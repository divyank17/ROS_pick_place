/*******************************************************************************
*    File Name   : hartstack.hpp                                               *
*    Description : HART protocol stack classes declaration.                    *
*******************************************************************************/
#ifndef __HARTSTACK_HPP__
#define __HARTSTACK_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifndef HARTSTACK_SIZE_T_DEFINED
typedef __SIZE_TYPE__ size_t;
#define HARTSTACK_SIZE_T_DEFINED
#endif

#include "datatype.h"
#include "hart.h"
#include "hal_fpga.h"
#if defined(IOMTYPE_AIH)
#include "commonelectronics.h"
#endif

/* Keep the RT1024 synchronous transaction engine as the production path.
 * The interrupt state-machine declarations remain in their original order. */
#ifndef HART_USE_RT1024_SYNCHRONOUS_TRANSPORT
#define HART_USE_RT1024_SYNCHRONOUS_TRANSPORT (1u)
#endif

#ifndef HART_ENABLE_MODEM_DIAGNOSTICS
#define HART_ENABLE_MODEM_DIAGNOSTICS (0u)
#endif

/* Static C++ objects are constructed before the RT1024 FPGA/SPI HAL is ready.
 * Production hardware initialization is performed by HartStack_Reset(). */
#ifndef HART_INITIALIZE_UART_IN_CONSTRUCTOR
#define HART_INITIALIZE_UART_IN_CONSTRUCTOR (0u)
#endif

#ifndef HART_RCVINTR_ENABLE
#define HART_RCVINTR_ENABLE HART_IER_RX_MODEM_STATUS
#endif

#ifndef HART_XMTINTR_ENABLE
#define HART_XMTINTR_ENABLE HART_IER_TX_EMPTY
#endif

#ifndef HART_RCVERROR_PRESENT
#define HART_RCVERROR_PRESENT HART_UART_LINE_STS_ERROR_BITS
#endif

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagHModemState {
    HMODEMSTATE_BAD,
    HMODEMSTATE_IDLE,
    HMODEMSTATE_SYNCWAIT,
    HMODEMSTATE_XMTING,
    HMODEMSTATE_RCVWAIT,
    HMODEMSTATE_RCVING,
    HMODEMSTATE_SUSPECT,
    HMODEMSTATE_DIAG
} HMODEMSTATE;

typedef enum tagHSyncStatus {
    HSYNCSTATUS_UNKNOWN,
    HSYNCSTATUS_KEEP_SYNC,
    HSYNCSTATUS_DROP_SYNC
} HSYNCSTATUS;

typedef enum tagHIntrType {
    HINTRTYPE_UNKNOWN,
    HINTRTYPE_RCVFIFOFULL,
    HINTRTYPE_RCVFIFOTOUT,
    HINTRTYPE_XMTFIFOEMPTY,
    HINTRTYPE_CARRIERDETECT,
    HINTRTYPE_CARRIERDROP
} HINTRTYPE;

typedef enum tagHMsgType {
    HMSGTYPE_UNKNOWN,
    HMSGTYPE_STX,
    HMSGTYPE_ACKTOME,
    HMSGTYPE_ACKTOHIM,
    HMSGTYPE_BACKTOME,
    HMSGTYPE_BACKTOHIM,
    HMSGTYPE_STXFROMME
} HMSGTYPE;

typedef enum tagHMsgStatus {
    HMSGSTATUS_GOOD,
    HMSGSTATUS_BAD,
    HMSGSTATUS_DEVICEERROR
} HMSGSTATUS;

typedef enum tagHEventType {
    HEVENTTYPE_UNKNOWN,
    HEVENTTYPE_COMMERROR,
    HEVENTTYPE_NORESPONSE,
    HEVENTTYPE_DEVICEERROR,
    HEVENTTYPE_RCVRERROR,
    HEVENTTYPE_RETRY,
    HEVENTTYPE_TOTALTIMEOUT,
    HEVENTTYPE_SECMASTER,
    HEVENTTYPE_BURSTMODE,
    HEVENTTYPE_PRIMASTER
} HEVENTTYPE;

typedef enum tagXmtRcvContext {
    XMTRCVCONTEXT_UNKNOWN,
    XMTRCVCONTEXT_PREAMBLE,
    XMTRCVCONTEXT_DELIMITER,
    XMTRCVCONTEXT_ADDRESS,
    XMTRCVCONTEXT_COMMAND,
    XMTRCVCONTEXT_BYTECOUNT,
    XMTRCVCONTEXT_STATUS,
    XMTRCVCONTEXT_DATA
} XMTRCVCONTEXT;

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
#if !defined(IOMTYPE_AIH)
const UINT8 HARTMODEM_COUNT        = 4;
#endif
const UINT8 HARTQUEUE_BUFFER_SIZE  = 16;
const UINT8 HARTMODEM_BUFFER_SIZE  = 32;
const UINT8 HSYNC_MINIMUM_TIME     = 1;
const UINT8 CHECKPAD_BYTECOUNT     = 2;
const UINT8 XMTINT_ALLOWANCE       = 1;
const UINT8 RCVINT_ALLOWANCE       = 2;
const UINT8 MAX_DRIBBLE_BYTES      = 2;
const UINT8 UART_XMT_FIFO_SIZE     = 16;
const UINT8 UART_RCV_FIFO_SIZE     = 16;
const UINT8 HMODEMDIAG_MAXCOUNT    = 3;
const UINT8 HMODEMDIAG_UNDERRUN_MAXCOUNT = 10;
const UINT8 HART_LOOPBACK_SIZE     = 12;
const UINT8 HART_ENABLE_ALL_MUXES  = 0x0F;
const UINT8 HART_UART_8BITS_PER_CHAR = 0x03;
const UINT8 HART_UART_LINE_STS_ERROR_BITS = 0x1E;
const UINT8 HART_LOOPBACK_PATTERN[HART_LOOPBACK_SIZE] = { 0xAA,0x55,0xA5,0x5A,
                                                          0xCC,0x33,0xC3,0x3C,
                                                          0xF0,0x0F,0x00,0xFF };

/* Size definitions are retained in UINT16 units so allocation expressions from
 * the source module continue to read the same way as the HART module they came
 * from.  The RT1024 build uses static objects, but these names are kept for
 * maintenance and integration compatibility. */
#define CLSHARTMODEM_SIZE ((sizeof(clsHartModem)+(sizeof(clsHartModem)%2)) / 2)
#define CLSHARTQUEUE_SIZE ((sizeof(clsHartQueue)+(sizeof(clsHartQueue)%2)) / 2)

/*******************************************************************************
*                               clsClientBuffer                                *
*                               ===============                                *
*  This class automates buffer management activities for clients of HART stack  *
*  like channel objects and for passthrough response.                           *
*******************************************************************************/
class clsClientBuffer {
    const UINT16 m_BUFSIZE;
    UINT8 *m_ucpBuffer;
    UINT16 m_usIndex;

public:
    clsClientBuffer(UINT16 a_usBufSize, UINT8 *a_ucpBuf);
    VOID Flush(VOID);
    UINT8 At(UINT16 a_usIndex);
    UINT8 *AddrAt(UINT16 a_usIndex);
    clsClientBuffer& operator=(const UINT8 a_ucData);
};

/*******************************************************************************
*                                 clsHartQueue                                 *
*                                 ============                                 *
*******************************************************************************/
class clsHartQueue {
    UINT8 m_ucNextIndex;
    UINT8 m_ucBuffer[HARTQUEUE_BUFFER_SIZE];

public:
    clsHartQueue(VOID);
    VOID *operator new(size_t, UINT8);
    BOOL AddToQueue(UINT8 a_ucChan);
    BOOL RemoveFromQueue(UINT8 a_ucChan);
    VOID ProcessQueue(UINT8 a_ucModemNumber);
    BOOL IsModemQueueEmpty(VOID);
    VOID operator delete(VOID *) {}
};

/*******************************************************************************
*                                clsModemBuffer                                *
*                                ==============                                *
*******************************************************************************/
class clsModemBuffer {
    UINT8   *m_ucpAppend;   // Append pointer used to add data to FIFO.
    UINT8   *m_ucpRemove;   // Remove pointer used to pop data from FIFO.
    UINT8   m_ucCount;      // Current size of the FIFO.

    UINT8   m_ucBuffer[HARTMODEM_BUFFER_SIZE];  // FIFO buffer.

public:
    clsModemBuffer(VOID);
    unsigned short GetLength(void);
    VOID Flush(VOID);
    UINT8 PopChar(VOID);
    VOID ThrowLastRcvd(VOID);
    clsModemBuffer& operator=(const UINT8 a_cucData);
};

/*******************************************************************************
*                                 clsHartModem                                 *
*                                 ============                                 *
*  clsHartModem implements the HART data link layer entry points used by the    *
*  source module. The RT1024 implementation keeps these names while the register   *
*  access is routed through hal_fpga.h.                                         *
*******************************************************************************/
class clsHartModem {
    /* Static modem state used by the data-link diagnostics and transport. */
    static UINT8  m_ucHartMuxEnbl;
    static UINT16 m_usHartMuxAddr;
    static UINT8  m_ucHDiagUnderRunCount;
    static UINT8  m_ucFailedChannel;
    static UINT32 m_sulMDiagCount;

    const UINT8 m_ucModemNumber;
    UINT8 m_ucModemTimer;
    HMODEMSTATE m_ModemState;
    UINT8 m_ucConnectedChannel;

    /* Transmit and receive state retained in the original member order. */
    const UINT8    *m_cucpXmtBuffer;
    clsModemBuffer  m_ModemRcvBuffer;
    UINT8           m_ucPollingAddress;
    HARTUNIQUEADDR  m_UniqueAddress;
    UINT8           m_ucXmtCommand;
    UINT8           m_ucBytesInRequest;
    UINT16          m_ucBytesInResponse;
    XMTRCVCONTEXT   m_XmtRcvContext;
    HMSGTYPE        m_RcvMsgType;
    HMSGSTATUS      m_RcvMsgStatus;
    UINT8           m_ucCheckSum;
    UINT8           m_ucRemPreambles;
    UINT8           m_ucRcvdDelimiter;
    UINT8           m_ucRetryCount;
    BOOL            m_bRequestDisconnect;
    BOOL            m_bBurstDeviceFound;
    UINT8           m_ucModemDiagCount;
#if defined(IOMTYPE_UIO)
    BOOL            m_bHartStackProc;
#endif

    VOID SetState(HMODEMSTATE a_ModemState, UINT8 a_ucTimer);
    VOID ModemTimeout(VOID);
    VOID TransmitRequest(VOID);
    VOID ProcessResponse(VOID);
    VOID DecodeResponse(VOID);
    VOID ActOnResponse(VOID);
    VOID SetupRetry(UINT8 a_ucRetryReason);
    VOID HandleReceiveError(VOID);
    VOID ProcessDiagModem(VOID);

public:
    clsHartModem(UINT8 a_ucModemNumber);
    VOID *operator new(size_t, UINT8);
    VOID HartModemInterrupt(HINTRTYPE a_IntrType);
    static VOID HartModemHeartbeat(VOID);
    UINT8 HartMuxLoopbackTest(VOID);
    VOID Connect(UINT8 a_ucChan);
#if defined(IOMTYPE_UIO)
    VOID Disconnect(BOOL bResetState);
#endif
    VOID Disconnect(VOID);
    VOID DiagConnect(UINT8 a_ucChan);
    VOID SwitchMux(UINT8 a_ucChan);

#if defined(IOMTYPE_UIO)
    BOOL IsHartStackProc(VOID) { return m_bHartStackProc; }
#endif
    UINT8 GetModemNumber(VOID) { return m_ucModemNumber; }
    UINT8 GetConnectedChannel(VOID) { return m_ucConnectedChannel; }
    UINT8 GetFailedChannel(VOID) { return m_ucFailedChannel; }
    VOID RequestDisconnect(VOID) { m_bRequestDisconnect = TRUE; }
    HMODEMSTATE GetModemState(VOID) { return m_ModemState; }
    UINT8 GetModemTimer(VOID) { return m_ucModemTimer; }
    UINT8 GetModemDiagCount(VOID) { return m_ucModemDiagCount; }

    VOID ReinstateModem(VOID);
    VOID SetModemBad(VOID);
    VOID ClearModemBad(VOID);
    VOID ClearTxRxFIFOs(VOID);
    VOID operator delete(VOID *) {}
};

/*******************************************************************************
*                    RT1024 FPGA/SPI TRANSPORT EXTENSIONS                    *
*******************************************************************************/
/* The following structures and APIs back the RT1024 transport. */

typedef struct tagHartParsedResponse {
    BOOL valid;
    BOOL checksumOk;
    BOOL isLongAddress;
    BOOL hasStatus;

    UINT8 preambleCount;
    UINT8 delimiter;
    UINT8 address[HART_LONGADDR_LENGTH];
    UINT8 addressLen;
    UINT8 command;
    UINT8 byteCount;
    UINT8 status0;
    UINT8 status1;
    UINT8 payloadLen;
    UINT8 payload[64];
    UINT8 checksumRx;
    UINT8 checksumCalc;

    UINT8 longAddr[HART_LONGADDR_LENGTH];
    UINT8 responsePreambles;
    UINT8 hartRevision;
    UINT8 deviceRevision;
} HartParsedResponse_t;

#ifdef __cplusplus
extern "C" {
#endif

VOID   HartStack_Reset(VOID);
BOOL   HartStack_GetCleanCmd0(UINT8 channel, UINT8 modem, UINT8 pollAddr,
                              HartParsedResponse_t *cmd0Out);
BOOL   HartStack_ExtractLongAddressFromCmd0(
           const HartParsedResponse_t *cmd0,
           UINT8 longAddr[HART_LONGADDR_LENGTH],
           UINT8 *respPreambles);
BOOL   HartStack_RunLongCommand(
           UINT8 channel, UINT8 modem, UINT8 pollAddr,
           const UINT8 longAddr[HART_LONGADDR_LENGTH],
           UINT8 command, const UINT8 *data, UINT8 dataLen,
           HartParsedResponse_t *parsedOut);
BOOL   HartStack_ResponseHasRequiredPayload(
           UINT8 command, const HartParsedResponse_t *response);

#ifdef __cplusplus
}
#endif


/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
extern clsHartQueue HartQueue;
extern clsHartModem *pHartModem[HARTMODEM_COUNT];

/*******************************************************************************
*                               GLOBAL FUNCTIONS                               *
*******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


VOID CheckAndInitHart(VOID);
BOOL isHartCapable(VOID);
VOID ProcessHartInterrupt(VOID);
BOOL InitHartConnection(UINT8 a_ucChan);
VOID ResetHart(VOID);
BOOL AbortHartConnection(UINT8 a_ucChan);

#ifdef __cplusplus
}
#endif

#endif
