/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihslot.hpp                                                 *
*    Description : Class clsAihSlot declaration.                               *
*******************************************************************************/
#ifndef __AIHSLOT_HPP__
#define __AIHSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aixslot.hpp"

#include "hartdb.hpp"


/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define AIHSLOT_SIZE ((sizeof(clsAihSlot) + (sizeof(clsAihSlot) % 2)) / 2)


/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define AIHSLOT_SIZE ((sizeof(clsAihSlot) + (sizeof(clsAihSlot) % 2)) / 2)

//PARAMETER NUMBER CONTANTS
#define PARAMID_LOCUTOFF    58
#define PARAMID_PVCHAR      68
#define PARAMID_PVCLAMP     69
#define PARAMID_PVEUHI      70
#define PARAMID_PVEULO      71
#define PARAMID_PVEXEUHI    72
#define PARAMID_PVEXEULO    73
#define PARAMID_PVRAWHI     87
#define PARAMID_PVRAWLO     88
#define PARAMID_PVTEMP      96
#define PARAMID_PVTV        97
#define PARAMID_PVTVP       98
#define PARAMID_SENSRTYP    99
#define PARAMID_TF          103

#if !defined(IOMTYPE_UIO) //(UIO definitions in aihslot.cpp)
#define PARAMID_INPTDIR     56
#define PARAMID_PNTTYPE     60
#define PARAMID_PTEXECST    61
#define PARAMID_PVSOURCE    93
#define PARAMID_PVSRCOPT    94
#endif

#if 1//defined(IOPTYPE_HLAI)
// for PMIO Redesign non-available param id
#define PARAMID_ALMINFO     51
#define PARAMID_CONTCUT     54
#define PARAMID_LASTPV      57
#define PARAMID_PNTFORM     59
#define PARAMID_PV          63
#define PARAMID_PVALDB      64
#define PARAMID_PVFORMAT    76
#define PARAMID_PVHHTP      78
#define PARAMID_PVHITP      80
#define PARAMID_PVLLTP      82
#define PARAMID_PVLOTP      84
#define PARAMID_PVP         85
#define PARAMID_PVROCNTP    90
#define PARAMID_PVROCPTP    92
#define PARAMID_PVSTS       95
#define PARAMID_SLWSRCID    101
#define PARAMID_PVALDBEU    107
#define PARAMID_PVEUHIRV    117
#define PARAMID_PVEULORV    118
#define PARAMID_PTEXECSTLRS 245
#define PARAMID_EUSPAN      247
#define PARAMID_KF          248
#define PARAMID_RAWSPAN     249

//5th order polynomial
#define TOTAL_COEFFS        5

#endif

#if defined(IOPTYPE_SCIOM)
const UINT8 AIHSLOT_SPARESIZE            = 16;
#else
const UINT8 AIHSLOT_SPARESIZE = 8;
#endif
const UINT8 OPENWIRE_TOTAL_TESTCOUNT     = 5;
const UINT8 OPENWIRE_PVFALL_MAXCOUNT     = 5;


//5th order polynomial
#define TOTAL_COEFFS        5

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsAihSlot; // forward declaration
typedef struct tagAiSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsAihSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsAihSlot::* PostPtr)(UINT8);
    VOID *   (clsAihSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} AI_SLOTPARAMINFO;

/*******************************************************************************
*                                   clsAihSlot                                 *
*                                   ==========                                 *
*******************************************************************************/
class clsAihSlot : public clsAixSlot {
    friend class clsAihBoxSlot;

    // for PMIO Redeisgn HLAI TC & RTD coeff's.
private:
    // J-Type Thermo-Couple coefficient table
    static  const FLOAT32 J_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 J_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 J_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 J_COEFF_SET3[TOTAL_COEFFS];
    static  const FLOAT32 J_COEFF_SET4[TOTAL_COEFFS];
    static  const FLOAT32 J_COEFF_SET5[TOTAL_COEFFS];
    // K-Type Thermo-Couple coefficient table
    static  const FLOAT32 K_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 K_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 K_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 K_COEFF_SET3[TOTAL_COEFFS];
    static  const FLOAT32 K_COEFF_SET4[TOTAL_COEFFS];
    static  const FLOAT32 K_COEFF_SET5[TOTAL_COEFFS];
    // E-Type Thermo-Couple coefficient table
    static  const FLOAT32 E_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 E_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 E_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 E_COEFF_SET3[TOTAL_COEFFS];
    static  const FLOAT32 E_COEFF_SET4[TOTAL_COEFFS];

    // T-Type Thermo-Couple coefficient table
    static  const FLOAT32 T_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 T_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 T_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 T_COEFF_SET3[TOTAL_COEFFS];
    // B-Type Thermo-Couple coefficient table
    static  const FLOAT32 B_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 B_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 B_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 B_COEFF_SET3[TOTAL_COEFFS];
    static  const FLOAT32 B_COEFF_SET4[TOTAL_COEFFS];
    static  const FLOAT32 B_COEFF_SET5[TOTAL_COEFFS];
    // S-Type Thermo-Couple coefficient table
    static  const FLOAT32 S_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 S_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 S_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 S_COEFF_SET3[TOTAL_COEFFS];
    static  const FLOAT32 S_COEFF_SET4[TOTAL_COEFFS];
    // R-Type Thermo-Couple coefficient table
    static  const FLOAT32 R_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 R_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 R_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 R_COEFF_SET3[TOTAL_COEFFS];
    static  const FLOAT32 R_COEFF_SET4[TOTAL_COEFFS];
    // JR-Type Thermo-Couple coefficient table
    static  const FLOAT32 JR_COEFF_SET0[TOTAL_COEFFS];
    static  const FLOAT32 JR_COEFF_SET1[TOTAL_COEFFS];
    static  const FLOAT32 JR_COEFF_SET2[TOTAL_COEFFS];
    static  const FLOAT32 JR_COEFF_SET3[TOTAL_COEFFS];
    static  const FLOAT32 JR_COEFF_SET4[TOTAL_COEFFS];
    // PTDIN-Type RTD coefficient table
    static  const FLOAT32 PTDIN_SET0[TOTAL_COEFFS];
    static  const FLOAT32 PTDIN_SET1[TOTAL_COEFFS];
    static  const FLOAT32 PTDIN_SET2[TOTAL_COEFFS];
    // PTJIS-Type RTD coefficient table
    static  const FLOAT32 PTJIS_SET0[TOTAL_COEFFS];
    static  const FLOAT32 PTJIS_SET1[TOTAL_COEFFS];
    static  const FLOAT32 PTJIS_SET2[TOTAL_COEFFS];
    // NIRTD-Type RTD coefficient table
    static  const FLOAT32 NIRTD_SET0[TOTAL_COEFFS];
    static  const FLOAT32 NIRTD_SET1[TOTAL_COEFFS];
    // CURTD-Type RTD coefficient table
    static  const FLOAT32 CURTD_SET0[TOTAL_COEFFS];

    // TABLE OF COEFFICEINT SET POINTERS
    static  const FLOAT32 *J_TYPE[];
    static  const FLOAT32 *K_TYPE[];
    static  const FLOAT32 *E_TYPE[];
    static  const FLOAT32 *T_TYPE[];
    static  const FLOAT32 *B_TYPE[];
    static  const FLOAT32 *S_TYPE[];
    static  const FLOAT32 *R_TYPE[];
    static  const FLOAT32 *JR_TYPE[];
    static  const FLOAT32 *PTDIN[];
    static  const FLOAT32 *PTJIS[];
    static  const FLOAT32 *NIRTD[];
    static  const FLOAT32 *CURTD[];

    //TABLE OF THERMOCOUPLE TYPE POINTERS
    static  const FLOAT32 **POLY_COEFF_SET[];

    //J TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 J_BP[];
    //K TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 K_BP[];
    //E TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 E_BP[];
    //T TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 T_BP[];
    //B TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 B_BP[];
    //S TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 S_BP[];
    //R TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 R_BP[];
    //JR TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 JR_BP[];
    //PTD TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 PTD_BP[];
    //PTJ TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 PTJ_BP[];
    //NI TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 NI_BP[];
    //CU TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
    static  const FLOAT32 CU_BP[];
    // TABLE OF BREAKPOINT POINTERS
    static  const FLOAT32 *BP_POINTER_TAB[];

public:
    // Checkpoint / redundancy tables
    static const UINT8 CheckPointVer1[];
    static const UINT8 CheckPointVer2[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
#if defined(IOMTYPE_UIO)
    static UINT8 AiSlotChkpntVersion;
#else
    static UINT8 SlotChkpntVersion;
#endif
    static const UINT8 RedParams[];
    static const UINT8 HEuRngExt[];
#if 1//defined(IOPTYPE_HLAI)
    static const UINT8 PmCheckPoint[];
    static const UINT8 PvRec[];
    static const UINT8 PmioDumpParamTbl[];
    static const UINT8 PmioHartDumpParamTbl[];
    static const UINT8 PvStRec[];
#endif

protected:
    UINT8    AihSlotSpare[AIHSLOT_SPARESIZE];

    INPTDIR  InptDir;
    PVCHAR   PvChar;
    FLOAT32  PvRawHI;
    FLOAT32  PvRawLO;
    PVTEMP   PvTemp;
    SENSRTYP SensrTyp;
    FLOAT32  ADRawHi;
    FLOAT32  ADRawLo;
    FLOAT32  HundredDivRawSpan;

    clsHartCfgDb HartCfgDb;
    clsHartCfgDb7 HartCfgDb7; //New parameters added for HART 7.

    clsHartDevDb HartDevDb;
#if 1//defined(IOPTYPE_HLAI)
    FLOAT32  PvEuHiRv;
    FLOAT32  PvEuLoRv;
    BOOL     DbChkFlg;
    UINT8    SlotCfgd;
#endif

    UINT16 RawAdcCount;
    BOOL InputBelowDeadband;
    UINT8 OpenWireTestCount;
    UINT8 OpenWirePvFallCount;

    static const AI_SLOTPARAMINFO tblParamInfo[256];

    VOID InitAihSlot(BOOL bFullInit, BOOL bObjCreate);

    FLOAT32* GenPolyPtr(FLOAT32 fPvRawVal);
    FLOAT32 EUConversion(FLOAT32* a_fCoeffOffSet);
    FLOAT32 ConvTempUnit(FLOAT32 rTemp);

    inline VOID *GetInptDirPtr(VOID)    {return &InptDir;}
    inline VOID *GetPvCharPtr(VOID)     {return &PvChar;}
    inline VOID *GetPvRawHIPtr(VOID)    {return &PvRawHI;}
    inline VOID *GetPvRawLOPtr(VOID)    {return &PvRawLO;}
    inline VOID *GetPvTempPtr(VOID)     {return &PvTemp;}
    inline VOID *GetSensrTypPtr(VOID)   {return &SensrTyp;}
    inline VOID *GetADRawHiPtr(VOID)    {return &ADRawHi;}
    inline VOID *GetADRawLoPtr(VOID)    {return &ADRawLo;}

    UINT8    *GetParamPtr(UINT8) override;

    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);


    PASTATUS PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPntType(UINT8 a_ucAccLvl);
    PASTATUS PrePtExecSt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPtExecSt(UINT8 a_ucAccLvl);

    VOID     PostPvSrcOpt(UINT8 a_ucAccLvl);

    VOID     PostPvEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvExEUHi(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvExEULo(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEULo(UINT8 a_ucAccLvl);

    PASTATUS PrePvRawHI(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PrePvRawLO(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PrePvTemp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreSensrTyp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostSensrTyp(UINT8 a_ucAccLvl);
    VOID     PostTf(UINT8 a_ucAccLvl);
    PASTATUS PreOwdEnable(UINT8 *a_Writebuffer,UINT8);

    PASTATUS PreCommand(UINT8 *,UINT8);
    VOID     PostCommand(UINT8);
    PASTATUS PreHEuRngExt(UINT8 *,UINT8);
    PASTATUS PreHEnable(UINT8 *,UINT8);
    VOID     PostHEnable(UINT8);
    PASTATUS PreHAlarmEnable(UINT8 *,UINT8);
    VOID     PostHAlarmEnable(UINT8);
    PASTATUS PreHScanCfg(UINT8 *,UINT8);
    VOID     PostHScanCfg(UINT8);
    PASTATUS PreHComThrs(UINT8 *,UINT8);
    PASTATUS PreHComHys(UINT8 *,UINT8);
    VOID     PostHDevIdCd(UINT8);
    PASTATUS PreHDvMfgCd(UINT8 *,UINT8);
    PASTATUS PreHDvTypCd(UINT8 *,UINT8);
    PASTATUS PreHDvMfgCd7(UINT8 *,UINT8);
    PASTATUS PreHDvTypCd7(UINT8 *,UINT8);
    PASTATUS PreHDvRevCd(UINT8 *,UINT8);
    PASTATUS PreHDdRevCd(UINT8 *,UINT8);


    PASTATUS PreLoCutOff(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreInptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);

    PASTATUS PrePvChar(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    inline VOID *GetPvClampPtr(VOID)  {return &PvClamp;}

    clsAihSlot(const clsAihSlot&); // Safeguard against default copy constructor
    clsAihSlot& operator=(const clsAihSlot&); // and default assignment

public:
    clsAihSlot(UINT8);
    ~clsAihSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    //VOID *operator new(UINT32,UINT8);
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    VOID InitSlotDatabase(BOOL bFullInit);
    VOID InactivateSlot(VOID);

    DATATYPE   GetDataType(UINT8) override;
    ACCESSTYPE GetAccessType(UINT8) override;
    UINT8      GetParamSize(UINT8) override;
    ACCESSLOCK GetAccessLock(UINT8) override;
    BOOL       GetIsDbChecksumed(UINT8) override;
    PASTATUS   VerifyControlState(UINT8) override;

    VOID ValidateOwdCkt(BOOL,FLOAT32);
    VOID ProcessSlot(FLOAT32);

    inline VOID InitPvDb(VOID) {
        PvRaw = NaN;
        PvCalc = NaN;
        PvAuto = NaN;
        FiltOut = NaN;
        PvAutoSt = PVVALST_BAD;
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
    }

    BOOL AlarmEvents(EVENTTYPE a_EventType);
    inline UINT8 GetAlmInfo(VOID) { return AlmInfo.ucByte; }
    inline UINT8 GetAlarmLrs(VOID) { return AlarmLrs.ucByte; }
    VOID CreatePtExecStEvt(EVENTTYPE a_EventType);


    inline SENSRTYP GetSensrType(VOID) {return SensrTyp;}

    inline BOOL WasInputBelowDeadband(VOID) { return InputBelowDeadband; }
    inline VOID SetInputBelowDeadband(BOOL a_bFlg) { InputBelowDeadband = a_bFlg; }

    inline VOID EnableOpenWireCheck(VOID) {
        OpenWireTestCount = 0;
        if ((TRUE == OwdEnable) && (PTEXECST_ACTIVE == PtExecSt)) {
            //OWD_CSEL = ChanNum - 1;
            //OWD_ENB = 1;
        }
    }
    inline VOID DisableOpenWireCheck(VOID) {
        //OWD_ENB = 0;
    }
    inline BOOL IsWireOpen(VOID) {

    	BOOL bWireOpen = (OpenWireTestCount >= OPENWIRE_TOTAL_TESTCOUNT) ? TRUE : FALSE;

        OpenWireTestCount = 0;
        //OWD_ENB = 0;
        return bWireOpen;
    }
    inline VOID CheckOpenWire(VOID) {
        // check if open wire detection is enabled
        // also, PvRaw must be >= 0.0 to check open-wire. This will prevent false-positives
        //     due to HART comm pulling the signal below the OWD threshold. The checking
        //     must continue once an open-wire is detected (PvRaw becomes NaN) to ensure
        //     the alarm will RTN only after the open-wire condition has been resolved.
        /*
    	if (OWD_ENB && ((PvRaw >= 0.0) || IsOwdSfBtSet()))
        {
            if (!GOODINPUT) OpenWireTestCount++;
        }*/
    }

    inline VOID ResetOpenWirePvFallCount(VOID) { OpenWirePvFallCount = 0; }

    inline BOOL IsOwdSfBtSet(VOID) { 

        const UINT8 AI_SFBT_MASK_FOR_OWD = 0x04;

        return (SlotSfBt & AI_SFBT_MASK_FOR_OWD) ? TRUE : FALSE;
    }

    inline VOID StoreRawAdcCount(UINT16 a_uiData) { RawAdcCount = a_uiData; }

    inline FLOAT32 GetADRawLo(VOID)           { return ADRawLo;  }
    inline FLOAT32 GetHundredDivRawSpan(VOID) { return HundredDivRawSpan; }

#if 1//defined(IOPTYPE_HLAI)
    inline VOID *GetHSlDvcPtr(VOID)         { return HartCfgDb.HSlotDvc; }
    inline VOID *GetSlotCfgdPtr(VOID)       { return &SlotCfgd; }
    inline VOID *GetPmCheckPointPtr(VOID)   { return (VOID *)PmCheckPoint; }
    inline VOID *GetPvEuHiRvPtr(VOID)       { return &PvEuHiRv; }
    inline VOID *GetPvEuLoRvPtr(VOID)       { return &PvEuLoRv; }
    inline VOID *GetDbChkFlgPtr(VOID)       { return &DbChkFlg; }
    inline VOID *GetPvRecPtr(VOID)          { return (VOID *)PvRec; }
    /**
     * added to fix following customer issues,
     * SR 1-27797231845/ SF 00611701 / BW-40405
     * SR 1-27868328215/ SF 00616362 / BW-40433 / FAR 1-CTDY638
     */
    inline VOID *GetPvStRecPtr(VOID)        { return (VOID *)PvStRec; }
#endif

#if 1 // temp for testing
    inline PVCHAR GetPvChar(VOID)     {return PvChar;}
#endif

#if 1//defined(IOPTYPE_HLAI)
    PASTATUS PreContCut(UINT8 *, UINT8);
    PASTATUS PrePvSrcOpt(UINT8 *, UINT8);

    VOID PostPntForm(UINT8);
    VOID PostPvRawHI(UINT8);

    FLOAT32 GetSlideWireRatio(FLOAT32 fPvRawVal);
#endif

    inline VOID *GetLrvPtr(VOID)        { return &HartDevDb.Lrv; }
    inline VOID *GetUrvPtr(VOID)        { return &HartDevDb.Urv; }
    inline VOID *GetLrlPtr(VOID)        { return &HartDevDb.Lrl; }
    inline VOID *GetUrlPtr(VOID)        { return &HartDevDb.Url; }
    inline VOID *GetDampingPtr(VOID)    { return &HartDevDb.Damping; }
    inline VOID *GetStiEuPtr(VOID)      { return &HartDevDb.StiEu; }

    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SlotChkpntVersion-1].CheckPointPtr; }

    // HART stack interface functions retained from the legacy AIH source.
    inline UINT8 GetChannelNumber(VOID) { return ChanNum; }
    inline HCHANTYPE GetHartChanType(VOID) { return HartDevDb.m_HChanType; }
    inline UINT8 GetPollingAddress(VOID) { return HartDevDb.m_ucPollingAddress; }
    inline VOID SetPollingAddress(UINT8 a_ucAddr) { HartDevDb.m_ucPollingAddress = a_ucAddr; }
    inline HARTUNIQUEADDR GetUniqueAddress(VOID) { return HartDevDb.m_UniqueAddress; }
    inline UINT8 GetNoOfPreambleBytes(VOID) { return HartDevDb.m_ucReqdPreambles; }
    inline const UINT8 *GetXmtDataPtr(VOID) { return HartDevDb.m_ucpLastXmtPtr; }

    inline HSYNCSTATUS ReceptionComplete(HMSGSTATUS a_HartMsgSts) {
        return HartDevDb.ReceptionComplete(a_HartMsgSts);
    }

    inline VOID LogEvent(HEVENTTYPE a_HartEventType) {
        HartDevDb.LogEvent(a_HartEventType);
    }

    inline UINT8 GetRetryCount(VOID) {
        UINT8 ucReturn = HART_MAX_RETRIES;
        if (FALSE == HartCfgDb.HEnable) {
            ucReturn = HART_AUTODISCOVERY_RETRYCOUNT;
        }
        return ucReturn;
    }

    clsClientBuffer& GetRcvBufObject(VOID);

    inline clsHartCfgDb& GetHartCfgDb(VOID) { return HartCfgDb; }
    inline clsHartDevDb& GetHartDevDb(VOID) { return HartDevDb; }


#if 1//defined(IOPTYPE_HLAI)
    inline VOID *GetStatePtr(VOID)      { return &HartDevDb.State; }

#endif
    inline VOID *GetCommandPtr(VOID)    { return &HartDevDb.Command; }
    inline VOID *GetHDevCdPtr(VOID)     { return (VOID *)HartCfgDb.HDevCd; }
    inline VOID *GetHDvRngExtPtr(VOID)  { return (VOID *)HartDevDb.HDvRngExt; }
    inline VOID *GetHEuRngExtPtr(VOID)  { return (VOID *)HEuRngExt; }
    inline VOID *GetHAlarmEnablePtr(VOID) { return &HartCfgDb.HAlarmEnable; }
    inline VOID *GetHEnablePtr(VOID)    { return &HartCfgDb.HEnable; }
    inline BOOL GetHEnable(VOID)         { return HartCfgDb.HEnable; }
    inline VOID SetHEnable(BOOL a_bHEnable) { HartCfgDb.HEnable = (UINT8)a_bHEnable; }
    inline VOID *GetHScanCfgPtr(VOID)   { return &HartCfgDb.HScanCfg; }
    inline VOID *GetHDynRatePtr(VOID)   { return &HartDevDb.HDynRate; }
    inline VOID *GetHDevRatePtr(VOID)   { return &HartDevDb.HDevRate; }
    inline VOID *GetHSlotDvcPtr(VOID)   { return HartCfgDb7.HSlotDvc7; }
    inline VOID *GetHSlotDvcPtr7(VOID)  { return &HartCfgDb7.HSlotDvc7[4];}
    inline VOID *GetHComThrsPtr(VOID)   { return &HartCfgDb.HComThrs; }
    inline VOID *GetHComHysPtr(VOID)    { return &HartCfgDb.HComHys; }
    inline VOID *GetHComStsPtr(VOID)    { return &HartDevDb.HComSts; }
    inline VOID *GetHNComErrPtr(VOID)   { return &HartDevDb.HNComErr; }
    inline VOID *GetHLComFailPtr(VOID)  { return &HartDevDb.HLComFail; }
    inline VOID *GetHCmd0Ptr(VOID)      { return &HartDevDb.HCmd0; }
    inline VOID *GetH7Cmd0Ptr(VOID)     { return &HartDevDb.HCmd0.ucBytes[HART6_CMD0_RESPONSE_SIZE]; }
    inline VOID *GetHCmd12Ptr(VOID)     { return &HartDevDb.HCmd12; }
    inline VOID *GetHCmd13Ptr(VOID)     { return &HartDevDb.HCmd13; }
    inline VOID *GetHCmd14Ptr(VOID)     { return &HartDevDb.HCmd14; }
    inline VOID *GetHCmd15Ptr(VOID)     { return &HartDevDb.HCmd15; }
    inline VOID *GetHCmd16Ptr(VOID)     { return &HartDevDb.HCmd16; }
    inline VOID *GetHLongTagPtr(VOID)   { return &HartDevDb.HLongTag; }
    inline VOID *GetHDynValPtr(VOID)    { return HartDevDb.HDynVal; }
    inline VOID *GetHDynStPtr(VOID)     { return HartDevDb.HDynSt; }
    inline VOID *GetHDynCcPtr(VOID)     { return HartDevDb.HDynCc; }
    inline VOID *GetHDynEuPtr(VOID)     { return HartDevDb.HDynEu; }
    inline VOID *GetHSlot0TSPtr(VOID)   { return &HartDevDb.HDevSlot0DTS;}
    inline VOID *GetHSlotValPtr(VOID)   { return HartDevDb.HSlotVal; }
    inline VOID *GetHSlotStPtr(VOID)    { return HartDevDb.HSlotSt; }
    inline VOID *GetHSlotCcPtr(VOID)    { return HartDevDb.HSlotCc; }
    inline VOID *GetHSlotEuPtr(VOID)    { return HartDevDb.HSlotEu; }
    inline VOID *GetHDevStPtr(VOID)     { return HartDevDb.HDevSt; }
    inline VOID *GetHCmd48Ptr(VOID)     { return &HartDevDb.HCmd48; }
    inline VOID *GetHCmdFailPtr(VOID)   { return &HartDevDb.HCmdFail; }
    inline VOID *GetHCmdRespPtr(VOID)   { return &HartDevDb.HCmdResp; }
    inline VOID *GetHDvMfgCdPtr(VOID)   { return &HartCfgDb.HDvMfgCd; }
    inline VOID *GetHDvMfgCd7Ptr(VOID)  { return HartCfgDb7.HDvMfgCd7;}
    inline VOID *GetHDevIdCdPtr(VOID)   { return HartCfgDb.HDevIdCd; }
    inline VOID *GetHDvTypCdPtr(VOID)   { return &HartCfgDb.HDvTypCd; }
    inline VOID *GetHDvTypCd7Ptr(VOID)  { return HartCfgDb7.HDvTypCd7;}
    inline VOID *GetHDvRevCdPtr(VOID)   { return &HartCfgDb.HDvRevCd; }
    inline VOID *GetHDdRevCdPtr(VOID)   { return &HartCfgDb.HDdRevCd; }
    inline VOID *GetHNtfyCfgPtr(VOID)   { return HartCfgDb.HNtfyCfg; }
    inline VOID *GetHDynDvcPtr(VOID)    { return HartDevDb.HDynDvc; }
    inline VOID *GetHartVersionPtr(VOID){ return &HartDevDb.m_ucHartVersion; }




};

#endif /* __AIHSLOT_HPP__ */
