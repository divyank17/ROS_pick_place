/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : tracelog_flash.hpp                                          *
*    Description : RT1024 external-flash adapter for the legacy TraceLog.       *
*******************************************************************************/
#ifndef __TRACELOG_FLASH_HPP__
#define __TRACELOG_FLASH_HPP__

#include "tracelog.hpp"

#if defined(CPU_MIMXRT1024CAG4B)

/* Limit work performed by one LowPriorityTask invocation. */
#ifndef TRACELOG_FLASH_RECORDS_PER_SERVICE
#define TRACELOG_FLASH_RECORDS_PER_SERVICE (8u)
#endif

/* One status line is emitted before AppMain() enables IO-Link. */
#ifndef TRACELOG_STARTUP_STATUS_PRINT
#define TRACELOG_STARTUP_STATUS_PRINT      (1u)
#endif

/* Hooks used only by the legacy clsTraceLog implementation. */
VOID TraceLogFlashBind(UINT8 *a_pucAppIndex,
                       UINT16 *a_pTraceLevel,
                       TRACERECORD *a_pTraceRecord);
VOID TraceLogFlashMarkRecordDirty(UINT8 a_ucIndex);
VOID TraceLogFlashPersistCrashBlock(VOID);

/* RT1024 platform lifecycle. */
BOOL TraceLogFlashInit(VOID);
VOID TraceLogFlashService(VOID);
VOID TraceLogPrintStartupStatus(VOID);

#endif /* CPU_MIMXRT1024CAG4B */

#endif /* __TRACELOG_FLASH_HPP__ */
