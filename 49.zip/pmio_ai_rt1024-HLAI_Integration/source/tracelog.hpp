/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tracelog.hpp                                                *
*    Description : Declaration of tracelog class.                              *
*******************************************************************************/
#ifndef __TRACELOG_HPP__
#define __TRACELOG_HPP__

// This file is used within the \io_arm_cm VOB for IOBreadCrumb definitions
// only. The IO_ARM_CM macro conditionally compiles this file for that purpose.
#if !defined(IO_ARM_CM)

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8 NO_OF_TRACERECORDS = 100;
const UINT8 CRASHBLOCKSIZE     = 20;
const UINT8 CRASHBLKSTARTINDEX = NO_OF_TRACERECORDS - CRASHBLOCKSIZE;
const UINT8 LASTTRACEINDEX     = CRASHBLKSTARTINDEX - 1;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef struct __attribute__((packed)) tagTraceRecord {
  UINT16  code;   //breadcrumb number
  UINT32  data;   //context data
  UINT32  time;   //time of occurance,10msec counter value
} TRACERECORD;

typedef enum tagTraceId {
    TRACEID_SCHEDULER   = 0x01,
    TRACEID_HPTASK      = 0x02,
    TRACEID_WRDBTASK    = 0x04,
    TRACEID_LPTASK      = 0x08,
    TRACEID_EVRCTASK    = 0x10,
    TRACEID_DIAGTASK    = 0x20,
    TRACEID_DEBUGTASK   = 0x40,
#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))
    TRACEID_APPLOG      = 0x80, /// redirect reads to application tracelog in shared memory.
#else
    TRACEID_SPARE       = 0x80, /// spare in case of other series C modules.
#endif
    TRACEID_GENERIC     = 0xFF
} TRACEID;

#endif // !defined(IO_ARM_CM)

////////////////////////////////////////////////////////////////////////////////
//
//  BREADCRUMB SYMBOL AND RESOURCE DEFINITION
//
//   NOTE: The comments on the bc~ lines are not just comments!!
//
//   This file is a C++ Header file, but at the same time, this file is placed on
//   system\bin directory and processed by Tracelog program as a resource file.
//   The line in the 'TraceLogRs.txt' indicates to include tracelog.hpp.
//   0x5000 is added to the C++ value.
//   The range of breadcrumb definition in this file should be from 0x5000 to 0x5fff.
//
//   <TraceLogRs.txt>
//     #bias 0x5000
//     #import tracelog.hpp
//
//   The format of bc~ definition is restricted by the Tracelog program. Here are the grammar.
//   1) Start with 'bc'. The maximum bc symbol name is 24.
//   2) Both side of '=' and '//' require Space character.
//   3) Between the value and the ',' should not contain spaces.
//   4) The column is fixed after the '//', that is,
//        One space, 34 character Location, one space, 24 character Description
//   5) After the description start with '%' is the data type
//
//          data format
//                %x Hex decimal           %d Decimal
//                %f Floating              %t Time
//                %n IP Address
//                %e=<Enum Name>   //Note: No space
//                If omitted, the data will be displayed in Hex if the data is not zero.
//          %m specifies a Major Event. "major" command will display only the Major Events.
//
//   6) The Enum Name is defined in TraceLogRs.txt. Current available Enums are
//         PCMSTATE, RMSTATE, and enmSuGate
//
//   7) 'unused' comment is meaningful for the compatibility. The codes once used in some
//      version should not be used for another event.
//      The assignments of breadcrumb code are Life Long.
//
//   tracelog.hpp is copied from epcio\src to system\bin at the installation.
//
//   note: The strings are generated based on the TraceLogRs.txt on July 6, 2005
//         Changing \ecs\common\misc\TraceLogRs.txt is not necessary anymore
//
////////////////////////////////////////////////////////////////////////////////
typedef enum tagIOBreadCrumb{
  // Tracelogs common to all IOMs - 0x0001 to 0x00FF
                                     // ================================== ======================== %x
  bcAppStart               = 0x0001, // AppPowerOnResetISR()               ---Application start---
  bcStackInit              = 0x0002, // AppPowerOnResetISR()               Stack initialized
  bcFPGADone               = 0x0003, // HardwareInit()                     FPGA load complete
  bcPowerOn                = 0x0004, // HardwareInit()                     PowerOn start detected
  bcReboot                 = 0x0005, // HardwareInit()                     Reboot detected
  bcStartupDiagDone        = 0x0006, // StartupDiagnostics()               Startup diag complete
  bcIomDbDone              = 0x0007, // main()                             IOM database created
  bcAppInitComplete        = 0x0008, // clsTaskScheduler::ExecuteTaskSched Application init complet
  bcWDTEnabled             = 0x0009, // clsTaskScheduler::ExecuteTaskSched WatchDog enabled
  bcIOLEnable              = 0x000a, // clsTaskScheduler::ExecuteTaskSched IOL interface enabled
  bcAssignDsa              = 0x000b, // clsIol::Cmd28Handler               DSA assigned DSA:BA
  bcAssignBa               = 0x000c, // clsIol::Cmd2AHandler               BA assigned DSA:BA
  bcEvrcBegin              = 0x000d, // EventRecoveryTask()                Event recovery begin
  bcEvrcExec               = 0x000e, // EventRecoveryTask()                EVRC execution context
  bcEvrcSuspended          = 0x000f, // EventRecoveryTask()                EVRC task suspended
                                     // ================================== ========================
  bcEvrcTerminated         = 0x0010, // EventRecoveryTask()                EVRC task terminated
  bcEvrcEnd                = 0x0011, // EventRecoveryTask()                Event recovery end
  bcNoRoomForRegen         = 0x0012, // EventRecoveryTask()                EVRC delay ECL half full
  bcDbRestoreDone          = 0x0013, // clsIomSlot::WriteParamData         Database restore complet
  bcDbRestoreFail          = 0x0014, // clsIomSlot::WriteParamData         Database restore failed
  bcAliveToIdle            = 0x0015, // clsTaskScheduler::ExecuteTaskSched ModStat ALIVE -> IDLE
  bcIdleToRun              = 0x0016, // clsBoxSlot::PreModStat1()          ModStat IDLE -> RUN
  bcRunToIdle              = 0x0017, // clsBoxSlot::PreModStat1()          ModStat RUN -> IDLE
  bcIdleToAlive            = 0x0018, // clsBoxSlot::PreModStat1()          ModStat IDLE -> ALIVE
  bcDiagTask               = 0x0019, // DiagnosticTask()                   Diag routine complete
  bcSchedulerDelay         = 0x001a, // clsTaskScheduler::ExecuteTaskSched Task scheduler delayed
  bcComTogFail             = 0x001b, // clsBoxSlot::IsTogFailed            Communcation TOG fail
  bcCtlTogFail             = 0x001c, // clsBoxSlot::IsTogFailed            Control TOG fail
  bcDMCFail                = 0x001d, // clsTaskScheduler::STCInterruptHand DMC failure for task id
  bcHardFail1              = 0x001e, // HardFail()                         ***HF***CODE|FILE|LINE
  bcFreezePermitted        = 0x001f, // clsIol::Cmd37Handler()             Freeze permitted for syn
                                     // ================================== ========================
  bcFrozen                 = 0x0020, // WriteDatabaseTask                  Writes frozen for sync
  bcDumpComplete           = 0x0021, // clsIol::Cmd0FHandler               Database dump complete
  bcDumpFailed             = 0x0022, // clsIol::Cmd0FHandler               Database dump failed
  bcSfActionTable          = 0x0023, // clsBoxSlot::PostSfActionTbl        SfActionTable written
  bcSyncVer                = 0x0024, // clsBoxSlot::PreSyncVer()           SyncVer updated
  bcSynced                 = 0x0025, // clsBoxSlot::PostRedState           Sync complete
  bcSyncFailed             = 0x0026, // clsBoxSlot::PostRedState           Sync failed
  bcNotSynced              = 0x0027, // clsBoxSlot::PostRedState           IOM not synced
  bcFailOver               = 0x0028, // clsBoxSlot::PostRedState           Failover initiated
  bcSwap                   = 0x0029, // clsBoxSlot::PostRedState           Swap ininitiated
  bcHardFail2              = 0x002a, // HardFail()                         ***HF***DSA|BA|PRM1|PRM2
  bcHardFail3              = 0x002b, // HardFail()                         ***MDST2|MDST3|RDDT|RDST
  bcHAdcEnable             = 0x0080, // clsUioBoxSlot::PostHADCEnable

#ifdef IOMTYPE_AIH
  // AIH IOM specific tracelogs - 0x0100 to 0x01FF
                                     // ================================== ========================
  bcAihIom                 = 0x0100, // main()                             HART AI IOM DPA
  bcCalibLoad              = 0x0101, // clsAihBoxSlot::LoadCalibrationData Loaded calibration data
  bcCalibStart             = 0x0102, // CalibrationTask                    Calibration requested
  bcCalibDone              = 0x0103, // CalibrationTask                    Calibration completed
  bcCalibAbort             = 0x0104, // CalibrationTask                    Calibration aborted
  bcInvHartIntr            = 0x0105, // ProcessHartInterrupt               Invalid HART interrupt
  bcOwdCktFail             = 0x0106, // clsAihSlot::ValidateOwdCkt         OWD circuit failure
  bcHModemDiagCount        = 0x0107, // clsHartModem::DiagConnect          HART modem diag count
  bcHModemDiagFailed       = 0x0108, // clsHartModem::ProcessDiagModem     HART modem diag failure
  bcBRDPHndleTmOut         = 0x0109, // clsBoxSlot::ProcessBrdpTimeout     BRDP handle timeout
  bcBRDPMsgTmOut           = 0x010A, // clsBoxSlot::ProcessBrdpTimeout     BRDP message timeout
  bcBRDPDupHndl            = 0x010B, // clsIol::Cmd0CHandler               Duplicate BRDP handle
  bcFPGAReadBackDiagFailed = 0x010C, // FpgaReadBackDiagRoutine()          FPGA Readback failed
  bcFPGAReadBackDiagPassed = 0x010D, // FpgaReadBackDiagRoutine()          FPGA Readback passed
  bcHModemDiagAbort        = 0x010E, // clsHartModem::ProcessDiagModem     HART modem diag aborted
  bcHModemDiagRetry        = 0x010F, // clsHartModem::ProcessDiagModem     HART modem diag retry
  bcHModemDiagReset        = 0x0110, // clsHartModem::ProcessDiagModem     HART modem diag reset
  bcAiIom                  = 0x0199, // main()                             HL AI IOM DPA
#endif
#ifdef IOMTYPE_AOH
  // AOH IOM specific tracelogs - 0x0200 to 0x02FF
                                     // ================================== ========================
  bcAohIom                 = 0x0200, // main()                             HART AO IOM DPA
  bcCalibLoad              = 0x0201, // clsAohBoxSlot::LoadCalibrationData Loaded calibration data
  bcCalibStart             = 0x0202, // CalibrationTask                    Calibration requested
  bcCalibDone              = 0x0203, // CalibrationTask                    Calibration completed
  bcCalibAbort             = 0x0204, // CalibrationTask                    Calibration aborted
  bcInvHartIntr            = 0x0205, // ProcessHartInterrupt               Invalid HART interrupt
  bcPriChanInFail          = 0x0206, // clsAohSlot::PreOp                  Sec IOM rejects OP write
  bcHModemDiagCount        = 0x0207, // clsHartModem::DiagConnect          HART modem diag count
  bcHModemDiagFailed       = 0x0208, // clsHartModem::ProcessDiagModem     HART modem diag failure
  bcBRDPHndleTmOut         = 0x0209, // clsBoxSlot::ProcessBrdpTimeout     BRDP handle timeout
  bcBRDPMsgTmOut           = 0x020A, // clsBoxSlot::ProcessBrdpTimeout     BRDP message timeout
  bcBRDPDupHndl            = 0x020B, // clsIol::Cmd0CHandler               Duplicate BRDP handle
  bcFPGAReadBackDiagFailed = 0x020C, // FpgaReadBackDiagRoutine()          FPGA Readback failed
  bcFPGAReadBackDiagPassed = 0x020D, // FpgaReadBackDiagRoutine()          FPGA Readback passed
  bcHModemDiagAbort        = 0x020E, // clsHartModem::ProcessDiagModem     HART modem diag aborted
  bcHModemDiagRetry        = 0x020F, // clsHartModem::ProcessDiagModem     HART modem diag retry
  bcHModemDiagReset        = 0x0210, // clsHartModem::ProcessDiagModem     HART modem diag reset
  bcAoIom                  = 0x0299, // main()                             AO IOM DPA
#endif
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
  // DI and DISOE IOM specific tracelogs - 0x0300 to 0x03FF
                                     // ================================== ========================
  bcDi24VIom               = 0x0300, // main()                             DI IOM 24V IOTA DPA
  bcDi110VIom              = 0x0301, // main()                             DI IOM 110V IOTA DPA
  bcDi240VIom              = 0x0302, // main()                             DI IOM 240V IOTA DPA
  bcOpenWireDiagmiss       = 0x0303, // clsDiBoxSlot::AppStcProcessing     Open wire diag skipped
#endif
#ifdef IOMTYPE_DO
  // DO IOM specific tracelogs - 0x0400 to 0x04FF
                                     // ================================== ========================
  bcDoIom                  = 0x0400, // main()                             DO IOM DPA
  bcDoLpBkDiagPriFail      = 0x0401, // clsDoBoxSlot::LoopbackDiagnostics  soft failure on primary
  bcDoLpBkDiagSecFail      = 0x0402, // clsDoBoxSlot::LoopbackDiagnostics  soft failure on backup
#endif
#ifdef IOMTYPE_LLMUX
  // LLMUX IOM specific tracelogs - 0x0500 to 0x05FF
                                     // ================================== ========================
  bcLLMuxIom               = 0x0500, // main()                             LLMUX IOM DPA
  bcLLMuxBadRxCount        = 0x0501, // clsLLMuxHardware::CopyRxFromFifo   Bad Rx count from FTA
  bcLLMuxBadRxFromFta      = 0x0502, // LLBoxSlot::CheckResponseForErrors  Garbled Rx from FTA
  bcLLMuxErrFromFta        = 0x0503, // LLBoxSlot::CheckResponseForErrors  Error code from FTA
  bcLLMuxUnsourcedInt      = 0x0504, // LLBoxSlot::LLMuxIRQ1InterruptHandl Unsourced interrupt
  bcLLMuxUnknownInt        = 0x0505, // LLBoxSlot::LLMuxIRQ1InterruptHandl Unknown interrupt type
  bcLLMuxCharTmoutInt      = 0x0506, // LLBoxSlot::LLMuxIRQ1InterruptHandl Character timeout interr
  bcLLMuxLneStatusInt      = 0x0507, // LLBoxSlot::LLMuxIRQ1InterruptHandl Line status interrupt
  bcFPGAReadBackDiagFailed = 0x0508, // FpgaReadBackDiagRoutine()          FPGA Readback failed
  bcFPGAReadBackDiagPassed = 0x0509, // FpgaReadBackDiagRoutine()          FPGA Readback passed
  bcLLMuxGeneric           = 0x05ff, // LLMuxGeneric                       General
#endif
#if (defined(IOMTYPE_DISOE))
  bcDisoeIom               = 0x0600, // main()                             DISOE IOM IOTA DPA
  bcBadPktType             = 0x0601, // DiBoxSlot::PostToPVCL()            Un Expected Pkt Type
  bcLogFrozen              = 0x0602, // DiBoxSlot::Prep_for_Regen()        Regen Log is Frozen
  bcStMchOpBuffFull        = 0x0603, // DiBoxSlot::ScanChannel()           StMchOpBuffer is full
  bcTaskFIFOFull           = 0x0604, // DiBoxSlot::AddToTaskFIFO()         Task FIFO is Full
  bcPVCLFull               = 0x0605, // clsEcl::AddPVCLEvent()             PVCL is full
#endif

#ifdef IOMTYPE_SVP
  // SVP IOM specific tracelogs - 0x0700 to 0x07FF
  bcPriChanInFail          = 0x0700, // clsComboSlot::PreOp
  bcFPGAReadBackDiagFailed = 0x0701, // FpgaReadBackDiagRoutine()          FPGA Readback failed
  bcFPGAReadBackDiagPassed = 0x0702, // FpgaReadBackDiagRoutine()          FPGA Readback passed
  bcOwdCktFail             = 0x0703, // clsSvpSlot::ValidateOwdCkt         OWD circuit failure
  bcAiIom                  = 0x0704, // main()                             HL AI IOM DPA
  bcXreadyVal              = 0x0705,
  bcUnexpectedExcution     = 0x0706,
  bcTcAppStart             = 0x0750, // start of range reserved for application processor logs
  bcAppEnd                 = 0x07FF, // end of range reserved for application processor logs
#endif


#ifdef IOMTYPE_SP
  // SP IOM specific tracelogs - 0x0800 to 0x08FF
  bcFPGAReadBackDiagFailed = 0x0800, // FpgaReadBackDiagRoutine()          FPGA Readback failed
  bcFPGAReadBackDiagPassed = 0x0801, // FpgaReadBackDiagRoutine()          FPGA Readback passed
  bcOwdCktFail             = 0x0802, // ValidateOwdCkt         OWD circuit failure
  bcAiIom                  = 0x0803, // main()
  bcCalibStart             = 0x0804, // CalibrationTask                    Calibration requested
  bcPriChanInFail          = 0x0805,
  bcCalibLoad              = 0x0806, // clsAihBoxSlot::LoadCalibrationData Loaded calibration data
  bcCalibDone              = 0x0807, // CalibrationTask                    Calibration completed
  bcCalibAbort             = 0x0808, // CalibrationTask                    Calibration aborted
  bcXreadyVal              = 0x0809,
  bcTcAppStart             = 0x0850, // start of range reserved for application processor logs
  bcAppEnd                 = 0x08FF, // end of range reserved for application processor logs
#endif

#ifdef IOMTYPE_PI
  // Pulse Input Module Tracelogs from --- 0x0900 to 0x09FF
  bcPiIom                  = 0x0900, // main()                              PI IOM DPA
  bcAppEnd                 = 0x09FF, // end of range reserved for application processor logs
#endif

#ifdef IOMTYPE_UIO
  // Universal I/O Module Tracelogs from --- 0x0A00 to 0x0AFF
                                     // ==================================  ========================
  bcUioIom                 = 0x0A00, // main()                              UIO IOM DPA
  bcAiSlotLoaded           = 0x0A01, // clsUioSlot::CreateConfiguredSlot()  AI Channel number
  bcAoSlotLoaded           = 0x0A02, // clsUioSlot::CreateConfiguredSlot()  AO Channel number
  bcDiSlotLoaded           = 0x0A03, // clsUioSlot::CreateConfiguredSlot()  DI Channel number
  bcDoSlotLoaded           = 0x0A04, // clsUioSlot::CreateConfiguredSlot()  DO Channel number
  bcConfiguredSlotDeleted  = 0x0A05, // clsUioSlot::DeleteConfiguredSlot()  Channel number
  bcConfigRestoreFailed    = 0x0A06, // clsUioSlot::WriteParamData()        CFGRestore Failed for Ch

  bcPriChanInFail          = 0x0A07, // clsAohSlot::PreOp                   Sec IOM rejects OP write

  bcCalibrationComplete    = 0x0A08, // clsUioFpga::CalibrateFiveVoltRef()  IoBoard | Iterations

  // HART related tracelogs
  bcInvHartIntr            = 0x0A50, // ProcessHartInterrupt                Invalid HART interrupt
  bcHModemDiagCount        = 0x0A51, // clsHartModem::DiagConnect           HART modem diag count
  bcHModemDiagFailed       = 0x0A52, // clsHartModem::ProcessDiagModem      HART modem diag failure
  bcBRDPHndleTmOut         = 0x0A53, // clsBoxSlot::ProcessBrdpTimeout      BRDP handle timeout
  bcBRDPMsgTmOut           = 0x0A54, // clsBoxSlot::ProcessBrdpTimeout      BRDP message timeout
  bcBRDPDupHndl            = 0x0A55, // clsIol::Cmd0CHandler                Duplicate BRDP handle
  bcHModemDiagAbort        = 0x0A56, // clsHartModem::ProcessDiagModem      HART modem diag aborted
  bcHModemDiagRetry        = 0x0A57, // clsHartModem::ProcessDiagModem      HART modem diag retry
  bcHModemDiagReset        = 0x0A58, // clsHartModem::ProcessDiagModem      HART modem diag reset

  bcSpiIntDetected         = 0x0A59, // clsUioBoxSlot::IRQ3InterruptHandler SPI interrupt detected
  bcAppEnd                 = 0x0AFF, // end of range reserved for application processor logs
#endif

#ifdef IO_ARM_CM
  // io_arm_cm VOB Tracelogs from --- 0x0B00 to 0x0BFF
                                     // ================================== ======================== %x
  bcUio2Iom                = 0x0B00, // main()                             UIO-2 IOM DPA
  bcAihSlotLoaded          = 0x0B01, // SlotDatabase: Channel created      AI Channel number
  bcAohSlotLoaded          = 0x0B02, // SlotDatabase: Channel created      AO Channel number
  bcDiSlotLoaded           = 0x0B03, // SlotDatabase: Channel created      DI Channel number
  bcDoSlotLoaded           = 0x0B04, // SlotDatabase: Channel created      DO Channel number
  bcConfiguredSlotDeleted  = 0x0B05, // SlotDatabase: Channel deleted      Channel number
  bcCalibLoad              = 0x0B06, // Loaded calibration data
  bcColdInit               = 0x0B07, //                                    Database Cold Init
  bcDropSync               = 0x0B08, //                                    Drop Sync
  bcSetForPrimary          = 0x0B09, //                                    Set for Primary
  bcSetForSecondary        = 0x0B10, //                                    Set for Secondary
  bcSoftfailFailOver       = 0x0B11, //                                    Softfail fail-over
  bcNominalCalibration     = 0x0B12, // Nominal calibration consts used
  bcLT4SpiByteReceived     = 0x0B13, // Less than 4 SPI bytes received      Asic number
  bcRefVoltageFailed       = 0x0B14, // Failed ASIC reference voltage       Asic number
  bcBRDPHndleTmOut         = 0x0B15, // HartPst::ProcessBrdpTimeout         BRDP handle timeout
  bcBRDPMsgTmOut           = 0x0B16, // HartPst::ProcessBrdpTimeout         BRDP message timeout    
#endif

  // Used for Debugging during development
                                     // ================================== ========================
  bcDebug                  = 0x0fff  // General                            Debug info

} IOBreadCrumb;
// End Breadcrumbs definition

#if !defined(IO_ARM_CM)

#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))
class clsAppTraceLog;
const UINT16 AUTO_UNLOCK_DELAY_COUNT = 120;// Lock for 30 seconds
#endif
/*******************************************************************************
*                                  clsTraceLog                                 *
*                                  ===========                                 *
*******************************************************************************/
class clsTraceLog {
    UINT8  m_ucAppIndex;
    UINT8  pad;
    UINT16 m_TraceLevel;
    // TraceLevel has to be UINT16 because its tblParamInfo entry is,
    // DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,

#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))
    clsAppTraceLog* m_pAppTraceLog;
    UINT16          AutoUnlockCount;
#endif

    TRACERECORD TraceRecord[NO_OF_TRACERECORDS];

    clsTraceLog(const clsTraceLog&); // Safeguard against def copy constr.
    clsTraceLog& operator=(const clsTraceLog&); // and default assignment.

public:
    clsTraceLog(VOID);
    ~clsTraceLog(VOID) {
        HardFail(HF_INVPROGRAMEXEC,TRACELOG_HPP,__LINE__);
    }

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(size_t) noexcept {
        HardFail(HF_INVPROGRAMEXEC,TRACELOG_HPP,__LINE__);
        return NULL;
    }
    VOID operator delete(VOID *) noexcept {
        HardFail(HF_INVPROGRAMEXEC,TRACELOG_HPP,__LINE__);
    }

    VOID AddToTrace(TRACEID a_TraceId,IOBreadCrumb crumb, UINT32 data = 0);
    VOID CopyCrashTraceBlock(VOID);

#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))
    // #ifdefed to eliminate impact on other modules.
    VOID *GetTracelog(VOID);
    UINT8 GetLatestTraceIndex(VOID);
    inline VOID StoreAppTraceLogPtr(clsAppTraceLog* pAppTrace)
    {
        m_pAppTraceLog = pAppTrace;
    }
    VOID LockAppTraceLog(VOID);
    VOID UnlockAppTraceLog(VOID);
    VOID LockTimeoutProc(VOID);
#else
    inline VOID *GetTracelog(VOID) { return TraceRecord; }
    inline UINT8 GetLatestTraceIndex(VOID) { return m_ucAppIndex; }
#endif

    inline VOID *GetTracelevel(VOID) { return &m_TraceLevel; }

    VOID ToggleTrace(TRACEID a_TraceId) {
        if (m_TraceLevel & a_TraceId) m_TraceLevel &= ~a_TraceId;
        else m_TraceLevel |= a_TraceId;
    }
};

/* The RT1024 common headers do not carry the legacy global declaration. */
extern clsTraceLog TraceLog;

#endif // !defined(IO_ARM_CM)

#endif
