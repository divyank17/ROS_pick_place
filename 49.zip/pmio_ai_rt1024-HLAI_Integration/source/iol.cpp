/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iol.cpp                                                     *
*    Description : IOL Interface object source file.                           *
*                                                                              *
*    Converted from Renesas H8S/2329 -> NXP LPC1763 -> NXP iMXRT1024.          *
*    - All UART I/O via IOL_WriteByte/ReadByte/etc. wrappers                   *
*      (armsrc precedent; RT1024 maps to HAL LPUART in commonelectronics.h)    *
*    - ISR architecture: extern "C" handlers with friend access (armsrc)       *
*    - Timer: SilenceTimer helpers (armsrc); maps to HAL_TIMER_IOL_SIL         *
*    - GPIO: SetTXREQ_n/SetCLR_GHL_n wrappers (armsrc); maps to HAL GPIO       *
*    - Stripped to AIH-only (no DISOE/DO/LLMUX/SVP/SP/PI/UIO conditionals)     *
*    - Removed S3 FPGA/SCI2 dual-UART paths                                    *
*    - BRDP (HART pass-through) handlers preserved for AIH                     *
*******************************************************************************/

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "iol.hpp"
#include "hart.h"
#include "utils.h"

#include "fsl_debug_console.h"
#include <cstdlib>

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern BOOL HWRevCodeWriteInProgress;

clsIol Iol;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const CMDINFO clsIol::aCmdInfo[] = {
    {0x04,0x00,&clsIol::DefaultHandler},   // 00 Null
    {0x08,0x04,&clsIol::Cmd01Handler},     // 01 Block Read Absolute
    {0x00,0x00,&clsIol::DefaultHandler},   // 02 Not Supported
    {0x08,0x05,&clsIol::Cmd0AHandler},     // 03 Block Write Absolute
    {0x07,0x05,&clsIol::Cmd04Handler},     // 04 Read Indexed Deferred
    {0x00,0x00,&clsIol::DefaultHandler},   // 05 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 06 Not Supported
    {0x05,0x05,&clsIol::Cmd07Handler},     // 07 Get Deferred Message Status
    {0x06,0x05,&clsIol::Cmd08Handler},     // 08 Read
    {0x00,0x00,&clsIol::DefaultHandler},   // 09 Not Supported
    {0x09,0x05,&clsIol::Cmd0AHandler},     // 0A Write
    {0x05,0x05,&clsIol::Cmd0BHandler},     // 0B Read Deferred Message Response
    {0x0A,0x05,&clsIol::Cmd0CHandler},     // 0C Write Indexed Deferred
    {0x00,0x00,&clsIol::DefaultHandler},   // 0D Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 0E Not Supported
    {0x04,0x05,&clsIol::Cmd0FHandler},     // 0F Dump
    {0x07,0x05,&clsIol::Cmd10Handler},     // 10 Read Indexed
    {0x00,0x00,&clsIol::DefaultHandler},   // 11 Not Supported
    {0x0A,0x05,&clsIol::Cmd0AHandler},     // 12 Write Indexed
    {0x00,0x00,&clsIol::DefaultHandler},   // 13 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 14 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 15 Not Supported
    {0x04,0x08,&clsIol::Cmd16Handler},     // 16 Collect ECL
    {0x04,0x05,&clsIol::Cmd17Handler},     // 17 Get ECL Status
    {0x04,0x00,&clsIol::BroadcastHandler}, // 18 Reserved Broadcast
    {0x00,0x00,&clsIol::DefaultHandler},   // 19 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1A Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1B Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1C Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1D Not Supported
    {0x04,0x08,&clsIol::DefaultHandler},   // 1E Collect PCL (unsupported for AIH)
    {0x05,0x05,&clsIol::Cmd1FHandler},     // 1F Get Write Message Status
    {0x05,0x04,&clsIol::Cmd20Handler},     // 20 Tog Refresh
    {0x00,0x00,&clsIol::DefaultHandler},   // 21 Not Supported
    {0x00,0x05,&clsIol::DefaultHandler},   // 22 NACK
    {0x00,0x00,&clsIol::DefaultHandler},   // 23 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 24 Not Supported
    {0x04,0x04,&clsIol::Cmd25Handler},     // 25 Regenerate Events
    {0x06,0x04,&clsIol::Cmd26Handler},     // 26 Update Event Remove Pointer
    {0x00,0x00,&clsIol::DefaultHandler},   // 27 Not Supported
    {0x05,0x04,&clsIol::Cmd28Handler},     // 28 Assign DSA
    {0x06,0x00,&clsIol::BroadcastHandler}, // 29 Time Sync
    {0x05,0x04,&clsIol::Cmd2AHandler},     // 2A Assign BA
    {0x00,0x00,&clsIol::DefaultHandler},   // 2B Not Supported
    {0x04,0x04,&clsIol::Cmd2CHandler},     // 2C Select Channel A
    {0x04,0x04,&clsIol::Cmd2DHandler},     // 2D Select Channel B
    {0x06,0x04,&clsIol::DefaultHandler},   // 2E Update PV Change Remove Ptr (unsupported)
    {0x04,0x05,&clsIol::Cmd2FHandler},     // 2F Freeze Database
    {0x00,0x00,&clsIol::DefaultHandler},   // 30 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 31 Not Supported
    {0x04,0x04,&clsIol::Cmd32Handler},     // 32 Reset Communication Errors
    {0x08,0x04,&clsIol::Cmd33Handler},     // 33 Test Hardware Functions
    {0x00,0x00,&clsIol::DefaultHandler},   // 34 Not Supported
    {0x04,0x04,&clsIol::Cmd35Handler},     // 35 Wiggle
    {0x00,0x00,&clsIol::BroadcastHandler}, // 36 Reserved Broadcast
    {0x04,0x04,&clsIol::Cmd37Handler},     // 37 Unfreeze Database
    {0x00,0x00,&clsIol::BroadcastHandler}, // 38 Reserved Broadcast
    {0x00,0x00,&clsIol::DefaultHandler},   // 39 Not Supported
    {0x00,0x00,&clsIol::BroadcastHandler}, // 3A Reserved Broadcast
    {0x00,0x00,&clsIol::DefaultHandler},   // 3B Not Supported
    {0x00,0x00,&clsIol::BroadcastHandler}  // 3C Reserved Broadcast
};
// Define the largest command number processed by the aCmdInfo table.
const UINT8 clsIol::LastCommand = (sizeof (aCmdInfo) / sizeof (CMDINFO)) - 1;

/* Diagnostic: see declaration in iol.hpp. */
volatile UINT32 clsIol::RcvrEntryCount = 0;
volatile UINT32 clsIol::NotMyAddressCount = 0;
volatile UINT32 clsIol::AlertErrCount = 0;
volatile UINT32 clsIol::GhoEntryCount = 0;
volatile UINT32 clsIol::GhoDummyReadHadDataCount = 0;
volatile UINT16 clsIol::LastAlertBytes[8] = {0};
volatile UINT8  clsIol::LastAlertBytesIdx = 0;

/*******************************************************************************
*                       clsIol::clsIol                                         *
*                       ==============                                         *
* PURPOSE:                                                                     *
*    Constructor \u2014 initialise IOL communication object.                   *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    RT1024 CHANGES: UART I/O replaced with HAL calls.                         *
*******************************************************************************/
clsIol::clsIol(VOID)
{
    // initialize variables
    ChecksumHi  = 0;
    ChecksumLo  = 0;
    ucIolId     = 0xFF;
    ucIolBA     = 0;
    ucIolDPA    = 0; //testing
    ucIolDSA    = 0;
    ucLastDSA   = 0;
    ucMsgNumber = 0;
    ucIdxDump   = 0;
    nCharProcd  = 0;
    pRcvBuffer  = NULL;
    ucDest      = 0;
    ucNumber    = 0;
    ucCommand   = 0;
    bCommError  = FALSE;
}

/*
 *
 */
VOID clsIol::Enable(VOID) {

    static const hal_uart_config_t IolUartConfig = {
    		IOL_BAUDRATE,	// 375 Kbps
			           8,	// data bits
			           1,	// stop bits
			           0	// parity none
    };

    hal_uart_init(HAL_UART_IOL, &IolUartConfig);

    CountErrorA = 0;
    CountErrorB = 0;
    pRcvBuffer = WriteMsgQueue.GetRcvBufPtr();// get ptr to rcv buffer
    ucIolBA  = BOX->GetBA();
    ucIolDPA = BOX->GetDPA();
    ucIolDSA = BOX->GetDSA();

    hal_uart_register_isr(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA,  clsIol::Rcvr);		// handling Receiver callback function
    hal_uart_register_isr(HAL_UART_IOL, HAL_UART_IRQ_TX_EMPTY, clsIol::Xmit);		// handling Transmit callback function
    hal_uart_register_isr(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE,  clsIol::XmitEnd);	// handling Transmit End callback function

    hal_uart_clear_errors(HAL_UART_IOL);

    /* Small settling delay for transceiver to stabilize */
    for (volatile uint32_t dly = 0; dly < 1000; dly++) { NOP; }

    SetJABRES_n(1); /* JABRES_n must be asserted for Tx, to get LinkWindow=0 from FPGA */

	SetTXREQ_n(IOLDRV_OFF); /* TXREQ_n deassert to make DE=0 */

	SetRCVSELA_n(0); /* RCVSELA_n is deasserting to select receiver channel A */

    Iol.ResetSilenceTimer(CNTLNKSIL); // Enable IOL Silence Timer

	IOL_RxEnable();

#if IOL_GHO_ENB
    EnableGHOInt(TRUE);         // Enable GHO_IRQ_n
    SetCLR_GHL_n(GHO_ENABLED);  // Enable GHO interrupt register
#endif
	IOL_RxInterrupt(TRUE);

#ifdef DBG_PRINT
	PRINTF("IOL ENABLED\r\n");
#endif
}

/**************************************************************************************
*                       GHO_IRQHandler                                                *
*                       ==============                                                *
* PURPOSE  : Gap Has Occurred interrupt handler.                                      *
* ARGUMENTS: None.                                                                    *
* RETURN   : None.                                                                    *
* NOTES    : RT1024 CHANGES: Uses HAL GPIO wrappers for GHO control.                  *
*            Called from BOARD_INITIOLINK_PINS_GHOIRQ_n_callback (NXP GPIO adapter).  *
***************************************************************************************/
VOID GHO_IRQHandler(VOID)
{
    GHO_INT_Clr();                       // Reset IRQ interrupt flag
    SetCLR_GHL_n(GHO_DISABLED);          // Clear/disable GHO interrupt register
    SetCLR_GHL_n(GHO_ENABLED);           // Enable GHO interrupt register
    Iol.GhoEntryCount++;   /* diagnostic: GHO edge entry-rate tracking */
    if (Iol.nCharProcd == 0U) {
        Iol.ChecksumHi = Iol.ChecksumLo = 0; // Reset running checksum
        Iol.pRcvBuffer[IOLMSG_NUMBER] = Iol.xmit_buffer[IOLMSG_NUMBER] = 0;
        IOL_FifoEnable();
        IOL_RxInterrupt(TRUE);
        if (IOL_RxDatReady()) {
            Iol.GhoDummyReadHadDataCount++;   /* diagnostic: dummy read may have eaten a real byte */
        }
        IOL_ReadByte();                      // dummy read to clear flags
    }
}

/* NXP GPIO adapter callback — required name for peripherals.c registration */
extern "C" void BOARD_INITIOLINK_PINS_GHOIRQ_n_callback(void *param) {
    (void)param;
    GHO_IRQHandler();
}

/**
 *
 */
VOID clsIol::Rcvr(VOID) {

    UINT8 *p=Iol.pRcvBuffer;
    UINT8 ucAlertBit;
	UINT16 uiData;
    UINT32 ucTimeOut;
    UINT8 ucCount = 0;
    PASTATUS ucStatus = PA_OK;

    Iol.RcvrEntryCount++;   /* diagnostic: ISR entry-rate tracking */

#if IOL_BYT_DBG
    UINT8 ucCount1 = 0; // testing
#endif

    Iol.bCommError = FALSE;
    /* First byte arrived by IRQ; disable RX IRQ and poll remaining bytes immediately. */
    IOL_RxInterrupt(FALSE);

    // *************************************
    //  1. Get Destination Address character
    // *************************************
    uiData = IOL_ReadByte() & 0x1FFU;

    *p = (UINT8)uiData;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit != IOL_ALERT_RCV_ADDR)
    {
#if 0 //IOL_ERR_DBG
    	PRINTF("RX ER B0 AL (%x) - ", uiData);
#endif
    	Iol.AlertErrCount++;   /* diagnostic: noise/framing signature */
    	Iol.LastAlertBytes[Iol.LastAlertBytesIdx & 0x07U] = uiData;
    	Iol.LastAlertBytesIdx++;
    	BOX->SetCommError(IOL_ALERT);			// error
    	goto ERROR;
    }
    if (Iol.NotMyAddress(*p))
    {
#if 0 //IOL_ERR_DBG
    	PRINTF("RX ER B0 AD (%x) - ", uiData);
#endif
    	Iol.NotMyAddressCount++;   /* diagnostic: other-node bus traffic */
    	Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }
    Iol.ucDest = *p++;
    Iol.Add2Checksum(Iol.ucDest);
    Iol.xmit_buffer[IOLMSG_SOURCE]=Iol.ucDest;
    SilenceTimerStop();							// stop the silence timer

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.ucDest;
#endif

    // *************************************
    //   2. Get Number character
    // *************************************
    {
    	ucTimeOut = NCYCLES_CHARTO;
    	while (!IOL_RxDatReady())
    	{
    		IdleWait(1);
    		if (--ucTimeOut == 0)
    		{
#if IOL_ERR_DBG
    			PRINTF("RX ER B1 TO (%x) - ", uiData);
#endif
    			BOX->SetCommError(IOL_CHRTM);
    			Iol.ResetSilenceTimer(CNTLNKSIL);      	// Reset Link Silence Timer
    			goto ERROR;
    		}
    	}
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
    	PRINTF("RX ER B1 AL (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_ALERT);
        Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }

    *p = (UINT8)uiData;
    Iol.Add2Checksum(*p);
    Iol.ucNumber = *p;
    p++;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.ucNumber;
#endif

    // *************************************
    //   3. Get Source Address character
    // *************************************
    {
    	ucTimeOut = NCYCLES_CHARTO;
    	while (!IOL_RxDatReady())
    	{
    		IdleWait(1);
    		if (--ucTimeOut == 0)
    		{
#if IOL_ERR_DBG
    			PRINTF("RX ER B2 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
    			goto ERROR;
    		}
    	}
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
    	PRINTF("RX ER B2 AL (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_ALERT);
        Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }

    *p = (UINT8)uiData;
    Iol.Add2Checksum(*p);
    Iol.xmit_buffer[IOLMSG_DESTINATION]=*p;
    p++;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.xmit_buffer[IOLMSG_DESTINATION];
#endif


    // *************************************
    //   4. Get Command character
    // *************************************
    {
    	ucTimeOut = NCYCLES_CHARTO;
    	while (!IOL_RxDatReady())
    	{
    		IdleWait(1);
    		if (--ucTimeOut == 0)
    		{
#if IOL_ERR_DBG
    			PRINTF("RX ER B3 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
    			goto ERROR;
    		}
    	}
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
    	PRINTF("RX ER B3 AL (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_ALERT);
        Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }

    *p = (UINT8)uiData;
    Iol.ucCommand = *p;

#if 0 // temp commented due to redesign PMIO is not working with this condition
    // Check if link id matches the link id jumpered on the module
    if ((Iol.ucCommand != CMD_TOG) && (!(BOX->IsIolCorrect(Iol.ucIolId))))
    {
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }
#endif

    Iol.Add2Checksum(*p);
    if (Iol.ucCommand <= LastCommand) {
        Iol.xmit_buffer[IOLMSG_NUMBER] = aCmdInfo[Iol.ucCommand].CountResp;
    }
    else {
        Iol.xmit_buffer[IOLMSG_NUMBER] = 0;
    }
    Iol.xmit_buffer[IOLMSG_COMMAND] = Iol.ucCommand | 0x80;
    p++;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.ucCommand;
#endif

    // *************************************
    //   5. Get Data
    // *************************************
    if (CMD_WRINDEXDEFERRED == Iol.ucCommand)
    {
        if (!Iol.ProcessDefWrCmd())
        {
            goto ERROR;
        }
    }
    else
    {   // Get I field characters
        if (Iol.ucNumber < 4U) {
            BOX->SetCommError(IOL_CHRCT);
            Iol.ResetSilenceTimer(CNTLNKSIL);
            goto ERROR;
        }

    	ucCount = Iol.ucNumber - 4;
    	while(ucCount--)
    	{
    		ucTimeOut = NCYCLES_CHARTO;
    		while (!IOL_RxDatReady())
    		{
    			IdleWait(1);
    			if (--ucTimeOut == 0)
    			{
#if IOL_ERR_DBG
    				PRINTF("RX ER B4 TO (%x) - ", uiData);
#endif
    				BOX->SetCommError(IOL_CHRTM);
    				Iol.ResetSilenceTimer(CNTLNKSIL);
    				goto ERROR;
    			}
    		}

    		uiData = IOL_ReadByte() & 0x1FFU;
    		ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    		if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    		{
#if IOL_ERR_DBG
    			PRINTF("RX ER B4 AL (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_ALERT);
                Iol.ResetSilenceTimer(CNTLNKSIL);
    			goto ERROR;
    		}

    		*p = (UINT8)uiData;

#if IOL_BYT_DBG
    		Iol.TempBuff[ucCount1++] = *p;
#endif

    		Iol.Add2Checksum(*p++);
    	}
    }

    // ********************************************
    //   6. Get Checksum High character and Check
    // ********************************************
    {
    	ucTimeOut = NCYCLES_CHARTO;
    	while (!IOL_RxDatReady())
    	{
    		IdleWait(1);
    		if (--ucTimeOut == 0)
    		{
#if IOL_ERR_DBG
    			PRINTF("RX ER B5 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
    			goto ERROR;
    		}
    	}
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
    	PRINTF("RX ER B5 AL (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_ALERT);
        Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }

    *p = (UINT8)uiData;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = *p;
#endif

    if ((UINT8)Iol.ChecksumHi != *p)
    {
#if IOL_ERR_DBG
    	PRINTF("RX ER B5 CH (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_CHKSM);
        Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }
    p++;

    // ********************************************
    //   7. Get Checksum Low character and Check
    // ********************************************
    {
    	ucTimeOut = NCYCLES_CHARTO;
    	while (!IOL_RxDatReady())
    	{
    		IdleWait(1);
    		if (--ucTimeOut == 0)
    		{
#if IOL_ERR_DBG
    			PRINTF("RX ER B6 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
    			goto ERROR;
    		}
    	}
    }

#if IOL_GHO_ENB
    Iol.StartGapTimer();
#endif

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
    	PRINTF("RX ER B6 AL (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_ALERT);
        Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }

    *p = (UINT8)uiData;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = *p;
#endif

    if ((UINT8)Iol.ChecksumLo != *p)
    {
#if IOL_ERR_DBG
    	PRINTF("RX ER B5 CL (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_CHKSM);
        Iol.ResetSilenceTimer(CNTLNKSIL);
    	goto ERROR;
    }

#if IOL_GHO_ENB
    SetCLR_GHL_n(GHO_DISABLED);             // Disable GHO interrupt

    // Test for overrun — Error if another character comes within TcWait
    while (GetGapTimerCnt() < TPU4CNT_TCWAIT);
    if (IOL_RxDatReady())
    {
        BOX->SetCommError(IOL_ORUN);
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }
#endif

#if IOL_BYT_DBG
	if((ucCount1 > 0) && (Iol.ucDest == 0x81)) {

		PRINTF("\r\nTR: ");
		for (int i = 0; i < ucCount1; i++)
		{
			PRINTF("%02X ", (unsigned)Iol.TempBuff[i]);
		}
	}
#endif

    // ********************************************
    //   Execute appropriate command handler.
    // ********************************************
    if (Iol.ucCommand <= LastCommand)
    {
        ucStatus = (Iol.*(aCmdInfo[Iol.ucCommand].CmdHandler))();
    }
    else
    {
        ucStatus = Iol.DefaultHandler();
    }

    if (Iol.bCommError)
     {
         Iol.ResetSilenceTimer(CNTLNKSIL);

#if IOL_GHO_ENB
         GHO_INT_Clr();
         SetCLR_GHL_n(GHO_DISABLED);
         SetCLR_GHL_n(GHO_ENABLED);
#endif
         Iol.ChecksumHi = Iol.ChecksumLo = 0;
         Iol.pRcvBuffer[IOLMSG_NUMBER] = Iol.xmit_buffer[IOLMSG_NUMBER] = 0;

         // Increment Comm error count for the appropriate channel
         if (BOX->GetPRC())
         {
             if (Iol.CountErrorB < MAXUINT8)
                 Iol.CountErrorB++;
             else
             {
                 Iol.CountErrorB = Iol.CountErrorB - Iol.CountErrorA;
                 Iol.CountErrorA = 0;
             }
         }
         else
         {
             if (Iol.CountErrorA < MAXUINT8)
                 Iol.CountErrorA++;
             else
             {
                 Iol.CountErrorA = Iol.CountErrorA - Iol.CountErrorB;
                 Iol.CountErrorB = 0;
             }
         }
         if (Iol.CountErrorA != Iol.CountErrorB)
         {
             if (Iol.CountErrorA < Iol.CountErrorB)
                 BOX->ResetPRC();
             else
                 BOX->SetPRC();
         }
         goto ERROR;
     }

     // No comm errors — decrement count for the appropriate channel
     if (BOX->GetPRC())
     {
         if (Iol.CountErrorB != 0) Iol.CountErrorB--;
     }
     else
     {
         if (Iol.CountErrorA != 0) Iol.CountErrorA--;
     }

    if (ucStatus != PA_OK) {

    	Iol.StartNakResponse(ucStatus);
    }

    // If no response is required reset for next request and get out
    if (Iol.xmit_buffer[IOLMSG_NUMBER] == 0)
    {
        Iol.ResetSilenceTimer(CNTLNKSIL);
#if IOL_GHO_ENB
        SetCLR_GHL_n(GHO_ENABLED);
#endif
        /* Keep RX path armed even when this request has no response payload. */
        IOL_TxInterrupt(FALSE);
        IOL_TxDoneInterrupt(FALSE);
        IOL_RxInterrupt(TRUE);
    }

    Iol.ChecksumLo = Iol.ChecksumHi = 0;

#if 0 // not required
    if((Iol.ucCommand != 0x08) && (Iol.nCharProcd == 0U)) {	// keep RX IRQ off while TX response is active
        /* Enable Rx interrupt */
        IOL_RxInterrupt(TRUE);
    }
#endif

    return;

ERROR:
#if IOL_BYT_DBG //IOL_ERR_DBG

	if(ucCount1 > 0) {

		PRINTF("\r\nTR: ");
		for (int i = 0; i < ucCount1; i++)
		{
			PRINTF("%02X ", (unsigned)Iol.TempBuff[i]);
		}
		PRINTF(" CH: %02X CL: %02X\r\n", (UINT8)Iol.ChecksumHi, (UINT8)Iol.ChecksumLo);
	}

#endif

	ucCount = 0U;
	hal_uart_clear_errors(HAL_UART_IOL);

    Iol.ChecksumLo = Iol.ChecksumHi = 0;
    if (Iol.nCharProcd == 0U) {
        /* Enable Rx interrupt */
        IOL_RxInterrupt(TRUE);

        Iol.ChecksumHi = Iol.ChecksumLo = 0; // Reset running checksum
        Iol.pRcvBuffer[IOLMSG_NUMBER] = Iol.xmit_buffer[IOLMSG_NUMBER] = 0;
        IOL_FifoEnable();
        IOL_RxInterrupt(TRUE);
        IOL_ReadByte();                      // dummy read to clear flags
    }
}


/*******************************************************************************
*                       SilenceTimer_IRQHandler                                *
*                       =======================                                *
* PURPOSE:   Link silence timer expired — swap cable channel and check errors. *
* ARGUMENTS: None.                                                             *
* RETURN:    None.                                                             *
* NOTES:     RT1024 CHANGES: Timer via HAL, FPGA register via SPI.             *
*******************************************************************************/
VOID SilenceTimer_IRQHandler(VOID)
{
    UINT8  ucPRC;

    SetCLR_GHL_n(GHO_DISABLED);               // Disable GHO interrupt register
    SilenceTimerIntClr();                     // Clear compare Interrupt flag
    ucPRC = BOX->SwapPRC();                   // swap PRC and log it

    if (BOX->AreLinkErrorsSet(ucPRC))
    {
        ucPRC ^= 0x01;
        if (BOX->AreLinkErrorsSet(ucPRC))

        {
            Iol.ResetSilenceTimer(CNTLNKHUNT);// Set compare register to hunt value
            Iol.LossofCommShed();             // and shed the screws if appropriate
        }
        else
        {
            Iol.ResetSilenceTimer(CNTLNKSIL); // Set compare reg to silence value
        }
    }
    else
    {
        Iol.ResetSilenceTimer(CNTLNKSIL);     // Set compare register to silence value
    }
    SetCLR_GHL_n(GHO_ENABLED);                // Enable GHO interrupt register
}

/**************************************************************************************
*                       clsIol::LossofCommShed                                        *
*                       ======================                                        *
* PURPOSE:   Detect IOL communication timeout and initiate backup takeover if needed. *
* ARGUMENTS: None.                                                                    *
* RETURN:    None.                                                                    *
* NOTES:     None.                                                                    *
**************************************************************************************/
VOID clsIol::LossofCommShed(VOID)
{
    /*
	UINT16  uiLimit = AmPrimary() ? CNTLNKPRITO : CNTLNKSECTO;
    if (uiLimit < BOX->GetSilenceCount() && !BOX->GetPartnersBackupStatus()) {
        if (REDSTATE_SYNCD == BOX->GetRedState()) {
            BOX->SetRedState(REDSTATE_IOL_TIMEOUT);
            BOX->AssertBackup();
        }
        if (AmPrimary()) {
            DropDSA();
            BOX->SetDSA(0);
        }
    }
    */
}

/**
 *
 */
VOID clsIol::Xmit(VOID) {

	/*
	 * check the loopback recv bytes to confirm successful Tx over IOLink
	 * loopback bytes starts receive from the 3rd byte of Tx
	 */
    if(Iol.nCharProcd > 1)
    {
        if (IOL_RxDatReady()) {
            if (Iol.xmit_buffer[Iol.nCharProcd - 2] != (IOL_ReadByte() & 0xFFU))
            {
                IOL_TxInterrupt(FALSE);

                IOL_TxDoneInterrupt(TRUE);

                return;
            }
        }
    }

	IOL_WriteByte(Iol.xmit_buffer[Iol.nCharProcd], IOL_ALERT_XMIT_DATA);

	Iol.nCharProcd += 1;

	if(Iol.nCharProcd == (Iol.xmit_buffer[IOLMSG_NUMBER] + 2))
	{
		IOL_TxInterrupt(FALSE);

		IOL_TxDoneInterrupt(TRUE);
	}
}

VOID clsIol::XmitEnd(VOID) {

	/* clearing Tx done flag */
	hal_uart_clear_flag(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE);

	/* Disable TC interrupt */
	IOL_TxDoneInterrupt(FALSE);

    /*
     * Drain all pending loopback bytes before re-enabling RX IRQ.
     * Long responses can leave multiple bytes queued; if not flushed,
     * the next request may start from stale loopback data.
     */
    UINT16 flushCount = 0U;
    while (IOL_RxDatReady() && (flushCount < (UINT16)(IOL_MAXXMT_MSGSIZE + 2U))) {
        (void)IOL_ReadByte();
        flushCount++;
    }

	/* disable Tx */
	IOL_TxDisable();

#if IOL_GHO_ENB
    SetCLR_GHL_n(GHO_ENABLED);	// Enable GHO interrupt register
#endif

    Iol.ResetSilenceTimer(CNTLNKSIL);

	/* Tx driver enable off (DE=0) */
	SetTXREQ_n(IOLDRV_OFF);

	Iol.nCharProcd = 0;

	/* Enable Rx interrupt */
	IOL_RxInterrupt(TRUE);
}

/*******************************************************************************
*                       clsIol::ComputeFletcher                                *
*                       =======================                                *
* PURPOSE:                                                                     *
*    Compute Fletcher checksum on an IOL message and either append or compare. *
* ARGUMENTS:                                                                   *
*    p       : pointer to the message buffer.                                  *
*    uAction : FTYP_APPEND to append checksum, FTYP_COMPARE to verify.        *
* RETURN:                                                                      *
*    EXIT_SUCCESS if ok, EXIT_FAILURE if compare mismatch.                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
UINT8 clsIol::ComputeFletcher(UINT8 *p, FLETCHERACTION uAction)
{
    UINT16  ChksumHi = 0, ChksumLo = 0, i;

    for (i=p[1]; i>0; i--) {
        ChksumLo += *p++;
        if (ChksumLo > 0xFF) ChksumLo += 0xFF01;     // if carry, sub 256, add 1
        ChksumHi += ChksumLo;
        if (ChksumHi > 0xFF) ChksumHi += 0xFF01;     // if carry, sub 256, add 1
    }
    if (uAction == FTYP_APPEND) {
        *p++ = ChksumHi;
        *p   = ChksumLo;
        return EXIT_SUCCESS;
    }
    else if (uAction == FTYP_COMPARE) {
        if (p[0] == ChksumHi && p[1] == ChksumLo)
            return EXIT_SUCCESS;
    }
    return EXIT_FAILURE;
}

PASTATUS clsIol::Cmd01Handler(VOID){

	return PA_OK;
}
PASTATUS clsIol::Cmd04Handler(VOID) {

	return PA_OK;
}
PASTATUS clsIol::Cmd07Handler(VOID) {

	return PA_OK;
}
PASTATUS clsIol::Cmd08Handler(VOID) {

    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    UINT8 ucSlotNum = pRcvBuffer[IOLREQ_SLOTNUM];
    if (ucSlotNum > MAXSLOTS) {
        return DO_INVALID_SLOT_INDEX;
    }

    /*
    // Check if the BRDP handle request
    if (PARAMID_HBRDP == pRcvBuffer[IOLREQ_PARAMID]) {
        if (0 == ucSlotNum) return DO_INVALID_SLOT_INDEX;
        if (BRDPSESSION_CLOSE == BOX->HNDLStatusTable[ucSlotNum-1].Handle) {
            if (GetGHOXXX() == GHO_NOTINGAP) {
                BOX->SetCommError(IOL_GAP);
                bCommError = TRUE;
            }
            else {
                xmit_buffer[IOLMSG_NUMBER] += 1;
                StartResponse();
                xmit_buffer[IOLRESP_DATATYPE] = DT_UINT8;
                xmit_buffer[IOLRESP_RDDATA] = ((ucSlotNum-1) & 0x0F)<<3;
                ComputeFletcher(xmit_buffer, FTYP_APPEND);
                BOX->HNDLStatusTable[ucSlotNum-1].Handle = BRDPSESSION_OPEN;
                BOX->HNDLStatusTable[ucSlotNum-1].Timeout = BRDP_HNDL_TIMEOUT;
            }
            return PA_OK;
        }
        else
            return PA_PS_ACQRD_HNDL;
    }
    */

    UINT8 ucDatatype = pDatabase[ucSlotNum]->GetDataType(pRcvBuffer[IOLREQ_PARAMID]);
    if (ucDatatype == DT_NONE) {
        return DO_PARAMETER_INVALID;
    }

    if (GetGHOXXX() == GHO_NOTINGAP)
    {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else
    {
        UINT8 ucParamSize = pDatabase[ucSlotNum]->GetParamSize(pRcvBuffer[IOLREQ_PARAMID]);
        xmit_buffer[IOLMSG_NUMBER] += ucParamSize;
        xmit_buffer[IOLRESP_DATATYPE] = ucDatatype;
        pDatabase[ucSlotNum]->ReadParamData(&xmit_buffer[IOLRESP_RDDATA],pRcvBuffer[IOLREQ_PARAMID]);
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
         // kept it here for testing, actually it should be before read param
        StartResponse();
    }
    return PA_OK;
}
PASTATUS clsIol::Cmd0AHandler(VOID) {

	if (ucDest == IOL_BROADCAST) {

		BOX->SetCommError(IOL_DEST);
		bCommError = TRUE;
		return PA_OK;
	}
	if (ucNumber < aCmdInfo[ucCommand].CountReq) {

		return IOL_CHRCT;
	}
	if (WriteMsgQueue.WillRcvBfrOverflow(ucNumber)) {

		return IOL_RCVBUFOV;
	}
  /*if (!is_iolink_in_gap()) {
		BOX->SetCommError(IOL_GAP);
	    bCommError = TRUE;
	}
	else*/
	{
		xmit_buffer[IOLRESP_MSGNUM] = ucMsgNumber;
		//StartResponse();
		/* Give Control Builder database writes priority over the synchronous
		 * RT1024 HART transport. HART resumes after the write burst ends. */
		HartDeferTransactions();
		WriteMsgQueue.AddMessage(ucMsgNumber++,ucNumber);
		pRcvBuffer = WriteMsgQueue.GetRcvBufPtr();
		TaskScheduler.RunTask(TASKID_WRDBTASK);
		ComputeFletcher(xmit_buffer, FTYP_APPEND);
		StartResponse();
	}

	return PA_OK;
}

PASTATUS clsIol::Cmd0BHandler(VOID) {

	return PA_OK;
}
PASTATUS clsIol::Cmd0CHandler(VOID) {

	return PA_OK;
}
PASTATUS clsIol::Cmd0FHandler(VOID) {

	return PA_OK;
}
PASTATUS clsIol::Cmd10Handler(VOID) {
    /* Legacy command 0x10: one-based indexed read.  Experion uses this for
       HART dynamic/device-variable arrays (HDYNVAL..HSLOTEU). */
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    UINT8 ucSlotNum = pRcvBuffer[IOLREQ_SLOTNUM];
    if (ucSlotNum > MAXSLOTS) {
        return DO_INVALID_SLOT_INDEX;
    }

    UINT8 ucParamNumber = pRcvBuffer[IOLREQ_PARAMID];
    UINT8 ucDatatype = pDatabase[ucSlotNum]->GetDataType(ucParamNumber);
    if (ucDatatype == DT_NONE) {
        return DO_PARAMETER_INVALID;
    }

    if ((ucSlotNum > 0u) &&
        (ucParamNumber >= PARAMID_HDYNVAL) &&
        (ucParamNumber <= PARAMID_HSLOTEU)) {
        if ((TRUE == SLOT(ucSlotNum)->GetHartCfgDb().HEnable) &&
            (HDATAINIT_PENDING == SLOT(ucSlotNum)->GetHartDevDb().m_HDataInit)) {
            return IOL_REMOTE_FETCH_PENDING;
        }
    }

    if (GHOXXX == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    } else {
        xmit_buffer[IOLMSG_NUMBER] +=
            pDatabase[ucSlotNum]->GetParamSize(ucParamNumber);
        xmit_buffer[IOLRESP_DATATYPE] = ucDatatype;
        pDatabase[ucSlotNum]->ReadParamData(
            &xmit_buffer[IOLRESP_RDDATA],
            ucParamNumber,
            pRcvBuffer[IOLREQ_INDEX]);
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        /* RT1024 starts sending as soon as StartResponse enables TX IRQ.
         * Finish the legacy indexed payload and checksum first so Experion
         * cannot receive stale HART variable bytes. */
        StartResponse();
    }
    return PA_OK;
}
PASTATUS clsIol::Cmd16Handler(VOID) {

	// If I am the backup module and the request was addressed via DSA, do nothing
	if (ucDest == ucIolBA) {

		xmit_buffer[IOLMSG_NUMBER] = 0;
		return PA_OK;
	}

	// Check for illegal broadcast
	if (ucDest == IOL_BROADCAST) {

		BOX->SetCommError(IOL_DEST);
		bCommError = TRUE;
		return PA_OK;
	}

	// Check that character count is correct
	if (ucNumber != aCmdInfo[ucCommand].CountReq) {

		return IOL_CHRCT;
	}

	// Check for gap error
	if (GHOXXX == GHO_NOTINGAP) {

		BOX->SetCommError(IOL_GAP);
		bCommError = TRUE;
	}
	else { // if none, build the response

		UINT16 nCount = BOX->CollectNrmEclInfo(&xmit_buffer[IOLRESP_ECLINFO],IOL_MAXXMT_MSGSIZE-10);
		xmit_buffer[IOLMSG_NUMBER] += (UINT8)nCount;
		BOX->CollectNrmEclData(&xmit_buffer[IOLRESP_ECLDATA],nCount);
		ComputeFletcher(xmit_buffer, FTYP_APPEND);
		StartResponse();
	}

	return PA_OK;
}
PASTATUS clsIol::Cmd17Handler(VOID) {

	// Get ECL Status
	if (ucDest == ucIolBA) {

		xmit_buffer[IOLMSG_NUMBER] = 0;
		return PA_OK;
	}
	if (ucDest == IOL_BROADCAST) {

		BOX->SetCommError(IOL_DEST);
		bCommError = TRUE;
		return PA_OK;
	}
	if (ucNumber != aCmdInfo[ucCommand].CountReq) {

		return IOL_CHRCT;
	}
	if (GetGHOXXX() == GHO_NOTINGAP) {

		BOX->SetCommError(IOL_GAP);
		bCommError = TRUE;
	}
	else {

		xmit_buffer[IOLRESP_MSGSTS] = BOX->GetNrmEclStatus();
		ComputeFletcher(xmit_buffer, FTYP_APPEND);
		StartResponse();
	}

	return PA_OK;
}
PASTATUS clsIol::Cmd1FHandler(VOID) { // Get Write Message Status

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
    	return IOL_CHRCT;
    }

    // Check for gap error
    if (GHOXXX == GHO_NOTINGAP) {
    	BOX->SetCommError(IOL_GAP);
    	bCommError = TRUE;
    }
    else { // if none, build the response
    	xmit_buffer[IOLRESP_MSGSTS] = WriteMsgQueue.GetMsgStatus(pRcvBuffer[IOLREQ_12DATA]);
    	ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }

	return PA_OK;
}
PASTATUS clsIol::Cmd20Handler(VOID) {
    // If the request was addressed to the backup address, do not respond.
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Legacy PMIO accepts CTLTOG length 0x05 and COMTOG length 0x06.
    if ((ucNumber != aCmdInfo[ucCommand].CountReq) &&
        (ucNumber != 0x06u)) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // If not a broadcast, build the response.
    if (ucDest != IOL_BROADCAST) {
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }

        /* On RT1024 the checksum must be complete before TX IRQ is enabled. */
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }
    else {
        xmit_buffer[IOLMSG_NUMBER] = 0;
    }

	return PA_OK;
}
PASTATUS clsIol::Cmd25Handler(VOID) { // Regenerate Events

	if (ucDest == ucIolBA) {
		xmit_buffer[IOLMSG_NUMBER] = 0;
		return PA_OK;
	}
	if (ucDest == IOL_BROADCAST) {
		BOX->SetCommError(IOL_DEST);
		bCommError = TRUE;
		return PA_OK;
	}
	if (ucNumber != aCmdInfo[ucCommand].CountReq) {
		return IOL_CHRCT;
	}
	if (GetGHOXXX() == GHO_NOTINGAP) {
		BOX->SetCommError(IOL_GAP);
		bCommError = TRUE;
	}
	else {
		ComputeFletcher(xmit_buffer, FTYP_APPEND);
		TaskScheduler.RunTask(TASKID_EVRCTASK);
		StartResponse();
	}
	return PA_OK;
}

PASTATUS clsIol::Cmd26Handler(VOID) { // Update Event Remove Pointer

	if (ucDest == ucIolBA) {
		xmit_buffer[IOLMSG_NUMBER] = 0;
		return PA_OK;
	}
	if (ucDest == IOL_BROADCAST) {
		BOX->SetCommError(IOL_DEST);
		bCommError = TRUE;
		return PA_OK;
	}
	if (ucNumber != aCmdInfo[ucCommand].CountReq) {
		return IOL_CHRCT;
	}
	if (GetGHOXXX() == GHO_NOTINGAP) {
		BOX->SetCommError(IOL_GAP);
		bCommError = TRUE;
	}
	else {

		UINT16 nCount = (256 * pRcvBuffer[IOLREQ_12DATA]) + pRcvBuffer[IOLREQ_12DATA+1];
		BOX->UpdateNrmEclRemPtr(nCount);
		ComputeFletcher(xmit_buffer, FTYP_APPEND);
		StartResponse();
	}
	return PA_OK;
}
PASTATUS clsIol::Cmd28Handler(VOID) {

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check that character count is correct
    // If it is not and it is a broadcast log a communication error
    // If it is not and it is not a broadcast respond with a NACK
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // Check if given DSA is valid
    // If so, disable transmission of response if request was not directed to me
    //        else build the class 2 response
	if (ucDest != IOL_BROADCAST) {

		if (pRcvBuffer[IOLREQ_12DATA] > MAXDSA) {
			return DO_ILLEGAL_VALUE;
		}
		// Check for gap error
		if (GetGHOXXX() == GHO_NOTINGAP) {
			BOX->SetCommError(IOL_GAP);
			bCommError = TRUE;
			return PA_OK;
		}
		else {// if none, build the response
			ComputeFletcher(xmit_buffer, FTYP_APPEND);
            StartResponse();
		}
	}
	else {
		xmit_buffer[IOLMSG_NUMBER] = 0;
		if (pRcvBuffer[IOLREQ_12DATA] != 0x00) return PA_OK;
	}

	SetIolDSA(pRcvBuffer[IOLREQ_12DATA]);
	BOX->SetDSA(ucIolDSA);

	// disable for AO [RTPN-1064] - AO16 Value drops for 2sec when EHPM is getting loaded even if FAULTOPT is set as HOLD
	if (ucIolDSA == 0) {
		BOX->ResetRedData(REDDATA_REDCFG);
	}

	return PA_OK;
}
PASTATUS clsIol::Cmd2AHandler(VOID) {

	// If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check that character count is correct
    // If it is not and it is a broadcast log a communication error
    // If it is not and it is not a broadcast respond with a NACK
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // Check if given DSA is valid
    // If so, disable transmission of response if request was not directed to me
    //        else build the class 2 response
	if (ucDest != IOL_BROADCAST) {

		if ((pRcvBuffer[IOLREQ_12DATA] != 0xFF) && (pRcvBuffer[IOLREQ_12DATA] > MAXDSA)) {
			return DO_ILLEGAL_VALUE;
		}
		// Check for gap error
		if (GetGHOXXX() == GHO_NOTINGAP) {
			BOX->SetCommError(IOL_GAP);
			bCommError = TRUE;
			return PA_OK;
		}
		else {// if none, build the response
			ComputeFletcher(xmit_buffer, FTYP_APPEND);
            StartResponse();
		}
	}
	else {
		xmit_buffer[IOLMSG_NUMBER] = 0;
		if (pRcvBuffer[IOLREQ_12DATA] != 0xFF) return PA_OK;
	}

    SetIolBA(pRcvBuffer[IOLREQ_12DATA]);
    BOX->SetBA(ucIolBA);

	return PA_OK;
}
PASTATUS clsIol::Cmd2CHandler(VOID) {
    // If the request was addressed to the backup address, do not respond.
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    if (ucDest != IOL_BROADCAST) {
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }

        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }
    else {
        xmit_buffer[IOLMSG_NUMBER] = 0;
    }

    BOX->ResetPRC();
	return PA_OK;
}
PASTATUS clsIol::Cmd2DHandler(VOID) {
    // If the request was addressed to the backup address, do not respond.
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    if (ucDest != IOL_BROADCAST) {
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }

        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }
    else {
        xmit_buffer[IOLMSG_NUMBER] = 0;
    }

    BOX->SetPRC();
	return PA_OK;
}
PASTATUS clsIol::Cmd2FHandler(VOID) {
    if (BOX->GetRedState() != REDSTATE_FREEZE_PERMITTED) {
        BOX->SetRedState(REDSTATE_FREEZE_NOT_ACCEPTED);
        if (ucDest == ucIolBA) {
            xmit_buffer[IOLMSG_NUMBER] = 0;
            return PA_OK;
        }
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }

    BOX->SetRedState(REDSTATE_FREEZE_ACCEPTED);
    return Cmd0AHandler();
}
PASTATUS clsIol::Cmd32Handler(VOID) {
    // If the request was addressed to the backup address, do not respond.
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    if (ucDest != IOL_BROADCAST) {
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }

        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }
    else {
        xmit_buffer[IOLMSG_NUMBER] = 0;
    }

    BOX->ResetCommErrs();
	return PA_OK;
}
PASTATUS clsIol::Cmd33Handler(VOID) {

	HWRevCodeWriteInProgress = TRUE;
	return PA_OK;
}
PASTATUS clsIol::Cmd35Handler(VOID) {

	return PA_OK;
}
PASTATUS clsIol::Cmd37Handler(VOID) {
    // A backup addressed through DSA updates state without responding.
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        BOX->SetRedState(REDSTATE_FREEZE_PERMITTED);
        return PA_OK;
    }

    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Legacy intentionally does not reject this command by character count.
    if (GHOXXX == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
        return PA_OK;
    }

    ComputeFletcher(xmit_buffer, FTYP_APPEND);
    StartResponse();
    BOX->SetRedState(REDSTATE_FREEZE_PERMITTED);
	return PA_OK;
}

PASTATUS clsIol::DefaultHandler(VOID)
{
	if (ucDest != IOL_BROADCAST) {

        BOX->SetCommError(IOL_COMM);
        bCommError = TRUE;
	}

    return PA_OK;
}

PASTATUS clsIol::BroadcastHandler(VOID)
{

    if (ucDest != IOL_BROADCAST) {

        BOX->SetCommError(IOL_COMM);
        ResetSilenceTimer(CNTLNKSIL);
        IOL_TxInterrupt(FALSE);
        IOL_TxDoneInterrupt(FALSE);
        IOL_RxInterrupt(TRUE);
    }

    return PA_OK;
}

/*******************************************************************************
*                       clsIol::ProcessDefWrCmd                                *
*                       =======================                                *
* PURPOSE:                                                                     *
*    Process deferred write command (BRDP) I-field extraction.  Get first 4    *
*    I-field characters, then remaining HART request bytes.                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    TRUE if all fields received, FALSE on timeout.                            *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
PASTATUS clsIol::ProcessDefWrCmd(VOID)
{
	return PA_OK;
}
