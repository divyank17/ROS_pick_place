/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_bbsram.h                                                *
*    Description : 23LCV1024 battery-backed SPI SRAM HAL for i.MX RT1024.      *
*******************************************************************************/
#ifndef __HAL_BBSRAM_H__
#define __HAL_BBSRAM_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HAL_BBSRAM_CAPACITY_BYTES (131072u) /* 1 Mbit / 128K x 8 */

bool hal_bbsram_init(void);
bool hal_bbsram_is_ready(void);
bool hal_bbsram_read(uint32_t address, void *destination, size_t length);
bool hal_bbsram_write(uint32_t address, const void *source, size_t length);
uint32_t hal_bbsram_get_error_count(void);

#ifdef __cplusplus
}
#endif

#endif /* __HAL_BBSRAM_H__ */
