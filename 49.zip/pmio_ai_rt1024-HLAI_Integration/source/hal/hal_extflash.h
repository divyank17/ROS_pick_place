/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_extflash.h                                              *
*    Description : W25Q128 failure-diagnostics NOR flash HAL for RT1024.       *
*******************************************************************************/
#ifndef __HAL_EXTFLASH_H__
#define __HAL_EXTFLASH_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HAL_EXTFLASH_CAPACITY_BYTES  (16u * 1024u * 1024u)
#define HAL_EXTFLASH_PAGE_BYTES      (256u)
#define HAL_EXTFLASH_SECTOR_BYTES    (4096u)

#define HAL_EXTFLASH_JEDEC_MFR        (0xEFu)
#define HAL_EXTFLASH_JEDEC_TYPE       (0x40u)
#define HAL_EXTFLASH_JEDEC_TYPE_ALT   (0x70u)
#define HAL_EXTFLASH_JEDEC_CAPACITY   (0x18u)

typedef enum tagHalExtFlashInitStage
{
    HAL_EXTFLASH_STAGE_NOT_STARTED = 0u,
    HAL_EXTFLASH_STAGE_PINS_READY = 1u,
    HAL_EXTFLASH_STAGE_SPI_READY = 2u,
    HAL_EXTFLASH_STAGE_RELEASED = 3u,
    HAL_EXTFLASH_STAGE_RESET = 4u,
    HAL_EXTFLASH_STAGE_JEDEC_READ = 5u,
    HAL_EXTFLASH_STAGE_JEDEC_VALID = 6u,
    HAL_EXTFLASH_STAGE_READY = 7u
} hal_extflash_init_stage_t;

typedef enum tagHalExtFlashInitError
{
    HAL_EXTFLASH_INIT_ERROR_NONE = 0u,
    HAL_EXTFLASH_INIT_ERROR_TRANSFER = 1u,
    HAL_EXTFLASH_INIT_ERROR_JEDEC_READ = 2u,
    HAL_EXTFLASH_INIT_ERROR_JEDEC_MISMATCH = 3u,
    HAL_EXTFLASH_INIT_ERROR_STATUS_READ = 4u,
    HAL_EXTFLASH_INIT_ERROR_BUSY_TIMEOUT = 5u
} hal_extflash_init_error_t;

bool hal_extflash_init(void);
bool hal_extflash_is_ready(void);
bool hal_extflash_read_jedec_id(uint8_t jedec_id[3]);
bool hal_extflash_read(uint32_t address, void *destination, size_t length);
bool hal_extflash_program(uint32_t address, const void *source, size_t length);
bool hal_extflash_erase_sector(uint32_t address);
bool hal_extflash_is_erased(uint32_t address, size_t length);
uint32_t hal_extflash_get_error_count(void);
uint32_t hal_extflash_get_raw_jedec_id(void);
uint32_t hal_extflash_get_init_stage(void);
uint32_t hal_extflash_get_init_error(void);
int32_t hal_extflash_get_last_transfer_status(void);
uint8_t hal_extflash_get_last_status1(void);

#ifdef __cplusplus
}
#endif

#endif /* __HAL_EXTFLASH_H__ */
