/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_bbsram.c                                                *
*    Description : 23LCV1024 battery-backed SPI SRAM HAL for i.MX RT1024.      *
*                                                                              *
*    Hardware (drawing 50195110, sheet 12):                                    *
*      LPSPI3 PCS0 -> BKP_CS0_n                                                *
*      LPSPI3 SCK  -> BKP_SCLK                                                 *
*      LPSPI3 SDO  -> BKP_MOSI                                                 *
*      LPSPI3 SDI  <- BKP_MISO                                                 *
*                                                                              *
*    Device: Microchip 23LCV1024-I/SN, 128K x 8, SPI mode 0.                  *
*******************************************************************************/
#include "hal_bbsram.h"

#include <string.h>

#include "fsl_clock.h"
#include "fsl_lpspi.h"
#include "hal_timer.h"

#define BBSRAM_SPI_BASE        LPSPI3
#define BBSRAM_SPI_CLOCK_FREQ  CLOCK_GetClockRootFreq(kCLOCK_LpspiClkRoot)
#define BBSRAM_SPI_BAUDRATE    (4000000u)
#define BBSRAM_SPI_PCS         kLPSPI_Pcs0
#define BBSRAM_XFER_PCS        kLPSPI_MasterPcs0

#define BBSRAM_CMD_READ        (0x03u)
#define BBSRAM_CMD_WRITE       (0x02u)
#define BBSRAM_CMD_RDMR        (0x05u)
#define BBSRAM_CMD_WRMR        (0x01u)
#define BBSRAM_CMD_RSTIO       (0xFFu)
#define BBSRAM_MODE_SEQUENTIAL (0x40u)

#define BBSRAM_TRANSFER_RETRIES (3u)
#define BBSRAM_DATA_CHUNK       (64u)
#define BBSRAM_HEADER_BYTES     (4u) /* command + 24-bit address */

static bool s_bbsramReady = false;
static uint32_t s_bbsramErrorCount = 0u;

static bool BbsramRangeIsValid(uint32_t address, size_t length)
{
    if (length == 0u)
    {
        return true;
    }

    if (address >= HAL_BBSRAM_CAPACITY_BYTES)
    {
        return false;
    }

    return (length <= (size_t)(HAL_BBSRAM_CAPACITY_BYTES - address));
}

static status_t BbsramTransfer(uint8_t *txData, uint8_t *rxData, size_t dataSize)
{
    lpspi_transfer_t transfer;
    status_t status = kStatus_Fail;

    transfer.txData = txData;
    transfer.rxData = rxData;
    transfer.dataSize = dataSize;
    transfer.configFlags = BBSRAM_XFER_PCS | kLPSPI_MasterPcsContinuous;

    for (uint32_t attempt = 0u; attempt < BBSRAM_TRANSFER_RETRIES; ++attempt)
    {
        const uint32_t savedMask = hal_interrupt_set_mask(7u);
        status = LPSPI_MasterTransferBlocking(BBSRAM_SPI_BASE, &transfer);
        hal_interrupt_set_mask(savedMask);

        if (status == kStatus_Success)
        {
            return status;
        }

        ++s_bbsramErrorCount;
    }

    return status;
}

static bool BbsramWriteMode(uint8_t mode)
{
    uint8_t tx[2] = { BBSRAM_CMD_WRMR, mode };
    return (BbsramTransfer(tx, NULL, sizeof(tx)) == kStatus_Success);
}

static bool BbsramReadMode(uint8_t *mode)
{
    uint8_t tx[2] = { BBSRAM_CMD_RDMR, 0u };
    uint8_t rx[2] = { 0u, 0u };

    if ((mode == NULL) ||
        (BbsramTransfer(tx, rx, sizeof(tx)) != kStatus_Success))
    {
        return false;
    }

    *mode = rx[1];
    return true;
}

bool hal_bbsram_init(void)
{
    lpspi_master_config_t config;
    uint8_t resetCommand = BBSRAM_CMD_RSTIO;
    uint8_t mode = 0u;

    s_bbsramReady = false;

    LPSPI_MasterGetDefaultConfig(&config);
    config.baudRate = BBSRAM_SPI_BAUDRATE;
    config.bitsPerFrame = 8u;
    config.cpol = kLPSPI_ClockPolarityActiveHigh; /* CPOL = 0 */
    config.cpha = kLPSPI_ClockPhaseFirstEdge;     /* CPHA = 0 */
    config.direction = kLPSPI_MsbFirst;
    config.pcsToSckDelayInNanoSec = 100u;
    config.lastSckToPcsDelayInNanoSec = 100u;
    config.betweenTransferDelayInNanoSec = 100u;
    config.whichPcs = BBSRAM_SPI_PCS;
    config.pcsActiveHighOrLow = kLPSPI_PcsActiveLow;

    LPSPI_MasterInit(BBSRAM_SPI_BASE, &config, BBSRAM_SPI_CLOCK_FREQ);

    /* RSTIO guarantees normal single-bit SPI operation even if a previous
     * interrupted transaction left the device in SDI mode. */
    if (BbsramTransfer(&resetCommand, NULL, 1u) != kStatus_Success)
    {
        return false;
    }

    /* Sequential mode lets one command transfer a complete trace record or
     * metadata block across page boundaries. */
    if (!BbsramWriteMode(BBSRAM_MODE_SEQUENTIAL) ||
        !BbsramReadMode(&mode) ||
        ((mode & 0xC0u) != BBSRAM_MODE_SEQUENTIAL))
    {
        ++s_bbsramErrorCount;
        return false;
    }

    s_bbsramReady = true;
    return true;
}

bool hal_bbsram_is_ready(void)
{
    return s_bbsramReady;
}

bool hal_bbsram_read(uint32_t address, void *destination, size_t length)
{
    uint8_t *output = (uint8_t *)destination;

    if (!s_bbsramReady || (destination == NULL) ||
        !BbsramRangeIsValid(address, length))
    {
        return (length == 0u);
    }

    while (length > 0u)
    {
        const size_t chunk = (length > BBSRAM_DATA_CHUNK) ?
                             BBSRAM_DATA_CHUNK : length;
        uint8_t tx[BBSRAM_HEADER_BYTES + BBSRAM_DATA_CHUNK];
        uint8_t rx[BBSRAM_HEADER_BYTES + BBSRAM_DATA_CHUNK];

        memset(tx, 0, BBSRAM_HEADER_BYTES + chunk);
        memset(rx, 0, BBSRAM_HEADER_BYTES + chunk);
        tx[0] = BBSRAM_CMD_READ;
        tx[1] = (uint8_t)(address >> 16);
        tx[2] = (uint8_t)(address >> 8);
        tx[3] = (uint8_t)address;

        if (BbsramTransfer(tx, rx, BBSRAM_HEADER_BYTES + chunk) != kStatus_Success)
        {
            return false;
        }

        memcpy(output, &rx[BBSRAM_HEADER_BYTES], chunk);
        output += chunk;
        address += (uint32_t)chunk;
        length -= chunk;
    }

    return true;
}

bool hal_bbsram_write(uint32_t address, const void *source, size_t length)
{
    const uint8_t *input = (const uint8_t *)source;

    if (!s_bbsramReady || (source == NULL) ||
        !BbsramRangeIsValid(address, length))
    {
        return (length == 0u);
    }

    while (length > 0u)
    {
        const size_t chunk = (length > BBSRAM_DATA_CHUNK) ?
                             BBSRAM_DATA_CHUNK : length;
        uint8_t tx[BBSRAM_HEADER_BYTES + BBSRAM_DATA_CHUNK];

        tx[0] = BBSRAM_CMD_WRITE;
        tx[1] = (uint8_t)(address >> 16);
        tx[2] = (uint8_t)(address >> 8);
        tx[3] = (uint8_t)address;
        memcpy(&tx[BBSRAM_HEADER_BYTES], input, chunk);

        if (BbsramTransfer(tx, NULL, BBSRAM_HEADER_BYTES + chunk) != kStatus_Success)
        {
            return false;
        }

        input += chunk;
        address += (uint32_t)chunk;
        length -= chunk;
    }

    return true;
}

uint32_t hal_bbsram_get_error_count(void)
{
    return s_bbsramErrorCount;
}
