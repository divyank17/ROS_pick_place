/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_tracestore.c                                            *
*    Description : Power-fail-safe TraceLog journal in external W25Q128 flash. *
*******************************************************************************/
#include "hal_tracestore.h"

#include <string.h>

#include "hal_extflash.h"

#define TRACESTORE_ENTRY_MAGIC            (0x544A4E4Cu) /* "TJNL" */
#define TRACESTORE_ENTRY_VERSION          (2u)
#define TRACESTORE_ENTRY_BYTES            (64u)
#define TRACESTORE_DATA_BYTES             (32u)
#define TRACESTORE_COMMIT_MARKER          (0xA55AA55Au)

#define TRACESTORE_FLAG_DATA              (0u)
#define TRACESTORE_FLAG_CHECKPOINT_COMMIT (1u)
#define TRACESTORE_CHECKPOINT_ADDRESS     (0xFFFFu)

#define TRACESTORE_ENTRY_COUNT \
    (HAL_TRACESTORE_FLASH_BYTES / TRACESTORE_ENTRY_BYTES)
#define TRACESTORE_ENTRIES_PER_SECTOR \
    (HAL_EXTFLASH_SECTOR_BYTES / TRACESTORE_ENTRY_BYTES)

/*
 * Two independent two-sector checkpoint banks preserve a complete 2048-byte
 * logical image. The remaining sectors are the normal append-only journal.
 *
 * A checkpoint bank contains 64 data entries plus one final bank-commit entry.
 * An incomplete bank is ignored after reset. The previous complete bank and
 * normal journal remain valid until the new bank commit has been programmed.
 */
#define TRACESTORE_CHECKPOINT_BANK_SECTORS (2u)
#define TRACESTORE_CHECKPOINT_BANK_SLOTS \
    (TRACESTORE_CHECKPOINT_BANK_SECTORS * TRACESTORE_ENTRIES_PER_SECTOR)
#define TRACESTORE_CHECKPOINT_DATA_ENTRIES \
    (HAL_TRACESTORE_CAPACITY_BYTES / TRACESTORE_DATA_BYTES)
#define TRACESTORE_CHECKPOINT_A_SLOT       (0u)
#define TRACESTORE_CHECKPOINT_B_SLOT       (TRACESTORE_CHECKPOINT_BANK_SLOTS)
#define TRACESTORE_NORMAL_START_SLOT \
    (2u * TRACESTORE_CHECKPOINT_BANK_SLOTS)

#pragma pack(push, 1)
typedef struct tagTraceStoreEntry
{
    uint32_t Magic;
    uint16_t Version;
    uint16_t EntryBytes;
    uint32_t Sequence;
    uint16_t LogicalAddress;
    uint16_t DataBytes;
    uint16_t Flags;
    uint16_t Reserved0;
    uint8_t  Data[TRACESTORE_DATA_BYTES];
    uint32_t Crc32;
    uint8_t  Reserved1[4];
    uint32_t Commit;
} TRACESTOREENTRY;
#pragma pack(pop)

_Static_assert(sizeof(TRACESTOREENTRY) == TRACESTORE_ENTRY_BYTES,
               "Trace journal entry must be 64 bytes");
_Static_assert((HAL_TRACESTORE_FLASH_BASE +
                HAL_TRACESTORE_FLASH_BYTES) <=
               HAL_EXTFLASH_CAPACITY_BYTES,
               "Trace journal exceeds W25Q128 capacity");
_Static_assert((HAL_TRACESTORE_FLASH_BASE %
                HAL_EXTFLASH_SECTOR_BYTES) == 0u,
               "Trace journal base must be sector aligned");
_Static_assert((HAL_TRACESTORE_FLASH_BYTES %
                HAL_EXTFLASH_SECTOR_BYTES) == 0u,
               "Trace journal size must be sector aligned");
_Static_assert((HAL_TRACESTORE_CAPACITY_BYTES %
                TRACESTORE_DATA_BYTES) == 0u,
               "Logical TraceStore must divide into complete entries");
_Static_assert((TRACESTORE_CHECKPOINT_DATA_ENTRIES + 1u) <=
               TRACESTORE_CHECKPOINT_BANK_SLOTS,
               "Checkpoint bank is too small");
_Static_assert(TRACESTORE_NORMAL_START_SLOT < TRACESTORE_ENTRY_COUNT,
               "No normal journal space remains");

static bool s_traceStoreReady = false;
static uint8_t s_traceStoreMirror[HAL_TRACESTORE_CAPACITY_BYTES];
static uint32_t s_traceStoreByteSequence[HAL_TRACESTORE_CAPACITY_BYTES];
static uint32_t s_traceStoreNextSlot = TRACESTORE_NORMAL_START_SLOT;
static uint32_t s_traceStoreSequence = 0u;
static uint32_t s_traceStoreErrorCount = 0u;
static uint32_t s_traceStoreJedecId = 0u;
static uint8_t s_traceStoreActiveCheckpoint = 0xFFu;
static uint32_t s_traceStoreCheckpointSequence = 0u;

static uint32_t TraceStoreCrc32(const uint8_t *data, uint32_t length)
{
    uint32_t crc = 0xFFFFFFFFu;

    for (uint32_t index = 0u; index < length; ++index)
    {
        crc ^= data[index];
        for (uint8_t bit = 0u; bit < 8u; ++bit)
        {
            const uint32_t mask = 0u - (crc & 1u);
            crc = (crc >> 1) ^ (0xEDB88320u & mask);
        }
    }

    return ~crc;
}

static bool TraceStoreSequenceIsNewer(uint32_t left, uint32_t right)
{
    return ((int32_t)(left - right) > 0);
}

static uint32_t TraceStoreSlotAddress(uint32_t slot)
{
    return HAL_TRACESTORE_FLASH_BASE +
           (slot * TRACESTORE_ENTRY_BYTES);
}

static bool TraceStoreRangeIsValid(uint32_t address, size_t length)
{
    if (length == 0u)
    {
        return true;
    }

    if (address >= HAL_TRACESTORE_CAPACITY_BYTES)
    {
        return false;
    }

    return (length <=
            (size_t)(HAL_TRACESTORE_CAPACITY_BYTES - address));
}

static bool TraceStoreEntryCommonIsValid(const TRACESTOREENTRY *entry)
{
    if ((entry->Magic != TRACESTORE_ENTRY_MAGIC) ||
        (entry->Version != TRACESTORE_ENTRY_VERSION) ||
        (entry->EntryBytes != TRACESTORE_ENTRY_BYTES) ||
        (entry->Commit != TRACESTORE_COMMIT_MARKER))
    {
        return false;
    }

    return (entry->Crc32 ==
            TraceStoreCrc32((const uint8_t *)entry,
                            (uint32_t)offsetof(TRACESTOREENTRY, Crc32)));
}

static bool TraceStoreDataEntryIsValid(const TRACESTOREENTRY *entry)
{
    return TraceStoreEntryCommonIsValid(entry) &&
           (entry->Flags == TRACESTORE_FLAG_DATA) &&
           (entry->DataBytes > 0u) &&
           (entry->DataBytes <= TRACESTORE_DATA_BYTES) &&
           TraceStoreRangeIsValid(entry->LogicalAddress,
                                  entry->DataBytes);
}

static bool TraceStoreCheckpointMarkerIsValid(
    const TRACESTOREENTRY *entry)
{
    return TraceStoreEntryCommonIsValid(entry) &&
           (entry->Flags == TRACESTORE_FLAG_CHECKPOINT_COMMIT) &&
           (entry->LogicalAddress == TRACESTORE_CHECKPOINT_ADDRESS) &&
           (entry->DataBytes == 0u);
}

static bool TraceStoreProgramEntry(uint32_t slot,
                                   uint16_t flags,
                                   uint32_t logicalAddress,
                                   const uint8_t *data,
                                   uint16_t length)
{
    TRACESTOREENTRY entry;
    TRACESTOREENTRY verify;
    const uint32_t commitOffset =
        (uint32_t)offsetof(TRACESTOREENTRY, Commit);

    memset(&entry, 0xFF, sizeof(entry));
    entry.Magic = TRACESTORE_ENTRY_MAGIC;
    entry.Version = TRACESTORE_ENTRY_VERSION;
    entry.EntryBytes = TRACESTORE_ENTRY_BYTES;
    entry.Sequence = s_traceStoreSequence + 1u;
    entry.LogicalAddress = (uint16_t)logicalAddress;
    entry.DataBytes = length;
    entry.Flags = flags;
    entry.Reserved0 = 0xFFFFu;

    if ((data != NULL) && (length > 0u))
    {
        memcpy(entry.Data, data, length);
    }

    entry.Crc32 = TraceStoreCrc32(
        (const uint8_t *)&entry,
        (uint32_t)offsetof(TRACESTOREENTRY, Crc32));
    entry.Commit = TRACESTORE_COMMIT_MARKER;

    const uint32_t entryAddress = TraceStoreSlotAddress(slot);

    /*
     * Program the commit word last. A power failure before that operation
     * leaves an entry which the next boot scan rejects.
     */
    if (!hal_extflash_program(entryAddress, &entry, commitOffset) ||
        !hal_extflash_program(entryAddress + commitOffset,
                              &entry.Commit,
                              sizeof(entry.Commit)) ||
        !hal_extflash_read(entryAddress, &verify, sizeof(verify)) ||
        (memcmp(&entry, &verify, sizeof(entry)) != 0))
    {
        ++s_traceStoreErrorCount;
        return false;
    }

    if (((flags == TRACESTORE_FLAG_DATA) &&
         !TraceStoreDataEntryIsValid(&verify)) ||
        ((flags == TRACESTORE_FLAG_CHECKPOINT_COMMIT) &&
         !TraceStoreCheckpointMarkerIsValid(&verify)))
    {
        ++s_traceStoreErrorCount;
        return false;
    }

    s_traceStoreSequence = entry.Sequence;
    return true;
}

static bool TraceStoreEraseCheckpointBank(uint32_t bankSlot)
{
    for (uint32_t sector = 0u;
         sector < TRACESTORE_CHECKPOINT_BANK_SECTORS;
         ++sector)
    {
        const uint32_t slot =
            bankSlot + (sector * TRACESTORE_ENTRIES_PER_SECTOR);
        if (!hal_extflash_erase_sector(TraceStoreSlotAddress(slot)))
        {
            ++s_traceStoreErrorCount;
            return false;
        }
    }

    return true;
}

static bool TraceStoreCreateCheckpoint(void)
{
    const uint8_t targetBank =
        (s_traceStoreActiveCheckpoint == 0u) ? 1u : 0u;
    const uint32_t targetSlot =
        (targetBank == 0u) ?
        TRACESTORE_CHECKPOINT_A_SLOT :
        TRACESTORE_CHECKPOINT_B_SLOT;

    /*
     * The inactive checkpoint bank can be erased safely. The currently
     * committed bank plus the normal journal still reconstruct the complete
     * logical image until the new checkpoint marker is committed.
     */
    if (!TraceStoreEraseCheckpointBank(targetSlot))
    {
        return false;
    }

    for (uint32_t entryIndex = 0u;
         entryIndex < TRACESTORE_CHECKPOINT_DATA_ENTRIES;
         ++entryIndex)
    {
        const uint32_t logicalAddress =
            entryIndex * TRACESTORE_DATA_BYTES;

        if (!TraceStoreProgramEntry(
                targetSlot + entryIndex,
                TRACESTORE_FLAG_DATA,
                logicalAddress,
                &s_traceStoreMirror[logicalAddress],
                TRACESTORE_DATA_BYTES))
        {
            return false;
        }
    }

    if (!TraceStoreProgramEntry(
            targetSlot + TRACESTORE_CHECKPOINT_DATA_ENTRIES,
            TRACESTORE_FLAG_CHECKPOINT_COMMIT,
            TRACESTORE_CHECKPOINT_ADDRESS,
            NULL,
            0u))
    {
        return false;
    }

    s_traceStoreActiveCheckpoint = targetBank;
    s_traceStoreCheckpointSequence = s_traceStoreSequence;
    s_traceStoreNextSlot = TRACESTORE_NORMAL_START_SLOT;
    return true;
}

static bool TraceStorePrepareNextNormalSlot(void)
{
    if (s_traceStoreNextSlot >= TRACESTORE_ENTRY_COUNT)
    {
        if (!TraceStoreCreateCheckpoint())
        {
            return false;
        }
    }

    uint32_t address = TraceStoreSlotAddress(s_traceStoreNextSlot);
    if (hal_extflash_is_erased(address, TRACESTORE_ENTRY_BYTES))
    {
        return true;
    }

    /*
     * A non-erased slot after the newest committed entry is either an older
     * journal generation or an interrupted program. Move to a sector boundary.
     * The committed checkpoint protects all values reclaimed from old sectors.
     */
    if ((s_traceStoreNextSlot % TRACESTORE_ENTRIES_PER_SECTOR) != 0u)
    {
        s_traceStoreNextSlot =
            ((s_traceStoreNextSlot / TRACESTORE_ENTRIES_PER_SECTOR) + 1u) *
            TRACESTORE_ENTRIES_PER_SECTOR;
    }

    if (s_traceStoreNextSlot >= TRACESTORE_ENTRY_COUNT)
    {
        if (!TraceStoreCreateCheckpoint())
        {
            return false;
        }
    }

    address = TraceStoreSlotAddress(s_traceStoreNextSlot);
    if (!hal_extflash_erase_sector(address))
    {
        ++s_traceStoreErrorCount;
        return false;
    }

    return true;
}

static bool TraceStoreAppend(uint32_t logicalAddress,
                             const uint8_t *data,
                             uint16_t length)
{
    if (!TraceStorePrepareNextNormalSlot())
    {
        return false;
    }

    if (!TraceStoreProgramEntry(s_traceStoreNextSlot,
                                TRACESTORE_FLAG_DATA,
                                logicalAddress,
                                data,
                                length))
    {
        /*
         * Do not retry a possibly partially programmed slot. The next call
         * skips the remainder of this sector if necessary.
         */
        ++s_traceStoreNextSlot;
        return false;
    }

    ++s_traceStoreNextSlot;
    return true;
}

static bool TraceStoreReadEntry(uint32_t slot, TRACESTOREENTRY *entry)
{
    if (!hal_extflash_read(TraceStoreSlotAddress(slot),
                           entry,
                           sizeof(*entry)))
    {
        ++s_traceStoreErrorCount;
        return false;
    }

    return true;
}

static void TraceStoreApplyDataEntry(const TRACESTOREENTRY *entry)
{
    for (uint16_t offset = 0u;
         offset < entry->DataBytes;
         ++offset)
    {
        const uint32_t logical =
            (uint32_t)entry->LogicalAddress + offset;

        if ((s_traceStoreByteSequence[logical] == 0u) ||
            TraceStoreSequenceIsNewer(
                entry->Sequence,
                s_traceStoreByteSequence[logical]))
        {
            s_traceStoreMirror[logical] = entry->Data[offset];
            s_traceStoreByteSequence[logical] = entry->Sequence;
        }
    }
}

static bool TraceStoreScanCheckpointBank(uint32_t bankSlot,
                                         bool *complete,
                                         uint32_t *markerSequence)
{
    TRACESTOREENTRY marker;
    const uint32_t markerSlot =
        bankSlot + TRACESTORE_CHECKPOINT_DATA_ENTRIES;

    *complete = false;
    *markerSequence = 0u;

    if (!TraceStoreReadEntry(markerSlot, &marker))
    {
        return false;
    }

    if (TraceStoreCheckpointMarkerIsValid(&marker))
    {
        *complete = true;
        *markerSequence = marker.Sequence;
    }

    return true;
}

static bool TraceStoreApplyCheckpointBank(uint32_t bankSlot,
                                          uint32_t markerSequence)
{
    TRACESTOREENTRY entry;

    for (uint32_t entryIndex = 0u;
         entryIndex < TRACESTORE_CHECKPOINT_DATA_ENTRIES;
         ++entryIndex)
    {
        if (!TraceStoreReadEntry(bankSlot + entryIndex, &entry))
        {
            return false;
        }

        if (TraceStoreDataEntryIsValid(&entry) &&
            !TraceStoreSequenceIsNewer(entry.Sequence, markerSequence))
        {
            TraceStoreApplyDataEntry(&entry);
            if ((s_traceStoreSequence == 0u) ||
                TraceStoreSequenceIsNewer(entry.Sequence,
                                          s_traceStoreSequence))
            {
                s_traceStoreSequence = entry.Sequence;
            }
        }
    }

    if ((s_traceStoreSequence == 0u) ||
        TraceStoreSequenceIsNewer(markerSequence,
                                  s_traceStoreSequence))
    {
        s_traceStoreSequence = markerSequence;
    }

    return true;
}

bool hal_tracestore_init(void)
{
    TRACESTOREENTRY entry;
    bool checkpointAComplete = false;
    bool checkpointBComplete = false;
    uint32_t checkpointASequence = 0u;
    uint32_t checkpointBSequence = 0u;
    bool foundNormalEntry = false;
    uint32_t newestNormalSequence = 0u;
    uint32_t newestNormalSlot = TRACESTORE_NORMAL_START_SLOT;

    s_traceStoreReady = false;
    s_traceStoreNextSlot = TRACESTORE_NORMAL_START_SLOT;
    s_traceStoreSequence = 0u;
    s_traceStoreJedecId = 0u;
    s_traceStoreActiveCheckpoint = 0xFFu;
    s_traceStoreCheckpointSequence = 0u;
    memset(s_traceStoreMirror, 0, sizeof(s_traceStoreMirror));
    memset(s_traceStoreByteSequence, 0,
           sizeof(s_traceStoreByteSequence));

    if (!hal_extflash_init())
    {
        s_traceStoreJedecId = hal_extflash_get_raw_jedec_id();
        ++s_traceStoreErrorCount;
        return false;
    }

    s_traceStoreJedecId = hal_extflash_get_raw_jedec_id();

    if (!TraceStoreScanCheckpointBank(
            TRACESTORE_CHECKPOINT_A_SLOT,
            &checkpointAComplete,
            &checkpointASequence) ||
        !TraceStoreScanCheckpointBank(
            TRACESTORE_CHECKPOINT_B_SLOT,
            &checkpointBComplete,
            &checkpointBSequence))
    {
        return false;
    }

    if (checkpointAComplete &&
        !TraceStoreApplyCheckpointBank(
            TRACESTORE_CHECKPOINT_A_SLOT,
            checkpointASequence))
    {
        return false;
    }

    if (checkpointBComplete &&
        !TraceStoreApplyCheckpointBank(
            TRACESTORE_CHECKPOINT_B_SLOT,
            checkpointBSequence))
    {
        return false;
    }

    if (checkpointAComplete &&
        ((!checkpointBComplete) ||
         TraceStoreSequenceIsNewer(checkpointASequence,
                                   checkpointBSequence)))
    {
        s_traceStoreActiveCheckpoint = 0u;
        s_traceStoreCheckpointSequence = checkpointASequence;
    }
    else if (checkpointBComplete)
    {
        s_traceStoreActiveCheckpoint = 1u;
        s_traceStoreCheckpointSequence = checkpointBSequence;
    }

    for (uint32_t slot = TRACESTORE_NORMAL_START_SLOT;
         slot < TRACESTORE_ENTRY_COUNT;
         ++slot)
    {
        if (!TraceStoreReadEntry(slot, &entry))
        {
            return false;
        }

        if (!TraceStoreDataEntryIsValid(&entry))
        {
            continue;
        }

        TraceStoreApplyDataEntry(&entry);

        if ((s_traceStoreSequence == 0u) ||
            TraceStoreSequenceIsNewer(entry.Sequence,
                                      s_traceStoreSequence))
        {
            s_traceStoreSequence = entry.Sequence;
        }

        if ((!foundNormalEntry) ||
            TraceStoreSequenceIsNewer(entry.Sequence,
                                      newestNormalSequence))
        {
            foundNormalEntry = true;
            newestNormalSequence = entry.Sequence;
            newestNormalSlot = slot;
        }
    }

    if (foundNormalEntry &&
        ((s_traceStoreCheckpointSequence == 0u) ||
         TraceStoreSequenceIsNewer(newestNormalSequence,
                                   s_traceStoreCheckpointSequence)))
    {
        s_traceStoreNextSlot = newestNormalSlot + 1u;
    }
    else
    {
        s_traceStoreNextSlot = TRACESTORE_NORMAL_START_SLOT;
    }

    memset(s_traceStoreByteSequence, 0,
           sizeof(s_traceStoreByteSequence));
    s_traceStoreReady = true;
    return true;
}

bool hal_tracestore_read(uint32_t address,
                         void *destination,
                         size_t length)
{
    if ((!s_traceStoreReady) || (destination == NULL) ||
        !TraceStoreRangeIsValid(address, length))
    {
        return (length == 0u);
    }

    memcpy(destination, &s_traceStoreMirror[address], length);
    return true;
}

bool hal_tracestore_write(uint32_t address,
                          const void *source,
                          size_t length)
{
    const uint8_t *input = (const uint8_t *)source;

    if ((!s_traceStoreReady) || (source == NULL) ||
        !TraceStoreRangeIsValid(address, length))
    {
        return (length == 0u);
    }

    while (length > 0u)
    {
        const uint16_t chunk =
            (length > TRACESTORE_DATA_BYTES) ?
            TRACESTORE_DATA_BYTES : (uint16_t)length;

        if (!TraceStoreAppend(address, input, chunk))
        {
            return false;
        }

        memcpy(&s_traceStoreMirror[address], input, chunk);
        address += chunk;
        input += chunk;
        length -= chunk;
    }

    return true;
}

uint32_t hal_tracestore_get_error_count(void)
{
    return s_traceStoreErrorCount +
           hal_extflash_get_error_count();
}

uint32_t hal_tracestore_get_jedec_id(void)
{
    return s_traceStoreJedecId;
}
