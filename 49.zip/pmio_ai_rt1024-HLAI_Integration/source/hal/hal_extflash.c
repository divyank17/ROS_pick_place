/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_extflash.c                                              *
*    Description : W25Q128 failure-diagnostics NOR flash HAL for RT1024.       *
*                                                                              *
*    Hardware (drawing 50195110, sheet 12):                                    *
*      LPSPI3 PCS1 -> BKP_CS1_n -> U30 W25Q128JVSIM                           *
*      LPSPI3 SCK  -> BKP_SCLK                                                 *
*      LPSPI3 SDO  -> BKP_MOSI                                                 *
*      LPSPI3 SDI  <- BKP_MISO                                                 *
*******************************************************************************/
#include "hal_extflash.h"

#include <string.h>

#include "fsl_clock.h"
#include "fsl_gpio.h"
#include "fsl_iomuxc.h"
#include "fsl_lpspi.h"
#include "hal_timer.h"

#define EXTFLASH_SPI_BASE           LPSPI3
#define EXTFLASH_SPI_CLOCK_FREQ     CLOCK_GetClockRootFreq(kCLOCK_LpspiClkRoot)
#define EXTFLASH_SPI_BAUDRATE       (4000000u)

/*
 * U30 is wired to the physical LPSPI3 PCS1 pad. The first board test showed
 * no accepted JEDEC response through hardware-managed PCS1. Drive the same
 * BKP_CS1_n net as GPIO1_IO25 and select the unrouted PCS3 internally. This
 * gives every W25Q128 command an explicit CS-high boundary and never selects
 * U39 on PCS0.
 */
#define EXTFLASH_SPI_UNUSED_PCS     kLPSPI_Pcs3
#define EXTFLASH_XFER_UNUSED_PCS    kLPSPI_MasterPcs3
#define EXTFLASH_CS_GPIO            GPIO1
#define EXTFLASH_CS_GPIO_PIN        (25u)
#define EXTFLASH_PAD_CONFIG         (0x10B0u)

#define EXTFLASH_CMD_WRITE_ENABLE   (0x06u)
#define EXTFLASH_CMD_READ_STATUS1   (0x05u)
#define EXTFLASH_CMD_READ_DATA      (0x03u)
#define EXTFLASH_CMD_PAGE_PROGRAM   (0x02u)
#define EXTFLASH_CMD_SECTOR_ERASE   (0x20u)
#define EXTFLASH_CMD_JEDEC_ID       (0x9Fu)
#define EXTFLASH_CMD_RELEASE_POWER_DOWN (0xABu)
#define EXTFLASH_CMD_RESET_ENABLE   (0x66u)
#define EXTFLASH_CMD_RESET          (0x99u)

#define EXTFLASH_STATUS_BUSY        (0x01u)
#define EXTFLASH_STATUS_WEL         (0x02u)

#define EXTFLASH_TRANSFER_RETRIES   (3u)
#define EXTFLASH_READ_CHUNK         (128u)
#define EXTFLASH_PROGRAM_TIMEOUT_MS (20u)
#define EXTFLASH_ERASE_TIMEOUT_MS   (500u)

static bool s_extflashReady = false;
static uint32_t s_extflashErrorCount = 0u;
static uint32_t s_extflashRawJedecId = 0u;
static uint32_t s_extflashInitStage = HAL_EXTFLASH_STAGE_NOT_STARTED;
static uint32_t s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_NONE;
static int32_t s_extflashLastTransferStatus = (int32_t)kStatus_Success;
static uint8_t s_extflashLastStatus1 = 0u;

static void ExtFlashChipSelect(bool asserted)
{
    GPIO_PinWrite(EXTFLASH_CS_GPIO,
                  EXTFLASH_CS_GPIO_PIN,
                  asserted ? 0u : 1u);
}

static bool ExtFlashRangeIsValid(uint32_t address, size_t length)
{
    if (length == 0u)
    {
        return true;
    }

    if (address >= HAL_EXTFLASH_CAPACITY_BYTES)
    {
        return false;
    }

    return (length <=
            (size_t)(HAL_EXTFLASH_CAPACITY_BYTES - address));
}

static status_t ExtFlashTransfer(uint8_t *txData,
                                 uint8_t *rxData,
                                 size_t dataSize)
{
    lpspi_transfer_t transfer;
    status_t status = kStatus_Fail;

    transfer.txData = txData;
    transfer.rxData = rxData;
    transfer.dataSize = dataSize;
    transfer.configFlags = EXTFLASH_XFER_UNUSED_PCS |
                           kLPSPI_MasterPcsContinuous;

    for (uint32_t attempt = 0u;
         attempt < EXTFLASH_TRANSFER_RETRIES;
         ++attempt)
    {
        ExtFlashChipSelect(true);
        const uint32_t savedMask = hal_interrupt_set_mask(7u);
        status = LPSPI_MasterTransferBlocking(EXTFLASH_SPI_BASE, &transfer);
        ExtFlashChipSelect(false);
        hal_interrupt_set_mask(savedMask);
        hal_delay_us(1u);
        s_extflashLastTransferStatus = (int32_t)status;

        if (status == kStatus_Success)
        {
            return status;
        }

        ++s_extflashErrorCount;
    }

    s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_TRANSFER;
    return status;
}

static bool ExtFlashReadStatus(uint8_t *status)
{
    uint8_t tx[2] = { EXTFLASH_CMD_READ_STATUS1, 0u };
    uint8_t rx[2] = { 0u, 0u };

    if ((status == NULL) ||
        (ExtFlashTransfer(tx, rx, sizeof(tx)) != kStatus_Success))
    {
        return false;
    }

    *status = rx[1];
    s_extflashLastStatus1 = rx[1];
    return true;
}

static bool ExtFlashWaitReady(uint32_t timeoutMs)
{
    uint8_t status = EXTFLASH_STATUS_BUSY;

    for (uint32_t elapsed = 0u; elapsed <= timeoutMs; ++elapsed)
    {
        if (!ExtFlashReadStatus(&status))
        {
            s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_STATUS_READ;
            return false;
        }

        if ((status & EXTFLASH_STATUS_BUSY) == 0u)
        {
            return true;
        }

        hal_delay_ms(1u);
    }

    ++s_extflashErrorCount;
    s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_BUSY_TIMEOUT;
    return false;
}

static bool ExtFlashWriteEnable(void)
{
    uint8_t command = EXTFLASH_CMD_WRITE_ENABLE;
    uint8_t status = 0u;

    if ((ExtFlashTransfer(&command, NULL, 1u) != kStatus_Success) ||
        !ExtFlashReadStatus(&status) ||
        ((status & EXTFLASH_STATUS_WEL) == 0u))
    {
        ++s_extflashErrorCount;
        return false;
    }

    return true;
}

bool hal_extflash_init(void)
{
    lpspi_master_config_t config;
    gpio_pin_config_t csConfig = {
        .direction = kGPIO_DigitalOutput,
        .outputLogic = 1u,
        .interruptMode = kGPIO_NoIntmode
    };
    uint8_t releasePowerDown = EXTFLASH_CMD_RELEASE_POWER_DOWN;
    uint8_t resetEnable = EXTFLASH_CMD_RESET_ENABLE;
    uint8_t reset = EXTFLASH_CMD_RESET;
    uint8_t id[3] = { 0u, 0u, 0u };

    s_extflashReady = false;
    s_extflashRawJedecId = 0u;
    s_extflashInitStage = HAL_EXTFLASH_STAGE_NOT_STARTED;
    s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_NONE;
    s_extflashLastTransferStatus = (int32_t)kStatus_Success;
    s_extflashLastStatus1 = 0u;

    CLOCK_EnableClock(kCLOCK_Gpio1);
    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_09_GPIO1_IO25, 0u);
    IOMUXC_SetPinConfig(IOMUXC_GPIO_AD_B1_09_GPIO1_IO25,
                       EXTFLASH_PAD_CONFIG);
    GPIO_PinInit(EXTFLASH_CS_GPIO, EXTFLASH_CS_GPIO_PIN, &csConfig);
    ExtFlashChipSelect(false);
    s_extflashInitStage = HAL_EXTFLASH_STAGE_PINS_READY;

    LPSPI_MasterGetDefaultConfig(&config);
    config.baudRate = EXTFLASH_SPI_BAUDRATE;
    config.bitsPerFrame = 8u;
    config.cpol = kLPSPI_ClockPolarityActiveHigh;
    config.cpha = kLPSPI_ClockPhaseFirstEdge;
    config.direction = kLPSPI_MsbFirst;
    config.pcsToSckDelayInNanoSec = 100u;
    config.lastSckToPcsDelayInNanoSec = 100u;
    config.betweenTransferDelayInNanoSec = 100u;
    config.whichPcs = EXTFLASH_SPI_UNUSED_PCS;
    config.pcsActiveHighOrLow = kLPSPI_PcsActiveLow;

    LPSPI_MasterInit(EXTFLASH_SPI_BASE, &config, EXTFLASH_SPI_CLOCK_FREQ);
    s_extflashInitStage = HAL_EXTFLASH_STAGE_SPI_READY;

    if (ExtFlashTransfer(&releasePowerDown, NULL, 1u) != kStatus_Success)
    {
        return false;
    }

    hal_delay_us(50u);
    s_extflashInitStage = HAL_EXTFLASH_STAGE_RELEASED;

    if ((ExtFlashTransfer(&resetEnable, NULL, 1u) != kStatus_Success) ||
        (ExtFlashTransfer(&reset, NULL, 1u) != kStatus_Success))
    {
        return false;
    }

    hal_delay_us(50u);
    s_extflashInitStage = HAL_EXTFLASH_STAGE_RESET;

    s_extflashReady = true;
    if (!hal_extflash_read_jedec_id(id))
    {
        s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_JEDEC_READ;
        s_extflashReady = false;
        return false;
    }

    s_extflashRawJedecId =
        ((uint32_t)id[0] << 16) |
        ((uint32_t)id[1] << 8) |
        (uint32_t)id[2];
    s_extflashInitStage = HAL_EXTFLASH_STAGE_JEDEC_READ;

    if ((id[0] != HAL_EXTFLASH_JEDEC_MFR) ||
        ((id[1] != HAL_EXTFLASH_JEDEC_TYPE) &&
         (id[1] != HAL_EXTFLASH_JEDEC_TYPE_ALT)) ||
        (id[2] != HAL_EXTFLASH_JEDEC_CAPACITY))
    {
        ++s_extflashErrorCount;
        s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_JEDEC_MISMATCH;
        s_extflashReady = false;
        return false;
    }

    s_extflashInitStage = HAL_EXTFLASH_STAGE_JEDEC_VALID;
    if (!ExtFlashWaitReady(EXTFLASH_PROGRAM_TIMEOUT_MS))
    {
        s_extflashReady = false;
        return false;
    }

    s_extflashInitStage = HAL_EXTFLASH_STAGE_READY;
    s_extflashInitError = HAL_EXTFLASH_INIT_ERROR_NONE;
    return true;
}

bool hal_extflash_is_ready(void)
{
    return s_extflashReady;
}

bool hal_extflash_read_jedec_id(uint8_t jedec_id[3])
{
    uint8_t tx[4] = { EXTFLASH_CMD_JEDEC_ID, 0u, 0u, 0u };
    uint8_t rx[4] = { 0u, 0u, 0u, 0u };

    if ((!s_extflashReady) || (jedec_id == NULL) ||
        (ExtFlashTransfer(tx, rx, sizeof(tx)) != kStatus_Success))
    {
        return false;
    }

    jedec_id[0] = rx[1];
    jedec_id[1] = rx[2];
    jedec_id[2] = rx[3];
    return true;
}

bool hal_extflash_read(uint32_t address, void *destination, size_t length)
{
    uint8_t *output = (uint8_t *)destination;

    if ((!s_extflashReady) || (destination == NULL) ||
        !ExtFlashRangeIsValid(address, length))
    {
        return (length == 0u);
    }

    while (length > 0u)
    {
        const size_t chunk = (length > EXTFLASH_READ_CHUNK) ?
                             EXTFLASH_READ_CHUNK : length;
        uint8_t tx[4u + EXTFLASH_READ_CHUNK];
        uint8_t rx[4u + EXTFLASH_READ_CHUNK];

        memset(tx, 0, 4u + chunk);
        memset(rx, 0, 4u + chunk);
        tx[0] = EXTFLASH_CMD_READ_DATA;
        tx[1] = (uint8_t)(address >> 16);
        tx[2] = (uint8_t)(address >> 8);
        tx[3] = (uint8_t)address;

        if (ExtFlashTransfer(tx, rx, 4u + chunk) != kStatus_Success)
        {
            return false;
        }

        memcpy(output, &rx[4], chunk);
        output += chunk;
        address += (uint32_t)chunk;
        length -= chunk;
    }

    return true;
}

bool hal_extflash_program(uint32_t address,
                          const void *source,
                          size_t length)
{
    const uint8_t *input = (const uint8_t *)source;

    if ((!s_extflashReady) || (source == NULL) ||
        !ExtFlashRangeIsValid(address, length))
    {
        return (length == 0u);
    }

    while (length > 0u)
    {
        const size_t pageRemaining =
            HAL_EXTFLASH_PAGE_BYTES -
            (size_t)(address & (HAL_EXTFLASH_PAGE_BYTES - 1u));
        const size_t chunk = (length < pageRemaining) ?
                             length : pageRemaining;
        uint8_t tx[4u + HAL_EXTFLASH_PAGE_BYTES];

        if (!ExtFlashWriteEnable())
        {
            return false;
        }

        tx[0] = EXTFLASH_CMD_PAGE_PROGRAM;
        tx[1] = (uint8_t)(address >> 16);
        tx[2] = (uint8_t)(address >> 8);
        tx[3] = (uint8_t)address;
        memcpy(&tx[4], input, chunk);

        if ((ExtFlashTransfer(tx, NULL, 4u + chunk) != kStatus_Success) ||
            !ExtFlashWaitReady(EXTFLASH_PROGRAM_TIMEOUT_MS))
        {
            return false;
        }

        input += chunk;
        address += (uint32_t)chunk;
        length -= chunk;
    }

    return true;
}

bool hal_extflash_erase_sector(uint32_t address)
{
    uint8_t tx[4];

    if ((!s_extflashReady) ||
        (address >= HAL_EXTFLASH_CAPACITY_BYTES))
    {
        return false;
    }

    address &= ~(HAL_EXTFLASH_SECTOR_BYTES - 1u);

    if (!ExtFlashWriteEnable())
    {
        return false;
    }

    tx[0] = EXTFLASH_CMD_SECTOR_ERASE;
    tx[1] = (uint8_t)(address >> 16);
    tx[2] = (uint8_t)(address >> 8);
    tx[3] = (uint8_t)address;

    if ((ExtFlashTransfer(tx, NULL, sizeof(tx)) != kStatus_Success) ||
        !ExtFlashWaitReady(EXTFLASH_ERASE_TIMEOUT_MS))
    {
        return false;
    }

    return true;
}

bool hal_extflash_is_erased(uint32_t address, size_t length)
{
    uint8_t data[EXTFLASH_READ_CHUNK];

    if (!ExtFlashRangeIsValid(address, length))
    {
        return false;
    }

    while (length > 0u)
    {
        const size_t chunk = (length > sizeof(data)) ?
                             sizeof(data) : length;
        if (!hal_extflash_read(address, data, chunk))
        {
            return false;
        }

        for (size_t index = 0u; index < chunk; ++index)
        {
            if (data[index] != 0xFFu)
            {
                return false;
            }
        }

        address += (uint32_t)chunk;
        length -= chunk;
    }

    return true;
}

uint32_t hal_extflash_get_error_count(void)
{
    return s_extflashErrorCount;
}

uint32_t hal_extflash_get_raw_jedec_id(void)
{
    return s_extflashRawJedecId;
}

uint32_t hal_extflash_get_init_stage(void)
{
    return s_extflashInitStage;
}

uint32_t hal_extflash_get_init_error(void)
{
    return s_extflashInitError;
}

int32_t hal_extflash_get_last_transfer_status(void)
{
    return s_extflashLastTransferStatus;
}

uint8_t hal_extflash_get_last_status1(void)
{
    return s_extflashLastStatus1;
}
