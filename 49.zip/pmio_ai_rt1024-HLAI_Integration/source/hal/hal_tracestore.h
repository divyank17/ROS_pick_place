/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_tracestore.h                                            *
*    Description : Power-fail-safe TraceLog journal in external W25Q128 flash. *
*******************************************************************************/
#ifndef __HAL_TRACESTORE_H__
#define __HAL_TRACESTORE_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * U30 is a dedicated 16 MiB failure-diagnostics flash. Build 39 reserves its
 * final 256 KiB for TraceLog. Keep these two definitions aligned with the
 * product-level failure-diagnostics memory allocation.
 */
#ifndef HAL_TRACESTORE_FLASH_BASE
#define HAL_TRACESTORE_FLASH_BASE       (0x00FC0000u)
#endif

#ifndef HAL_TRACESTORE_FLASH_BYTES
#define HAL_TRACESTORE_FLASH_BYTES      (0x00040000u)
#endif

#define HAL_TRACESTORE_CAPACITY_BYTES   (2048u)

bool hal_tracestore_init(void);
bool hal_tracestore_read(uint32_t address,
                         void *destination,
                         size_t length);
bool hal_tracestore_write(uint32_t address,
                          const void *source,
                          size_t length);
uint32_t hal_tracestore_get_error_count(void);
uint32_t hal_tracestore_get_jedec_id(void);

#ifdef __cplusplus
}
#endif

#endif /* __HAL_TRACESTORE_H__ */
