#ifndef HART_UART_COMPAT_HPP
#define HART_UART_COMPAT_HPP

#include "datatype.h"
#include "hal_fpga.h"

/*
 * RT1024 compatibility view of the legacy H8 memory-mapped HART UART.
 *
 * The legacy expression HART_UART(n).FIELD is preserved, but every access is
 * translated to the FPGA SPI HAL.  This is not a memory-mapped structure:
 * callers must not take addresses of fields or retain references to them.
 */
namespace hart_uart_compat
{
enum class Register : UINT8
{
    RBR = FPGA_UART_RHR,
    THR = FPGA_UART_THR,
    IER = FPGA_UART_IER,
    IIR = FPGA_UART_IIR,
    FCR = FPGA_UART_FCR,
    LCR = FPGA_UART_LCR,
    MCR = FPGA_UART_MCR,
    LSR = FPGA_UART_LSR,
    MSR = FPGA_UART_MSR,
    SCR = FPGA_UART_SCR,
    RESET = 0xFFu
};

enum class Access : UINT8
{
    HardwareRead,
    ShadowRead,
    ReadOnly,
    WriteOnly,
    ResetPulse
};

struct ShadowState
{
    UINT8 ier;
    UINT8 fcr;
    UINT8 lcr;
    UINT8 mcr;
    UINT8 scr;
};

inline ShadowState *Shadows()
{
    static ShadowState state[FPGA_HART_UART_COUNT] = {};
    return state;
}

inline UINT8 ClampModem(UINT8 modem)
{
    return (UINT8)(modem & 0x03u);
}

inline UINT8 ReadShadow(UINT8 modem, Register reg)
{
    const ShadowState &s = Shadows()[ClampModem(modem)];
    switch (reg)
    {
        case Register::IER: return s.ier;
        case Register::FCR: return s.fcr;
        case Register::LCR: return s.lcr;
        case Register::MCR: return s.mcr;
        case Register::SCR: return s.scr;
        default: return 0u;
    }
}

inline void WriteShadow(UINT8 modem, Register reg, UINT8 value)
{
    ShadowState &s = Shadows()[ClampModem(modem)];
    switch (reg)
    {
        case Register::IER: s.ier = value; break;
        case Register::FCR:
            s.fcr = (UINT8)(value & (UINT8)~0x06u);
            break;
        case Register::LCR: s.lcr = value; break;
        case Register::MCR: s.mcr = value; break;
        case Register::SCR: s.scr = value; break;
        default: break;
    }
}

inline UINT8 Read(UINT8 modem, Register reg, Access access)
{
    modem = ClampModem(modem);
    if (access == Access::ShadowRead)
    {
        return ReadShadow(modem, reg);
    }
    if ((access == Access::WriteOnly) || (access == Access::ResetPulse))
    {
        return 0u;
    }
    return hal_fpga_uart_read(modem, (UINT8)reg);
}

inline void Write(UINT8 modem, Register reg, UINT8 value, Access access)
{
    modem = ClampModem(modem);
    if (access == Access::ReadOnly)
    {
        return;
    }
    if (access == Access::ResetPulse)
    {
        if (value != 0u)
        {
            hal_fpga_uart_reset(modem);
            Shadows()[modem] = ShadowState{};
        }
        return;
    }

    WriteShadow(modem, reg, value);
    hal_fpga_uart_write(modem, (UINT8)reg, value);
}

class RegisterProxy
{
public:
    RegisterProxy(UINT8 modem, Register reg, Access access)
        : modem_(ClampModem(modem)), reg_(reg), access_(access) {}

    operator UINT8() const { return Read(modem_, reg_, access_); }

    RegisterProxy &operator=(UINT8 value)
    {
        Write(modem_, reg_, value, access_);
        return *this;
    }

    RegisterProxy &operator=(int value)
    {
        return (*this = (UINT8)value);
    }

    RegisterProxy &operator=(unsigned int value)
    {
        return (*this = (UINT8)value);
    }

private:
    UINT8 modem_;
    Register reg_;
    Access access_;
};

class FieldProxy
{
public:
    FieldProxy(UINT8 modem, Register reg, UINT8 mask, UINT8 shift, Access access)
        : modem_(ClampModem(modem)), reg_(reg), mask_(mask), shift_(shift), access_(access) {}

    operator UINT8() const
    {
        return (UINT8)((Read(modem_, reg_, access_) & mask_) >> shift_);
    }

    FieldProxy &operator=(UINT8 value)
    {
        UINT8 regValue = Read(modem_, reg_,
                              (access_ == Access::WriteOnly) ? Access::ShadowRead : access_);
        regValue = (UINT8)((regValue & (UINT8)~mask_) |
                           (UINT8)((UINT8)(value << shift_) & mask_));
        Write(modem_, reg_, regValue, access_);
        return *this;
    }

    FieldProxy &operator=(int value)
    {
        return (*this = (UINT8)value);
    }

    FieldProxy &operator=(unsigned int value)
    {
        return (*this = (UINT8)value);
    }

private:
    UINT8 modem_;
    Register reg_;
    UINT8 mask_;
    UINT8 shift_;
    Access access_;
};

class HartUartCompat
{
public:
    explicit HartUartCompat(UINT8 modem)
        : RCVBUF_REGISTER(modem, Register::RBR, Access::ReadOnly),
          XMTHOLD_REGISTER(modem, Register::THR, Access::WriteOnly),
          INTR_ENBL_REGISTER(modem, Register::IER, Access::ShadowRead),
          INTR_IDNT_REGISTER(modem, Register::IIR, Access::HardwareRead),
          FIFO_CTRL_REGISTER(modem, Register::FCR, Access::ShadowRead),
          LINE_CTRL_REGISTER(modem, Register::LCR, Access::ShadowRead),
          MODEM_CTRL_REGISTER(modem, Register::MCR, Access::ShadowRead),
          LINE_STS_REGISTER(modem, Register::LSR, Access::ReadOnly),
          MODEM_STS_REGISTER(modem, Register::MSR, Access::ReadOnly),
          SCRATCH_PAD_REGISTER(modem, Register::SCR, Access::ShadowRead),
          RESET(modem, Register::RESET, Access::ResetPulse),

          RCVDATAAVBL_INTR_ENBL(modem, Register::IER, 0x01u, 0u, Access::ShadowRead),
          XMTREGEMPTY_INTR_ENBL(modem, Register::IER, 0x02u, 1u, Access::ShadowRead),
          RCVLINESTS_INTR_ENBL(modem, Register::IER, 0x04u, 2u, Access::ShadowRead),
          MODEMSTS_INTR_ENBL(modem, Register::IER, 0x08u, 3u, Access::ShadowRead),

          INTR_PENDING(modem, Register::IIR, 0x01u, 0u, Access::ReadOnly),
          INTR_ID(modem, Register::IIR, 0x0Eu, 1u, Access::ReadOnly),
          HART_INTR_ID(modem, Register::IIR, 0x0Fu, 0u, Access::ReadOnly),

          FIFO_ENBL(modem, Register::FCR, 0x01u, 0u, Access::ShadowRead),
          RCV_FIFO_CLEAR(modem, Register::FCR, 0x02u, 1u, Access::ShadowRead),
          XMT_FIFO_CLEAR(modem, Register::FCR, 0x04u, 2u, Access::ShadowRead),
          DMA_MODE_SELECT(modem, Register::FCR, 0x08u, 3u, Access::ShadowRead),
          RCV_FIFO_TRIG_LEVEL(modem, Register::FCR, 0xC0u, 6u, Access::ShadowRead),

          BITS_PER_CHAR(modem, Register::LCR, 0x03u, 0u, Access::ShadowRead),
          STOP_BITS_SELECT(modem, Register::LCR, 0x04u, 2u, Access::ShadowRead),
          PARITY_ENBL(modem, Register::LCR, 0x08u, 3u, Access::ShadowRead),
          EVEN_PARITY_SELECT(modem, Register::LCR, 0x10u, 4u, Access::ShadowRead),
          STICK_PARITY_SELECT(modem, Register::LCR, 0x20u, 5u, Access::ShadowRead),
          SET_BREAK(modem, Register::LCR, 0x40u, 6u, Access::ShadowRead),
          DVSR_LATCH_ACCESS(modem, Register::LCR, 0x80u, 7u, Access::ShadowRead),

          DATA_TERM_READY(modem, Register::MCR, 0x01u, 0u, Access::ShadowRead),
          REQUEST_TO_SEND(modem, Register::MCR, 0x02u, 1u, Access::ShadowRead),
          USER_OUTPUT1(modem, Register::MCR, 0x04u, 2u, Access::ShadowRead),
          USER_OUTPUT2(modem, Register::MCR, 0x08u, 3u, Access::ShadowRead),
          LOOP_BACK_ENBL(modem, Register::MCR, 0x10u, 4u, Access::ShadowRead),

          DATA_READY(modem, Register::LSR, 0x01u, 0u, Access::ReadOnly),
          OVERRUN_ERROR(modem, Register::LSR, 0x02u, 1u, Access::ReadOnly),
          PARITY_ERROR(modem, Register::LSR, 0x04u, 2u, Access::ReadOnly),
          FRAMING_ERROR(modem, Register::LSR, 0x08u, 3u, Access::ReadOnly),
          BREAK_INTR(modem, Register::LSR, 0x10u, 4u, Access::ReadOnly),
          XMTREG_EMPTY(modem, Register::LSR, 0x20u, 5u, Access::ReadOnly),
          XMT_COMPLETE(modem, Register::LSR, 0x40u, 6u, Access::ReadOnly),
          RCV_FIFO_ERROR(modem, Register::LSR, 0x80u, 7u, Access::ReadOnly),

          DELTA_CLEAR_TO_SEND(modem, Register::MSR, 0x01u, 0u, Access::ReadOnly),
          DELTA_DATASET_READ(modem, Register::MSR, 0x02u, 1u, Access::ReadOnly),
          TRAIL_EDGE_INDICATOR(modem, Register::MSR, 0x04u, 2u, Access::ReadOnly),
          DELTA_CARRIER_DETECT(modem, Register::MSR, 0x08u, 3u, Access::ReadOnly),
          CLEAR_TO_SEND(modem, Register::MSR, 0x10u, 4u, Access::ReadOnly),
          DATASET_READ(modem, Register::MSR, 0x20u, 5u, Access::ReadOnly),
          RING_INDICATER(modem, Register::MSR, 0x40u, 6u, Access::ReadOnly),
          CARRIER_DETECT(modem, Register::MSR, 0x80u, 7u, Access::ReadOnly) {}

    RegisterProxy RCVBUF_REGISTER;
    RegisterProxy XMTHOLD_REGISTER;
    RegisterProxy INTR_ENBL_REGISTER;
    RegisterProxy INTR_IDNT_REGISTER;
    RegisterProxy FIFO_CTRL_REGISTER;
    RegisterProxy LINE_CTRL_REGISTER;
    RegisterProxy MODEM_CTRL_REGISTER;
    RegisterProxy LINE_STS_REGISTER;
    RegisterProxy MODEM_STS_REGISTER;
    RegisterProxy SCRATCH_PAD_REGISTER;
    RegisterProxy RESET;

    FieldProxy RCVDATAAVBL_INTR_ENBL;
    FieldProxy XMTREGEMPTY_INTR_ENBL;
    FieldProxy RCVLINESTS_INTR_ENBL;
    FieldProxy MODEMSTS_INTR_ENBL;
    FieldProxy INTR_PENDING;
    FieldProxy INTR_ID;
    FieldProxy HART_INTR_ID;
    FieldProxy FIFO_ENBL;
    FieldProxy RCV_FIFO_CLEAR;
    FieldProxy XMT_FIFO_CLEAR;
    FieldProxy DMA_MODE_SELECT;
    FieldProxy RCV_FIFO_TRIG_LEVEL;
    FieldProxy BITS_PER_CHAR;
    FieldProxy STOP_BITS_SELECT;
    FieldProxy PARITY_ENBL;
    FieldProxy EVEN_PARITY_SELECT;
    FieldProxy STICK_PARITY_SELECT;
    FieldProxy SET_BREAK;
    FieldProxy DVSR_LATCH_ACCESS;
    FieldProxy DATA_TERM_READY;
    FieldProxy REQUEST_TO_SEND;
    FieldProxy USER_OUTPUT1;
    FieldProxy USER_OUTPUT2;
    FieldProxy LOOP_BACK_ENBL;
    FieldProxy DATA_READY;
    FieldProxy OVERRUN_ERROR;
    FieldProxy PARITY_ERROR;
    FieldProxy FRAMING_ERROR;
    FieldProxy BREAK_INTR;
    FieldProxy XMTREG_EMPTY;
    FieldProxy XMT_COMPLETE;
    FieldProxy RCV_FIFO_ERROR;
    FieldProxy DELTA_CLEAR_TO_SEND;
    FieldProxy DELTA_DATASET_READ;
    FieldProxy TRAIL_EDGE_INDICATOR;
    FieldProxy DELTA_CARRIER_DETECT;
    FieldProxy CLEAR_TO_SEND;
    FieldProxy DATASET_READ;
    FieldProxy RING_INDICATER;
    FieldProxy CARRIER_DETECT;
};
} // namespace hart_uart_compat

#ifndef HART_UART
#define HART_UART(n) (::hart_uart_compat::HartUartCompat((UINT8)(n)))
#endif

#endif /* HART_UART_COMPAT_HPP */
