/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihslot.cpp                                                 *
*    Description : Class clsAihSlot definition.                                *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <math.h>
#include "aihmain.h"

//UINT32 u1_LastExecState = 0; // temp for testing

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Slot checkpoint version - must be available in all build configurations
#define LATEST_SLTCHKPNT_VERSION LATEST_UIO_AI_SLTCHKPNT_VERSION

#if defined(IOMTYPE_UIO)
// Parameter IDs for following parameters are moved from aihslot.hpp to aihslot.cpp file.
// Because UIO will support AI,AO,DI and DO and aihslot.hpp,dislot.hpp,aohslot.hpp and doslot.hpp
// files will have same macro names for these parameters. To avoid compilation errors(Duplicate definitions)
// parameter definitions are moved from aihslot.hpp to aihslot.cpp file. Similarly for DI,DO and AO files.
#define PARAMID_INPTDIR     56
#define PARAMID_PNTTYPE     60
#define PARAMID_PTEXECST    61
#define PARAMID_PVSOURCE    93
#define PARAMID_PVSRCOPT    94
#define PARAMID_SLTCHKPNT   150
#define PARAMID_SLTCHKPNTVER    245
#endif

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
#if 1//defined(IOPTYPE_HLAI)
//J TYPE T/C Segment Number: 1 from -7900.0000000000uV(-200.44C) to -5720.0000000000uV(-127.80C)
const FLOAT32 clsAihSlot::J_COEFF_SET0[] = { -6.43695661790666690E+002,
                                             -3.88231251386591420E-001,
                                             -9.75924384722758450E-005,
                                             -1.03669907783138520E-008,
                                             -4.22158808250626940E-013
};
//J TYPE T/C Segment Number: 2 from -5720.0000000000uV(-127.80C) to 1030.0000000000uV(20.21C)
const FLOAT32 clsAihSlot::J_COEFF_SET1[] = {  1.13535074806805220E-002,
                                              1.98598352260953950E-002,
                                             -2.61721179183327980E-007,
                                             -3.06144992424454780E-013,
                                             -5.28828335206980480E-015
};
//J TYPE T/C Segment Number: 3 from 1030.0000000000uV(20.21C) to 20460.0000000000uV(374.83C)
const FLOAT32 clsAihSlot::J_COEFF_SET2[] = {  1.65435622583975260E-001,
                                              1.96759697511699370E-002,
                                             -1.76641317022024960E-007,
                                              7.97751945739614400E-012,
                                             -1.27323294206093460E-016
};
//J TYPE T/C Segment Number: 4 from 20460.0000000000uV(374.83C) to 40710.0000000000uV(725.22C)
const FLOAT32 clsAihSlot::J_COEFF_SET3[] = {  6.83090142524482080E+001,
                                              8.74901516766694860E-003,
                                              4.88562274570928810E-007,
                                             -1.04417467043403530E-011,
                                              7.11754469159352980E-017
};
//J TYPE T/C Segment Number: 5 from 40710.0000000000uV(725.22C) to 54740.0000000000uV(946.45C)
const FLOAT32 clsAihSlot::J_COEFF_SET4[] = { -1.15442105601496540E+003,
                                              1.13043370512791310E-001,
                                             -2.81080770865706660E-006,
                                              3.52611825636707710E-011,
                                             -1.61312124534184950E-016
};
//J TYPE T/C Segment Number: 6 from 54740.0000000000uV(946.45C) to 69550.0000000000uV(1199.94C)
const FLOAT32 clsAihSlot::J_COEFF_SET5[] = {  1.93892600506231160E+003,
                                             -9.69580594534117930E-002,
                                              2.52643500996247030E-006,
                                             -2.49050466500328800E-011,
                                              9.24112882557700110E-017
};

//K TYPE T/C Segment Number: 1 from -5900.0000000000uV(-200.57C) to -4390.0000000000uV(-129.22C)
const FLOAT32 clsAihSlot::K_COEFF_SET0[] = { -8.92177560258824090E+002,
                                             -7.19454456424979960E-001,
                                             -2.34454102191807010E-004,
                                             -3.28113878679712870E-008,
                                             -1.75826689009500490E-012
};
//K TYPE T/C Segment Number: 2 from -4390.0000000000uV(-129.22C) to 120.0000000000uV(3.04C)
const FLOAT32 clsAihSlot::K_COEFF_SET1[] = { -1.10605455819896000E-002,
                                              2.52005090009401990E-002,
                                             -6.63408346560438360E-007,
                                             -4.74226046559569210E-011,
                                             -2.62950802592357400E-014
};
//K TYPE T/C Segment Number: 3 from 120.0000000000uV(3.04C) to 7390.0000000000uV(181.25c)
const FLOAT32 clsAihSlot::K_COEFF_SET2[] = { -5.76550468802076170E-002,
                                              2.55286020323433130E-002,
                                             -5.34264574962465480E-007,
                                              7.81551449901910080E-011,
                                             -3.24304720927834710E-015
};
//K TYPE T/C Segment Number: 4 from 7390.0000000000uV(181.25c) to 15950.0000000000uV(389.41C)
const FLOAT32 clsAihSlot::K_COEFF_SET3[] = { -9.59108054424247670E+000,
                                              2.59983971951745390E-002,
                                              5.40282439347601430E-008,
                                             -1.35032458534748660E-011,
                                              3.92382067977712910E-016
};
//K TYPE T/C Segment Number: 5 from 15950.0000000000uV(389.41C) to 43550.0000000000uV(1058.82C)
const FLOAT32 clsAihSlot::K_COEFF_SET4[] = { -2.18527558347884750E+001,
                                              2.90842841683011320E-002,
                                             -2.96559356087807350E-007,
                                              6.22507527924963840E-012,
                                             -3.82807841890674420E-017
};
//K TYPE T/C Segment Number: 6 from 43550.0000000000uV(1058.82C) to 54880.0000000000uV(1371.81C)
const FLOAT32 clsAihSlot::K_COEFF_SET5[] = { -6.98688653046794230E+002,
                                              8.03281455814631170E-002,
                                             -1.68725107654565850E-006,
                                              2.17688903150353730E-011,
                                             -9.41843570167859030E-017
};

//E TYPE T/C Segment Number: 1 from -8830.0000000000uV(-200.22C) to -6720.0000000000uV(-135.15C)
const FLOAT32 clsAihSlot::E_COEFF_SET0[] = { -6.32905404450387660E+002,
                                             -3.33078781071565410E-001,
                                             -7.32485751512888060E-005,
                                             -6.79677565323291140E-009,
                                             -2.42897784985820620E-013
};
//E TYPE T/C Segment Number: 2 from -6720.0000000000uV(-135.15C) to -930.0000000000uV(-16.09C)
const FLOAT32 clsAihSlot::E_COEFF_SET1[] = { -1.78326863258159050E-001,
                                              1.67086231449987310E-002,
                                             -4.72498635674809390E-007,
                                             -3.58954462457204780E-011,
                                             -5.99373678998937170E-015
};
//E TYPE T/C Segment Number: 3 from -930.0000000000uV(-16.09) to 20180.0000000000uV(288.99C)
const FLOAT32 clsAihSlot::E_COEFF_SET2[] = { -2.16591632083498740E-003,
                                              1.70539828070282760E-002,
                                             -2.31173315751847020E-007,
                                              6.33383940929738860E-012,
                                             -7.89039480362184520E-017
};
//E TYPE T/C Segment Number: 4 from 20180.0000000000uV(288.99C) to 66170.0000000000uV(866.09C)
const FLOAT32 clsAihSlot::E_COEFF_SET3[] = {  8.42065978977963430E+000,
                                              1.52966549190731140E-002,
                                             -9.02625402525974190E-008,
                                              1.14504170927725980E-012,
                                             -4.75018749551588610E-018
};
//E TYPE T/C Segment Number: 5 from 66170.0000000000uV(866.09C) to 76370.0000000000uV(999.96C)
const FLOAT32 clsAihSlot::E_COEFF_SET4[] = { -1.84650057042293540E+003,
                                              1.20900688392081180E-001,
                                             -2.33547943818221080E-006,
                                              2.22535279653548410E-011,
                                             -7.87103044811625910E-017
};

//T TYPE T/C Segment Number: 1 from -6010.0000000000uV(-230.3C) to -5130.0000000000uV(-173.09C)
const FLOAT32 clsAihSlot::T_COEFF_SET0[] = { -1.27825271430897190E+004,
                                             -9.47614727154809170E+000,
                                             -2.65296824726376710E-003,
                                             -3.29582058408168200E-007,
                                             -1.54217437370670380E-011
};
//T TYPE T/C Segment Number: 2 from -5130.0000000000uV(-173.09C) to -2020.0000000000uV(-55.98C)
const FLOAT32 clsAihSlot::T_COEFF_SET1[] = { -8.07250631377047870E+000,
                                              1.45403509353883260E-002,
                                             -6.63799488870291950E-006,
                                             -1.29856703787583990E-009,
                                             -1.31390471391359630E-013
};
//T TYPE T/C Segment Number: 3 from -2020.0000000000uV(-55.98C) to 4470.0000000000uV(104.08C)
const FLOAT32 clsAihSlot::T_COEFF_SET2[] = {  2.97945235157134410E-002,
                                              2.58784581480305740E-002,
                                             -7.63828576723525590E-007,
                                              6.00464354552880470E-011,
                                             -4.44093693067020570E-015
};
//T TYPE T/C Segment Number: 4 from 4470.0000000000uV(104.08C) to 20870.0000000000uV(399.97C)
const FLOAT32 clsAihSlot::T_COEFF_SET3[] = {  2.30508485673941710E+000,
                                              2.45917730058376710E-002,
                                             -4.60380874689007880E-007,
                                              1.27587285981034450E-011,
                                             -1.63727142853188040E-016
};

//B TYPE T/C Segment Number: 1 from 30.0000000000uV(96.36C) to 130.0000000000uV(173.97C)
const FLOAT32 clsAihSlot::B_COEFF_SET0[] = {  5.45992307696616310E+001,
                                              1.68883041955307120E+000,
                                             -1.16099358968468230E-002,
                                              6.21503496451529110E-005,
                                             -1.41899766883674080E-007
};
//B TYPE T/C Segment Number: 2 from 130.0000000000uV(173.97C) to 450.0000000000uV(306.28C)
const FLOAT32 clsAihSlot::B_COEFF_SET1[] = {  7.99574846073366960E+001,
                                              9.04907029411058830E-001,
                                             -1.69015057714431720E-003,
                                              2.47007692143254960E-006,
                                             -1.55452838415347220E-009
};
//B TYPE T/C Segment Number: 3 from 450.0000000000uV(306.28C) to 1280.0000000000uV(507.52C)
const FLOAT32 clsAihSlot::B_COEFF_SET2[] = {  1.22272105534472000E+002,
                                              5.24119163696616820E-001,
                                             -3.18531931589741370E-004,
                                              1.53952422784960910E-007,
                                             -3.22735006942212740E-011
};
//B TYPE T/C Segment Number: 4 from 1280.0000000000uV(507.52C) to 3160.0000000000uV(800.84C)
const FLOAT32 clsAihSlot::B_COEFF_SET3[] = {  1.83562969293202680E+002,
                                              3.30524994986902130E-001,
                                             -7.76646530157251460E-005,
                                              1.50708055917700800E-008,
                                             -1.27619191786428160E-012
};
//B TYPE T/C Segment Number: 5 from 3160.0000000000uV(800.84C) to 7290.0000000000uV(1248.03C)
const FLOAT32 clsAihSlot::B_COEFF_SET4[] = {  2.71778002132017430E+002,
                                              2.17475293508387620E-001,
                                             -2.05030289473182130E-005,
                                              1.65920150666076200E-009,
                                             -5.74936015826816990E-014
};
//B TYPE T/C Segment Number: 6 from 7290.0000000000uV(1248.03C) to 13820.0000000000uV(1819.98C)
const FLOAT32 clsAihSlot::B_COEFF_SET5[] = {  3.85274848390841900E+002,
                                              1.52322479588850760E-001,
                                             -6.06281555999801910E-006,
                                              2.01003972833264160E-010,
                                             -1.17933904374876600E-015
};

//S TYPE T/C Segment Number: 1 from 0.0000000000uV(0C) to 940.0000000000uV(138.7C)
const FLOAT32 clsAihSlot::S_COEFF_SET0[] = {  3.65414414686176800E-002,
                                              1.83617522223811250E-001,
                                             -6.63434467258597530E-005,
                                              4.19316470620177650E-008,
                                             -1.30257885085664480E-011
};
//S TYPE T/C Segment Number: 2 from 940.0000000000uV(138.7C) to 3480.0000000000uV(422.96C)
const FLOAT32 clsAihSlot::S_COEFF_SET1[] = {  8.01481593364703570E+000,
                                              1.53890667399949220E-001,
                                             -1.88726447711641790E-005,
                                              3.57440235732600070E-009,
                                             -2.91187879370899280E-013
};
//S TYPE T/C Segment Number: 3 from 3480.0000000000uV(422.96C) to 8900.0000000000uV(939.96C)
const FLOAT32 clsAihSlot::S_COEFF_SET2[] = {  4.29732545176711510E+001,
                                              1.15248107722635900E-001,
                                             -1.80394773302148860E-006,
                                              1.85749943033436530E-011,
                                              1.67431220779231400E-016
};
//S TYPE T/C Segment Number: 4 from 8900.0000000000uV(939.96C) to 17270.0000000000uV(1641.79C)
const FLOAT32 clsAihSlot::S_COEFF_SET3[] = { -1.64476230004524380E+001,
                                              1.35620622165937230E-001,
                                             -4.23938797180483730E-006,
                                              1.29509088355384420E-010,
                                             -9.73893187051826770E-016
};
//S TYPE T/C Segment Number: 5 from 17270.0000000000uV(1641.79C) to 17950.0000000000uV(1700.24C)
const FLOAT32 clsAihSlot::S_COEFF_SET4[] = { -6.81153434014709550E+003,
                                              1.28982712586512040E+000,
                                             -6.87717555781677640E-005,
                                              1.26919226361528260E-009,
                                              1.70867561718942700E-015
};

//R TYPE T/C Segment Number: 1 from 0.0000000000uV(0C) to 930.0000000000uV(136.37C)
const FLOAT32 clsAihSlot::R_COEFF_SET0[] = {  4.49054409037791260E-002,
                                              1.87210818100058430E-001,
                                             -7.64597479298262750E-005,
                                              5.02381168410082140E-008,
                                             -1.61634065089609490E-011
};
//R TYPE T/C Segment Number: 2 from 930.0000000000uV(136.37C) to 3500.0000000000uV(408.88C)
const FLOAT32 clsAihSlot::R_COEFF_SET1[] = {  8.97819621525579240E+000,
                                              1.53225848318800430E-001,
                                             -2.06818834751034600E-005,
                                              3.79494671165287610E-009,
                                             -3.05051011890756770E-013
};
//R TYPE T/C Segment Number: 3 from 3500.0000000000uV(408.88C) to 9740.0000000000uV(941.55C)
const FLOAT32 clsAihSlot::R_COEFF_SET2[] = {  4.50626330284994200E+001,
                                              1.13404895422409140E-001,
                                             -3.06072527556911900E-006,
                                              1.11672527872904500E-010,
                                             -2.32528171594228990E-015
};
//R TYPE T/C Segment Number: 4 from 9740.0000000000uV(941.55C) to 19520.0000000000uV(1648.56C)
const FLOAT32 clsAihSlot::R_COEFF_SET3[] = {  1.42737153828793030E+001,
                                              1.21462386274025090E-001,
                                             -3.61407979172566870E-006,
                                              1.02375444339413060E-010,
                                             -8.33885802514159460E-016
};
//R TYPE T/C Segment Number: 5 from 19520.0000000000uV(1648.56C) to 20230.0000000000uV(1700.62C)
const FLOAT32 clsAihSlot::R_COEFF_SET4[] = { -3.28830546466814670E+003,
                                              4.35583972867782610E-001,
                                             -3.63088542765380780E-007,
                                             -9.28384312509475540E-010,
                                              2.39534806708817900E-014
};

const FLOAT32 clsAihSlot::JR_COEFF_SET0[] = { 0.0768595,
                                              0.185029,
                                             -0.646992E-04,
                                              0.312839E-07,
                                             -0.672033E-11
};
//JAPAN R TYPE T/C  POLYNOMIAL COEFFICEINTS   200-400 oC
const FLOAT32 clsAihSlot::JR_COEFF_SET1[] = { 11.9452,
                                               0.147953,
                                              -0.172254E-04,
                                               0.281948E-08,
                                              -0.204802E-12
};
//JAPAN R TYPE T/C   POLYNOMIAL COEFFICEINTS 400-1050 oC
const FLOAT32 clsAihSlot::JR_COEFF_SET2[] = {  4.5509556E+01,
                                               1.1284875E-01,
                                              -2.8603978E-06,
                                               8.5173702E-11,
                                              -1.1440038E-15
};
//JAPAN TYPE R T/C POLYNOMIAL COEFFICIENTS  1050 TO 1400 oC
const FLOAT32 clsAihSlot::JR_COEFF_SET3[] = {  7.33001,
                                               0.123987E+00,
                                              -0.393709E-05,
                                               0.120231E-09,
                                              -0.119247E-14
};
//JAPAN TYPE R T/C POLYNOMIAL COEFFICIENTS  1400 TO 1770 oC
const FLOAT32 clsAihSlot::JR_COEFF_SET4[] = {  3665.91,
                                                 -0.694224,
                                                  0.645961E-4,
                                                 -0.242821E-8,
                                                  0.343118E-13
};

//PT 100 OHM DIN RTD  POLYNOMIAL COEFFICEINTS  -200-0 oC
const FLOAT32 clsAihSlot::PTDIN_SET0[] = { -241.773,
                                              0.220760E-02,
                                              0.301526E-08,
                                             -0.113419E-13,
                                              0.220445E-19
};
//PT 100 OHM DIN RTD  POLYNOMIAL COEFFICEINTS   0-300 oC
const FLOAT32 clsAihSlot::PTDIN_SET1[] = { -246.121,
                                              0.236461E-02,
                                              0.982877E-09,
                                             -0.365307E-15,
                                              0.201745E-20
};
//PT 100 OHM DIN RTD  POLYNOMIAL COEFFICEINTS  300-850 oC
const FLOAT32 clsAihSlot::PTDIN_SET2[] = { -241.813,
                                              0.229999E-02,
                                              0.132504E-08,
                                             -0.108666E-14,
                                              0.245641E-20
};

//PT 100 JIS POLYNOMIAL COEFFICIENTS  RANGE -200 TO 0 oC
const FLOAT32 clsAihSlot::PTJIS_SET0[] = { -237.404,
                                              0.214186E-02,
                                              0.365448E-08,
                                             -0.172584E-13,
                                              0.392444E-19
};
//PT 100 JIS POLYNOMIAL COEFFICIENTS  RANGE 0 TO 300 oC
const FLOAT32 clsAihSlot::PTJIS_SET1[] = { -241.641,
                                              0.231667E-02,
                                              0.102498E-08,
                                             -0.489978E-15,
                                              0.186215E-20
};
//PT 100 JIS POLYNOMIAL COEFFICIENTS  RANGE 300 TO 650 oC
const FLOAT32 clsAihSlot::PTJIS_SET2[] = { -238.055,
                                              0.225328E-02,
                                              0.144704E-08,
                                             -0.174097E-14,
                                              0.326377E-20
};

//NI 120 OHM RTD  POLYNOMIAL COEFFICEINTS   -45 TO 110 oC
const FLOAT32 clsAihSlot::NIRTD_SET0[] = { -188.416,
                                              0.155130E-02,
                                              0.225404E-08,
                                             -0.225913E-13,
                                              0.424983E-19
};
//NI 120 OHM RTD   POLYNOMIAL COEFFICEINTS   110-315 oC
const FLOAT32 clsAihSlot::NIRTD_SET1[] = { -162.158,
                                              0.147965E-02,
                                             -0.556362E-09,
                                             -0.200283E-14,
                                              0.239475E-20
};

//CU 10 OHM  POLYNOMIAL COEFFICEINTS   -20 TO 250 oC
const FLOAT32 clsAihSlot::CURTD_SET0[] = { -234.336,
                                              0.0259336,
                                             -0.402695E-14,
                                              0.203216E-18,
                                             -0.376112E-23
};
// TABLE OF COEFFICEINT SET POINTERS FOR J_TYPE
const FLOAT32 *clsAihSlot::J_TYPE[] = { J_COEFF_SET0,    //  -200 TO    0 DEGREES
                                        J_COEFF_SET1,    //     0 TO  400 DEGREES
                                        J_COEFF_SET2,    //   400 TO  760 DEGREES
                                        J_COEFF_SET3,    //   760 TO 1200 DEGREES
                                        J_COEFF_SET4,
                                        J_COEFF_SET5
};

// TABLE OF COEFFICEINT SET POINTERS FOR K_TYPE
const FLOAT32 *clsAihSlot::K_TYPE[] = { K_COEFF_SET0,    //-200 TO -100  DEGREES
                                        K_COEFF_SET1,    //-100 TO    0  DEGREES
                                        K_COEFF_SET2,    //   0 TO  200  DEGREES
                                        K_COEFF_SET3,    // 200 TO  400  DEGREES
                                        K_COEFF_SET4,    // 400 TO 1370  DEGREES
                                        K_COEFF_SET5
};

// TABLE OF COEFFICEINT SET POINTERS FOR E_TYPE
const FLOAT32 *clsAihSlot::E_TYPE[] = { E_COEFF_SET0,    //-200 TO -100  DEGREES
                                        E_COEFF_SET1,    //-100 TO    0  DEGREES
                                        E_COEFF_SET2,    //   0 TO  400  DEGREES
                                        E_COEFF_SET3,    // 400 TO 1000  DEGREES
                                        E_COEFF_SET4
};

// TABLE OF COEFFICEINT SET POINTERS FOR T_TYPE
const FLOAT32 *clsAihSlot::T_TYPE[] = { T_COEFF_SET0,    //-230 TO -200  DEGREES
                                        T_COEFF_SET1,    //-200 TO -100  DEGREES
                                        T_COEFF_SET2,    //-100 TO    0  DEGREES
                                        T_COEFF_SET3     //   0 TO  400  DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR B_TYPE
const FLOAT32 *clsAihSlot::B_TYPE[] = { B_COEFF_SET0,    //100  TO 200   DEGREES
                                        B_COEFF_SET1,    //200  TO 400   DEGREES
                                        B_COEFF_SET2,    //400  TO 700   DEGREES
                                        B_COEFF_SET3,    //700  TO 1050  DEGREES
                                        B_COEFF_SET4,    //1050 TO 1650  DEGREES
                                        B_COEFF_SET5     //1650 TO 1820  DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR S_TYPE
const FLOAT32 *clsAihSlot::S_TYPE[] = { S_COEFF_SET0,    //   0 TO 200   DEGREES
                                        S_COEFF_SET1,    // 200 TO 400   DEGREES
                                        S_COEFF_SET2,    // 400 TO 1050  DEGREES
                                        S_COEFF_SET3,    //1050 TO 1400  DEGREES
                                        S_COEFF_SET4     //1400 TO 1700  DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR R_TYPE
const FLOAT32 *clsAihSlot::R_TYPE[] = { R_COEFF_SET0,    //   0 TO  200  DEGREES
                                        R_COEFF_SET1,    // 200 TO  400  DEGREES
                                        R_COEFF_SET2,    // 400 TO 1050  DEGREES
                                        R_COEFF_SET3,    //1050 TO 1400  DEGREES
                                        R_COEFF_SET4     //1400 TO 1700  DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR JR_TYPE
const FLOAT32 *clsAihSlot::JR_TYPE[] = { JR_COEFF_SET0,   //   0 TO 200   DEGREES
                                         JR_COEFF_SET1,   // 200 TO 400   DEGREES
                                         JR_COEFF_SET2,   // 400 TO 1050  DEGREES
                                         JR_COEFF_SET3,   //1050 TO 1400  DEGREES
                                         JR_COEFF_SET4    //1400 TO 1700  DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR PTDIN
const FLOAT32 *clsAihSlot::PTDIN[] = { PTDIN_SET0,      //-180 TO   0   DEGREES
                                       PTDIN_SET1,      //   0 TO 300   DEGREES
                                       PTDIN_SET2       // 300 TO 800   DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR PTJIS
const FLOAT32 *clsAihSlot::PTJIS[] = { PTJIS_SET0,      //-180 TO   0   DEGREES
                                       PTJIS_SET1,      //   0 TO 300   DEGREES
                                       PTJIS_SET2       // 300 TO 650   DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR NIRTD
const FLOAT32 *clsAihSlot::NIRTD[] = { NIRTD_SET0,      // -45 TO 110   DEGREES
                                       NIRTD_SET1       // 110 TO 315   DEGREES
};

// TABLE OF COEFFICEINT SET POINTERS FOR CURTD
const FLOAT32 *clsAihSlot::CURTD[] = { CURTD_SET0 };    // -20 TO 250   DEGREES


// TABLE OF THERMOCOUPLE TYPE POINTERS
const FLOAT32 **clsAihSlot::POLY_COEFF_SET[] = { J_TYPE,  //POINTER TO J COEFF SETS
                                                 K_TYPE,  //POINTER TO K COEFF SETS
                                                 E_TYPE,  //POINTER TO E COEFF SETS
                                                 T_TYPE,  //POINTER TO T COEFF SETS
                                                 B_TYPE,  //POINTER TO B COEFF SETS
                                                 S_TYPE,  //POINTER TO S COEFF SETS
                                                 R_TYPE,  //POINTER TO R COEFF SETS
                                                JR_TYPE,  //POINTER TO JR COEFF SETS
                                                  PTDIN,  //POINTER TO PTDIN COEFF SETS
                                                  PTJIS,  //POINTER TO PTJIS COEFF SETS
                                                  NIRTD,  //POINTER TO NIRTD COEFF SETS
                                                  CURTD   //POINTER TO CURTD COEFF SETS
};

// J TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::J_BP[] = {    5.0,    //MAXIMUM OFFSET VALUE
                                    -7900.0,    // -200.44C
                                    -5720.0,    // -127.80C
                                     1030.0,    //   20.21C
                                    20460.0,    //  374.83C
                                    40710.0,    //  725.22C
                                    54740.0,    //  946.45C
                                    69550.0     // 1199.94C
};

// K TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::K_BP[] = {    5.0,    //MAXIMUM OFFSET VALUE
                                    -5900.0,    //-200.57C
                                    -4390.0,    //-129.22C
                                      120.0,    //   3.04C
                                     7390.0,    // 181.25C
                                    15950.0,    // 389.41C
                                    43550.0,    //1058.82C
                                    54880.0     //1371.81C
};

// E TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::E_BP[] = {    4.0,    //MAXIMUM OFFSET VALUE
                                    -8830.0,    //-200.22C
                                    -6720.0,    //-135.15C
                                     -930.0,    // -16.09C
                                    20180.0,    // 288.99C
                                    66170.0,    // 866.09C
                                    76370.0     // 999.96C
};

// T TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::T_BP[] = {    3.0,    //MAXIMUM OFFSET VALUE
                                    -6010.0,    //-230.03C
                                    -5130.0,    //-173.09C
                                    -2020.0,    // -55.98C
                                     4470.0,    // 104.08C
                                    20870.0     // 399.97C
};

// B TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::B_BP[] = {    5.0,    //MAXIMUM OFFSET VALUE
                                       30.0,    //  96.36C
                                      130.0,    // 173.97C
                                      450.0,    // 306.28C
                                     1280.0,    // 507.52C
                                     3160.0,    // 800.84C
                                     7290.0,    //1248.03C
                                    13820.0     //1819.98C
};

// S TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::S_BP[] = {    4.0,    //MAXIMUM OFFSET VALUE
                                        0.0,    //   0.0C
                                      940.0,    // 138.7C
                                     3480.0,    // 422.96C
                                     8900.0,    // 939.96C
                                    17270.0,    //1641.79C
                                    17950.0     //1700.24C
};

// R TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::R_BP[] = {    4.0,    //MAXIMUM OFFSET VALUE
                                        0.0,    //   0.0C
                                      930.0,    // 136.37C
                                     3500.0,    // 408.88C
                                     9740.0,    // 941.55C
                                    19520.0,    //1648.56C
                                    20230.0     //1700.62C
};

// JAPAN R TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsAihSlot::JR_BP[] = {   4.0,    //MAXIMUM OFFSET VALUE
                                        0.0,    //0oC    =  0.0
                                     1468.13,   //200oC  =  1468.13
                                     3407.19,   //400oC  =  3407.19
                                    11169.53,   //1050oC =  11169.53
                                    16034.71,   //1400oC =  16034.71
                                    21133.5     //1770oC =  21133.5
};

// PT 100 DIN  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHM)
const FLOAT32 clsAihSlot::PTD_BP[] = {    2.0,  //MAXIMUM OFFSET VALUE
                                      18490.0,  //-200oC =  18490
                                     100000.0,  //0oC    =  100000
                                     212020.0,  //300oC  =  212020
                                     390260.0   //850oC  =  390260
};

// PT 100 JIS  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHM)
const FLOAT32 clsAihSlot::PTJ_BP[] = {    2.0,  //MAXIMUM OFFSET VALUE
                                      17140.0,  //-200oC =  17140
                                     100000.0,  //0oC    =  100000
                                     213930.0,  //300oC  =  213930
                                     333450.0   //650oC  =  333450
};

// NI 120 OHM RTD  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHMS)
const FLOAT32 clsAihSlot::NI_BP[] = {    1.0,   //MAXIMUM OFFSET VALUE
                                     89492.0,   //-45oC  =  89492
                                    209850.0,   //110oC  =  209850
                                    463135.0    //315oC  =  463135
};

// CU 10 OHM RTD  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHMS)
const FLOAT32 clsAihSlot::CU_BP[] = {   0.0,    //MAXIMUM OFFSET VALUE
                                     8264.8,    //-20oC  =  8264.8
                                     8676.0     //250oC  =  18676
};

const FLOAT32 *clsAihSlot::BP_POINTER_TAB[] = {
    J_BP,                  //POINT TO J T/C BP's
    K_BP,                  //POINT TO K T/C BP's
    E_BP,                  //POINT TO E T/C BP's
    T_BP,                  //POINT TO T T/C BP's
    B_BP,                  //POINT TO B T/C BP's
    S_BP,                  //POINT TO S T/C BP's
    R_BP,                  //POINT TO R T/C BP's
    JR_BP,                 //POINT TO JR T/C BP's
    PTD_BP,                //POINT TO PT DIN BP's
    PTJ_BP,                //POINT TO PT JIS BP's
    NI_BP,                 //POINT TO NI RTD BP's
    CU_BP                  //POINT TO CU RTD BP's
};

#endif

//check point struct for AIH channel
const UINT8  clsAihSlot::CheckPointVer1[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    //PARAMID_HENABLE,
    //PARAMID_HALARMENABLE,
    PARAMID_SENSRTYP,
    PARAMID_PVCHAR,
    PARAMID_PVTEMP,
    PARAMID_INPTDIR,
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    PARAMID_PVRAWHI,
    PARAMID_PVRAWLO,
    PARAMID_PVCLAMP,
    PARAMID_LOCUTOFF,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_TF,
    PARAMID_PVTV,
    PARAMID_OWDENABLE,
    //PARAMID_HNTFYCFG,
    //PARAMID_HDVMFGCD,
    //PARAMID_HDVTYPCD,
    //PARAMID_HDVREVCD,
    //PARAMID_HDEVIDCD,
    //PARAMID_HDDREVCD,
    //PARAMID_HSCANCFG,
    //PARAMID_HCOMTHRS,
    //PARAMID_HCOMHYS,
    //PARAMID_HSLOTDVCBLND,
    PARAMID_PTEXECST,
    0 // Terminator
};

#if 0//!defined(IOPTYPE_HLAI)
// Series C IOM Checkpoint version 2[]
const UINT8  clsAihSlot::CheckPointVer2[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    //PARAMID_HENABLE,
    //PARAMID_HALARMENABLE,
    PARAMID_SENSRTYP,
    PARAMID_PVCHAR,
    PARAMID_PVTEMP,
    PARAMID_INPTDIR,
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    PARAMID_PVRAWHI,
    PARAMID_PVRAWLO,
    PARAMID_PVCLAMP,
    PARAMID_LOCUTOFF,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_TF,
    PARAMID_PVTV,
    PARAMID_OWDENABLE,
    //PARAMID_HNTFYCFG,
    //PARAMID_HDVMFGCD,
    //PARAMID_HDVTYPCD,
    //PARAMID_HDVREVCD,
    //PARAMID_HDEVIDCD,
    //PARAMID_HDDREVCD,
    //PARAMID_HSCANCFG,
    //PARAMID_HCOMTHRS,
    //PARAMID_HCOMHYS,
    //PARAMID_HSLOTDVCBLND,
    PARAMID_PTEXECST,
    //PARAMID_HDVMFGCD7,
    //PARAMID_HDVTYPCD7,
    //PARAMID_HSLOTDVCBLND7,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsAihSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { clsAihSlot::CheckPointVer1, 115 },
    { clsAihSlot::CheckPointVer2, 123 }
};

#else
// PM IOP Checkpoint[]
const UINT8  clsAihSlot::CheckPointVer2[] = {
    PARAMID_PNTTYPE,
    PARAMID_PNTFORM,
    PARAMID_SENSRTYP,
    PARAMID_PVCHAR,
    PARAMID_PVTEMP,
    PARAMID_INPTDIR,
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVFORMAT,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    PARAMID_PVRAWHI,
    PARAMID_PVRAWLO,
    PARAMID_PVCLAMP,
    PARAMID_LOCUTOFF,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_TF,
    PARAMID_PVTV,
    PARAMID_PVALDB,
    PARAMID_PVALDBEU,
    PARAMID_PVHITP,
    PARAMID_PVLOTP,
    PARAMID_PVHHTP,
    PARAMID_PVLLTP,
    PARAMID_PVROCPTP,
    PARAMID_PVROCNTP,
    PARAMID_SLWSRCID,
    PARAMID_PTEXECST,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsAihSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { clsAihSlot::CheckPointVer1, 115 },
    { clsAihSlot::CheckPointVer2, 77 }
};

const UINT8  clsAihSlot::PmCheckPoint[] = {
    PARAMID_PNTTYPE,
    PARAMID_PNTFORM,
    PARAMID_SENSRTYP,
    PARAMID_PVCHAR,
    PARAMID_PVTEMP,
    PARAMID_INPTDIR,
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVFORMAT,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    PARAMID_PVRAWHI,
    PARAMID_PVRAWLO,
    PARAMID_PVCLAMP,
    PARAMID_LOCUTOFF,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_TF,
    PARAMID_PVTV,
    PARAMID_PVALDB,
  //PARAMID_PVALDBEU,// not included even in pmio
    PARAMID_PVHITP,
    PARAMID_PVLOTP,
    PARAMID_PVHHTP,
    PARAMID_PVLLTP,
    PARAMID_PVROCPTP,
    PARAMID_PVROCNTP,
    PARAMID_SLWSRCID,
    PARAMID_PTEXECST,
    0 // Terminator
};

// PMIO HLAI SLOT DUMP PARAM
const UINT8  clsAihSlot::PmioDumpParamTbl[] = {
    PARAMID_PTEXECST,
    PARAMID_PTEXECSTLRS,
    PARAMID_PNTFORM,
    PARAMID_PNTTYPE,
    PARAMID_PV,
    PARAMID_PVP,
    PARAMID_PVSTS,
    PARAMID_LASTPV,
    PARAMID_PVCLAMP,
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_EUSPAN,
    PARAMID_PVALDB,
    PARAMID_PVALDBEU,
    PARAMID_PVHHTP,
    PARAMID_PVHITP,
    PARAMID_PVLLTP,
    PARAMID_PVLOTP,
    PARAMID_PVROCNTP,
    PARAMID_PVROCPTP,
    PARAMID_PVSOURCE,
    PARAMID_PVSRCOPT,
    PARAMID_LOCUTOFF,
    PARAMID_PVCHAR,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    PARAMID_SENSRTYP,
    PARAMID_PVFORMAT,
    PARAMID_CONTCUT,
    PARAMID_PVTV,
    PARAMID_PVTVP,
    PARAMID_TF,
    PARAMID_KF,
    PARAMID_INPTDIR,
    PARAMID_PVTEMP,
    PARAMID_PVRAWHI,
    PARAMID_PVRAWLO,
    PARAMID_RAWSPAN,
#if defined(HART_SUPPORT) // this shows, need of different FW req for HART & nHART
    PARAMID_LRV,
    PARAMID_URV,
    PARAMID_URL,
    PARAMID_DAMPING,
    PARAMID_STATE,
#endif
    PARAMID_SLWSRCID,
    PARAMID_PVEUHIRV,
    PARAMID_PVEULORV,
    0 // Terminator
};


// PMIO HART SLOT DUMP PARAM
const UINT8  clsAihSlot::PmioHartDumpParamTbl[] = {
    PARAMID_HENABLE,
    PARAMID_HSCANCFG,
    PARAMID_HDYNRATE,
    PARAMID_HDEVRATE,
  //PARAMID_HSLOTDVC,
    PARAMID_HSLOTDVCBLND,
    PARAMID_HCOMTHRS,
    PARAMID_HCOMHYS,
    PARAMID_HDVMFGCD,
    PARAMID_HDEVIDCD,
    PARAMID_HDVTYPCD,
    PARAMID_HDVREVCD,
    PARAMID_HALARMENABLE,
    PARAMID_HNTFYCFG,
    PARAMID_SLOTCFGD,
  //PARAMID_H7SLDVC,
    PARAMID_HSLOTDVCBLND,
    PARAMID_HSLOTDVCBLND7,
    PARAMID_HDVMFGCD7,
    PARAMID_HDVTYPCD7,
    0 // Terminator
};

const UINT8  clsAihSlot::PvRec[] = {
    PARAMID_PV,
    PARAMID_ALMINFO,
    PARAMID_PVSTS,
    0 //Terminator
};

/**
 * added to fix following customer issues,
 * SR 1-27797231845/ SF 00611701 / BW-40405
 * SR 1-27868328215/ SF 00616362 / BW-40433 / FAR 1-CTDY638
 */
const UINT8  clsAihSlot::PvStRec[] = {
    PARAMID_PV,
    PARAMID_PVSTS,
    0 //Terminator
};

#endif


UINT8 clsAihSlot::SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;



const UINT8 clsAihSlot::RedParams[] = {
    PARAMID_INPTDIR,
    PARAMID_LOCUTOFF,
    PARAMID_PNTTYPE,
    PARAMID_PTEXECST,
    PARAMID_PVCHAR,
    PARAMID_PVCLAMP,
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    PARAMID_PVRAWHI,
    PARAMID_PVRAWLO,
    PARAMID_PVSOURCE,
    PARAMID_PVSRCOPT,
    PARAMID_PVTEMP,
    PARAMID_PVTV,
    PARAMID_PVTVP,
    PARAMID_SENSRTYP,
    PARAMID_TF,
#if 1//defined(IOPTYPE_HLAI)
    PARAMID_CONTCUT,
    PARAMID_PNTFORM,
    PARAMID_PVALDB,
    PARAMID_PVFORMAT,
    PARAMID_PVHHTP,
    PARAMID_PVHITP,
    PARAMID_PVLLTP,
    PARAMID_PVLOTP,
    PARAMID_PVROCNTP,
    PARAMID_PVROCPTP,
    PARAMID_SLWSRCID,
    PARAMID_PVALDBEU,
    PARAMID_PVEUHIRV,
    PARAMID_PVEULORV,
    PARAMID_EUSPAN,
    PARAMID_KF,
    PARAMID_RAWSPAN,
#if 0 //defined(HART_SUPPORT) // this shows, need of different FW req for HART & nHART
	PARAMID_LRV,
	PARAMID_URV,
	PARAMID_URL,
	PARAMID_DAMPING,
#endif
#endif
    0 // Terminator
};

const UINT8 clsAihSlot::HEuRngExt[] = {
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    0 // Terminator
};

/*******************************************************************************
*                     PARAMETER TABLE (256 entries — sparse)                    *
*  Populated entries match Experion paramId assignments for AIH-HART.          *
*  Empty entries use DT_NONE sentinel.                                         *
*******************************************************************************/
#define EMPTY   {DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE}
#define S(fn)   &clsAihSlot::fn

const AI_SLOTPARAMINFO clsAihSlot::tblParamInfo[256] = {
    EMPTY,                                                                                       // 00
    EMPTY,                                                                                       // 01
    EMPTY,                                                                                       // 02
    EMPTY,                                                                                       // 03
    EMPTY,                                                                                       // 04
    EMPTY,                                                                                       // 05
    EMPTY,                                                                                       // 06
    EMPTY,                                                                                       // 07
    EMPTY,                                                                                       // 08
    EMPTY,                                                                                       // 09
    EMPTY,                                                                                       // 10
    EMPTY,                                                                                       // 11
    EMPTY,                                                                                       // 12
    EMPTY,                                                                                       // 13
    EMPTY,                                                                                       // 14
    EMPTY,                                                                                       // 15
    EMPTY,                                                                                       // 16
    EMPTY,                                                                                       // 17
    EMPTY,                                                                                       // 18
    EMPTY,                                                                                       // 19
    EMPTY,                                                                                       // 20
    EMPTY,                                                                                       // 21
    EMPTY,                                                                                       // 22
    EMPTY,                                                                                       // 23
    EMPTY,                                                                                       // 24
    EMPTY,                                                                                       // 25
    EMPTY,                                                                                       // 26
    EMPTY,                                                                                       // 27
    EMPTY,                                                                                       // 28
    EMPTY,                                                                                       // 29
    EMPTY,                                                                                       // 30
    EMPTY,                                                                                       // 31
    EMPTY,                                                                                       // 32
    EMPTY,                                                                                       // 33
    EMPTY,                                                                                       // 34
    EMPTY,                                                                                       // 35
    EMPTY,                                                                                       // 36
    EMPTY,                                                                                       // 37
    EMPTY,                                                                                       // 38
#if 1//defined(IOPTYPE_HLAI)
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetSlotCfgdPtr), FALSE,            // 39 SLOTCFGD
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                           // 39
#endif
    DT_BLIND, 4, AT_MBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, S(GetHSlotDvcPtr), TRUE,         // 40 HSLOTDVCBLND
    DT_BLIND, 4, AT_MBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, S(GetHSlotDvcPtr7), TRUE,        // 41 HSLOTDVCBLND7
    EMPTY,                                                                                       // 42
    EMPTY,                                                                                       // 43
    EMPTY,                                                                                       // 44
    EMPTY,                                                                                       // 45
    EMPTY,                                                                                       // 46
    EMPTY,                                                                                       // 47
    EMPTY,                                                                                       // 48
    EMPTY,                                                                                       // 49
    EMPTY,                                                                                       // 50
#if 1//defined(IOPTYPE_HLAI)
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetAlmInfoPtr), FALSE,                    // 51 ALMINFO
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 51
#endif
	DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetBadPvFlPtr), FALSE,              // 52 BadPvFl
    EMPTY,                                                                                       // 53
#if 1//defined(IOPTYPE_HLAI)
    DT_BOOL, 1, AT_SBYTE, ALCK_PROG, CONTROLSTATE_NONE, S(PreContCut), 0, S(GetContCutPtr), TRUE,      // 54 CONTCUT
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHighAlPtr), FALSE,               // 55 HIGHAL
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                           // 54
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                           // 55
#endif
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, S(PreInptDir), 0, S(GetInptDirPtr), TRUE,   // 56 InptDir
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetLastPvPtr), FALSE,            // 57 LastPv
	DT_FLOAT32, 4, AT_MBYTE, ALCK_EPB, CONTROLSTATE_NONE, S(PreLoCutOff), 0, S(GetLoCutOffPtr), TRUE,  // 58 LoCutOff
#if 1//defined(IOPTYPE_HLAI)
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, 0, S(PostPntForm), S(GetPntFormPtr), TRUE,  // 59 PNTFORM
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 59
#endif
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, S(PrePntType), S(PostPntType), S(GetPntTypePtr), TRUE,    // 60 PntType
    DT_ENUM, 1, AT_SBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PrePtExecSt), S(PostPtExecSt), S(GetPtExecStPtr), TRUE,// 61 PtExecSt
#if 1 //defined(IOPTYPE_HLAI)
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPtInAlPtr), FALSE,                      // 62 PTINAL
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 62
#endif
    DT_FLOAT32, 4, AT_BXREC, ALCK_OPER, CONTROLSTATE_NONE, S(PrePv), S(PostPv), S(GetPvPtr), TRUE,               // 63 Pv
#if 1//defined(IOPTYPE_HLAI)
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_NONE, S(PrePvAlDb), S(PostPvAlDb), S(GetPvAlDbPtr), FALSE,      // 64 PVALDB
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 64
#endif
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvAutoPtr), FALSE,         // 65 PvAuto
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvAutoStPtr), FALSE,          // 66 PvAutoSt
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvCalcPtr), FALSE,         // 67 PvCalc
#if 1//defined(IOPTYPE_HLAI)
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PrePvChar), S(PostPvEUHi), S(GetPvCharPtr), TRUE,   // 68 PvChar
#else
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PrePvChar), 0, S(GetPvCharPtr), TRUE,            // 68 PvChar
#endif
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, 0, 0, S(GetPvClampPtr), TRUE,                   // 69 PvClamp
    DT_FLOAT32, 4, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_INACTIVE, S(PrePvEUHi), S(PostPvEUHi), S(GetPvEUHiPtr), TRUE,// 70 PvEUHi
    DT_FLOAT32, 4, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_INACTIVE, S(PrePvEULo), S(PostPvEUHi), S(GetPvEULoPtr), TRUE,// 71 PvEULo
    DT_FLOAT32, 4, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_INACTIVE, S(PrePvExEUHi), S(PostPvExEUHi), S(GetPvExEUHiPtr), TRUE,// 72 PvExEUHi
    DT_FLOAT32, 4, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_INACTIVE, S(PrePvExEULo), S(PostPvExEULo), S(GetPvExEULoPtr), TRUE,// 73 PvExEULo
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvExHiFlPtr), FALSE,                    // 74 PvExHiFl
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvExLoFlPtr), FALSE,                    // 75 PvExLoFl
#if 1//defined(IOPTYPE_HLAI)
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, 0, 0, S(GetPvFormatPtr), TRUE,                     // 76 PVFORMAT
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 77
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PrePvHhTp), S(PostPvHhTp), S(GetPvHhTpPtr), TRUE,   // 78 PVHHTP
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 79
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PrePvHiTp), S(PostPvHiTp), S(GetPvHiTpPtr), TRUE,   // 80 PVHITP
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 81
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PrePvLlTp), S(PostPvLlTp), S(GetPvLlTpPtr), TRUE,   // 82 PVLLTP
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 83
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PrePvLoTp), S(PostPvLoTp), S(GetPvLoTpPtr), TRUE,   // 84 PVLOTP
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 76
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 77
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 78
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 79
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 80
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 81
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 82
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 83
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 84
#endif
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvPPtr), FALSE,                      // 85 PvP
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvRawPtr), FALSE,                    // 86 PvRaw
#if 1//defined(IOPTYPE_HLAI)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PrePvRawHI), S(PostPvRawHI), S(GetPvRawHIPtr), TRUE, // 87 PvRawHI
    DT_FLOAT32, 4, AT_MBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PrePvRawLO), S(PostPvRawHI), S(GetPvRawLOPtr), TRUE, // 88 PvRawLO
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 89
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PrePvRocNTp), S(PostPvRocNTp), S(GetPvRocNTpPtr), TRUE, // 90 PVROCNTP
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 91
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PrePvRocPTp), S(PostPvRocPTp), S(GetPvRocPTpPtr), TRUE, // 92 PVROCPTP
#else
    DT_FLOAT32, 4, AT_MBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PrePvRawHI), 0, S(GetPvRawHIPtr), TRUE,       // 87 PvRawHI
    DT_FLOAT32, 4, AT_MBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PrePvRawLO), 0, S(GetPvRawLOPtr), TRUE,       // 88 PvRawLO
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 89
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 90
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 91
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 92
#endif
    DT_ENUM, 1, AT_SBYTE, ALCK_OPER, CONTROLSTATE_NONE, S(PrePvSource), S(PostPvSource), S(GetPvSourcePtr), TRUE,// 93 PvSource
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, 0, S(PostPvSrcOpt), S(GetPvSrcOptPtr), TRUE,          // 94 PvSrcOpt
    DT_ENUM, 1, AT_BXREC, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvStsPtr), FALSE,                       // 95 PvSts
#if 1//defined(IOPTYPE_HLAI)
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, S(PrePvTemp), S(PostPvEUHi), S(GetPvTempPtr), TRUE,   // 96 PvTemp
#else
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, S(PrePvTemp), 0, S(GetPvTempPtr), TRUE,            // 96 PvTemp
#endif
    DT_FLOAT32, 4, AT_MBYTE, ALCK_OPER, CONTROLSTATE_NONE, S(PrePvTv), S(PostPvTv), S(GetPvTvPtr), TRUE,         // 97 PvTv
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvTvPPtr), TRUE,                     // 98 PvTvP
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PreSensrTyp), S(PostSensrTyp), S(GetSensrTypPtr), TRUE,// 99 SensrTyp
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,S(GetSlotSfBtPtr),FALSE},               // 100 SlotSfBt
#if 1//defined(IOPTYPE_HLAI)
    DT_UINT8, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, 0, 0, S(GetSlwSrcIdPtr), TRUE,                 // 101 SLWSRCID
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 101
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 102
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_NONE, S(PreTf), S(PostTf), S(GetTfPtr), TRUE,               // 103 Tf
#if 1//defined(IOPTYPE_HLAI)
    DT_BLIND, 72, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, S(PreCheckPoint), 0, S(GetPmCheckPointPtr), TRUE,    // 104 CHKPNT
    DT_BLIND, 6, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvRecPtr), TRUE,                        // 105 PVREC
    DT_BLIND, 5, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvStRecPtr), TRUE,                        // 106 PVSTREC // added due to customer issue (SR 1-27797231845/ SF 00611701 / BW-40405, and SR 1-27868328215/ SF 00616362 / BW-40433 / FAR 1-CTDY638)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_EPB, CONTROLSTATE_NONE, S(PrePvAlDbEu), 0, S(GetPvAlDbEuPtr), TRUE,         // 107 PVALDBEU
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 104
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 105
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 106
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 107
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 108
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 109
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 110
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 111
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 112
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 113
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 114
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 115
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 116
#if 1//defined(IOPTYPE_HLAI)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvEuHiRvPtr), FALSE,                 // 117 PVEUHIRV
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetPvEuLoRvPtr), FALSE,                 // 118 PVEULORV
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetFiltOutPtr), FALSE,                  // 119 FILTOUT
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetDbChkFlgPtr), FALSE,                    // 120 DBCHK_FLG
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetAlarmLrsPtr), FALSE,                   // 121 ALARMLRS
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetSlotSfLrsPtr), FALSE,                  // 122 SLOT_SF_LRS
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetADRawHiPtr), FALSE,                  // 123 ADRAWHI
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetADRawLoPtr), FALSE,                  // 124 ADRAWLO
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 117
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 118
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 119
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 120
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 121
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 122
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 123
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 124
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 125
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 126
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 127
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 128
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 129
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 130
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 131
#if 1//defined(HART_SUPPORT)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetLrvPtr), FALSE,                      // 132 Lrv
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetUrvPtr), FALSE,                      // 133 Urv
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetLrlPtr), FALSE,                      // 134 Lrl
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetUrlPtr), FALSE,                      // 135 Url
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 136
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 137
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetDampingPtr), FALSE,                  // 138 Damping
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetStiEuPtr), FALSE,                       // 139 StiEu
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 140
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetStatePtr), FALSE,                       // 141 STATE
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 142
    DT_BOOL, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_NONE, S(PreOwdEnable), 0, S(GetOwdEnablePtr), TRUE,          // 143 OwdEnable
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 144
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, S(PreCommand), S(PostCommand), S(GetCommandPtr), FALSE,  // 145 Command
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 132
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 133
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 134
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 135
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 136
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 137
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 138
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 139
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 140
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 141
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 142
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 143
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 144
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 145
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 146
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 147
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 148
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 149
#if 1//defined(IOPTYPE_HLAI)
    DT_BLIND, 77, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, S(PreCheckPoint), 0, S(GetCheckPointPtr), TRUE,      // 150 Checkpoint
#else
    DT_BLIND, 123, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, S(PreCheckPoint), 0, S(GetCheckPointPtr), TRUE,     // 150 Checkpoint
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 151
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 152
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 153
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 154
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 155
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 156
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 157
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 158
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 159
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 160
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 161
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 162
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 163
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 164
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 165
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 166
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 167
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 168
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 169
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 170
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 171
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 172
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 173
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 174
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 175
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 176
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 177
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 178
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 179
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 180
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 181
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHLongTagPtr), FALSE,                  // 182 HLongTag
    DT_BLIND, 5, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetH7Cmd0Ptr), FALSE,                     // 183 H7Cmd0
    DT_UINT16, 2, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, S(PreHDvMfgCd7), 0, S(GetHDvMfgCd7Ptr), TRUE,        // 184 HDvMfgCd7
    DT_UINT16, 2, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, S(PreHDvTypCd7), 0, S(GetHDvTypCd7Ptr), TRUE,        // 185 HDvTypCd7
#if defined(HART_SUPPORT)
	DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHSlot0TSPtr), FALSE,                   // 186 HSlot0TS
#else
	DT_UINT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHSlot0TSPtr), FALSE,                  // 186 HSlot0TS
#endif
    DT_BLIND, 7, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDevCdPtr), FALSE,                      // 187 HDevCd
    DT_BLIND, 16, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDvRngExtPtr), FALSE,                  // 188 HDvRngExt
    DT_BLIND, 16, AT_PSET, ALCK_ENGR, CONTROLSTATE_INACTIVE, S(PreHEuRngExt), 0, S(GetHEuRngExtPtr), TRUE,    // 189 HEuRngExt
    DT_BOOL, 1, AT_SBYTE, ALCK_OPER, CONTROLSTATE_NONE, S(PreHAlarmEnable), S(PostHAlarmEnable), S(GetHAlarmEnablePtr), TRUE, // 190 HAlarmEnable
    DT_BOOL, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PreHEnable), S(PostHEnable), S(GetHEnablePtr), TRUE,// 191 HEnable
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, S(PreHScanCfg), S(PostHScanCfg), S(GetHScanCfgPtr), TRUE, // 192 HScanCfg
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDynRatePtr), FALSE,                   // 193 HDynRate
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDevRatePtr), FALSE,                   // 194 HDevRate
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, 0, 0, S(GetHSlotDvcPtr), TRUE,                      // 195 HSlotDvc7[8]
    DT_UINT16, 2, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_NONE, S(PreHComThrs), 0, S(GetHComThrsPtr), TRUE,         // 196 HComThrs
    DT_UINT16, 2, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_NONE, S(PreHComHys), 0, S(GetHComHysPtr), TRUE,           // 197 HComHys
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHComStsPtr), FALSE,                     // 198 HComSts
    DT_UINT16, 2, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHNComErrPtr), FALSE,                  // 199 HNComErr
    EMPTY,                                                                                       // 200
    EMPTY,                                                                                       // 201
    EMPTY,                                                                                       // 202
    EMPTY,                                                                                       // 203
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHLComFailPtr), FALSE,                   // 204 HLComFail
    DT_BLIND, 17, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd0Ptr), FALSE,                     // 205 HCmd0
    DT_BLIND, 24, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd12Ptr), FALSE,                    // 206 HCmd12
    DT_BLIND, 21, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd13Ptr), FALSE,                    // 207 HCmd13
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd14Ptr), FALSE,                    // 208 HCmd14
    DT_BLIND, 18, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd15Ptr), FALSE,                    // 209 HCmd15
    DT_BLIND, 3, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd16Ptr), FALSE,                     // 210 HCmd16
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDynValPtr), FALSE,                  // 211 HDynVal[4]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDynStPtr), FALSE,                      // 212 HDynSt[4]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDynCcPtr), FALSE,                      // 213 HDynCc[4]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDynEuPtr), FALSE,                      // 214 HDynEu[4]
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHSlotValPtr), FALSE,                 // 215 HSlotVal[8]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHSlotStPtr), FALSE,                     // 216 HSlotSt[8]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHSlotCcPtr), FALSE,                     // 217 HSlotCc[8]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHSlotEuPtr), FALSE,                     // 218 HSlotEu[8]
    DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDevStPtr), FALSE,                     // 219 HDevSt[4]
    DT_BLIND, 25, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd48Ptr), FALSE,                    // 220 HCmd48
    DT_BOOL, 1, AT_BITPACK, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmd48Ptr), FALSE,                    // 221 HCmd48BT
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmdFailPtr), FALSE,                    // 222 HCmdFail
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHCmdRespPtr), FALSE,                   // 223 HCmdResp
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, S(PreHDvMfgCd), 0, S(GetHDvMfgCdPtr), TRUE,            // 224 HDvMfgCd
    DT_BLIND, 3, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, 0, S(PostHDevIdCd), S(GetHDevIdCdPtr), TRUE,          // 225 HDevIdCd
    DT_UINT8, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, S(PreHDvTypCd), 0, S(GetHDvTypCdPtr), TRUE,           // 226 HDvTypCd
    DT_UINT8, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, S(PreHDvRevCd), 0, S(GetHDvRevCdPtr), TRUE,           // 227 HDvRevCd
    DT_UINT8, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, S(PreHDdRevCd), 0, S(GetHDdRevCdPtr), TRUE,           // 228 HDdRevCd
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 229
    DT_BLIND, 50, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, 0, 0, S(GetHNtfyCfgPtr), TRUE,                    // 230 HNtfyCfg
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 231
    DT_UINT8, 1, AT_SBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                               // 232 HBrdp
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHDynDvcPtr), FALSE,                     // 233 HDynDvc
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetHartVersionPtr), FALSE,                 // 234 HartVersion
    EMPTY,                                                                                       // 235
    EMPTY,                                                                                       // 236
    EMPTY,                                                                                       // 237
    EMPTY,                                                                                       // 238
    EMPTY,                                                                                       // 239
    EMPTY,                                                                                       // 240
    EMPTY,                                                                                       // 241
    EMPTY,                                                                                       // 242
    EMPTY,                                                                                       // 243
    EMPTY,                                                                                       // 244
#if 1//defined(IOPTYPE_HLAI)
    // New parameter created which was not existing in PMIO, using to match Legacy Dump Data.
    DT_ENUM, 1, AT_SBYTE, ALCK_SUPR, CONTROLSTATE_NONE, 0, 0, S(GetPtExecStLrsPtr), FALSE,                 // 245  PTEXECST_LRS
#else
    DT_UINT8, 1, AT_SBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, S(GetSlotChkpntVersionPtr), TRUE,          // 245 SlotChekpointVerNum
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 246
#if 1//defined(IOPTYPE_HLAI)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetEUSpanPtr), FALSE,                   // 247 EU_SPAN
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetKfPtr), FALSE,                       // 248 KF
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, S(GetRawSpanPtr), FALSE,                  // 249 RAW_SPAN
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 247
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 248
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 249
#endif
	EMPTY,                                                                                       // 250
    EMPTY,                                                                                       // 251
    EMPTY,                                                                                       // 252
    EMPTY,                                                                                       // 253
    EMPTY,                                                                                       // 254
    EMPTY                                                                                        // 255
};

#undef EMPTY
#undef P

/*******************************************************************************
*                           clsAihSlot::operator new                           *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS: a_ucSltNm = 0-relative slot number                                *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
//VOID *clsAihSlot::operator new(UINT32, UINT8 a_ucSltNm) {
//   return (ucIomDbMemory + AIHBOXSLOT_SIZE + (a_ucSltNm * AIHSLOT_SIZE));
//}

/*******************************************************************************
*                            clsAihSlot::clsAihSlot                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsAihSlot::clsAihSlot(UINT8 a_ucSltNm) : clsAixSlot(a_ucSltNm), HartDevDb(a_ucSltNm,&HartCfgDb,&HartCfgDb7) {
//clsAihSlot::clsAihSlot(UINT8 a_ucSltNm) : clsAixSlot(a_ucSltNm) {

    InitAihSlot(TRUE, TRUE);

    for (UINT8 ucCount = 0; ucCount < AIHSLOT_SPARESIZE; ucCount++) {

        AihSlotSpare[ucCount] = 0;
    }

    //BOX->SetHADCStatus(ChanNum, HART_DATA_PENDING);
}

/*******************************************************************************
*                           clsAihSlot::InitAihSlot                            *
*                           =======================                            *
* PURPOSE: InitAihSlot function which initializes clsAohSlot class members.    *
* ARGUMENTS:                                                                   *
*            bFullInit   - Flag utilised when slots have to be reinitialised   *
*            bObjCreate  - Flag utilised when slots have to be reinitialised   *
* RETURN:    NONE                                                              *
* NOTES:   This function is called when slot parameters                        *
*          need to be reinitialised                                            *
*******************************************************************************/
VOID clsAihSlot::InitAihSlot(BOOL, BOOL) {

    InptDir  = INPTDIR_DIRECT;
    PvChar   = PVCHAR_LINEAR;
    PvRawHI  = NaN;
    PvRawLO  = NaN;
    PvTemp   = PVTEMP_DEG_C;
    SensrTyp = SENSRTYP_1to5_V;
    ADRawHi  = NaN;
    ADRawLo  = NaN;
    HundredDivRawSpan = NaN;
    InputBelowDeadband = FALSE;
    OpenWireTestCount = 0;
    OpenWirePvFallCount = 0;
    PntType = PNTTYPE_ANALOGINPUT;
    PvEuHiRv = NaN;
    PvEuLoRv = NaN;
	DbChkFlg = OFF;
}
/*******************************************************************************
*                            clsAihSlot::GetDataType                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsAihSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsAihSlot::GetAccessType                           *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsAihSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                            clsAihSlot::GetParamSize                          *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAihSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                            clsAihSlot::GetParamPtr                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsAihSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                           clsAihSlot::GetAccessLock                          *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsAihSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                       clsAihSlot::GetIsDbChecksumed                          *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                         clsAihSlot::VerifyControlState                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::VerifyControlState(UINT8 a_ucParamNumber) {

    UINT8 ModuleState = BOX->GetModuleStatus();

    switch (tblParamInfo[a_ucParamNumber].ControlState) {

    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {

            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && (MODSTATUS_IDLE != ModuleState)) {

            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || (MODSTATUS_RUN != ModuleState)) {

            return DO_STATE_MUST_BE_RUN;
        }
        break;
    default:
    	break;
    }

    return PA_OK;
}
/*******************************************************************************
*                         clsAihSlot::ExecutePreFunction                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::ExecutePreFunction(UINT8 a_ucParamNumber,UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {

    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {

        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))(a_Buffer,a_ucAccessLevel);
    }

    return PA_OK;
}
/*******************************************************************************
*                         clsAihSlot::ExecutePostFunction                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::ExecutePostFunction(UINT8 a_ucParamNumber,UINT8 a_ucAccessLevel) {

    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {

        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                           clsAihSlot::InitSlotDatabase                       *
*                           ============================                       *
*  Initialize the entire channel database. Calls the Init function for each    *
*  class in the channel object hierarchy and recompute database checksum.      *
*******************************************************************************/
VOID clsAihSlot::InitSlotDatabase(BOOL bFullInit) {
    BOOL bObjCreate = FALSE;

#if 0
    if (TRUE == bFullInit) {
        // If this is a active 1-second HART channel, decrement the static
        // 1-second channel counter as InitIoSlot will be inactivating the
        // channel without calling PostPtExecSt(). This step is required to
        // cover the scenario where the C300 and IOM database got out-of-sync.
        // Two examples are:
        // IOMSTATE is IDLE, there is a one 1-second channel in ACTIVE state.
        // 1) IOL communication is lost and then channel configurtion is force
        //    deleted from C300. Subsequently IOL communication is restord and
        //    channel is reloaded.
        // 2) C300 is rebooted in NODB state (after a ntsetup or failure) and
        //    channel configuration is reloaded.
        if ((TRUE == HartCfgDb.HEnable) &&
            (PTEXECST_ACTIVE == PtExecSt) &&
            ((HSCANCFG_1SECDEV == HartCfgDb.HScanCfg) ||
             (HSCANCFG_1SECDYN == HartCfgDb.HScanCfg) ||
             (HSCANCFG_2SECDEVDYN == HartCfgDb.HScanCfg))) {
            clsHartDevDb::Decrement1SecChannels();
        }
    }
#endif

    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitInSlot(bFullInit, bObjCreate);
    InitAixSlot(bFullInit, bObjCreate);
    InitAihSlot(bFullInit, bObjCreate);
    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                          clsAihSlot::PreInptDir                              *
*                          ======================                              *
* PURPOSE:  Pre Receiver-Beware function for InptDir parameter.                *
*           This method checks for range of the data, access level, and valid  *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PreInptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    INPTDIR NewVal = *(INPTDIR *) a_Writebuffer;

    if ((a_ucAccLvl != ALVL_IUSER) || (NewVal != InptDir))
        if ((PvChar != PVCHAR_LINEAR) && (PvChar != PVCHAR_SQRROOT) &&
            (PvChar != PVCHAR_DEVRANGE) && (PvChar != PVCHAR_SYSRANGE) &&
            (PvChar != PVCHAR_SYSRSQRT)) {
            return DO_PARAMETER_INVALID;
        }

    return PA_OK;
}

/*******************************************************************************
*                            clsAihSlot::PrePntType                            *
*                            ======================                            *
* PURPOSE:  Pre Receiver-Beware function for PntType parameter.                *
*           This method checks for range of the data that can be written to    *
*           PntType parameter, access level check, module status check, point  *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    ScratchPad = PntType; // Save old point type for post function.
    UINT8 MdSts = BOX->GetModuleStatus();

    if (TRUE == BOX->GetCalibAllState()) {
        return DO_CALIB_IN_PROGRESS;
    }

    if ((a_ucAccLvl == ALVL_IUSER) && (MdSts != MODSTATUS_IDLE)) {
        return DO_STATE_MUST_BE_IDLE;
    }

    if ((MdSts != MODSTATUS_IDLE) && (PtExecSt != PTEXECST_INACTIVE)) {
        return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
    }

    if ((*(PNTTYPE *)a_Writebuffer != PNTTYPE_ANALOGINPUT) &&
        (*(PNTTYPE *)a_Writebuffer != PNTTYPE_NOTCONFIGURED)) {
        return DO_ILLEGAL_VALUE;
    }
#if 1//defined(IOPTYPE_HLAI)
    // this is because, when Legacy as PRI & redesign as SEC, SEC module is not showing PVRAW, PVCAL, ..
    // due to its Checkpoint data overwriting with sync data hence some calculations like, ESPAN/100, etc.
    // this is due to default (or unconfigured point) is NOT CONFIGURED rather than, ANALOGINPUT.
    else //if (PNTTYPE_NOTCONFIGURED == *(PNTTYPE *)a_Writebuffer)
    {
        *(PNTTYPE *)a_Writebuffer = PNTTYPE_ANALOGINPUT;
    }
#endif

    return PA_OK;
}

/*******************************************************************************
*                            clsAihSlot::PostPntForm                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PntForm parameter.               *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostPntForm(UINT8)
{
    if (PNTFORM_COMPONENT == PntForm)
    {
        PvSrcOpt = PVSRCOPT_ONLYAUTO;
        PvSource = PVSOURCE_AUTO;
        InactivateSlot(); //Warm Slot Init to clear PV
    }
}
/*******************************************************************************
*                            clsAihSlot::PostPntType                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
*           (1) Checks for valid range and access level.                       *
*           (2) Calls Point-Build initialization.                              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostPntType(UINT8 a_ucAccLvl) {

    if ((PNTTYPE_NOTCONFIGURED == PntType) || (PvSource != PVSOURCE_MANUAL) || (ALVL_IUSER == a_ucAccLvl)) {

        InitSlotDatabase(TRUE);
    }
    else {
        // Call Point-Build initialization.
        InitSlotDatabase(FALSE);
    }

    if (PNTTYPE_NOTCONFIGURED == PntType) {
        // In case of UIO the Delete will remove the AihSlot class entirely and all HART functions will cease.
        // The AbortHartConnection call is sufficient for cleaning up residual queued messages.

        // if channel got deleted, initialize HART database
        /*BOX->ResetHADCEnable(ChanNum);
        BOX->SetHADCStatus(ChanNum, HART_DATA_PENDING);
        BOX->SetAdcCycleCount(ChanNum,1);
        AbortHartConnection(ChanNum);
        HartDevDb.InitDevDb(TRUE);
        HartCfgDb.InitCfgDb();
        HartCfgDb7.InitCfgDb();
        BOX->InitHGChngFl(ChanNum);*/

#if defined(IOMTYPE_UIO)
        BOX->InitHGCfgChgCnt(ChanNum);
#endif
        //HartDevDb.m_bAtLeastOneTry = FALSE;

        // if IOM is primary, rebuild scan table and
        // schedule next scan after 30 seconds.

        // AF: Channel was deleted.  Why talking HART?? UIO NEEDS TO STOP ALL SCANNING.
        /*UINT8 ucDsa = BOX->GetDSA();
        if ((ucDsa > 0) && (ucDsa <= MAXDSA)) {
			SensrTyp = SENSRTYP_1to5_V;
			PostSensrTyp(ALVL_PBD);
			BOX->SetHADCStatus(ChanNum, HART_DATA_PENDING);
			HartDevDb.BuildScanTable();
			HartDevDb.m_sScanCounter = TICKS_IN_1_SEC;
        }*/

    }
}
/*******************************************************************************
*                          clsAihSlot::PreContCut                              *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for ContCut parameter.               *
*            Validates some pre conditions before the new ContCut value can    *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PreContCut(UINT8 *, UINT8)
{
    if (PNTFORM_FULL != PntForm)
        return DO_PARAMETER_INVALID;

    return PA_OK;
}

/*******************************************************************************
*                            clsAihSlot::PostTf                                *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvTf parameter.                  *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Parameter Access level                         *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostTf(UINT8) {

// PPX period is defined in units of milli seconds. Convert to seconds.
#if defined (IOMTYPE_UIO)
    FLOAT32 Ts = (FLOAT32)AI_PROCESS_SLOT_PERIOD / (FLOAT32)MILLISECONDS_IN_SECOND;
#else
    FLOAT32 Ts = (FLOAT32)AIHPPX_PERIOD / (FLOAT32)MILLISECONDS_IN_SECOND;
#if 1//defined(IOPTYPE_HLAI)
	// fix for the PAR # 1-DVUK26N (Channel takes more time than define Filter Lag time for PVRAW=PV)
	Ts = Ts * (FLOAT32)5;
#endif
#endif

    Kf = Ts / (Ts + (Tf * (FLOAT32)SECONDS_IN_MINUTE));

#if defined(HART_SUPPORT)
	if (TRUE == HartCfgDb.HEnable) {

		SlotCfgd = TRUE;
	}
#endif
}


/*******************************************************************************
*                            clsAihSlot::PrePtExecSt                           *
*                            =======================                           *
* PURPOSE:   Pre Receiver-Beware function for PtExecSt parameter.              *
*            Validates some pre conditions before the new PtExecSt parameter   *
*            can be written to database.                                       *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PrePtExecSt(UINT8 *a_Writebuffer, UINT8) {
    // Check if calibration is enabled.
    if (TRUE == BOX->GetCalibAllState()) {
        return DO_CALIB_IN_PROGRESS;
    }

    ScratchPad = PtExecSt; // Save current execution state for post function.

    if (*(PTEXECST *)a_Writebuffer == PTEXECST_ACTIVE) {
        if ((isnan(PvExEUHi)) || (isnan(PvExEULo)) ||
            (isnan(PvEUHi)) || (isnan(PvEULo)))
            return DO_CONFIGURATION_MISMATCH_ERROR;
#if 1//defined(IOPTYPE_HLAI)
        else if (((SENSRTYP_SLIDWIRE == SensrTyp)
                ||(SENSRTYP_0to100_MV == SensrTyp))
                &&(isnan(PvRawHI)||isnan(PvRawLO)))
            return DO_CONFIGURATION_MISMATCH_ERROR;
#endif
    }

    //if ((*(PTEXECST *)a_Writebuffer == PTEXECST_ACTIVE) && (BOX->GetHADCEnable(ChanNum)))
    //return DO_PRIOR_FUNCTION_NOT_COMPLETE;

    // For HART enabled channels, make sure that only two channels with
    // dedicated modems will be activated at a time. This change was brought
    // in while adding HART modem diagnostic for fixing the PAR 1-2EDL2L.
    //
    // NOTE: UIO does not support 1-second channels
/*#if !defined(IOMTYPE_UIO)
    if ((TRUE == HartCfgDb.HEnable) &&
        ((HSCANCFG_1SECDEV == HartCfgDb.HScanCfg) ||
         (HSCANCFG_1SECDYN == HartCfgDb.HScanCfg) ||
         (HSCANCFG_2SECDEVDYN == HartCfgDb.HScanCfg))) {
        if ((PTEXECST_INACTIVE == PtExecSt) &&
            (PTEXECST_ACTIVE == *(PTEXECST *)a_Writebuffer)) {
            // channel is getting activated
            if (clsHartDevDb::GetNoOf1SecChannels() >= MAX_1SEC_CHANNELS) {
                return DO_MAX_CONNECTIONS_EXCEEDED;
            }
            clsHartDevDb::Increment1SecChannels();
        }
        else if ((PTEXECST_ACTIVE == PtExecSt) &&
                 (PTEXECST_INACTIVE == *(PTEXECST *)a_Writebuffer)) {
            // channel is getting inactivated
            clsHartDevDb::Decrement1SecChannels();
        }
    }*/
//#endif
    return PA_OK;
}
/*******************************************************************************
*                          clsAihSlot::CreatePtExecStEvt                       *
*                          =============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS: a_EventType - Normal / Recovery                                   *
* RETURN:                                                                      *
* NOTES:     added to resolve, PAR# 1-7GYPETL                                  *
*******************************************************************************/
VOID clsAihSlot::CreatePtExecStEvt(EVENTTYPE a_EventType) {
    EVENTRECORD PtExecStEvent;

    PtExecStEvent.Overflow = FALSE;
    PtExecStEvent.ContactCutout = FALSE;
    PtExecStEvent.Qualifier = a_EventType;
    PtExecStEvent.CurrentState = EVENTSTATE_RETURN;
    PtExecStEvent.EventPacket = EVENTPACKET_SYSTEM;
    PtExecStEvent.SystemEvent.SoftfailStatus = FALSE;
    PtExecStEvent.SystemEvent.ChannelNumber = ChanNum;

    //IF CURRENT PTEXECST = ON
    if (PTEXECST_ACTIVE == PtExecSt)
    {
        PtExecStLrs |= PTEXECST_ON_LRSBIT;

        if (PtExecStLrs & PTEXECST_OFF_LRSBIT)
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_OFF_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_OFF_LRSBIT;
            }
        }
        else
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_ON_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_ON_LRSBIT;
            }
        }
    }
    else //(PTEXECST_INACTIVE == PtExecSt)
    {
        PtExecStLrs |= PTEXECST_OFF_LRSBIT;

        if (PtExecStLrs & PTEXECST_ON_LRSBIT)
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_ON_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_ON_LRSBIT;
            }
        }
        else
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_OFF_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_OFF_LRSBIT;
            }
        }
    }
}


/*******************************************************************************
*                          clsAihSlot::PreOwdEnable                            *
*                          ========================                            *
* PURPOSE:   Pre Receiver-Beware function for SensrTyp parameter.              *
*            Validates some pre conditions before the new OwdEnable value can  *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the OwdEnable parameter        *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PreOwdEnable(UINT8 *a_Writebuffer, UINT8) {
#if !LOWCOST
    if (((SensrTyp == SENSRTYP_0to5_V) || (SensrTyp == SENSRTYP_P4TO2_V))
#else
    if (TRUE    // LOWCOST should not be set OwdEnable.
#endif
        && (TRUE == *(BOOL *)a_Writebuffer)) {
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    return PA_OK;
}

/*******************************************************************************
*                            clsAihSlot::PostPtExecSt                          *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostPtExecSt(UINT8) {
    if (PtExecSt == PTEXECST_INACTIVE) {
        InactivateSlot();
    }

    if ((PTEXECST)ScratchPad != PtExecSt) { // point execution state changed
        HartDevDb.ControlStateChange();
#if 1//defined(IOPTYPE_HLAI)
        // modified to resolve, PAR# 1-7GYPETL
        if(PNTFORM_FULL == PntForm)
        {
            CreatePtExecStEvt(EVENTTYPE_NORMAL);
        }
#endif
        // Need to CREATE_PTEXECST_EVT
    }
}


/*******************************************************************************
*                          clsAihSlot::PreSensrTyp                             *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for SensrTyp parameter.              *
*            Validates some pre conditions before the new PvTemp value can     *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PreSensrTyp(UINT8 *a_Writebuffer, UINT8) {
    // Check if calibration is enabled.
    if (BOX->GetCalibAllState()) {
        return DO_CALIB_IN_PROGRESS;
    }

    SENSRTYP NewVal = *(SENSRTYP *) a_Writebuffer;

#if !LOWCOST
    if ((NewVal != SENSRTYP_1to5_V) &&
#if 1//defined(IOPTYPE_HLAI)
        // for PMIO Redesign HLAI
        (NewVal != SENSRTYP_SLIDWIRE)  &&
#endif
        (NewVal != SENSRTYP_0to5_V) && (NewVal != SENSRTYP_P4TO2_V)) {
        return DO_ILLEGAL_VALUE;
    }
#elif defined(IOMTYPE_UIO)
    if ((NewVal != SENSRTYP_1to5_V) && (NewVal != SENSRTYP_0to5_V)) {
        return DO_ILLEGAL_VALUE;
    }
#else
    // For Low Cost, SENSRTYP_1to5_V is only applicable.
    if ( NewVal != SENSRTYP_1to5_V )
        return DO_ILLEGAL_VALUE;
#endif
    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostSensrTyp                          *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for SensrTyp parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostSensrTyp(UINT8) {
    PvChar = PVCHAR_LINEAR;

#if defined (IOMTYPE_UIO)
    ADRawHi = (FLOAT32)FPGA.MilliampsToAdcCount(20.0);  // 100% = 20 mA = 52428 ADC counts

    if (SensrTyp == SENSRTYP_1to5_V) {
        ADRawLo = (FLOAT32)FPGA.MilliampsToAdcCount(4.0); // 0% = 4mA = 10485 ADC counts
    }
    else {
        ADRawLo = (FLOAT32)FPGA.MilliampsToAdcCount(0.0); // 0% = 0mA = 0 ADC counts
        OwdEnable = FALSE;
    }

#elif (!LOWCOST)
    if (SensrTyp == SENSRTYP_P4TO2_V) {
        ADRawLo = (FLOAT32) 0.4;
        ADRawHi = (FLOAT32) 2.0;
    }
    else {
        if (SensrTyp == SENSRTYP_1to5_V)
            ADRawLo = (FLOAT32) 1.0;
        else
            ADRawLo = (FLOAT32) 0.0;

        ADRawHi = (FLOAT32) 5.0;
    }

    if ((SensrTyp == SENSRTYP_0to5_V) || (SensrTyp == SENSRTYP_P4TO2_V)) {
        OwdEnable = FALSE;
    }

#if 1//defined(IOPTYPE_HLAI)
    // Default PvChar for TC & RTD
    if (SensrTyp == SENSRTYP_THERMCPL)
        PvChar = PVCHAR_JTHERM;
    else if(SensrTyp == SENSRTYP_RTD)
        PvChar = PVCHAR_DINRTD;
#endif

#else // LOWCOST. Always 4-20 mA, 200 Ohm
    ADRawLo = (FLOAT32) 0.8;  // 0%
    ADRawHi = (FLOAT32) 4.0;  // 100%
    OwdEnable = FALSE;
#endif

    HundredDivRawSpan = (FLOAT32)100.0 / (ADRawHi - ADRawLo);
}

/*******************************************************************************
*                            clsAixSlot::PrePv                                 *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for PV parameter.                     *
*           This method checks for range of the data that can be written to    *
*           PV parameter, access level check, module status check, point       *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    // Get IOM state.
    UINT8 MdSts = BOX->GetModuleStatus();

    // Get new value of PV in a local variable.
    FLOAT32 ufNewVal = *(FLOAT32 *)a_Writebuffer;

    if (PvSrcOpt == PVSRCOPT_ONLYAUTO)
        return DO_READ_ONLY_PARAMETER;

    if (PvSource == PVSOURCE_AUTO)
        return DO_PVSOURCE_INVALID;

    //Access lock = engr OR supr OR oper OR pbd
    if ((PvSource == PVSOURCE_SUB) && (a_ucAccLvl & ALCK_ONPROC_PBD))
        return DO_PVSOURCE_INVALID;

    //Access lock = prog OR cc OR umcc OR iuser
    if ((PvSource == PVSOURCE_MANUAL) && (a_ucAccLvl & ALCK_PROG_UMCC_CC_IUSER))
        return DO_PVSOURCE_INVALID;

    if (isnan(ufNewVal)) return PA_OK;

    if (PvSource == PVSOURCE_MANUAL) {
        if (ufNewVal > PvExEUHi)
            return DO_LIMIT_OR_RANGE_EXCEEDED;
        if (ufNewVal < PvExEULo)
            return DO_LIMIT_OR_RANGE_EXCEEDED;
        return PA_OK;
    }
    else if (PvSource == PVSOURCE_SUB) {
        if (MdSts == MODSTATUS_IDLE)
            return DO_STATE_MUST_BE_RUN;

        if (PtExecSt == PTEXECST_INACTIVE)
            return DO_PTEXECST_OR_MODLSTAT_INCONSISTENT;

        if (ufNewVal > PvExEUHi) {
            ufNewVal = PvExEUHi;
            *(FLOAT32*) a_Writebuffer = ufNewVal;
            return DO_VALUE_CLAMPED_ERROR;
        }
        if (ufNewVal < PvExEULo) {
            ufNewVal = PvExEULo;
            *(FLOAT32*) a_Writebuffer = ufNewVal;
            return DO_VALUE_CLAMPED_ERROR;
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAixSlot::PostPv                                 *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for PV parameter.                    *
*           (1) Sets the PV Extended Range flags if PV exceeds the extended    *
*               range values.                                                  *
*           (2) Updates PvSts, EU Span, and PVP.                               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPv(UINT8) {
    FLOAT32 fCurPv = BOX->GetPv(ChanNum);

    if (isnan(fCurPv)) {
        PvP = NaN;
        BOX->SetPvSts(ChanNum,PVVALST_BAD);
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
    }
    else {
        if (fCurPv == PvExEULo)
            PvExLoFl = TRUE;
        else
            PvExLoFl = FALSE;

        if (fCurPv == PvExEUHi)
            PvExHiFl = TRUE;
        else
            PvExHiFl = FALSE;

        if (PVSOURCE_MANUAL == PvSource) {
#if 1 //defined(IOPTYPE_HLAI)
            BOX->SetPv(ChanNum, fCurPv);
#endif
            BOX->SetPvSts(ChanNum,PVVALST_MANUAL);
        }
        else {
            BOX->SetPvSts(ChanNum,PVVALST_UNCERTN);
        }

        // Update EUSpan and PvP.
        if (isnan(PvEUHi) || isnan(PvEULo)) {
            EUSpan = NaN;
            EUSpanDivHundred = NaN;
            HundredDivEUSpan = NaN;
            PvP = NaN;
        }
        else {
            EUSpan = PvEUHi - PvEULo;
            EUSpanDivHundred = EUSpan / (FLOAT32)100.0;
            HundredDivEUSpan = (FLOAT32)100.0 / EUSpan;
            PvP = (fCurPv - PvEULo) * HundredDivEUSpan;
        }
    }
}


/*******************************************************************************
*                            clsAihSlot::PostPvSrcOpt                          *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvSrcOpt parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostPvSrcOpt(UINT8) {
    UINT8 ucModSts = BOX->GetModuleStatus();

    if (PvSrcOpt == PVSRCOPT_ONLYAUTO) {
        PvSource = PVSOURCE_AUTO;
        if ((PtExecSt == PTEXECST_INACTIVE) || (ucModSts == MODSTATUS_IDLE)) {
            BOX->SetPv(ChanNum,NaN);
            BOX->SetPvSts(ChanNum,PVVALST_BAD);
            PvP       = NaN;
            PvExHiFl  = FALSE;
            PvExLoFl  = FALSE;
#if 1 //defined(IOPTYPE_HLAI)
            AlmVar.fPv4secOld = NaN;
#endif
        }
    }
}
/*******************************************************************************
*                          clsAihSlot::preLoCutOff                             *
*                          =======================                             *
* PURPOSE:  Pre Receiver-Beware function for LoCutOff parameter.               *
*           This method checks for a valid data range, access level, and valid *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PreLoCutOff(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    FLOAT32 NewVal = *(FLOAT32*) a_Writebuffer;

    if (!RealCompare(NewVal, LoCutOff)) {
        if ((PvChar != PVCHAR_LINEAR) && (PvChar != PVCHAR_SQRROOT) &&
            (PvChar != PVCHAR_DEVRANGE) && (PvChar != PVCHAR_SYSRANGE) &&
            (PvChar != PVCHAR_SYSRSQRT)) {
            return DO_PARAMETER_INVALID;
        }

        if ( !isnan(NewVal) ) {
            if ((NewVal < (FLOAT32)0.0) && (a_ucAccLvl != ALVL_IUSER))
                return DO_LIMIT_OR_RANGE_EXCEEDED;
            else {
                if ((!isnan(PvEUHi)) && (NewVal > PvEUHi))
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
                if ((!isnan(PvEULo)) && (NewVal < PvEULo))
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
            }
        }
    }
    return PA_OK;
}

/*******************************************************************************
*                            clsAihSlot::PrePvChar                             *
*                            =====================                             *
* PURPOSE:   Pre Receiver-Beware function for PvChar parameter.                *
*            Validates some pre conditions before the new PvChar parameter     *
*            can be written to database.                                       *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PrePvChar(UINT8 *a_Writebuffer, UINT8) {
    // Check if calibration is enabled.
    if (TRUE == BOX->GetCalibAllState()) {
        return DO_CALIB_IN_PROGRESS;
    }

    PVCHAR NewVal = *(PVCHAR *) a_Writebuffer;

#if 1//defined(IOPTYPE_HLAI)
    // for PMIO Redesign HLAI,
    // Block, if other than Linear type for SLIDWIRE sensor type
    if((PVCHAR_LINEAR != NewVal) && (SENSRTYP_SLIDWIRE == SensrTyp))
        return DO_CONFIGURATION_MISMATCH_ERROR;
#else
    // Block, if above SQRROOT PvChar
    if(NewVal > PVCHAR_SQRROOT)
        return DO_ILLEGAL_VALUE;

    //Block any value other than LINEAR and SQRROOT
    if ((NewVal != PVCHAR_LINEAR) && (NewVal != PVCHAR_SQRROOT)) {
        /*if (TRUE == HartCfgDb.HEnable) {
            if ((NewVal >= PVCHAR_DEVRANGE) && (NewVal <= PVCHAR_SYSRSQRT)) {
                return PA_OK;
            }
        }*/
        return DO_ILLEGAL_VALUE;
    }
#endif

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostPvEUHi                             *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for PvEUHi parameter.                *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostPvEUHi(UINT8 a_ucAlvl) {
    // Force result of floating point operation to QNaN, if any of
    // the operands is NaN. Otherwise it will result in SNaN.
    if (isnan(PvEUHi) || isnan(PvEULo)) {
        EUSpan = NaN;
        EUSpanDivHundred = NaN;
        HundredDivEUSpan = NaN;
    }
    else {
        EUSpan = PvEUHi - PvEULo;
        EUSpanDivHundred = EUSpan / (FLOAT32)100.0;
        HundredDivEUSpan = (FLOAT32)100.0 / EUSpan;
#if 1//defined(IOPTYPE_HLAI)

        // Recalculate PvAlDbEu
        if (PVALDB_EU != PvAlDb)
        PostPvAlDb(a_ucAlvl);
        // Recalculate PvTvP
        PostPvTv(a_ucAlvl);
        // Recalculate RawSpan
        PostPvRawHI(a_ucAlvl);

        // for PMIO Redesign HLAI
        if (((PvChar >= PVCHAR_JTHERM) && (PvChar <= PVCHAR_RPTHERM)) ||
            ((PvChar >= PVCHAR_DINRTD) && (PvChar <= PVCHAR_COPPRRTD)))
        {
            PvEuHiRv = ConvTempUnit(EUConversion(GenPolyPtr(PvEUHi)));
            PvEuLoRv = ConvTempUnit(EUConversion(GenPolyPtr(PvEULo)));
        }
#endif
    }

    // Delay the range mismatch check until PostPvExEuHi
    // during point build and checkpoint restore.
    /*if ((TRUE == HartCfgDb.HEnable) &&
        (ALVL_PBD != a_ucAlvl) && (ALVL_IUSER != a_ucAlvl)) {
        HartDevDb.CheckRangeMismatch();
    }*/
}

/*******************************************************************************
*                        clsAihSlot::PrePvExEUHi                               *
*                        ========================                               *
* PURPOSE:  Validate PvExEUHi write.                                           *
*******************************************************************************/
PASTATUS clsAihSlot::PrePvExEUHi(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvExEUHi)) {
        if (isnan(NewVal))
            return DO_ILLEGAL_VALUE;

        if ((!isnan(PvExEULo)) && (NewVal < PvExEULo))
            return DO_LIMIT_OR_RANGE_CROSSOVER;

        if ((!isnan(PvEUHi)) && (NewVal < PvEUHi))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
    }

    return PA_OK;
}

/*******************************************************************************
*                       clsAihSlot::PostPvExEUHi                               *
*                       =========================                               *
* PURPOSE:  Recompute dependent values after PvExEUHi update.                  *
*******************************************************************************/
VOID clsAihSlot::PostPvExEUHi(UINT8 a_ucAlvl) {
    PostPvEUHi(a_ucAlvl);
}

/*******************************************************************************
*                        clsAihSlot::PrePvExEULo                               *
*                        ========================                               *
* PURPOSE:  Validate PvExEULo write.                                           *
*******************************************************************************/
PASTATUS clsAihSlot::PrePvExEULo(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvExEULo)) {
        if (isnan(NewVal))
            return DO_ILLEGAL_VALUE;

        if ((!isnan(PvExEUHi)) && (NewVal > PvExEUHi))
            return DO_LIMIT_OR_RANGE_CROSSOVER;

        if ((!isnan(PvEULo)) && (NewVal > PvEULo))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
    }

    return PA_OK;
}

/*******************************************************************************
*                       clsAihSlot::PostPvExEULo                               *
*                       =========================                               *
* PURPOSE:  Recompute dependent values after PvExEULo update.                  *
*******************************************************************************/
VOID clsAihSlot::PostPvExEULo(UINT8 a_ucAlvl) {
    PostPvEUHi(a_ucAlvl);
}

/*******************************************************************************
*                          clsAihSlot::PrePvRawHI                              *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvRawHI parameter.               *
*            Validates some pre conditions before the new PvRawHI value can    *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
#if 1//defined(IOPTYPE_HLAI)
PASTATUS clsAihSlot::PrePvRawHI(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
#else
PASTATUS clsAihSlot::PrePvRawHI(UINT8 *, UINT8 a_ucAccLvl) {
#endif

#if 1//defined(IOPTYPE_HLAI)
    FLOAT32 NewVal = *(FLOAT32 *)a_Writebuffer;

    if (!RealCompare(NewVal, PvRawHI)) {
        if ((SensrTyp != SENSRTYP_SLIDWIRE)
         && (SensrTyp != SENSRTYP_0to100_MV))
        {
            return DO_READ_ONLY_PARAMETER;
        }
        else if (isnan(NewVal))
            return DO_ILLEGAL_VALUE;

        else if (!isnan(PvRawLO) && (NewVal < PvRawLO))
            return DO_LIMIT_OR_RANGE_CROSSOVER;

        else if (((SensrTyp == SENSRTYP_SLIDWIRE)  && (NewVal > 1.0))
              || ((SensrTyp == SENSRTYP_0to100_MV) && (NewVal > 100)))
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    if ((a_ucAccLvl == ALVL_IUSER)||(a_ucAccLvl == ALVL_PBD))
#else
    if (a_ucAccLvl == ALVL_IUSER)
#endif
        return PA_OK;

    return DO_READ_ONLY_PARAMETER;
}
/*******************************************************************************
*                          clsAihSlot::PrePvRawLO                              *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvRawLO parameter.               *
*            Validates some pre conditions before the new PvRawLO value can    *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
#if 1//defined(IOPTYPE_HLAI)
PASTATUS clsAihSlot::PrePvRawLO(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
#else
PASTATUS clsAihSlot::PrePvRawLO(UINT8 *, UINT8 a_ucAccLvl) {
#endif

#if 1//defined(IOPTYPE_HLAI)
    FLOAT32 NewVal = *(FLOAT32 *)a_Writebuffer;

    if (!RealCompare(NewVal, PvRawLO)) {
        if ((SensrTyp != SENSRTYP_SLIDWIRE)
         && (SensrTyp != SENSRTYP_0to100_MV))
        {
            return DO_READ_ONLY_PARAMETER;
        }
        else if (isnan(NewVal))
            return DO_ILLEGAL_VALUE;

        else if (!isnan(PvRawHI) && (NewVal > PvRawHI))
            return DO_LIMIT_OR_RANGE_CROSSOVER;

        else if (NewVal < 0.0)
            return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    if ((a_ucAccLvl == ALVL_IUSER) || (a_ucAccLvl == ALVL_PBD))
#else
    if (a_ucAccLvl == ALVL_IUSER)
#endif
        return PA_OK;

    return DO_READ_ONLY_PARAMETER;
}
#if 1//defined(IOPTYPE_HLAI)
/*******************************************************************************
*                            clsAihSlot::PostPvRawHI                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvRawHI parameter.               *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::PostPvRawHI(UINT8)
{
    RawSpan = (!isnan(PvRawHI) && !isnan(PvRawLO)) ? (PvRawHI - PvRawLO) : NaN;
}
//postPvRawLO is the same as postPvRawHI

/*******************************************************************************
*                          clsAihSlot::PrePvSrcOpt                             *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvSrcopt parameter.              *
*            Validates some pre conditions before the new PvSrcopt value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PrePvSrcOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {

    PVSRCOPT NewVal = *(PVSRCOPT *)a_Writebuffer;

    if ((a_ucAccLvl != ALVL_IUSER) && (NewVal != PvSrcOpt))
    {
        if (PNTFORM_FULL != PntForm)
            return DO_PARAMETER_INVALID;
    }

    return PA_OK;
}
#endif

/*******************************************************************************
*                          clsAihSlot::InactivateSlot                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::InactivateSlot(VOID) 
{
#if 0
    PvAuto   = NaN;
    PvAutoSt = PVVALST_BAD;
    PvCalc   = NaN;
    PvRaw    = NaN;
    LastPv   = NaN;
    FiltOut  = NaN;
    BadPvFl  = FALSE;

    if (PvSource != PVSOURCE_MANUAL) {
        BOX->SetPv(ChanNum,NaN);
        BOX->SetPvSts(ChanNum,PVVALST_BAD);
        PvP   = NaN;
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
    }

#if 1 //defined(IOPTYPE_HLAI)
    // for PMIO Redesign 
    AlmVar.fPv4secOld = NaN;
    AlmVar.uiTsCounter = 0;
    AlmVar.bPFirstInc = FALSE;
    AlmVar.bNFirstInc = FALSE;
    AlmVar.bPFirstDec = FALSE;
    AlmVar.bNFirstDec = FALSE;

    HighAl = NOALARM;
    PtInAl = OFF;

    AlmInfo.ucByte = 0x00;
    AlarmLrs.ucByte = 0x00;

    BOX->SetPvAlmInfo(ChanNum, AlmInfo.ucByte);    
#endif
#endif
}

/*******************************************************************************
*                           clsAihSlot::ValidateOwdCkt                         *
*                           ==========================                         *
*  This function is called once every 50 msec for each channel and it verifies *
*  whether the open wire detection circuitry is working correctly. Depending   *
*  whether open wire condition is detected or not, the first argument will be  *
*  TRUE or FALSE. Based on this, different tests are performed.                *
*  If open wire is detected:                                                   *
*     1) In the first PPX cycle it is detected, three ADC samples 200 uS apart *
*        are taken to verify that the PV is in fact falling down. This test    *
*        will catch OWD circuit faults to GND or -12V. Since OWD circuit is    *
*        disconnected from channel at the time of this test, and if there was  *
*        a fault to GND or -12V, all 3 samples will be in ascending order (as  *
*        it will be charging back to the channel input level).                 *
*        Note that this is a time consuming test (approximately 700 uS extra)  *
*        but it runs rarely - only in the first cycle after open wire is newly *
*        detected for a channel. Since open wire softfail is throttled for 10  *
*        seconds, additional processing introduced is not a concern.           *
*     2) In addition, the filter output is monitored for next 5 PPX cycles to  *
*        make sure that it falls below OWD threshold within 250 msec.          *
*  If open wire is not detected (which is most usually the case)               *
*     1) A quick ADC sample is taken with zero delay and it is compared with   *
*        the ADC sample obtained at the original conversion time. If there is  *
*        a substantial difference, +18V fault is assumed as the normal filter  *
*        output is not expected to ramp up at that rate.                       *
*  If any of the above test fails, box softfail 26 is issued.                  *
*  NOTE : OWD circuit diagnostic running in SeriesC DI all the time while in   *
*  SeriesC AI it runs only when the module is in RUN state. This was forced by *
*  the following two reasons:                                                  *
*  1) Unlike DI, there is no hardware support for circuit diagnsotics in AI.   *
*  2) AI circuit diagnostics depends on the result of open wire diagnostics in *
*     the first place. Since open wire diagnostics is not running when the     *
*     module is IDLE, the diagnostics will not produce any bad result.         *
*******************************************************************************/
VOID clsAihSlot::ValidateOwdCkt(BOOL a_bOpenWireDetected,FLOAT32 a_fRawData)
{
    const FLOAT32 ZERO_POINT_FIVE_VOLT = 0.5;
    const UINT8   INPUT_RESAMPLED_THRICE = 3;
    const UINT16  ZERO_POINT_FIVE_VOLT_ADCCOUNT = PASS2_ONE_VOLT_HILIMIT/2;
    //UINT16 samples[INPUT_RESAMPLED_THRICE];   // 3 samples for Case #1 Tracelog

    UINT16 uiNewCount,uiLastCount;

    if (BOX->IsOwdCktGood() == TRUE) {
        // Run the tests only if OWD circuit is in good state.

        if (TRUE == a_bOpenWireDetected) {
            // open wire condition is detected for this channel

            if (IsOwdSfBtSet() == FALSE) {
                // Open wire is detected newly in the current PPX cycle.

                // Set OpenWirePvFallCount back to MAXVALUE. This
                // re-arms the PVFALL timer in the case of chattering
                // input so that DIAGCTFL will not be mistriggered.
                OpenWirePvFallCount = OPENWIRE_PVFALL_MAXCOUNT;

                // Make sure that PV is in fact falling down by checking
                // three ADC samples 200 uS apart. This test will catch
                // OWD circuit faults to GND or -12V. Since OWD circuit
                // is disconnected from channel now, if there was a fault
                // to GND or -12V, all 3 samples will be in ascending order.
                uiLastCount = Adc.GetRawData(ChanNum);

                for (UINT8 ucCount = 0; ucCount < INPUT_RESAMPLED_THRICE; ucCount++) {
                    uiNewCount = Adc.GetRawData(ChanNum);
                    //samples[ucCount] = uiNewCount;

                    // Abort the test if ADC sample already below threshold
                    if (uiNewCount < ZERO_POINT_FIVE_VOLT_ADCCOUNT) return;

                    if (uiNewCount > uiLastCount) {
                        uiLastCount = uiNewCount;
                    }
                    else {
                        // Abort test if any successive
                        // samples are not in ascending order.
                        return;
                    }
                }

                // Execution reaches here only if all three samples
                // are in ascending order. Report OWD circuit failure.
              //TraceLog.AddToTrace(TRACEID_GENERIC,bcOwdCktFail,(0x10000000|((UINT32)ChanNum<<16)|samples[0]));
              //TraceLog.AddToTrace(TRACEID_GENERIC,bcOwdCktFail,(((UINT32)samples[1]<<16)|samples[2]));
                //BOX->SetOwdCktBad();
            }
            else { // Open wire was detected in this channel in an earlier cycle.

                // Make sure that PV falls below OWD threshold in 5 PPX cycles.
                if (OpenWirePvFallCount > 0) {
                    OpenWirePvFallCount--;

                    if (isnan(a_fRawData) || (a_fRawData < ZERO_POINT_FIVE_VOLT)) {
                        // Stop the PV fall test since PV has fallen below OWD threshold
                        OpenWirePvFallCount = 0;
                    }
                    else if (0 == OpenWirePvFallCount) {
                        // Five PPX scan cycles (250msec) had been elapsed since
                        // this count was initialized and the input has not fallen
                        // below the zero reference level. This means that there is
                        // a problem with open wire detection circuitry.
                      //TraceLog.AddToTrace(TRACEID_GENERIC,bcOwdCktFail,(0x20000000|((UINT32)ChanNum<<16)|(UINT16)(a_fRawData*1000)));
                        //BOX->SetOwdCktBad();
                    }
                }
            }
        }
        else {   // Open wire was not detected for this channel.
            ResetOpenWirePvFallCount();

            //if ( (IsOwdSfBtSet() == FALSE) &&
            //     (TRUE == OwdEnable) && (PVSOURCE_AUTO == PvSource) &&
            //     (PTEXECST_ACTIVE == PtExecSt) && (MODSTATUS_RUN == BOX->GetModuleStatus()) ) {
                // No open wire softfail is reported and the channel is in
                // the right state for detecting any open wire condition.
                // Verify that there is no +18V fault at OWD circuit.
                // Currently this diagnostic is removed.
            //}
        }
    }

    // Currently this diagnostic is disabled.
    //if (BOX->IsOwdCktGood() != TRUE) {
    //    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,TRUE,0);
    //}
}

// for Thermocouple / RTD input type related routines.
/*******************************************************************************
*                               clsAihSlot::ConvTempUnit                       *
*                               =======================                        *
* PURPOSE:  Convert the temeperature value from degree celsius to the          *
*           unit specified by PvTemp parameter                                 *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the parameter                  *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
FLOAT32 clsAihSlot::ConvTempUnit(FLOAT32 rTemp)
{
    switch (PvTemp)
    {
    case PVTEMP_DEG_C:
        return rTemp;

    case PVTEMP_DEG_F:
        return (FARENHEIT_CONV_OFFSET + (rTemp * FARENHEIT_CONV_NUM / FARENHEIT_CONV_DEN));

    case PVTEMP_DEG_R:
        return (RANKINE_CONV_OFFSET + (rTemp * RANKINE_CONV_NUM / RANKINE_CONV_DEN));

    case PVTEMP_DEG_K:
        return (KELVIN_CONV_OFFSET + rTemp);

    default:
        return NaN;
    }
}

/*******************************************************************************
*                           clsAihSlot::EUConversion                           *
*                           =======================                            *
* PURPOSE:   Forward Polynomial conversion                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
FLOAT32 clsAihSlot::EUConversion(FLOAT32* a_fCoeffOffSet)
{
    FLOAT32 fIntmdtePv = *(a_fCoeffOffSet + 4);

    for (UINT8 ucIndex = 4; ucIndex > 0; ucIndex--)
    {
        fIntmdtePv = fIntmdtePv * PvRaw + *(a_fCoeffOffSet + ucIndex - 1);
    }

    return fIntmdtePv;
}

/*******************************************************************************
*                            clsAihSlot::GenPolyPtr                            *
*                            =====================                             *
* PURPOSE: Generates Polynomial Co-efficient Pointer                           *                                        *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
FLOAT32* clsAihSlot::GenPolyPtr(FLOAT32 fPvRawVal)
{
    FLOAT32 *BpPtr = (FLOAT32 *)BP_POINTER_TAB[PvChar];
    FLOAT32 **PolyPtr;
    // Get the maximum number of breakpoints
    UINT8 ucMaxOffSet = *BpPtr;
    UINT8 ucCoeffOffSet = 0;

    BpPtr++;// Point to the start of break point

    //If PvRaw > Low Limit
    if (fPvRawVal > *BpPtr)
    {
        BOOL LoopCriterion = TRUE;

        do
        {
            BpPtr++;//point to next break point

            if (fPvRawVal < *BpPtr) LoopCriterion = FALSE;
            else
            {
                ++ucCoeffOffSet;

                //if PvRaw is greater than the last (END) break point
                if (ucCoeffOffSet > ucMaxOffSet)
                {
                    // decrement the Co-efficient count by one and exit.
                    --ucCoeffOffSet;

                    LoopCriterion = FALSE;
                }
            }
        } while (TRUE == LoopCriterion);
    }

    // read a pointer to the correct set of polynomial co-efficient set
    // for the current slot characterisation
    PolyPtr = (FLOAT32 **)POLY_COEFF_SET[PvChar];

    // Addup Co-efficient count to polynomial pointer to get the correct pointer
    // to correct set of polynomial values set.
    return *(PolyPtr + ucCoeffOffSet);
}

/*******************************************************************************
*                           clsAihSlot::ProcessSlot                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihSlot::ProcessSlot(FLOAT32 a_fRawData)
{
    FLOAT32 fNewPvRaw, fNewPvCalc, fNewFiltOut, fNewPvAuto;

	static UINT32 ul_FtaMissingTimeout = 0;

#if 1 // testing
	//u1_LastExecState = 0;
	EUSpan = PvEUHi - PvEULo;
#else

	Iol.SetDSA(1); // to make primary
	PvEUHi = 100.0F;
	PvEULo = 0.0F;
	PvExEUHi = 102.9F;
	PvExEULo = -2.9F;
	PtExecSt = PTEXECST_ACTIVE;
	EUSpan = PvEUHi - PvEULo;
	//RawSpan = PvRawHI - PvRawLO;

    // Inject deterministic raw input but keep full ProcessSlot pipeline active.
    static FLOAT32 sPhase = 0.0F;
    if (ChanNum == 1) {
        sPhase += 0.05F;
        if (sPhase >= 1.0F) {
            sPhase = 0.0F;
        }
    }

    a_fRawData = ((FLOAT32)ChanNum * 0.2F) + sPhase;
    if (a_fRawData > 5.0F) {
        a_fRawData -= 5.0F;
    }
#endif

    /*
     * added to fix PAR#1-CGC6AUZ (PID mode shedding when FTA cable removed from primary)
     */
	if (FTA_MISSING == BOX->GetFtaPres()) {

		if(Iol.AmPrimary()) {

			if (ul_FtaMissingTimeout < 100) {
                ul_FtaMissingTimeout++;
                return;
            }
		}
        else { // Secondary FTA is missing, return immediately

            ul_FtaMissingTimeout = 0;
            return;
        }
	}
    else {
        ul_FtaMissingTimeout = 0;
    }

    /*
     * Inhibit slot processing on backup module during db synchronization
     * Man and Sub PVs could otherwise be inappropriately updated from raw data
     */
    if (!Iol.AmPrimary() && REDSTATE_SYNCD != BOX->GetRedState()) { 
        return;
    }

    if (SensrTyp == SENSRTYP_P4TO2_V) {
        ADRawLo = (FLOAT32) 0.4;
        ADRawHi = (FLOAT32) 2.0;
    }
    else {
        if (SensrTyp == SENSRTYP_1to5_V)
            ADRawLo = (FLOAT32) 1.0;
        else
            ADRawLo = (FLOAT32) 0.0;

        ADRawHi = (FLOAT32) 5.0;
    }
    // these values will be updated while checkpoint restore only (in be aware functions)
    // and if module freshly programmed & turned ON as SEC, it will get data dump from PRI 
    // then these values will not get update, so updating here once again.
    EUSpanDivHundred  = EUSpan / (FLOAT32)100.0;
    HundredDivEUSpan  = (FLOAT32)100.0 / EUSpan;
    HundredDivRawSpan = (FLOAT32)100.0 / (ADRawHi - ADRawLo);

    /*
     * Check for NaN raw data
     */
    if (isnan(a_fRawData)) {

        fNewPvRaw = NaN;
    }
    else {        

        fNewPvRaw = (a_fRawData - ADRawLo) * HundredDivRawSpan;
        // Storing Slidewire power source into buffer
        *(FLOAT32 *)BOX->GetSlwSrcValuePtr(ChanNum) = fNewPvRaw;
    }

    /*
     * Pv Characterization
     */ 
    if ((isnan(fNewPvRaw)) || (PTEXECST_INACTIVE == PtExecSt)) {

        fNewPvCalc = NaN;
        // pvraw shouldn't display if point inactive
        if (PTEXECST_INACTIVE == PtExecSt) {

            fNewPvRaw = NaN;
        }
    }
    else { 

        switch(PvChar) {

            case PVCHAR_LINEAR:
            	if (SENSRTYP_SLIDWIRE == SensrTyp) {

                    RawSpan = (PvRawHI - PvRawLO);

                    fNewPvRaw = (fNewPvRaw / *(FLOAT32 *)BOX->GetSlwSrcValuePtr(SlwSrcId));

                    if (INPTDIR_DIRECT == InptDir) {

                        fNewPvCalc = (((fNewPvRaw - PvRawLO) * EUSpan) / RawSpan) + PvEULo;
                    }
                    else {

                        fNewPvCalc = PvEUHi - (((fNewPvRaw - PvRawLO) * EUSpan) / RawSpan);
                    }
                    break;
                }
            case PVCHAR_SYSRANGE:
            case PVCHAR_DEVRANGE:
                if (INPTDIR_DIRECT == InptDir) {

                    fNewPvCalc = (fNewPvRaw * EUSpanDivHundred) + PvEULo;
                }
                else {

                    fNewPvCalc = PvEUHi - (fNewPvRaw * EUSpanDivHundred);
                }
                break;
            
            case PVCHAR_SQRROOT:
            case PVCHAR_SYSRSQRT:
                if (INPTDIR_DIRECT == InptDir) {

                    if (fNewPvRaw >= 0) {

                        fNewPvCalc = (FLOAT32)(sqrt(fNewPvRaw/(FLOAT32)100.0) * EUSpan ) + PvEULo;
                    }
                    else {

                        fNewPvCalc = (FLOAT32)(-sqrt(-(fNewPvRaw)/(FLOAT32)100.0) * EUSpan ) + PvEULo;
                    }
                }
                else {
                    if (fNewPvRaw >= 0) {

                        fNewPvCalc = PvEUHi - (FLOAT32)(sqrt(fNewPvRaw/(FLOAT32)100.0) * EUSpan );
                    }
                    else {

                        fNewPvCalc = PvEUHi + (FLOAT32)(sqrt(-(fNewPvRaw)/(FLOAT32)100.0) * EUSpan );
                    }
                }
                break;
            
            default:
                // for PVCHAR, all thermocouple & RTD types.
                if (((PvChar >= PVCHAR_JTHERM) && (PvChar <= PVCHAR_RPTHERM)) 
                ||  ((PvChar >= PVCHAR_DINRTD) && (PvChar <= PVCHAR_COPPRRTD))) {

                    fNewPvCalc = ConvTempUnit(EUConversion(GenPolyPtr(fNewPvRaw)));
                }
                else {

                    fNewPvCalc = NaN;
                }
                break;
        }
    } //end of characterization

    /*
     * Check for open wire condition (fourth check) and set the OpenWireTestCount accordingly.
     */
    CheckOpenWire();

    /* 
     * Pv range checking and filtering 
     */
    BOOL bHiFlag = FALSE, bLoFlag = FALSE;
    PVVALST NewPvAutoSt = PvAutoSt;

    if (isnan(fNewPvCalc)) {
        
        fNewFiltOut = NaN;
        fNewPvAuto  = NaN;
        NewPvAutoSt = PVVALST_BAD;
    }
    else { // New PvCalc is not NaN

        // Do Pv filtering first.
        fNewFiltOut = NaN;
		if (isnan(FiltOut)) {

            fNewFiltOut = fNewPvCalc;
        }
        else {

            fNewFiltOut = FiltOut + Kf * (fNewPvCalc - FiltOut);
        }

        // Do range check and clamping.
        fNewPvAuto = NaN;
        if (PvClamp) {

            if (fNewFiltOut > PvExEUHi) {

                fNewFiltOut = NaN;
                NewPvAutoSt = PVVALST_UNCERTN;
                fNewPvAuto  = PvExEUHi;
                bHiFlag     = TRUE;
            }
            else {

                if (fNewFiltOut < PvExEULo) {

                    fNewFiltOut = NaN;
                    NewPvAutoSt = PVVALST_UNCERTN;
                    fNewPvAuto  = PvExEULo;
                    bLoFlag     = TRUE;
                }   
                else {

                    NewPvAutoSt = PVVALST_NORMAL;
                    fNewPvAuto  = fNewFiltOut;
                }
            }
        } 
        else { // No clamp configured

			if (fNewPvCalc > PvExEUHi) {

                fNewFiltOut = NaN;
                NewPvAutoSt = PVVALST_BAD;
                fNewPvAuto  = NaN;
                bHiFlag     = TRUE;
            }
            else {

                if (fNewPvCalc < PvExEULo) {

                    fNewFiltOut = NaN;
                    NewPvAutoSt = PVVALST_BAD;
                    fNewPvAuto  = NaN;
                    bLoFlag     = TRUE;
                }
                else {

                    NewPvAutoSt = PVVALST_NORMAL;
                    fNewPvAuto  = fNewFiltOut;
                }
            }
        } //end of range checking and clamping.

        // Apply LoCutOff if configured.
        if ((!isnan(LoCutOff)) && (!isnan(fNewPvAuto)) && (fNewPvAuto < LoCutOff)) {

            fNewPvAuto = PvEULo;
        }
    } //end of range checking and filtering

    /*
     * Check for open wire condition (fifth check) and set the OpenWireTestCount accordingly.
     */
    CheckOpenWire();

    // Open Wire Circuit Diagnostics
    // Note: LOWCOST will never detect Open Wire. See CheckOpenWire().
    //       Hence, Open Wire Circuit failure will not be detected neither. See ValidateOwdCkt(FALSE,).
    //       Besides, OWD is not Enabled for LOWCOST. See PreOwdEnable().
    BOOL bOwdCktWasGood = BOX->IsOwdCktGood();

#if 0 // temp for testing
#if !LOWCOST
    if ((IsWireOpen() == TRUE) && (PVSOURCE_AUTO ==  PvSource) &&
        (PTEXECST_ACTIVE == PtExecSt) && (MODSTATUS_RUN == BOX->GetModuleStatus())) {

        ValidateOwdCkt(TRUE,a_fRawData); // Verify open wire circuitry is working fine.
        // Report/return open wire softfail according to the OWD circuit state
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,BOX->IsOwdCktGood(),ChanNum);
    }
    else { // No open wire condition detected for this channel

        ValidateOwdCkt(FALSE,a_fRawData);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
    }
#endif
#endif
    if (IsOwdSfBtSet() == TRUE) {

        InitPvDb();
    }
    else if ((FALSE == bOwdCktWasGood) || (BOX->IsOwdCktGood() == TRUE)) {

        // Update PV database with new values
        PvRaw = fNewPvRaw;
        PvCalc = fNewPvCalc;
        PvAuto  = fNewPvAuto;
        FiltOut = fNewFiltOut;
        PvAutoSt = NewPvAutoSt;
    }
    else { // Issues with OWD circuit was newly detected. 
        // Discard PV values computed in this cycle.
        return;
    }


    /* 
     * Do Pv source selection
     */
    FLOAT32 fPv;
    if (PvSource == PVSOURCE_AUTO) {

        fPv = PvAuto;
        BOX->SetPv(ChanNum,fPv);
        BOX->SetPvSts(ChanNum,PvAutoSt);

        //AlarmProcessor(fPv, PvAutoSt); // temp for testing
        //BOX->SetPvAlmInfo(ChanNum, AlmInfo.ucByte);
        
        if (PVVALST_BAD != PvAutoSt) {

            LastPv = fPv;
        }

        PvExHiFl = bHiFlag;
        PvExLoFl = bLoFlag;
    }
    else { // if PvSource is Man or Sub

        fPv = BOX->GetPv(ChanNum);
        if (!isnan(fPv)) {

            LastPv = fPv;
            BOX->SetPv(ChanNum, fPv);
            BOX->SetPvSts(ChanNum, PVVALST_UNCERTN);

            //AlarmProcessor(fPv, PVVALST_UNCERTN);
            //BOX->SetPvAlmInfo(ChanNum, AlmInfo.ucByte);
        }

    } //end of Pv source selection

    //Normalize Pv
    PvP = (fPv - PvEULo) * HundredDivEUSpan;
}

/*******************************************************************************
*                          clsAihSlot::AlarmEvents                             *
*                          =======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: a_EventType - Normal / Recovery                                   *
* RETURN:    Event Success or not                                              *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihSlot::AlarmEvents(EVENTTYPE a_EventType)
{
    ALARMEVENTRECORD AlarmEvent;
    UINT8 ucChangeInAlarms;

    // Modified to resolve, PAR# 1-7HX4J5B
    ucChangeInAlarms = (EVENTTYPE_NORMAL == a_EventType) ? (AlmInfo.ucByte ^ AlarmLrs.ucByte) :
                                                            AlmInfo.ucByte;

    for (UINT8 ucMask = 1; ucMask < 0x80; ucMask*=2)
    {
        if (ucChangeInAlarms & ucMask)
        {
            AlarmEvent.Overflow      = FALSE;
            AlarmEvent.ContactCutout = ContCut;
            AlarmEvent.Qualifier     = a_EventType;
            AlarmEvent.Direction     = (AlmInfo.ucByte & ucMask) ? EVENTSTATE_ALARM : EVENTSTATE_RETURN;
            AlarmEvent.EventPacket   = EVENTPACKET_ALARM;
            AlarmEvent.ChannelNumber = ChanNum;
            AlarmEvent.SysOrBrkt     = FALSE; // 0 - for Alarm;
                                              // 1 - ptexectst, contcut change event;
            AlarmEvent.AlarmCode     = GetAlmCode(ucMask);
            AlarmEvent.Pv            = (FLOAT32)(BADPVFL_CODE == AlarmEvent.AlarmCode) ? NaN : BOX->GetPv(ChanNum);
            AlarmEvent.PvTp          = GetViolatedTripPoint(AlarmEvent.AlarmCode);

            if (BOX->AddAiAlarmEvent(&AlarmEvent) == TRUE)
            {
                if (AlmInfo.ucByte & ucMask)
                {
                    AlarmLrs.ucByte |= ucMask;
                }
                else
                {
                    AlarmLrs.ucByte &= ~ucMask;
                }
            }
            else return FALSE;
        }
    }


    return TRUE;
}
