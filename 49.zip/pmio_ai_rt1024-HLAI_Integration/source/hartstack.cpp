/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hartstack.cpp                                               *
*    Description : HART protocol stack implementation.                         *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif
#ifdef IOMTYPE_AOH
#include "aohmain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif

#include <stdint.h>
#include <stdbool.h>
#include "hartstack.hpp"
#include "hartdb.hpp"
#include "scheduler.hpp"
#include "hal_fpga.h"
#include "fsl_debug_console.h"
#include <string.h>

/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
clsHartQueue HartQueue;
static clsHartModem HartModem0(0);
static clsHartModem HartModem1(1);
static clsHartModem HartModem2(2);
static clsHartModem HartModem3(3);
clsHartModem *pHartModem[HARTMODEM_COUNT] = { &HartModem0, &HartModem1, &HartModem2, &HartModem3 };

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;
extern UINT16 g_usModemObjectMemory[];
#if defined(IOMTYPE_UIO)
// Memory for HART queues
extern UINT16 g_usHartQueueObjectMemory[];
#endif
/*******************************************************************************
*                               STATIC VARIABLES                               *
*******************************************************************************/
UINT8  clsHartModem::m_ucHartMuxEnbl        = 0x00u;  // Disable all multiplexors.
UINT16 clsHartModem::m_usHartMuxAddr        = 0xC840u;  // Connect modems to each MUX
UINT8  clsHartModem::m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT;
UINT8  clsHartModem::m_ucFailedChannel      = 0u;
UINT32 clsHartModem::m_sulMDiagCount        = 0u;

#if defined(IOMTYPE_UIO)
/*******************************************************************************
*                          clsHartQueue::operator new                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
*   Allocate memory for a clsHartQueue object.                                 *
* ARGUMENTS:                                                                   *
*   a_ucModemNumber: The modem the queue is to be associated with              *
* RETURN:                                                                      *
*   Pointer to memory that will hold the queue object.                         *
* NOTES:                                                                       *
*   None                                                                       *
*******************************************************************************/
VOID *clsHartQueue::operator new(UINT32, UINT8 a_ucModemNumber)
{ 
    return (g_usHartQueueObjectMemory + (a_ucModemNumber * CLSHARTQUEUE_SIZE));
}
#endif

/*******************************************************************************
*                         clsHartQueue::clsHartQueue                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Constructor. Initializes the object.                                      *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    Not applicable.                                                           *
* PROCESS:                                                                     *
*    1. Clear the Q buffer and initialze the next free index to zero.          *
* NOTES:                                                                       *
*    1. Only one clsQ object is constructed by the HARTP startup code.         *
*******************************************************************************/
clsHartQueue::clsHartQueue(VOID) {
    for (UINT8 ucCount = 0; ucCount < HARTQUEUE_BUFFER_SIZE; ucCount++) {
        m_ucBuffer[ucCount] = 0;
    }
    m_ucNextIndex = 0;
}
/*******************************************************************************
*                          clsHartQueue::AddToQueue                            *
*                          ========================                            *
* PURPOSE:                                                                     *
*    Add an entry to the HART communication queue.                             *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if request is accepted; FALSE if rejected.                  *
* PROCESS:                                                                     *
*    1. Check whether there is room in the Q. Reject if the Q is full.         *
*    2. Check whether a previous request from the same client is still         *
*       pending in the Q. Reject if a match is found.                          *
*    3. Check whether a previous request from the same client is still         *
*       processed by a modem object. Reject if a match is found.               *
*    4. Add the client reference to the tail.                                  *
* NOTES:                                                                       *
*    1. This method is called from the global function InitHartConnection.     *
*    2. Modem objects periodically checks the stack queue and uses the client  *
*       reference and callback interface to carry out the HART transaction.    *
*******************************************************************************/
BOOL clsHartQueue::AddToQueue(UINT8 a_ucChan) {
    // Do not let HART modem and timer interrupts to come in between.
    // Check whether Q is full already. Q full means that client is already
    // present in the Q as we allow only entry per client in the Q.
    if ((a_ucChan == 0u) || (m_ucNextIndex >= HARTQUEUE_BUFFER_SIZE)) {

        return FALSE;
    }

    // If client is already in the queue, reject the request.
    for (UINT8 ucCount = 0; ucCount < m_ucNextIndex; ucCount++) {
        if (m_ucBuffer[ucCount] == a_ucChan)    {
            return FALSE;
        }
    }

    // If client is already being processed by a modem, reject the request.
    for (UINT8 ucCount = 0; ucCount < HARTMODEM_COUNT; ucCount++) {
        // Do not check connected channel for modems in DIAG state. 
        // These have connected channel set to the modem being diagnosed.
        if ((pHartModem[ucCount]->GetModemState() != HMODEMSTATE_DIAG) &&
            (pHartModem[ucCount]->GetConnectedChannel() == a_ucChan)) {
            return FALSE;
        }
    }

    // Otherwise, add the client to the tail.
    m_ucBuffer[m_ucNextIndex++] = a_ucChan;
    return TRUE;
}
/*******************************************************************************
*                         clsHartQueue::RemoveFromQueue                        *
*                         =============================                        *
* PURPOSE:                                                                     *
*    Remove a client reference from the HART communication queue.              *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if the reference is found in the Q and removed;             *
*    FALSE if no match to the passed reference is found.                       *
* PROCESS:                                                                     *
*    1. Compare each queue member with the passed reference.                   *
*    2. If a match is found, delete the element by shifting all the members    *
*       right of it to one position left.                                      *
*    3. Clear the last queue position and update next free index.              *
* NOTES:                                                                       *
*    1. This method is called by AbortHartConnection.                          *
*******************************************************************************/
BOOL clsHartQueue::RemoveFromQueue(UINT8 a_ucChan) {
    // Do not let HART modem and timer interrupts to come in between.
    for (UINT8 ucCount = 0; ucCount < m_ucNextIndex; ucCount++) {
        if (m_ucBuffer[ucCount] == a_ucChan)    { // a_pClient found in queue
            // Shift rest of the Q to one position left.
            for (UINT8 ucShift = ucCount; (UINT8)(ucShift + 1u) < m_ucNextIndex; ucShift++) {
                m_ucBuffer[ucShift] = m_ucBuffer[ucShift + 1u];
            }

            // Clear the old tail and update the next-free index.
            m_ucNextIndex--;
            m_ucBuffer[m_ucNextIndex] = 0u;

            // request to remove is successful
            return TRUE;
        }
    }

    // Client not found in the queue.
    return FALSE;
}
static UINT8 HartMinimumPayloadLength(UINT8 ucCommand)
{
    switch (ucCommand)
    {
        case HARTCOMMAND_ZERO:     return HART_CMD0_ID_RESPONSE_SIZE;
        case HARTCOMMAND_THREE:    return HART_CMD3_1VAR_RESPONSE_SIZE;
        case HARTCOMMAND_TWELVE:   return HART_CMD12_RESPONSE_SIZE;
        case HARTCOMMAND_THIRTEEN: return HART_CMD13_RESPONSE_SIZE;
        case HARTCOMMAND_FOURTEEN: return HART_CMD14_RESPONSE_SIZE;
        case HARTCOMMAND_FIFTEEN:  return HART_CMD15_MANDATORY_RESPONSE_SIZE;
        case HARTCOMMAND_SIXTEEN:  return HART_CMD16_RESPONSE_SIZE;
        case HARTCOMMAND_TWENTY:   return HART_CMD20_RESPONSE_SIZE;
        case HARTCOMMAND_FIFTY:    return HART_CMD50_RESPONSE_SIZE;
        default:                   return 0u;
    }
}

BOOL HartStack_ResponseHasRequiredPayload(UINT8 ucCommand,
                                          const HartParsedResponse_t *pResponse)
{
    if (pResponse == NULL)
    {
        return FALSE;
    }

    if (pResponse->status0 != HART_RESPCODE_SUCCESS)
    {
        return TRUE;
    }

    const UINT8 ucExpected = HartMinimumPayloadLength(ucCommand);
    return ((ucExpected == 0u) || (pResponse->payloadLen >= ucExpected)) ? TRUE : FALSE;
}

/*******************************************************************************
*                         clsHartQueue::ProcessQueue                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Serach the queue and service a pending HART transaction request.          *
* ARGUMENTS:                                                                   *
*    1. a_ucModem - modem number (0,1,2 or 3)                                  *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Return if queue is empty.                                              *
*    2. Call the Connect method of the modem object specified and pass the     *
*       client reference at the head of the Q.                                 *
*    3. Advance all the Q members to one position left.                        *
*    4. Clear the last Q position and update next free index.                  *
* NOTES:                                                                       *
*    1. This method is called by ILDE modem objects when processing modem      *
*       heartbeat interrupt.                                                   *
*******************************************************************************/
VOID clsHartQueue::ProcessQueue(UINT8 a_ucModem) {
    // If the queue is empty, don't do anything
    if (0u == m_ucNextIndex) {
        return;
    }

    const UINT8 ucChannel = m_ucBuffer[0];

    if ((ucChannel == 0u) || (ucChannel > MAXSLOTS) ||
        (HartGetModemForChannel(ucChannel) != a_ucModem)) {
        return;
    }

    pHartModem[a_ucModem]->Connect(ucChannel);

#if HART_USE_RT1024_SYNCHRONOUS_TRANSPORT
    BOOL bContinueQueued = FALSE;
    clsHartDevDb &HartDevDb = SLOT(ucChannel)->GetHartDevDb();

    if (HartDevDb.m_HChanMode == HCHANMODE_INIT)
    {
        
        const HARTDISCOVERYRESULT result =
            HartDiscoverOnRoute(ucChannel, a_ucModem);

        HartDb_FinalizeSynchronousDiscovery(ucChannel, result);

#if HART_ENABLE_FINAL_RESPONSE_PRINT
        HartReportFinalResponse(ucChannel, a_ucModem, result);
#endif
    }
    else
    {
        
    // Make sure the HART address registers reflect what was written
    // when we connected to a channel.
        HSYNCSTATUS HartSyncStatus = HSYNCSTATUS_KEEP_SYNC;
        UINT8 ucBackToBackCount = 0u;
        HartSetRoute(ucChannel, a_ucModem);

        while ((HartSyncStatus == HSYNCSTATUS_KEEP_SYNC) &&
               (ucBackToBackCount < (UINT8)HART_MAX_SYNC_TRANSACTIONS))
        {
            HartParsedResponse_t HartResponse;
            const UINT8 *pRequest = HartDevDb.m_ucpLastXmtPtr;
            UINT8 ucCommand = HartDevDb.m_ucLastReqCmd;
            UINT8 ucDataLength = 0u;
            const UINT8 *pData = NULL;
            BOOL bResponseGood = FALSE;
            UINT8 ucRetryCount = SLOT(ucChannel)->GetRetryCount();

            memset(&HartResponse, 0, sizeof(HartResponse));

            if ((pRequest != NULL) && (pRequest[0] == ucCommand))
            {
                ucDataLength = pRequest[1];
                pData = (ucDataLength > 0u) ? &pRequest[2] : NULL;
            }

            if (ucRetryCount > HART_MAX_RETRIES)
            {
                ucRetryCount = HART_MAX_RETRIES;
            }

            if ((ucCommand != HARTCOMMAND_INVALID) && (pRequest != NULL))
            {
                HARTUNIQUEADDR UniqueAddress = HartDevDb.m_UniqueAddress;
                UniqueAddress.ucBytes[0] =
                    (UINT8)((UniqueAddress.ucBytes[0] & HART_MANUFACTURE_ID_MASK) |
                            HART_MASTER_ADDR_MASK);

                for (UINT8 ucAttempt = 0u;
                     (ucAttempt <= ucRetryCount) && (bResponseGood == FALSE);
                     ucAttempt++)
                {
                    memset(&HartResponse, 0, sizeof(HartResponse));
                    bResponseGood = HartStack_RunLongCommand(
                                        ucChannel,
                                        a_ucModem,
                                        HartDevDb.m_ucPollingAddress,
                                        UniqueAddress.ucBytes,
                                        ucCommand,
                                        pData,
                                        ucDataLength,
                                        &HartResponse);

                    if (bResponseGood != FALSE)
                    {
                        if (HartStack_ResponseHasRequiredPayload(
                                ucCommand, &HartResponse) == FALSE)
                        {
                            bResponseGood = FALSE;
                        }
                    }

                    if ((bResponseGood == FALSE) &&
                        (ucAttempt < ucRetryCount))
                    {
                        SLOT(ucChannel)->LogEvent(HEVENTTYPE_RETRY);
                    }
                }
            }

            if (bResponseGood != FALSE)
            {
                HartDb_LoadParsedResponse(&HartDevDb, &HartResponse);
                HartSyncStatus =
                    HartDevDb.ReceptionComplete(HMSGSTATUS_GOOD);

                if ((ucCommand == HARTCOMMAND_THREE) ||
                    (ucCommand == HARTCOMMAND_NINE))
                {
                    HartReportDynamicResult(ucChannel, a_ucModem);
                }
            }
            else
            {
                SLOT(ucChannel)->LogEvent(HEVENTTYPE_COMMERROR);
                HartSyncStatus =
                    HartDevDb.ReceptionComplete(HMSGSTATUS_BAD);
            }

            ucBackToBackCount++;
        }

        if (HartSyncStatus == HSYNCSTATUS_KEEP_SYNC)
        {
          
            HartDevDb.m_sScanCounter = TICKS_SYNCED_CHAN;
            bContinueQueued = TRUE;
        }
    }

    pHartModem[a_ucModem]->Disconnect();

    if (bContinueQueued != FALSE)
    {
 
        for (UINT8 ucCount = 0u;
             (UINT8)(ucCount + 1u) < m_ucNextIndex;
             ucCount++)
        {
            m_ucBuffer[ucCount] = m_ucBuffer[ucCount + 1u];
        }
        m_ucBuffer[m_ucNextIndex - 1u] = ucChannel;
        return;
    }
#else
#if defined(IOMTYPE_UIO)
    if (!FPGA.IsHartAddressRegisterValid(a_ucModem)) {
        pHartModem[a_ucModem]->SetModemBad();
        return;
    }
#else
    // Do loopback diagnostics on HART MUX ENBL and ADDR 
    // lines immediately after connecting to the channel.
    if (pHartModem[a_ucModem]->HartMuxLoopbackTest() > 1u) 
	{
        pHartModem[a_ucModem]->SetModemBad();
        return;
    }
#endif
#endif

    for (UINT8 ucCount = 0u;
         (UINT8)(ucCount + 1u) < m_ucNextIndex;
         ucCount++) {
        m_ucBuffer[ucCount] = m_ucBuffer[ucCount + 1u];
    }

    m_ucNextIndex--;
    m_ucBuffer[m_ucNextIndex] = 0u;
}

#if defined(IOMTYPE_UIO)
BOOL clsHartQueue::IsModemQueueEmpty(VOID) {
    // Next index is used to check for modem queue empty
    if(m_ucNextIndex == 0)
        return TRUE;
    else
        return FALSE;
}
#endif

/*******************************************************************************
*                          clsHartModem::operator new                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsHartModem::operator new(size_t, UINT8 a_ucModemNumber)
{
    return (g_usModemObjectMemory + (a_ucModemNumber * CLSHARTMODEM_SIZE));
}
/*******************************************************************************
*                         clsHartModem::clsHartModem                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Constructor. Initializes the object.                                      *
* ARGUMENTS:                                                                   *
*    1. a_ucModem - modem number - 0,1,2 or 3                                  *
* RETURN:                                                                      *
*    Not applicable.                                                           *
* PROCESS:                                                                     *
*    1. Initialize all members variables.                                      *
*    2. Clear the associated DUART FIFO and disable associated DUART channel   *
*       interrupts.                                                            *
* NOTES:                                                                       *
*    1. IOM startup code instantiates four objects of the clsHartModem class.  *
*******************************************************************************/
clsHartModem::clsHartModem(UINT8 a_ucModemNumber) :
    m_ucModemNumber(a_ucModemNumber),
    m_ucModemTimer(0),
    m_ModemState(HMODEMSTATE_IDLE),

    m_ucConnectedChannel(0),
    m_cucpXmtBuffer(NULL),
    m_ModemRcvBuffer(),
    m_ucPollingAddress(0),
    m_ucXmtCommand(HARTCOMMAND_INVALID),
    m_ucBytesInRequest(0),
    m_ucBytesInResponse(HART_MAX_BYTECOUNT),
    m_XmtRcvContext(XMTRCVCONTEXT_UNKNOWN),
    m_RcvMsgType(HMSGTYPE_UNKNOWN),
    m_RcvMsgStatus(HMSGSTATUS_BAD),
    m_ucCheckSum(0),
    m_ucRemPreambles(0),
    m_ucRcvdDelimiter(0),
    m_ucRetryCount(HART_MAX_RETRIES),
    m_bRequestDisconnect(FALSE),
    m_bBurstDeviceFound(FALSE),
    m_ucModemDiagCount(0)
#if defined(IOMTYPE_UIO)
    ,m_bHartStackProc(FALSE)
#endif
{
    memset(&m_UniqueAddress, 0, sizeof(m_UniqueAddress));

#if HART_INITIALIZE_UART_IN_CONSTRUCTOR
 
    HART_UART(m_ucModemNumber).RESET = 1u;
    // Modem control register - Disable RTS.
    HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0u;
    // Line control register
    // Configure UART for 8 bits per character, odd parity and one stop bit.
    HART_UART(m_ucModemNumber).BITS_PER_CHAR = HART_UART_8BITS_PER_CHAR;
    HART_UART(m_ucModemNumber).PARITY_ENBL = 1u;
    // FIFO control register - Enable both transmit and receive FIFOs 
    // and configure receive interrupt trigger level of 14 bytes.
    HART_UART(m_ucModemNumber).FIFO_ENBL = 1u;
    HART_UART(m_ucModemNumber).RCV_FIFO_TRIG_LEVEL = 3u;
    ClearTxRxFIFOs();
    HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = 0u;
#endif
}

/*******************************************************************************
*                            clsHartModem::Connect                             *
*                            =====================                             *
* PURPOSE:                                                                     *
*    Connect the modem to the specified client.                                *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number to be connected.                             *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Initialize clsHartModem members with the new channel details.          *
*    2. Enable and switch the HART multiplexor to the specified channel.       *
* NOTES:                                                                       *
*    1. Connect method is called from ProcessQueue.                            *
*******************************************************************************/
VOID clsHartModem::Connect(UINT8 a_ucChan) {
    m_ucConnectedChannel = a_ucChan;

#if defined(IOMTYPE_AIH)

    m_ucPollingAddress = SLOT(m_ucConnectedChannel)->GetPollingAddress(); 
    m_ucPollingAddress = (UINT8)((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) 
                                | HART_MASTER_ADDR_MASK);
    m_UniqueAddress = SLOT(m_ucConnectedChannel)->GetUniqueAddress();
    
    m_ucRetryCount = SLOT(m_ucConnectedChannel)->GetRetryCount();
#else
    m_ucPollingAddress = 0u;
    m_ucRetryCount = HART_MAX_RETRIES;
#endif

    m_UniqueAddress.ucBytes[0] =
        (UINT8)((m_UniqueAddress.ucBytes[0] & HART_MANUFACTURE_ID_MASK) |
                HART_MASTER_ADDR_MASK);
    m_ucXmtCommand = HARTCOMMAND_ZERO;
    m_ucBytesInRequest = 0u;
    m_ucBytesInResponse = HART_MAX_BYTECOUNT;
    m_XmtRcvContext = XMTRCVCONTEXT_PREAMBLE;
    m_RcvMsgType = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus = HMSGSTATUS_BAD;
    m_ucCheckSum = 0u;
    m_ucRemPreambles = 0u;
    m_ucRcvdDelimiter = 0u;
    // Limit the number of retries to 3.
    if (m_ucRetryCount > HART_MAX_RETRIES) 
    {
        m_ucRetryCount = HART_MAX_RETRIES;
    }
    m_bRequestDisconnect = FALSE;
    m_bBurstDeviceFound = FALSE;
#if defined(IOMTYPE_UIO)
    m_bHartStackProc = TRUE;
#endif
    m_ModemRcvBuffer.Flush(); // Initialize the modem receive buffer.
    SwitchMux(a_ucChan);  // Swith multiplexor to the connected channel.

    // Set SYNCWAIT state and turn ON the receiver to monitor 
    // the HART circuit during link quiet time.
    SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
}
/*******************************************************************************
*                          clsHartModem::Disconnect                            *
*                          ========================                            *
* PURPOSE:                                                                     *
*    Disconnect the modem from the currently connected channel.                *
* ARGUMENTS:                                                                   *
*    bResetState (UIO only) - When set to FALSE, caller intends to search for  *
*                             FDM sessions.                                    *           
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Initialize clsHartModem members with default values and flush buffers. *
*    2. Disable the HART multiplexor associated with the modem and RTS.        *
* NOTES:                                                                       *
*    1. Disonnect is called from HartModemHeartbeat and HartModemInterrupt,    *
*       if client has requested to disconnect.                                 *
*    2. Disconnect need to be protected as private method to streamline the    *
*       state change activities. So clients requesting disconnect sets a bool  *
*       variable in the modem object rather than calling the disconnect method *
*       directly. Next invocation of HartModemInterrupt or HartModemHeartbeat  *
*       method will call the Disconnect method.                                *
*******************************************************************************/
#if defined(IOMTYPE_UIO)
VOID clsHartModem::Disconnect(BOOL bResetState)
{
    Disconnect();



    if(bResetState == FALSE) 
    {
        // TRUE indicates, after this function execution, there is going to be 
        // search for PST from function which has called Disconnect function
        m_bHartStackProc = TRUE;
    }
}
#endif

VOID clsHartModem::Disconnect(VOID)
{
    const UINT8 modemMask = (UINT8)(1u << m_ucModemNumber);

    HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0u;
    HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = 0u;
    ClearTxRxFIFOs();

    m_ucHartMuxEnbl = (UINT8)(m_ucHartMuxEnbl & (UINT8)(~modemMask));
    hal_fpga_hart_mux_enable(m_ucHartMuxEnbl);

    if (m_ModemState != HMODEMSTATE_BAD)
    {
        m_ModemState = HMODEMSTATE_IDLE;
    }

    m_ucConnectedChannel = 0u;
    m_ucModemTimer = 0u;
    m_cucpXmtBuffer = NULL;
    m_ucPollingAddress = 0u;
    memset(&m_UniqueAddress, 0, sizeof(m_UniqueAddress));
    m_ucXmtCommand = HARTCOMMAND_INVALID;
    m_ucBytesInRequest = 0u;
    m_ucBytesInResponse = HART_MAX_BYTECOUNT;
    m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
    m_RcvMsgType = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus = HMSGSTATUS_BAD;
    m_ucCheckSum = 0u;
    m_ucRemPreambles = 0u;
    m_ucRcvdDelimiter = 0u;
    m_ucRetryCount = 0u;
    m_bRequestDisconnect = FALSE;
    m_bBurstDeviceFound = FALSE;
    m_ucModemDiagCount = 0u;
#if defined(IOMTYPE_UIO)
    m_bHartStackProc = FALSE;
#endif
    m_ModemRcvBuffer.Flush();
}
/*******************************************************************************
*                            clsHartModem::SwitchMux                           *
*                            =======================                           *
*******************************************************************************/
VOID clsHartModem::SwitchMux(UINT8 a_ucChan)
{
    UINT16 usAddr = (UINT16)((a_ucChan - 1u) & 0x000Fu);


    usAddr = (UINT16)(usAddr << (m_ucModemNumber * 4u));

    switch (m_ucModemNumber)
    {
        case 0u: m_usHartMuxAddr &= 0xFFF0u; break;
        case 1u: m_usHartMuxAddr &= 0xFF0Fu; break;
        case 2u: m_usHartMuxAddr &= 0xF0FFu; break;
        case 3u: m_usHartMuxAddr &= 0x0FFFu; break;
        default: return;
    }

    m_usHartMuxAddr |= usAddr;
    m_ucHartMuxEnbl |= (UINT8)(0x01u << m_ucModemNumber);


    hal_fpga_hart_mux_set16(m_usHartMuxAddr);
    hal_fpga_hart_mux_enable(m_ucHartMuxEnbl);
}

#if !defined(IOMTYPE_UIO)
/*******************************************************************************
*                       clsHartModem::HartMuxLoopbackTest                      *
*                       =================================                      *
*******************************************************************************/
UINT8 clsHartModem::HartMuxLoopbackTest(VOID) 
{
    const UINT8 enableMask = (UINT8)(1u << m_ucModemNumber);
    const UINT16 addressMask = (UINT16)(0x000Fu << (m_ucModemNumber * 4u));
    UINT8 failureCount = 0u;

    // Do HART MUX ENBL and ADDR lines readback test with three retries.
    for (UINT8 trial = 0u; trial < HART_MAX_RETRIES; trial++)
    {
        const UINT16 actualAddress = hal_fpga_hart_mux_get_addr16();
        const UINT8 actualEnable = hal_fpga_hart_mux_get_enable();

        if (((actualAddress & addressMask) != (m_usHartMuxAddr & addressMask)) ||
            ((actualEnable & enableMask) != (m_ucHartMuxEnbl & enableMask)))
        {
            failureCount++;
        }
    }
    
    return failureCount;
}
#endif

/*******************************************************************************
*                          clsHartModem::DiagConnect                           *
*                          =========================                           *
*  Perform modem diagnostics by connecting to the same channel as the suspect  *
*  modem. In DIAG mode, the data member m_ucConnectedChannel is used to store  *
*  the modem number of the suspect modem. Suspect modem is reinstated back to  *
*  SYNCWAIT state so that it will retry transmission. DIAG modem will look for *
*  carrier detect when suspect modem is transmitting.                          *
*******************************************************************************/
VOID clsHartModem::DiagConnect(UINT8 a_ucSuspectModem) {

#if defined(IOMTYPE_UIO)
    // UIO cannot support diagnostic connections.
    HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
#endif
    m_ModemState = HMODEMSTATE_DIAG;
    m_ucConnectedChannel = a_ucSuspectModem;
    m_ucModemTimer = HART_SLAVE_TIME_OUT;
    m_ucRemPreambles = 0;
    SwitchMux(pHartModem[a_ucSuspectModem]->GetConnectedChannel());
    
    ClearTxRxFIFOs();
    m_ModemRcvBuffer.Flush(); // Initialize the modem receive buffer.
    if (HART_RCVINTR_ENABLE != HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER) {
        HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;
        HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_RCVINTR_ENABLE;
    }
    
    // Put the SUSPECT modem back into SYNCWAIT state.
    pHartModem[a_ucSuspectModem]->ReinstateModem();

    // Update the diagnostic count and log the trace if required.
    m_sulMDiagCount++;
    if ((m_sulMDiagCount % 100) == 0) {
        TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagCount,m_sulMDiagCount);
    }
}
/*******************************************************************************
*                       clsHartModem::ProcessDiagModem                         *
*                       ==============================                         *
*  This function will be called if any RCV interrupt is detected while modem   *
*  is DIAG state. Check for the presence of carrier and make sure that suspect *
*  modem is transmitting. If both conditions are met, simply disconnect modem  *
*  so that it will be relieved of dianostic duties. Any data received in DIAG  *
*  mode is discarded.                                                          *
*******************************************************************************/
VOID clsHartModem::ProcessDiagModem(VOID) {
    UINT8 ucRcvdByte;
    // First ready any data in the UART receive buffer.
    while (HART_UART(m_ucModemNumber).DATA_READY) {
        UINT8 ucLineStatus = HART_UART(m_ucModemNumber).LINE_STS_REGISTER;
        ucRcvdByte = HART_UART(m_ucModemNumber).RCVBUF_REGISTER;
        if ((HART_PREAMBLE_BYTE == ucRcvdByte) &&
            (!(ucLineStatus & HART_RCVERROR_PRESENT))) {
            // If a preamble byte is received without any reception 
            // (break, framing, parity or overrun) error, increment byte count.
            m_ucRemPreambles++;
        }
    }

    if (m_ucRemPreambles >= HART_MIN_PREAMBLES) 
    {
        // Modem circuit is working fine. Reset last failed channel and disconnect the DIAG modem. 
        if (pHartModem[m_ucConnectedChannel]->GetConnectedChannel() == m_ucFailedChannel)
        {
            m_ucFailedChannel = 0;
        }

        Disconnect();
    }
}
/*******************************************************************************
*                         clsHartModem::HartModemInterrupt                     *
*                         ================================                     *
* PURPOSE:                                                                     *
*    Service interrupts from the associated UART channel.                      *
* ARGUMENTS:                                                                   *
*    1. a_HartIntrType - interrupt type identified by the ISR.                 *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Exit if modem state is IDLE or BAD.                                    *
*    2. If the client has requested disconnect, process it and return.         *
*    3. Process according to the interrupt type.                               *
* NOTES:                                                                       *
*    1. This method is called from ProcessHartInterrupt.                       *
*******************************************************************************/
VOID clsHartModem::HartModemInterrupt(HINTRTYPE a_HartIntrType) {
    if ((HMODEMSTATE_BAD == m_ModemState) || (HMODEMSTATE_IDLE == m_ModemState)) {
        return;
    }

    if (TRUE == m_bRequestDisconnect) {
        Disconnect();
        return;
    }

    BOOL bRcvdGood = TRUE;
    UINT8 ucByteCount = 0, ucLineErrCount = 0;

    switch (a_HartIntrType) {
    case HINTRTYPE_XMTFIFOEMPTY:
        if (HMODEMSTATE_XMTING == m_ModemState) {
            // Whatever put into UART FIFO earlier is transmitted.  
            if (m_ucBytesInRequest == 0) {
                // If all bytes of the request are transmitted, change state to RCVING. 
                SetState(HMODEMSTATE_RCVING,HART_SLAVE_TIME_OUT);
            }
            else {
                // There are more bytes left in the request.
                // Transmit next frame.
                TransmitRequest();
            }
        }
        break;
    case HINTRTYPE_CARRIERDETECT:
        // This interrupt is used for the timing of slave timeout or modem diagnostics.
        if ((HMODEMSTATE_RCVING == m_ModemState) ||
            (HMODEMSTATE_RCVWAIT == m_ModemState) ||
            (HMODEMSTATE_SUSPECT == m_ModemState)) {
            m_ModemState = HMODEMSTATE_RCVING;
            // Detected the start of the response messsage. Set the modem 
            // timer to the time required to fill UART receive FIFO.
            if (m_ucModemTimer < UART_RCV_FIFO_SIZE) {
                m_ucModemTimer = UART_RCV_FIFO_SIZE;
            }
        }
        else if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
            m_ucModemTimer = UART_RCV_FIFO_SIZE;
        }
        break;
    case HINTRTYPE_RCVFIFOFULL:
    case HINTRTYPE_RCVFIFOTOUT:
    case HINTRTYPE_CARRIERDROP:
        if (HMODEMSTATE_DIAG == m_ModemState) {
            ProcessDiagModem();
            break;
        }
        else if (HMODEMSTATE_SUSPECT == m_ModemState) {
            m_ModemState = HMODEMSTATE_RCVING;
        }
        // Data is available in UART FIFO. Copy all data to the modem buffer.
        // Check the line status register for each data byte. The status of
        // reception is revealed by the UART when the data byte is on top of
        // the receive FIFO.
        while (HART_UART(m_ucModemNumber).DATA_READY) { // while data in DUART RCV FIFO
            UINT8 ucLineStatus = HART_UART(m_ucModemNumber).LINE_STS_REGISTER;
            // Copy data from UART RCV FIFO to modem object buffer.
            m_ModemRcvBuffer = HART_UART(m_ucModemNumber).RCVBUF_REGISTER;
            ucByteCount++;
            if (ucLineStatus & HART_RCVERROR_PRESENT) {
                // If any reception (break, framing, parity or overrun) error detected.
                if ((1 == ucByteCount) && (HART_MAX_BYTECOUNT == m_ucBytesInResponse)) {
                    // First byte of the frame may not be received correctly. Ignore the error
                    // and discard the received byte for error in the first byte of the frame.
                    m_ModemRcvBuffer.ThrowLastRcvd(); 
                }
                else if (ucByteCount < m_ucBytesInResponse) {
                    ucLineErrCount++; // increment the error count.
                    if (ucLineErrCount > 1) { // if more than one error present
                        bRcvdGood = FALSE; // declare the message reception as bad.
                    }
                }
                else { // All bytes are received. This is a dribble byte.
                    m_ModemRcvBuffer.ThrowLastRcvd(); // Ignore it.
                }
            }
        }

        // All bytes left in the RCV FIFO are now copied to modem object buffer.
        if ((ucByteCount <= MAX_DRIBBLE_BYTES) && (m_ucBytesInResponse > MAX_DRIBBLE_BYTES)) {
            // PMIO SIT found that two dribble byte can be in the FIFO when secondary
            // master is used with some type of devices. If only two bytes are 
            // there in the FIFO when more than two bytes are expected in the 
            // response, these are dribble bytes left in the FIFO from an earlier 
            // transaction. Igore these bytes.
            // NOTE: Communication failure will be reported, in case more than  
            // two dribble bytes happen to occur.
            while (ucByteCount > 0) {
                m_ModemRcvBuffer.ThrowLastRcvd();
                ucByteCount--;
            }
            return;
        }

        if (TRUE == bRcvdGood) { // If the reception was good
            ProcessResponse();
        }
        else {
            HandleReceiveError();
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,1);
    }
}
/*******************************************************************************
*                       clsHartModem::HartModemHeartbeat                       *
*                       ================================                       *
* PURPOSE:                                                                     *
*    Service the timer interrupt from TPU2 once every HART chracter time       *
*    (9.167 msec) interval.                                                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If modem state is BAD return immediately.                              *
*    2. If modem state is IDLE process the HART Q and return.                  *
*    3. If client has requested to disconnect, process it and return.          *
*    4. Decrement the modem timer and call ModemTimeout method if the timer    *
*       decrements to zero.                                                    *
* NOTES:                                                                       *
*    1. This method is invoked from the TPU2 of H8.                            *
*******************************************************************************/
VOID clsHartModem::HartModemHeartbeat(VOID) {
    static UINT8 stucProcessModem = 0u;

    for (UINT8 ucModem = 0u; ucModem < HARTMODEM_COUNT; ucModem++, stucProcessModem++) {
        if (stucProcessModem >= HARTMODEM_COUNT) { stucProcessModem = 0u;
        }

        clsHartModem *pModem = pHartModem[stucProcessModem];
        if (pModem == NULL) {
            continue;
        }

        // If modem is BAD, make sure that softfail is posted and continue.
        if (pHartModem[stucProcessModem]->m_ModemState == HMODEMSTATE_BAD) {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,(SOFTFAILTYPE)(SF_HMODEM1+stucProcessModem),TRUE,0);
            continue;
        }

#if HART_ENABLE_MODEM_DIAGNOSTICS
        // Diag underrun count should be reset in secondary in any case.
        if (Iol.AmPrimary() == FALSE) {
            m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT; 
        }
        // Post/return SF_HDIAGTO depending on the number of 1-second  
        // channels and the diag underrun count. If m_ucHDiagUnderRunCount  
        // has reached zero, this modem is waiting in SUSPECT state for  
        // 3 seconds and SF_HDIAGTO softfail should be posted.
        if ((0 == m_ucHDiagUnderRunCount) ||
            (clsHartDevDb::GetNoOf1SecChannels() > MAX_1SEC_CHANNELS)) { 
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_HDIAGTO,TRUE,0);
        }
        else {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_HDIAGTO,FALSE,0);
        }
#endif

        // If client request disconnect, do it and process the queue.
        if (pModem->m_bRequestDisconnect != FALSE) {
            pModem->Disconnect();
        }
        
        // If modem is IDLE, first check whether any other modem needs diagnosis
        if (pModem->m_ModemState == HMODEMSTATE_IDLE) {
            //---------------------------------------------
            // UIO cannot perform diagnostic connections 
            // and will not mark modems as suspect.
            //---------------------------------------------
#if !defined(IOMTYPE_UIO)
            for (UINT8 ucCheck = 0; ucCheck < HARTMODEM_COUNT; ucCheck++) {
                if ((ucCheck != stucProcessModem) &&
                    (pHartModem[ucCheck] != NULL) &&
                    (pHartModem[ucCheck]->GetModemState() == HMODEMSTATE_SUSPECT)) {
                        // Perform diagnostics of the suspect modem.
                    pModem->DiagConnect(ucCheck);
                        break; // Break from the inner for loop.
                }
            }
#endif

            if (pModem->m_ModemState != HMODEMSTATE_DIAG) {
                // if no modem requires diagnosis, process the HART queue as usual.           
#if defined(IOMTYPE_UIO)
                // Each modem has its own queue                   
                pHartQueue[stucProcessModem]->ProcessQueue(stucProcessModem);
#else
                HartQueue.ProcessQueue(stucProcessModem);
#endif
            }

            continue; // Continue to process next modem.
        }
   
        // Execution reaches here if modem was not IDLE. Process modem timer.
        if (pModem->m_ucModemTimer > 0u) {
            pModem->m_ucModemTimer--;
        }
        if (pModem->m_ucModemTimer == 0u) {
            pModem->ModemTimeout();
        }
    }
}
/*******************************************************************************
*                           clsHartModem::SetState                             *
*                           ======================                             *
* PURPOSE:                                                                     *
*    Set modem object to transmit, receive and waiting-to-sync states.         *
* ARGUMENTS:                                                                   *
*    1. a_ModemState - HMODEMSTATE to be set.                                  *
*    2. a_ucModemTimer - modem timer value to be set.                          *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Set the specified members and initialize other object members with     *
*       default values.                                                        *
*    2. Re-initialize channel details if state is changed to SYNCWAIT.         *
*    3. Set the UART interrupts and drive the RTS line as per the new state.   *
* NOTES:                                                                       *
*    1. This method is called from a number of modem object methods - Connect, *
*       TransmitRequest, ProcessResponse, ActOnResponse and SetupRetry.        *
*******************************************************************************/
VOID clsHartModem::SetState(HMODEMSTATE a_ModemState,UINT8 a_ucModemTimer) {
    m_ucModemTimer      = a_ucModemTimer;
    m_XmtRcvContext     = XMTRCVCONTEXT_UNKNOWN;
    m_RcvMsgType        = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus      = HMSGSTATUS_BAD;
    m_ucCheckSum        = 0;
    m_ucBytesInResponse = HART_MAX_BYTECOUNT; 

    ClearTxRxFIFOs();
#if defined(IOMTYPE_UIO) 
    HCHANTYPE ChanType;
    
    // Since the AI and AO channels don't inherit from a common HART class,
    // switch on the channel type to pull out the information we need.
    switch (BOX->GetInitPntType(m_ucConnectedChannel))
    {
        case PNTTYPE_ANALOGINPUT:
        
            ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        case PNTTYPE_ANALOGOUTPUT:
        
            ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        default:
            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
            break;
    }  
#else
    HCHANTYPE ChanType = HCHANTYPE_CHANNEL;
    if ((m_ucConnectedChannel > 0u) && (m_ucConnectedChannel <= MAXSLOTS)) {
        ChanType = SLOT(m_ucConnectedChannel)->GetHartChanType();
    }
#endif
    switch (a_ModemState) {
    case HMODEMSTATE_SUSPECT:
    case HMODEMSTATE_SYNCWAIT:
        if (HART_RCVINTR_ENABLE != HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER) {
#if defined(IOMTYPE_UIO)
            // Disable the transmitter so we can receive data
            FPGA.EnableHartTransmitter(m_ucConnectedChannel, FALSE);
#endif
            HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;
            HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_RCVINTR_ENABLE;
        }

#if !defined(IOMTYPE_UIO)
       // UIO has separate pointers for PST and Status updates
        m_cucpXmtBuffer = SLOT(m_ucConnectedChannel)->GetXmtDataPtr();
#endif
        if (HCHANTYPE_PASSTHROUGH == ChanType) {
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
            
                    m_cucpXmtBuffer = AIH_SLOT(m_ucConnectedChannel)->GetPstXmtDataPtr();
                    break;
                
                case PNTTYPE_ANALOGOUTPUT:
            
                    m_cucpXmtBuffer = AOH_SLOT(m_ucConnectedChannel)->GetPstXmtDataPtr();
                    break;
                
                default:
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
          }    
#endif
            m_ucXmtCommand = *(m_cucpXmtBuffer + HPST_COMMAND_OFFSET);
            m_ucBytesInRequest = HPST_MESSAGE_OVERHEAD + *(m_cucpXmtBuffer + HPST_BYTECOUNT_OFFSET); 
        }
        else if ((HCHANTYPE_CHANNEL == ChanType) && (m_cucpXmtBuffer != NULL)) {
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
            
                    m_cucpXmtBuffer = AIH_SLOT(m_ucConnectedChannel)->GetXmtDataPtr();
                    break;
                
                case PNTTYPE_ANALOGOUTPUT:
            
                    m_cucpXmtBuffer = AOH_SLOT(m_ucConnectedChannel)->GetXmtDataPtr();
                    break;
                
                default:
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
          }    
#endif
            m_ucXmtCommand = *m_cucpXmtBuffer++;
            // Bytecount + 1 checkbyte + 1 pad character. Pad character is
            // required to make sure that check byte is fully transmitted
            // before the RTS line is disabled.
            m_ucBytesInRequest = *m_cucpXmtBuffer++ + CHECKPAD_BYTECOUNT; 
        }
        else {
            
            m_ucXmtCommand = HARTCOMMAND_INVALID;
            m_ucBytesInRequest = 0u;
        }

#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                m_ucPollingAddress = AIH_SLOT(m_ucConnectedChannel)->GetPollingAddress();
                m_ucPollingAddress = ((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
                m_UniqueAddress = AIH_SLOT(m_ucConnectedChannel)->GetUniqueAddress();
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                m_ucPollingAddress = AOH_SLOT(m_ucConnectedChannel)->GetPollingAddress();
                m_ucPollingAddress = ((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
                m_UniqueAddress = AOH_SLOT(m_ucConnectedChannel)->GetUniqueAddress();
                break;
                
            default:
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }    
        
#else
        m_ucPollingAddress = SLOT(m_ucConnectedChannel)->GetPollingAddress();
        m_ucPollingAddress = ((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
        m_UniqueAddress = SLOT(m_ucConnectedChannel)->GetUniqueAddress();
#endif
        m_UniqueAddress.ucBytes[0] = ((m_UniqueAddress.ucBytes[0] & 
                                       HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
        m_ModemState = a_ModemState;
        break;
    case HMODEMSTATE_XMTING:
        // Note that Transmit Holding Register Empty (THRE) interrupt is not
        // enabled here. As the transmit FIFO is empty now, enabling this 
        // interrupt will cause a false triggering. THRE interrupt is enabled
        // in TransmitRequest method, only after transmit bytes are transfered to
        // the UART XMT FIFO. RTS is also asserted just before the trasmit start.
        m_ModemState = HMODEMSTATE_XMTING;
        break; 
    case HMODEMSTATE_RCVING:
        if (HART_RCVINTR_ENABLE != HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER) {
#if defined(IOMTYPE_UIO)
            // Disable the transmitter so we can receive data
            FPGA.EnableHartTransmitter(m_ucConnectedChannel, FALSE);
#endif
            HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;
            HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_RCVINTR_ENABLE;
        }
        m_ModemState = HMODEMSTATE_RCVING;
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,2);
    }
}
/*******************************************************************************
*                         clsHartModem::ModemTimeout                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Service modem timer expired condition.                                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If modem is idle or bad, return.                                       *
*    2. If waiting for sync, check the receive buffer. If any data is received *
*       call HartModemInterrupt with RCVFIFOTOUT to process the received bytes.*
*       Otherwise, the link quiet time has been validated and is ok to start   *
*       tranmsitting the request.                                              *
*    3. If in reception mode also, check the receive buffer. If any data is    *
*       received, call HartModemInterrupt with RCVFIFOTOUT to process the      *
*       received bytes. Otherwise, call SetupRetry to retry the request.       *
*    4. If in transmit mode, check the transmit FIFO to see any characters are *
*       left to transmit. If not, this trasmit interrupt was somehow missed    *
*       by the IRQ1 processing. Call HartModemInterrupt with XMTFIFOEMPTY.     *
* NOTES:                                                                       *
*    1. ModemTimeout is called from HartModemHeartbeat method when modem timer *
*       decrements to zero.                                                    *
*******************************************************************************/
VOID clsHartModem::ModemTimeout(VOID) {
    switch (m_ModemState) {
    case HMODEMSTATE_BAD:
    case HMODEMSTATE_IDLE:
        return;
    case HMODEMSTATE_SUSPECT:
        // This modem needs diagnosis. Do not allow it to timeout and change
        // state. It will be taken out SUSPECT state only when another modem
        // is available for diagnosis.
        m_ucModemTimer = HART_PRIMARY_QUIET_TIME;
        // It takes approximately 300 milli second for the timer to timeout.
        // m_ucHDiagUnderRunCount is decremented for each timeout. When it
        // decrements to zero, 3 seconds has elapsed with this modem in
        // SUSPECT state. This will result in posing of SF_HDIAGTO softfail.
        if (m_ucHDiagUnderRunCount > 0) {
            m_ucHDiagUnderRunCount--;
            if (1 == m_ucHDiagUnderRunCount) {
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagFailed,
                                    (0xAA00|m_ucModemNumber));
            }
        }
        break;
    case HMODEMSTATE_DIAG:
        {
#if defined(IOMTYPE_UIO)
             // UIO cannot support diagnostic connections.
             HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
#else
            UINT8 ucSuspectModem = m_ucConnectedChannel; // NOTE: SUSPECT modem is connected to DIAG modem.
            UINT8 ucSuspectChannel = pHartModem[ucSuspectModem]->GetConnectedChannel();

            UINT8 ucModemDiagCount = pHartModem[ucSuspectModem]->GetModemDiagCount();
            HMODEMSTATE SuspectModemState = pHartModem[ucSuspectModem]->GetModemState();

            if (SuspectModemState == HMODEMSTATE_IDLE)
            {
                // SUSPECT modem has aborted transmission due to a configuration change.
                // For example, channel delete. Abort diagnostics by disconnecting the DIAG modem.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagAbort);
                Disconnect();
            }
            else if ((SuspectModemState == HMODEMSTATE_SYNCWAIT) || (SuspectModemState == HMODEMSTATE_XMTING))
            {
                // SUSPECT modem is still waiting for transmission or doing the transmission. Reset
                // DIAG modem timer and wait for the SUSPECT modem to complete transmission of preambles.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagReset,
                                    (SuspectModemState << BYTESIZE) | pHartModem[ucSuspectModem]->GetModemTimer());
                m_ucModemTimer = HART_SLAVE_TIME_OUT; 
            }
            //---------------------------------------------
            // UIO cannot perform diagnostic connections 
            // and will not mark modems as suspect.
            //---------------------------------------------
            else if (ucModemDiagCount < HMODEMDIAG_MAXCOUNT)
            {
                // Retry diagnostics.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagRetry,
                    (((UINT32)m_ucRemPreambles << (WORDSIZE+BYTESIZE)) | ((UINT32)ucSuspectChannel << WORDSIZE) |
                     (SuspectModemState << BYTESIZE) | ucModemDiagCount)); 
                DiagConnect(ucSuspectModem);
            }
            else {
                // Send bad status back to the connected channel of the 
                // SUSPECT modem until the channel agrees to disconnect.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagFailed,
                    ((UINT32)ucSuspectModem << (WORDSIZE+BYTESIZE)) | ((UINT32)m_ucModemNumber << WORDSIZE) |
                    (ucSuspectChannel << BYTESIZE) | m_ucFailedChannel);

                while (HSYNCSTATUS_KEEP_SYNC == SLOT(ucSuspectChannel)->ReceptionComplete(HMSGSTATUS_BAD));

                if (ucSuspectChannel == m_ucFailedChannel)
                {
                    // If modem diagnostics failed on the same channel as the last one,
                    // problem is with the HART channel, not with the modem. Clear all
                    // modem failures and report HART channel failure.
                    if (Iol.AmPrimary()) SLOT(m_ucFailedChannel)->GetHartDevDb().SetHartChanFail();

                    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
                    {
                        pHartModem[ucModem]->ClearModemBad();
                    }

                    pHartModem[ucSuspectModem]->Disconnect();
                    Disconnect();
                }
                else
                {
                    // DIAG modem timed out means it waited for 28 character times and 
                    // did not see a carrier. Also the diagnostics was retried three times
                    // and all trails failed. That means there is a failure with either
                    // the DIAG modem itself or with the modem being diagnosed. Mark 
                    // both modems bad so that both will be taken out of scheduling.
                    // Set DIAG modem also bad as it cannot be determined whether 
                    // the SUSPECT modem or the DIAG modem has hardware problem.
                    // Note that DIAG modem is connected only to the physical channel,
                    // it is not connected to any channel object and does not need to
                    // call ReceptionComplete() unlike the SUSPECT modem.
                    if (Iol.AmPrimary()) 
                    {
                        m_ucFailedChannel = ucSuspectChannel;
                        pHartModem[ucSuspectModem]->SetModemBad();
                        SetModemBad();
                    }
                    else 
                    {
                        pHartModem[ucSuspectModem]->Disconnect();
                        Disconnect();
                    }
                }
            }
#endif
        }
        break;
    case HMODEMSTATE_SYNCWAIT:
        if (HART_UART(m_ucModemNumber).DATA_READY) {
            // There is data in UART RCV FIFO but not up to the RCV FIFO
            // interrupt trigger level. Treat this condition similar to RCV
            // FIFO timeout and call HartModemInterrupt.
            HartModemInterrupt(HINTRTYPE_RCVFIFOTOUT);
        }
        else {
            // HART master link quiet time has elapsed and the IOP is now
            // synchronized. Start transmission of the request.
            TransmitRequest();
        }
        break;
    case HMODEMSTATE_RCVWAIT:
    case HMODEMSTATE_RCVING:
        if (HART_UART(m_ucModemNumber).DATA_READY) {
            // There is data in DUART RCV FIFO but not up to the RCV FIFO
            // interrupt trigger level. Treat this condition similar to RCV
            // FIFO timeout and call HartModemInterrupt.
            HartModemInterrupt(HINTRTYPE_RCVFIFOTOUT);
        }
        else {
            // Timeout while waiting for reply. 
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
                
                    AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_NORESPONSE);        
                    break;
                    
                case PNTTYPE_ANALOGOUTPUT:
                
                    AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_NORESPONSE);
                    break;
                    
                default:
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
            } 
                
            // Setup a retry and don't mark the modem as suspect.
            // UIO cannot perform diagnostic connections.
            SetupRetry(HART_LINK_GRANT_TIME);
#else
            SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_NORESPONSE);
#endif
            // If this is the first retry after a complete loss of response,
            // and is not device discovery operation, mark modem as SUSPECT so that
            // modem diagnosis will be done with the transmission of the retry request.
            // For AO make sure that the loopback test is also successful.
            // For AI make sure HEnable is TRUE
#if defined(IOMTYPE_AIH)
            if ((Iol.AmPrimary()) && 
                (m_ucModemDiagCount == 0) &&
                (SLOT(m_ucConnectedChannel)->GetHartCfgDb().HEnable == TRUE)) {
#endif
            
#if defined(IOMTYPE_AOH)
            AOLPBKSTS LpbkSts = AOLPBK_PASSED;
            if ((BOX->GetModuleStatus() == MODSTATUS_RUN) &&
                (SLOT(m_ucConnectedChannel)->GetPtExecSt() == PTEXECST_ACTIVE)) {
                LpbkSts = SLOT(m_ucConnectedChannel)->GetLoopBackStatus();
            }
            else {
                LpbkSts = SLOT(m_ucConnectedChannel)->DoLoopbackTest();
            }
            if ((Iol.AmPrimary()) && 
                (m_ucModemDiagCount == 0) && 
                (AOLPBK_PASSED == LpbkSts) && 
                (SLOT(m_ucConnectedChannel)->GetOpFinal() > OP_LOLIMIT)) {
#endif

#if !defined(IOMTYPE_UIO)
                // This modem requires diagnostics. Before changing the state
                // to SUSPECT, check how many modems are already in SUSPECT state.
                UINT8 ucSuspectModems = 0;
                for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
                {
                    if (pHartModem[ucModem]->GetModemState() == HMODEMSTATE_SUSPECT)
                    {
                        ucSuspectModems++;
                    }
                }

                // Make sure that at least one modem is available for diagnostics.
                if (ucSuspectModems < (HARTMODEM_COUNT - 1))
                {
                    m_ucRetryCount--;

                    SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);

                    SetState(HMODEMSTATE_SUSPECT,HART_PRIMARY_QUIET_TIME);
                }
                else
                {
                    // This is the only modem that not in SUSPECT state.
                    // Free this one so that it can do diagnostics.
                    // Also force channel to disconnect from this modem.

                    while (HSYNCSTATUS_KEEP_SYNC == 
                           SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD));

                    Disconnect();
                }
            }
            else {
                // This is not the first retry or this channel is not configued
                // for HART (auto detection is going on) or loopback test has failed.
                // Setup for retry as usual.
                SetupRetry(HART_LINK_GRANT_TIME);
            }
#endif
        }
        break;
    case HMODEMSTATE_XMTING:
        if (HART_UART(m_ucModemNumber).XMTREG_EMPTY) {
            // Transmit FIFO is empty; but the interrupt was missed.
            // Call HartModemInterrupt as if interrupt really triggered.
            HartModemInterrupt(HINTRTYPE_XMTFIFOEMPTY);
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,3);
    }
}
/*******************************************************************************
*                        clsHartModem::TransmitRequest                         *
*                        =============================                         *
* PURPOSE:                                                                     *
*    Transmit the request by transfering bytes to UART transmit FIFO.          *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If this is the first frame of transmission, set the state to XMTING.   *
*       If this is the last retry of a command zero poll, reset address to 0.  *
*    2. Check the client type and do the transmit context switching depending  *
*       on the bytes left to transmit and the space available in the UART XMT  *
*       FIFO.                                                                  *
*    3. Enable Transmit Holding Register Empty interrupt.                      *
* NOTES:                                                                       *
*    1. This method is called from ModemTimeout when link quiet time expires   *
*       without any activity in the link.                                      *
*    2. TransmitRequest is called from ActOnResponse method when ACK or BACK   *
*       frame to the secondary master is detected.                             *
*    3. TransmitRequest is called from HartModemInterrupt in response to XMT   *
*       Holding Register Empty interrupt for transmitting rest of the message. *
*******************************************************************************/
VOID clsHartModem::TransmitRequest(VOID) 
{
    UINT8 ucXmtByteCount = 0, ucAddrByteCount = 0;
    
#if defined(IOMTYPE_UIO)

    HCHANTYPE ChanType;
    
    // Enable the transmitter
    FPGA.EnableHartTransmitter(m_ucConnectedChannel, TRUE);
    
    // Since the AI and AO channels don't inherit from a common HART class,
    // switch on the channel type to pull out the information we need.
    switch (BOX->GetInitPntType(m_ucConnectedChannel))
    {
        case PNTTYPE_ANALOGINPUT:
        
            ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        case PNTTYPE_ANALOGOUTPUT:
        
            ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        default:
            // We should never get here...
            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
            break;
    }
#else
    HCHANTYPE ChanType = SLOT(m_ucConnectedChannel)->GetHartChanType();
#endif

    if (HMODEMSTATE_SYNCWAIT == m_ModemState) { 
        // If modem state is SYNCWAIT, it means that the link quiet time has
        // just elapsed and this is the first frame of a new request.
        if (HCHANTYPE_CHANNEL == ChanType) {
            if ((m_ucRetryCount == 0) && (HARTCOMMAND_ZERO == m_ucXmtCommand)) {
                // If transmit command is command zero, device discovery going 
                // on and this is the last retry. Change the polling address to 
                // 0 to speed up the overall device discovery time. Otherwise, 
                // if the device misses the first poll for address 0, it will 
                // have to wait until all 16 addresses are tried. With this 
                // scheme, IOP will poll for address 0 during the last retry 
                // of any other address. NOTE that this scheme assumes the
                // number of retries for command 0 is always greater than one.
                m_ucPollingAddress = HART_MASTER_ADDR_MASK;
            }
        }

        // This is the first frame. Change modem state to XMTING and
        // initialize the context to PREAMBLE. 
        SetState(HMODEMSTATE_XMTING,UART_XMT_FIFO_SIZE);
        ucXmtByteCount = 0; 
        m_XmtRcvContext = XMTRCVCONTEXT_PREAMBLE;
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                m_ucRemPreambles = AIH_SLOT(m_ucConnectedChannel)->GetNoOfPreambleBytes();
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                m_ucRemPreambles = AOH_SLOT(m_ucConnectedChannel)->GetNoOfPreambleBytes();
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }      
#else
        m_ucRemPreambles = SLOT(m_ucConnectedChannel)->GetNoOfPreambleBytes();
#endif
    }

    if (HCHANTYPE_PASSTHROUGH == ChanType) {
        if (ucXmtByteCount < UART_XMT_FIFO_SIZE) { 
            switch (m_XmtRcvContext) {
            case XMTRCVCONTEXT_PREAMBLE:
                while ((m_ucRemPreambles > 0) && (ucXmtByteCount < UART_XMT_FIFO_SIZE)) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
                    ucXmtByteCount++;
                    m_ucRemPreambles--;
                }
                if (ucXmtByteCount >= UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    if (m_ucRemPreambles == 0) { 
                        // all preambles sent
                        m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                    }
                    break;
                }
                // No break for this case. Let the execution fall through 
                // if transmit FIFO is not full.
            case XMTRCVCONTEXT_DATA:
                m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                while ((m_ucBytesInRequest > 0) && (ucXmtByteCount < UART_XMT_FIFO_SIZE)) {
                    // Transmit passthrough bytes.
                    if (m_ucBytesInRequest > 1) {
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = *m_cucpXmtBuffer++; 
                        ucXmtByteCount++;
                    }
                    else {
                        // Transmit the pad character. Pad character is 
                        // required to make sure that check byte is fully 
                        // transmitted before the RTS line is disabled.
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
                        ucXmtByteCount++;
                    }                    
                    m_ucBytesInRequest--;
                }
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,4);
            }
        }
    }
    else if (HCHANTYPE_CHANNEL == ChanType) {  // this is a request from a channel object
        if (ucXmtByteCount < UART_XMT_FIFO_SIZE) { 
            switch (m_XmtRcvContext) {
            case XMTRCVCONTEXT_PREAMBLE:
                while ((m_ucRemPreambles > 0) && (ucXmtByteCount < UART_XMT_FIFO_SIZE)) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
                    ucXmtByteCount++;
                    m_ucRemPreambles--;
                }
                if (ucXmtByteCount >= UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    if (m_ucRemPreambles == 0) {
                        // all preambles sent
                        m_XmtRcvContext = XMTRCVCONTEXT_DELIMITER;
                    }
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_DELIMITER:
                if (HARTCOMMAND_ZERO == m_ucXmtCommand) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_POLLING_DELIMITER; 
                    ucXmtByteCount++;
                    m_ucCheckSum = HART_POLLING_DELIMITER;
                }
                else {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_UNIQUE_DELIMITER; 
                    ucXmtByteCount++;
                    m_ucCheckSum = HART_UNIQUE_DELIMITER;
                }

                if (ucXmtByteCount >= UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_ADDRESS;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_ADDRESS:
                if (HARTCOMMAND_ZERO == m_ucXmtCommand) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_ucPollingAddress; 
                    ucXmtByteCount++;
                    m_ucCheckSum ^= m_ucPollingAddress;
                }
                else {
                    if ((UART_XMT_FIFO_SIZE - ucXmtByteCount) >= HART_LONGADDR_LENGTH) { 
                        // Five FIFO bytes required for unique address. Stack 
                        // will not break unique address into two frames.
                        for (ucAddrByteCount = 0; ucAddrByteCount < HART_LONGADDR_LENGTH;) {
                            HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_UniqueAddress.ucBytes[ucAddrByteCount]; 
                            ucXmtByteCount++;
                            m_ucCheckSum ^= m_UniqueAddress.ucBytes[ucAddrByteCount++];
                        }
                    }
                    else { 
                        // XMT FIFO does not have enough space to completely 
                        // queue up unique address. Let the current bytes in
                        // the FIFO to get transmitted.
                        m_XmtRcvContext = XMTRCVCONTEXT_ADDRESS;
                        break;
                    }
                }
                if (ucXmtByteCount == UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_COMMAND;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_COMMAND:
                HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_ucXmtCommand; 
                ucXmtByteCount++;
                m_ucCheckSum ^= m_ucXmtCommand;
                if (ucXmtByteCount == UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_BYTECOUNT;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_BYTECOUNT:
                // m_ucBytesInRequest is set with Bytecount + 2 to account for
                // the checkbyte and the pad character by the SetState method.
                // For transmitting, use the actual byte count.
                HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = (m_ucBytesInRequest - CHECKPAD_BYTECOUNT); 
                ucXmtByteCount++;
                m_ucCheckSum ^= (m_ucBytesInRequest - CHECKPAD_BYTECOUNT);
                if (ucXmtByteCount == UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_DATA:
                while ((ucXmtByteCount < UART_XMT_FIFO_SIZE) && (m_ucBytesInRequest > 0)) {
                    if (m_ucBytesInRequest > CHECKPAD_BYTECOUNT) {
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = *m_cucpXmtBuffer; 
                        ucXmtByteCount++;
                        m_ucCheckSum ^= *m_cucpXmtBuffer++;
                    }
                    else if (m_ucBytesInRequest == CHECKPAD_BYTECOUNT) { 
                        // Data is over, now transmit the checkbyte
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_ucCheckSum; 
                        ucXmtByteCount++;
                    }
                    else  { 
                        // m_ucBytesInRequest is 1. Request is now complete, 
                        // transmit the pad character. Pad character is 
                        // required to make sure that check byte is fully 
                        // transmitted before the RTS line is disabled.
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE; 
                        ucXmtByteCount++;
                    }

                    m_ucBytesInRequest--;
                }
                m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,5);
            }
        } // if continuation frame
    } // if client type is CHANNEL
    else {
        HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
    }

    // Enable XMT holding register empty interrupt and assert RTS.
    HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 1;
    HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_XMTINTR_ENABLE;

    // Set modem timer with time for FIFO with ucXmtByteCount bytes to become 
    // empty. Add an allowance two byte times.
    m_ucModemTimer = ucXmtByteCount + XMTINT_ALLOWANCE; 

}
/*******************************************************************************
*                        clsHartModem::ProcessResponse                         *
*                        =============================                         *
* PURPOSE:                                                                     *
*    Pre-process the received bytes.                                           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Decode the response and decide the course of action depending on the   *
*       modem state and the received message status.                           *
* NOTES:                                                                       *
*    1. This method is called from HartModemInterrupt when response is         *
*       received without any reception errors.                                 *
*******************************************************************************/
VOID clsHartModem::ProcessResponse(VOID) {
    switch (m_ModemState) {
    case HMODEMSTATE_SYNCWAIT:
        // Activity on the link while waiting for sync. 
        // Decode the message and try to get in sync.
        DecodeResponse();
        // DecodeResponse sets the response status in m_RcvMsgStatus.
        // m_ucBytesInResponse will be the number of bytes left to receive.
        if (HMSGSTATUS_GOOD == m_RcvMsgStatus) {              
            if (0 == m_ucBytesInResponse) {  
                // Message is completely received and the status is good
                ActOnResponse();
                return;
            } 
            else { // Message is good but not complete yet.
                if (m_ucBytesInResponse > UART_RCV_FIFO_SIZE) {
                    m_ucModemTimer = UART_RCV_FIFO_SIZE;
                }
                else {
                    m_ucModemTimer = m_ucBytesInResponse + RCVINT_ALLOWANCE;
                }
            }
        } 
        else { // Message status is not good
            // Flush modem receive buffer
            m_ModemRcvBuffer.Flush();

            // NOTE: The code below is to work around a probable FPGA UART issue
            // which is under investigation with Xilinx. Sometimes FPGA UARTs does
            // not get into break condition, instead keep filling the FIFO with zero
            // characters when the Rx line of the modem is at low state. The work
            // around is to reset and re-intialize the UART and modem.
            HART_UART(m_ucModemNumber).RESET = 1; 
            // Modem control register - Disable RTS.
            HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;

            // Line control register
            // Configure UART for 8 bits per character, odd parity and one stop bit.
            HART_UART(m_ucModemNumber).BITS_PER_CHAR = HART_UART_8BITS_PER_CHAR;
            HART_UART(m_ucModemNumber).PARITY_ENBL = 1; // By default parity is disabled.
            if (HART_UART(m_ucModemNumber).LINE_CTRL_REGISTER != 0x0B) {
                HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
            }
            // FIFO control register - Enable both transmit and receive FIFOs 
            // and configure receive interrupt trigger level of 14 bytes.
            HART_UART(m_ucModemNumber).FIFO_ENBL = 1;
            HART_UART(m_ucModemNumber).RCV_FIFO_TRIG_LEVEL = 3;
            ClearTxRxFIFOs();

            if (HART_UART(m_ucModemNumber).FIFO_CTRL_REGISTER != 0xC1) {
                HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
            }

            // Reset the timer to LINK QUIET time and keep waiting to get sync
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        break;
    case HMODEMSTATE_RCVING:
        DecodeResponse();
        // DecodeResponse sets the response status in m_RcvMsgStatus.
        // m_ucBytesInResponse will be the number of bytes left to receive.
        if (HMSGSTATUS_GOOD == m_RcvMsgStatus) {
            if (m_ucBytesInResponse == 0) {  
                // Message is completely received and the status is good
                ActOnResponse(); 
            }
            else { // Message is good but not complete yet.
                if (m_ucBytesInResponse > UART_RCV_FIFO_SIZE) {
                    m_ucModemTimer = UART_RCV_FIFO_SIZE;
                }
                else {
                    m_ucModemTimer = m_ucBytesInResponse + RCVINT_ALLOWANCE;
                }
            }
        } 
        else { // If message is not good because of some 
            // communication error, log event and retry.
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
                
                    if (HMSGSTATUS_DEVICEERROR == m_RcvMsgStatus) {
                        AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_DEVICEERROR);
                    }
                    else {
                        AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
                    }
                    break;
                    
                case PNTTYPE_ANALOGOUTPUT:
                
                    if (HMSGSTATUS_DEVICEERROR == m_RcvMsgStatus) {
                        AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_DEVICEERROR);
                    }
                    else {
                        AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
                    }
                    break;
                    
                default:
                    // We should never get here...
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
            } 
#else
            if (HMSGSTATUS_DEVICEERROR == m_RcvMsgStatus) {
                SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_DEVICEERROR);
            }
            else {
                SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
            }
#endif            
            SetupRetry(HART_PRIMARY_QUIET_TIME);            
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,6);
    }
}
/*******************************************************************************
*                         clsHartModem::DecodeResponse                         *
*                         ============================                         *
* PURPOSE:                                                                     *
*    Peform framing of the response message and return the response to client. *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Check each byte in the modem receive FIFO and perform the framing of   *
*       the response as per HART data link layer specification.                *
*    2. Set message status and number of bytes left to receive in the modem    *
*       class memmbers m_RcvMsgStatus and m_ucBytesInResponse respectively.    *
*    3. Copy appropriate part of the response message to the client receive    *
*       buffer. For passthrough objects, entire response message except the    *
*       preamble bytes is copied. For channel objects only the message from    *
*       byte count field is copied.                                            *
* NOTES:                                                                       *
*    1. This method is called from ProcessResponse method.                     *
*******************************************************************************/
VOID clsHartModem::DecodeResponse(VOID) {
    UINT8 ucCount,ucRcvChar;

    if (HMSGSTATUS_BAD == m_RcvMsgStatus) {
        m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
    }

#if defined(IOMTYPE_UIO)
    HCHANTYPE ChanType;
    
    // Since the AI and AO channels don't inherit from a common HART class,
    // switch on the channel type to pull out the information we need.
    switch (BOX->GetInitPntType(m_ucConnectedChannel))
    {
        case PNTTYPE_ANALOGINPUT:
        
            ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        case PNTTYPE_ANALOGOUTPUT:
        
            ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        default:
            // We should never get here...
            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
            break;
    }
#else
    HCHANTYPE ChanType = SLOT(m_ucConnectedChannel)->GetHartChanType();
#endif
    while (m_ModemRcvBuffer.GetLength() > 0) { 
        switch (m_XmtRcvContext) {
        case XMTRCVCONTEXT_UNKNOWN:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (ucRcvChar == HART_PREAMBLE_BYTE) {
                m_ucRemPreambles = HART_MIN_PREAMBLES - 1;
                m_RcvMsgStatus = HMSGSTATUS_GOOD;
                m_XmtRcvContext = XMTRCVCONTEXT_PREAMBLE;
            }
            else { // start preamble detection again
                m_ucRemPreambles = HART_MIN_PREAMBLES; 
                m_RcvMsgStatus = HMSGSTATUS_BAD;
            }
            break;
        case XMTRCVCONTEXT_PREAMBLE:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (ucRcvChar == HART_PREAMBLE_BYTE) {
                m_RcvMsgStatus = HMSGSTATUS_GOOD;
                m_ucRemPreambles--;
                if (m_ucRemPreambles == 0) {
                    m_XmtRcvContext = XMTRCVCONTEXT_DELIMITER;
                }
            }
            else { // start preamble detection again
                m_ucRemPreambles = HART_MIN_PREAMBLES;
                m_RcvMsgStatus = HMSGSTATUS_BAD;
                m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
            }
            break;
        case XMTRCVCONTEXT_DELIMITER:
            {
                BOOL bTestedGood = TRUE;
                m_ucRcvdDelimiter = 0;
                ucRcvChar = m_ModemRcvBuffer.PopChar();
                // Preambles may not be complete even now. Take these out.
                if (ucRcvChar != HART_PREAMBLE_BYTE) {
                    m_ucRcvdDelimiter = ucRcvChar;

                    // Decode number of expansion bytes to ucRcvChar 
                    ucRcvChar = ((m_ucRcvdDelimiter & HART_EXPANSION_BYTE_MASK) >> HART_EXPANSION_BYTE_SHIFTS); 
                    if (ucRcvChar > 0) {
                        // Expansion bytes should be zero.
                        bTestedGood = FALSE;
                    }

                    // Check physical layer type set the status to bad if any of 
                    // the bit is set. Asynchronous physical layer value is zero.
                    if (m_ucRcvdDelimiter & HART_PHYSICAL_LAYER_MASK) {
                        bTestedGood = FALSE;
                    }

                    // Decode frame type to ucRcvChar
                    ucRcvChar = m_ucRcvdDelimiter & HART_FRAME_TYPE_MASK;
                    if ((bTestedGood == TRUE) && ((ucRcvChar == HART_FRAME_TYPE_ACK) ||
                         (ucRcvChar == HART_FRAME_TYPE_STX) || (ucRcvChar == HART_FRAME_TYPE_BACK))) {
                        // A valid delimiter is received
                        m_ucCheckSum = m_ucRcvdDelimiter; // Checksum starts here
                        if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                            (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                            // Since the AI and AO channels don't inherit from a common HART class,
                            // switch on the channel type to pull out the information we need.
                            switch (BOX->GetInitPntType(m_ucConnectedChannel))
                            {
                                case PNTTYPE_ANALOGINPUT:
                                
                                    AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = m_ucRcvdDelimiter;
                                    break;
                                    
                                case PNTTYPE_ANALOGOUTPUT:
                                
                                    AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = m_ucRcvdDelimiter;
                                    break;
                                    
                                default:
                                    // We should never get here...
                                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                    break;
                            }
#else
                            SLOT(m_ucConnectedChannel)->GetRcvBufObject() = m_ucRcvdDelimiter;
#endif
                        }
                        m_XmtRcvContext = XMTRCVCONTEXT_ADDRESS;
                    }
                    else { // If not a valid delimiter,
                        //  start preamble detection again
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                        m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
                        m_ucRemPreambles = HART_MIN_PREAMBLES;
                    }
                }
            }
            break;        
        case XMTRCVCONTEXT_ADDRESS:
            {
                BOOL bToMe = TRUE;
                HARTUNIQUEADDR unique;
                UINT8 ucPolAddr;

                // Start of message is successfully detected now.
                // Set the message status to good and decode rest of the message.
                m_RcvMsgStatus = HMSGSTATUS_GOOD;
                m_bBurstDeviceFound = FALSE; 

                // Validate the address in the response.
                if (m_ucRcvdDelimiter & HART_ADDR_TYPE_MASK) { 
                    // This response has unique address. Check whether entire 
                    // address is received or not.
                    if (m_ModemRcvBuffer.GetLength() < HART_LONGADDR_LENGTH) {
                        // Wait until full address is there in modem receive buffer.
                        return;
                    }

                    for (ucCount = 0; ucCount < HART_LONGADDR_LENGTH; ucCount++) {
                        unique.ucBytes[ucCount] = m_ModemRcvBuffer.PopChar();
                        m_ucCheckSum ^= unique.ucBytes[ucCount];
                        if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                            (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                            // Since the AI and AO channels don't inherit from a common HART class,
                            // switch on the channel type to pull out the information we need.
                            switch (BOX->GetInitPntType(m_ucConnectedChannel))
                            {
                                case PNTTYPE_ANALOGINPUT:
                                
                                    AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = unique.ucBytes[ucCount];
                                    break;
                                    
                                case PNTTYPE_ANALOGOUTPUT:
                                
                                    AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = unique.ucBytes[ucCount];
                                    break;
                                    
                                default:
                                    // We should never get here...
                                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                    break;
                            }                           
#else
                            SLOT(m_ucConnectedChannel)->GetRcvBufObject() = unique.ucBytes[ucCount];
#endif
                        }

                        if (ucCount == 0) {
                            if (HMODEMSTATE_RCVING == m_ModemState) {
                                if ((m_UniqueAddress.ucBytes[ucCount] & HART_MANUFACTURE_ID_MASK) != 
                                    (unique.ucBytes[ucCount] & HART_MANUFACTURE_ID_MASK)) {
                                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                                }
                            }
                            if (!(unique.ucBytes[ucCount] & HART_MASTER_ADDR_MASK)) {
                                bToMe = FALSE;
                            }
                            if (unique.ucBytes[ucCount] & HART_BURST_MODE_MASK) {
                                m_bBurstDeviceFound = TRUE;
                            }
                        }
                        else if (HMODEMSTATE_RCVING == m_ModemState) {
                            if (m_UniqueAddress.ucBytes[ucCount] != unique.ucBytes[ucCount]) {
                                m_RcvMsgStatus = HMSGSTATUS_BAD;
                            }
                        }
                    }
                }
                else { // polling address in the response
                    ucPolAddr = m_ModemRcvBuffer.PopChar();
                    m_ucCheckSum ^= ucPolAddr;
                    if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                        (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                        // Since the AI and AO channels don't inherit from a common HART class,
                        // switch on the channel type to pull out the information we need.
                        switch (BOX->GetInitPntType(m_ucConnectedChannel))
                        {
                            case PNTTYPE_ANALOGINPUT:
                            
                                AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucPolAddr;
                                break;
                                
                            case PNTTYPE_ANALOGOUTPUT:
                            
                                AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucPolAddr;
                                break;
                                
                            default:
                                // We should never get here...
                                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                break;
                        }                     
#else
                        SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucPolAddr;
#endif
                    }
                    if (HMODEMSTATE_RCVING == m_ModemState) {
                        if ((ucPolAddr & HART_MANUFACTURE_ID_MASK) != 
                            (m_ucPollingAddress & HART_MANUFACTURE_ID_MASK)) {
                            m_RcvMsgStatus = HMSGSTATUS_BAD;
                        }
                    }
                    if (!(ucPolAddr & HART_MASTER_ADDR_MASK)) {
                        bToMe = FALSE;
                    }
                    if (ucPolAddr & HART_BURST_MODE_MASK) {
                        m_bBurstDeviceFound = TRUE;
                    }
                }

                // Determine the frame type.
                switch (m_ucRcvdDelimiter & HART_FRAME_TYPE_MASK) {
                case HART_FRAME_TYPE_BACK:
                    m_bBurstDeviceFound = TRUE;
                    if (TRUE == bToMe) {
                        m_RcvMsgType = HMSGTYPE_BACKTOME;
                    }
                    else {
                        m_RcvMsgType = HMSGTYPE_BACKTOHIM;
                    }
                    break;
                case HART_FRAME_TYPE_STX:
                    if (TRUE == bToMe) {
                        m_RcvMsgType = HMSGTYPE_STXFROMME;
                    }
                    else {
                        m_RcvMsgType = HMSGTYPE_STX;
                    }
                    break;
                case HART_FRAME_TYPE_ACK:
                    if (TRUE == bToMe) {
                        m_RcvMsgType = HMSGTYPE_ACKTOME;
                    }
                    else {
                        m_RcvMsgType = HMSGTYPE_ACKTOHIM;
                    }
                    break;
                default:
                    // Invalidate receive message status and return. 
                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                    return;
                }

                // If delimiter is all fine, decode command field.
                m_XmtRcvContext = XMTRCVCONTEXT_COMMAND;
            }
            break;
        case XMTRCVCONTEXT_COMMAND:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (HMODEMSTATE_RCVING == m_ModemState) {
                if (m_ucXmtCommand != ucRcvChar) {
                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                }
            }

            m_ucCheckSum ^= ucRcvChar;
            if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }                
#else
                SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
            }
            m_XmtRcvContext = XMTRCVCONTEXT_BYTECOUNT;
            break;
        case XMTRCVCONTEXT_BYTECOUNT:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (HMODEMSTATE_RCVING == m_ModemState) {
                if (ucRcvChar < HART_MIN_RESPONSE_BYTECOUNT) {
                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                }
#if defined(IOMTYPE_UIO)
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }           
#else
                SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
            }
            m_ucBytesInResponse = ucRcvChar + 1; // +1 to account for check byte
            m_ucCheckSum ^= ucRcvChar;
            if (HMSGTYPE_STX == m_RcvMsgType) {
                m_XmtRcvContext = XMTRCVCONTEXT_DATA;
            }
            else {
                m_XmtRcvContext = XMTRCVCONTEXT_STATUS;
            }
            break;
        case XMTRCVCONTEXT_STATUS:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            m_ucBytesInResponse--;
            if (m_ucBytesInResponse == 0) {
                m_RcvMsgStatus = HMSGSTATUS_BAD;
                return;
            }
            if (HMODEMSTATE_RCVING == m_ModemState) {
#if defined(IOMTYPE_UIO)
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }
#else
                SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
                if (ucRcvChar & HART_COMMN_STATUS_BIT) {
                    m_RcvMsgStatus = HMSGSTATUS_DEVICEERROR;
                }
            }            
            m_ucCheckSum ^= ucRcvChar;
            m_XmtRcvContext = XMTRCVCONTEXT_DATA;
            break;
        case XMTRCVCONTEXT_DATA:
            // m_RcvMsgType is already set and message is decoded upto 
            // byte count field Pending message length m_ucBytesInResponse
            // is also set now If m_ucBytesInResponse == 1 then verify the 
            // checksum. 
            if (m_ucBytesInResponse > 0)  {
                if (m_ucBytesInResponse > 1) {
                    ucRcvChar = m_ModemRcvBuffer.PopChar();
                    m_ucBytesInResponse--;
                    if (HMODEMSTATE_RCVING == m_ModemState) {
#if defined(IOMTYPE_UIO)
                        // Since the AI and AO channels don't inherit from a common HART class,
                        // switch on the channel type to pull out the information we need.
                        switch (BOX->GetInitPntType(m_ucConnectedChannel))
                        {
                            case PNTTYPE_ANALOGINPUT:
                            
                                AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            case PNTTYPE_ANALOGOUTPUT:
                            
                                AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            default:
                                // We should never get here...
                                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                break;
                        }
#else
                        SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
                    }
                    m_ucCheckSum ^= ucRcvChar;
                }
                else {    // this is the checkbyte. verify checksum
                    ucRcvChar = m_ModemRcvBuffer.PopChar();
                    m_ucBytesInResponse--;
                    if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                        (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                        // Since the AI and AO channels don't inherit from a common HART class,
                        // switch on the channel type to pull out the information we need.
                        switch (BOX->GetInitPntType(m_ucConnectedChannel))
                        {
                            case PNTTYPE_ANALOGINPUT:
                            
                                AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            case PNTTYPE_ANALOGOUTPUT:
                            
                                AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            default:
                                // We should never get here...
                                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                break;
                        }
#else
                        SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
                    }
                    if ((ucRcvChar != m_ucCheckSum)) {
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                    }

                    // At this point a message is completely processed.
                    // Break the while loop and return.
                    return;
                }
            }
            break;   
        default: 
            TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,7);
        }
    }
}
/*******************************************************************************
*                         clsHartModem::ActOnResponse                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
*    Post process the response message.                                        *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If STX is received, it means secondary master is there. Set modem to   *
*       SYNCWAIT with link quiet time to wait for ACK from device.             *
*    2. If ACK is received for a request just send, pass it to the client. If  *
*       the state is SYNCWAIT, setup link grant time to allow secondary master *
*       to start it transmission.                                              *
*    3. If an ACK or BACK to secondary master is received, start trasmission   *
*       of the request immediately.                                            *
*    4. If the device was found to be in burst mode, schedule command 109 to   *
*       turn off the burst mode.                                               *
* NOTES:                                                                       *
*    1. This method is called from ProcessResponse method when a good message  *
*       is completely received.                                                *
*******************************************************************************/
VOID clsHartModem::ActOnResponse(VOID) {
// AF: Review this function.  A lot is done with HART PST
    switch (m_RcvMsgType) {
    case HMSGTYPE_STX:
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }
        
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
#endif
        if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        else { // HMODEMSTATE_RCVING
            m_RcvMsgStatus = HMSGSTATUS_BAD;
            SetupRetry(HART_PRIMARY_QUIET_TIME);
        }
        break;
    case HMSGTYPE_ACKTOME:
        if (TRUE == m_bBurstDeviceFound) {
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
                
                    AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    break;
                    
                case PNTTYPE_ANALOGOUTPUT:
                
                    AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    break;
                    
                default:
                    // We should never get here...
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
            }
#else
            SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
#endif
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        else {
            if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                SetState(HMODEMSTATE_SYNCWAIT,HART_LINK_GRANT_TIME);
            }
            else { // HMODEMSTATE_RCVING
                // Good response. Submit the response to the client.
                
#if defined(IOMTYPE_UIO)
                HCHANTYPE ChanType;
                
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }  
#endif

                if ((m_ucRetryCount == 0) && (HARTCOMMAND_ZERO == m_ucXmtCommand)) {
                    // If command zero was successful in the last retry, reset the 
                    // polling address in DevDb so that command 6 will be not be issued.
#if defined(IOMTYPE_UIO)    
                    // Since the AI and AO channels don't inherit from a common HART class,
                    // switch on the channel type to pull out the information we need.
                    switch (BOX->GetInitPntType(m_ucConnectedChannel))
                    {
                        case PNTTYPE_ANALOGINPUT:
                        
                            AIH_SLOT(m_ucConnectedChannel)->SetPollingAddress(0);
                            break;
                            
                        case PNTTYPE_ANALOGOUTPUT:
                        
                            AOH_SLOT(m_ucConnectedChannel)->SetPollingAddress(0);
                            break;
                            
                        default:
                            // We should never get here...
                            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                            break;
                    }                
#else
                    SLOT(m_ucConnectedChannel)->SetPollingAddress(0);
#endif
                }

#if defined(IOMTYPE_UIO)
                HSYNCSTATUS receptionComplete = HSYNCSTATUS_UNKNOWN;
                
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                        receptionComplete = 
                            AIH_SLOT(m_ucConnectedChannel)->ReceptionComplete(m_RcvMsgStatus);
                        break;
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        receptionComplete =
                            AOH_SLOT(m_ucConnectedChannel)->ReceptionComplete(m_RcvMsgStatus);
                        break;
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }  
                
                if (HSYNCSTATUS_KEEP_SYNC == receptionComplete) {
                    // If Client wants stack to continue with a back-to-back message. 
                    ClearTxRxFIFOs();
                    SetState(HMODEMSTATE_SYNCWAIT,HART_LINK_GRANT_TIME);

                    // Since the AI and AO channels don't inherit from a common HART class,
                    // switch on the channel type to pull out the information we need.
                    switch (BOX->GetInitPntType(m_ucConnectedChannel))
                    {
                        case PNTTYPE_ANALOGINPUT:
                             m_ucRetryCount = AIH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                            break;
                        case PNTTYPE_ANALOGOUTPUT:                        
                             m_ucRetryCount = AOH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                            break;
                        default:
                            // We should never get here...
                            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                            break;
                    }
#else
                if (HSYNCSTATUS_KEEP_SYNC == SLOT(m_ucConnectedChannel)->ReceptionComplete(m_RcvMsgStatus)) {
                    // If Client wants stack to continue with a back-to-back message. 
                    ClearTxRxFIFOs();
                    SetState(HMODEMSTATE_SYNCWAIT,HART_LINK_GRANT_TIME);
                    m_ucRetryCount = SLOT(m_ucConnectedChannel)->GetRetryCount();
#endif
                    if (m_ucRetryCount > HART_MAX_RETRIES) {
                        m_ucRetryCount = HART_MAX_RETRIES;
                    }
                }
                else 
                {                    
#if defined(IOMTYPE_UIO)
                    // Client does not have any new request. 
                    // Disconnect and check for any pass through requests.
                    
                    // Save the priority
                    UINT8 ucSaveExr = get_imask_exr();
                    
                    Disconnect(FALSE);
                    
                    // Check for previous transaction type
                    // If it was DYN or DEV or C48, check for FDM sessions
                    if(HCHANTYPE_CHANNEL == ChanType) 
                    {
                        if(BOX->PassthroughInQueue(m_ucModemNumber) != FALSE) 
                        {
                            // Search for Pass through and set up pass through request if present
                            BOX->SearchForPassthrough(m_ucModemNumber);
                        }
                    }
                    else 
                    {   
                        // If Previous Channel type was PST
                        if(BOX->bMultiplePSTPresent[m_ucModemNumber] == TRUE) 
                        {
                            // Search for other PST, do not calculate for back to back pst's count
                            // while performing multiple pst's
                            BOX->SearchForPassthrough(m_ucModemNumber, FALSE);
                            if(!BOX->usChannelsWithPST[m_ucModemNumber]) 
                            {
                                BOX->bMultiplePSTPresent[m_ucModemNumber] = FALSE;
                                // Channels with pst is made one so that, multiple pst present will not be
                                // set for one FDM session
                                BOX->usChannelsWithPST[m_ucModemNumber] = (UINT16)1;
                            }
                        }
                        else
                        {
                            BOX->usChannelsWithPST[m_ucModemNumber] = (UINT16)1;
                        }
                    }
                    // PST can be scheduled from two places, one after any channel disconnect (in HartStack.cpp)
                    // other when modem is idle (in Hart.cpp), Hart task in Hart.cpp has priority (5) and
                    // ActOnResponse function in HartStack.cpp (3), immediately after disconnect function if
                    // Hart task gets executed, then Hart task tries to schedule PST (because modem is idle after disconnect) 
                    // and after its execution ActOnResponse function also to tries to schedule PST, 
                    // to prevent this case, m_bHartStackProc variable is used to avoid Hart task from scheduling PST,
                    // its value is made true in Disconnect function and made false after PST scheduling by ActOnResponse
                    
                    // Temporarily raise priority to update m_bHartStackProc
                    set_imask_exr(LVLPRI_TICK);
                    m_bHartStackProc = FALSE;
                    
                    // Restore priority
                    set_imask_exr(ucSaveExr);
#else
                    // Client does not have any new request.
                    Disconnect();
#endif
                }
            }
        }
        break;
        
    case HMSGTYPE_ACKTOHIM:
#if defined(IOMTYPE_UIO) 
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                if (TRUE == m_bBurstDeviceFound) {
                    AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
                }
                else {
                    if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                        TransmitRequest();
                    }
                    else {
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                        SetupRetry(HSYNC_MINIMUM_TIME);
                    }
                }
                    
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                if (TRUE == m_bBurstDeviceFound) {
                    AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
                }
                else {
                    if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                        TransmitRequest();
                    }
                    else {
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                        SetupRetry(HSYNC_MINIMUM_TIME);
                    }
                }
                
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
        if (TRUE == m_bBurstDeviceFound) {
            SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        else {
            if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                TransmitRequest();
            }
            else {
                m_RcvMsgStatus = HMSGSTATUS_BAD;
                SetupRetry(HSYNC_MINIMUM_TIME);
            }
        }
#endif
        break;
    case HMSGTYPE_BACKTOHIM:
        // BACK to SecMaster just finished. We have the token now.
        // Note that the LogEvent will setup command 109 as the 
        // next command for this channel to turn off the burst mode.
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
#endif
        if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
            TransmitRequest();
        }
        else {
            SetState(HMODEMSTATE_SYNCWAIT,HSYNC_MINIMUM_TIME);
        }
        break; 
    case HMSGTYPE_BACKTOME:
        // A BACK message to me just finished. The token is now with 
        // the secondary master even if it is present or not. Remain 
        // in sync with link quiet timer. 
        // Note that the LogEvent will setup command 109 as the 
        // next command for this channel to turn off the burst mode.
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
#endif
        SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        break;
    case HMSGTYPE_STXFROMME:
        // STXFROMME is totally unexpected. This means another primary 
        // master in the network. Log error and disconnect.
        m_RcvMsgStatus = HMSGSTATUS_BAD;
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_PRIMASTER);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_PRIMASTER);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_PRIMASTER);
#endif
        SetupRetry(HART_PRIMARY_QUIET_TIME);
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,8);
    }                
}
/*******************************************************************************
*                          clsHartModem::SetupRetry                            *
*                          ========================                            *
* PURPOSE:                                                                     *
*    Prepare the modem object for retrying the request.                        *
* ARGUMENTS:                                                                   *
*    1. a_ucWaitTime - wait time in in HART char interval before request is    *
*                      transmitted.                                            *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If retry count is greater than zero, setup for retry.                  *
*    2. If retry count is zero, notify the client with failed status.          *
* NOTES:                                                                       *
*    1. This method is called from the following methods - HandleReceiveError, *
*       ModemTimeout, ProcessResponse and ActOnResponse.                       *
*******************************************************************************/
VOID clsHartModem::SetupRetry(UINT8 a_ucWaitTime) {
    // Invalidate current receive message.
    m_RcvMsgStatus = HMSGSTATUS_BAD;
    // Flush the modem buffer.
    m_ModemRcvBuffer.Flush();

    if (m_ucRetryCount > 0) {
        m_ucRetryCount--;
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);
#endif
        SetState(HMODEMSTATE_SYNCWAIT,a_ucWaitTime);
#if defined(IOMTYPE_UIO)

        // Factory Test support
        // Check for factory test in progress flag. if it is set, change the state to warning
        if(TRUE == HartLoopBkTestInProgress) 
        {
            BOX->SetLpBkStat(LOOPBACK_WARNING);
        }
#endif
    }
    else { 
        // Submit the reply with BAD status to the client.
#if defined(IOMTYPE_UIO)
        HSYNCSTATUS hStatus = HSYNCSTATUS_UNKNOWN;
        UINT8 retryCount = 0;
        
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:

                hStatus = AIH_SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD); 
                retryCount = AIH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                break;

            case PNTTYPE_ANALOGOUTPUT:
            
                hStatus = AOH_SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD);
                retryCount = AOH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                break;

            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }
        
        if (HSYNCSTATUS_KEEP_SYNC == hStatus) {
            ClearTxRxFIFOs();
            SetState(HMODEMSTATE_SYNCWAIT,a_ucWaitTime);
            // Re-initialize retry count
            m_ucRetryCount = retryCount;
            if (m_ucRetryCount > HART_MAX_RETRIES) {
                m_ucRetryCount = HART_MAX_RETRIES;
            }
        }
        else {
            Disconnect();
        }
#else
        if (HSYNCSTATUS_KEEP_SYNC == SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD)) {
            ClearTxRxFIFOs();
            SetState(HMODEMSTATE_SYNCWAIT,a_ucWaitTime);
            // Re-initialize retry count
            m_ucRetryCount = SLOT(m_ucConnectedChannel)->GetRetryCount();
            if (m_ucRetryCount > HART_MAX_RETRIES) {
                m_ucRetryCount = HART_MAX_RETRIES;
            }
        }
        else {
            Disconnect();
        }
#endif        
    }
}
/*******************************************************************************
*                       clsHartModem::HandleReceiveError                       *
*                       ================================                       *
* PURPOSE:                                                                     *
*    Decide what to do when a receive error is reported by the UART.           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If modem state is idle or bad, return.                                 *
*    2. If modem state is SYNCWAIT, reset the link timer.                      *
*    3. If modem state is RCVING, setup for retry.                             *
* NOTES:                                                                       *
*    1. This method is called from ModemInterrupts.                            *
*******************************************************************************/
VOID clsHartModem::HandleReceiveError(VOID) {
    switch (m_ModemState) {
    case HMODEMSTATE_BAD:
    case HMODEMSTATE_IDLE:
        return;
    case HMODEMSTATE_SYNCWAIT:
        // Acitivity in the channel while waiting to get in sync.
        // Reset m_ucModemTimer to LINK QUIET TIME and continue to wait.
        m_ModemRcvBuffer.Flush();
        m_ucModemTimer = HART_PRIMARY_QUIET_TIME;
        break;
    case HMODEMSTATE_RCVWAIT:
    case HMODEMSTATE_RCVING:
        // RCVERROR while getting a reply. Setup for retry.
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);               
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }         
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
#endif
        SetupRetry(HART_PRIMARY_QUIET_TIME);
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,9);
    }
}

clsClientBuffer::clsClientBuffer(UINT16 a_usBufSize, UINT8 *a_ucpBuf) :
    m_BUFSIZE(a_usBufSize),
    m_ucpBuffer(a_ucpBuf),
    m_usIndex(0)
{
    Flush();
}

VOID clsClientBuffer::Flush(VOID)
{
    for (m_usIndex = 0; m_usIndex < m_BUFSIZE; m_usIndex++)
    {
        m_ucpBuffer[m_usIndex] = 0;
    }
    m_usIndex = 0;
}

UINT8 clsClientBuffer::At(UINT16 a_usIndex)
{
    return (a_usIndex < m_BUFSIZE) ? m_ucpBuffer[a_usIndex] : 0;
}

UINT8 *clsClientBuffer::AddrAt(UINT16 a_usIndex)
{
    return (a_usIndex < m_BUFSIZE) ? &m_ucpBuffer[a_usIndex] : NULL;
}

clsClientBuffer& clsClientBuffer::operator=(const UINT8 a_ucData)
{
    if (m_usIndex < m_BUFSIZE)
    {
        m_ucpBuffer[m_usIndex++] = a_ucData;
    }
    return *this;
}

clsModemBuffer::clsModemBuffer(VOID)
{
    Flush();
}

unsigned short clsModemBuffer::GetLength(void)
{
    return m_ucCount;
}

VOID clsModemBuffer::Flush(VOID)
{
    m_ucpAppend = m_ucpRemove = m_ucBuffer;
    while (m_ucpAppend < (m_ucBuffer + HARTMODEM_BUFFER_SIZE))
    {
        *m_ucpAppend++ = 0;
    }
    m_ucpAppend = m_ucpRemove;
    m_ucCount = 0;
}

UINT8 clsModemBuffer::PopChar(VOID)
{
    UINT8 ucChar = *m_ucpRemove;
    if (m_ucCount > 0)
    {
        *m_ucpRemove++ = 0;
        m_ucCount--;
        if (m_ucpRemove == (m_ucBuffer + HARTMODEM_BUFFER_SIZE))
        {
            m_ucpRemove = m_ucBuffer;
        }
    }
    return ucChar;
}

VOID clsModemBuffer::ThrowLastRcvd(VOID)
{
    if (m_ucCount > 0)
    {
        *m_ucpAppend = 0;
        m_ucCount--;
        if (m_ucpAppend == m_ucBuffer)
        {
            m_ucpAppend = m_ucBuffer + HARTMODEM_BUFFER_SIZE - 1;
        }
        else
        {
            m_ucpAppend--;
        }
    }
}

clsModemBuffer& clsModemBuffer::operator=(const UINT8 a_cucData)
{
    if (m_ucCount < HARTMODEM_BUFFER_SIZE)
    {
        *m_ucpAppend++ = a_cucData;
        m_ucCount++;
        if (m_ucpAppend == (m_ucBuffer + HARTMODEM_BUFFER_SIZE))
        {
            m_ucpAppend = m_ucBuffer;
        }
    }
    return *this;
}

VOID clsHartModem::ReinstateModem(VOID)
{
    m_ucModemDiagCount++;
    m_ModemState = HMODEMSTATE_SYNCWAIT;
    m_ucModemTimer = HART_LINK_GRANT_TIME;
    m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT;
}

VOID clsHartModem::SetModemBad(VOID)
{
    UINT8 failedChannel = m_ucConnectedChannel;
    Disconnect();
    m_ucFailedChannel = failedChannel;
    m_ModemState = HMODEMSTATE_BAD;
}

VOID clsHartModem::ClearModemBad(VOID)
{
    m_ucFailedChannel = 0;
    if (m_ModemState == HMODEMSTATE_BAD)
    {
        m_ModemState = HMODEMSTATE_IDLE;
    }
}

VOID clsHartModem::ClearTxRxFIFOs(VOID)
{
    /* 16550 FCR: enable FIFO, clear RX/TX, keep 14-byte RX trigger. */
    HART_UART(m_ucModemNumber).FIFO_CTRL_REGISTER = 0xC7u;
    HART_UART(m_ucModemNumber).FIFO_CTRL_REGISTER = 0xC1u;
    m_ModemRcvBuffer.Flush();
}


#define HART_STACK_DEFAULT_CHANNEL        (16u)
#define HART_STACK_DEFAULT_MODEM          (3u)
#define HART_POLL_ADDR_START           (0u)
#define HART_POLL_ADDR_END             (0u)

#define HART_CMD0_RETRY_COUNT           (5u)

#define HART_MODEM_HEARTBEAT_LOOPS     (920000u)

#define HART_SYNCWAIT_TICKS            (8u)
#define HART_RCVWAIT_TICKS             (80u)
#define HART_RCVING_IDLE_TICKS         (35u)

#define HART_RESET_HOLD_LOOPS          (250000u)
#define HART_RESET_SETTLE_LOOPS        (600000u)
#define HART_MUX_SETTLE_LOOPS          (200000u)
#define HART_RTS_PRE_TX_TICKS          (2u)
#define HART_TX_TO_RX_GUARD_TICKS      (2u)

#define HART_INITIAL_MAR           ((UINT16)HART_DEFAULT_MAR_CH1_M0)
#define HART_INITIAL_MER           ((UINT8)HART_DEFAULT_MER_NONE)


typedef enum
{
    HART_MODEM_IDLE = 0,
    HART_MODEM_SYNCWAIT,
    HART_MODEM_XMITTING,
    HART_MODEM_RCVWAIT,
    HART_MODEM_RCVING,
    HART_MODEM_DONE,
    HART_MODEM_TIMEOUT,
    HART_MODEM_BAD
} HartModemState_t;

typedef struct
{
    UINT8 modem;
    UINT8 channel;
    UINT8 pollAddr;

    UINT8 txFrame[32];
    UINT32 txLen;
    UINT32 txIndex;

    UINT8 rxBuf[128];          /* cleaned bytes used by parser */
    UINT32 rxCount;
    UINT32 rxRawCount;
    UINT32 rxExpectedLen;
    UINT32 preambleCount;

    HartModemState_t state;
    UINT32 tickInState;
    UINT32 totalTicks;

    bool sawDcd;
    bool completed;
} HartModemObject_t;

typedef struct
{
    bool useLongAddress;
    UINT8 command;
    UINT8 pollAddr;
    UINT8 longAddr[5];
    UINT8 data[16];
    UINT8 dataLen;
} HartRequest_t;

static HartRequest_t g_HartRequest;

static UINT16 m_usHartMuxAddr = HART_INITIAL_MAR;
static UINT8  m_ucHartMuxEnbl = HART_INITIAL_MER;
static UINT8  m_ucConnectedChannel = HART_STACK_DEFAULT_CHANNEL;
static UINT8  m_ucModemNumber = HART_STACK_DEFAULT_MODEM;
static UINT8  m_ucRemPreambles = 0u;
static BOOL   g_bLastTransactionSawDcd = FALSE;
static UINT32 g_ulLastTransactionRawCount = 0u;

static const UINT8 g_uartReset[UART_COUNT] =
{
    UART0_RESET,
    UART1_RESET,
    UART2_RESET,
    UART3_RESET
};

/*******************************************************************************
* Delay
*******************************************************************************/
static void HartStackIdleWait(volatile UINT32 loops)
{
    while (loops-- > 0u)
    {
        __asm volatile ("nop");
    }
}

static void HartCharacterDelayTicks(UINT32 ticks)
{
    for (UINT32 i = 0u; i < ticks; i++)
    {
        HartStackIdleWait(HART_MODEM_HEARTBEAT_LOOPS);
    }
}

/*******************************************************************************
* FPGA helpers
*******************************************************************************/
static UINT16 Read16(UINT8 addr)
{
    return hal_fpga_read(addr);
}

static UINT8 Read8(UINT8 addr)
{
    return (UINT8)((Read16(addr) >> 8) & 0xFFu);
}

static void Write16(UINT8 addr, UINT16 value)
{
    hal_fpga_write(addr, value);
}

static void Write8(UINT8 addr, UINT8 value)
{
    hal_fpga_write(addr, (UINT16)((UINT16)value << 8));
}

static UINT8 UartReadRegAddr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_READ_BASE(modem) + reg);
}

static UINT8 UartWriteRegAddr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_WRITE_BASE(modem) + reg);
}

static UINT8 UartRead8(UINT8 modem, UINT8 reg)
{
    return Read8(UartReadRegAddr(modem, reg));
}


static UINT8 UartReadStatus8(UINT8 modem, UINT8 reg)
{
    UINT8 a = UartRead8(modem, reg);
    UINT8 b = UartRead8(modem, reg);
    UINT8 c = UartRead8(modem, reg);

    if (a == b) { return a; }
    if (a == c) { return a; }
    return c;
}

static void UartWrite8(UINT8 modem, UINT8 reg, UINT8 value)
{
    Write8(UartWriteRegAddr(modem, reg), value);
}

static void UartForceNormalLineMode(UINT8 modem)
{
    UartWrite8(modem, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    HartStackIdleWait(1200u);
}

static void ResetUartAndHartModem(UINT8 modem)
{

    Write8(g_uartReset[modem], 0x01u);
    HartStackIdleWait(HART_RESET_HOLD_LOOPS);

    Write8(g_uartReset[modem], 0x00u);
    HartStackIdleWait(HART_RESET_SETTLE_LOOPS);
}

static void ClearTxRxFIFOs(UINT8 modem)
{
    UartWrite8(modem, UART_IIR_FCR, 0xC7u);
    HartStackIdleWait(8000u);
    UartWrite8(modem, UART_IIR_FCR, 0xC1u);
    HartStackIdleWait(8000u);

    for (UINT32 guard = 0u; guard < 256u; guard++)
    {
        if ((UartReadStatus8(modem, UART_LSR) & UART_LSR_DR) == 0u)
        {
            break;
        }

        (void)UartRead8(modem, UART_RBR_THR);
    }
}

static void InitUart(UINT8 modem)
{
    ResetUartAndHartModem(modem);

    UartWrite8(modem, UART_MCR, 0x00u);   /* /RTS inactive high */
    UartWrite8(modem, UART_IER, 0x00u);
    UartWrite8(modem, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    ClearTxRxFIFOs(modem);
    UartWrite8(modem, UART_SCR, 0xDBu);
    HartStackIdleWait(20000u);

}

static bool WaitTxReady(UINT8 modem)
{
    for (UINT32 guard = 0u; guard < 150000u; guard++)
    {
        if ((UartReadStatus8(modem, UART_LSR) & UART_LSR_THRE) != 0u)
        {
            return true;
        }
    }

    return false;
}

static bool WaitTxEmpty(UINT8 modem)
{
    for (UINT32 guard = 0u; guard < 350000u; guard++)
    {
        UINT8 lsr = UartReadStatus8(modem, UART_LSR);

        if ((lsr & (UART_LSR_THRE | UART_LSR_TEMT)) == (UART_LSR_THRE | UART_LSR_TEMT))
        {
            return true;
        }
    }

    return false;
}

static void SetMcr(UINT8 modem, UINT8 mcr, const char *tag)
{
    (void)tag;
    mcr = (UINT8)(mcr & (UINT8)(~UART_MCR_LOOPBACK));
    UartWrite8(modem, UART_MCR, mcr);
    HartStackIdleWait(12000u);


}

static void WriteTxByte(UINT8 modem, UINT8 byte)
{
    if (!WaitTxReady(modem))
    {

    }

    UartWrite8(modem, UART_RBR_THR, byte);
}

static void ConfigureHartBaud(void)
{

    Write8(FPGA_BRG_DLL, 0xE2u);
    HartStackIdleWait(20000u);

    Write8(FPGA_BRG_DLM, 0x04u);
    HartStackIdleWait(20000u);

    Write8(FPGA_BRG_MUX, 0x00u);
    HartStackIdleWait(20000u);

}

static void SwitchMux(UINT8 channel, UINT8 modem)
{
    UINT16 usAddr;
    UINT16 clearMask;

    m_ucConnectedChannel = channel;
    m_ucModemNumber = modem;
    m_usHartMuxAddr = HART_INITIAL_MAR;
    m_ucHartMuxEnbl = HART_INITIAL_MER;

    if (channel == 0u)
    {
        channel = 1u;
    }

    usAddr = (UINT16)((channel - 1u) & 0x000Fu);
    usAddr = (UINT16)(usAddr << (modem * 4u));

    switch (modem)
    {
        case 0u: clearMask = 0xFFF0u; break;
        case 1u: clearMask = 0xFF0Fu; break;
        case 2u: clearMask = 0xF0FFu; break;
        case 3u: clearMask = 0x0FFFu; break;
        default: clearMask = 0xFFFFu; break;
    }

    m_usHartMuxAddr &= clearMask;
    m_usHartMuxAddr |= usAddr;
    m_ucHartMuxEnbl |= (UINT8)(0x01u << modem);

    Write16(FPGA_MAR, m_usHartMuxAddr);
    HartStackIdleWait(HART_MUX_SETTLE_LOOPS);


    Write16(FPGA_MER, (UINT16)m_ucHartMuxEnbl);
    HartStackIdleWait(HART_MUX_SETTLE_LOOPS);

}

static void SetShortRequest(UINT8 command, UINT8 pollAddr, const UINT8 *data, UINT8 dataLen)
{
    g_HartRequest.useLongAddress = false;
    g_HartRequest.command = command;
    g_HartRequest.pollAddr = pollAddr;
    g_HartRequest.dataLen = dataLen;
    for (UINT8 i = 0u; i < sizeof(g_HartRequest.data); i++)
    {
        g_HartRequest.data[i] = 0u;
    }

    for (UINT8 i = 0u; (i < dataLen) && (i < sizeof(g_HartRequest.data)); i++)
    {
        g_HartRequest.data[i] = data[i];
    }
}

static void SetLongRequest(UINT8 command, const UINT8 longAddr[5], const UINT8 *data, UINT8 dataLen)
{
    g_HartRequest.useLongAddress = true;
    g_HartRequest.command = command;
    g_HartRequest.pollAddr = 0u;
    g_HartRequest.dataLen = dataLen;
    for (UINT8 i = 0u; i < 5u; i++)
    {
        g_HartRequest.longAddr[i] = longAddr[i];
    }

    for (UINT8 i = 0u; i < sizeof(g_HartRequest.data); i++)
    {
        g_HartRequest.data[i] = 0u;
    }

    for (UINT8 i = 0u; (i < dataLen) && (i < sizeof(g_HartRequest.data)); i++)
    {
        g_HartRequest.data[i] = data[i];
    }
}

static void BuildShortFrame(UINT8 pollAddr,
                            UINT8 command,
                            const UINT8 *data,
                            UINT8 dataLen,
                            UINT8 *out,
                            UINT32 *outLen)
{
    UINT32 idx = 0u;
    UINT8 addr = (UINT8)(HART_MASTER_ADDR_MASK | (pollAddr & 0x0Fu));
    UINT8 checksum = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = HART_PREAMBLE_BYTE;
    }

    out[idx++] = HART_DELIMITER_SHORT_MASTER_REQ;
    checksum ^= HART_DELIMITER_SHORT_MASTER_REQ;

    out[idx++] = addr;
    checksum ^= addr;

    out[idx++] = command;
    checksum ^= command;

    out[idx++] = dataLen;
    checksum ^= dataLen;

    for (UINT8 i = 0u; i < dataLen; i++)
    {
        out[idx++] = data[i];
        checksum ^= data[i];
    }

    out[idx++] = checksum;

    out[idx++] = HART_PREAMBLE_BYTE;

    *outLen = idx;
}

static void BuildLongFrame(const UINT8 longAddr[5],
                           UINT8 command,
                           const UINT8 *data,
                           UINT8 dataLen,
                           UINT8 *out,
                           UINT32 *outLen)
{
    UINT32 idx = 0u;
    UINT8 checksum = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = HART_PREAMBLE_BYTE;
    }

    out[idx++] = 0x82u;
    checksum ^= 0x82u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = longAddr[i];
        checksum ^= longAddr[i];
    }

    out[idx++] = command;
    checksum ^= command;

    out[idx++] = dataLen;
    checksum ^= dataLen;

    for (UINT8 i = 0u; i < dataLen; i++)
    {
        out[idx++] = data[i];
        checksum ^= data[i];
    }

    out[idx++] = checksum;

    /* HART pad byte */
    out[idx++] = HART_PREAMBLE_BYTE;

    *outLen = idx;
}

static void BuildCurrentHartRequest(UINT8 pollAddr, UINT8 *out, UINT32 *outLen)
{
    if (g_HartRequest.useLongAddress)
    {
        BuildLongFrame(g_HartRequest.longAddr,
                       g_HartRequest.command,
                       g_HartRequest.data,
                       g_HartRequest.dataLen,
                       out,
                       outLen);
    }
    else
    {
        BuildShortFrame(pollAddr,
                        g_HartRequest.command,
                        g_HartRequest.data,
                        g_HartRequest.dataLen,
                        out,
                        outLen);
    }
}

static bool CheckHartChecksum(const UINT8 *rx, UINT32 frameStart, UINT32 checksumIndex, UINT8 *calcOut)
{
    UINT8 calc = 0u;

    for (UINT32 i = frameStart; i < checksumIndex; i++)
    {
        calc ^= rx[i];
    }

    *calcOut = calc;
    return (calc == rx[checksumIndex]);
}

static bool ParseHartFrameAtOffset(const UINT8 *rx, UINT32 rxLen, UINT32 offset, HartParsedResponse_t *out, bool requireChecksum)
{
    UINT32 idx = offset;
    UINT32 frameStart;
    UINT32 checksumIndex;
    UINT8 calc = 0u;

    for (UINT32 i = 0u; i < sizeof(*out); i++)
    {
        ((UINT8 *)out)[i] = 0u;
    }

    while ((idx < rxLen) && (rx[idx] == HART_PREAMBLE_BYTE))
    {
        out->preambleCount++;
        idx++;
    }

    if (out->preambleCount == 0u)
    {
        return false;
    }

    if ((idx + 4u) >= rxLen)
    {
        return false;
    }

    frameStart = idx;
    out->delimiter = rx[idx++];

    if (!((out->delimiter == 0x06u) ||
          (out->delimiter == 0x86u) ||
          (out->delimiter == 0x8Eu) ||
          (out->delimiter == 0x96u) ||
          ((out->delimiter & 0x80u) != 0u)))
    {
        return false;
    }

    if ((out->delimiter & 0x80u) != 0u)
    {
        out->isLongAddress = true;
        out->addressLen = 5u;

        if ((idx + 5u + 3u) >= rxLen)
        {
            return false;
        }

        for (UINT8 i = 0u; i < 5u; i++)
        {
            out->address[i] = rx[idx++];
        }
    }
    else
    {
        out->isLongAddress = false;
        out->addressLen = 1u;
        out->address[0] = rx[idx++];
    }

    out->command = rx[idx++];
    out->byteCount = rx[idx++];

    if (out->byteCount > sizeof(out->payload))
    {
        return false;
    }

    checksumIndex = idx + out->byteCount;

    if (checksumIndex >= rxLen)
    {
        return false;
    }

    if (out->byteCount >= 2u)
    {
        out->hasStatus = true;
        out->status0 = rx[idx++];
        out->status1 = rx[idx++];
        out->payloadLen = (UINT8)(out->byteCount - 2u);
    }
    else
    {
        out->payloadLen = out->byteCount;
    }

    for (UINT8 i = 0u; i < out->payloadLen; i++)
    {
        out->payload[i] = rx[idx++];
    }

    out->checksumRx = rx[checksumIndex];
    out->checksumOk = CheckHartChecksum(rx, frameStart, checksumIndex, &calc);
    out->checksumCalc = calc;

    if (requireChecksum && !out->checksumOk)
    {
        return false;
    }

    out->valid = true;
    return true;
}

static bool ParseHartResponse(const UINT8 *rx, UINT32 rxLen, HartParsedResponse_t *out)
{
    for (UINT32 offset = 0u; offset < rxLen; offset++)
    {
        if (rx[offset] != HART_PREAMBLE_BYTE)
        {
            continue;
        }

        if (ParseHartFrameAtOffset(rx, rxLen, offset, out, true))
        {

            break;
        }
    }

    if (!out->valid)
    {
        return false;
    }

    return true;
}

static bool ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[5], UINT8 *respPreambles)
{
    if (!cmd0->valid || !cmd0->checksumOk || (cmd0->command != HARTCOMMAND_ZERO))
    {

        return false;
    }

    if (cmd0->payloadLen < HART_CMD0_ID_RESPONSE_SIZE)
    {

        return false;
    }

    longAddr[0] = (UINT8)((cmd0->payload[1] & HART_MANUFACTURE_ID_MASK) |
                          HART_MASTER_ADDR_MASK);
    longAddr[1] = cmd0->payload[2];
    longAddr[2] = cmd0->payload[9];
    longAddr[3] = cmd0->payload[10];
    longAddr[4] = cmd0->payload[11];

    *respPreambles = cmd0->payload[3];
    if (*respPreambles < 5u)
    {
        *respPreambles = 5u;
    }

    for (UINT8 i = 0u; i < cmd0->payloadLen; i++)
    {

    }

    return true;
}

static void HartModemSetState(HartModemObject_t *obj, HartModemState_t newState, const char *reason)
{
    (void)reason;
    obj->state = newState;
    obj->tickInState = 0u;
}


static bool HartIsValidResponseDelimiter(UINT8 b)
{
    return ((b == 0x06u) || (b == 0x86u) || (b == 0x8Eu) || (b == 0x96u));
}

static bool HartLooksLikeStatusEcho(UINT8 b)
{
    return ((b == 0x60u) || (b == 0x61u) || (b == 0xC1u) ||
            (b == 0x88u) || (b == 0x09u) || (b == 0x08u) ||
            (b == 0x02u));
}

static UINT32 HartFindDelimiterIndex(const HartModemObject_t *obj)
{
    for (UINT32 i = 0u; i < obj->rxCount; i++)
    {
        if (obj->rxBuf[i] != HART_PREAMBLE_BYTE)
        {
            return i;
        }
    }
    return 0xFFFFFFFFu;
}

static void HartUpdateExpectedLength(HartModemObject_t *obj)
{
    UINT32 d;
    UINT8 delimiter;
    UINT32 byteCountIndex;
    UINT8 byteCount;

    if (obj->rxExpectedLen != 0u)
    {
        return;
    }

    d = HartFindDelimiterIndex(obj);
    if (d == 0xFFFFFFFFu)
    {
        return;
    }

    delimiter = obj->rxBuf[d];
    byteCountIndex = ((delimiter & 0x80u) != 0u) ? (d + 7u) : (d + 3u);

    if (obj->rxCount <= byteCountIndex)
    {
        return;
    }

    byteCount = obj->rxBuf[byteCountIndex];
    if (byteCount > 64u)
    {
        return;
    }

    obj->rxExpectedLen = ((delimiter & 0x80u) != 0u) ? (d + 9u + byteCount) : (d + 5u + byteCount);

}

static bool HartByteAllowedAtCleanIndex(HartModemObject_t *obj, UINT8 b, UINT8 lsrBefore)
{
    UINT32 d;
    UINT32 pos;

    if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
    {
        return false;
    }

    if (obj->rxCount == 0u)
    {
        return (b == HART_PREAMBLE_BYTE);
    }

    d = HartFindDelimiterIndex(obj);
    if (d == 0xFFFFFFFFu)
    {
        if (b == HART_PREAMBLE_BYTE)
        {
            return true;
        }
        if ((obj->rxCount >= 2u) && HartIsValidResponseDelimiter(b))
        {
            return true;
        }
        return false;
    }

    pos = obj->rxCount - d;

    if ((obj->rxBuf[d] & 0x80u) == 0u)
    {
        if (pos == 1u)
        {
            if ((b != (UINT8)(HART_MASTER_ADDR_MASK | (obj->pollAddr & 0x0Fu))) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 2u)
        {
            if ((b != g_HartRequest.command) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 3u)
        {
            if ((b > 64u) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
    }
    else
    {
        if (pos == 6u)
        {
            if ((b != g_HartRequest.command) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 7u)
        {
            if ((b > 64u) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
    }

    if ((b == lsrBefore) && HartLooksLikeStatusEcho(b))
    {
        return false;
    }

    return true;
}

static void HartAppendRxByte(HartModemObject_t *obj, UINT8 b, UINT8 lsrBefore)
{
    obj->rxRawCount++;

    if (!HartByteAllowedAtCleanIndex(obj, b, lsrBefore))
    {
        return;
    }

    if (obj->rxCount < sizeof(obj->rxBuf))
    {
        obj->rxBuf[obj->rxCount] = b;
    }

    if (b == HART_PREAMBLE_BYTE)
    {
        obj->preambleCount++;
        m_ucRemPreambles++;
    }

    obj->rxCount++;
    HartUpdateExpectedLength(obj);
}

static void HartDrainRxFifoClean(HartModemObject_t *obj, UINT8 firstLsr)
{
    UINT8 lsr = firstLsr;

    for (UINT32 guard = 0u; guard < 64u; guard++)
    {
        if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
        {

            break;
        }

        if ((lsr & UART_LSR_DR) == 0u)
        {
            break;
        }

        UartForceNormalLineMode(obj->modem);
        HartStackIdleWait(2500u);

        UINT8 b = UartRead8(obj->modem, UART_RBR_THR);
        HartAppendRxByte(obj, b, lsr);

        HartStackIdleWait(2500u);
        lsr = UartReadStatus8(obj->modem, UART_LSR);
    }
}

static void HartModemSampleStatus(HartModemObject_t *obj)
{
    UINT8 lsr = UartReadStatus8(obj->modem, UART_LSR);

    if ((lsr & UART_LSR_DR) != 0u)
    {
        HartDrainRxFifoClean(obj, lsr);
    }

    UINT8 msr = UartReadStatus8(obj->modem, UART_MSR);

    if ((msr & UART_MSR_DCD) != 0u)
    {
        obj->sawDcd = true;
    }
}

static void HartModemPrepareTransaction(HartModemObject_t *obj, UINT8 channel, UINT8 modem, UINT8 pollAddr)
{
    obj->modem = modem;
    obj->channel = channel;
    obj->pollAddr = pollAddr;
    obj->txLen = 0u;
    obj->txIndex = 0u;
    obj->rxCount = 0u;
    obj->rxRawCount = 0u;
    obj->rxExpectedLen = 0u;
    obj->preambleCount = 0u;
    obj->state = HART_MODEM_IDLE;
    obj->tickInState = 0u;
    obj->totalTicks = 0u;
    obj->sawDcd = false;
    obj->completed = false;

    BuildCurrentHartRequest(pollAddr, obj->txFrame, &obj->txLen);
}

static void HartModemEnterSyncWait(HartModemObject_t *obj)
{
    ClearTxRxFIFOs(obj->modem);

    SwitchMux(obj->channel, obj->modem);

    SetMcr(obj->modem, 0x00u, "SYNCWAIT_RX_RTS_INACTIVE");
    UartWrite8(obj->modem, UART_IER, HART_IER_RX_MODEM_STATUS);

    HartModemSetState(obj, HART_MODEM_SYNCWAIT, "connected modem and waiting before transmit");
}

static void HartModemEnterTransmit(HartModemObject_t *obj)
{
    SetMcr(obj->modem, UART_MCR_RTS, "XMITTING_ASSERT_RTS_ACTIVE_LOW");
    UartWrite8(obj->modem, UART_IER, HART_IER_TX_EMPTY);
    HartCharacterDelayTicks(HART_RTS_PRE_TX_TICKS);

    HartModemSetState(obj, HART_MODEM_XMITTING, "RTS asserted active-low");
}

static void HartModemTransmitAll(HartModemObject_t *obj)
{
    while (obj->txIndex < obj->txLen)
    {
        WriteTxByte(obj->modem, obj->txFrame[obj->txIndex]);
        obj->txIndex++;
    }

    UartWrite8(obj->modem, UART_IER, HART_IER_TX_EMPTY);

    if (!WaitTxEmpty(obj->modem))
    {

    }

}

static void HartModemEnterRcvWait(HartModemObject_t *obj)
{
    HartCharacterDelayTicks(HART_TX_TO_RX_GUARD_TICKS);

    /* Receive mode: /RTS inactive high. */
    SetMcr(obj->modem, 0x00u, "RCVWAIT_DEASSERT_RTS_FOR_RX");
    UartWrite8(obj->modem, UART_IER, HART_IER_RX_MODEM_STATUS);

    HartModemSetState(obj, HART_MODEM_RCVWAIT, "TX complete and waiting for carrier/RX");
}

static void HartModemTick(HartModemObject_t *obj)
{
    UINT32 rxBefore = obj->rxCount;

    obj->totalTicks++;
    obj->tickInState++;

    HartModemSampleStatus(obj);


    if ((obj->state == HART_MODEM_RCVING) && (obj->rxCount > rxBefore))
    {
        obj->tickInState = 0u;
    }

    switch (obj->state)
    {
        case HART_MODEM_IDLE:
            HartModemEnterSyncWait(obj);
            break;

        case HART_MODEM_SYNCWAIT:
            if (obj->tickInState >= HART_SYNCWAIT_TICKS)
            {
                HartModemEnterTransmit(obj);
            }
            break;

        case HART_MODEM_XMITTING:
            HartModemTransmitAll(obj);
            HartModemEnterRcvWait(obj);
            break;

        case HART_MODEM_RCVWAIT:
            if (obj->rxCount > 0u)
            {
                HartModemSetState(obj, HART_MODEM_RCVING, "RX byte arrived");
            }
            else if (obj->sawDcd)
            {
                HartModemSetState(obj, HART_MODEM_RCVING, "carrier detected");
            }
            else if (obj->tickInState >= HART_RCVWAIT_TICKS)
            {
                HartModemSetState(obj, HART_MODEM_TIMEOUT, "no carrier/RX during receive wait");
            }
            break;

        case HART_MODEM_RCVING:
            if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
            {
                HartModemSetState(obj, HART_MODEM_DONE, "RX completed by expected frame length");
            }
            else if (obj->rxCount > 0u)
            {
                if (obj->tickInState >= HART_RCVING_IDLE_TICKS)
                {
                    HartModemSetState(obj, HART_MODEM_DONE, "RX completed by idle timeout");
                }
            }
            else if (obj->tickInState >= HART_RCVING_IDLE_TICKS)
            {
                HartModemSetState(obj, HART_MODEM_TIMEOUT, "carrier seen but no RX byte");
            }
            break;

        case HART_MODEM_DONE:
        case HART_MODEM_TIMEOUT:
        case HART_MODEM_BAD:
        default:
            obj->completed = true;
            break;
    }
}

static void HartModemRun(HartModemObject_t *obj)
{

    while (!obj->completed)
    {
        HartModemTick(obj);

#if HART_SERVICE_DMC_DURING_TRANSACTION
        if ((obj->totalTicks & 0x03u) == 0u)
        {
            TaskScheduler.RefreshTaskDmc(TASKID_HARTTASK);
        }
#endif

        if (obj->completed)
        {
            break;
        }

        HartCharacterDelayTicks(1u);
    }
}

static BOOL HartValidateCmd0Identity(const HartParsedResponse_t *rsp, UINT8 pollAddr)
{
    BOOL uniqueAllZero;
    BOOL uniqueAllFF;

    if ((rsp == NULL) || !rsp->valid || !rsp->checksumOk ||
        rsp->isLongAddress || (rsp->delimiter != 0x06u) ||
        (rsp->addressLen != 1u) ||
        (rsp->address[0] != (UINT8)(HART_MASTER_ADDR_MASK | (pollAddr & 0x0Fu))) ||
        (rsp->command != HARTCOMMAND_ZERO) ||
        (rsp->status0 != HART_RESPCODE_SUCCESS) ||
        (rsp->byteCount < (UINT8)(HART_CMD0_ID_RESPONSE_SIZE + 2u)) ||
        (rsp->payloadLen < HART_CMD0_ID_RESPONSE_SIZE))
    {
        return FALSE;
    }

    if ((rsp->payload[4] < HARTVERSION_5X) ||
        (rsp->payload[4] > HARTVERSION_LASTESTSUPPORTED) ||
        (rsp->payload[3] < 3u) || (rsp->payload[3] > 32u))
    {
        return FALSE;
    }

    uniqueAllZero = ((rsp->payload[9] == 0u) &&
                     (rsp->payload[10] == 0u) &&
                     (rsp->payload[11] == 0u)) ? TRUE : FALSE;
    uniqueAllFF = ((rsp->payload[9] == 0xFFu) &&
                   (rsp->payload[10] == 0xFFu) &&
                   (rsp->payload[11] == 0xFFu)) ? TRUE : FALSE;

    return ((uniqueAllZero == FALSE) && (uniqueAllFF == FALSE)) ? TRUE : FALSE;
}

static UINT32 RunHartTransaction(UINT8 channel,
                                 UINT8 modem,
                                 UINT8 pollAddr,
                                 HartParsedResponse_t *parsedOut)
{
    HartModemObject_t obj;

    InitUart(modem);
    ConfigureHartBaud();

    HartModemPrepareTransaction(&obj, channel, modem, pollAddr);
    HartModemRun(&obj);

    g_bLastTransactionSawDcd = obj.sawDcd ? TRUE : FALSE;
    g_ulLastTransactionRawCount = obj.rxRawCount;

    if (obj.rxCount > 0u)
    {

        if (parsedOut != NULL)
        {
            (void)ParseHartResponse(obj.rxBuf, obj.rxCount, parsedOut);
        }
    }

    return obj.rxCount;
}

static bool GetCleanCmd0Response(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out)
{
    if (cmd0Out == NULL)
    {
        return false;
    }

    memset(cmd0Out, 0, sizeof(*cmd0Out));

    const UINT8 emptyRouteRetryLimit =
        (UINT8)HART_EMPTY_ROUTE_RETRY_COUNT;

    for (UINT8 attempt = 1u; attempt <= HART_CMD0_RETRY_COUNT; attempt++)
    {
        HartParsedResponse_t candidate;
        memset(&candidate, 0, sizeof(candidate));

        SetShortRequest(HARTCOMMAND_ZERO, pollAddr, NULL, 0u);
        if (RunHartTransaction(channel, modem, pollAddr, &candidate) == 0u)
        {
            if ((g_bLastTransactionSawDcd == FALSE) &&
                (g_ulLastTransactionRawCount == 0u) &&
                (attempt >= emptyRouteRetryLimit))
            {
                break;
            }
            continue;
        }

        if (HartValidateCmd0Identity(&candidate, pollAddr) == FALSE)
        {
            continue;
        }

        *cmd0Out = candidate;
        cmd0Out->responsePreambles = cmd0Out->payload[3];
        if (cmd0Out->responsePreambles < HART_MIN_PREAMBLES)
        {
            cmd0Out->responsePreambles = HART_MIN_PREAMBLES;
        }
        cmd0Out->hartRevision = cmd0Out->payload[4];
        cmd0Out->deviceRevision = cmd0Out->payload[5];
        cmd0Out->longAddr[0] = (UINT8)((cmd0Out->payload[1] & HART_MANUFACTURE_ID_MASK) |
                                       HART_MASTER_ADDR_MASK);
        cmd0Out->longAddr[1] = cmd0Out->payload[2];
        cmd0Out->longAddr[2] = cmd0Out->payload[9];
        cmd0Out->longAddr[3] = cmd0Out->payload[10];
        cmd0Out->longAddr[4] = cmd0Out->payload[11];

        return true;
    }

    return false;
}

VOID HartStack_Reset(VOID)
{
    for (UINT8 modem = 0u; modem < UART_COUNT; modem++)
    {
        ResetUartAndHartModem(modem);
    }
}

BOOL HartStack_RunLongCommand(UINT8 channel,
                              UINT8 modem,
                              UINT8 pollAddr,
                              const UINT8 longAddr[5],
                              UINT8 command,
                              const UINT8 *data,
                              UINT8 dataLen,
                              HartParsedResponse_t *parsedOut)
{
    SetLongRequest(command, longAddr, data, dataLen);

    if (RunHartTransaction(channel, modem, pollAddr, parsedOut) == 0u)
    {
        return false;
    }

    if ((parsedOut == NULL) || !parsedOut->valid || !parsedOut->checksumOk ||
        !parsedOut->isLongAddress || (parsedOut->addressLen != HART_LONGADDR_LENGTH) ||
        (parsedOut->command != command))
    {
        return FALSE;
    }

    if (((parsedOut->address[0] & HART_MANUFACTURE_ID_MASK) !=
         (longAddr[0] & HART_MANUFACTURE_ID_MASK)) ||
        (parsedOut->address[1] != longAddr[1]) ||
        (parsedOut->address[2] != longAddr[2]) ||
        (parsedOut->address[3] != longAddr[3]) ||
        (parsedOut->address[4] != longAddr[4]))
    {
        return FALSE;
    }

    return TRUE;
}

BOOL HartStack_GetCleanCmd0(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out)
{
    return GetCleanCmd0Response(channel, modem, pollAddr, cmd0Out);
}

BOOL HartStack_ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[HART_LONGADDR_LENGTH], UINT8 *respPreambles)
{
    return ExtractLongAddressFromCmd0(cmd0, longAddr, respPreambles);
}
