/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihmain.cpp                                                 *
*    Description : Analog HART input module application startup code for       *
*                  NXP iMXRT1024.  Creates the box and slot database objects,  *
*                  registers task functions, and initialises periodic tasks.   *
*                                                                              *
*    Converted from Renesas H8S/2329 -> NXP LPC1768 -> NXP iMXRT1024.          *
*    Global objects that were in section-attributed memory on the LPC1768      *
*    are now plain C++ globals (linker handles placement).                     *
*    Static m_TaskDefinitionTable[] replaced by runtime RegisterTask() calls.  *
*******************************************************************************/

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aihmain.h"
#include "hart.h"
#include "tracelog_flash.hpp"
#include <new>  /* placement new */

// temp for testing
//extern volatile BOOL bOneSecTick;
//extern UINT32 u1_LastExecState;

/*******************************************************************************
*                                    GLOBALS                                   *
*  These are the global object instances declared extern in aihmain.h.         *
*  On the LPC1768 original these had linker section attributes — on RT1024     *
*  the linker script handles all placement automatically.                      *
*******************************************************************************/

/* Static memory pool for IOM database objects — no heap on bare metal.
 * Sized in UINT32 units for alignment.  Matches the original ucIomDbMemory
 * pattern from the H8S/LPC codebase. */
#define AIHBOXSLOT_WORDS  ((sizeof(clsAihBoxSlot) + 3) / 4)
#define AIHSLOT_WORDS     ((sizeof(clsAihSlot) + 3) / 4)
static UINT32 ucIomDbMemory[AIHBOXSLOT_WORDS + (MAXSLOTS * AIHSLOT_WORDS)];

/* Box-level database pointer — set during AppMain() */
//clsBoxSlot *BOX = NULL;

/* pDatabase[] — slot database pointers (box=0, slots=1..MAXSLOTS) */
clsIomSlot *pDatabase[MAXSLOTS + 1] = { NULL };

/* Legacy trace object; persistent storage is initialized from main(). */
clsTraceLog TraceLog;

extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN HartTask(TASKCONTEXT);
//extern TASKRETURN DiagnosticTask(TASKCONTEXT);
//extern TASKRETURN LowPriorityTask(TASKCONTEXT);

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
TASKRETURN CalibrationTask(TASKCONTEXT);

/*******************************************************************************
*                                   AppMain                                    *
*                                   =======                                    *
* PURPOSE:                                                                     *
*    Application specific startup code for the AIH module.                     *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    This function is called from main() (epicio_kernel.cpp) after hardware    *
*    initialisation is complete.  It creates the box and slot database          *
*    objects, registers task functions with the scheduler, and initialises     *
*    periodic tasks.  Execution returns to main() which then transfers         *
*    control to TaskScheduler.ExecuteTaskScheduler().                          *
*                                                                              *
*    RT1024 CHANGES:                                                           *
*    - Task functions are registered with RegisterTask() at runtime instead    *
*      of the old static m_TaskDefinitionTable[] initialised in this file.     *
*    - clsAihSlot replaced by clsAixSlot (unified AI analog slot).            *
*    - Section attributes removed — linker handles placement.                  *
*    - Legacy HART entry points are retained. The H8 TPU/UART hardware body is *
*      bridged to the RT1024 FPGA-SPI/UART16550 transport.                     *
*******************************************************************************/
VOID AppMain(VOID)
{
    BOOL bHart = FALSE;

    if (isHartCapable())
    {
        pDatabase[0] = new (ucIomDbMemory) clsAihBoxSlot(MODLTYPE_AIH);
        bHart = TRUE;
        TraceLog.AddToTrace(TRACEID_GENERIC, bcAihIom, BOX->GetDPA());
    }
    else
    {
        pDatabase[0] = new (ucIomDbMemory) clsAihBoxSlot(MODLTYPE_AI);
        TraceLog.AddToTrace(TRACEID_GENERIC, bcAiIom, BOX->GetDPA());
    }

#ifdef DBG_PRINT
    PRINTF("DPA ADDRESS: %02X\r\n", BOX->GetDPA());
    PRINTF("DSA ADDRESS: %02X\r\n", BOX->GetDSA());
    PRINTF(" BA ADDRESS: %02X\r\n", BOX->GetBA());
#endif

    for (UINT8 ucSltNm = 0u; ucSltNm < MAXSLOTS; ucSltNm++)
    {
        UINT32 *pSlotMem = ucIomDbMemory + AIHBOXSLOT_WORDS + (ucSltNm * AIHSLOT_WORDS);
        pDatabase[ucSltNm + 1u] = new (pSlotMem) clsAihSlot(ucSltNm + 1u);
    }

    TraceLog.AddToTrace(TRACEID_GENERIC, bcIomDbDone);

    BOX->SetFactoryTestMode();

    if (TRUE == bHart)
    {
        CheckAndInitHart();
        /* Do not run HART transactions from AppMain. Discovery is serviced by
         * HartTask after the scheduler, database and IO-Link are active. */
    }
    else
    {
        ResetHart();
    }

    TaskScheduler.RegisterTask(TASKID_WRDBTASK, WriteDatabaseTask);
    TaskScheduler.RegisterTask(TASKID_LPTASK,   LowPriorityTask);
    TaskScheduler.RegisterTask(TASKID_EVRCTASK, EventRecoveryTask);
    TaskScheduler.RegisterTask(TASKID_CALIBTASK, CalibrationTask);
    if (TRUE == bHart)
    {
        TaskScheduler.RegisterTask(TASKID_HARTTASK, HartTask);
    }

    TaskScheduler.InitPeriodicTask(TASKID_LPTASK, TASKPERIOD_LPTASK, DMCPERIOD_LPTASK);
    if (TRUE == bHart)
    {
        TaskScheduler.InitPeriodicTask(TASKID_HARTTASK, TASKPERIOD_HARTTASK, DMCPERIOD_HARTTASK);
    }

    TaskScheduler.ExecuteTaskScheduler();

    while (1)
    {
        ;
    }
}

/***********************************************************************************************************************
*                          LowPriorityTask                                    *
*                          ================                                   *
* PURPOSE  :                                                                  *
* ARGUMENTS: None.                                                            *
* RETURN   : None.                                                            *
* NOTES    : Runs Task every 1 seconds,can view LowPriorityTask over Debug    *
*            terminal to identify the task                                    *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

    /* Journal TraceLog records in U30 external NOR flash. Console diagnostics
     * are intentionally not serviced here so they cannot delay IO-Link. */
    TraceLogFlashService();

    /* The only added runtime console message is the successful HART result. */
    HartServiceLowPriorityPrint();

#if 0 // testing
    if (TRUE == bOneSecTick) {

    	PRINTF("\r\nCLB : %d", (UINT8)BOX->GetCalibrationGood());
    	PRINTF("\r\nFTA : %d", (UINT8)BOX->GetFtaPres());
		PRINTF("\r\nPRI : %d", (UINT8)Iol.AmPrimary());

		PRINTF("\r\nSNT : %d", (UINT8)SLOT(1)->GetSensrType());
		PRINTF("\r\nPTX : %d", (UINT8)SLOT(1)->GetPtExecSt());
		PRINTF("\r\nPCH : %d", (UINT8)SLOT(1)->GetPvChar());
		PRINTF("\r\nPCL : %d", (UINT8)SLOT(1)->GetPvClamp());
		PRINTF("\r\nPSC : %d", (UINT8)SLOT(1)->GetPvSource());

		PRINTF("\r\nLES : %X", (UINT32)u1_LastExecState);

	    for (UINT8 chan = 1; chan <= MAXSLOTS; chan++) {

	    	PVVALST pvSts = BOX->GetPvSts(chan);
	    	if (PVVALST_BAD == pvSts) {
	    		PRINTF("\r\nPV (%02X): BAD", chan);
	    	}
	    	else {
	    		FLOAT32 pv = BOX->GetPv(chan);
	    		UINT8 *pPvBytes = (UINT8 *)&pv;
	    		INT32 pvMilli = (INT32)(pv * 1000.0F);
	    		INT32 whole = pvMilli / 1000;
	    		INT32 frac = pvMilli % 1000;
	    		if (frac < 0) {
	    			frac = -frac;
	    		}
	    		PRINTF("\r\nPV (%02X): ST=%d HEX=%02X %02X %02X %02X DEC=%d.%03d",
	    		       chan, pvSts, pPvBytes[3], pPvBytes[2], pPvBytes[1], pPvBytes[0], whole, frac);
	    	}
    	}
    	bOneSecTick = FALSE;
    }
#endif

#if 0 //!LOWCOST
    if(TRUE == HartLoopBkTestInProgress){

        HartLoopBkTestInProgress = (RETURNSTATUS_INPROGRESS == BOX->HartLoopBackTest());
    }
#endif

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();

#if 0 //(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
    // Process BRDP Handle and Message Timeout every second.
    if (BOX->BRDPOneSecCounter >= 10) {

        BOX->BRDPOneSecCounter = 0;
        BOX->ProcessBrdpTimeout();
    }
    else {

    	BOX->BRDPOneSecCounter++;
    }
#endif

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}

/*******************************************************************************
*                                CalibrationTask                               *
*                                ===============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN CalibrationTask(TASKCONTEXT a_TaskContext)
{
#if 0 //#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tStarting calibration...\n\r"));
#else
    PRINTF("\n\r\tStarting calibration...\n\r");
#endif

    //TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibStart,FACTCAL);

#if 0 // HART
    // Disable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {

        SLOT(ucChan)->GetHartDevDb().InitDevDb(TRUE);
    }

    IdleWait(MICROSECONDS_IN_MILLISECOND);
    TPU2_CST = 0; // Stop HART modem heartbeat timer.
#endif

    if (FALSE == BOX->PerformModuleCalibration()) {

        // Calibration was aborted for failed.
        //TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibAbort,MODULEINFO_WRITECOUNT);

#if 0 //#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalibration aborted"));
#else
        PRINTF("\n\r\tCalibration aborted");
#endif
    }

#if 0 // HART
    // Reneable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {

        SLOT(ucChan)->GetHartDevDb().m_sScanCounter = TICKS_IN_16_SEC;
    }

    TPU2_CST = 1; // Restart HART modem heartbeat timer.
#endif

    TASKRETURN      TaskReturnValue;
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;

    return TaskReturnValue;
}
