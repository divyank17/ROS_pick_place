/******************************************************************************
*                                                                             *
*                              COPYRIGHT (C) 2004                             *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                *
*                              ALL RIGHTS RESERVED                            *
*                                                                             *
*   This software is a copyrighted work and / or information protected as a   *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct*
*   from ownership of any medium in which the software is embodied. Copyright *
*   or trade secret notices included must be reproduced in any copies that are*
*   authorized by Honeywell Inc.                                              *
*                                                                             *
*   The information in this software is subject to change without notice and  *
*   should not be considered as a commitment by Honeywell Inc.                *
*                                                                             *
* ============================================================================*
*    File Name   : scheduler.cpp                                              *
*    Description : Definitions and constants of  scheduler                    *
******************************************************************************/
/******************************************************************************
*                               INCLUDE FILES                                 *
******************************************************************************/
#include "scheduler.hpp"
#include "boxslot.hpp"
#include "iol.hpp"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern BOOL HWRevCodeWriteInProgress;

clsTaskScheduler TaskScheduler;

/******************************************************************************
*                 clsTaskScheduler::clsTaskScheduler                          *
*                 ==================================                          *
* PURPOSE:                                                                    *
*    The constructor for Scheduler class                                      *
* ARGUMENTS:                                                                  *
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
clsTaskScheduler::clsTaskScheduler(VOID)
{
	// Initialize data members
	m_ul10msCounter        = 0;
	m_ulLast10msCounter    = 0;
	m_usTaskActivationBits = 0;
	m_ucDelayedTaskCount   = 0;
	m_bOneSecondTimerFlag  = 0;

    for (UINT8 ucTask=0 ; ucTask < TASKCOUNT; ucTask++)
    {
        // Initialize Periodic table
        m_PeriodicTable[ucTask].usDownCounter     = 0;
        m_PeriodicTable[ucTask].usPeriod          = 0;
        // Initialize Suspended table
        m_DelaySuspendTable[ucTask].usDownCounter = 0;
        m_DelaySuspendTable[ucTask].TaskContext   = TASKCONTEXT_ZERO;
        // Initiaize task status to sleep state and ReRequest counter to zero
        m_TaskStatus[ucTask].TaskState            = TASKSTATE_ASLEEP;
        m_TaskStatus[ucTask].ucRequestCounter     = 0;
        // Initialize DMC table
        m_DmcTable[ucTask].usLifespan             = 0;
        m_DmcTable[ucTask].usCurrentLife          = 0;
    }
}

/*******************************************************************************
*                 clsTaskScheduler::RegisterTask                               *
*                 =============================                                *
* PURPOSE  : Register a task function pointer for a given task ID.  Replaces   *
*             the old static m_TaskDefinitionTable[] initialiser.              *
* ARGUMENTS: a_ucTaskId : task ID (1-based).                                   *
*            a_pfTask   : pointer to the task entry function.                  *
* RETURN   : None.                                                             *
* NOTES    : None.                                                             *
*******************************************************************************/
VOID clsTaskScheduler::RegisterTask(UINT8 a_ucTaskId, TASKRETURN (*a_pfTask)(TASKCONTEXT))

{
    if (a_ucTaskId >= 1 && a_ucTaskId <= TASKCOUNT) {

        m_TaskDefinitionTable[a_ucTaskId - 1].TaskFunctionPtr = a_pfTask;
    }
}

/*******************************************************************************
*                 clsTaskScheduler::InitPeriodicTask                           *
*                 ==================================                           *
* PURPOSE   : Initialise the periodic table structure for a given task.        *
* ARGUMENTS : a_ucTaskId   : task ID (1-based).                                *
*             a_usPeriod   : period in milliseconds.                           *
*             a_usLifeSpan : DMC lifespan in milliseconds.                     *
* RETURN    : None.                                                            *
* NOTES     : None.                                                            *
*******************************************************************************/
VOID clsTaskScheduler::InitPeriodicTask(UINT8 a_ucTaskId, UINT16 a_usPeriod, UINT16 a_usLifeSpan)
{
    m_PeriodicTable[a_ucTaskId - 1].usPeriod      = a_usPeriod / SCHEDULER_PERIOD;
    m_PeriodicTable[a_ucTaskId - 1].usDownCounter = a_usPeriod / SCHEDULER_PERIOD;
    m_DmcTable[a_ucTaskId - 1].usLifespan         = a_usLifeSpan / SCHEDULER_PERIOD;
    m_DmcTable[a_ucTaskId - 1].usCurrentLife      = a_usLifeSpan / SCHEDULER_PERIOD;
}

/******************************************************************************
*                 clsTaskScheduler::RunTask                                   *
*                 =========================                                   *
* PURPOSE   : Sets the Task activation bit based on the task number           *
* ARGUMENTS : None.                                                           *
* RETURN    : None.                                                           *
* NOTES     :                                                                 *
******************************************************************************/
VOID clsTaskScheduler::RunTask(UINT8 a_ucTaskId)
{
    UINT16 usMask = (0x0001 << (a_ucTaskId - 1));
    // Protect the access of task activation bits from
    // STC ISR since the access is not atomic and the
    // same data is accessed in STC ISR.
    UINT32 ucSaveExr = hal_interrupt_set_mask(LVLPRI_HIGHEST);

    m_usTaskActivationBits |= usMask;

#if 0
    // Customer (MiRO) Issue(CL Fail) Fix - counter increment if write requests arrives into the buffer
    if (TASKID_WRDBTASK == a_ucTaskId) {

        m_usWriteReqCount += 1;
    }
#endif

    hal_interrupt_set_mask(ucSaveExr);
}

/*******************************************************************************
*                 clsTaskScheduler::RefreshTaskDmc                             *
*                 ================================                             *
* PURPOSE  : Refresh the DMC (Dead Man’s Click) counter for a periodic task.   *
* ARGUMENTS: a_ucTaskId : task ID (1-based) of the calling task.               *
* RETURN   : None.                                                             *
* NOTES    : None.                                                             *
*******************************************************************************/
VOID clsTaskScheduler::RefreshTaskDmc(UINT8 a_ucTaskId)
{
    m_DmcTable[a_ucTaskId - 1].usCurrentLife = m_DmcTable[a_ucTaskId - 1].usLifespan;
}

/*******************************************************************************
*                 clsTaskScheduler::StartTimer                                 *
*                 ============================                                 *
* PURPOSE  : Start the SysTick timer for scheduler periodic (10ms) interrupts. *
* ARGUMENTS: None.                                                             *
* RETURN   : None.                                                             *
* NOTES    : RT1024 uses SysTick_Config; QEMU uses hal_stc_init.               *
*******************************************************************************/
VOID clsTaskScheduler::StartTimer(VOID)
{
    // RT1024: SysTick for 10ms tick at SystemCoreClock rate
    extern uint32_t SystemCoreClock;

    SysTick_Config(SystemCoreClock / 100);  // 10ms tick (100 Hz)
    NVIC_SetPriority(SysTick_IRQn, HAL_IRQ_PRIO_SYSTICK);
}

/******************************************************************************
*                 clsTaskScheduler::ExecuteTaskScheduler                      *
*                 ======================================                      *
* PURPOSE:                                                                    *
*    Main Task Scheduler Exeutive Method                                      *
* ARGUMENTS:                                                                  *
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID clsTaskScheduler::ExecuteTaskScheduler(VOID) {

	UINT16 usTimeDifference = 0;
	UINT16 usMask = 0;
	UINT8 ucTask = 0;
	UINT8 ucActiveTaskIndex = 0;

	BOX->AppInitialization(); // IOM Specific Init.
	TraceLog.AddToTrace(TRACEID_GENERIC, bcAppInitComplete);

    // Disable all interrupt to start STC and watchdog timer together
    // so that both timers remain in sync for the life of execution.

    // Start the SysTick scheduler timer (replaces TPU5_CST = 1 / STC_Start())
    StartTimer();

    // Enable all interrupts

    Iol.Enable();                  // Start the IOL Interface
    TraceLog.AddToTrace(TRACEID_GENERIC, bcIOLEnable);

    BOX->DoAliveToIdleChange();    // Change module status to IDLE.
    TraceLog.AddToTrace(TRACEID_GENERIC, bcAliveToIdle);

    while(TRUE) {

    	if(m_ul10msCounter != m_ulLast10msCounter) {

    		// Check if the Current Value of clock > last execution time
    		if (m_ul10msCounter > m_ulLast10msCounter) {

    			usTimeDifference = (UINT16)(m_ul10msCounter - m_ulLast10msCounter);
    		}
    		else {
    			// Check for Overflow and calculate accordingly
				usTimeDifference = (UINT16)(MAXUINT32 - m_ulLast10msCounter + m_ul10msCounter + 1);
    		}

            static UINT32 susMaxTimeDifference = 1;
            static UINT32 susTimeDifferenceCount = 0;

            if (usTimeDifference > 1) {

            	susTimeDifferenceCount++;
            }

            // Log the time difference only if it is greater than previous maximum.
            if (usTimeDifference > susMaxTimeDifference) {

                susMaxTimeDifference = usTimeDifference;
                //TraceLog.AddToTrace(TRACEID_GENERIC, bcSchedulerDelay, (UINT32)(((UINT32)susMaxTimeDifference << WORDSIZE) | susTimeDifferenceCount));
            }

            m_ulLast10msCounter = m_ul10msCounter;
    	}

        // Block the timer ISR while processing task activation bits.
        hal_interrupt_set_mask(LVLPRI_TICK);

        // Process Task Activation Bits
        for (ucTask = 0; ucTask < TASKCOUNT; ucTask++) {

        	usMask = 0x0001 << ucTask;

        	// Protect the access of task activation bits from
        	// STC ISR since the access is not atomic and the
        	// same data is accessed in STC ISR.
        	hal_interrupt_set_mask(LVLPRI_TICK);

        	if (m_usTaskActivationBits & usMask) {

        		switch (m_TaskStatus[ucTask].TaskState) {
        		case TASKSTATE_ASLEEP:
        			m_TaskStatus[ucTask].TaskState = TASKSTATE_READYTORUN;
        			break;
        		case TASKSTATE_READYTORUN:
        		case TASKSTATE_WAITING:
        		case TASKSTATE_READYTORESUME:
        			m_TaskStatus[ucTask].ucRequestCounter++;
        			// If the task could not be scheduled even after
					// MAX_TASKREQ_COUNT attempts, raise a softfail.
        			if (MAX_TASKREQ_COUNT == m_TaskStatus[ucTask].ucRequestCounter) {

        				//BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_REQOFLOW, TRUE, 0);
        			}
        		default:
        			break;
        		} // end of switch
        		// Reset Task activation bit
        		m_usTaskActivationBits &= ~usMask;
        	}
            hal_interrupt_set_mask(LVLPRI_TASK);
        }

        // Find Ready Task with highest priority
        for (ucTask = 0; ucTask < TASKCOUNT; ucTask++) {

            if ((TASKSTATE_READYTORUN == m_TaskStatus[ucTask].TaskState) ||
                (TASKSTATE_READYTORESUME == m_TaskStatus[ucTask].TaskState)) {

                m_ucActiveTask = ucTask + 1;  // Set task to be scheduled.
                break;
            } // Task state either in Ready to Run state or Ready to Resume state
        } // End of Find Ready Tasks for loop

        // Restore original priority after updating active task.
        hal_interrupt_set_mask(LVLPRI_TASK);

        // Schedule the task if any
        if (m_ucActiveTask > 0) {

            ucActiveTaskIndex = m_ucActiveTask - 1;

            TASKRETURN TaskReturnValue;

            // If task is in Ready to Resume state, set the task state to run state
            if (TASKSTATE_READYTORESUME == m_TaskStatus[ucActiveTaskIndex].TaskState) {

                m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_RUNNING;
                // Assign task execution function
                if (m_TaskDefinitionTable[ucActiveTaskIndex].TaskFunctionPtr != NULL) {

                    TaskReturnValue = m_TaskDefinitionTable[ucActiveTaskIndex].TaskFunctionPtr(m_DelaySuspendTable[ucActiveTaskIndex].TaskContext);
                }
            }
            else { // Task is ready to Run State

                m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_RUNNING;
                // Assign task execution function
                if (m_TaskDefinitionTable[ucActiveTaskIndex].TaskFunctionPtr != NULL) {

                    TaskReturnValue = m_TaskDefinitionTable[ucActiveTaskIndex].TaskFunctionPtr(TASKCONTEXT_ZERO);
                }
            }

            // Process the return value of the function
            if (TASKRETURNSTATE_SUSPEND == TaskReturnValue.TaskReturnState) {

                // If the task return state was suspend, set the task state to wait state
                m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_WAITING;
                // Compensate for current SysTick count (armsrc: GetSTCCount() >= HALFVALUE)
                // RT1024 SysTick counts DOWN from reload to 0, so if we've consumed > half
                // the tick period we're near the end — increment suspend time.
                if (hal_stc_get_count() <= (hal_stc_get_reload() / 2)) {

                    TaskReturnValue.ucSuspendTime++;
                }
                m_DelaySuspendTable[ucActiveTaskIndex].usDownCounter = TaskReturnValue.ucSuspendTime;
                m_DelaySuspendTable[ucActiveTaskIndex].TaskContext = TaskReturnValue.TaskContext;
                m_ucDelayedTaskCount++;
            }
            else {
            	// Check the ReRequest counter, if zero set task state to sleep state
                if (0 == m_TaskStatus[ucActiveTaskIndex].ucRequestCounter) {

                    m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_ASLEEP;
                    // Return request overflow softfail if any.
                    //BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_REQOFLOW, FALSE, 0);
                }
                else {

                    // Decrement ReRequest counter & set task to ReadytoRun
                    m_TaskStatus[ucActiveTaskIndex].ucRequestCounter--;
                    m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_READYTORUN;
                }
            }

            m_ucActiveTask = 0;

#if 0
            // Check the stack top pattern for any overuse by the task just executed.
            if (STACKTESTPATTERN != *(UINT32 *)(STACK_TOP)) {
                HardFail(HF_STACKOVERRURN, SCHEDULER_CPP, __LINE__);
            }
            else {
                // ARF: EPICIO use STACK_TOP + 1, ARMSRC used STACK_TOP + 4
                // Post SF_STCKLIM if stack usage went above softfail limit level
                volatile UINT8 *ucpStack = (volatile UINT8 *)(STACK_TOP + 4);
                while (*ucpStack++ == 0xFF);
                if (((UINT32)ucpStack - (UINT32)STACK_TOP) < (UINT32)STACK_SFLIMIT) {
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_STCKLIM, TRUE, 0);
                }
                else {
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_STCKLIM, FALSE, 0);
                }
            }
#endif
        } // Active task > 0
    }
}

/*******************************************************************************
*                         SysTick_Handler (ISR)                                *
*                         ====================                                 *
* PURPOSE:                                                                     *
*    SysTick timer interrupt service routine — 10ms periodic interrupt.        *
*    Declared extern "C" for CMSIS vector table linkage.                      *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    Replaces the old STCInterruptHandler / STC_IRQHandler.                   *
*******************************************************************************/
extern "C" void SysTick_Handler(void)
{
    TaskScheduler.STCInterruptHandler();
}

/******************************************************************************
*                  clsTaskScheduler::STCInterruptHandler                      *
*                  ====================================                       *
* PURPOSE:                                                                    *
*    TPU(Timer Pulse Unit) interrupt service routine,uses channel 5           *
*    in overflow mode                                                         *
* ARGUMENTS:                                                                  *
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID clsTaskScheduler::STCInterruptHandler(VOID) {

	UINT8 ucTask;
	UINT16 usMask;

	TaskScheduler.m_ul10msCounter++;
    BOX->SetTraceTime(); // Update legacy 10 ms trace timestamp.

    // During calibration no other tasks are active. Don't hardfail if DMC expires.
	// and, During update of HW Rev Code and Hardware Serial Number
    if ((FALSE == BOX->GetCalibAllState()) && ( FALSE == HWRevCodeWriteInProgress))
    {
    	// Process Periodic Table
    	for(ucTask=0; ucTask < TASKCOUNT; ucTask++) {

    		if(TaskScheduler.m_PeriodicTable[ucTask].usDownCounter > 0) {

    			TaskScheduler.m_PeriodicTable[ucTask].usDownCounter--;
    			if(0 == TaskScheduler.m_PeriodicTable[ucTask].usDownCounter) {

    				TaskScheduler.m_PeriodicTable[ucTask].usDownCounter = TaskScheduler.m_PeriodicTable[ucTask].usPeriod;
    				usMask = 0x0001 << ucTask;
    				TaskScheduler.m_usTaskActivationBits |= usMask;
    			}
    		}

#if 0
    		// Customer (-MiRO) Issue(-CL Fail) Fix - Setting task activation bit again here (other than run task), if write requests are exists in the buffer
    		if (TASKID_WRDBTASK == (ucTask + 1)) {
    			usMask = 0x0001 << ucTask;
    			if ((TaskScheduler.m_usWriteReqCount > 0) && !(TaskScheduler.m_usTaskActivationBits & usMask)) {
    				TaskScheduler.m_usTaskActivationBits |= usMask;
    			}
    		}
#endif
    	}

    	// Process Delay/Suspend Table if any delayed tasks exists
    	if(0 != TaskScheduler.m_ucDelayedTaskCount) {

    		for(ucTask=0; ucTask < TASKCOUNT; ucTask++) {

    			// Check if the the task was in suspended state already
    			if((TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter > 0) &&
    					(TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter < MAXUINT8)) {

    				TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter--;
    			}
#if 0
    			// Customer(-MiRO) Issue(-CL Fail & EHPM Crash due to HLAI IOL Comm Error) fix
    			else if (TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter >= MAXUINT8) {
    				TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter &= 0x00FF;
    			}
#endif
    			if ((TASKSTATE_WAITING == TaskScheduler.m_TaskStatus[ucTask].TaskState) &&
    					(0 == TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter)) {
    				// if suspension time over,set task in ReadytoResume state
    				TaskScheduler.m_TaskStatus[ucTask].TaskState = TASKSTATE_READYTORESUME;
    				TaskScheduler.m_ucDelayedTaskCount--;
    			}
    		}
    	}

    	// Monitor DMC for periodic tasks
    	for (ucTask = 0; ucTask < TASKCOUNT; ucTask++)  {
    		if (TaskScheduler.m_DmcTable[ucTask].usCurrentLife > 0) {

    			// If either CPU free max value find test or HART loopback
    			// test is running, do not decrement DMC counter.
    			//#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
    			if (LOOPBACK_RUNNING == BOX->GetLpBkStat()) {

    				continue;
    			}
    			//#endif
    			//#ifdef DEBUG
    			//if (g_ucCpuFreeTestIndex > 0) continue;
    			//#endif
    			//#if defined(IOPTYPE_SCIOM)
    			// disabled due to PAR# 1-93OP1Z9 (DO16 Forcing the DO channel via data change schematic makes IOP as NR) (note: HF17)
    			// disabled for redesign IOP due to HF17.
    			TaskScheduler.m_DmcTable[ucTask].usCurrentLife--;
    			if (TaskScheduler.m_DmcTable[ucTask].usCurrentLife == 0) {

    				TraceLog.AddToTrace(TRACEID_GENERIC,bcDMCFail,(UINT32)ucTask);
    				// Report the IOL UART RX ISR entry count so we can tell
    				// whether an interrupt storm (e.g. noisy/jabbered line,
    				// higher priority than SysTick) is starving the
    				// cooperative scheduler's main loop, versus the task
    				// itself genuinely being stuck.
    				// NOTE: this lite debug console has PRINTF_ADVANCED_ENABLE
    				// = 0, which disables length-modifier parsing ('l','h','z') —
    				// %lu is NOT recognized and silently prints nothing for the
    				// argument (seen as "RcvrEntryCount=lu" with no number).
    				// Use %u (plain unsigned int, same 32-bit width here) instead.
    				// AlertErrCount / NotMyAddressCount let us tell whether the
    				// flood is noise/framing errors (jabber signature) versus
    				// legitimate other-node traffic on the multi-drop bus.
    				// GhoEntryCount/GhoDummyReadHadDataCount test whether
    				// GHO_IRQHandler's unconditional dummy read is eating
    				// genuine incoming address bytes between Rcvr() calls.
    				#if 0
					PRINTF("\r\nDMC EXPIRE: task=%d active=%d RcvrEntryCount=%u AlertErr=%u NotMyAddr=%u CountErrA=%d CountErrB=%d GhoEntry=%u GhoHadData=%u\r\n",
    				       (int)(ucTask + 1), (int)TaskScheduler.m_ucActiveTask,
    				       (unsigned int)Iol.RcvrEntryCount,
    				       (unsigned int)Iol.AlertErrCount,
    				       (unsigned int)Iol.NotMyAddressCount,
    				       (int)Iol.GetCountErrorA(), (int)Iol.GetCountErrorB(),
    				       (unsigned int)Iol.GhoEntryCount,
    				       (unsigned int)Iol.GhoDummyReadHadDataCount);
    				// Dump the last few raw byte-0 values that failed the
    				// alert-bit check, to see whether they look like
    				// structured/misaligned protocol bytes or random noise.
    				PRINTF("LastAlertBytes:");
    				for (UINT8 ucB = 0; ucB < 8U; ucB++) {
    				    PRINTF(" %X", (unsigned int)Iol.LastAlertBytes[ucB]);
    				}
    				PRINTF("\r\n");
    				// p1 = task ID whose DMC expired (1-based); p2 = task ID
    				// actually holding the CPU right now (0 = none/idle in the
    				// main loop). Since the scheduler is cooperative/non-
    				// preemptive at the task level, a starved DMC means p2's
    				// task function never returned control long enough for
    				// p1's task to be dispatched — p2 is the one to inspect.
#endif
					#if 0 // temp only for testing
    				HardFail(HF_DMCTIMEOUT, SCHEDULER_CPP, __LINE__, (UINT8)(ucTask + 1), TaskScheduler.m_ucActiveTask);
#else
    				RefreshTaskDmc(ucTask + 1);
#endif
    			}
    			//#endif
    		}
    	}
    }

    // Process 1 second Timer
    if(0 == (TaskScheduler.m_ul10msCounter % SCHEDULER_TICKS_IN_SECOND)) {
        // Set the one second indicator flag
        TaskScheduler.m_bOneSecondTimerFlag = TRUE;
#ifdef IOPTYPE_DI
        // also set the one second flag used for SOE applications in diboxslot
        BOX->SetOneSecFlagDI();
#endif
#ifdef IOMTYPE_DISOE
        // also set the one second flag used for SOE applications in diboxslot
        BOX->SetOneSecFl();
#endif
    }

    // Drive the 500ms status LED blink directly off this existing 10ms tick —
    // no dedicated hardware timer required.
    if (0 == (TaskScheduler.m_ul10msCounter % LEDBLINK_PERIOD_TICKS)) {
        BOX->BlinkLEDInterruptHandler();
    }

    BOX->AppStcProcessing();
}
