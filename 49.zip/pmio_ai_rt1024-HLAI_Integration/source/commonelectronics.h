/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : commonelectronics.h                                         *
*    Description : RT1024 / QEMU hardware abstraction.                         *
*                  Replaces the H8S register definitions with HAL calls.       *
*                  This file is included by legacy code that expects it.       *
*******************************************************************************/
#ifndef __COMMONELECTRONICS_H__
#define __COMMONELECTRONICS_H__

#include "hal.h"

//#define NOP  __asm volatile("nop")

const BOOL WRITE = TRUE;
const BOOL READ  = FALSE;

typedef enum tagStatusLed {
    STATUSLED_AMBER = 0x0300, //0,
	STATUSLED_RED   = 0x0301, //1,
	STATUSLED_GREEN = 0x0302, //2,
    STATUSLED_OFF   = 0x0303, //3
} STATUSLED;

/*******************************************************************************
*                          SYSTEM CLOCK                                        *
*******************************************************************************/
#if defined(QEMU_BUILD)
const UINT32 SYSTEM_CLOCK_FREQUENCY = 25000000;   // 25 MHz MPS2-AN500
#elif defined(UNIT_TEST_BUILD)
const UINT32 SYSTEM_CLOCK_FREQUENCY = 24000000;   // Matches H8S for test compat
#else
const UINT32 SYSTEM_CLOCK_FREQUENCY = 600000000;  // 600 MHz RT1024
#endif

const UINT16 MILLISECONDS_IN_SECOND      = 1000;
const UINT16 MICROSECONDS_IN_MILLISECOND = 1000;
const UINT32 SECONDS_IN_MINUTE      = 60;

const UINT8  HARTMODEM_COUNT  = 4;

/*******************************************************************************
*                      INTERRUPT PRIORITY LEVELS                               *
*  H8S: 0=lowest .. 7=highest                                                 *
*  ARM:  0=highest .. 255=lowest (BASEPRI)                                     *
*  We keep the H8S logical names and map through HAL.                          *
*******************************************************************************/
const UINT32 LVLPRI_HIGHEST = 7;
const UINT32 LVLPRI_TICK    = 5;
const UINT32 LVLPRI_GHO     = 4;
const UINT32 LVLPRI_TASK    = 1;
const UINT32 LVLPRI_LOWEST  = 0;

/* Legacy macros — route through HAL */
#define set_imask_exr(level)  hal_interrupt_set_mask(level)
#define get_imask_exr()       hal_interrupt_get_mask()

#define NOP  __asm volatile("nop")

/*******************************************************************************
*                      IOL UART CONSTANTS                                      *
*******************************************************************************/
const UINT32 IOL_BAUDRATE = 375000;   // 375 kbps IOLink

/* IOL RS-485 transmitter enable (active low on H8S/LPC, same convention)      */
const UINT8 IOLDRV_ON  = 0;
const UINT8 IOLDRV_OFF = 1;

/* GHO interrupt register control                                              */
const UINT8 GHO_ENABLED  = 1;
const UINT8 GHO_DISABLED = 0;
const UINT8 GHO_NOTINGAP = 0;

/* 9-bit alert/address mode                                                    */
const UINT8 IOL_ALERT_XMIT_ADDR = 1;   /* TX 9th bit = 1: address frame       */
const UINT8 IOL_ALERT_XMIT_DATA = 0;   /* TX 9th bit = 0: data frame          */
const UINT8 IOL_ALERT_RCV_ADDR  = 1;   /* RX 9th bit = 1: address frame       */

/* FPGA readback register index for IOTA/jabber status                         */
const UINT8 RDBK_IOTA         = 0x05;
const UINT8 JABLOCK_ASSERTED  = 0;     /* active low anti-jabber               */

/* H8S-origin module enable (kept for code compatibility)                      */
const UINT8 MODULE_ENABLED = 0;

/*******************************************************************************
*                      IOL UART ABSTRACTION                                    *
*  Inline wrappers matching armsrc convention (IOL_WriteByte etc.).            *
*  armsrc targeted LPC_UART1 registers; RT1024 routes through HAL LPUART.     *
*******************************************************************************/
#ifdef __cplusplus

#if 1 // RS - 9bit read write
static inline void   IOL_WriteByte(UINT8 x, UINT8 y)  	{ hal_uart_write_byte9(HAL_UART_IOL, x, y); }
static inline UINT16 IOL_ReadByte(void)      		 	{ return hal_uart_read_byte9(HAL_UART_IOL); }
#else
static inline void   IOL_WriteByte(UINT8 x)    			{ hal_uart_write_byte(HAL_UART_IOL, x); }
static inline UINT8  IOL_ReadByte(void)        			{ return hal_uart_read_byte(HAL_UART_IOL); }
#endif
static inline BOOL  IOL_RxDatReady(void)      			{ return hal_uart_rx_ready(HAL_UART_IOL); }
static inline BOOL  IOL_TxEnd(void)           			{ return hal_uart_tx_complete(HAL_UART_IOL); }
static inline BOOL  IOL_TxBufEmpty(void)      			{ return hal_uart_tx_ready(HAL_UART_IOL);  }
static inline void  IOL_RxInterrupt(BOOL en)  			{ hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA, en); }
static inline void  IOL_TxInterrupt(BOOL en)  			{ hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_EMPTY, en); }
static inline void  IOL_TxDoneInterrupt(BOOL en)  		{ hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE, en); }
static inline void  IOL_TxEnable(void)        			{ hal_uart_tx_enable(HAL_UART_IOL, TRUE); }
static inline void  IOL_TxDisable(void)       			{ hal_uart_tx_enable(HAL_UART_IOL, FALSE); }
static inline void  IOL_RxEnable(void)        			{ hal_uart_rx_enable(HAL_UART_IOL, TRUE); }
static inline void  IOL_RxDisable(void)       			{ hal_uart_rx_enable(HAL_UART_IOL, FALSE); }
static inline void  IOL_FifoEnable(void)      			{ hal_uart_clear_errors(HAL_UART_IOL); }
static inline void  IOL_FifoDisable(void)     			{ /* LPUART FIFO is auto-managed */ }
static inline void  IOL_Disable(void)         			{ hal_uart_tx_enable(HAL_UART_IOL, FALSE);
                                                		  hal_uart_rx_enable(HAL_UART_IOL, FALSE); }

static inline void  IOL_DisAllInt(void) {
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA,  FALSE);
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_EMPTY, FALSE);
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE,  FALSE);
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_RX_ERROR, FALSE);
}

/* 9-bit alert / address-mark framing
   H8S:  MP bit in SSR; armsrc: LPC stick-parity trick
   RT1024: LPUART 9-bit mode via CTRL.M / DATA[T8/R8] — wired in hal_uart */
static inline void IOL_TxAlert(UINT8 mode)    { hal_uart_set_tx_9bit(HAL_UART_IOL, mode); }
static inline BOOL IOL_RxAlert(void)          { return (BOOL)hal_uart_get_rx_9bit(HAL_UART_IOL); }

/*******************************************************************************
*                      IOL GPIO ABSTRACTION                                    *
*  Matches armsrc SetTXREQ_n / SetCLR_GHL_n / GHO_INT_Clr convention.         *
*******************************************************************************/
static inline void  SetJABRES_n(UINT8 val)    { hal_gpio_write(HAL_PIN_JABRES_n,  val); }
static inline void  SetRCVSELA_n(UINT8 val)   { hal_gpio_write(HAL_PIN_RCVSELA_n,  val); }
static inline void  SetTXREQ_n(UINT8 val)     { hal_gpio_write(HAL_PIN_TXREQ_n,  val); }
static inline UINT8 GetTXREQ_n(void)          { return hal_gpio_read(HAL_PIN_TXREQ_n);  }
static inline void  SetCLR_GHL_n(UINT8 val)   { hal_gpio_write(HAL_PIN_CLRGHL_n, val); }
static inline void  GHO_INT_Clr(void) {
#if !defined(UNIT_TEST_BUILD) && !defined(QEMU_BUILD)
    /* GHOIRQ_n is on GPIO3_IO17. Clear pending for GPIO3 combined 16-31 IRQ. */
    NVIC_ClearPendingIRQ(GPIO3_Combined_16_31_IRQn);
#endif
}
static inline void  EnableGHOInt(BOOL en) {
#if !defined(UNIT_TEST_BUILD) && !defined(QEMU_BUILD)
    if (en) {
        /* Clear any stale latched edge on GPIO3_IO17 before enabling path. */
        GPIO3->ISR = (1u << 17);
        NVIC_ClearPendingIRQ(GPIO3_Combined_16_31_IRQn);
        /* Enable falling-edge interrupt on GPIO3 pin 17 (GHOIRQ_n active low) */
        GPIO3->IMR |= (1u << 17);
        NVIC_SetPriority(GPIO3_Combined_16_31_IRQn, HAL_IRQ_PRIO_GHO);
        NVIC_EnableIRQ(GPIO3_Combined_16_31_IRQn);
    } else {
        GPIO3->IMR &= ~(1u << 17);
    }
#else
    (void)en;
#endif
}

/* GHOXXX signal — read from GPIO pin on RT1024 (was P_P6.PORT.BIT.B6 on H8S) */
static inline UINT8 GetGHOXXX(void)           { return hal_gpio_read(HAL_PIN_GHOIRQ_n); }
#define GHOXXX  GetGHOXXX()

/* SWBUREQ_n — read/write backup request GPIO                                  */
#define SWBUREQ_n_READ  hal_gpio_read(HAL_PIN_BUPREQ_OUT)
#define SWBUREQ_n_WRITE(v) hal_gpio_write(HAL_PIN_BUPREQ_OUT, (v))

/*******************************************************************************
*                      IOL SILENCE TIMER ABSTRACTION                           *
*  armsrc used LPC Timer1; RT1024 uses HAL_TIMER_IOL_SIL (GPT or PIT).        *
*  Timer count units: microseconds (armsrc used raw LPC timer counts).         *
*******************************************************************************/
static inline void   SilenceTimerStop(void)            { hal_timer_stop(HAL_TIMER_IOL_SIL);  }
static inline void   SilenceTimerStart(void)           { hal_timer_start(HAL_TIMER_IOL_SIL); }
static inline void   SilenceTimerReset(void)           { /* reset handled by stop+configure */ }
static inline void   SilenceTimerSetCount(UINT32 us)   { hal_timer_configure(HAL_TIMER_IOL_SIL, us, NULL); }
static inline void   SilenceTimerIntClr(void)          { /* cleared by HAL timer ISR entry */ }
static inline UINT32 GetGapTimerCnt(void)              { return hal_timer_get_count(HAL_TIMER_IOL_SIL); }

/* Character timeout counter — microsecond busy-wait via hal_delay_us          */
/* armsrc used a dedicated counter; RT1024 uses simple delay                    */
static inline void StartCounter(UINT32 us)             { (void)us; /* see IOL_CHAR_TIMEOUT_US */ }
static inline void StopCounter(void)                   { /* no-op */ }
static inline BOOL IsCounterArrived(void)              { return FALSE; /* see polling loop */ }

/* CPLD / FPGA readback register addressing                                     */
/* CPLD readback bank select → FPGA IOLIOTASR on RT1024                        */
static inline void  SetCPLDAddr(UINT8 addr)   { (void)addr; /* RT1024: readback via direct GPIO/FPGA SPI, no bank select needed */ }
static inline UINT8 GetCPLDAddr(void)          { return RDBK_IOTA; /* always IOTA bank on RT1024 */ }
static inline BOOL  GetJABLOCK_n(void) {
    return (hal_fpga_read8(FPGA_IOLIOTASR) & FPGA_IOTA_JABLOCK_n) ? TRUE : FALSE;
}

#endif /* __cplusplus */

/*******************************************************************************
*                      STACK MONITORING CONSTANTS                              *
*  STACK_TOP: lowest address of the stack (grows down on Cortex-M).            *
*  Derived from linker symbol _vStackBase for RT1024 so it stays in sync       *
*  with the linker script stack size and placement.                            *
*  STACKTESTPATTERN: sentinel value written at STACK_TOP by startup code.      *
*  STACK_SFLIMIT: softfail threshold for remaining stack headroom (bytes).     *
*******************************************************************************/
#if defined(QEMU_BUILD)
  #define STACK_TOP           0x20400000u   /* MPS2-AN500 top of RAM - stack */
  #define STACK_SFLIMIT       0x100u        /* 256 bytes guard area */
#elif defined(UNIT_TEST_BUILD)
  #define STACK_TOP           0x20000000u   /* dummy for tests */
  #define STACK_SFLIMIT       0x100u
#else /* RT1024 */
  extern unsigned int _vStackBase;          /* linker-provided stack bottom */
  #define STACK_TOP           ((UINT32)&_vStackBase)
  #define STACK_SFLIMIT       0x100u
#endif

/*******************************************************************************
*                      MEMORY MAP CONSTANTS                                    *
*  Kept same as H8S for checkpoint/version block compatibility.                *
*******************************************************************************/
#define MODULEINFO_START_ADDRESS    0x00007000u
#define HW_PROD_CODE_OFFSET         0x02u
#define BOOT_VERSION_BLOCK          0x00000170u
#define APP_VERSION_BLOCK           0x00008170u

#if 0
// Offsets in the SPI EEPROM for the calibration and HWINFO.
#if (HEK) || (LOWCOST)
    const UINT8 EE_VENDOR_ID            = 0;
    const UINT8 EE_PRODUCT_TYPE         = 2;
    const UINT8 EE_PRODUCT_CODE         = 4;
    const UINT8 EE_SERIAL_NUMBER        = 6;
    const UINT8 EE_HARDWARE_REVCODE     = 10;
    const UINT8 EE_CALIBRATION_MARK     = 15;
  #ifdef IOMTYPE_AIH
    const UINT8 EE_CALIBRATION_5VREF_HILIMIT    = 16;
    const UINT8 EE_CALIBRATION_5VREF_LOLIMIT    = 20;
    const UINT8 EE_CALIBRATION_SLOPE            = 24;
    const UINT8 EE_CALIBRATION_OFFSET           = 28;
    #if !LOWCOST
    const UINT8 EE_CHANNEL_ZERODRIFT_PTR        = 32;   // AIH
    #else
    const UINT8 EE_CHANNEL_SLOPE_PTR            = 32;   // LOWCOST
    const UINT8 EE_CHANNEL_OFFSET_PTR           = 96;
    #endif
  #elif defined(IOMTYPE_AOH)
    const UINT8 EE_CHANNEL_OFFSET_PTR           = 16;
    const UINT16 EE_CALIBRATION_SLOPE           = 272;
    const UINT16 EE_CALIBRATION_OFFSET          = 276;
    const UINT16 EE_CALIB_TEST_COUNT            = 280;
  #endif
    const UINT16 EE_MODULEINFO_WRITECOUNT       = 506;
    const UINT16 EE_MODULEINFO_WRITE_FLAGS      = 508;
    const UINT16 EE_MODULEINFO_CHKSUM           = 510;
#endif

#define ADDRESS_RANGE_END           (0x00FFFFFF)
#define EEPROM_ADDR_RANGE_START     (0x00000)
#define EEPROM_ADDR_RANGE_END       (0x001FF)
#define EEPROM_CHKSM_ADDR_END       (0x001FE)
#define MAX_EEPROM_SIZE             512
#define EEPROM_PAGE_SIZE            16
#define EEPROM_LOW_PAGE             256

#endif // moved to eeprom.hpp

    // Stack pattern bytes to check against stack corruption
    const UINT32 STACKTESTPATTERN         = 0xFF5AA5FF;
    const UINT32 MAX_CALIBRATION_COUNT    = 200;
    const UINT8  CALIBRATION_DONE         = 0xA5;

    const UINT16 MODULINFO_WRITE_COMPLETE = 0x5A5A;
    const UINT16 EEPROM_MAXWRCOUNT        = 10000;  //MAx 10,000 writes supported for EEPROM
    const UINT8  HWINFO_REVLETTER_MASK    = 0x3F; // to mask out the two unused MSBs.
#if (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT))
    const UINT8  FPGA_REVNUMBER_MASK    = 0x3F;
#elif (defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
    const UINT8  FPGA_REVNUMBER_MASK    = 0x3F;
    const UINT8  CPLD_REVNUMBER_MASK    = 0xFF;
#elif (defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT) || defined(IOMTYPE_DISOE) || defined(IOMTYPE_DISOEBOOT) || defined(IOMTYPE_DO) || defined(IOMTYPE_DOBOOT))
    const UINT8  CPLD_REVNUMBER_MASK    = 0x1F;
#else
    const UINT8  FPGA_REVNUMBER_MASK    = 0xFF;
    const UINT8  CPLD_REVNUMBER_MASK    = 0xFF;
#endif
    // Default manufacturing info values - loaded if module info section is not programmed.
    const UINT32 DEFAULT_SERIAL_NUMBER    = 1234567890;
    const UINT16 HWINFO_VENDOR_ID         = 3;
    const UINT16 DEFAULT_PRODUCT_CODE     = 1;
    const UINT8  DEFAULT_REVNUMBER        = 255;
    const UINT8  REVLETTER_A              = 1;
    const UINT8  REVLETTER_Z              = 26;
    const UINT8  REVLETTER_ZZ             = 0x3A;

/*******************************************************************************
*                      IDLE WAIT UTILITY                                       *
*******************************************************************************/
static inline void IdleWait(UINT32 us) { hal_delay_us(us); }


#ifdef __cplusplus
#include "hal/hart_uart_compat.hpp"
#endif

#endif /* __COMMONELECTRONICS_H__ */
