/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iomslot.hpp                                                 *
*    Description : Abstract base class clsIomSlot for RT1024/QEMU.             *
*                  Stripped to AIH-only (no SP/SVP/UIO/DISOE conditionals).    *
*                  Provides the parameter read/write framework and virtual     *
*                  interface that clsBoxSlot implements.                        *
*******************************************************************************/
#ifndef __IOMSLOT_HPP__
#define __IOMSLOT_HPP__

#include "utils.h"
#include "global.h"



#define LATEST_UIO_AI_SLTCHKPNT_VERSION  2
#define LATEST_SLTCHKPNT_VERSION LATEST_UIO_AI_SLTCHKPNT_VERSION

/*******************************************************************************
*   Write-in-progress semaphore — protects multi-byte params from torn reads. *
*   When a multi-byte write is in progress, ReadParamData redirects to the    *
*   write buffer if the destination address matches.                           *
*******************************************************************************/
typedef struct tagWriteInProgress {
    UINT8 *pDatabase;        /* Address being written (null = idle)          */
    UINT8 *pWriteBuffer;     /* Pointer to the incoming write data           */
} WRITEINPROGRESS;

class clsIomSlot; // forward declaration
/*******************************************************************************
*                                  clsIomSlot                                  *
*                                  ==========                                  *
*  Abstract base for all IO module database slot objects.                      *
*  Derived classes implement GetParamPtr / Pre/PostFunction for each           *
*  parameter number in their database tables.                                  *
*******************************************************************************/
class clsIomSlot {
protected:
    const UINT8 ChanNum;
    static DATABYTES Data;
    static UINT8  ScratchPad;
    static UINT8  WriteIndex;
    static UINT8  SlotChkpntVersion;
    //static UINT8  BoxChkpntVersion;
    //static PASTATUS ucSaveChkpntPaStatus;
    static WRITEINPROGRESS WriteInProgress;

    clsIomSlot(UINT8 a_ucSltNm) : ChanNum(a_ucSltNm) { WriteIndex = 0; }
    virtual ~clsIomSlot(void) {}

    /* Pure virtual — each derived class maps param numbers to memory */
    virtual UINT8 *GetParamPtr(UINT8 a_ucParamId) = 0;
    virtual PASTATUS ExecutePreFunction(UINT8,UINT8 *, UINT8) = 0;
    virtual VOID ExecutePostFunction(UINT8,UINT8) = 0;

    /* Optional hook for opaque DT_BLIND composite records (e.g. an array of
       structs) that contain embedded multi-byte scalar fields (FLOAT32,
       UINT16, etc). The generic Read/WriteParamData copy such records
       byte-for-byte since their internal layout isn't known generically;
       a derived class can override this to byte-swap just the embedded
       scalar fields for a specific a_ucParamId. a_bToWire is TRUE when
       converting the native database copy for output to the caller/wire,
       FALSE when converting an incoming wire buffer before it is stored.
       Default is a no-op (pure passthrough). */
    virtual VOID TransformBlindRecord(UINT8 a_ucParamId, UINT8 *a_pData, UINT8 a_ucSize, BOOL a_bToWire) {
        (void)a_ucParamId; (void)a_pData; (void)a_ucSize; (void)a_bToWire;
    }

#if !defined(IOMTYPE_UIO)
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SlotChkpntVersion;}
#endif

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    //VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,IOMSLOT_HPP,__LINE__); return NULL; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,IOMSLOT_HPP,__LINE__); } 
    clsIomSlot(const clsIomSlot&); // Safeguard against default copy constructor
    clsIomSlot& operator=(const clsIomSlot&); // and default assignment.

public:
    /* Parameter data access — non-virtual for AIH (single IOM type) */
    void ReadParamData(UINT8 *a_pDest, UINT8 a_ucParamId);
    void ReadParamData(UINT8 *a_pDest, UINT8 a_ucParamId, UINT8 a_ucIndex);

    PASTATUS WriteParamData(UINT8 *a_pSrc, UINT8 a_ucParamId, UINT8 a_ucAccessLevel, BOOL a_bDoChkSm = TRUE);
    PASTATUS WriteParamData(UINT8 *a_pSrc, UINT8 a_ucParamId, UINT8 a_ucAccessLevel, UINT8 a_ucIndex);

    /* Database attribute queries — pure virtual */
	virtual BOOL GetIsDbChecksumed(UINT8) = 0;
    virtual DATATYPE   GetDataType(UINT8) = 0;
    virtual ACCESSTYPE GetAccessType(UINT8) = 0;
	virtual UINT8 GetParamSize(UINT8) = 0;
    virtual ACCESSLOCK GetAccessLock(UINT8) = 0;
    virtual PASTATUS   VerifyControlState(UINT8) = 0;

    void   ComputeCheckSum(void);
};

extern clsIomSlot *pDatabase[];

#endif /* __IOMSLOT_HPP__ */
