/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iomslot.cpp                                                 *
*    Description : IOM database interface functions — ReadParamData,           *
*                  WriteParamData, ComputeCheckSum, ComputeRedCheckSum.        *
*                                                                              *
*    Ported from epicio_src/iomslot.cpp (H8S original).                        *
*    Stripped to AIH-only (no SVP/SP/UIO/DISOE conditionals).                  *
*    H8S set_imask_exr/get_imask_exr replaced with HAL calls.                  *
*******************************************************************************/
#include "iomslot.hpp"
#include "boxslot.hpp"
#include "utils.h"

class clsIomSlot;

/*******************************************************************************
*                          STATIC DATA                                         *
*******************************************************************************/
DATABYTES       clsIomSlot::Data;
UINT8           clsIomSlot::ScratchPad = 0;
UINT8           clsIomSlot::WriteIndex = 0;
UINT8           clsIomSlot::SlotChkpntVersion = 0;
//UINT8           clsIomSlot::BoxChkpntVersion = 0;
//PASTATUS        clsIomSlot::ucSaveChkpntPaStatus = PA_OK;
WRITEINPROGRESS clsIomSlot::WriteInProgress = { NULL, NULL };

/*******************************************************************************
*                   IsMultiByteScalar (local helper)                           *
*                   =================================                         *
* PURPOSE:                                                                     *
*    AT_MBYTE covers two very different things: true multi-byte numeric        *
*    scalars (UINT16/INT16/UINT32/INT32/FLOAT32) that need byte-order          *
*    conversion between the wire (big-endian, inherited from the H8S)  and     *
*    this ARM Cortex-M7's native little-endian storage, and opaque DT_BLIND    *
*    byte arrays/records (device tags, HART frames, etc.) that must be         *
*    copied byte-for-byte with no reordering.  This distinguishes the two.     *
*******************************************************************************/
static inline BOOL IsMultiByteScalar(DATATYPE a_dt, UINT8 a_ucSize)
{
    if (a_ucSize < 2u || a_ucSize > (UINT8)sizeof(DATABYTES)) {
        return FALSE;
    }
    switch (a_dt) {
        case DT_UINT16:
        case DT_INT16:
        case DT_UINT32:
        case DT_INT32:
        case DT_FLOAT32:
            return TRUE;
        default:
            return FALSE;
    }
}

/*******************************************************************************
*                   clsIomSlot::ReadParamData (basic)                          *
*                   ================================                           *
* PURPOSE:                                                                     *
*    Read parameter data from the database into a_pDest.  Dispatches by        *
*    AccessType: SBYTE, MBYTE, PSET, BXPACK, BXREC.                            *
* ARGUMENTS:                                                                   *
*    a_pDest     : destination buffer for the parameter data.                  *
*    a_ucParamId : parameter index (0–255).                                    *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    WriteInProgress guard prevents torn reads on multi-byte params.           *
*******************************************************************************/
void clsIomSlot::ReadParamData(UINT8 *a_pDest, UINT8 a_ucParamId)
{
    UINT8 *pSource = GetParamPtr(a_ucParamId);
    if (pSource == NULL) {
        return;
    }

    ACCESSTYPE at = GetAccessType(a_ucParamId);

    switch (at) {
        case AT_SBYTE:
            *a_pDest = *pSource;
            break;

        case AT_MBYTE: {
            /* Redirect to write buffer if a write is in progress to this
               exact location — prevents torn reads of multi-byte data */
            UINT8 *pActual = pSource;
            if (WriteInProgress.pDatabase == pSource &&
                WriteInProgress.pWriteBuffer != NULL) {
                pActual = WriteInProgress.pWriteBuffer;
            }
            UINT8 ucSize = GetParamSize(a_ucParamId);
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucSize)) {
                /* Numeric scalar: native byte order -> wire byte order. */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pActual[ucSize - 1u - i];
                }
            } else {
                /* Opaque BLIND byte array/record: copy as-is, then let the
                   derived class swap any embedded scalar fields it knows
                   about (e.g. a FLOAT32 inside a repeating struct array). */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pActual[i];
                }
                TransformBlindRecord(a_ucParamId, a_pDest, ucSize, TRUE);
            }
            break;
        }

        case AT_PSET: {
            /* Parameter-set: pSource is a null-terminated list of
               sub-parameter IDs. Walk the list, copying each sub-param. */
            while (*pSource != 0) {
                UINT8 ucSubParam = *pSource;
                UINT8 *pSubSrc   = GetParamPtr(ucSubParam);
                UINT8  ucSubSz   = GetParamSize(ucSubParam);

                if (pSubSrc != NULL) {
                    /* Check WriteInProgress for multi-byte sub-params */
                    if (ucSubSz > 1 &&
                        WriteInProgress.pDatabase == pSubSrc &&
                        WriteInProgress.pWriteBuffer != NULL) {
                        pSubSrc = WriteInProgress.pWriteBuffer;
                    }
                    if (IsMultiByteScalar(GetDataType(ucSubParam), ucSubSz)) {
                        for (UINT8 j = 0; j < ucSubSz; j++) {
                            a_pDest[j] = pSubSrc[ucSubSz - 1u - j];
                        }
                        a_pDest += ucSubSz;
                    } else {
                        for (UINT8 j = 0; j < ucSubSz; j++) {
                            *a_pDest++ = *pSubSrc++;
                        }
                    }
                }
                pSource++;
            }
            /* For large checkpoint reads, reset STC overrun counter so the
               IOL TX phase doesn't trigger a spurious STC overrun softfail. */
            if (ChanNum != 0 && a_ucParamId == PARAMID_SLTCHKPNT) {
                //TaskScheduler.SetStcOverrunCounter(1);
            }
            break;
        }

        case AT_BXPACK: {
            /* Box-packed bitmap: each channel's data is one bit inside
               a box-level byte array.  Extract the bit for this channel. */
            UINT8 ucBitIndex  = 0x80u >> ((ChanNum - 1) & 0x07);
            UINT8 ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
            *a_pDest = (pSource[ucByteIndex] & ucBitIndex) ? TRUE : FALSE;
            break;
        }

        case AT_BXREC: {
            /* Box blind record: block copy under interrupt protection */
            UINT8 ucSize = GetParamSize(a_ucParamId);
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucSize)) {
                /* Numeric scalar (e.g. per-channel Pv): native -> wire order. */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[ucSize - 1u - i];
                }
            } else {
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[i];
                }
                TransformBlindRecord(a_ucParamId, a_pDest, ucSize, TRUE);
            }
            break;
        }

        default:
            HardFail(HF_BADPROGRAMJUMP, IOMSLOT_CPP, __LINE__);
            break;
    }
}

/*******************************************************************************
*                   clsIomSlot::ReadParamData (indexed)                        *
*                   ===================================                        *
* PURPOSE:                                                                     *
*    Legacy one-based indexed parameter read used by IOL command 0x10.         *
*    HART dynamic variables (211-218) are arrays whose table size describes   *
*    one element, not the complete array.                                      *
*******************************************************************************/
void clsIomSlot::ReadParamData(UINT8 *a_pDest, UINT8 a_ucParamId, UINT8 a_ucIndex)
{
    if (a_ucIndex == 0u) {
        return;
    }

    UINT8 ucSize = GetParamSize(a_ucParamId);
    UINT8 *pSource = GetParamPtr(a_ucParamId);
    if ((pSource == NULL) || (ucSize == 0u)) {
        return;
    }

    pSource += ((UINT16)ucSize * (UINT16)(a_ucIndex - 1u));

    switch (GetAccessType(a_ucParamId)) {
        case AT_SBYTE:
            *a_pDest = *pSource;
            break;

        case AT_MBYTE:
            if ((WriteInProgress.pDatabase == pSource) &&
                (WriteInProgress.pWriteBuffer != NULL)) {
                pSource = WriteInProgress.pWriteBuffer;
            }
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucSize)) {
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[ucSize - 1u - i];
                }
            } else {
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[i];
                }
            }
            break;

        case AT_BITPACK: {
            /* Legacy indexed bitmap parameters (for example HCmd48BT) use a
               one-based bit index, not an element-size byte offset. */
            UINT8 *pBitmap = GetParamPtr(a_ucParamId);
            const UINT8 ucZeroBased = (UINT8)(a_ucIndex - 1u);
            const UINT8 ucByteIndex = (UINT8)(ucZeroBased >> 3u);
            const UINT8 ucBitMask =
                (UINT8)(0x01u << (ucZeroBased & 0x07u));
            *a_pDest = ((pBitmap[ucByteIndex] & ucBitMask) != 0u) ?
                       TRUE : FALSE;
            break;
        }

        default:
            HardFail(HF_BADPROGRAMJUMP, IOMSLOT_CPP, __LINE__);
            break;
    }
}




PASTATUS clsIomSlot::WriteParamData(UINT8 *a_pSrc, UINT8 a_ucParamId, UINT8 a_ucAccessLevel, BOOL a_bDoChkSm)
{
    UINT8 *pDestination = GetParamPtr(a_ucParamId);
    if (pDestination == NULL) {
        return DO_PARAMETER_INVALID;
    }

    const ACCESSTYPE AccessType = GetAccessType(a_ucParamId);
    const UINT8 ucParamSize = GetParamSize(a_ucParamId);
    PASTATUS PaStatus = PA_OK;

    /* Match the legacy contract: the third argument is the caller's access
       level.  It is not the number of bytes in the write. */
    if (AccessType != AT_PSET) {
        const ACCESSLOCK AccessLock = GetAccessLock(a_ucParamId);
        if (AccessLock == ALCK_VIEW) {
            return DO_READ_ONLY_PARAMETER;
        }
        if ((AccessLock & a_ucAccessLevel) == 0u) {
            return DO_ACCESS_LEVEL_INVALID;
        }

        PaStatus = VerifyControlState(a_ucParamId);
        if (PaStatus != PA_OK) {
            return PaStatus;
        }

        if (ucParamSize <= (UINT8)sizeof(DATABYTES)) {
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucParamSize)) {
                for (UINT8 i = 0; i < ucParamSize; i++) {
                    Data.ucBytes[i] = a_pSrc[ucParamSize - 1u - i];
                }
            } else {
                for (UINT8 i = 0; i < ucParamSize; i++) {
                    Data.ucBytes[i] = a_pSrc[i];
                }
            }

            PaStatus = ExecutePreFunction(
                a_ucParamId, Data.ucBytes, a_ucAccessLevel);
        } else {
            PaStatus = ExecutePreFunction(
                a_ucParamId, a_pSrc, a_ucAccessLevel);
        }

        if (PaStatus > PA_OK) {
            return PaStatus;
        }
    }

    if (PaStatus != PA_REDDATA_BYPASS) {
        if (AccessType == AT_PSET) {
            /* The destination is the legacy null-terminated list of member
               parameter IDs.  Each member keeps the same access level and
               executes its own Pre/Post functions in the same sequence. */
            UINT8 *pSubParam = pDestination;
            UINT8 *pWrite = a_pSrc;

            while (*pSubParam != 0u) {
                const UINT8 ucSubSize = GetParamSize(*pSubParam);
                PaStatus = WriteParamData(
                    pWrite, *pSubParam, a_ucAccessLevel, FALSE);
                if (PaStatus > PA_OK) {
                    ComputeCheckSum();
                    return PaStatus;
                }
                pWrite += ucSubSize;
                pSubParam++;
            }
        } else {
            UINT32 uiSavedMask = hal_interrupt_set_mask(LVLPRI_TICK);

            switch (AccessType) {
                case AT_SBYTE:
                    *pDestination = Data.ucBytes[0];
                    break;

                case AT_MBYTE: {
                    UINT8 *pCopySource =
                        (ucParamSize <= (UINT8)sizeof(DATABYTES)) ?
                        Data.ucBytes : a_pSrc;

                    WriteInProgress.pDatabase = pDestination;
                    WriteInProgress.pWriteBuffer = pCopySource;
                    for (UINT8 i = 0; i < ucParamSize; i++) {
                        pDestination[i] = pCopySource[i];
                    }
                    break;
                }

                case AT_BXPACK: {
                    if (ChanNum == 0u) {
                        hal_interrupt_set_mask(uiSavedMask);
                        return DO_INVALID_SLOT_INDEX;
                    }
                    const UINT8 ucBitIndex =
                        (UINT8)(0x80u >> ((ChanNum - 1u) & 0x07u));
                    const UINT8 ucByteIndex =
                        (UINT8)(((ChanNum - 1u) >> 3u) & 0x03u);
                    if (Data.ucBytes[0] != 0u) {
                        pDestination[ucByteIndex] |= ucBitIndex;
                    } else {
                        pDestination[ucByteIndex] &= (UINT8)~ucBitIndex;
                    }
                    break;
                }

                case AT_BXREC: {
                    UINT8 *pCopySource =
                        (ucParamSize <= (UINT8)sizeof(DATABYTES)) ?
                        Data.ucBytes : a_pSrc;
                    UINT32 uiHighestMask =
                        hal_interrupt_set_mask(LVLPRI_HIGHEST);
                    for (UINT8 i = 0; i < ucParamSize; i++) {
                        pDestination[i] = pCopySource[i];
                    }
                    hal_interrupt_set_mask(uiHighestMask);
                    break;
                }

                default:
                    hal_interrupt_set_mask(uiSavedMask);
                    return DO_DATA_TYPE_ERROR;
            }

            WriteInProgress.pDatabase = NULL;
            WriteInProgress.pWriteBuffer = NULL;
            hal_interrupt_set_mask(uiSavedMask);
        }
    }

    ExecutePostFunction(a_ucParamId, a_ucAccessLevel);

    if (a_bDoChkSm && GetIsDbChecksumed(a_ucParamId)) {
        ComputeCheckSum();
    }

    return PaStatus;
}

/*******************************************************************************
*                   clsIomSlot::WriteParamData (indexed)                       *
*                   ====================================                       *
* PURPOSE:                                                                     *
*    Legacy one-based indexed write used by IOL command 0x12.  WriteIndex is  *
*    set before Pre/Post callbacks because box HADC callbacks use it to select *
*    the channel.                                                              *
*******************************************************************************/
PASTATUS clsIomSlot::WriteParamData(UINT8 *a_pSrc,
                                    UINT8 a_ucParamId,
                                    UINT8 a_ucAccessLevel,
                                    UINT8 a_ucIndex)
{
    if (a_ucIndex == 0u) {
        return DO_INVALID_SLOT_INDEX;
    }

    const ACCESSTYPE AccessType = GetAccessType(a_ucParamId);
    const UINT8 ucParamSize = GetParamSize(a_ucParamId);
    const ACCESSLOCK AccessLock = GetAccessLock(a_ucParamId);
    UINT8 *pDestination = GetParamPtr(a_ucParamId);

    if ((pDestination == NULL) || (ucParamSize == 0u)) {
        return DO_PARAMETER_INVALID;
    }
    if ((AccessType != AT_SBYTE) && (AccessType != AT_MBYTE)) {
        return DO_DATA_TYPE_ERROR;
    }
    if (AccessLock == ALCK_VIEW) {
        return DO_READ_ONLY_PARAMETER;
    }
    if ((AccessLock & a_ucAccessLevel) == 0u) {
        return DO_ACCESS_LEVEL_INVALID;
    }

    PASTATUS PaStatus = VerifyControlState(a_ucParamId);
    if (PaStatus != PA_OK) {
        return PaStatus;
    }
    if (ucParamSize > (UINT8)sizeof(DATABYTES)) {
        return DO_DATA_TYPE_ERROR;
    }

    if (IsMultiByteScalar(GetDataType(a_ucParamId), ucParamSize)) {
        for (UINT8 i = 0; i < ucParamSize; i++) {
            Data.ucBytes[i] = a_pSrc[ucParamSize - 1u - i];
        }
    } else {
        for (UINT8 i = 0; i < ucParamSize; i++) {
            Data.ucBytes[i] = a_pSrc[i];
        }
    }

    WriteIndex = a_ucIndex;
    PaStatus = ExecutePreFunction(
        a_ucParamId, Data.ucBytes, a_ucAccessLevel);
    if (PaStatus > PA_OK) {
        return PaStatus;
    }

    if (PaStatus != PA_REDDATA_BYPASS) {
        pDestination +=
            ((UINT16)ucParamSize * (UINT16)(a_ucIndex - 1u));

        UINT32 uiSavedMask = hal_interrupt_set_mask(LVLPRI_TICK);
        if (AccessType == AT_SBYTE) {
            *pDestination = Data.ucBytes[0];
        } else {
            WriteInProgress.pDatabase = pDestination;
            WriteInProgress.pWriteBuffer = Data.ucBytes;
            for (UINT8 i = 0; i < ucParamSize; i++) {
                pDestination[i] = Data.ucBytes[i];
            }
        }
        WriteInProgress.pDatabase = NULL;
        WriteInProgress.pWriteBuffer = NULL;
        hal_interrupt_set_mask(uiSavedMask);
    }

    ExecutePostFunction(a_ucParamId, a_ucAccessLevel);
    if (GetIsDbChecksumed(a_ucParamId)) {
        ComputeCheckSum();
    }
    return PaStatus;
}


/*******************************************************************************
*                   clsIomSlot::ComputeCheckSum                                *
*                   ===========================                                *
* PURPOSE:                                                                     *
*    Byte-sum checksum over all parameters in the checkpoint record.           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None (stores result via SetCheckSum).                                     *
* NOTES:                                                                       *
*    Walks the null-terminated sub-parameter ID list at the checkpoint ptr.    *
*******************************************************************************/
void clsIomSlot::ComputeCheckSum(void)
{
  UINT16 ulChecksum = 0;
  UINT8 *pChkPnt;

  if (ChanNum == 0) {
      pChkPnt = GetParamPtr(PARAMID_BOXCHKPNT);
  } else {
      pChkPnt = GetParamPtr(PARAMID_SLTCHKPNT);
  }

  if (pChkPnt == NULL) {
      ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, 0);
      return;
  }

  /* Iterate the null-terminated sub-parameter ID list */
  while (*pChkPnt != 0) {
      UINT8 ucSubParam = *pChkPnt;
      UINT8 *pParam    = GetParamPtr(ucSubParam);
      UINT8  ucParamSz = GetParamSize(ucSubParam);

      if (pParam != NULL) {
          for (UINT8 j = 0; j < ucParamSz; j++) {
              ulChecksum += pParam[j];
          }
      }

      pChkPnt++;
  }

  ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, ulChecksum);
}
