/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : wrdbtask.cpp                                                *
*    Description : WriteDatabase task for RT1024/QEMU — AIH-only.             *
*                  Processes IOL write messages from the queue.                *
*******************************************************************************/

#include "iol.hpp"

clsWriteMsgQueue WriteMsgQueue;

extern clsIomSlot *pDatabase[];

UINT8 ValidateWrMessage (clsIomSlot *,UINT8 *,UINT8);

TASKRETURN WriteDatabaseTask(TASKCONTEXT a_TaskContext) {

	const UINT8 WRDBTASK_MAX_EXEC_TIME = 5;  /* 50ms max continuous run */
	const UINT8 WRDBTASK_SUSPEND_TIME  = 2;  /* 20ms suspend */

	TASKRETURN TaskReturnValue;
	TaskReturnValue.TaskContext = a_TaskContext;
	UINT32 ulTimeStart = TaskScheduler.Get10msecCounter();

	if (REDSTATE_FROZEN > BOX->GetRedState()) {

		while (WriteMsgQueue.IsRcvBfrEmpty() == FALSE) {

			UINT8 ucMsgStatus = IOL_WM_IN_PROGRESS;
			// Get next message pointer from the write message queue object
			UINT8 *ucpMsg    = WriteMsgQueue.GetNextMsgPtr();
			UINT8 ucMsgSize  = ucpMsg[IOLMSG_NUMBER];
			UINT8 ucMsgNumber = ucpMsg[ucMsgSize];

			// Construct pointer to the database object to which write is addressed
			clsIomSlot *pIomSlot = pDatabase[ucpMsg[IOLREQ_SLOTNUM]];

			switch (ucpMsg[IOLMSG_COMMAND]) {

			case WRCMD_BLOCKABSOLUTE:
				/* Absolute writes are restricted on RT1024 */
#if 0
				DATABYTES address;
				UINT8     *pDest,*pSrc,ucCount;
				if (ucpMsg[IOLMSG_NUMBER] - IOLWRMSG_OVERHEAD != ucpMsg[IOLREQ_ABSNUM]) {

					ucMsgStatus = DO_WM_INSUF_DATA;
					break;
				}
				if (BOX->GetModuleStatus() != MODSTATUS_IDLE) {

					ucMsgStatus = DO_STATE_MUST_BE_IDLE;
					break;
				}
				address.ucBytes[0] = 0;
				address.ucBytes[1] = ucpMsg[IOLREQ_12DATA];
				address.ucBytes[2] = ucpMsg[IOLREQ_12DATA+1];
				address.ucBytes[3] = ucpMsg[IOLREQ_12DATA+2];
				pDest = (UINT8 *) address.ui32Val;
                pSrc = &ucpMsg[IOLREQ_WRDATA];
                for (ucCount=ucpMsg[IOLREQ_ABSNUM]; ucCount>0; ucCount--) {

                    *pDest++ = *pSrc++;
                }
                ucMsgStatus = PA_OK;
#endif
				ucMsgStatus = DO_FUNCTION_NOT_IMPLEMENTED;
				break;
			case WRCMD_NORMAL:
				if ((ucMsgStatus = ValidateWrMessage(pIomSlot, ucpMsg, 0)) == PA_OK) {

					ucMsgStatus = pIomSlot->WriteParamData(&ucpMsg[IOLREQ_WRDATA], ucpMsg[IOLREQ_PARAMID], ucpMsg[IOLREQ_ACCLVL]);
				}
				break;
			case WRCMD_INDEXED:
				if ((ucMsgStatus = ValidateWrMessage(pIomSlot, ucpMsg, 1)) == PA_OK) {
					ucMsgStatus = pIomSlot->WriteParamData(
						&ucpMsg[IOLREQ_WRDATA + 1],
						ucpMsg[IOLREQ_PARAMID],
						ucpMsg[IOLREQ_ACCLVL + 1],
						ucpMsg[IOLREQ_INDEX]);
				}
				break;
			case CMD_WRINDEXDEFERRED:
				ucMsgStatus = DO_COMMAND_NOT_SUPPORTED;
				break;
			case CMD_FREEZE:
				if (BOX->GetRedState() == REDSTATE_FREEZE_ACCEPTED) {
					BOX->SetRedState(REDSTATE_FROZEN);
#if 0 //#ifdef IOMTYPE_AIH
					TraceLog.AddToTrace(TRACEID_GENERIC,bcFrozen,
							((BOX->GetRedData() << BYTESIZE) | BOX->GetRedState()));
#endif
				}
				else BOX->SetRedState(REDSTATE_FREEZE_NOT_ACCEPTED);
				Iol.ResetDumpIndex();
				ucMsgStatus = PA_OK;
				break;
			default:
				HardFail(HF_BADPROGRAMJUMP, WRDBTASK_CPP, __LINE__);
				break;
			}

			WriteMsgQueue.SetMsgStatus(ucMsgNumber, ucMsgStatus);
			WriteMsgQueue.RemoveMessage(ucMsgNumber, ucMsgSize);

			/* Co-operative yield if running too long */
			UINT32 ulNow = TaskScheduler.Get10msecCounter();
			UINT32 ulElapsed = (ulNow >= ulTimeStart) ? (ulNow - ulTimeStart) : (MAXUINT32 - ulTimeStart + 1 + ulNow);

			if (ulElapsed >= WRDBTASK_MAX_EXEC_TIME) {

				TaskReturnValue.ucSuspendTime   = WRDBTASK_SUSPEND_TIME;
				TaskReturnValue.TaskReturnState = TASKRETURNSTATE_SUSPEND;
				return TaskReturnValue;
			}
		}
	}

	TaskReturnValue.ucSuspendTime   = 0;
	TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
	return TaskReturnValue;
}


UINT8 ValidateWrMessage (clsIomSlot *pIomSlot, UINT8 *ucpMsg, UINT8 ucOffset)
{
#ifdef IOMTYPE_PI
    if ((PARAMID_TV == ucpMsg[IOLREQ_PARAMID]) && (DT_BLIND == ucpMsg[IOLREQ_DATATYPE])){
        ucpMsg[IOLREQ_PARAMID] = PARAMID_TV64;
        ucpMsg[IOLREQ_DATATYPE] = DT_FLOAT64;
    }
#endif

    UINT8 ucActualDataType = pIomSlot->GetDataType(ucpMsg[IOLREQ_PARAMID]);

    // Validate parameter number.
    if (DT_NONE == ucActualDataType)
    {
        return DO_PARAMETER_INVALID;
    }

    // Validate parameter data type.
    else if (ucActualDataType != ucpMsg[IOLREQ_DATATYPE + ucOffset])
    {
        return DO_DATA_TYPE_ERROR;
    }

    // Validate parameter size.
    else {

        //due to checkpoint version not existing in PMIO
        if ((ucpMsg[IOLMSG_NUMBER] - IOLWRMSG_OVERHEAD - ucOffset) < pIomSlot->GetParamSize(ucpMsg[IOLREQ_PARAMID]))
        {
            return DO_WM_INSUF_DATA;
        }
    }

    return PA_OK;
}

