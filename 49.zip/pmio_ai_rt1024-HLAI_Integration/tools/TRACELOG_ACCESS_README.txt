PMIO external-flash TraceLog access
===================================

Build 40 keeps the TraceLog in U30, the W25Q128JV 16 MiB SPI NOR flash on
the physical BKP_CS1_n net. The driver controls that pin explicitly and uses
LPSPI3 for SCK/MOSI/MISO. The legacy 100-record, 10-byte TraceLog object remains
unchanged for application and IO-Link compatibility:

    UINT16 code
    UINT32 data
    UINT32 time

External-flash allocation
-------------------------

    U30 JEDEC IDs accepted:   EF 40 18 and EF 70 18
    TraceLog reserved base:   0x00FC0000
    TraceLog reserved size:   0x00040000 (256 KiB)
    Logical TraceLog store:   2048 bytes

The store is an append-only, CRC-protected journal with two committed checkpoint
banks. Each entry is committed last, so an interrupted program operation is
ignored after reset. A full logical checkpoint protects unchanged records
before old normal-journal sectors are reclaimed.

The reserved range must remain excluded from every other U30 user. Change
HAL_TRACESTORE_FLASH_BASE and HAL_TRACESTORE_FLASH_BYTES in
source/hal/hal_tracestore.h if the product-level diagnostics allocation differs.

1. Console test and dump
------------------------

This validation build enables the startup test, one-time test summary, and
automatic latest-record dump. Look for:

    TRACELOG TEST INIT=1 RW=1 HDR=1 ...
    TRACELOG FLASH JEDEC=EF7018 BASE=00FC0000 SIZE=262144 ... STAGE=7 INITERR=0 ...
    TRACELOG DUMP BEGIN ...
    TRACELOG DUMP INDEX=... CODE=... NAME=... DATA=... TIME=...
    TRACELOG DUMP END ...

On the first boot, RESTORED and RET may be 0 because no previous valid image
exists. After a reset or power cycle they should be 1, and BOOT should increase.

To request another dump in the MCUXpresso debugger, set:

    g_ucTraceLogConsoleDumpCount = 20
    g_bTraceLogConsoleDumpRequest = 1

Then resume. Use 80 to dump the complete circular application block.
Records 80-99 are the preserved crash block and are not included in the normal
newest-first console dump.

2. Debugger
-----------

Inspect:

    TraceLog.m_ucAppIndex
    TraceLog.TraceRecord[0] ... TraceLog.TraceRecord[99]

The object members are private in C++, so some debugger configurations may
require direct memory/structure expansion rather than an expression.

3. IO-Link parameters
---------------------

    165 TraceLog
    166 TraceLogInfo
    167 TraceLevel

In the current RT1024 database implementation, parameter 165 has a size of
100 bytes. Since one record is 10 bytes, one parameter read exposes a 10-record
window, not the full 100-record array. Parameter 166 returns the 4-byte trace
time and 1-byte next index.

Decode bytes copied from the IO-Link tool:

    python tools/decode_tracelog.py trace_hex.txt --input-format hex --byte-order big

Decode a raw little-endian debugger memory capture:

    python tools/decode_tracelog.py trace.bin --input-format binary --byte-order little -o trace.csv

Production switch-off
---------------------

After board validation, set these macros in source/tracelog.hpp to 0:

    TRACELOG_FLASH_STARTUP_TEST
    TRACELOG_FLASH_TEST_PRINT
    TRACELOG_CONSOLE_DUMP_ON_BOOT
