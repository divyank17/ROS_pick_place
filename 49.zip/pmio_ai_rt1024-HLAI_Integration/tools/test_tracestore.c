#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "../source/hal/hal_extflash.h"
#include "../source/hal/hal_tracestore.h"

static uint8_t s_flash[HAL_EXTFLASH_CAPACITY_BYTES];
static bool s_initialized = false;
static int s_failProgramCall = -1;
static int s_programCalls = 0;

enum
{
    TEST_ENTRY_BYTES = 64u,
    TEST_CHECKPOINT_SECTORS = 4u,
    TEST_NORMAL_ENTRY_COUNT =
        (HAL_TRACESTORE_FLASH_BYTES / TEST_ENTRY_BYTES) -
        (TEST_CHECKPOINT_SECTORS *
         (HAL_EXTFLASH_SECTOR_BYTES / TEST_ENTRY_BYTES))
};

static void ResetMockFlash(void)
{
    memset(s_flash, 0xFF, sizeof(s_flash));
    s_initialized = true;
    s_failProgramCall = -1;
    s_programCalls = 0;
}

bool hal_extflash_init(void)
{
    if (!s_initialized)
    {
        memset(s_flash, 0xFF, sizeof(s_flash));
        s_initialized = true;
    }
    return true;
}

bool hal_extflash_is_ready(void)
{
    return true;
}

bool hal_extflash_read_jedec_id(uint8_t id[3])
{
    id[0] = HAL_EXTFLASH_JEDEC_MFR;
    id[1] = HAL_EXTFLASH_JEDEC_TYPE;
    id[2] = HAL_EXTFLASH_JEDEC_CAPACITY;
    return true;
}

bool hal_extflash_read(uint32_t address, void *destination, size_t length)
{
    memcpy(destination, &s_flash[address], length);
    return true;
}

bool hal_extflash_program(uint32_t address,
                          const void *source,
                          size_t length)
{
    if (s_programCalls++ == s_failProgramCall)
    {
        return false;
    }

    const uint8_t *input = (const uint8_t *)source;
    for (size_t index = 0u; index < length; ++index)
    {
        s_flash[address + index] &= input[index];
    }
    return true;
}

bool hal_extflash_erase_sector(uint32_t address)
{
    address &= ~(HAL_EXTFLASH_SECTOR_BYTES - 1u);
    memset(&s_flash[address], 0xFF, HAL_EXTFLASH_SECTOR_BYTES);
    return true;
}

bool hal_extflash_is_erased(uint32_t address, size_t length)
{
    for (size_t index = 0u; index < length; ++index)
    {
        if (s_flash[address + index] != 0xFFu)
        {
            return false;
        }
    }
    return true;
}

uint32_t hal_extflash_get_error_count(void)
{
    return 0u;
}

uint32_t hal_extflash_get_raw_jedec_id(void)
{
    return 0x00EF4018u;
}

uint32_t hal_extflash_get_init_stage(void)
{
    return HAL_EXTFLASH_STAGE_READY;
}

uint32_t hal_extflash_get_init_error(void)
{
    return HAL_EXTFLASH_INIT_ERROR_NONE;
}

int32_t hal_extflash_get_last_transfer_status(void)
{
    return 0;
}

uint8_t hal_extflash_get_last_status1(void)
{
    return 0u;
}

static void TestBlankWriteAndRestart(void)
{
    uint8_t expected[100];
    uint8_t actual[100];

    ResetMockFlash();

    for (uint32_t index = 0u; index < sizeof(expected); ++index)
    {
        expected[index] = (uint8_t)(index ^ 0xA5u);
    }

    assert(hal_tracestore_init());
    assert(hal_tracestore_get_jedec_id() == 0x00EF4018u);
    assert(hal_tracestore_write(17u, expected, sizeof(expected)));
    assert(hal_tracestore_read(17u, actual, sizeof(actual)));
    assert(memcmp(expected, actual, sizeof(expected)) == 0);

    memset(actual, 0, sizeof(actual));
    assert(hal_tracestore_init());
    assert(hal_tracestore_read(17u, actual, sizeof(actual)));
    assert(memcmp(expected, actual, sizeof(expected)) == 0);
}

static void TestInterruptedCommitIsRejected(void)
{
    const uint8_t oldValue[8] =
        { 1u, 2u, 3u, 4u, 5u, 6u, 7u, 8u };
    const uint8_t newValue[8] =
        { 9u, 10u, 11u, 12u, 13u, 14u, 15u, 16u };
    uint8_t actual[8];

    ResetMockFlash();
    assert(hal_tracestore_init());
    assert(hal_tracestore_write(500u, oldValue, sizeof(oldValue)));

    s_programCalls = 0;
    s_failProgramCall = 1; /* Fail commit-marker program. */
    assert(!hal_tracestore_write(500u, newValue, sizeof(newValue)));
    s_failProgramCall = -1;

    assert(hal_tracestore_init());
    assert(hal_tracestore_read(500u, actual, sizeof(actual)));
    assert(memcmp(oldValue, actual, sizeof(oldValue)) == 0);

    assert(hal_tracestore_write(500u, newValue, sizeof(newValue)));
    assert(hal_tracestore_init());
    assert(hal_tracestore_read(500u, actual, sizeof(actual)));
    assert(memcmp(newValue, actual, sizeof(newValue)) == 0);
}

static void TestCheckpointPreservesCompleteLogicalImage(void)
{
    uint8_t expected[HAL_TRACESTORE_CAPACITY_BYTES];
    uint8_t actual[HAL_TRACESTORE_CAPACITY_BYTES];
    uint32_t value = 0u;
    const uint32_t baselineEntries =
        HAL_TRACESTORE_CAPACITY_BYTES / 32u;

    ResetMockFlash();
    assert(hal_tracestore_init());

    for (uint32_t index = 0u; index < sizeof(expected); ++index)
    {
        expected[index] = (uint8_t)((index * 37u) ^ 0x5Au);
    }

    assert(hal_tracestore_write(0u, expected, sizeof(expected)));

    /*
     * Fill the normal journal, force checkpoint A, then continue far enough
     * to exercise normal-sector reclamation.
     */
    for (uint32_t index = 0u;
         index < (TEST_NORMAL_ENTRY_COUNT - baselineEntries + 200u);
         ++index)
    {
        value = 0x12340000u | index;
        assert(hal_tracestore_write(1000u, &value, sizeof(value)));
        memcpy(&expected[1000u], &value, sizeof(value));
    }

    assert(hal_tracestore_init());
    assert(hal_tracestore_read(0u, actual, sizeof(actual)));
    assert(memcmp(expected, actual, sizeof(expected)) == 0);

    /*
     * Force a second complete wrap so the alternate checkpoint bank is used.
     * Bytes which are never updated after the original baseline must survive.
     */
    for (uint32_t index = 0u;
         index < (TEST_NORMAL_ENTRY_COUNT + 200u);
         ++index)
    {
        value = 0x56780000u | index;
        assert(hal_tracestore_write(1500u, &value, sizeof(value)));
        memcpy(&expected[1500u], &value, sizeof(value));
    }

    assert(hal_tracestore_init());
    assert(hal_tracestore_read(0u, actual, sizeof(actual)));
    assert(memcmp(expected, actual, sizeof(expected)) == 0);
}

static void TestInterruptedCheckpointKeepsPreviousImage(void)
{
    uint8_t expected[HAL_TRACESTORE_CAPACITY_BYTES];
    uint8_t actual[HAL_TRACESTORE_CAPACITY_BYTES];
    uint32_t value = 0u;
    uint32_t failedValue = 0xDEADBEEFu;
    const uint32_t baselineEntries =
        HAL_TRACESTORE_CAPACITY_BYTES / 32u;

    ResetMockFlash();
    assert(hal_tracestore_init());

    for (uint32_t index = 0u; index < sizeof(expected); ++index)
    {
        expected[index] = (uint8_t)(index ^ (index >> 3));
    }

    assert(hal_tracestore_write(0u, expected, sizeof(expected)));

    for (uint32_t index = 0u;
         index < (TEST_NORMAL_ENTRY_COUNT - baselineEntries);
         ++index)
    {
        value = 0xABC00000u | index;
        assert(hal_tracestore_write(700u, &value, sizeof(value)));
        memcpy(&expected[700u], &value, sizeof(value));
    }

    /*
     * The next write starts a checkpoint. Fail after several checkpoint data
     * entries but before its final bank-commit marker.
     */
    s_programCalls = 0;
    s_failProgramCall = 10;
    assert(!hal_tracestore_write(700u,
                                 &failedValue,
                                 sizeof(failedValue)));
    s_failProgramCall = -1;

    assert(hal_tracestore_init());
    assert(hal_tracestore_read(0u, actual, sizeof(actual)));
    assert(memcmp(expected, actual, sizeof(expected)) == 0);
}

int main(void)
{
    TestBlankWriteAndRestart();
    TestInterruptedCommitIsRejected();
    TestCheckpointPreservesCompleteLogicalImage();
    TestInterruptedCheckpointKeepsPreviousImage();
    puts("TraceStore tests passed");
    return 0;
}
