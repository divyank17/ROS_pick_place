#!/usr/bin/env python3
"""Decode PMIO TraceLog binary records into readable CSV.

Input may be:
  * raw binary bytes, or
  * text containing hexadecimal bytes copied from an IO-Link tool.

Each legacy record is 10 bytes:
    UINT16 code, UINT32 data, UINT32 time

IO-Link parameter data is normally big-endian. A raw debugger/BBSRAM memory
capture is normally little-endian on the RT1024.
"""

from __future__ import annotations

import argparse
import csv
import re
import struct
import sys
from pathlib import Path

RECORD_SIZE = 10

CODE_NAMES = {
    0x0001: "bcAppStart",
    0x0007: "bcIomDbDone",
    0x0008: "bcAppInitComplete",
    0x000A: "bcIOLEnable",
    0x0015: "bcAliveToIdle",
    0x001D: "bcDMCFail",
    0x001E: "bcHardFail1",
    0x0020: "bcFrozen",
    0x002A: "bcHardFail2",
    0x002B: "bcHardFail3",
    0x0100: "bcAihIom",
    0x0107: "bcHModemDiagCount",
    0x0108: "bcHModemDiagFailed",
    0x010E: "bcHModemDiagAbort",
    0x010F: "bcHModemDiagRetry",
    0x0110: "bcHModemDiagReset",
    0x0199: "bcAiIom",
    0x0FFF: "bcDebug",
}


def data_name(code: int, data: int) -> str:
    if code == 0x0FFF:
        prefix = data & 0xFFFF0000
        if prefix == 0x48530000:
            return "HART_SCAN"
        if prefix == 0x48430000:
            return "HART_SCAN_COMPLETE"
        if prefix == 0x54520000:
            return "TRACE_TEST_MARKER"
    return CODE_NAMES.get(code, "UNKNOWN")


def load_bytes(path: Path, input_format: str) -> bytes:
    raw = path.read_bytes()
    if input_format == "binary":
        return raw
    if input_format == "hex":
        text = raw.decode("utf-8", errors="strict")
    else:
        # Auto: text-like content is treated as hex; otherwise binary.
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            return raw
        if not re.fullmatch(r"[\s,;:\-xXa-fA-F0-9\[\](){}]+", text):
            return raw

    text = re.sub(r"0[xX]", "", text)
    pairs = re.findall(r"(?i)(?<![0-9a-f])[0-9a-f]{2}(?![0-9a-f])", text)
    if not pairs:
        compact = re.sub(r"[^0-9a-fA-F]", "", text)
        if len(compact) % 2:
            raise ValueError("hex input contains an odd number of digits")
        pairs = [compact[i : i + 2] for i in range(0, len(compact), 2)]
    return bytes(int(pair, 16) for pair in pairs)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="binary file or text file containing hex bytes")
    parser.add_argument("-o", "--output", type=Path, help="CSV output path; defaults to stdout")
    parser.add_argument(
        "--input-format", choices=("auto", "binary", "hex"), default="auto"
    )
    parser.add_argument(
        "--byte-order",
        choices=("big", "little"),
        default="big",
        help="big for IO-Link parameter data; little for raw RT1024 memory",
    )
    parser.add_argument(
        "--include-empty", action="store_true", help="include records whose code/data/time are all zero"
    )
    args = parser.parse_args()

    try:
        blob = load_bytes(args.input, args.input_format)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))

    if len(blob) < RECORD_SIZE:
        parser.error(f"input contains only {len(blob)} bytes; at least {RECORD_SIZE} required")

    trailing = len(blob) % RECORD_SIZE
    if trailing:
        print(
            f"warning: ignoring {trailing} trailing byte(s); record size is {RECORD_SIZE}",
            file=sys.stderr,
        )
        blob = blob[: len(blob) - trailing]

    fmt = ">HII" if args.byte_order == "big" else "<HII"
    rows: list[tuple[int, str, str, str, int]] = []
    for index, offset in enumerate(range(0, len(blob), RECORD_SIZE)):
        code, data, trace_time = struct.unpack_from(fmt, blob, offset)
        if not args.include_empty and code == 0 and data == 0 and trace_time == 0:
            continue
        rows.append((index, f"0x{code:04X}", data_name(code, data), f"0x{data:08X}", trace_time))

    output = args.output.open("w", newline="", encoding="utf-8") if args.output else sys.stdout
    try:
        writer = csv.writer(output)
        writer.writerow(("index", "code", "name", "data", "time"))
        writer.writerows(rows)
    finally:
        if args.output:
            output.close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
