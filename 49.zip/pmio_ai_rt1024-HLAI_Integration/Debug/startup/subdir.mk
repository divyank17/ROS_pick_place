################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../startup/startup_mimxrt1024.cpp 

CPP_DEPS += \
./startup/startup_mimxrt1024.d 

OBJS += \
./startup/startup_mimxrt1024.o 


# Each subdirectory must supply rules for building sources it contributes
startup/%.o: ../startup/%.cpp startup/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -D__NEWLIB__ -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\board" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\source\hal" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\source" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\drivers" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\utilities\debug_console_lite" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\utilities\str" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\device" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\component\uart" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\component\gpio" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\utilities" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\CMSIS" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\CMSIS\m-profile" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\xip" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\E2\47\pmio_ai_rt1024-HLAI_Integration\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fno-rtti -fno-exceptions -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-startup

clean-startup:
	-$(RM) ./startup/startup_mimxrt1024.d ./startup/startup_mimxrt1024.o

.PHONY: clean-startup

