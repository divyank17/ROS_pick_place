# HART PV / Route Scan Fix Notes

## Problem seen on board

The previous build printed:

```text
HART_RESPONSE PV=lu.lu CHANNEL=0 MODEM=0
```

That pointed to two separate issues:

1. `PV=lu.lu` came from using `%lu` / `%03lu` in `PRINTF()`. The NXP debug console used in this project does not reliably support those length / width modifiers.
2. `CHANNEL=0 MODEM=0` came from reporting an untrusted route after scan. The scan could accept a route after CMD0/partial discovery, even if CMD3 PV decode did not pass.

## What changed

### `hart.cpp`

- Discovery now follows the proven working-project route test:

```text
select channel/modem -> CMD0 -> extract long address -> CMD48 status check -> CMD3 -> decode PV
```

- A route is now accepted only after `HartReadDynamicValues()` succeeds.
- The old init command table is kept available, but it is not run during route discovery by default:

```cpp
#define HART_RUN_INIT_COMMAND_TABLE_AFTER_PV     (0u)
```

This prevents write/config commands such as CMD6/CMD38/CMD59/CMD109 from disturbing channel scanning before PV is proven.

- Write/config commands are disabled by default during scan:

```cpp
#define HART_ENABLE_WRITE_COMMAND_CHECKS         (0u)
```

- The last good route is stored separately:

```cpp
static UINT8 g_lastGoodChannel;
static UINT8 g_lastGoodModem;
static BOOL  g_haveLastGoodRoute;
```

- `HartReportFinalResponse()` now prints the PV using only simple `%d` / `%u` formatting and manual decimal digits:

```text
HART_RESPONSE PV=<value> CHANNEL=<actual-good-channel> MODEM=<actual-good-modem>
```

If CMD3/PV is not valid:

```text
HART_RESPONSE PV=NA CHANNEL=<last-tested-channel> MODEM=<last-tested-modem>
```

## Important behavior

The scan no longer reports success just because CMD0 responded. CMD3 PV decode must pass before the scan returns `HART_DISCOVERY_COMPLETE`.

## Channel/modem mapping retained

```text
CH1..CH4   -> modem0
CH5..CH8   -> modem1
CH9..CH12  -> modem2
CH13..CH16 -> modem3
```

