# AIH HART close-to-source update

This package keeps the HART source-facing files as close as practical to the existing maintenance style while using the RT1024/FPGA register access from `hal_fpga.h`.

## Files updated

- `source/hart.h`
- `source/hart.cpp`
- `source/hartstack.cpp`
- `source/pmio_kernel.cpp`

## Preserved maintenance-facing API

The existing HART entry points are retained:

- `isHartCapable()`
- `CheckAndInitHart()`
- `ResetHart()`
- `InitHartConnection()`
- `AbortHartConnection()`
- `ProcessHartInterrupt()`

The source-style queue/modem/database names are retained:

- `HartQueue`
- `pHartModem[]`
- `clsHartQueue`
- `clsHartModem`
- `clsHartDevDb`
- `Cmd0GoodHandler()` through `Cmd109GoodHandler()`

The PV is still stored through the source-style database path:

- `clsHartDevDb::HDynVal[0]`
- `clsHartDevDb::HDynEu[0]`

## Route configuration

Default route remains the known working route:

```c
#define HART_TEST_CHANNEL 16u
#define HART_TEST_MODEM   3u
```

To test another channel or modem, override these in `hart.h`, `pmio_kernel.cpp`, or MCUXpresso project preprocessor symbols.

Examples:

```c
#define HART_TEST_CHANNEL 12u
#define HART_TEST_MODEM   2u
```

```c
#define HART_TEST_CHANNEL 8u
#define HART_TEST_MODEM   1u
```

## Final PV print

The only normal terminal output remains:

```text
HART_RESPONSE PV=<value> CHANNEL=<channel> MODEM=<modem>
```

If no valid PV is available:

```text
HART_RESPONSE PV=NA CHANNEL=<channel> MODEM=<modem>
```

The print can be disabled for integration by setting:

```c
#define HART_ENABLE_FINAL_RESPONSE_PRINT 0u
```

## What is intentionally different from source

The original hardware register access, H8S interrupt plumbing, and TPU timer setup are not copied directly because AIH now uses RT1024 and FPGA SPI register access. Those differences are isolated behind the RT1024/FPGA HART backend and `hal_fpga.h`.
