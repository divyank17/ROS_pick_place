# HART Maintenance Alignment Notes

This package keeps the RT1024/FPGA working transport path and reshapes the HART module around the older maintenance-facing structure.

## Updated HART files
- `source/hart.h`
- `source/hart.cpp`
- `source/hartdb.hpp`
- `source/hartdb.cpp`
- `source/hartstack.cpp`

## Main alignment changes
- Kept public functions: `isHartCapable`, `CheckAndInitHart`, `ResetHart`, `InitHartConnection`, `AbortHartConnection`, `ProcessHartInterrupt`.
- Kept old command enum names and command numbers.
- Added old database-facing classes: `clsHartCfgDb`, `clsHartCfgDb7`, `clsHartDevDb`, `clsHartPst`.
- Added old command handler names: `Cmd0GoodHandler`, `Cmd0BadHandler`, `Cmd3GoodHandler`, `Cmd3BadHandler`, through CMD109 handlers.
- Added old handler dispatch table: `clsHartDevDb::HartCmdHandler`.
- Changed discovery/init flow to use the old initialization command table order after CMD0:
  `CMD48 -> CMD59 -> CMD6 -> CMD38 -> CMD12 -> CMD13 -> CMD14 -> CMD15 -> CMD16 -> CMD20 -> CMD50`.
- CMD3 updates `clsHartDevDb::HDynVal[0]` and `clsHartDevDb::HDynEu[0]`; the final PV print reads from this old-style database path.
- `InitHartConnection()` is queue-oriented again. Queue processing routes through `clsHartQueue::ProcessQueue()`.
- Removed normal HART debug prints. Only `HartReportFinalResponse()` prints the final PV/channel/modem line.

## Final output
Expected success line:

```text
HART_RESPONSE PV=<value> CHANNEL=16 MODEM=3
```

Failure/no PV line:

```text
HART_RESPONSE PV=NA CHANNEL=16 MODEM=3
```

## Hardware path kept
Low-level HART UART/FPGA access still uses `hal_fpga.h` and the working RT1024 transaction path.
