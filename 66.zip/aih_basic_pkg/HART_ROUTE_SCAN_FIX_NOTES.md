# HART route scan fix notes

## Reason for this update

The previous close-to-legacy package built successfully, but `pmio_kernel.cpp` still executed only the fixed route:

```cpp
HartSetRoute(HART_TEST_CHANNEL, HART_TEST_MODEM);
result = HartDiscoverOnRoute(HART_TEST_CHANNEL, HART_TEST_MODEM);
```

That made the run look hard-coded to channel 16 / modem 3, even though the lower HART module already had `HartScanChannels()` and `HartGetModemForChannel()` support.

The original working `55.zip` project identified the route by scanning logical channels and deriving the modem from the channel group:

```text
CH1..CH4   -> modem0
CH5..CH8   -> modem1
CH9..CH12  -> modem2
CH13..CH16 -> modem3
```

This package restores that behavior in the latest maintenance-friendly code.

## Main changes

### `pmio_kernel.cpp`

Changed the board entry path from a fixed route to a scan route:

```cpp
result = HartScanChannels((UINT8)HART_SCAN_CHANNEL_START,
                          (UINT8)HART_SCAN_CHANNEL_END);

HartReportFinalResponse(HartGetActiveChannel(),
                        HartGetActiveModem(),
                        result);
```

Default scan range:

```cpp
#define HART_SCAN_CHANNEL_START          (1u)
#define HART_SCAN_CHANNEL_END            (16u)
```

To test one channel only:

```cpp
#define HART_SCAN_CHANNEL_START          (16u)
#define HART_SCAN_CHANNEL_END            (16u)
```

The modem is still derived automatically using `HartGetModemForChannel()`.

### `hart.cpp`

Changed default route comments/macros so channel/modem are treated as scan defaults, not the fixed runtime route.

Changed `HartDiscoveryTask()` to call:

```cpp
HartScanChannels(HART_SCAN_CHANNEL_START, HART_SCAN_CHANNEL_END);
```

instead of a fixed `HartDiscoverOnRoute(HART_TEST_CHANNEL, HART_TEST_MODEM)` call.

### `hart.h`

Added scan-range macros so the channel scan can be configured from one place or overridden in MCUXpresso project preprocessor settings.

## Final terminal output

Normal HART terminal output remains one line:

```text
HART_RESPONSE PV=<value> CHANNEL=<actual-channel> MODEM=<actual-modem>
```

If no valid HART device/PV is found:

```text
HART_RESPONSE PV=NA CHANNEL=<last-tried-channel> MODEM=<last-tried-modem>
```

## What did not change

- HART command flow was not changed.
- `hal_fpga.h` register map was not changed.
- HART database path was not changed.
- PV is still read through the old-style path:

```cpp
clsHartDevDb::HDynVal[0]
clsHartDevDb::HDynEu[0]
```

- Public function names remain unchanged:

```text
isHartCapable
CheckAndInitHart
ResetHart
InitHartConnection
AbortHartConnection
ProcessHartInterrupt
HartScanChannels
HartGetModemForChannel
HartReportFinalResponse
```
