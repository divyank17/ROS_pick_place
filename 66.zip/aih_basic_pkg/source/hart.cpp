/*******************************************************************************
*    File Name   : hart.cpp                                                    *
*    Description : HART global data and functions.                             *
*******************************************************************************/

#include <stddef.h>
#include <string.h>

#include "hart.h"
#include "hartdb.hpp"
#include "hartstack.hpp"
#include "fsl_debug_console.h"

/*
 * HART discovery range.
 *
 * The working AIH bring-up code identifies the connected HART device by
 * scanning logical channels and deriving the modem from the channel group.
 * These values are only scan defaults; the active channel/modem are updated
 * from the route that actually returns a valid HART response.
 */
#ifndef HART_SCAN_CHANNEL_START
#define HART_SCAN_CHANNEL_START                 (1u)
#endif

#ifndef HART_SCAN_CHANNEL_END
#define HART_SCAN_CHANNEL_END                   (16u)
#endif

#ifndef HART_TEST_CHANNEL
#define HART_TEST_CHANNEL                       HART_SCAN_CHANNEL_START
#endif

#ifndef HART_TEST_MODEM
#define HART_TEST_MODEM                         ((UINT8)((HART_TEST_CHANNEL - 1u) / 4u))
#endif

#ifndef HART_POLL_ADDR_START
#define HART_POLL_ADDR_START                    (0u)
#endif

#ifndef HART_POLL_ADDR_END
#define HART_POLL_ADDR_END                      (0u)
#endif

/* Keep this enabled to run the same initialization command table as the old
 * module. Set to 0 only when the hardware team explicitly wants read-only tests.
 */
#ifndef HART_ENABLE_WRITE_COMMAND_CHECKS
#define HART_ENABLE_WRITE_COMMAND_CHECKS         (0u)
#endif

/*
 * During route discovery the working AIH project first proves the route with
 * CMD0 + CMD3 PV read. The old initialization command table can be enabled for
 * maintenance testing, but it is kept out of the discovery pass by default so
 * write/config commands cannot disturb channel scanning.
 */
#ifndef HART_RUN_INIT_COMMAND_TABLE_AFTER_PV
#define HART_RUN_INIT_COMMAND_TABLE_AFTER_PV     (0u)
#endif

/*
 * Keep this enabled for board validation.  Set to 0 for integration/production
 * when IO-Link traffic must not share the debug UART.
 */
#ifndef HART_ENABLE_FINAL_RESPONSE_PRINT
#define HART_ENABLE_FINAL_RESPONSE_PRINT         (1u)
#endif

static UINT8 g_runtimeLongAddr[HART_LONGADDR_LENGTH] = {0u, 0u, 0u, 0u, 0u};
static UINT8 g_runtimePollAddr = 0u;
static bool  g_haveLongAddr = false;

static UINT8 g_activeChannel = (UINT8)HART_TEST_CHANNEL;
static UINT8 g_activeModem = (UINT8)HART_TEST_MODEM;
static UINT8 g_lastGoodChannel = 0u;
static UINT8 g_lastGoodModem = 0u;
static BOOL  g_haveLastGoodRoute = FALSE;

static VOID HartClearRuntimeState(VOID)
{
    HartDb_Clear();
    g_haveLongAddr = false;
    g_runtimePollAddr = (UINT8)HART_POLL_ADDR_START;
    memset(g_runtimeLongAddr, 0, sizeof(g_runtimeLongAddr));
}

static VOID HartSetActiveRoute(UINT8 channel, UINT8 modem)
{
    if (channel < 1u)
    {
        channel = 1u;
    }

    if (channel > 16u)
    {
        channel = 16u;
    }

    if (modem > 3u)
    {
        modem = HartGetModemForChannel(channel);
    }

    g_activeChannel = channel;
    g_activeModem = modem;
    HartClearRuntimeState();
}

/*******************************************************************************
*                                HartSetRoute                                  *
*                                ============                                  *
* PURPOSE:      Select the HART channel and modem used by the RT1024/FPGA      *
*               hardware access path.                                         *
* ARGUMENTS:    1. channel - HART channel number.                              *
*               2. modem   - HART modem number.                                *
* RETURN:       None                                                           *
* NOTES:        This is an AIH board validation helper.  The original channel   *
*               connection API is unchanged.                                   *
*******************************************************************************/
VOID HartSetRoute(UINT8 channel, UINT8 modem)
{
    HartSetActiveRoute(channel, modem);
}

UINT8 HartGetActiveChannel(VOID)
{
    return g_activeChannel;
}

UINT8 HartGetActiveModem(VOID)
{
    return g_activeModem;
}

static BOOL HartIsWriteCommand(UINT8 command)
{
    return ((command == HARTCOMMAND_SIX) ||
            (command == HARTCOMMAND_THIRTYEIGHT) ||
            (command == HARTCOMMAND_FIFTYNINE) ||
            (command == HARTCOMMAND_HUNDREDNINE)) ? TRUE : FALSE;
}

static BOOL HartRunCommand(UINT8 command,
                           const UINT8 *data,
                           UINT8 dataLen,
                           const char *label,
                           HartParsedResponse_t *responseOut)
{
    HartParsedResponse_t localResponse;
    HartParsedResponse_t *rsp = (responseOut != NULL) ? responseOut : &localResponse;

    if (!g_haveLongAddr)
    {
        return FALSE;
    }

#if !HART_ENABLE_WRITE_COMMAND_CHECKS
    if (HartIsWriteCommand(command))
    {
        (void)data;
        (void)dataLen;
        (void)label;
        memset(rsp, 0, sizeof(*rsp));
        rsp->valid = TRUE;
        rsp->checksumOk = TRUE;
        rsp->command = command;
        rsp->status0 = HART_RESPCODE_SUCCESS;
        rsp->status1 = 0u;
        (void)HartDb_HandleResponse(rsp);
        return TRUE;
    }
#endif

    if (!HartStack_RunLongCommand(g_activeChannel,
                                  g_activeModem,
                                  g_runtimePollAddr,
                                  g_runtimeLongAddr,
                                  command,
                                  data,
                                  dataLen,
                                  label,
                                  rsp))
    {
        return FALSE;
    }

    (void)HartDb_HandleResponse(rsp);

    if (command == HARTCOMMAND_FOURTYEIGHT)
    {
        HartDb_UpdateCmd48Status(rsp->status0, rsp->status1);
    }
    else if (command == HARTCOMMAND_FIFTYNINE)
    {
        HartDb_UpdateCmd59Status(rsp->status0, rsp->status1);
    }

    return TRUE;
}

static const UINT8 *HartGetInitCommand(UINT8 hartRevision, UINT8 index, UINT8 *rowSize)
{
    if (index >= HART_INITCOMMAND_COUNT)
    {
        if (rowSize != NULL)
        {
            *rowSize = 0u;
        }
        return NULL;
    }

    if (hartRevision >= HARTVERSION_7X)
    {
        if (rowSize != NULL)
        {
            *rowSize = sizeof(HART7_INIT_COMMANDS[0]);
        }
        return HART7_INIT_COMMANDS[index];
    }

    if (hartRevision >= HARTVERSION_6X)
    {
        if (rowSize != NULL)
        {
            *rowSize = sizeof(HART6_INIT_COMMANDS[0]);
        }
        return HART6_INIT_COMMANDS[index];
    }

    if (rowSize != NULL)
    {
        *rowSize = sizeof(HART5_INIT_COMMANDS[0]);
    }
    return HART5_INIT_COMMANDS[index];
}

static VOID HartBuildInitCommandData(UINT8 command,
                                     UINT8 hartRevision,
                                     UINT8 responsePreambles,
                                     UINT8 *data,
                                     UINT8 *dataLen)
{
    clsHartDevDb *db = HartDb_GetHartDevDb();

    if ((data == NULL) || (dataLen == NULL))
    {
        return;
    }

    *dataLen = 0u;
    data[0] = 0u;
    data[1] = 0u;

    switch (command)
    {
        case HARTCOMMAND_FIFTYNINE:
            data[0] = responsePreambles;
            if (data[0] < HART_MIN_PREAMBLES)
            {
                data[0] = HART_MIN_PREAMBLES;
            }
            *dataLen = 1u;
            break;

        case HARTCOMMAND_SIX:
            data[0] = g_runtimePollAddr;
            if (hartRevision <= HARTVERSION_5X)
            {
                *dataLen = 1u;
            }
            else
            {
                data[1] = HART_LOOP_CURRENT_ENABLED;
                *dataLen = 2u;
            }
            break;

        case HARTCOMMAND_THIRTYEIGHT:
            if ((hartRevision >= HARTVERSION_7X) && (db != NULL))
            {
                data[0] = db->HCmd0.str.ucusConfigChgCnt[0];
                data[1] = db->HCmd0.str.ucusConfigChgCnt[1];
                *dataLen = 2u;
            }
            break;

        case HARTCOMMAND_HUNDREDNINE:
            data[0] = HART_BURSTMODE_OFF;
            *dataLen = 1u;
            break;

        default:
            break;
    }
}

static BOOL HartRunInitCommandTable(UINT8 responsePreambles, UINT8 hartRevision)
{
    BOOL anyFailure = FALSE;
    clsHartDevDb *db = HartDb_GetHartDevDb();

    if (db != NULL)
    {
        db->m_HChanMode = HCHANMODE_INIT;
        db->m_ucInitCmdIndex = 0u;
    }

    for (UINT8 index = 0u; index < HART_INITCOMMAND_COUNT; index++)
    {
        UINT8 rowSize = 0u;
        const UINT8 *row = HartGetInitCommand(hartRevision, index, &rowSize);
        UINT8 command;
        UINT8 data[2] = {0u, 0u};
        UINT8 dataLen = 0u;
        HartParsedResponse_t rsp;

        if ((row == NULL) || (rowSize < 2u))
        {
            continue;
        }

        command = row[0];
        HartBuildInitCommandData(command, hartRevision, responsePreambles, data, &dataLen);

        if (!HartRunCommand(command,
                            (dataLen > 0u) ? data : NULL,
                            dataLen,
                            "HART_INIT_COMMAND",
                            &rsp))
        {
            anyFailure = TRUE;
        }

        if (db != NULL)
        {
            db->m_ucInitCmdIndex = (UINT8)(index + 1u);
            (void)db->ScheduleFromInitTable();
        }
    }

    if (db != NULL)
    {
        db->m_HChanMode = HCHANMODE_SCAN;
        db->m_sScanCounter = TICKS_IN_1_SEC;
        db->BuildScanTable();
    }

    return (anyFailure == FALSE) ? TRUE : FALSE;
}

BOOL HartReadDynamicValues(VOID)
{
    HartParsedResponse_t cmd3;

    if (!HartRunCommand(HARTCOMMAND_THREE, NULL, 0u, "CMD3_READ_DYNAMIC_VARS", &cmd3))
    {
        return FALSE;
    }

    if ((cmd3.status0 != HART_RESPCODE_SUCCESS) || (cmd3.status1 != 0u))
    {
        return FALSE;
    }

    if (!HartDb_UpdateDynamicFromCmd3(&cmd3))
    {
        return FALSE;
    }

    return TRUE;
}

VOID HartInit(VOID)
{
    g_activeChannel = (UINT8)HART_TEST_CHANNEL;
    g_activeModem = (UINT8)HART_TEST_MODEM;
    g_lastGoodChannel = 0u;
    g_lastGoodModem = 0u;
    g_haveLastGoodRoute = FALSE;
    HartClearRuntimeState();
}

HARTDISCOVERYRESULT HartDiscover(VOID)
{
    HartParsedResponse_t cmd0;
    HartParsedResponse_t cmd48;
    UINT8 respPreambles = HART_DEFAULT_PREAMBLECOUNT;

    if (!HartStack_SelfCheck())
    {
        return HART_DISCOVERY_FAILED;
    }

    for (UINT8 pa = HART_POLL_ADDR_START; pa <= HART_POLL_ADDR_END; pa++)
    {
        if (!HartStack_GetCleanCmd0(g_activeChannel,
                                    g_activeModem,
                                    pa,
                                    &cmd0))
        {
            continue;
        }

        if (!HartStack_ExtractLongAddressFromCmd0(&cmd0, g_runtimeLongAddr, &respPreambles))
        {
            return HART_DISCOVERY_CMD0_OK;
        }

        g_runtimePollAddr = pa;
        g_haveLongAddr = true;

        if (!HartDb_UpdateFromCmd0(g_activeChannel,
                                   g_activeModem,
                                   pa,
                                   &cmd0,
                                   g_runtimeLongAddr,
                                   respPreambles))
        {
            return HART_DISCOVERY_CMD0_OK;
        }

        /* Match the proven AIH bring-up path: after CMD0, optionally read CMD48
         * as a link/status check, then immediately read CMD3.  A route is not
         * accepted as discovered until the PV is decoded successfully. */
        if (HartRunCommand(HARTCOMMAND_FOURTYEIGHT,
                           NULL,
                           0u,
                           "CMD48_READ_ADDITIONAL_STATUS",
                           &cmd48))
        {
            HartDb_UpdateCmd48Status(cmd48.status0, cmd48.status1);
        }

        if (!HartReadDynamicValues())
        {
            HartClearRuntimeState();
            continue;
        }

        g_lastGoodChannel = g_activeChannel;
        g_lastGoodModem = g_activeModem;
        g_haveLastGoodRoute = TRUE;

#if HART_RUN_INIT_COMMAND_TABLE_AFTER_PV
        (void)HartRunInitCommandTable(respPreambles, cmd0.hartRevision);
#endif

        return HART_DISCOVERY_COMPLETE;
    }

    return HART_DISCOVERY_FAILED;
}

HARTDISCOVERYRESULT HartDiscoverOnRoute(UINT8 channel, UINT8 modem)
{
    HartSetActiveRoute(channel, modem);
    return HartDiscover();
}

UINT8 HartGetModemForChannel(UINT8 logicalChannel)
{
    if (logicalChannel < 1u)
    {
        logicalChannel = 1u;
    }

    if (logicalChannel > 16u)
    {
        logicalChannel = 16u;
    }

    /* Channel groups are retained from the HART mux organization:             *
     *   channels  1-4  -> modem 0                                             *
     *   channels  5-8  -> modem 1                                             *
     *   channels  9-12 -> modem 2                                             *
     *   channels 13-16 -> modem 3                                             */
    return (UINT8)((logicalChannel - 1u) / 4u);
}

HARTDISCOVERYRESULT HartScanChannels(UINT8 logicalChannelStart, UINT8 logicalChannelEnd)
{
    UINT8 start = logicalChannelStart;
    UINT8 end = logicalChannelEnd;
    UINT8 tmp;

    if (start < 1u)
    {
        start = 1u;
    }

    if (end > 16u)
    {
        end = 16u;
    }

    if (start > end)
    {
        tmp = start;
        start = end;
        end = tmp;
    }

    for (UINT8 ch = start; ch <= end; ch++)
    {
        UINT8 modem = HartGetModemForChannel(ch);
        HARTDISCOVERYRESULT result = HartDiscoverOnRoute(ch, modem);

        if (result == HART_DISCOVERY_COMPLETE)
        {
            return result;
        }
    }

    return HART_DISCOVERY_FAILED;
}

/*******************************************************************************
*                             HartReportFinalResponse                          *
*                             ======================                           *
* PURPOSE:                                                                     *
*    Report one terminal line with the HART PV value and active route.          *
* ARGUMENTS:                                                                   *
*    1. channel - channel number used for the request.                         *
*    2. modem   - modem number used for the request.                           *
*    3. result  - discovery result returned by the HART scan.                  *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    This is the only normal terminal output in the HART path. The PV comes    *
*    from the source device database member HDynVal[0].                     *
*******************************************************************************/
VOID HartReportFinalResponse(UINT8 channel, UINT8 modem, HARTDISCOVERYRESULT result)
{
#if HART_ENABLE_FINAL_RESPONSE_PRINT
    const HartDeviceInfo_t *device = HartDb_GetDevice();
    UINT8 outChannel = channel;
    UINT8 outModem = modem;
    FLOAT32 pv = 0.0f;
    UINT8 unit = 0u;

    if (g_haveLastGoodRoute != FALSE)
    {
        outChannel = g_lastGoodChannel;
        outModem = g_lastGoodModem;
    }
    else if ((device != NULL) && (device->valid != FALSE) &&
             (device->channel >= 1u) && (device->channel <= 16u) &&
             (device->modem <= 3u))
    {
        outChannel = device->channel;
        outModem = device->modem;
    }

    if ((outChannel < 1u) || (outChannel > 16u))
    {
        outChannel = g_activeChannel;
    }
    if (outModem > 3u)
    {
        outModem = HartGetModemForChannel(outChannel);
    }

    /* PV is read from the same database path used by the source handler:
     *     clsHartDevDb::HDynVal[0]
     *     clsHartDevDb::HDynEu[0]
     */
    if ((result == HART_DISCOVERY_COMPLETE) && HartDb_GetPrimaryVariable(&pv, &unit) &&
        (pv == pv) && (pv > -1000000000.0f) && (pv < 1000000000.0f))
    {
        const char *sign = "";
        INT32 scaled;
        INT32 whole;
        INT32 frac;
        INT32 h;
        INT32 t;
        INT32 o;

        (void)unit;

        if (pv >= 0.0f)
        {
            scaled = (INT32)((pv * 1000.0f) + 0.5f);
        }
        else
        {
            scaled = (INT32)((pv * 1000.0f) - 0.5f);
        }

        if (scaled < 0)
        {
            sign = "-";
            scaled = -scaled;
        }

        whole = scaled / 1000;
        frac = scaled % 1000;
        h = frac / 100;
        t = (frac / 10) % 10;
        o = frac % 10;

        /* fsl_debug_console in this project is not reliable with %lu or %03lu.
         * Use only simple %d conversions and print decimal digits manually. */
        PRINTF("HART_RESPONSE PV=%s%d.%d%d%d CHANNEL=%u MODEM=%u\r\n",
               sign,
               (int)whole,
               (int)h,
               (int)t,
               (int)o,
               (unsigned int)outChannel,
               (unsigned int)outModem);
    }
    else
    {
        PRINTF("HART_RESPONSE PV=NA CHANNEL=%u MODEM=%u\r\n",
               (unsigned int)outChannel,
               (unsigned int)outModem);
    }
#else
    (void)channel;
    (void)modem;
    (void)result;
#endif
}

VOID HartDiscoveryTask(VOID)
{
    (void)HartScanChannels((UINT8)HART_SCAN_CHANNEL_START,
                           (UINT8)HART_SCAN_CHANNEL_END);
}

/*******************************************************************************
*                               isHartCapable                                  *
*                               =============                                  *
* PURPOSE: Determine if the HW is HART capable                                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Called by aihmain and aohmain. Meaningless if it is called by di/do   *
*        If MUXADDR (0x80010) is Read Only, the module is Hartless             *
*******************************************************************************/
BOOL isHartCapable(VOID)
{
    return TRUE;
}

/*******************************************************************************
*                               CheckAndInitHart                               *
*                               ================                               *
* PURPOSE:      Initialize HART registers for HART modules                     *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is HART            *
*******************************************************************************/
VOID CheckAndInitHart(VOID)
{
    HartInit();
}

/*******************************************************************************
*                               ResetHart                                      *
*                               =========                                      *
* PURPOSE:      Reset Hart UARTS                                               *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is Hartless        *
*******************************************************************************/
VOID ResetHart(VOID)
{
    HartStack_Reset();
}

/*******************************************************************************
*                              InitHartConnection                              *
*                              ==================                              *
* PURPOSE:                                                                     *
*    Initiate a HART transaction.                                              *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel object number which requests connection.            *
* RETURN:                                                                      *
*    Boolean. TRUE if request is accepted; FALSE if rejected.                  *
* PROCESS:                                                                     *
*    1. Add a_pClient to the stack queue.                                      *
* NOTES:                                                                       *
*    1. This function is used by channel object to initiate HART transaction.  *
*    2. Modem objects periodically checks the stack queue and uses the client  *
*       reference and callback interface to carry out the HART transaction.    *
*******************************************************************************/
BOOL InitHartConnection(UINT8 a_ucChan)
{
    return HartQueue.AddToQueue(a_ucChan);
}

/*******************************************************************************
*                             ProcessHartInterrupt                             *
*                             ====================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID ProcessHartInterrupt(VOID)
{
    for (UINT8 modem = 0u; modem < 4u; modem++)
    {
        HartQueue.ProcessQueue(modem);
    }
}

/*******************************************************************************
*                             AbortHartConnection                              *
*                             ===================                              *
* PURPOSE:                                                                     *
*    Abort a previously initiated HART transaction.                            *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if transaction is aborted; FALSE if any transaction with    *
*    the specified client is not found.                                        *
* PROCESS:                                                                     *
*    1. Check the stack queue for the passed reference and remove from queue   *
*       if it is found.                                                        *
*    2. Otherwise check each modem object for their client references and      *
*       disconnect the modem if a match with the passed reference is found.    *
* NOTES:                                                                       *
*    1. Note that Disconnect method a private method in clsModem and cannot be *
*       called from here. Instead a request is made is to the modem object     *
*       which will be processed subsequently by the modem interrupt routines.  *
*       Disconnect need to be protected as private method to streamline the    *
*       modem state change.                                                    *
*******************************************************************************/
BOOL AbortHartConnection(UINT8 a_ucChan)
{
    BOOL removed = HartQueue.RemoveFromQueue(a_ucChan);

    for (UINT8 modem = 0u; modem < 4u; modem++)
    {
        if ((pHartModem[modem] != NULL) &&
            (pHartModem[modem]->GetConnectedChannel() == a_ucChan))
        {
            pHartModem[modem]->RequestDisconnect();
            removed = TRUE;
        }
    }

    return removed;
}
