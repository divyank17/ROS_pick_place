/*******************************************************************************
*    File Name   : hartstack.hpp                                               *
*    Description : HART protocol stack classes declaration.                    *
*******************************************************************************/
#ifndef __HARTSTACK_HPP__
#define __HARTSTACK_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifndef HARTSTACK_SIZE_T_DEFINED
typedef __SIZE_TYPE__ size_t;
#define HARTSTACK_SIZE_T_DEFINED
#endif

#include "datatype.h"
#include "hart.h"
#include "hal_fpga.h"

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagHModemState {
    HMODEMSTATE_BAD,
    HMODEMSTATE_IDLE,
    HMODEMSTATE_SYNCWAIT,
    HMODEMSTATE_XMTING,
    HMODEMSTATE_RCVWAIT,
    HMODEMSTATE_RCVING,
    HMODEMSTATE_SUSPECT,
    HMODEMSTATE_DIAG
} HMODEMSTATE;

typedef enum tagHSyncStatus {
    HSYNCSTATUS_UNKNOWN,
    HSYNCSTATUS_KEEP_SYNC,
    HSYNCSTATUS_DROP_SYNC
} HSYNCSTATUS;

typedef enum tagHIntrType {
    HINTRTYPE_UNKNOWN,
    HINTRTYPE_RCVFIFOFULL,
    HINTRTYPE_RCVFIFOTOUT,
    HINTRTYPE_XMTFIFOEMPTY,
    HINTRTYPE_CARRIERDETECT,
    HINTRTYPE_CARRIERDROP
} HINTRTYPE;

typedef enum tagHMsgType {
    HMSGTYPE_UNKNOWN,
    HMSGTYPE_STX,
    HMSGTYPE_ACKTOME,
    HMSGTYPE_ACKTOHIM,
    HMSGTYPE_BACKTOME,
    HMSGTYPE_BACKTOHIM,
    HMSGTYPE_STXFROMME
} HMSGTYPE;

typedef enum tagHMsgStatus {
    HMSGSTATUS_GOOD,
    HMSGSTATUS_BAD,
    HMSGSTATUS_DEVICEERROR
} HMSGSTATUS;

typedef enum tagHEventType {
    HEVENTTYPE_UNKNOWN,
    HEVENTTYPE_COMMERROR,
    HEVENTTYPE_NORESPONSE,
    HEVENTTYPE_DEVICEERROR,
    HEVENTTYPE_RCVRERROR,
    HEVENTTYPE_RETRY,
    HEVENTTYPE_TOTALTIMEOUT,
    HEVENTTYPE_SECMASTER,
    HEVENTTYPE_BURSTMODE,
    HEVENTTYPE_PRIMASTER
} HEVENTTYPE;

typedef enum tagXmtRcvContext {
    XMTRCVCONTEXT_UNKNOWN,
    XMTRCVCONTEXT_PREAMBLE,
    XMTRCVCONTEXT_DELIMITER,
    XMTRCVCONTEXT_ADDRESS,
    XMTRCVCONTEXT_COMMAND,
    XMTRCVCONTEXT_BYTECOUNT,
    XMTRCVCONTEXT_STATUS,
    XMTRCVCONTEXT_DATA
} XMTRCVCONTEXT;

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
const UINT8 HARTMODEM_COUNT        = 4;
const UINT8 HARTQUEUE_BUFFER_SIZE  = 16;
const UINT8 HARTMODEM_BUFFER_SIZE  = 32;
const UINT8 HSYNC_MINIMUM_TIME     = 1;
const UINT8 CHECKPAD_BYTECOUNT     = 2;
const UINT8 XMTINT_ALLOWANCE       = 1;
const UINT8 RCVINT_ALLOWANCE       = 2;
const UINT8 MAX_DRIBBLE_BYTES      = 2;
const UINT8 UART_XMT_FIFO_SIZE     = 16;
const UINT8 UART_RCV_FIFO_SIZE     = 16;
const UINT8 HMODEMDIAG_MAXCOUNT    = 3;
const UINT8 HMODEMDIAG_UNDERRUN_MAXCOUNT = 10;
const UINT8 HART_LOOPBACK_SIZE     = 12;
const UINT8 HART_ENABLE_ALL_MUXES  = 0x0F;
const UINT8 HART_UART_8BITS_PER_CHAR = 0x03;
const UINT8 HART_UART_LINE_STS_ERROR_BITS = 0x1E;
const UINT8 HART_LOOPBACK_PATTERN[HART_LOOPBACK_SIZE] = { 0xAA,0x55,0xA5,0x5A,
                                                          0xCC,0x33,0xC3,0x3C,
                                                          0xF0,0x0F,0x00,0xFF };

/* Size definitions are retained in UINT16 units so allocation expressions from
 * the source module continue to read the same way as the HART module they came
 * from.  The RT1024 build uses static objects, but these names are kept for
 * maintenance and integration compatibility. */
#define CLSHARTMODEM_SIZE ((sizeof(clsHartModem)+(sizeof(clsHartModem)%2)) / 2)
#define CLSHARTQUEUE_SIZE ((sizeof(clsHartQueue)+(sizeof(clsHartQueue)%2)) / 2)

/*******************************************************************************
*                               clsClientBuffer                                *
*                               ===============                                *
*  This class automates buffer management activities for clients of HART stack  *
*  like channel objects and for passthrough response.                           *
*******************************************************************************/
class clsClientBuffer {
    const UINT16 m_BUFSIZE;
    UINT8 *m_ucpBuffer;
    UINT16 m_usIndex;

public:
    clsClientBuffer(UINT16 a_usBufSize, UINT8 *a_ucpBuf);
    VOID Flush(VOID);
    UINT8 At(UINT16 a_usIndex);
    UINT8 *AddrAt(UINT16 a_usIndex);
    clsClientBuffer& operator=(const UINT8 a_ucData);
};

/*******************************************************************************
*                                 clsHartQueue                                 *
*                                 ============                                 *
*******************************************************************************/
class clsHartQueue {
    UINT8 m_ucQueue[HARTQUEUE_BUFFER_SIZE];
    UINT8 m_ucHead;
    UINT8 m_ucTail;
    UINT8 m_ucCount;

public:
    clsHartQueue(VOID);
    BOOL AddToQueue(UINT8 a_ucChan);
    BOOL RemoveFromQueue(UINT8 a_ucChan);
    VOID ProcessQueue(UINT8 a_ucModemNumber);
    BOOL IsModemQueueEmpty(VOID);
    VOID *operator new(size_t, UINT8);
    VOID operator delete(VOID *) {}
};

/*******************************************************************************
*                                clsModemBuffer                                *
*                                ==============                                *
*******************************************************************************/
class clsModemBuffer {
    UINT8 m_ucBuffer[HARTMODEM_BUFFER_SIZE];
    UINT8 m_ucAppend;
    UINT8 m_ucRemove;
    UINT8 m_ucCount;

public:
    clsModemBuffer(VOID);
    unsigned short GetLength(void);
    VOID Flush(VOID);
    UINT8 PopChar(VOID);
    VOID ThrowLastRcvd(VOID);
    clsModemBuffer& operator=(const UINT8 a_cucData);
};

/*******************************************************************************
*                                 clsHartModem                                 *
*                                 ============                                 *
*  clsHartModem implements the HART data link layer entry points used by the    *
*  source module. The RT1024 implementation keeps these names while the register   *
*  access is routed through hal_fpga.h.                                         *
*******************************************************************************/
class clsHartModem {
    const UINT8 m_ucModemNumber;
    UINT8 m_ucModemTimer;
    HMODEMSTATE m_ModemState;
    UINT8 m_ucConnectedChannel;
    UINT8 m_ucFailedChannel;
    UINT8 m_ucModemDiagCount;
    BOOL m_bRequestDisconnect;
    BOOL m_bHartStackProc;

    VOID SetState(HMODEMSTATE a_ModemState, UINT8 a_ucTimer);
    VOID ModemTimeout(VOID);
    VOID TransmitRequest(VOID);
    VOID ProcessResponse(VOID);
    VOID DecodeResponse(VOID);
    VOID ActOnResponse(VOID);
    VOID SetupRetry(UINT8 a_ucRetryReason);
    VOID HandleReceiveError(VOID);
    VOID ProcessDiagModem(VOID);

public:
    clsHartModem(UINT8 a_ucModemNumber);
    VOID HartModemInterrupt(HINTRTYPE a_IntrType);
    static VOID HartModemHeartbeat(VOID);
    UINT8 HartMuxLoopbackTest(VOID);
    VOID Connect(UINT8 a_ucChan);
    VOID Disconnect(VOID);
    VOID DiagConnect(UINT8 a_ucChan);
    VOID SwitchMux(UINT8 a_ucChan);

    BOOL IsHartStackProc(VOID) { return m_bHartStackProc; }
    UINT8 GetModemNumber(VOID) { return m_ucModemNumber; }
    UINT8 GetConnectedChannel(VOID) { return m_ucConnectedChannel; }
    UINT8 GetFailedChannel(VOID) { return m_ucFailedChannel; }
    VOID RequestDisconnect(VOID) { m_bRequestDisconnect = TRUE; }
    HMODEMSTATE GetModemState(VOID) { return m_ModemState; }
    UINT8 GetModemTimer(VOID) { return m_ucModemTimer; }
    UINT8 GetModemDiagCount(VOID) { return m_ucModemDiagCount; }
    VOID ReinstateModem(VOID);
    VOID SetModemBad(VOID);
    VOID ClearModemBad(VOID);
    VOID ClearTxRxFIFOs(VOID);
    VOID *operator new(size_t, UINT8);
    VOID operator delete(VOID *) {}
};

/*******************************************************************************
*                              RT1024 response                                 *
*******************************************************************************/
typedef struct tagHartParsedResponse {
    BOOL valid;
    BOOL checksumOk;
    BOOL isLongAddress;
    BOOL hasStatus;

    UINT8 preambleCount;
    UINT8 delimiter;
    UINT8 address[HART_LONGADDR_LENGTH];
    UINT8 addressLen;
    UINT8 command;
    UINT8 byteCount;
    UINT8 status0;
    UINT8 status1;
    UINT8 payloadLen;
    UINT8 payload[64];
    UINT8 checksumRx;
    UINT8 checksumCalc;

    UINT8 longAddr[HART_LONGADDR_LENGTH];
    UINT8 responsePreambles;
    UINT8 hartRevision;
    UINT8 deviceRevision;
} HartParsedResponse_t;

typedef struct tagHartCommandInfo {
    HARTCOMMAND command;
    const char *name;
    BOOL implemented;
    BOOL executedByDefault;
    BOOL changesDeviceConfiguration;
} HartCommandInfo_t;

/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
extern clsHartQueue HartQueue;
extern clsHartModem *pHartModem[4];

/*******************************************************************************
*                               GLOBAL FUNCTIONS                               *
*******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

VOID   HartStack_IdleWait(UINT32 loops);
VOID   HartStack_Reset(VOID);
BOOL   HartStack_SelfCheck(VOID);
VOID   HartStack_SetShortRequest(UINT8 command, UINT8 pollAddr, const UINT8 *data, UINT8 dataLen, const char *label);
VOID   HartStack_SetLongRequest(UINT8 command, const UINT8 longAddr[HART_LONGADDR_LENGTH], const UINT8 *data, UINT8 dataLen, const char *label);
UINT32 HartStack_RunTransaction(UINT8 channel, UINT8 modem, UINT8 pollAddr, BOOL gpwr, HartParsedResponse_t *parsedOut);
BOOL   HartStack_GetCleanCmd0(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out);
BOOL   HartStack_ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[HART_LONGADDR_LENGTH], UINT8 *respPreambles);
BOOL   HartStack_ParseHartResponse(const UINT8 *rx, UINT32 rxLen, HartParsedResponse_t *out);
BOOL   HartStack_RunLongCommand(UINT8 channel,
                                UINT8 modem,
                                UINT8 pollAddr,
                                const UINT8 longAddr[HART_LONGADDR_LENGTH],
                                UINT8 command,
                                const UINT8 *data,
                                UINT8 dataLen,
                                const char *label,
                                HartParsedResponse_t *parsedOut);
const HartCommandInfo_t *HartStack_GetCommandTable(UINT8 *countOut);

VOID CheckAndInitHart(VOID);
BOOL isHartCapable(VOID);
VOID ProcessHartInterrupt(VOID);
BOOL InitHartConnection(UINT8 a_ucChan);
VOID ResetHart(VOID);
BOOL AbortHartConnection(UINT8 a_ucChan);

#ifdef __cplusplus
}
#endif

#endif
