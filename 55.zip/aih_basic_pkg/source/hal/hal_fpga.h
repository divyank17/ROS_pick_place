/*******************************************************************************
*    File Name   : hal_fpga.h
*    Description : RT1024 -> FPGA SPI register access and centralized AIH HART
*                  register map.
*
*    Clean HART cleanup:
*      - All FPGA, UART16550, BRG, HART mux, GPWR and HART command/register
*        values used by pmio_kernel.cpp are kept here.
*      - pmio_kernel.cpp contains the HART bring-up/state-machine logic only.
*
*    SPI note:
*      The FPGA design uses 7-bit register address plus bit7 read command.
*      The low-level HAL accepts read-command addresses such as 0xC5 and masks
*      bit7 internally for the wire transaction. Existing hal_fpga_read/write
*      implementations from the project are preserved.
*******************************************************************************/

#ifndef HAL_FPGA_H
#define HAL_FPGA_H

#include "datatype.h"

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
* FPGA SPI address helpers
*******************************************************************************/
#define FPGA_READ_BIT                         ((UINT8)0x80u)
#define FPGA_ADDR_MASK                        ((UINT8)0x7Fu)
#define FPGA_RAW_ADDR(a)                      ((UINT8)((a) & FPGA_ADDR_MASK))
#define FPGA_READ_CMD(a)                      ((UINT8)(FPGA_READ_BIT | FPGA_RAW_ADDR(a)))
#define FPGA_WRITE_CMD(a)                     ((UINT8)(FPGA_RAW_ADDR(a)))

#ifndef FPGA_SPI_ADDRESS_SHIFT
#define FPGA_SPI_ADDRESS_SHIFT                (0u)
#endif

#ifndef FPGA_SPI_8BIT_DATA_IN_MSB
#define FPGA_SPI_8BIT_DATA_IN_MSB             (1u)
#endif

/*******************************************************************************
* FPGA common register map
*******************************************************************************/
/* Common UART baud generator registers. */
#define FPGA_BRG_DLL                          ((UINT8)0x40u)
#define FPGA_BRG_DLM                          ((UINT8)0x41u)
#define FPGA_BRG_MUX                          ((UINT8)0x42u)

/* Register 0x50 is not baud. It is output-control / wiggle related. */
#define FPGA_REG_50_OUTPUT_CONTROL            ((UINT8)0x50u)

/* Read-command view for global/common registers. */
#define FPGA_IRQ_STATUS                       ((UINT8)0xC4u)
#define FPGA_VERSION                          ((UINT8)0xC5u)
#define FPGA_REVISION                         ((UINT8)0xC6u)

#define FPGA_MODNUM                           ((UINT8)0xC8u)
#define FPGA_SW_STATUS                        ((UINT8)0xC9u)
#define FPGA_IOL_STATUS                       ((UINT8)0xCAu)
#define FPGA_IOTA_STATUS                      FPGA_IOL_STATUS
#define FPGA_MISC                             ((UINT8)0xCBu)
#define FPGA_MISC_STATUS                      FPGA_MISC
#define FPGA_CPLD_REV                         ((UINT8)0xCCu)
#define FPGA_CPLD_REVISION                    FPGA_CPLD_REV

#define FPGA_MAR                              ((UINT8)0xCDu)
#define FPGA_MER                              ((UINT8)0xCEu)
#define FPGA_HMUX_ADDR                        FPGA_MAR
#define FPGA_HMUX_ENABLE                      FPGA_MER

#define FPGA_GPWR                             ((UINT8)0xCFu)
#define FPGA_WIGGLE                           ((UINT8)0xD0u)
#define FPGA_WIGGLE_PV                        FPGA_WIGGLE
#define FPGA_WIGGLE_PV_CR                     FPGA_WIGGLE

#define FPGA_OUTPUT_MUX                       ((UINT8)0xE0u)
#define FPGA_READBACK_MUX                     ((UINT8)0xF0u)

/* Compatibility aliases used by earlier port files. */
#define FPGA_DLL                              FPGA_BRG_DLL
#define FPGA_DLM                              FPGA_BRG_DLM
#define FPGA_REV_LETTER                       FPGA_VERSION
#define FPGA_REV_NUMBER                       FPGA_REVISION
#define FPGA_IOLIOTASR                        FPGA_IOL_STATUS
#define FPGA_ISR_ADDR                         FPGA_IRQ_STATUS
#define FPGA_HART_MUXADDR                     FPGA_MAR
#define FPGA_HART_MUXENBL                     FPGA_MER
#define FPGA_BAUDRATE_BASE                    FPGA_BRG_DLL

/*******************************************************************************
* Proven Stage 24/27/28 HART hardware values
*******************************************************************************/
/* Confirmed working HART baud generator values. */
#define FPGA_HART_BRG_DLL_1200                ((UINT8)0xE2u)
#define FPGA_HART_BRG_DLM_1200                ((UINT8)0x04u)
#define FPGA_HART_BRG_MUX_DEFAULT             ((UINT8)0x00u)

/* GPWR mask/data format: write 0x0808 to enable the HART power/mux path bit. */
#define FPGA_GPWR_HART_POWER_MASK             ((UINT8)0x08u)
#define FPGA_GPWR_HART_POWER_ENABLE           ((UINT8)0x08u)
#define FPGA_GPWR_HART_POWER_WRITE16          ((UINT16)0x0808u)

/* Legacy mux values that worked for channel 1 / modem 0. */
#define HART_DEFAULT_MAR_CH1_M0               ((UINT16)0xC840u)
#define HART_DEFAULT_MER_NONE                 ((UINT8)0x00u)
#define HART_DEFAULT_MER_MODEM0               ((UINT8)0x01u)

/*******************************************************************************
* FPGA UART16550 register map
*******************************************************************************/
#define UART_COUNT                            ((UINT8)4u)
#define UART_STRIDE                           ((UINT8)0x10u)

/* Raw write base addresses. */
#define UART0_WRITE_BASE                      ((UINT8)0x00u)
#define UART1_WRITE_BASE                      ((UINT8)0x10u)
#define UART2_WRITE_BASE                      ((UINT8)0x20u)
#define UART3_WRITE_BASE                      ((UINT8)0x30u)

/* Read-command base addresses. */
#define UART0_READ_BASE                       ((UINT8)0x80u)
#define UART1_READ_BASE                       ((UINT8)0x90u)
#define UART2_READ_BASE                       ((UINT8)0xA0u)
#define UART3_READ_BASE                       ((UINT8)0xB0u)

/* Backward-compatible names used by pmio/stage code. */
#define UART0_BASE                            UART0_READ_BASE
#define UART1_BASE                            UART1_READ_BASE
#define UART2_BASE                            UART2_READ_BASE
#define UART3_BASE                            UART3_READ_BASE

#define UART_READ_BASE(modem)                 ((UINT8)(UART0_READ_BASE  + ((UINT8)((modem) & 0x03u) * UART_STRIDE)))
#define UART_WRITE_BASE(modem)                ((UINT8)(UART0_WRITE_BASE + ((UINT8)((modem) & 0x03u) * UART_STRIDE)))

#define UART0_RESET                           ((UINT8)0x08u)
#define UART1_RESET                           ((UINT8)0x18u)
#define UART2_RESET                           ((UINT8)0x28u)
#define UART3_RESET                           ((UINT8)0x38u)

#define UART_RESET_ADDR(modem)                ((UINT8)(UART0_RESET + ((UINT8)((modem) & 0x03u) * UART_STRIDE)))

#define UART_RBR_THR                          ((UINT8)0x00u)
#define UART_RBR                              UART_RBR_THR
#define UART_THR                              UART_RBR_THR
#define UART_IER                              ((UINT8)0x01u)
#define UART_IIR_FCR                          ((UINT8)0x02u)
#define UART_IIR                              UART_IIR_FCR
#define UART_FCR                              UART_IIR_FCR
#define UART_LCR                              ((UINT8)0x03u)
#define UART_MCR                              ((UINT8)0x04u)
#define UART_LSR                              ((UINT8)0x05u)
#define UART_MSR                              ((UINT8)0x06u)
#define UART_SCR                              ((UINT8)0x07u)

/* UART LSR bits. */
#define UART_LSR_DR                           ((UINT8)0x01u)
#define UART_LSR_OE                           ((UINT8)0x02u)
#define UART_LSR_PE                           ((UINT8)0x04u)
#define UART_LSR_FE                           ((UINT8)0x08u)
#define UART_LSR_BI                           ((UINT8)0x10u)
#define UART_LSR_THRE                         ((UINT8)0x20u)
#define UART_LSR_TEMT                         ((UINT8)0x40u)
#define UART_LSR_ERROR_MASK                   ((UINT8)(UART_LSR_OE | UART_LSR_PE | UART_LSR_FE | UART_LSR_BI))

/* UART MCR bits. */
#define UART_MCR_DTR                          ((UINT8)0x01u)
#define UART_MCR_RTS                          ((UINT8)0x02u)
#define UART_MCR_OUT1                         ((UINT8)0x04u)
#define UART_MCR_OUT2                         ((UINT8)0x08u)
#define UART_MCR_LOOPBACK                     ((UINT8)0x10u)

/* UART MSR bits. */
#define UART_MSR_DCTS                         ((UINT8)0x01u)
#define UART_MSR_DDSR                         ((UINT8)0x02u)
#define UART_MSR_TERI                         ((UINT8)0x04u)
#define UART_MSR_DDCD                         ((UINT8)0x08u)
#define UART_MSR_CTS                          ((UINT8)0x10u)
#define UART_MSR_DSR                          ((UINT8)0x20u)
#define UART_MSR_RI                           ((UINT8)0x40u)
#define UART_MSR_DCD                          ((UINT8)0x80u)

/* Proven UART configuration values. */
#define UART_LCR_8O1_ODD_PARITY               ((UINT8)0x0Bu)
#define UART_FCR_ENABLE_CLEAR_TRIGGER         ((UINT8)0xC1u)
#define UART_SCR_TEST_VALUE                   ((UINT8)0xDBu)

#define HART_IER_RX_MODEM_STATUS              ((UINT8)0x09u)
#define HART_IER_TX_EMPTY                     ((UINT8)0x02u)

/*******************************************************************************
* HART protocol constants used by bring-up
*******************************************************************************/
#ifndef HART_PREAMBLE_BYTE
#define HART_PREAMBLE_BYTE                    ((UINT8)0xFFu)
#endif

#ifndef HART_DELIMITER_SHORT_MASTER_REQ
#define HART_DELIMITER_SHORT_MASTER_REQ       ((UINT8)0x02u)
#endif
#ifndef HART_DELIMITER_SHORT_SLAVE_RESP
#define HART_DELIMITER_SHORT_SLAVE_RESP       ((UINT8)0x06u)
#endif
#ifndef HART_DELIMITER_LONG_MASTER_REQ
#define HART_DELIMITER_LONG_MASTER_REQ        ((UINT8)0x82u)
#endif
#ifndef HART_DELIMITER_LONG_SLAVE_RESP
#define HART_DELIMITER_LONG_SLAVE_RESP        ((UINT8)0x86u)
#endif

#ifndef HART_COMMAND_ZERO
#define HART_COMMAND_ZERO                     ((UINT8)0u)
#endif
#ifndef HART_COMMAND_THREE
#define HART_COMMAND_THREE                    ((UINT8)3u)
#endif
#ifndef HART_COMMAND_SIX
#define HART_COMMAND_SIX                      ((UINT8)6u)
#endif
#ifndef HART_COMMAND_NINE
#define HART_COMMAND_NINE                     ((UINT8)9u)
#endif
#ifndef HART_COMMAND_TWELVE
#define HART_COMMAND_TWELVE                   ((UINT8)12u)
#endif
#ifndef HART_COMMAND_THIRTEEN
#define HART_COMMAND_THIRTEEN                 ((UINT8)13u)
#endif
#ifndef HART_COMMAND_FOURTEEN
#define HART_COMMAND_FOURTEEN                 ((UINT8)14u)
#endif
#ifndef HART_COMMAND_FIFTEEN
#define HART_COMMAND_FIFTEEN                  ((UINT8)15u)
#endif
#ifndef HART_COMMAND_SIXTEEN
#define HART_COMMAND_SIXTEEN                  ((UINT8)16u)
#endif
#ifndef HART_COMMAND_TWENTY
#define HART_COMMAND_TWENTY                   ((UINT8)20u)
#endif
#ifndef HART_COMMAND_THIRTYTHREE
#define HART_COMMAND_THIRTYTHREE              ((UINT8)33u)
#endif
#ifndef HART_COMMAND_THIRTYEIGHT
#define HART_COMMAND_THIRTYEIGHT              ((UINT8)38u)
#endif
#ifndef HART_COMMAND_FORTYEIGHT
#define HART_COMMAND_FORTYEIGHT               ((UINT8)48u)
#endif
#ifndef HART_COMMAND_FOURTYEIGHT
#define HART_COMMAND_FOURTYEIGHT              HART_COMMAND_FORTYEIGHT
#endif
#ifndef HART_COMMAND_FIFTY
#define HART_COMMAND_FIFTY                    ((UINT8)50u)
#endif
#ifndef HART_COMMAND_FIFTYNINE
#define HART_COMMAND_FIFTYNINE                ((UINT8)59u)
#endif
#ifndef HART_COMMAND_HUNDREDNINE
#define HART_COMMAND_HUNDREDNINE              ((UINT8)109u)
#endif
#ifndef HART_COMMAND_DEFAULT
#define HART_COMMAND_DEFAULT                  ((UINT8)250u)
#endif
#ifndef HART_COMMAND_INVALID
#define HART_COMMAND_INVALID                  ((UINT8)0xFFu)
#endif

/* Old legacy enum-style aliases. */
#ifndef HARTCOMMAND_ZERO
#define HARTCOMMAND_ZERO                      HART_COMMAND_ZERO
#endif
#ifndef HARTCOMMAND_THREE
#define HARTCOMMAND_THREE                     HART_COMMAND_THREE
#endif
#ifndef HARTCOMMAND_SIX
#define HARTCOMMAND_SIX                       HART_COMMAND_SIX
#endif
#ifndef HARTCOMMAND_NINE
#define HARTCOMMAND_NINE                      HART_COMMAND_NINE
#endif
#ifndef HARTCOMMAND_TWELVE
#define HARTCOMMAND_TWELVE                    HART_COMMAND_TWELVE
#endif
#ifndef HARTCOMMAND_THIRTEEN
#define HARTCOMMAND_THIRTEEN                  HART_COMMAND_THIRTEEN
#endif
#ifndef HARTCOMMAND_FOURTEEN
#define HARTCOMMAND_FOURTEEN                  HART_COMMAND_FOURTEEN
#endif
#ifndef HARTCOMMAND_FIFTEEN
#define HARTCOMMAND_FIFTEEN                   HART_COMMAND_FIFTEEN
#endif
#ifndef HARTCOMMAND_SIXTEEN
#define HARTCOMMAND_SIXTEEN                   HART_COMMAND_SIXTEEN
#endif
#ifndef HARTCOMMAND_TWENTY
#define HARTCOMMAND_TWENTY                    HART_COMMAND_TWENTY
#endif
#ifndef HARTCOMMAND_THIRTYTHREE
#define HARTCOMMAND_THIRTYTHREE               HART_COMMAND_THIRTYTHREE
#endif
#ifndef HARTCOMMAND_THIRTYEIGHT
#define HARTCOMMAND_THIRTYEIGHT               HART_COMMAND_THIRTYEIGHT
#endif
#ifndef HARTCOMMAND_FOURTYEIGHT
#define HARTCOMMAND_FOURTYEIGHT               HART_COMMAND_FOURTYEIGHT
#endif
#ifndef HARTCOMMAND_FIFTY
#define HARTCOMMAND_FIFTY                     HART_COMMAND_FIFTY
#endif
#ifndef HARTCOMMAND_FIFTYNINE
#define HARTCOMMAND_FIFTYNINE                 HART_COMMAND_FIFTYNINE
#endif
#ifndef HARTCOMMAND_HUNDREDNINE
#define HARTCOMMAND_HUNDREDNINE               HART_COMMAND_HUNDREDNINE
#endif
#ifndef HARTCOMMAND_DEFAULT
#define HARTCOMMAND_DEFAULT                   HART_COMMAND_DEFAULT
#endif
#ifndef HARTCOMMAND_INVALID
#define HARTCOMMAND_INVALID                   HART_COMMAND_INVALID
#endif

#ifndef HART_MASTER_ADDR_MASK
#define HART_MASTER_ADDR_MASK                 ((UINT8)0x80u)
#endif
#ifndef HART_MANUFACTURE_ID_MASK
#define HART_MANUFACTURE_ID_MASK              ((UINT8)0x3Fu)
#endif
#ifndef HART_BURST_MODE_MASK
#define HART_BURST_MODE_MASK                  ((UINT8)0x40u)
#endif

#ifndef HART_LONGADDR_LENGTH
#define HART_LONGADDR_LENGTH                  ((UINT8)5u)
#endif
#ifndef HART_CMD0_LEGACY_RESPONSE_SIZE
#define HART_CMD0_LEGACY_RESPONSE_SIZE        ((UINT8)12u)
#endif
#ifndef HART_DEVICEID_SIZE
#define HART_DEVICEID_SIZE                    ((UINT8)3u)
#endif
#ifndef HART_MIN_PREAMBLES
#define HART_MIN_PREAMBLES                    ((UINT8)5u)
#endif
#ifndef HART_MIN_RESPONSE_BYTECOUNT
#define HART_MIN_RESPONSE_BYTECOUNT           ((UINT8)2u)
#endif

/*******************************************************************************
* Low-level FPGA access functions implemented by the existing HAL source file
*******************************************************************************/
void   hal_fpga_init(void);
UINT16 hal_fpga_read(UINT8 addr);
void   hal_fpga_write(UINT8 addr, UINT16 data);

/*******************************************************************************
* Inline helpers
*******************************************************************************/
static inline UINT8 hal_fpga_wire_addr(UINT8 addr)
{
    return (UINT8)(addr << FPGA_SPI_ADDRESS_SHIFT);
}

static inline UINT8 hal_fpga_read8(UINT8 addr)
{
#if FPGA_SPI_8BIT_DATA_IN_MSB
    return (UINT8)((hal_fpga_read(hal_fpga_wire_addr(addr)) >> 8) & 0xFFu);
#else
    return (UINT8)(hal_fpga_read(hal_fpga_wire_addr(addr)) & 0xFFu);
#endif
}

static inline UINT8 hal_fpga_read_lsb8(UINT8 addr)
{
    return (UINT8)(hal_fpga_read(hal_fpga_wire_addr(addr)) & 0xFFu);
}

static inline void hal_fpga_write8(UINT8 addr, UINT8 data)
{
#if FPGA_SPI_8BIT_DATA_IN_MSB
    hal_fpga_write(hal_fpga_wire_addr(addr), (UINT16)((UINT16)data << 8));
#else
    hal_fpga_write(hal_fpga_wire_addr(addr), (UINT16)data);
#endif
}

static inline UINT8 hal_fpga_uart_read_addr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_READ_BASE(modem) + reg);
}

static inline UINT8 hal_fpga_uart_write_addr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_WRITE_BASE(modem) + reg);
}

static inline UINT8 hal_fpga_uart_read(UINT8 modem, UINT8 reg)
{
    return hal_fpga_read8(hal_fpga_uart_read_addr(modem, reg));
}

static inline void hal_fpga_uart_write(UINT8 modem, UINT8 reg, UINT8 data)
{
    hal_fpga_write8(hal_fpga_uart_write_addr(modem, reg), data);
}

static inline UINT8 hal_fpga_uart_rx_byte(UINT8 modem)
{
    return hal_fpga_uart_read(modem, UART_RBR);
}

static inline void hal_fpga_uart_tx_byte(UINT8 modem, UINT8 data)
{
    hal_fpga_uart_write(modem, UART_THR, data);
}

static inline void hal_fpga_uart_reset(UINT8 modem)
{
    UINT8 addr = UART_RESET_ADDR(modem);
    hal_fpga_write8(addr, 0x01u);
    hal_fpga_write8(addr, 0x00u);
}

static inline void hal_fpga_hart_brg_configure_1200(void)
{
    hal_fpga_write8(FPGA_BRG_DLL, FPGA_HART_BRG_DLL_1200);
    hal_fpga_write8(FPGA_BRG_DLM, FPGA_HART_BRG_DLM_1200);
    hal_fpga_write8(FPGA_BRG_MUX, FPGA_HART_BRG_MUX_DEFAULT);
}

static inline void hal_fpga_gpwr_hart_power_enable(void)
{
    hal_fpga_write(FPGA_GPWR, FPGA_GPWR_HART_POWER_WRITE16);
}

static inline void hal_fpga_gpwr_write(UINT8 mask, UINT8 data)
{
    hal_fpga_write(FPGA_GPWR, (UINT16)(((UINT16)mask << 8) | data));
}

static inline void hal_fpga_hart_mux_set16(UINT16 muxAddr)
{
    hal_fpga_write(FPGA_MAR, muxAddr);
}

static inline void hal_fpga_hart_mux_enable(UINT8 muxEnableMask)
{
    hal_fpga_write8(FPGA_MER, muxEnableMask);
}

static inline UINT16 hal_fpga_hart_mux_get_addr16(void)
{
    return hal_fpga_read(FPGA_MAR);
}

static inline UINT8 hal_fpga_hart_mux_get_enable(void)
{
    return hal_fpga_read8(FPGA_MER);
}

/* Compatibility helpers for old HART-style code. */
static inline UINT8 HART_UART_ReadByte(UINT8 uart)
{
    return hal_fpga_uart_rx_byte(uart);
}

static inline void HART_UART_WriteByte(UINT8 uart, UINT8 val)
{
    hal_fpga_uart_tx_byte(uart, val);
}

static inline UINT8 HART_UART_ReadReg(UINT8 uart, UINT8 reg)
{
    return hal_fpga_uart_read(uart, reg);
}

static inline void HART_UART_WriteReg(UINT8 uart, UINT8 reg, UINT8 val)
{
    hal_fpga_uart_write(uart, reg, val);
}

static inline UINT8 HART_UART_DataReady(UINT8 uart)
{
    return (UINT8)((hal_fpga_uart_read(uart, UART_LSR) & UART_LSR_DR) ? 1u : 0u);
}

static inline UINT8 HART_UART_TxEmpty(UINT8 uart)
{
    return (UINT8)((hal_fpga_uart_read(uart, UART_LSR) & UART_LSR_THRE) ? 1u : 0u);
}

static inline UINT8 HART_UART_TxCompletelyEmpty(UINT8 uart)
{
    return (UINT8)((hal_fpga_uart_read(uart, UART_LSR) & UART_LSR_TEMT) ? 1u : 0u);
}

static inline UINT8 HART_UART_LineStatus(UINT8 uart)
{
    return hal_fpga_uart_read(uart, UART_LSR);
}

static inline UINT8 HART_UART_ModemStatus(UINT8 uart)
{
    return hal_fpga_uart_read(uart, UART_MSR);
}


/*******************************************************************************
* Legacy HART/FPGA compatibility names
*
* These names are used by existing hart.cpp / hartstack.cpp. The clean HART module moved the
* register map into this file, so keep these aliases here to avoid touching the
* legacy source files.
*******************************************************************************/
#ifndef FPGA_UART_STRIDE
#define FPGA_UART_STRIDE                      UART_STRIDE
#endif

#ifndef FPGA_UART0_BASE
#define FPGA_UART0_BASE                       UART0_WRITE_BASE
#endif
#ifndef FPGA_UART1_BASE
#define FPGA_UART1_BASE                       UART1_WRITE_BASE
#endif
#ifndef FPGA_UART2_BASE
#define FPGA_UART2_BASE                       UART2_WRITE_BASE
#endif
#ifndef FPGA_UART3_BASE
#define FPGA_UART3_BASE                       UART3_WRITE_BASE
#endif

#ifndef FPGA_UART_RBR
#define FPGA_UART_RBR                         UART_RBR
#endif
#ifndef FPGA_UART_THR
#define FPGA_UART_THR                         UART_THR
#endif
#ifndef FPGA_UART_IER
#define FPGA_UART_IER                         UART_IER
#endif
#ifndef FPGA_UART_IIR
#define FPGA_UART_IIR                         UART_IIR
#endif
#ifndef FPGA_UART_FCR
#define FPGA_UART_FCR                         UART_FCR
#endif
#ifndef FPGA_UART_LCR
#define FPGA_UART_LCR                         UART_LCR
#endif
#ifndef FPGA_UART_MCR
#define FPGA_UART_MCR                         UART_MCR
#endif
#ifndef FPGA_UART_LSR
#define FPGA_UART_LSR                         UART_LSR
#endif
#ifndef FPGA_UART_MSR
#define FPGA_UART_MSR                         UART_MSR
#endif
#ifndef FPGA_UART_SCR
#define FPGA_UART_SCR                         UART_SCR
#endif

#ifndef HART_UART_LSR_DR
#define HART_UART_LSR_DR                      UART_LSR_DR
#endif
#ifndef HART_UART_LSR_THRE
#define HART_UART_LSR_THRE                    UART_LSR_THRE
#endif
#ifndef HART_UART_LSR_TEMT
#define HART_UART_LSR_TEMT                    UART_LSR_TEMT
#endif
#ifndef HART_UART_LSR_ERROR_MASK
#define HART_UART_LSR_ERROR_MASK              UART_LSR_ERROR_MASK
#endif

#ifndef HART_UART_MCR_DTR
#define HART_UART_MCR_DTR                     UART_MCR_DTR
#endif
#ifndef HART_UART_MCR_RTS
#define HART_UART_MCR_RTS                     UART_MCR_RTS
#endif

#ifndef HART_UART_MSR_DCD
#define HART_UART_MSR_DCD                     UART_MSR_DCD
#endif
#ifndef HART_UART_MSR_DDCD
#define HART_UART_MSR_DDCD                    UART_MSR_DDCD
#endif
#ifndef HART_UART_MSR_RI
#define HART_UART_MSR_RI                      UART_MSR_RI
#endif
#ifndef HART_UART_MSR_DSR
#define HART_UART_MSR_DSR                     UART_MSR_DSR
#endif
#ifndef HART_UART_MSR_CTS
#define HART_UART_MSR_CTS                     UART_MSR_CTS
#endif

static inline UINT8 hal_fpga_get_rev_letter(void)
{
    return hal_fpga_read8(FPGA_VERSION);
}

static inline UINT8 hal_fpga_get_rev_number(void)
{
    return hal_fpga_read8(FPGA_REVISION);
}

static inline UINT8 hal_fpga_get_modnum(void)
{
    return hal_fpga_read8(FPGA_MODNUM);
}

static inline UINT8 hal_fpga_read_isr(void)
{
    return hal_fpga_read8(FPGA_IRQ_STATUS);
}

static inline UINT8 hal_fpga_get_switch_status(void)
{
    return hal_fpga_read8(FPGA_SW_STATUS);
}

static inline UINT8 hal_fpga_get_iota_status(void)
{
    return hal_fpga_read8(FPGA_IOL_STATUS);
}

static inline UINT8 hal_fpga_get_misc_status(void)
{
    return hal_fpga_read8(FPGA_MISC_STATUS);
}

static inline UINT8 hal_fpga_get_cpld_rev(void)
{
    return hal_fpga_read8(FPGA_CPLD_REVISION);
}

static inline UINT16 hal_fpga_hart_mux_get_addr(void)
{
    return hal_fpga_hart_mux_get_addr16();
}

static inline UINT16 HART_ReadMuxAddr(void)
{
    return hal_fpga_hart_mux_get_addr16();
}

static inline UINT8 HART_ReadMuxEnable(void)
{
    return hal_fpga_hart_mux_get_enable();
}

static inline UINT8 HART_ReadIrqStatus(void)
{
    return hal_fpga_read8(FPGA_IRQ_STATUS);
}

static inline void HART_SetMux(UINT16 muxAddr)
{
    hal_fpga_hart_mux_set16(muxAddr);
}

static inline void HART_EnableMux(UINT8 muxEnableMask)
{
    hal_fpga_hart_mux_enable(muxEnableMask);
}

static inline void HART_UART_DisableInts(UINT8 uart)
{
    hal_fpga_uart_write(uart, UART_IER, 0x00u);
}

static inline void HART_UART_EnableRxInt(UINT8 uart)
{
    hal_fpga_uart_write(uart, UART_IER, HART_IER_RX_MODEM_STATUS);
}

static inline void HART_UART_EnableTxInt(UINT8 uart)
{
    hal_fpga_uart_write(uart, UART_IER, HART_IER_TX_EMPTY);
}

static inline UINT8 HART_UART_GetMCR(UINT8 uart)
{
    return hal_fpga_uart_read(uart, UART_MCR);
}

static inline void HART_UART_SetMCR(UINT8 uart, UINT8 value)
{
    hal_fpga_uart_write(uart, UART_MCR, value);
}

static inline void HART_UART_SetDTRValue(UINT8 uart, UINT8 enable)
{
    UINT8 mcr = HART_UART_GetMCR(uart);

    if (enable != 0u)
    {
        mcr |= UART_MCR_DTR;
    }
    else
    {
        mcr &= (UINT8)(~UART_MCR_DTR);
    }

    HART_UART_SetMCR(uart, mcr);
}

static inline void HART_UART_SetDTRAssert(UINT8 uart)
{
    HART_UART_SetDTRValue(uart, 1u);
}

static inline void HART_UART_ClearDTR(UINT8 uart)
{
    HART_UART_SetDTRValue(uart, 0u);
}

static inline void HART_UART_SetRTSValue(UINT8 uart, UINT8 enable)
{
    UINT8 mcr = HART_UART_GetMCR(uart);

    if (enable != 0u)
    {
        mcr |= UART_MCR_RTS;
    }
    else
    {
        mcr &= (UINT8)(~UART_MCR_RTS);
    }

    HART_UART_SetMCR(uart, mcr);
}

static inline void HART_UART_SetRTSAssert(UINT8 uart)
{
    HART_UART_SetRTSValue(uart, 1u);
}

static inline void HART_UART_ClearRTS(UINT8 uart)
{
    HART_UART_SetRTSValue(uart, 0u);
}

/*
 * Legacy code uses both forms:
 *   HART_UART_SetDTR(uart);
 *   HART_UART_SetDTR(uart, 0u/1u);
 *   HART_UART_SetRTS(uart);
 *   HART_UART_SetRTS(uart, 0u/1u);
 *
 * Use a small macro dispatcher so the old files compile without editing
 * hartstack.cpp.
 */
#ifndef HART_UART_SETDTR_SELECT
#define HART_UART_SETDTR_SELECT(_1, _2, NAME, ...) NAME
#endif

#ifndef HART_UART_SETRTS_SELECT
#define HART_UART_SETRTS_SELECT(_1, _2, NAME, ...) NAME
#endif

#ifndef HART_UART_SetDTR
#define HART_UART_SetDTR(...) HART_UART_SETDTR_SELECT(__VA_ARGS__, HART_UART_SetDTRValue, HART_UART_SetDTRAssert)(__VA_ARGS__)
#endif

#ifndef HART_UART_SetRTS
#define HART_UART_SetRTS(...) HART_UART_SETRTS_SELECT(__VA_ARGS__, HART_UART_SetRTSValue, HART_UART_SetRTSAssert)(__VA_ARGS__)
#endif

static inline void HART_UART_InitLegacy16550(UINT8 uart)
{
    HART_UART_DisableInts(uart);
    hal_fpga_uart_write(uart, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    hal_fpga_uart_write(uart, UART_FCR, UART_FCR_ENABLE_CLEAR_TRIGGER);
    hal_fpga_uart_write(uart, UART_SCR, UART_SCR_TEST_VALUE);
}

#ifdef __cplusplus
}
#endif

#endif /* HAL_FPGA_H */
