/*******************************************************************************
*    File Name   : hartstack.hpp
*    Description : HART frame/state-machine stack for RT1024 AIH FPGA UART16550.
*
*    Clean legacy-style modularization:
*      - Low-level UART/FPGA transaction state machine lives in hartstack.cpp.
*      - Register values remain in source/hal/hal_fpga.h.
*      - High-level discovery lives in hart.cpp.
*******************************************************************************/

#ifndef __HARTSTACK_HPP__
#define __HARTSTACK_HPP__

#include <stdint.h>
#include <stdbool.h>

#include "datatype.h"
#include "hal_fpga.h"


/*******************************************************************************
*                             TYPES AND ENUMERATIONS
*******************************************************************************/
typedef enum tagHModemState
{
    HMODEMSTATE_UNKNOWN,
    HMODEMSTATE_BAD,
    HMODEMSTATE_IDLE,
    HMODEMSTATE_SYNCWAIT,
    HMODEMSTATE_XMTING,
    HMODEMSTATE_RCVWAIT,
    HMODEMSTATE_RCVING,
    HMODEMSTATE_SUSPECT,
    HMODEMSTATE_DIAG
} HMODEMSTATE;

typedef enum tagHSyncStatus
{
    HSYNCSTATUS_UNKNOWN,
    HSYNCSTATUS_KEEP_SYNC,
    HSYNCSTATUS_DROP_SYNC
} HSYNCSTATUS;

typedef enum tagHIntrType
{
    HINTRTYPE_UNKNOWN,
    HINTRTYPE_RCVFIFOFULL,
    HINTRTYPE_RCVFIFOTOUT,
    HINTRTYPE_XMTFIFOEMPTY,
    HINTRTYPE_CARRIERDETECT,
    HINTRTYPE_CARRIERDROP
} HINTRTYPE;

typedef enum tagHMsgType
{
    HMSGTYPE_UNKNOWN,
    HMSGTYPE_STX,
    HMSGTYPE_ACKTOME,
    HMSGTYPE_ACKTOHIM,
    HMSGTYPE_BACKTOME,
    HMSGTYPE_BACKTOHIM,
    HMSGTYPE_STXFROMME
} HMSGTYPE;

typedef enum tagHMsgStatus
{
    HMSGSTATUS_GOOD,
    HMSGSTATUS_BAD,
    HMSGSTATUS_DEVICEERROR
} HMSGSTATUS;

typedef enum tagHEventType
{
    HEVENTTYPE_UNKNOWN,
    HEVENTTYPE_COMMERROR,
    HEVENTTYPE_NORESPONSE,
    HEVENTTYPE_DEVICEERROR,
    HEVENTTYPE_RCVRERROR,
    HEVENTTYPE_RETRY,
    HEVENTTYPE_TOTALTIMEOUT,
    HEVENTTYPE_SECMASTER,
    HEVENTTYPE_BURSTMODE,
    HEVENTTYPE_PRIMASTER
} HEVENTTYPE;

typedef enum tagXmtRcvContext
{
    XMTRCVCONTEXT_UNKNOWN,
    XMTRCVCONTEXT_PREAMBLE,
    XMTRCVCONTEXT_DELIMITER,
    XMTRCVCONTEXT_ADDRESS,
    XMTRCVCONTEXT_COMMAND,
    XMTRCVCONTEXT_BYTECOUNT,
    XMTRCVCONTEXT_STATUS,
    XMTRCVCONTEXT_DATA
} XMTRCVCONTEXT;

/*******************************************************************************
*                                  CONSTANTS
*******************************************************************************/
#ifndef HARTMODEM_COUNT
#define HARTMODEM_COUNT                       ((UINT8)4u)
#endif

#ifndef HARTQUEUE_BUFFER_SIZE
#define HARTQUEUE_BUFFER_SIZE                 ((UINT8)16u)
#endif

#ifndef HARTMODEM_BUFFER_SIZE
#define HARTMODEM_BUFFER_SIZE                 ((UINT8)32u)
#endif

#ifndef HSYNC_MINIMUM_TIME
#define HSYNC_MINIMUM_TIME                    ((UINT8)1u)
#endif

#ifndef CHECKPAD_BYTECOUNT
#define CHECKPAD_BYTECOUNT                    ((UINT8)2u)
#endif

#ifndef XMTINT_ALLOWANCE
#define XMTINT_ALLOWANCE                      ((UINT8)1u)
#endif

#ifndef RCVINT_ALLOWANCE
#define RCVINT_ALLOWANCE                      ((UINT8)2u)
#endif

#ifndef MAX_DRIBBLE_BYTES
#define MAX_DRIBBLE_BYTES                     ((UINT8)2u)
#endif

#ifndef UART_XMT_FIFO_SIZE
#define UART_XMT_FIFO_SIZE                    ((UINT8)16u)
#endif

#ifndef UART_RCV_FIFO_SIZE
#define UART_RCV_FIFO_SIZE                    ((UINT8)16u)
#endif

#ifndef HMODEMDIAG_MAXCOUNT
#define HMODEMDIAG_MAXCOUNT                   ((UINT8)3u)
#endif

#ifndef HMODEMDIAG_UNDERRUN_MAXCOUNT
#define HMODEMDIAG_UNDERRUN_MAXCOUNT          ((UINT8)10u)
#endif

#ifndef HART_LOOPBACK_SIZE
#define HART_LOOPBACK_SIZE                    ((UINT8)12u)
#endif

#ifndef HART_ENABLE_ALL_MUXES
#define HART_ENABLE_ALL_MUXES                 ((UINT16)0x000Fu)
#endif

#ifndef HART_UART_8BITS_PER_CHAR
#define HART_UART_8BITS_PER_CHAR              ((UINT8)0x03u)
#endif

#ifndef HART_UART_LINE_STS_ERROR_BITS
#define HART_UART_LINE_STS_ERROR_BITS         ((UINT8)0x1Eu)
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    bool valid;
    bool checksumOk;
    bool isLongAddress;
    bool hasStatus;

    UINT8 preambleCount;
    UINT8 delimiter;
    UINT8 address[5];
    UINT8 addressLen;
    UINT8 command;
    UINT8 byteCount;
    UINT8 status0;
    UINT8 status1;
    UINT8 payloadLen;
    UINT8 payload[64];
    UINT8 checksumRx;
    UINT8 checksumCalc;

    UINT8 longAddr[5];
    UINT8 responsePreambles;
    UINT8 hartRevision;
    UINT8 deviceRevision;
} HartParsedResponse_t;

typedef struct
{
    UINT8 command;
    const char *name;
    bool implemented;
    bool executedByDefault;
    bool changesDeviceConfiguration;
} HartLegacyCommandInfo_t;

void   HartStack_IdleWait(UINT32 loops);
void   HartStack_Reset(VOID);
bool   HartStack_SelfCheck(void);
void   HartStack_SetShortRequest(UINT8 command, UINT8 pollAddr, const UINT8 *data, UINT8 dataLen, const char *label);
void   HartStack_SetLongRequest(UINT8 command, const UINT8 longAddr[5], const UINT8 *data, UINT8 dataLen, const char *label);
UINT32 HartStack_RunTransaction(UINT8 channel, UINT8 modem, UINT8 pollAddr, bool gpwr, HartParsedResponse_t *parsedOut);
bool   HartStack_GetCleanCmd0(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out);
bool   HartStack_ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[5], UINT8 *respPreambles);
bool   HartStack_ParseHartResponse(const UINT8 *rx, UINT32 rxLen, HartParsedResponse_t *out);
bool   HartStack_RunLongCommand(UINT8 channel,
                                UINT8 modem,
                                UINT8 pollAddr,
                                const UINT8 longAddr[5],
                                UINT8 command,
                                const UINT8 *data,
                                UINT8 dataLen,
                                const char *label,
                                HartParsedResponse_t *parsedOut);
const HartLegacyCommandInfo_t *HartStack_GetLegacyCommandTable(UINT8 *countOut);


/* Legacy global interface names are implemented in hart.cpp. */
BOOL isHartCapable(VOID);
VOID CheckAndInitHart(VOID);
VOID ProcessHartInterrupt(VOID);
BOOL InitHartConnection(UINT8 a_ucChan);
VOID ResetHart(VOID);
BOOL AbortHartConnection(UINT8 a_ucChan);

#ifdef __cplusplus
}
#endif

#endif /* __HARTSTACK_HPP__ */
