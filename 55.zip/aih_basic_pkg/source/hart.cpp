/*******************************************************************************
*    File Name   : hart.cpp
*    Description : High-level HART discovery and legacy command checks.
*******************************************************************************/

#include <stddef.h>
#include <string.h>

#include "fsl_debug_console.h"
#include "hart.h"

#define HART_TEST_CHANNEL                       (2u)
#define HART_TEST_MODEM                         (0u)
#define HART_POLL_ADDR_START                    (0u)
#define HART_POLL_ADDR_END                      (0u)

/* Keep read-only legacy checks enabled. These are summary-only prints. */
#ifndef HART_ENABLE_LEGACY_READ_CHECKS
#define HART_ENABLE_LEGACY_READ_CHECKS          (1u)
#endif

/* Disabled by default because these commands change device configuration/state. */
#ifndef HART_ENABLE_LEGACY_WRITE_CHECKS
#define HART_ENABLE_LEGACY_WRITE_CHECKS         (0u)
#endif

static UINT8 g_runtimeLongAddr[5] = {0u, 0u, 0u, 0u, 0u};
static UINT8 g_runtimePollAddr = 0u;
static bool  g_haveLongAddr = false;

static UINT8 g_activeChannel = (UINT8)HART_TEST_CHANNEL;
static UINT8 g_activeModem = (UINT8)HART_TEST_MODEM;

static void HartClearRuntimeState(void)
{
    HartDb_Clear();
    g_haveLongAddr = false;
    g_runtimePollAddr = (UINT8)HART_POLL_ADDR_START;
    memset(g_runtimeLongAddr, 0, sizeof(g_runtimeLongAddr));
}

static void HartSetActiveRoute(UINT8 channel, UINT8 modem)
{
    g_activeChannel = channel;
    g_activeModem = modem;
    HartClearRuntimeState();

    PRINTF("[HART_ROUTE] channel=%u modem=%u\r\n",
           (unsigned int)g_activeChannel,
           (unsigned int)g_activeModem);
}

static void HartPrintCommandStatus(const char *label, const HartParsedResponse_t *rsp)
{
    if ((label == NULL) || (rsp == NULL))
    {
        return;
    }

    if (!rsp->valid || !rsp->checksumOk)
    {
        PRINTF("[HART_CMD][%s] parse/checksum failed.\r\n", label);
        return;
    }

    PRINTF("[HART_CMD][%s] cmd=%u status=[0x%02X 0x%02X] payloadLen=%u\r\n",
           label,
           (unsigned int)rsp->command,
           (unsigned int)rsp->status0,
           (unsigned int)rsp->status1,
           (unsigned int)rsp->payloadLen);
}

static bool HartRunReadCommand(UINT8 command, const char *label, HartParsedResponse_t *responseOut)
{
    if (!g_haveLongAddr)
    {
        PRINTF("[HART_CMD][%s] skipped; no long address yet.\r\n", label);
        return false;
    }

    if (!HartStack_RunLongCommand(g_activeChannel,
                                  g_activeModem,
                                  g_runtimePollAddr,
                                  g_runtimeLongAddr,
                                  command,
                                  NULL,
                                  0u,
                                  label,
                                  responseOut))
    {
        PRINTF("[HART_CMD][%s] no valid response.\r\n", label);
        return false;
    }

    HartPrintCommandStatus(label, responseOut);
    return true;
}

static bool HartRunWriteCommand(UINT8 command, const UINT8 *data, UINT8 dataLen, const char *label, HartParsedResponse_t *responseOut)
{
    if (!g_haveLongAddr)
    {
        PRINTF("[HART_CMD][%s] skipped; no long address yet.\r\n", label);
        return false;
    }

    if (!HartStack_RunLongCommand(g_activeChannel,
                                  g_activeModem,
                                  g_runtimePollAddr,
                                  g_runtimeLongAddr,
                                  command,
                                  data,
                                  dataLen,
                                  label,
                                  responseOut))
    {
        PRINTF("[HART_CMD][%s] no valid response.\r\n", label);
        return false;
    }

    HartPrintCommandStatus(label, responseOut);
    return true;
}

void HartPrintLegacyCommandCoverage(void)
{
    UINT8 count = 0u;
    const HartLegacyCommandInfo_t *table = HartStack_GetLegacyCommandTable(&count);

    PRINTF("[LEGACY_COMMANDS] implemented:");
    for (UINT8 i = 0u; i < count; i++)
    {
        if (table[i].implemented)
        {
            PRINTF(" %u", (unsigned int)table[i].command);
        }
    }
    PRINTF("\r\n");

    PRINTF("[LEGACY_COMMANDS] default checks: CMD3 and read-only commands\r\n");
}

static void HartPrintPayloadBytes(const char *label, const UINT8 *payload, UINT8 payloadLen)
{
    if ((label == NULL) || (payload == NULL))
    {
        return;
    }

    PRINTF("[%s] payloadLen=%u :", label, (unsigned int)payloadLen);
    for (UINT8 i = 0u; i < payloadLen; i++)
    {
        PRINTF(" %02X", (unsigned int)payload[i]);
    }
    PRINTF("\r\n");
}

bool HartReadDynamicValues(void)
{
    HartParsedResponse_t cmd3;

    if (!HartRunReadCommand(HART_COMMAND_THREE, "CMD3_READ_DYNAMIC_VARS", &cmd3))
    {
        return false;
    }

    if ((cmd3.status0 != 0u) || (cmd3.status1 != 0u))
    {
        PRINTF("[HART_VALUE] CMD3 returned device status [0x%02X 0x%02X]. Value not updated.\r\n",
               (unsigned int)cmd3.status0,
               (unsigned int)cmd3.status1);
        return false;
    }

    HartPrintPayloadBytes("CMD3_PAYLOAD_RAW", cmd3.payload, cmd3.payloadLen);

    if (!HartDb_UpdateDynamicFromCmd3(&cmd3))
    {
        PRINTF("[HART_VALUE] CMD3 response received but payload is too short/invalid for PV decode.\r\n");
        return false;
    }

    HartDb_PrintDynamic();
    PRINTF("[HART_VALUE_NOTE] CMD3 decoded values\r\n");
    return true;
}

static void HartRunLegacyReadChecks(void)
{
#if HART_ENABLE_LEGACY_READ_CHECKS
    HartParsedResponse_t rsp;

    PRINTF("[LEGACY_READ_CHECKS] read-only checks\r\n");

    (void)HartRunReadCommand(HART_COMMAND_TWELVE,   "CMD12_READ_MESSAGE", &rsp);
    (void)HartRunReadCommand(HART_COMMAND_THIRTEEN, "CMD13_READ_TAG_DESCRIPTOR_DATE", &rsp);
    (void)HartRunReadCommand(HART_COMMAND_FOURTEEN, "CMD14_READ_PV_TRANSDUCER_INFO", &rsp);
    (void)HartRunReadCommand(HART_COMMAND_FIFTEEN,  "CMD15_READ_DEVICE_INFO", &rsp);
    (void)HartRunReadCommand(HART_COMMAND_SIXTEEN,  "CMD16_READ_FINAL_ASSEMBLY", &rsp);
    (void)HartRunReadCommand(HART_COMMAND_TWENTY,   "CMD20_READ_LONG_TAG", &rsp);
    (void)HartRunReadCommand(HART_COMMAND_FIFTY,    "CMD50_READ_DYNAMIC_ASSOCIATION", &rsp);
#else
    PRINTF("[LEGACY_READ_CHECKS] Disabled.\r\n");
#endif
}

static void HartRunLegacyWriteChecks(UINT8 responsePreambles)
{
#if HART_ENABLE_LEGACY_WRITE_CHECKS
    HartParsedResponse_t rsp;
    UINT8 cmd59Data[1];

    cmd59Data[0] = responsePreambles;
    if (cmd59Data[0] < HART_MIN_PREAMBLES)
    {
        cmd59Data[0] = HART_MIN_PREAMBLES;
    }

    PRINTF("[LEGACY_WRITE_CHECKS] Running config-changing legacy commands.\r\n");
    (void)HartRunWriteCommand(HART_COMMAND_FIFTYNINE, cmd59Data, 1u, "CMD59_SET_RESPONSE_PREAMBLES", &rsp);
#else
    (void)responsePreambles;
#endif
}

void HartInit(void)
{
    g_activeChannel = (UINT8)HART_TEST_CHANNEL;
    g_activeModem = (UINT8)HART_TEST_MODEM;
    HartClearRuntimeState();
}

HARTDISCOVERYRESULT HartDiscover(void)
{
    HartParsedResponse_t cmd0;
    HartParsedResponse_t cmd48;
    UINT8 respPreambles = 5u;

    PRINTF("\r\n============================================================\r\n");
    PRINTF(" HART discovery\r\n");
    PRINTF("============================================================\r\n");
    PRINTF("[HART] channel=%u modem=%u pollAddr=%u..%u\r\n",
           (unsigned int)g_activeChannel,
           (unsigned int)g_activeModem,
           (unsigned int)HART_POLL_ADDR_START,
           (unsigned int)HART_POLL_ADDR_END);

    if (!HartStack_SelfCheck())
    {
        PRINTF("[HART_STOP] FPGA self-check failed.\r\n");
        return HART_DISCOVERY_FAILED;
    }

    HartPrintLegacyCommandCoverage();

    for (UINT8 pa = HART_POLL_ADDR_START; pa <= HART_POLL_ADDR_END; pa++)
    {
        if (!HartStack_GetCleanCmd0(g_activeChannel,
                                    g_activeModem,
                                    pa,
                                    &cmd0))
        {
            PRINTF("[CMD0_FAIL] no valid response\r\n");
            continue;
        }

        if (!HartStack_ExtractLongAddressFromCmd0(&cmd0, g_runtimeLongAddr, &respPreambles))
        {
            PRINTF("[DISCOVERY_STOP] CMD0 responded but long-address extraction failed.\r\n");
            return HART_DISCOVERY_CMD0_OK;
        }

        g_runtimePollAddr = pa;
        g_haveLongAddr = true;

        if (!HartDb_UpdateFromCmd0(g_activeChannel,
                                   g_activeModem,
                                   pa,
                                   &cmd0,
                                   g_runtimeLongAddr,
                                   respPreambles))
        {
            PRINTF("[HARTDB_WARN] Could not update database from CMD0.\r\n");
        }

        HartDb_Print();

        /* CMD48 is legacy-supported, but this device has been returning a valid
         * response with non-zero status [0x02 0x82]. Keep it as a warning path.
         */
        if (HartRunReadCommand(HART_COMMAND_FORTYEIGHT, "CMD48_READ_ADDITIONAL_STATUS", &cmd48))
        {
            HartDb_UpdateCmd48Status(cmd48.status0, cmd48.status1);
            if ((cmd48.status0 != 0u) || (cmd48.status1 != 0u))
            {
                PRINTF("[CMD48_WARN] non-zero device status; link is valid\r\n");
            }
        }

        /* CMD59 was already proven to pass; keep it once per discovery. */
        HartRunLegacyWriteChecks(respPreambles);
#if !HART_ENABLE_LEGACY_WRITE_CHECKS
        {
            HartParsedResponse_t cmd59;
            UINT8 cmd59Data[1];
            cmd59Data[0] = respPreambles;
            if (cmd59Data[0] < HART_MIN_PREAMBLES)
            {
                cmd59Data[0] = HART_MIN_PREAMBLES;
            }

            if (HartRunWriteCommand(HART_COMMAND_FIFTYNINE, cmd59Data, 1u, "CMD59_SET_RESPONSE_PREAMBLES", &cmd59))
            {
                HartDb_UpdateCmd59Status(cmd59.status0, cmd59.status1);
                if ((cmd59.status0 == 0u) && (cmd59.status1 == 0u))
                {
                    PRINTF("[CMD59_PASS] Response preamble count command accepted.\r\n");
                }
            }
        }
#endif

        (void)HartReadDynamicValues();
        HartRunLegacyReadChecks();

        PRINTF("\r\n============================================================\r\n");
        PRINTF(" HART DISCOVERY COMPLETE\r\n");
        PRINTF("============================================================\r\n");
        HartDb_Print();
        return HART_DISCOVERY_COMPLETE;
    }

    PRINTF("[HART_FAIL] no valid CMD0 response\r\n");
    return HART_DISCOVERY_FAILED;
}

HARTDISCOVERYRESULT HartDiscoverOnRoute(UINT8 channel, UINT8 modem)
{
    HartSetActiveRoute(channel, modem);
    return HartDiscover();
}

UINT8 HartGetModemForChannel(UINT8 logicalChannel)
{
    if (logicalChannel < 1u)
    {
        logicalChannel = 1u;
    }

    if (logicalChannel > 16u)
    {
        logicalChannel = 16u;
    }

    /* FPGA/HART channel grouping:
     *   CH1..CH4   -> modem0
     *   CH5..CH8   -> modem1
     *   CH9..CH12  -> modem2
     *   CH13..CH16 -> modem3
     */
    return (UINT8)((logicalChannel - 1u) / 4u);
}

HARTDISCOVERYRESULT HartScanChannels(UINT8 logicalChannelStart, UINT8 logicalChannelEnd)
{
    UINT8 start = logicalChannelStart;
    UINT8 end = logicalChannelEnd;
    UINT8 tmp;

    if (start < 1u)
    {
        start = 1u;
    }

    if (end > 16u)
    {
        end = 16u;
    }

    if (start > end)
    {
        tmp = start;
        start = end;
        end = tmp;
    }

    PRINTF("\r\n============================================================\r\n");
    PRINTF(" HART channel scan\r\n");
    PRINTF("============================================================\r\n");
    PRINTF("[HART_SCAN] using legacy transaction path\r\n");
    PRINTF("[HART_SCAN] modem groups: CH1-4=M0 CH5-8=M1 CH9-12=M2 CH13-16=M3\r\n");
    PRINTF("[HART_SCAN] channels %u..%u\r\n",
           (unsigned int)start,
           (unsigned int)end);

    for (UINT8 ch = start; ch <= end; ch++)
    {
        UINT8 modem = HartGetModemForChannel(ch);
        HARTDISCOVERYRESULT result;

        PRINTF("\r\n[HART_SCAN_TRY] channel=%u modem=%u\r\n",
               (unsigned int)ch,
               (unsigned int)modem);

        result = HartDiscoverOnRoute(ch, modem);

        if (result == HART_DISCOVERY_COMPLETE)
        {
            PRINTF("[HART_SCAN_PASS] channel=%u modem=%u\r\n",
                   (unsigned int)ch,
                   (unsigned int)modem);
            PRINTF("");
            return result;
        }

        PRINTF("[HART_SCAN_FAIL] channel=%u modem=%u\r\n",
               (unsigned int)ch,
               (unsigned int)modem);
    }

    PRINTF("[HART_SCAN_DONE] no device found in channels %u..%u\r\n",
           (unsigned int)start,
           (unsigned int)end);
    return HART_DISCOVERY_FAILED;
}


void HartPrintDatabase(void)
{
    HartDb_Print();
}

void HartDiscoveryTask(void)
{
    (void)HartScanChannels((UINT8)1u, (UINT8)16u);
}

BOOL isHartCapable(VOID)
{
    return TRUE;
}

VOID CheckAndInitHart(VOID)
{
    HartInit();
}

VOID ResetHart(VOID)
{
    HartStack_Reset();
}

BOOL InitHartConnection(UINT8 a_ucChan)
{
    UINT8 modem = HartGetModemForChannel(a_ucChan);
    return (HartDiscoverOnRoute(a_ucChan, modem) != HART_DISCOVERY_FAILED) ? TRUE : FALSE;
}

VOID ProcessHartInterrupt(VOID)
{
    /* This RT1024 integration uses the proven polling transaction style. */
}

BOOL AbortHartConnection(UINT8 a_ucChan)
{
    (void)a_ucChan;
    ResetHart();
    return TRUE;
}
