/*******************************************************************************
*    File Name   : pmio_kernel.cpp
*    Description : Board entry for HART discovery.
*******************************************************************************/

#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "peripherals.h"
#include "fsl_debug_console.h"

#include "hal_fpga.h"
#include "hal_gpio.h"
#include "hart.h"
#include "hartstack.hpp"

#ifndef HART_RUN_DISCOVERY_ONCE
#define HART_RUN_DISCOVERY_ONCE          (1u)
#endif

#define HART_SCAN_CHANNEL_START          (1u)
#define HART_SCAN_CHANNEL_END            (16u)

int main(void)
{
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    hal_gpio_init();
    BOARD_InitBootPeripherals();
    BOARD_InitDebugConsole();

    PRINTF("\r\n\r\n============================================================\r\n");
    PRINTF(" RT1024 AIH HART discovery\r\n");
    PRINTF("============================================================\r\n");

    hal_fpga_init();
    HartStack_IdleWait(100000u);
    CheckAndInitHart();

#if HART_RUN_DISCOVERY_ONCE
    (void)HartScanChannels((UINT8)HART_SCAN_CHANNEL_START,
                           (UINT8)HART_SCAN_CHANNEL_END);

    PRINTF("\r\n[HART] discovery cycle complete\r\n");

    while (1)
    {
        HartStack_IdleWait(5000000u);
    }
#else
    while (1)
    {
        (void)HartScanChannels((UINT8)HART_SCAN_CHANNEL_START,
                               (UINT8)HART_SCAN_CHANNEL_END);

        PRINTF("\r\n[HART] discovery cycle complete\r\n");
        HartStack_IdleWait(5000000u);
    }
#endif
}
