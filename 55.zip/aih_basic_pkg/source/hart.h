/*******************************************************************************
*    File Name   : hart.h
*    Description : HART protocol declarations.
*******************************************************************************/

#ifndef __HART_H__
#define __HART_H__

#include <stdint.h>
#include <stdbool.h>

#include "datatype.h"


/*******************************************************************************
*                               CONSTANTS
*******************************************************************************/
#ifndef HART_BYTE_TIME
#define HART_BYTE_TIME                         ((UINT16)9167u)
#endif

#ifndef HART_PRIMARY_QUIET_TIME
#define HART_PRIMARY_QUIET_TIME                ((UINT8)33u)
#endif

#ifndef HART_LINK_GRANT_TIME
#define HART_LINK_GRANT_TIME                   ((UINT8)8u)
#endif

#ifndef HART_SLAVE_TIME_OUT
#define HART_SLAVE_TIME_OUT                    ((UINT8)28u)
#endif

#ifndef HART_PREAMBLE_BYTE
#define HART_PREAMBLE_BYTE                     ((UINT8)0xFFu)
#endif

#ifndef HART_MIN_PREAMBLES
#define HART_MIN_PREAMBLES                     ((UINT8)2u)
#endif

#ifndef HART_MAX_RETRIES
#define HART_MAX_RETRIES                       ((UINT8)3u)
#endif

#ifndef HART_MAX_BYTECOUNT
#define HART_MAX_BYTECOUNT                     ((UINT8)255u)
#endif

#ifndef HART_FRAME_TYPE_BACK
#define HART_FRAME_TYPE_BACK                   ((UINT8)0x01u)
#endif

#ifndef HART_FRAME_TYPE_STX
#define HART_FRAME_TYPE_STX                    ((UINT8)0x02u)
#endif

#ifndef HART_FRAME_TYPE_ACK
#define HART_FRAME_TYPE_ACK                    ((UINT8)0x06u)
#endif

#ifndef HART_FRAME_TYPE_MASK
#define HART_FRAME_TYPE_MASK                   ((UINT8)0x07u)
#endif

#ifndef HART_ADDR_TYPE_MASK
#define HART_ADDR_TYPE_MASK                    ((UINT8)0x80u)
#endif

#ifndef HART_POLLING_DELIMITER
#define HART_POLLING_DELIMITER                 ((UINT8)0x02u)
#endif

#ifndef HART_POLLING_ADDR_MASK
#define HART_POLLING_ADDR_MASK                 ((UINT8)0x3Fu)
#endif

#ifndef HART_POLADDR_LENGTH
#define HART_POLADDR_LENGTH                    ((UINT8)1u)
#endif

#ifndef HART_POLADDR_MAXVAL
#define HART_POLADDR_MAXVAL                    ((UINT8)15u)
#endif

#ifndef HART_UNIQUE_DELIMITER
#define HART_UNIQUE_DELIMITER                  ((UINT8)0x82u)
#endif

#ifndef HART_LONGADDR_LENGTH
#define HART_LONGADDR_LENGTH                   ((UINT8)5u)
#endif

#ifndef HART_MASTER_ADDR_MASK
#define HART_MASTER_ADDR_MASK                  ((UINT8)0x80u)
#endif

#ifndef HART_MANUFACTURE_ID_MASK
#define HART_MANUFACTURE_ID_MASK               ((UINT8)0x3Fu)
#endif

#ifndef HART_BURST_MODE_MASK
#define HART_BURST_MODE_MASK                   ((UINT8)0x40u)
#endif

#ifndef HART_GENERIC_MANUFACTURE_ID
#define HART_GENERIC_MANUFACTURE_ID            ((UINT8)250u)
#endif

#ifndef HART_EXPANSION_BYTE_MASK
#define HART_EXPANSION_BYTE_MASK               ((UINT8)0x60u)
#endif

#ifndef HART_EXPANSION_BYTE_SHIFTS
#define HART_EXPANSION_BYTE_SHIFTS             ((UINT8)0x05u)
#endif

#ifndef HART_PHYSICAL_LAYER_MASK
#define HART_PHYSICAL_LAYER_MASK               ((UINT8)0x18u)
#endif

#ifndef HART_COMMN_STATUS_BIT
#define HART_COMMN_STATUS_BIT                  ((UINT8)0x80u)
#endif

#ifndef HART_DEVSTS_DEV_MALFUNCTION
#define HART_DEVSTS_DEV_MALFUNCTION            ((UINT8)0x80u)
#endif

#ifndef HART_DEVSTS_CFG_CHANGED
#define HART_DEVSTS_CFG_CHANGED                ((UINT8)0x40u)
#endif

#ifndef HART_DEVSTS_COLD_START
#define HART_DEVSTS_COLD_START                 ((UINT8)0x20u)
#endif

#ifndef HART_DEVSTS_MORE_STATUS
#define HART_DEVSTS_MORE_STATUS                ((UINT8)0x10u)
#endif

#ifndef HART_DEVSTS_LOOP_FIXED
#define HART_DEVSTS_LOOP_FIXED                 ((UINT8)0x08u)
#endif

#ifndef HART_DEVSTS_LOOP_SATURATED
#define HART_DEVSTS_LOOP_SATURATED             ((UINT8)0x04u)
#endif

#ifndef HART_DEVSTS_XV_OUT_OF_LIMIT
#define HART_DEVSTS_XV_OUT_OF_LIMIT            ((UINT8)0x02u)
#endif

#ifndef HART_DEVSTS_PV_OUT_OF_LIMIT
#define HART_DEVSTS_PV_OUT_OF_LIMIT            ((UINT8)0x01u)
#endif

#ifndef HART_DATA_UNKNOWN
#define HART_DATA_UNKNOWN                      ((UINT8)255u)
#endif

#ifndef HART_DATA_NOT_AVAILABLE
#define HART_DATA_NOT_AVAILABLE                ((UINT8)0u)
#endif

#ifndef HART_DATA_AVAILABLE
#define HART_DATA_AVAILABLE                    ((UINT8)1u)
#endif

#ifndef HART_DATA_PENDING
#define HART_DATA_PENDING                      ((UINT8)2u)
#endif

#ifndef HART_CMD0_RESPONSE_SIZE
#define HART_CMD0_RESPONSE_SIZE                ((UINT8)22u)
#endif

#ifndef HART_CMD3_4VAR_RESPONSE_SIZE
#define HART_CMD3_4VAR_RESPONSE_SIZE           ((UINT8)24u)
#endif

#ifndef HART_CMD3_3VAR_RESPONSE_SIZE
#define HART_CMD3_3VAR_RESPONSE_SIZE           ((UINT8)19u)
#endif

#ifndef HART_CMD3_2VAR_RESPONSE_SIZE
#define HART_CMD3_2VAR_RESPONSE_SIZE           ((UINT8)14u)
#endif

#ifndef HART_CMD3_1VAR_RESPONSE_SIZE
#define HART_CMD3_1VAR_RESPONSE_SIZE           ((UINT8)9u)
#endif

#ifndef HART_CMD6_RESPONSE_SIZE
#define HART_CMD6_RESPONSE_SIZE                ((UINT8)2u)
#endif

#ifndef HART_CMD12_RESPONSE_SIZE
#define HART_CMD12_RESPONSE_SIZE               ((UINT8)24u)
#endif

#ifndef HART_CMD13_RESPONSE_SIZE
#define HART_CMD13_RESPONSE_SIZE               ((UINT8)21u)
#endif

#ifndef HART_CMD14_RESPONSE_SIZE
#define HART_CMD14_RESPONSE_SIZE               ((UINT8)16u)
#endif

#ifndef HART_CMD15_RESPONSE_SIZE
#define HART_CMD15_RESPONSE_SIZE               ((UINT8)18u)
#endif

#ifndef HART_CMD16_RESPONSE_SIZE
#define HART_CMD16_RESPONSE_SIZE               ((UINT8)3u)
#endif

#ifndef HART_CMD20_RESPONSE_SIZE
#define HART_CMD20_RESPONSE_SIZE               ((UINT8)32u)
#endif

#ifndef HART_CMD33_4VAR_RESPONSE_SIZE
#define HART_CMD33_4VAR_RESPONSE_SIZE          ((UINT8)24u)
#endif

#ifndef HART_CMD38_RESPONSE_SIZE
#define HART_CMD38_RESPONSE_SIZE               ((UINT8)2u)
#endif

#ifndef HART_CMD48_RESPONSE_SIZE
#define HART_CMD48_RESPONSE_SIZE               ((UINT8)25u)
#endif

#ifndef HART_CMD50_RESPONSE_SIZE
#define HART_CMD50_RESPONSE_SIZE               ((UINT8)4u)
#endif

#ifndef HART_CMD59_RESPONSE_SIZE
#define HART_CMD59_RESPONSE_SIZE               ((UINT8)1u)
#endif

#ifndef HART_CMD109_RESPONSE_SIZE
#define HART_CMD109_RESPONSE_SIZE              ((UINT8)1u)
#endif

#ifndef HART_MIN_RESPONSE_BYTECOUNT
#define HART_MIN_RESPONSE_BYTECOUNT            ((UINT8)2u)
#endif

#ifndef HART_RESPCODE_SUCCESS
#define HART_RESPCODE_SUCCESS                  ((UINT8)0u)
#endif

#ifndef HART_RESPCODE_DEVICE_BUSY
#define HART_RESPCODE_DEVICE_BUSY              ((UINT8)32u)
#endif

#ifndef HART_RESPCODE_CMD_NOT_IMPLEMENTED
#define HART_RESPCODE_CMD_NOT_IMPLEMENTED      ((UINT8)64u)
#endif

#ifndef HART_DEVICEID_SIZE
#define HART_DEVICEID_SIZE                     ((UINT8)3u)
#endif

#ifndef HART_PACKED_TAG_SIZE
#define HART_PACKED_TAG_SIZE                   ((UINT8)6u)
#endif

#ifndef HART_UNPACKED_TAG_SIZE
#define HART_UNPACKED_TAG_SIZE                 ((UINT8)8u)
#endif

#ifndef HART_DESCRIPTOR_SIZE
#define HART_DESCRIPTOR_SIZE                   ((UINT8)12u)
#endif

#ifndef HART_TRSERIALNUMBER_SIZE
#define HART_TRSERIALNUMBER_SIZE               ((UINT8)3u)
#endif

#ifndef HART_FINALASSEMBLYNO_SIZE
#define HART_FINALASSEMBLYNO_SIZE              ((UINT8)3u)
#endif

#ifndef HART_HWREVLEVEL_SIZE
#define HART_HWREVLEVEL_SIZE                   ((UINT8)5u)
#endif

#ifndef HART_SINGALINGCODE_SIZE
#define HART_SINGALINGCODE_SIZE                ((UINT8)3u)
#endif

#ifndef HARTVERSION_UNDEFINED
#define HARTVERSION_UNDEFINED                  0
#endif

#ifndef HARTVERSION_5X
#define HARTVERSION_5X                         5
#endif

#ifndef HARTVERSION_6X
#define HARTVERSION_6X                         6
#endif

#ifndef HARTVERSION_7X
#define HARTVERSION_7X                         7
#endif

#ifndef HARTVERSION_MISMATCH
#define HARTVERSION_MISMATCH                   0xFF
#endif

#ifndef HARTVERSION_LASTESTSUPPORTED
#define HARTVERSION_LASTESTSUPPORTED           HARTVERSION_7X
#endif

typedef UINT8 HARTCOMMAND;

typedef union UniqueAddrTag
{
    UINT8 ucBytes[HART_LONGADDR_LENGTH];
    struct
    {
        UINT8 ucExpDeviceType1;
        UINT8 ucExpDeviceType2;
        UINT8 ucDeviceId[HART_DEVICEID_SIZE];
    } str;
} HARTUNIQUEADDR;

typedef struct HartDateTag
{
    UINT8 ucDay;
    UINT8 ucMonth;
    UINT8 ucYear;
} HARTDATE;

typedef union Cmd0ResponseTag
{
    UINT8 ucBytes[HART_CMD0_RESPONSE_SIZE];
    struct
    {
        UINT8 ucTwoFiveFour;
        UINT8 ucusExpDeviceType[sizeof(UINT16)];
        UINT8 ucReqdPreambleBytes;
        UINT8 ucHARTMajorRevision;
        UINT8 ucDeviceRevisionLevel;
        UINT8 ucSoftwareRevLevel;
        UINT8 ucHardwareRevLevel : HART_HWREVLEVEL_SIZE;
        UINT8 ucSignalingCode    : HART_SINGALINGCODE_SIZE;
        UINT8 ucFlags;
        UINT8 ucDeviceId[HART_DEVICEID_SIZE];
        UINT8 ucResponsePreambleBytes;
        UINT8 ucMaxDevVariables;
        UINT8 ucusConfigChgCnt[sizeof(UINT16)];
        UINT8 ucExtendedStatus;
        UINT8 ucusManufactureId[sizeof(UINT16)];
        UINT8 ucusPrivateLblDisCode[sizeof(UINT16)];
        UINT8 ucDevProfile;
    } str;
} HARTCMD0RESPONSE;

typedef union Cmd3ResponseTag
{
    UINT8 ucBytes[HART_CMD3_4VAR_RESPONSE_SIZE];
    struct
    {
        UINT8 ucfLoopCurrent[sizeof(FLOAT32)];
        UINT8 ucPvUnitCode;
        UINT8 ucfPvVal[sizeof(FLOAT32)];
        UINT8 ucSvUnitCode;
        UINT8 ucfSvVal[sizeof(FLOAT32)];
        UINT8 ucTvUnitCode;
        UINT8 ucfTvVal[sizeof(FLOAT32)];
        UINT8 ucQvUnitCode;
        UINT8 ucfQvVal[sizeof(FLOAT32)];
    } str;
} HARTCMD3RESPONSE;

typedef union Cmd12ResponseTag
{
    UINT8 ucBytes[HART_CMD12_RESPONSE_SIZE];
    struct
    {
        UINT8 ucMessage[HART_CMD12_RESPONSE_SIZE];
    } str;
} HARTCMD12RESPONSE;

typedef union Cmd13ResponseTag
{
    UINT8 ucBytes[HART_CMD13_RESPONSE_SIZE];
    struct
    {
        UINT8 ucTag[HART_PACKED_TAG_SIZE];
        UINT8 ucDescriptor[HART_DESCRIPTOR_SIZE];
        HARTDATE HartDate;
    } str;
} HARTCMD13RESPONSE;

typedef union Cmd14ResponseTag
{
    UINT8 ucBytes[HART_CMD14_RESPONSE_SIZE];
    struct
    {
        UINT8 ucTrSerialNumber[HART_TRSERIALNUMBER_SIZE];
        UINT8 ucTrUnitsCode;
        UINT8 ucfUpperTrLimit[sizeof(FLOAT32)];
        UINT8 ucfLowerTrLimit[sizeof(FLOAT32)];
        UINT8 ucfMinimumSpan[sizeof(FLOAT32)];
    } str;
} HARTCMD14RESPONSE;

typedef union Cmd15ResponseTag
{
    UINT8 ucBytes[HART_CMD15_RESPONSE_SIZE];
    struct
    {
        UINT8 ucPvAlarmCode;
        UINT8 ucPvTrFunCode;
        UINT8 ucPvRngUnitCode;
        UINT8 ucfPvURngVal[sizeof(FLOAT32)];
        UINT8 ucfPvLRngVal[sizeof(FLOAT32)];
        UINT8 ucfPvDampVal[sizeof(FLOAT32)];
        UINT8 ucWrProtCode;
        UINT8 ucPvtDistrLabel;
        UINT8 ucPvFlags;
    } str;
} HARTCMD15RESPONSE;

typedef union Cmd16ResponseTag
{
    UINT8 ucBytes[HART_CMD16_RESPONSE_SIZE];
    struct
    {
        UINT8 ucFinAssemblyNo[HART_FINALASSEMBLYNO_SIZE];
    } str;
} HARTCMD16RESPONSE;

typedef struct Cmd20ResponseTag
{
    UINT8 ucBytes[HART_CMD20_RESPONSE_SIZE];
} HARTLONGTAG_RESPONSE;

typedef union Cmd48ResponseTag
{
    UINT8 ucBytes[HART_CMD48_RESPONSE_SIZE];
    struct
    {
        UINT8 ucCmd48Response[HART_CMD48_RESPONSE_SIZE];
    } str;
} HARTCMD48RESPONSE;

typedef union Cmd50ResponseTag
{
    UINT8 ucBytes[HART_CMD50_RESPONSE_SIZE];
    struct
    {
        UINT8 ucDynVar0Code;
        UINT8 ucDynVar1Code;
        UINT8 ucDynVar2Code;
        UINT8 ucDynVar3Code;
    } str;
} HARTCMD50RESPONSE;

typedef union Cmd59ResponseTag
{
    UINT8 ucBytes[HART_CMD59_RESPONSE_SIZE];
    struct
    {
        UINT8 ucNoOfPreambleBytes;
    } str;
} HARTCMD59RESPONSE;

typedef union Cmd109ResponseTag
{
    UINT8 ucBytes[HART_CMD109_RESPONSE_SIZE];
    struct
    {
        UINT8 ucBurstModeCode;
    } str;
} HARTCMD109RESPONSE;


#include "hartdb.hpp"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    HART_DISCOVERY_FAILED = 0,
    HART_DISCOVERY_CMD0_OK = 1,
    HART_DISCOVERY_COMPLETE = 2
} HARTDISCOVERYRESULT;

VOID HartInit(VOID);
HARTDISCOVERYRESULT HartDiscover(VOID);
HARTDISCOVERYRESULT HartDiscoverOnRoute(UINT8 channel, UINT8 modem);
HARTDISCOVERYRESULT HartScanChannels(UINT8 channelStart, UINT8 channelEnd);
UINT8 HartGetModemForChannel(UINT8 channel);
VOID HartDiscoveryTask(VOID);
VOID HartPrintDatabase(VOID);
bool HartReadDynamicValues(VOID);
VOID HartPrintLegacyCommandCoverage(VOID);

BOOL isHartCapable(VOID);
VOID CheckAndInitHart(VOID);
VOID ResetHart(VOID);
BOOL InitHartConnection(UINT8 a_ucChan);
BOOL AbortHartConnection(UINT8 a_ucChan);
VOID ProcessHartInterrupt(VOID);

#ifdef __cplusplus
}
#endif

#endif /* __HART_H__ */
