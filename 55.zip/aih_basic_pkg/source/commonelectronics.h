/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : commonelectronics.h                                         *
*    Description : RT1024 / QEMU hardware abstraction.                         *
*                  Replaces the H8S register definitions with HAL calls.       *
*                  This file is included by legacy code that expects it.       *
*******************************************************************************/
#ifndef __COMMONELECTRONICS_H__
#define __COMMONELECTRONICS_H__

#include "hal.h"

#define NOP  __asm volatile("nop")

/*******************************************************************************
*                      MAXSLOTS (AIH ONLY)                                     *
*******************************************************************************/
const UINT8 MAXSLOTS = 16;

/*******************************************************************************
*                      IOL UART CONSTANTS                                      *
*******************************************************************************/
const UINT32 IOL_BAUDRATE = 375000;   // 375 kbps IOLink

/* IOL RS-485 transmitter enable (active low on H8S/LPC, same convention)      */
const UINT8 IOLDRV_ON  = 0;
const UINT8 IOLDRV_OFF = 1;

/*******************************************************************************
*                      INTERRUPT PRIORITY LEVELS                               *
*  H8S: 0=lowest .. 7=highest                                                 *
*  ARM:  0=highest .. 255=lowest (BASEPRI)                                     *
*  We keep the H8S logical names and map through HAL.                          *
*******************************************************************************/
const UINT32 LVLPRI_TICK    = 5;

/* GHO interrupt register control                                              */
const UINT8 GHO_ENABLED  = 1;
const UINT8 GHO_DISABLED = 0;
const UINT8 GHO_NOTINGAP = 0;

/* 9-bit alert/address mode                                                    */
const UINT8 IOL_ALERT_XMIT_ADDR = 1;   /* TX 9th bit = 1: address frame       */
const UINT8 IOL_ALERT_XMIT_DATA = 0;   /* TX 9th bit = 0: data frame          */
const UINT8 IOL_ALERT_RCV_ADDR  = 1;   /* RX 9th bit = 1: address frame       */

/* FPGA readback register index for IOTA/jabber status                         */
const UINT8 RDBK_IOTA         = 0x05;
const UINT8 JABLOCK_ASSERTED  = 0;     /* active low anti-jabber               */

/* H8S-origin module enable (kept for code compatibility)                      */
const UINT8 MODULE_ENABLED = 0;

/*******************************************************************************
*                      IOL UART ABSTRACTION                                    *
*  Inline wrappers matching armsrc convention (IOL_WriteByte etc.).            *
*  armsrc targeted LPC_UART1 registers; RT1024 routes through HAL LPUART.     *
*******************************************************************************/
#ifdef __cplusplus

#if 1 // RS - 9bit read write
static inline void   IOL_WriteByte(UINT8 x, UINT8 y)  	{ hal_uart_write_byte9(HAL_UART_IOL, x, y); }
static inline UINT16 IOL_ReadByte(void)      		 	{ return hal_uart_read_byte9(HAL_UART_IOL); }
#else
static inline void   IOL_WriteByte(UINT8 x)    			{ hal_uart_write_byte(HAL_UART_IOL, x); }
static inline UINT8  IOL_ReadByte(void)        			{ return hal_uart_read_byte(HAL_UART_IOL); }
#endif
static inline BOOL  IOL_RxDatReady(void)      			{ return hal_uart_rx_ready(HAL_UART_IOL); }
static inline BOOL  IOL_TxEnd(void)           			{ return hal_uart_tx_complete(HAL_UART_IOL); }
static inline BOOL  IOL_TxBufEmpty(void)      			{ return hal_uart_tx_ready(HAL_UART_IOL);  }
static inline void  IOL_RxInterrupt(BOOL en)  			{ hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA, en); }
static inline void  IOL_TxInterrupt(BOOL en)  			{ hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_EMPTY, en); }
static inline void  IOL_TxDoneInterrupt(BOOL en)  		{ hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE, en); }
static inline void  IOL_TxEnable(void)        			{ hal_uart_tx_enable(HAL_UART_IOL, TRUE); }
static inline void  IOL_TxDisable(void)       			{ hal_uart_tx_enable(HAL_UART_IOL, FALSE); }
static inline void  IOL_RxEnable(void)        			{ hal_uart_rx_enable(HAL_UART_IOL, TRUE); }
static inline void  IOL_RxDisable(void)       			{ hal_uart_rx_enable(HAL_UART_IOL, FALSE); }
static inline void  IOL_FifoEnable(void)      			{ hal_uart_clear_errors(HAL_UART_IOL); }
static inline void  IOL_FifoDisable(void)     			{ /* LPUART FIFO is auto-managed */ }
static inline void  IOL_Disable(void)         			{ hal_uart_tx_enable(HAL_UART_IOL, FALSE);
                                                		  hal_uart_rx_enable(HAL_UART_IOL, FALSE); }

static inline void  IOL_DisAllInt(void) {
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA,  FALSE);
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_EMPTY, FALSE);
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE,  FALSE);
    hal_uart_irq_enable(HAL_UART_IOL, HAL_UART_IRQ_RX_ERROR, FALSE);
}

/* 9-bit alert / address-mark framing
   H8S:  MP bit in SSR; armsrc: LPC stick-parity trick
   RT1024: LPUART 9-bit mode via CTRL.M / DATA[T8/R8] — wired in hal_uart */
static inline void IOL_TxAlert(UINT8 mode)    { hal_uart_set_tx_9bit(HAL_UART_IOL, mode); }
static inline BOOL IOL_RxAlert(void)          { return (BOOL)hal_uart_get_rx_9bit(HAL_UART_IOL); }

/*******************************************************************************
*                      IOL GPIO ABSTRACTION                                    *
*  Matches armsrc SetTXREQ_n / SetCLR_GHL_n / GHO_INT_Clr convention.         *
*******************************************************************************/
static inline void  SetJABRES_n(UINT8 val)    { hal_gpio_write(HAL_PIN_JABRES_n,  val); }
static inline void  SetRCVSELA_n(UINT8 val)   { hal_gpio_write(HAL_PIN_RCVSELA_n,  val); }
static inline void  SetTXREQ_n(UINT8 val)     { hal_gpio_write(HAL_PIN_TXREQ_n,  val); }
static inline UINT8 GetTXREQ_n(void)          { return hal_gpio_read(HAL_PIN_TXREQ_n);  }
static inline void  SetCLR_GHL_n(UINT8 val)   { hal_gpio_write(HAL_PIN_CLRGHL_n, val); }
static inline void  GHO_INT_Clr(void) {
#if !defined(UNIT_TEST_BUILD) && !defined(QEMU_BUILD)
    /* GHOIRQ_n is on GPIO3_IO17. Clear pending for GPIO3 combined 16-31 IRQ. */
    NVIC_ClearPendingIRQ(GPIO3_Combined_16_31_IRQn);
#endif
}
static inline void  EnableGHOInt(BOOL en) {
#if !defined(UNIT_TEST_BUILD) && !defined(QEMU_BUILD)
    if (en) {
        /* Clear any stale latched edge on GPIO3_IO17 before enabling path. */
        GPIO3->ISR = (1u << 17);
        NVIC_ClearPendingIRQ(GPIO3_Combined_16_31_IRQn);
        /* Enable falling-edge interrupt on GPIO3 pin 17 (GHOIRQ_n active low) */
        GPIO3->IMR |= (1u << 17);
        NVIC_SetPriority(GPIO3_Combined_16_31_IRQn, HAL_IRQ_PRIO_GHO);
        NVIC_EnableIRQ(GPIO3_Combined_16_31_IRQn);
    } else {
        GPIO3->IMR &= ~(1u << 17);
    }
#else
    (void)en;
#endif
}

/* GHOXXX signal — read from GPIO pin on RT1024 (was P_P6.PORT.BIT.B6 on H8S) */
static inline UINT8 GetGHOXXX(void)           { return hal_gpio_read(HAL_PIN_GHOIRQ_n); }
#define GHOXXX  GetGHOXXX()

/* SWBUREQ_n — read/write backup request GPIO                                  */
#define SWBUREQ_n_READ  hal_gpio_read(HAL_PIN_BUPREQ_OUT)
#define SWBUREQ_n_WRITE(v) hal_gpio_write(HAL_PIN_BUPREQ_OUT, (v))

/*******************************************************************************
*                      IOL SILENCE TIMER ABSTRACTION                           *
*  armsrc used LPC Timer1; RT1024 uses HAL_TIMER_IOL_SIL (GPT or PIT).        *
*  Timer count units: microseconds (armsrc used raw LPC timer counts).         *
*******************************************************************************/
static inline void   SilenceTimerStop(void)            { hal_timer_stop(HAL_TIMER_IOL_SIL);  }
static inline void   SilenceTimerStart(void)           { hal_timer_start(HAL_TIMER_IOL_SIL); }
static inline void   SilenceTimerReset(void)           { /* reset handled by stop+configure */ }
static inline void   SilenceTimerSetCount(UINT32 us)   { hal_timer_configure(HAL_TIMER_IOL_SIL, us, NULL); }
static inline void   SilenceTimerIntClr(void)          { /* cleared by HAL timer ISR entry */ }
static inline UINT32 GetGapTimerCnt(void)              { return hal_timer_get_count(HAL_TIMER_IOL_SIL); }

/* Character timeout counter — microsecond busy-wait via hal_delay_us          */
/* armsrc used a dedicated counter; RT1024 uses simple delay                    */
static inline void StartCounter(UINT32 us)             { (void)us; /* see IOL_CHAR_TIMEOUT_US */ }
static inline void StopCounter(void)                   { /* no-op */ }
static inline BOOL IsCounterArrived(void)              { return FALSE; /* see polling loop */ }

/* CPLD / FPGA readback register addressing                                     */
/* CPLD readback bank select → FPGA IOLIOTASR on RT1024                        */
static inline void  SetCPLDAddr(UINT8 addr)   { (void)addr; /* RT1024: readback via direct GPIO/FPGA SPI, no bank select needed */ }
static inline UINT8 GetCPLDAddr(void)          { return RDBK_IOTA; /* always IOTA bank on RT1024 */ }
static inline BOOL  GetJABLOCK_n(void) {
//    return (hal_fpga_read8(FPGA_IOLIOTASR) & FPGA_IOTA_JABLOCK_n) ? TRUE : FALSE;
}

#endif /* __cplusplus */

/*******************************************************************************
*                      STACK MONITORING CONSTANTS                              *
*  STACK_TOP: lowest address of the stack (grows down on Cortex-M).            *
*  Derived from linker symbol _vStackBase for RT1024 so it stays in sync       *
*  with the linker script stack size and placement.                            *
*  STACKTESTPATTERN: sentinel value written at STACK_TOP by startup code.      *
*  STACK_SFLIMIT: softfail threshold for remaining stack headroom (bytes).     *
*******************************************************************************/
#if defined(QEMU_BUILD)
  #define STACK_TOP           0x20400000u   /* MPS2-AN500 top of RAM - stack */
  #define STACK_SFLIMIT       0x100u        /* 256 bytes guard area */
#elif defined(UNIT_TEST_BUILD)
  #define STACK_TOP           0x20000000u   /* dummy for tests */
  #define STACK_SFLIMIT       0x100u
#else /* RT1024 */
  extern unsigned int _vStackBase;          /* linker-provided stack bottom */
  #define STACK_TOP           ((UINT32)&_vStackBase)
  #define STACK_SFLIMIT       0x100u
#endif
const UINT32 STACKTESTPATTERN = 0xFF5AA5FFu;

/*******************************************************************************
*                      MEMORY MAP CONSTANTS                                    *
*  Kept same as H8S for checkpoint/version block compatibility.                *
*******************************************************************************/
#define MODULEINFO_START_ADDRESS    0x00007000u
#define HW_PROD_CODE_OFFSET         0x02u
#define BOOT_VERSION_BLOCK          0x00000170u
#define APP_VERSION_BLOCK           0x00008170u

/*******************************************************************************
*                      IDLE WAIT UTILITY                                       *
*******************************************************************************/
static inline void IdleWait(UINT32 us) { hal_delay_us(us); }

#endif /* __COMMONELECTRONICS_H__ */
