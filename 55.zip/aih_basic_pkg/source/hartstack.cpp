/*******************************************************************************
*    File Name   : hartstack.cpp
*    Description : HART stack transaction/state machine.
*
*    Set HART_DEBUG_LEVEL to 2 for detailed UART/RX traces.
*******************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "fsl_debug_console.h"

#include "hartstack.hpp"
#include "hartdb.hpp"
#include "hal_fpga.h"

/*******************************************************************************
* Logging control
*******************************************************************************/
#ifndef HART_DEBUG_LEVEL
#define HART_DEBUG_LEVEL                 (1u)
#endif

#define HART_LOG_ERROR                   (0u)
#define HART_LOG_INFO                    (1u)
#define HART_LOG_TRACE                   (2u)

#define HART_LOG(level, ...) \
    do \
    { \
        if ((UINT32)HART_DEBUG_LEVEL >= (UINT32)(level)) \
        { \
            PRINTF(__VA_ARGS__); \
        } \
    } while (0)

/*******************************************************************************
* User settings
*******************************************************************************/
#define HART_DEFAULT_CHANNEL              (1u)
#define HART_DEFAULT_MODEM                (0u)
#define HART_POLL_ADDR_START           (0u)
#define HART_POLL_ADDR_END             (0u)

/* Discovery behavior:
 * The HART stack keeps the proven legacy transaction style and only
 * adds parsing + CMD48/CMD59 after a valid CMD0.
 */
#define HART_ENABLE_CMD48_CMD59         (1u)
#define HART_PRIMARY_GPWR_BIT3          (1u)
#define HART_CMD0_RETRY_COUNT           (3u)

/* Try GPWR HART power bit from hal_fpga.h enable in addition to no-GPWR case. */
#define HART_TRY_GPWR_BIT3             (1u)

/* Legacy heartbeat: one HART character time approximately 9.187 ms.
 * This is a busy-loop approximation; exact value is not critical for
 * diagnostics, but state transitions now happen like legacy modem heartbeat.
 */
#define HART_MODEM_HEARTBEAT_LOOPS     (920000u)

/* Number of modem-heartbeat ticks allowed for each state. */
#define HART_SYNCWAIT_TICKS            (8u)
#define HART_RCVWAIT_TICKS             (80u)
#define HART_RCVING_IDLE_TICKS         (35u)

/* Reset and setup timing */
#define HART_RESET_HOLD_LOOPS          (250000u)
#define HART_RESET_SETTLE_LOOPS        (600000u)
#define HART_MUX_SETTLE_LOOPS          (200000u)
#define HART_RTS_PRE_TX_TICKS          (2u)
#define HART_TX_TO_RX_GUARD_TICKS      (2u)

#define HART_INITIAL_MAR           ((UINT16)HART_DEFAULT_MAR_CH1_M0)
#define HART_INITIAL_MER           ((UINT8)HART_DEFAULT_MER_NONE)

/*******************************************************************************
* Register map location
*******************************************************************************/
/*
 * The HART stack keeps all FPGA, UART, BRG, HART mux, GPWR and HART protocol register
 * values in source/hal/hal_fpga.h.
 *
 * pmio_kernel.cpp now contains only the bring-up/state-machine logic.
 */

/*******************************************************************************
* Legacy modem object state
*******************************************************************************/
typedef enum
{
    HART_MODEM_IDLE = 0,
    HART_MODEM_SYNCWAIT,
    HART_MODEM_XMITTING,
    HART_MODEM_RCVWAIT,
    HART_MODEM_RCVING,
    HART_MODEM_DONE,
    HART_MODEM_TIMEOUT,
    HART_MODEM_BAD
} HartModemState_t;

typedef struct
{
    UINT8 modem;
    UINT8 channel;
    UINT8 pollAddr;

    UINT8 txFrame[32];
    UINT32 txLen;
    UINT32 txIndex;

    UINT8 rxBuf[128];          /* cleaned bytes used by parser */
    UINT32 rxCount;
    UINT8 rxRawBuf[160];       /* raw bytes seen before status-echo filtering */
    UINT32 rxRawCount;
    UINT32 rxDroppedStatusEcho;
    UINT32 rxExpectedLen;
    UINT32 preambleCount;

    HartModemState_t state;
    UINT32 tickInState;
    UINT32 totalTicks;

    UINT32 msrChanges;
    UINT32 irqChanges;
    UINT32 iirChanges;
    UINT32 uartErrors;
    UINT32 dcdHighTicks;
    UINT32 riHighTicks;
    UINT32 dsrHighTicks;
    UINT32 ctsHighTicks;

    UINT8 lastMsr;
    UINT8 lastIir;
    UINT8 lastIrq;

    bool gpwrEnable;
    bool sawDcd;
    bool completed;
} HartModemObject_t;

/*******************************************************************************
* HART request/response helpers
*******************************************************************************/
/* HART constants are centralized in hal_fpga.h. */

/* HartParsedResponse_t is declared in hartstack.hpp. */

typedef struct
{
    bool useLongAddress;
    UINT8 command;
    UINT8 pollAddr;
    UINT8 longAddr[5];
    UINT8 data[16];
    UINT8 dataLen;
    const char *label;
} HartRequest_t;

static HartRequest_t g_HartRequest;


/*******************************************************************************
* Globals matching old names
*******************************************************************************/
static UINT16 m_usHartMuxAddr = HART_INITIAL_MAR;
static UINT8  m_ucHartMuxEnbl = HART_INITIAL_MER;
static UINT8  m_ucConnectedChannel = HART_DEFAULT_CHANNEL;
static UINT8  m_ucModemNumber = HART_DEFAULT_MODEM;
static UINT8  m_ucRemPreambles = 0u;

static const UINT8 g_uartBase[UART_COUNT] =
{
    UART0_BASE,
    UART1_BASE,
    UART2_BASE,
    UART3_BASE
};

static const UINT8 g_uartReset[UART_COUNT] =
{
    UART0_RESET,
    UART1_RESET,
    UART2_RESET,
    UART3_RESET
};

/*******************************************************************************
* Delay
*******************************************************************************/
static void IdleWait(volatile UINT32 loops)
{
    while (loops-- > 0u)
    {
        __asm volatile ("nop");
    }
}

static void HartCharacterDelayTicks(UINT32 ticks)
{
    for (UINT32 i = 0u; i < ticks; i++)
    {
        IdleWait(HART_MODEM_HEARTBEAT_LOOPS);
    }
}

/*******************************************************************************
* FPGA helpers
*******************************************************************************/
static UINT16 Read16(UINT8 addr)
{
    return hal_fpga_read(addr);
}

static UINT8 Read8(UINT8 addr)
{
    return (UINT8)((Read16(addr) >> 8) & 0xFFu);
}

static UINT8 ReadLsb(UINT8 addr)
{
    return (UINT8)(Read16(addr) & 0xFFu);
}

static void Write16(UINT8 addr, UINT16 value)
{
    hal_fpga_write(addr, value);
}

static void Write8(UINT8 addr, UINT8 value)
{
    hal_fpga_write(addr, (UINT16)((UINT16)value << 8));
}

static UINT8 UartReg(UINT8 modem, UINT8 reg)
{
    return (UINT8)(g_uartBase[modem] + reg);
}

/* UART read and write address helpers.
 * FPGA UART read addresses are 0x80/0x90/0xA0/0xB0 + offset.
 * FPGA UART write addresses are 0x00/0x10/0x20/0x30 + offset.
 */
static UINT8 UartReadRegAddr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_READ_BASE(modem) + reg);
}

static UINT8 UartWriteRegAddr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_WRITE_BASE(modem) + reg);
}

static UINT8 UartRead8(UINT8 modem, UINT8 reg)
{
    return Read8(UartReadRegAddr(modem, reg));
}

static void UartWrite8(UINT8 modem, UINT8 reg, UINT8 value)
{
    Write8(UartWriteRegAddr(modem, reg), value);
}

static void UartForceNormalLineMode(UINT8 modem)
{
    UartWrite8(modem, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    IdleWait(1200u);
}

static UINT16 StableRead16(UINT8 addr, const char *name)
{
    UINT16 r[5];
    UINT16 best = 0u;
    UINT8 bestCount = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        r[i] = Read16(addr);
        IdleWait(2000u);
    }

    for (UINT8 i = 0u; i < 5u; i++)
    {
        UINT8 count = 0u;

        for (UINT8 j = 0u; j < 5u; j++)
        {
            if (r[i] == r[j])
            {
                count++;
            }
        }

        if (count > bestCount)
        {
            bestCount = count;
            best = r[i];
        }
    }

    HART_LOG(HART_LOG_TRACE, "[STABLE_READ] %s addr=0x%02X reads=[0x%04X 0x%04X 0x%04X 0x%04X 0x%04X] use=0x%04X\r\n",
           name,
           (unsigned int)addr,
           (unsigned int)r[0],
           (unsigned int)r[1],
           (unsigned int)r[2],
           (unsigned int)r[3],
           (unsigned int)r[4],
           (unsigned int)best);

    return best;
}

/*******************************************************************************
* Print helpers
*******************************************************************************/
static const char *StateName(HartModemState_t s)
{
    switch (s)
    {
        case HART_MODEM_IDLE:     return "IDLE";
        case HART_MODEM_SYNCWAIT: return "SYNCWAIT";
        case HART_MODEM_XMITTING: return "XMITTING";
        case HART_MODEM_RCVWAIT:  return "RCVWAIT";
        case HART_MODEM_RCVING:   return "RCVING";
        case HART_MODEM_DONE:     return "DONE";
        case HART_MODEM_TIMEOUT:  return "TIMEOUT";
        case HART_MODEM_BAD:      return "BAD";
        default:                  return "UNKNOWN";
    }
}

static void PrintMsrBits(UINT8 msr)
{
    HART_LOG(HART_LOG_TRACE, "MSR=0x%02X DCD=%u RI=%u DSR=%u CTS=%u DDCD=%u TERI=%u DDSR=%u DCTS=%u",
           (unsigned int)msr,
           (unsigned int)((msr & UART_MSR_DCD) ? 1u : 0u),
           (unsigned int)((msr & UART_MSR_RI) ? 1u : 0u),
           (unsigned int)((msr & UART_MSR_DSR) ? 1u : 0u),
           (unsigned int)((msr & UART_MSR_CTS) ? 1u : 0u),
           (unsigned int)((msr & UART_MSR_DDCD) ? 1u : 0u),
           (unsigned int)((msr & UART_MSR_TERI) ? 1u : 0u),
           (unsigned int)((msr & UART_MSR_DDSR) ? 1u : 0u),
           (unsigned int)((msr & UART_MSR_DCTS) ? 1u : 0u));
}

static void DumpCommon(const char *tag)
{
    HART_LOG(HART_LOG_TRACE, "[COMMON][%s] IRQ=0x%04X VER=0x%04X REV=0x%04X MOD=0x%04X SW=0x%04X IOL=0x%04X MISC=0x%04X CPLD=0x%04X MAR=0x%04X MER=0x%04X GPWR=0x%04X WIG=0x%04X BRG_DLL40=0x%04X BRG_DLM41=0x%04X\r\n",
           tag,
           (unsigned int)Read16(FPGA_IRQ_STATUS),
           (unsigned int)Read16(FPGA_VERSION),
           (unsigned int)Read16(FPGA_REVISION),
           (unsigned int)Read16(FPGA_MODNUM),
           (unsigned int)Read16(FPGA_SW_STATUS),
           (unsigned int)Read16(FPGA_IOL_STATUS),
           (unsigned int)Read16(FPGA_MISC),
           (unsigned int)Read16(FPGA_CPLD_REV),
           (unsigned int)Read16(FPGA_MAR),
           (unsigned int)Read16(FPGA_MER),
           (unsigned int)Read16(FPGA_GPWR),
           (unsigned int)Read16(FPGA_WIGGLE),
           (unsigned int)Read16(FPGA_BRG_DLL),
           (unsigned int)Read16(FPGA_BRG_DLM));
}

static void DumpUart(UINT8 modem, const char *tag)
{
    UINT8 ier = UartRead8(modem, UART_IER);
    UINT8 iir = UartRead8(modem, UART_IIR_FCR);
    UINT8 lcr = UartRead8(modem, UART_LCR);
    UINT8 mcr = UartRead8(modem, UART_MCR);
    UINT8 lsr = UartRead8(modem, UART_LSR);
    UINT8 msr = UartRead8(modem, UART_MSR);
    UINT8 scr = UartRead8(modem, UART_SCR);

    HART_LOG(HART_LOG_TRACE, "[UART%u][%s] IER=0x%02X IIR=0x%02X LCR=0x%02X MCR=0x%02X SCR=0x%02X LSR=0x%02X DR=%u ERR=%u THRE=%u TEMT=%u ",
           (unsigned int)modem,
           tag,
           (unsigned int)ier,
           (unsigned int)iir,
           (unsigned int)lcr,
           (unsigned int)mcr,
           (unsigned int)scr,
           (unsigned int)lsr,
           (unsigned int)((lsr & UART_LSR_DR) ? 1u : 0u),
           (unsigned int)((lsr & (UART_LSR_OE | UART_LSR_PE | UART_LSR_FE | UART_LSR_BI)) ? 1u : 0u),
           (unsigned int)((lsr & UART_LSR_THRE) ? 1u : 0u),
           (unsigned int)((lsr & UART_LSR_TEMT) ? 1u : 0u));
    PrintMsrBits(msr);
    HART_LOG(HART_LOG_TRACE, " IRQ=0x%04X MAR=0x%04X MER=0x%04X GPWR=0x%04X\r\n",
           (unsigned int)Read16(FPGA_IRQ_STATUS),
           (unsigned int)Read16(FPGA_MAR),
           (unsigned int)Read16(FPGA_MER),
           (unsigned int)Read16(FPGA_GPWR));
}

/*******************************************************************************
* UART and modem setup
*******************************************************************************/
static void ResetUartAndHartModem(UINT8 modem)
{
    HART_LOG(HART_LOG_TRACE, "[RESET_UART_AND_HART_MODEM] modem=%u resetAddr=0x%02X assert reset\r\n",
           (unsigned int)modem,
           (unsigned int)g_uartReset[modem]);

    Write8(g_uartReset[modem], 0x01u);
    IdleWait(HART_RESET_HOLD_LOOPS);

    HART_LOG(HART_LOG_TRACE, "[RESET_UART_AND_HART_MODEM] modem=%u release reset\r\n",
           (unsigned int)modem);

    Write8(g_uartReset[modem], 0x00u);
    IdleWait(HART_RESET_SETTLE_LOOPS);
}

static void ClearTxRxFIFOs(UINT8 modem)
{
    UartWrite8(modem, UART_IIR_FCR, 0xC7u);
    IdleWait(8000u);
    UartWrite8(modem, UART_IIR_FCR, 0xC1u);
    IdleWait(8000u);

    for (UINT32 guard = 0u; guard < 256u; guard++)
    {
        if ((UartRead8(modem, UART_LSR) & UART_LSR_DR) == 0u)
        {
            break;
        }

        (void)UartRead8(modem, UART_RBR_THR);
    }
}

static void InitUartLegacy(UINT8 modem)
{
    ResetUartAndHartModem(modem);

    UartWrite8(modem, UART_MCR, 0x00u);   /* /RTS inactive high */
    UartWrite8(modem, UART_IER, 0x00u);
    UartWrite8(modem, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    ClearTxRxFIFOs(modem);
    UartWrite8(modem, UART_SCR, 0xDBu);
    IdleWait(20000u);

    DumpUart(modem, "AFTER_LEGACY_UART_INIT");
}

static bool WaitTxReady(UINT8 modem)
{
    for (UINT32 guard = 0u; guard < 150000u; guard++)
    {
        if ((UartRead8(modem, UART_LSR) & UART_LSR_THRE) != 0u)
        {
            return true;
        }
    }

    return false;
}

static bool WaitTxEmpty(UINT8 modem)
{
    for (UINT32 guard = 0u; guard < 350000u; guard++)
    {
        UINT8 lsr = UartRead8(modem, UART_LSR);

        if ((lsr & (UART_LSR_THRE | UART_LSR_TEMT)) == (UART_LSR_THRE | UART_LSR_TEMT))
        {
            return true;
        }
    }

    return false;
}

static void SetMcr(UINT8 modem, UINT8 mcr, const char *tag)
{
    mcr = (UINT8)(mcr & (UINT8)(~UART_MCR_LOOPBACK));
    UartWrite8(modem, UART_MCR, mcr);
    IdleWait(12000u);

    HART_LOG(HART_LOG_TRACE, "[SET_MCR][%s] modem=%u MCR=0x%02X NOTE: MCR.RTS=1 should drive HARTRTS%u_n LOW/asserted\r\n",
           tag,
           (unsigned int)modem,
           (unsigned int)mcr,
           (unsigned int)modem);
}

static void WriteTxByte(UINT8 modem, UINT8 byte)
{
    if (!WaitTxReady(modem))
    {
        HART_LOG(HART_LOG_INFO, "[WARN] UART%u THR not ready byte=0x%02X LSR=0x%02X\r\n",
               (unsigned int)modem,
               (unsigned int)byte,
               (unsigned int)UartRead8(modem, UART_LSR));
    }

    UartWrite8(modem, UART_RBR_THR, byte);
}

/*******************************************************************************
* BRG, MUX, GPWR
*******************************************************************************/
static void ConfigureHartBaudLegacy(void)
{
    /* Corrected from FPGA design document:
     *   0x40 = common BRG DLL
     *   0x41 = common BRG DLM
     *   0x42 = BRG MUX SELECT
     *
     * 0x04E2 is the legacy HART baud divisor:
     *   DLL = 0xE2
     *   DLM = 0x04
     *
     * Do NOT use 0x50/0x51 for baud. 0x50 is AO Output Control /
     * AI Wiggle PV register.
     */
    HART_LOG(HART_LOG_TRACE, "[CONFIGURE_HART_BAUD_FIXED] DLL 0x40=0xE2, DLM 0x41=0x04, BRGMUX 0x42=0x00\r\n");

    Write8(FPGA_BRG_DLL, 0xE2u);
    IdleWait(20000u);

    Write8(FPGA_BRG_DLM, 0x04u);
    IdleWait(20000u);

    /* BRG MUX select: use 0 first. If RX still fails, next stage can scan this.
     * The current priority is to stop writing baud into wrong register 0x50.
     */
    Write8(FPGA_BRG_MUX, 0x00u);
    IdleWait(20000u);

    HART_LOG(HART_LOG_TRACE, "[CONFIGURE_HART_BAUD_FIXED] DLL40=0x%04X DLM41=0x%04X BRGMUX42=0x%04X OUTCTRL50=0x%04X\r\n",
           (unsigned int)StableRead16(FPGA_BRG_DLL, "BRG_DLL40"),
           (unsigned int)StableRead16(FPGA_BRG_DLM, "BRG_DLM41"),
           (unsigned int)StableRead16(FPGA_BRG_MUX, "BRG_MUX42"),
           (unsigned int)StableRead16(FPGA_REG_50_OUTPUT_CONTROL, "REG50_OUTPUT_CONTROL"));
}

static void SwitchMuxLegacy(UINT8 channel, UINT8 modem)
{
    UINT16 usAddr;
    UINT16 clearMask;

    m_ucConnectedChannel = channel;
    m_ucModemNumber = modem;
    m_usHartMuxAddr = HART_INITIAL_MAR;
    m_ucHartMuxEnbl = HART_INITIAL_MER;

    if (channel == 0u)
    {
        channel = 1u;
    }

    usAddr = (UINT16)((channel - 1u) & 0x000Fu);
    usAddr = (UINT16)(usAddr << (modem * 4u));

    switch (modem)
    {
        case 0u: clearMask = 0xFFF0u; break;
        case 1u: clearMask = 0xFF0Fu; break;
        case 2u: clearMask = 0xF0FFu; break;
        case 3u: clearMask = 0x0FFFu; break;
        default: clearMask = 0xFFFFu; break;
    }

    m_usHartMuxAddr &= clearMask;
    m_usHartMuxAddr |= usAddr;
    m_ucHartMuxEnbl |= (UINT8)(0x01u << modem);

    Write16(FPGA_MAR, m_usHartMuxAddr);
    IdleWait(HART_MUX_SETTLE_LOOPS);

    Write16(FPGA_MER, (UINT16)m_ucHartMuxEnbl);
    IdleWait(HART_MUX_SETTLE_LOOPS);

    HART_LOG(HART_LOG_TRACE, "[SWITCH_MUX_LEGACY] ch=%u modem=%u usAddr=0x%04X clearMask=0x%04X MAR_wr=0x%04X MAR_rd=0x%04X MER_wr=0x%02X MER_rd=0x%04X\r\n",
           (unsigned int)channel,
           (unsigned int)modem,
           (unsigned int)usAddr,
           (unsigned int)clearMask,
           (unsigned int)m_usHartMuxAddr,
           (unsigned int)StableRead16(FPGA_MAR, "MAR"),
           (unsigned int)m_ucHartMuxEnbl,
           (unsigned int)StableRead16(FPGA_MER, "MER"));
}

static void GpwrMaskData(UINT8 mask, UINT8 data)
{
    if (mask == 0u)
    {
        HART_LOG(HART_LOG_TRACE, "[GPWR] no-change current=0x%04X\r\n",
               (unsigned int)Read16(FPGA_GPWR));
        return;
    }

    Write16(FPGA_GPWR, (UINT16)(((UINT16)mask << 8) | (UINT16)data));
    IdleWait(80000u);

    HART_LOG(HART_LOG_TRACE, "[GPWR] mask=0x%02X data=0x%02X read16=0x%04X lsb=0x%02X\r\n",
           (unsigned int)mask,
           (unsigned int)data,
           (unsigned int)Read16(FPGA_GPWR),
           (unsigned int)ReadLsb(FPGA_GPWR));
}

/*******************************************************************************
* HART frame
*******************************************************************************/
static void SetShortRequest(UINT8 command, UINT8 pollAddr, const UINT8 *data, UINT8 dataLen, const char *label)
{
    g_HartRequest.useLongAddress = false;
    g_HartRequest.command = command;
    g_HartRequest.pollAddr = pollAddr;
    g_HartRequest.dataLen = dataLen;
    g_HartRequest.label = label;

    for (UINT8 i = 0u; i < sizeof(g_HartRequest.data); i++)
    {
        g_HartRequest.data[i] = 0u;
    }

    for (UINT8 i = 0u; (i < dataLen) && (i < sizeof(g_HartRequest.data)); i++)
    {
        g_HartRequest.data[i] = data[i];
    }
}

static void SetLongRequest(UINT8 command, const UINT8 longAddr[5], const UINT8 *data, UINT8 dataLen, const char *label)
{
    g_HartRequest.useLongAddress = true;
    g_HartRequest.command = command;
    g_HartRequest.pollAddr = 0u;
    g_HartRequest.dataLen = dataLen;
    g_HartRequest.label = label;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        g_HartRequest.longAddr[i] = longAddr[i];
    }

    for (UINT8 i = 0u; i < sizeof(g_HartRequest.data); i++)
    {
        g_HartRequest.data[i] = 0u;
    }

    for (UINT8 i = 0u; (i < dataLen) && (i < sizeof(g_HartRequest.data)); i++)
    {
        g_HartRequest.data[i] = data[i];
    }
}

static void BuildShortFrame(UINT8 pollAddr,
                            UINT8 command,
                            const UINT8 *data,
                            UINT8 dataLen,
                            UINT8 *out,
                            UINT32 *outLen)
{
    UINT32 idx = 0u;
    UINT8 addr = (UINT8)(HART_MASTER_ADDR_MASK | (pollAddr & 0x0Fu));
    UINT8 checksum = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = HART_PREAMBLE_BYTE;
    }

    out[idx++] = HART_DELIMITER_SHORT_MASTER_REQ;
    checksum ^= HART_DELIMITER_SHORT_MASTER_REQ;

    out[idx++] = addr;
    checksum ^= addr;

    out[idx++] = command;
    checksum ^= command;

    out[idx++] = dataLen;
    checksum ^= dataLen;

    for (UINT8 i = 0u; i < dataLen; i++)
    {
        out[idx++] = data[i];
        checksum ^= data[i];
    }

    out[idx++] = checksum;

    /* Legacy pad byte */
    out[idx++] = HART_PREAMBLE_BYTE;

    *outLen = idx;
}

static void BuildLongFrame(const UINT8 longAddr[5],
                           UINT8 command,
                           const UINT8 *data,
                           UINT8 dataLen,
                           UINT8 *out,
                           UINT32 *outLen)
{
    UINT32 idx = 0u;
    UINT8 checksum = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = HART_PREAMBLE_BYTE;
    }

    /* Legacy uses HART_UNIQUE_DELIMITER = 0x82 for all non-CMD0 channel requests. */
    out[idx++] = 0x82u;
    checksum ^= 0x82u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = longAddr[i];
        checksum ^= longAddr[i];
    }

    out[idx++] = command;
    checksum ^= command;

    out[idx++] = dataLen;
    checksum ^= dataLen;

    for (UINT8 i = 0u; i < dataLen; i++)
    {
        out[idx++] = data[i];
        checksum ^= data[i];
    }

    out[idx++] = checksum;

    /* Legacy pad byte */
    out[idx++] = HART_PREAMBLE_BYTE;

    *outLen = idx;
}

static void BuildCurrentHartRequest(UINT8 pollAddr, UINT8 *out, UINT32 *outLen)
{
    if (g_HartRequest.useLongAddress)
    {
        BuildLongFrame(g_HartRequest.longAddr,
                       g_HartRequest.command,
                       g_HartRequest.data,
                       g_HartRequest.dataLen,
                       out,
                       outLen);
    }
    else
    {
        BuildShortFrame(pollAddr,
                        g_HartRequest.command,
                        g_HartRequest.data,
                        g_HartRequest.dataLen,
                        out,
                        outLen);
    }
}

static void BuildCmd0(UINT8 pollAddr, UINT8 *out, UINT32 *outLen)
{
    SetShortRequest(HART_COMMAND_ZERO, pollAddr, NULL, 0u, "CMD0");
    BuildCurrentHartRequest(pollAddr, out, outLen);
}

static void PrintFrame(const UINT8 *buf, UINT32 len)
{
    const char *label = (g_HartRequest.label != NULL) ? g_HartRequest.label : "UNKNOWN";

    HART_LOG(HART_LOG_TRACE, "[TX_FRAME][%s] len=%u :", label, (unsigned int)len);

    for (UINT32 i = 0u; i < len; i++)
    {
        HART_LOG(HART_LOG_TRACE, " %02X", (unsigned int)buf[i]);
    }

    HART_LOG(HART_LOG_TRACE, "\r\n");
}

static void PrintBytesInfo(const char *tag, const UINT8 *buf, UINT32 len)
{
    if ((tag == NULL) || (buf == NULL))
    {
        return;
    }

    HART_LOG(HART_LOG_INFO, "[%s] len=%u :", tag, (unsigned int)len);

    for (UINT32 i = 0u; i < len; i++)
    {
        HART_LOG(HART_LOG_INFO, " %02X", (unsigned int)buf[i]);
    }

    HART_LOG(HART_LOG_INFO, "\r\n");
}

static bool CheckHartChecksum(const UINT8 *rx, UINT32 frameStart, UINT32 checksumIndex, UINT8 *calcOut)
{
    UINT8 calc = 0u;

    for (UINT32 i = frameStart; i < checksumIndex; i++)
    {
        calc ^= rx[i];
    }

    *calcOut = calc;
    return (calc == rx[checksumIndex]);
}

static bool ParseHartFrameAtOffset(const UINT8 *rx, UINT32 rxLen, UINT32 offset, HartParsedResponse_t *out, bool requireChecksum)
{
    UINT32 idx = offset;
    UINT32 frameStart;
    UINT32 checksumIndex;
    UINT8 calc = 0u;

    for (UINT32 i = 0u; i < sizeof(*out); i++)
    {
        ((UINT8 *)out)[i] = 0u;
    }

    while ((idx < rxLen) && (rx[idx] == HART_PREAMBLE_BYTE))
    {
        out->preambleCount++;
        idx++;
    }

    if (out->preambleCount == 0u)
    {
        return false;
    }

    if ((idx + 4u) >= rxLen)
    {
        return false;
    }

    frameStart = idx;
    out->delimiter = rx[idx++];

    /* Known response delimiters:
     * 0x06 = short address slave response, already observed on hardware.
     * 0x86/0x8E/0x96 = possible long response variants depending on stack/device.
     */
    if (!((out->delimiter == 0x06u) ||
          (out->delimiter == 0x86u) ||
          (out->delimiter == 0x8Eu) ||
          (out->delimiter == 0x96u) ||
          ((out->delimiter & 0x80u) != 0u)))
    {
        return false;
    }

    if ((out->delimiter & 0x80u) != 0u)
    {
        out->isLongAddress = true;
        out->addressLen = 5u;

        if ((idx + 5u + 3u) >= rxLen)
        {
            return false;
        }

        for (UINT8 i = 0u; i < 5u; i++)
        {
            out->address[i] = rx[idx++];
        }
    }
    else
    {
        out->isLongAddress = false;
        out->addressLen = 1u;
        out->address[0] = rx[idx++];
    }

    out->command = rx[idx++];
    out->byteCount = rx[idx++];

    if (out->byteCount > sizeof(out->payload))
    {
        return false;
    }

    checksumIndex = idx + out->byteCount;

    if (checksumIndex >= rxLen)
    {
        return false;
    }

    if (out->byteCount >= 2u)
    {
        out->hasStatus = true;
        out->status0 = rx[idx++];
        out->status1 = rx[idx++];
        out->payloadLen = (UINT8)(out->byteCount - 2u);
    }
    else
    {
        out->payloadLen = out->byteCount;
    }

    for (UINT8 i = 0u; i < out->payloadLen; i++)
    {
        out->payload[i] = rx[idx++];
    }

    out->checksumRx = rx[checksumIndex];
    out->checksumOk = CheckHartChecksum(rx, frameStart, checksumIndex, &calc);
    out->checksumCalc = calc;

    if (requireChecksum && !out->checksumOk)
    {
        return false;
    }

    out->valid = true;
    return true;
}

static bool ParseHartResponse(const UINT8 *rx, UINT32 rxLen, HartParsedResponse_t *out)
{
    for (UINT32 offset = 0u; offset < rxLen; offset++)
    {
        if (rx[offset] != HART_PREAMBLE_BYTE)
        {
            continue;
        }

        if (ParseHartFrameAtOffset(rx, rxLen, offset, out, true))
        {
            HART_LOG(HART_LOG_TRACE, "[PARSE_SYNC] offset=%u checksum-valid\\r\\n", (unsigned int)offset);
            break;
        }
    }

    if (!out->valid)
    {
        HART_LOG(HART_LOG_INFO, "[PARSE_FAIL] no checksum-valid HART frame found in rxLen=%u\\r\\n",
               (unsigned int)rxLen);
        PrintBytesInfo("PARSE_FAIL_CLEAN_RX", rx, rxLen);
        return false;
    }

    HART_LOG(HART_LOG_TRACE, "[PARSED] valid=%u checksumOk=%u preambles=%u delimiter=0x%02X long=%u addrLen=%u cmd=%u byteCount=%u status=[0x%02X 0x%02X] payloadLen=%u chkRx=0x%02X chkCalc=0x%02X\\r\\n",
           (unsigned int)(out->valid ? 1u : 0u),
           (unsigned int)(out->checksumOk ? 1u : 0u),
           (unsigned int)out->preambleCount,
           (unsigned int)out->delimiter,
           (unsigned int)(out->isLongAddress ? 1u : 0u),
           (unsigned int)out->addressLen,
           (unsigned int)out->command,
           (unsigned int)out->byteCount,
           (unsigned int)out->status0,
           (unsigned int)out->status1,
           (unsigned int)out->payloadLen,
           (unsigned int)out->checksumRx,
           (unsigned int)out->checksumCalc);

    if (out->payloadLen > 0u)
    {
        HART_LOG(HART_LOG_TRACE, "[PARSED_PAYLOAD]");
        for (UINT8 i = 0u; i < out->payloadLen; i++)
        {
            HART_LOG(HART_LOG_TRACE, " %02X", (unsigned int)out->payload[i]);
        }
        HART_LOG(HART_LOG_TRACE, "\\r\\n");
    }

    return true;
}

static bool ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[5], UINT8 *respPreambles)
{
    if (!cmd0->valid || !cmd0->checksumOk || (cmd0->command != HART_COMMAND_ZERO))
    {
        HART_LOG(HART_LOG_INFO, "[LONG_ADDR_FAIL] CMD0 invalid/checksum/command mismatch\r\n");
        return false;
    }

    if (cmd0->payloadLen < HART_CMD0_LEGACY_RESPONSE_SIZE)
    {
        HART_LOG(HART_LOG_INFO, "[LONG_ADDR_FAIL] CMD0 payloadLen=%u. Need at least %u bytes. Status=[0x%02X 0x%02X]\r\n",
               (unsigned int)cmd0->payloadLen,
               (unsigned int)HART_CMD0_LEGACY_RESPONSE_SIZE,
               (unsigned int)cmd0->status0,
               (unsigned int)cmd0->status1);
        return false;
    }

    /* HART stack fix:
     * Stage 27 proved the real clean CMD0 response is:
     *   FF FF FF 06 80 00 0E 00 00 FE AA 04 05 05 0A 01 09 04 00 00 30 EE
     *
     * Parsed payloadLen = 12:
     *   payload[0]  = 0xFE
     *   payload[1]  = expanded/manufacturer byte = 0xAA
     *   payload[2]  = device type = 0x04
     *   payload[3]  = response preambles = 0x05
     *   payload[4]  = HART revision = 0x05
     *   payload[5]  = device revision = 0x0A
     *   payload[6]  = software revision = 0x01
     *   payload[7]  = hardware revision / physical signaling = 0x09
     *   payload[8]  = flags / device profile = 0x04
     *   payload[9..11] = unique ID = 00 00 30
     *
     * Legacy Cmd0GoodHandler addressing:
     *   unique[0] = payload[1]
     *   unique[1] = payload[2]
     *   unique[2..4] = payload[9..11]
     */
    longAddr[0] = cmd0->payload[1];
    longAddr[1] = cmd0->payload[2];
    longAddr[2] = cmd0->payload[9];
    longAddr[3] = cmd0->payload[10];
    longAddr[4] = cmd0->payload[11];

    *respPreambles = cmd0->payload[3];
    if (*respPreambles < 5u)
    {
        *respPreambles = 5u;
    }

    HART_LOG(HART_LOG_TRACE, "[CMD0_IDENTITY] payloadLen=%u payload=",
           (unsigned int)cmd0->payloadLen);
    for (UINT8 i = 0u; i < cmd0->payloadLen; i++)
    {
        HART_LOG(HART_LOG_TRACE, " %02X", (unsigned int)cmd0->payload[i]);
    }
    HART_LOG(HART_LOG_TRACE, "\r\n");

    HART_LOG(HART_LOG_INFO, "[CMD0_LONG_ADDR] %02X %02X %02X %02X %02X respPreambles=%u hartRev=%u devRev=%u swRev=%u hwPhys=0x%02X\r\n",
           (unsigned int)longAddr[0],
           (unsigned int)longAddr[1],
           (unsigned int)longAddr[2],
           (unsigned int)longAddr[3],
           (unsigned int)longAddr[4],
           (unsigned int)*respPreambles,
           (unsigned int)cmd0->payload[4],
           (unsigned int)cmd0->payload[5],
           (unsigned int)cmd0->payload[6],
           (unsigned int)cmd0->payload[7]);

    HART_LOG(HART_LOG_INFO, "[LONG_ADDR_PASS] Using CMD0 12-byte identity payload for CMD48/CMD59\r\n");

    return true;
}



/*******************************************************************************
* Modem object helpers
*******************************************************************************/
static void HartModemSetState(HartModemObject_t *obj, HartModemState_t newState, const char *reason)
{
    HART_LOG(HART_LOG_TRACE, "[STATE] %s -> %s reason=%s totalTicks=%u rx=%u dcd=%u\r\n",
           StateName(obj->state),
           StateName(newState),
           reason,
           (unsigned int)obj->totalTicks,
           (unsigned int)obj->rxCount,
           (unsigned int)(obj->sawDcd ? 1u : 0u));

    obj->state = newState;
    obj->tickInState = 0u;
}


static bool HartIsValidResponseDelimiter(UINT8 b)
{
    return ((b == 0x06u) || (b == 0x86u) || (b == 0x8Eu) || (b == 0x96u));
}

static bool HartLooksLikeStatusEcho(UINT8 b)
{
    return ((b == 0x60u) || (b == 0x61u) || (b == 0xC1u) ||
            (b == 0x88u) || (b == 0x09u) || (b == 0x08u) ||
            (b == 0x02u));
}

static UINT32 HartFindDelimiterIndex(const HartModemObject_t *obj)
{
    for (UINT32 i = 0u; i < obj->rxCount; i++)
    {
        if (obj->rxBuf[i] != HART_PREAMBLE_BYTE)
        {
            return i;
        }
    }
    return 0xFFFFFFFFu;
}

static void HartUpdateExpectedLength(HartModemObject_t *obj)
{
    UINT32 d;
    UINT8 delimiter;
    UINT32 byteCountIndex;
    UINT8 byteCount;

    if (obj->rxExpectedLen != 0u)
    {
        return;
    }

    d = HartFindDelimiterIndex(obj);
    if (d == 0xFFFFFFFFu)
    {
        return;
    }

    delimiter = obj->rxBuf[d];
    byteCountIndex = ((delimiter & 0x80u) != 0u) ? (d + 7u) : (d + 3u);

    if (obj->rxCount <= byteCountIndex)
    {
        return;
    }

    byteCount = obj->rxBuf[byteCountIndex];
    if (byteCount > 64u)
    {
        return;
    }

    obj->rxExpectedLen = ((delimiter & 0x80u) != 0u) ? (d + 9u + byteCount) : (d + 5u + byteCount);

    HART_LOG(HART_LOG_TRACE, "[RX_EXPECT] delimiterIndex=%u delimiter=0x%02X byteCount=%u expectedCleanLen=%u\r\n",
           (unsigned int)d,
           (unsigned int)delimiter,
           (unsigned int)byteCount,
           (unsigned int)obj->rxExpectedLen);
}

static bool HartByteAllowedAtCleanIndex(HartModemObject_t *obj, UINT8 b, UINT8 lsrBefore)
{
    UINT32 d;
    UINT32 pos;

    if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
    {
        return false;
    }

    if (obj->rxCount == 0u)
    {
        return (b == HART_PREAMBLE_BYTE);
    }

    d = HartFindDelimiterIndex(obj);
    if (d == 0xFFFFFFFFu)
    {
        if (b == HART_PREAMBLE_BYTE)
        {
            return true;
        }
        if ((obj->rxCount >= 2u) && HartIsValidResponseDelimiter(b))
        {
            return true;
        }
        return false;
    }

    pos = obj->rxCount - d;

    if ((obj->rxBuf[d] & 0x80u) == 0u)
    {
        if (pos == 1u)
        {
            if ((b != (UINT8)(HART_MASTER_ADDR_MASK | (obj->pollAddr & 0x0Fu))) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 2u)
        {
            if ((b != g_HartRequest.command) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 3u)
        {
            if ((b > 64u) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
    }
    else
    {
        if (pos == 6u)
        {
            if ((b != g_HartRequest.command) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 7u)
        {
            if ((b > 64u) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
    }

    if ((b == lsrBefore) && HartLooksLikeStatusEcho(b))
    {
        return false;
    }

    return true;
}

static void HartAppendRxByte(HartModemObject_t *obj, UINT8 b, UINT8 lsrBefore)
{
    if (obj->rxRawCount < sizeof(obj->rxRawBuf))
    {
        obj->rxRawBuf[obj->rxRawCount] = b;
    }
    obj->rxRawCount++;

    if (!HartByteAllowedAtCleanIndex(obj, b, lsrBefore))
    {
        obj->rxDroppedStatusEcho++;
        HART_LOG(HART_LOG_TRACE, "[RX_DROP] tick=%u raw[%u]=0x%02X lsrBefore=0x%02X cleanLen=%u dropped=%u\r\n",
               (unsigned int)obj->totalTicks,
               (unsigned int)(obj->rxRawCount - 1u),
               (unsigned int)b,
               (unsigned int)lsrBefore,
               (unsigned int)obj->rxCount,
               (unsigned int)obj->rxDroppedStatusEcho);
        return;
    }

    if (obj->rxCount < sizeof(obj->rxBuf))
    {
        obj->rxBuf[obj->rxCount] = b;
    }

    if (b == HART_PREAMBLE_BYTE)
    {
        obj->preambleCount++;
        m_ucRemPreambles++;
    }

    HART_LOG(HART_LOG_TRACE, "[RX_BYTE_CLEAN] tick=%u state=%s rx[%u]=0x%02X preambles=%u raw=%u\r\n",
           (unsigned int)obj->totalTicks,
           StateName(obj->state),
           (unsigned int)obj->rxCount,
           (unsigned int)b,
           (unsigned int)obj->preambleCount,
           (unsigned int)obj->rxRawCount);

    obj->rxCount++;
    HartUpdateExpectedLength(obj);
}

static void HartDrainRxFifoClean(HartModemObject_t *obj, UINT8 firstLsr)
{
    UINT8 lsr = firstLsr;

    for (UINT32 guard = 0u; guard < 64u; guard++)
    {
        if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
        {
            HART_LOG(HART_LOG_TRACE, "[RX_DONE_BY_LENGTH] cleanLen=%u expected=%u raw=%u dropped=%u\r\n",
                   (unsigned int)obj->rxCount,
                   (unsigned int)obj->rxExpectedLen,
                   (unsigned int)obj->rxRawCount,
                   (unsigned int)obj->rxDroppedStatusEcho);
            break;
        }

        if ((lsr & UART_LSR_DR) == 0u)
        {
            break;
        }

        UartForceNormalLineMode(obj->modem);
        IdleWait(2500u);

        UINT8 b = UartRead8(obj->modem, UART_RBR_THR);
        HartAppendRxByte(obj, b, lsr);

        IdleWait(2500u);
        lsr = UartRead8(obj->modem, UART_LSR);
    }
}

static void HartModemSampleStatus(HartModemObject_t *obj)
{
    UINT8 lsr = UartRead8(obj->modem, UART_LSR);

    if ((lsr & UART_LSR_DR) != 0u)
    {
        HartDrainRxFifoClean(obj, lsr);
    }

    lsr = UartRead8(obj->modem, UART_LSR);
    UINT8 msr = UartRead8(obj->modem, UART_MSR);
    UINT8 iir = UartRead8(obj->modem, UART_IIR_FCR);
    UINT8 irq = Read8(FPGA_IRQ_STATUS);

    if (msr != obj->lastMsr)
    {
        obj->msrChanges++;
        HART_LOG(HART_LOG_TRACE, "[MSR_CHANGE][%s] tick=%u state=%s old=0x%02X new=0x%02X ",
               "MODEM",
               (unsigned int)obj->totalTicks,
               StateName(obj->state),
               (unsigned int)obj->lastMsr,
               (unsigned int)msr);
        PrintMsrBits(msr);
        HART_LOG(HART_LOG_TRACE, "\r\n");
        obj->lastMsr = msr;
    }

    if (iir != obj->lastIir)
    {
        obj->iirChanges++;
        HART_LOG(HART_LOG_TRACE, "[IIR_CHANGE] tick=%u state=%s old=0x%02X new=0x%02X\r\n",
               (unsigned int)obj->totalTicks,
               StateName(obj->state),
               (unsigned int)obj->lastIir,
               (unsigned int)iir);
        obj->lastIir = iir;
    }

    if (irq != obj->lastIrq)
    {
        obj->irqChanges++;
        HART_LOG(HART_LOG_TRACE, "[IRQ_CHANGE] tick=%u state=%s old=0x%02X new=0x%02X\r\n",
               (unsigned int)obj->totalTicks,
               StateName(obj->state),
               (unsigned int)obj->lastIrq,
               (unsigned int)irq);
        obj->lastIrq = irq;
    }

    if ((msr & UART_MSR_DCD) != 0u)
    {
        obj->dcdHighTicks++;
        obj->sawDcd = true;
    }

    if ((msr & UART_MSR_RI) != 0u)  { obj->riHighTicks++;  }
    if ((msr & UART_MSR_DSR) != 0u) { obj->dsrHighTicks++; }
    if ((msr & UART_MSR_CTS) != 0u) { obj->ctsHighTicks++; }

    if ((lsr & (UART_LSR_OE | UART_LSR_PE | UART_LSR_FE | UART_LSR_BI)) != 0u)
    {
        obj->uartErrors++;
        HART_LOG(HART_LOG_TRACE, "[UART_ERR] tick=%u state=%s LSR=0x%02X\r\n",
               (unsigned int)obj->totalTicks,
               StateName(obj->state),
               (unsigned int)lsr);
    }

}

static void HartModemPrintTick(HartModemObject_t *obj)
{
    UINT8 lsr = UartRead8(obj->modem, UART_LSR);
    UINT8 msr = UartRead8(obj->modem, UART_MSR);
    UINT8 iir = UartRead8(obj->modem, UART_IIR_FCR);
    UINT8 irq = Read8(FPGA_IRQ_STATUS);

    HART_LOG(HART_LOG_TRACE, "[TICK] total=%u inState=%u state=%s rx=%u dcdSeen=%u LSR=0x%02X IIR=0x%02X ",
           (unsigned int)obj->totalTicks,
           (unsigned int)obj->tickInState,
           StateName(obj->state),
           (unsigned int)obj->rxCount,
           (unsigned int)(obj->sawDcd ? 1u : 0u),
           (unsigned int)lsr,
           (unsigned int)iir);
    PrintMsrBits(msr);
    HART_LOG(HART_LOG_TRACE, " IRQ=0x%02X MAR=0x%04X MER=0x%04X GPWR=0x%04X\r\n",
           (unsigned int)irq,
           (unsigned int)Read16(FPGA_MAR),
           (unsigned int)Read16(FPGA_MER),
           (unsigned int)Read16(FPGA_GPWR));
}

static void HartModemPrepareTransaction(HartModemObject_t *obj, UINT8 channel, UINT8 modem, UINT8 pollAddr, bool gpwrEnable)
{
    obj->modem = modem;
    obj->channel = channel;
    obj->pollAddr = pollAddr;
    obj->txLen = 0u;
    obj->txIndex = 0u;
    obj->rxCount = 0u;
    obj->rxRawCount = 0u;
    obj->rxDroppedStatusEcho = 0u;
    obj->rxExpectedLen = 0u;
    obj->preambleCount = 0u;
    obj->state = HART_MODEM_IDLE;
    obj->tickInState = 0u;
    obj->totalTicks = 0u;
    obj->msrChanges = 0u;
    obj->irqChanges = 0u;
    obj->iirChanges = 0u;
    obj->uartErrors = 0u;
    obj->dcdHighTicks = 0u;
    obj->riHighTicks = 0u;
    obj->dsrHighTicks = 0u;
    obj->ctsHighTicks = 0u;
    obj->gpwrEnable = gpwrEnable;
    obj->sawDcd = false;
    obj->completed = false;

    BuildCurrentHartRequest(pollAddr, obj->txFrame, &obj->txLen);

    obj->lastMsr = UartRead8(modem, UART_MSR);
    obj->lastIir = UartRead8(modem, UART_IIR_FCR);
    obj->lastIrq = Read8(FPGA_IRQ_STATUS);
}

static void HartModemEnterSyncWait(HartModemObject_t *obj)
{
    ClearTxRxFIFOs(obj->modem);

    /* Connect and stay connected. */
    SwitchMuxLegacy(obj->channel, obj->modem);

    if (obj->gpwrEnable)
    {
        GpwrMaskData(0x08u, 0x08u);
    }
    else
    {
        GpwrMaskData(0x00u, 0x00u);
    }

    /* Receive mode before transmit: /RTS inactive high, RX+modem status enabled. */
    SetMcr(obj->modem, 0x00u, "SYNCWAIT_RX_RTS_INACTIVE");
    UartWrite8(obj->modem, UART_IER, HART_IER_RX_MODEM_STATUS);
    DumpUart(obj->modem, "ENTER_SYNCWAIT");
    HART_LOG(HART_LOG_TRACE, "[REQUEST_LABEL] %s\r\n", (g_HartRequest.label != NULL) ? g_HartRequest.label : "UNKNOWN");
    PrintFrame(obj->txFrame, obj->txLen);

    HartModemSetState(obj, HART_MODEM_SYNCWAIT, "connected modem and waiting before transmit");
}

static void HartModemEnterTransmit(HartModemObject_t *obj)
{
    if (obj->gpwrEnable)
    {
        GpwrMaskData(0x08u, 0x08u);
    }

    /* HARTRTSx_n active-low: MCR.RTS=1 asserts the external /RTS low. */
    SetMcr(obj->modem, UART_MCR_RTS, "XMITTING_ASSERT_RTS_ACTIVE_LOW");
    UartWrite8(obj->modem, UART_IER, HART_IER_TX_EMPTY);
    HartCharacterDelayTicks(HART_RTS_PRE_TX_TICKS);

    DumpUart(obj->modem, "ENTER_XMITTING");
    HartModemSetState(obj, HART_MODEM_XMITTING, "RTS asserted active-low");
}

static void HartModemTransmitAll(HartModemObject_t *obj)
{
    while (obj->txIndex < obj->txLen)
    {
        WriteTxByte(obj->modem, obj->txFrame[obj->txIndex]);
        obj->txIndex++;
    }

    UartWrite8(obj->modem, UART_IER, HART_IER_TX_EMPTY);

    if (!WaitTxEmpty(obj->modem))
    {
        HART_LOG(HART_LOG_INFO, "[WARN] TX empty timeout modem=%u\r\n", (unsigned int)obj->modem);
    }

    DumpUart(obj->modem, "AFTER_TX_DRAIN");
}

static void HartModemEnterRcvWait(HartModemObject_t *obj)
{
    HartCharacterDelayTicks(HART_TX_TO_RX_GUARD_TICKS);

    /* Receive mode: /RTS inactive high. */
    SetMcr(obj->modem, 0x00u, "RCVWAIT_DEASSERT_RTS_FOR_RX");
    UartWrite8(obj->modem, UART_IER, HART_IER_RX_MODEM_STATUS);

    if (obj->gpwrEnable)
    {
        /* Keep bit3 on while receiving first. If this is a TX enable bit only,
         * later logs will still tell us DCD/RX behavior.
         */
        GpwrMaskData(0x08u, 0x08u);
    }

    DumpUart(obj->modem, "ENTER_RCVWAIT");
    HartModemSetState(obj, HART_MODEM_RCVWAIT, "TX complete and waiting for carrier/RX");
}

static void HartModemTick(HartModemObject_t *obj)
{
    UINT32 rxBefore = obj->rxCount;

    obj->totalTicks++;
    obj->tickInState++;

    HartModemSampleStatus(obj);

    /*
     * Important after reducing PRINTF spam:
     * The old debug-heavy loop was accidentally giving the UART more real time
     * between state ticks. With clean logs the loop is faster, so do not treat
     * RCVING idle timeout as "time since entering RCVING"; treat it as
     * "time since the last received byte".
     */
    if ((obj->state == HART_MODEM_RCVING) && (obj->rxCount > rxBefore))
    {
        obj->tickInState = 0u;
    }

    if ((obj->totalTicks % 5u) == 0u)
    {
        HartModemPrintTick(obj);
    }

    switch (obj->state)
    {
        case HART_MODEM_IDLE:
            HartModemEnterSyncWait(obj);
            break;

        case HART_MODEM_SYNCWAIT:
            if (obj->tickInState >= HART_SYNCWAIT_TICKS)
            {
                HartModemEnterTransmit(obj);
            }
            break;

        case HART_MODEM_XMITTING:
            HartModemTransmitAll(obj);
            HartModemEnterRcvWait(obj);
            break;

        case HART_MODEM_RCVWAIT:
            if (obj->rxCount > 0u)
            {
                HartModemSetState(obj, HART_MODEM_RCVING, "RX byte arrived");
            }
            else if (obj->sawDcd)
            {
                HartModemSetState(obj, HART_MODEM_RCVING, "carrier detected");
            }
            else if (obj->tickInState >= HART_RCVWAIT_TICKS)
            {
                HartModemSetState(obj, HART_MODEM_TIMEOUT, "no carrier/RX during receive wait");
            }
            break;

        case HART_MODEM_RCVING:
            if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
            {
                HartModemSetState(obj, HART_MODEM_DONE, "RX completed by expected frame length");
            }
            else if (obj->rxCount > 0u)
            {
                if (obj->tickInState >= HART_RCVING_IDLE_TICKS)
                {
                    HartModemSetState(obj, HART_MODEM_DONE, "RX completed by idle timeout");
                }
            }
            else if (obj->tickInState >= HART_RCVING_IDLE_TICKS)
            {
                HartModemSetState(obj, HART_MODEM_TIMEOUT, "carrier seen but no RX byte");
            }
            break;

        case HART_MODEM_DONE:
        case HART_MODEM_TIMEOUT:
        case HART_MODEM_BAD:
        default:
            obj->completed = true;
            break;
    }
}

static void HartModemRun(HartModemObject_t *obj)
{
    while (!obj->completed)
    {
        HartModemTick(obj);

        if (obj->completed)
        {
            break;
        }

        HartCharacterDelayTicks(1u);
    }
}

static void HartModemPrintResult(HartModemObject_t *obj, const char *caseName)
{
    HART_LOG(HART_LOG_TRACE, "\r\n[MODEM_RESULT][%s] state=%s modem=%u channel=%u pollAddr=%u gpwr=%u totalTicks=%u rx=%u raw=%u dropped=%u expected=%u preambles=%u sawDcd=%u msrChanges=%u iirChanges=%u irqChanges=%u uartErrors=%u dcdHighTicks=%u riHighTicks=%u dsrHighTicks=%u ctsHighTicks=%u\r\n",
           caseName,
           StateName(obj->state),
           (unsigned int)obj->modem,
           (unsigned int)obj->channel,
           (unsigned int)obj->pollAddr,
           (unsigned int)(obj->gpwrEnable ? 1u : 0u),
           (unsigned int)obj->totalTicks,
           (unsigned int)obj->rxCount,
           (unsigned int)obj->rxRawCount,
           (unsigned int)obj->rxDroppedStatusEcho,
           (unsigned int)obj->rxExpectedLen,
           (unsigned int)obj->preambleCount,
           (unsigned int)(obj->sawDcd ? 1u : 0u),
           (unsigned int)obj->msrChanges,
           (unsigned int)obj->iirChanges,
           (unsigned int)obj->irqChanges,
           (unsigned int)obj->uartErrors,
           (unsigned int)obj->dcdHighTicks,
           (unsigned int)obj->riHighTicks,
           (unsigned int)obj->dsrHighTicks,
           (unsigned int)obj->ctsHighTicks);

    if (obj->rxCount > 0u)
    {
        HART_LOG(HART_LOG_TRACE, "[RX_CLEAN_DUMP]");
        for (UINT32 i = 0u; (i < obj->rxCount) && (i < sizeof(obj->rxBuf)); i++)
        {
            HART_LOG(HART_LOG_TRACE, " %02X", (unsigned int)obj->rxBuf[i]);
        }
        HART_LOG(HART_LOG_TRACE, "\r\n");
    }

    if (obj->rxRawCount > 0u)
    {
        UINT32 rawToPrint = obj->rxRawCount;
        if (rawToPrint > sizeof(obj->rxRawBuf))
        {
            rawToPrint = sizeof(obj->rxRawBuf);
        }

        HART_LOG(HART_LOG_TRACE, "[RX_RAW_DUMP]");
        for (UINT32 i = 0u; i < rawToPrint; i++)
        {
            HART_LOG(HART_LOG_TRACE, " %02X", (unsigned int)obj->rxRawBuf[i]);
        }
        HART_LOG(HART_LOG_TRACE, "\r\n");
    }
}

/*******************************************************************************
* Self-check
*******************************************************************************/
static bool SelfCheck(void)
{
    UINT16 ver;
    UINT16 rev;
    UINT16 mod;

    DumpCommon("BOOT_RAW");

    ver = StableRead16(FPGA_VERSION, "C5_VERSION");
    rev = StableRead16(FPGA_REVISION, "C6_REVISION");
    mod = StableRead16(FPGA_MODNUM, "C8_MODNUM");

    HART_LOG(HART_LOG_INFO, "[IDENTITY] VER=0x%04X VER8=0x%02X REV=0x%04X REV8=0x%02X MOD=0x%04X MOD8=0x%02X\r\n",
           (unsigned int)ver,
           (unsigned int)((ver >> 8) & 0xFFu),
           (unsigned int)rev,
           (unsigned int)((rev >> 8) & 0xFFu),
           (unsigned int)mod,
           (unsigned int)((mod >> 8) & 0xFFu));

    if ((((ver >> 8) & 0xFFu) != 0x6Du) ||
        (((rev >> 8) & 0xFFu) != 0x03u))
    {
        HART_LOG(HART_LOG_INFO, "[SELF_CHECK_FAIL] FPGA VER/REV mismatch.\r\n");
        return false;
    }

    if ((((mod >> 8) & 0xFFu) != 0x13u) &&
        (((mod >> 8) & 0xFFu) != 0x14u))
    {
        HART_LOG(HART_LOG_INFO, "[SELF_CHECK_WARN] FPGA MODNUM is not 0x13/0x14, continuing.\r\n");
    }

    HART_LOG(HART_LOG_INFO, "[SELF_CHECK_PASS]\r\n");
    return true;
}

/*******************************************************************************
* HART stack
*******************************************************************************/
static UINT32 RunHartTransaction(UINT8 channel,
                                      UINT8 modem,
                                      UINT8 pollAddr,
                                      bool gpwr,
                                      HartParsedResponse_t *parsedOut)
{
    HartModemObject_t obj;
    char caseName[128];

    snprintf(caseName, sizeof(caseName), "CH%u_M%u_PA%u_GPWR%u_%s",
             (unsigned int)channel,
             (unsigned int)modem,
             (unsigned int)pollAddr,
             (unsigned int)(gpwr ? 1u : 0u),
             (g_HartRequest.label != NULL) ? g_HartRequest.label : "REQ");

    HART_LOG(HART_LOG_TRACE, "\r\n============================================================\r\n");
    HART_LOG(HART_LOG_TRACE, "[HART_TRANSACTION] %s\r\n", caseName);
    HART_LOG(HART_LOG_TRACE, "============================================================\r\n");

    /* IMPORTANT:
     * Keep proven legacy working behavior: each transaction gets the same legacy
     * reset/baud/mux/write sequence that proved TX/RX on hardware.
     */
    InitUartLegacy(modem);
    ConfigureHartBaudLegacy();

    HartModemPrepareTransaction(&obj, channel, modem, pollAddr, gpwr);
    HartModemRun(&obj);
    HartModemPrintResult(&obj, caseName);

    if (obj.rxCount > 0u)
    {
        HART_LOG(HART_LOG_TRACE, "[HART_DETECTED_RX] %s\r\n", caseName);
        if (parsedOut != NULL)
        {
            bool parseOk = ParseHartResponse(obj.rxBuf, obj.rxCount, parsedOut);
            if (!parseOk)
            {
                PrintBytesInfo("PARSE_FAIL_RAW_RX", obj.rxRawBuf, obj.rxRawCount);
                HART_LOG(HART_LOG_INFO,
                         "[RX_HINT] Expected CMD0 is usually 21-22 bytes. If rxLen is 17/18, RX was ending too early; Stage34 waits based on last byte received.\r\n");
            }
        }
    }
    else if (obj.sawDcd)
    {
        HART_LOG(HART_LOG_INFO, "[HART_DETECTED_DCD_NO_RX] %s - carrier seen but no byte decoded\r\n", caseName);
    }
    else
    {
        HART_LOG(HART_LOG_INFO, "[HART_NO_CARRIER_NO_RX] %s\r\n", caseName);
    }

    return obj.rxCount;
}

static bool GetCleanCmd0Response(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out)
{
    for (UINT8 attempt = 1u; attempt <= HART_CMD0_RETRY_COUNT; attempt++)
    {
        HART_LOG(HART_LOG_INFO, "\r\n[CMD0_ATTEMPT] %u/%u using legacy transaction style\r\n",
               (unsigned int)attempt,
               (unsigned int)HART_CMD0_RETRY_COUNT);

        SetShortRequest(HART_COMMAND_ZERO, pollAddr, NULL, 0u, "CMD0");

        if (RunHartTransaction(channel, modem, pollAddr, true, cmd0Out) == 0u)
        {
            HART_LOG(HART_LOG_INFO, "[CMD0_ATTEMPT_FAIL] no RX\r\n");
            continue;
        }

        if (!cmd0Out->valid || !cmd0Out->checksumOk)
        {
            HART_LOG(HART_LOG_INFO, "[CMD0_ATTEMPT_FAIL] parser/checksum failed\r\n");
            continue;
        }

        if (cmd0Out->command != HART_COMMAND_ZERO)
        {
            HART_LOG(HART_LOG_INFO, "[CMD0_ATTEMPT_FAIL] expected command 0 response, got %u\r\n",
                   (unsigned int)cmd0Out->command);
            continue;
        }

        HART_LOG(HART_LOG_INFO, "[CMD0_CLEAN_PASS] attempt=%u status=[0x%02X 0x%02X] payloadLen=%u\r\n",
               (unsigned int)attempt,
               (unsigned int)cmd0Out->status0,
               (unsigned int)cmd0Out->status1,
               (unsigned int)cmd0Out->payloadLen);

        return true;
    }

    return false;
}



/*******************************************************************************
* Legacy command coverage table
*******************************************************************************/
static const HartLegacyCommandInfo_t g_legacyCommandTable[] =
{
    { HART_COMMAND_ZERO,        "CMD0_READ_UNIQUE_ID",                true,  true,  false },
    { HART_COMMAND_THREE,       "CMD3_READ_DYNAMIC_VARS",             true,  true,  false },
    { HART_COMMAND_SIX,         "CMD6_WRITE_POLLING_ADDRESS",         true,  false, true  },
    { HART_COMMAND_NINE,        "CMD9_READ_DEVICE_VARIABLE_STATUS",   true,  false, false },
    { HART_COMMAND_TWELVE,      "CMD12_READ_MESSAGE",                 true,  true,  false },
    { HART_COMMAND_THIRTEEN,    "CMD13_READ_TAG_DESCRIPTOR_DATE",     true,  true,  false },
    { HART_COMMAND_FOURTEEN,    "CMD14_READ_PV_TRANSDUCER_INFO",      true,  true,  false },
    { HART_COMMAND_FIFTEEN,     "CMD15_READ_DEVICE_INFO",             true,  true,  false },
    { HART_COMMAND_SIXTEEN,     "CMD16_READ_FINAL_ASSEMBLY",          true,  true,  false },
    { HART_COMMAND_TWENTY,      "CMD20_READ_LONG_TAG",                true,  true,  false },
    { HART_COMMAND_THIRTYTHREE, "CMD33_READ_DEVICE_VARIABLES",        true,  false, false },
    { HART_COMMAND_THIRTYEIGHT, "CMD38_RESET_CONFIG_CHANGED",         true,  false, true  },
    { HART_COMMAND_FORTYEIGHT,  "CMD48_READ_ADDITIONAL_STATUS",       true,  true,  false },
    { HART_COMMAND_FIFTY,       "CMD50_READ_DYNAMIC_ASSOCIATION",     true,  true,  false },
    { HART_COMMAND_FIFTYNINE,   "CMD59_SET_RESPONSE_PREAMBLES",       true,  true,  true  },
    { HART_COMMAND_HUNDREDNINE, "CMD109_DISABLE_BURST_MODE",          true,  false, true  }
};

/*******************************************************************************
* Public utility
*******************************************************************************/
void HartStack_Reset(VOID)
{
    for (UINT8 modem = 0u; modem < UART_COUNT; modem++)
    {
        ResetUartAndHartModem(modem);
    }
}

/*******************************************************************************
* Public wrappers
*******************************************************************************/
void HartStack_IdleWait(UINT32 loops)
{
    IdleWait(loops);
}

bool HartStack_SelfCheck(void)
{
    return SelfCheck();
}

void HartStack_SetShortRequest(UINT8 command, UINT8 pollAddr, const UINT8 *data, UINT8 dataLen, const char *label)
{
    SetShortRequest(command, pollAddr, data, dataLen, label);
}

void HartStack_SetLongRequest(UINT8 command, const UINT8 longAddr[5], const UINT8 *data, UINT8 dataLen, const char *label)
{
    SetLongRequest(command, longAddr, data, dataLen, label);
}

UINT32 HartStack_RunTransaction(UINT8 channel, UINT8 modem, UINT8 pollAddr, bool gpwr, HartParsedResponse_t *parsedOut)
{
    return RunHartTransaction(channel, modem, pollAddr, gpwr, parsedOut);
}

bool HartStack_RunLongCommand(UINT8 channel,
                              UINT8 modem,
                              UINT8 pollAddr,
                              const UINT8 longAddr[5],
                              UINT8 command,
                              const UINT8 *data,
                              UINT8 dataLen,
                              const char *label,
                              HartParsedResponse_t *parsedOut)
{
    HartStack_SetLongRequest(command, longAddr, data, dataLen, label);

    if (HartStack_RunTransaction(channel, modem, pollAddr, true, parsedOut) == 0u)
    {
        return false;
    }

    return ((parsedOut != NULL) && parsedOut->valid && parsedOut->checksumOk);
}

const HartLegacyCommandInfo_t *HartStack_GetLegacyCommandTable(UINT8 *countOut)
{
    if (countOut != NULL)
    {
        *countOut = (UINT8)(sizeof(g_legacyCommandTable) / sizeof(g_legacyCommandTable[0]));
    }

    return g_legacyCommandTable;
}

bool HartStack_GetCleanCmd0(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out)
{
    return GetCleanCmd0Response(channel, modem, pollAddr, cmd0Out);
}

bool HartStack_ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[5], UINT8 *respPreambles)
{
    return ExtractLongAddressFromCmd0(cmd0, longAddr, respPreambles);
}

bool HartStack_ParseHartResponse(const UINT8 *rx, UINT32 rxLen, HartParsedResponse_t *out)
{
    return ParseHartResponse(rx, rxLen, out);
}
