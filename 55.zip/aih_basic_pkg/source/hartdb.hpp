/*******************************************************************************
*    File Name   : hartdb.hpp
*    Description : Clean HART device database for discovered AIH HART device.
*******************************************************************************/

#ifndef __HARTDB_HPP__
#define __HARTDB_HPP__

#include <stdint.h>
#include <stdbool.h>

#include "datatype.h"
#include "hartstack.hpp"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    bool valid;
    UINT8 channel;
    UINT8 modem;
    UINT8 pollAddr;
    UINT8 longAddr[5];
    UINT8 responsePreambles;

    UINT8 expandedDeviceType;
    UINT8 manufacturer;
    UINT8 deviceType;
    UINT8 hartRevision;
    UINT8 deviceRevision;
    UINT8 softwareRevision;
    UINT8 hardwareRevisionPhysical;
    UINT8 flags;
    UINT8 uniqueId[3];

    UINT8 cmd0Status0;
    UINT8 cmd0Status1;
    UINT8 cmd48Status0;
    UINT8 cmd48Status1;
    UINT8 cmd59Status0;
    UINT8 cmd59Status1;

    bool dynamicValid;
    FLOAT32 loopCurrentMa;
    FLOAT32 dynamicValue[4];
    UINT8 dynamicUnit[4];
    UINT8 dynamicCount;
} HartDeviceInfo_t;

void HartDb_Clear(void);
bool HartDb_UpdateFromCmd0(UINT8 channel,
                            UINT8 modem,
                            UINT8 pollAddr,
                            const HartParsedResponse_t *cmd0,
                            const UINT8 longAddr[5],
                            UINT8 responsePreambles);
void HartDb_UpdateCmd48Status(UINT8 status0, UINT8 status1);
void HartDb_UpdateCmd59Status(UINT8 status0, UINT8 status1);
bool HartDb_UpdateDynamicFromCmd3(const HartParsedResponse_t *cmd3);
void HartDb_PrintDynamic(void);
bool HartDb_HasDevice(void);
const HartDeviceInfo_t *HartDb_GetDevice(void);
void HartDb_Print(void);

#ifdef __cplusplus
}
#endif

#endif /* __HARTDB_HPP__ */
