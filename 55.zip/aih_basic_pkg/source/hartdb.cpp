/*******************************************************************************
*    File Name   : hartdb.cpp
*    Description : HART device database implementation.
*******************************************************************************/

#include <string.h>
#include <stdint.h>

#include "fsl_debug_console.h"
#include "hartdb.hpp"

static HartDeviceInfo_t g_hartDevice;

static FLOAT32 HartDb_ReadFloatBe(const UINT8 *bytes)
{
    union
    {
        UINT32 u32;
        FLOAT32 f32;
    } v;

    v.u32 = (((UINT32)bytes[0]) << 24) |
            (((UINT32)bytes[1]) << 16) |
            (((UINT32)bytes[2]) << 8)  |
            ((UINT32)bytes[3]);

    return v.f32;
}

static void HartDb_PrintFloat3(const char *name, FLOAT32 value)
{
    INT32 scaled;
    INT32 whole;
    INT32 frac;
    const char *sign = "";
    INT32 h;
    INT32 t;
    INT32 o;

    if (value >= 0.0f)
    {
        scaled = (INT32)((value * 1000.0f) + 0.5f);
    }
    else
    {
        scaled = (INT32)((value * 1000.0f) - 0.5f);
    }

    /*
     * fsl_debug_console in this project does not reliably support width/zero-pad
     * field-width modifiers. Print the decimal digits manually.
     */
    if (scaled < 0)
    {
        sign = "-";
        scaled = -scaled;
    }

    whole = scaled / 1000;
    frac = scaled % 1000;

    h = frac / 100;
    t = (frac / 10) % 10;
    o = frac % 10;

    PRINTF("%s%s=%d.%d%d%d", name, sign, (int)whole, (int)h, (int)t, (int)o);
}

static const char *HartDb_UnitName(UINT8 unitCode)
{
    /*
     * Only the common/observed unit codes are named here.
     * Unknown codes are still printed numerically.
     */
    switch (unitCode)
    {
        case 32u:  return "degC";
        case 33u:  return "degF";
        case 34u:  return "degR";
        case 35u:  return "K";
        case 38u:  return "mV";
        case 39u:  return "V";
        case 40u:  return "mA";
        case 41u:  return "ohm";
        case 44u:  return "Hz";
        case 45u:  return "kHz";
        case 57u:  return "percent";
        case 121u: return "unknown121";
        case 237u: return "not-used";
        default:   return "unknown";
    }
}

static void HartDb_PrintUnit(UINT8 unitCode)
{
    PRINTF(" unit=%u(%s)", (unsigned int)unitCode, HartDb_UnitName(unitCode));
}

void HartDb_Clear(void)
{
    memset(&g_hartDevice, 0, sizeof(g_hartDevice));
}

bool HartDb_UpdateFromCmd0(UINT8 channel,
                            UINT8 modem,
                            UINT8 pollAddr,
                            const HartParsedResponse_t *cmd0,
                            const UINT8 longAddr[5],
                            UINT8 responsePreambles)
{
    if ((cmd0 == NULL) || !cmd0->valid || !cmd0->checksumOk || (cmd0->command != HART_COMMAND_ZERO))
    {
        return false;
    }

    if (cmd0->payloadLen < HART_CMD0_LEGACY_RESPONSE_SIZE)
    {
        return false;
    }

    HartDb_Clear();

    g_hartDevice.valid = true;
    g_hartDevice.channel = channel;
    g_hartDevice.modem = modem;
    g_hartDevice.pollAddr = pollAddr;
    g_hartDevice.responsePreambles = responsePreambles;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        g_hartDevice.longAddr[i] = longAddr[i];
    }

    g_hartDevice.expandedDeviceType = cmd0->payload[0];
    g_hartDevice.manufacturer = cmd0->payload[1];
    g_hartDevice.deviceType = cmd0->payload[2];
    g_hartDevice.hartRevision = cmd0->payload[4];
    g_hartDevice.deviceRevision = cmd0->payload[5];
    g_hartDevice.softwareRevision = cmd0->payload[6];
    g_hartDevice.hardwareRevisionPhysical = cmd0->payload[7];
    g_hartDevice.flags = cmd0->payload[8];
    g_hartDevice.uniqueId[0] = cmd0->payload[9];
    g_hartDevice.uniqueId[1] = cmd0->payload[10];
    g_hartDevice.uniqueId[2] = cmd0->payload[11];
    g_hartDevice.cmd0Status0 = cmd0->status0;
    g_hartDevice.cmd0Status1 = cmd0->status1;

    return true;
}

void HartDb_UpdateCmd48Status(UINT8 status0, UINT8 status1)
{
    g_hartDevice.cmd48Status0 = status0;
    g_hartDevice.cmd48Status1 = status1;
}

void HartDb_UpdateCmd59Status(UINT8 status0, UINT8 status1)
{
    g_hartDevice.cmd59Status0 = status0;
    g_hartDevice.cmd59Status1 = status1;
}

bool HartDb_UpdateDynamicFromCmd3(const HartParsedResponse_t *cmd3)
{
    if ((cmd3 == NULL) || !cmd3->valid || !cmd3->checksumOk || (cmd3->command != HART_COMMAND_THREE))
    {
        return false;
    }

    if ((cmd3->status0 != 0u) || (cmd3->status1 != 0u))
    {
        g_hartDevice.dynamicValid = false;
        return false;
    }

    /* CMD3 response payload after the two HART status bytes:
     *   bytes 0..3   = loop current, IEEE754 big-endian
     *   byte  4      = PV unit
     *   bytes 5..8   = PV value
     *   byte  9      = SV unit, bytes 10..13 = SV value
     *   byte  14     = TV unit, bytes 15..18 = TV value
     *   byte  19     = QV unit, bytes 20..23 = QV value
     */
    if (cmd3->payloadLen < 9u)
    {
        g_hartDevice.dynamicValid = false;
        return false;
    }

    g_hartDevice.loopCurrentMa = HartDb_ReadFloatBe(&cmd3->payload[0]);
    g_hartDevice.dynamicUnit[0] = cmd3->payload[4];
    g_hartDevice.dynamicValue[0] = HartDb_ReadFloatBe(&cmd3->payload[5]);
    g_hartDevice.dynamicCount = 1u;

    if (cmd3->payloadLen >= 14u)
    {
        g_hartDevice.dynamicUnit[1] = cmd3->payload[9];
        g_hartDevice.dynamicValue[1] = HartDb_ReadFloatBe(&cmd3->payload[10]);
        g_hartDevice.dynamicCount = 2u;
    }

    if (cmd3->payloadLen >= 19u)
    {
        g_hartDevice.dynamicUnit[2] = cmd3->payload[14];
        g_hartDevice.dynamicValue[2] = HartDb_ReadFloatBe(&cmd3->payload[15]);
        g_hartDevice.dynamicCount = 3u;
    }

    if (cmd3->payloadLen >= 24u)
    {
        g_hartDevice.dynamicUnit[3] = cmd3->payload[19];
        g_hartDevice.dynamicValue[3] = HartDb_ReadFloatBe(&cmd3->payload[20]);
        g_hartDevice.dynamicCount = 4u;
    }

    g_hartDevice.dynamicValid = true;
    return true;
}

bool HartDb_HasDevice(void)
{
    return g_hartDevice.valid;
}

const HartDeviceInfo_t *HartDb_GetDevice(void)
{
    return &g_hartDevice;
}

void HartDb_PrintDynamic(void)
{
    if (!g_hartDevice.dynamicValid)
    {
        PRINTF("[HART_VALUE] CMD3 dynamic value not available yet.\r\n");
        return;
    }

    PRINTF("[HART_VALUE] ");
    HartDb_PrintFloat3("loop_mA", g_hartDevice.loopCurrentMa);
    PRINTF(" ");
    HartDb_PrintFloat3("PV", g_hartDevice.dynamicValue[0]);
    HartDb_PrintUnit(g_hartDevice.dynamicUnit[0]);

    if (g_hartDevice.dynamicCount > 1u)
    {
        PRINTF(" ");
        HartDb_PrintFloat3("SV", g_hartDevice.dynamicValue[1]);
        HartDb_PrintUnit(g_hartDevice.dynamicUnit[1]);
    }

    if (g_hartDevice.dynamicCount > 2u)
    {
        PRINTF(" ");
        HartDb_PrintFloat3("TV", g_hartDevice.dynamicValue[2]);
        HartDb_PrintUnit(g_hartDevice.dynamicUnit[2]);
    }

    if (g_hartDevice.dynamicCount > 3u)
    {
        PRINTF(" ");
        HartDb_PrintFloat3("QV", g_hartDevice.dynamicValue[3]);
        HartDb_PrintUnit(g_hartDevice.dynamicUnit[3]);
    }

    PRINTF("\r\n");
}

void HartDb_Print(void)
{
    if (!g_hartDevice.valid)
    {
        PRINTF("[HARTDB] No device discovered.\r\n");
        return;
    }

    PRINTF("[HARTDB] ch=%u modem=%u poll=%u longAddr=%02X %02X %02X %02X %02X hartRev=%u devRev=%u unique=%02X %02X %02X\r\n",
           (unsigned int)g_hartDevice.channel,
           (unsigned int)g_hartDevice.modem,
           (unsigned int)g_hartDevice.pollAddr,
           (unsigned int)g_hartDevice.longAddr[0],
           (unsigned int)g_hartDevice.longAddr[1],
           (unsigned int)g_hartDevice.longAddr[2],
           (unsigned int)g_hartDevice.longAddr[3],
           (unsigned int)g_hartDevice.longAddr[4],
           (unsigned int)g_hartDevice.hartRevision,
           (unsigned int)g_hartDevice.deviceRevision,
           (unsigned int)g_hartDevice.uniqueId[0],
           (unsigned int)g_hartDevice.uniqueId[1],
           (unsigned int)g_hartDevice.uniqueId[2]);

    if (g_hartDevice.dynamicValid)
    {
        HartDb_PrintDynamic();
    }
}
