AIH-only HART basic integration for RT1024 PMIO project
======================================================

Files added/changed:
1) source/hart_aih_basic.h        NEW
2) source/hart_aih_basic.cpp      NEW
3) source/pmio_kernel.cpp         REPLACED with AIH HART bring-up main
4) source/hal/hal_fpga.h          PATCHED read8/write8 upper-byte alignment and no address shift for 0x38/0x39/0x64

Why this version:
- The uploaded legacy HART files are production files and depend on BOX, SLOT, TaskScheduler, TPU2 registers,
  HART_UART macros, and the old memory-mapped H8S environment.
- This package starts AIH-only bring-up with the same important entry-point names:
    isHartCapable()
    CheckAndInitHart()
    ResetHart()
    HartTask()
    InitHartConnection()
    AbortHartConnection()
- It maps those checks to the RT1024 FPGA SPI HAL.

Expected terminal flow:
1) FPGA identity read:
   - 0x38 should show FPGA revision letter, expected around 0x6D if hardware matches earlier reference.
   - 0x39 should show revision number, expected around 0x03.
   - 0x64 should show module number low byte, expected around 0x01 for earlier reference.

2) isHartCapable():
   - Writes/reads HART mux address register 0x70.
   - PASS means the FPGA HART mux register is writable/readable over SPI.

3) CheckAndInitHart():
   - Resets FPGA HART UARTs.
   - Writes baud divisor 0x04E2 for 1200 bps.
   - Initializes all 4 UARTs with LCR 0x0B, FIFO enabled, interrupts disabled.
   - Tests each modem scratch register with 0xA5 and 0x5A.

4) InitHartConnection(1):
   - Maps AIH channel 1 to modem 0.
   - Writes HART mux address and mux enable.

5) AihHart_SendCmd0():
   - Sends a short-frame HART command 0 with polling address 0.
   - If a HART device/modem/channel is connected correctly, RX count should become non-zero.

Important first-pass result interpretation:
- If FPGA identity reads are all 0x00, SPI/pinmux/PCS is still not talking to FPGA.
- If identity reads are good but isHartCapable fails, HART mux register mapping/address needs correction.
- If SCR tests fail, UART register mapping or byte alignment is wrong.
- If SCR tests pass but CMD0 has no RX, digital FPGA UART path is okay, but analog HART modem/channel/mux/device path needs checking.
