device/system_MIMXRT1024.o device/system_MIMXRT1024.d: \
 ../device/system_MIMXRT1024.c ../device/fsl_device_registers.h \
 ../device/MIMXRT1024.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ADC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device/MIMXRT1024_COMMON.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/core_cm7.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/cmsis_version.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/cmsis_compiler.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/cmsis_gcc.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/m-profile/armv7m_mpu.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/m-profile/armv7m_cachel1.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device/system_MIMXRT1024.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device/MIMXRT1024_features.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ADC_ETC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_AIPSTZ.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_AOI.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_BEE.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CAN.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CCM.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CCM_ANALOG.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CM7_MCM.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CMP.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CSU.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DCDC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DCP.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DMA.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DMAMUX.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ENC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ENET.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_EWM.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_FLEXIO.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_FLEXRAM.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_FLEXSPI.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_GPC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_GPIO.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_GPT.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_I2S.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC_GPR.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC_SNVS.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC_SNVS_GPR.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_KPP.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_LPI2C.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_LPSPI.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_LPUART.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_OCOTP.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PGC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PIT.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PMU.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PWM.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_RTWDOG.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SEMC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SNVS.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SPDIF.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SRC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_TEMPMON.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_TMR.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_TRNG.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USB.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USBNC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USBPHY.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USB_ANALOG.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USDHC.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_WDOG.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_XBARA.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_XBARB.h \
 C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_XTALOSC24M.h
../device/fsl_device_registers.h:
../device/MIMXRT1024.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ADC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device/MIMXRT1024_COMMON.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/core_cm7.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/cmsis_version.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/cmsis_compiler.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/cmsis_gcc.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/m-profile/armv7m_mpu.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS/m-profile/armv7m_cachel1.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device/system_MIMXRT1024.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device/MIMXRT1024_features.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ADC_ETC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_AIPSTZ.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_AOI.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_BEE.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CAN.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CCM.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CCM_ANALOG.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CM7_MCM.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CMP.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_CSU.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DCDC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DCP.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DMA.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_DMAMUX.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ENC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_ENET.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_EWM.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_FLEXIO.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_FLEXRAM.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_FLEXSPI.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_GPC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_GPIO.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_GPT.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_I2S.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC_GPR.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC_SNVS.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_IOMUXC_SNVS_GPR.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_KPP.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_LPI2C.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_LPSPI.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_LPUART.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_OCOTP.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PGC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PIT.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PMU.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_PWM.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_RTWDOG.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SEMC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SNVS.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SPDIF.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_SRC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_TEMPMON.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_TMR.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_TRNG.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USB.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USBNC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USBPHY.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USB_ANALOG.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_USDHC.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_WDOG.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_XBARA.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_XBARB.h:
C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph/PERI_XTALOSC24M.h:
