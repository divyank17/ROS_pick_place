#include "source/aixslot.hpp"
static_assert(sizeof(clsAixSlot) == 8, "clsAixSlot size mismatch");
int dummy[(int)sizeof(clsAixSlot)];
