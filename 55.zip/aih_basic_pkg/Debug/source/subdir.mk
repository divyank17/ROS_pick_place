################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../source/cpp_config.cpp \
../source/hardfail.cpp \
../source/hart.cpp \
../source/hartdb.cpp \
../source/hartstack.cpp \
../source/pmio_kernel.cpp 

C_SRCS += \
../source/semihost_hardfault.c 

CPP_DEPS += \
./source/cpp_config.d \
./source/hardfail.d \
./source/hart.d \
./source/hartdb.d \
./source/hartstack.d \
./source/pmio_kernel.d 

C_DEPS += \
./source/semihost_hardfault.d 

OBJS += \
./source/cpp_config.o \
./source/hardfail.o \
./source/hart.o \
./source/hartdb.o \
./source/hartstack.o \
./source/pmio_kernel.o \
./source/semihost_hardfault.o 


# Each subdirectory must supply rules for building sources it contributes
source/%.o: ../source/%.cpp source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -D__NEWLIB__ -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\board" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\source\hal" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\source" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\drivers" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\utilities\debug_console_lite" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\utilities\str" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\component\uart" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\component\gpio" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\utilities" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS\m-profile" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\xip" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fno-rtti -fno-exceptions -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

source/%.o: ../source/%.c source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\board" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\source\hal" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\source" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\drivers" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\utilities\debug_console_lite" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\utilities\str" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\component\uart" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\component\gpio" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\utilities" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\CMSIS\m-profile" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\xip" -I"C:\Users\Andor\Downloads\aih_hart_basic_integration\aih_basic_pkg\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-source

clean-source:
	-$(RM) ./source/cpp_config.d ./source/cpp_config.o ./source/hardfail.d ./source/hardfail.o ./source/hart.d ./source/hart.o ./source/hartdb.d ./source/hartdb.o ./source/hartstack.d ./source/hartstack.o ./source/pmio_kernel.d ./source/pmio_kernel.o ./source/semihost_hardfault.d ./source/semihost_hardfault.o

.PHONY: clean-source

