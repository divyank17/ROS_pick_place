# A6 HART Legacy-Flow Integration

## Objective

Integrate the working RT1024 HART hardware transport into the same logical flow used by the `s1` legacy source, retain the legacy class/function/member names, and keep HART console output limited to:

```text
HART CHANNEL=<channel> MODEM=<modem> PV=<value> LOOP_CURRENT_MA=<value>
```

No HART probe, route, raw-frame, CMD0, CMD3 detail, failed-channel, or scan-summary messages are enabled in this build.

## Legacy flow retained

The A6 path is:

```text
HartTask()
  -> InitHartConnection(channel)
  -> clsHartQueue::AddToQueue()
  -> clsHartQueue::ProcessQueue()
  -> clsHartModem::Connect(channel)
  -> RT1024 FPGA/UART transaction adapter
  -> clsHartDevDb::LoadParsedResponse()
  -> clsHartDevDb::UpdateDatabase()
  -> Cmd0GoodHandler()/Cmd48GoodHandler()/.../Cmd3GoodHandler()
  -> clsHartDevDb database members
```

After CMD0 identifies the device and establishes `m_UniqueAddress`, the build uses the original revision-specific initialization tables and variables:

- `HART5_INIT_COMMANDS`
- `HART6_INIT_COMMANDS`
- `HART7_INIT_COMMANDS`
- `m_HChanMode`
- `m_ucInitCmdIndex`
- `m_ucLastReqCmd`
- `m_ucpLastXmtPtr`

The initialization order is the legacy order:

```text
CMD48 -> CMD59 -> CMD6 -> CMD38 -> CMD12 -> CMD13 ->
CMD14 -> CMD15 -> CMD16 -> CMD20 -> CMD50 -> CMD3
```

The write commands CMD59, CMD6, and CMD38 are enabled because they are part of the original legacy initialization flow.

## Database ownership

The detected channel's own `clsHartDevDb` is authoritative. Responses are no longer handled only by the RT1024 compatibility singleton.

CMD3 processing uses the original storage names:

- `HDynVal[0]`: PV
- `HDynEu[0]`: PV unit
- `HDynSt[0]`: PV availability
- `HDynVal[1..3]`: SV/TV/QV

The HART wire float is big-endian. `Cmd3GoodHandler()` now reverses the four wire bytes when building the little-endian RT1024 `FLOAT32`. This produces the expected values from the supplied console frame:

- loop current: `40 80 00 00` -> `4.000 mA`
- PV: `00 00 00 00` -> `0.000`
- QV: `41 AC 35 A9` -> approximately `21.526`

The original legacy database does not define a dedicated loop-current database member. For the requested test print only, loop current is retained by the parsed CMD3 transport record while PV is read from `clsHartDevDb::HDynVal[0]`.

## Restored legacy slot/modem interface

The following AIH slot methods have been restored with the original names:

- `GetChannelNumber()`
- `GetHartChanType()`
- `GetPollingAddress()`
- `SetPollingAddress()`
- `GetUniqueAddress()`
- `GetNoOfPreambleBytes()`
- `GetXmtDataPtr()`
- `ReceptionComplete()`
- `LogEvent()`
- `GetRetryCount()`

`clsHartModem::Connect()` again loads the polling address, unique address, and retry count from the connected channel object before selecting the RT1024 FPGA route.

## Hardware-specific exception

The old H8 DUART register and interrupt implementation cannot be copied directly to i.MX RT1024. The physical transmit/receive operation therefore remains in the proven RT1024 FPGA/UART adapter. All command scheduling, channel database ownership, legacy handler dispatch, and stored variable names around that hardware boundary follow the legacy design.

The staged startup scan is retained because the supplied integrated console runs with `DSA ADDRESS: 0`; the normal legacy heartbeat intentionally does not initiate channel communication while DSA is invalid. The staged scan tests one logical channel per `HartTask()` invocation and continues through channels 1 to 16.

## Expected console result

For the device previously detected on channel 10:

```text
HART CHANNEL=10 MODEM=2 PV=0.000 LOOP_CURRENT_MA=4.000
```

Only a complete CMD0 + initialization-table + valid CMD3 path produces this HART line.

## Verification performed

- All 22 project C++ translation units passed a host-side syntax check with the Cortex-M architecture profile and project build defines.
- HART wire-float byte order was checked against the supplied CMD3 bytes.
- The output ZIP and source patch were generated from the modified A6 project.

The actual `arm-none-eabi-c++` compiler and target hardware are not available in this environment, so the final MCUXpresso ARM build and on-device behavior must be confirmed by clean-building and flashing on the PMIO device.
