/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hart.h                                                      *
*    Description : HART protocol declarations.                                 *
*******************************************************************************/
#ifndef __HART_H__
#define __HART_H__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "datatype.h"
#if defined(__cplusplus) && defined(IOMTYPE_AIH)
#include "scheduler.hpp"
#endif
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
#if defined(IOMTYPE_UIO)
extern BOOL HartLoopBkTestInProgress;
#endif
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
const UINT16 HART_BYTE_TIME         = 9167; // HART byte time in microseconds.
const UINT8 HART_PRIMARY_QUIET_TIME = 33;
const UINT8 HART_LINK_GRANT_TIME    = 8;
const UINT8 HART_SLAVE_TIME_OUT     = 28;

const UINT8 HART_PREAMBLE_BYTE = 0xFF;
const UINT8 HART_MIN_PREAMBLES = 2;
const UINT8 HART_MAX_RETRIES   = 3;
const UINT8 HART_MAX_BYTECOUNT = 255;

#if defined(IOMTYPE_UIO)
const UINT8 MAX_FDM_SESSIONS  = 16;
const UINT8 MAX_SCAN_CONFIG_ALLOWED = 4;
#endif

const UINT8 HART_FRAME_TYPE_BACK = 0x01;
const UINT8 HART_FRAME_TYPE_STX  = 0x02;
const UINT8 HART_FRAME_TYPE_ACK  = 0x06;
const UINT8 HART_FRAME_TYPE_MASK = 0x07;

const UINT8 HART_ADDR_TYPE_MASK    = 0x80;
const UINT8 HART_POLLING_DELIMITER = 0x02;
const UINT8 HART_POLLING_ADDR_MASK = 0x3F;
const UINT8 HART_POLADDR_LENGTH     = 1;
const UINT8 HART_POLADDR_MAXVAL     = 15;
const UINT8 HART_UNIQUE_DELIMITER  = 0x82;
const UINT8 HART_LONGADDR_LENGTH   = 5;
const UINT8 HART_MASTER_ADDR_MASK  = 0x80;

const UINT8 HART_MANUFACTURE_ID_MASK    = 0x3F;
const UINT8 HART_BURST_MODE_MASK        = 0x40;
const UINT8 HART_GENERIC_MANUFACTURE_ID = 250;
const UINT8 HART_EXPANSION_BYTE_MASK    = 0x60;
const UINT8 HART_EXPANSION_BYTE_SHIFTS  = 0x05;
const UINT8 HART_PHYSICAL_LAYER_MASK    = 0x18;
const UINT8 HART_COMMN_STATUS_BIT       = 0x80;

const UINT8 HART_DEVSTS_DEV_MALFUNCTION = 0x80;
const UINT8 HART_DEVSTS_CFG_CHANGED     = 0x40;
const UINT8 HART_DEVSTS_COLD_START      = 0x20;
const UINT8 HART_DEVSTS_MORE_STATUS     = 0x10;
const UINT8 HART_DEVSTS_LOOP_FIXED      = 0x08;
const UINT8 HART_DEVSTS_LOOP_SATURATED  = 0x04;
const UINT8 HART_DEVSTS_XV_OUT_OF_LIMIT = 0x02;
const UINT8 HART_DEVSTS_PV_OUT_OF_LIMIT = 0x01;

const UINT8 ADCEN_NOCHANGE = 0;
const UINT8 ADCEN_OFF_ON   = 1;
const UINT8 ADCEN_ON_OFF   = 2;

const UINT8 HART_DATA_UNKNOWN       = 255;
const UINT8 HART_DATA_NOT_AVAILABLE = 0;
const UINT8 HART_DATA_AVAILABLE     = 1;
const UINT8 HART_DATA_PENDING       = 2;

const UINT8 HART_CMD0_RESPONSE_SIZE        = 22;
const UINT8 HART_CMD3_4VAR_RESPONSE_SIZE   = 24;
const UINT8 HART_CMD3_3VAR_RESPONSE_SIZE   = 19;
const UINT8 HART_CMD3_2VAR_RESPONSE_SIZE   = 14;
const UINT8 HART_CMD3_1VAR_RESPONSE_SIZE   = 9;
const UINT8 HART_CMD6_RESPONSE_SIZE        = 2;
const UINT8 HART_CMD9_8VAR_RESPONSE_SIZE   = 69;
const UINT8 HART_CMD9_7VAR_RESPONSE_SIZE   = 61;
const UINT8 HART_CMD9_6VAR_RESPONSE_SIZE   = 53;
const UINT8 HART_CMD9_5VAR_RESPONSE_SIZE   = 45;
const UINT8 HART_CMD9_4VAR_RESPONSE_SIZE   = 33;
const UINT8 HART_CMD9_3VAR_RESPONSE_SIZE   = 25;
const UINT8 HART_CMD9_2VAR_RESPONSE_SIZE   = 17;
const UINT8 HART_CMD9_1VAR_RESPONSE_SIZE   = 9;
const UINT8 HART_CMD12_RESPONSE_SIZE       = 24;
const UINT8 HART_CMD13_RESPONSE_SIZE       = 21;
const UINT8 HART_CMD14_RESPONSE_SIZE       = 16;
const UINT8 HART_CMD15_RESPONSE_SIZE       = 18;
const UINT8 HART_CMD16_RESPONSE_SIZE       = 3;
const UINT8 HART_CMD20_RESPONSE_SIZE       = 32;
const UINT8 HART_CMD33_4VAR_RESPONSE_SIZE  = 24;
const UINT8 HART_CMD33_3VAR_RESPONSE_SIZE  = 18;
const UINT8 HART_CMD33_2VAR_RESPONSE_SIZE  = 12;
const UINT8 HART_CMD33_1VAR_RESPONSE_SIZE  = 6;
const UINT8 HART_CMD38_RESPONSE_SIZE       = 2;
const UINT8 HART_CMD48_RESPONSE_SIZE       = 25;
const UINT8 HART7_CMD48_REQUESTDATA_SIZE   = 25;
const UINT8 HART_CMD50_RESPONSE_SIZE       = 4;
const UINT8 HART_CMD59_RESPONSE_SIZE       = 1;
const UINT8 HART_CMD109_RESPONSE_SIZE      = 1;

const UINT8 HART_MIN_RESPONSE_BYTECOUNT         = 2;
const UINT8 HART_RESPCODE_SUCCESS               = 0;
const UINT8 HART_RESPCODE_WRITE_PROTECTED       = 7;
const UINT8 HART_RESPCODE_DATA_DID_NOT_CHANGE   = 8;
const UINT8 HART_RESPCODE_CONFIGCHGCNT_MISMATCH = 9;
const UINT8 HART_RESPCODE_RESTRUNCATED          = 30; // added this definition from legacy to fix, HART Variable values (HSlotVal) are displaying NaN.
const UINT8 HART_RESPCODE_DEVICE_BUSY           = 32;
const UINT8 HART_RESPCODE_CMD_NOT_IMPLEMENTED   = 64;
const UINT8 HART_INVALID_PARAMETER_CODE         = 250;

const UINT8 HART_DEVICEID_SIZE        = 3;
const UINT8 HART_PACKED_TAG_SIZE      = 6;
const UINT8 HART_UNPACKED_TAG_SIZE    = 8;
const UINT8 HART_DESCRIPTOR_SIZE      = 12;
const UINT8 HART_TRSERIALNUMBER_SIZE  = 3;
const UINT8 HART_FINALASSEMBLYNO_SIZE = 3;
const UINT8 HART_HWREVLEVEL_SIZE      = 5;
const UINT8 HART_SINGALINGCODE_SIZE   = 3;

const UINT8 HART_LOOP_CURRENT_DISABLED = 0;
const UINT8 HART_LOOP_CURRENT_ENABLED  = 1;

const UINT8 HART_BURSTMODE_OFF     = 0;
const UINT8 HART_BURSTMODE_ON      = 1;
const UINT8 HART_BURSTMODE_NOTUSED = 250;
const UINT8 HART_BURSTMODE_NONE    = 251;
const UINT8 HART_BURSTMODE_UNKNOWN = 252;
const UINT8 HART_BURSTMODE_SPECIAL = 253;
const UINT8 HART_SIZEOFVAR0 = 8;
//HART_SIZEOFVAR0 is the sum of the sizes of ucVar0Code,ucVar0Class,ucfVar0Val and
//ucVar0sts in Cmd9ResponseTag.

/******************************************************************
*                   HART VERSION DEFNITIONS                       *
******************************************************************/

#define    HARTVERSION_UNDEFINED   0
#define    HARTVERSION_5X          5
#define    HARTVERSION_6X          6
#define    HARTVERSION_7X          7
#define    HARTVERSION_MISMATCH    0xFF

// As of now HART protocol version 7 is supported. Devices with HART protocol versions 
// greater than 7 will be treated like version 7 device
#define HARTVERSION_LASTESTSUPPORTED HARTVERSION_7X

typedef enum tagHartCmd {
    HARTCOMMAND_ZERO        = 0,
    HARTCOMMAND_THREE       = 3,
    HARTCOMMAND_SIX         = 6,
    HARTCOMMAND_NINE        = 9,
    HARTCOMMAND_TWELVE      = 12,
    HARTCOMMAND_THIRTEEN    = 13,
    HARTCOMMAND_FOURTEEN    = 14,
    HARTCOMMAND_FIFTEEN     = 15,
    HARTCOMMAND_SIXTEEN     = 16,
    HARTCOMMAND_TWENTY      = 20,
    HARTCOMMAND_THIRTYTHREE = 33,
    HARTCOMMAND_THIRTYEIGHT = 38,
    HARTCOMMAND_FOURTYEIGHT = 48,
    HARTCOMMAND_FIFTY       = 50,
    HARTCOMMAND_FIFTYNINE   = 59,
    HARTCOMMAND_HUNDREDNINE = 109,
    HARTCOMMAND_DEFAULT     = 250,
    HARTCOMMAND_INVALID     = 0xFF
} HARTCOMMAND;

typedef union UniqueAddrTag {
    UINT8 ucBytes[HART_LONGADDR_LENGTH];
    struct {
        UINT8 ucExpDeviceType1;
        UINT8 ucExpDeviceType2;
        UINT8 ucDeviceId[HART_DEVICEID_SIZE];
    } str;
} HARTUNIQUEADDR;

typedef struct HartDateTag {
    UINT8 ucDay;
    UINT8 ucMonth;
    UINT8 ucYear;
} HARTDATE;

// HART command response structures.
// NOTE : To work around the multi-byte addressing from odd memory locations in H8,
// some of the multi-byte  elements in this structure are defined as UINT8 arrays.
// Whereever multi-byte members are used, it need to be assured that they are on an
// even index from the start of the structure. 
typedef union Cmd0ResponseTag {
    UINT8 ucBytes[HART_CMD0_RESPONSE_SIZE];
    struct {
        UINT8 ucTwoFiveFour;
        UINT8 ucusExpDeviceType[sizeof(UINT16)];
        UINT8 ucReqdPreambleBytes;
        UINT8 ucHARTMajorRevision;
        UINT8 ucDeviceRevisionLevel;
        UINT8 ucSoftwareRevLevel;
        UINT8 ucHardwareRevLevel : HART_HWREVLEVEL_SIZE;
        UINT8 ucSignalingCode    : HART_SINGALINGCODE_SIZE;
        UINT8 ucFlags;
        UINT8 ucDeviceId[HART_DEVICEID_SIZE];
        UINT8 ucResponsePreambleBytes;
        UINT8 ucMaxDevVariables;
        UINT8 ucusConfigChgCnt[sizeof(UINT16)];
        UINT8 ucExtendedStatus;
        UINT8 ucusManufactureId[sizeof(UINT16)];
        UINT8 ucusPrivateLblDisCode[sizeof(UINT16)];
        UINT8 ucDevProfile;
    } str;
} HARTCMD0RESPONSE;

typedef union Cmd3ResponseTag {
    UINT8 ucBytes[HART_CMD3_4VAR_RESPONSE_SIZE];
    struct {
        UINT8 ucfLoopCurrent[sizeof(FLOAT32)];
        UINT8 ucPvUnitCode;
        UINT8 ucfPvVal[sizeof(FLOAT32)];
        UINT8 ucSvUnitCode;
        UINT8 ucfSvVal[sizeof(FLOAT32)];
        UINT8 ucTvUnitCode;
        UINT8 ucfTvVal[sizeof(FLOAT32)];
        UINT8 ucQvUnitCode;
        UINT8 ucfQvVal[sizeof(FLOAT32)];
    } str;
} HARTCMD3RESPONSE;

typedef union Cmd6ResponseTag {
    UINT8 ucBytes[HART_CMD6_RESPONSE_SIZE];
    struct {
        UINT8 ucPollingAddress;
        UINT8 ucLoopCurMode;
    } str;
} HARTCMD6RESPONSE;

typedef union Cmd9ResponseTag {
    UINT8 ucBytes[HART_CMD9_8VAR_RESPONSE_SIZE];
    struct {
        UINT8 ucExtDevSts;
        UINT8 ucVar0Code;
        UINT8 ucVar0Class;
        UINT8 ucVar0Unit;
        UINT8 ucfVar0Val[sizeof(FLOAT32)];
        UINT8 ucVar0Sts;
        UINT8 ucVar1Code;
        UINT8 ucVar1Class;
        UINT8 ucVar1Unit;
        UINT8 ucfVar1Val[sizeof(FLOAT32)];
        UINT8 ucVar1Sts;
        UINT8 ucVar2Code;
        UINT8 ucVar2Class;
        UINT8 ucVar2Unit;
        UINT8 ucfVar2Val[sizeof(FLOAT32)];
        UINT8 ucVar2Sts;
        UINT8 ucVar3Code;
        UINT8 ucVar3Class;
        UINT8 ucVar3Unit;
        UINT8 ucfVar3Val[sizeof(FLOAT32)];
        UINT8 ucVar3Sts;
        UINT8 ucVar4Code;
        UINT8 ucVar4Class;
        UINT8 ucVar4Unit;
        UINT8 ucfVar4Val[sizeof(FLOAT32)];
        UINT8 ucVar4Sts;
        UINT8 ucVar5Code;
        UINT8 ucVar5Class;
        UINT8 ucVar5Unit;
        UINT8 ucfVar5Val[sizeof(FLOAT32)];
        UINT8 ucVar5Sts;
        UINT8 ucVar6Code;
        UINT8 ucVar6Class;
        UINT8 ucVar6Unit;
        UINT8 ucfVar6Val[sizeof(FLOAT32)];
        UINT8 ucVar6Sts;
        UINT8 ucVar7Code;
        UINT8 ucVar7Class;
        UINT8 ucVar7Unit;
        UINT8 ucfVar7Val[sizeof(FLOAT32)];
        UINT8 ucVar7Sts;
        UINT8 ucfSlt0DataTimeStmp[sizeof(FLOAT32)];
    } str;
} HARTCMD9RESPONSE;

typedef union Cmd12ResponseTag {
    UINT8 ucBytes[HART_CMD12_RESPONSE_SIZE];
    struct {
        UINT8 ucMessage[HART_CMD12_RESPONSE_SIZE];
    } str;
} HARTCMD12RESPONSE;

typedef union Cmd13ResponseTag {
    UINT8 ucBytes[HART_CMD13_RESPONSE_SIZE];
    struct {
        UINT8    ucTag[HART_PACKED_TAG_SIZE];
        UINT8    ucDescriptor[HART_DESCRIPTOR_SIZE];
        HARTDATE HartDate;
    } str;
} HARTCMD13RESPONSE;

typedef union Cmd14ResponseTag {
    UINT8 ucBytes[HART_CMD14_RESPONSE_SIZE];
    struct {
        UINT8 ucTrSerialNumber[HART_TRSERIALNUMBER_SIZE];
        UINT8 ucTrUnitsCode;
        UINT8 ucfUpperTrLimit[sizeof(FLOAT32)];
        UINT8 ucfLowerTrLimit[sizeof(FLOAT32)];
        UINT8 ucfMinimumSpan[sizeof(FLOAT32)];
    } str;
} HARTCMD14RESPONSE;

typedef union Cmd15ResponseTag {
    UINT8 ucBytes[HART_CMD15_RESPONSE_SIZE];
    struct {
        UINT8 ucPvAlarmCode;
        UINT8 ucPvTrFunCode;
        UINT8 ucPvRngUnitCode;
        UINT8 ucfPvURngVal[sizeof(FLOAT32)];
        UINT8 ucfPvLRngVal[sizeof(FLOAT32)];
        UINT8 ucfPvDampVal[sizeof(FLOAT32)];
        UINT8 ucWrProtCode;
        UINT8 ucPvtDistrLabel;//TwoFiveZero for HART revision > 7
        UINT8 ucPvFlags;
    } str;
} HARTCMD15RESPONSE;

typedef union Cmd16ResponseTag {
    UINT8 ucBytes[HART_CMD16_RESPONSE_SIZE];
    struct {
        UINT8 ucFinAssemblyNo[HART_FINALASSEMBLYNO_SIZE];
    } str;
} HARTCMD16RESPONSE;

typedef struct Cmd20ResponseTag {
    UINT8 ucBytes[HART_CMD20_RESPONSE_SIZE];
}HARTLONGTAG_RESPONSE;

typedef union Cmd33ResponseTag {
    UINT8 ucBytes[HART_CMD33_4VAR_RESPONSE_SIZE];
    struct {
        UINT8   ucVar0Code;
        UINT8   ucVar0Unit;
      //FLOAT32 fVar0Val;
		UINT8   ucfVar0Val[sizeof(FLOAT32)];
        UINT8   ucVar1Code;
        UINT8   ucVar1Unit;
      //FLOAT32 fVar1Val;
		UINT8   ucfVar1Val[sizeof(FLOAT32)];
        UINT8   ucVar2Code;
        UINT8   ucVar2Unit;
      //FLOAT32 fVar2Val;
		UINT8   ucfVar2Val[sizeof(FLOAT32)];
        UINT8   ucVar3Code;
        UINT8   ucVar3Unit;
      //FLOAT32 fVar3Val;
		UINT8   ucfVar3Val[sizeof(FLOAT32)];
    } str;
} HARTCMD33RESPONSE;

typedef union Cmd38ResponseTag {
    UINT8 ucBytes[HART_CMD38_RESPONSE_SIZE];
    struct {
        UINT8 ucusConfigChgCnt[sizeof(UINT16)];
    } str;
} HARTCMD38RESPONSE;

typedef union Cmd48ResponseTag {
    UINT8 ucBytes[HART_CMD48_RESPONSE_SIZE];
    struct {
        UINT8 ucCmd48Response[HART_CMD48_RESPONSE_SIZE];
    } str;
} HARTCMD48RESPONSE;

typedef union Cmd50ResponseTag {
    UINT8 ucBytes[HART_CMD50_RESPONSE_SIZE];
    struct {
        UINT8 ucDynVar0Code;
        UINT8 ucDynVar1Code;
        UINT8 ucDynVar2Code;
        UINT8 ucDynVar3Code;
    } str;
} HARTCMD50RESPONSE;

typedef union Cmd59ResponseTag {
    UINT8 ucBytes[HART_CMD59_RESPONSE_SIZE];
    struct {
        UINT8 ucNoOfPreambleBytes;
    } str;
} HARTCMD59RESPONSE;

typedef union Cmd109ResponseTag {
    UINT8 ucBytes[HART_CMD109_RESPONSE_SIZE];
    struct {
        UINT8 ucBurstModeCode;
    } str;
} HARTCMD109RESPONSE;


#ifndef HART_SCAN_CHANNEL_START
#define HART_SCAN_CHANNEL_START                 (1u)
#endif
#ifndef HART_SCAN_CHANNEL_END
#define HART_SCAN_CHANNEL_END                   (16u)
#endif
#ifndef HART_TEST_CHANNEL
#define HART_TEST_CHANNEL                       HART_SCAN_CHANNEL_START
#endif
#ifndef HART_TEST_MODEM
#define HART_TEST_MODEM                         ((UINT8)((HART_TEST_CHANNEL - 1u) / 4u))
#endif

/* A5 integration validation switches.
 * The hardware build scans one logical channel per HartTask invocation after
 * BOX->AppInitialization() and Iol.Enable() have completed.  The clean build
 * keeps the same legacy task/queue flow but does not run the test scan. */
#ifndef HART_HARDWARE_VALIDATION_BUILD
#define HART_HARDWARE_VALIDATION_BUILD            (1u)
#endif
#ifndef HART_HARDWARE_VALIDATION_DELAY_CYCLES
#define HART_HARDWARE_VALIDATION_DELAY_CYCLES      (1u)
#endif
#ifndef HART_HARDWARE_VALIDATION_CONFIRMATIONS
#define HART_HARDWARE_VALIDATION_CONFIRMATIONS     (2u)
#endif
#ifndef HART_HARDWARE_VALIDATION_CONTINUE_LEGACY_TASK_AFTER_SCAN
#define HART_HARDWARE_VALIDATION_CONTINUE_LEGACY_TASK_AFTER_SCAN (1u)
#endif
#ifndef HART_EMPTY_ROUTE_RETRY_COUNT
#define HART_EMPTY_ROUTE_RETRY_COUNT                (1u)
#endif
#ifndef HART_ENABLE_FINAL_RESPONSE_PRINT
#define HART_ENABLE_FINAL_RESPONSE_PRINT           (1u)
#endif
#ifndef HART_ENABLE_CMD3_RESPONSE_PRINT
#define HART_ENABLE_CMD3_RESPONSE_PRINT            (0u)
#endif
#ifndef HART_ENABLE_ROUTE_DIAG_PRINT
#define HART_ENABLE_ROUTE_DIAG_PRINT               (0u)
#endif
#ifndef HART_ENABLE_RAW_RX_DIAG_PRINT
#define HART_ENABLE_RAW_RX_DIAG_PRINT              (0u)
#endif
#ifndef HART_ENABLE_NO_RX_DIAG_PRINT
#define HART_ENABLE_NO_RX_DIAG_PRINT               (0u)
#endif
#ifndef HART_PRINT_FAILED_PROBES
#define HART_PRINT_FAILED_PROBES                   (0u)
#endif
#ifndef HART_ENABLE_SCAN_DIAG_PRINT
#define HART_ENABLE_SCAN_DIAG_PRINT                (0u)
#endif
#ifndef HART_WIRE_FLOAT_BIG_ENDIAN
#define HART_WIRE_FLOAT_BIG_ENDIAN                 (1u)
#endif
#ifndef HART_POLL_ADDR_END
#define HART_POLL_ADDR_END                         (0u)
#endif

/* Retained compatibility switches.  Immediate/full blocking scans are
 * intentionally disabled; HART task registration must remain enabled. */
#ifndef HART_HARDWARE_TEST_IMMEDIATE_SCAN
#define HART_HARDWARE_TEST_IMMEDIATE_SCAN          (0u)
#endif
#ifndef HART_HARDWARE_TEST_DELAYED_SCAN
#define HART_HARDWARE_TEST_DELAYED_SCAN            (0u)
#endif
#ifndef HART_HARDWARE_TEST_TARGET_CHANNEL
#define HART_HARDWARE_TEST_TARGET_CHANNEL          (14u)
#endif
#ifndef HART_HARDWARE_TEST_SCAN_ALL_CHANNELS
#define HART_HARDWARE_TEST_SCAN_ALL_CHANNELS       (1u)
#endif
#ifndef HART_HARDWARE_TEST_DELAY_TASK_CYCLES
#define HART_HARDWARE_TEST_DELAY_TASK_CYCLES       (8u)
#endif
#ifndef HART_HARDWARE_TEST_DISABLE_HART_TASK
#define HART_HARDWARE_TEST_DISABLE_HART_TASK       (0u)
#endif

typedef enum tagHartDiscoveryResult {
    HART_DISCOVERY_FAILED   = 0,
    HART_DISCOVERY_CMD0_OK  = 1,
    HART_DISCOVERY_COMPLETE = 2
} HARTDISCOVERYRESULT;

#ifdef __cplusplus
extern "C" {
#endif

VOID HartInit(VOID);
VOID HartSetRoute(UINT8 channel, UINT8 modem);
UINT8 HartGetActiveChannel(VOID);
UINT8 HartGetActiveModem(VOID);
HARTDISCOVERYRESULT HartDiscover(VOID);
HARTDISCOVERYRESULT HartDiscoverOnRoute(UINT8 channel, UINT8 modem);
HARTDISCOVERYRESULT HartScanChannels(UINT8 channelStart, UINT8 channelEnd);
UINT8 HartGetModemForChannel(UINT8 channel);
VOID HartDiscoveryTask(VOID);
BOOL HartReadDynamicValues(VOID);
VOID HartReportFinalResponse(UINT8 channel, UINT8 modem, HARTDISCOVERYRESULT result);
VOID HartReportCmd3Response(UINT8 channel, UINT8 modem);
VOID HartReportLegacyDynamicResult(UINT8 channel, UINT8 modem);
VOID TestHartAddressMux(VOID);

#ifndef HART_ENABLE_LEGACY_TASK_API
#define HART_ENABLE_LEGACY_TASK_API (1u)
#endif

#if HART_ENABLE_LEGACY_TASK_API
#ifndef __SCHEDULER_HPP__
typedef enum tagTaskReturnState {
    TASKRETURNSTATE_TERMINATE = 0,
    TASKRETURNSTATE_SUSPEND   = 1
} TASKRETURNSTATE;
typedef enum tagTaskContext {
    TASKCONTEXT_ZERO  = 0,
    TASKCONTEXT_ONE   = 1,
    TASKCONTEXT_TWO   = 2,
    TASKCONTEXT_THREE = 3,
    TASKCONTEXT_FOUR  = 4,
    TASKCONTEXT_FIVE  = 5,
    TASKCONTEXT_SIX   = 6,
    TASKCONTEXT_SEVEN = 7
} TASKCONTEXT;
typedef struct tagTaskReturn {
    TASKRETURNSTATE TaskReturnState;
    TASKCONTEXT     TaskContext;
    UINT8           ucReserved;
    UINT8           ucSuspendTime;
} TASKRETURN;
#endif
TASKRETURN HartTask(TASKCONTEXT a_TaskContext);
#endif

VOID HartSetLastTransactionResult(UINT8 channel, UINT8 modem, HARTDISCOVERYRESULT result);
HARTDISCOVERYRESULT HartGetLastTransactionResult(VOID);
UINT8 HartGetLastGoodChannel(VOID);
UINT8 HartGetLastGoodModem(VOID);
BOOL HartHasLastGoodRoute(VOID);

BOOL isHartCapable(VOID);
VOID CheckAndInitHart(VOID);
VOID HartRunHardwareValidation(VOID);
VOID ResetHart(VOID);
BOOL InitHartConnection(UINT8 a_ucChan);
BOOL AbortHartConnection(UINT8 a_ucChan);
VOID ProcessHartInterrupt(VOID);

#ifdef __cplusplus
}
#endif

#endif
