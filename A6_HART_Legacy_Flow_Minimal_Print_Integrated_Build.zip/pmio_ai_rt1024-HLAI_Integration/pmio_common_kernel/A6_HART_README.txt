A6 HART legacy-flow integrated build

Clean build this project in MCUXpresso and flash it to the PMIO device.

Expected HART output for the currently connected instrument:
HART CHANNEL=10 MODEM=2 PV=0.000 LOOP_CURRENT_MA=4.000

HART diagnostics are disabled. Only a fully initialized device with a valid
CMD3 result prints a HART line.

See A6_HART_LEGACY_FLOW_REPORT.md for the implementation details and the
RT1024 hardware-adapter boundary.
