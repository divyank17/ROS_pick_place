X2 HART COMPLETE FIX
====================

Files changed
-------------
1. source/hart.h
2. source/hart.cpp
3. source/hartstack.cpp

Root causes corrected
---------------------
1. The scan started from channel 1 although the connected instrument is known to
   be on channel 10. Silent channels therefore consumed receive timeouts before
   any successful HART result could be printed.

2. All scan progress prints were disabled. During the synchronous transaction,
   the console showed only unrelated DMC messages and looked blocked.

3. ProcessHartInterrupt() processed the queue directly and then called
   HartModemHeartbeat(), which also processes idle queues. Queue servicing was
   duplicated.

4. The synchronous modem transaction did not refresh the HART task DMC while it
   was waiting through HART character-time states.

5. HART_RUN_INIT_COMMAND_TABLE_AFTER_PV existed but did not control command
   ordering. It now selects whether the complete initialization table executes
   before or after CMD3. The table is always executed, so the full command flow
   is retained.

Current defaults
----------------
HART_SCAN_PRIORITY_CHANNEL              = 10
HART_ENABLE_SCAN_PROGRESS_PRINT         = 1
HART_RUN_INIT_COMMAND_TABLE_AFTER_PV     = 0
HART_SERVICE_DMC_DURING_TRANSACTION      = 1
HART_ENABLE_FINAL_RESPONSE_PRINT         = 1

With HART_RUN_INIT_COMMAND_TABLE_AFTER_PV = 0, the sequence is:
CMD0 -> full revision-specific initialization table -> CMD3 -> result print.

With HART_RUN_INIT_COMMAND_TABLE_AFTER_PV = 1, the sequence is:
CMD0 -> CMD3 -> immediate result print -> full initialization table.

Expected console
----------------
HART SCAN START=1 END=16 FIRST=10
HART CHECK CHANNEL=10 MODEM=2
HART CHANNEL=10 MODEM=2 PV=0.000 LOOP_CURRENT_MA=4.000
HART CHECK CHANNEL=1 MODEM=0
...
HART SCAN COMPLETE DEVICES=1 CHANNEL_MASK=0200

The priority channel is checked first, but the remaining channels are still
scanned exactly once. Channel 10 is skipped when the scan later advances through
channels 1 to 16, preventing a duplicate transaction.

Build steps
-----------
1. Import/open the project in MCUXpresso.
2. Project -> Clean.
3. Build the Debug configuration.
4. Confirm the console contains:
      Building file: ../source/hart.cpp
      Building file: ../source/hartstack.cpp
5. Flash the newly generated AXF.
6. Power-cycle the PMIO module.

Validation performed
--------------------
All 22 C++ translation units passed a host-side Cortex-M-profile syntax check.
The ARM GCC linker and target hardware were not available in the analysis
environment, so the final MCUXpresso ARM build and device test must be performed
on the development workstation and PMIO hardware.
