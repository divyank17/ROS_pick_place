X4 HART exact legacy-flow bench build

Purpose
- Run the original HartTask -> ChannelHeartbeat -> HartQueue -> clsHartModem -> clsHartDevDb flow.
- Process channels in legacy order: 1-4, 5-8, 9-12, 13-16.
- Do not print probe, route, timeout, raw RX, or scan-complete messages.
- Print only after a valid dynamic-variable response stores PV in HDynVal[0].

Corrected issues
1. The HLAI-specific branches now recognize IOMTYPE_AIH, which is the symbol used by this RT1024 project.
2. DSA 0 bench allowance is applied consistently in HartTask and ChannelHeartbeat.
3. Initial database setup leaves m_ucLastDsa at 0 so the first heartbeat performs the original primary-transition initialization and BuildScanTable path.
4. The matching hartstack.cpp remains included; it contains the RT1024 FPGA/UART transport used beneath the legacy queue/database architecture.

Expected successful output
HART CHANNEL=<channel> MODEM=<modem> PV=<value> LOOP_CURRENT_MA=<value>

Build
1. Import/open the project.
2. Project -> Clean.
3. Build Project.
4. Confirm hart.cpp, hartdb.cpp, and hartstack.cpp rebuild.
5. Flash the newly generated AXF and power-cycle the module.

Production note
HART_LEGACY_BENCH_TEST_ALLOW_DSA0 is enabled for the current bench where DSA prints as 0. Disable it when the module is configured with a valid production DSA.
