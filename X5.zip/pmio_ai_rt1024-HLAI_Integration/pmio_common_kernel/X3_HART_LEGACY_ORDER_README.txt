X3 HART legacy-order build

HART execution:
1. HartTask processes four channels per 250 ms invocation, exactly in the legacy order:
   1-4, 5-8, 9-12, 13-16, then repeats.
2. Each channel executes clsHartDevDb::ChannelHeartbeat().
3. ChannelHeartbeat queues the request through InitHartConnection().
4. HartQueue assigns the request to the mapped modem.
5. The RT1024 transport performs the transaction.
6. Responses are passed to clsHartDevDb and the original Cmd*GoodHandler functions.
7. Only a successful CMD3/PV database update prints:
   HART CHANNEL=<channel> MODEM=<modem> PV=<pv> LOOP_CURRENT_MA=<current>

All scan-start, channel-check, no-device, route, raw-RX and scan-complete prints are disabled.

Bench-test note:
The console reports DSA=0. Original legacy firmware does not initiate HART while DSA is invalid/secondary. HART_LEGACY_BENCH_TEST_ALLOW_DSA0 is therefore enabled only for HART scheduling, without changing BOX DSA globally. Disable it for the final configured system.

For production:
#define HART_LEGACY_BENCH_TEST_ALLOW_DSA0   (0u)
#define HART_LEGACY_BENCH_TEST_INITIAL_SCAN (0u)

Perform Project Clean, Build Project, flash the newly generated AXF and power-cycle.
