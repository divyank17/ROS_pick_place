################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/fsl_clock.c \
../drivers/fsl_common.c \
../drivers/fsl_common_arm.c \
../drivers/fsl_dcdc.c \
../drivers/fsl_gpc.c \
../drivers/fsl_gpio.c \
../drivers/fsl_lpspi.c \
../drivers/fsl_lpuart.c \
../drivers/fsl_pit.c \
../drivers/fsl_pmu.c \
../drivers/fsl_src.c 

C_DEPS += \
./drivers/fsl_clock.d \
./drivers/fsl_common.d \
./drivers/fsl_common_arm.d \
./drivers/fsl_dcdc.d \
./drivers/fsl_gpc.d \
./drivers/fsl_gpio.d \
./drivers/fsl_lpspi.d \
./drivers/fsl_lpuart.d \
./drivers/fsl_pit.d \
./drivers/fsl_pmu.d \
./drivers/fsl_src.d 

OBJS += \
./drivers/fsl_clock.o \
./drivers/fsl_common.o \
./drivers/fsl_common_arm.o \
./drivers/fsl_dcdc.o \
./drivers/fsl_gpc.o \
./drivers/fsl_gpio.o \
./drivers/fsl_lpspi.o \
./drivers/fsl_lpuart.o \
./drivers/fsl_pit.o \
./drivers/fsl_pmu.o \
./drivers/fsl_src.o 


# Each subdirectory must supply rules for building sources it contributes
drivers/%.o: ../drivers/%.c drivers/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\board" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source\hal" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\drivers" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\debug_console_lite" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\str" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\uart" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\gpio" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS\m-profile" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\xip" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-drivers

clean-drivers:
	-$(RM) ./drivers/fsl_clock.d ./drivers/fsl_clock.o ./drivers/fsl_common.d ./drivers/fsl_common.o ./drivers/fsl_common_arm.d ./drivers/fsl_common_arm.o ./drivers/fsl_dcdc.d ./drivers/fsl_dcdc.o ./drivers/fsl_gpc.d ./drivers/fsl_gpc.o ./drivers/fsl_gpio.d ./drivers/fsl_gpio.o ./drivers/fsl_lpspi.d ./drivers/fsl_lpspi.o ./drivers/fsl_lpuart.d ./drivers/fsl_lpuart.o ./drivers/fsl_pit.d ./drivers/fsl_pit.o ./drivers/fsl_pmu.d ./drivers/fsl_pmu.o ./drivers/fsl_src.d ./drivers/fsl_src.o

.PHONY: clean-drivers

