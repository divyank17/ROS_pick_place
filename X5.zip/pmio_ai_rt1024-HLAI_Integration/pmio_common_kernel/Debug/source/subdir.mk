################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../source/adc.cpp \
../source/aihboxslot.cpp \
../source/aihmain.cpp \
../source/aihslot.cpp \
../source/aixslot.cpp \
../source/boxslot.cpp \
../source/cpp_config.cpp \
../source/debug.cpp \
../source/diag.cpp \
../source/ecl.cpp \
../source/eeprom.cpp \
../source/evrctask.cpp \
../source/hardfail.cpp \
../source/hart.cpp \
../source/hartdb.cpp \
../source/hartstack.cpp \
../source/iol.cpp \
../source/iomslot.cpp \
../source/pmio_kernel.cpp \
../source/scheduler.cpp \
../source/utils.cpp \
../source/wrdbtask.cpp 

C_SRCS += \
../source/semihost_hardfault.c 

CPP_DEPS += \
./source/adc.d \
./source/aihboxslot.d \
./source/aihmain.d \
./source/aihslot.d \
./source/aixslot.d \
./source/boxslot.d \
./source/cpp_config.d \
./source/debug.d \
./source/diag.d \
./source/ecl.d \
./source/eeprom.d \
./source/evrctask.d \
./source/hardfail.d \
./source/hart.d \
./source/hartdb.d \
./source/hartstack.d \
./source/iol.d \
./source/iomslot.d \
./source/pmio_kernel.d \
./source/scheduler.d \
./source/utils.d \
./source/wrdbtask.d 

C_DEPS += \
./source/semihost_hardfault.d 

OBJS += \
./source/adc.o \
./source/aihboxslot.o \
./source/aihmain.o \
./source/aihslot.o \
./source/aixslot.o \
./source/boxslot.o \
./source/cpp_config.o \
./source/debug.o \
./source/diag.o \
./source/ecl.o \
./source/eeprom.o \
./source/evrctask.o \
./source/hardfail.o \
./source/hart.o \
./source/hartdb.o \
./source/hartstack.o \
./source/iol.o \
./source/iomslot.o \
./source/pmio_kernel.o \
./source/scheduler.o \
./source/semihost_hardfault.o \
./source/utils.o \
./source/wrdbtask.o 


# Each subdirectory must supply rules for building sources it contributes
source/%.o: ../source/%.cpp source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -D__NEWLIB__ -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\board" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source\hal" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\drivers" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\debug_console_lite" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\str" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\uart" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\gpio" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS\m-profile" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\xip" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fno-rtti -fno-exceptions -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

source/%.o: ../source/%.c source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\board" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source\hal" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\drivers" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\debug_console_lite" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\str" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\uart" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\gpio" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS\m-profile" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\xip" -I"C:\Users\Andor\Downloads\A6_HART_Legacy_Flow_Minimal_Print_Integrated_Build\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-source

clean-source:
	-$(RM) ./source/adc.d ./source/adc.o ./source/aihboxslot.d ./source/aihboxslot.o ./source/aihmain.d ./source/aihmain.o ./source/aihslot.d ./source/aihslot.o ./source/aixslot.d ./source/aixslot.o ./source/boxslot.d ./source/boxslot.o ./source/cpp_config.d ./source/cpp_config.o ./source/debug.d ./source/debug.o ./source/diag.d ./source/diag.o ./source/ecl.d ./source/ecl.o ./source/eeprom.d ./source/eeprom.o ./source/evrctask.d ./source/evrctask.o ./source/hardfail.d ./source/hardfail.o ./source/hart.d ./source/hart.o ./source/hartdb.d ./source/hartdb.o ./source/hartstack.d ./source/hartstack.o ./source/iol.d ./source/iol.o ./source/iomslot.d ./source/iomslot.o ./source/pmio_kernel.d ./source/pmio_kernel.o ./source/scheduler.d ./source/scheduler.o ./source/semihost_hardfault.d ./source/semihost_hardfault.o ./source/utils.d ./source/utils.o ./source/wrdbtask.d ./source/wrdbtask.o

.PHONY: clean-source

