BUILD 34 - HART COMMAND 13/14/15 AND PV FIX
===========================================

Base project
------------
33_HART_CMD13_14_15_StateMachine_Fix_Project(1).zip

Legacy reference
----------------
s1(14).zip

Purpose
-------
Preserve the S1/legacy channel database and command handlers while fixing the
RT1024 redesign transport-to-database bridge for Commands 13, 14, 15 and 3.

What remains identical to S1
----------------------------
1. Cmd3GoodHandler / Cmd3BadHandler.
2. Cmd13GoodHandler / Cmd13BadHandler.
3. Cmd14GoodHandler / Cmd14BadHandler.
4. Cmd15GoodHandler / Cmd15BadHandler.
5. HART5_INIT_COMMANDS, HART6_INIT_COMMANDS and HART7_INIT_COMMANDS order,
   including Command 20 before Command 50.
6. HCmd13 = 21-byte packed tag/descriptor/date database block.
7. HCmd14 = 16-byte transducer-information database block.
8. HCmd15 = 18-byte device-information database block.

Fixes in this build
-------------------
1. Command 15 revision-dependent response length
   - The core legacy fields at bytes 0..15 are accepted.
   - If a device omits optional bytes 16 and/or 17, the redesign bridge pads
     them with 0xFF before the unchanged legacy 18-byte handler runs.
   - The three Command 15 floats at offsets 3, 7 and 11 are still converted
     from HART big-endian wire order to RT1024 native order.

2. Command 3 / PV bridge
   - The scheduler/state-machine path now captures loop current and all
     available PV/SV/TV/QV values directly from the valid Command 3 wire
     response before legacy byte reversal.
   - The direct/synchronous path and scheduler path now publish the same
     runtime dynamic values.
   - The final PV report uses HartDb_GetPrimaryVariable(), which first uses the
     validated Command 3 runtime value and then falls back to the legacy DB.

3. Payload validation
   - Command 3 requires at least the loop-current + one-variable payload.
   - Commands 13 and 14 retain their legacy fixed minimum lengths.
   - Command 15 accepts the 16-byte core and normalizes to the legacy 18-byte
     database layout.

4. Discovery failure handling
   - A true communication failure or legacy REINIT result stops the direct
     initialization table immediately.
   - Optional commands that return legacy CONTINUE behavior still continue.

5. Debugger diagnostics
   - Command-good mask bits are cleared before each latest attempt, so they do
     not remain falsely sticky after a later failure.
   - The actual status and payload length of a parsed short response are kept
     in the per-channel diagnostics rather than being overwritten with 0/FF.

Files changed
-------------
source/hart.h
source/hart.cpp
source/hartdb.cpp
source/hartstack.cpp
source/hartstack.hpp
Debug/*/subdir.mk (portable relative include paths only)

Validation completed
--------------------
- Legacy handler comparison: PASS.
- Legacy HART 5/6/7 initialization-table comparison: PASS.
- Command 3 big-endian loop-current and PV/SV/TV/QV decode test: PASS.
- Command 14 float conversion and wire round-trip test: PASS.
- Command 15 16-byte core, 0xFF padding and wire round-trip test: PASS.
- Syntax-only check of hart.cpp, hartdb.cpp and hartstack.cpp: PASS using a
  host validation harness with ARM/CMSIS shims.
- Generated Debug makefiles no longer contain the previous developer machine
  absolute include paths; they use project-relative include paths.

The ARM GCC/MCUXpresso toolchain is not installed in the packaging environment,
so an .axf/.bin was not generated here. Import this full project into the same
MCUXpresso workspace/toolchain used for the base project and perform Clean +
Build before flashing.

Hardware validation
-------------------
For a device on channel N, watch:
  g_ucHartLastCommandByChannel[N]
  g_ucHartLastResponseByChannel[N]
  g_ucHartLastPayloadLengthByChannel[N]
  g_ucHartInitIndexByChannel[N]
  g_usHartCmd13GoodMask
  g_usHartCmd14GoodMask
  g_usHartCmd15GoodMask
  g_usHartShortResponseMask

Expected after discovery:
- Commands 13, 14 and 15 reach their good handlers.
- HCmd13 no longer remains all 0xFF.
- HCmd14 contains valid unit/LRL/URL/minimum-span data.
- HCmd15 contains valid range/damping/write-protect data; optional absent tail
  bytes are 0xFF.
- Command 3 reports valid loop current, PV unit and PV value. If returned by the
  device, SV/TV/QV unit and values are captured as well.
