# Build 33 HART Command 13/14/15 Deep Comparison

## Result of the S1 comparison

The Command 13, Command 14, and Command 15 response structures are unchanged from S1:

- Command 13 response: 21 bytes
- Command 14 response: 16 bytes
- Command 15 response: 18 bytes

The following six handler bodies match S1 after removing comments and whitespace:

- `Cmd13GoodHandler()`
- `Cmd13BadHandler()`
- `Cmd14GoodHandler()`
- `Cmd14BadHandler()`
- `Cmd15GoodHandler()`
- `Cmd15BadHandler()`

`ScheduleFromInitTable()` also matches S1 and retains the established initialization-command order.

## Meaning of the displayed values

The observed values are the database initialization pattern:

- `????????`: packed text initialized with `0xFF`
- `UNKNOWN 255`: engineering-unit byte initialized with `0xFF`
- `NaN`: four-byte numeric field initialized with `0xFFFFFFFF`
- day/month `255`, year `2155`: Command 13 date bytes still contain `0xFF`

These values prove that the command data is still in its initialized state. They do not indicate that the Command 13/14/15 handlers decoded a valid response incorrectly.

## State-machine startup problem

`InitDevDb(TRUE)` initializes the channel to:

- `m_HChanMode = HCHANMODE_INIT`
- `m_ucInitCmdIndex = 0`
- `m_sScanCounter = TICKS_DISABLE_SCAN`

The normal configuration callback `PostHEnable()` arms the scan counter. During startup/database restoration, HENABLE can already be TRUE before the HART objects and task are ready, so that callback is not guaranteed to arm the channel afterward. The channel can therefore remain indefinitely in INIT with scanning disabled, leaving Commands 13, 14, and 15 at their initialized values.

Build 33 adds a channel-neutral arming check in the normal HART task. It arms every HART-enabled channel that is still at the initial disabled state. No channel is prioritized.

## Completion and response validation

The FPGA/SPI transport still executes only the request selected by the established channel state machine. Its response returns through:

`HartDb_LoadParsedResponse()` -> `ReceptionComplete()` -> `UpdateDatabase()` -> command handler -> `ScheduleFromInitTable()`

Build 33 also:

- retries initialization reads 12, 13, 14, 15, 16, 20, and 50 up to the configured initialization retry limit;
- rejects successful-status responses that are shorter than the defined response structure;
- prevents a back-to-back guard limit from leaving the channel permanently in `TICKS_SYNCED_CHAN`;
- preserves the S1 Command 13/14/15 handler bodies and structure layout;
- preserves Command 13 packed text without byte reversal;
- converts Command 14 and 15 floating-point fields for the little-endian RT1024 handler, then restores protocol byte order in the blind database block.

## Command 13/14/15 byte handling

### Command 13

The complete 21-byte packed text/date payload is copied unchanged. No byte reversal is performed.

### Command 14

The three 32-bit floating-point fields at offsets 4, 8, and 12 are reversed before the S1 handler reads them as native RT1024 floats. The stored 16-byte HCmd14 blind block is converted back to HART protocol order.

### Command 15

Only the three 32-bit floating-point fields at offsets 3, 7, and 11 are reversed. The write-protect, distributor-label, and PV-flag bytes at offsets 15, 16, and 17 are not reversed. The stored 18-byte HCmd15 blind block is converted back to HART protocol order.

A synthetic round-trip test verifies that Command 13 stays unchanged and Command 14/15 native values and stored wire bytes are correct.

## Silent debugger diagnostics

Build 33 does not add console diagnostics. These globals can be watched in MCUXpresso:

- `g_ucHartLastCommandByChannel[17]`
- `g_ucHartLastResponseByChannel[17]`
- `g_ucHartLastPayloadLengthByChannel[17]`
- `g_ucHartInitIndexByChannel[17]`
- `g_usHartCmd0GoodMask`
- `g_usHartCmd13GoodMask`
- `g_usHartCmd14GoodMask`
- `g_usHartCmd15GoodMask`
- `g_usHartShortResponseMask`

For channel 2, the channel bit is `0x0002`.

After successful initialization on channel 2, the CMD0, CMD13, CMD14, and CMD15 masks should all contain `0x0002`. The expected successful payload lengths are 21, 16, and 18 respectively.

## Console policy

There is one enabled HART print in the six HART files:

`HART CHANNEL=<channel> MODEM=<modem> PV=<value>`

TraceLog and HART state diagnostics remain silent. TraceLog continues persisting to BBSRAM.
