/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : boxslot.cpp                                                 *
*    Description : clsBoxSlot implementation for RT1024/QEMU — AIH-only.       *
*                  Full implementation: soft-fail management, status           *
*                  transitions, ECL events, BRDP handle management,           *
*                  parameter read/write, checksum, CPU free tracking.          *
*******************************************************************************/
#include "aihmain.h"

/* pDatabase: slot 0 = BOX, slots 1..MAXSLOTS = channel objects */
extern clsIomSlot *pDatabase[];

HARDFAILTYPE clsBoxSlot::FailCode;
UINT32 clsBoxSlot::TracelogTimeCntr = 0u;

BOOL HWRevCodeWriteInProgress;
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/

const UINT8 clsBoxSlot::Bits[] = {0,1,2,4,8,16,32,64,128};

const UINT8 VersionInfo[] = {
    VERSION_NUMBER,
    REVISION_NUMBER,
    BUILD_NUMBER
};
/*
const UINT8 clsBoxSlot::ModStatType[] = {
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT1,
    PARAMID_MODSTAT2,
    0 // Terminator
};*/

const UINT8 clsBoxSlot::Sup300[] = {
    PARAMID_DSA,
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT2,
    PARAMID_NTH,
    PARAMID_COMMSTAT,
    PARAMID_COMMERR,
    PARAMID_CHNERRA,
    PARAMID_CHNERRB,
    PARAMID_CHNSILA,
    PARAMID_CHNSILB,
    PARAMID_BA,
    PARAMID_REDDATA,
    PARAMID_DBVALID,
    0 // Terminator
};

const UINT8 clsBoxSlot::SfInfo300[] = {

    // added to fix in DO, PAR#1 - 91X5DJ1
    // in DI, observed similar issue in experion setup
    //PARAMID_DO_BOXSFAIL,

    PARAMID_BOXSFBITS,
    PARAMID_SLOTSFBITS,
    PARAMID_MAPSLOTINFAIL,
    0 // Terminator
};

/*******************************************************************************
*                       clsBoxSlot::clsBoxSlot                                 *
*                       ======================                                 *
* PURPOSE:                                                                     *
*    Constructor — initialise module identity, status, softfail bitmaps, ECL,  *
*    BRDP table and LED housekeeping state.                                    *
* ARGUMENTS:                                                                   *
*    a_ModlType : MODLTYPE identifying this module (AIH, AOH, etc.).           *
*    a_MaxSlots : number of channel slots this module supports.                *
* RETURN:                                                                      *
*    None (constructor).                                                       *
* NOTES:                                                                       *
*    RT1024 CHANGES: MODNUM read via hal_fpga_get_modnum() SPI abstraction.    *
*******************************************************************************/
clsBoxSlot::clsBoxSlot(MODLTYPE a_ModlType, UINT8 a_MaxSlots) : clsIomSlot(0) {

    pNrmEcl = new clsEcl(ECLTYPE_NORMAL);
#ifdef IOMTYPE_DISOE
    pPvChngEcl = new clsEcl(ECLTYPE_PVCHANGE);
#endif

    /* Module identity */
    ModlType = a_ModlType;
    MaxSlots = a_MaxSlots;

    HwInfo.HwRevLetter = 1; // temp value for testing
    HwInfo.HwRevNumber = 0;
    AppRevCode.ucVersion = VersionInfo[0];
    AppRevCode.ucRevision = VersionInfo[1];

    /* Read module number from FPGA MODNUM register via SPI (HDD Table 29).
       MODNUM[7:0] comes from backplane DIP switches into FPGA, exposed at
       SPI register 0x64. Bits [5:0] = BCD device address, bit 7 = IOL ID. */
    UINT8 modnum_raw = hal_fpga_get_modnum();
    ModlNum = modnum_raw & MODNUMBITS;
    IolId   = modnum_raw & IOLIDBIT;

    // DPA formation with File & Slot configuration
    // ModlNum Bit 0:3 - Slot number
    // ModlNum Bit 4:6 - File number
    // ModlNUm Bit 7   - Parity bit

    // always odd no of one's should be in the file code (inclusive parity-Bit7)
    if (isOddParity((ModlNum + IolId) >> 4))
        Dpa = (0x80 | ModlNum);
    else
        HardFail(HF_PARITYERROR, BOXSLOT_CPP, __LINE__);

    // added to fix PAR #1-72NBQP7 (HLAI), #1-7KEY6J5 (AO16) - (IOL COMM Errors issues)
    IolId = IOLIDBIT;
    Dsa     = 0;
    Ba      = 0xFF;
    Nth     = 0;
    IolDevType = IOLDEVTYPE_SLAVE;

    /* Module status */
    ModStat1.BYTE = 0;
    ModStat1.Status = MODSTATUS_ALIVE;
    ModStat1Lrs   = 0;
    ModStat2.BYTE = 0x45;
    //ModStat3.BYTE = 0;
    //MesNo    = 0;
    CommErr  = PA_OK;
    CommStat = {0};
    ChnErrA  = 0;
    ChnErrB  = 0;
    ChnSilA  = 0;
    ChnSilB  = 0;
    //CpuFreeMin = 0.0f;
    //CpuFreeAvg = 0.0f;
    //StatReset  = FALSE;

    LastFail  = HF_UNKNOWN;
    FailCode = HF_UNKNOWN;

    for (UINT8 ucCount = 0; ucCount < SFBYTES_SIZE; ucCount++) {
        BoxSfBits[ucCount]   = 0;
        SlotSfBits[ucCount]  = 0;
        BoxSfLrs[ucCount]    = 0;
        SfActionTbl[ucCount] = 0;
        if (ucCount < SLOTINFAIL_SIZE) {
            MapSlotInFail[ucCount] = 0;
        }
    }

    //SuprCtrl  = 0;
    //ToknStll  = 0;
    DbValid   = DB_INVALID;
    //WithBias  = FALSE;
    //LedBlinkCounter = 0;
    //LedOn     = FALSE;
    //LpBkStat  = 0;
    //bStcSyncRestart  = FALSE;
    //bWdtIntProcessed = FALSE;

    /* Zero bit-field arrays * /
    for (UINT8 i = 0; i < SFBYTES_SIZE; i++) {
        BoxSfBits[i]   = 0;
        SlotSfBits[i]  = 0;
        BoxSfLrs[i]    = 0;
        SfActionTbl[i] = 0;
    }
    for (UINT8 i = 0; i < SLOTINFAIL_SIZE; i++) {
        MapSlotInFail[i] = 0;
    }
    for (UINT8 i = 0; i < SYNCVER_SIZE; i++) {
        SyncVer[i] = 0;
    } */
    RedData[0] = REDDATA_SFFOEN | REDDATA_BURQST;
    RedData[1] = 0;
    /*
    for (UINT8 i = 0; i <= MAXSLOTS; i++) {
        CheckSum[i] = 0;
    }
    for (UINT8 i = 0; i < BOXSLOT_SPARESIZE; i++) {
        BoxSlotSpare[i] = 0;
    }*/

    BoxSfCounter  = 0;
    SlotSfCounter = 0;

    HWRevCodeWriteInProgress = FALSE;

    TraceLogInfo.TracelogTime = 0u;
    TraceLogInfo.LatestIndex  = 0u;

    /* HW info — will be populated from EEPROM/flash at init time */
    //HwInfo = {0};
    //AppSwRevCode.ucByte  = 0;
    //BootSwRevCode.ucByte = 0;

    /* BRDP */
    //InitBRDPDatabase();

    /* Housekeeping rotation */
    //HouseKeepingSlot = 0;

    /* Configure LED blink timer interrupt.
       Period: 500ms (500,000 microseconds) — typical for status LED blinking.
       Callback: BlinkLEDInterruptHandler will be invoked periodically. */
    //hal_timer_configure(HAL_TIMER_LED_BLINK, 500000, (hal_timer_callback_t)BlinkLEDInterruptHandler);
    //hal_timer_start(HAL_TIMER_LED_BLINK);
}

/*******************************************************************************
*                     clsBoxSlot::BlinkLEDInterruptHandler                     *
*                     ====================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::BlinkLEDInterruptHandler(VOID)  {

    //TPU3_TGFA = 0; // Acknowledge the compare match interrupt
    if ((BOX->BoxSfCounter > 0) || (BOX->SlotSfCounter > 0) || (BOX->LedBlinkCounter > 0)) {
        if (BOX->LedBlinkCounter > 0) {
            --(BOX->LedBlinkCounter);
        }

        else if (TRUE == BOX->GetCalibAllState()) {
            // If calibration is progress and there is no request to blink the LED by
            // by the calibration function, switch off the LED and return.
        	BOX->LED_PINS(WRITE, STATUSLED_OFF);
            return;
        }

        if (STATUSLED_OFF == BOX->LED_PINS(READ)) {
            (BOX->GetDSA()) ? BOX->LED_PINS(WRITE, STATUSLED_GREEN)
                            : BOX->LED_PINS(WRITE, STATUSLED_AMBER);
        }
        else BOX->LED_PINS(WRITE, STATUSLED_OFF);
    }
    else {
        if (TRUE == BOX->GetCalibAllState()) {
        	BOX->LED_PINS(WRITE, STATUSLED_OFF);
        }
        else {
            (BOX->GetDSA()) ? BOX->LED_PINS(WRITE, STATUSLED_GREEN)
                            : BOX->LED_PINS(WRITE, STATUSLED_AMBER);
        }
    }
}

/*******************************************************************************
*                           clsBoxSlot::ManageRedIO                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::ManageRedIO(VOID) {

	switch(Iol.AddressChange()) {
	case ADDCHG_NONE:
		break;
	case ADDCHG_NEW:
		if(Iol.AmPrimary()) {
			DeAssertBackup();
		}
		SetRedState(REDSTATE_NOT_SYNCD);
		//TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0x55555555);
		break;
	case ADDCHG_DROPPED:
		if(REDSTATE_IOL_TIMEOUT != GetRedState()){
			DropSync();
			//TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0xAAAAAAAA);
		}
		break;
	}
}

/*******************************************************************************
*                           clsBoxSlot::DropSync                               *
*                           ====================                               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::DropSync(VOID) {
    if(REDSTATE_FREEZE_PERMITTED != GetRedState()){
       if(REDSTATE_SYNC_FAILED != GetRedState()) SetRedState(REDSTATE_NOT_SYNCD);
       if(!Iol.AmPrimary()) AssertBackup();
    }
}

/*******************************************************************************
*                          clsBoxSlot::AddModStatEvent                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddModStatEvent(EVENTTYPE a_EventType) {
    EVENTRECORD ModStatEvent;
    UINT8 CurrentLrsMask, PreviousLrsMask,PreviousModStat;
    EVENTSUBTYPE CurrentSubType, PreviousSubType;

    // Initialize event record.
    ModStatEvent.Overflow      = FALSE;
    ModStatEvent.ContactCutout = FALSE;
    ModStatEvent.Qualifier     = a_EventType;
    ModStatEvent.CurrentState  = EVENTSTATE_RETURN;
    ModStatEvent.EventPacket   = EVENTPACKET_SYSTEM;
    ModStatEvent.SystemEvent.SoftfailStatus = FALSE;
    ModStatEvent.SystemEvent.ChannelNumber  = 0;
    if (ModStat1.Status == MODSTATUS_IDLE) {
        CurrentLrsMask     = MODSTATUS_IDLE_LRSBIT;
        PreviousLrsMask    = MODSTATUS_RUN_LRSBIT;
        CurrentSubType     = EVENTSUBTYPE_IDLE;
        PreviousSubType    = EVENTSUBTYPE_RUN;
        PreviousModStat    = MODSTATUS_RUN;
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        CurrentLrsMask     = MODSTATUS_RUN_LRSBIT;
        PreviousLrsMask    = MODSTATUS_IDLE_LRSBIT;
        CurrentSubType     = EVENTSUBTYPE_RUN;
        PreviousSubType    = EVENTSUBTYPE_IDLE;
        PreviousModStat    = MODSTATUS_IDLE;
    }
    // Set LRS bit only for normal events.
    if (EVENTTYPE_NORMAL == a_EventType) {
        ModStat1Lrs |= CurrentLrsMask;
    }
    // If last module state change is not reported yet, report it.
    if (ModStat1Lrs & PreviousLrsMask) {
        ModStatEvent.SystemEvent.EventSubType = PreviousSubType;
        if (EVENTTYPE_RECOVERY == a_EventType) {
            if (pNrmEcl->IsRoomForRegen() == FALSE) {
                return FALSE;
            }
        }
        else {
            // Set ECL module status only for normal events.
            pNrmEcl->SetEclModStat(PreviousModStat);
        }
        // Do not update LRS for recovery events.
        if (pNrmEcl->AddEvent(&ModStatEvent) == TRUE) {
            if (EVENTTYPE_NORMAL == a_EventType) {
                ModStat1Lrs &= (~PreviousLrsMask);
            }
        }
        else {
            return FALSE;
        }
    }
    // Report current state change to idle.
    ModStatEvent.SystemEvent.EventSubType = CurrentSubType;
    if (EVENTTYPE_RECOVERY == a_EventType) {
        if (pNrmEcl->IsRoomForRegen() == FALSE) {
            return FALSE;
        }
    }
    else {
        // Set ECL module status only for normal events.
        pNrmEcl->SetEclModStat(ModStat1.Status);
    }
    // Do not update lrs for recovery events.
    if (pNrmEcl->AddEvent(&ModStatEvent) == TRUE) {
        if (EVENTTYPE_NORMAL == a_EventType) {
            ModStat1Lrs &= (~CurrentLrsMask);
        }
        return TRUE;
    }
    return FALSE;
}

#if 1 //defined(IOPTYPE_HLAI) || defined(IOPTYPE_DI)
// for redesign PMIO, Alarm Event for HLAI
BOOL clsBoxSlot::AddAiAlarmEvent(ALARMEVENTRECORD *pAlarmEvent)
{
#if 1 //defined(IOPTYPE_HLAI) || defined(IOPTYPE_DI)
    if (NOALARM == pAlarmEvent->AlarmCode)
    {
        pNrmEcl->ResetStatus(ECLSTATUS_NORMAL);
    }
    else
    {
        pNrmEcl->SetStatus(ECLSTATUS_NORMAL);
    }
#endif

    return pNrmEcl->AddAlarmEvent(pAlarmEvent);
}
#endif

BOOL clsBoxSlot::AddPtExecStEvent(EVENTRECORD *pPtExecStEvent)
{
    pNrmEcl->SetStatus(ECLSTATUS_NORMAL);

    return pNrmEcl->AddEvent(pPtExecStEvent);
}

/*******************************************************************************
*                         clsBoxSlot::AddSoftfailEvent                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddSoftfailEvent(EVENTTYPE a_EventType,
                                  SOFTFAILTYPE a_SoftfailType,
                                  BOOL a_bDirection, UINT8 a_ucSltNm) {
    EVENTRECORD SoftfailEvent;
    // Initialize event record.
    SoftfailEvent.Overflow      = FALSE;
    SoftfailEvent.ContactCutout = FALSE;
    SoftfailEvent.Qualifier     = a_EventType;
    SoftfailEvent.EventPacket   = EVENTPACKET_SYSTEM;
    SoftfailEvent.SystemEvent.ChannelNumber = a_ucSltNm;
    SoftfailEvent.SystemEvent.EventSubType  = a_SoftfailType;

    UINT8 ucSfByte,ucLrsByte,ucByteOffset,ucBitOffset=0x01;
    UINT8 ucSfActByteOffset,ucSfActBitOffset=0x01;

#if 1//defined(IOPTYPE_HLAI)
    // for redesign PMIO, there should be timeout between accessing of ADC & xRAM through SPI.
    // in that timeout these softfails are not valid.
    if (/*(ucXRamTimeout) &&*/
       ((SF_VREFFAIL == a_SoftfailType) ||
        (SF_ADOUTUDF == a_SoftfailType) ||
        (SF_VZERO_FL == a_SoftfailType) ||
        (SF_ADOUTCAL == a_SoftfailType)))
        return FALSE;
#elif defined(IOPTYPE_AO16)
    // added to fix unwanted softfails with the greater than SFail code 127
    // root cause: Legacy has BoxSfBits[16], where as redesign BoxSfBits[32]
    // modification: so supressed to 128 SFail codes (16 x 8bits)
    if (a_SoftfailType > SF_IDLE) {
        return FALSE;
    }
#endif

    // Generate ByteOffset and BitOffsets for SfActionTable search
    ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
    ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);

    // Set SfByte and LrsByte according to the slot number and softail type.
    if (0 == a_ucSltNm) {
        ucByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
        ucBitOffset <<= (a_SoftfailType % BYTESIZE);
        ucSfByte  = BoxSfBits[ucByteOffset];
        ucLrsByte = BoxSfLrs[ucByteOffset];
    }
    else {
        for (ucByteOffset = 0; ucByteOffset < BYTESIZE; ucByteOffset++) {
            if (SlotSfMap[ucByteOffset] == a_SoftfailType) {
                break;
            }
            ucBitOffset <<= 1;
        }
        if (BYTESIZE == ucByteOffset) {
            return FALSE;
        }
        ucSfByte  = SLOT(a_ucSltNm)->GetSlotSfBt();
        ucLrsByte = SLOT(a_ucSltNm)->GetSlotSfLrs();
    }

    if (TRUE == a_bDirection) {
        SoftfailEvent.CurrentState = EVENTSTATE_ALARM;
        if (EVENTTYPE_NORMAL == a_EventType) {
            //Initiate a SoftFail Failover if enabled and appropriate
            if (REDSTATE_SYNCD == GetRedState() &&       // if modules syncd
                CheckRedData(REDDATA_SFFOEN) &&          // + SF FO enabled
                (SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset))// + FO for this SF
            {
                if ((!GetFtaPres() || !GetPartnersBackupStatus()) && Iol.AmPrimary())
                {
                // added to fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
#if defined(IOPTYPE_AO16)
                    LastSfCode = a_SoftfailType;
#endif
                    Iol.DropDSA();
                    BOX->SetDSA(0);
                }
                AssertBackup();
                ResetRedData(REDDATA_SFFOEN);
            }
        }
    }
    else SoftfailEvent.CurrentState = EVENTSTATE_RETURN;

    UINT8 ucSaveExr = get_imask_exr();
    if (EVENTTYPE_NORMAL == a_EventType) {
        // Elevate the priority of executing thread to STC level
        // when SfBits and Sfcounter in database are updated.
        set_imask_exr(LVLPRI_TICK);

        #ifndef IOMTYPE_SVP
        #ifndef IOMTYPE_SP
            if (a_ucSltNm > 0) { // if slot softfail, check for throttling
                if ((SLOT(a_ucSltNm)->IsSlotSfToBeThrottled(ucBitOffset,a_bDirection) == TRUE) ){
                    // Softfail to be throttled. Restore original priority and
                    // return wihtout updating SfBits and SfCounter in database.
                    set_imask_exr(ucSaveExr);
                    return FALSE;
                }
            }
        #endif
        #endif

        if ((ucSfByte & ucBitOffset) && (FALSE == a_bDirection)) {
            // SfByte bit is set and the softfail is returning
            ucSfByte &= ~ucBitOffset; // reset SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter > 0) BoxSfCounter--;
            }
            else {
                if (SlotSfCounter > 0) SlotSfCounter--;

                // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
#if defined(IOPTYPE_AO16)
                if ((SF_OUTPUTFL == a_SoftfailType) && (ucOutputFailCounter))
                {
                    ucOutputFailCounter--;
                }
#endif
            }
        }
        else if ((!(ucSfByte & ucBitOffset)) && (TRUE == a_bDirection)) {
            // SfByte bit is not set and the softfail is being reported
            ucSfByte |= ucBitOffset; // set SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter < MAXUINT8) BoxSfCounter++;
            }
            else {
                if (SlotSfCounter < MAXUINT8) SlotSfCounter++;

                // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
#if defined(IOPTYPE_AO16)
                SfCodeLrs = a_SoftfailType;

                if (SF_OUTPUTFL == a_SoftfailType)
                    ucOutputFailCounter++;
#endif
            }
        }

#if defined(PMIO_DEBUG) && (0)
        if (ucDbgPnt == NRML_DBGPNT)
        {
            if (ucDbgCnt < DMPBUF_SIZE - 5)
            {
                ucDumpBuff[ucDbgCnt++] = a_SoftfailType;
                ucDumpBuff[ucDbgCnt++] = ((a_ucSltNm << 4) | a_bDirection);
            }
            else ucDbgCnt = 0;
        }
#endif

        // Update SfByte in the box/slot database.
        if (0 == a_ucSltNm) {
            BoxSfBits[ucByteOffset] = ucSfByte;
        }
        else {
            SLOT(a_ucSltNm)->SetSlotSfBt(ucSfByte);
        }

        // Database update complete.
        // Restore original interrupt priority.
        set_imask_exr(ucSaveExr);
    }

    if ((0 == BoxSfCounter) && (0 == SlotSfCounter)) {
        SoftfailEvent.SystemEvent.SoftfailStatus = FALSE;
        pNrmEcl->ResetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = FALSE;
        SetRedData(REDDATA_SFFOEN);
        if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) {
            if (GetCalibAllState() != TRUE) {
                DeAssertBackup();
            }
        }
    }
    else {
        SoftfailEvent.SystemEvent.SoftfailStatus = TRUE;
        pNrmEcl->SetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = TRUE;
    }

    // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (SEC is going into SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion on power up)
#if defined(IOPTYPE_AO16)
    if ((!Iol.AmPrimary())
    && (SF_OUTPUTFL == a_SoftfailType)
    && (GetPartnersBackupStatus())
    && (INHIN_NEGATED != INHIN_FB_n))
    {
        LastSfCode = SF_OUTPUTFL;
    }
#endif

    if (MODSTATUS_FAIL != ModStat1.Status) {
        // Add softfail event to the normal event circular list if this is
        // event recovery OR if SfByte and LrsByte are not matching.
        if ((EVENTTYPE_RECOVERY == a_EventType) ||
            (ucLrsByte ^ ucSfByte) & ucBitOffset) {
            if (EVENTTYPE_RECOVERY == a_EventType) {
                if (pNrmEcl->IsRoomForRegen() == FALSE) {
                    return FALSE;
                }
            }

            if (TRUE == pNrmEcl->AddEvent(&SoftfailEvent)) {
                if (EVENTTYPE_NORMAL == a_EventType) {
                    // Update LRS byte only for normal events.
                    if (TRUE == a_bDirection) {
                        ucLrsByte |= ucBitOffset;
                    }
                    else {
                        ucLrsByte &= ~ucBitOffset;
                    }
                }

                // Elevate the priority of executing thread to
                // STC level when LRS byte in database is updated.
                set_imask_exr(LVLPRI_TICK);
                if (0 == a_ucSltNm) {
                    BoxSfLrs[ucByteOffset] = ucLrsByte;
                }
                else {
                    SLOT(a_ucSltNm)->SetSlotSfLrs(ucLrsByte);
                }
                // Database update complete.
                // Restore original interrupt priority.
                set_imask_exr(ucSaveExr);

                return TRUE;
            }
            else { // AddEvent failed
                return FALSE;
            }
        }
    }

    // Execution reaches here only if
    // there is nothing to report.
    return TRUE;
}

/*******************************************************************************
*                           clsBoxSlot::AddBrackEvent                          *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddBracketEvent(EVENTSUBTYPE a_EventSubType) {
    EVENTRECORD EventBracket;
#ifdef IOMTYPE_DISOE
    // The regen in progress flag is set.  If a regen is not expected, the
    // Timesync Table is saved via the Save Timesync Table routine.  Then, if the
    // regen is expected or the log is not frozen, the log is frozen, and the
    // regen expected flag is set false.
    BOOL bRegen_Expected = BOX->IsRegen_Expected();
    if(EVENTSUBTYPE_RECOVERYSTART==a_EventSubType) {
        BOX->SetPVCLEvtRegInProgress(TRUE);
    }
    if(FALSE == bRegen_Expected)
    {
        BOX->CopySyncTbl();
    }
    if( (TRUE==bRegen_Expected) || (FALSE== BOX->IsLogFrozen()) ) {
        BOX->SetLog_Frozen(TRUE);
        BOX->SetRegen_Expected(FALSE);
    }
#endif // disoe
    // Create start backet
    EventBracket.Overflow      = FALSE;
    EventBracket.ContactCutout = FALSE;
    EventBracket.Qualifier     = EVENTTYPE_RECOVERY;
    EventBracket.CurrentState  = EVENTSTATE_RETURN;
    EventBracket.EventPacket   = EVENTPACKET_SYSTEM;
    EventBracket.SystemEvent.SoftfailStatus = FALSE;
    EventBracket.SystemEvent.ChannelNumber  = 0;
    EventBracket.SystemEvent.EventSubType   = a_EventSubType;
    if (pNrmEcl->IsRoomForRegen() == TRUE) {
        return pNrmEcl->AddEvent(&EventBracket);
    }
    return FALSE;
}

#if defined IOMTYPE_DISOE || defined IOPTYPE_DI
/*******************************************************************************
*                           clsBoxSlot::AddPVCLBracketEvent                    *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddPVCLBracketEvent(EVENTSUBTYPE a_EventSubType) {
    EVENTRECORD EventBracket;

    // Create backet event
    EventBracket.Overflow      = FALSE;
    EventBracket.ContactCutout = FALSE;
    EventBracket.Qualifier     = EVENTTYPE_RECOVERY;
    EventBracket.CurrentState  = EVENTSTATE_RETURN;
    EventBracket.EventPacket   = EVENTPACKET_SYSTEM;
    EventBracket.SystemEvent.SoftfailStatus = FALSE;
    EventBracket.SystemEvent.ChannelNumber  = 0;
    EventBracket.SystemEvent.EventSubType   = a_EventSubType;

    if (pPvChngEcl->IsRoomForPVCLRegen() == TRUE)
    {
        return pPvChngEcl->AddPVCLEvent((PVCLEVTRECORD *)&EventBracket);
    }

    return FALSE;
}
#endif
/*******************************************************************************
*                           clsBoxSlot::RegenSoftfails                         *
*                           ==========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::RegenSoftfails(VOID) {

    static UINT8 ucByteCount = 0,ucBitCount = 0,ucMask = 0x01;

    // Iterate for 32 BoxSfBytes and each SlotSfByte.
    while (ucByteCount <= (SFBYTES_SIZE + MaxSlots)) {

        UINT8 ucSfByte,ucSlotNum;
        if (ucByteCount < SFBYTES_SIZE) { //get box softfail byte

            ucSlotNum = 0;
            ucSfByte = BoxSfBits[ucByteCount];
        }
        else { //get slot soft fail byte

            if (SFBYTES_SIZE == ucByteCount) {

                // Return FALSE so that event recovery task will suspend before
                // recovering slot softfails. Increment ucByteCount before
                // returning so that this function will continue with slot soft
                // fail recovery when scheduler resumes event recovery task.
                ucByteCount++;
                return FALSE;
            }
            ucSlotNum = ucByteCount - SFBYTES_SIZE;
            ucSfByte = SLOT(ucSlotNum)->GetSlotSfBt();
        }

        if (ucSfByte > 0) { // any soft fails exists

            while (ucBitCount < BYTESIZE) {

                if (ucSfByte & ucMask) { // Regenerate softfail event

                    SOFTFAILTYPE SoftfailType;
                    if (ucByteCount < SFBYTES_SIZE) { // box softfail

                        SoftfailType = (SOFTFAILTYPE)
                                       ((ucByteCount * BYTESIZE) + ucBitCount);
                    }
                    else { //slot softfail

                        SoftfailType = (SOFTFAILTYPE)SlotSfMap[ucBitCount];
                    }
                    if (FALSE == AddSoftfailEvent(EVENTTYPE_RECOVERY,SoftfailType, TRUE,ucSlotNum))
                    {
                        // Return FALSE so that task will suspend.
                        return FALSE;
                    }
                }
                ucMask <<= 1;
                ucBitCount++;
            }
        }
        // Reinitialize ucMask and ucBitCount for next regeneration.
        ucMask = 0x01;
        ucBitCount = 0;
        ucByteCount++;
    }
    // Reinitialize ucByteCount for next regeneration.
    ucByteCount = 0;

    return TRUE; // Mark end of the softfail recovery.
}

/*******************************************************************************
*                          clsBoxSlot::BoxHouseKeeping                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::BoxHouseKeeping(VOID) {

	CheckFtaPresence();

#if 0
    // Save current interrupt masks and set current masks
    // so that STC or point processing cannot come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    UINT8 ucCount,ucIndex = 0,ucCompositeByte = 0,ucMask = SLOTINFAIL_MASKINIT;
    UINT8 ucByteOffset,ucBitOffset;

    CheckFtaPresence();

    // Update MapSlotInFail parameter
    for (ucCount = 1; ucCount <= MaxSlots; ucCount++) {

        if ((ucByteOffset = SLOT(ucCount)->GetSlotSfBt()) > 0) {

            ucCompositeByte |= ucByteOffset;
            MapSlotInFail[ucIndex] |= ucMask;
        }
        else {

            MapSlotInFail[ucIndex] &= ~ucMask;
        }
        ucMask >>= 1;
        if (0 == ucMask) {

            ucMask = SLOTINFAIL_MASKINIT;
            ucIndex++;
        }

        // Allow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr);
        set_imask_exr(LVLPRI_TICK);
    }

    // Update SlotSfBits from individual SlotSfBt.
    ucMask = 0x01;
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++) {

        if (SF_UNKNOWN != SlotSfMap[ucCount]) {

            ucByteOffset = SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;

            if (ucCompositeByte & ucMask) {

                SlotSfBits[ucByteOffset] |= ucBoxSfMask;
            }
            else {

                SlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
            }
        }
        ucMask <<= 1;

        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr);
        set_imask_exr(LVLPRI_TICK);
    }

    // Count down SlotSfThrottleCount in all slots.
    for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {

        SLOT(ucCount)->CountDownSlotSfThrottle();
    }

    // Rereport ModStat event if required
    if (ModStat1Lrs > 0) {

        AddModStatEvent(EVENTTYPE_NORMAL);
    }

    // Alow STC to run to avoid STC overruns.
    set_imask_exr(ucSaveExr);
    set_imask_exr(LVLPRI_TICK);

#if ( defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE) )
    DIMODE DiModeVal = BOX->GetDiMode();
#ifdef IOMTYPE_DISOE
    if((DIMODE_SOE == DiModeVal) || (DIMODE_LOWLATNCY == DiModeVal))
#else
    if(DIMODE_LOWLATNCY == DiModeVal)
#endif
    {
        // If the module is reloaded with the DiMode as SOE/LOWLATNCY, send OWD RTN event
        // as OpenWireDiag routine will not run in these modes to check OWDEnable param and
        // post the SF_OPENWIRE RTN event.
        for(UINT8 ucChanNum=1;ucChanNum<=MAXSLOTS;ucChanNum++)
        {
            if(TRUE == SLOT(ucChanNum)->IsOwdSfSet())
            {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ucChanNum);
            }
        }
    }
    // Allow STC to run to avoid STC overruns.
    set_imask_exr(ucSaveExr);
    set_imask_exr(LVLPRI_TICK);
    // Post I/P fail soft fail using results saved in ForcedInputDiag.
    UINT32 DiagData,ulMask;
    DiagData = BOX->GetForcedInputDiagStatus();
    for (ucCount = 1,ulMask = 1; ucCount <= MAXSLOTS; ucCount++,ulMask <<= 1)
    {
        if ((ModStat1.Status == MODSTATUS_RUN) &&
            (SLOT(ucCount)->GetPtExecSt() == PTEXECST_ACTIVE) &&
            (DiagData & ulMask))
        {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_INPTFAIL,TRUE,ucCount);
        }
        else
        {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_INPTFAIL,FALSE,ucCount);
        }
    }
#endif

#if (defined(IOMTYPE_DO) || defined(IOMTYPE_UIO))
    for (UINT8 ucChanNum = 1; ucChanNum <= MAXSLOTS; ucChanNum++)
    {
        BOOL bDirection = BOX->GetOverCurrent(ucChanNum);
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,bDirection,ucChanNum);
    }
#endif

    // Periodically recompute database checksums.
    static UINT8 sucSlot = 0;

    // Storing the dump data into the battery backed SRAM slot wise.
    BOX->StoreDatabase(sucSlot, FALSE); // Store database without checksum

    pDatabase[sucSlot++]->ComputeCheckSum();

    if (sucSlot > MAXSLOTS) {
        sucSlot = 0;
    }

    // Restore original interrupt mask and return.
    set_imask_exr(ucSaveExr);
#endif
}

/********************************************************************************************
*                            clsBoxSlot::PreModStat1                                        *
*                            =======================                                        *
* PURPOSE:   Pre Receiver-Beware function for ModStat1 parameter. Checks for module status. *
* ARGUMENTS: a_Writebuffer   -   Pointer to the data to be written.                         *
*            a_ucAccLvl      -   Access level for check                                     *
* RETURN:    PA_OK           -   If pre check is succesfull                                 *
* NOTES:     This method will update ModStat1Trans flag if there is any                     *
*            change in the module status.                                                   *
*********************************************************************************************/
PASTATUS clsBoxSlot::PreModStat1(UINT8 *a_Writebuffer,UINT8) {

    const UINT8 FACTORYMODE_BIT = 0x04; //3rd bit in ModStat1 byte is Factory Mode bit
    UINT8 ucNewMod1State = *(UINT8*)a_Writebuffer;

    if (ucNewMod1State > MODSTATUS_FAIL) {

      return DO_ILLEGAL_VALUE;
    }

    // Return error is module is in the Alive state.
    if (ModStat1.Status == MODSTATUS_ALIVE) {

        return DO_STATE_MUST_BE_IDLE_OR_RUN;
    }

    // Check if calibration is in progress for analog IOMs. 
    // This virtual function returns always FALSE for digtial IOMs.
    if (TRUE == GetCalibAllState()) {

        return DO_CALIB_IN_PROGRESS;
    }

    // Shutdown the IOM if the new value is ALIVE or FAILED.
    if ((MODSTATUS_ALIVE == ucNewMod1State) || (MODSTATUS_FAIL == ucNewMod1State)) {

        if (ModStat1.Status == MODSTATUS_IDLE) {

            //TraceLog.AddToTrace(TRACEID_GENERIC,bcIdleToAlive);

            // Make sure the FaultOpt values are resetted to UNPOWER so that they will
            // Come as UNPOWERED when Module Reboots in ALIVE Mode
            #if (defined(IOMTYPE_DO))
            *(BOX->OutputPorts[0]) = 0;
            *(BOX->OutputPorts[1]) = 0;
            *(BOX->OutputPorts[2]) = 0;
            *(BOX->OutputPorts[3]) = 0;
            HOLDOUT_n = 1;
            HOLDOUT_n = 0;
            #endif

            // Update the FailCode and shutdown IOM.
            FailCode = HF_IOMUSERRESET;
            ShutdownIom();
        }
        else
        {
            return DO_STATE_MUST_BE_IDLE;
        }
    }

    this->ScratchPad = MODSTATUS_NO_TRANS;
    if (ModStat1.Status == MODSTATUS_IDLE) {
        if (ucNewMod1State == MODSTATUS_IDLE) {
            this->ScratchPad  = MODSTATUS_IDLE_IDLE;
        }
        else if (ucNewMod1State == MODSTATUS_RUN) {
            this->ScratchPad  = MODSTATUS_IDLE_RUN;
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcIdleToRun);
        }
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        if (ucNewMod1State == MODSTATUS_IDLE) {
            this->ScratchPad  = MODSTATUS_RUN_IDLE;
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcRunToIdle);
        }
        else if (ucNewMod1State == MODSTATUS_RUN) {
            this->ScratchPad  = MODSTATUS_RUN_RUN;
        }
    }

    //Retain the state of Factory Mode bit when Module state is changed
    if (CheckForFactoryTestMode()) {
        *(UINT8*)a_Writebuffer |= FACTORYMODE_BIT;//Factory Bit
    }

    return PA_OK;
}
/********************************************************************************
*                         clsBoxSlot::PostModStat1                              *
*                         ========================                              *
* PURPOSE:   Post Receiver-Beware function for ModStat1 parameter.  After a     *
*            successfull module status change, this method invokes the Post     *
*            method for Point Execution State parameter (PtExecSt) on each slot.*
*            If there is a module transition from RUN to IDLE or vice versa,    *
*            this generates a module status event.  If the new module state is  *
*            RUN,sets DbValid flag to DB_VALID.                                 *
* ARGUMENTS: a_ucAccLvl      -   Access level for check                         *
* RETURN:    PA_OK           -   If post check is succesfull                    *
* NOTES:     !ToDo! FPGA control on transitions of module status                *
*********************************************************************************/
VOID clsBoxSlot::PostModStat1(UINT8) {
    #if (defined(IOMTYPE_AIH) || defined(IOMTYPE_SVP)||defined(IOMTYPE_SP))
    if (ModStat1.Status == MODSTATUS_IDLE) {
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            SLOT(ucSlotNum)->InactivateSlot();
        }
    }
    #endif

    #if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        SLOT(ucSlotNum)->InactivateSlot();
        if(ScratchPad == MODSTATUS_IDLE_RUN) {
            SLOT(ucSlotNum)->ResetLpBkPassCount();
        }
    }
    #endif

    #if (defined(IOMTYPE_DO))
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        SLOT(ucSlotNum)->InactivateSlot();
    }
    #endif

    #if ( defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE) )
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        if (ScratchPad == MODSTATUS_IDLE_RUN) {
            SLOT(ucSlotNum)->UpdateBadPv();
        }
        else if (ScratchPad == MODSTATUS_RUN_IDLE) {
            SLOT(ucSlotNum)->InactivateSlot();
            SLOT(ucSlotNum)->UpdateBadPv();
        }
    }
    #endif

    #if (defined(IOMTYPE_PI))
    if (ModStat1.Status == MODSTATUS_IDLE) {
        // The following line will be uncommented when the FPGA supports it
        //FPGA_RST = FPGA_RESET;
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            SLOT(ucSlotNum)->InactivateSlot();
        }
        BOX->SetForceSafe(FORCEDSAFE_ON);
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        BOX->SetForceSafe(FORCEDSAFE_OFF);
        // If going to RUN, clear all AVRAW counters and PL timers
        if (ScratchPad == MODSTATUS_IDLE_RUN) {
            UINT8 ucSaveExr = get_imask_exr();          // save current Int mask
            set_imask_exr(LVLPRI_TICK);         //disable STC and FPGA interrupts
            for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++)
                SLOT(ucSlotNum)->ClrCtrArchive();
            CCCR.FPGAWORDREG = 0xFFFF;
            CCCR.FPGAWORDREG = 0;
            set_imask_exr(ucSaveExr);                   // restore Int mask
        }
    }
    #endif

    #if (defined(IOMTYPE_UIO))
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        switch (SLOT(ucSlotNum)->GetPntType()) {
            // output channels: always call InactivateSlot()
            case PNTTYPE_ANALOGOUTPUT:
            case PNTTYPE_DIGITALOUTPUT:
                OUT_SLOT(ucSlotNum)->InactivateSlot();
                break;

            // digital input channels: check ScratchPad for correct behavior
            case PNTTYPE_DIGITALINPUT:
                if (ScratchPad == MODSTATUS_IDLE_RUN) {
                    if((ucSlotNum >= PC_CHANNEL1) && (ucSlotNum <= PC_CHANNEL4))
                    {
                        BOX->StoreAvRaw(ucSlotNum,0);
                        FPGA.ClrCounter(ucSlotNum);
                    }
                    DI_SLOT(ucSlotNum)->UpdateBadPv();
                }
                else if (ScratchPad == MODSTATUS_RUN_IDLE) {
                    DI_SLOT(ucSlotNum)->InactivateSlot();
                    DI_SLOT(ucSlotNum)->UpdateBadPv();
                }
                break;

            // analog input channels: call InactivateSlot() if MODSTATUS_IDLE
            case PNTTYPE_ANALOGINPUT:
                if (ModStat1.Status == MODSTATUS_IDLE) {
                    AIH_SLOT(ucSlotNum)->InactivateSlot();
                }
                break;

            default: // Null PntType
                // do nothing
                break;
        }
    }
    #endif // IOMTYPE_UIO

    if (ModStat1.Status == MODSTATUS_RUN) {
        // Mark the Database to be valid.
        DbValid = DB_VALID; 
    #if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        // start the SOE ISR if DiMode is not Normal
        if( DIMODE_NORMAL != BOX->GetDiMode() ) {
            // for the first time after the IOM made RUN, do
            // initialization of SOE State Machine Input buffer.
            #ifdef IOMTYPE_DISOE
            BOX->ScanChannel();
            #endif
            TPU0_CST = 1;       // Start the DISOE timer.
        }
    }

    if (ModStat1.Status == MODSTATUS_IDLE) {
        if(DIMODE_SOE != BOX->GetDiMode()){
            // SOE ISR should run in Idle Mode also as the TPU2 counter
            // wrap is handled in SOE ISR only.
            TPU0_CST = 0;       // Stop the DISOE timer.
        }
    #endif // IOMTYPE_DI || IOMTYPE_DISOE
    }

    if ((ScratchPad == MODSTATUS_IDLE_RUN) || (ScratchPad == MODSTATUS_RUN_IDLE)){
        AddModStatEvent(EVENTTYPE_NORMAL);
        #if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
        //for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        //    SLOT(ucSlotNum)->GetHartDevDb().ControlStateChange();
        //}
        #elif defined(IOMTYPE_UIO)
        
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            switch (SLOT(ucSlotNum)->GetPntType()) {
                case PNTTYPE_ANALOGINPUT:
                    AIH_SLOT(ucSlotNum)->GetHartDevDb().ControlStateChange();
                    break;

                case PNTTYPE_ANALOGOUTPUT:
                    AOH_SLOT(ucSlotNum)->GetHartDevDb().ControlStateChange();

                default:
                    // No hart for DI and DO
                    break;
            }
            
        }

        #endif
    }
}

/*******************************************************************************
*                                    isOddParity                               *
*                                    ===========                               *
* PURPOSE   : Test for odd no of 1's in a binary number.                       *
* ARGUMENTS : UINT8 - variable to be tested.                                   *
* RETURN    : TRUE if the variable is ODD, else FALSE.                         *
* NOTES     :                                                                  *
*******************************************************************************/
BOOL clsBoxSlot::isOddParity(UINT8 ucBinary)
{
    BOOL bParity = 0;

    while (ucBinary)
    {
        bParity = !bParity;

        ucBinary &= (ucBinary - 1);
    }

    return bParity;
}

/*******************************************************************************
*                              SetFactoryTestMode                              *
*                              ==================                              *
* PURPOSE   : Check factory test hardware and set factory test bit accordingly *
* ARGUMENTS : NONE                                                             *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsBoxSlot::SetFactoryTestMode(VOID)
{
	UINT8 iotabits = (UINT8)hal_fpga_get_iota_status();

#ifdef DBG_PRINT
	PRINTF("  IOTA BITS: %02X\r\n", iotabits);
#endif

	// if REDUNT_n=1 (FTA missing), BOTTOM=0 (IOPB) & BUPREQ_IN=0(SWITCHED=0), set IOP in Factory Test Mode.
	ModStat1.Factory = 0;
}

