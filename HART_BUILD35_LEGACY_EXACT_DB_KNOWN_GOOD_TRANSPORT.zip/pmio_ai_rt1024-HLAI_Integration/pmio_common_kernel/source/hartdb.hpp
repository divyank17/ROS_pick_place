/*******************************************************************************
*    File Name   : hartdb.hpp                                                  *
*    Description : HART database classes declaration.                          *
*******************************************************************************/
#ifndef __HARTDB_HPP__
#define __HARTDB_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "datatype.h"
#include "hart.h"
#include "hartstack.hpp"
#include "ecl.hpp"
#include "ioslot.hpp"
#if defined(IOMTYPE_AIH)
#include "boxslot.hpp"
#endif

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagHScanCfg {
    HSCANCFG_UNDEFINED      = 0,
    HSCANCFG_1SECDEV        = 1,
    HSCANCFG_1SECDYN        = 2,
    HSCANCFG_2SECDEV        = 3,
    HSCANCFG_2SECDYN        = 4,
    HSCANCFG_2SECDEVDYN     = 5,
    HSCANCFG_4SECDEV        = 6,
    HSCANCFG_4SECDYN        = 7,
    HSCANCFG_4SECDEVDYN     = 8,
    HSCANCFG_8SECDEV        = 9,
    HSCANCFG_8SECDYN        = 10,
    HSCANCFG_8SECDEVDYN     = 11,
    HSCANCFG_16SECDEV       = 12,
    HSCANCFG_16SECDYN       = 13,
    HSCANCFG_16SECDEVDYN    = 14,
    HSCANCFG_STATUSONLY     = 15
} HSCANCFG;

typedef enum tagHScanRate {
    HSCANRATE_NONE  = 0,
    HSCANRATE_16SEC = 1,
    HSCANRATE_8SEC  = 2,
    HSCANRATE_4SEC  = 4,
    HSCANRATE_2SEC  = 8,
    HSCANRATE_1SEC  = 16
} HSCANRATE;

typedef enum tagHComSts {
    HCOMSTS_GOOD          = 0,
    HCOMSTS_NORESPONSE    = 1,
    HCOMSTS_IOMFOUNDERROR = 2,
    HCOMSTS_DEVFOUNDERROR = 3,
    HCOMSTS_CHANNELERROR  = 4
} HCOMSTS;

typedef enum tagCommand {
    COMMAND_UNDEFINED    = 0,
    COMMAND_ACCEPTCFG    = 9,
    COMMAND_RESETHCOMERR = 10
} COMMAND;

typedef enum tagHChanType {
    HCHANTYPE_UNKNOWN,
    HCHANTYPE_CHANNEL,
    HCHANTYPE_PASSTHROUGH
} HCHANTYPE;

typedef enum tagHChanMode {
    HCHANMODE_INIT,
    HCHANMODE_SCAN
} HCHANMODE;

typedef enum tagHScanMsg {
    HSCANMSG_NONE,
    HSCANMSG_DYN,
    HSCANMSG_DEV,
    HSCANMSG_C48,
    HSCANMSG_PST
} HSCANMSG;

typedef enum tagHDataInit {
    HDATAINIT_PENDING  = 0,
    HDATAINIT_COMPLETE = 1
} HDATAINIT;

typedef enum tagHEventInit {
    HEVENTINIT_PENDING = 0,
    HEVENTINIT_COMFAIL = 1,
    HEVENTINIT_C48FAIL = 2,
    HEVENTINIT_SUCCESS = 3
} HEVENTINIT;

typedef enum tagHReplyStatus {
    HREPLYSTATUS_GOOD,
    HREPLYSTATUS_CONTINUE,
    HREPLYSTATUS_BUSY,
    HREPLYSTATUS_MORE,
    HREPLYSTATUS_REINIT,
    HREPLYSTATUS_BAD
} HREPLYSTATUS;

typedef enum tagHPstStatus {
    HPSTSTATUS_IDLE         = 0,
    HPSTSTATUS_BUSY         = 0xCA,
    HPSTSTATUS_RUNNING      = 0xCB,
    HPSTSTATUS_INIT         = 0xCC,
    HPSTSTATUS_DEAD         = 0xCD,
    HPSTSTATUS_SUCCESS      = 0xCE
} HPSTSTATUS;

class clsHartDevDb;
typedef struct tagHartCmdHandler {
    HREPLYSTATUS (clsHartDevDb::* GoodHandler)(VOID);
    HREPLYSTATUS (clsHartDevDb::* BadHandler)(UINT8);
} HARTCMDHANDLER;

#define PARAMID_SLOTCFGD     39
#define PARAMID_HDYNRATE    193
#define PARAMID_HDEVRATE    194
#define PARAMID_HSLOTDVCBLND 40
#define PARAMID_HSLOTDVCBLND7 41
#define PARAMID_LRV         132
#define PARAMID_URV         133
#define PARAMID_LRL         134
#define PARAMID_URL         135

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
const UINT8  HART6_MAXVAR_COUNT   = 4;
const UINT8  HART_MAXVAR_COUNT    = 8;
const UINT8  HART_MAXDYNVAR_COUNT = 4;
const UINT8  HNTFYCFG_BYTECOUNT   = HART_CMD48_RESPONSE_SIZE * 2;
const UINT16 HCOMTHRS_DEFAULT     = 100;
const UINT16 HCOMHYS_DEFAULT      = 10;

const UINT8 MIN_CYCLE_NUMBER    = 1;
const UINT8 MAX_CYCLE_NUMBER    = 16;
const UINT8 MAX_MSGS_IN_A_CYCLE = 3;
const UINT8 FIRST_SCAN_MSG      = 0;
const UINT8 FIRST_B2B_MSG       = 1;
const UINT8 FINAL_B2B_MSG       = 2;

const INT16 TICKS_IN_1_SEC      = 1;
const INT16 TICKS_IN_2_SEC      = TICKS_IN_1_SEC * 2;
const INT16 TICKS_IN_4_SEC      = TICKS_IN_1_SEC * 4;
const INT16 TICKS_IN_8_SEC      = TICKS_IN_1_SEC * 8;
const INT16 TICKS_IN_16_SEC     = TICKS_IN_1_SEC * 16;
const INT16 TICKS_IN_30_SEC     = TICKS_IN_1_SEC * 30;
const INT16 TICKS_IN_60_SEC     = TICKS_IN_1_SEC * 60;
const INT16 TICKS_IN_64_SEC     = TICKS_IN_1_SEC * 64;
const INT16 TICKS_SYNCED_CHAN   = 0;
const INT16 TICKS_DISABLE_SCAN  = -1;

const HSCANRATE HSCANCFG_TABLE[HSCANCFG_STATUSONLY+1][2] = {
    HSCANRATE_NONE, HSCANRATE_NONE,
    HSCANRATE_1SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_1SEC,
    HSCANRATE_2SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_2SEC,
    HSCANRATE_2SEC, HSCANRATE_2SEC,
    HSCANRATE_4SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_4SEC,
    HSCANRATE_4SEC, HSCANRATE_4SEC,
    HSCANRATE_8SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_8SEC,
    HSCANRATE_8SEC, HSCANRATE_8SEC,
    HSCANRATE_16SEC,HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_16SEC,
    HSCANRATE_16SEC,HSCANRATE_16SEC,
    HSCANRATE_NONE, HSCANRATE_NONE
};

const UINT8 HARTCMD0[]   = { HARTCOMMAND_ZERO,0 };
const UINT8 HARTCMD38[]  = { HARTCOMMAND_THIRTYEIGHT,0 };
const UINT8 HARTCMD48[]  = { HARTCOMMAND_FOURTYEIGHT,0 };
const UINT8 HARTCMD109[] = { HARTCOMMAND_HUNDREDNINE,1,0};

const UINT8 HART_INITCOMMAND_COUNT  = 11;
const UINT8 HART_INITCMD14_INDEX    = 6;
const UINT8 HART_INITCMD15_INDEX    = 7;

const UINT8 HART5_INIT_COMMANDS[HART_INITCOMMAND_COUNT][3] = {
    { HARTCOMMAND_FOURTYEIGHT,0 },
    { HARTCOMMAND_FIFTYNINE,1,5 },
    { HARTCOMMAND_SIX,1,0 },
    { HARTCOMMAND_THIRTYEIGHT,0 },
    { HARTCOMMAND_TWELVE,0 },
    { HARTCOMMAND_THIRTEEN,0 },
    { HARTCOMMAND_FOURTEEN,0 },
    { HARTCOMMAND_FIFTEEN,0 },
    { HARTCOMMAND_SIXTEEN,0 },
    { HARTCOMMAND_TWENTY,0 },
    { HARTCOMMAND_FIFTY,0 }
};

const UINT8 HART6_INIT_COMMANDS[HART_INITCOMMAND_COUNT][4] = {
    { HARTCOMMAND_FOURTYEIGHT,0 },
    { HARTCOMMAND_FIFTYNINE,1,5 },
    { HARTCOMMAND_SIX,2,0,1 },
    { HARTCOMMAND_THIRTYEIGHT,0 },
    { HARTCOMMAND_TWELVE,0 },
    { HARTCOMMAND_THIRTEEN,0 },
    { HARTCOMMAND_FOURTEEN,0 },
    { HARTCOMMAND_FIFTEEN,0 },
    { HARTCOMMAND_SIXTEEN,0 },
    { HARTCOMMAND_TWENTY,0 },
    { HARTCOMMAND_FIFTY,0 }
};

const UINT8 HART7_INIT_COMMANDS[HART_INITCOMMAND_COUNT][4] = {
    { HARTCOMMAND_FOURTYEIGHT,0 },
    { HARTCOMMAND_FIFTYNINE,1,5 },
    { HARTCOMMAND_SIX,2,0,1 },
    { HARTCOMMAND_THIRTYEIGHT,2,0,0 },
    { HARTCOMMAND_TWELVE,0 },
    { HARTCOMMAND_THIRTEEN,0 },
    { HARTCOMMAND_FOURTEEN,0 },
    { HARTCOMMAND_FIFTEEN,0 },
    { HARTCOMMAND_SIXTEEN,0 },
    { HARTCOMMAND_TWENTY,0 },
    { HARTCOMMAND_FIFTY,0 }
};

const UINT8 HGCHNGFL_STATUSCOUNT_BIT0 = 0x01;
const UINT8 HGCHNGFL_STATUSCOUNT_BIT1 = 0x02;
const UINT8 HGCHNGFL_CONFIGCOUNT_BIT0 = 0x04;
const UINT8 HGCHNGFL_CONFIGCOUNT_BIT1 = 0x08;
const UINT8 HGCHNGFL_INITCMPLT_BIT    = 0x10;
const UINT8 HGCHNGFL_COMMSTATUS_BIT   = 0x20;
const UINT8 HGCHNGFL_SECMASTER_BIT    = 0x40;
const UINT8 HGCHNGFL_PSTSTATUS_BIT    = 0x80;

const UINT8 HART_SCANMSG_SIZE = 10;
const UINT8 HART_CHANBUFFER_SIZE = 84;
const UINT8 HART_DEFAULT_PREAMBLECOUNT = 10;
const UINT8 HART_AUTODISCOVERY_RETRYCOUNT = 1;
const UINT16 HART_COMMERROR_MAXCOUNT = MAXUINT16;
const UINT8 MAX_TEMPLATECHANGE_WAITCOUNT = 16;
const UINT8 HALF_TEMPLATECHANGE_WAITCOUNT = MAX_TEMPLATECHANGE_WAITCOUNT/2;
const UINT8 MAX_1SEC_CHANNELS = 2;
const UINT8 HPST_OBJECTCOUNT    = 16;
const UINT8 HPST_TIMEOUT_COUNT  = 180;
const UINT8 HPST_B2BMSG_MAXCOUNT = 3;
const UINT8 HPST_DELIMITER_OFFSET = 0;
#if !defined(IOMTYPE_AIH)
const UINT8 INVALID_HANDLE      = 0xFF;
const UINT8 INVALID_SLOTNUM     = 0xFF;
const UINT8 INVALID_HANDLE_MASK = 0x80;
#endif
const UINT8 HPST_ADDRESS_OFFSET   = 1;
const UINT8 HPST_COMMAND_OFFSET   = 6;
const UINT8 HPST_BYTECOUNT_OFFSET = 7;
const UINT8 HPST_MESSAGE_OVERHEAD = 10;
const UINT8 HART6_CMD0_RESPONSE_SIZE = 17;

#define PARAMID_HALARMENABLE 190
#define PARAMID_HENABLE     191
#define PARAMID_HSCANCFG    192
#define PARAMID_HSLOTDVC    195
#define PARAMID_HCOMTHRS    196
#define PARAMID_HCOMHYS     197
#define PARAMID_HDYNVAL     211
#define PARAMID_HSLOTEU     218
#define PARAMID_HDVMFGCD    224
#define PARAMID_HDEVIDCD    225
#define PARAMID_HDVTYPCD    226
#define PARAMID_HDVREVCD    227
#define PARAMID_HDDREVCD    228
#define PARAMID_HNTFYCFG    230
#define PARAMID_HDVMFGCD7   184
#define PARAMID_HDVTYPCD7   185
#define PARAMID_HSLOT0TS    186

const UINT8 HART_DEVST_BYTECOUNT = 4;
const UINT8 HART_SLT0TS_MSEC = 32;
const UINT8 HART_SLT0TS_TIMEOFDAY = 10;

const UINT8 HART_DEVST0_PRIVAROUTLIMIT_MASK     = 0x01;
const UINT8 HART_DEVST0_NPRIVAROUTLIMIT_MASK    = 0x02;
const UINT8 HART_DEVST0_LOOPCURSATURATED_MASK   = 0x04;
const UINT8 HART_DEVST0_LOOPCURFIXED_MASK       = 0x08;
const UINT8 HART_DEVST0_MORESTATUSAVLBL_MASK    = 0x10;
const UINT8 HART_DEVST0_DEVICECOLDSTART_MASK    = 0x20;
const UINT8 HART_DEVST0_CONFIGCHANGED_MASK      = 0x40;
const UINT8 HART_DEVST0_DEVICEMALFUNCTION_MASK  = 0x80;
const UINT8 HART_DEVST1_DEVMISMATCH_MASK = 0x01;
const UINT8 HART_DEVST1_REVMISMATCH_MASK = 0x02;
const UINT8 HART_DEVST1_DEVCHANGED_MASK  = 0x04;
const UINT8 HART_DEVST1_SECMASTER_MASK   = 0x08;
const UINT8 HART_DEVST1_COMMFAIL_MASK    = 0x10;
const UINT8 HART_DEVST1_EXCOMMERR_MASK   = 0x20;
const UINT8 HART_DEVST1_CMDFAIL_MASK     = 0x40;
const UINT8 HART_DEVST1_SCANOVRUN_MASK   = 0x80;
const UINT8 HART_DEVST2_RANGEMISMATCH_MASK  = 0x01;
const UINT8 HART_DEVST2_SPAREBIT1_MASK      = 0x02;
const UINT8 HART_DEVST2_SPAREBIT2_MASK      = 0x04;
const UINT8 HART_DEVST2_SPAREBIT3_MASK      = 0x08;
const UINT8 HART_DEVST2_SPAREBIT4_MASK      = 0x10;
const UINT8 HART_DEVST2_SPAREBIT5_MASK      = 0x20;
const UINT8 HART_DEVST2_SPAREBIT6_MASK      = 0x40;
const UINT8 HART_DEVST2_SPAREBIT7_MASK      = 0x80;
const UINT8 HART_DEVST3_MAINTAINREQD_MASK   = 0x01;
const UINT8 HART_DEVST3_DEVVALALERT_MASK    = 0x02;
const UINT8 HART_DEVST3_RESERVEDBIT2_MASK   = 0x04;
const UINT8 HART_DEVST3_RESERVEDBIT3_MASK   = 0x08;
const UINT8 HART_DEVST3_RESERVEDBIT4_MASK   = 0x10;
const UINT8 HART_DEVST3_RESERVEDBIT5_MASK   = 0x20;
const UINT8 HART_DEVST3_RESERVEDBIT6_MASK   = 0x40;
const UINT8 HART_DEVST3_RESERVEDBIT7_MASK   = 0x80;
const UINT8 HART_DEVST_EVENT_ENABLE[HART_DEVST_BYTECOUNT] = { 0xEF,0xFF,0x01,0x03 };
const UINT8 HART_DEVST_ALARM_ENABLE[HART_DEVST_BYTECOUNT] = { 0xAF,0xBF,0x01,0x03 };
const UINT8 HEVENT_COMFAIL   = 12;
const UINT8 HEVENT_EXCOMFAIL = 13;
const UINT8 HALARMENABLE_ALMENBSTATE_MASK = 0x01;
const UINT8 HALARMENABLE_JOURNALONLY_MASK = 0x80;
const UINT8 HALARMENABLE_ALMENBSTATE_RSTVAL = 0x00;
const UINT8 HALARMENABLE_ALMENBSTATE_SETVAL = 0x01;
const UINT8 HALARMENABLE_JOURNALONLY_RSTVAL = 0x40;
const UINT8 HALARMENABLE_JOURNALONLY_SETVAL = 0x80;

/*******************************************************************************
*                              RT1024 database                                 *
*******************************************************************************/
typedef struct {
    BOOL valid;
    UINT8 channel;
    UINT8 modem;
    UINT8 pollAddr;
    UINT8 longAddr[HART_LONGADDR_LENGTH];
    UINT8 responsePreambles;

    UINT8 expandedDeviceType;
    UINT8 manufacturer;
    UINT8 deviceType;
    UINT8 hartRevision;
    UINT8 deviceRevision;
    UINT8 softwareRevision;
    UINT8 hardwareRevisionPhysical;
    UINT8 flags;
    UINT8 uniqueId[HART_DEVICEID_SIZE];

    UINT8 cmd0Status0;
    UINT8 cmd0Status1;
    UINT8 cmd48Status0;
    UINT8 cmd48Status1;
    /* RT1024 decoded CMD3 status retained for hardware diagnostics. */
    UINT8 cmd3Status0;
    UINT8 cmd3Status1;
    UINT8 cmd59Status0;
    UINT8 cmd59Status1;

    BOOL dynamicValid;
    FLOAT32 loopCurrentMa;
    FLOAT32 dynamicValue[HART_MAXDYNVAR_COUNT];
    UINT8 dynamicUnit[HART_MAXDYNVAR_COUNT];
    UINT8 dynamicCount;
} HartDeviceInfo_t;

/*******************************************************************************
*                               clsHartCfgDb                                   *
*******************************************************************************/
class clsHartCfgDb {
public:
    BOOL        HEnable;
    HSCANCFG    HScanCfg;
    BLIND       HSlotDvc[HART6_MAXVAR_COUNT];
    UINT16      HComThrs;
    UINT16      HComHys;
    BLIND       HDvMfgCd;
    BLIND       HDevIdCd[HART_DEVICEID_SIZE];
    BLIND       HDvTypCd;
    BLIND       HDvRevCd;
    BLIND       HDdRevCd;
    BLIND       HNtfyCfg[HNTFYCFG_BYTECOUNT];
    BOOL        HAlarmEnable;
    BOOL        HAlarmEnableLrs;

    static const UINT8 HDevCd[];
    VOID *operator new(size_t) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }
    clsHartCfgDb(const clsHartCfgDb&);
    clsHartCfgDb& operator=(const clsHartCfgDb&);
    clsHartCfgDb(VOID) { InitCfgDb(); }
    ~clsHartCfgDb(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }
    VOID InitCfgDb(VOID);
};

/*******************************************************************************
*                               clsHartCfgDb7                                  *
*******************************************************************************/
class clsHartCfgDb7 {
public:
    BLIND       HSlotDvc7[HART_MAXVAR_COUNT];
    BLIND       HDvMfgCd7[sizeof(UINT16)];
    BLIND       HDvTypCd7[sizeof(UINT16)];
    VOID *operator new(size_t) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }
    clsHartCfgDb7(const clsHartCfgDb7&);
    clsHartCfgDb7& operator=(const clsHartCfgDb7&);
    clsHartCfgDb7(VOID) { InitCfgDb(); }
    ~clsHartCfgDb7(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }
    VOID InitCfgDb(VOID);
};

/*******************************************************************************
*                               clsHartDevDb                                   *
*                               ============                                   *
*  The public members and command-handler names are kept close to the original *
*  HART database class so maintenance and integration code can use the same    *
*  symbols. The low-level transaction bytes are supplied by the RT1024 FPGA    *
*  HART stack.                                                                *
*******************************************************************************/
class clsHartDevDb {
    const UINT8 m_cucParent;
    clsHartCfgDb * const m_pHartCfgDb; 
    clsHartCfgDb7 * const m_pHartCfgDb7;
    static const HARTCMDHANDLER HartCmdHandler[];
    static UINT8 m_stucNoOf1SecChannels;

public:
    HCHANMODE   m_HChanMode;
    HCHANTYPE   m_HChanType;
    HDATAINIT   m_HDataInit;
    HEVENTINIT  m_HEventInit;
    UINT8       m_ucLastDsa;

    // Scan table related members. Scan table is a 16 x 3 table that
    // specifies HART command sequence when channel is in scan mode.
    HSCANMSG    m_ScanMsgTbl[MAX_CYCLE_NUMBER][MAX_MSGS_IN_A_CYCLE];
    INT16       m_sScanCounter;  // Channel heartbeats to the next scan.
    UINT8       m_ucScanNo;      // Next row of scan table to process.
    UINT8       m_ucSavedScanNo; // Scan table row for the current scan.
    UINT8       m_ucB2BNo;       // Scan table column for the current scan.
    UINT8       m_ucSkipC48Cycles; // Number of command 48 scans to skip.

    // Attributes of the discovered device.
    HARTUNIQUEADDR  m_UniqueAddress;    
    UINT8           m_ucPollingAddress; 
    UINT8           m_ucHartVersion;
    UINT8           m_ucDeviceRevision; 
    UINT8           m_ucReqdPreambles;  // Preambles required by the device.

    // Members for handling requests and response messages.
    clsClientBuffer m_ChanRcvBuffer;// Channel receive buffer object.
    UINT8   m_ucInitCmdIndex;       // Index to the array of init commands.
    UINT8   m_ucPstAppIndex;        // Index at which last PST message was queued.
    UINT8   m_ucPstRemIndex;        // Next PST Q index to be processed.
    UINT8   m_ucLastReqCmd;         // Last command that was just processed.
    UINT8   m_ucB2BPstMsgCount;     // Number of back-to-back PST requests.
    UINT8   *m_ucpLastXmtPtr;       // XMT buffer pointer to the last CMD.
    UINT8   m_ucLastRespCode;       // Response code the last message.
    UINT8   m_ucNextReqCmd;         // Next command that will be processed.
    UINT8   *m_ucpNextXmtPtr;       // XMT buffer pointer to the next CMD.
#if defined (IOMTYPE_UIO)
    UINT8   *m_ucpLastPstXmtPtr;    // Transmit buffer pointer to last PST
    UINT8   *m_ucpNextPstXmtPtr;    // Transmit buffer pointer to next PST
    UINT8   m_ucLastPstCmd;         // Last PST command transmitted
    UINT8   m_ucNextPstCmd;         // Next PST command that will be processed
#endif
    UINT8   m_ucRcvBufIndex;        // Index in the receive buffer.
    UINT8   m_ucRcvMsgLen;          // Length of the received response.
    UINT8   m_ucDynScan[HART_SCANMSG_SIZE]; // Dynamic scan XMT buffer. 
    UINT8   m_ucDevScan[HART_SCANMSG_SIZE]; // Device scan XMT buffer

    HCOMSTS m_ucCommStatus;     // Current commn status returned by stack.
    UINT8   m_ucDeviceStatus;   // Device status byte in the response. 
    UINT8   m_ucSecMasterResetCounter;  // To throttle SecMaster alarm.
    UINT8   m_ucScanOverrunCounter;     // To throttle ScanOverrun alarm.
    UINT8   m_ucPstPresentCounter;
    BOOL    m_bCmd38FailReported;   // To avoid repeated posting of alarm.
    BOOL    m_bCmd48FailReported;   // To avoid repeated posting of alarm.
    BOOL    m_bReReportEvents;      // Re-report HART events.
    UINT8   m_ucTemplateChangeWaitCount;// To temporarily suspend HART events on template change.
    BOOL    m_bHartChanFail;

    HCOMSTS     HComSts;
    HCOMSTS     HLComFail;
    UINT16      HNComErr;
    HARTCOMMAND HCmdFail;
    BLIND       HCmdResp;

    BLIND       HDevSt[HART_DEVST_BYTECOUNT];
    BLIND       HDevStLrs[HART_DEVST_BYTECOUNT];
    BLIND       HDynDvc[HART_MAXDYNVAR_COUNT];
    HSCANRATE   HDynRate;
    HSCANRATE   HDevRate;
    HSCANRATE   HTotalRate;
    COMMAND     Command;

    HARTCMD0RESPONSE    HCmd0;
    HARTCMD3RESPONSE    HCmd12;
    HARTCMD13RESPONSE   HCmd13;
    HARTCMD14RESPONSE   HCmd14;
    HARTCMD15RESPONSE   HCmd15;
    HARTCMD16RESPONSE   HCmd16;
    HARTLONGTAG_RESPONSE   HLongTag;
    HARTCMD48RESPONSE   HCmd48;
    BLIND HCmd48Lrs[HART_CMD48_RESPONSE_SIZE];

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    FLOAT32 Lrv;
    FLOAT32 Urv;
    FLOAT32 Lrl;
    FLOAT32 Url;
    FLOAT32 Damping;
    BLIND   StiEu;
    BLIND   State;

    static const UINT8 HDvRngExt[];
#endif

    FLOAT32 HDynVal[HART_MAXDYNVAR_COUNT];
    BLIND   HDynSt[HART_MAXDYNVAR_COUNT];
    BLIND   HDynCc[HART_MAXDYNVAR_COUNT];
    BLIND   HDynEu[HART_MAXDYNVAR_COUNT];

    FLOAT32 HSlotVal[HART_MAXVAR_COUNT];
    BLIND   HSlotSt[HART_MAXVAR_COUNT];
    BLIND   HSlotCc[HART_MAXVAR_COUNT];
    BLIND   HSlotEu[HART_MAXVAR_COUNT];
    UINT32  HDevSlot0DTS;

    BOOL    m_bAtLeastOneTry;
    UINT32  m_ulDynGoodCount;
    UINT32  m_ulDevGoodCount;
    UINT32  m_ulC48GoodCount;

    static EVENTRECORD HAlmOptChgEvent;

    UINT8 HART7_CMD38[HART_CMD38_RESPONSE_SIZE + 2];
    //UINT8 HART7_CMD48[HART7_CMD48_REQUESTDATA_SIZE+2];
    UINT16 HT5_CfgChngCnt; //Configuration Change counter for HART revision 5.
    HSCANMSG m_ScanMsg; //Parameter to identify which scan is completed.
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(size_t) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); } 
    clsHartDevDb(const clsHartDevDb&); // Safeguard against default copy constructor
    clsHartDevDb& operator=(const clsHartDevDb&); // and default assignment

    clsHartDevDb(UINT8,clsHartCfgDb *,clsHartCfgDb7 *);
    ~clsHartDevDb(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }

    VOID InitDevDb(BOOL); 
    VOID SetHComSts(HCOMSTS);
    BOOL PostHComFail(BOOL);
    BOOL PostHAlmOptChgEvent(BOOL);
    VOID SetHDevSt(UINT8,UINT8);
    VOID SetHCmdFail(HARTCOMMAND,UINT8);
    VOID IncrementHCfgChCounter(VOID);
    VOID IncrementHDevStCounter(VOID);
    VOID ChannelHeartbeat(VOID);
    BOOL ProcessHartEvents(BOOL);
    HSYNCSTATUS ReceptionComplete(HMSGSTATUS);
    VOID LogEvent(HEVENTTYPE);
    VOID BuildScanTable(VOID);
    VOID ControlStateChange(VOID);
    VOID CheckDevMismatch(VOID);
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    VOID CheckRangeMismatch(VOID);
#endif

    VOID WriteHCmdData(HARTCOMMAND,UINT8 *);
    HSYNCSTATUS BumpPollingAddress(VOID);
    HSYNCSTATUS ScheduleFromInitTable(VOID);
    HSYNCSTATUS ScheduleFromScanTable(VOID);
    HSCANMSG SetupScanMessage(UINT8,UINT8);
    HSCANMSG SetupPassThrough(VOID);
    HREPLYSTATUS UpdateDatabase(VOID);
    FLOAT32 GetHartLoading(VOID);

    inline static UINT8 GetNoOf1SecChannels(VOID) { return m_stucNoOf1SecChannels; }
    inline static VOID SetNoOf1SecChannels(UINT8 a_ucCount) {
        m_stucNoOf1SecChannels = a_ucCount; 
    }
    inline static VOID Increment1SecChannels(VOID) { m_stucNoOf1SecChannels++; }
    inline static VOID Decrement1SecChannels(VOID) { 
        if (m_stucNoOf1SecChannels > 0) m_stucNoOf1SecChannels--; 
    }

    inline VOID SetScanCounterForRediscovery(PNTTYPE a_PointType) {
        if (a_PointType != PNTTYPE_NOTCONFIGURED) { // If channel is configured
            if (TRUE == m_pHartCfgDb->HEnable) {    // and HART is enabled, phase rediscovery
                m_sScanCounter = TICKS_IN_30_SEC + m_cucParent;  // based on the channel number.
            }
            else InitDevDb(TRUE);                   // No rediscovery if HART is disabled
        }
        else { // Rediscover after a minute if channel is not configured.
            m_sScanCounter = TICKS_IN_60_SEC;
        }
    }

    inline VOID SetHartChanFail(VOID) { m_bHartChanFail = TRUE; }
    inline VOID ClearHartChanFail(VOID) 
    { 
        m_bHartChanFail = FALSE;
        m_sScanCounter = TICKS_IN_16_SEC;
    }

    HREPLYSTATUS Cmd0GoodHandler(VOID);
    HREPLYSTATUS Cmd0BadHandler(UINT8);
    HREPLYSTATUS Cmd3GoodHandler(VOID);
    HREPLYSTATUS Cmd3BadHandler(UINT8);
    HREPLYSTATUS Cmd6GoodHandler(VOID);
    HREPLYSTATUS Cmd6BadHandler(UINT8);
    HREPLYSTATUS Cmd9GoodHandler(VOID);
    HREPLYSTATUS Cmd9BadHandler(UINT8);
    HREPLYSTATUS Cmd12GoodHandler(VOID);
    HREPLYSTATUS Cmd12BadHandler(UINT8);
    HREPLYSTATUS Cmd13GoodHandler(VOID);
    HREPLYSTATUS Cmd13BadHandler(UINT8);
    HREPLYSTATUS Cmd14GoodHandler(VOID);
    HREPLYSTATUS Cmd14BadHandler(UINT8);
    HREPLYSTATUS Cmd15GoodHandler(VOID);
    HREPLYSTATUS Cmd15BadHandler(UINT8);
    HREPLYSTATUS Cmd16GoodHandler(VOID);
    HREPLYSTATUS Cmd16BadHandler(UINT8);
    HREPLYSTATUS Cmd20GoodHandler(VOID);
    HREPLYSTATUS Cmd20BadHandler(UINT8);
    HREPLYSTATUS Cmd33GoodHandler(VOID);
    HREPLYSTATUS Cmd33BadHandler(UINT8);
    HREPLYSTATUS Cmd38GoodHandler(VOID);
    HREPLYSTATUS Cmd38BadHandler(UINT8);
    HREPLYSTATUS Cmd48GoodHandler(VOID);
    HREPLYSTATUS Cmd48BadHandler(UINT8);
    HREPLYSTATUS Cmd50GoodHandler(VOID);
    HREPLYSTATUS Cmd50BadHandler(UINT8);
    HREPLYSTATUS Cmd59GoodHandler(VOID);
    HREPLYSTATUS Cmd59BadHandler(UINT8);
    HREPLYSTATUS Cmd109GoodHandler(VOID);
    HREPLYSTATUS Cmd109BadHandler(UINT8);

};

VOID HartDb_LoadParsedResponse(clsHartDevDb *a_pHartDevDb,
                               const HartParsedResponse_t *a_pResponse);

class clsHartPst {
    UINT8 m_PstRcvMemory[HART_MAX_BYTECOUNT];

public:
    // expects these names when it posts/monitors HART pass-through messages.
    UINT8           m_ucHandle;
    UINT8           m_ucSlotNumber;
    UINT8           m_ucPstMsgTimeout;
    HPSTSTATUS      m_PstStatus;
    clsClientBuffer m_PstRcvBuffer;

    clsHartPst(VOID);
    VOID *operator new(size_t, UINT8 a_PstNo);
    VOID operator delete(VOID *) {}
    static clsHartPst **PassThroughTable(UINT8 a_ucModemNum);
};

#define CLSHARTPST_SIZE ((sizeof(clsHartPst)+(sizeof(clsHartPst)%2)) / 2)

#if defined(IOMTYPE_UIO)
extern UINT8 g_ucHPstReqBuffer[HARTMODEM_COUNT][HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];
extern clsHartPst *pUioHartPst[HARTMODEM_COUNT][HPST_OBJECTCOUNT];
#else
extern UINT8 g_ucHPstReqBuffer[HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];
extern clsHartPst *pHartPst[HPST_OBJECTCOUNT];
#endif
extern UINT8 g_ucHPstRcvBuffer[HART_MAX_BYTECOUNT * HPST_OBJECTCOUNT];
extern UINT8 *g_pucHPstRcvBuffer;
extern UINT8 g_ucHChanRcvBuffer[HART_CHANBUFFER_SIZE * 16u];
extern UINT8 *g_pucHChanRcvBuffer;
extern UINT16 g_usHPstObjMemory[CLSHARTPST_SIZE * HPST_OBJECTCOUNT];
extern UINT16 g_usModemObjectMemory[HARTMODEM_COUNT * CLSHARTMODEM_SIZE];
extern UINT16 g_usHartQueueObjectMemory[HARTMODEM_COUNT * CLSHARTQUEUE_SIZE];

#ifdef __cplusplus
extern "C" {
#endif

VOID HartDb_Clear(VOID);
VOID HartDb_FinalizeSynchronousDiscovery(UINT8 channel, HARTDISCOVERYRESULT result);
BOOL HartDb_UpdateFromCmd0(UINT8 channel,
                           UINT8 modem,
                           UINT8 pollAddr,
                           const HartParsedResponse_t *cmd0,
                           const UINT8 longAddr[HART_LONGADDR_LENGTH],
                           UINT8 responsePreambles);
VOID HartDb_UpdateCmd48Status(UINT8 status0, UINT8 status1);
VOID HartDb_UpdateCmd59Status(UINT8 status0, UINT8 status1);
BOOL HartDb_UpdateDynamicFromCmd3(const HartParsedResponse_t *cmd3);
BOOL HartDb_HasDevice(VOID);
const HartDeviceInfo_t *HartDb_GetDevice(VOID);
clsHartDevDb *HartDb_GetHartDevDb(VOID);
HREPLYSTATUS HartDb_HandleResponse(const HartParsedResponse_t *response);
BOOL HartDb_GetPrimaryVariable(FLOAT32 *pvOut, UINT8 *unitOut);

#ifdef __cplusplus
}
#endif

#endif
