/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tracelog.cpp                                                *
*    Description : TraceLog class implementation.                              *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#if !defined(CPU_MIMXRT1024CAG4B)
#include <machine.h>
#endif
#include "utils.h"
#include "scheduler.hpp"
#include "tracelog.hpp"
#include "debug.hpp"
#include "boxslot.hpp"
#if defined(CPU_MIMXRT1024CAG4B)
#include <string.h>
#include "commonelectronics.h"
#include "fsl_debug_console.h"
#include "hal/hal_bbsram.h"

extern volatile BOOL  g_bHartTraceLogTestPassed;
extern volatile UINT8 g_ucHartTraceLogTestStartIndex;
extern volatile UINT8 g_ucHartTraceLogTestEndIndex;

static VOID TraceLogBbsramBind(UINT8 *a_pucAppIndex,
                               UINT16 *a_pTraceLevel,
                               TRACERECORD *a_pTraceRecord);
static VOID TraceLogBbsramPersistRecord(UINT8 a_ucIndex);
static VOID TraceLogBbsramPersistCrashBlock(VOID);
static BOOL TraceLogBbsramHasDirtyRecords(VOID);
static BOOL TraceLogBbsramHasPendingWrites(VOID);
#endif
/*******************************************************************************
*                            clsTraceLog::clsTraceLog                          *
*                            ========================                          *
*  Constructor. TraceLog Class Data members are initialize only when IOM is    *
*  power recycled. Trace memory is preserved so when it is restarted by        *
*  pressing reset button to recover from a hard failure.                       *
*******************************************************************************/
clsTraceLog::clsTraceLog(VOID)
{
#if !defined(CPU_MIMXRT1024CAG4B)
    if (FALSE == BOX->GetIomRebooted()) {
#else
    /* RT1024 global objects are created before LPSPI3 is initialized.
     * Initialize the legacy cache now; TraceLogBbsramInit() restores the
     * retained BBSRAM contents later from main(). */
    {
#endif
        // Initialize object only in case of power-on-restart.
        m_TraceLevel = 0;
        m_ucAppIndex = 0;
        pad = 0;

        for (UINT8 ucCount = 0; ucCount < NO_OF_TRACERECORDS; ucCount++) {
            TraceRecord[ucCount].code = 0;
            TraceRecord[ucCount].data = 0;
            TraceRecord[ucCount].time = 0;
        }

        clsBoxSlot::ResetTraceLogTime();

    #if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))

        m_pAppTraceLog = NULL;
        AutoUnlockCount = 0;

    #endif

    }

#if defined(CPU_MIMXRT1024CAG4B)
    TraceLogBbsramBind(&m_ucAppIndex, &m_TraceLevel, TraceRecord);
#endif
}
/*******************************************************************************
*                            clsTraceLog::AddToTrace                           *
*                            =======================                           *
*  Adds traces to the tracelog table and updates the append index.             *
*******************************************************************************/
VOID clsTraceLog::AddToTrace(TRACEID a_TraceId,IOBreadCrumb crumb,UINT32 data)
{ 
    if ((TRACEID_GENERIC == a_TraceId) || (a_TraceId & m_TraceLevel))
    {
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);  // Disable all interrupts
        
        UINT8 ucIndex = m_ucAppIndex;   // Reserve index for this log
        // Check for wrap around and update current index. 
        // Do not allow to overwrite crash traces.
        m_ucAppIndex = (LASTTRACEINDEX <= m_ucAppIndex) ? 0 : (m_ucAppIndex+1);
        
        set_imask_exr(ucSaveExr);

        // Log the trace.
        TraceRecord[ucIndex].code = crumb;
        TraceRecord[ucIndex].data = data;
        TraceRecord[ucIndex].time = clsBoxSlot::GetTraceLogTime();
#if defined(CPU_MIMXRT1024CAG4B)
        TraceLogBbsramPersistRecord(ucIndex);
#endif
    } 
}
/*******************************************************************************
*                          clsTraceLog::CopyCrashTraceBlock                    *
*                          ================================                    *
*  Copies the last 20 traces to crash block (records 80-100) which is an area  *
*  that will never be overwritten by the new traces. Called from HardFail.     *
*******************************************************************************/
VOID clsTraceLog::CopyCrashTraceBlock(VOID) 
{
    UINT8 ucSrcIndex = 0,ucDstIndex = CRASHBLKSTARTINDEX;

    // If the latest trace index is greater than 20, the scenario is simple.  
    // The last 20 traces are copied to the crash block (records 80-100).
    if ( m_ucAppIndex >= CRASHBLOCKSIZE )
    {
        // Start from the trace which is 20 traces away from current AppIndex.
        ucSrcIndex = m_ucAppIndex - CRASHBLOCKSIZE;
        while (ucDstIndex < NO_OF_TRACERECORDS)
        {
            TraceRecord[ucDstIndex].time = TraceRecord[ucSrcIndex].time;
            TraceRecord[ucDstIndex].code = TraceRecord[ucSrcIndex].code;
            TraceRecord[ucDstIndex++].data = TraceRecord[ucSrcIndex++].data;
        }
    }

    else 
    {   // If the latest trace index is < 20, there may be a wrap around.
        
        if (TraceRecord[LASTTRACEINDEX].code > 0) 
        { 
            // A valid code at the last trace index means there was a wrap-
            // around and the last 20 traces are split at the end and 
            // beginning of the array. First copy the older traces which are 
            // at the end of the array.
            ucSrcIndex = (CRASHBLKSTARTINDEX - (CRASHBLOCKSIZE-m_ucAppIndex));

            while (ucSrcIndex < CRASHBLKSTARTINDEX)
            {
                TraceRecord[ucDstIndex].time = TraceRecord[ucSrcIndex].time;
                TraceRecord[ucDstIndex].code = TraceRecord[ucSrcIndex].code;
                TraceRecord[ucDstIndex++].data = TraceRecord[ucSrcIndex++].data;
            }
        }

        // Copy the newer traces which are at the beginning of the array.
        // NOTE: In the case where there was no wrap around, the loop below
        // starts with ucSrcIndex = 0 and ucDstIndex = CRASHBLKSTARTINDEX
        // and continues until (ucSrcIndex < m_ucAppIndex).
        // In the case where there was a wrap around, the loop starts with
        // the values determined by the previous while loop. In this case,
        // both conditions below go FALSE at the same time. ucDstIndex check
        // ensures that write never goes beyond allocated trace memory.
        while ((ucSrcIndex < m_ucAppIndex) && (ucDstIndex < NO_OF_TRACERECORDS))
        {
            TraceRecord[ucDstIndex].time = TraceRecord[ucSrcIndex].time;
            TraceRecord[ucDstIndex].code = TraceRecord[ucSrcIndex].code;
            TraceRecord[ucDstIndex++].data = TraceRecord[ucSrcIndex++].data;
        }
    }
#if defined(CPU_MIMXRT1024CAG4B)
    TraceLogBbsramPersistCrashBlock();
#endif
}

#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))
/*******************************************************************************
*                          clsTraceLog::GetTracelog                            *
*                          ================================                    *
*                                                                              *
*  Redirects reads to app trace log based on trace level setting               *
*******************************************************************************/
VOID* clsTraceLog::GetTracelog(VOID)
{   
    if((TRACEID_APPLOG & m_TraceLevel) && m_pAppTraceLog)
    {
        LockAppTraceLog();
        return m_pAppTraceLog->GetTracelog();
    }
    else
    {
        return TraceRecord;
    }
}
/*******************************************************************************
*                          clsTraceLog::GetLatestTraceIndex                    *
*                          ================================                    *
*                                                                              *
*  Redirects reads to app trace log based on trace level setting               *
*******************************************************************************/
UINT8 clsTraceLog::GetLatestTraceIndex(VOID)
{
    if((TRACEID_APPLOG & m_TraceLevel) && m_pAppTraceLog)
    {
        return m_pAppTraceLog->GetLatestTraceIndex();
    }
    else
    {
        return m_ucAppIndex;
    }
}
/*******************************************************************************
*                          clsTraceLog::LockAppTraceLog                        *
*                          ================================                    *
*                                                                              *
*  Ask app processor not to log        ...........................             *
*******************************************************************************/
VOID clsTraceLog::LockAppTraceLog(VOID) 
{
    if(m_pAppTraceLog)
    {
        AutoUnlockCount = AUTO_UNLOCK_DELAY_COUNT;
        m_pAppTraceLog->SetFlags(COPY_IN_PROGRESS);
    }
}
/*******************************************************************************
*                          clsTraceLog::UnlockAppTraceLog                      *
*                          ================================                    *
*                                                                              *
*  Tell app processor it is free to log        ...........................     *
*******************************************************************************/
VOID clsTraceLog::UnlockAppTraceLog(VOID) 
{
    if(m_pAppTraceLog)
    {
        AutoUnlockCount = 0;
        m_pAppTraceLog->ClearFlags(COPY_IN_PROGRESS);
    }
}
/*******************************************************************************
*                          clsTraceLog::LockTimeoutProc                      *
*                          ================================                    *
*                                                                              *
*  Tell app processor it is free to log        ...........................     *
*******************************************************************************/
VOID clsTraceLog::LockTimeoutProc(VOID)
{
    if(AutoUnlockCount > 0)
    {
        if(--AutoUnlockCount == 0)
        {
            UnlockAppTraceLog();
        }
    }
}

#endif // SP or SVP
/**/


#if defined(CPU_MIMXRT1024CAG4B)
/*******************************************************************************
*                    RT1024 BBSRAM STORAGE ADAPTER                            *
*                                                                              *
*  This section is intentionally below the complete legacy clsTraceLog method *
*  sequence. The class names, data-member names and method order above remain *
*  aligned with the S1 source.                                                  *
*******************************************************************************/
#define TRACELOG_BBSRAM_MAGIC          (0x544C4F47u) /* "TLOG" */
#define TRACELOG_BBSRAM_VERSION        (2u)
#define TRACELOG_HEADER_A_ADDRESS      (0x0000u)
#define TRACELOG_HEADER_B_ADDRESS      (0x0020u)
#define TRACELOG_RECORDS_ADDRESS       (0x0040u)

#pragma pack(push, 1)
typedef struct tagTracePersistentHeader {
    UINT32 Magic;
    UINT16 Version;
    UINT16 HeaderBytes;
    UINT32 Generation;
    UINT32 BootCount;
    UINT32 TraceTime;
    UINT8  AppIndex;
    UINT8  Reserved;
    UINT16 TraceLevel;
    UINT32 Crc32;
} TRACEPERSISTENTHEADER;
#pragma pack(pop)

static_assert(sizeof(TRACEPERSISTENTHEADER) == 28u,
              "Trace BBSRAM header layout changed");
static_assert((TRACELOG_RECORDS_ADDRESS +
               (NO_OF_TRACERECORDS * sizeof(TRACERECORD))) <=
              HAL_BBSRAM_CAPACITY_BYTES,
              "Trace log exceeds BBSRAM capacity");

static UINT8       *s_pucTraceAppIndex = NULL;
static UINT16      *s_pTraceLevel = NULL;
static TRACERECORD *s_pTraceRecord = NULL;
static UINT8        s_ucActiveHeader = 0u;
static UINT32       s_ulGeneration = 0u;
static UINT32       s_ulBootCount = 0u;
static BOOL         s_bBbsramInitialized = FALSE;
static BOOL         s_bBbsramReady = FALSE;

static BOOL         s_bRestoredExistingState = FALSE;

/* Pending-write state is intentionally outside clsTraceLog so the legacy class
 * data-member names and ordering remain unchanged. */
static volatile UINT8 s_aucRecordDirty[NO_OF_TRACERECORDS] = {0u};
static volatile BOOL  s_bHeaderDirty = FALSE;
static BOOL           s_bLowPrioritySummaryPrinted = FALSE;

/* Human-readable console dump state.  It is intentionally outside the legacy
 * clsTraceLog object and prints only one record per LowPriorityTask cycle. */
static BOOL           s_bConsoleDumpActive = FALSE;
static UINT8          s_ucConsoleDumpLatestIndex = 0u;
static UINT8          s_ucConsoleDumpRequested = 0u;
static UINT8          s_ucConsoleDumpPrinted = 0u;
static UINT8          s_ucConsoleDumpScanned = 0u;

volatile BOOL   g_bTraceLogBbsramInitPassed = FALSE;
volatile BOOL   g_bTraceLogWriteReadPassed = FALSE;
volatile BOOL   g_bTraceLogHeaderPassed = FALSE;
volatile BOOL   g_bTraceLogRestoredFromBbsram = FALSE;
volatile BOOL   g_bTraceLogPreviousBootMarkerFound = FALSE;
volatile BOOL   g_bTraceLogRetentionPassed = FALSE;
volatile UINT8  g_ucTraceLogTestRecordIndex = 0u;
volatile UINT8  g_ucTraceLogLatestIndex = 0u;
volatile UINT32 g_ulTraceLogTestMarker = 0u;
volatile UINT32 g_ulTraceLogBootCount = 0u;
volatile UINT32 g_ulTraceLogPreviousMarkerCount = 0u;
volatile UINT32 g_ulTraceLogBbsramErrorCount = 0u;
volatile BOOL   g_bTraceLogConsoleDumpRequest = FALSE;
volatile UINT8  g_ucTraceLogConsoleDumpCount = TRACELOG_CONSOLE_DUMP_RECORDS;

static UINT32 TraceLogBbsramCrc32(const UINT8 *a_pData, UINT32 a_ulLength)
{
    UINT32 ulCrc = 0xFFFFFFFFu;

    for (UINT32 ulIndex = 0u; ulIndex < a_ulLength; ++ulIndex)
    {
        ulCrc ^= a_pData[ulIndex];
        for (UINT8 ucBit = 0u; ucBit < 8u; ++ucBit)
        {
            const UINT32 ulMask = (UINT32)(0u - (ulCrc & 1u));
            ulCrc = (ulCrc >> 1) ^ (0xEDB88320u & ulMask);
        }
    }

    return ~ulCrc;
}

static BOOL TraceLogBbsramHeaderIsValid(const TRACEPERSISTENTHEADER &a_Header)
{
    if ((a_Header.Magic != TRACELOG_BBSRAM_MAGIC) ||
        (a_Header.Version != TRACELOG_BBSRAM_VERSION) ||
        (a_Header.HeaderBytes != sizeof(TRACEPERSISTENTHEADER)) ||
        (a_Header.AppIndex > LASTTRACEINDEX))
    {
        return FALSE;
    }

    const UINT32 ulExpectedCrc = TraceLogBbsramCrc32(
        reinterpret_cast<const UINT8 *>(&a_Header),
        (UINT32)(sizeof(TRACEPERSISTENTHEADER) - sizeof(a_Header.Crc32)));

    return (ulExpectedCrc == a_Header.Crc32) ? TRUE : FALSE;
}

static BOOL TraceLogBbsramGenerationIsNewer(UINT32 a_ulLeft,
                                             UINT32 a_ulRight)
{
    return ((INT32)(a_ulLeft - a_ulRight) > 0) ? TRUE : FALSE;
}

static VOID TraceLogBbsramBind(UINT8 *a_pucAppIndex,
                               UINT16 *a_pTraceLevel,
                               TRACERECORD *a_pTraceRecord)
{
    s_pucTraceAppIndex = a_pucAppIndex;
    s_pTraceLevel = a_pTraceLevel;
    s_pTraceRecord = a_pTraceRecord;
}

static BOOL TraceLogBbsramCommitHeader(VOID)
{
    if ((s_bBbsramReady == FALSE) ||
        (s_pucTraceAppIndex == NULL) ||
        (s_pTraceLevel == NULL))
    {
        return FALSE;
    }

    TRACEPERSISTENTHEADER Header;
    TRACEPERSISTENTHEADER Verify;
    const UINT8 ucTarget = (UINT8)(s_ucActiveHeader ^ 1u);
    const UINT32 ulAddress = (ucTarget == 0u) ?
        TRACELOG_HEADER_A_ADDRESS : TRACELOG_HEADER_B_ADDRESS;

    memset(&Header, 0, sizeof(Header));
    Header.Magic = TRACELOG_BBSRAM_MAGIC;
    Header.Version = TRACELOG_BBSRAM_VERSION;
    Header.HeaderBytes = sizeof(TRACEPERSISTENTHEADER);
    Header.Generation = s_ulGeneration + 1u;
    Header.BootCount = s_ulBootCount;
    Header.TraceTime = clsBoxSlot::GetTraceLogTime();
    Header.AppIndex = *s_pucTraceAppIndex;
    Header.TraceLevel = *s_pTraceLevel;
    Header.Crc32 = TraceLogBbsramCrc32(
        reinterpret_cast<const UINT8 *>(&Header),
        (UINT32)(sizeof(Header) - sizeof(Header.Crc32)));

    if (!hal_bbsram_write(ulAddress, &Header, sizeof(Header)) ||
        !hal_bbsram_read(ulAddress, &Verify, sizeof(Verify)) ||
        (memcmp(&Header, &Verify, sizeof(Header)) != 0))
    {
        return FALSE;
    }

    s_ulGeneration = Header.Generation;
    s_ucActiveHeader = ucTarget;
    return TRUE;
}

static BOOL TraceLogBbsramInitializePersistentState(VOID)
{
    if ((s_pucTraceAppIndex == NULL) ||
        (s_pTraceLevel == NULL) ||
        (s_pTraceRecord == NULL))
    {
        return FALSE;
    }

    memset(s_pTraceRecord, 0,
           (size_t)NO_OF_TRACERECORDS * sizeof(TRACERECORD));
    *s_pucTraceAppIndex = 0u;
    *s_pTraceLevel = 0u;
    s_ulGeneration = 0u;
    s_ulBootCount = 1u;
    s_bRestoredExistingState = FALSE;
    clsBoxSlot::ResetTraceLogTime();
    s_ucActiveHeader = 1u; /* First commit targets header A. */

    if (!hal_bbsram_write(TRACELOG_RECORDS_ADDRESS,
                          s_pTraceRecord,
                          (size_t)NO_OF_TRACERECORDS * sizeof(TRACERECORD)))
    {
        s_bBbsramReady = FALSE;
        return FALSE;
    }

    if ((TraceLogBbsramCommitHeader() == FALSE) ||
        (TraceLogBbsramCommitHeader() == FALSE))
    {
        s_bBbsramReady = FALSE;
        return FALSE;
    }

    memset((void *)s_aucRecordDirty, 0, sizeof(s_aucRecordDirty));
    s_bHeaderDirty = FALSE;
    return TRUE;
}

BOOL TraceLogBbsramInit(VOID)
{
    if (s_bBbsramInitialized != FALSE)
    {
        return s_bBbsramReady;
    }

    s_bBbsramInitialized = TRUE;

    if ((s_pucTraceAppIndex == NULL) ||
        (s_pTraceLevel == NULL) ||
        (s_pTraceRecord == NULL))
    {
        return FALSE;
    }

    s_bBbsramReady = hal_bbsram_init() ? TRUE : FALSE;
    if (s_bBbsramReady == FALSE)
    {
        return FALSE;
    }

    TRACEPERSISTENTHEADER HeaderA;
    TRACEPERSISTENTHEADER HeaderB;
    const BOOL bReadA = hal_bbsram_read(TRACELOG_HEADER_A_ADDRESS,
                                       &HeaderA, sizeof(HeaderA)) ? TRUE : FALSE;
    const BOOL bReadB = hal_bbsram_read(TRACELOG_HEADER_B_ADDRESS,
                                       &HeaderB, sizeof(HeaderB)) ? TRUE : FALSE;
    const BOOL bValidA = (bReadA != FALSE) ?
        TraceLogBbsramHeaderIsValid(HeaderA) : FALSE;
    const BOOL bValidB = (bReadB != FALSE) ?
        TraceLogBbsramHeaderIsValid(HeaderB) : FALSE;
    const TRACEPERSISTENTHEADER *pSelected = NULL;

    if ((bValidA == FALSE) && (bValidB == FALSE))
    {
        const BOOL bInitialized = TraceLogBbsramInitializePersistentState();
        g_bTraceLogBbsramInitPassed = bInitialized;
        return bInitialized;
    }

    if ((bValidA != FALSE) &&
        ((bValidB == FALSE) ||
         TraceLogBbsramGenerationIsNewer(HeaderA.Generation,
                                         HeaderB.Generation)))
    {
        pSelected = &HeaderA;
        s_ucActiveHeader = 0u;
    }
    else
    {
        pSelected = &HeaderB;
        s_ucActiveHeader = 1u;
    }

    if (!hal_bbsram_read(TRACELOG_RECORDS_ADDRESS,
                         s_pTraceRecord,
                         (size_t)NO_OF_TRACERECORDS * sizeof(TRACERECORD)))
    {
        return FALSE;
    }

    s_bRestoredExistingState = TRUE;
    *s_pucTraceAppIndex = pSelected->AppIndex;
    *s_pTraceLevel = pSelected->TraceLevel;
    s_ulGeneration = pSelected->Generation;
    s_ulBootCount = pSelected->BootCount + 1u;
    clsBoxSlot::RestoreTraceLogTime(pSelected->TraceTime);

    memset((void *)s_aucRecordDirty, 0, sizeof(s_aucRecordDirty));
    s_bHeaderDirty = FALSE;

    const BOOL bHeaderCommitted = TraceLogBbsramCommitHeader();
    g_bTraceLogBbsramInitPassed =
        ((s_bBbsramReady != FALSE) && (bHeaderCommitted != FALSE)) ? TRUE : FALSE;
    return bHeaderCommitted;
}

static VOID TraceLogBbsramPersistRecord(UINT8 a_ucIndex)
{
    if ((s_bBbsramReady == FALSE) ||
        (s_pTraceRecord == NULL) ||
        (a_ucIndex >= NO_OF_TRACERECORDS))
    {
        return;
    }

    /* Match the legacy TraceLog timing: AddToTrace() updates RAM and returns.
     * The external SPI write is deferred to LowPriorityTask. */
    const UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    s_aucRecordDirty[a_ucIndex] = 1u;
    s_bHeaderDirty = TRUE;
    set_imask_exr(ucSaveExr);
}

static BOOL TraceLogBbsramHasDirtyRecords(VOID)
{
    for (UINT8 ucIndex = 0u; ucIndex < NO_OF_TRACERECORDS; ++ucIndex)
    {
        if (s_aucRecordDirty[ucIndex] != 0u)
        {
            return TRUE;
        }
    }

    return FALSE;
}

static BOOL TraceLogBbsramHasPendingWrites(VOID)
{
    return ((s_bHeaderDirty != FALSE) ||
            (TraceLogBbsramHasDirtyRecords() != FALSE)) ? TRUE : FALSE;
}

VOID TraceLogBbsramService(VOID)
{
    if ((s_bBbsramReady == FALSE) || (s_pTraceRecord == NULL))
    {
        return;
    }

    UINT8 ucFlushed = 0u;

    for (UINT8 ucIndex = 0u;
         (ucIndex < NO_OF_TRACERECORDS) &&
         (ucFlushed < (UINT8)TRACELOG_BBSRAM_RECORDS_PER_SERVICE);
         ++ucIndex)
    {
        BOOL bWriteRecord = FALSE;

        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        if (s_aucRecordDirty[ucIndex] != 0u)
        {
            s_aucRecordDirty[ucIndex] = 0u;
            bWriteRecord = TRUE;
        }
        set_imask_exr(ucSaveExr);

        if (bWriteRecord == FALSE)
        {
            continue;
        }

        const UINT32 ulAddress = TRACELOG_RECORDS_ADDRESS +
            ((UINT32)ucIndex * (UINT32)sizeof(TRACERECORD));

        if (!hal_bbsram_write(ulAddress,
                              &s_pTraceRecord[ucIndex],
                              sizeof(TRACERECORD)))
        {
            ucSaveExr = get_imask_exr();
            set_imask_exr(LVLPRI_HIGHEST);
            s_aucRecordDirty[ucIndex] = 1u;
            s_bHeaderDirty = TRUE;
            set_imask_exr(ucSaveExr);
            return;
        }

        ++ucFlushed;
    }

    BOOL bCommitHeader = FALSE;
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    if ((s_bHeaderDirty != FALSE) &&
        (TraceLogBbsramHasDirtyRecords() == FALSE))
    {
        s_bHeaderDirty = FALSE;
        bCommitHeader = TRUE;
    }
    set_imask_exr(ucSaveExr);

    if ((bCommitHeader != FALSE) &&
        (TraceLogBbsramCommitHeader() == FALSE))
    {
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        s_bHeaderDirty = TRUE;
        set_imask_exr(ucSaveExr);
    }

    g_ulTraceLogBbsramErrorCount = hal_bbsram_get_error_count();
}

BOOL TraceLogBbsramFlushAll(VOID)
{
    if (s_bBbsramReady == FALSE)
    {
        return FALSE;
    }

    /* At most 100 records plus a header can be pending.  The guard prevents an
     * unexpected producer from keeping a startup/hard-fail flush in a loop. */
    for (UINT16 usPass = 0u;
         (usPass < (UINT16)(NO_OF_TRACERECORDS + 4u)) &&
         (TraceLogBbsramHasPendingWrites() != FALSE);
         ++usPass)
    {
        TraceLogBbsramService();
    }

    return (TraceLogBbsramHasPendingWrites() == FALSE) ? TRUE : FALSE;
}

static VOID TraceLogBbsramPersistCrashBlock(VOID)
{
    if ((s_bBbsramReady == FALSE) || (s_pTraceRecord == NULL))
    {
        return;
    }

    const UINT32 ulAddress = TRACELOG_RECORDS_ADDRESS +
        ((UINT32)CRASHBLKSTARTINDEX * (UINT32)sizeof(TRACERECORD));

    if (hal_bbsram_write(ulAddress,
                         &s_pTraceRecord[CRASHBLKSTARTINDEX],
                         (size_t)CRASHBLOCKSIZE * sizeof(TRACERECORD)))
    {
        (void)TraceLogBbsramCommitHeader();
    }
}

BOOL TraceLogBbsramVerifyTraceRange(UINT8 a_ucStartIndex,
                                    UINT8 a_ucRecordCount)
{
    if ((s_bBbsramReady == FALSE) ||
        (s_pTraceRecord == NULL) ||
        (a_ucStartIndex > LASTTRACEINDEX))
    {
        return FALSE;
    }

    UINT8 ucIndex = a_ucStartIndex;
    for (UINT8 ucCount = 0u; ucCount < a_ucRecordCount; ++ucCount)
    {
        TRACERECORD StoredRecord;
        const UINT32 ulAddress = TRACELOG_RECORDS_ADDRESS +
            ((UINT32)ucIndex * (UINT32)sizeof(TRACERECORD));

        if ((!hal_bbsram_read(ulAddress, &StoredRecord, sizeof(StoredRecord))) ||
            (memcmp(&StoredRecord, &s_pTraceRecord[ucIndex],
                    sizeof(TRACERECORD)) != 0))
        {
            return FALSE;
        }

        ucIndex = (ucIndex >= LASTTRACEINDEX) ? 0u : (UINT8)(ucIndex + 1u);
    }

    return TRUE;
}

BOOL TraceLogBbsramRunStartupTest(VOID)
{
#if TRACELOG_BBSRAM_STARTUP_TEST
    g_bTraceLogBbsramInitPassed = s_bBbsramReady;
    g_bTraceLogRestoredFromBbsram = s_bRestoredExistingState;
    g_ulTraceLogBootCount = s_ulBootCount;
    g_ulTraceLogBbsramErrorCount = hal_bbsram_get_error_count();

    if ((s_bBbsramReady == FALSE) ||
        (s_pucTraceAppIndex == NULL) ||
        (s_pTraceRecord == NULL))
    {
        return FALSE;
    }

    UINT32 ulPreviousMarkers = 0u;
    for (UINT8 ucIndex = 0u; ucIndex <= LASTTRACEINDEX; ++ucIndex)
    {
        if ((s_pTraceRecord[ucIndex].code == (UINT16)bcDebug) &&
            ((s_pTraceRecord[ucIndex].data & 0xFFFF0000u) ==
             TRACELOG_TEST_MARKER_PREFIX))
        {
            ++ulPreviousMarkers;
        }
    }

    g_ulTraceLogPreviousMarkerCount = ulPreviousMarkers;
    g_bTraceLogPreviousBootMarkerFound =
        (ulPreviousMarkers > 0u) ? TRUE : FALSE;
    /* The circular application trace can legitimately overwrite an older test
     * marker when repeated HART scans generate many records.  RESTORED plus a
     * retained boot count proves BBSRAM/header/record restoration; PREV remains
     * a separate informational field indicating whether an old marker survived. */
    g_bTraceLogRetentionPassed =
        ((s_bRestoredExistingState != FALSE) &&
         (s_ulBootCount > 1u)) ? TRUE : FALSE;

    const UINT8 ucRecordIndex = *s_pucTraceAppIndex;
    const UINT32 ulMarker = TRACELOG_TEST_MARKER_PREFIX |
                            (s_ulBootCount & 0x0000FFFFu);

    g_ucTraceLogTestRecordIndex = ucRecordIndex;
    g_ulTraceLogTestMarker = ulMarker;

    TraceLog.AddToTrace(TRACEID_GENERIC, bcDebug, ulMarker);
    const BOOL bFlushed = TraceLogBbsramFlushAll();

    TRACERECORD StoredRecord;
    const UINT32 ulRecordAddress = TRACELOG_RECORDS_ADDRESS +
        ((UINT32)ucRecordIndex * (UINT32)sizeof(TRACERECORD));

    g_bTraceLogWriteReadPassed =
        ((bFlushed != FALSE) &&
         hal_bbsram_read(ulRecordAddress, &StoredRecord,
                         sizeof(StoredRecord)) &&
         (memcmp(&StoredRecord, &s_pTraceRecord[ucRecordIndex],
                 sizeof(TRACERECORD)) == 0) &&
         (StoredRecord.code == (UINT16)bcDebug) &&
         (StoredRecord.data == ulMarker)) ? TRUE : FALSE;

    TRACEPERSISTENTHEADER Header;
    const UINT32 ulHeaderAddress = (s_ucActiveHeader == 0u) ?
        TRACELOG_HEADER_A_ADDRESS : TRACELOG_HEADER_B_ADDRESS;

    g_bTraceLogHeaderPassed =
        (hal_bbsram_read(ulHeaderAddress, &Header, sizeof(Header)) &&
         (TraceLogBbsramHeaderIsValid(Header) != FALSE) &&
         (Header.AppIndex == *s_pucTraceAppIndex) &&
         (Header.BootCount == s_ulBootCount)) ? TRUE : FALSE;

    g_ucTraceLogLatestIndex = *s_pucTraceAppIndex;
    g_ulTraceLogBbsramErrorCount = hal_bbsram_get_error_count();

    return ((g_bTraceLogWriteReadPassed != FALSE) &&
            (g_bTraceLogHeaderPassed != FALSE)) ? TRUE : FALSE;
#else
    return TRUE;
#endif
}


static const char *TraceLogBreadcrumbName(UINT16 a_usCode, UINT32 a_ulData)
{
    if (a_usCode == (UINT16)bcDebug)
    {
        if ((a_ulData & 0xFFFF0000u) == 0x48530000u)
        {
            return "HART_SCAN";
        }
        if ((a_ulData & 0xFFFF0000u) == 0x48430000u)
        {
            return "HART_SCAN_COMPLETE";
        }
        if ((a_ulData & 0xFFFF0000u) == TRACELOG_TEST_MARKER_PREFIX)
        {
            return "TRACE_TEST_MARKER";
        }
    }

    switch (a_usCode)
    {
        case (UINT16)bcAppStart:          return "bcAppStart";
        case (UINT16)bcIomDbDone:         return "bcIomDbDone";
        case (UINT16)bcAppInitComplete:   return "bcAppInitComplete";
        case (UINT16)bcIOLEnable:         return "bcIOLEnable";
        case (UINT16)bcAliveToIdle:       return "bcAliveToIdle";
        case (UINT16)bcDMCFail:           return "bcDMCFail";
        case (UINT16)bcHardFail1:         return "bcHardFail1";
        case (UINT16)bcFrozen:            return "bcFrozen";
        case (UINT16)bcHardFail2:         return "bcHardFail2";
        case (UINT16)bcHardFail3:         return "bcHardFail3";
        case (UINT16)bcAihIom:            return "bcAihIom";
        case (UINT16)bcAiIom:             return "bcAiIom";
        case (UINT16)bcHModemDiagCount:   return "bcHModemDiagCount";
        case (UINT16)bcHModemDiagFailed:  return "bcHModemDiagFailed";
        case (UINT16)bcHModemDiagAbort:   return "bcHModemDiagAbort";
        case (UINT16)bcHModemDiagRetry:   return "bcHModemDiagRetry";
        case (UINT16)bcHModemDiagReset:   return "bcHModemDiagReset";
        case (UINT16)bcDebug:             return "bcDebug";
        default:                          return "UNKNOWN";
    }
}

VOID TraceLogRequestConsoleDump(UINT8 a_ucRecordCount)
{
    if (a_ucRecordCount == 0u)
    {
        a_ucRecordCount = 1u;
    }
    if (a_ucRecordCount > (UINT8)(LASTTRACEINDEX + 1u))
    {
        a_ucRecordCount = (UINT8)(LASTTRACEINDEX + 1u);
    }

    g_ucTraceLogConsoleDumpCount = a_ucRecordCount;
    g_bTraceLogConsoleDumpRequest = TRUE;
}

VOID TraceLogServiceConsoleDump(VOID)
{
    if ((s_pTraceRecord == NULL) || (s_pucTraceAppIndex == NULL))
    {
        return;
    }

    if ((g_bTraceLogConsoleDumpRequest != FALSE) &&
        (s_bConsoleDumpActive == FALSE))
    {
        g_bTraceLogConsoleDumpRequest = FALSE;
        s_bConsoleDumpActive = TRUE;
        s_ucConsoleDumpLatestIndex = *s_pucTraceAppIndex;
        s_ucConsoleDumpRequested = g_ucTraceLogConsoleDumpCount;
        if ((s_ucConsoleDumpRequested == 0u) ||
            (s_ucConsoleDumpRequested > (UINT8)(LASTTRACEINDEX + 1u)))
        {
            s_ucConsoleDumpRequested = (UINT8)(LASTTRACEINDEX + 1u);
        }
        s_ucConsoleDumpPrinted = 0u;
        s_ucConsoleDumpScanned = 0u;

        PRINTF("TRACELOG DUMP BEGIN ORDER=NEWEST_FIRST REQUESTED=%u NEXT_INDEX=%u BOOT=%u\r\n",
               (unsigned int)s_ucConsoleDumpRequested,
               (unsigned int)s_ucConsoleDumpLatestIndex,
               (unsigned int)g_ulTraceLogBootCount);
        return;
    }

    if (s_bConsoleDumpActive == FALSE)
    {
        return;
    }

    if (s_ucConsoleDumpPrinted >= s_ucConsoleDumpRequested)
    {
        PRINTF("TRACELOG DUMP END PRINTED=%u SCANNED=%u\r\n",
               (unsigned int)s_ucConsoleDumpPrinted,
               (unsigned int)s_ucConsoleDumpScanned);
        s_bConsoleDumpActive = FALSE;
        return;
    }

    while (s_ucConsoleDumpScanned < (UINT8)(LASTTRACEINDEX + 1u))
    {
        const UINT8 ucOffset = s_ucConsoleDumpScanned;
        const UINT8 ucIndex = (UINT8)(
            ((UINT16)s_ucConsoleDumpLatestIndex + (UINT16)LASTTRACEINDEX -
             (UINT16)ucOffset) % (UINT16)(LASTTRACEINDEX + 1u));
        const TRACERECORD &Record = s_pTraceRecord[ucIndex];
        s_ucConsoleDumpScanned++;

        if (Record.code == 0u)
        {
            continue;
        }

        PRINTF("TRACELOG DUMP INDEX=%u CODE=%04X NAME=%s DATA=%08X TIME=%u\r\n",
               (unsigned int)ucIndex,
               (unsigned int)Record.code,
               TraceLogBreadcrumbName(Record.code, Record.data),
               (unsigned int)Record.data,
               (unsigned int)Record.time);
        s_ucConsoleDumpPrinted++;

        /* One record per second keeps console output out of the timing paths. */
        return;
    }

    PRINTF("TRACELOG DUMP END PRINTED=%u SCANNED=%u\r\n",
           (unsigned int)s_ucConsoleDumpPrinted,
           (unsigned int)s_ucConsoleDumpScanned);
    s_bConsoleDumpActive = FALSE;
}

VOID TraceLogServiceLowPriorityTestPrint(VOID)
{
#if TRACELOG_BBSRAM_TEST_PRINT
    if (s_bLowPrioritySummaryPrinted != FALSE)
    {
        return;
    }

    s_bLowPrioritySummaryPrinted = TRUE;

    PRINTF("TRACELOG TEST INIT=%u RW=%u HDR=%u RESTORED=%u PREV=%u RET=%u "
           "HART=%u IDX=%u HSTART=%u HEND=%u MARK=%08X BOOT=%u ERR=%u\r\n",
           (unsigned int)g_bTraceLogBbsramInitPassed,
           (unsigned int)g_bTraceLogWriteReadPassed,
           (unsigned int)g_bTraceLogHeaderPassed,
           (unsigned int)g_bTraceLogRestoredFromBbsram,
           (unsigned int)g_bTraceLogPreviousBootMarkerFound,
           (unsigned int)g_bTraceLogRetentionPassed,
           (unsigned int)g_bHartTraceLogTestPassed,
           (unsigned int)g_ucTraceLogLatestIndex,
           (unsigned int)g_ucHartTraceLogTestStartIndex,
           (unsigned int)g_ucHartTraceLogTestEndIndex,
           (unsigned int)g_ulTraceLogTestMarker,
           (unsigned int)g_ulTraceLogBootCount,
           (unsigned int)g_ulTraceLogBbsramErrorCount);

    if ((g_ucTraceLogTestRecordIndex < NO_OF_TRACERECORDS) &&
        (s_pTraceRecord != NULL))
    {
        const TRACERECORD &Record =
            s_pTraceRecord[g_ucTraceLogTestRecordIndex];

        PRINTF("TRACELOG RECORD INDEX=%u CODE=%04X DATA=%08X TIME=%u\r\n",
               (unsigned int)g_ucTraceLogTestRecordIndex,
               (unsigned int)Record.code,
               (unsigned int)Record.data,
               (unsigned int)Record.time);
    }
#if TRACELOG_CONSOLE_DUMP_ON_BOOT
    TraceLogRequestConsoleDump((UINT8)TRACELOG_CONSOLE_DUMP_RECORDS);
#endif
#else
    /* Test output disabled. */
#endif
}

#endif /* CPU_MIMXRT1024CAG4B */
