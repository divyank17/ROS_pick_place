/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihboxslot.cpp                                              *
*    Description : clsAihBoxSlot implementation for RT1024/QEMU.               *
*******************************************************************************/

#include "aihmain.h"

//volatile BOOL bOneSecTick = FALSE; // temp for testing

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern "C" void hal_pit_init(bool lowCostMode, hal_timer_callback_t callback);
extern "C" void hal_pit_start(void);

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
#define LATEST_BOXCHKPNT_VERSION 2
#define PARAMID_PVSCANREC 105u

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_VREFFAIL,
#if !LOWCOST
    SF_ADOUTUDF,
    SF_OPENWIRE,
#else
    SF_ADC_SUPPLY_FAIL,
    SF_ADC_REG_WR_FAIL,
#endif
    SF_BADRJVAL,
    SF_HARTCHANFAIL,
    SF_ADCINCOMPLETE,
    SF_ADC_OVERFLOW,
    SF_UNKNOWN
};

const UINT8 clsAihBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};

#if 0 //!defined(IOPTYPE_HLAI)
const UINT8 clsAihBoxSlot::CheckPointVer2[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};
const CHECKPOINT_VER_TABLE clsAihBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 3 },
    { CheckPointVer2, 3 }
};
#else
// PMIO HLAI Redesign
const UINT8 clsAihBoxSlot::CheckPointVer2[] = {
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsAihBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 3 },
    { CheckPointVer2, 2 }
};

// PMIO HLAI dump param order (since pmio param order is diff from series c)
const UINT8  clsAihBoxSlot::PmioDumpParamTbl[] = {
    PARAMID_MODSTAT1,
    PARAMID_DBVALID,
    PARAMID_PVSCAN,
    0 // Terminator
};

#if defined(HART_SUPPORT)
const UINT8 clsBoxSlot::IopDesc[] = "HLAIH   ";
#else
const UINT8 clsBoxSlot::IopDesc[] = "HLAI    ";
#endif

#endif

UINT8 clsAihBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

/*******************************************************************************
*                          BLINDFIELDXFORM (local type/table)                   *
*                          ===================================                 *
* PURPOSE:                                                                     *
*    Most DT_BLIND parameters (bitmaps, tag/frame byte arrays, ASCII strings)  *
*    really are opaque and must be copied byte-for-byte. A few, however, are   *
*    arrays of records/scalars with an embedded multi-byte numeric field that  *
*    still needs the same wire/native byte-order conversion as an ordinary     *
*    AT_MBYTE scalar (e.g. the FLOAT32 Pv inside each PvScanRec entry).        *
*    Each row below describes one such field: which parameter it belongs to,   *
*    its byte offset/size within one record, and the record's stride (0 means *
*    a flat array of back-to-back scalars with no surrounding struct).        *
* NOTES:                                                                       *
*    Add one row per embedded scalar field to cover additional parameters —   *
*    no code changes needed in TransformBlindRecord itself.                    *
*******************************************************************************/
typedef struct tagBlindFieldXform {
    UINT8 ParamId;      /* Parameter ID this row applies to                  */
    UINT8 FieldOffset;  /* Byte offset of the scalar field within one record  */
    UINT8 FieldSize;    /* Size of the scalar field in bytes (2, 4, ...)      */
    UINT8 Stride;       /* Size of one record; 0 = flat array (Stride=FieldSize) */
} BLINDFIELDXFORM;

static const BLINDFIELDXFORM s_tblBlindFieldXform[] = {
    /* PvScanRec (param 105): FLOAT32 Pv at offset 0 of each 8-byte PVSCANREC */
    { PARAMID_PVSCANREC, 0, (UINT8)sizeof(FLOAT32), (UINT8)sizeof(PVSCANREC) },

    /* Legacy TraceLog record (param 165): packed {UINT16 code, UINT32 data,
     * UINT32 time}. The ARM cache is native little-endian; the IOL wire format
     * remains the legacy big-endian format. */
    { 165u, 0u, 2u, (UINT8)sizeof(TRACERECORD) },
    { 165u, 2u, 4u, (UINT8)sizeof(TRACERECORD) },
    { 165u, 6u, 4u, (UINT8)sizeof(TRACERECORD) },

    /* TraceLogInfo (param 166): UINT32 timestamp followed by UINT8 index. */
    { 166u, 0u, 4u, (UINT8)sizeof(TRACELOGDATA) },
};

/*******************************************************************************
*                   clsAihBoxSlot::TransformBlindRecord                        *
*                   ====================================                      *
* PURPOSE:                                                                     *
*    Generic engine: for a_ucParamId, apply every matching row in             *
*    s_tblBlindFieldXform, reversing just the described scalar field in each   *
*    record. All other DT_BLIND parameters (not listed in the table) are left *
*    completely untouched by the generic Read/WriteParamData byte-for-byte    *
*    copy, since their layout is genuinely opaque.                             *
* NOTES:                                                                       *
*    A byte reversal is its own inverse, so the same swap applies for both     *
*    to-wire (read) and from-wire (write) directions.                          *
*******************************************************************************/
VOID clsAihBoxSlot::TransformBlindRecord(UINT8 a_ucParamId, UINT8 *a_pData, UINT8 a_ucSize, BOOL /*a_bToWire*/)
{
    const UINT8 ucNumRows = (UINT8)(sizeof(s_tblBlindFieldXform) / sizeof(s_tblBlindFieldXform[0]));

    for (UINT8 ucRow = 0; ucRow < ucNumRows; ucRow++) {
        const BLINDFIELDXFORM &Xform = s_tblBlindFieldXform[ucRow];
        if (Xform.ParamId != a_ucParamId) {
            continue;
        }

        UINT8 ucStride = (Xform.Stride != 0) ? Xform.Stride : Xform.FieldSize;
        UINT8 ucCount  = ucStride ? (a_ucSize / ucStride) : 0;

        for (UINT8 ucRec = 0; ucRec < ucCount; ucRec++) {
            UINT8 *pField = a_pData + (ucRec * ucStride) + Xform.FieldOffset;
            for (UINT8 i = 0; i < (Xform.FieldSize / 2u); i++) {
                UINT8 ucTmp;
                ucTmp = pField[i];
                pField[i] = pField[Xform.FieldSize - 1u - i];
                pField[Xform.FieldSize - 1u - i] = ucTmp;
            }
        }
    }
}

const UINT8 clsAihBoxSlot::RedParams[] = {
    PARAMID_IOLDEVTYPE,
    PARAMID_MODLTYPE,
    PARAMID_DBVALID,
    PARAMID_SFACTNTBL,
#if !defined(IOPTYPE_HLAI)
    PARAMID_MAXSLOTS,
#endif
    0 // Terminator
};

/*******************************************************************************
*                     PARAMETER TABLE (256 entries — sparse)                    *
*  Populated entries match Experion paramId assignments for AIH-HART.          *
*  Empty entries use DT_NONE sentinel.                                         *
*******************************************************************************/
#define EMPTY   {DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE}
#define P(fn)   &clsAihBoxSlot::fn

const BOXPARAMINFO clsAihBoxSlot::s_tblParamInfo[256] = {
    EMPTY,                                                                     // 00
    EMPTY,                                                                     // 01
    EMPTY,                                                                     // 02
    {DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,0,FALSE},                                // 03 ModStatType
    EMPTY,                                                                     // 04
    EMPTY,                                                                     // 05
    EMPTY,                                                                     // 06
    EMPTY,                                                                     // 07
    EMPTY,                                                                     // 08
    EMPTY,                                                                     // 09
    EMPTY,                                                                     // 10
    EMPTY,                                                                     // 11
    EMPTY,                                                                     // 12
    EMPTY,                                                                     // 13
    EMPTY,                                                                     // 14
    EMPTY,                                                                     // 15
    EMPTY,                                                                     // 16
    EMPTY,                                                                     // 17
    EMPTY,                                                                     // 18
    EMPTY,                                                                     // 19
    EMPTY,                                                                     // 20
    EMPTY,                                                                     // 21
    EMPTY,                                                                     // 22
    EMPTY,                                                                     // 23
    EMPTY,                                                                     // 24
    EMPTY,                                                                     // 25
    EMPTY,                                                                     // 26
    EMPTY,                                                                     // 27
    EMPTY,                                                                     // 28
    EMPTY,                                                                     // 29
    EMPTY,                                                                     // 30
    EMPTY,                                                                     // 31
    EMPTY,                                                                     // 32
    EMPTY,                                                                     // 33
    EMPTY,                                                                     // 34
    {DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,P(GetSlotSfBitsPtr),FALSE},            // 35 SlotSfBits
    EMPTY,                                                                     // 36
    {DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,P(GetMapSlotInFailPtr),FALSE},         // 37 MapSlotInFail
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetChnErrAPtr),FALSE},                // 38 ChnErrA
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetChnErrBPtr),FALSE},                // 39 ChnErrB
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetChnSilAPtr),FALSE},                // 40 ChnSilA
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetChnSilBPtr),FALSE},                // 41 ChnSilB
    EMPTY,                                                                     // 42
    {DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                              // 43 HwInfo
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 44 BootBuildNo
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 45 BootSwRevCode
    EMPTY,                                                                     // 46
    {DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,P(GetSup300Ptr),FALSE},                 // 47 Sup300
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 48 AppBuildNo
    EMPTY,                                                                     // 49
    EMPTY,                                                                     // 50
    {DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,P(GetBoxSfBitsPtr),FALSE},             // 51 BoxSfBits
    {DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                              // 52 BoxSfLrs
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 53 CircListSt
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetCommErrPtr),FALSE},                // 54 CommErr
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetCommStatPtr),FALSE},               // 55 CommStat
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetDpaPtr),FALSE},                    // 56 Dpa
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetDsaPtr),FALSE},                    // 57 Dsa
    {DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                              // 58 EvntAppPtr
    {DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                              // 59 EvntRemPtr
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetBaPtr),FALSE},                     // 60 Ba
    {DT_BLIND,4,AT_MBYTE,ALCK_IUSER,0,0,0,FALSE},                              // 61 SyncVer
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 62 FailCode
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetHwRevCodePtr),FALSE},              // 63 HwRevCode
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,TRUE},                                // 64 IolDevType
    {DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetLastFailPtr),FALSE},                // 65 LastFail
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 66 MesNo
    {DT_UINT8,1,AT_SBYTE,ALCK_IUSER,P(PreModStat1),P(PostModStat1),P(GetModStat1Ptr),TRUE},                // 67 ModStat1
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetModStat2Ptr),FALSE},               // 68 ModStat2
    {DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetModlTypePtr),TRUE},                 // 69 ModlType
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetNthPtr),FALSE},                    // 70 Nth
    EMPTY,                                                                     // 71
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetAppRevCodePtr),FALSE},             // 72 SwRevCode (App Rev)
    EMPTY,                                                                     // 73
    {DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 74 TstFunct
    {DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,P(GetSfInfo300Ptr),FALSE},              // 75 SfInfo300
    {DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                                // 76 WithBias
    {DT_BLIND,2,AT_MBYTE,ALCK_IUSER,0,0,P(GetRedDataPtr),FALSE},               // 77 RedData
    {DT_BOOL, 1,AT_SBYTE,ALCK_IUSER,0,0,P(GetDbValidPtr),TRUE},                // 78 DbValid
    {DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,0,0,FALSE},                             // 79 SfActionTbl
    {DT_BOOL,1,AT_SBYTE,ALCK_EPB,P(PreCalibAll),P(PostCalibAll),P(GetCalibAllPtr),FALSE},                 // 80 CalibAll
    EMPTY,                                                                     // 81
    EMPTY,                                                                     // 82
    EMPTY,                                                                     // 83
    EMPTY,                                                                     // 84
    EMPTY,                                                                     // 85
    EMPTY,                                                                     // 86
    EMPTY,                                                                     // 87
    EMPTY,                                                                     // 88
    EMPTY,                                                                     // 89
    EMPTY,                                                                     // 90
    EMPTY,                                                                     // 91
    EMPTY,                                                                     // 92
    EMPTY,                                                                     // 93
    EMPTY,                                                                     // 94
    EMPTY,                                                                     // 95
    EMPTY,                                                                     // 96
    EMPTY,                                                                     // 97
    EMPTY,                                                                     // 98
    EMPTY,                                                                     // 99
    EMPTY,                                                                     // 100
    EMPTY,                                                                     // 101
    EMPTY,                                                                     // 102
    EMPTY,                                                                     // 103
    EMPTY,                                                                     // 104
    {DT_BLIND,96,AT_MBYTE,ALCK_VIEW,0,0,P(GetPvScanRecPtr),FALSE},              // 105 PvScanRec
    EMPTY,                                                                     // 106
    EMPTY,                                                                     // 107
    EMPTY,                                                                     // 108
    EMPTY,                                                                     // 109
    EMPTY,                                                                     // 110
    EMPTY,                                                                     // 111
    EMPTY,                                                                     // 112
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,P(GetLpBkStatPtr),FALSE},                // 113 LpBkStat
    EMPTY,                                                                     // 114
    {DT_STRG, 8,AT_MBYTE,ALCK_VIEW,0,0,P(GetIopDescPtr),FALSE},                 // 115 IopDesc
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 116 MaxSlots
    EMPTY,                                                                     // 117
    EMPTY,                                                                     // 118
    EMPTY,                                                                     // 119
    EMPTY,                                                                     // 120
    {DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                              // 121 HGCfgChgCnt
    {DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,P(GetHGChngFlPtr),FALSE},               // 122 HGChngFl
    EMPTY,                                                                     // 123
    {DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                             // 124 HCuAvail
    EMPTY,                                                                     // 125
    EMPTY,                                                                     // 126
    EMPTY,                                                                     // 127
    EMPTY,                                                                     // 128
    EMPTY,                                                                     // 129
    EMPTY,                                                                     // 130
    EMPTY,                                                                     // 131
    EMPTY,                                                                     // 132
    EMPTY,                                                                     // 133
    EMPTY,                                                                     // 134
    {DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                              // 135 HGDevSt
    EMPTY,                                                                     // 136
    EMPTY,                                                                     // 137
    EMPTY,                                                                     // 138
    EMPTY,                                                                     // 139
    EMPTY,                                                                     // 140
    EMPTY,                                                                     // 141
    EMPTY,                                                                     // 142
    {DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,0,TRUE},                                 // 143 CheckPoint
    EMPTY,                                                                     // 144
    EMPTY,                                                                     // 145
    EMPTY,                                                                     // 146
    EMPTY,                                                                     // 147
    EMPTY,                                                                     // 148
    EMPTY,                                                                     // 149
    EMPTY,                                                                     // 150
    EMPTY,                                                                     // 151
    EMPTY,                                                                     // 152
    {DT_BOOL,1,AT_SBYTE,ALCK_PBD,0,0,0,FALSE},                                 // 153 HADCEnable
    {DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,0,FALSE},                               // 154 HADCStatus
    EMPTY,                                                                     // 155
    EMPTY,                                                                     // 156
    EMPTY,                                                                     // 157
    {DT_BLIND,34,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                              // 158 CheckSum
    {DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                             // 159 CPUFreeAvg
    {DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE},                             // 160 CPUFreeMin
    {DT_BOOL,1,AT_SBYTE,ALCK_OPER,0,0,0,FALSE},                                // 161 StatReset
    EMPTY,                                                                     // 162
    EMPTY,                                                                     // 163
    EMPTY,                                                                     // 164
    {DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,P(GetTracelogPtr),FALSE},             // 165 TraceLog
    {DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,P(GetTraceLogInfoPtr),FALSE},            // 166 TraceLogInfo
    {DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,P(GetTracelevelPtr),FALSE},             // 167 TraceLevel
    EMPTY,                                                                     // 168
    EMPTY,                                                                     // 169
    EMPTY,                                                                     // 170
    EMPTY,                                                                     // 171
    EMPTY,                                                                     // 172
    EMPTY,                                                                     // 173
    EMPTY,                                                                     // 174
    EMPTY,                                                                     // 175
    EMPTY,                                                                     // 176
    EMPTY,                                                                     // 177
    EMPTY,                                                                     // 178
    EMPTY,                                                                     // 179
    EMPTY,                                                                     // 180
    EMPTY,                                                                     // 181
    EMPTY,                                                                     // 182
    EMPTY,                                                                     // 183
    EMPTY,                                                                     // 184
    EMPTY,                                                                     // 185
    EMPTY,                                                                     // 186
    EMPTY,                                                                     // 187
    EMPTY,                                                                     // 188
    EMPTY,                                                                     // 189
    EMPTY,                                                                     // 190
    EMPTY,                                                                     // 191
    EMPTY,                                                                     // 192
    EMPTY,                                                                     // 193
    EMPTY,                                                                     // 194
    EMPTY,                                                                     // 195
    EMPTY,                                                                     // 196
    EMPTY,                                                                     // 197
    EMPTY,                                                                     // 198
    EMPTY,                                                                     // 199
    EMPTY,                                                                     // 200
    EMPTY,                                                                     // 201
    EMPTY,                                                                     // 202
    EMPTY,                                                                     // 203
    EMPTY,                                                                     // 204
    EMPTY,                                                                     // 205
    EMPTY,                                                                     // 206
    EMPTY,                                                                     // 207
    EMPTY,                                                                     // 208
    EMPTY,                                                                     // 209
    EMPTY,                                                                     // 210
    EMPTY,                                                                     // 211
    EMPTY,                                                                     // 212
    EMPTY,                                                                     // 213
    EMPTY,                                                                     // 214
    EMPTY,                                                                     // 215
    EMPTY,                                                                     // 216
    EMPTY,                                                                     // 217
    EMPTY,                                                                     // 218
    EMPTY,                                                                     // 219
    EMPTY,                                                                     // 220
    EMPTY,                                                                     // 221
    EMPTY,                                                                     // 222
    EMPTY,                                                                     // 223
    EMPTY,                                                                     // 224
    EMPTY,                                                                     // 225
    EMPTY,                                                                     // 226
    EMPTY,                                                                     // 227
    EMPTY,                                                                     // 228
    EMPTY,                                                                     // 229
    EMPTY,                                                                     // 230
    EMPTY,                                                                     // 231
    EMPTY,                                                                     // 232
    EMPTY,                                                                     // 233
    EMPTY,                                                                     // 234
    EMPTY,                                                                     // 235
    EMPTY,                                                                     // 236
    EMPTY,                                                                     // 237
    EMPTY,                                                                     // 238
    EMPTY,                                                                     // 239
    EMPTY,                                                                     // 240
    EMPTY,                                                                     // 241
    EMPTY,                                                                     // 242
    {DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,0,TRUE},                               // 243 BoxChkpntVer
    EMPTY,                                                                     // 244
    EMPTY,                                                                     // 245
    EMPTY,                                                                     // 246
    EMPTY,                                                                     // 247
    EMPTY,                                                                     // 248
    EMPTY,                                                                     // 249
    EMPTY,                                                                     // 250
    EMPTY,                                                                     // 251
    EMPTY,                                                                     // 252
    EMPTY,                                                                     // 253
    EMPTY,                                                                     // 254
    EMPTY                                                                      // 255
};

#undef EMPTY
#undef P


/*******************************************************************************
*                    clsAihBoxSlot::clsAihBoxSlot                              *
*                    ============================                              *
* PURPOSE:                                                                     *
*    Constructor — initialize the AIH box slot object with module type.        *
*    Passes MAXSLOTS (16) to the base clsBoxSlot constructor.                  *
* ARGUMENTS:                                                                   *
*    a_ModlType : module type (e.g., MODLTYPE_AIH).                            *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
clsAihBoxSlot::clsAihBoxSlot(MODLTYPE a_ModlType) : clsBoxSlot(a_ModlType, MAXSLOTS) {
	// initialize data members.
	PpxChannel = 1; // start with channel 1

    // Initialize data members.
    for (UINT8 ucSlot = 0; ucSlot < MAXSLOTS; ucSlot++) {
        PvScanRec[ucSlot].Pv        = 0.0;
        PvScanRec[ucSlot].PvSts     = PVVALST_BAD;
        PvScanRec[ucSlot].Sequence  = 0;
    }

    CalibAll 		= FALSE;
    CalibrationGood = FALSE;
    BoardType       = BOARDTYPE_UNKNOWN;
    CalibData.f5VRefHiLimit      = NaN;
    CalibData.f5VRefLoLimit      = NaN;
#if !LOWCOST
    CalibData.fCalibrationSlope  = NaN;
    CalibData.fCalibrationOffset = NaN;
    for (UINT8 ucSlot = 0; ucSlot < MAXSLOTS; ucSlot++) {
        CalibData.fChannelZeroDrift[ucSlot] = NaN;
        HADCEnable[ucSlot] = FALSE;
        HADCStatus[ucSlot] = HART_DATA_PENDING;
        AdcCycleCount[ucSlot] = 0;
        HGChngFl[ucSlot] = 0;
        SlwSrcBuff[ucSlot] = NaN;
    }
#else   // LOWCOST
    CalibData.spare1  = NaN;
    CalibData.spare2 = NaN;
    for (UINT8 ucSlot = 0; ucSlot < MAXSLOTS; ucSlot++) {
        CalibData.fCalibrationSlope[ucSlot] = NaN;
        CalibData.fCalibrationOffset[ucSlot] = NaN;
        HADCStatus[ucSlot] = HART_DATA_NOT_AVAILABLE;
        HGChngFl[ucSlot] = 0;
    }

    // If EEPROM is not mounted, Load the default constants.
    CalibrationGood = TRUE;
    CalibData.f5VRefHiLimit = LCOST_FIVE_VOLT_HILIMIT;
    CalibData.f5VRefLoLimit = LCOST_FIVE_VOLT_LOLIMIT;
    for (UINT8 ucSlotNum=0; ucSlotNum<MAXSLOTS; ucSlotNum++) {
        CalibData.fCalibrationSlope[ucSlotNum]  = 1.0/(FLOAT32)LCOST_ONE_VOLT_COUNT;  // divide by 12288 = 0xf000 / 5(V)
        CalibData.fCalibrationOffset[ucSlotNum] = 0.0;
    }

#endif
    HCuAvail = 100.0;
    OwdCktGood 		= TRUE;

    BxLimit1 = NaN;
    BxLimit2 = NaN;
    PvsGood = FALSE;
    bSlwFirstPass = TRUE;

    HwInfo.ProductType = PRODTYPE_AI;
    switch(a_ModlType) {
    	case MODLTYPE_AIH:
    		HwInfo.ProductCode = PRODCODE_AI_HART;
    		break;
    	case MODLTYPE_AI:
#if HEK
    		HwInfo.ProductCode = PRODCODE_AI_HL;
#else
    		HwInfo.ProductCode = PRODCODE_AI_HL_LC;
    		BoardType = BOARDTYPE_LOWCOST;
#endif
    		break;
    	case MODLTYPE_AI_S8:
#if LOWCOST
        	HwInfo.ProductCode = PRODCODE_AI_HL_LC_S8;
        	BoardType = BOARDTYPE_LOWCOST;
        	break;
#endif
        // Series C Depop AI is not planned in Series 8,
        // Hard fail module if configuration is done
    	case MODLTYPE_AIH_S8:
        // Series C HART AI is not planned in Series 8,
        // Hard fail module if configuration is done
    	default:
    		HardFail(HF_BADPROGRAMJUMP,AIHBOXSLOT_CPP,__LINE__);
    }

    //PPX Configuration

#if 0
    OWD_ENB = 0; // Disable open wire detection circuitry at startup
#endif

#ifdef _DEBUG_
    m_ulMaxPpxTime  = 0;
    m_ulAvgPpxTime  = 0;
    m_ulMinPpxTime  = MAXUINT32;
#endif

    PartnersChkPntVer = 0;
}


/*******************************************************************************
*                      clsAihBoxSlot::GetDataType                              *
*                      ==========================                              *
* PURPOSE:                                                                     *
*    Return the DATATYPE for a given parameter ID from the param table.        *
* ARGUMENTS:                                                                   *
*    a_ucParamId : parameter index (0–255).                                    *
* RETURN:                                                                      *
*    DATATYPE enum value (DT_NONE if entry is empty).                          *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
DATATYPE clsAihBoxSlot::GetDataType(UINT8 a_ucParamId) {
    return s_tblParamInfo[a_ucParamId].DataType;
}

/*******************************************************************************
*                      clsAihBoxSlot::GetAccessType                            *
*                      ============================                            *
* PURPOSE:                                                                     *
*    Return the ACCESSTYPE for a given parameter ID.                           *
* ARGUMENTS:                                                                   *
*    a_ucParamId : parameter index (0–255).                                    *
* RETURN:                                                                      *
*    ACCESSTYPE enum value.                                                    *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
ACCESSTYPE clsAihBoxSlot::GetAccessType(UINT8 a_ucParamId) {
    return s_tblParamInfo[a_ucParamId].AccessType;
}

/*******************************************************************************
*                      clsAihBoxSlot::GetParamSize                             *
*                      ===========================                             *
* PURPOSE:                                                                     *
*    Return the byte size for a given parameter ID.                            *
* ARGUMENTS:                                                                   *
*    a_ucParamId : parameter index (0–255).                                    *
* RETURN:                                                                      *
*    Size in bytes (0 if entry is empty).                                      *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
UINT8 clsAihBoxSlot::GetParamSize(UINT8 a_ucParamId) {
    return s_tblParamInfo[a_ucParamId].Size;
}

/*******************************************************************************
*                      clsAihBoxSlot::GetParamPtr                              *
*                      ==========================                              *
* PURPOSE:                                                                     *
*    Return a pointer to the in-memory storage for a given parameter.          *
* ARGUMENTS:                                                                   *
*    a_ucParamId : parameter index (0–255).                                    *
* RETURN:                                                                      *
*    Pointer to the parameter’s storage, or NULL if not mapped.                *
* NOTES:                                                                       *
*    RT1024 CHANGES: Member-function-pointer dispatch from param table.        *
*******************************************************************************/
UINT8 *clsAihBoxSlot::GetParamPtr(UINT8 a_ucParamId) {
    /* If the table entry has a member-function pointer, use it.
       Otherwise fall back to known param IDs. */
    if (s_tblParamInfo[a_ucParamId].ParamPtr != 0) {
        return (UINT8 *)(this->*(s_tblParamInfo[a_ucParamId].ParamPtr))();
    }
    /* TODO: Expand as needed for specific parameter IDs */
    return NULL;
}

/*******************************************************************************
*                         clsAihBoxSlot::GetAccessLock                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsAihBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return s_tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                    clsAihBoxSlot::GetIsDbChecksumed                          *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return s_tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                        clsAihBoxSlot::VerifyControlState                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}

/*******************************************************************************
*                        clsAihBoxSlot::ExecutePreFunction                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (s_tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(s_tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsAihBoxSlot::ExecutePostFunction                    *
*                        ==================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (s_tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(s_tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
    return;
}
/*******************************************************************************
*                         clsAihBoxSlot::  PreCalibAll                         *
*                         ============================                         *
* PURPOSE:  Pre Receiver-Beware function for CalibAll parameter. Checks for    *
*           Calibration present status.                                        *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesfull                     *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::PreCalibAll(UINT8 *,UINT8) {
    // Calibration is only permitted when the module state is Idle.
    if(ModStat1.Status == MODSTATUS_RUN) {
        return DO_STATE_MUST_BE_IDLE;
    }

    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostCalibAll                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::PostCalibAll(UINT8) {
    TaskScheduler.RunTask(TASKID_CALIBTASK);
}
/*******************************************************************************
*                         clsAihBoxSlot::PreCheckPoint                         *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsAihBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    return PA_OK;
}
/*******************************************************************************
*                   clsAihBoxSlot::AppInitialization                           *
*                   ===============================                            *
* PURPOSE:                                                                     *
*    One-time startup: load calibration data and start PPX timer.              *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    RT1024 CHANGES: PPX timer via hal_timer_configure; QEMU uses scheduler.   *
*******************************************************************************/
void clsAihBoxSlot::AppInitialization(void) {

	LoadCalibrationData();

#if !LOWCOST
    // Detect whether pass one or pass two board. It takes a while for the zero
    // reference to settle after a cold powerup. Repeat the detection until a
    // the zero reference settle to a difference of 10 counts over 10 samples.
    const UINT8 REF0_SAMPLES_OR_DIFF = 10;
    const UINT8 REF0_TRIALS = 50;
    UINT8 ucTrials = REF0_TRIALS;
    clsOlympicAverage ZeroAvg;

    while (BOARDTYPE_UNKNOWN == BoardType) {

        UINT16 uiZero = REF0_SAMPLES_OR_DIFF;
        ZeroAvg.Initialize();

        while (uiZero--) {

            ZeroAvg.AddSample(Adc.GetRawData(IN_REF0));
        }

        PRINTF("\r\nZeroAvg Hi: %d, ZeroAvg Lo: %d", ZeroAvg.GetHiSample(), ZeroAvg.GetLoSample());

        if ((ZeroAvg.GetHiSample() - ZeroAvg.GetLoSample()) < REF0_SAMPLES_OR_DIFF) {
            // Zero reference settled to a difference of 10 counts.
            uiZero = ZeroAvg.GetResult();

            PRINTF("\r\nZero: %d", uiZero);

            if ((uiZero > PASS1_ZERO_REF_LOLIMIT) && (uiZero < PASS1_ZERO_REF_HILIMIT)) {
                BoardType = BOARDTYPE_PASSONE;
            }
            else if ((uiZero > PASS2_ZERO_REF_LOLIMIT) && (uiZero < PASS2_ZERO_REF_HILIMIT)) {
                BoardType = BOARDTYPE_PASSTWO;
            }
        }

        // Exit the while loop with a softfail if reference type cannot be found in 50 trials.
        if (0 == --ucTrials) {

            BoardType = BOARDTYPE_PASSTWO;
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
        }
    }

    PRINTF("\r\nBoardType: %d\r\n", BoardType);

#endif

    //BoardType = BOARDTYPE_SCIO_RT;
    //TraceLog.AddToTrace(TRACEID_GENERIC, bcBoxInit);

    /* On RT1024: configure PPX processing timer (PIT or GPT) here.
       For now we rely on the scheduler SysTick for all timing. */
    //hal_timer_configure(HAL_TIMER_PPX, AIHPPX_PERIOD * 1000, NULL);

    /* Use PIT channel 0 for PPX periodic processing. */
    // Start AIH point processing timer
#if LOWCOST
    hal_pit_init(true, PpxInterruptHandler);
#else
    hal_pit_init(false, PpxInterruptHandler);
#endif
    hal_pit_start();
}

/*******************************************************************************
*                   clsAihBoxSlot::AppStcProcessing                            *
*                   ===============================                            *
* PURPOSE:                                                                     *
*    Per-tick processing called from scheduler housekeeping path (10ms).       *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
VOID clsAihBoxSlot::AppStcProcessing(VOID)
{
    // Hardfail the module if FPGA CRC check fails
    //HardFail(HF_FPGARDBKFAIL, AIHBOXSLOT_CPP, __LINE__);

    ManageRedIO(); // Process redundancy inputs and state
}

/*******************************************************************************
*                       clsAihBoxSlot::LoadCalibrationData                     *
*                       ==================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::LoadCalibrationData(VOID) {
    UINT8 ucSlotNum;

	/*
     * Disabling below part of code due to,
     * As of now calibration data stored in both FRAM & Flash memories, but the latest HW is replaced with battery backup SRAM,
	 * calibration data is going to maintain in FLASH memory, and after power on calib data copied into SRAM as is.
     */
#if 1 //!defined(IOPTYPE_HLAI)
    // First check if the SPI EEPROM is present on the app board. If the SPI
    // EEPROM is present then check  if the data is valid. If the data in SPI
    // is not VALID then check if the calibration data is present in FLASH. If
    // yes load the data or declare Invalid calibration data.
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        if (CALIBRATION_DONE == Eeprom.ReadByte(EE_CALIBRATION_MARK)) {
            // Check if Calibration data is good
            if (Eeprom.ValidateEepromChecksum()) {
                CalibrationGood = TRUE;
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,FALSE,0);

                CalibData.f5VRefHiLimit = Eeprom.ReadFloat(EE_CALIBRATION_5VREF_HILIMIT);
                CalibData.f5VRefLoLimit = Eeprom.ReadFloat(EE_CALIBRATION_5VREF_LOLIMIT);
#if !LOWCOST    // one SLOPE/OFFSET. Zero drift for each channel
                CalibData.fCalibrationSlope  = Eeprom.ReadFloat(EE_CALIBRATION_SLOPE);
                CalibData.fCalibrationOffset = Eeprom.ReadFloat(EE_CALIBRATION_OFFSET);

#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r- EEPROM CALIB DATA -"));
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r5VHL-%f 5VLL-%f SLOPE-%f OFSET-%f",
                    CalibData.f5VRefHiLimit,
                    CalibData.f5VRefLoLimit,
                    CalibData.fCalibrationSlope,
                    CalibData.fCalibrationOffset));
#endif
#endif
                for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
                    CalibData.fChannelZeroDrift[ucSlotNum] =
                        Eeprom.ReadFloat(EE_CHANNEL_ZERODRIFT_PTR+(ucSlotNum*sizeof(FLOAT32)));
#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.
                    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\rChnl0Drift[%02x]-%f",
                        ucSlotNum, CalibData.fChannelZeroDrift[ucSlotNum]));
#endif
#endif
                }
#else   // LOWCOST, SLOPE and OFFSET for each channel
                for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
                    CalibData.fCalibrationSlope[ucSlotNum] =
                        Eeprom.ReadFloat(EE_CHANNEL_SLOPE_PTR+(ucSlotNum*sizeof(FLOAT32)));
                    CalibData.fCalibrationOffset[ucSlotNum] =
                        Eeprom.ReadFloat(EE_CHANNEL_OFFSET_PTR+(ucSlotNum*sizeof(FLOAT32)));
                }
#endif
                return;
            }
        }
    }
#endif

    // It Should be replaced with FLASH read
    if (Eeprom.ReadByte(EE_CALIBRATION_MARK) == CALIBRATION_DONE) {
        // Calibration present in flash. There is no plan to implement
        // CRC on flash calibration as this is getting relocated to EEPROM.
        CalibrationGood = TRUE;
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,FALSE,0);

        CalibData.f5VRefHiLimit = Eeprom.ReadByte(EE_CALIBRATION_5VREF_HILIMIT);
        CalibData.f5VRefLoLimit = Eeprom.ReadByte(EE_CALIBRATION_5VREF_LOLIMIT);
#if !LOWCOST
        CalibData.fCalibrationSlope  = Eeprom.ReadByte(EE_CALIBRATION_SLOPE);
        CalibData.fCalibrationOffset = Eeprom.ReadByte(EE_CALIBRATION_OFFSET);

#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r- FLASH CALIB DATA -"));
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r5VHL-%f 5VLL-%f SLOPE-%f OFSET-%f",
            CalibData.f5VRefHiLimit,
            CalibData.f5VRefLoLimit,
            CalibData.fCalibrationSlope,
            CalibData.fCalibrationOffset));
#endif
#endif

        //volatile FLOAT32 *pfChanZeroDrift = Eeprom.ReadByte(EE_CHANNEL_ZERODRIFT_PTR);
        for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
            CalibData.fChannelZeroDrift[ucSlotNum] = Eeprom.ReadFloat(EE_CHANNEL_ZERODRIFT_PTR + (ucSlotNum * sizeof(float)));//*pfChanZeroDrift++;

#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\rChnl0Drift[%02x]-%f",
                ucSlotNum, CalibData.fChannelZeroDrift[ucSlotNum]));
#endif
#endif
        }
#else   // LOWCOST
        volatile FLOAT32 *pfChanZeroDrift = CHANNEL_ZERODRIFT_PTR;
        for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
            CalibData.fCalibrationSlope[ucSlotNum] = *pfChanZeroDrift++;
        }
        for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
            CalibData.fCalibrationOffset[ucSlotNum] = *pfChanZeroDrift++;
        }
#endif
        //TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibLoad);

       /*
        * below part of code works as is,
        * Since FRAM is replaced with battery backup SRAM, Calibration data retrives from the flash
        * and writes in the SRAM on every power on.
        */

        // Now copy the data in SPI EEPROM. We need this only 1 time. This is because
        // if the module is already calibrated and the data is in Flash.This will be
        // removed later as it is not required once the data is in SPI. If calibration
        // is attempted, it will be written to EPIEEPROM directly if present.

        // First check if the SPI EEPROM is present on the app board. If the SPI
        // EEPROM is present then store the data in SPI EEPROM else use FLASH.
        // Read the status register. Bits 2 and 3 are write protect bits and
        // always 0 as we do not protect it. If we see any of these bits ON,then
        // it is safe to assume that SPI device is not present.
        if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
            // Reinit the pointer
            UINT8 *ucBufferPtr = (UINT8*)(MODULEINFO_START_ADDRESS);
            //Enable the writes EEPROM
            Eeprom.EnableWrite();
            //Start writing calibration constants to SPI.
            for (UINT16 ucCount=0; ucCount < MAX_EEPROM_SIZE-6; ucCount++) {
                Eeprom.WriteByte(ucCount,*ucBufferPtr);
                ucBufferPtr++;
                Eeprom.CheckWriteInProgress();
            }
            Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS,0x5A);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS+1,0x5A);
            Eeprom.CheckWriteInProgress();

            UINT16 ModuleWriteCount;
            ModuleWriteCount = Eeprom.ReadUint16(EE_MODULEINFO_WRITECOUNT)+1;
            if (0==ModuleWriteCount) ModuleWriteCount = 1;
            Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
            // calculate and write the checksum
            UINT16 Chksum = Eeprom.ComputeEepromChecksum();
            Eeprom.WriteByte(EE_MODULEINFO_CHKSUM,(UINT8)Chksum);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_CHKSUM+1,(UINT8)(Chksum>>8));
            Eeprom.CheckWriteInProgress();
            //Disable the writes EEPROM
            Eeprom.DisableWrite();

            //TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x107);
        }
    }
}
/*******************************************************************************
*                       clsAihBoxSlot::FlashCalibrationData                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihBoxSlot::FlashCalibrationData(VOID) {
    UINT8 *ucBufferPtr;
    UINT16 uiCount;
    UINT8 ucModuleInfoBlockTop[MAX_EEPROM_SIZE];       // for EEPROM and FLASH(top)
    // note: In case of EEPROM, the Top buffer does not include the first 16 byte
    // of EEPROM which is the manufacture data.
    /*
     * enabled the part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */
#if defined(IOPTYPE_HLAI) //#ifndef DEBUG
    UINT8 ucModuleInfoBlockBottom[FLASH_PROGRAM_BLOCK_SIZE];    // for FLASH(bottom)
#endif

    // Initialize the buffers.
    for (uiCount = 0; uiCount < MAX_EEPROM_SIZE; uiCount++) {
        ucModuleInfoBlockTop[uiCount]    = 0xFF;
    }
    /*
     * enabled the part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */
#if defined(IOPTYPE_HLAI) //#ifndef DEBUG
    for (uiCount = 0; uiCount < FLASH_PROGRAM_BLOCK_SIZE; uiCount++) {
        ucModuleInfoBlockBottom[uiCount]  = 0xFF;
    }
#endif

    /*
     * Disabling below part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */
#if !defined(IOPTYPE_HLAI)
    // First check if the SPI EEPROM is present on the app board. If the SPI
    // EEPROM is present then store the data in SPI EEPROM else use FLASH.
    // Read the status register. Bits 2 and 3 are write protect bits and
    // always 0 as we do not protect it. If we see any of these bits ON,then
    // it is safe to assume that SPI device is not present.
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        // Fill the information at the top of the module info block.
        ucBufferPtr = ucModuleInfoBlockTop;
        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefHiLimit;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefLoLimit;
        ucBufferPtr += sizeof(FLOAT32);
#if !LOWCOST
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset;
        ucBufferPtr += sizeof(FLOAT32);

        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fChannelZeroDrift[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#else   // LOWCOST
        ucBufferPtr += sizeof(FLOAT32);    // skip spare1
        ucBufferPtr += sizeof(FLOAT32);    // skip spare2

        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#endif

        // calculate Total number fo bytes to be copied to EEPROM
        UINT16 uCalDataBytes = ucBufferPtr - ucModuleInfoBlockTop;
        // Reinit the pointer
        ucBufferPtr = ucModuleInfoBlockTop;
        //Enable the writes EEPROM
        Eeprom.EnableWrite();
        //Start writing calibration constants to EEPROM.

        for (UINT16 ucCount=0; ucCount < uCalDataBytes; ucCount++) {
            Eeprom.WriteByte(ucCount+EE_CALIBRATION_5VREF_HILIMIT,*ucBufferPtr);
            ucBufferPtr++;
            Eeprom.CheckWriteInProgress();
        }

        // Write Calibration complete
        Eeprom.WriteByte(EE_CALIBRATION_MARK,CALIBRATION_DONE);
        Eeprom.CheckWriteInProgress();

        Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS,0x5A);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS+1,0x5A);
        Eeprom.CheckWriteInProgress();

        UINT16 ModuleWriteCount;
        ModuleWriteCount = Eeprom.ReadUint16(EE_MODULEINFO_WRITECOUNT)+1;
        if (0==ModuleWriteCount) ModuleWriteCount = 1;
        Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
        Eeprom.CheckWriteInProgress();
        // calculate and write the checksum
        UINT16 Chksum = Eeprom.ComputeEepromChecksum();
        Eeprom.WriteByte(EE_MODULEINFO_CHKSUM,(UINT8)Chksum);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_CHKSUM+1,(UINT8)(Chksum>>8));
        Eeprom.CheckWriteInProgress();
        //Disable the writes EEPROM
        Eeprom.DisableWrite();

        //TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x108,(UINT32)Eeprom.ReadByte(EE_MODULEINFO_WRITECOUNT));
        return TRUE;
    }

    // *************************************************************
    //    EEPROM does not exist. Write to FLASH. Write 2 sectors
    // *************************************************************
    // note: Question for LLMUX since 4 byte x 64 chan = 256.
//#ifndef DEBUG // Flash programming will not be supported by APP debug build.
    else
#else
	{
#ifdef DEBUG
	while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalib data storing into FLASH, "));
#endif
        // Fill the information at the top of the module info block.
        ucBufferPtr = ucModuleInfoBlockTop;
        *((UINT16 *)ucBufferPtr) = VENDOR_ID;
        ucBufferPtr += sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = PRODUCT_TYPE;
        ucBufferPtr += sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = PRODUCT_CODE;
        ucBufferPtr += sizeof(UINT16);
        *((UINT32 *)ucBufferPtr) = SERIAL_NUMBER;
        ucBufferPtr += sizeof(UINT32);
        *((UINT8 *)ucBufferPtr) = HARDWARE_REVCODE;
        ucBufferPtr += sizeof(UINT8);

         ucBufferPtr += sizeof(UINT32); // Fill area.
        *((UINT8 *)ucBufferPtr) = CALIBRATION_DONE;
        ucBufferPtr += sizeof(UINT8);

        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefHiLimit;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefLoLimit;
        ucBufferPtr += sizeof(FLOAT32);
#if !LOWCOST
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset;
        ucBufferPtr += sizeof(FLOAT32);

        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fChannelZeroDrift[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#else   // LOWCOST
        ucBufferPtr += sizeof(FLOAT32);    // skip spare1
        ucBufferPtr += sizeof(FLOAT32);    // skip spare2

        UINT8 ucCount;
        for (ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
        for (ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#endif

        // Fill information at the bottom of module info block.
        ucBufferPtr = ucModuleInfoBlockBottom + FLASH_PROGRAM_BLOCK_SIZE - 1;
        *((UINT16 *)ucBufferPtr) = 0; // Replace this CRC value later.

        ucBufferPtr -= sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = MODULINFO_WRITE_COMPLETE;

        // Program number of times module info section is programmed.
        ucBufferPtr -= sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) =  MODULEINFO_WRITECOUNT + 1;
        if (0 == *((UINT16 *)ucBufferPtr)) {
            *((UINT16 *)ucBufferPtr) = 1;
        }

        if (EraseFlash(MODULE_INFO_FLASH_BLOCK)) {
            if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS,
                ucModuleInfoBlockTop)) {
                if (ProgramFlash((UINT8 *)(MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1),
                    ucModuleInfoBlockBottom)) {
#ifdef DEBUG
	while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("done"));
#endif
                    return TRUE;
                }
            }
        }
    }
//#endif // ifndef DEBUG
#endif

    return FALSE;
}

/*******************************************************************************
*                       clsAihBoxSlot::ValidateCheckVoltage                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihBoxSlot::ValidateCheckVoltage(UINT8 a_ucSlotNum,UINT16 a_uiZeroRef) {

    UINT16 uiRefInput = 0;

    switch (a_ucSlotNum) {

    case IN_CHAN01:
    case IN_CHAN02:
    case IN_CHAN03:
        uiRefInput = IN_CKVT1;
        break;
    case IN_CHAN04:
    case IN_CHAN05:
    case IN_CHAN06:
        uiRefInput = IN_CKVT2;
        break;
    case IN_CHAN07:
    case IN_CHAN08:
    case IN_CHAN09:
        uiRefInput = IN_CKVT3;
        break;
    case IN_CHAN10:
    case IN_CHAN11:
    case IN_CHAN12:
        uiRefInput = IN_CKVT41;
        break;
    case IN_CHAN13:
    case IN_CHAN14:
        uiRefInput = IN_CKVT52;
        break;
    case IN_CHAN15:
    case IN_CHAN16:
        uiRefInput = IN_CKVT5;
        break;
    }

    FLOAT32 fRefInput = ((FLOAT32)(Adc.GetRawData(uiRefInput) - a_uiZeroRef) * CalibData.fCalibrationSlope) + CalibData.fCalibrationOffset;

    uiRefInput -= (MAXSLOTS + 1); // Compute index to REFVOLTAGE_LIMITS array.

    if ((fRefInput > REFVOLTAGE_LIMITS[uiRefInput].fHiLimit) ||
        (fRefInput < REFVOLTAGE_LIMITS[uiRefInput].fLoLimit)) {
        return FALSE;
    }

    return TRUE;
}

/*******************************************************************************
*                         clsAihBoxSlot::DoIdleDiagnostics                     *
*                         ================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::DoIdleDiagnostics(VOID) {
#if !LOWCOST
    // Validate zero reference.
    UINT16 uiZeroRefCount = Adc.GetRawData(IN_REF0);
    if (BOARDTYPE_PASSONE == BoardType) {
        if ((uiZeroRefCount < PASS1_ZERO_REF_LOLIMIT) ||
            (uiZeroRefCount > PASS1_ZERO_REF_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
            return;
        }
    }
    else { // Pass2 board
        if ((uiZeroRefCount < PASS2_ZERO_REF_LOLIMIT) ||
            (uiZeroRefCount > PASS2_ZERO_REF_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
            return;
        }
    }
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);

    // Validate 5V reference.
    UINT16 uiRefInput = Adc.GetRawData(IN_CKVT5) - uiZeroRefCount;
    if (BOARDTYPE_PASSONE == BoardType) {
        if ((uiRefInput < PASS1_FIVE_VOLT_LOLIMIT) ||
            (uiRefInput > PASS1_FIVE_VOLT_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,TRUE,0);
            return;
        }
    }
    else { // Pass2 board
        if ((uiRefInput < PASS2_FIVE_VOLT_LOLIMIT) ||
            (uiRefInput > PASS2_FIVE_VOLT_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,TRUE,0);
            return;
        }
    }
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,FALSE,0);

    // Test 5V reference against limits for stored in flash.
    if (((FLOAT32)uiRefInput > CalibData.f5VRefHiLimit) ||
        ((FLOAT32)uiRefInput < CalibData.f5VRefLoLimit)) {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
        return;
    }

    // Test against +/- 4% limits of the reference voltage
    // corresponding to the current PPX channel.
    if (FALSE == ValidateCheckVoltage(PpxChannel,uiZeroRefCount)) {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
        return;
    }
#endif
}


/*******************************************************************************
*                       clsAihBoxSlot::PpxInterruptHandler                     *
*                       ==================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: this handler will be called for every 3.125ms PIT configured          *
*                                                                              *
*******************************************************************************/
VOID clsAihBoxSlot::PpxInterruptHandler(VOID) {

	UINT16 uiZeroRef = 0;

#if 1 // testing
    BOX->CalibrationGood = TRUE;
    BOX->CalibData.fChannelZeroDrift[BOX->PpxChannel-1] = 0.0;
    BOX->CalibData.fCalibrationOffset = 0.0;
    BOX->CalibData.fCalibrationSlope = (BOARDTYPE_PASSONE == BOX->BoardType) ? (1 / 12451.65) : (1 / 11232.699);
#else
	static volatile UINT32 PpxCount = 0;

	if((++PpxCount > 640) && (BOX->PpxChannel == 1)) // 3.125 x 320 = 1 sec
	{
		PpxCount = 0;
		bOneSecTick = TRUE;
	}    
#endif

	if((FALSE == BOX->CalibrationGood) // Calibration data is bad or not available,
	|| (FALSE == BOX->GetFtaPres())) { // FTA missing,

		BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_ADOUTCAL, TRUE, 0);
		SLOT(BOX->PpxChannel)->ProcessSlot(NaN);
	}
	else if(MODSTATUS_IDLE == BOX->ModStat1.Status) {
		// Return open wire softfail if any, since module is now idle.
		SLOT(BOX->PpxChannel)->DisableOpenWireCheck();
		BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, FALSE, BOX->PpxChannel);
        // If module is IDLE, return any diagnostic circuit failure. It was found
        // during testing that an extremely chattering input may misfire this box softfail
        // and IDLEing the module is the only way this softfail can be cleared. If this is
        // in fact a module h/w problem, softfail will be reposted when module is RUN again.
        BOX->SetOwdCktGood();
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_DIAGCTFL, FALSE, 0);
        // previously softfail SF_BADRJVAL was returned here,
        // but now it is removed as part of PAR 1-ATOTCQ fix.
        if (FALSE == BOX->CalibAll) {
            BOX->DoIdleDiagnostics();

            if (PTEXECST_ACTIVE == SLOT(BOX->PpxChannel)->GetPtExecSt()) {
                SLOT(BOX->PpxChannel)->ProcessSlot(NaN);
            }
        }
	}
	else if (MODSTATUS_RUN == BOX->ModStat1.Status) {

#if 0 // temp only for testing
		// Check ZeroRef each time
		// Open wire testing enabled in the previous cycle for this channel.
		// Re-evaluate the conditions and disable if required.
		if (TRUE != (BOX->IsOwdCktGood())
		|| (SLOT(BOX->PpxChannel)->GetOwdEnable() == FALSE)
		|| (SLOT(BOX->PpxChannel)->GetPtExecSt() != PTEXECST_ACTIVE)) {

			SLOT(BOX->PpxChannel)->DisableOpenWireCheck();
			BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, FALSE, BOX->PpxChannel);
		}
#endif
		uiZeroRef = Adc.GetRawData(IN_REF0); // Convert zero reference.
		// Do the zero reference test based on the board type.
		if (BOARDTYPE_PASSONE == BOX->BoardType) {
			if ((uiZeroRef < PASS1_ZERO_REF_LOLIMIT) ||
				(uiZeroRef > PASS1_ZERO_REF_HILIMIT)) {
				// Post softfail for zero reference test failure.
				BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
			}
			else { // Zero reference test passed. Return softfail if any.
				BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
			}
		}
		else { // Pass2 board
			if ((uiZeroRef < PASS2_ZERO_REF_LOLIMIT) ||
				(uiZeroRef > PASS2_ZERO_REF_HILIMIT)) {
				// Post softfail for zero reference test failure.
				BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
			}
			else { // Zero reference test passed. Return softfail if any.
				BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
			}
		}


//#if !LOWCOST

		UINT16 uiRawData = 0;
		FLOAT32 fRawData = NaN;

		uiRawData = Adc.GetRawData(BOX->PpxChannel); // Convert raw data for this channel.
		SLOT(BOX->PpxChannel)->StoreRawAdcCount(uiRawData); // Store raw count in channel.

#if 0 // temp only for testing
		// Check the common mode voltage warning bit.
		if (0 == BOX->OVERVT_n()) {
			SLOT(BOX->PpxChannel)->DisableOpenWireCheck();
			// Fix for PAR:1-ATOTCQ
			// posting of soft fail is removed ,as currently we dont have
			// soft fail code present for Common mode voltage out of range.
			// Instead of that we are supposed to set Pv to NAN and Pvstatus to BAD,
			// but that is happening  in process slot function.
		}
		else
#endif
		{

#if 0 // temp only for testing

			SLOT(BOX->PpxChannel)->CheckOpenWire(); // First open wire check

			// Convert and test the check voltage corresponding to this channel.
			// This test ensures that the analog mux is switching correctly.
			if (FALSE == BOX->ValidateCheckVoltage(BOX->PpxChannel,uiZeroRef)) {

				// Check voltage test failed for this channel. Post softfail.
				BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
			}
			else // Check voltage validated.
#endif
			{

				BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_ADOUTCAL, FALSE, 0);
				// Connnect ADC back to the input channel. This is done now so
				// that there is enough time for the MUX to settle before the
				// VerifyOwdCkt is called at the end of PPX. Since MUX is settled,
				// VerifyOwdCkt can take the ADC sample without additional wait.
				Adc.Connect(BOX->PpxChannel);

				if ((0 == uiRawData) || (MAXIMUM_ADCOUNT == uiRawData)) {
					// ADC count check failed. Post ADOUTUDF softfail.
					BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTUDF,FALSE,BOX->PpxChannel);
				}
				else { // ADC count is good. Clear ADOUTUDF softfail if any.
					BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTUDF,FALSE,BOX->PpxChannel);
					SLOT(BOX->PpxChannel)->CheckOpenWire(); // Second open wire check

					// Threshold values based on the Board Type. Applied to 1-5V and P4-2V configuration.
					// The NaN Threshold corresponds to -24% (1-5V) or -22.5% (P4-2V).
					UINT16 uiNanEnterThreshold;   // set NaN if RawData is below this value (40 mV)
					UINT16 uiNanExitThreshold;    // Exit from NaN if RawData is above this value (50 mV)
					if (BOARDTYPE_PASSTWO == BOX->BoardType) {
						uiNanEnterThreshold = PASS2_INPUT_NAN_COUNT;    // =589
						uiNanExitThreshold = uiNanEnterThreshold + PASS2_INPUT_DEADBAND_BIAS;
					}
					else { // BOARDTYPE_PASSONE
						uiNanEnterThreshold = PASS1_INPUT_NAN_COUNT;    // =1307
						uiNanExitThreshold = uiNanEnterThreshold + PASS1_INPUT_DEADBAND_BIAS;
					}

					// convert counts to 0.0 to 5.0 value, or to NaN
					if (uiRawData > uiNanEnterThreshold) { // RawData is greater than NaN threshold.
						if (TRUE == SLOT(BOX->PpxChannel)->WasInputBelowDeadband()) {
							// Input was below deadband in previous cycle. Continue raw value
							// calculation, only if it had risen above deadband in this cycle.
							// This allows a hysteris to set in once input goes below NaN threshold.

							if (uiRawData > uiNanExitThreshold) {
								SLOT(BOX->PpxChannel)->SetInputBelowDeadband(FALSE);
								fRawData = (FLOAT32)uiRawData;
								fRawData -= (FLOAT32)(uiZeroRef + BOX->CalibData.fChannelZeroDrift[BOX->PpxChannel - 1]);
							}
						}
						else { // Input was above NaN threshold in previous cycle.
							fRawData = (FLOAT32)uiRawData;
							fRawData -= (FLOAT32)(uiZeroRef + BOX->CalibData.fChannelZeroDrift[BOX->PpxChannel - 1]);
						}
					}
					else if ((SENSRTYP_0to5_V   == SLOT(BOX->PpxChannel)->GetSensrType()) ||
							 (SENSRTYP_SLIDWIRE == SLOT(BOX->PpxChannel)->GetSensrType())) {
						SLOT(BOX->PpxChannel)->SetInputBelowDeadband(FALSE);
						fRawData = (FLOAT32)uiRawData;
						fRawData -= (FLOAT32)(uiZeroRef + BOX->CalibData.fChannelZeroDrift[BOX->PpxChannel - 1]);
					}
					else { // Input is below NaN threshold and sensor type is not 0to5V.
						fRawData = NaN;
						SLOT(BOX->PpxChannel)->SetInputBelowDeadband(TRUE);
					}

					// All checks passed. Use calibration data
					// to convert ADC counts into raw data.
			if (!isnan(fRawData)) {
						fRawData *= BOX->CalibData.fCalibrationSlope;
						fRawData += BOX->CalibData.fCalibrationOffset;

#if 1 //defined(IOPTYPE_HLAI)
						// work around to make pvraw high, when SLIDWIRE not connected.
						if ((uiRawData <= uiNanEnterThreshold) && (SENSRTYP_SLIDWIRE == SLOT(BOX->PpxChannel)->GetSensrType()))
						{
							fRawData  = BOX->SlwSrcBuff[SLOT(BOX->PpxChannel)->GetSlwSrcId()-1];
							fRawData += SLOT(BOX->PpxChannel)->GetADRawLo();
							fRawData /= SLOT(BOX->PpxChannel)->GetHundredDivRawSpan();
						}
#endif
					}
					SLOT(BOX->PpxChannel)->CheckOpenWire(); // Third open wire check
				}
			}  // else part of validate check voltage
		} // else part of common mode voltage check

#if 1 //defined(IOPTYPE_HLAI)
		// Storing Slidewire power source into buffer
		BOX->SlwSrcBuff[BOX->PpxChannel - 1] = fRawData;

		// Slidewire first pass clear to get slidewire pwr src from buffer
		if (MAXSLOTS == BOX->PpxChannel) BOX->bSlwFirstPass = FALSE;

		// If not slidewire sensor or not slidewire first pass
		if ((FALSE == BOX->bSlwFirstPass) || (SENSRTYP_SLIDWIRE != SLOT(BOX->PpxChannel)->GetSensrType()))
#endif
			SLOT(BOX->PpxChannel)->ProcessSlot(fRawData); // Do slot processing.


	} // else if MODSTATUS_RUN

	// Setup to do point PPX in the next channel in the next cycle.
	BOX->PpxChannel = (MAXSLOTS == BOX->PpxChannel) ? 1 : BOX->PpxChannel + 1;

	if ((BOX->IsOwdCktGood() == TRUE) &&
			(BOX->GetModuleStatus() == MODSTATUS_RUN) &&
			(SLOT(BOX->PpxChannel)->GetOwdEnable() == TRUE) &&
			(SLOT(BOX->PpxChannel)->GetPtExecSt() == PTEXECST_ACTIVE)) {
		// Connect open wire MUX to the next channel so that HART filter
		// capacitors will be stabilized before actual open wire detection
		// start in the next cycle. Decision to carry on with open wire
		// detection or not will be taken at the beginning of next cycle.
		SLOT(BOX->PpxChannel)->EnableOpenWireCheck();
	}
}

/*******************************************************************************
*                               PerformModuleCalibration                       *
*                               ========================                       *
* PURPOSE: This function is responsible for module calibration                 *
* ARGUMENTS: None.                                                             *
* RETURN: TRUE if successful, FALSE otherwise                                  *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsAihBoxSlot::PerformModuleCalibration(VOID)
{
    UINT8  ucCount;
    FLOAT32 fOneVolt,fFiveVolt;
    clsOlympicAverage CalInputAverage,ZeroRefAverage;

#if !LOWCOST
    const UINT8 TOTAL_SAMPLES = 34;
    UINT16 uiCount;
    FLOAT32 fZeroRef;

    AssertBackup();

    if (FACTCAL() == FALSE) { // If factory calibration is being performed
#if 0 //#ifdef DEBUG
        if (BOARDTYPE_PASSONE == BoardType) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Pass 1 board"));
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Pass 2 board"));
        }
#else
        if (BOARDTYPE_PASSONE == BoardType) {
        	PRINTF("\n\r\tFactory calibration..Pass 1 board");
        }
        else {
        	PRINTF("\n\r\tFactory calibration..Pass 2 board");
        }
#endif
        // Wait till user press and release CALIBRATE switch on the IOTA.
        while (!CALIBRATE()) { // Process any pending writes while waiting
            WriteDatabaseTask(TASKCONTEXT_ZERO);
            // Abort calibration if cancel request was done
            if (FALSE == CalibAll) return FALSE;
        }
        while (CALIBRATE()) { // Process any pending writes while waiting
            WriteDatabaseTask(TASKCONTEXT_ZERO);
            // Abort calibration if cancel request was done
            if (FALSE == CalibAll) return FALSE;
        }

        BlinkLed(1);

        // Start with averaging 1V at calib inputs.
        for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {

            uiCount = Adc.GetRawData(IN_CALIB,CALIBRATION_MUX_SETTLE_TIME);
            CalInputAverage.AddSample(uiCount);

            uiCount = Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
            ZeroRefAverage.AddSample(uiCount);
        }

        fZeroRef = ZeroRefAverage.GetResult();
        fOneVolt = CalInputAverage.GetResult() - fZeroRef;

#if 0 //#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f",
                                          ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(),
                                          fZeroRef));
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t1V Hi = %d Lo = %d Avg = %f+%f\n",
                                          CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                          fOneVolt,fZeroRef));
#else
        PRINTF("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f", ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(), fZeroRef);
        PRINTF("\n\r\t1V Hi = %d Lo = %d Avg = %f+%f\n",  CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(), fOneVolt,fZeroRef);
#endif
        uiCount = (UINT16) fOneVolt;
        if (BOARDTYPE_PASSONE == BoardType) {
            if ((uiCount < PASS1_ONE_VOLT_LOLIMIT) ||
                (uiCount > PASS1_ONE_VOLT_HILIMIT)) {
                // Post bad calibration reference softfail.
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
                CalibAll = FALSE;
                return FALSE; // Abort calibration.
            }
        }
        else { // Pass2 board
            if ((uiCount < PASS2_ONE_VOLT_LOLIMIT) ||
                (uiCount > PASS2_ONE_VOLT_HILIMIT)) {
                // Post bad calibration reference softfail.
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
                CalibAll = FALSE;
                return FALSE; // Abort calibration.
            }
        }
    }
    else { // Field calibration. Ensure that factory calibration data is present.
        if (CalibrationGood != TRUE) {
#if 0 //#ifdef DEBUG
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tDo factory calibration first"));
#else
            PRINTF("\n\r\tDo factory calibration first");
#endif
            CalibAll = FALSE;
            return FALSE; // Abort calibration.
        }
#if 0 //#ifdef DEBUG
        if (BOARDTYPE_PASSONE == BoardType) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tField calibration..Pass 1 board"));
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tField calibration..Pass 2 board"));
        }
#else
        if (BOARDTYPE_PASSONE == BoardType) {
        	PRINTF("\n\r\tField calibration..Pass 1 board");
        }
        else {
        	PRINTF("\n\r\tField calibration..Pass 2 board");
        }
#endif
    }

    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE()) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO);
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE()) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO);
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    BlinkLed(2);

    // Average 5V at calib inputs for both factory and field calibration.
    ZeroRefAverage.Initialize();
    CalInputAverage.Initialize();

    for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {

        uiCount = Adc.GetRawData(IN_CALIB,CALIBRATION_MUX_SETTLE_TIME);
        CalInputAverage.AddSample(uiCount);

        uiCount = Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
        ZeroRefAverage.AddSample(uiCount);
    }

    fZeroRef = ZeroRefAverage.GetResult();
    fFiveVolt = CalInputAverage.GetResult() - fZeroRef;

#if 0 //#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f",
                                      ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(),
                                      fZeroRef));
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t5V Hi = %d Lo = %d Avg = %f+%f\n",
                                      CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                      fFiveVolt,fZeroRef));
#else
    PRINTF("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f", ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(), fZeroRef);
    PRINTF("\n\r\t5V Hi = %d Lo = %d Avg = %f+%f\n", CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(), fFiveVolt,fZeroRef);
#endif
    uiCount = (UINT16) fFiveVolt;
    if (BOARDTYPE_PASSONE == BoardType) {
        if ((uiCount < PASS1_FIVE_VOLT_LOLIMIT) ||
            (uiCount > PASS1_FIVE_VOLT_HILIMIT)) {
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE;
            return FALSE; // Abort calibration.
        }
    }
    else { // Pass2 board
        if ((uiCount < PASS2_FIVE_VOLT_LOLIMIT) ||
            (uiCount > PASS2_FIVE_VOLT_HILIMIT)) {
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE;
            return FALSE; // Abort calibration.
        }
    }
    // Clear bad calibration reference softfail if any.
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,0);

    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE()) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO);
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE()) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO);
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    BlinkLed(3);

    if (0 == FACTCAL()) { // if factory calibration
        CalibData.fCalibrationSlope = 4.0 / (fFiveVolt - fOneVolt);
        CalibData.fCalibrationOffset =  1.0 - (CalibData.fCalibrationSlope * fOneVolt);
    }
    else { // if field calibration
        CalibData.fCalibrationSlope = (5.0 - CalibData.fCalibrationOffset) / fFiveVolt;
    }

    // Validate reference voltages.
    for (ucCount = 1; ucCount <= NO_OF_REF_VOLTAGES; ucCount++) {

        FLOAT32 fRefInput = (FLOAT32)Adc.GetRawData(MAXSLOTS + ucCount,CALIBRATION_MUX_SETTLE_TIME);
        fZeroRef = (FLOAT32)Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
        fRefInput -= fZeroRef;

        if (NO_OF_REF_VOLTAGES == ucCount) {
            // Save 5V reference limits for storing in flash.
            CalibData.f5VRefHiLimit = fRefInput + (FLOAT32) FIVE_VOLT_TOLERENCE_COUNT;
            CalibData.f5VRefLoLimit = fRefInput - (FLOAT32) FIVE_VOLT_TOLERENCE_COUNT;
        }
        fRefInput = (fRefInput * CalibData.fCalibrationSlope) + CalibData.fCalibrationOffset;
#if 0 //#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCHKVT%d : %f ZeroCount : %f",
                                          ucCount,(fRefInput * 1000),fZeroRef));
#else
        PRINTF("\n\r\tCHKVT%d : %f ZeroCount : %f", ucCount,(fRefInput * 1000),fZeroRef);
#endif
        if ((fRefInput > REFVOLTAGE_LIMITS[ucCount - 1].fHiLimit) ||
            (fRefInput < REFVOLTAGE_LIMITS[ucCount - 1].fLoLimit)) {
#if 0 //#ifdef DEBUG
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCHKVT test failed"));
#else
            PRINTF("\n\r\tCHKVT test failed");
#endif
            CalibAll = FALSE;
            return FALSE;
        }
    }

    if (0 == FACTCAL()) { // if factory calibration
        // Find individual channel zero drift offsets.
        for (UINT8 ucSlot = 1; ucSlot <= MAXSLOTS; ucSlot++) {

            ZeroRefAverage.Initialize();
            CalInputAverage.Initialize();

            for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {

                uiCount = Adc.GetRawData(ucSlot,CALIBRATION_MUX_SETTLE_TIME);
                CalInputAverage.AddSample(uiCount);

                uiCount = Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
                ZeroRefAverage.AddSample(uiCount);
            }
            fZeroRef = ZeroRefAverage.GetResult();
            CalibData.fChannelZeroDrift[ucSlot - 1] = CalInputAverage.GetResult() - fZeroRef;
#if 0 //#ifdef DEBUG
            if (ucSlot & 0x01) {
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r"));
            }
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\tChan%d zero drift %f",ucSlot,
                                                                    CalibData.fChannelZeroDrift[ucSlot - 1]));
#else
            if (ucSlot & 0x01) {
            	PRINTF("\n\r");
            }
            PRINTF("\tChan%d zero drift %f",ucSlot, CalibData.fChannelZeroDrift[ucSlot - 1]);
#endif
        }
    }
#else // Lowcost

    const UINT8 TOTAL_SAMPLES = 34;
    UINT32 ulCount,ulRawCount[MAXSLOTS];
    UINT16 SAMPLE_WAIT = 5000;       // 5 msec IdleWait after GetRawData()

    UINT8   ucSlot,ucSeq,ucEnd;
    FLOAT32 fOneVoltArray[MAXSLOTS];
    FLOAT32 fFiveVoltArray[MAXSLOTS];

    for(ucSlot=0;ucSlot<MAXSLOTS;ucSlot++){
    fOneVoltArray[ucSlot]  = NaN;
    fFiveVoltArray[ucSlot] = NaN;
    ulRawCount[ucSlot] = 0;
    }

    AssertBackup();

#ifdef DEBUG
        if (BOARDTYPE_LOWCOST == BoardType) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Low Cost Board"));
        }
#endif

    ucEnd = MAXSLOTS; // 1 to 16 chanels.

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tApply 0.8V input to all 16 Channels and touch calib pad"));
#endif

    // Wait till user press and release CALIBRATE switch on the IOTA.
    if(WaitCalibSwitch()==FALSE){
        return FALSE;
    }

    // Average 0.8V at input channel(16 Channels) for factory calibration.
    for(ucSeq = 1;ucSeq<=ucEnd;ucSeq++){
        CalInputAverage.Initialize();
        for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {
        Adc.GetRawData(FALSE,ulRawCount,TRUE);
        ulCount = (ulRawCount[ucSeq-1] & ADC_CHAN_DATA_MASK);
        CalInputAverage.AddSample(ulCount);
        IdleWait(SAMPLE_WAIT);
        }
        fOneVolt = CalInputAverage.GetResult();

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t0.8V Hi = 0x%08X Lo = 0x%08X Avg = %f\n",
                                      CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                      fOneVolt));
#endif
        ulCount = (UINT32) fOneVolt;
        if ((ulCount < LCOST_0_8_VOLT_LOLIMIT) ||
            (ulCount > LCOST_0_8_VOLT_HILIMIT)){
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE;
            return FALSE; // Abort calibration.
        }
        fOneVoltArray[ucSeq-1] = fOneVolt;
        for(ucSlot=0;ucSlot<MAXSLOTS;ucSlot++){
           ulRawCount[ucSlot] = 0;
        }
    }

    ucEnd = MAXSLOTS; // 1 to 16 chanels. now for 4V
    BlinkLed(1);

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tNow Apply 4V input to all 16 Channels and touch calib pad"));
#endif

    // Wait till user press and release CALIBRATE switch on the IOTA.
    if(WaitCalibSwitch()==FALSE){
      return FALSE;
     }

    // Average 4V at input channel(16 Channels) for factory calibration.
    for(ucSeq = 1;ucSeq<=ucEnd;ucSeq++){
        CalInputAverage.Initialize();
        for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {
        Adc.GetRawData(FALSE,ulRawCount,TRUE);
        ulCount = (ulRawCount[ucSeq-1] & ADC_CHAN_DATA_MASK);
        CalInputAverage.AddSample(ulCount);
        IdleWait(SAMPLE_WAIT);
        }
        fFiveVolt = CalInputAverage.GetResult();

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t4V Hi = 0x%08X Lo = 0x%08X Avg = %f\n",
                                      CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                      fFiveVolt));
#endif
        ulCount = (UINT32) fFiveVolt;
        if ((ulCount < LCOST_FOUR_VOLT_LOLIMIT) ||
            (ulCount > LCOST_FOUR_VOLT_HILIMIT)){
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE;
            return FALSE; // Abort calibration.
        }

        fFiveVoltArray[ucSeq-1] = fFiveVolt;
        for(ucSlot=0;ucSlot<MAXSLOTS;ucSlot++){
           ulRawCount[ucSlot] = 0;
        }
    }
    // Clear bad calibration reference softfail if any.
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,0);

    BlinkLed(2);

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tTouch calib pad module will reboot"));
#endif
    // Wait till user press and release CALIBRATE switch on the IOTA.
       if(WaitCalibSwitch() == FALSE){
          return FALSE; // Abort calibration
       }
    BlinkLed(3);

    // Calculating the slope and offset for each channel.
    for (ucSlot = 0; ucSlot < MAXSLOTS ; ucSlot++)
    {
           CalibData.fCalibrationSlope[ucSlot]  = (4.0 - 0.8) / (fFiveVoltArray[ucSlot] - fOneVoltArray[ucSlot]);
           CalibData.fCalibrationOffset[ucSlot] = 0.8 - (CalibData.fCalibrationSlope[ucSlot] * fOneVoltArray[ucSlot]);
     }

#endif
    if (FlashCalibrationData()) {
        // Calibrtion is successful.
        //TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibDone,MODULEINFO_WRITECOUNT);

#if 0 //#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalibration successful"));
#endif
#if LOWCOST
        // Clear write message queue before rebooting IOM, as it is utilised for
        // copying ProgramFlash and EraseFlash routines before flashing
        UINT16 usItr;
        UINT8* ucPtr = WriteMsgQueue.GetMsgBufferPtr();
        // Wait for a watchdog refresh to happen so that there is maximum time is
        // available to the flash uitility before the next watchdog refresh window.
        while (TaskScheduler.GetWdtRefreshCounter() != 0);

        for(usItr = 0;usItr < WRITEMSG_QUEUESIZE;usItr++) {
            ucPtr[usItr] = 0x00;
        }
#endif
        // Reboot the module so that the new
        // calibration data gets loaded.
#if 0 // temp for testing
        RebootIom();
#endif

        /*
         * Since FRAM is replaced with backup SRAM, calibration done must be stored in FLASH only.
         */
#if defined(IOPTYPE_HLAI)
        xRamWrite((xRAM_CHKPNT_ADRS + xRAM_CALIB_DONE), (UINT8 *)&TRUE, sizeof(UINT8));
#endif
    }

    CalibAll = FALSE;
    return FALSE;
}


BOOL clsAihBoxSlot::FACTCAL(VOID)  {

	return (hal_fpga_get_misc_status() & FPGA_MISC_FACTCAL);
}
BOOL clsAihBoxSlot::CALIBRATE(VOID){

	return (hal_fpga_get_misc_status() & FPGA_MISC_CALIBRATE);
}
BOOL clsAihBoxSlot::OVERVT_n(VOID) {

	return (hal_fpga_get_misc_status() & FPGA_MISC_OVERVT_n);
}

/*******************************************************************************
*                         extern "C" ISR Wrapper                               *
*                         =======================                              *
* PURPOSE:                                                                     *
*    Provide C linkage for PpxInterruptHandler so it can be called from C      *
*    code (hal_pit.c). This wrapper forwards to the C++ static member.         *
*******************************************************************************/
extern "C" void PpxInterruptHandler(void) {
	clsAihBoxSlot::PpxInterruptHandler();
}
