BUILD 33 - HART COMMAND 13/14/15 STATE-MACHINE TEST
===================================================

PURPOSE
-------
This build keeps the S1 Command 13, 14, and 15 structures, handler names,
handler bodies, and initialization order. It fixes the condition where an
HART-enabled channel can remain in INIT with its scan counter disabled after
startup/configuration restoration.

BUILD
-----
1. Import/open the Build 33 project in MCUXpresso.
2. Project -> Refresh.
3. Project -> Clean.
4. Project -> Build Project.
5. Confirm these compile again:
       ../source/hart.cpp
       ../source/hartdb.cpp
       ../source/hartstack.cpp
6. Flash the newly generated AXF.
7. Power-cycle once and leave the module running for at least 90 seconds.

EXPECTED CONSOLE OUTPUT
-----------------------
Only the final successful HART value is added by the HART code:

    HART CHANNEL=2 MODEM=0 PV=<value>

No TraceLog dump, scan summary, raw response, command diagnostic, or route
print is enabled.

EXPECTED EXPERION RESULT
------------------------
For the one channel with the connected device:

Command 13:
    HTAG, HDESC, HDAY, HMONTH, HYEAR leave the initialization pattern.

Command 14:
    HTDEU, HTDURL, HTDLRL, HTDMINSPAN, HTDSN leave the initialization pattern.

Command 15:
    HEU, HPVURV, HPVLRV, HPVDAMP leave the initialization pattern.

A device can return blank tag/descriptor/message strings, but a successful
response must not remain as repeated '?' from 0xFF initialization. Optional
unsupported commands can remain unavailable only when the device explicitly
returns a non-success response code.

SILENT DEBUGGER CHECK
---------------------
Add these expressions for channel 2:

    g_ucHartLastCommandByChannel[2]
    g_ucHartLastResponseByChannel[2]
    g_ucHartLastPayloadLengthByChannel[2]
    g_ucHartInitIndexByChannel[2]
    g_usHartCmd0GoodMask
    g_usHartCmd13GoodMask
    g_usHartCmd14GoodMask
    g_usHartCmd15GoodMask
    g_usHartShortResponseMask

Expected channel-2 success bit:

    0x0002

Expected successful payload lengths:

    Command 13 = 21
    Command 14 = 16
    Command 15 = 18

Interpretation:

- CMD0 mask does not contain 0x0002:
  device discovery did not complete.

- CMD0 contains 0x0002 but CMD13/14/15 do not:
  inspect last command, response code, payload length, and init index.

- last response is non-zero:
  field device rejected or did not implement that command.

- g_usHartShortResponseMask contains 0x0002:
  a success-status response was received with too few payload bytes and was
  rejected/retried instead of being copied into the database.

- all four masks contain 0x0002 but the Experion display is stale:
  refresh/reopen the channel block and verify the current downloaded block and
  parameter mappings.

TRACELOG
--------
TraceLog remains active and persists to BBSRAM. Its console test and dump are
disabled.

LIMITATION
----------
The target ARM GCC toolchain and PMIO hardware are unavailable in this
environment. Complete the final target build, flash, HART-device test, and
Experion refresh on the PMIO system.
