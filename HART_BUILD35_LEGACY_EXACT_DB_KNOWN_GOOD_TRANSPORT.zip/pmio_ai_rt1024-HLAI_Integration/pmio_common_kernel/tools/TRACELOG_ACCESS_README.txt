PMIO TraceLog access
====================

The BBSRAM TraceLog is not a text file. It is a circular array of packed
10-byte records stored in external battery-backed SPI SRAM:

    UINT16 code
    UINT32 data
    UINT32 time

Build 27 provides three ways to read it.

1. Console dump (recommended for board testing)
------------------------------------------------
The latest 12 application records are printed automatically, newest first,
one record per LowPriorityTask cycle:

    TRACELOG DUMP BEGIN ...
    TRACELOG DUMP INDEX=... CODE=... NAME=... DATA=... TIME=...
    TRACELOG DUMP END ...

To request another dump in the MCUXpresso debugger, set:

    g_ucTraceLogConsoleDumpCount = 20
    g_bTraceLogConsoleDumpRequest = 1

Then resume. Use 80 to dump the complete circular application block.
Records 80-99 are the preserved crash block and are not included in this
normal newest-first dump.

2. Debugger
-----------
Inspect:

    TraceLog.m_ucAppIndex
    TraceLog.TraceRecord[0] ... TraceLog.TraceRecord[99]

The object members are private in C++, so some debugger configurations may
require direct memory/structure expansion rather than an expression.

3. IO-Link parameters
---------------------

    165 TraceLog
    166 TraceLogInfo
    167 TraceLevel

Important: in the current RT1024 database implementation, parameter 165 has a
size of 100 bytes. Since one record is 10 bytes, a single parameter read exposes
a 10-record window, not the full 100-record array. Parameter 166 returns the
4-byte trace time and 1-byte next index. For the complete 80-record application
history, use the console dump or debugger.

Decode bytes copied from the IO-Link tool:

    python tools/decode_tracelog.py trace_hex.txt --input-format hex --byte-order big

Decode a raw little-endian debugger/BBSRAM memory capture:

    python tools/decode_tracelog.py trace.bin --input-format binary --byte-order little -o trace.csv
