BUILD 35 - HART LEGACY DATABASE + RT1024 KNOWN-GOOD TRANSPORT FIX
================================================================

BASES COMPARED
--------------
1. Legacy source: s1(15).zip
2. Previous redesign build: HART_BUILD34_CMD13_14_15_PV_FIX.zip
3. Known-working redesign transport baseline:
   29_QUIET_TRACELOG_HART_PV_ONLY_Project(1).zip
4. SeriesC HART Implementation maintenance document

WHY THE MONITORING SCREENS SHOWED UNKNOWN / NaN / NO RESPONSE
--------------------------------------------------------------
The screen values are the exact initialization pattern of clsHartDevDb:
- HComSts / HLComFail = HCOMSTS_NORESPONSE
- HCmd13 = 0xFF, displayed as ????????, date 255/255/2155
- HCmd14 and HCmd15 = 0xFF, displayed as UNKNOWN 255 and NaN
- HCmd0 identity fields = zero

This means the received HART information did not remain in the IOLINK-visible
legacy database. It was not only a Command 13/14/15 text-decoding issue.

The previous redesign queue path attempted to enter the legacy per-command
state machine immediately and also executed the H8-style MUX readback test
before the RT1024 synchronous SPI transaction. If that path failed before a
clean CMD0/unique address was established, ReceptionComplete(BAD) or the
runtime reset path initialized HCmd0/HCmd13/HCmd14/HCmd15 again.

BUILD 35 CHANGES
----------------
1. INITIAL DISCOVERY USES THE KNOWN-WORKING RT1024 TRANSPORT
   - clsHartQueue::ProcessQueue retains the legacy queue/connect/disconnect
     ownership and the original function name.
   - When m_HChanMode == HCHANMODE_INIT, it calls HartDiscoverOnRoute().
   - HartDiscoverOnRoute performs clean CMD0 discovery, the complete legacy
     initialization table, and CMD3 dynamic-data collection.
   - The H8 memory-mapped MUX loopback diagnostic is not executed in the
     RT1024 synchronous branch.

2. PERIODIC SCANNING RETURNS TO THE LEGACY STATE FLOW
   - After discovery, m_HChanMode is HCHANMODE_SCAN.
   - Periodic DYN/DEV/C48 requests use the existing members:
       m_ucLastReqCmd
       m_ucpLastXmtPtr
       m_ucPollingAddress
       m_UniqueAddress
       m_ucCommStatus
       m_ChanRcvBuffer
   - Responses are completed through the original ReceptionComplete() and
     UpdateDatabase() functions.
   - This prevents HCmd13/HCmd14/HCmd15 from being reset on every PV scan.

3. EXACT LEGACY COMMAND FUNCTIONS RESTORED
   The following normalized function bodies are identical to s1(15):
   - WriteHCmdData
   - Cmd3GoodHandler / Cmd3BadHandler
   - Cmd13GoodHandler / Cmd13BadHandler
   - Cmd14GoodHandler / Cmd14BadHandler
   - Cmd15GoodHandler / Cmd15BadHandler
   - ScheduleFromInitTable

4. EXACT LEGACY INIT TABLE ORDER RETAINED
   HART 5 / HART 6 command order is unchanged from s1:
   48, 59, 6, 38, 12, 13, 14, 15, 16, 20, 50

5. ENDIAN CONVERSION IS OUTSIDE THE LEGACY HANDLERS
   H8 is big-endian and RT1024 is little-endian. Build 35 converts numeric
   fields only in HartDb_LoadParsedResponse before the unchanged handler runs.
   After the handler calculates native FLOAT32 values, the blind HCmd0,
   HCmd13, HCmd14 and HCmd15 blocks are restored to the original HART wire-byte
   sequence expected by IOLINK/server decoding.

   This gives both:
   - correct native Lrl, Url, Lrv, Urv, Damping and HDynVal values; and
   - correct blind HCmd13/HCmd14/HCmd15 parameter bytes.

6. COMMAND 15 REVISION COMPATIBILITY
   - The fixed database remains the legacy 18-byte HCmd15 structure.
   - A successful 16-byte core response is accepted.
   - Missing optional bytes 16 and 17 are initialized to 0xFF.
   - The original Cmd15GoodHandler remains unchanged.

7. LEGACY COMMUNICATION STATE IS PUBLISHED AFTER SYNCHRONOUS DISCOVERY
   On complete discovery, the same IOLINK-visible members are updated:
   - HComSts = HCOMSTS_GOOD
   - HLComFail = HCOMSTS_GOOD
   - m_ucCommStatus = HCOMSTS_GOOD
   - m_HChanMode = HCHANMODE_SCAN
   - m_HDataInit = HDATAINIT_COMPLETE
   - m_sScanCounter and BuildScanTable are initialized for periodic scanning

8. COMMAND 3 / PV
   - Wire-order loop current and PV/SV/TV/QV are converted before the original
     Cmd3GoodHandler runs.
   - Periodic CMD3/CMD9 responses continue through ReceptionComplete().
   - The low-priority terminal output remains:
       HART CHANNEL=<n> MODEM=<n> PV=<value>

VALIDATION COMPLETED
--------------------
- 59 structural and synthetic checks: PASS
- Exact legacy handler/body comparisons: PASS
- Exact HART 5 and HART 6 init-table comparisons: PASS
- Required legacy variable-name checks: PASS
- CMD3 loop/PV/SV/TV/QV byte-order test: PASS
- CMD14 upper/lower/min-span float conversion test: PASS
- CMD15 16-to-18-byte normalization and float conversion test: PASS
- Host 32-bit freestanding syntax checks for hart.cpp, hartdb.cpp and
  hartstack.cpp: PASS
- MCUXpresso generated-makefile dry run: PASS

The ARM GCC/MCUXpresso toolchain and target FPGA hardware are not available in
this environment, so no .axf/.bin has been produced and hardware behavior has
not been claimed as tested.

MCUXPRESSO BUILD STEPS
----------------------
1. Import the complete Build 35 project.
2. Project -> Clean.
3. Build the Debug configuration.
4. Flash the PMIO AI HART module.
5. Keep HENABLE selected for the connected channel.
6. Allow the channel discovery cycle to complete.
7. First verify the terminal line:
       HART CHANNEL=2 MODEM=0 PV=<real value>
8. Then verify the monitoring screens.

EXPECTED MONITORING RESULT
--------------------------
HART Device Status:
- HCOMSTS: Good
- HCOMFAIL: Good or cleared
- HNCOMERR: 0 unless actual retries occurred

HART Identification:
- Manufacturer, device type, device revision and device ID are non-zero and
  match CMD0.

HART Configuration:
- Command 13 Tag/Descriptor/Date are no longer ???????? / 255.
- Command 14 units and transducer limits are no longer UNKNOWN 255 / NaN.
- Command 15 units, URV, LRV and damping are no longer UNKNOWN 255 / NaN.

IMPORTANT DEBUG VARIABLES IF DISCOVERY STILL FAILS
---------------------------------------------------
Inspect the affected channel's clsHartDevDb directly:
- m_HChanMode
- m_ucInitCmdIndex
- m_ucLastReqCmd
- m_ucLastRespCode
- m_ucRcvMsgLen
- m_ucHartVersion
- m_UniqueAddress.ucBytes[]
- HComSts / HLComFail / HCmdFail / HCmdResp
- HCmd0.ucBytes[]
- HCmd13.ucBytes[]
- HCmd14.ucBytes[]
- HCmd15.ucBytes[]

Also inspect redesign diagnostics:
- g_ucHartLastCommandByChannel[channel]
- g_ucHartLastResponseByChannel[channel]
- g_ucHartLastPayloadLengthByChannel[channel]
- g_ucHartInitIndexByChannel[channel]
- g_usHartShortResponseMask
- g_usHartCmd0GoodMask
- g_usHartCmd13GoodMask
- g_usHartCmd14GoodMask
- g_usHartCmd15GoodMask
