A5 HART FULL-SCAN OPTIMIZED VALIDATION BUILD

HART_HARDWARE_VALIDATION_BUILD=1
HART_HARDWARE_VALIDATION_CONFIRMATIONS=2
HART_EMPTY_ROUTE_RETRY_COUNT=1
HART_HARDWARE_VALIDATION_CONTINUE_LEGACY_TASK_AFTER_SCAN=1
RAW RX diagnostics disabled; final response/CMD3/route diagnostics enabled.

Hardware validation flow:
  AppMain -> BOX/SLOT construction -> CheckAndInitHart -> HartTask registration
  -> scheduler/BOX initialization -> IOL enable -> one logical channel per HartTask
  -> legacy queue/modem ownership -> RT1024 FPGA/UART transport
  -> continue after every detection through channel 16
  -> print device count/channel bitmap
  -> resume the normal legacy HartTask heartbeat/event path.

After "IOL ENABLED", verify this banner:
  HART_BUILD A5_FULL_SCAN_OPT_V1 EMPTY_RETRY=1 CMD0_CONFIRM=2 SCAN=1-16

For the supplied setup, channel 10 / modem 2 should be detected, followed by probes
for channels 11 through 16. If channel 10 is the only device, the final summary is:
  HART_SCAN_COMPLETE DEVICES=1 CHANNEL_MASK=0200 SPI_ERRORS=0

No A5 banner means an older binary/project configuration was flashed.
See A5_HART_FIX_REPORT.md for the root cause and exact changes.
