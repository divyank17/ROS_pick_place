################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../board/board.c \
../board/clock_config.c \
../board/peripherals.c \
../board/pin_mux.c 

C_DEPS += \
./board/board.d \
./board/clock_config.d \
./board/peripherals.d \
./board/pin_mux.d 

OBJS += \
./board/board.o \
./board/clock_config.o \
./board/peripherals.o \
./board/pin_mux.o 


# Each subdirectory must supply rules for building sources it contributes
board/%.o: ../board/%.c board/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\board" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source\hal" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\source" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\drivers" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\debug_console_lite" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities\str" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\uart" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\component\gpio" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\utilities" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\CMSIS\m-profile" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\xip" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\PMIO_HART_B2\pmio_ai_rt1024-HLAI_Integration\pmio_common_kernel\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-board

clean-board:
	-$(RM) ./board/board.d ./board/board.o ./board/clock_config.d ./board/clock_config.o ./board/peripherals.d ./board/peripherals.o ./board/pin_mux.d ./board/pin_mux.o

.PHONY: clean-board

