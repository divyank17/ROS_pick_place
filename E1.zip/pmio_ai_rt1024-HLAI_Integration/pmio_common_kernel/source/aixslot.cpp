/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aixslot.cpp                                                 *
*    Description : AIH Analog Input channel slot implementation.               *
*                  Provides per-channel ADC scan, calibration application,     *
*                  and parameter read/write for C300 controller access.        *
*******************************************************************************/
#include "aixslot.hpp"
#include "boxslot.hpp"
#if defined(IOMTYPE_AIH)
    #include "aihslot.hpp"
    #include "aihboxslot.hpp"
#elif defined (IOMTYPE_LLMUX)
    #include "llmuxboxslot.hpp"
#endif
//#include "hal_adc.h"

/*******************************************************************************
*                       clsAixSlot::clsAixSlot                                 *
*                       ======================                                 *
* PURPOSE:                                                                     *
*    Constructor — initialise channel slot to safe defaults.                   *
* ARGUMENTS:                                                                   *
*    a_ucChannelNum : 1-based channel number for this slot.                    *
* RETURN:                                                                      *
*    None (constructor).                                                       *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
clsAixSlot::clsAixSlot(UINT8 a_ucChannelNum) : clsInSlot(PNTTYPE_NOTCONFIGURED, a_ucChannelNum) {

	InitAixSlot(TRUE,TRUE);
}
/*******************************************************************************
*                              clsAixSlot::PrePvTv                             *
*                              ===================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvTv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
{
    FLOAT32 NewVal = *(FLOAT32 *)a_Writebuffer;

    if (! RealCompare(NewVal,PvTv)) {

#if 1//defined(IOPTYPE_HLAI)
        if (PNTFORM_FULL != PntForm)
            return DO_PARAMETER_INVALID;
#endif
        if (isnan(PvExEUHi) || isnan(PvExEULo))
            return DO_CONFIGURATION_MISMATCH_ERROR;
        if (!isnan(NewVal)) {
            if (a_ucAccLvl & ALCK_ONPROC_PBD) { //OPER or SUPR or ENGR or PBD
                if ((NewVal > PvExEUHi) || (NewVal < PvExEULo))
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
            }
            else { //PROG or CC or UMCC or IUSER
                if (NewVal < PvExEULo) {
                    *(FLOAT32 *)a_Writebuffer = PvExEULo;
                    return DO_VALUE_CLAMPED_ERROR;
                }
                if (NewVal > PvExEUHi) {
                    *(FLOAT32 *)a_Writebuffer = PvExEUHi;
                    return DO_VALUE_CLAMPED_ERROR;
                }
            } //access level
        } //PvTv is NaN
    }

    return PA_OK;
}
/*******************************************************************************
*                              clsAixSlot::PostPvTv                            *
*                              ====================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvTv(UINT8)
{
    //Force result of any floating point operation to QNaN, if any of the
    //operands is NaN. Otherwise it will result in SNaN.
    if (isnan(PvTv) || isnan(PvEULo) || isnan(EUSpan)) PvTvP = NaN;
    else PvTvP = (PvTv - PvEULo) * HundredDivEUSpan;
}

/*******************************************************************************
*                             clsAixSlot::GetPvPtr                             *
*                             ====================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAixSlot::GetPvPtr(VOID) {
#ifdef IOMTYPE_UIO
    return &(BOX->PvScanRec.ScanRec[ChanNum - 1].AIH.Pv);
#else
    return &(BOX->PvScanRec[ChanNum - 1].Pv);
#endif
}

/*******************************************************************************
*                            clsAixSlot::GetPvStsPtr                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAixSlot::GetPvStsPtr(VOID) {
#ifdef IOMTYPE_UIO
    return &(BOX->PvScanRec.ScanRec[ChanNum - 1].AIH.PvSts);
#else
    return &(BOX->PvScanRec[ChanNum - 1].PvSts);
#endif
}

/*******************************************************************************
*                          clsAixSlot::PrePvEUHi                               *
*                          =====================                               *
* PURPOSE:  Pre Receiver-Beware function for PvEUHi parameter.                 *
*           This method checks for range of the data that can be written to    *
*           PvEUHi parameter, access level check, module status check, point   *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvEUHi(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvEUHi)) {
        if (isnan(NewVal))
            return DO_ILLEGAL_VALUE;

        if (!isnan(PvEULo)){
            if (NewVal < PvEULo)
                return DO_LIMIT_OR_RANGE_CROSSOVER;

            if (NewVal < (PvEULo + (FLOAT32) 0.001))
                return DO_ENGR_UNIT_SPAN_TOO_SMALL;
        }

        if ((!isnan(PvExEUHi)) && (NewVal > PvExEUHi))
            return DO_LIMIT_OR_RANGE_CROSSOVER;

        if ((!isnan(LoCutOff)) && (NewVal < LoCutOff))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
    }
    return PA_OK;
}
/*******************************************************************************
*                          clsAixSlot::PrePvEULo                               *
*                          =====================                               *
* PURPOSE:  Pre Receiver-Beware function for PvEULo parameter.                 *
*           This method checks for range of the data that can be written to    *
*           PvEULo parameter, access level check, module status check, point   *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvEULo(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if ( !RealCompare(NewVal, PvEULo) ) {
        if (isnan(NewVal))
            return DO_ILLEGAL_VALUE;

        if ( !isnan(PvEUHi) ) {
            if (NewVal > PvEUHi)
                return DO_LIMIT_OR_RANGE_CROSSOVER;

            if (NewVal > (PvEUHi - (FLOAT32)0.001))
                return DO_ENGR_UNIT_SPAN_TOO_SMALL;
        }

        if ( (!isnan(PvExEULo)) && (NewVal < PvExEULo) )
            return DO_LIMIT_OR_RANGE_CROSSOVER;

        if ( (!isnan(LoCutOff)) && (NewVal > LoCutOff) )
            return DO_LIMIT_OR_RANGE_CROSSOVER;
    }
    return PA_OK;
}

/*******************************************************************************
*                          clsAixSlot::PrePvSource                             *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvSource parameter.              *
*            Validates some pre conditions before the new PvSource value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvSource(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PVSOURCE NewVal = *(PVSOURCE *) a_Writebuffer;

    if ((a_ucAccLvl != ALVL_IUSER) || (NewVal != PvSource)) {

#if 1//defined(IOPTYPE_HLAI)
        if (PNTFORM_FULL != PntForm)
            return DO_PARAMETER_INVALID;
#endif
        if (PVSRCOPT_ONLYAUTO == PvSrcOpt)
            return DO_PARAMETER_INVALID;
    }
    return PA_OK;
}
/*******************************************************************************
*                          clsAixSlot::PreTf                                   *
*                          =====================                               *
* PURPOSE:  Pre Receiver-Beware function for Tf parameter.                     *
*           This method checks for range of the data that can be written to    *
*           Tf parameter.                                                      *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PreTf(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*) a_Writebuffer;

    if ((NewVal < 0.0) || (NewVal > (FLOAT32)SECONDS_IN_MINUTE)) {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    if (isnan(NewVal) || (NewVal < (FLOAT32) 0.00001)) {
        *(FLOAT32*) a_Writebuffer = (FLOAT32) 0.0;
    }

    return PA_OK;
}

/*******************************************************************************
*                            clsAixSlot::PostPvSource                          *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvSource parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvSource(UINT8) {
    UINT8 ucModSts = BOX->GetModuleStatus();

    if (PvSource != PVSOURCE_MANUAL) {
        if ((PTEXECST_INACTIVE == PtExecSt) || (MODSTATUS_IDLE == ucModSts)) {
            BOX->SetPv(ChanNum,NaN);
            BOX->SetPvSts(ChanNum,PVVALST_BAD);
            PvP       = NaN;
            PvExHiFl  = FALSE;
            PvExLoFl  = FALSE;
#if 1//defined(IOPTYPE_HLAI)
            AlmVar.fPv4secOld = NaN;
#endif
        }
        else if (PVSOURCE_SUB == PvSource) {
            if ((PVVALST_NORMAL == BOX->GetPvSts(ChanNum)) ||
                (PVVALST_MANUAL == BOX->GetPvSts(ChanNum))) {
                BOX->SetPvSts(ChanNum,PVVALST_UNCERTN);
            }
        }
    }
    else if (PVVALST_BAD != BOX->GetPvSts(ChanNum)) {
        BOX->SetPvSts(ChanNum,PVVALST_MANUAL);
    }
}


/*******************************************************************************
*                          clsAihSlot::PrePvTemp                               *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvTemp parameter.                *
*            Validates some pre conditions before the new PvTemp value can     *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihSlot::PrePvTemp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {

#if 1//defined(IOPTYPE_HLAI)
    // for PMIO Redesign HLAI
    PVTEMP NewVal = *(PVTEMP *)a_Writebuffer;

    // Check if calibration is enabled.
    if (BOX->GetCalibAllState())
    {
        return DO_CALIB_IN_PROGRESS;
    }
    // if not checkpoint configuartion or new != old value
    else if ((a_ucAccLvl != ALVL_IUSER) || (NewVal != PvTemp))
    {
        // for all types of thermocouple & RTD
        if (PvChar < PVCHAR_LINEAR)
        return PA_OK;
    }
    /*else if (a_ucAccLvl != ALVL_PBD)
    {
        return DO_READ_ONLY_PARAMETER;
    }*/
#endif

    //since this parameter is not applicable to LINEAR and SQRROOT PvChar,
    //it is not applicable to HLAI VIOPs.
    if (a_ucAccLvl == ALVL_IUSER)
        return PA_OK;

    return DO_PARAMETER_INVALID;
}



#if 1//defined(IOPTYPE_HLAI)
/*******************************************************************************
*                          clsAihSlot::PrePvAlDb                               *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvAlDb parameter.                *
*            Validates some pre conditions before the new PvAlDb value can     *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvAlDb parameter           *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvAlDb(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
{
    if ((ALVL_IUSER != a_ucAccLvl) || (*(PVALDB *)a_Writebuffer != PvAlDb))
    {
        if (PNTFORM_FULL != PntForm)
            return DO_PARAMETER_INVALID;
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostPvAlDb                            *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvAlDb parameter.                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvAlDb(UINT8)
{
    FLOAT32 fValue;

    fValue = ((PvAlDb == PVALDB_EU)   ? 1.0 : \
              (PvAlDb == PVALDB_HALF) ? 5.0 : (FLOAT32)PvAlDb * 10.0);

    //if (PVALDB_EU != PvAlDb)
    if (!isnan(EUSpan))
    {
        PvAlDbEu = ((fValue * EUSpan) / 1000.0);
        //*(FLOAT32 *)GetPvAlDbEuPtr() = ((fValue * EUSpan) / 1000.0);

#if 1
        // In PMIO redesign, checkpoint param should be stored in the battery backup sram
        //UINT8 u8Index = IsCheckPointParam(PARAMID_PVALDBEU);
        //UINT8 *pDest = GetParamPtr(PARAMID_PVALDBEU);

        //xRamWrite((xRAM_CHKPNT_ADRS + (xRAM_CHKPNT_BLOCK*ChanNum) + (u8Index - 1)), pDest, GetParamSize(PARAMID_PVALDBEU));
#endif
    }
}
/*******************************************************************************
*                          clsAihSlot::PrePvAlDbEu                             *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvAlDbEu parameter.              *
*            Validates some pre conditions before the new PvAlDbEu value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvAlDbEu parameter         *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvAlDbEu(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
{
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvAlDbEu)) {

        if (!((ALVL_ENGR | ALVL_PBD | ALVL_IUSER) & a_ucAccLvl))
        {
            return DO_ACCESS_LEVEL_INVALID;
        }
        else if ((PNTFORM_FULL != PntForm) || (PVALDB_EU != PvAlDb))
        {
            return DO_PARAMETER_INVALID;
        }
        else if (isnan(NewVal))
        {
            return DO_ILLEGAL_VALUE;
        }
        else if ((NewVal < (FLOAT32)0.0) || (NewVal > EUSpan))
        {
            return DO_LIMIT_OR_RANGE_EXCEEDED;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAixSlot::PrePvHhTp                             *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvHhTp parameter.                *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvHhTp(UINT8 *a_Writebuffer, UINT8)
{
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvHhTp)) {

        if (PNTFORM_FULL != PntForm)
        {
            return DO_PARAMETER_INVALID;
        }
        else if (isnan(PvExEUHi))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if (!isnan(NewVal) && isnan(PvHiTp))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if ((NewVal < PvHiTp) || (NewVal > PvExEUHi))
        {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostPvHhTp                            *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvHhTp parameter.                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvHhTp(UINT8)
{
    if (isnan(PvHhTp))
    {
        AlmInfo.Bit.ucPvHhFl = FALSE;
        // need to check for the update PVSTALM (PvScanRec)
    }
}
/*******************************************************************************
*                            clsAixSlot::PrePvHiTp                             *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvHiTp parameter.                *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvHiTp(UINT8 *a_Writebuffer, UINT8)
{
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvHiTp)) {

        if (PNTFORM_FULL != PntForm)
        {
            return DO_PARAMETER_INVALID;
        }
        else if (isnan(PvExEUHi) || isnan(PvExEULo))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if (isnan(NewVal))
        {
            if (!isnan(PvHhTp))
                return DO_CONFIGURATION_MISMATCH_ERROR;
            else
                return PA_OK;
        }
        else if ((NewVal < PvExEULo) || (NewVal < PvLoTp))
        {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
        else if ((!isnan(PvHhTp) && (NewVal > PvHhTp)) || (NewVal > PvExEUHi))
        {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostPvHiTp                            *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvHiTp parameter.                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvHiTp(UINT8)
{
    if (isnan(PvHiTp))
    {
        AlmInfo.Bit.ucPvHhFl = FALSE;
        AlmInfo.Bit.ucPvHiFl = FALSE;
        // need to check for the update PVSTALM (PvScanRec)
    }
}
/*******************************************************************************
*                            clsAixSlot::PrePvLlTp                             *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvLlTp parameter.                *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvLlTp(UINT8 *a_Writebuffer, UINT8)
{
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvLlTp)) {

        if (PNTFORM_FULL != PntForm)
        {
            return DO_PARAMETER_INVALID;
        }
        else if (isnan(PvExEULo))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if (!isnan(NewVal) && isnan(PvLoTp))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if ((NewVal > PvLoTp) || (NewVal < PvExEULo))
        {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostPvLlTp                            *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvLlTp parameter.                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvLlTp(UINT8)
{
    if (isnan(PvLlTp))
    {
        AlmInfo.Bit.ucPvLlFl = FALSE;
        // need to check for the update PVSTALM (PvScanRec)
    }
}
/*******************************************************************************
*                            clsAixSlot::PrePvLoTp                             *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvLoTp parameter.                *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvLoTp(UINT8 *a_Writebuffer, UINT8)
{
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvLoTp)) {

        if (PNTFORM_FULL != PntForm)
        {
            return DO_PARAMETER_INVALID;
        }
        else if (isnan(PvExEUHi) || isnan(PvExEULo))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if (isnan(NewVal))
        {
            if (!isnan(PvLlTp))
                return DO_CONFIGURATION_MISMATCH_ERROR;
            else
                return PA_OK;
        }
        else if ((!isnan(PvHiTp) && (NewVal > PvHiTp)) || (NewVal > PvExEUHi))
        {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
        else if ((!isnan(PvLlTp) && (NewVal < PvLlTp)) || (NewVal < PvExEULo))
        {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostPvLoTp                            *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvLoTp parameter.                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvLoTp(UINT8)
{
    if (isnan(PvLoTp))
    {
        AlmInfo.Bit.ucPvLoFl = FALSE;
        AlmInfo.Bit.ucPvLlFl = FALSE;
        // need to check for the update PVSTALM (PvScanRec)
    }
}
/*******************************************************************************
*                            clsAixSlot::PrePvRocNTp                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvRocNTp parameter.              *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvRocNTp(UINT8 *a_Writebuffer, UINT8)
{
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvRocNTp)) {

        if (PNTFORM_FULL != PntForm)
        {
            return DO_PARAMETER_INVALID;
        }
        else if (isnan(PvExEUHi) || isnan(PvExEULo))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if (!isnan(NewVal))
        {
            // The max rate of change allowable is a step from PVEXEULO to PVEXEUHI
            // in 8 seconds. {2 * ROC SAMPLE PERIOD(4 sec) }
            // Thus, Max = ABS(PVEXEUHI - PVEXEULO)*7.5 units / minute { 7.5 = 60 / 8 }

            if ((NewVal > fabs(PvExEUHi - PvExEULo)*7.5) || (NewVal < 0.0))
                return DO_LIMIT_OR_RANGE_EXCEEDED;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostPvRocNTp                          *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvRocNTp parameter.              *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvRocNTp(UINT8)
{
    if (isnan(PvRocNTp))
        AlmInfo.Bit.ucPvRocNFl = FALSE;
}
/*******************************************************************************
*                            clsAixSlot::PrePvRocPTp                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvRocPTp parameter.              *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAixSlot::PrePvRocPTp(UINT8 *a_Writebuffer, UINT8)
{
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvRocPTp)) {

        if (PNTFORM_FULL != PntForm)
        {
            return DO_PARAMETER_INVALID;
        }
        else if (isnan(PvExEUHi) || isnan(PvExEULo))
        {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        else if (!isnan(NewVal))
        {
            // The max rate of change allowable is a step from PVEXEULO to PVEXEUHI
            // in 8 seconds. {2 * ROC SAMPLE PERIOD(4 sec) }
            // Thus, Max = ABS(PVEXEUHI - PVEXEULO)*7.5 units / minute { 7.5 = 60 / 8 }

            if ((NewVal > fabs(PvExEUHi - PvExEULo)*7.5) || (NewVal < 0.0))
                return DO_LIMIT_OR_RANGE_EXCEEDED;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PostPvRocPTp                          *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvRocPTp parameter.              *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAixSlot::PostPvRocPTp(UINT8)
{
    if (isnan(PvRocPTp))
        AlmInfo.Bit.ucPvRocPFl = FALSE;
}

#endif


/*******************************************************************************
*                           clsAixSlot::InitAixSlot                            *
*                           =======================                            *
* PURPOSE:   Initialization function for clsAixSlot data members.              *
* ARGUMENTS: bFullInit   - Flag utilised when slots have to be reinitialized   *
*            bObjCreate  - Flag utilised when slots have to be reinitialized   *
* RETURN:    NONE                                                              *
* NOTES:     This function is called when slot parameters                      *
*            need to be reinitialized                                          *
*******************************************************************************/
VOID clsAixSlot::InitAixSlot(BOOL bFullInit, BOOL) {

    PvRaw     = NaN;
    PvCalc    = NaN;
    FiltOut   = NaN;
    PvAuto    = NaN;
    PvAutoSt  = PVVALST_BAD;
    LastPv    = NaN;

    PvEUHi    = NaN;
    PvEULo    = NaN;
    PvExEUHi  = NaN;
    PvExEULo  = NaN;
    PvClamp   = PVCLAMP_NOCLAMP;
    LoCutOff  = NaN;
    Tf        = (FLOAT32) 0.0;
    Kf        = (FLOAT32) 1.0;
    PvTv      = NaN;
    PvTvP     = NaN;

    EUSpan    = NaN;
    EUSpanDivHundred = NaN;
    HundredDivEUSpan = NaN;

    AlmInfo.ucByte  = 0x00;
    AlarmLrs.ucByte = 0x00;

#if 0
    AlmVar.fPv4secOld  = NaN;
    AlmVar.uiTsCounter = 0;
    AlmVar.bPFirstInc  = FALSE;
    AlmVar.bNFirstInc  = FALSE;
    AlmVar.bPFirstDec  = FALSE;
    AlmVar.bNFirstDec  = FALSE;

    HighAl = NOALARM;
    PtInAl = OFF;
#endif

    PvHhTp   = NaN;
    PvHiTp   = NaN;
    PvLlTp   = NaN;
    PvLoTp   = NaN;
    PvRocNTp = NaN;
    PvRocPTp = NaN;

    SlwSrcId = 1;
    PvAlDbEu = NaN;
    RawSpan  = NaN;
    PvAlDb   = PVALDB_ONE;
    PvFormat = PVFORMAT_D1;

    if (bFullInit) {
        PvP      = NaN;
        BadPvFl  = TRUE;
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;

        BOX->SetPv(ChanNum,NaN);
        BOX->SetPvSts(ChanNum,PVVALST_BAD);
    }
}

