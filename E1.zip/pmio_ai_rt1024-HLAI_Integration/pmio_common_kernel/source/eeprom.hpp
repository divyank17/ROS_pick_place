/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : eeprom.hpp                                                  *
*    Description : Class clsEeprom declaration.                                *
*******************************************************************************/

#ifndef __EEPROM_HPP__
#define __EEPROM_HPP__

#include "datatype.h"

// Offsets in the SPI EEPROM for the calibration and HWINFO.
#if (HEK) || (LOWCOST)

	#define ADDRESS_RANGE_END           (0x00FFFFFF)
	#define EEPROM_ADDR_RANGE_START     (0x00000)
	#define EEPROM_ADDR_RANGE_END       (0x001FF)
	#define EEPROM_CHKSM_ADDR_END       (0x001FE)
	#define MAX_EEPROM_SIZE             512
	#define EEPROM_PAGE_SIZE            16
	#define EEPROM_LOW_PAGE             256

    const UINT8 EE_VENDOR_ID            	  = 0;
    const UINT8 EE_PRODUCT_TYPE         	  = 2;
    const UINT8 EE_PRODUCT_CODE         	  = 4;
    const UINT8 EE_SERIAL_NUMBER        	  = 6;
    const UINT8 EE_HARDWARE_REVCODE     	  = 10;
    const UINT8 EE_HARDWARE_REVNUMBER         = 11;
    const UINT8 EE_CALIBRATION_MARK     	  = 15;
    const UINT8 EE_CALIBRATION_5VREF_HILIMIT  = 16;
    const UINT8 EE_CALIBRATION_5VREF_LOLIMIT  = 20;
    const UINT8 EE_CALIBRATION_SLOPE          = 24;
    const UINT8 EE_CALIBRATION_OFFSET         = 28;
    const UINT8 EE_CHANNEL_ZERODRIFT_PTR      = 32;   // AIH
    const UINT16 EE_MODULEINFO_WRITECOUNT     = 506;
    const UINT16 EE_MODULEINFO_WRITE_FLAGS    = 508;
    const UINT16 EE_MODULEINFO_CHKSUM         = 510;

	//const UINT16 EEPROM_MAXWRCOUNT    = 10000;
	const UINT8 SS_EEPROM   			= 0xFD;
	const UINT8 SPI_EEPROM_WIP    	    = 0x01;
    //const UINT8 CALIBRATION_DONE      = 0xA5;

	const UINT8 EEPROM_WREN   = 0x06;
	const UINT8 EEPROM_WRDI   = 0x04;
	const UINT8 EEPROM_RDSR   = 0x05;
	const UINT8 EEPROM_WRSR   = 0x01;
	const UINT8 EEPROM_RDLO   = 0x03;
	const UINT8 EEPROM_RDHI   = 0x0B;
	const UINT8 EEPROM_WRLO   = 0x02;
	const UINT8 EEPROM_WRHI   = 0x0A;

	// This is status register value for EEPROM. Bit0-1 should always be 0,
	// Bit2-3 should always 0 and bit4-7 should be always 1. We do not write
	// protect EEPROM so it should always read bit2-3 as 0's.
	const UINT8 EEPROM_PRESENT  = 0xF0;
	const UINT8 EEPROM_STSMASK  = 0xFC;
	//const UINT8 EEPROM_SELECT   = 0xFD;
	//const UINT8 EEPROM_DESELECT = 0x02;


/*******************************************************************************
*                                  clsEeprom                                   *
*                                  =========                                   *
*******************************************************************************/
class clsEeprom; // forward declaration
class clsEeprom {
public:

    clsEeprom(VOID);
    ~clsEeprom(VOID) { HardFail(HF_INVPROGRAMEXEC, BOXSLOT_HPP,__LINE__); }

    //VOID *operator new (SIZE_T)  { return NULL; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,BOXSLOT_HPP,__LINE__); }

    VOID    EnableWrite(VOID);
    VOID    DisableWrite(VOID);
    UINT8   ReadStatusRegister(VOID);
    VOID    CheckWriteInProgress(VOID);

    UINT8   ReadByte(UINT16);
    UINT16  ReadUint16(UINT16);
    UINT32  ReadUint32(UINT16);
    FLOAT32 ReadFloat(UINT16);
    VOID    WriteByte(UINT16,UINT8);
    VOID    WriteData(UINT16, UINT8 *, UINT16);

    UINT16  ComputeEepromChecksum(VOID);
    BOOL    ValidateEepromChecksum(VOID);

#if LOWCOST
    BOOL    SendCommand(UINT8 ucCmd);   // Send an Instruction
    UINT8   ReadResponse(VOID);         // Read Serial Data
    inline  VOID ChipSelect(VOID){EEP_CS = 0;}
    inline  VOID ChipDeselect(VOID){EEP_CS = 1;}
#endif

};  // clsEeprom
#endif //#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))

extern clsEeprom Eeprom;

#endif /* __EEPROM_HPP__ */
