/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hart.cpp                                                    *
*    Description : HART global data and functions.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/

#include "scheduler.hpp"
#include "hart.h"
#include "hartdb.hpp"
#include "hartstack.hpp"
#include "fsl_debug_console.h"
#if defined(IOMTYPE_AIH)
#include "aihmain.h"
#endif
#include <string.h>

    // When the compiler first enters hart.cpp UIO_HART_GLOBAL and UIO_HART_SLOTS are not defined.
    // On first pass through hart.cpp define UIO_HART_GLOBAL to process Global Variables and Functions.
    // These are encapsulated by #ifndef UIO_HART_SLOTS and the comments "Start/End Global Variables and Functions".

    // On second pass through hart.cpp change the context by defining UIO_HART_SLOTS, IOMTYPE_AIH, and redefining 
    // SLOT(n) to AIH_SLOT(n). This will process all slot data members and functions conditionally compiled based 
    // on the IOM type. UIO_HART_SLOTS will direct the compiler to skip the Global Functions/Variables and process
    // just the functions encapsulated by #ifndef UIO_HART_GLOBAL and the comments "Start/End Slot Variables and Functions"
    // in the context of the AIH module.

    // On the third and final pass through hart.cpp UIO_HART_SLOTS and IOMTYPE_AIH are defined. Undefine IOMTYPE_AIH,
    // define IOMTYPE_AOH and redefine SLOT(n) to AOH_SLOT(n). This will again skip the Global Functions/Variables and process
    // just the functions encapsulated by #ifndef UIO_HART_GLOBAL and the comments "Start/End Slot Variables and Functions"
    // in the context of the AOH module.

#ifndef HART_SCAN_CHANNEL_START
#define HART_SCAN_CHANNEL_START                 (1u)
#endif

#ifndef HART_SCAN_CHANNEL_END
#define HART_SCAN_CHANNEL_END                   (16u)
#endif

#ifndef HART_TEST_CHANNEL
#define HART_TEST_CHANNEL                       HART_SCAN_CHANNEL_START
#endif

#ifndef HART_TEST_MODEM
#define HART_TEST_MODEM                         ((UINT8)((HART_TEST_CHANNEL - 1u) / 4u))
#endif

#ifndef HART_POLL_ADDR_START
#define HART_POLL_ADDR_START                    (0u)
#endif

// UIO will compile this file with IOMTYPE_AIH and IOMTYPE_AOH defined.
// Intentionally preventing aihmain.h and aohmain.h from being included in those contexts.
#ifndef HART_POLL_ADDR_END
#define HART_POLL_ADDR_END                      (0u)
#endif


#ifndef HART_ENABLE_WRITE_COMMAND_CHECKS
#define HART_ENABLE_WRITE_COMMAND_CHECKS         (0u)
#endif

#ifndef HART_RUN_INIT_COMMAND_TABLE_AFTER_PV
#define HART_RUN_INIT_COMMAND_TABLE_AFTER_PV     (0u)
#endif


#ifndef HART_ENABLE_FINAL_RESPONSE_PRINT
#define HART_ENABLE_FINAL_RESPONSE_PRINT         (0u)
#endif

/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
// Memory for HART channels receive buffers

#ifndef HART_MAXSLOTS
#define HART_MAXSLOTS 16u
#endif

UINT8  g_ucHChanRcvBuffer[HART_CHANBUFFER_SIZE * HART_MAXSLOTS];
UINT8 *g_pucHChanRcvBuffer = g_ucHChanRcvBuffer;
UINT8  g_ucHPstReqBuffer[HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];
clsHartPst *pHartPst[HPST_OBJECTCOUNT];
UINT16 g_usHPstObjMemory[CLSHARTPST_SIZE * HPST_OBJECTCOUNT];
UINT16 g_usModemObjectMemory[HARTMODEM_COUNT * CLSHARTMODEM_SIZE];
UINT16 g_usHartQueueObjectMemory[HARTMODEM_COUNT * CLSHARTQUEUE_SIZE];

static UINT8 g_runtimeLongAddr[HART_LONGADDR_LENGTH] = {0u, 0u, 0u, 0u, 0u};
static UINT8 g_runtimePollAddr = 0u;
static bool  g_haveLongAddr = false;

static UINT8 g_activeChannel = (UINT8)HART_TEST_CHANNEL;
static UINT8 g_activeModem = (UINT8)HART_TEST_MODEM;
static UINT8 g_lastGoodChannel = 0u;
static UINT8 g_lastGoodModem = 0u;
static BOOL  g_haveLastGoodRoute = FALSE;
static HARTDISCOVERYRESULT g_lastTransactionResult = HART_DISCOVERY_FAILED;



/*******************************************************************************
*                               isHartCapable                                  *
*                               =============                                  *
* PURPOSE: Determine if the HW is HART capable                                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Called by aihmain and aohmain. Meaningless if it is called by di/do   *
*        If MUXADDR (0x80010) is Read Only, the module is Hartless             *
*******************************************************************************/
BOOL isHartCapable(VOID)
{
    return TRUE;
}

/*******************************************************************************
*                               CheckAndInitHart                               *
*                               ================                               *
* PURPOSE:      Initialize HART registers for HART modules                     *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is HART            *
*******************************************************************************/
VOID CheckAndInitHart(VOID){
    static BOOL bHartObjectsCreated = FALSE;

    HartInit();
    ResetHart();

    if (FALSE == bHartObjectsCreated)
    {
        for (UINT8 index = 0u; index < HPST_OBJECTCOUNT; index++)
        {
            pHartPst[index] = new(index) clsHartPst();
        }
        bHartObjectsCreated = TRUE;
    }

    clsHartDevDb *db = HartDb_GetHartDevDb();
    if (db != NULL)
    {
        db->BuildScanTable();
        db->m_sScanCounter = TICKS_IN_1_SEC;
    }

/* Integration note: the standalone J3 build initializes HART first and runs
     * the physical scan as a separate main-level step.  Do not run the blocking
     * FPGA/UART scan inside this database/object initialization function. */
}




/*******************************************************************************
*                         HartRunHardwareValidation                            *
*                         ==========================                            *
* PURPOSE: Run the same one-shot physical channel scan used by the standalone *
*          J3 RT1024 HART project, after BOX/SLOT/HART objects exist.           *
* NOTES:   Test build only. The clean integration build disables this macro.   *
*******************************************************************************/
VOID HartRunHardwareValidation(VOID)
{
    /* A4 integration fix: retained for source/API compatibility.  The actual
     * validation is staged from HartTask so one route is tested per scheduler
     * invocation after BOX and IO-Link startup. */
}

/*******************************************************************************
*                               ResetHart                                      *
*                               =========                                      *
* PURPOSE:      Reset Hart UARTS                                               *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is Hartless        *
*******************************************************************************/
VOID ResetHart(VOID)
{
    HartStack_Reset();
}


/******************************************************************************
*                               TestHartAddressMux                            *
*                               ==================                            *
* PURPOSE:                                                                    *
*   Write to the H_MA register and readback what was written to verify that   *
*   the HART address multiplexer is working.                                  *
* ARGUMENTS:                                                                  *
*   NONE                                                                      *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   This diagnostic should only be run on the secondary.  The primary         *
*   performs a similar diagnostic when HART communication is initiated for    *
*   a channel.                                                                *
******************************************************************************/
VOID TestHartAddressMux(VOID)
{
    static UINT8 sucHartAddressMuxCurrentSlot = 1u;
    UINT8 modem = HartGetModemForChannel(sucHartAddressMuxCurrentSlot);
    UINT16 muxMask = (UINT16)(0x000Fu << (modem * 4u));
    UINT16 expectedAddr = (UINT16)((UINT16)((sucHartAddressMuxCurrentSlot - 1u) & 0x0Fu) << (modem * 4u));
    UINT8 expectedEnable = (UINT8)(1u << modem);

    /* A3 channel-14 hardware check fix: match s1 legacy MUX readback test. */
    hal_fpga_hart_mux_set16((UINT16)((HART_DEFAULT_MAR_CH1_M0 & (UINT16)(~muxMask)) | expectedAddr));
    hal_fpga_hart_mux_enable(expectedEnable);

    UINT16 readAddr = hal_fpga_hart_mux_get_addr16();
    UINT8 readEnable = hal_fpga_hart_mux_get_enable();

    if (((readAddr & muxMask) != expectedAddr) || ((readEnable & expectedEnable) == 0u))
    {
        if ((modem < HARTMODEM_COUNT) && (pHartModem[modem] != NULL))
        {
            // Read back failed...
            pHartModem[modem]->SetModemBad();
        }
    }

    sucHartAddressMuxCurrentSlot++;
    if (sucHartAddressMuxCurrentSlot > 16u)
    {
        sucHartAddressMuxCurrentSlot = 1u;
    }
}


#if HART_ENABLE_LEGACY_TASK_API
/*******************************************************************************
*                                    HartTask                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN HartTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    static UINT8 sucHChanToProcess = 1u;
#if HART_HARDWARE_TEST_DELAYED_SCAN
    static BOOL sucHartHardwareTestScanDone = FALSE;
    static UINT8 sucHartHardwareTestDelay = (UINT8)HART_HARDWARE_TEST_DELAY_TASK_CYCLES;
#endif

    TaskScheduler.RefreshTaskDmc(TASKID_HARTTASK);

#if HART_HARDWARE_VALIDATION_BUILD
    /* A5 hardware validation: one channel per HartTask invocation.  This keeps
     * the legacy scheduler alive, avoids the previous 16-channel blocking scan,
     * and deliberately bypasses DSA=0 only for this explicit test build. */
    {
        static BOOL sbValidationStarted = FALSE;
        static BOOL sbValidationFinished = FALSE;
        static UINT8 sucValidationDelay = (UINT8)HART_HARDWARE_VALIDATION_DELAY_CYCLES;
        static UINT8 sucValidationChannel = (UINT8)HART_SCAN_CHANNEL_START;
        static UINT8 sucDetectedCount = 0u;
        static UINT16 susDetectedChannelMask = 0u;

        if (sbValidationFinished == FALSE)
        {
            if (sucValidationDelay > 0u)
            {
                sucValidationDelay--;
            }
            else
            {
                UINT8 modem;
                HARTDISCOVERYRESULT result;

                if (sbValidationStarted == FALSE)
                {
                    PRINTF("HART_BUILD A5_FULL_SCAN_OPT_V1 EMPTY_RETRY=%d CMD0_CONFIRM=%d SCAN=%d-%d\r\n",
                           (int)HART_EMPTY_ROUTE_RETRY_COUNT,
                           (int)HART_HARDWARE_VALIDATION_CONFIRMATIONS,
                           (int)HART_SCAN_CHANNEL_START,
                           (int)HART_SCAN_CHANNEL_END);
                    hal_fpga_clear_spi_error_count();
                    sbValidationStarted = TRUE;
                }

                modem = HartGetModemForChannel(sucValidationChannel);
                PRINTF("HART_PROBE CHANNEL=%d MODEM=%d POLL=0\r\n",
                       (int)sucValidationChannel, (int)modem);

                TaskScheduler.RefreshTaskDmc(TASKID_HARTTASK);
                result = HartScanChannels(sucValidationChannel, sucValidationChannel);
                TaskScheduler.RefreshTaskDmc(TASKID_HARTTASK);

                if (result == HART_DISCOVERY_COMPLETE)
                {
                    const UINT8 detectedChannel = HartGetActiveChannel();
                    const UINT8 detectedModem = HartGetActiveModem();
                    const UINT16 detectedBit = (UINT16)(1u << (detectedChannel - 1u));

                    if ((susDetectedChannelMask & detectedBit) == 0u)
                    {
                        susDetectedChannelMask |= detectedBit;
                        sucDetectedCount++;
                    }

                    PRINTF("HART_DETECTED CHANNEL=%d MODEM=%d SPI_ERRORS=%d\r\n",
                           (int)detectedChannel, (int)detectedModem,
                           (int)hal_fpga_get_spi_error_count());
                }
                else
                {
                    PRINTF("HART_NO_DEVICE CHANNEL=%d MODEM=%d SPI_ERRORS=%d\r\n",
                           (int)sucValidationChannel, (int)modem,
                           (int)hal_fpga_get_spi_error_count());
                }

                /* A5 fix: detection is a per-channel result, not an end-of-scan
                 * condition. Always advance so every logical route is checked. */
                sucValidationChannel++;
                if (sucValidationChannel > (UINT8)HART_SCAN_CHANNEL_END)
                {
                    PRINTF("HART_SCAN_COMPLETE DEVICES=%d CHANNEL_MASK=%04X SPI_ERRORS=%d\r\n",
                           (int)sucDetectedCount,
                           (unsigned int)susDetectedChannelMask,
                           (int)hal_fpga_get_spi_error_count());
                    sbValidationFinished = TRUE;
                }
            }

            TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
            TaskReturnValue.TaskContext     = a_TaskContext;
            TaskReturnValue.ucReserved      = 0u;
            TaskReturnValue.ucSuspendTime   = 0u;
            return TaskReturnValue;
        }

#if !HART_HARDWARE_VALIDATION_CONTINUE_LEGACY_TASK_AFTER_SCAN
        /* Optional validation-only mode. The integrated build defaults to
         * falling through so the normal legacy heartbeat/event path resumes. */
        TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
        TaskReturnValue.TaskContext     = a_TaskContext;
        TaskReturnValue.ucReserved      = 0u;
        TaskReturnValue.ucSuspendTime   = 0u;
        return TaskReturnValue;
#endif
    }
#endif

    if ((BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA)) {
        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
#if defined(IOMTYPE_UIO)
            if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT){
               AIH_SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
               AIH_SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
               AIH_SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
            }
            else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT){
               AOH_SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
               AOH_SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
               AOH_SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
            }
#else
            SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
#endif
        }
        
#if defined (IOMTYPE_UIO)
        // Test the HART address multiplexer for one channel everytime the
        // HART task runs (250ms) on the secondary.
        TestHartAddressMux();
#endif
    }

    //static UINT8 sucHChanToProcess = 1;
    const  UINT8 CHANNELS_PER_CYCLE = 4;

#if defined(IOMTYPE_UIO)
    // Regular HART processing is halted during factory HART testing
    if(FALSE == HartLoopBkTestInProgress)
    {
#endif
        for (UINT8 ucChan = 0; ucChan < CHANNELS_PER_CYCLE; ucChan++) 
        {
#if defined(IOMTYPE_UIO)
           UINT16 ChanToProcessOnBoard1 = sucHChanToProcess;
           UINT16 ChanToProcessOnBoard2 = sucHChanToProcess + SLOTSPERMODEM;
    
           // Process a channel on IoBoard1
           if(BOX->GetInitPntType(ChanToProcessOnBoard1) == PNTTYPE_ANALOGINPUT){
              AIH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ChannelHeartbeat();
              AIH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
           else if(BOX->GetInitPntType(ChanToProcessOnBoard1) == PNTTYPE_ANALOGOUTPUT){
              AOH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ChannelHeartbeat();
              AOH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
    
           // Process a channel on IoBoard2
           if(BOX->GetInitPntType(ChanToProcessOnBoard2) == PNTTYPE_ANALOGINPUT){
              AIH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ChannelHeartbeat();
              AIH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
           else if(BOX->GetInitPntType(ChanToProcessOnBoard2) == PNTTYPE_ANALOGOUTPUT){
              AOH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ChannelHeartbeat();
              AOH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
    
           sucHChanToProcess++;
    
#else
            SLOT(sucHChanToProcess)->GetHartDevDb().ChannelHeartbeat();
            SLOT(sucHChanToProcess++)->GetHartDevDb().ProcessHartEvents(FALSE);
#endif
        }
    
#if defined(IOMTYPE_UIO)
        // One channel on each board is processed every pass through HartTask().
        // After all the slots per modem are processed:
        //   1) Reset channel to process counter
        //   2) Compute Hart load HCUAVAIL at this time for each modem.
        //   3) For both modems, check if modem is idle, there are no requests from any channels, 
        //      module is primary and HartStack is currently is not processing FDM queue.  If all
        //      cases are true, set up pass through requests.
        if (sucHChanToProcess > SLOTSPERMODEM) {
            sucHChanToProcess = 1;
    
            for (int modem = 0; modem < HARTMODEM_COUNT; modem++) {
                // Update HCuAvail
                FLOAT32 fTotalHartLoad = 100.0;
    
                for (UINT8 ucChan = ((modem*SLOTSPERMODEM)+1); ucChan <= ((modem+1)*SLOTSPERMODEM); ucChan++) {
                    if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT) {
                        fTotalHartLoad -= AIH_SLOT(ucChan)->GetHartDevDb().GetHartLoading();
                    }
                    else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT) {
                        fTotalHartLoad -= AOH_SLOT(ucChan)->GetHartDevDb().GetHartLoading();
                    }
                }
                BOX->SetHCuAvail(fTotalHartLoad, modem);
            
                if ((TRUE == pHartQueue[modem]->IsModemQueueEmpty()) && 
                    (HMODEMSTATE_IDLE == pHartModem[modem]->GetModemState()) && 
                    (FALSE == pHartModem[modem]->IsHartStackProc()) &&
                    (!(BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA))) {
                    // Check for number of PST's available in PST queue
                    // If FDM sessions are present
                    if(BOX->PassthroughInQueue(modem) != FALSE) {
                        // Set up passthrough
                        BOX->SearchForPassthrough(modem);
                    }
                }
            }
        }
#else
        if (sucHChanToProcess > MAXSLOTS) {
            sucHChanToProcess = 1;
            
            // Update HCuAvail
            FLOAT32 fTotalHartLoad = 100.0;
            for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) { 
                fTotalHartLoad -= SLOT(ucChan)->GetHartDevDb().GetHartLoading();
            }
            BOX->SetHCuAvail(fTotalHartLoad);
        }
#endif

#if defined(IOMTYPE_UIO)
    }
    else
    {
       sucHChanToProcess = 1;
    }
#endif

#if HART_HARDWARE_TEST_DELAYED_SCAN
    /* A3 channel-14 hardware check fix: do not scan inside CheckAndInitHart().
     * Run one delayed read-only legacy discovery scan after the scheduler/IOL path has started. */
    if (sucHartHardwareTestScanDone == FALSE)
    {
        if (sucHartHardwareTestDelay > 0u)
        {
            sucHartHardwareTestDelay--;
        }
        else
        {
            (void)HartScanChannels((UINT8)HART_HARDWARE_TEST_TARGET_CHANNEL,
                                   (UINT8)HART_HARDWARE_TEST_TARGET_CHANNEL);
            sucHartHardwareTestScanDone = TRUE;
        }
    }
#endif

    /* A3 RT1024 integration: legacy H8 uses a separate TPU/UART interrupt path.
     * In this RT1024 hardware test build, service the FPGA/HART queue from HartTask so queued channel requests actually run. */
    ProcessHartInterrupt();

    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucReserved      = 0u;
    TaskReturnValue.ucSuspendTime   = 0u;
    return TaskReturnValue;
}
#endif


/*******************************************************************************
*                              InitHartConnection                              *
*                              ==================                              *
* PURPOSE:                                                                     *
*    Initiate a HART transaction.                                              *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel object number which requests connection.            *
* RETURN:                                                                      *
*    Boolean. TRUE if request is accepted; FALSE if rejected.                  *
* PROCESS:                                                                     *
*    1. Add a_pClient to the stack queue.                                      *
* NOTES:                                                                       *
*    1. This function is used by channel object to initiate HART transaction.  *
*    2. Modem objects periodically checks the stack queue and uses the client  *
*       reference and callback interface to carry out the HART transaction.    *
*******************************************************************************/
BOOL InitHartConnection(UINT8 a_ucChan) {
#if defined(IOMTYPE_UIO)   
    return pHartQueue[FPGA.GetChannelModem(a_ucChan)]->AddToQueue(a_ucChan);
#else
    return HartQueue.AddToQueue(a_ucChan);
#endif
}
/*******************************************************************************
*                             AbortHartConnection                              *
*                             ===================                              *
* PURPOSE:                                                                     *
*    Abort a previously initiated HART transaction.                            *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if transaction is aborted; FALSE if any transaction with    *
*    the specified client is not found.                                        *
* PROCESS:                                                                     *
*    1. Check the stack queue for the passed reference and remove from queue   *
*       if it is found.                                                        *
*    2. Otherwise check each modem object for their client references and      *
*       disconnect the modem if a match with the passed reference is found.    *
* NOTES:                                                                       *
*    1. Note that Disconnect method a private method in clsModem and cannot be *
*       called from here. Instead a request is made is to the modem object     *
*       which will be processed subsequently by the modem interrupt routines.  *
*       Disconnect need to be protected as private method to streamline the    *
*       modem state change.                                                    *
*******************************************************************************/
BOOL AbortHartConnection(UINT8 a_ucChan) {

#if defined(IOMTYPE_UIO)  
    // If the request is in the queue, remove it
    if (pHartQueue[FPGA.GetChannelModem(a_ucChan)]->RemoveFromQueue(a_ucChan) == TRUE) 
    {
        return TRUE;
    }
#else
    // If the request is in the queue, remove it
    if (HartQueue.RemoveFromQueue(a_ucChan) == TRUE) {
        return TRUE;
    }
#endif
    
    // If not in the queue, check whether any modem is 
    // processing it. If yes, disconnect and free the modem.
    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) {
        if (pHartModem[ucModem]->GetConnectedChannel() == a_ucChan) { 
            pHartModem[ucModem]->RequestDisconnect();
            return TRUE;
        }
    }

    // No match for the passed refence is found. Nothing to abort.
    return FALSE;
}
/*******************************************************************************
*                             ProcessHartInterrupt                             *
*                             ====================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID ProcessHartInterrupt(VOID){
    for (UINT8 modem = 0u; modem < HARTMODEM_COUNT; modem++)
    {
        HartQueue.ProcessQueue(modem);
    }

    clsHartModem::HartModemHeartbeat();
}



#ifndef HART_ENABLE_REFRESH_SLOT_API
#define HART_ENABLE_REFRESH_SLOT_API 1
#endif

#if HART_ENABLE_REFRESH_SLOT_API
#if defined(IOMTYPE_AIH)
#include "aihmain.h"
#endif
#if defined(IOMTYPE_AOH)
#include "aohmain.h"
#endif
#ifndef UIO_HART_GLOBAL
// ----------------------------------
// Start Slot Variables and Functions
// ----------------------------------

/*******************************************************************************
*                         clsAihSlot::GetRcvBufObject                          *
*                         clsAohSlot::GetRcvBufObject                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
clsClientBuffer& clsAihSlot::GetRcvBufObject(VOID) {
#endif
#ifdef IOMTYPE_AOH
clsClientBuffer& clsAohSlot::GetRcvBufObject(VOID) {
#endif
    if (HCHANTYPE_CHANNEL == HartDevDb.m_HChanType) {
        return HartDevDb.m_ChanRcvBuffer; 
    }
    else if (HCHANTYPE_PASSTHROUGH == HartDevDb.m_HChanType) {
#if defined(IOMTYPE_UIO)
        clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(ChanNum));
#endif
        return pHartPst[HartDevDb.m_ucPstRemIndex]->m_PstRcvBuffer;
    }
    else {
        HardFail(HF_INVPROGRAMEXEC,HART_CPP,__LINE__);
        // Return value is just to silence compiler.
        return HartDevDb.m_ChanRcvBuffer; 
    }
}
/*******************************************************************************
*                           clsAihSlot::PreCommand                             *
*                           clsAohSlot::PreCommand                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreCommand(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreCommand(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if ((*(COMMAND *)a_WriteBuffer < COMMAND_ACCEPTCFG) ||
        (*(COMMAND *)a_WriteBuffer > COMMAND_RESETHCOMERR)) {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostCommand                            *
*                           clsAohSlot::PostCommand                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostCommand(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostCommand(UINT8) {
#endif
    if (COMMAND_RESETHCOMERR == HartDevDb.Command) {
        HartDevDb.HComSts     = HCOMSTS_GOOD;
        HartDevDb.HLComFail   = HCOMSTS_GOOD;
        HartDevDb.HNComErr    = 0;
        HartDevDb.HCmdFail    = HARTCOMMAND_INVALID;
        HartDevDb.HCmdResp    = 0;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_EXCOMMERR_MASK;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_CMDFAIL_MASK;
#if defined (IOMTYPE_UIO)

        UINT8 modem = FPGA.GetChannelModem(ChanNum);

        // Only clear the modem status for the modem associated with this channel
        pHartModem[modem]->ClearModemBad();

        // Clear HART Chan Fail for all AI/AO channels associated with this modem
        for (UINT8 ucChan = ((modem*SLOTSPERMODEM)+1); ucChan <= ((modem+1)*SLOTSPERMODEM); ucChan++)
        {
            if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT)
            {
                AIH_SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
            }
            else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT)
            {
                AOH_SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
            }
        }
#else
        for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
        {
            pHartModem[ucModem]->ClearModemBad();
        }

        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++)
        {
            SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
        }
#endif
    }
    
    // No need to do anything for accept configuratoin as the controller 
    // is going to write HDVxxCD parameters to the IOM. PostHDevIdCd will 
    // take care resetting any mismatch alarms present.

    HartDevDb.Command = COMMAND_UNDEFINED;
}
/*******************************************************************************
*                           clsAihSlot::PreHEnable                             *
*                           clsAohSlot::PreHEnable                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHEnable(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHEnable(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (*(UINT8 *)a_WriteBuffer > TRUE) {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHEnable                            *
*                           clsAohSlot::PostHEnable                            *
*                           =======================                            *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHEnable(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHEnable(UINT8) {
#endif
    if ((PNTTYPE_NOTCONFIGURED != PntType) || BOX->GetHADCEnable(ChanNum)) { // if channel is configured or STAC ops
        if (TRUE == HartCfgDb.HEnable) {
#ifdef IOMTYPE_AIH
            // Sensor type is not loaded for HART enabled channels as it is
            // greyed out on the forms. Default it to 1 to 5V and execute
            // PostSensorTyp for initializing ADRaw and RawSpan correctly.
            SensrTyp = SENSRTYP_1to5_V;
            PostSensrTyp(ALVL_PBD);
            BOX->SetHADCStatus(ChanNum, HART_DATA_PENDING);
#endif
            if (HCHANMODE_INIT == HartDevDb.m_HChanMode) {
#ifdef IOMTYPE_AOH
                if (!isnan(OpFinal) && (OpFinal > OP_LOLIMIT))
#endif
                {
                    // Initialization commands not completed yet
                    HartDevDb.m_HDataInit = HDATAINIT_PENDING;
                    if (HartDevDb.m_ucInitCmdIndex < 1) {
                        // if first C48 is not complete yet
                        HartDevDb.m_HEventInit = HEVENTINIT_PENDING;
                    }
                }
            }

            UINT8 ucDsa = BOX->GetDSA();
            if ((ucDsa > 0) && (ucDsa <= MAXDSA)) {
                // IOM is primary is channel configued with HART enabled.
                // Start HART scanning in this cycle.
                HartDevDb.m_sScanCounter = TICKS_IN_1_SEC;
            }
        }
        else { // Channel configured with HART disabled.
            HartDevDb.InitDevDb(TRUE);
            BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
        }
    }
#ifdef IOMTYPE_AOH
    else // Channel deleted
        BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
#endif
}
/*******************************************************************************
*                           clsAihSlot::PreHAlarmEnable                        *
*                           clsAohSlot::PreHAlarmEnable                        *
*                           ===========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHAlarmEnable(UINT8 *a_WriteBuffer,UINT8 a_ucAccLvl) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHAlarmEnable(UINT8 *a_WriteBuffer,UINT8 a_ucAccLvl) {
#endif
    // Save current configuration
    ScratchPad = HartCfgDb.HAlarmEnable;

    if (ALVL_IUSER == a_ucAccLvl) {
        // If warm restore and checkpoint restore is 
        // going on accept the write value as it is.
        return PA_OK;
    }

    // Update the writebuffer according to write value coming down.
    switch (*a_WriteBuffer) {
    case HALARMENABLE_ALMENBSTATE_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_ALMENBSTATE_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_JOURNALONLY_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_JOURNALONLY_MASK;
        break;
    default:
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;
}
/*******************************************************************************
*                          clsAihSlot::PostHAlarmEnable                        *
*                          clsAohSlot::PostHAlarmEnable                        *
*                          ============================                        *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHAlarmEnable(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHAlarmEnable(UINT8) {
#endif
    // Check for bits changed in HAlarmEnable
    ScratchPad ^= HartCfgDb.HAlarmEnable;

    if (ScratchPad > 0) { // either or both bits got changed
        if (ScratchPad & HALARMENABLE_ALMENBSTATE_MASK) {
            // ALMENBSTATE bit changed
            if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) {
                // Alarms got enabled - regen current HART event state
                HartDevDb.m_bReReportEvents = TRUE;
            }
        }
        
        if (ScratchPad & HALARMENABLE_JOURNALONLY_MASK) {
            // JOURNALONLY bit changed
            if (0 == (HartCfgDb.HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK)) {
                // Alarms got unsuppressed - if ALENBSTATE is enabled 
                // then regen current HART event state.
                if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) {
                    HartDevDb.m_bReReportEvents = TRUE;
                }
            }
        }

        // Post appropriate alarm option change event.
        // Pass FALSE as argument for normal event reporting.
        HartDevDb.PostHAlmOptChgEvent(FALSE);
    }
}
/*******************************************************************************
*                           clsAihSlot::PreHScanCfg                            *
*                           clsAohSlot::PreHScanCfg                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHScanCfg(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHScanCfg(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (TRUE == HartCfgDb.HEnable) { 
        if ((*a_WriteBuffer > HSCANCFG_UNDEFINED) && 
            (*a_WriteBuffer <= HSCANCFG_STATUSONLY)) {
            return PA_OK;
        }
    }
    else if (HSCANCFG_UNDEFINED == *a_WriteBuffer) {
        return PA_OK;
    }

    return DO_ILLEGAL_VALUE;
}
/*******************************************************************************
*                           clsAihSlot::PostHScanCfg                           *
*                           clsAohSlot::PostHScanCfg                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHScanCfg(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHScanCfg(UINT8) {
#endif
    HartDevDb.BuildScanTable();
}
/*******************************************************************************
*                           clsAihSlot::PreHComThrs                            *
*                           clsAohSlot::PreHComThrs                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHComThrs(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHComThrs(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (0 == *(UINT16 *)a_WriteBuffer) {
        *(UINT16 *)a_WriteBuffer = 1;
        return DO_VALUE_CLAMPED_ERROR;
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PreHComHys                            *
*                            clsAohSlot::PreHComHys                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHComHys(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHComHys(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (*(UINT16 *)a_WriteBuffer > HartCfgDb.HComThrs) {
        *(UINT16 *)a_WriteBuffer = HartCfgDb.HComThrs;
    }
    
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHDevIdCd                           *
*                           clsAohSlot::PostHDevIdCd                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHDevIdCd(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHDevIdCd(UINT8) {
#endif
    HartDevDb.CheckDevMismatch();
#ifdef IOMTYPE_AIH
    HartDevDb.CheckRangeMismatch();
#endif
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd                            *
*                           clsAohSlot::PreHDvMfgCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvMfgCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvMfgCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvMfgCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd7                            *
*                           clsAohSlot::PreHDvMfgCd7                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvMfgCd7(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvMfgCd7(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if ((*(UINT16 *)HartCfgDb7.HDvMfgCd7) != *(UINT16 *)a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd                            *
*                           clsAohSlot::PreHDvTypCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvTypCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvTypCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvTypCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd7                           *
*                           clsAohSlot::PreHDvTypCd7                           *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvTypCd7(UINT8 *a_WriteBuffer,UINT8){
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvTypCd7(UINT8 *a_WriteBuffer,UINT8){
#endif
    if ((*(UINT16 *)HartCfgDb7.HDvTypCd7) != *(UINT16 *)a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvRevCd                            *
*                           clsAohSlot::PreHDvRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvRevCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDdRevCd                            *
*                           clsAohSlot::PreHDdRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDdRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDdRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDdRevCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHEuRngExt                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHEuRngExt(UINT8 *a_WriteBuffer,UINT8) {
    if (PTEXECST_INACTIVE != PtExecSt) {
        return DO_POINT_MUST_BE_INACTIVE;
    }

    for (UINT8 ucCount = 0; HEuRngExt[ucCount] > 0; ucCount++) {
        DATABYTES RangeData;
        for (UINT8 ucByte = 0; ucByte < sizeof(FLOAT32); ucByte++) {
            RangeData.ucBytes[ucByte] = *a_WriteBuffer++;
        }
        if (isnan(RangeData.f32Val)) return DO_SOURCE_OF_REQUEST_INVALID;
    }

    // If the above cheks passes, default the current value of ranges so that  
    // the individual pre functions will not fail with range cross-over error.
    PvEUHi = NaN;
    PvEULo = NaN;
    PvExEUHi = NaN;
    PvExEULo = NaN;
    
    return PA_OK;
}
#endif
#ifndef IOMTYPE_UIO
#ifdef IOMTYPE_AIH
/*******************************************************************************
*                          clsAihBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAihBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::PostHADCEnable(UINT8) {
    PNTTYPE PointType = SLOT(WriteIndex)->GetPntType();
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    SetAdcCycleCount(WriteIndex,0);
    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        // Save present value of HEnable
        HEnableSaved[WriteIndex - 1] = SLOT(WriteIndex)->GetHEnable();
        // If channel is loaded and HEnable is FALSE set it to TRUE
        if ((PNTTYPE_ANALOGINPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(TRUE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        // If channel is loaded restore old value of HEnable if it was FALSE
        if ((PNTTYPE_ANALOGINPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(FALSE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
    }
}
#endif // ifdef IOMTYPE_AIH
#ifdef IOMTYPE_AOH
/*******************************************************************************
*                          clsAohBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if (TRUE == SLOT(WriteIndex)->IsRedTagged())
        return DO_POINT_IS_RED_TAGGED;
    if (TRUE == HAutoDet[WriteIndex - 1])
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::PostHADCEnable(UINT8) {
    PNTTYPE PointType = SLOT(WriteIndex)->GetPntType();
    FLOAT32 fOp;
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        // Save present OP value
        Op_Saved[WriteIndex - 1] = GetOp(WriteIndex);
        // If there is not presently enough current
        // Drive output current to the minimum necessary for device discovery
        if (HART_AUTODETECT_OP > SLOT(WriteIndex)->GetOpFinal()) {
            fOp = HART_AUTODETECT_OP;
            if (TRUE == SLOT(WriteIndex)->GetOpChar()) fOp = SLOT(WriteIndex)->ChrcBkwrd(HART_AUTODETECT_OP);
            if (OPTDIR_REVERSE == SLOT(WriteIndex)->GetOptDir()) fOp = ((FLOAT32) 100.0) - fOp;
            SetOp(WriteIndex,fOp);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
        HEnableSaved[WriteIndex - 1] = SLOT(WriteIndex)->GetHEnable();
        // If channel is loaded and HEnable is FALSE set it to TRUE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(TRUE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        // If channel is loaded restore old value of HEnable if it was FALSE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(FALSE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
        // If channel current was forced to the min value restore it to old value
        if (HART_AUTODETECT_OP > Op_Saved[WriteIndex - 1]) {
            SetOp(WriteIndex,Op_Saved[WriteIndex - 1]);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
    }
}
/*******************************************************************************
*                          clsAohBoxSlot::PreHAutoDet                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHAutoDet(UINT8 *a_WriteBuffer,UINT8) {
#if defined(IOPTYPE_AO16)
	if (TRUE == *(BOOL *)a_WriteBuffer) {
		if (BOX->GetFtaPres() == FTA_MISSING) {
			return DO_INITIALIZATION_ERROR;
		}
	}
#else
	if ((TRUE == *(BOOL *)a_WriteBuffer) &&
        (PNTTYPE_NOTCONFIGURED != SLOT(WriteIndex)->GetPntType())) {
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    if (TRUE == HADCEnable[WriteIndex - 1]) {
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    }
#endif
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHAutoDet                         *
*                          ===========================                         *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsAohBoxSlot::PostHAutoDet(UINT8) {
    /* Removed the check of Primary Module to Fix
       PAR 1-2KSQYU: AO-HART secondary IOM momentarily goes to IDLE
                     while loading a channel with HAUTODET
    */
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    if (TRUE == HAutoDet[WriteIndex - 1]) {
        // Drive output current for auto detection.
        SetOp(WriteIndex,HART_AUTODETECT_OP); // Drive 3.2 mA for auto detection
        SetHADCStatus(WriteIndex,HART_DATA_PENDING);
        SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
    }
    else {
        SetOp(WriteIndex,OP_LOLIMIT); // Drive 0 mA at output
        // If auto detection is disabled, schedule scan counter for
        // four seconds. This helps in keeping the HART discovery
        // information, if auto detection was disabled by a channel
        // load operation and there is enough current for HART. If
        // there is not enough current, HART database will be fully
        // initialized later.
        SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
    }
}
#endif // ifdef IOMTYPE_AOH
#endif // end ifndef IOMTYPE_UIO

// --------------------------------
// End Slot Variables and Functions
// --------------------------------
#endif // not UIO_HART_GLOBAL

#endif /* HART_ENABLE_REFRESH_SLOT_API */



static VOID HartClearRuntimeState(VOID)
{
    HartDb_Clear();
    g_haveLongAddr = false;
    g_runtimePollAddr = (UINT8)HART_POLL_ADDR_START;
    memset(g_runtimeLongAddr, 0, sizeof(g_runtimeLongAddr));
}


static VOID HartSetActiveRoute(UINT8 channel, UINT8 modem)
{
    if (channel < 1u)
    {
        channel = 1u;
    }

    if (channel > 16u)
    {
        channel = 16u;
    }

    if (modem > 3u)
    {
        modem = HartGetModemForChannel(channel);
    }

    g_activeChannel = channel;
    g_activeModem = modem;
    HartClearRuntimeState();
}


VOID HartSetRoute(UINT8 channel, UINT8 modem)
{
    HartSetActiveRoute(channel, modem);
}


UINT8 HartGetActiveChannel(VOID)
{
    return g_activeChannel;
}


UINT8 HartGetActiveModem(VOID)
{
    return g_activeModem;
}


VOID HartSetLastTransactionResult(UINT8 channel, UINT8 modem, HARTDISCOVERYRESULT result)
{
    if (channel < 1u)
    {
        channel = 1u;
    }

    if (channel > 16u)
    {
        channel = 16u;
    }

    if (modem > 3u)
    {
        modem = HartGetModemForChannel(channel);
    }

    g_activeChannel = channel;
    g_activeModem = modem;
    g_lastTransactionResult = result;

    if (result == HART_DISCOVERY_COMPLETE)
    {
        g_lastGoodChannel = channel;
        g_lastGoodModem = modem;
        g_haveLastGoodRoute = TRUE;
    }
}


HARTDISCOVERYRESULT HartGetLastTransactionResult(VOID)
{
    return g_lastTransactionResult;
}


UINT8 HartGetLastGoodChannel(VOID)
{
    return (g_haveLastGoodRoute != FALSE) ? g_lastGoodChannel : g_activeChannel;
}


UINT8 HartGetLastGoodModem(VOID)
{
    return (g_haveLastGoodRoute != FALSE) ? g_lastGoodModem : g_activeModem;
}


BOOL HartHasLastGoodRoute(VOID)
{
    return g_haveLastGoodRoute;
}


static BOOL HartIsWriteCommand(UINT8 command)
{
    return ((command == HARTCOMMAND_SIX) ||
            (command == HARTCOMMAND_THIRTYEIGHT) ||
            (command == HARTCOMMAND_FIFTYNINE) ||
            (command == HARTCOMMAND_HUNDREDNINE)) ? TRUE : FALSE;
}


static BOOL HartRunCommand(UINT8 command,
                           const UINT8 *data,
                           UINT8 dataLen,
                           const char *label,
                           HartParsedResponse_t *responseOut)
{
    HartParsedResponse_t localResponse;
    HartParsedResponse_t *rsp = (responseOut != NULL) ? responseOut : &localResponse;

    if (!g_haveLongAddr)
    {
        return FALSE;
    }

#if !HART_ENABLE_WRITE_COMMAND_CHECKS
    if (HartIsWriteCommand(command))
    {
        (void)data;
        (void)dataLen;
        (void)label;
        memset(rsp, 0, sizeof(*rsp));
        rsp->valid = TRUE;
        rsp->checksumOk = TRUE;
        rsp->command = command;
        rsp->status0 = HART_RESPCODE_SUCCESS;
        rsp->status1 = 0u;
        (void)HartDb_HandleResponse(rsp);
        return TRUE;
    }
#endif

    if (!HartStack_RunLongCommand(g_activeChannel,
                                  g_activeModem,
                                  g_runtimePollAddr,
                                  g_runtimeLongAddr,
                                  command,
                                  data,
                                  dataLen,
                                  label,
                                  rsp))
    {
        return FALSE;
    }


    if (command != HARTCOMMAND_THREE)
    {
        (void)HartDb_HandleResponse(rsp);
    }

    if (command == HARTCOMMAND_FOURTYEIGHT)
    {
        HartDb_UpdateCmd48Status(rsp->status0, rsp->status1);
    }
    else if (command == HARTCOMMAND_FIFTYNINE)
    {
        HartDb_UpdateCmd59Status(rsp->status0, rsp->status1);
    }

    return TRUE;
}


static const UINT8 *HartGetInitCommand(UINT8 hartRevision, UINT8 index, UINT8 *rowSize)
{
    if (index >= HART_INITCOMMAND_COUNT)
    {
        if (rowSize != NULL)
        {
            *rowSize = 0u;
        }
        return NULL;
    }

    if (hartRevision >= HARTVERSION_7X)
    {
        if (rowSize != NULL)
        {
            *rowSize = sizeof(HART7_INIT_COMMANDS[0]);
        }
        return HART7_INIT_COMMANDS[index];
    }

    if (hartRevision >= HARTVERSION_6X)
    {
        if (rowSize != NULL)
        {
            *rowSize = sizeof(HART6_INIT_COMMANDS[0]);
        }
        return HART6_INIT_COMMANDS[index];
    }

    if (rowSize != NULL)
    {
        *rowSize = sizeof(HART5_INIT_COMMANDS[0]);
    }
    return HART5_INIT_COMMANDS[index];
}


static VOID HartBuildInitCommandData(UINT8 command,
                                     UINT8 hartRevision,
                                     UINT8 responsePreambles,
                                     UINT8 *data,
                                     UINT8 *dataLen)
{
    clsHartDevDb *db = HartDb_GetHartDevDb();

    if ((data == NULL) || (dataLen == NULL))
    {
        return;
    }

    *dataLen = 0u;
    data[0] = 0u;
    data[1] = 0u;

    switch (command)
    {
        case HARTCOMMAND_FIFTYNINE:
            data[0] = responsePreambles;
            if (data[0] < HART_MIN_PREAMBLES)
            {
                data[0] = HART_MIN_PREAMBLES;
            }
            *dataLen = 1u;
            break;

        case HARTCOMMAND_SIX:
            data[0] = g_runtimePollAddr;
            if (hartRevision <= HARTVERSION_5X)
            {
                *dataLen = 1u;
            }
            else
            {
                data[1] = HART_LOOP_CURRENT_ENABLED;
                *dataLen = 2u;
            }
            break;

        case HARTCOMMAND_THIRTYEIGHT:
            if ((hartRevision >= HARTVERSION_7X) && (db != NULL))
            {
                data[0] = db->HCmd0.str.ucusConfigChgCnt[0];
                data[1] = db->HCmd0.str.ucusConfigChgCnt[1];
                *dataLen = 2u;
            }
            break;

        case HARTCOMMAND_HUNDREDNINE:
            data[0] = HART_BURSTMODE_OFF;
            *dataLen = 1u;
            break;

        default:
            break;
    }
}


static BOOL HartRunInitCommandTable(UINT8 responsePreambles, UINT8 hartRevision)
{
    BOOL anyFailure = FALSE;
    clsHartDevDb *db = HartDb_GetHartDevDb();

    if (db != NULL)
    {
        db->m_HChanMode = HCHANMODE_INIT;
        db->m_ucInitCmdIndex = 0u;
    }

    for (UINT8 index = 0u; index < HART_INITCOMMAND_COUNT; index++)
    {
        UINT8 rowSize = 0u;
        const UINT8 *row = HartGetInitCommand(hartRevision, index, &rowSize);
        UINT8 command;
        UINT8 data[2] = {0u, 0u};
        UINT8 dataLen = 0u;
        HartParsedResponse_t rsp;

        if ((row == NULL) || (rowSize < 2u))
        {
            continue;
        }

        command = row[0];
        HartBuildInitCommandData(command, hartRevision, responsePreambles, data, &dataLen);

        if (!HartRunCommand(command,
                            (dataLen > 0u) ? data : NULL,
                            dataLen,
                            "HART_INIT_COMMAND",
                            &rsp))
        {
            anyFailure = TRUE;
        }

        if (db != NULL)
        {
            db->m_ucInitCmdIndex = (UINT8)(index + 1u);
            (void)db->ScheduleFromInitTable();
        }
    }

    if (db != NULL)
    {
        db->m_HChanMode = HCHANMODE_SCAN;
        db->m_sScanCounter = TICKS_IN_1_SEC;
        db->BuildScanTable();
    }

    return (anyFailure == FALSE) ? TRUE : FALSE;
}


BOOL HartReadDynamicValues(VOID)
{
    HartParsedResponse_t cmd3;

    if (!HartRunCommand(HARTCOMMAND_THREE, NULL, 0u, "CMD3_READ_DYNAMIC_VARS", &cmd3))
    {
#if HART_ENABLE_ROUTE_DIAG_PRINT
        PRINTF("HART_STAGE CMD3_TRANSPORT_FAIL CHANNEL=%d MODEM=%d\r\n",
               (int)g_activeChannel, (int)g_activeModem);
#endif
        return FALSE;
    }

    /* Legacy treats status0 as the command response code and status1 as the
     * device-status byte.  A non-zero device-status byte does not invalidate
     * otherwise valid dynamic data. */
    if (cmd3.status0 != HART_RESPCODE_SUCCESS)
    {
#if HART_ENABLE_ROUTE_DIAG_PRINT
        PRINTF("HART_STAGE CMD3_RESPCODE_FAIL CHANNEL=%d MODEM=%d RC=%d DEVSTS=%02X LEN=%d\r\n",
               (int)g_activeChannel, (int)g_activeModem,
               (int)cmd3.status0, (unsigned int)cmd3.status1,
               (int)cmd3.payloadLen);
#endif
        return FALSE;
    }

    if (!HartDb_UpdateDynamicFromCmd3(&cmd3))
    {
#if HART_ENABLE_ROUTE_DIAG_PRINT
        PRINTF("HART_STAGE CMD3_VALUE_DECODE_FAIL CHANNEL=%d MODEM=%d DEVSTS=%02X LEN=%d\r\n",
               (int)g_activeChannel, (int)g_activeModem,
               (unsigned int)cmd3.status1, (int)cmd3.payloadLen);
#endif
        return FALSE;
    }

    return TRUE;
}


VOID HartInit(VOID)
{
    g_activeChannel = (UINT8)HART_TEST_CHANNEL;
    g_activeModem = (UINT8)HART_TEST_MODEM;
    g_lastGoodChannel = 0u;
    g_lastGoodModem = 0u;
    g_haveLastGoodRoute = FALSE;
    g_lastTransactionResult = HART_DISCOVERY_FAILED;
    HartClearRuntimeState();
}


HARTDISCOVERYRESULT HartDiscover(VOID)
{
    HartParsedResponse_t cmd0;
    HartParsedResponse_t cmd48;
    UINT8 respPreambles = HART_DEFAULT_PREAMBLECOUNT;

    if (!HartStack_SelfCheck())
    {
        return HART_DISCOVERY_FAILED;
    }

    for (UINT8 pa = HART_POLL_ADDR_START; pa <= HART_POLL_ADDR_END; pa++)
    {
        if (!HartStack_GetCleanCmd0(g_activeChannel,
                                    g_activeModem,
                                    pa,
                                    &cmd0))
        {
            continue;
        }

#if HART_ENABLE_ROUTE_DIAG_PRINT
        PRINTF("HART_STAGE CMD0_OK CHANNEL=%d MODEM=%d POLL=%d REV=%d\r\n",
               (int)g_activeChannel, (int)g_activeModem,
               (int)pa, (int)cmd0.hartRevision);
#endif

        if (!HartStack_ExtractLongAddressFromCmd0(&cmd0, g_runtimeLongAddr, &respPreambles))
        {
            return HART_DISCOVERY_CMD0_OK;
        }

#if HART_ENABLE_ROUTE_DIAG_PRINT
        PRINTF("HART_STAGE LONG_ADDR CHANNEL=%d MODEM=%d ADDR=%02X%02X%02X%02X%02X PRE=%d\r\n",
               (int)g_activeChannel, (int)g_activeModem,
               (unsigned int)g_runtimeLongAddr[0],
               (unsigned int)g_runtimeLongAddr[1],
               (unsigned int)g_runtimeLongAddr[2],
               (unsigned int)g_runtimeLongAddr[3],
               (unsigned int)g_runtimeLongAddr[4],
               (int)respPreambles);
#endif

        g_runtimePollAddr = pa;
        g_haveLongAddr = true;

        if (!HartDb_UpdateFromCmd0(g_activeChannel,
                                   g_activeModem,
                                   pa,
                                   &cmd0,
                                   g_runtimeLongAddr,
                                   respPreambles))
        {
            return HART_DISCOVERY_CMD0_OK;
        }


        if (HartRunCommand(HARTCOMMAND_FOURTYEIGHT,
                           NULL,
                           0u,
                           "CMD48_READ_ADDITIONAL_STATUS",
                           &cmd48))
        {
            HartDb_UpdateCmd48Status(cmd48.status0, cmd48.status1);
        }

        if (!HartReadDynamicValues())
        {
#if HART_ENABLE_ROUTE_DIAG_PRINT
            PRINTF("HART_STAGE CMD3_FAIL CHANNEL=%d MODEM=%d POLL=%d\r\n",
                   (int)g_activeChannel, (int)g_activeModem, (int)pa);
#endif
            HartClearRuntimeState();
            continue;
        }

        g_lastGoodChannel = g_activeChannel;
        g_lastGoodModem = g_activeModem;
        g_haveLastGoodRoute = TRUE;

#if HART_RUN_INIT_COMMAND_TABLE_AFTER_PV
        (void)HartRunInitCommandTable(respPreambles, cmd0.hartRevision);
#endif

        return HART_DISCOVERY_COMPLETE;
    }

    return HART_DISCOVERY_FAILED;
}


HARTDISCOVERYRESULT HartDiscoverOnRoute(UINT8 channel, UINT8 modem)
{
    HARTDISCOVERYRESULT result;

    HartSetActiveRoute(channel, modem);
    result = HartDiscover();
    HartSetLastTransactionResult(g_activeChannel, g_activeModem, result);

    return result;
}


UINT8 HartGetModemForChannel(UINT8 logicalChannel)
{
    if (logicalChannel < 1u)
    {
        logicalChannel = 1u;
    }

    if (logicalChannel > 16u)
    {
        logicalChannel = 16u;
    }


    return (UINT8)((logicalChannel - 1u) / 4u);
}


HARTDISCOVERYRESULT HartScanChannels(UINT8 logicalChannelStart, UINT8 logicalChannelEnd)
{
    UINT8 start = logicalChannelStart;
    UINT8 end = logicalChannelEnd;
    UINT8 tmp;
    HARTDISCOVERYRESULT overallResult = HART_DISCOVERY_FAILED;

    if (start < 1u)
    {
        start = 1u;
    }

    if (end > 16u)
    {
        end = 16u;
    }

    if (start > end)
    {
        tmp = start;
        start = end;
        end = tmp;
    }

    for (UINT8 ch = start; ch <= end; ch++)
    {
        UINT8 modem = HartGetModemForChannel(ch);

        HartSetLastTransactionResult(ch, modem, HART_DISCOVERY_FAILED);

        if (InitHartConnection(ch) == FALSE)
        {
            continue;
        }

        ProcessHartInterrupt();

        const HARTDISCOVERYRESULT channelResult = HartGetLastTransactionResult();
        if (channelResult == HART_DISCOVERY_COMPLETE)
        {
            overallResult = HART_DISCOVERY_COMPLETE;
        }
        else if ((channelResult == HART_DISCOVERY_CMD0_OK) &&
                 (overallResult == HART_DISCOVERY_FAILED))
        {
            overallResult = HART_DISCOVERY_CMD0_OK;
        }

        /* Do not return on the first device. HartScanChannels() must honour the
         * complete requested range so multiple instruments can be discovered. */
    }

    return overallResult;
}


static BOOL HartIsValidFloat(FLOAT32 value)
{
    return ((value == value) && (value > -2000000.0f) &&
            (value < 2000000.0f)) ? TRUE : FALSE;
}


static VOID HartFormatFloat3(FLOAT32 value, char *buffer, UINT32 bufferSize)
{
    INT32 scaled;
    UINT32 magnitude;
    UINT32 whole;
    UINT32 frac;
    UINT32 divisor = 1u;
    UINT32 wholeDigits = 1u;
    UINT32 index = 0u;

    if ((buffer == NULL) || (bufferSize == 0u))
    {
        return;
    }

    buffer[0] = '\0';
    if (HartIsValidFloat(value) == FALSE)
    {
        if (bufferSize >= 3u)
        {
            buffer[0] = 'N';
            buffer[1] = 'A';
            buffer[2] = '\0';
        }
        return;
    }

    scaled = (value >= 0.0f) ?
             (INT32)((value * 1000.0f) + 0.5f) :
             (INT32)((value * 1000.0f) - 0.5f);

    if (scaled < 0)
    {
        if ((index + 1u) >= bufferSize) { return; }
        buffer[index++] = '-';
        magnitude = (UINT32)(-(scaled + 1)) + 1u;
    }
    else
    {
        magnitude = (UINT32)scaled;
    }

    whole = magnitude / 1000u;
    frac = magnitude % 1000u;
    while ((whole / divisor) >= 10u)
    {
        divisor *= 10u;
        wholeDigits++;
    }

    if ((index + wholeDigits + 4u) >= bufferSize)
    {
        buffer[0] = '\0';
        return;
    }

    do
    {
        buffer[index++] = (char)('0' + ((whole / divisor) % 10u));
        divisor /= 10u;
    } while (divisor > 0u);

    buffer[index++] = '.';
    buffer[index++] = (char)('0' + ((frac / 100u) % 10u));
    buffer[index++] = (char)('0' + ((frac / 10u) % 10u));
    buffer[index++] = (char)('0' + (frac % 10u));
    buffer[index] = '\0';
}


static VOID HartPrintFloat3(FLOAT32 value)
{
    char text[24];
    HartFormatFloat3(value, text, (UINT32)sizeof(text));
    PRINTF("%s", text);
}


VOID HartReportCmd3Response(UINT8 channel, UINT8 modem)
{
#if HART_ENABLE_CMD3_RESPONSE_PRINT
    const HartDeviceInfo_t *device = HartDb_GetDevice();
    UINT8 outChannel = channel;
    UINT8 outModem = modem;

    if (g_haveLastGoodRoute != FALSE)
    {
        outChannel = g_lastGoodChannel;
        outModem = g_lastGoodModem;
    }

    if ((device == NULL) || (device->dynamicValid == FALSE))
    {
        PRINTF("HART_CMD3 LOOP_CURRENT_MA=NA PV_UNIT=0 PV=NA SV_UNIT=0 SV=NA TV_UNIT=0 TV=NA QV_UNIT=0 QV=NA CHANNEL=%d MODEM=%d\r\n",
               (int)outChannel,
               (int)outModem);
        return;
    }

    /* Build every floating-point field first, then emit CMD3 using one PRINTF.
     * This prevents scheduler/DMC diagnostics from splitting the line midway. */
    char loopCurrent[24];
    char pv[24];
    char sv[24];
    char tv[24];
    char qv[24];

    HartFormatFloat3(device->loopCurrentMa, loopCurrent, (UINT32)sizeof(loopCurrent));
    if (device->dynamicCount > 0u) { HartFormatFloat3(device->dynamicValue[0], pv, (UINT32)sizeof(pv)); }
    else { strcpy(pv, "NA"); }
    if (device->dynamicCount > 1u) { HartFormatFloat3(device->dynamicValue[1], sv, (UINT32)sizeof(sv)); }
    else { strcpy(sv, "NA"); }
    if (device->dynamicCount > 2u) { HartFormatFloat3(device->dynamicValue[2], tv, (UINT32)sizeof(tv)); }
    else { strcpy(tv, "NA"); }
    if (device->dynamicCount > 3u) { HartFormatFloat3(device->dynamicValue[3], qv, (UINT32)sizeof(qv)); }
    else { strcpy(qv, "NA"); }

    PRINTF("HART_CMD3 LOOP_CURRENT_MA=%s PV_UNIT=%d PV=%s SV_UNIT=%d SV=%s TV_UNIT=%d TV=%s QV_UNIT=%d QV=%s DYN_COUNT=%d DEVSTS=%02X CHANNEL=%d MODEM=%d\r\n",
           loopCurrent,
           (int)device->dynamicUnit[0], pv,
           (int)device->dynamicUnit[1], sv,
           (int)device->dynamicUnit[2], tv,
           (int)device->dynamicUnit[3], qv,
           (int)device->dynamicCount,
           (unsigned int)device->cmd3Status1,
           (int)outChannel,
           (int)outModem);
#else
    (void)channel;
    (void)modem;
#endif
}


VOID HartReportFinalResponse(UINT8 channel, UINT8 modem, HARTDISCOVERYRESULT result)
{
#if HART_ENABLE_FINAL_RESPONSE_PRINT
    const HartDeviceInfo_t *device = HartDb_GetDevice();
    UINT8 outChannel = channel;
    UINT8 outModem = modem;
    FLOAT32 pv = 0.0f;
    UINT8 unit = 0u;

    /* Only a successful transaction may use the last-good/device route.
     * A failed probe must remain associated with the channel being tested. */
    if (result == HART_DISCOVERY_COMPLETE)
    {
        if ((device != NULL) && (device->valid != FALSE) &&
            (device->channel >= 1u) && (device->channel <= 16u) &&
            (device->modem <= 3u))
        {
            outChannel = device->channel;
            outModem = device->modem;
        }
        else if (g_haveLastGoodRoute != FALSE)
        {
            outChannel = g_lastGoodChannel;
            outModem = g_lastGoodModem;
        }
    }

    if ((outChannel < 1u) || (outChannel > 16u))
    {
        outChannel = g_activeChannel;
    }
    if (outModem > 3u)
    {
        outModem = HartGetModemForChannel(outChannel);
    }

    if ((result == HART_DISCOVERY_COMPLETE) && HartDb_GetPrimaryVariable(&pv, &unit) &&
        HartIsValidFloat(pv))
    {
        (void)unit;
        PRINTF("HART_RESPONSE PV=");
        HartPrintFloat3(pv);
        PRINTF(" CHANNEL=%d MODEM=%d\r\n", (int)outChannel, (int)outModem);
        HartReportCmd3Response(outChannel, outModem);
    }
    else
    {
#if HART_ENABLE_ROUTE_DIAG_PRINT
        /* MAR/MER/GPWR are command/control registers and their direct readback
         * is not a reliable route diagnostic on this FPGA SPI bridge.  Print
         * the exact values commanded by the legacy nibble-per-modem mapping. */
        const UINT16 clearMask[HARTMODEM_COUNT] = {0xFFF0u, 0xFF0Fu, 0xF0FFu, 0x0FFFu};
        UINT16 expectedMar = HART_DEFAULT_MAR_CH1_M0;
        expectedMar &= clearMask[outModem];
        expectedMar |= (UINT16)(((UINT16)(outChannel - 1u) & 0x0Fu) << (outModem * 4u));
        const UINT8 expectedMer = (UINT8)(1u << outModem);

        PRINTF("HART_ROUTE_CMD CHANNEL=%d MODEM=%d MAR=%04X MER=%02X GPWR_MASK=08 GPWR_DATA=08 SPI_ERRORS=%d\r\n",
               (int)outChannel, (int)outModem,
               (unsigned int)expectedMar, (unsigned int)expectedMer,
               (int)hal_fpga_get_spi_error_count());
#endif
#if HART_PRINT_FAILED_PROBES
        /* Keep one concise failure result for hardware validation; do not print
         * a fake CMD3 value line for a route that never passed strict CMD0. */
        PRINTF("HART_RESPONSE PV=NA CHANNEL=%d MODEM=%d\r\n", (int)outChannel, (int)outModem);
#endif
    }
#else
    (void)channel;
    (void)modem;
    (void)result;
#endif
}


VOID HartDiscoveryTask(VOID)
{
    (void)HartScanChannels((UINT8)HART_SCAN_CHANNEL_START,
                           (UINT8)HART_SCAN_CHANNEL_END);
}

