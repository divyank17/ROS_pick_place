/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aixslot.hpp                                                 *
*    Description : AIH Analog Input channel slot class for RT1024.             *
*                  clsAixSlot represents one of the 16 ADC input channels.     *
*                  Inherits from clsIomSlot (simplified from H8S's             *
*                  clsIomSlot→clsIoSlot→clsInSlot→clsAixSlot chain).          *
*                                                                              *
*    On the H8S, channel slots were allocated via placement new into           *
*    pDatabase[1..16] and had their own per-channel parameter tables.          *
*    On RT1024, channel data lives inside clsAihBoxSlot's arrays              *
*    (PvScanRec[], CalibData, HADCEnable[], etc.) for simplicity.             *
*    clsAixSlot provides the per-channel ReadParam/WriteParam interface.       *
*******************************************************************************/
#ifndef __AIXSLOT_HPP__
#define __AIXSLOT_HPP__

#include "inslot.hpp"

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
//Constants for PvSts, PvAutoSt parameters
typedef enum tagPvValSt {
    PVVALST_BAD       =0,
    PVVALST_UNCERTN   =1,
    PVVALST_NORMAL    =2,
    PVVALST_MANUAL    =3
} PVVALST;

//Constants for PvClamp parameter
typedef enum tagPvClamp {
    PVCLAMP_NOCLAMP   =0,
    PVCLAMP_CLAMP     =1
} PVCLAMP;

typedef enum tagPvChar {
    PVCHAR_JTHERM   = 0,
    PVCHAR_KTHERM   = 1,
    PVCHAR_ETHERM   = 2,
    PVCHAR_TTHERM   = 3,
    PVCHAR_BTHERM   = 4,
    PVCHAR_STHERM   = 5,
    PVCHAR_RTHERM   = 6,
    PVCHAR_RPTHERM  = 7,
    PVCHAR_DINRTD   = 8,
    PVCHAR_JISRTD   = 9,
    PVCHAR_NICKLRTD = 10,
    PVCHAR_COPPRRTD = 11,
    PVCHAR_LINEAR   = 12,
    PVCHAR_SQRROOT  = 13,
    PVCHAR_NTHERM   = 14,
    PVCHAR_PT200RTD = 15,
    PVCHAR_PT500RTD = 16,
    PVCHAR_CU10RTD  = 17,
    PVCHAR_CU25RTD  = 18,
    PVCHAR_RHRAD    = 19,
    PVCHAR_W5W26TC  = 20,
    PVCHAR_W5W25TC  = 21,
    PVCHAR_NINIMOTC = 22,
    PVCHAR_RTDOHMS  = 23,
    PVCHAR_DEVRANGE = 26,
    PVCHAR_SYSRANGE = 27,
    PVCHAR_SYSRSQRT = 28
} PVCHAR;

typedef enum tagPvTemp {
    PVTEMP_DEG_C  = 0,
    PVTEMP_DEG_F  = 1,
    PVTEMP_DEG_R  = 2,
    PVTEMP_DEG_K  = 3
} PVTEMP;

typedef enum tagSensrTyp {
    SENSRTYP_1to5_V     =0,
    SENSRTYP_0to5_V     =1,
    SENSRTYP_0to100_MV  =2,
    SENSRTYP_THERMCPL   =3,
    SENSRTYP_RTD        =4,
    SENSRTYP_P4TO2_V    =5,
    SENSRTYP_SLIDWIRE   =6,
    SENSRTYP_SLDWSRCE   =7,
    SENSRTYP_SPT_DP     =8,
    SENSRTYP_SPT_GP     =9,
    SENSRTYP_SPT_AP     =10,
    SENSRTYP_STT        =11,
    SENSRTYP_SFM        =12,
    SENSRTYP_SCM        =13,
    SENSRTYP_SGC        =14,
    SENSRTYP_SVP        =15,
    SENSRTYP_MTT        =16,
    SENSRTYP_STP        =17,
    SENSRTYP_SLV        =18,
    SENSRTYP_SDU        =19,
    SENSRTYP_GENERIC    =20
} SENSRTYP;

#if 1//defined(IOPTYPE_HLAI)

typedef union tagAlmInfo {
    UINT8 ucByte;
    struct {
        UINT8 Unused     : 1;
        UINT8 ucPvRocNFl : 1;
        UINT8 ucPvRocPFl : 1;
        UINT8 ucPvLoFl   : 1;
        UINT8 ucPvHiFl   : 1;
        UINT8 ucPvLlFl   : 1;
        UINT8 ucPvHhFl   : 1;
        UINT8 ucBadPvFl  : 1;
    } Bit;
} ALMINFO;

typedef struct tagAlmVar {
    FLOAT32 fPv4secOld;
    UINT16 uiTsCounter;
    BOOL bPFirstInc;
    BOOL bPFirstDec;
    BOOL bNFirstInc;
    BOOL bNFirstDec;
} ALMVAR;

typedef enum tagHighAl {
    NOALARM       = 0,
    OFFNORM_CODE  = 1,
    UNCEVT_CODE   = 2,
    CMDDIS_CODE   = 3,
    ADVDEV_CODE   = 4,
    DEVLO_CODE    = 5,
    DEVHI_CODE    = 6,
    PVROCNFL_CODE = 7,
    PVROCPFL_CODE = 8,
    PVLOFL_CODE   = 9,
    PVHIFL_CODE   = 10,
    PVLLFL_CODE   = 11,
    PVHHFL_CODE   = 12,
    CNFERR_CODE   = 13,
    BADCTL_CODE   = 14,
    BADPVFL_CODE  = 15
} ALMCODE;

typedef enum tagPvFormat {
    PVFORMAT_D0 = 0,
    PVFORMAT_D1 = 1,
    PVFORMAT_D2 = 2,
    PVFORMAT_D3 = 3
} PVFORMAT;

typedef enum tagPvAlDb {
    PVALDB_HALF  = 0,
    PVALDB_ONE   = 1,
    PVALDB_TWO   = 2,
    PVALDB_THREE = 3,
    PVALDB_FOUR  = 4,
    PVALDB_FIVE  = 5,
    PVALDB_EU    = 6
} PVALDB;

#define BADPV_MASK  0x01
#define PVHH_MASK   0x02
#define PVLL_MASK   0x04
#define PVHI_MASK   0x08
#define PVLO_MASK   0x10
#define PVROCP_MASK 0x20
#define PVROCN_MASK 0x40

#define GetAlmCode(AlmBit) ((AlmBit == BADPV_MASK)  ? BADPVFL_CODE  : \
                            (AlmBit == PVHH_MASK)   ? PVHHFL_CODE   : \
                            (AlmBit == PVLL_MASK)   ? PVLLFL_CODE   : \
                            (AlmBit == PVHI_MASK)   ? PVHIFL_CODE   : \
                            (AlmBit == PVLO_MASK)   ? PVLOFL_CODE   : \
                            (AlmBit == PVROCP_MASK) ? PVROCPFL_CODE : \
                            (AlmBit == PVROCN_MASK) ? PVROCNFL_CODE : NOALARM)

#define GetViolatedTripPoint(AlrmCode)  ((AlrmCode == PVHHFL_CODE)   ? PvHhTp   : \
                                         (AlrmCode == PVLLFL_CODE)   ? PvLlTp   : \
                                         (AlrmCode == PVHIFL_CODE)   ? PvHiTp   : \
                                         (AlrmCode == PVLOFL_CODE)   ? PvLoTp   : \
                                         (AlrmCode == PVROCPFL_CODE) ? PvRocPTp : \
                                         (AlrmCode == PVROCNFL_CODE) ? PvRocNTp : NaN)

#endif
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8 PARAMID_PV         = 1;    /* Process variable (FLOAT32)         */
const UINT8 PARAMID_PVSTS      = 2;    /* PV status (UINT8)                  */
const UINT8 PARAMID_RAWCOUNT   = 3;    /* Raw ADC count (UINT32)             */
const UINT8 PARAMID_CONTCUT    = 10;   /* Continuous cut-off (BOOL)          */
const UINT8 PARAMID_PVSOURCE   = 11;   /* PV source (UINT8)                 */
const UINT8 PARAMID_CH_SLOPE   = 200;  /* Calibration slope (FLOAT32)       */
const UINT8 PARAMID_CH_OFFSET  = 201;  /* Calibration offset (FLOAT32)      */

//enms for temperature conversion
const  FLOAT32 FARENHEIT_CONV_OFFSET  =   32.0;
const  FLOAT32 FARENHEIT_CONV_NUM     =   9.0;
const  FLOAT32 FARENHEIT_CONV_DEN     =   5.0;
const  FLOAT32 RANKINE_CONV_OFFSET    =   491.69;
const  FLOAT32 RANKINE_CONV_NUM       =   9.0;
const  FLOAT32 RANKINE_CONV_DEN       =   5.0;
const  FLOAT32 KELVIN_CONV_OFFSET     =   273.0;

/*******************************************************************************
*                                   clsAixSlot                                 *
*                                   ==========                                 *
*  Per-channel slot object for AIH analog input channels (1-16).               *
*  Each instance manages one ADC channel: PV, raw count, calibration,          *
*  open-wire detection flag, and soft-fail per channel.                         *
*******************************************************************************/
class clsAixSlot : public clsInSlot {

protected:

    FLOAT32 PvRaw;
    FLOAT32 PvCalc;
    FLOAT32 FiltOut;
	BOOL    BadPvFl;
    FLOAT32 PvAuto;
    PVVALST PvAutoSt;
    FLOAT32 LastPv;
    FLOAT32 PvP;
    FLOAT32 LoCutOff;

    FLOAT32 PvEUHi;
    FLOAT32 PvEULo;
    FLOAT32 PvExEUHi;
    FLOAT32 PvExEULo;
    BOOL    PvExHiFl;
    BOOL    PvExLoFl;
    PVCLAMP PvClamp;

    FLOAT32 Tf;
    FLOAT32 Kf;
    FLOAT32 PvTv;
    FLOAT32 PvTvP;

    FLOAT32 EUSpan;
    FLOAT32 EUSpanDivHundred;
    FLOAT32 HundredDivEUSpan;

#if 1//defined(IOPTYPE_HLAI)
    ALMINFO  AlmInfo;
    ALMINFO  AlarmLrs;
    ALMVAR   AlmVar;
    ALMCODE  HighAl;
    BOOL     PtInAl;
    PVALDB   PvAlDb;
    PVFORMAT PvFormat;
    FLOAT32  PvHhTp;
    FLOAT32  PvHiTp;
    FLOAT32  PvLlTp;
    FLOAT32  PvLoTp;
    FLOAT32  PvRocNTp;
    FLOAT32  PvRocPTp;
    /*
    BOOL     PvHhFl;
    BOOL     PvHiFl;
    BOOL     PvLlFl;
    BOOL     PvLoFl;
    BOOL     PvRocnFl;
    BOOL     PvRocpFl;
    */
    UINT8    SlwSrcId;
    FLOAT32  PvAlDbEu;
    FLOAT32  RawSpan;
#endif

    clsAixSlot(UINT8);
    virtual ~clsAixSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AIXSLOT_HPP,__LINE__); }

    VOID InitAixSlot(BOOL bFullInit, BOOL bObjCreate);

    inline VOID *GetAlmInfoPtr(VOID)  { return &AlmInfo; }
    inline VOID *GetAlarmLrsPtr(VOID) { return &AlarmLrs; }

    VOID *GetPvPtr(VOID);
    VOID *GetPvStsPtr(VOID);

    inline VOID *GetPvPPtr(VOID)      {return &PvP;}
    inline VOID *GetPvRawPtr(VOID)    {return &PvRaw;}
    inline VOID *GetPvCalcPtr(VOID)   {return &PvCalc;}
    inline VOID *GetFiltOutPtr(VOID)  {return &FiltOut;}
    inline VOID *GetPvAutoPtr(VOID)   {return &PvAuto;}
    inline VOID *GetPvAutoStPtr(VOID) {return &PvAutoSt;}

    inline VOID *GetPvHhTpPtr(VOID)   { return &PvHhTp; }
    inline VOID *GetPvHiTpPtr(VOID)   { return &PvHiTp; }
    inline VOID *GetPvLlTpPtr(VOID)   { return &PvLlTp; }
    inline VOID *GetPvLoTpPtr(VOID)   { return &PvLoTp; }
    inline VOID *GetPvRocNTpPtr(VOID) { return &PvRocNTp; }
    inline VOID *GetPvRocPTpPtr(VOID) { return &PvRocPTp; }

    inline VOID *GetBadPvFlPtr(VOID)  {return &BadPvFl;}
    inline VOID *GetLastPvPtr(VOID)   {return &LastPv;}
    inline VOID *GetLoCutOffPtr(VOID) {return &LoCutOff;}
    inline VOID *GetPvTvPtr(VOID)     {return &PvTv;}
    inline VOID *GetPvTvPPtr(VOID)    {return &PvTvP;}

    PASTATUS PrePv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPv(UINT8 a_ucAccLvl);
    PASTATUS PreTf(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);

    /* EU range and exception accessors */
    PASTATUS PrePvEUHi(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvEULo(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvEULo(UINT8 a_ucAccLvl);
    PASTATUS PrePvExEUHi(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvExEULo(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEULo(UINT8 a_ucAccLvl);
    PASTATUS PrePvChar(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvChar(UINT8 a_ucAccLvl);
    PASTATUS PreInptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreContCut(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPntType(UINT8 a_ucAccLvl);
    PASTATUS PrePtExecSt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPtExecSt(UINT8 a_ucAccLvl);
    PASTATUS PrePntForm(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPntForm(UINT8 a_ucAccLvl);
    PASTATUS PrePvSource(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvSource(UINT8 a_ucAccLvl);

    //PASTATUS PreTf(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PrePvTv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvTv(UINT8 a_ucAccLvl);

    /* Ptr accessors for EU range and exception data */
    inline VOID *GetPvEUHiPtr(VOID)   {return &PvEUHi;}
    inline VOID *GetPvEULoPtr(VOID)   {return &PvEULo;}
    inline VOID *GetPvExEUHiPtr(VOID) {return &PvExEUHi;}
    inline VOID *GetPvExEULoPtr(VOID) {return &PvExEULo;}
    inline VOID *GetPvExHiFlPtr(VOID) {return &PvExHiFl;}
    inline VOID *GetPvExLoFlPtr(VOID) {return &PvExLoFl;}
    //inline VOID *GetPvCharPtr(VOID) { return &PvChar; }
    inline VOID *GetPvClampPtr(VOID)  {return &PvClamp;}
    //inline VOID *GetInptDirPtr(VOID) { return &InptDir; }
    inline VOID *GetPntFormPtr(VOID) { return &PntForm; }
    //inline VOID *GetPntTypePtr(VOID) { return &PntType; }
    //inline VOID *GetPtExecStPtr(VOID) { return &PtExecSt; }
    //inline VOID *GetContCutPtr(VOID) { return &ContCut; }
    //inline VOID *GetSlotSfBtPtr(VOID) { return &SlotSfBt; }
    inline VOID *GetTfPtr(VOID)       {return &Tf;}
    inline VOID *GetKfPtr(VOID)       {return &Kf;}
    inline VOID *GetEUSpanPtr(VOID)   {return &EUSpan;}

#if 1//defined(IOPTYPE_HLAI)
    PASTATUS PrePvAlDbEu(UINT8 *, UINT8);
    PASTATUS PrePvAlDb(UINT8 *, UINT8);
    PASTATUS PrePvHhTp(UINT8 *, UINT8);
    PASTATUS PrePvHiTp(UINT8 *, UINT8);
    PASTATUS PrePvLlTp(UINT8 *, UINT8);
    PASTATUS PrePvLoTp(UINT8 *, UINT8);
    PASTATUS PrePvRocNTp(UINT8 *, UINT8);
    PASTATUS PrePvRocPTp(UINT8 *, UINT8);

    VOID PostPvAlDb(UINT8);
    VOID PostPvHhTp(UINT8);
    VOID PostPvHiTp(UINT8);
    VOID PostPvLlTp(UINT8);
    VOID PostPvLoTp(UINT8);
    VOID PostPvRocNTp(UINT8);
    VOID PostPvRocPTp(UINT8);

    inline VOID *GetHighAlPtr(VOID)   { return &HighAl; }
    inline VOID *GetPtInAlPtr(VOID)   { return &PtInAl; }
    inline VOID *GetPvAlDbPtr(VOID)   { return &PvAlDb; }
    inline VOID *GetPvFormatPtr(VOID) { return &PvFormat; }
    /*
    inline VOID *GetPvHhFlPtr(VOID)   { return &PvHhFl; }
    inline VOID *GetPvHiFlPtr(VOID)   { return &PvHiFl; }
    inline VOID *GetPvLlFlPtr(VOID)   { return &PvLlFl; }
    inline VOID *GetPvLoFlPtr(VOID)   { return &PvLoFl; }
    inline VOID *GetPvRocNFlPtr(VOID) { return &PvRocNFl; }
    inline VOID *GetPvRocPFlPtr(VOID) { return &PvRocPFl; }
    */
    inline VOID *GetSlwSrcIdPtr(VOID) { return &SlwSrcId; }
    inline VOID *GetPvAlDbEuPtr(VOID) { return &PvAlDbEu; }
    inline VOID *GetRawSpanPtr(VOID)  { return &RawSpan; }
#endif

    clsAixSlot(const clsAixSlot&); // Safeguard against default copy constructor
    clsAixSlot& operator=(const clsAixSlot&); // and default assignment.
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    //VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,AIXSLOT_HPP,__LINE__); return NULL; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AIXSLOT_HPP,__LINE__); }

public:

    //clsAixSlot(UINT8);
#if 1//defined(IOPTYPE_HLAI)
    inline UINT8 GetSlwSrcId(VOID) { return SlwSrcId; }
#endif

    inline FLOAT32 GetPvEUHi(VOID) { return PvEUHi; }
    inline FLOAT32 GetPvEULo(VOID) { return PvEULo; }
    inline FLOAT32 GetPvExEUHi(VOID) { return PvExEUHi; }
    inline FLOAT32 GetPvExEULo(VOID) { return PvExEULo; }
    inline VOID UpdateBadPvFl(BOOL a_bFlag) { BadPvFl = a_bFlag; }

#if 1 // temp for testing
    inline PVCLAMP GetPvClamp(VOID)  {return PvClamp;}
#endif
};


#endif /* __AIXSLOT_HPP__ */
