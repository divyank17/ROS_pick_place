/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iol.hpp                                                     *
*    Description : IOL Interface class definition file.                        *
*                                                                              *
*    Converted from Renesas H8S/2329 -> NXP LPC1763 -> NXP iMXRT1024.         *
*    - H8S SCI register macros replaced by IOL_WriteByte/ReadByte/etc.        *
*      (armsrc precedent, LPC_UART1 inline wrappers)                          *
*    - RT1024: inline wrappers route through HAL LPUART (see                  *
*      commonelectronics.h for IOL_WriteByte et al. definitions)              *
*    - H8S TPU4 timer replaced by SilenceTimer helpers (armsrc precedent)     *
*    - H8S GPIO (TXREQ_n, CLRGHL_n) replaced by SetTXREQ_n/SetCLR_GHL_n     *
*    - ISR architecture: extern "C" IRQ handlers with friend access           *
*      (armsrc precedent, replaces H8S static ISR members)                    *
*******************************************************************************/
//   - Removed S3 FPGA/SCI2 dual-UART paths (single-channel LPUART)          //
//   - Removed non-AIH IOM types (DISOE, DO, LLMUX, SVP, SP, PI, UIO)       //
//   - ChecksumHi/Lo widened from UINT to UINT16 (armsrc precedent)           //
//   - Preserved all original logic, variable names, and command handlers      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <stddef.h>
#if IOMTYPE_AIH
#include "aihmain.h"
#endif

#ifndef __IOL_HPP__
#define __IOL_HPP__

#include <cstddef>

#define IOL_BYT_DBG 0
#define IOL_ERR_DBG 0

#define IOL_GHO_ENB 1

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#if defined(AIH_PROTO_V1) && AIH_PROTO_V1
	#define IOLINK_RX_MUX			IOMUXC_GPIO_AD_B0_07_LPUART1_RX /* GPIO_AD_B0_07 is configured as LPUART1_RX */
	#define IOLINK_TX_MUX			IOMUXC_GPIO_AD_B0_06_LPUART1_TX /* GPIO_AD_B0_06 is configured as LPUART1_TX */

	#define IOLINK_UART_BASEADDR	LPUART1
	#define IOLINK_UART_IRQn		LPUART1_IRQn
	#define IOLINK_UART_IRQHandler	LPUART1_IRQHandler
#else
	#define IOLINK_RX_MUX    		IOMUXC_GPIO_AD_B0_15_LPUART3_RX /* GPIO_AD_B0_15 is configured as LPUART3_RX */
	#define IOLINK_TX_MUX    		IOMUXC_GPIO_AD_B0_14_LPUART3_TX /* GPIO_AD_B0_14 is configured as LPUART3_TX */

	#define IOLINK_UART_BASEADDR	LPUART3
	#define IOLINK_UART_IRQn		LPUART3_IRQn
	#define IOLINK_UART_IRQHandler	LPUART3_IRQHandler
#endif

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8   MAXDSA = 63;
/* Inter-character timeout budget for the byte-to-byte polling loops in
 * Rcvr(). Was 27 (~27us) — essentially exactly ONE byte-time at 375,000 bps
 * (26.67us/byte), i.e. zero margin. Any jitter from the remote sender or
 * from this loop's own per-iteration overhead (beyond the explicit
 * IdleWait(1) call) blows the budget, aborts mid-message via goto ERROR,
 * and (since nCharProcd==0 during RX) immediately re-arms the RX interrupt
 * — so the very next byte of the SAME still-arriving message gets treated
 * as a fresh address-frame start, fails the alert-bit check, and repeats.
 * Observed in the field as RcvrEntryCount racing into the millions with
 * ~83% of entries failing the byte-0 alert check (AlertErrCount), starving
 * the scheduler and looking like "IOL stopped transmitting". Widened to
 * ~3 byte-times for real margin; see clsIol::RcvrEntryCount/AlertErrCount. */
const UINT32  NCYCLES_CHARTO = 81;                        // TcWait = ~81.00 us (~3 byte-times @ 375kbps)
const UINT8   PHI = 24;                                // System Clock (in MHz)
const UINT16  TMRCLKPER = 16000/PHI;            // Timer 4 Clock period (in ns)
const UINT32  LNKSILNS = 10000000;                      // Link Silence (in ns)
const UINT32  LNKHUNTNS = 500000;                     // Link hunt time (in ns)
const UINT16  CNTLNKSIL = 10000;                   // 10ms (LNKSILNS/TMRCLKPER)
const UINT16  CNTLNKHUNT = 500;                 // 500 us (LNKHUNTUS/TMRCLKPER)
const UINT16  CNTLNKSECTO = 2 + 40;       // 40ms timeout for the backup module
const UINT16  CNTLNKPRITO = 2 + 120;      // 80ms timeout for the primary module
const UINT16  TPU4CNT_TCWAIT = 16;        // TcWait TPU4_TCNT;=26 * 0.6667=17.3us
const UINT16  TPU4CNT_TMGAP  = 26;        // Tmgap TPU4_TCNT; =41 * 0.6667=27.3us
const UINT8   LOOPCNT100USEC = 100;
const UINT8   LOOPCNT50USEC  = 50;

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum FLETCHERACTION {
    FTYP_APPEND,
    FTYP_COMPARE
}FLETCHERACTION;

class clsIol; // Forward declaration
typedef struct tagCMDINFO {
    UINT8 CountReq;
    UINT8 CountResp;
    PASTATUS (clsIol::* CmdHandler)(VOID);
}CMDINFO;

extern "C" void GHO_IRQHandler(VOID);
extern "C" void SilenceTimer_IRQHandler(VOID);
extern "C" void BOARD_INITIOLINK_PINS_GHOIRQ_n_callback(void *param);

/*******************************************************************************
*                                     clsIol                                   *
*                                     ======                                   *
*******************************************************************************/
class clsIol {

public:

    clsIol(VOID);
    VOID Enable(VOID);

    /* Free-running count of Rcvr() ISR entries — diagnostic only. Lets us
     * tell whether the IOL UART RX interrupt is firing at an abnormal rate
     * (e.g. a noisy/jabbered line retriggering continuously) versus normal
     * traffic, since that ISR runs at higher priority than SysTick and can
     * starve the cooperative task scheduler if it dominates the CPU. */
    static volatile UINT32 RcvrEntryCount;

    /* Of those Rcvr() entries: how many were address-mismatch (legitimate
     * other-node traffic on the multi-drop bus, i.e. NotMyAddress()==TRUE)
     * versus how many failed the address-mark/alert-bit check on byte 0
     * (a noise/framing signature, not just "someone else's message"). */
    static volatile UINT32 NotMyAddressCount;
    static volatile UINT32 AlertErrCount;

    /* GHO_IRQHandler diagnostics: GhoEntryCount = total GPIO-edge entries;
     * GhoDummyReadHadDataCount = how many of those found a byte already
     * sitting in the UART data register at the moment of the unconditional
     * "dummy read to clear flags" — i.e. how often that read may have eaten
     * a genuine incoming byte instead of a stale/empty one. */
    static volatile UINT32 GhoEntryCount;
    static volatile UINT32 GhoDummyReadHadDataCount;

    /* Rolling capture of the last few raw byte-0 values (data + alert bit in
     * bit 8, as read from IOL_ReadByte()) that failed the alert-bit check.
     * Lets us see whether the "wrong" bytes look like structured/misaligned
     * protocol data (e.g. repeating or sequential patterns) versus genuinely
     * random electrical noise. */
    static volatile UINT16 LastAlertBytes[8];
    static volatile UINT8  LastAlertBytesIdx;

private:

    static const UINT8 LastCommand;
	static const CMDINFO aCmdInfo[];

    UINT16 ChecksumHi;
    UINT16 ChecksumLo;
    UINT8 CountErrorA;
    UINT8 CountErrorB;
    UINT8 ucIolId;
    UINT8 ucIolBA;
    UINT8 ucIolDPA;
    UINT8 ucIolDSA;    //when BA!= 0xFF, Dsa=BA
    UINT8 ucLastDSA;
    UINT8 ucMsgNumber;
    UINT8 ucIdxDump;
    UINT8 nCharProcd;
    UINT8 *pRcvBuffer;
    UINT8 xmit_buffer[IOL_MAXXMT_MSGSIZE+1];
    UINT8 ucDest;
	UINT8 ucNumber;
    UINT8 ucCommand;
    BOOL  bCommError;

#if IOL_BYT_DBG
    UINT16 TempBuff[64];
#endif

    BOOL NotMyAddress (UINT8 ucAddress)
    {
        return ((ucAddress != 0) && (ucAddress != ucIolDPA) && (ucAddress != ucIolDSA));
    }

    VOID Add2Checksum (UINT8 ucByte)
    {
        ChecksumLo += ucByte;
        if (ChecksumLo > 0xFF) ChecksumLo += 0xFF01;     // if carry, sub 256, add 1
        ChecksumHi += ChecksumLo;
        if (ChecksumHi > 0xFF) ChecksumHi += 0xFF01;     // if carry, sub 256, add 1
    }

    VOID StartNakResponse(PASTATUS ucNack) {

    	xmit_buffer[IOLMSG_DESTINATION] = pRcvBuffer[IOLMSG_SOURCE];
    	xmit_buffer[IOLMSG_NUMBER]      = aCmdInfo[IOLCMD_NACK].CountResp;
    	xmit_buffer[IOLMSG_SOURCE]      = pRcvBuffer[IOLMSG_DESTINATION];
    	xmit_buffer[IOLMSG_COMMAND]     = IOLCMD_NACK | 0x80;
    	xmit_buffer[IOLNAK_PASTAT]      = ucNack;
    	ComputeFletcher(xmit_buffer, FTYP_APPEND);

    	StartResponse();
    }

    VOID StartResponse(VOID) {

        /* Recover from a stale/incomplete TX state so the current response is not dropped. */
        if (nCharProcd != 0U) {
            IOL_TxInterrupt(FALSE);
            IOL_TxDoneInterrupt(FALSE);
            IOL_TxDisable();
            SetTXREQ_n(IOLDRV_OFF);
            nCharProcd = 0U;

            /* Flush any residual loopback bytes from the aborted TX sequence. */
            UINT16 flushCount = 0U;
            while (IOL_RxDatReady() && (flushCount < (UINT16)(IOL_MAXXMT_MSGSIZE + 2U))) {
                (void)IOL_ReadByte();
                flushCount++;
            }
        }

        // Always drain any leftover loopback bytes from previous complete transmissions
        // to prevent old RX data from interfering with the next request/response cycle.
        UINT16 staleDrainCount = 0U;
        while (IOL_RxDatReady() && (staleDrainCount < (UINT16)(IOL_MAXXMT_MSGSIZE + 10U))) {
            (void)IOL_ReadByte();
            staleDrainCount++;
        }

        nCharProcd = 0;                      // reset transmitted character count

        /* Block RX IRQ while transmitting; loopback bytes must be handled by TX path. */
        IOL_RxInterrupt(FALSE);

        SetTXREQ_n(IOLDRV_ON);               // turn on RS-485 transmitter to tx

        IOL_TxEnable();						 // enable transmitter

        while(!IOL_TxBufEmpty());            // Wait TX data register ready

        IOL_WriteByte(xmit_buffer[nCharProcd++], IOL_ALERT_XMIT_ADDR);	// send address with 9th bit set

        IOL_TxInterrupt(TRUE);
    }

    // IOLink ISR methods (called from extern "C" handlers)
	static VOID Rcvr(VOID);
	static VOID Xmit(VOID);
	static VOID XmitEnd(VOID);

    VOID ResetSilenceTimer(UINT32 uwTimeOut)
    {
        SilenceTimerStop();
        SilenceTimerReset();
        SilenceTimerSetCount(uwTimeOut);
        SilenceTimerStart();

    }

    VOID StartGapTimer(VOID)
    {
        SilenceTimerStop();
        SilenceTimerReset();
        SilenceTimerStart();
    }

    VOID SetIolDSA(UINT8 ucNewDSA)
    {
        ucIolDSA = ucNewDSA;
        ucIolBA = 0xFF;
    }

    UINT8 ComputeFletcher(UINT8 *, FLETCHERACTION);
    VOID LossofCommShed(VOID);

    PASTATUS Cmd01Handler(VOID);
    PASTATUS Cmd04Handler(VOID);
    PASTATUS Cmd07Handler(VOID);
    PASTATUS Cmd08Handler(VOID);
    PASTATUS Cmd0AHandler(VOID);
    PASTATUS Cmd0BHandler(VOID);
    PASTATUS Cmd0CHandler(VOID);
    PASTATUS Cmd0FHandler(VOID);
    PASTATUS Cmd10Handler(VOID);
    PASTATUS Cmd16Handler(VOID);
    PASTATUS Cmd17Handler(VOID);
    PASTATUS Cmd1FHandler(VOID);
    PASTATUS Cmd20Handler(VOID);
    PASTATUS Cmd25Handler(VOID);
    PASTATUS Cmd26Handler(VOID);
    PASTATUS Cmd28Handler(VOID);
    PASTATUS Cmd2AHandler(VOID);
    PASTATUS Cmd2CHandler(VOID);
    PASTATUS Cmd2DHandler(VOID);
    PASTATUS Cmd2FHandler(VOID);
    PASTATUS Cmd32Handler(VOID);
    PASTATUS Cmd33Handler(VOID);
    PASTATUS Cmd35Handler(VOID);
    PASTATUS Cmd37Handler(VOID);
    PASTATUS DefaultHandler(VOID);
    PASTATUS BroadcastHandler(VOID);
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    PASTATUS ProcessDefWrCmd(VOID);
#endif

public:

    /* Diagnostic accessors for the redundancy channel comm-error counters
     * (see declaration below in the private section) — used to tell whether
     * a high Rcvr() ISR entry rate is mostly noise/framing errors versus
     * address-mismatch traffic from other nodes on the multi-drop bus. */
    UINT8 GetCountErrorA(VOID) { return CountErrorA; }
    UINT8 GetCountErrorB(VOID) { return CountErrorB; }

    VOID ResetDumpIndex(VOID) {ucIdxDump=0;}
    VOID DropDSA(VOID) {
        ucIolBA = 0xFF;
        ucIolDSA = 0;
        ucLastDSA = 0;
    }
    VOID SetIolBA(UINT8 ucNewBA) {
        ucIolBA = ucNewBA;
        ucIolDSA = (ucIolBA == 0xFF) ? 0 : ucIolBA;
    }
    ADDCHG AddressChange(VOID) {
        ADDCHG RetVal = ADDCHG_DROPPED;
        if (ucIolDSA == ucLastDSA) {
            RetVal = ADDCHG_NONE;
        }
        else if (ucLastDSA == 0) {
            RetVal = ADDCHG_NEW;
        }
        ucLastDSA = ucIolDSA;
        return RetVal;
    }
    BOOL AmPrimary(VOID) {
        BOOL bReturn = TRUE;
        if (ucIolDSA == 0) bReturn = FALSE;
        if (ucIolDSA == ucIolBA) bReturn = FALSE;
        return bReturn;
    }

    friend VOID GHO_IRQHandler(VOID);
    friend VOID SilenceTimer_IRQHandler(VOID);
    friend void BOARD_INITIOLINK_PINS_GHOIRQ_n_callback(void *param);

#if 1 // temp for testing
    VOID SetDSA(UINT8 ucNewDSA)
    {
        ucIolDSA = ucNewDSA;
        ucIolBA = 0xFF;
    }
#endif

}; //clsIol

extern clsIol Iol;

#endif // IOL_HPP
