/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : eeprom.cpp                                                  *
*    Description : Class clsEeprom implementation.                             *
*******************************************************************************/
#include "fsl_lpspi.h"
#include "utils.h"
#include "eeprom.hpp"

clsEeprom Eeprom;

clsEeprom::clsEeprom(VOID) {
#if LOWCOST
    EEP_CS = 1;
#else
    // Initialize FPGA Interrrupt registers (IE, GE)
    //EEPROM_SPI.CRL = 0x86;          // Enable SPI system in master manual mode.
    //EEPROM_SPI.CRH = 0x00;          // Enable master transaction.
    //EEPROM_SPI.SSR = SS_DESELECT;   // Deassert both slave selects.
#endif
}

VOID clsEeprom::EnableWrite(VOID) {

	// Flush FIFO, clear status, disable all the interrupts.
	LPSPI4->CR |= ((uint32_t)true << LPSPI_CR_RTF_SHIFT) | ((uint32_t)true << LPSPI_CR_RRF_SHIFT);
	LPSPI4->SR = kLPSPI_AllStatusFlag;

    //Assert slave select
	LPSPI4->TCR = (LPSPI_GetTcr(LPSPI4) & (~LPSPI_TCR_PCS_MASK)) | LPSPI_TCR_PCS((uint8_t)kLPSPI_Pcs1);
	LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) | LPSPI_TCR_CONT_MASK;

	// TCR also shares the FIFO, so wait for TCR written.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    //send the Write Enable to SPI EEPROM first
	LPSPI4->TDR = EEPROM_WREN; //Instruction for write Enable

    // Set the PCS back to uncontinuous to finish the transfer if all tx data are pushed to FIFO.
    LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) & ~LPSPI_TCR_CONT_MASK;

	// Wait until all transmit data is sent.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }
}

VOID clsEeprom::DisableWrite(VOID) {
	//   EEPROM_WP_n = 0;

	// Flush FIFO, clear status, disable all the interrupts.
	LPSPI4->CR |= ((uint32_t)true << LPSPI_CR_RTF_SHIFT) | ((uint32_t)true << LPSPI_CR_RRF_SHIFT);
	LPSPI4->SR = kLPSPI_AllStatusFlag;

	//Assert slave select
	LPSPI4->TCR = (LPSPI_GetTcr(LPSPI4) & (~LPSPI_TCR_PCS_MASK)) | LPSPI_TCR_PCS((uint8_t)kLPSPI_Pcs1);
	LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) | LPSPI_TCR_CONT_MASK;

	// TCR also shares the FIFO, so wait for TCR written.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
	}

	//send the Write Enable to SPI EEPROM first
	LPSPI4->TDR = EEPROM_WRDI; //Instruction for write Enable

	// Set the PCS back to uncontinuous to finish the transfer if all tx data are pushed to FIFO.
	LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) & ~LPSPI_TCR_CONT_MASK;

	// Wait until all transmit data is sent.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
	}
}

UINT8 clsEeprom::ReadStatusRegister(VOID) {

    uint8_t ucData = 0xFF;

	// Flush FIFO, clear status, disable all the interrupts.
	LPSPI4->CR |= ((uint32_t)true << LPSPI_CR_RTF_SHIFT) | ((uint32_t)true << LPSPI_CR_RRF_SHIFT);
	LPSPI4->SR = kLPSPI_AllStatusFlag;

    // Assert slave select
    LPSPI4->TCR = (LPSPI_GetTcr(LPSPI4) & (~LPSPI_TCR_PCS_MASK)) | LPSPI_TCR_PCS((uint8_t)kLPSPI_Pcs1);
    LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) | LPSPI_TCR_CONT_MASK;

	// TCR also shares the FIFO, so wait for TCR written.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    // write command to read status register
    LPSPI4->TDR = EEPROM_RDSR;                //Instruction for Status Reg read
    LPSPI4->TDR = 0;                          //send additional 8 clocks to get the data from EEPROM

    // Set the PCS back to uncontinuous to finish the transfer if all tx data are pushed to FIFO.
    LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) & ~LPSPI_TCR_CONT_MASK;

	// Wait until all transmit data is sent.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    // While receive FIFO is not empty
    while (((LPSPI4->FSR & LPSPI_FSR_RXCOUNT_MASK) >> LPSPI_FSR_RXCOUNT_SHIFT) != 0)
    {
        ucData = (uint8_t)LPSPI4->RDR;     // Get data from receive FIFO.
    }

    return ucData;
}

VOID clsEeprom::CheckWriteInProgress(VOID) {
    uint8_t ucData = 0xA5;
    uint8_t ucWaitCount = 10;  //wait max 10ms

    while(ucWaitCount) // Check if the WIP bit is reset
    {
        ucData = ReadStatusRegister();

        if(0 == (ucData & SPI_EEPROM_WIP))
        {
            ucWaitCount = 0;   // Exit
        }
        else
        {
            ucWaitCount--;

            // Idle wait for 1ms
            /*PITDrv::ClearTimerInterruptFlag(1);
            PITDrv::LoaduSecTimerValue(1, 1000);
            PITDrv::EnableTimer(1);
            while(!PIT_GetStatusFlags(DEMO_PIT_BASEADDR, kPIT_Chnl_0));
            PITDrv::ClearTimerInterruptFlag(1);
            PITDrv::DisableTimer(1);*/
        }
    }
}

UINT8 clsEeprom::ReadByte(uint16_t uAddress) {

    uint8_t ucData = 0x55;

	// Flush FIFO, clear status, disable all the interrupts.
	LPSPI4->CR |= ((uint32_t)true << LPSPI_CR_RTF_SHIFT) | ((uint32_t)true << LPSPI_CR_RRF_SHIFT);
	LPSPI4->SR = kLPSPI_AllStatusFlag;

    //Assert slave select
	LPSPI4->TCR = (LPSPI_GetTcr(LPSPI4) & (~LPSPI_TCR_PCS_MASK)) | LPSPI_TCR_PCS((uint8_t)kLPSPI_Pcs1);
	LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) | LPSPI_TCR_CONT_MASK;

	// TCR also shares the FIFO, so wait for TCR written.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    // Now send the read command
    if (uAddress < EEPROM_LOW_PAGE)
    {
        LPSPI4->TDR = EEPROM_RDLO;              //Instruction for read from addr < 255
    }
    else
    {
        LPSPI4->TDR = EEPROM_RDHI;              //Instruction for read from addr > 255
    }
    LPSPI4->TDR = (uint8_t)uAddress;            //send only last 8 Bits of Address.
    LPSPI4->TDR = 0;                            //send additional 8 clocks to get the data from EEPROM

    // Set the PCS back to uncontinuous to finish the transfer if all tx data are pushed to FIFO.
    LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) & ~LPSPI_TCR_CONT_MASK;

	// Wait until all transmit data is sent.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    // While receive FIFO is not empty
    while (((LPSPI4->FSR & LPSPI_FSR_RXCOUNT_MASK) >> LPSPI_FSR_RXCOUNT_SHIFT) != 0)
    {
        ucData = (uint8_t)LPSPI4->RDR;     // Get data from receive FIFO.
    }

    return ucData;
}

UINT16 clsEeprom::ReadUint16(UINT16 uAddress) {

    uint16_t Temp;
    Temp = ReadByte(uAddress+1);
    Temp <<= 8;
    Temp |= ReadByte(uAddress);
    return Temp;
}

UINT32 clsEeprom::ReadUint32(UINT16 uAddress) {

    DATABYTES DataBytes;

    for (uint8_t ucCount=0;ucCount < sizeof(uint32_t); ucCount++)
    {
        DataBytes.ucBytes[ucCount] = ReadByte(uAddress+ucCount);
    }

    return DataBytes.ui32Val;
}

FLOAT32 clsEeprom::ReadFloat(UINT16 uAddress) {

    DATABYTES DataBytes;

    for (uint8_t ucCount=0;ucCount < sizeof(float); ucCount++)
    {
        DataBytes.ucBytes[ucCount] = ReadByte(uAddress+ucCount);
    }

    return DataBytes.f32Val;
}

VOID clsEeprom::WriteByte(UINT16 uAddress, UINT8 ucData) {

    EnableWrite();

	// Flush FIFO, clear status, disable all the interrupts.
	LPSPI4->CR |= ((uint32_t)true << LPSPI_CR_RTF_SHIFT) | ((uint32_t)true << LPSPI_CR_RRF_SHIFT);
	LPSPI4->SR = kLPSPI_AllStatusFlag;

    //Assert slave select
	LPSPI4->TCR = (LPSPI_GetTcr(LPSPI4) & (~LPSPI_TCR_PCS_MASK)) | LPSPI_TCR_PCS((uint8_t)kLPSPI_Pcs1);
	LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) | LPSPI_TCR_CONT_MASK;

	// TCR also shares the FIFO, so wait for TCR written.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    // Now program the byte
    if (uAddress < EEPROM_LOW_PAGE)
    {
    	LPSPI4->TDR = EEPROM_WRLO;        //Instruction for write from addr < 255
    }
    else
    {
    	LPSPI4->TDR = EEPROM_WRHI;        //Instruction for write from addr > 255
    }
    LPSPI4->TDR = (uint8_t)uAddress;        //send only last 8 Bits of Address.
    LPSPI4->TDR = (uint8_t)ucData;          //send data to be written

    // Set the PCS back to uncontinuous to finish the transfer if all tx data are pushed to FIFO.
    LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) & ~LPSPI_TCR_CONT_MASK;

	// Wait until all transmit data is sent.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }
}

UINT16 clsEeprom::ComputeEepromChecksum(VOID) {

    uint16_t index = 0;
    uint16_t uChksum = 0;
    uint16_t NumBytes = MAX_EEPROM_SIZE-2;  // Number of bytes to checksum
    for (index = 0; index < NumBytes; index++)
    {
        uChksum ^= (ReadUint16(index));
        uChksum >>= 1;  // rotate right once
        index++;    // increment the index so that address and count macthes.
    }
    return(uChksum);
}

BOOL clsEeprom::ValidateEepromChecksum(VOID) {

    //Calculate the checksum
    uint16_t uChksum = ComputeEepromChecksum();
    if (ReadUint16(EEPROM_CHKSM_ADDR_END) == uChksum)
        return true;
    else
        return false;
}

VOID clsEeprom::WriteData(UINT16 a_RegisterAddress, UINT8 * a_pWriteBuffer, UINT16 a_Size)
{
    //Find the last address we will write to
    const unsigned int endAddress = a_RegisterAddress + a_Size - 1;

    //Initialize our current address
    unsigned int currentRegAddr = a_RegisterAddress;

    //EEPROM has 16bit pages. Can only write to one page during a single write cycle.
    //Determine number of pages we plan to write to
    unsigned int pages = ((a_RegisterAddress + a_Size)>>4) - ((a_RegisterAddress)>>4) + 1;
    int a = 0;
    for (unsigned int i = 0; i < pages; ++i)
    {
        //How much space do we have left to fulfill our contract
        unsigned int sizeRemaining = endAddress - currentRegAddr + 1;

        //Initialize size to be space left until end of page
        unsigned int size = 0x10 - (currentRegAddr & 0x0F);

        //Take the lower of the two sizes
        if ( size > sizeRemaining )
        {
            size = sizeRemaining;
        }

        // the memory address is 10-bit, therefore the 2 MSBs of the memory address
        // are provided in the I2C address byte

        WriteByte(currentRegAddr, a_pWriteBuffer[a]);
        currentRegAddr += 8;
        a_pWriteBuffer += 8;
        a++;

        WriteByte(currentRegAddr, a_pWriteBuffer[a]);
        currentRegAddr += 8;
        a_pWriteBuffer += 8;
        a++;
    }
}

