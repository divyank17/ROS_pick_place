////////////////////////////////////////////////////////////////////////////////
//                         CSysE, Fort Washington, PA.                        //
//                                                                            //
//                             COPYRIGHT (C) 2004                             //
//                HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                //
//                             ALL RIGHTS RESERVED                            //
//                                                                            //
// This software is a copyrighted work and / or information protected as a    //
// trade secret.  Legal rights of Honeywell Inc. in this software is distinct //
// from ownership of any medium in which the software is embodied. Copyright  //
// or trade secret notices included must be reproduced in any copies that are //
// authorized by Honeywell Inc.                                               //
//                                                                            //
// The information in this software is subject to change without notice and   //
// should not be considered as a commitment by Honeywell Inc.                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//   File Name   : adc.hpp                                                    //
//   Description : Analog to Digital Converter class definition file          //
////////////////////////////////////////////////////////////////////////////////
#ifndef __ADC_HPP__
#define __ADC_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
//#include "datatype.h"
//#include "global.h"
//#include "commonelectronics.h"

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef struct tagHiLoLimits {
    FLOAT32 fHiLimit;
    FLOAT32 fLoLimit;
} HILOLIMITS;

/*******************************************************************************
*                          LPSPI4 (ADC SPI) CONFIGURATION                     *
*                                                                              *
*  Pin mapping (from pin_mux.c):                                               *
*    LPSPI4_SCK   — GPIO_EMC_32  (pad 124)                                    *
*    LPSPI4_PCS0  — GPIO_EMC_33  (pad 123)   chip-select to ADC               *
*    LPSPI4_SDO   — GPIO_EMC_34  (pad 122)   MOSI                             *
*    LPSPI4_SDI   — GPIO_EMC_35  (pad 121)   MISO                             *
*                                                                              *
*  SPI Configuration:                                                          *
*    Mode:    CPOL=0, CPHA=0 (SPI Mode 0), 8-bit frames, MSB first            *
*    Clock:   4 MHz                                                            *
*    CS:      PCS0, active-low                                                 *
*******************************************************************************/
#define ADC_SPI_BASE        LPSPI4
/* LPSPI functional clock root actually feeding LPSPI4 (see board/clock_config.c:
 * CLOCK_SetMux(kCLOCK_LpspiMux, 2) -> SysPllClk, CLOCK_SetDiv(kCLOCK_LpspiDiv, 4)
 * -> divide by 5), NOT the USB1 PLL PFD0 clock. Using the wrong source here
 * causes LPSPI_MasterInit() to mis-calculate the baud-rate/delay dividers. */
#define ADC_SPI_CLOCK_FREQ  CLOCK_GetClockRootFreq(kCLOCK_LpspiClkRoot)
#define ADC_SPI_BAUDRATE    4000000u   /* 4 MHz */
#define ADC_SPI_PCS         kLPSPI_Pcs0

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8 IN_REF0   = 0;
const UINT8 IN_CHAN01 = 1;
const UINT8 IN_CHAN02 = 2;
const UINT8 IN_CHAN03 = 3;
const UINT8 IN_CHAN04 = 4;
const UINT8 IN_CHAN05 = 5;
const UINT8 IN_CHAN06 = 6;
const UINT8 IN_CHAN07 = 7;
const UINT8 IN_CHAN08 = 8;
const UINT8 IN_CHAN09 = 9;
const UINT8 IN_CHAN10 = 10;
const UINT8 IN_CHAN11 = 11;
const UINT8 IN_CHAN12 = 12;
const UINT8 IN_CHAN13 = 13;
const UINT8 IN_CHAN14 = 14;
const UINT8 IN_CHAN15 = 15;
const UINT8 IN_CHAN16 = 16;
const UINT8 IN_CKVT1  = 17;
const UINT8 IN_CKVT2  = 18;
const UINT8 IN_CKVT3  = 19;
const UINT8 IN_CKVT41 = 20;
const UINT8 IN_CKVT52 = 21;
const UINT8 IN_CKVT5  = 22;
const UINT8 IN_CALIB  = 23;
const UINT8 TOTALINPUTS  = IN_CALIB+1;

const UINT16 NORMAL_MUX_SETTLE_TIME      = 200;   // In units of microseconds.
const UINT16 CALIBRATION_MUX_SETTLE_TIME = 10000; // In units of microseconds.
const UINT16 MAXIMUM_ADCOUNT             = 0xFFFF;

// Reference constants for Pass 1 boards. Corresponds to the divider ratio of 0.95 before ADC.
// Zero Reference : Ranges from 55 to 75 mV. Zero reference average is 65 mV.
const UINT16 PASS1_ZERO_REF_HILIMIT = 933; // floor(75 * 0.95 * 65535 / 5000) = floor(933.87375)
const UINT16 PASS1_ZERO_REF_LOLIMIT = 685; // ceil(55 * 0.95 * 65535 / 5000) = ceil(684.84075)
// 1V calib input : Ideal count = (1000 + 65) * 0.95 * 65535 / 5000 = 13261.00725
const UINT16 PASS1_ONE_VOLT_HILIMIT = 14587; // floor(13261.00725 + 10%) = floor(14587.107975)
const UINT16 PASS1_ONE_VOLT_LOLIMIT = 11935; // ceil(13261.00725 - 10%) = ceil(11934.906525)
// 5V calib input : Ideal count = (5000 + 65) * 0.95 * 65535 / 5000 = 63067.60725
const UINT16 PASS1_FIVE_VOLT_HILIMIT = 65534; // Clamped at 0xFFFE as 63067.60725 + 10% = 69374.367975
const UINT16 PASS1_FIVE_VOLT_LOLIMIT = 56761; // ciel(63067.60725 - 10%) = ciel(56760.846525)
// NaN threshold (40 mV) : Count = (40 + 65) * 0.95 * 65535 / 5000 = 1307.42325
const UINT16 PASS1_INPUT_NAN_COUNT = 1307; // floor(1307.42325)
// Input deadbad bias (10 mV) : Count = (10) * 0.95 * 65535 / 5000 = 124.5165
const UINT16 PASS1_INPUT_DEADBAND_BIAS = 124; // floor(124.5165)

// Reference constants for Pass 2 boards. Corresponds to the divider ratio of 0.857 before ADC.
// Zero Reference : Ranges from 5 to 20 mV. Zero reference average is 12.5mV.
const UINT16 PASS2_ZERO_REF_HILIMIT = 224; // floor(20 * 0.857 * 65535 / 5000) = floor(224.65398)
const UINT16 PASS2_ZERO_REF_LOLIMIT = 57;  // ciel(5 * 0.857 * 65535 / 5000) = ciel(56.163495)
// 1V calib input : Ideal count = (1000 + 12.5) * 0.857 * 65535 / 5000 = 11373.1077375
const UINT16 PASS2_ONE_VOLT_HILIMIT = 12510; // floor(11373.1077375 + 10%) = floor(12510.41851125)
const UINT16 PASS2_ONE_VOLT_LOLIMIT = 10236; // ciel(11373.1077375 - 10%) = ciel(10235.79696375)
// 5V calib input : Ideal count = (5000 + 12.5) * 0.857 * 65535 / 5000 = 56303.9037375
const UINT16 PASS2_FIVE_VOLT_HILIMIT = 61934; // floor(56303.9037375 + 10%) = floor(61934.29411125)
const UINT16 PASS2_FIVE_VOLT_LOLIMIT = 50674; // ciel(56303.9037375 - 10%) = ciel(50673.51336375)
// NaN threshold (40 mV) : Count = (40 + 12.5) * 0.857 * 65535 / 5000 = 589.7166975
const UINT16 PASS2_INPUT_NAN_COUNT = 589; // floor(589.7166975)
// Input deadbad bias (10 mV) : Count = (10) * 0.857 * 65535 / 5000 = 112.32699
const UINT16 PASS2_INPUT_DEADBAND_BIAS = 112; // floor(112.32699)


const UINT8 NO_OF_REF_VOLTAGES = 6;
const HILOLIMITS REFVOLTAGE_LIMITS[NO_OF_REF_VOLTAGES] = {
    0.114912, 0.097888, // CHVT1  : (0.1064 + 8%), (0.1064 - 8%)
    0.289848, 0.267552, // CKVT2  : (0.2787 + 4%), (0.2787 - 4%)
    0.758680, 0.700320, // CKVT3  : (0.7295 + 4%), (0.7295 - 4%)
    1.875640, 1.731360, // CKVT41 : ((1.9099 - 0.1064) + 4%), ((1.9099 - 0.1064) - 4%)
    4.910152, 4.532448, // CKVT52 : ((5.0000 - 0.2787) + 4%), ((5.0000 - 0.2787) - 4%)
    5.200000, 4.800000  // CKVT5  : (5.0000 + 4%), (5.0000 - 4%)
};

class ClsAdc; //forward declaration
/*******************************************************************************
*                                    clsAdc                                    *
*                                    ======                                    *
*******************************************************************************/
class ClsAdc {

    static const UINT8 aInputSelect[];

public:
    ClsAdc(VOID) {
        // Initialize FPGA Interrrupt registers (IE, GE)
        //ADC_SPI.CRL = 0x86; // Enable SPI system in master manual mode.
        //ADC_SPI.CRH = 0x00; // Enable master transaction.
        //ADC_SPI.SSR = 0xFF; // Deassert both slave selects.
    }
    ~ClsAdc(VOID) { HardFail(HF_INVPROGRAMEXEC, ADC_HPP, __LINE__); }

    //VOID *operator new (SIZE_T)  { return NULL; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC, ADC_HPP, __LINE__); }

    VOID Init(VOID);
    VOID Connect(UINT8 Channel);
    UINT16 GetRawData(UINT8, UINT16 a_uiWaitTime = NORMAL_MUX_SETTLE_TIME);

};  // ClsAdc

extern ClsAdc Adc;

#endif /* __ADC_HPP__ */
