/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : global.h                                                    *
*    Description : Global enumerations and constants for all IOMs.             *
*                  Stripped to AIH-only (no multi-module conditionals).        *
*******************************************************************************/
#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#include <cmath>
#include "productdefs.h"
#include "datatype.h"
#include "softfail.h"

using namespace std;

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/

/* IOL Data types */
typedef enum tagDataType {
    DT_UINT8    = 0,   // SUSI
    DT_UINT16   = 1,   // USGI
    DT_INT16    = 2,   // SIGI
    DT_INT32    = 3,   // DPSI
    DT_FLOAT32  = 4,   // REAL
    DT_FLOAT64  = 5,   // REAL
    DT_BOOL     = 6,   // BOOL
#if !defined (IOPTYPE_SCIOM)
    // for redesign PMIO
    DT_STRG     = 11,  // ASCII STRING
#endif
    DT_ENUM     = 12,  // STEN
    DT_SDENUM   = 13,  // SDEN
    DT_BLIND    = 14,  // BLND
    DT_UINT32   = 254, // DPUI
    DT_NONE     = 255
} DATATYPE;

/* Parameter table access types — controls read/write dispatch behavior.
   These match the original H8S Experion database access type byte.
   AT_SBYTE = single byte, AT_MBYTE = multi-byte, AT_PSET = parameter set,
   AT_BXPACK = box-packed bitmap, AT_BXREC = box blind record. */
typedef enum tagAccessType {
    AT_NONE   = 0, // Access type undefined.
    AT_SBYTE  = 1, // Single byte parameter.
    AT_MBYTE  = 2, // Multi byte parameter.
    AT_PSET   = 3, // Parameter set access.
    AT_BXPACK = 4, // Bool parameter from all slots kept as a packed bitmap in box database.
    AT_BXREC  = 5, // Parameter data from all slots kept as a blind record in box database.
    AT_BITPACK = 6 // Parameter data is bit packed and accessed using a bit index.
} ACCESSTYPE;

/*******************************************************************************
*                         IOL PROTOCOL ENUMERATIONS                            *
*******************************************************************************/

/* IOL PASTATUS return codes */
typedef enum tagPAStatus {
    PA_NULL                                              = 0,
    DO_VALUE_CLAMPED_ERROR                               = 1,
    PA_STRING_TRUNCATED_ON_STORE_ERROR                   = 2,
    DO_INITIALIZATION_WARNING                            = 3,
    DO_SLOT_CHECKPOINT_PARTIALLY_RESTORED                = 4,
    DO_UCN_NUM_FAST_POINTS_CLAMPED                       = 5,
    DO_DATA_OVERLAPS_WITH_OTHER_ARRAY_POINT_DATA_WARNING = 6,
    PA_OK                                                = 12,
    IOL_COMM_ERROR_START                                 = 13,
    IOL_ALERT                                            = 14,
    IOL_DEST                                             = 15,
    IOL_CHRCT                                            = 16,
    IOL_SRC                                              = 17,
    IOL_COMM                                             = 18,
    IOL_CHKSM                                            = 19,
    IOL_NORSP                                            = 20,
    IOL_CHRTM                                            = 21,
    IOL_ORUN                                             = 22,
    IOL_GAP                                              = 23,
    IOL_LPBK                                             = 24,
    IOL_NTH_0                                            = 25,
    IOL_RCVTKN                                           = 26,
    IOL_RPLBUFOV                                         = 27,
    IOL_TKNTMOUT                                         = 28,
    IOL_RESOURCE_ERROR_START                             = 29,
    IOL_WM_IN_PROGRESS                                   = 30,
    IOL_RCVBUFOV                                         = 31,
    IOL_REMOTE_FETCH_PENDING                             = 32,
    IOL_SPARE014                                         = 33,
    IOL_SPARE015                                         = 34,
    DO_END_OF_HISTORY_DATA_FILE                          = 35,
    DO_END_OF_USER_SPECIFIED_SAMPLES_OR_TIME             = 36,
    DO_USER_ALLOCATED_BUFFER_FULL                        = 37,
    PA_TVR_TOO_SMALL                                     = 38,
    DO_ACCESS_LEVEL_INVALID                              = 39,
    DO_CALIB_IN_PROGRESS                                 = 40,
    DO_CHANGE_NOT_PERMITTED_BY_OPERATOR                  = 41,
    DO_CHECK_POINT_IN_PROGRESS                           = 42,
    DO_CHRC_DATA_BAD                                     = 43,
    DO_COMMAND_NOT_SUPPORTED                             = 44,
    DO_CONFIGURATION_MISMATCH_ERROR                      = 45,
    DO_CONTROL_OUTPUT_CONNECTION_NOT_CONFIGURED          = 46,
    DO_DATA_TYPE_ERROR                                   = 47,
    DO_ENGR_UNIT_SPAN_TOO_SMALL                          = 48,
    DO_EXTERNAL_MODE_SWITCHING_ENABLED                   = 49,
    DO_FUNCTION_NOT_IMPLEMENTED                          = 50,
    DO_ILLEGAL_VALUE                                     = 51,
    DO_INITIALIZATION_ERROR                              = 52,
    DO_INVALID_ALGORITHM_EQUATION                        = 53,
    DO_INVALID_DESTINATION_PARAMETER                     = 54,
    DO_INVALID_DESTINATION_POINT_ID                      = 55,
    DO_INVALID_MODE                                      = 56,
    DO_INVALID_MODE_ATTRIBUTE                            = 57,
    DO_INVALID_NORMAL_MODE                               = 58,
    DO_INVALID_NUMBER_OF_CTL_INPUTS                      = 59,
    DO_INVALID_NUMBER_OF_CTL_OUTPUTS                     = 60,
    DO_INVALID_NUMBER_OF_PV_INPUTS                       = 61,
    DO_INVALID_PNTYP_FOR_IOL_PF                          = 62,
    DO_INVALID_PNTYP_FOR_IOL_PS                          = 63,
    DO_INVALID_SLOT_INDEX                                = 64,
    DO_INVALID_SLOT_TYPE                                 = 65,
    DO_INVALID_TARGET_VALUE_PROCESSOR_STATE              = 66,
    DO_MAX_IOL_PF_CONNECTIONS_EXCEEDED                   = 67,
    DO_MAX_IOL_PS_CONNECTIONS_EXCEEDED                   = 68,
    DO_LIMIT_OR_RANGE_CROSSOVER                          = 69,
    DO_LIMIT_OR_RANGE_EXCEEDED                           = 70,
    DO_MAX_AVAILABLE_MEMORY_EXCEEDED                     = 71,
    DO_MAX_POINT_PROCESSING_RATE_EXCEEDED                = 72,
    DO_MODE_MUST_BE_MANUAL                               = 73,
    DO_MODE_NOT_MAN_OR_POINT_ACTIVE                      = 74,
    DO_NO_PF_CONNECTIONS_FOR_SELECTED_SLOT               = 75,
    DO_NORMAL_ATTRIBUTE_NOT_CONFIGURED                   = 76,
    DO_NORMAL_MODE_IS_NOT_CONFIGURED                     = 77,
    DO_ONLY_ONE_CONNECTION_ALLOWED_TO_IOL                = 78,
    DO_PARAMETER_CAN_NOT_BE_CHANGED                      = 79,
    DO_PARAMETER_ID_ERROR                                = 80,
    DO_PARAMETER_INVALID                                 = 81,
    DO_PARAMETER_TYPE_INVALID                            = 82,
    DO_PF_BUFFER_OVERFLOW                                = 83,
    DO_PS_BUFFER_OVERFLOW                                = 84,
    DO_PTEXECST_OR_MODLSTAT_INCONSISTENT                 = 85,
    DO_POINT_IN_ALARM                                    = 86,
    DO_POINT_IS_LOCAL_MANUAL                             = 87,
    DO_POINT_IS_RED_TAGGED                               = 88,
    DO_POINT_MUST_BE_INACTIVE                            = 89,
    DO_POINT_MUST_BE_INACTIVE_OR_IDLE                    = 90,
    DO_PPX_TASK_NOT_STARTED                              = 91,
    DO_PPX_TASK_NOT_TERMINATED                           = 92,
    DO_PVSOURCE_INVALID                                  = 93,
    DO_READ_ONLY_PARAMETER                               = 94,
    DO_SECONDARY_HAS_TOO_MANY_PRIMARIES                  = 95,
    DO_SLOT_INVALID                                      = 96,
    DO_SOURCE_OF_REQUEST_INVALID                         = 97,
    DO_STATE_MUST_BE_IDLE                                = 98,
    DO_STATE_MUST_BE_RUN                                 = 99,
    DO_STORE_NOT_ALLOWED_WITH_SPC_CONNECTION             = 100,
    DO_UMSCANRT_MUST_BE_NULL                             = 101,
    DO_UMSCANRATE_MUST_NOT_BE_NULL                       = 102,
    DO_WM_INVALID                                        = 103,
    DO_WM_INSUF_DATA                                     = 104,
    DO_WM_INVALID_ST                                     = 105,
    DO_WRONG_POINT_TYPE_FOR_MODULE                       = 106,
    DO_POINT_IS_SHUTDOWN                                 = 107,
    DO_HPN_SCAN_TBL_OVERFLOW                             = 108,
    DO_CALCULTR_SYNTAX_ERROR                             = 109,
    DO_CALCULTR_EXPR_TOO_BIG                             = 110,
    DO_PERMISSIVE_ERROR                                  = 111,
    DO_INTERLOCK_ERROR                                   = 112,
    DO_HPN_COM_ERROR                                     = 113,
    DO_ENTITY_ID_ERROR                                   = 114,
    DO_SLOT_CHECKPOINT_EXCEEDS_AVAILABLE_EXTENSION_MEMORY= 115,
    DO_INVALID_STATE_PA_STATUS                           = 116,
    DO_INVALID_FOR_SECONDARY_PA_STATUS                   = 117,
    DO_CHECKSUM_BAD                                      = 118,
    DO_INVALID_SEQUENCE_EXECUTION_STATE                  = 119,
    DO_INVALID_PROCESS_MODULE_STATE                      = 120,
    DO_ABNORMAL_HANDLER_NOT_AVAILABLE                    = 121,
    DO_SEQUENCE_PROGRAM_MUST_BE_LOADED                   = 122,
    DO_SEQUENCE_PROGRAM_EXCEEDS_CONFIGURED_SLOT_SIZE     = 123,
    DO_NO_CONFIRMABLE_MESSAGE_PENDING                    = 124,
    DO_FATAL_SEQUENCE_CODE_ERROR                         = 125,
    DO_CHECKPOINT_REV_CODE_ERROR                         = 126,
    DO_CANNOT_LEAVE_SCOPE_OF_NORMAL                      = 127,
    DO_CANNOT_LEAVE_SCOPE_OF_ABNORMAL                    = 128,
    DO_CANNOT_LEAVE_CURRENT_BLOCK                        = 129,
    DO_CANNOT_LEAVE_CURRENT_STEP                         = 130,
    DO_SEQUENCE_PROGRAM_INVALID_DEST_NODE_TYPE           = 131,
    DO_CL_COMPILER_VERSION_OR_REVISION_ERROR             = 132,
    DO_SEQUENCE_DLL_PACKET_OUT_OF_ORDER                  = 133,
    DO_CANNOT_LEAVE_CURRENT_PHASE                        = 134,
    DO_RETRY                                             = 135,
    DO_IOL_PS_REQUESTED                                  = 136,
    DO_PRIOR_FUNCTION_NOT_COMPLETE                       = 137,
    DO_CANNOT_OBTAIN_PLC_PROGRAM_MODE                    = 138,
    DO_PLC_WRITE_FAILED                                  = 139,
    DO_PLC_READ_FAILED                                   = 140,
    DO_PLC_READ_COMPLETE                                 = 141,
    DO_ILLEGAL_LM_REDUNDANCY_STATE                       = 142,
    DO_ARRAY_MAPPING_VIOLATION                           = 143,
    PA_COMMUNICATION_ERROR                               = 144,
    HPN_ENCODE_ERROR                                     = 145,
    HPN_RECEPTION_ERROR                                  = 146,
    HPN_TRANSMIT_ERROR                                   = 147,
    DO_DB_NOT_VALID                                      = 148,
    DO_SWAP_FAIL                                         = 149,
    PA_LM_PAF_OVERFLOW                                   = 150,
    DO_IOL_SCAN_MAX_LIMIT_EXCEEDED                       = 151,
    DO_IOL_SCAN_CYCLE_LIMIT_EXCEEDED                     = 152,
    DO_ERROR_CMD_NOT_VALID_FOR_ON_PROCESS_PERSONALITY    = 153,
    DO_ERROR_CMD_NOT_VALID_FOR_SIMULATION_PERSONALITY    = 154,
    DO_STATE_MUST_BE_PAUSE                               = 155,
    DO_STATE_MUST_BE_RUN_OR_PAUSE                        = 156,
    DO_STATE_MUST_BE_IDLE_OR_PAUSE                       = 157,
    COM_DBIF_ERROR                                       = 158,
    COM_CTL_RQST_ERROR                                   = 159,
    COM_DEV_TMOT_ERROR                                   = 160,
    COM_DEV_FAIL_ERROR                                   = 161,
    COM_FTA_MISSING_ERROR                                = 162,
    COM_SPARE04_ERROR                                    = 163,
    COM_SPARE05_ERROR                                    = 164,
    COM_SPARE06_ERROR                                    = 165,
    COM_SPARE07_ERROR                                    = 166,
    COM_SPARE08_ERROR                                    = 167,
    DO_DELETE_NOT_ALLOWED_WHILE_FUNC_BLOCKS_ASSIGNED     = 168,
    DO_CONTROL_OUTPUT_WRITE_NOT_PERMITTED                = 169,
    DO_LC_ADDRESS_ALIAS_MISMATCH                         = 170,
    DO_WRITES_NOT_PERMITTED                              = 171,
    DO_PARAMETER_INDEX_INVALID                           = 172,
    DO_MAX_CONNECTIONS_EXCEEDED                          = 173,
    DO_FILES_INCOMPATIBLE                                = 174,
    DO_INVALID_TARGET                                    = 175,
    DO_STATE_MUST_BE_IDLE_OR_RUN                         = 176,
    DO_CANNOT_REDUCE_SLOTS_POINTS_EXIST_IN_NIM           = 177,
    XX_SPARE178_ERROR                                    = 178,
    XX_SPARE179_ERROR                                    = 179,
    FB_FMS_INITIATE_ERR                                  = 180,
    FB_FMS_VFD_ERR                                       = 181,
    FB_FMS_APPL_ERR                                      = 182,
    FB_FMS_DEF_ERR                                       = 183,
    FB_FMS_RESOURCE_ERR                                  = 184,
    FB_FMS_SERVICE_ERR                                   = 185,
    FB_FMS_ACCESS_ERR                                    = 186,
    FB_FMS_OD_ERR                                        = 187,
    FB_FMS_OTHER_ERR                                     = 188,
    FB_NMA_COMREF_ERR                                    = 189,
    FB_SYSMANAGE_ERR                                     = 190,
    FB_LOADER_ERR                                        = 191,
    FB_STARTUP_ERR                                       = 192,
    FB_RUNTIME_ERR                                       = 193,
    FB_STACK_ERR                                         = 194,
    FB_FIL_ERR                                           = 195,
    FB_CCR_BUSY                                          = 196,
    FB_NO_SEG_CCRS_AVAILABLE                             = 197,
    FB_FIL_DATASIZE_RETURNED_DOES_MATCH_DB               = 198,
    FB_UNEXPECTED_FBREQ_STATE                            = 199,
    PA_OK_NO_DATA                                        = 200,
    PA_PS_INVLD_HNDL                                     = 201,
    PA_PS_BUSY                                           = 202,
    PA_PS_RUNNING                                        = 203,
    PA_PS_INITIATING                                     = 204,
    PA_PS_DEAD                                           = 205,
    PA_PS_SUCCESS                                        = 206,
    PA_PS_INVLD_MSGNO                                    = 207,
    PA_PS_DUPL_HNDL                                      = 208,
    PA_PS_ACQRD_HNDL                                     = 209,
    PA_PS_SPLTMSG_ERR                                    = 210,
    DO_FWIOMMISMATCH_ERROR                               = 211,
    DO_FWSESSIONTMOUT_ERROR                              = 212,
    DO_FLASHPROGRAM_ERROR                                = 213,
    DO_FLASHERASE_ERROR                                  = 214,
    DO_FWFRMMISMATCH_ERROR                               = 215,
    DO_FLASH_PROG_ERASE_DOWNLD_ERROR                     = 216,
    DO_FLASH_INIT_ERROR                                  = 217,
    DO_CALIBVAL_WRITE_NOT_ALLOWED                        = 218,
    DO_SVPREGCTL_BLOCK_IS_INACTIVE                       = 219,
    DO_POINT_IS_IN_BADCTL                                = 220,
    DO_LOAD_BOOT_FIRST                                   = 221,
    DO_FPGA_APP_IMAGE_BAD                                = 222,
    DO_TOL_LIMIT_EXCEEDED                                = 223,
    DO_SVPREGCTL_BLOCK_IN_BADCTL                         = 224,
    DO_STEP_ALREADY_DONE                                 = 225,
    DO_IOM_NOT_SYNCHED                                   = 226,
    DO_CONFIG_NOT_SUP_WITH_DUALCOIL                      = 227,
    PA_REDDATA_BYPASS                                    = 0xFF
} PASTATUS;

typedef enum tagControlState {
    CONTROLSTATE_NONE           = 0,
    CONTROLSTATE_INACTIVE       = 1,
    CONTROLSTATE_INACTIVEORIDLE = 2,
    CONTROLSTATE_ACTIVEANDRUN   = 3
} CONTROLSTATE;

typedef enum tagOnOff{
    OFF = 0,
    ON  = 1
} ONOFF;

typedef enum tagContext {
    CONTEXT_ZERO     = 0,
    CONTEXT_ONE      = 1,
    CONTEXT_TWO      = 2,
    CONTEXT_THREE    = 3,
    CONTEXT_FOUR     = 4,
    CONTEXT_FIVE     = 5,
    CONTEXT_SIX      = 6,
    CONTEXT_SEVEN    = 7,
    CONTEXT_EIGHT    = 8,
    CONTEXT_NINE     = 9,
    CONTEXT_TEN      = 10,
    CONTEXT_ELEVEN   = 11,
    CONTEXT_TWELVE   = 12,
    CONTEXT_THIRTEEN = 13,
    CONTEXT_FOURTEEN = 14,
    CONTEXT_FIFTEEN  = 15,
    CONTEXT_SIXTEEN   = 16,
    CONTEXT_SEVENTEEN = 17,
    CONTEXT_EIGHTEEN  = 18,
    CONTEXT_NINETEEN  = 19,
    CONTEXT_TWENTY    = 20,
    CONTEXT_TWENTYONE   = 21,
    CONTEXT_TWENTYTWO   = 22,
    CONTEXT_TWENTYTHREE = 23,
    CONTEXT_TWENTYFOUR  = 24,
    CONTEXT_TWENTYFIVE  = 25,
    CONTEXT_TWENTYSIX   = 26,
    CONTEXT_TWENTYSEVEN = 27,
    CONTEXT_TWENTYEIGHT = 28,
    CONTEXT_TWENTYNINE  = 29,
    CONTEXT_THIRTY      = 30,
    CONTEXT_THIRTYONE   = 31,
    CONTEXT_THIRTYTWO   = 32,
    CONTEXT_THIRTYTHREE = 33,
    CONTEXT_THIRTYFOUR  = 34,
    CONTEXT_THIRTYFIVE  = 35
} CONTEXT;

/* Return status for multi-step operations */
typedef enum tagReturnStatus {
    RETURNSTATUS_COMPLETE    = 0,
    RETURNSTATUS_INPROGRESS  = 1
} RETURNSTATUS;

// Access Lock Constant Definitions
typedef enum tagAccessLock {
    ALCK_VIEW  = 0x00,      // 0000 0000    kViewOnlyLock
    ALCK_IUSER = 0x01,      // 0000 0001    kIntimateUserLock
    ALCK_UMCC  = 0x03,      // 0000 0011
    ALCK_PBD   = 0x05,      // 0000 0101    kAppDevOnlyLock
    ALCK_CC    = 0x09,      // 0000 1001    kControlLock
    ALCK_EPB   = 0x25,      // 0010 0101    kEngineerAppDevLock
    ALCK_ENGR  = 0x3F,      // 0011 1111    kEngineerOnlyLock
    ALCK_SUPR  = 0x7F,      // 0111 1111    kSupervisorLock
    ALCK_OPER  = 0xFF,      // 1111 1111    kOperatorLock
    ALCK_PROG  = 0x1F       // 0001 1111    kProgramLock
} ACCESSLOCK;

// Access Level Constant Definitions
typedef enum tagAccessLevel {
    ALVL_OPER  = 0x80,      // 1000 0000    kOperator
    ALVL_SUPR  = 0x40,      // 0100 0000    kSupervisor
    ALVL_ENGR  = 0x20,      // 0010 0000    kEngineer
    ALVL_PROG  = 0x10,      // 0001 0000    kProgramAccLevel
    ALVL_CC    = 0x08,      // 0000 1000    kContControl
    ALVL_PBD   = 0x04,      // 0000 0100    kAppDeveloper
    ALVL_UMCC  = 0x02,      // 0000 0010    kUmContControl
    ALVL_IUSER = 0x01,      // 0000 0001    kIntimateUser
    ALVL_VIEW  = 0x00       // 0000 0000    kViewOnly
} ACCESSLEVEL;

typedef enum tagHartLpBkStat {
    LOOPBACK_SUCCESS = 0x00,
    LOOPBACK_INIT    = 0x01,
    LOOPBACK_RUNNING = 0x02,
    LOOPBACK_WARNING = 0x03
} HARTLPBKSTAT;


typedef struct tagCheckPointVerTable {
    const UINT8 *CheckPointPtr;
    UINT8 CheckPointSize;
} CHECKPOINT_VER_TABLE;

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8 ALCK_ONPROC             = ALVL_ENGR | ALVL_SUPR | ALVL_OPER;    //  1110 0000   kHumanLock
const UINT8 ALCK_ONPROC_PBD         = ALCK_ONPROC | ALVL_PBD;               //  1110 0100
const UINT8 ALCK_ONPROC_IUSER       = ALCK_ONPROC | ALVL_IUSER;             //  1110 0001
const UINT8 ALCK_PROG_UMCC_IUSER    = ALVL_PROG | ALVL_UMCC | ALVL_IUSER;   //  0001 0011
const UINT8 ALCK_PROG_UMCC_CC       = ALVL_PROG | ALVL_UMCC | ALVL_CC;      //  0001 1010
const UINT8 ALCK_PROG_UMCC_CC_IUSER = ALCK_PROG_UMCC_CC | ALVL_IUSER;       //  0001 1011
const UINT8 ALCK_ENG_SUP_IUSER      = ALVL_SUPR | ALVL_ENGR | ALVL_IUSER;   //  0110 0001
const UINT8 ALCK_ONPROC_IUSER_UMCC  = ALCK_ONPROC_IUSER | ALVL_UMCC;        //  1110 0011
const UINT8 ALCK_UMCC_IUSER         = ALVL_UMCC | ALVL_IUSER;               //  0000 0011

/* IOL address change status */
typedef enum tagAddressChange {
    ADDCHG_NONE    = 0,
    ADDCHG_NEW     = 1,
    ADDCHG_DROPPED = 2
} ADDCHG;

/*******************************************************************************
*                      IOL PROTOCOL CONSTANTS                                  *
*  Wire-format message field offsets, command IDs, and buffer sizes.            *
*  Values match H8S/LPC original—must remain identical for Experion compat.   *
*******************************************************************************/
const UINT8 IOLCMD_NACK         = 0x22;
const UINT8 IOL_MAXIFIELD       = 249;
const UINT8 IOL_MAXRCV_MSGSIZE  = 255;
const UINT8 IOL_MAXXMT_MSGSIZE  = 255;
const UINT8 IOL_MAXRESPONSE     = 249;
const UINT8 IOL_BROADCAST       = 0;

/* Wire-format message field offsets */
const UINT8 IOLMSG_DESTINATION  = 0;
const UINT8 IOLMSG_NUMBER       = 1;
const UINT8 IOLMSG_SOURCE       = 2;
const UINT8 IOLMSG_COMMAND      = 3;

/* Request field offsets (I-field, starting after command byte) */
const UINT8 IOLREQ_12DATA       = 4;
const UINT8 IOLREQ_SLOTNUM      = 4;
const UINT8 IOLREQ_SCRTYDATA    = 4;
const UINT8 IOLREQ_PARAMID      = 5;
const UINT8 IOLREQ_INDEX        = 6;
const UINT8 IOLREQ_ACCLVL       = 6;
const UINT8 IOLREQ_DATATYPE     = 7;
const UINT8 IOLREQ_ABSNUM       = 7;
const UINT8 IOLREQ_SUBCMD       = 7;
const UINT8 IOLREQ_WRDATA       = 8;

/* Response field offsets */
const UINT8 IOLNAK_PASTAT       = 4;
const UINT8 IOLRESP_REDSTATE    = 4;
const UINT8 IOLRESP_MSGSTS      = 4;
const UINT8 IOLRESP_MSGNUM      = 4;
const UINT8 IOLRESP_DATATYPE    = 4;
const UINT8 IOLRESP_ECLINFO     = 4;
const UINT8 IOLRESP_RDABSDATA   = 4;
const UINT8 IOLRESP_HARTRESP    = 5;
const UINT8 IOLRESP_DUMPDATA    = 5;
const UINT8 IOLRESP_RDDATA      = 5;
const UINT8 IOLRESP_ACKCHKSUMLO = 5;
const UINT8 IOLRESP_ECLDATA     = 8;

/* IOL command IDs */
const UINT8 CMD_WRBLOCKABSOLUTE = 0x03;
const UINT8 CMD_WRNORMAL        = 0x0A;
const UINT8 CMD_WRINDEXDEFERRED = 0x0C;
const UINT8 CMD_WRINDEXED       = 0x12;
const UINT8 CMD_TOG             = 0x20;
const UINT8 CMD_FREEZE          = 0x2F;

#ifdef IOMTYPE_AIH
    #define PARAMID_SLTCHKPNT   150
    #define BOX                 ((clsAihBoxSlot *)pDatabase[0])
    #define SLOT(N)             ((clsAihSlot *)pDatabase[N])
	const UINT8 LATEST_BOXCHKPNT_VERSION = 2;
	const UINT8 LATEST_SLTCHKPNT_VERSION = 2;
#if 1 //defined(IOPTYPE_HLAI)
	// PMIO HLAI Redesign red dump data constants
	const UINT8 PMIO_BOXDUMP_PARAMSIZE = 98;
	const UINT8 PMIO_SLOTDUMP_PARAMSIZE = 116;
	const UINT8 PMIO_HSLOTDUMP_PARAMSIZE = 133; // 5 params (4x4 + 1x1) added in HLAIH
	const UINT8 PMIO_HARTDUMP_PARAMSIZE = 82;
#endif
#endif

/*******************************************************************************
*                              FORWARD DECLARATIONS                            *
*******************************************************************************/

class clsTaskScheduler;
class clsIomSlot;
class clsWriteMsgQueue;

/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/

extern clsTaskScheduler TaskScheduler;
extern clsIomSlot       *pDatabase[];
extern clsWriteMsgQueue WriteMsgQueue;

#endif /* __GLOBAL_H__ */
