/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_pit.c                                                   *
*    Description : Application PIT implementation for iMXRT1024.               *
*                                                                              *
*******************************************************************************/

#include "fsl_pit.h"
#include "fsl_clock.h"
#include "fsl_common.h"
#include "hal_timer.h"

void PIT_DriverIRQHandler(void);

static hal_timer_callback_t s_pitCallback = NULL;

static void hal_pit_irq_dispatch(void)
{
    (void)PIT_GetStatusFlags(PIT, kPIT_Chnl_0);
    PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);
    if (s_pitCallback != NULL) {
        s_pitCallback();
    }

    __DSB();
}

void hal_pit_init(bool lowCostMode, hal_timer_callback_t callback)
{
    uint32_t pitClkHz = CLOCK_GetFreq(kCLOCK_PerClk);
    if (pitClkHz == 0U) {
        pitClkHz = CLOCK_GetFreq(kCLOCK_IpgClk);
    }
    uint32_t periodUs = lowCostMode ? 50000U : 3125U; // 3.125ms nominal, 50ms for low-cost mode

    s_pitCallback = callback;

    DisableIRQ(PIT_IRQn);

    pit_config_t pitConfig;
    PIT_GetDefaultConfig(&pitConfig);
    PIT_Init(PIT, &pitConfig);

    uint64_t ticks = ((uint64_t)pitClkHz * periodUs) / 1000000ULL;

    if (ticks == 0U) {
        ticks = 1U;
    }

    PIT_SetTimerPeriod(PIT, kPIT_Chnl_0, (uint32_t)(ticks - 1ULL));

    PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);
    PIT_EnableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);

#if defined(ENABLE_RAM_VECTOR_TABLE)
    InstallIRQHandler(PIT_IRQn, (uint32_t)PIT_DriverIRQHandler);
#endif

    NVIC_ClearPendingIRQ(PIT_IRQn);
    /* Keep PIT above LVLPRI_TICK/LVLPRI_TASK BASEPRI masks; only LVLPRI_HIGHEST should block it. */
    NVIC_SetPriority(PIT_IRQn, 10);   // tune to match your I/O processing priority scheme
    EnableIRQ(PIT_IRQn);
}

void hal_pit_start(void) {
	PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);

	PIT_StartTimer(PIT, kPIT_Chnl_0);
}

void PIT_IRQHandler(void)
{
    hal_pit_irq_dispatch();
}

void PIT_DriverIRQHandler(void)
{
    hal_pit_irq_dispatch();
}


