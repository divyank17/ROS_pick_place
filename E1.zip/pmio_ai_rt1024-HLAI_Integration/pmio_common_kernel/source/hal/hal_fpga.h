/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_fpga.h                                                  *
*    Description : FPGA Register Access Abstraction Layer.                     *
*                                                                              *
*    The Lattice MACHXO3LF-4300C FPGA on the RT1024 Kernel board is accessed  *
*    via LPSPI2 instead of the parallel memory bus used by the H8S.            *
*                                                                              *
*    SPI Protocol (per HDD Rev 1.0):                                           *
*      Byte 0: { R/~W (1 bit), Address[6:0] (7 bits) }                        *
*      Byte 1: Data[15:8]  (MSB)                                              *
*      Byte 2: Data[7:0]   (LSB)                                              *
*      R/~W = 1 for Read, 0 for Write                                         *
*      SPI Clock: 10 MHz (LPSPI2), CPOL=0, CPHA=0                             *
*                                                                              *
*    On QEMU, a RAM-backed register file simulates the FPGA.                   *
*    On Unit Test (host PC), all calls are no-ops returning defaults.          *
*                                                                              *
*    Key architecture changes from H8S → RT1024 (HDD Section 5.6.1):          *
*      - ADC/EEPROM SPI removed from FPGA → now LPSPI3/LPSPI4 direct          *
*      - ADC mux select (MUXAD/ENBMX) removed from FPGA → direct GPIO         *
*      - HART UARTs 0-3 remain inside FPGA, accessed via SPI                   *
*      - GPWR: MSB[15:8] = mask, LSB[7:0] = data (Rev 6D-02)                  *
*                                                                              *
*    Access Priority (per HDD guidance):                                       *
*      1. Direct GPIO pins — fastest (~100ns, used for time-critical I/O)      *
*      2. FPGA SPI registers — moderate (~4.3us per transaction at 10 MHz)     *
*      3. Mock parallel via GPIO (ADDR/DATA + RD/WR/AS) — fallback             *
*******************************************************************************/
#ifndef HAL_FPGA_H
#define HAL_FPGA_H

#include "hal_platform.h"
#include "datatype.h"

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
*                  FPGA SPI REGISTER ADDRESS MAP (7-bit)                       *
*                                                                              *
*  Derived from original H8S memory-mapped addresses (0x400000 + offset).     *
*  The SPI address = (H8S byte offset) / 2, since each SPI transaction        *
*  transfers a 16-bit word. The FPGA SPI slave decodes these addresses.        *
*                                                                              *
*  Table 12 in HDD: "Address Mapping for Common & Application Specific         *
*  Registers in Lattice FPGA"                                                  *
*******************************************************************************/

/* ---- HART UART Registers (4 UARTs, 8 registers each) ---- */
#define FPGA_UART0_BASE          0x00   /* HART UART 0 WR ADRS & 0x80 RD ADRS */
#define FPGA_UART1_BASE          0x10   /* HART UART 1 WR ADRS & 0x90 RD ADRS */
#define FPGA_UART2_BASE          0x20   /* HART UART 2 WR ADRS & 0xA0 RD ADRS */
#define FPGA_UART3_BASE          0x30   /* HART UART 3 WR ADRS & 0xB0 RD ADRS */

/* UART register offsets (add to UARTn_BASE) — same as 16550 layout */
#define FPGA_UART_RHR            0x00   /* Receive Holding Register (read)    */
#define FPGA_UART_THR            0x00   /* Transmit Holding Register (write)  */
#define FPGA_UART_IER            0x01   /* Interrupt Enable Register          */
#define FPGA_UART_IIR            0x02   /* Interrupt ID Register (read)       */
#define FPGA_UART_FCR            0x02   /* FIFO Control Register (write)      */
#define FPGA_UART_LCR            0x03   /* Line Control Register              */
#define FPGA_UART_MCR            0x04   /* Modem Control Register (RTS/DTR)   */
#define FPGA_UART_LSR            0x05   /* Line Status Register               */
#define FPGA_UART_MSR            0x06   /* Modem Status Register (CD/CTS)     */
#define FPGA_UART_SCR            0x07   /* Scratch Register                   */

/* UART IER bit definitions */
#define FPGA_UART_IER_RCV_DATA   0x01   /* Receive data available interrupt   */
#define FPGA_UART_IER_XMT_EMPTY  0x02   /* Transmit holding empty interrupt   */
#define FPGA_UART_IER_LINE_STS   0x04   /* Receive line status interrupt      */
#define FPGA_UART_IER_MODEM_STS  0x08   /* Modem status interrupt             */

/* UART IIR (Interrupt Identification) values */
#define FPGA_UART_IIR_NONE       0x01   /* No interrupt pending               */
#define FPGA_UART_IIR_LINE_STS   0x06   /* Receiver line status (highest pri) */
#define FPGA_UART_IIR_RCV_DATA   0x04   /* Receive data available             */
#define FPGA_UART_IIR_RCV_TMOUT  0x0C   /* Character timeout                  */
#define FPGA_UART_IIR_XMT_EMPTY  0x02   /* Transmit holding empty             */
#define FPGA_UART_IIR_MODEM_STS  0x00   /* Modem status (lowest priority)     */

/* UART LSR bit definitions */
#define FPGA_UART_LSR_DR         0x01   /* Data Ready                         */
#define FPGA_UART_LSR_OE         0x02   /* Overrun Error                      */
#define FPGA_UART_LSR_PE         0x04   /* Parity Error                       */
#define FPGA_UART_LSR_FE         0x08   /* Framing Error                      */
#define FPGA_UART_LSR_BI         0x10   /* Break Interrupt                    */
#define FPGA_UART_LSR_THRE       0x20   /* Transmit Holding Reg Empty         */
#define FPGA_UART_LSR_TEMT       0x40   /* Transmitter Empty (TSR + THR)      */

/* UART MCR bit definitions */
#define FPGA_UART_MCR_DTR        0x01   /* Data Terminal Ready                */
#define FPGA_UART_MCR_RTS        0x02   /* Request To Send (→ HART modem)     */

/* ---- UARTLite (IOL interboard UART — moved to SPI) ---- */
#define FPGA_UARTLITE_BASE       0x20   /* UARTLite register (H8S: 0x400040)  */

/* ---- HART Baud Rate Generator (Common DLL/DLM) ---- */
#define FPGA_BAUDRATE_BASE       0x28   /* Baud Rate Register (H8S: 0x400050) */

/* ---- UART Reset Register ---- */
/* Rev 6D-02: Common single address with individual bits per UART + master    */
#define FPGA_UART_RESET          0x04   /* Bit 0-3: UART0-3, Bit 7: all       */

/* ---- FPGA Interrupt Status Register (ISR) ---- */
#define FPGA_ISR_ADDR            0x30   /* (H8S: 0x400060)                    */
/* ISR bit definitions */
#define FPGA_ISR_UART0           0x01   /* UART 0 interrupt pending           */
#define FPGA_ISR_UART1           0x02   /* UART 1 interrupt pending           */
#define FPGA_ISR_UART2           0x04   /* UART 2 interrupt pending           */
#define FPGA_ISR_UART3           0x08   /* UART 3 interrupt pending           */
#define FPGA_ISR_UART4           0x10   /* UART 4 (UARTLite) interrupt        */
#define FPGA_ISR_SPI             0x20   /* SPI interrupt (legacy)             */
#define FPGA_ISR_WDTO            0x40   /* Watchdog timeout pending           */

/* ---- FPGA Revision Registers (read-only) ---- */
#define FPGA_REV_LETTER          0xC5   //0x38   /* Version letter (H8S: 0x400070)     */
#define FPGA_REV_NUMBER          0xC6   //0x39   /* Revision number (H8S: 0x400071)    */

/* ---- Wiggle/OWD Control Register (WIGLPVCR) ---- */
/* AIH: Selects ADC channel for open wire detection */
#define FPGA_WIGLPVCR            0x40   /* (H8S: 0x400080)                    */
/* Bit fields: [3:0]=Channel Select, [4]=Enable, [5]=Up, [6]=FilterOff        */
#define FPGA_WIGLPVCR_CSEL_MASK  0x0F
#define FPGA_WIGLPVCR_ENB        0x10
#define FPGA_WIGLPVCR_UP         0x20
#define FPGA_WIGLPVCR_FILTOFF    0x40

/* ---- Output Select Register (AOH only, Analog Output) ---- */
#define FPGA_OUTSEL              0x48   /* (H8S: 0x400090)                    */

/* ---- Unlock Key Register ---- */
#define FPGA_UKEY                0x49   /* (H8S: 0x400091)                    */

/* ---- Input Select Register ---- */
#define FPGA_INPSEL              0x50   /* (H8S: 0x4000A0)                    */

/* ---- IRQ Status Register ---- */
/* Read-only: reflects state of interrupt sources from external devices        */
#define FPGA_IRQ_STATUS          0x60   /* See Table 26 in HDD                */

/* HART UART aggregate interrupt/status register used by the proven J3 stack.
 * Keep separate from the application IRQ status register at 0x60. */
#define FPGA_HART_IRQ_STATUS     0xC4

/* ---- Module Status (Read-only, CPLD portion exposed via FPGA) ---- */
#define FPGA_MODNUM              0xC8 //0x64   /* Module Number / RIP readback       */
#define FPGA_IOLIOTASR           0xCA //0x65   /* IOTA status: BUPREQ_IN, BOTTOM, REDUNT, GHOXXX, JABLOCK etc.       */
/* IOLIOTASR bit definitions (from P_CPLDR04) */
#define FPGA_IOTA_REDUNT_n       0x01   /* Redundancy indicator (active low)  */
#define FPGA_IOTA_BOTTOM         0x02   /* Bottom slot indicator              */
#define FPGA_IOTA_BUPREQ_IN      0x04   /* Backup request input from partner  */
#define FPGA_IOTA_JABLOCK_n      0x08   /* Anti-jabber lockout (active low)   */
#define FPGA_IOTA_GHOXXX         0x10   /* Gap Has Occurred status            */
#define FPGA_IOTA_BUPREQ_FB      0x20   /* Backup request feedback            */

/* ---- Misc Status Register ---- */
#define FPGA_MISC_STATUS         0xCB //0x66   /* CALIBRATE, FACTCAL, OVERVT, etc.   */
#define FPGA_MISC_GOODINPUT      0x20
#define FPGA_MISC_CALIBRATE      0x10
#define FPGA_MISC_FACTCAL        0x08
#define FPGA_MISC_OVERVT_n       0x04
#define FPGA_MISC_ADC_CLK        0x01

/* ---- HART Mux Address/Enable ---- */
#define FPGA_HART_MUXADDR        0xCD //0x70   /* (H8S: 0x080010)                    */
#define FPGA_HART_MUXENBL        0xCE //0x71   /* (H8S: 0x080012)                    */

/* ---- General Purpose Write Register (GPWR) ---- */
/* Rev 6D-02: Write format: MSB[15:8] = mask, LSB[7:0] = data               */
/* Only bits where mask=1 are updated in the FPGA register.                   */
#define FPGA_GPWR                0xCF //0x68   /* (H8S: 0x080014 in GPR via CPLD)    */
#define FPGA_GPWR_LED_GREEN      0x01   /* Status LED green                   */
#define FPGA_GPWR_LED_RED        0x02   /* Status LED red                     */
#define FPGA_GPWR_LED_MASK       0x03   /* LED pin mask (bits 0-1)            */
#define FPGA_GPWR_CLR_RIP        0x04   /* Clear RIP latch                    */
#define FPGA_GPWR_SET_DIP        0x08   /* Set DIP latch                      */
#define FPGA_GPWR_EEPROM_WP_n    0x10   /* EEPROM Write Protect               */

/* ---- CPLD Revision ---- */
#define FPGA_CPLD_REV_LETTER     0x6C   /* (H8S: 0x080008)                    */
#define FPGA_CPLD_REV_NUMBER     0x6D   /* (H8S: 0x080009)                    */

/* ---- STATUS LED ----- */
#define FPGA_STATUS_LED          0x4F //0x70

/*******************************************************************************
*                         HART UART COUNT                                      *
*******************************************************************************/
#define FPGA_HART_UART_COUNT     4

/*******************************************************************************
*                  FPGA ACCESS API — LOW LEVEL                                 *
*                                                                              *
*  These functions abstract the underlying transport:                          *
*    RT1024:  LPSPI2 at 10 MHz SPI clock                                      *
*    QEMU:    RAM-backed register file (direct read/write)                     *
*    UnitTest: Stubs returning default values                                  *
*******************************************************************************/

/**
 * @brief Initialize the FPGA interface (SPI port, CS pin, etc.).
 *
 * RT1024: Configures LPSPI2 as master, 10 MHz, CPOL=0, CPHA=0.
 * QEMU:   Initializes the RAM-backed register file to power-on defaults.
 */
void hal_fpga_init(void);

/**
 * @brief Read a 16-bit value from an FPGA register.
 * @param addr  7-bit FPGA register address (0x00-0x7F)
 * @return 16-bit register value (MSB in bits 15:8, LSB in bits 7:0)
 */
UINT16 hal_fpga_read(UINT8 addr);
/* A4: transport-health counters.  A failed blocking LPSPI transfer is
 * retried and never exposes an uninitialized receive buffer to HART. */
UINT32 hal_fpga_get_spi_error_count(void);
void   hal_fpga_clear_spi_error_count(void);

/**
 * @brief Write a 16-bit value to an FPGA register.
 * @param addr  7-bit FPGA register address (0x00-0x7F)
 * @param data  16-bit value to write
 */
void hal_fpga_write(UINT8 addr, UINT16 data);

/*******************************************************************************
*                  FPGA ACCESS API — NON-BLOCKING IOTA STATUS READ             *
*                                                                              *
*  hal_fpga_read()/hal_fpga_write() are blocking (LPSPI_MasterTransferBlocking)
*  — fine for one-shot/init-time use, but a low-priority periodic caller (e.g.
*  CheckFtaPresence(), called every ~100ms from LowPriorityTask) can end up
*  stalled for a long *wall-clock* time under heavy, legitimate high-priority
*  interrupt load (e.g. a busy IOL UART bus) even though the transfer itself
*  is only a few bytes, because the blocking poll loop keeps getting
*  preempted. This small non-blocking state machine lets such callers kick
*  off a read and check back later without ever spinning/blocking:
*    hal_fpga_start_iota_read()  - start a transfer if none is in progress
*    hal_fpga_iota_read_pending()- TRUE while a transfer is in flight
*    hal_fpga_iota_read_ready()  - TRUE once the transfer has completed
*    hal_fpga_get_iota_result()  - fetch the result and clear pending/ready
*******************************************************************************/
void hal_fpga_start_iota_read(void);
BOOL hal_fpga_iota_read_pending(void);
BOOL hal_fpga_iota_read_ready(void);
UINT8 hal_fpga_get_iota_result(void);

/**
 * @brief Read an 8-bit value from an FPGA register (low byte only).
 * @param addr  7-bit FPGA register address
 * @return Low 8 bits of the 16-bit SPI read
 *
 * Most FPGA registers are 8-bit (UART, status).  This convenience
 * function saves the caller from masking.
 */
static inline UINT8 hal_fpga_read8(UINT8 addr)
{
    return (UINT8)(hal_fpga_read(addr) & 0xFF);
}

/**
 * @brief Write an 8-bit value to an FPGA register.
 * @param addr  7-bit FPGA register address
 * @param data  8-bit value (zero-extended to 16 bits)
 */
static inline void hal_fpga_write8(UINT8 addr, UINT8 data)
{
    hal_fpga_write(addr, (UINT16)data);
}

/*******************************************************************************
*                  FPGA ACCESS API — GPWR (MASKED WRITE)                       *
*                                                                              *
*  The GPWR register uses a mask+data scheme (Rev 6D-02):                      *
*    Write value = { mask[7:0] << 8 | data[7:0] }                             *
*  Only GPWR bits where mask=1 are modified.  This allows atomic              *
*  bit-level control without a read-modify-write cycle.                       *
*******************************************************************************/

/**
 * @brief Write to GPWR with mask.  Only sets bits where mask=1.
 * @param mask  Bitmask of which bits to modify
 * @param data  New values for the masked bits
 */
static inline void hal_fpga_gpwr_write(UINT8 mask, UINT8 data)
{
    hal_fpga_write(FPGA_GPWR, (UINT16)((UINT16)mask << 8) | data);
}

/** @brief Set the status LED color via GPWR.
 *  @param green  TRUE to illuminate green LED
 *  @param red    TRUE to illuminate red LED
 *  Both TRUE = amber.
 */
static inline void hal_fpga_set_led(BOOL green, BOOL red)
{
    UINT8 data = 0;
    if (green) data |= FPGA_GPWR_LED_GREEN;
    if (red)   data |= FPGA_GPWR_LED_RED;
    hal_fpga_gpwr_write(FPGA_GPWR_LED_MASK, data);
}

/*******************************************************************************
*                  FPGA ACCESS API — HART UART HELPERS                         *
*                                                                              *
*  HART UARTs 0-3 are 16550-compatible UARTs inside the FPGA.                 *
*  These helpers provide typed access indexed by modem number.                 *
*******************************************************************************/

/**
 * @brief Get the SPI base address for a given HART modem UART.
 * @param modem  Modem index 0-3
 * @return SPI register base address for that UART
 */
static inline UINT8 hal_fpga_uart_write_base(UINT8 modem)
{
    return (UINT8)(FPGA_UART0_BASE + ((modem & 0x03u) * 0x10u));
}

static inline UINT8 hal_fpga_uart_read_base(UINT8 modem)
{
    return (UINT8)(0x80u + ((modem & 0x03u) * 0x10u));
}

/**
 * @brief Read a HART UART register.
 * @param modem  Modem index 0-3
 * @param reg    UART register offset (FPGA_UART_RHR, FPGA_UART_LSR, etc.)
 * @return Register value (8-bit)
 */
static inline UINT8 hal_fpga_uart_read(UINT8 modem, UINT8 reg)
{
    return (UINT8)((hal_fpga_read((UINT8)(hal_fpga_uart_read_base(modem) + reg)) >> 8) & 0xFFu);
}

/**
 * @brief Write a HART UART register.
 * @param modem  Modem index 0-3
 * @param reg    UART register offset
 * @param data   Value to write (8-bit)
 */
static inline void hal_fpga_uart_write(UINT8 modem, UINT8 reg, UINT8 data)
{
    hal_fpga_write((UINT8)(hal_fpga_uart_write_base(modem) + reg),
                   (UINT16)((UINT16)data << 8));
}

/** @brief Check if HART UART has received data. */
static inline BOOL hal_fpga_uart_rx_ready(UINT8 modem)
{
    return (hal_fpga_uart_read(modem, FPGA_UART_LSR) & FPGA_UART_LSR_DR)
            ? TRUE : FALSE;
}

/** @brief Check if HART UART transmit holding register is empty. */
static inline BOOL hal_fpga_uart_tx_ready(UINT8 modem)
{
    return (hal_fpga_uart_read(modem, FPGA_UART_LSR) & FPGA_UART_LSR_THRE)
            ? TRUE : FALSE;
}

/** @brief Read a byte from HART UART receive buffer. */
static inline UINT8 hal_fpga_uart_rx_byte(UINT8 modem)
{
    return hal_fpga_uart_read(modem, FPGA_UART_RHR);
}

/** @brief Write a byte to HART UART transmit buffer. */
static inline void hal_fpga_uart_tx_byte(UINT8 modem, UINT8 data)
{
    hal_fpga_uart_write(modem, FPGA_UART_THR, data);
}

/** @brief Reset a specific HART UART (& its external HART modem). */
static inline void hal_fpga_uart_reset(UINT8 modem)
{
    const UINT8 resetAddr = (UINT8)(0x08u + ((modem & 0x03u) * 0x10u));
    hal_fpga_write(resetAddr, (UINT16)0x0100u);
    hal_fpga_write(resetAddr, (UINT16)0x0000u);
}

/** @brief Reset ALL HART UARTs. */
static inline void hal_fpga_uart_reset_all(void)
{
    hal_fpga_write8(FPGA_UART_RESET, 0x80);
}

/*******************************************************************************
*                  FPGA ACCESS API — STATUS & IDENTIFICATION                   *
*******************************************************************************/

/** @brief Read the FPGA interrupt status register. */
static inline UINT8 hal_fpga_read_isr(void)
{
    return hal_fpga_read8(FPGA_ISR_ADDR);
}

/** @brief Read the FPGA revision letter (e.g., 0x36 = '6'). */
static inline UINT8 hal_fpga_get_rev_letter(void)
{
    //return hal_fpga_read8(FPGA_REV_LETTER);

	/*
	 * result will be in MSB of 16bit data & FPGA address is 7bit LSB.
	 */
	return (hal_fpga_read(FPGA_REV_LETTER) >> 8);
}

/** @brief Read the FPGA revision number (e.g., 0x44 = 'D' → ver 6D). */
static inline UINT8 hal_fpga_get_rev_number(void)
{
    //return hal_fpga_read8(FPGA_REV_NUMBER);

	/*
	 * result will be in MSB of 16bit data & FPGA address is 7bit LSB.
	 */
	return (hal_fpga_read(FPGA_REV_NUMBER) >> 8);
}

/** @brief Read the module number (MODNUM from backplane DIP switches). */
static inline UINT8 hal_fpga_get_modnum(void)
{
	//return hal_fpga_read8(FPGA_MODNUM);

	/*
	 * result will be in MSB of 16bit data & FPGA address is 7bit LSB.
	 */
	return (hal_fpga_read(FPGA_MODNUM) >> 8);
}

/** @brief Read the IOTA status register (BUPREQ_IN, BOTTOM, REDUNT, etc). */
static inline UINT8 hal_fpga_get_iota_status(void)
{
    //return hal_fpga_read8(FPGA_IOLIOTASR);
	/*
	 * result will be in MSB of 16bit data & FPGA address is 7bit LSB.
	 */
	return (hal_fpga_read(FPGA_IOLIOTASR) >> 8);
}

/** @brief Read the MISC status register (OPENWIRE, CALIBRATE, FACT_CAL, OVERVT, CLK_ADC). */
static inline UINT8 hal_fpga_get_misc_status(void)
{
    //return hal_fpga_read8(FPGA_MISC_STATUS);
	/*
	 * result will be in MSB of 16bit data & FPGA address is 7bit LSB.
	 */
	return (hal_fpga_read(FPGA_MISC_STATUS) >> 8);
}
/*******************************************************************************
*                  FPGA ACCESS API — OWD / WIGGLE TEST                         *
*******************************************************************************/

/**
 * @brief Select an ADC channel for open wire detection (OWD).
 * @param channel  Channel number (0-15)
 * @param enable   TRUE to enable OWD on that channel
 */
static inline void hal_fpga_owd_select(UINT8 channel, BOOL enable)
{
    UINT8 val = (UINT8)(channel & FPGA_WIGLPVCR_CSEL_MASK);
    if (enable) val |= FPGA_WIGLPVCR_ENB;
    hal_fpga_write8(FPGA_WIGLPVCR, val);
}

/*******************************************************************************
*                  FPGA ACCESS API — HART MODEM MUX                            *
*******************************************************************************/

/**
 * @brief Set the HART modem mux address (selects which modem channel).
 * @param addr  Mux address value
 */
static inline void hal_fpga_hart_mux_set(UINT8 addr)
{
    hal_fpga_write8(FPGA_HART_MUXADDR, addr);
}

/**
 * @brief Enable/disable HART modem mux channels.
 * @param enable_mask  Bit mask of mux enables
 */
static inline void hal_fpga_hart_mux_enable(UINT8 enable_mask)
{
    /* J3 standalone compatibility: this class-level compatibility write uses
     * the FPGA 8-bit/MSB convention. The synchronous transaction path then
     * programs the full MAR/MER values exactly as J3 did. */
    hal_fpga_write(FPGA_HART_MUXENBL,
                   (UINT16)((UINT16)enable_mask << 8));
}

static inline void hal_fpga_hart_mux_set16(UINT16 muxAddr)
{
    hal_fpga_write(FPGA_HART_MUXADDR, muxAddr);
}

static inline UINT16 hal_fpga_hart_mux_get_addr16(void)
{
    return hal_fpga_read(FPGA_HART_MUXADDR);
}

static inline UINT8 hal_fpga_hart_mux_get_enable(void)
{
    return (UINT8)((hal_fpga_read(FPGA_HART_MUXENBL) >> 8) & 0xFFu);
}


#ifndef FPGA_BRG_DLL
#define FPGA_BRG_DLL ((UINT8)0x40u)
#endif
#ifndef FPGA_BRG_DLM
#define FPGA_BRG_DLM ((UINT8)0x41u)
#endif
#ifndef FPGA_BRG_MUX
#define FPGA_BRG_MUX ((UINT8)0x42u)
#endif
#ifndef FPGA_MAR
#define FPGA_MAR FPGA_HART_MUXADDR
#endif
#ifndef FPGA_MER
#define FPGA_MER FPGA_HART_MUXENBL
#endif
#ifndef HART_DEFAULT_MAR_CH1_M0
#define HART_DEFAULT_MAR_CH1_M0 ((UINT16)0xC840u)
#endif
#ifndef HART_DEFAULT_MER_NONE
#define HART_DEFAULT_MER_NONE ((UINT8)0x00u)
#endif
#ifndef UART_COUNT
#define UART_COUNT ((UINT8)4u)
#endif
#ifndef UART_STRIDE
#define UART_STRIDE ((UINT8)0x10u)
#endif
#ifndef UART0_WRITE_BASE
#define UART0_WRITE_BASE ((UINT8)0x00u)
#endif
#ifndef UART1_WRITE_BASE
#define UART1_WRITE_BASE ((UINT8)0x10u)
#endif
#ifndef UART2_WRITE_BASE
#define UART2_WRITE_BASE ((UINT8)0x20u)
#endif
#ifndef UART3_WRITE_BASE
#define UART3_WRITE_BASE ((UINT8)0x30u)
#endif
#ifndef UART0_READ_BASE
#define UART0_READ_BASE ((UINT8)0x80u)
#endif
#ifndef UART1_READ_BASE
#define UART1_READ_BASE ((UINT8)0x90u)
#endif
#ifndef UART2_READ_BASE
#define UART2_READ_BASE ((UINT8)0xA0u)
#endif
#ifndef UART3_READ_BASE
#define UART3_READ_BASE ((UINT8)0xB0u)
#endif
#ifndef UART0_BASE
#define UART0_BASE UART0_READ_BASE
#endif
#ifndef UART1_BASE
#define UART1_BASE UART1_READ_BASE
#endif
#ifndef UART2_BASE
#define UART2_BASE UART2_READ_BASE
#endif
#ifndef UART3_BASE
#define UART3_BASE UART3_READ_BASE
#endif
#ifndef UART_READ_BASE
#define UART_READ_BASE(modem) ((UINT8)(UART0_READ_BASE + ((UINT8)((modem) & 0x03u) * UART_STRIDE)))
#endif
#ifndef UART_WRITE_BASE
#define UART_WRITE_BASE(modem) ((UINT8)(UART0_WRITE_BASE + ((UINT8)((modem) & 0x03u) * UART_STRIDE)))
#endif
#ifndef UART0_RESET
#define UART0_RESET ((UINT8)0x08u)
#endif
#ifndef UART1_RESET
#define UART1_RESET ((UINT8)0x18u)
#endif
#ifndef UART2_RESET
#define UART2_RESET ((UINT8)0x28u)
#endif
#ifndef UART3_RESET
#define UART3_RESET ((UINT8)0x38u)
#endif
#ifndef UART_RBR_THR
#define UART_RBR_THR ((UINT8)0x00u)
#endif
#ifndef UART_IER
#define UART_IER ((UINT8)0x01u)
#endif
#ifndef UART_IIR_FCR
#define UART_IIR_FCR ((UINT8)0x02u)
#endif
#ifndef UART_LCR
#define UART_LCR ((UINT8)0x03u)
#endif
#ifndef UART_MCR
#define UART_MCR ((UINT8)0x04u)
#endif
#ifndef UART_LSR
#define UART_LSR ((UINT8)0x05u)
#endif
#ifndef UART_MSR
#define UART_MSR ((UINT8)0x06u)
#endif
#ifndef UART_SCR
#define UART_SCR ((UINT8)0x07u)
#endif
#ifndef UART_LSR_DR
#define UART_LSR_DR ((UINT8)0x01u)
#endif
#ifndef UART_LSR_OE
#define UART_LSR_OE ((UINT8)0x02u)
#endif
#ifndef UART_LSR_PE
#define UART_LSR_PE ((UINT8)0x04u)
#endif
#ifndef UART_LSR_FE
#define UART_LSR_FE ((UINT8)0x08u)
#endif
#ifndef UART_LSR_BI
#define UART_LSR_BI ((UINT8)0x10u)
#endif
#ifndef UART_LSR_THRE
#define UART_LSR_THRE ((UINT8)0x20u)
#endif
#ifndef UART_LSR_TEMT
#define UART_LSR_TEMT ((UINT8)0x40u)
#endif
#ifndef UART_MCR_RTS
#define UART_MCR_RTS ((UINT8)0x02u)
#endif
#ifndef UART_MCR_LOOPBACK
#define UART_MCR_LOOPBACK ((UINT8)0x10u)
#endif
#ifndef UART_MSR_DCD
#define UART_MSR_DCD ((UINT8)0x80u)
#endif
#ifndef UART_MSR_RI
#define UART_MSR_RI ((UINT8)0x40u)
#endif
#ifndef UART_MSR_DSR
#define UART_MSR_DSR ((UINT8)0x20u)
#endif
#ifndef UART_MSR_CTS
#define UART_MSR_CTS ((UINT8)0x10u)
#endif
#ifndef UART_LCR_8O1_ODD_PARITY
#define UART_LCR_8O1_ODD_PARITY ((UINT8)0x0Bu)
#endif
#ifndef HART_IER_RX_MODEM_STATUS
#define HART_IER_RX_MODEM_STATUS ((UINT8)0x09u)
#endif
#ifndef HART_IER_TX_EMPTY
#define HART_IER_TX_EMPTY ((UINT8)0x02u)
#endif
#ifndef HART_DELIMITER_SHORT_MASTER_REQ
#define HART_DELIMITER_SHORT_MASTER_REQ ((UINT8)0x02u)
#endif
#ifndef HART_CMD0_ID_RESPONSE_SIZE
#define HART_CMD0_ID_RESPONSE_SIZE ((UINT8)12u)
#endif

static inline UINT8 hal_fpga_hart_read8(UINT8 addr)
{
    return (UINT8)((hal_fpga_read(addr) >> 8) & 0xFFu);
}

static inline void hal_fpga_hart_write8(UINT8 addr, UINT8 data)
{
    hal_fpga_write(addr, (UINT16)((UINT16)data << 8));
}

static inline void HART_UART_InitHART16550(UINT8 uart)
{
    hal_fpga_hart_write8((UINT8)(UART_WRITE_BASE(uart) + UART_IER), 0x00u);
    hal_fpga_hart_write8((UINT8)(UART_WRITE_BASE(uart) + UART_LCR), UART_LCR_8O1_ODD_PARITY);
    hal_fpga_hart_write8((UINT8)(UART_WRITE_BASE(uart) + UART_IIR_FCR), 0xC1u);
    hal_fpga_hart_write8((UINT8)(UART_WRITE_BASE(uart) + UART_SCR), 0xDBu);
}

#ifdef __cplusplus
}
#endif

#endif /* HAL_FPGA_H */
