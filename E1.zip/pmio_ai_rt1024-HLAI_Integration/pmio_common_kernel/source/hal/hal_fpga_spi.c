/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_fpga_spi.c                                             *
*    Description : FPGA register access via LPSPI2 for iMXRT1024.             *
*                                                                              *
*    Implements the hal_fpga API using the RT1024's LPSPI2 peripheral.         *
*    The Lattice MACHXO3LF FPGA operates as SPI slave.                        *
*                                                                              *
*    SPI Configuration (per HDD Table 51/52):                                  *
*      - Peripheral: LPSPI2                                                    *
*      - Clock:      10 MHz (max per FPGA spec)                                *
*      - Mode:       CPOL=0, CPHA=0 (SPI Mode 0)                              *
*      - Frame:      8-bit, MSB first                                          *
*      - CS:         PCS0 (hardware-managed chip select)                       *
*                                                                              *
*    This file is compiled ONLY for RT1024_BUILD.                              *
*******************************************************************************/
#include "hal_platform.h"

#include "hal_platform.h"

#if defined(RT1024_BUILD) && defined(HAL_FPGA_SPI_ENABLED)

#include "hal_fpga.h"
#include "fsl_lpspi.h"
#include "fsl_clock.h"
#include "hal_timer.h"

/*******************************************************************************
*                          LPSPI2 PIN CONFIGURATION                            *
*                                                                              *
*  From HDD Table 51 — Pin Mapping for LPSPI2:                                *
*    LPSPI2_SCK    — GPIO_SD_B1_07 (pad L3)                                   *
*    LPSPI2_PCS0   — GPIO_SD_B1_06 (pad K1)   Chip Select for FPGA            *
*    LPSPI2_SDO    — GPIO_SD_B1_08 (pad M3)   MOSI → FPGA SPI_DIN            *
*    LPSPI2_SDI    — GPIO_SD_B1_09 (pad M4)   MISO ← FPGA SPI_DOUT           *
*******************************************************************************/

/* LPSPI2 peripheral base pointer (from NXP SDK) */
#define FPGA_SPI_BASE       LPSPI2
#define FPGA_SPI_CLOCK_FREQ CLOCK_GetFreq(kCLOCK_Usb1PllPfd0Clk)
#define FPGA_SPI_BAUDRATE   10000000u   /* 10 MHz */
#define FPGA_SPI_PCS        kLPSPI_Pcs0

/* SPI command byte: bit 7 = R/~W, bits 6:0 = address */
#define SPI_CMD_READ(addr)  (UINT8)(0x80 | ((addr) & 0x7F))
#define SPI_CMD_WRITE(addr) (UINT8)(0x00 | ((addr) & 0x7F))


/* A4 integration fix: all FPGA clients share LPSPI2.  Keep each three-byte
 * transaction atomic with respect to UART/PIT interrupts, check the SDK return
 * status, and retry bounded failures.  This prevents stale stack bytes from
 * being interpreted as FPGA/UART data when a transfer times out. */
#define FPGA_SPI_TRANSFER_RETRIES (3u)
static volatile UINT32 s_fpgaSpiErrorCount = 0u;

static status_t FpgaSpiTransfer(lpspi_transfer_t *xfer)
{
    status_t status = kStatus_Fail;

    for (UINT8 attempt = 0u; attempt < FPGA_SPI_TRANSFER_RETRIES; attempt++)
    {
        /* Level 7 is the legacy LVLPRI_HIGHEST value.  Restore the raw BASEPRI
         * returned by hal_interrupt_set_mask() after this microsecond transfer. */
        UINT32 savedMask = hal_interrupt_set_mask(7u);
        status = LPSPI_MasterTransferBlocking(FPGA_SPI_BASE, xfer);
        hal_interrupt_set_mask(savedMask);

        if (status == kStatus_Success)
        {
            return status;
        }

        s_fpgaSpiErrorCount++;
    }

    return status;
}

UINT32 hal_fpga_get_spi_error_count(void)
{
    return s_fpgaSpiErrorCount;
}

void hal_fpga_clear_spi_error_count(void)
{
    s_fpgaSpiErrorCount = 0u;
}

/*******************************************************************************
*                  Non-blocking IOTA status read state machine                *
*  See hal_fpga_start_iota_read() etc. in hal_fpga.h for rationale: lets a
*  low-priority periodic caller (CheckFtaPresence()) kick off a read and
*  check back later instead of blocking/spinning on the transfer.
*******************************************************************************/
/* Integration-safe IOTA status API.
 * J3 uses only blocking LPSPI2 transfers for FPGA/HART. Keep these optional
 * APIs synchronous so no LPSPI2 IRQ/handle can overlap a HART register access. */
static volatile BOOL s_iotaReadPending = FALSE;
static volatile BOOL s_iotaReadReady = FALSE;
static volatile UINT8 s_iotaReadResult = 0u;

void hal_fpga_start_iota_read(void)
{
    s_iotaReadPending = TRUE;
    s_iotaReadResult = (UINT8)((hal_fpga_read(FPGA_IOLIOTASR) >> 8) & 0xFFu);
    s_iotaReadPending = FALSE;
    s_iotaReadReady = TRUE;
}

BOOL hal_fpga_iota_read_pending(void)
{
    return s_iotaReadPending;
}

BOOL hal_fpga_iota_read_ready(void)
{
    return s_iotaReadReady;
}

UINT8 hal_fpga_get_iota_result(void)
{
    s_iotaReadReady = FALSE;
    return s_iotaReadResult;
}

/*******************************************************************************
*                          hal_fpga_init                                       *
*******************************************************************************/
void hal_fpga_init(void)
{
    lpspi_master_config_t config;

    LPSPI_MasterGetDefaultConfig(&config);
    config.baudRate     = FPGA_SPI_BAUDRATE;
    config.cpol         = kLPSPI_ClockPolarityActiveHigh;   /* CPOL=0 */
    config.cpha         = kLPSPI_ClockPhaseFirstEdge;       /* CPHA=0 */
    config.direction    = kLPSPI_MsbFirst;
    config.pcsToSckDelayInNanoSec    = 100;
    config.lastSckToPcsDelayInNanoSec = 100;
    config.betweenTransferDelayInNanoSec = 200;  /* Clock stretch gap */
    config.whichPcs     = FPGA_SPI_PCS;
    config.pcsActiveHighOrLow = kLPSPI_PcsActiveLow;

    LPSPI_MasterInit(FPGA_SPI_BASE, &config, FPGA_SPI_CLOCK_FREQ);

}

/*******************************************************************************
*                          hal_fpga_read                                       *
*  SPI Read Transaction (3 bytes):                                             *
*    TX: [1_ADDR6..0] [0x00] [0x00]                                           *
*    RX: [ignored]    [D15:8] [D7:0]                                           *
*******************************************************************************/
UINT16 hal_fpga_read(UINT8 addr)
{
    UINT8 txBuf[3] = {0u, 0u, 0u};
    UINT8 rxBuf[3] = {0u, 0u, 0u};

    txBuf[0] = SPI_CMD_READ(addr);

    lpspi_transfer_t xfer;
    xfer.txData   = txBuf;
    xfer.rxData   = rxBuf;
    xfer.dataSize = 3u;
    xfer.configFlags = FPGA_SPI_PCS | kLPSPI_MasterPcsContinuous;

    if (FpgaSpiTransfer(&xfer) != kStatus_Success)
    {
        return 0u;
    }

    /* Response in bytes 1-2: MSB first. */
    return (UINT16)(((UINT16)rxBuf[1] << 8) | (UINT16)rxBuf[2]);
}

/********************************************************************************
*                          hal_fpga_write                                      *
*  SPI Write Transaction (3 bytes):                                            *
*    TX: [0_ADDR6..0] [D15:8] [D7:0]                                          *
*    RX: [don't care]                                                          *
*******************************************************************************/
void hal_fpga_write(UINT8 addr, UINT16 data)
{
    UINT8 txBuf[3];

    txBuf[0] = SPI_CMD_WRITE(addr);
    txBuf[1] = (UINT8)(data >> 8);     /* MSB */
    txBuf[2] = (UINT8)(data & 0xFF);   /* LSB */

    lpspi_transfer_t xfer;
    xfer.txData   = txBuf;
    xfer.rxData   = NULL;
    xfer.dataSize = 3;
    xfer.configFlags = FPGA_SPI_PCS | kLPSPI_MasterPcsContinuous;

    (void)FpgaSpiTransfer(&xfer);
}

#endif /* RT1024_BUILD */
