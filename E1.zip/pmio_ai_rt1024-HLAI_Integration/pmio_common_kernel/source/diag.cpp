/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : diag.cpp                                                    *
*    Description : Implements common diagnostics                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif

#include "utils.h"

/*******************************************************************************
*                          FtaPresenceChecking                                 *
*                          ===================                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID CheckFtaPresence(VOID)
{
    //static BOOL FtaCheckRepeat = FALSE;

    // This function is called every ~100ms from LowPriorityTask
    // (TASKID_LPTASK), which has a limited DMC watchdog budget
    // (DMCPERIOD_LPTASK). hal_fpga_get_iota_status() -> hal_fpga_read()
    // is a BLOCKING SPI transfer (LPSPI_MasterTransferBlocking) — the
    // transfer itself only takes a few microseconds, but under heavy IOL
    // UART interrupt load the CPU's polling loop kept getting preempted,
    // stretching the *wall-clock* stall long enough to blow the DMC
    // budget, causing continuous "DMC EXPIRE" reports for task 2.
    //
    // NOTE: an earlier fix attempted a separate interrupt-driven
    // non-blocking transfer (hal_fpga_start_iota_read() etc., see
    // hal_fpga_spi.c) running concurrently with the other BLOCKING
    // hal_fpga_read()/hal_fpga_write() call sites elsewhere (adc.cpp,
    // aihboxslot.cpp) on the SAME LPSPI2 peripheral. LPSPI_MasterTransferBlocking()
    // does not coordinate with the handle-based/IRQ-driven transfer, so
    // the two corrupted each other's SPI state — this is what caused
    // wrong FPGA_IOTA_REDUNT_n/FPGA_IOTA_BOTTOM bits and broader FPGA
    // misbehavior. Do NOT re-introduce that without a proper mutex
    // guarding ALL hal_fpga_read()/hal_fpga_write() call sites.
    //
    // Instead, mask all interrupts for just this short (~microseconds)
    // transaction so the IOL UART ISR storm cannot preempt the polling
    // wait and stretch it out. This bounds the worst-case stall
    // deterministically without touching any other FPGA access path.
    UINT32 ucSaveExr = hal_interrupt_set_mask(LVLPRI_HIGHEST);
    UINT8 iotabits = (UINT8)hal_fpga_get_iota_status();
    hal_interrupt_set_mask(ucSaveExr);

    // temp for testing — force FTA present for DB-path verification
    //iotabits |= FPGA_IOTA_REDUNT_n;
    
    BOOL FtaPresence = (iotabits & FPGA_IOTA_REDUNT_n) ? FALSE : TRUE;

    // any change in FTA behaviour (present / missing)
    //if ((FtaMissing != BOX->GetFtaPres()) || (FtaCheckRepeat))
    {
        // Updating FTA Presence bit in MODSTAT2
        BOX->SetFtaPres(FtaPresence);

#if !defined(IOPTYPE_AO16)
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_FTAMISSG, (FtaPresence==FALSE), 0);
#endif
        // added to update IotaPos bit correctly
        //FtaCheckRepeat = (FtaCheckRepeat) ? FALSE : TRUE;

        //BOX->SetIotaPos((BOTTOM==DEASSERTED));
        BOX->SetIotaPos((iotabits & FPGA_IOTA_BOTTOM) ? ASSERTED : DEASSERTED);
    }
#if defined(IOPTYPE_AO16)
    if (uiFtaReturnTimeout) --uiFtaReturnTimeout;
#endif

}
