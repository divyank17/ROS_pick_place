/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : utils.h                                                     *
*    Description : Common utility declarations for RT1024/QEMU.                *
*                  Stripped to portable functions only (no H8S register access).*
*******************************************************************************/
#ifndef __UTILS_H__
#define __UTILS_H__

#include "debug.hpp" // temporary

#include "datatype.h"
#include "hardfail.h"

/* RETURNSTATUS is defined in global.h — include global.h before this header */
#include "global.h"

/*******************************************************************************
*                         HARD FAIL FUNCTION                                   *
*  Prototype — implementation in hardfail.cpp                                  *
*******************************************************************************/
#ifdef __cplusplus
void HardFail(HARDFAILTYPE a_HfCode, FILE_NAME a_FlIdx = UNKNOWN_FILE,
              UINT16 a_LnNo = 0, UINT8 a_Parm1 = 0, UINT8 a_Parm2 = 0);
#else
void HardFail(HARDFAILTYPE a_HfCode, FILE_NAME a_FlIdx, UINT16 a_LnNo,
              UINT8 a_Parm1, UINT8 a_Parm2);
#endif

/*******************************************************************************
*                                 ShutdownIom                                  *
*                                 ===========                                  *
* PURPOSE : Reboot the module to ALIVE state.                                  *
*******************************************************************************/
inline VOID ShutdownIom(VOID) {
    //SET_DIP  = 1; // Set DIP pin so the boot will stay in ALIVE state
    //RebootIom();
}

BOOL RealCompare(FLOAT32 a_flVal, FLOAT32 a_frVal);

/*******************************************************************************
*                               clsOlympicAverage                              *
*                               =================                              *
*******************************************************************************/
class clsOlympicAverage {
    UINT8   ucNoOfSamples;
#if LOWCOST
    UINT32  uiHiSample;
    UINT32  uiLoSample;
#else
    UINT16  uiHiSample;
    UINT16  uiLoSample;
#endif
    FLOAT32 fAccumulator;

#if 0
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    #if defined(IOMTYPE_AIHBOOT) || defined(IOMTYPE_AOHBOOT)   || \
    defined(IOMTYPE_LLMUXBOOT)   || defined(IOMTYPE_DIBOOT)    || \
    defined(IOMTYPE_DOBOOT)      || defined(IOMTYPE_DISOEBOOT) || \
    defined(IOMTYPE_SVPBOOT)     || defined(IOMTYPE_SPBOOT)    || \
    defined(IOMTYPE_PIBOOT)      || defined(IOMTYPE_UIOBOOT)
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC); }
    #else
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,UTILS_H,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,UTILS_H,__LINE__); }
    #endif
#endif

    clsOlympicAverage(const clsOlympicAverage&); // Safeguard against def copy constr.
    clsOlympicAverage& operator=(const clsOlympicAverage&); // and default assignment.

public:
    clsOlympicAverage(VOID) { Initialize(); }
    ~clsOlympicAverage(VOID) {}

    VOID Initialize(VOID) {
        ucNoOfSamples = 0;
        uiHiSample    = 0;
#if LOWCOST
        uiLoSample    = MAXUINT32;
#else
        uiLoSample    = MAXUINT16;
#endif
        fAccumulator  = 0.0;
    }

#if LOWCOST
    VOID AddSample(UINT32 a_uiSample) {
#else
    VOID AddSample(UINT16 a_uiSample) {
#endif
        ucNoOfSamples++;
        fAccumulator += (FLOAT32)a_uiSample;
        if (a_uiSample > uiHiSample) uiHiSample = a_uiSample;
        if (a_uiSample < uiLoSample) uiLoSample = a_uiSample;
    }

    FLOAT32 GetResult(VOID) {
        // It was observed that the code fAccumulator -= (uiHiSample + uiLoSample)
        // could not be used (uiHiSample + uiLoSample) resulted in UINT16 overflow.
        fAccumulator -= (FLOAT32)uiHiSample;
        fAccumulator -= (FLOAT32)uiLoSample;
        ucNoOfSamples -= 2;
        fAccumulator /= (FLOAT32)ucNoOfSamples;
        FLOAT32 fCeil = ceil(fAccumulator);
        if ((fCeil - fAccumulator) <= (FLOAT32)0.5) fAccumulator = fCeil;
        return fAccumulator;
    }

#if LOWCOST
    UINT32 GetHiSample(VOID) { return uiHiSample; }
    UINT32 GetLoSample(VOID) { return uiLoSample; }
#else
    UINT16 GetHiSample(VOID) { return uiHiSample; }
    UINT16 GetLoSample(VOID) { return uiLoSample; }
#endif
};

/*******************************************************************************
*                         MAXUINT CONSTANTS                                    *
*  MAXUINT8, MAXUINT16, MAXUINT32 are already defined as macros in datatype.h *
*******************************************************************************/

/* TRUE / FALSE / NULL are also in datatype.h */

#endif /* __UTILS_H__ */


