/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : inslot.hpp                                                  *
*    Description : Class clsInSlot declaration.                                *
*******************************************************************************/
#ifndef __INSLOT_HPP__
#define __INSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "ioslot.hpp"
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/

const UINT8 PARAMID_OWDENABLE  = 143;  /* Open wire detect enable (BOOL)    */

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/

typedef enum tagPvSource {
    PVSOURCE_SUB     = 0,
    PVSOURCE_MANUAL  = 1,
    PVSOURCE_AUTO    = 2,
    PVSOURCE_TRACK   = 3
} PVSOURCE;

typedef enum tagPvSrcOpt {
    PVSRCOPT_ONLYAUTO = 0,
    PVSRCOPT_ALL      = 1
} PVSRCOPT;

typedef enum tagInptDir {
    INPTDIR_DIRECT  = 0,
    INPTDIR_REVERSE = 1
} INPTDIR;

/*******************************************************************************
*                                   clsInSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsInSlot : public clsIoSlot {
protected:
    // !!!*** IN_SLOT_DUMP_RECORD ***!!!
    // This class is wholly contained within an input slot's redundant synch
    // data area. No data members can be added or deleted to this class. This
    // would break the IOM FO upgrade procedure that OPM depends on.
    // Any new data members to be added to an input slot's dump record must be
    // added at the end in cls<iomtype>Slot or to the spare memory allocated.
    // If new member is added to the end class, cls<iomtype>Slot::GetRedSlotSize()
    // must be updated to reference the new end member. This dump record ends
    // in cls<iomtype>Slot.
    BOOL        ContCut;
    PVSOURCE    PvSource;
    PVSRCOPT    PvSrcOpt;
    BOOL        OwdEnable;
    UINT8       InSlotSpare[4];

    clsInSlot(PNTTYPE a_PntType, UINT8 a_ucSltNm) : clsIoSlot(a_PntType,a_ucSltNm) {
        InitInSlot(TRUE,TRUE);
        InSlotSpare[0] = 0;
        InSlotSpare[1] = 0;
        InSlotSpare[2] = 0;
        InSlotSpare[3] = 0;
    }

    VOID InitInSlot(BOOL bFullInit, BOOL) {
        ContCut   = FALSE;
        OwdEnable = FALSE;
        if (bFullInit) {
            PvSource = PVSOURCE_AUTO;
            PvSrcOpt = PVSRCOPT_ONLYAUTO;
        }
    }

    virtual ~clsInSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,INSLOT_HPP,__LINE__); }

    inline VOID *GetContCutPtr(VOID)    { return &ContCut; }
    inline VOID *GetPvSourcePtr(VOID)   { return &PvSource; }
    inline VOID *GetPvSrcOptPtr(VOID)   { return &PvSrcOpt; }
    inline VOID *GetOwdEnablePtr(VOID)  { return &OwdEnable; }

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    //VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,INSLOT_HPP,__LINE__); return NULL; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,INSLOT_HPP,__LINE__); }

    clsInSlot(const clsInSlot&); // Safeguard against default copy constructor
    clsInSlot& operator=(const clsInSlot&); // and defualt assignement.

#if !defined(IOMTYPE_UIO)
    inline PASTATUS PreCheckPoint(UINT8 *, UINT8) {
            SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
        return PA_OK;
    }
#endif

public:
    inline BOOL GetOwdEnable(VOID) { return OwdEnable;}

#if 1 // temp for testing
    inline PVSOURCE GetPvSource(VOID)   { return PvSource; }
#endif
};
#endif //__INSLOT_HPP__
