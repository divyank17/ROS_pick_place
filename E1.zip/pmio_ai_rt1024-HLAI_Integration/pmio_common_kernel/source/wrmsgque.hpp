/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : wrmsgque.hpp                                                *
*    Description : Write message queue for RT1024/QEMU — AIH-only.            *
*******************************************************************************/
#ifndef __WRMSGQUE_HPP__
#define __WRMSGQUE_HPP__

#include "datatype.h"
#include "global.h"
#include "utils.h"

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
/* IOL_MAXRCV_MSGSIZE is defined in global.h */

const UINT16 WRITEMSG_QUEUESIZE = 2048;
const UINT16 WRITEMSG_BUFFERSIZE = WRITEMSG_QUEUESIZE + IOL_MAXRCV_MSGSIZE;
const UINT16 WRITESTS_ARRAYSIZE = 256;

/* IOL message field offsets — use values from global.h */
const UINT8 IOLWRMSG_OVERHEAD = 6;

/* Write database command queue indices */
const UINT8 WRCMD_BLOCKABSOLUTE  = 0x03;
const UINT8 WRCMD_NORMAL         = 0x0A;
const UINT8 WRCMD_INDEXDEFERRED  = 0x0C;
const UINT8 WRCMD_INDEXED        = 0x12;
const UINT8 WRCMD_TOG            = 0x20;
const UINT8 WRCMD_FREEZE         = 0x2F;

/*******************************************************************************
*                              clsWriteMsgQueue                                *
*******************************************************************************/
class clsWriteMsgQueue {
protected:
    UINT8 ucMsgBuffer[WRITEMSG_BUFFERSIZE];
    UINT8 ucMsgStatus[WRITESTS_ARRAYSIZE];
    UINT8 *ucpAppend;
    UINT8 *ucpRemove;

    clsWriteMsgQueue(const clsWriteMsgQueue&);
    clsWriteMsgQueue& operator=(const clsWriteMsgQueue&);

public:
    clsWriteMsgQueue(void) {
        ucpAppend = ucpRemove = ucMsgBuffer;
        for (UINT16 i = 0; i < WRITESTS_ARRAYSIZE; i++) {
            ucMsgStatus[i] = 0;
        }
    }
    ~clsWriteMsgQueue(void) {}

    inline UINT8 *GetRcvBufPtr(void) { return ucpAppend; }
    inline UINT8 *GetNextMsgPtr(void) { return ucpRemove; }

    inline UINT8 GetMsgStatus(UINT8 a_ucMsgNum) {
        return ucMsgStatus[a_ucMsgNum];
    }
    inline void SetMsgStatus(UINT8 a_ucMsgNum, UINT8 a_ucMsgStatus) {
        ucMsgStatus[a_ucMsgNum] = a_ucMsgStatus;
    }

    inline BOOL IsRcvBfrEmpty(void) {
        return (ucpRemove == ucpAppend) ? TRUE : FALSE;
    }

    inline BOOL WillRcvBfrOverflow(UINT8 a_ucMsgSize) {
        UINT16 usUsed;
        if (ucpAppend >= ucpRemove) {
            usUsed = (UINT16)(ucpAppend - ucpRemove);
        } else {
            usUsed = WRITEMSG_QUEUESIZE - (UINT16)(ucpRemove - ucpAppend);
        }
        return ((usUsed + (UINT16)a_ucMsgSize + IOL_MAXRCV_MSGSIZE)
                 > WRITEMSG_QUEUESIZE) ? TRUE : FALSE;
    }

    inline void AddMessage(UINT8 a_ucMsgNumber, UINT8 a_ucMsgSize) {
        ucMsgStatus[a_ucMsgNumber] = IOL_WM_IN_PROGRESS;
        ucpAppend += a_ucMsgSize;
        *ucpAppend++ = a_ucMsgNumber;
        if (ucpAppend > ucMsgBuffer + WRITEMSG_QUEUESIZE) {
            ucpAppend -= WRITEMSG_QUEUESIZE;
        }
    }

    inline void RemoveMessage(UINT8 a_ucMsgNumber, UINT8 a_ucMsgSize) {
        ucpRemove += a_ucMsgSize + 1;
        if (ucpRemove > ucMsgBuffer + WRITEMSG_QUEUESIZE) {
            ucpRemove -= WRITEMSG_QUEUESIZE;
        }
    }
};

extern clsWriteMsgQueue WriteMsgQueue;
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);

#endif /* __WRMSGQUE_HPP__ */
