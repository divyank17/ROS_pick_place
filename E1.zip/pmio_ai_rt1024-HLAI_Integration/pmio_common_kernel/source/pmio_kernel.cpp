/*
 * Copyright 2016-2026 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file    MIMXRT1024_Project.cpp
 * @brief   Application entry point.
 */
//#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */
#include "hal.h"
#include "aihmain.h"
/* TODO: insert other definitions and declarations here. */

NANINIT  NaNInit;  // For initializing NaN value.

extern VOID AppMain(VOID);


/*
 * @brief   Application entry point.
 */
int main(void) {

    /* Init board hardware. */
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();

    /* Initialize default GPIO directions/levels before GPIO adapter IRQ setup. */
    hal_gpio_init();

    /* Init LPSPI4 as SPI master for ADC communication. Must be done before any
     * Adc.GetRawData() call, otherwise LPSPI4 stays clock-gated/disabled and
     * the TX FIFO never drains, hanging in the polling loops forever. */
    Adc.Init();

    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    /* J3-compatible ordering: initialize the FPGA/HART LPSPI2 transport after
     * all generated board peripheral initialization has completed. */
    hal_fpga_init();

    /* ~10 second JTAG attach window — remove once board bring-up is stable */
    for (volatile UINT32 ulDelay = 0; ulDelay < 5000000UL; ulDelay++) { NOP; }

#ifdef DBG_PRINT
    PRINTF("\r\nPMIO HLAIH\r\n");
	PRINTF("FPGA REVNUM: %2X.%2X\r\n", hal_fpga_get_rev_letter(), hal_fpga_get_rev_number());

    UINT8 modnum = hal_fpga_get_modnum();
    UINT8 fileno = ((modnum >> 4) & 0x07) + 1;
    UINT8 slotno = (modnum & 0x0F) + 1;

    PRINTF("RAW MODLNUM: %02X\r\n", modnum);
    PRINTF("FILE NUMBER: %02X\r\n", fileno);
    PRINTF("SLOT NUMBER: %02X\r\n", slotno);

    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {

    	Eeprom.EnableWrite();
        Eeprom.WriteByte(EE_HARDWARE_REVCODE, 1);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_HARDWARE_REVNUMBER, 0);
        Eeprom.CheckWriteInProgress();

        UINT8 HWR1 = Eeprom.ReadByte(EE_HARDWARE_REVCODE);
        UINT8 HWR2 = Eeprom.ReadByte(EE_HARDWARE_REVNUMBER);

        PRINTF("HW REVISION: %02X.%0X\r\n", HWR1, HWR2);
    }

#endif

    NaNInit.ulDword = SIGNL_NAN; // Initialize NaN value

    AppMain();

    /* Enter an infinite loop, just incrementing a counter. */
    while(1) {
    	;
    }

    return 0 ;
}
