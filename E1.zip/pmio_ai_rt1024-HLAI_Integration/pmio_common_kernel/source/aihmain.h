/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihmain.h                                                   *
*    Description : Master include for AIH module — RT1024/QEMU.               *
*                  Replaces the epicio_src/aihmain.h which included            *
*                  everything + H8S hardware definitions.                      *
*******************************************************************************/
#ifndef __AIHMAIN_H__
#define __AIHMAIN_H__

/*******************************************************************************
*                           HAL + PLATFORM                                     *
*******************************************************************************/
#include "hal/hal.h"

/*******************************************************************************
*                           CORE TYPES                                         *
*******************************************************************************/
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "commonelectronics.h"
#include "softfail.h"
#include "adc.hpp"
#include "eeprom.hpp"
/*******************************************************************************
*                           SCHEDULER                                          *
*******************************************************************************/
#include "scheduler.hpp"

/*******************************************************************************
*                           TRACELOG / ECL                                      *
*******************************************************************************/
//#include "tracelog.hpp"
//#include "ecl.hpp"

/*******************************************************************************
*                           HART PASSTHROUGH TYPES                             *
*******************************************************************************/
//#include "hartpst.hpp"

/*******************************************************************************
*                           IOL COMMUNICATION                                  *
*******************************************************************************/
#include "iol.hpp"
#include "wrmsgque.hpp"

/*******************************************************************************
*                           DATABASE CLASSES                                   *
*******************************************************************************/
#include "iomslot.hpp"
#include "boxslot.hpp"
#include "aihslot.hpp"
#include "aihboxslot.hpp"
#include "aihversion.h"

/*******************************************************************************
*                           DIAGNOSTICS / DEBUG                                *
*******************************************************************************/
#include "diag.h"
//#include "debug.hpp"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/

#endif /* __AIHMAIN_H__ */
