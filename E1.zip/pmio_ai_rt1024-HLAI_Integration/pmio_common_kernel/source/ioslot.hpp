/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : ioslot.hpp                                                  *
*    Description : Class clsIoSlot declaration.                                *
*******************************************************************************/
#ifndef __IOSLOT_HPP__
#define __IOSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "iomslot.hpp"
/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
const UINT8 SLOTSF_10SEC_THROTTLE_COUNT = 100;
const UINT8 PTEXECST_NO_TRANS    = 0;
const UINT8 PTEXECST_INACT_INACT = 1;
const UINT8 PTEXECST_INACT_ACT   = 2;
const UINT8 PTEXECST_ACT_INACT   = 3;
const UINT8 PTEXECST_ACT_ACT     = 4;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagPntType {
    PNTTYPE_NOTCONFIGURED = 0,
    PNTTYPE_ANALOGINPUT   = 1,
    PNTTYPE_ANALOGOUTPUT  = 2,
    PNTTYPE_DIGITALINPUT  = 4,
    PNTTYPE_DIGITALOUTPUT = 5,
//The enumerations between 5 and 32 are used up in the file /db/src/IOLIM/pm_pnttype.enm.xml
    PNTTYPE_SVP           = 32,
    PNTTYPE_SP            = 33,
    PNTTYPE_PULSEINPUT    = 34,
    PNTTYPE_UNIVERSALIO   = 35
} PNTTYPE;

typedef enum tagPtExecSt {
    PTEXECST_INACTIVE = 0,
    PTEXECST_ACTIVE   = 1
} PTEXECST;

// for redesign PMIO,
typedef enum tagPntForm {
    PNTFORM_FULL = 0,
    PNTFORM_COMPONENT = 1
} PNTFORM;

/*******************************************************************************
*                                   clsIoSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsIoSlot : public clsIomSlot {

protected:
    UINT8       SlotSfBt;
    UINT8       SlotSfLrs;
    UINT8       SlotSfThrottleByte;
    UINT8       SlotSfThrottleCount;
    // !!!*** IO_SLOT_DUMP_RECORD_BEGIN ***!!!
    // This marks the beginning of all i/o slot's redundant synch data area.
    // No data members that are not to be synch'd can be declared below this
    // point. Any new data members to be added to this dump record must be
    // added at the end in cls<iomtype>Slot or to the spare allocated. If the
    // new member is added to the end class, cls<iomtype>Slot::GetRedSlotSize()
    // must be updated to reference the new end member. This dump record includes
    // one of either clsInSlot or clsOutSlot and ends in cls<iomtype>Slot.
    PNTTYPE     PntType;
    PTEXECST    PtExecSt;

    // for redesign PMIO,
    UINT8       PtExecStLrs;
    PNTFORM     PntForm;
    UINT8       IoSlotSpare[2];

    clsIoSlot(PNTTYPE a_PntType, UINT8 a_ucSltNm) : clsIomSlot(a_ucSltNm) {
        InitIoSlot(a_PntType, TRUE, TRUE);
        IoSlotSpare[0] = 0;
        IoSlotSpare[1] = 0;
    }

    VOID InitIoSlot(PNTTYPE a_PntType, const BOOL bFullInit, const BOOL bObjCreate) {
        PntType   = a_PntType;

        if (bObjCreate) {
            PtExecSt        = PTEXECST_INACTIVE;
            SlotSfBt        = 0;
            SlotSfLrs       = 0;
            SlotSfThrottleByte = 0;
            SlotSfThrottleCount = 0;
        }
        if (bFullInit)
        {
            PtExecSt = PTEXECST_INACTIVE;
        }

        // for redesign PMIO,
#if 1 //defined(IOPTYPE_HLAI)
        PntForm = PNTFORM_FULL;
#elif defined(IOPTYPE_AO16) || defined(IOPTYPE_DO)
        PntForm = PNTFORM_COMPONENT;
#endif
        PtExecStLrs = PTEXECST_INACTIVE;
    }

    virtual ~clsIoSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,IOSLOT_HPP,__LINE__); }

    inline VOID *GetPntTypePtr(VOID)    { return &PntType; }
    inline VOID *GetPtExecStPtr(VOID)   { return &PtExecSt; }

    // for all PMIO Redesign module IoSlots
    inline VOID *GetPntFormPtr(VOID)    { return &PntForm; }
    inline VOID *GetPtExecStLrsPtr(VOID){ return &PtExecStLrs; }

    inline VOID *GetSlotSfBtPtr(VOID)   { return &SlotSfBt; }
    inline VOID *GetSlotSfLrsPtr(VOID)  { return &SlotSfLrs; }

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    //VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,IOSLOT_HPP,__LINE__); return NULL; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,IOSLOT_HPP,__LINE__); }

    clsIoSlot(const clsIoSlot&);            // Safeguard against default copy constructor
    clsIoSlot& operator=(const clsIoSlot&); // and defualt assignement.

public:

    virtual BOOL RegenChannelEvents(VOID) { return TRUE; }

    inline PTEXECST GetPtExecSt(VOID)   { return PtExecSt; }
    inline PNTTYPE  GetPntType(VOID)    { return PntType; }
    inline UINT8 GetSlotSfBt(VOID)      { return SlotSfBt; }
    inline VOID  SetSlotSfBt(UINT8 a_ucByte){ SlotSfBt = a_ucByte; }
    inline UINT8 GetSlotSfLrs(VOID)         { return SlotSfLrs; }
    inline VOID  SetSlotSfLrs(UINT8 a_ucByte) { SlotSfLrs = a_ucByte; }

    inline VOID CountDownSlotSfThrottle(VOID) { if (SlotSfThrottleCount > 0) SlotSfThrottleCount--; }
    inline BOOL IsSlotSfToBeThrottled(UINT8 a_ucByte,BOOL a_bDir) {
        BOOL bRetVal = FALSE;
        if (TRUE == a_bDir) { // softfail is being reported
            if (0 == (SlotSfThrottleByte & a_ucByte)) {
                // If it is not set in SlotSfThrottleByte, it is newly being reported.
                // Set the bit and start the throttle counter to minimize chattering.
                SlotSfThrottleByte |=  a_ucByte;
                SlotSfThrottleCount = SLOTSF_10SEC_THROTTLE_COUNT;
            }
        }
        else { // softfail is being returned
            if (SlotSfThrottleByte & a_ucByte) {
                // If the bit is set in SlotSfThrottleByte, it is newly being returned.
                // Reset the bit and restart the throttle counter to ensure 10 seconds
                // good run before softfail is returned.
                SlotSfThrottleByte &= ~a_ucByte;
                SlotSfThrottleCount = SLOTSF_10SEC_THROTTLE_COUNT;
            }
            // Allow the softfail to be returned only if throttling is not going on.
            if (SlotSfThrottleCount > 0) {
                bRetVal = TRUE;
            }
        }
        return bRetVal;
    }
};

#endif /* __IOSLOT_HPP__ */
