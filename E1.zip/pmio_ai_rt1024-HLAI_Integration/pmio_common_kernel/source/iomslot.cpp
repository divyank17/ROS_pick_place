/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iomslot.cpp                                                 *
*    Description : IOM database interface functions — ReadParamData,           *
*                  WriteParamData, ComputeCheckSum, ComputeRedCheckSum.        *
*                                                                              *
*    Ported from epicio_src/iomslot.cpp (H8S original).                        *
*    Stripped to AIH-only (no SVP/SP/UIO/DISOE conditionals).                  *
*    H8S set_imask_exr/get_imask_exr replaced with HAL calls.                  *
*******************************************************************************/
#include "iomslot.hpp"
#include "boxslot.hpp"
#include "utils.h"

class clsIomSlot;

/*******************************************************************************
*                          STATIC DATA                                         *
*******************************************************************************/
DATABYTES       clsIomSlot::Data;
UINT8           clsIomSlot::ScratchPad = 0;
UINT8           clsIomSlot::WriteIndex = 0;
UINT8           clsIomSlot::SlotChkpntVersion = 0;
//UINT8           clsIomSlot::BoxChkpntVersion = 0;
//PASTATUS        clsIomSlot::ucSaveChkpntPaStatus = PA_OK;
WRITEINPROGRESS clsIomSlot::WriteInProgress = { NULL, NULL };

/*******************************************************************************
*                   IsMultiByteScalar (local helper)                           *
*                   =================================                         *
* PURPOSE:                                                                     *
*    AT_MBYTE covers two very different things: true multi-byte numeric        *
*    scalars (UINT16/INT16/UINT32/INT32/FLOAT32) that need byte-order          *
*    conversion between the wire (big-endian, inherited from the H8S)  and     *
*    this ARM Cortex-M7's native little-endian storage, and opaque DT_BLIND    *
*    byte arrays/records (device tags, HART frames, etc.) that must be         *
*    copied byte-for-byte with no reordering.  This distinguishes the two.     *
*******************************************************************************/
static inline BOOL IsMultiByteScalar(DATATYPE a_dt, UINT8 a_ucSize)
{
    if (a_ucSize < 2u || a_ucSize > (UINT8)sizeof(DATABYTES)) {
        return FALSE;
    }
    switch (a_dt) {
        case DT_UINT16:
        case DT_INT16:
        case DT_UINT32:
        case DT_INT32:
        case DT_FLOAT32:
            return TRUE;
        default:
            return FALSE;
    }
}

/*******************************************************************************
*                   clsIomSlot::ReadParamData (basic)                          *
*                   ================================                           *
* PURPOSE:                                                                     *
*    Read parameter data from the database into a_pDest.  Dispatches by        *
*    AccessType: SBYTE, MBYTE, PSET, BXPACK, BXREC.                            *
* ARGUMENTS:                                                                   *
*    a_pDest     : destination buffer for the parameter data.                  *
*    a_ucParamId : parameter index (0–255).                                    *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    WriteInProgress guard prevents torn reads on multi-byte params.           *
*******************************************************************************/
void clsIomSlot::ReadParamData(UINT8 *a_pDest, UINT8 a_ucParamId)
{
    UINT8 *pSource = GetParamPtr(a_ucParamId);
    if (pSource == NULL) {
        return;
    }

    ACCESSTYPE at = GetAccessType(a_ucParamId);

    switch (at) {
        case AT_SBYTE:
            *a_pDest = *pSource;
            break;

        case AT_MBYTE: {
            /* Redirect to write buffer if a write is in progress to this
               exact location — prevents torn reads of multi-byte data */
            UINT8 *pActual = pSource;
            if (WriteInProgress.pDatabase == pSource &&
                WriteInProgress.pWriteBuffer != NULL) {
                pActual = WriteInProgress.pWriteBuffer;
            }
            UINT8 ucSize = GetParamSize(a_ucParamId);
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucSize)) {
                /* Numeric scalar: native byte order -> wire byte order. */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pActual[ucSize - 1u - i];
                }
            } else {
                /* Opaque BLIND byte array/record: copy as-is, then let the
                   derived class swap any embedded scalar fields it knows
                   about (e.g. a FLOAT32 inside a repeating struct array). */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pActual[i];
                }
                TransformBlindRecord(a_ucParamId, a_pDest, ucSize, TRUE);
            }
            break;
        }

        case AT_PSET: {
            /* Parameter-set: pSource is a null-terminated list of
               sub-parameter IDs. Walk the list, copying each sub-param. */
            while (*pSource != 0) {
                UINT8 ucSubParam = *pSource;
                UINT8 *pSubSrc   = GetParamPtr(ucSubParam);
                UINT8  ucSubSz   = GetParamSize(ucSubParam);

                if (pSubSrc != NULL) {
                    /* Check WriteInProgress for multi-byte sub-params */
                    if (ucSubSz > 1 &&
                        WriteInProgress.pDatabase == pSubSrc &&
                        WriteInProgress.pWriteBuffer != NULL) {
                        pSubSrc = WriteInProgress.pWriteBuffer;
                    }
                    if (IsMultiByteScalar(GetDataType(ucSubParam), ucSubSz)) {
                        for (UINT8 j = 0; j < ucSubSz; j++) {
                            a_pDest[j] = pSubSrc[ucSubSz - 1u - j];
                        }
                        a_pDest += ucSubSz;
                    } else {
                        for (UINT8 j = 0; j < ucSubSz; j++) {
                            *a_pDest++ = *pSubSrc++;
                        }
                    }
                }
                pSource++;
            }
            /* For large checkpoint reads, reset STC overrun counter so the
               IOL TX phase doesn't trigger a spurious STC overrun softfail. */
            if (ChanNum != 0 && a_ucParamId == PARAMID_SLTCHKPNT) {
                //TaskScheduler.SetStcOverrunCounter(1);
            }
            break;
        }

        case AT_BXPACK: {
            /* Box-packed bitmap: each channel's data is one bit inside
               a box-level byte array.  Extract the bit for this channel. */
            UINT8 ucBitIndex  = 0x80u >> ((ChanNum - 1) & 0x07);
            UINT8 ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
            *a_pDest = (pSource[ucByteIndex] & ucBitIndex) ? TRUE : FALSE;
            break;
        }

        case AT_BXREC: {
            /* Box blind record: block copy under interrupt protection */
            UINT8 ucSize = GetParamSize(a_ucParamId);
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucSize)) {
                /* Numeric scalar (e.g. per-channel Pv): native -> wire order. */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[ucSize - 1u - i];
                }
            } else {
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[i];
                }
                TransformBlindRecord(a_ucParamId, a_pDest, ucSize, TRUE);
            }
            break;
        }

        default:
            HardFail(HF_BADPROGRAMJUMP, IOMSLOT_CPP, __LINE__);
            break;
    }
}




PASTATUS clsIomSlot::WriteParamData(UINT8 *a_pSrc, UINT8 a_ucParamId, UINT8 a_ucLen, BOOL a_bDoChkSm)
{
	UINT8 *pDestination = GetParamPtr(a_ucParamId);

	if (pDestination == NULL) {
		return DO_PARAMETER_INVALID;
	}

	ACCESSTYPE at = GetAccessType(a_ucParamId);
	UINT8 ucParamSize = GetParamSize(a_ucParamId);

#if 0
	/* ---- Checkpoint version negotiation ---- */
	if (ChanNum == 0 && a_ucParamId == PARAMID_BOXCHKPNT) {
		ucSaveChkpntPaStatus = PA_OK;
		UINT8 ucIncomingVer = *a_pSrc;
		if (ucIncomingVer > BoxChkpntVersion) {
			/* Incoming checkpoint is newer than we support — accept partial */
			pDestination = (UINT8 *)GetCheckPointPtr(BoxChkpntVersion);
			ucParamSize  = GetCheckPointSize(BoxChkpntVersion);
			ucSaveChkpntPaStatus = PA_BAD_PARAMETER_VALUE;
		} else {
			pDestination = (UINT8 *)GetCheckPointPtr(ucIncomingVer);
			ucParamSize  = GetCheckPointSize(ucIncomingVer);
		}
		*a_pSrc = BoxChkpntVersion;  /* Stamp latest version */
	}
	else if (ChanNum != 0 && a_ucParamId == PARAMID_SLTCHKPNT) {
		ucSaveChkpntPaStatus = PA_OK;
		UINT8 ucIncomingVer = *a_pSrc;
		if (ucIncomingVer > SlotChkpntVersion) {
			pDestination = (UINT8 *)GetCheckPointPtr(SlotChkpntVersion);
			ucParamSize  = GetCheckPointSize(SlotChkpntVersion);
			ucSaveChkpntPaStatus = PA_BAD_PARAMETER_VALUE;
		} else {
			pDestination = (UINT8 *)GetCheckPointPtr(ucIncomingVer);
			ucParamSize  = GetCheckPointSize(ucIncomingVer);
		}
		*a_pSrc = SlotChkpntVersion;
	}
#endif
/* ---- Copy incoming data to aligned scratch ---- */
	UINT8 ucCopyLen = (a_ucLen < ucParamSize) ? a_ucLen : ucParamSize;
	if (at != AT_PSET) {
		if (IsMultiByteScalar(GetDataType(a_ucParamId), ucCopyLen)) {
			/* Numeric scalar: wire byte order -> native byte order. */
			for (UINT8 i = 0; i < ucCopyLen; i++) {
				Data.ucBytes[i] = a_pSrc[ucCopyLen - 1u - i];
			}
		} else {
			for (UINT8 i = 0; i < ucCopyLen && i < (UINT8)sizeof(DATABYTES); i++) {
				Data.ucBytes[i] = a_pSrc[i];
			}
		}
	}

	/* ---- Pre-function validation ---- */
	PASTATUS PaStatus = PA_OK;
	if (at != AT_PSET) {
		if (ucCopyLen <= (UINT8)sizeof(DATABYTES)) {
			PaStatus = ExecutePreFunction(a_ucParamId, Data.ucBytes, ucCopyLen);
		} else {
			PaStatus = ExecutePreFunction(a_ucParamId, a_pSrc, ucCopyLen);
		}
		if (PaStatus != PA_OK) {
			return PaStatus;
		}
	}

	/* ---- Interrupt-guarded data copy ---- */
	UINT32 uiSavedMask = hal_interrupt_set_mask(LVLPRI_TICK);

	switch (at) {
	case AT_SBYTE:
		*pDestination = Data.ucBytes[0];
		break;

	case AT_MBYTE: {
		/* Set write-in-progress semaphore */
		WriteInProgress.pDatabase    = pDestination;
		WriteInProgress.pWriteBuffer = &Data.ucBytes[0];

		UINT8 *pCopySrc = (ucCopyLen <= (UINT8)sizeof(DATABYTES)) ? Data.ucBytes : a_pSrc;

		for (UINT8 i = 0; i < ucCopyLen; i++) {

			pDestination[i] = pCopySrc[i];
		}
		break;
	}

#if 0
	case AT_PSET: {
		/* Restore interrupt mask — each recursive sub-param write
             will set its own mask individually. */


		hal_interrupt_set_mask(uiSavedMask);

		UINT8 *pSubList = pDestination; /* null-terminated param ID list */
		UINT8 *pWrPtr   = a_pSrc;

		while (*pSubList != 0) {
			UINT8 ucSubSize = GetParamSize(*pSubList);

			/* Recursive sub-parameter write (no checksum per sub-param) */
			PaStatus = WriteParamData(pWrPtr, *pSubList, ucSubSize, FALSE);
			if (PaStatus > PA_OK) {
				ComputeCheckSum();
				return PaStatus;
			}

			pWrPtr += ucSubSize;
			pSubList++;
		}

		/* Checkpoint status override */
		if ((ChanNum == 0 && a_ucParamId == PARAMID_BOXCHKPNT) ||
				(ChanNum != 0 && a_ucParamId == PARAMID_SLTCHKPNT)) {
			PaStatus = ucSaveChkpntPaStatus;
		}

#if !defined(UNIT_TEST_BUILD) && !defined(QEMU_BUILD)
		if (a_ucParamId == PARAMID_SLTCHKPNT && ChanNum == MAXSLOTS) {
			//TraceLog.AddToTrace(TRACEID_GENERIC, bcDbRestoreDone);
		}
#endif
		/* PSET already restored interrupts above — skip the restore below */
		if (a_bDoChkSm && GetIsDbChecksumed(a_ucParamId)) {
			ComputeCheckSum();
		}
		return (PaStatus == PA_OK) ? PA_OK : PaStatus;
	}

	case AT_BXPACK: {
		/* Box-packed bitmap: set/clear one bit for this channel */
		UINT8 ucBitIndex  = 0x80u >> ((ChanNum - 1) & 0x07);
		UINT8 ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
		if (Data.ucBytes[0] > 0) {
			pDestination[ucByteIndex] |= ucBitIndex;
		} else {
			pDestination[ucByteIndex] &= ~ucBitIndex;
		}
		break;
	}

	case AT_BXREC: {
		/* Box blind record: copy under highest interrupt guard */
		UINT32 uiHiMask = hal_interrupt_set_mask(LVLPRI_HIGHEST);
		for (UINT8 i = 0; i < ucCopyLen; i++) {
			pDestination[i] = Data.ucBytes[i];
		}
		hal_interrupt_set_mask(uiHiMask);
		break;
	}
#endif
	default:
		hal_interrupt_set_mask(uiSavedMask);
		return DO_DATA_TYPE_ERROR;
	}

	/* ---- Clear semaphore and post-function ---- */
	WriteInProgress.pDatabase    = NULL;
	WriteInProgress.pWriteBuffer = NULL;
	ExecutePostFunction(a_ucParamId, ucCopyLen);

	hal_interrupt_set_mask(uiSavedMask);

	/* ---- Recompute checksum if needed ---- */
	//if (a_bDoChkSm && GetIsDbChecksumed(a_ucParamId)) {
	//  ComputeCheckSum();
	// }

	return PA_OK;
}


/*******************************************************************************
*                   clsIomSlot::ComputeCheckSum                                *
*                   ===========================                                *
* PURPOSE:                                                                     *
*    Byte-sum checksum over all parameters in the checkpoint record.           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None (stores result via SetCheckSum).                                     *
* NOTES:                                                                       *
*    Walks the null-terminated sub-parameter ID list at the checkpoint ptr.    *
*******************************************************************************/
void clsIomSlot::ComputeCheckSum(void)
{
  UINT16 ulChecksum = 0;
  UINT8 *pChkPnt;

  if (ChanNum == 0) {
      pChkPnt = GetParamPtr(PARAMID_BOXCHKPNT);
  } else {
      pChkPnt = GetParamPtr(PARAMID_SLTCHKPNT);
  }

  if (pChkPnt == NULL) {
      ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, 0);
      return;
  }

  /* Iterate the null-terminated sub-parameter ID list */
  while (*pChkPnt != 0) {
      UINT8 ucSubParam = *pChkPnt;
      UINT8 *pParam    = GetParamPtr(ucSubParam);
      UINT8  ucParamSz = GetParamSize(ucSubParam);

      if (pParam != NULL) {
          for (UINT8 j = 0; j < ucParamSz; j++) {
              ulChecksum += pParam[j];
          }
      }

      pChkPnt++;
  }

  ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, ulChecksum);
}



