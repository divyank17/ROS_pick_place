////////////////////////////////////////////////////////////////////////////////
//                         CSysE, Fort Washington, PA.                        //
//                                                                            //
//                             COPYRIGHT (C) 2004                             //
//                HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                //
//                             ALL RIGHTS RESERVED                            //
//                                                                            //
// This software is a copyrighted work and / or information protected as a    //
// trade secret.  Legal rights of Honeywell Inc. in this software is distinct //
// from ownership of any medium in which the software is embodied. Copyright  //
// or trade secret notices included must be reproduced in any copies that are //
// authorized by Honeywell Inc.                                               //
//                                                                            //
// The information in this software is subject to change without notice and   //
// should not be considered as a commitment by Honeywell Inc.                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//   File Name   : adc.cpp                                                    //
//   Description : Analog to Digital Converter object source file             //
////////////////////////////////////////////////////////////////////////////////
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
#include "hal_fpga.h"
#include "fsl_lpspi.h"
#include "adc.hpp"

ClsAdc Adc;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const uint8_t ClsAdc::aInputSelect[] = {
    0x93,   // REF0
    0x81,   // CHAN01
    0x82,   // CHAN02
    0x83,   // CHAN03
    0x84,   // CHAN04
    0x86,   // CHAN05
    0x87,   // CHAN06
    0x88,   // CHAN07
    0x89,   // CHAN08
    0x8B,   // CHAN09
    0x8C,   // CHAN10
    0x8D,   // CHAN11
    0x8E,   // CHAN12
    0x91,   // CHAN13
    0x92,   // CHAN14
    0x94,   // CHAN15
    0x96,   // CHAN16
    0x80,   // CKVT1
    0x85,   // CKVT2
    0x8A,   // CKVT3
    0x8F,   // CKVT41
    0x90,   // CKVT52
    0x95,   // CKVT5
    0x97    // CALIB
};

/*******************************************************************************
*                                   Init                                      *
*                                   ====                                       *
* PURPOSE:  Initialise LPSPI4 as SPI master for ADC communication.            *
* ARGUMENTS: none                                                              *
* RETURN:   none                                                               *
* NOTES:    Must be called once before GetRawData().                           *
*******************************************************************************/
void ClsAdc::Init(void) {

	lpspi_master_config_t config;

	LPSPI_MasterGetDefaultConfig(&config);
	config.baudRate                      = ADC_SPI_BAUDRATE;
	config.cpol                          = kLPSPI_ClockPolarityActiveHigh;   /* CPOL=0 */
	config.cpha                          = kLPSPI_ClockPhaseFirstEdge;       /* CPHA=0 */
	config.direction                     = kLPSPI_MsbFirst;
	config.whichPcs                      = ADC_SPI_PCS;
	config.pcsActiveHighOrLow            = kLPSPI_PcsActiveLow;
	config.pcsToSckDelayInNanoSec        = 100u;
	config.lastSckToPcsDelayInNanoSec    = 100u;
	config.betweenTransferDelayInNanoSec = 200u;

	LPSPI_MasterInit(ADC_SPI_BASE, &config, ADC_SPI_CLOCK_FREQ);
}

VOID ClsAdc::Connect(UINT8 a_ucMuxSel) {

	UINT16 val;

	val = ((UINT16)aInputSelect[a_ucMuxSel]) << 8;

	hal_fpga_write(0x70 ,val);
}

/*******************************************************************************
*                                   GetRawData                                 *
*                                   ==========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 ClsAdc::GetRawData(UINT8 a_ucMuxSel, UINT16 a_uiWaitTime) {

    UINT32 ulData = 0;
	UINT16 val;

	val = ((UINT16)aInputSelect[a_ucMuxSel]) << 8;

	hal_fpga_write(0x70 ,val);

    if (a_uiWaitTime != 0u)
    {
        SDK_DelayAtLeastUs((uint32_t)a_uiWaitTime, CLOCK_GetFreq(kCLOCK_CpuClk));
    }

	// Flush FIFO, clear status, disable all the interrupts.
	LPSPI4->CR |= ((UINT32)true << LPSPI_CR_RTF_SHIFT) | ((UINT32)true << LPSPI_CR_RRF_SHIFT);
	LPSPI4->SR = kLPSPI_AllStatusFlag;

    //Assert slave select
	LPSPI4->TCR = (LPSPI_GetTcr(LPSPI4) & (~LPSPI_TCR_PCS_MASK)) | LPSPI_TCR_PCS((UINT8)kLPSPI_Pcs0);
	LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) | LPSPI_TCR_CONT_MASK;

	// TCR also shares the FIFO, so wait for TCR written.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    // Write three bytes to SPI transmit register to create 24 DCLOCKs to ADC for input conversion.
    LPSPI4->TDR = 0;
    LPSPI4->TDR = 0;
    LPSPI4->TDR = 0;

    // Set the PCS back to uncontinuous to finish the transfer if all tx data are pushed to FIFO.
    LPSPI4->TCR = LPSPI_GetTcr(LPSPI4) & ~LPSPI_TCR_CONT_MASK;

	// Wait until all transmit data is sent.
	while ((LPSPI4->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT != 0)
	{
    }

    while (((LPSPI4->FSR & LPSPI_FSR_RXCOUNT_MASK) >> LPSPI_FSR_RXCOUNT_SHIFT) != 0)
    {    // While receive FIFO is not empty
        ulData <<= 8;              // Shift MSB as LSB is received.
        ulData += (UINT8)LPSPI4->RDR;     // Get data from receive FIFO.
    }

    // ADC starts data transmission only at 6th clock cycle. So the received
    // data is left shifted by two bits in the uint32_t variable.  Right shift
    // by two bits to align the converted value.Mask out upper 16 bits.
    ulData >>= 2;
    ulData &= 0x0000FFFF;

    return (UINT16)ulData;
}
