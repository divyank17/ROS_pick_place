/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihversion.h                                         *
*    Description : RT1024 / QEMU hardware abstraction.                         *
*                  Replaces the H8S register definitions with HAL calls.       *
*                  This file is included by legacy code that expects it.       *
*******************************************************************************/

#ifndef __AIHVERSION_H__
#define __AIHVERSION_H__

const UINT8 VERSION_NUMBER  = 8; // starting ver with 1 is not working with c300, seems like there is a min ver required.
const UINT8 REVISION_NUMBER = 0;
const UINT8 BUILD_NUMBER    = 0;

#endif /* __AIHVERSION_H__ */
