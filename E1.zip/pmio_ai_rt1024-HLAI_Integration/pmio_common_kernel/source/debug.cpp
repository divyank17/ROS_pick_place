/*
 * debug.cpp
 *
 *  Created on: 03-Jun-2026
 *      Author: E829166
 */

#include "debug.hpp"

clsDebug Debug;

VOID clsDebug::Print(UINT32 ulValue) {

#if 0
	if (Iol.nCharProcd >= (Iol.xmit_buffer[IOLMSG_NUMBER] + 2))
	{

		PRINTF("RX: ");
		for (int i = 0; i < Iol.pRcvBuffer[IOLMSG_NUMBER]+2; i++)
		{
			// Print raw 16-bit value: bit8=9th-bit, bits15:11=error flags, bits7:0=data
			PRINTF("%02X  ", (unsigned)Iol.pRcvBuffer[i]);
		}

		PRINTF("\r\nTX: ");
		for (int i = 0; i < Iol.xmit_buffer[IOLMSG_NUMBER]+2; i++)
		{
			// Print raw 16-bit value: bit8=9th-bit, bits15:11=error flags, bits7:0=data
			PRINTF("%02X ", (unsigned)Iol.xmit_buffer[i]);
		}

		PRINTF("\r\n");

	    Iol.nCharProcd = 0;
	}
#endif

	if(ulValue == 0) {
		PRINTF("S");
	}
}

