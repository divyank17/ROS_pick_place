/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hardfail.h                                                  *
*    Description : Hard failure type enumeration for RT1024/QEMU.              *
*                  Aligned with Experion database pm_iomlhfst.enm.xml.         *
*******************************************************************************/
#ifndef HARDFAIL_H
#define HARDFAIL_H

typedef enum tagHardfailType {
    HF_UNKNOWN              = 0,
    HF_POWERDOWN            = 1,
    HF_INVPROGRAMEXEC       = 2,
    HF_EPROMCHKERROR        = 3,
    HF_RAMCONTERROR         = 4,
    HF_RAMADDRERROR         = 5,
    HF_DPAERROR             = 6,
    HF_DSAERROR             = 7,
    HF_RCVBUFOVERFLOW       = 8,
    HF_IOLJABBERFIRED       = 9,
    HF_SRAMFAIL             = 10,
    HF_BADPROGRAMJUMP       = 11,
    HF_ADCINCOMPLETE        = 12,
    HF_ADOUTOVERFLOW        = 13,
    HF_ADOUTUNDERFLOW       = 14,
    HF_ADCCALIBERROR        = 15,
    HF_BADDCLTC             = 16,
    HF_DMCTIMEOUT           = 17,
    HF_MULTIPLEOUTPUT       = 18,
    HF_PIDATBUSDIAG         = 19,
    HF_BADDARANGE           = 20,
    HF_MASTERTIMEOUT        = 21,
    HF_UM51WATCHDOG         = 22,
    HF_COUNTERCIRCUIT       = 23,
    HF_SOECOUNTERFAIL       = 24,
    HF_OUTPUTCONTROL        = 25,
    HF_BD_OUTPUT_MUX        = 26,
    HF_APPCRCFAIL           = 27,
    HF_PSCODEMISMATCH       = 28,
    HF_PARITYHWFAIL         = 29,
    HF_TASKSTACKSTART       = 30,
    HF_STACKOVERRURN        = 31,
    HF_WDTTIMEOUT           = 32,
    HF_ILLEGALWRITE         = 33,
    HF_PARITYERROR          = 34,
    HF_IOMUSERRESET         = 35,
    HF_ZEROREFFAIL          = 36,
    HF_REFINPFAIL           = 37,
    HF_FPGARDBKFAIL         = 38,
    HF_PSISOPUFAIL          = 39,
    HF_TCRAMDIAGFAIL        = 40,
    HF_TCCAPSEMPHOREFAIL    = 41,
    HF_TCCPUDIAGFAIL        = 42,
    HF_TCILLEGALISR         = 43,
    HF_TCDATABUSERROR       = 44,
    HF_TCAPPIOTAERROR       = 45,
    HF_TCAPPBOARDPOWERR     = 46,
    HF_TCEXTRAMCONTERROR    = 47,
    HF_TCKERNALPOWERFAIL    = 48,
    HF_TCCPLD_VER_FAIL      = 49,
    HF_TCPARITYFAIL         = 50,
    HF_TCXREADYFAIL         = 51,
    HF_TCLVDTADCFAIL        = 52,
    HF_TCDACRBFAIL          = 53,
    HF_TCAPPWDTTIMEOUT      = 54,
    HF_AODACFAIL            = 55,
    HF_FPGAIRQFAIL          = 56,
    HF_OSCFAIL              = 57,
    HF_COUNTERFAIL          = 58,
    HF_FIRSTUNUSEDENUM      = 59
} HARDFAILTYPE;

/* File name indices for HardFail() caller identification */
typedef enum tagFileName {
	UNKNOWN_FILE = 0,       // 0
    ADC_CPP,                // 1
    ADC_HPP,                // 2
    AIHBOXSLOT_CPP,         // 3
    AIHBOXSLOT_HPP,         // 4
    AIHMAIN_CPP,            // 5
    AIHMAIN_H,              // 6
    AIHSLOT_CPP,            // 7
    AIHSLOT_HPP,            // 8
    AIHVERSION_H,           // 9
    AIXSLOT_CPP,            // 10
    AIXSLOT_HPP,            // 11
    AOHARDWARE_CPP,         // 12
    AOHARDWARE_HPP,         // 13
    AOHBOXSLOT_CPP,         // 14
    AOHBOXSLOT_HPP,         // 15
    AOHMAIN_CPP,            // 16
    AOHMAIN_H,              // 17
    AOHSLOT_CPP,            // 18
    AOHSLOT_HPP,            // 19
    AOHVERSION_H,           // 20
    ASMUTILS_ASM,           // 21
    BOXSLOT_CPP,            // 22
    BOXSLOT_HPP,            // 23
    COMMONELECTRONICS_H,    // 24
    DATATYPE_H,             // 25
    DEBUG_CPP,              // 26
    DEBUG_HPP,              // 27
    DIAG_CPP,               // 28
    DIAG_H,                 // 29
    DIBOXSLOT_CPP,          // 30
    DIBOXSLOT_HPP,          // 31
    DIMAIN_CPP,             // 32
    DIMAIN_H,               // 33
    DISOEVERSION_H,         // 34
    DISLOT_CPP,             // 35
    DISLOT_HPP,             // 36
    DIVERSION_H,            // 37
    DOBOXSLOT_CPP,          // 38
    DOBOXSLOT_HPP,          // 39
    DOMAIN_CPP,             // 40
    DOMAIN_H,               // 41
    DOSLOT_CPP,             // 42
    DOSLOT_HPP,             // 43
    DOVERSION_H,            // 44
    ECL_CPP,                // 45
    ECL_HPP,                // 46
    EVRCTASK_CPP,           // 47
    GLOBAL_H,               // 48
    HART_CPP,               // 49
    HART_H,                 // 50
    HARTDB_CPP,             // 51
    HARTDB_HPP,             // 52
    HARTSTACK_CPP,          // 53
    HARTSTACK_HPP,          // 54
    INSLOT_HPP,             // 55
    IOL_CPP,                // 56
    IOL_HPP,                // 57
    IOMSLOT_CPP,            // 58
    IOMSLOT_HPP,            // 59
    IOSLOT_HPP,             // 60
    LLHARDWARE_CPP,         // 61
    LLHARDWARE_HPP,         // 62
    LLMUXBOXSLOT_CPP,       // 63
    LLMUXBOXSLOT_HPP,       // 64
    LLMUXMAIN_CPP,          // 65
    LLMUXMAIN_H,            // 66
    LLMUXSLOT_CPP,          // 67
    LLMUXSLOT_HPP,          // 68
    LLMUXVERSION_H,         // 69
    OUTSLOT_HPP,            // 70
    ROOT_CPP,               // 71
    SCHEDULER_CPP,          // 72
    SCHEDULER_HPP,          // 73
    TRACELOG_CPP,           // 74
    TRACELOG_HPP,           // 75
    UTILS_CPP,              // 76
    UTILS_H,                // 77
    WRDBTASK_CPP,           // 78
    WRMSGQUE_HPP,           // 79
    FPGA_HPP,               // 80
    FPGA_CPP,               // 81
//Turbine control SVP Files
    TCCOMMONSLOT_CPP,          // 82
    TCCOMMONSLOT_HPP,          // 83
    SVPBOXSLOT_CPP,         // 84
    SVPBOXSLOT_HPP,         // 85
    SVPMAIN_CPP,            // 86
    SVPMAIN_H,              // 87
    SVPSLOT_CPP,            // 88
    SVPSLOT_HPP,            // 89
    SVPVERSION_H,            // 90
    //Turbine control SP Files
    SPBOXSLOT_CPP,         // 91
    SPBOXSLOT_HPP,         // 92
    SPMAIN_CPP,            // 93
    SPMAIN_H,              // 94
    SPSLOT_CPP,            // 95
    SPSLOT_HPP,            // 96
    SPVERSION_H,            // 97
    TCAILVDTSLOT_CPP,       // 98
    TCAILVDTSLOT_HPP,       // 99
    TCAOSERVOSLOT_CPP,       // 100
    TCAOSERVOSLOT_HPP,       // 101
    TCDISLOT_CPP,       // 102
    TCDISLOT_HPP,       // 103
    TCDOSLOT_CPP,       // 104
    TCDOSLOT_HPP,       // 105
    TCSPVOTBLOCK_HPP,   // 106
    //Pulse input module files
    PIMAIN_CPP,         // 107
    PIMAIN_H,           // 108
    PIBOXSLOT_CPP,      // 109
    PIBOXSLOT_HPP,        // 110
    PISLOT_CPP,         // 111
    PISLOT_HPP,         // 112
    PIVERSION_H,        // 113
    UIOMAIN_CPP,        // 114
    UIOMAIN_H,          // 115
    UIOBOXSLOT_CPP,     // 116
    UIOBOXSLOT_HPP,     // 117
    UIOSLOT_CPP,        // 118
    UIOSLOT_HPP,        // 119
    UIOFPGA_CPP,        // 120
    UIOFPGA_HPP,        // 121
    UIOVERSION_H        // 122
} FILE_NAME;

#endif /* HARDFAIL_H */
