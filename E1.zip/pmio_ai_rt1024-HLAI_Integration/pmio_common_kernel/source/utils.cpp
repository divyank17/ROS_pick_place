/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : utils.cpp                                                   *
*    Description : Common utility functions.                                   *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
//YaGa#include <machine.h>
#include "utils.h"
#include "scheduler.hpp"
//YaGa#include "tracelog.hpp"
#include "debug.hpp"
#include "boxslot.hpp"
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
#ifdef DEBUG
extern CHAR g_strDebugPrompt[];
#endif
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
extern "C" BOOL _EraseFlashBlock(UINT8);
extern "C" BOOL _ProgramFlash(UINT8*, UINT8*);
extern clsWriteMsgQueue WriteMsgQueue;
#if(!HEK) || (defined(IOMTYPE_PI))
UINT8 *Flash_Util_Relocation_Address_Ptr = (WriteMsgQueue.GetMsgBufferPtr() + FLASH_UTIL_RELOC_WRTMSGQUE_OFFSET);
#if H8S_2319C
UINT8 *DummyFunc_address = (WriteMsgQueue.GetMsgBufferPtr() + FLASH_UTIL_RELOC_WRTMSGQUE_OFFSET + FLASH_UTIL_SIZE);
#endif // ifdef H8S_2319C
#endif
/*******************************************************************************
*                                     abort                                    *
*                                     =====                                    *
* PURPOSE:                                                                     *
*    This function is required for the time being by the tool set.             *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function may be removed or renamed in future.                        *
*******************************************************************************/
extern "C" VOID abort(VOID) {
    while (true);
}

/*******************************************************************************
*                               RealCompare                                    *
*                               ===========                                    *
* PURPOSE:   This function compares two REAL values. Returns TRUE if both are  *
*            equal or the same NaN type. Otherwise returns FALSE.              *
*                                                                              *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL RealCompare(FLOAT32 a_flVal, FLOAT32 a_frVal) {
    DATABYTES lVal,rVal;

    lVal.f32Val = a_flVal;
    rVal.f32Val = a_frVal;

#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG) && (0)
    if (ucDbgPnt < 5)
    {
        for (UINT8 ucCount = 0; ucCount < sizeof(FLOAT32); ucCount++)
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n%02x - %02x", lVal.ucBytes[ucCount], rVal.ucBytes[ucCount]));
        ucDbgPnt++;
    }
#endif

    for (UINT8 ucCount = 0; ucCount < sizeof(FLOAT32); ucCount++) {
        if (lVal.ucBytes[ucCount] != rVal.ucBytes[ucCount]) {
#if !defined(IOPTYPE_SCIOM)
            if ((ucCount!=0) || (lVal.ucBytes[0] != 0xFF) || (rVal.ucBytes[0] != 0x7F))
#endif
            return FALSE;
        }
    }

    return TRUE;
}

/*******************************************************************************
*                                    isnan                                     *
*                                    =====                                     *
* PURPOSE   : Test for all types of NaNs.                                      *
* ARGUMENTS : FLOAT32 - variable to be tested.                                 *
* RETURN    : TRUE if the variable is NaN, else FALSE.                         *
*******************************************************************************
BOOL IomIsNan(FLOAT32 a_fVal) {
    NANINIT TestNaN;
    TestNaN.fVal = a_fVal;
    BOOL bIsNaN = FALSE;

    // if all exponent bits are set and the mantissa is non-zero
    if (TESTNAN_EXPONENT == (TestNaN.ulDword & TESTNAN_EXPONENT))  {
        if (TestNaN.ulDword & TESTNAN_MANTISSA) {
            bIsNaN = TRUE;
        }
    }

    return bIsNaN;
} */

/*******************************************************************************
*                                     fabs                                     *
*                                     =====                                    *
* PURPOSE: Returns the absolute value of FLOAT32                               *
* ARGUMENTS: Value for which absolute value is required                        *
* RETURN: Absolute value                                                       *
* NOTES:                                                                       *
*******************************************************************************/
FLOAT32 fabs (FLOAT32 a_fVal) {
  return !isnan(a_fVal) ? ((a_fVal < (FLOAT32)0.0) ? -a_fVal : a_fVal) : NaN;
}

/*******************************************************************************
*                                    isnan                                     *
*                                    =====                                     *
* PURPOSE   : Test for all types of NaNs.                                      *
* ARGUMENTS : FLOAT64 - variable to be tested.                                 *
* RETURN    : TRUE if the variable is NaN, else FALSE.                         *
*******************************************************************************
BOOL IomIsNan(FLOAT64 a_dVal) {
    DNANINIT TestDNaN;
    TestDNaN.dVal = a_dVal;
    BOOL bIsDNaN = FALSE;

    // if all exponent bits are set and the mantissa is non-zero
    if ((TESTDNAN_EXPONENT_HI == (TestDNaN.uqWord.ulDwordHi & TESTDNAN_EXPONENT_HI)) &&
        (TESTDNAN_EXPONENT_LO == TestDNaN.uqWord.ulDwordLo)) {
        if ((TestDNaN.uqWord.ulDwordHi & TESTDNAN_MANTISSA_HI) ||
            TestDNaN.uqWord.ulDwordLo) {
            bIsDNaN = TRUE;
        }
    }

    return bIsDNaN;
}
*/
