/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : diag.h                                                      *
*    Description : Implements common diagnostics                               *
*******************************************************************************/
#ifndef __DIAG_H__
#define __DIAG_H__

#define FTA_MISSING         0x00
#define FTA_RETURN_BUT_TOUT 0x01
#define FTA_RETURN_AND_TOUT 0x03


VOID CheckFtaPresence(VOID);

#endif /* __DIAG_H__ */
