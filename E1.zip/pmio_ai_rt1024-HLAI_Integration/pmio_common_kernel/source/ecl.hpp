/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : ecl.hpp                                                     *
*    Description : Class clsEcl declaration.                                   *
*******************************************************************************/
#ifndef __ECL_HPP__
#define __ECL_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern UINT16 NrmEclMemory[];
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT16 ECL_SIZE       = 256; // ECL size .

#define ECLOBJECT_SIZE ((sizeof(clsEcl) + (sizeof(clsEcl) % 2)) / 2)
#if defined(IOMTYPE_DISOE) || defined(IOPTYPE_DI)
#define     PVCHGCL_SIZE                 1024   // DISOE PVCL size.
#endif

const UINT8 EVENTPACKETSIZE_SYSTEM   = 3; // system event size
const UINT8 EVENTPACKETSIZE_OVERFLOW = 1; // overflow event size
const UINT8 EVENTPACKETSIZE_SOEPVC   = 2; // SOE PV change with no timestamp
const UINT8 EVENTPACKETSIZE_SOEPVCTS = 7; // SOE PV change with timestamp
const UINT8 EVENTPACKETSIZE_IOLTSB   = 6; // IOL timesync boundary event size
const UINT8 EVENTPACKETSIZE_SOELOST  = 6; // SOE lost event size

const UINT8 EVENTSTATE_RETURN    = 0; // return from alarm state (normal events)
const UINT8 EVENTSTATE_ALARM     = 1; // going to alarm state (normal events)
const UINT8 EVENTSTATE_TIMESTAMP = 1; // time stamp follows (DISOE PV change)

const UINT8 ECLMODSTAT_SHIFT = 2; // ModStat bit position shift in CircListSt
const UINT8 EVERC_SUSPENDTIME = 50; // 500 milliseconds
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagEclType {
    ECLTYPE_NORMAL   = 0,
    ECLTYPE_PVCHANGE = 1
} ECLTYPE;

typedef enum tagEventType {
    EVENTTYPE_NORMAL   = 0, // normal event
    EVENTTYPE_RECOVERY = 1  // recovered event
} EVENTTYPE;

// Unused packet types like AI, AI with limits, DI, FBUS event are not defined.
typedef enum tagEventPacket {
	EVENTPACKET_DI          = 1,  // Digital Input Event
	EEENTPACKET_EIP         = 2,
	EVENTPACKET_ALARM       = 3,  // AI Alarm Event Packet
	EVENTPACKET_SOEPVC      = 4,  // SOE PV change - used in DISOE only
	EVENTPACKET_IOLTSB      = 5,  // IOL timesync boundary - DISOE only
	EVENTPACKET_SOELOST     = 6,  // SOE events lost - in DISOE only
	EVENTPACKET_SYSTEM      = 7,  // system event
	EVENTPACKET_HART        = 8,  // HART event
	EVENTPACKET_32CHAN_HART = 12, // HART event for more than 16 channels
	EVENTPACKET_OVERFLOW    = 15  // ECL overflow event
} EVENTPACKET;

typedef enum tagEventSubType {
    EVENTSUBTYPE_FAILOVER      = 125, // IOM failover
    EVENTSUBTYPE_RUN           = 126, // ModStat run event
    EVENTSUBTYPE_IDLE          = 127, // ModStat idle event
#ifdef IOMTYPE_DISOE
    EVENTSUBTYPE_RECOVERYSTART = 130, // recovery start bracket (ECL AND PVCL)
#else
    EVENTSUBTYPE_RECOVERYSTART = 128, // event recovery start bracket
#endif
    EVENTSUBTYPE_RECOVERYEND   = 129, // event recovery end bracket
    EVENTSUBTYPE_DISABLEALARM  = 131, // disable alarms
    EVENTSUBTYPE_INACTIVE      = 132, // PtExecSt inactive event
    EVENTSUBTYPE_ACTIVE        = 133, // PtExecSt active event
    EVENTSUBTYPE_ENABLEALARM   = 134, // enable alarms
    EVENTSUBTYPE_SUPPRESSALARM = 135, // suppress alarms to journal-only
    EVENTSUBTYPE_UNSUPPRESSALARM = 136// unsuppress supprssed alarms
} EVENTSUBTYPE;

typedef enum tagEclStatus {
    ECLSTATUS_LARGE    = 0x20, // set for DISOE circular list status only
    ECLSTATUS_SOFTFAIL = 0x10, // set when softfail exists
    ECLSTATUS_MODSTAT  = 0x0C, // set according to the module state
    ECLSTATUS_NORMAL   = 0x02, // set for normal ECL
    ECLSTATUS_PVCHANGE = 0x01  // set for PVCHANGE ECL (only in DISOE)
} ECLSTATUS;

typedef enum tagEclModStat {
    ECLMODSTAT_ALIVE   = 0x00, // IOM is alive
    ECLMODSTAT_IDLE    = 0x04, // IOM is idle
    ECLMODSTAT_RUN     = 0x08, // IOM is running
    ECLMODSTAT_FAIL    = 0x0C  // IOM is failed
} ECLMODSTAT;

#ifdef BIG_ENDIAN
typedef struct tagEventRecord {
    // First byte of event packet
    UINT8 Overflow      : 1; // indicates ECL in overflow
    UINT8 ContactCutout : 1; // contact cutout status
    UINT8 Qualifier     : 1; // normal or recovered
    UINT8 CurrentState  : 1; // alarm, return or timestamp follows
    UINT8 EventPacket   : 4; // packet type which defines the variant part
    union { // Event type
        struct { // system event (softfails, ModStat, PtExecSt etc.)
            UINT8 SoftfailStatus : 1; // 1 if any soft fail present
            UINT8 ChannelNumber  : 7; // IOM channel number
            UINT8 EventSubType   : 8; // Event subtype code
        } SystemEvent;
        struct { // HART event/alarm
            UINT8                : 1;
            UINT8 AlarmOn        : 1; // Set if HART alarm type
            UINT8 C48Event       : 1; // Set for C48 event type
            UINT8 ChannelNumber  : 5;
            UINT8 HEventCode     : 8;
        } HartEvent;
        // Add PV change and DI alarm event variants when DISOE is developed.
    };
} EVENTRECORD;
#else
typedef struct tagEventRecord {
    // First byte of event packet
	UINT8 EventPacket   : 4; // packet type which defines the variant part (LSB)
	UINT8 CurrentState  : 1; // alarm, return or timestamp follows
	UINT8 Qualifier     : 1; // normal or recovered
	UINT8 ContactCutout : 1; // contact cutout status
	UINT8 Overflow      : 1; // indicates ECL in overflow (MSB)
    union { // Event type
        struct { // system event (softfails, ModStat, PtExecSt etc.)
            UINT8 ChannelNumber  : 7; // IOM channel number (LSB)
            UINT8 SoftfailStatus : 1; // 1 if any soft fail present (MSB)
            UINT8 EventSubType   : 8; // Event subtype code
        } SystemEvent;
        struct { // HART event/alarm
        	UINT8 ChannelNumber  : 5; //(LSB)
        	UINT8 C48Event       : 1; // Set for C48 event type
            UINT8 AlarmOn        : 1; // Set if HART alarm type
            UINT8                : 1; //(MSB)
            UINT8 HEventCode     : 8;
        } HartEvent;
        // Add PV change and DI alarm event variants when DISOE is developed.
    };
} EVENTRECORD;
#endif

// AI Alarm Event Record
typedef struct tagAlarmEventRecord {
    // First byte of event packet
    UINT8 Overflow      : 1; // indicates ECL in overflow
    UINT8 ContactCutout : 1; // contact cutout status
    UINT8 Qualifier     : 1; // normal or recovered
    UINT8 Direction     : 1; // alarm, return or timestamp follows
    UINT8 EventPacket   : 4; // packet type which defines the variant part
    UINT8 ChannelNumber : 8; // Channel / Slot Number
    FLOAT32 Pv;              // Current Pv Value
    FLOAT32 PvTp;            // violated trip point value
    UINT8 SysOrBrkt     : 1; // System or Bracket Event (0 = alarm packet; 1 = ptexectst, contcut change event)
    UINT8 AlarmCode     : 7; // Alarm code
} ALARMEVENTRECORD;

const UINT8 EVENTPACKETSIZE_ALARM = 11; // AI Alarm Event Packet Size (>=R300 release)

#if defined(IOPTYPE_DI)
typedef struct tagAlarmEventRecord {
    // First byte of event packet
    UINT8 NotUsed       : 1; // indicates ECL in overflow
    UINT8 ContactCutout : 1; // contact cutout status
    UINT8 Qualifier     : 1; // Event Qualifier (0=Normal, 1=Recovery)
    UINT8 Direction     : 1; // Direction (0=OFF or Clear, 1=ON)
    UINT8 EventPacket   : 4; // Event Types Supported(1. Digital Input Event)
    UINT8 Pv            : 1; // Current Pv Value
    UINT8 ChannelNumber : 7; // Channel / Slot Number
    UINT8 SysOrBracket  : 1; // System or Bracket Event
    UINT8 AlarmCode     : 7; // Alarm code
} ALARMEVENTRECORD;
const UINT8 EVENTPACKETSIZE_ALARM = 3; // DI Alarm Event Packet Size (>=R300 release)

#endif

// DISOE related structres
#if defined(IOMTYPE_DISOE) || defined(IOPTYPE_DI)
typedef enum tagPVCLEventType {
    EVENTTYPE_PVCLNORMAL   = 0, // normal event
    EVENTTYPE_PVCLRECOVERY = 1  // recovered event
} PVCLEVENTTYPE;
typedef struct tagPVCLEvtRecord {
    UINT8 Spare                 :2;
#if defined(IOPTYPE_DI)
    UINT8 Notused1              :1;
#else
    UINT8 Qualifier             :1; // normal or recovered
#endif
    UINT8 TimeStampFlag         :1; // indicates TimeStamp Flag.
    UINT8 EventPktType          :4; // packet type which defines the variant part
    union { // event type
        struct { // PV change event
            UINT8 PVCHG_PV          :1;
            UINT8 PVCHGSOEslot      :7;
#if !defined(IOPTYPE_DI)
            UINT8 SyncIDHigh          ;
            UINT8 SyncIDLow           ;
#endif
            UINT8 TimeStampHigh       ;
            UINT8 TimeStampMid        ;
            UINT8 TimeStampLow        ;
        } PVCL_PVCHANGEPKT;
#if !defined(IOPTYPE_DI)
        struct { // Pv change lost event
            UINT8 SOE_SyncIDHigh      ;
            UINT8 SOE_SyncIDLow       ;
            UINT8 SynchTimeHigh       ;
            UINT8 SynchTimeMid        ;
            UINT8 SynchTimeLow        ;
            UINT8 Spare1              ;
        } PVCL_EVTLOSTPKT;
        struct { // Boundary packet
            UINT8 SOE_SyncIDHigh      ;
            UINT8 SOE_SyncIDLow       ;
            UINT8 SynchTimeHigh       ;
            UINT8 SynchTimeMid        ;
            UINT8 SynchTimeLow        ;
            UINT8 Spare1              ;
        }PVCL_BOUNDRYPKT;
#endif
    };
}PVCLEVTRECORD;
#endif
/*******************************************************************************
*                                     clsEcl                                   *
*                                     ======                                   *
*******************************************************************************/
class clsEcl {
private:
    const ECLTYPE EclType;
    UINT8   CircListSt;
    UINT16  EvntAppPtr;
    UINT16  EvntRemPtr;
    BOOL    EclInOverflow;
    UINT8   CircularList[ECL_SIZE];

     //PVCL circular buffer related.
#if defined(IOMTYPE_DISOE) || defined(IOPTYPE_DI)
    UINT8   PVCHGCircularList[PVCHGCL_SIZE];
    BOOL    PVCHGCLInOverflow;
    UINT16  PVCLAppPtr;
    UINT16  PVCLRemPtr;
#endif

    clsEcl(const clsEcl&); // Safeguard against default copy constructor.
    clsEcl& operator=(const clsEcl&); // Sefeguard against default assignment.

    UINT16 GetEclSize(VOID);

public:
    clsEcl(const ECLTYPE);
    ~clsEcl(VOID) { HardFail(HF_INVPROGRAMEXEC,ECL_HPP,__LINE__); }

    //VOID *operator new(UINT32) { return NrmEclMemory; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,ECL_HPP,__LINE__); }

    inline UINT8 GetStatus(VOID) {
        return CircListSt;
    }
    inline VOID SetStatus(ECLSTATUS a_ucEclStatus) {
        CircListSt |= a_ucEclStatus;
    }
    inline VOID ResetStatus(ECLSTATUS a_ucEclStatus) {
        CircListSt &= ~a_ucEclStatus;
    }
    inline VOID SetEclModStat(UINT8 a_ucModStat) {
        a_ucModStat <<= ECLMODSTAT_SHIFT;
        CircListSt &= ~ECLSTATUS_MODSTAT; // clear current EclModStat
        CircListSt |= a_ucModStat; // Set new EclModStat
    }

    BOOL   AddEvent(const EVENTRECORD *);
    UINT16 CollectEclInfo(UINT8 *, UINT16);
    VOID   CollectEclData(UINT8 *, UINT16);
    VOID   UpdateRemPtr(UINT16);
    BOOL   IsRoomForRegen(VOID);

    BOOL AddAlarmEvent(ALARMEVENTRECORD *);

#if defined (IOMTYPE_DISOE) || defined(IOPTYPE_DI)
    // Declarations for PVCL Buffer handling.
    UINT16 CollectPVCLInfo(UINT8 *, UINT16);
    VOID   CollectPVCLData(UINT8 *, UINT16);
    VOID   UpdatePVCLRemPtr(UINT16);
    BOOL   AddPVCLEvent(PVCLEVTRECORD *);
    UINT16 GetPVCHGCLSize(VOID);
    BOOL   IsRoomForPVCLRegen(VOID);
    inline VOID ResetPVCLAppPtr(VOID){ PVCLAppPtr = 0;}
    inline VOID ResetPVCLRemPtr(VOID){ PVCLRemPtr = 0;}
#endif
    friend class clsBoxSlot;
#ifdef IOMTYPE_DISOE
    friend class clsDiBoxSlot;
#endif
};

#endif //__ECL_HPP__
