/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihboxslot.hpp                                              *
*    Description : AIH (Analog Input HART) box slot class for RT1024/QEMU.     *
*                  Derived from clsBoxSlot — manages PV scanning, calibration, *
*                  HART ADC enable, and AIH-specific parameter table.          *
*******************************************************************************/
#ifndef __AIHBOXSLOT_HPP__
#define __AIHBOXSLOT_HPP__

#include "boxslot.hpp"


/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT16 FIVE_VOLT_TOLERENCE_COUNT = 425;
const UINT8 AIHPPX_PERIOD = 50; // In units of msec.
// PPX interrupt is configured for (50 / 16) = 3.125 msec for AI-HART
// so that all channels completes processsing in 50 msec.
const UINT32 PPX_TIMER_COUNT = 3125; // interrupt every (50/16) = 3.125 msec.

/*******************************************************************************
*                             TYPES                                            *
*******************************************************************************/

class clsAihBoxSlot; // forward declaration
class clsAixSlot;    // forward declaration
typedef struct tagBoxParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    PASTATUS (clsAihBoxSlot::* PrePtr)(UINT8 *, UINT8);
    void     (clsAihBoxSlot::* PostPtr)(UINT8);
    void *   (clsAihBoxSlot::* ParamPtr)(void);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

typedef struct tagPvScanRec {
    FLOAT32 Pv;
    PVVALST PvSts;
    UINT8   Sequence;
} PVSCANREC;

typedef struct tagAiCalibData {
    FLOAT32 f5VRefHiLimit;
    FLOAT32 f5VRefLoLimit;
#if !LOWCOST
    FLOAT32 fCalibrationSlope;
    FLOAT32 fCalibrationOffset;
    FLOAT32 fChannelZeroDrift[MAXSLOTS];
#else   // LOWCOST, Slope for each channel
    FLOAT32 spare1;
    FLOAT32 spare2;
    FLOAT32 fCalibrationSlope[MAXSLOTS];
    FLOAT32 fCalibrationOffset[MAXSLOTS];
#endif
} AICALIBDATA;

typedef enum tagBoardType {
    BOARDTYPE_UNKNOWN,
    BOARDTYPE_PASSONE,
    BOARDTYPE_PASSTWO,
    BOARDTYPE_LOWCOST
} BOARDTYPE;

/*******************************************************************************
*                                 clsAihBoxSlot                                *
*                                 =============                                *
*******************************************************************************/
class clsAihBoxSlot : public clsBoxSlot {

private:
    friend class clsAixSlot;

	UINT8       PpxChannel;
    PVSCANREC   PvScanRec[MAXSLOTS];
    // Slot checkpoint is used to determine the partners HART7 compatibility.
    // Primary IOM will set this variable to Latest slot checkpoint version before
    // dump and reset to zero after sync.
    // Secondary IOM will initialise its HART7 variables based on the slot checkpoint version
    // set by the primary.
    UINT8       PartnersChkPntVer;
    // !!!*** AIH_BOXSLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the AIH box slot's redundant synch data area
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedBoxSize() must be updated to
    // reference the new end member. This dump record begins in clsBoxSlot.

    BOOL        CalibAll;
    BOOL 		CalibrationGood;
    AICALIBDATA CalibData;
    BOARDTYPE   BoardType;
    BOOL        OwdCktGood;

#if 1 //defined(IOPTYPE_HLAI)
    FLOAT32 BxLimit1;
    FLOAT32 BxLimit2;
    BOOL    PvsGood;
    FLOAT32 SlwSrcBuff[MAXSLOTS];
    BOOL    bSlwFirstPass;
#endif

    FLOAT32 HCuAvail;
    BLIND   HGChngFl[MAXSLOTS];
    UINT16  HGCfgChgCnt[MAXSLOTS]; //Config Change counter of all the channels.
    UINT8   HGDevSt[MAXSLOTS];     //Device status of all the channels.
    BOOL    HADCEnable[MAXSLOTS];
    UINT8   HADCStatus[MAXSLOTS];
    UINT8   AdcCycleCount[MAXSLOTS];
    BOOL    HEnableSaved[MAXSLOTS];

    static const UINT8 CheckPointVer1[];
    static const UINT8 CheckPointVer2[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[];
    static UINT8 BoxChkpntVersion;

	static const BOXPARAMINFO s_tblParamInfo[256];
#if 1 //defined(IOPTYPE_HLAI)
    static const UINT8 PmioDumpParamTbl[];
#endif

    PASTATUS PreCalibAll(UINT8 *,UINT8);
    VOID     PostCalibAll(UINT8);
    PASTATUS PreHADCEnable(UINT8 *,UINT8);
    VOID     PostHADCEnable(UINT8);
    PASTATUS PreCheckPoint(UINT8 *,UINT8);

    inline VOID *GetCalibAllPtr(VOID)   { return &CalibAll; }
    inline VOID *GetPvScanRecPtr(VOID)  { return PvScanRec; }
    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[BoxChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetRedParamsPtr(VOID)  { return (VOID *)RedParams; }
    inline VOID *GetHADCEnablePtr(VOID) { return (VOID *)HADCEnable; }
    inline VOID *GetHADCStatusPtr(VOID) { return (VOID *)HADCStatus; }
    inline VOID *GetHGCfgChgCntPtr(VOID){ return (VOID *)HGCfgChgCnt;}
    inline VOID *GetHGChngFlPtr(VOID)   { return (VOID *)HGChngFl; }
    inline VOID *GetHCuAvailPtr(VOID)   { return (VOID *)&HCuAvail; }
    inline VOID *GetHGDevStPtr(VOID)    { return (VOID *)HGDevSt;}

#if 1 //defined(IOPTYPE_HLAI)
    inline VOID *GetBxLimit1Ptr(VOID)   { return &BxLimit1; }
    inline VOID *GetBxLimit2Ptr(VOID)   { return &BxLimit2; }
    inline VOID *GetPvsGoodPtr(VOID)    { return &PvsGood;  }
#endif

    inline VOID *GetCheckPointPtr(UINT8 a_ucVer)  { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

#if 0 //!defined(IOPTYPE_HLAI)
    UINT8   *GetParamPtr(UINT8 a_ucParamId) override;
#endif

    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    VOID     TransformBlindRecord(UINT8 a_ucParamId, UINT8 *a_pData, UINT8 a_ucSize, BOOL a_bToWire) override;
	
    VOID LoadCalibrationData(VOID);
    BOOL FlashCalibrationData(VOID);
    BOOL ValidateCheckVoltage(UINT8,UINT16);
	VOID DoIdleDiagnostics(VOID);

	BOOL FACTCAL(VOID);
	BOOL CALIBRATE(VOID);
	BOOL OVERVT_n(VOID);


    //inline BOOL FACTCAL(VOID)  { return (hal_fpga_get_misc_status() | FPGA_MISC_FACTCAL);   }
    //inline BOOL CALIBRATE(VOID){ return (hal_fpga_get_misc_status() | FPGA_MISC_CALIBRATE); }
    //inline BOOL OVERVT_n(VOID) { return (hal_fpga_get_misc_status() | FPGA_MISC_OVERVT_n);  }

    clsAihBoxSlot(const clsAihBoxSlot&); // Safeguard against def copy constr.
    clsAihBoxSlot& operator=(const clsAihBoxSlot&); // and default assignment.

public:
    clsAihBoxSlot(MODLTYPE a_ModlType);
    ~clsAihBoxSlot(void) {}

    //VOID *operator new(UINT32) { return ucIomDbMemory; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AIHBOXSLOT_HPP,__LINE__); }

    /* Application hooks */
    void AppInitialization(void) override;
    void AppStcProcessing(void) override;
    BOOL PerformModuleCalibration(VOID);

    // PPX ISR methods (called from extern "C" handlers)
	static VOID PpxInterruptHandler(VOID);

    /* Pure virtual overrides from clsIomSlot via clsBoxSlot */
    DATATYPE   GetDataType(UINT8 a_ucParamId) override;
    ACCESSTYPE GetAccessType(UINT8 a_ucParamId) override;
    UINT8      GetParamSize(UINT8 a_ucParamId) override;
    ACCESSLOCK GetAccessLock(UINT8 a_ucParamNumber) override;
    BOOL       GetIsDbChecksumed(UINT8 a_ucParamNumber) override;
    PASTATUS   VerifyControlState(UINT8) override;
    VOID       AppColdInit(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);

#if 1 //defined(IOPTYPE_HLAI)
    inline UINT32 GetRedBoxDelta(VOID)   { return 0; }
    inline UINT32 GetRedBoxSize(VOID)    { return PMIO_BOXDUMP_PARAMSIZE; }
    inline UINT8 *GetRedBoxPointer(VOID) { return (UINT8 *)PmioDumpParamTbl; }
#else
    inline UINT32 GetRedBoxDelta(VOID) {
        return (UINT32)(((UINT8*)&PartnersChkPntVer - (UINT8*)&PvScanRec[MAXSLOTS-1]) - (sizeof(PVSCANREC) - 1));
    }

    inline UINT32 GetRedBoxSize(VOID) {
        return ((UINT32)((UINT8 *)&PartnersChkPntVer - (UINT8 *)&ModStat1) + (sizeof(PartnersChkPntVer)));
    }

    inline UINT8 *GetRedBoxPointer(VOID) {
        return (UINT8 *)&ModStat1;
    }
#endif

    //inline BOOL GetHADCEnable(UINT8 a_ucSlot) { return HADCEnable[a_ucSlot - 1]; }

    inline BOOL GetCalibAllState(VOID) { return CalibAll; }

    inline FLOAT32 GetPv(UINT8 a_ucChanNum) {
        return PvScanRec[a_ucChanNum - 1].Pv;
    }

    inline PVVALST GetPvSts(UINT8 a_ucChanNum) {
        return PvScanRec[a_ucChanNum - 1].PvSts;
    }

    inline VOID SetPv(UINT8 a_ucChanNum, FLOAT32 a_fPv) {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        PvScanRec[a_ucChanNum - 1].Pv = a_fPv;
        set_imask_exr(uiMask);
    }

    inline VOID SetPvSts(UINT8 a_ucChanNum, PVVALST a_PvSts) {
        PvScanRec[a_ucChanNum - 1].PvSts = a_PvSts;
        SLOT(a_ucChanNum)->UpdateBadPvFl(PVVALST_BAD == a_PvSts);
    }

#if 1 //defined(IOPTYPE_HLAI)
    // for PMIO Redesign
    inline VOID SetPvAlmInfo(UINT8 a_ucChanNum, UINT8 ucAlmInfo){
        PvScanRec[a_ucChanNum - 1].Sequence = ucAlmInfo;
    }
#else
    inline VOID IncrementSequence(UINT8 a_ucChanNum) {
        PvScanRec[a_ucChanNum - 1].Sequence++;
    }
#endif
    inline UINT8 GetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        return (HGChngFl[a_ucSlot - 1] & a_ucBit);
    }

    inline VOID SetHGCfgChgCnt(UINT8 a_ucSlot,UINT16 a_ucCfgChgCnt) {
        HGCfgChgCnt[a_ucSlot - 1] = a_ucCfgChgCnt;
    }
    inline VOID SetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        HGChngFl[a_ucSlot - 1] |= a_ucBit;
    }

    inline VOID ResetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        HGChngFl[a_ucSlot - 1] &= ~a_ucBit;
    }

    inline VOID ToggleHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        HGChngFl[a_ucSlot - 1] ^= a_ucBit;
    }

    inline VOID InitHGCfgChgCnt(UINT8 a_ucSlot) {
        HGCfgChgCnt[a_ucSlot - 1] = 0;
    }

    inline VOID InitHGChngFl(UINT8 a_ucSlot) {
        HGChngFl[a_ucSlot - 1] = 0;
    }
    inline VOID SetHGDevSt(UINT8 a_ucSlot,UINT8 a_ucSts) {
        HGDevSt[a_ucSlot - 1] = a_ucSts;
    }
    inline FLOAT32 GetHCuAvail(VOID)             { return HCuAvail; }
    inline VOID    SetHCuAvail(FLOAT32 a_fVal)   { HCuAvail = a_fVal; }
    inline BOOL    GetHADCEnable(UINT8 a_ucSlot) { return HADCEnable[a_ucSlot - 1]; }
    inline UINT8   GetHADCStatus(UINT8 a_ucSlot) { return HADCStatus[a_ucSlot - 1]; }
    inline VOID    ResetHADCEnable(UINT8 a_ucSlot) { HADCEnable[a_ucSlot - 1] = FALSE; }
    inline VOID    SetHADCStatus(UINT8 a_ucSlot, UINT8 a_ucStatus) { HADCStatus[a_ucSlot - 1] = a_ucStatus; }
    inline VOID    DecAdcCycleCount(UINT8 a_ucSlot) {if (AdcCycleCount[a_ucSlot - 1] != 0) AdcCycleCount[a_ucSlot - 1] -= 1; }
    inline UINT8   GetAdcCycleCount(UINT8 a_ucSlot) {return AdcCycleCount[a_ucSlot - 1]; }
    inline VOID    SetAdcCycleCount(UINT8 a_ucSlot, UINT8 a_ucCount) {AdcCycleCount[a_ucSlot - 1] = a_ucCount; }
	
#if !LOWCOST
    inline BOOL IsOwdCktGood(VOID) { return OwdCktGood; }
#else
    inline BOOL IsOwdCktGood(VOID) { return TRUE; }   // always Good for LOWCOST
#endif
    inline VOID SetOwdCktBad(VOID) { OwdCktGood = FALSE; }
    inline VOID SetOwdCktGood(VOID) { OwdCktGood = TRUE; }

#if 0//#ifdef DEBUG
    UINT32 m_ulMaxPpxTime;
    UINT32 m_ulAvgPpxTime;
    UINT32 m_ulMinPpxTime;
    inline VOID SetCalibAll(BOOL a_bVal)   { CalibAll = a_bVal; }
    inline AICALIBDATA *GetCalibData(VOID) { return &CalibData; }
    inline BOARDTYPE GetBoardType(VOID) { return BoardType; }
#endif
    VOID AppPreDump(VOID);
    VOID AppPostDump(VOID);

#if 1 //defined(IOPTYPE_HLAI)
    UINT8 *GetParamPtr(UINT8);
    inline VOID *GetPmioDumpParamPtr(VOID)           { return (VOID *)PmioDumpParamTbl; }
    inline VOID *GetPmioHartDumpParamPtr(VOID)       { return (VOID *)NULL; }
    inline VOID *GetSlwSrcValuePtr(UINT8 a_ucSlot)   { return &SlwSrcBuff[a_ucSlot - 1]; }
    inline UINT8 IsCheckPointParam(UINT8 ucParamId)
    {
        UINT8 ucArrayIndex = 0;
        UINT8 ucChkPntIndex = 0;

        while (CheckPointVer2[ucArrayIndex])
        {
            if (CheckPointVer2[ucArrayIndex] == ucParamId)
                return (ucChkPntIndex + 1);
            else
                ucChkPntIndex += GetParamSize(CheckPointVer2[ucArrayIndex]);

            ucArrayIndex++;
        }

        return PA_NULL;
    }
#endif

#if 1 // temp for testing
    inline BOOL GetCalibrationGood() { return CalibrationGood; }
#endif
};

/*******************************************************************************
*                         extern "C" ISR Wrapper                               *
*  Provides C-linkage entry point for PpxInterruptHandler called from hal_pit.c
*******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

void PpxInterruptHandler(void);

#ifdef __cplusplus
}
#endif

#endif /* __AIHBOXSLOT_HPP__ */
