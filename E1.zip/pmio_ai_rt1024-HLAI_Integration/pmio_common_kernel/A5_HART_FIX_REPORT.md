# A5 HART full-scan and blocking-path fix

## Console finding

The captured run is not hanging in the UART parser. It reaches a valid CMD0, CMD48 and CMD3 on logical channel 10 / modem 2, then prints `HART_DETECTED`. The scan stops because `HartTask()` explicitly sets its validation-finished flag on the first `HART_DISCOVERY_COMPLETE` result.

The log also shows 156 DMC-expiry reports before the first detection: 16 reports for each empty channel 1-9 and 12 while processing channel 10. This confirms that the synchronous HART receive/retry loop is holding the cooperative scheduler for too long.

## Changes

1. Detection no longer ends the scan. The task always advances to the next logical channel and scans through channel 16.
2. `HartScanChannels(start,end)` no longer returns at the first device; it completes the requested range and returns the best overall result.
3. A detected-channel bitmap and device count are maintained. Final output is:
   `HART_SCAN_COMPLETE DEVICES=<n> CHANNEL_MASK=<mask> SPI_ERRORS=<n>`
4. After the validation sweep, the integrated legacy heartbeat/event task path resumes instead of leaving `HartTask()` permanently quiet.
5. Failed probes after a successful channel keep their own channel/modem. They no longer inherit the previous last-good route.
6. Electrically silent routes stop after one full no-carrier/no-byte timeout instead of repeating all three CMD0 attempts. Valid CMD0 identity still requires two matching responses.
7. Raw RX dump is disabled by default to reduce console load. It can be re-enabled with `HART_ENABLE_RAW_RX_DIAG_PRINT=1`.
8. CMD3 is emitted with one `PRINTF`, preventing DMC diagnostics from splitting the line between `QV_U` and `NIT`.

## Expected result for the supplied hardware

With only the device currently seen on channel 10:

```
HART_DETECTED CHANNEL=10 MODEM=2 SPI_ERRORS=0
HART_PROBE CHANNEL=11 MODEM=2 POLL=0
...
HART_PROBE CHANNEL=16 MODEM=3 POLL=0
HART_SCAN_COMPLETE DEVICES=1 CHANNEL_MASK=0200 SPI_ERRORS=0
```

The CMD3 line should remain intact:

```
HART_CMD3 LOOP_CURRENT_MA=4.000 PV_UNIT=121 PV=0.000 SV_UNIT=38 SV=0.000 TV_UNIT=237 TV=0.000 QV_UNIT=32 QV=21.526 DYN_COUNT=4 DEVSTS=00 CHANNEL=10 MODEM=2
```

## Important limitation

The RT1024 transport is still synchronous inside one cooperative task invocation. The silent-route fast exit substantially reduces the validation delay, but a fully non-blocking production implementation requires the modem transaction state to be advanced from a timer/UART-driven state machine rather than `HartModemRun()` busy-waiting until completion.
