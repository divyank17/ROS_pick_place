source/hartdb.o source/hartdb.d: ../source/hartdb.cpp \
 ../source/hartdb.hpp ../source/datatype.h ../source/hart.h \
 ../source/hartstack.hpp \
 C:\Users\Andor\Downloads\k7\aih_basic_pkg\source\hal/hal_fpga.h \
 C:\Users\Andor\Downloads\k7\aih_basic_pkg\source/datatype.h
../source/hartdb.hpp:
../source/datatype.h:
../source/hart.h:
../source/hartstack.hpp:
C:\Users\Andor\Downloads\k7\aih_basic_pkg\source\hal/hal_fpga.h:
C:\Users\Andor\Downloads\k7\aih_basic_pkg\source/datatype.h:
