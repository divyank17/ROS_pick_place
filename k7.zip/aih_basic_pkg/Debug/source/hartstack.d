source/hartstack.o source/hartstack.d: ../source/hartstack.cpp \
 ../source/hartstack.hpp ../source/datatype.h ../source/hart.h \
 C:\Users\Andor\Downloads\k7\aih_basic_pkg\source\hal/hal_fpga.h \
 C:\Users\Andor\Downloads\k7\aih_basic_pkg\source/datatype.h \
 ../source/hartdb.hpp
../source/hartstack.hpp:
../source/datatype.h:
../source/hart.h:
C:\Users\Andor\Downloads\k7\aih_basic_pkg\source\hal/hal_fpga.h:
C:\Users\Andor\Downloads\k7\aih_basic_pkg\source/datatype.h:
../source/hartdb.hpp:
