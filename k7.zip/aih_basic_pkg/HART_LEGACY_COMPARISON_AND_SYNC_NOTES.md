# HART legacy comparison and sync notes

## Compared files

Legacy zip `s1(3).zip` and current project `aih_hart_cmd3_debug_project_clean(1).zip` both contain the same primary HART file set:

- `hart.h`
- `hart.cpp`
- `hartdb.hpp`
- `hartdb.cpp`
- `hartstack.hpp`
- `hartstack.cpp`

## Result of comparison

### 1. HART command response structures

The current `hart.h` already carries the same command-3 payload layout as the legacy code:

```cpp
typedef union Cmd3ResponseTag {
    UINT8 ucBytes[HART_CMD3_4VAR_RESPONSE_SIZE];
    struct {
        UINT8 ucfLoopCurrent[sizeof(FLOAT32)];
        UINT8 ucPvUnitCode;
        UINT8 ucfPvVal[sizeof(FLOAT32)];
        UINT8 ucSvUnitCode;
        UINT8 ucfSvVal[sizeof(FLOAT32)];
        UINT8 ucTvUnitCode;
        UINT8 ucfTvVal[sizeof(FLOAT32)];
        UINT8 ucQvUnitCode;
        UINT8 ucfQvVal[sizeof(FLOAT32)];
    } str;
} HARTCMD3RESPONSE;
```

The CMD3 expected values are therefore retained:

- loop current
- PV unit and PV value
- SV unit and SV value
- TV unit and TV value
- QV unit and QV value

### 2. HART DB handler names

The current project already has the same main command handler names as legacy:

- `clsHartDevDb::Cmd0GoodHandler()` / `Cmd0BadHandler()`
- `clsHartDevDb::Cmd3GoodHandler()` / `Cmd3BadHandler()`
- `clsHartDevDb::Cmd6GoodHandler()` / `Cmd6BadHandler()`
- `clsHartDevDb::Cmd9GoodHandler()` / `Cmd9BadHandler()`
- `clsHartDevDb::Cmd12GoodHandler()` / `Cmd12BadHandler()`
- `clsHartDevDb::Cmd13GoodHandler()` / `Cmd13BadHandler()`
- `clsHartDevDb::Cmd14GoodHandler()` / `Cmd14BadHandler()`
- `clsHartDevDb::Cmd15GoodHandler()` / `Cmd15BadHandler()`
- `clsHartDevDb::Cmd16GoodHandler()` / `Cmd16BadHandler()`
- `clsHartDevDb::Cmd20GoodHandler()` / `Cmd20BadHandler()`
- `clsHartDevDb::Cmd33GoodHandler()` / `Cmd33BadHandler()`
- `clsHartDevDb::Cmd38GoodHandler()` / `Cmd38BadHandler()`
- `clsHartDevDb::Cmd48GoodHandler()` / `Cmd48BadHandler()`
- `clsHartDevDb::Cmd50GoodHandler()` / `Cmd50BadHandler()`
- `clsHartDevDb::Cmd59GoodHandler()` / `Cmd59BadHandler()`
- `clsHartDevDb::Cmd109GoodHandler()` / `Cmd109BadHandler()`

### 3. Main mismatch found before this update

The current project had a practical CMD3 flow issue:

- `HartRunCommand(HARTCOMMAND_THREE, ...)` was already calling `HartDb_HandleResponse()`.
- Then `HartReadDynamicValues()` called `HartDb_UpdateDynamicFromCmd3()`.
- `HartDb_UpdateDynamicFromCmd3()` loaded the same response again and called `UpdateDatabase()` again.

That meant `Cmd3GoodHandler()` could run twice for one physical CMD3 reply, and `m_ulDynGoodCount` could increment twice. The legacy flow processes one received reply once.

### 4. Changes made

#### `source/hart.cpp`

- CMD3 is no longer handled inside the generic `HartRunCommand()` path.
- CMD3 is handled only in `HartReadDynamicValues()` through `HartDb_UpdateDynamicFromCmd3()`.
- This keeps one CMD3 response equal to one `Cmd3GoodHandler()` / `Cmd3BadHandler()` call.

#### `source/hartdb.cpp`

- Added `HartDb_NaN()` helper so RT1024 can initialize missing HART values the way the old code did with `NaN`.
- Updated `InitDevDb()` so HART range/dynamic/slot values initialize closer to legacy:
  - `Lrv`, `Urv`, `Lrl`, `Url`, `Damping` -> NaN
  - `StiEu` -> `MAXUINT8`
  - `HDynVal[]` -> NaN
  - `HSlotVal[]` -> NaN
  - units/status fields -> cleared
- Reworked `Cmd3GoodHandler()` to follow the old legacy order:
  - copy CMD3 payload into `HCmd3`
  - use legacy variable names: `pResponse`, `DataQvVal`, `DataTvVal`, `DataSvVal`, `DataPvVal`
  - populate `HDynVal[0..3]` and `HDynEu[0..3]`
  - missing SV/TV/QV entries become NaN/unit 0 instead of keeping stale previous values
  - loop current is decoded and stored into `HartDeviceInfo_t::loopCurrentMa` for diagnostic printing
- Reworked `Cmd3BadHandler()` to match the old behavior:
  - `HART_RESPCODE_DATA_DID_NOT_CHANGE` calls `Cmd3GoodHandler()`
  - other failures set `HCmdFail`
  - all dynamic values are cleared to NaN/unit 0
- Reworked `Cmd33GoodHandler()` / `Cmd33BadHandler()` closer to legacy:
  - command 33 updates `HSlotVal[]` / `HSlotEu[]`
  - variable-code checks use `m_ucDevScan[]`, same as old flow
  - `HART_RESPCODE_DATA_DID_NOT_CHANGE` calls the good handler
- `HartDb_UpdateDynamicFromCmd3()` now copies the already-decoded values from `clsHartDevDb::HDynVal[]` / `HDynEu[]` into `HartDeviceInfo_t` and sets `dynamicCount` from available values.

#### `source/hartstack.cpp`

- `clsHartQueue::AddToQueue()` now rejects duplicate channel requests and rejects channels already being processed by a modem, matching the legacy queue behavior more closely.

## Current CMD3 diagnostic print

The current project keeps this test line enabled by default:

```text
HART_CMD3 LOOP_CURRENT_MA=<value> PV_UNIT=<unit> PV=<value> SV_UNIT=<unit> SV=<value> TV_UNIT=<unit> TV=<value> QV_UNIT=<unit> QV=<value> DYN_COUNT=<count> CHANNEL=<channel> MODEM=<modem>
```

This directly verifies whether CMD3 decoded all expected values.

## What still cannot be made identical without full main-refresh dependencies

The legacy `HartTask()` depends on old product framework objects and scheduler objects such as `TaskScheduler`, `BOX`, `SLOT()`, `AIH_SLOT()`, `AOH_SLOT()`, pass-through queues, and old event/softfail handling. Those objects are not present in this clean RT1024 validation project, so the current project keeps the same stack-facing names and database flow but uses the RT1024 discovery loop in `pmio_kernel.cpp`.

The integration-ready part is therefore:

- the same HART command constants/response structures
- the same DB command handler names
- the same CMD3 dynamic variable destination members: `HDynVal[]`, `HDynEu[]`, `HDynSt[]`
- the same queue names: `HartQueue`, `pHartModem[]`, `InitHartConnection()`, `AbortHartConnection()`, `ProcessHartInterrupt()`
- a current-board route scan wrapper for RT1024/FPGA validation
