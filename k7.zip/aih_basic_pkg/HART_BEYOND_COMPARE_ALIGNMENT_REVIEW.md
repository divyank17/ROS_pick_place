# HART Beyond Compare Alignment Review

## Scope
Compared `s1` legacy code against `k5` present working code for:

- `source/hart.cpp`
- `source/hart.h`
- `source/hartdb.cpp`
- `source/hartdb.hpp`
- `source/hartstack.cpp`
- `source/hartstack.hpp`
- `source/hal/hal_fpga.h`

## Important conclusion
A byte-for-byte / line-for-line identical file is not possible for the standalone RT1024 project because `s1` depends on the old refresh framework and H8S-style hardware symbols:

- `BOX`, `SLOT`, `AIH_SLOT`, `AOH_SLOT`
- `clsAihSlot`, `clsAohSlot`, `clsAihBoxSlot`, `clsAohBoxSlot`
- `HART_UART(...)`, `HART_MUXADDR`, `HART_MUXENBL`
- `TPU2_*`, `IPRG_HART`, `get_imask_exr()`, `set_imask_exr()`
- old interrupt-driven DUART execution

The `k5` project must keep the RT1024 FPGA SPI path, so hardware access is intentionally routed through `hal_fpga_read()` / `hal_fpga_write()` and small adapter helpers.

## What was changed in this package

### 1. `hart.cpp`
All legacy `s1` global HART function names are present:

- `isHartCapable()`
- `CheckAndInitHart()`
- `ResetHart()`
- `TestHartAddressMux()`
- `HartTask(TASKCONTEXT)`
- `InitHartConnection(UINT8)`
- `AbortHartConnection(UINT8)`
- `ProcessHartInterrupt()`

The old refresh/slot-facing member functions from `s1` were added back under:

```cpp
#ifndef HART_ENABLE_REFRESH_SLOT_API
#define HART_ENABLE_REFRESH_SLOT_API 0
#endif
```

This preserves the original names and bodies for Beyond Compare and future main-refresh integration, without breaking the standalone RT1024 build. Enable it only inside the refresh project where the old slot classes and macros exist.

Legacy slot functions preserved under the flag include:

- `clsAihSlot::GetRcvBufObject()` / `clsAohSlot::GetRcvBufObject()`
- `clsAihSlot::PreCommand()` / `clsAohSlot::PreCommand()`
- `clsAihSlot::PostCommand()` / `clsAohSlot::PostCommand()`
- `clsAihSlot::PreHEnable()` / `clsAohSlot::PreHEnable()`
- `clsAihSlot::PostHEnable()` / `clsAohSlot::PostHEnable()`
- `clsAihSlot::PreHAlarmEnable()` / `clsAohSlot::PreHAlarmEnable()`
- `clsAihSlot::PostHAlarmEnable()` / `clsAohSlot::PostHAlarmEnable()`
- `clsAihSlot::PreHScanCfg()` / `clsAohSlot::PreHScanCfg()`
- `clsAihSlot::PostHScanCfg()` / `clsAohSlot::PostHScanCfg()`
- `clsAihSlot::PreHComThrs()` / `clsAohSlot::PreHComThrs()`
- `clsAihSlot::PreHComHys()` / `clsAohSlot::PreHComHys()`
- `clsAihSlot::PostHDevIdCd()` / `clsAohSlot::PostHDevIdCd()`
- `clsAihSlot::PreHDvMfgCd()` / `clsAohSlot::PreHDvMfgCd()`
- `clsAihSlot::PreHDvMfgCd7()` / `clsAohSlot::PreHDvMfgCd7()`
- `clsAihSlot::PreHDvTypCd()` / `clsAohSlot::PreHDvTypCd()`
- `clsAihSlot::PreHDvTypCd7()` / `clsAohSlot::PreHDvTypCd7()`
- `clsAihSlot::PreHDvRevCd()` / `clsAohSlot::PreHDvRevCd()`
- `clsAihSlot::PreHDdRevCd()` / `clsAohSlot::PreHDdRevCd()`
- `clsAihSlot::PreHEuRngExt()`
- `clsAihBoxSlot::PreHADCEnable()` / `clsAihBoxSlot::PostHADCEnable()`
- `clsAohBoxSlot::PreHADCEnable()` / `clsAohBoxSlot::PostHADCEnable()`
- `clsAohBoxSlot::PreHAutoDet()` / `clsAohBoxSlot::PostHAutoDet()`

### 2. `hartstack.hpp` / `hartstack.cpp`
The modem FIFO member names were changed back closer to legacy:

- `m_ucAppend` -> `m_ucpAppend`
- `m_ucRemove` -> `m_ucpRemove`

The FIFO implementation was also changed back to the pointer-based legacy flow:

- `Flush()` sets both pointers to `m_ucBuffer`
- `PopChar()` advances `m_ucpRemove`
- `ThrowLastRcvd()` walks `m_ucpAppend` backward
- `operator=()` appends through `m_ucpAppend`

All legacy stack-facing function names are present:

- `clsHartQueue::AddToQueue()`
- `clsHartQueue::RemoveFromQueue()`
- `clsHartQueue::ProcessQueue()`
- `clsHartQueue::IsModemQueueEmpty()`
- `clsHartModem::Connect()`
- `clsHartModem::Disconnect()`
- `clsHartModem::Disconnect(BOOL)`
- `clsHartModem::SwitchMux()`
- `clsHartModem::HartMuxLoopbackTest()`
- `clsHartModem::DiagConnect()`
- `clsHartModem::ProcessDiagModem()`
- `clsHartModem::HartModemInterrupt()`
- `clsHartModem::HartModemHeartbeat()`
- `clsHartModem::SetState()`
- `clsHartModem::ModemTimeout()`
- `clsHartModem::TransmitRequest()`
- `clsHartModem::ProcessResponse()`
- `clsHartModem::DecodeResponse()`
- `clsHartModem::ActOnResponse()`
- `clsHartModem::SetupRetry()`
- `clsHartModem::HandleReceiveError()`

Intentional difference: old UART register access is not used directly. It is adapted to RT1024/FPGA SPI through `hal_fpga.h`.

### 3. `hartdb.cpp` / `hartdb.hpp`
The legacy HART DB function surface is present, including:

- `clsHartCfgDb::InitCfgDb()`
- `clsHartCfgDb7::InitCfgDb()`
- `clsHartDevDb::InitDevDb()`
- `clsHartDevDb::SetHComSts()`
- `clsHartDevDb::SetHDevSt()`
- `clsHartDevDb::SetHCmdFail()`
- `clsHartDevDb::IncrementHCfgChCounter()`
- `clsHartDevDb::IncrementHDevStCounter()`
- `clsHartDevDb::ChannelHeartbeat()`
- `clsHartDevDb::PostHComFail()`
- `clsHartDevDb::PostHAlmOptChgEvent()`
- `clsHartDevDb::ProcessHartEvents()`
- `clsHartDevDb::ReceptionComplete()`
- `clsHartDevDb::LogEvent()`
- `clsHartDevDb::BuildScanTable()`
- `clsHartDevDb::ControlStateChange()`
- `clsHartDevDb::CheckDevMismatch()`
- `clsHartDevDb::CheckRangeMismatch()`
- `clsHartDevDb::WriteHCmdData()`
- `clsHartDevDb::BumpPollingAddress()`
- `clsHartDevDb::ScheduleFromInitTable()`
- `clsHartDevDb::ScheduleFromScanTable()`
- `clsHartDevDb::SetupScanMessage()`
- `clsHartDevDb::SetupPassThrough()`
- `clsHartDevDb::UpdateDatabase()`
- `clsHartDevDb::GetHartLoading()`
- all `Cmd*GoodHandler()` and `Cmd*BadHandler()` functions for supported commands

All main command handlers are present:

- CMD0, CMD3, CMD6, CMD9, CMD12, CMD13, CMD14, CMD15, CMD16, CMD20, CMD33, CMD38, CMD48, CMD50, CMD59, CMD109

Intentional difference: event posting and slot/range checks are compacted because the standalone project does not contain the old event client database or slot execution framework.

### 4. `hal_fpga.h`
The header was cleaned from 798 lines to 169 lines.

Removed from `hal_fpga.h`:

- duplicate HART command aliases that already belong in `hart.h`
- duplicate delimiter/HARTCOMMAND macro pollution
- unused register aliases and compatibility helpers not referenced by the current HART path
- unused variadic `HART_UART_SetDTR` / `HART_UART_SetRTS` macro dispatchers

Kept in `hal_fpga.h`:

- FPGA common HART registers
- UART16550 HART registers
- low-level `hal_fpga_init/read/write` prototypes
- minimal inline helpers used by `hart.cpp` and `hartstack.cpp`

## Build validation performed locally
The following local checks passed with a small `PRINTF` and `hal_fpga_*` stub:

```text
hart.cpp syntax check: pass
hartdb.cpp syntax check: pass
hartstack.cpp syntax check: pass
hart.o + hartdb.o + hartstack.o link check: pass
HART_LOG references: 0
hal_fpga.h line count: 169
```

A full MCUXpresso ARM build still needs to be run in your environment because the container does not include the NXP SDK/toolchain project setup.
