/*******************************************************************************
*    File Name   : hartdb.cpp                                                  *
*    Description : HART database implementation.                               *
*******************************************************************************/

#include <string.h>
#include <stdint.h>

#include "hartdb.hpp"

static HartDeviceInfo_t g_hartDevice;
static clsHartCfgDb     g_HartCfgDb;
static clsHartCfgDb7    g_HartCfgDb7;
static clsHartDevDb     g_HartDevDb(16u, &g_HartCfgDb, &g_HartCfgDb7);

UINT8 clsHartDevDb::m_stucNoOf1SecChannels = 0u;
const HARTCMDHANDLER clsHartDevDb::HartCmdHandler[clsHartDevDb::HARTCMDHANDLER_COUNT] = {
    { &clsHartDevDb::Cmd0GoodHandler, &clsHartDevDb::Cmd0BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd3GoodHandler, &clsHartDevDb::Cmd3BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd6GoodHandler, &clsHartDevDb::Cmd6BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd9GoodHandler, &clsHartDevDb::Cmd9BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd12GoodHandler, &clsHartDevDb::Cmd12BadHandler },
    { &clsHartDevDb::Cmd13GoodHandler, &clsHartDevDb::Cmd13BadHandler },
    { &clsHartDevDb::Cmd14GoodHandler, &clsHartDevDb::Cmd14BadHandler },
    { &clsHartDevDb::Cmd15GoodHandler, &clsHartDevDb::Cmd15BadHandler },
    { &clsHartDevDb::Cmd16GoodHandler, &clsHartDevDb::Cmd16BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd20GoodHandler, &clsHartDevDb::Cmd20BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd33GoodHandler, &clsHartDevDb::Cmd33BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd38GoodHandler, &clsHartDevDb::Cmd38BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd48GoodHandler, &clsHartDevDb::Cmd48BadHandler },
    { NULL, NULL },
    { &clsHartDevDb::Cmd50GoodHandler, &clsHartDevDb::Cmd50BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd59GoodHandler, &clsHartDevDb::Cmd59BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd109GoodHandler, &clsHartDevDb::Cmd109BadHandler }
};

static FLOAT32 HartDb_ReadFloatBe(const UINT8 *bytes)
{
    union
    {
        UINT32 u32;
        FLOAT32 f32;
    } v;

    v.u32 = (((UINT32)bytes[0]) << 24) |
            (((UINT32)bytes[1]) << 16) |
            (((UINT32)bytes[2]) << 8)  |
            ((UINT32)bytes[3]);

    return v.f32;
}

static FLOAT32 HartDb_NaN(VOID)
{
    NANINIT nanValue;
    nanValue.ulDword = SIGNL_NAN;
    return nanValue.fVal;
}


static VOID HartDb_CopyPayload(UINT8 *dst, UINT32 dstLen, const HartParsedResponse_t *rsp)
{
    UINT32 count = 0u;

    if ((dst == NULL) || (dstLen == 0u))
    {
        return;
    }

    memset(dst, 0, dstLen);
    if (rsp == NULL)
    {
        return;
    }

    count = (rsp->payloadLen < dstLen) ? rsp->payloadLen : dstLen;
    for (UINT32 i = 0u; i < count; i++)
    {
        dst[i] = rsp->payload[i];
    }
}

/*******************************************************************************
*                           HART pass-through storage                          *
*******************************************************************************/
#if defined(IOMTYPE_UIO)
UINT8 g_ucHPstReqBuffer[HARTMODEM_COUNT][HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];
static clsHartPst g_UioHartPstObjects[HARTMODEM_COUNT][HPST_OBJECTCOUNT];
clsHartPst *pUioHartPst[HARTMODEM_COUNT][HPST_OBJECTCOUNT] =
{
    { &g_UioHartPstObjects[0][0], &g_UioHartPstObjects[0][1], &g_UioHartPstObjects[0][2], &g_UioHartPstObjects[0][3], &g_UioHartPstObjects[0][4], &g_UioHartPstObjects[0][5], &g_UioHartPstObjects[0][6], &g_UioHartPstObjects[0][7], &g_UioHartPstObjects[0][8], &g_UioHartPstObjects[0][9], &g_UioHartPstObjects[0][10], &g_UioHartPstObjects[0][11], &g_UioHartPstObjects[0][12], &g_UioHartPstObjects[0][13], &g_UioHartPstObjects[0][14], &g_UioHartPstObjects[0][15] },
    { &g_UioHartPstObjects[1][0], &g_UioHartPstObjects[1][1], &g_UioHartPstObjects[1][2], &g_UioHartPstObjects[1][3], &g_UioHartPstObjects[1][4], &g_UioHartPstObjects[1][5], &g_UioHartPstObjects[1][6], &g_UioHartPstObjects[1][7], &g_UioHartPstObjects[1][8], &g_UioHartPstObjects[1][9], &g_UioHartPstObjects[1][10], &g_UioHartPstObjects[1][11], &g_UioHartPstObjects[1][12], &g_UioHartPstObjects[1][13], &g_UioHartPstObjects[1][14], &g_UioHartPstObjects[1][15] },
    { &g_UioHartPstObjects[2][0], &g_UioHartPstObjects[2][1], &g_UioHartPstObjects[2][2], &g_UioHartPstObjects[2][3], &g_UioHartPstObjects[2][4], &g_UioHartPstObjects[2][5], &g_UioHartPstObjects[2][6], &g_UioHartPstObjects[2][7], &g_UioHartPstObjects[2][8], &g_UioHartPstObjects[2][9], &g_UioHartPstObjects[2][10], &g_UioHartPstObjects[2][11], &g_UioHartPstObjects[2][12], &g_UioHartPstObjects[2][13], &g_UioHartPstObjects[2][14], &g_UioHartPstObjects[2][15] },
    { &g_UioHartPstObjects[3][0], &g_UioHartPstObjects[3][1], &g_UioHartPstObjects[3][2], &g_UioHartPstObjects[3][3], &g_UioHartPstObjects[3][4], &g_UioHartPstObjects[3][5], &g_UioHartPstObjects[3][6], &g_UioHartPstObjects[3][7], &g_UioHartPstObjects[3][8], &g_UioHartPstObjects[3][9], &g_UioHartPstObjects[3][10], &g_UioHartPstObjects[3][11], &g_UioHartPstObjects[3][12], &g_UioHartPstObjects[3][13], &g_UioHartPstObjects[3][14], &g_UioHartPstObjects[3][15] }
};
#else
UINT8 g_ucHPstReqBuffer[HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];
static clsHartPst g_HartPstObjects[HPST_OBJECTCOUNT];
clsHartPst *pHartPst[HPST_OBJECTCOUNT] =
{
    &g_HartPstObjects[0], &g_HartPstObjects[1], &g_HartPstObjects[2], &g_HartPstObjects[3],
    &g_HartPstObjects[4], &g_HartPstObjects[5], &g_HartPstObjects[6], &g_HartPstObjects[7],
    &g_HartPstObjects[8], &g_HartPstObjects[9], &g_HartPstObjects[10], &g_HartPstObjects[11],
    &g_HartPstObjects[12], &g_HartPstObjects[13], &g_HartPstObjects[14], &g_HartPstObjects[15]
};
#endif
UINT8 g_ucHPstRcvBuffer[HART_MAX_BYTECOUNT * HPST_OBJECTCOUNT];
UINT8 *g_pucHPstRcvBuffer = g_ucHPstRcvBuffer;

clsHartPst::clsHartPst(VOID) :
    m_ucHandle(INVALID_HANDLE),
    m_ucSlotNumber(INVALID_SLOTNUM),
    m_ucPstMsgTimeout(0u),
    m_PstStatus(HPSTSTATUS_DEAD),
    m_PstRcvBuffer(HART_MAX_BYTECOUNT, m_PstRcvMemory)
{
    m_PstRcvBuffer.Flush();
}

VOID *clsHartPst::operator new(size_t, UINT8 a_PstNo)
{
#if defined(IOMTYPE_UIO)
    UINT8 modem = (UINT8)(a_PstNo / HPST_OBJECTCOUNT);
    UINT8 index = (UINT8)(a_PstNo % HPST_OBJECTCOUNT);
    if (modem >= HARTMODEM_COUNT)
    {
        modem = 0u;
    }
    return &g_UioHartPstObjects[modem][index];
#else
    if (a_PstNo >= HPST_OBJECTCOUNT)
    {
        a_PstNo = 0u;
    }
    return &g_HartPstObjects[a_PstNo];
#endif
}

clsHartPst **clsHartPst::PassThroughTable(UINT8 a_ucModemNum)
{
#if defined(IOMTYPE_UIO)
    if (a_ucModemNum >= HARTMODEM_COUNT)
    {
        a_ucModemNum = 0u;
    }
    return pUioHartPst[a_ucModemNum];
#else
    (void)a_ucModemNum;
    return pHartPst;
#endif
}

VOID clsHartCfgDb::InitCfgDb(VOID)
{
    HEnable = TRUE;
    HScanCfg = HSCANCFG_1SECDYN;
    for (UINT8 i = 0u; i < HART6_MAXVAR_COUNT; i++)
    {
        HSlotDvc[i] = i;
    }
    HComThrs = HCOMTHRS_DEFAULT;
    HComHys = HCOMHYS_DEFAULT;
    HDvMfgCd = 0u;
    memset(HDevIdCd, 0, sizeof(HDevIdCd));
    HDvTypCd = 0u;
    HDvRevCd = 0u;
    HDdRevCd = 0u;
    memset(HNtfyCfg, 0, sizeof(HNtfyCfg));
    HAlarmEnable = HALARMENABLE_ALMENBSTATE_MASK;
    HAlarmEnableLrs = HALARMENABLE_ALMENBSTATE_MASK;
}

VOID clsHartCfgDb7::InitCfgDb(VOID)
{
    HDvMfgCd7 = 0u;
    HDvTypCd7 = 0u;
    HSlot0TS = 0.0f;
}

clsHartDevDb::clsHartDevDb(UINT8 a_ucParent, clsHartCfgDb *a_pHartCfgDb, clsHartCfgDb7 *a_pHartCfgDb7) :
    m_cucParent(a_ucParent),
    m_pHartCfgDb(a_pHartCfgDb),
    m_pHartCfgDb7(a_pHartCfgDb7),
    m_ChanRcvBuffer(HART_MAX_BYTECOUNT, m_ChanRcvMemory)
{
    InitDevDb(TRUE);
}

VOID clsHartDevDb::InitDevDb(BOOL a_bInitAll)
{
    (void)a_bInitAll;

    memset(&m_LastParsedResponse, 0, sizeof(m_LastParsedResponse));
    memset(m_ChanRcvMemory, 0, sizeof(m_ChanRcvMemory));
    memset(m_ScanMsgTbl, 0, sizeof(m_ScanMsgTbl));
    memset(&m_UniqueAddress, 0, sizeof(m_UniqueAddress));
    memset(m_ucDynScan, 0, sizeof(m_ucDynScan));
    memset(m_ucDevScan, 0, sizeof(m_ucDevScan));
    m_ucDynScan[0] = HARTCOMMAND_THREE;
    m_ucDevScan[0] = HARTCOMMAND_THIRTYTHREE;
    m_ucDevScan[1] = HART_MAXDYNVAR_COUNT;
    for (UINT8 idx = 0u; idx < HART_MAXDYNVAR_COUNT; idx++)
    {
        m_ucDevScan[(UINT8)(2u + idx)] = idx;
    }
    memset(HDevSt, 0, sizeof(HDevSt));
    memset(HDevStLrs, 0, sizeof(HDevStLrs));
    memset(HDynDvc, 0, sizeof(HDynDvc));
    memset(&HCmd0, 0, sizeof(HCmd0));
    memset(&HCmd3, 0, sizeof(HCmd3));
    memset(&HCmd12, 0, sizeof(HCmd12));
    memset(&HCmd13, 0, sizeof(HCmd13));
    memset(&HCmd14, 0, sizeof(HCmd14));
    memset(&HCmd15, 0, sizeof(HCmd15));
    memset(&HCmd16, 0, sizeof(HCmd16));
    memset(&HLongTag, 0, sizeof(HLongTag));
    memset(&HCmd48, 0, sizeof(HCmd48));
    memset(HCmd48Lrs, 0, sizeof(HCmd48Lrs));
    memset(&HCmd50, 0, sizeof(HCmd50));
    memset(&HCmd59, 0, sizeof(HCmd59));
    memset(HART7_CMD38, 0, sizeof(HART7_CMD38));

    m_HChanMode = HCHANMODE_INIT;
    m_HChanType = HCHANTYPE_CHANNEL;
    m_HDataInit = HDATAINIT_PENDING;
    m_HEventInit = HEVENTINIT_PENDING;
    m_ucLastDsa = 0u;
    m_sScanCounter = TICKS_DISABLE_SCAN;
    m_ucScanNo = 0u;
    m_ucSavedScanNo = 0u;
    m_ucB2BNo = 0u;
    m_ucSkipC48Cycles = 0u;
    m_ucPollingAddress = 0u;
    m_ucHartVersion = HARTVERSION_UNDEFINED;
    m_ucDeviceRevision = 0u;
    m_ucReqdPreambles = HART_DEFAULT_PREAMBLECOUNT;
    m_ucInitCmdIndex = 0u;
    m_ucPstAppIndex = 0u;
    m_ucPstRemIndex = 0u;
    m_ucLastReqCmd = HARTCOMMAND_ZERO;
    m_ucB2BPstMsgCount = 0u;
    m_ucpLastXmtPtr = NULL;
    m_ucLastRespCode = HART_RESPCODE_SUCCESS;
    m_ucNextReqCmd = HARTCOMMAND_ZERO;
    m_ucpNextXmtPtr = (UINT8 *)HARTCMD0;
    m_ucRcvBufIndex = 0u;
    m_ucRcvMsgLen = 0u;
    m_ucCommStatus = HCOMSTS_NORESPONSE;
    m_ucDeviceStatus = 0u;
    m_ucSecMasterResetCounter = 0u;
    m_ucScanOverrunCounter = 0u;
    m_ucPstPresentCounter = 0u;
    m_bCmd38FailReported = FALSE;
    m_bCmd48FailReported = FALSE;
    m_bReReportEvents = FALSE;
    m_ucTemplateChangeWaitCount = 0u;
    m_bHartChanFail = FALSE;
    HComSts = HCOMSTS_NORESPONSE;
    HLComFail = HCOMSTS_NORESPONSE;
    HNComErr = 0u;
    HCmdFail = HARTCOMMAND_INVALID;
    HCmdResp = HART_RESPCODE_SUCCESS;
    HDynRate = HSCANRATE_1SEC;
    HDevRate = HSCANRATE_16SEC;
    HTotalRate = HSCANRATE_1SEC;
    Command = COMMAND_UNDEFINED;
    Lrv = HartDb_NaN();
    Urv = HartDb_NaN();
    Lrl = HartDb_NaN();
    Url = HartDb_NaN();
    Damping = HartDb_NaN();
    StiEu = MAXUINT8;
    for (UINT8 i = 0u; i < HART_MAXDYNVAR_COUNT; i++)
    {
        HDynVal[i] = HartDb_NaN();
        HDynSt[i] = HART_DATA_NOT_AVAILABLE;
        HDynCc[i] = 0u;
        HDynEu[i] = 0u;
    }
    for (UINT8 i = 0u; i < HART_MAXVAR_COUNT; i++)
    {
        HSlotVal[i] = HartDb_NaN();
        HSlotSt[i] = HART_DATA_NOT_AVAILABLE;
        HSlotCc[i] = 0u;
        HSlotEu[i] = 0u;
    }
    HDevSlot0DTS = 0u;
    m_bAtLeastOneTry = FALSE;
    m_ulDynGoodCount = 0u;
    m_ulDevGoodCount = 0u;
    m_ulC48GoodCount = 0u;
    HT5_CfgChngCnt = 0u;
    m_ScanMsg = HSCANMSG_NONE;
}

VOID clsHartDevDb::SetHComSts(HCOMSTS a_HComSts)
{
    m_ucCommStatus = a_HComSts;
    HComSts = a_HComSts;
}

BOOL clsHartDevDb::PostHComFail(BOOL a_bIsRegen)
{
    (void)a_bIsRegen;
    return TRUE;
}

BOOL clsHartDevDb::PostHAlmOptChgEvent(BOOL a_bIsRegen)
{
    (void)a_bIsRegen;
    return TRUE;
}

VOID clsHartDevDb::SetHDevSt(UINT8 a_ucIndex, UINT8 a_ucValue)
{
    if (a_ucIndex < HART_DEVST_BYTECOUNT)
    {
        HDevSt[a_ucIndex] = a_ucValue;
    }
}

VOID clsHartDevDb::SetHCmdFail(HARTCOMMAND a_HCmdFail, UINT8 a_ucRespCode)
{
    HCmdFail = a_HCmdFail;
    HCmdResp = a_ucRespCode;
}

VOID clsHartDevDb::IncrementHCfgChCounter(VOID)
{
    HT5_CfgChngCnt++;
}

VOID clsHartDevDb::IncrementHDevStCounter(VOID)
{
    /* The compact RT1024 database stores current status directly in HDevSt. */
}

VOID clsHartDevDb::ChannelHeartbeat(VOID)
{
    if (m_sScanCounter > 0)
    {
        m_sScanCounter--;
    }
}

BOOL clsHartDevDb::ProcessHartEvents(BOOL a_bIsRegen)
{
    (void)a_bIsRegen;

    if (m_pHartCfgDb == NULL)
    {
        return FALSE;
    }

    /* Compact RT1024 version of the legacy channel heartbeat/event path.
     * Legacy HartTask() calls ChannelHeartbeat() and then ProcessHartEvents()
     * for each channel.  This implementation preserves that visible flow and
     * submits a queue request when the scan counter expires. */
    if (m_pHartCfgDb->HEnable == FALSE)
    {
        return TRUE;
    }

    if (m_sScanCounter == TICKS_DISABLE_SCAN)
    {
        return TRUE;
    }

    if (m_sScanCounter > 0)
    {
        return TRUE;
    }

    HSCANMSG newMsg = HSCANMSG_NONE;
    if (m_HChanMode == HCHANMODE_SCAN)
    {
        m_ucScanNo++;
        if (m_ucScanNo >= MAX_CYCLE_NUMBER)
        {
            m_ucScanNo = 0u;
        }

        newMsg = SetupScanMessage(m_ucScanNo, FIRST_SCAN_MSG);
        if (newMsg == HSCANMSG_NONE)
        {
            m_sScanCounter = TICKS_IN_1_SEC;
            return TRUE;
        }
    }
    else
    {
        if (m_ucInitCmdIndex >= HART_INITCOMMAND_COUNT)
        {
            m_HChanMode = HCHANMODE_SCAN;
            BuildScanTable();
            m_sScanCounter = TICKS_IN_1_SEC;
            return TRUE;
        }
    }

    if (InitHartConnection(m_cucParent) == TRUE)
    {
        m_bAtLeastOneTry = TRUE;
        m_ucSavedScanNo = m_ucScanNo;
        if (m_HChanMode == HCHANMODE_INIT)
        {
            m_sScanCounter = TICKS_SYNCED_CHAN;
        }
        else if (HTotalRate == HSCANRATE_1SEC)
        {
            m_sScanCounter = TICKS_SYNCED_CHAN;
        }
        else
        {
            m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    else
    {
        if (m_ucScanOverrunCounter < MAXUINT8)
        {
            m_ucScanOverrunCounter++;
        }
        m_sScanCounter = TICKS_IN_1_SEC;
    }

    return TRUE;
}

HSYNCSTATUS clsHartDevDb::ReceptionComplete(HMSGSTATUS a_HMsgStatus)
{
    if (a_HMsgStatus == HMSGSTATUS_GOOD)
    {
        (void)UpdateDatabase();
        return HSYNCSTATUS_DROP_SYNC;
    }

    SetHComSts(HCOMSTS_IOMFOUNDERROR);
    return HSYNCSTATUS_DROP_SYNC;
}

VOID clsHartDevDb::LogEvent(HEVENTTYPE a_HEventType)
{
    (void)a_HEventType;
}

VOID clsHartDevDb::BuildScanTable(VOID)
{
    for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
    {
        for (UINT8 col = 0u; col < MAX_MSGS_IN_A_CYCLE; col++)
        {
            m_ScanMsgTbl[row][col] = HSCANMSG_NONE;
        }
    }

    if ((m_pHartCfgDb == NULL) || (m_pHartCfgDb->HEnable == FALSE))
    {
        HDynRate = HSCANRATE_NONE;
        HDevRate = HSCANRATE_NONE;
        HTotalRate = HSCANRATE_NONE;
        return;
    }

    HSCANCFG scanCfg = m_pHartCfgDb->HScanCfg;
    if (scanCfg > HSCANCFG_STATUSONLY)
    {
        scanCfg = HSCANCFG_1SECDYN;
    }

    HDevRate = HSCANCFG_TABLE[scanCfg][0];
    HDynRate = HSCANCFG_TABLE[scanCfg][1];
    if ((HDynRate > HSCANRATE_NONE) || (HDevRate > HSCANRATE_NONE))
    {
        HTotalRate = (HSCANRATE)(HDynRate + HDevRate);
    }
    else
    {
        HTotalRate = HSCANRATE_16SEC;
    }

    if ((HDynRate == HSCANRATE_NONE) && (HDevRate == HSCANRATE_NONE))
    {
        m_ScanMsgTbl[0u][FIRST_SCAN_MSG] = HSCANMSG_C48;
        m_ucSkipC48Cycles = 0u;
        return;
    }

    if ((HDynRate > HSCANRATE_NONE) && (HDynRate >= HDevRate))
    {
        UINT8 period = (UINT8)(HSCANRATE_1SEC / HDynRate);
        if ((period == 0u) || (HTotalRate == HSCANRATE_1SEC))
        {
            period = 1u;
        }
        for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
        {
            if ((row % period) == 0u)
            {
                m_ScanMsgTbl[row][FIRST_SCAN_MSG] = HSCANMSG_DYN;
            }
        }

        if (HDevRate > HSCANRATE_NONE)
        {
            period = (UINT8)(HSCANRATE_1SEC / HDevRate);
            if ((period == 0u) || (HTotalRate == HSCANRATE_1SEC))
            {
                period = 1u;
            }
            for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
            {
                if ((row % period) == 0u)
                {
                    m_ScanMsgTbl[row][FIRST_B2B_MSG] = HSCANMSG_DEV;
                }
            }
        }
    }
    else if (HDevRate > HSCANRATE_NONE)
    {
        UINT8 period = (UINT8)(HSCANRATE_1SEC / HDevRate);
        if (period == 0u)
        {
            period = 1u;
        }
        for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
        {
            if ((row % period) == 0u)
            {
                m_ScanMsgTbl[row][FIRST_SCAN_MSG] = HSCANMSG_DEV;
            }
        }

        if (HDynRate > HSCANRATE_NONE)
        {
            period = (UINT8)(HSCANRATE_1SEC / HDynRate);
            if (period == 0u)
            {
                period = 1u;
            }
            for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
            {
                if ((row % period) == 0u)
                {
                    m_ScanMsgTbl[row][FIRST_B2B_MSG] = HSCANMSG_DYN;
                }
            }
        }
    }

    /* Legacy behavior: ensure command 48 is present at least once in a cycle. */
    for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
    {
        if ((m_ScanMsgTbl[row][FIRST_SCAN_MSG] != HSCANMSG_NONE) &&
            (m_ScanMsgTbl[row][FIRST_B2B_MSG] == HSCANMSG_NONE))
        {
            m_ScanMsgTbl[row][FIRST_B2B_MSG] = HSCANMSG_C48;
            m_ucSkipC48Cycles = 0u;
            return;
        }
    }

    m_ScanMsgTbl[0u][FIRST_SCAN_MSG] = HSCANMSG_C48;
    m_ucSkipC48Cycles = 0u;
}

VOID clsHartDevDb::ControlStateChange(VOID) {}
VOID clsHartDevDb::CheckDevMismatch(VOID) {}
VOID clsHartDevDb::CheckRangeMismatch(VOID) {}

VOID clsHartDevDb::WriteHCmdData(HARTCOMMAND a_HCommand, UINT8 *a_pData)
{
    if (a_pData == NULL)
    {
        return;
    }

    switch (a_HCommand)
    {
        case HARTCOMMAND_ZERO:        memcpy(HCmd0.ucBytes, a_pData, sizeof(HCmd0.ucBytes)); break;
        case HARTCOMMAND_THREE:       memcpy(HCmd3.ucBytes, a_pData, sizeof(HCmd3.ucBytes)); break;
        case HARTCOMMAND_TWELVE:      memcpy(HCmd12.ucBytes, a_pData, sizeof(HCmd12.ucBytes)); break;
        case HARTCOMMAND_THIRTEEN:    memcpy(HCmd13.ucBytes, a_pData, sizeof(HCmd13.ucBytes)); break;
        case HARTCOMMAND_FOURTEEN:    memcpy(HCmd14.ucBytes, a_pData, sizeof(HCmd14.ucBytes)); break;
        case HARTCOMMAND_FIFTEEN:     memcpy(HCmd15.ucBytes, a_pData, sizeof(HCmd15.ucBytes)); break;
        case HARTCOMMAND_SIXTEEN:     memcpy(HCmd16.ucBytes, a_pData, sizeof(HCmd16.ucBytes)); break;
        case HARTCOMMAND_TWENTY:      memcpy(HLongTag.ucBytes, a_pData, sizeof(HLongTag.ucBytes)); break;
        case HARTCOMMAND_FOURTYEIGHT: memcpy(HCmd48.ucBytes, a_pData, sizeof(HCmd48.ucBytes)); break;
        case HARTCOMMAND_FIFTY:       memcpy(HCmd50.ucBytes, a_pData, sizeof(HCmd50.ucBytes)); break;
        case HARTCOMMAND_FIFTYNINE:   memcpy(HCmd59.ucBytes, a_pData, sizeof(HCmd59.ucBytes)); break;
        default: break;
    }
}

HSYNCSTATUS clsHartDevDb::BumpPollingAddress(VOID)
{
    if (m_ucPollingAddress < HART_POLADDR_MAXVAL)
    {
        m_ucPollingAddress++;
        return HSYNCSTATUS_KEEP_SYNC;
    }
    return HSYNCSTATUS_DROP_SYNC;
}

HSYNCSTATUS clsHartDevDb::ScheduleFromInitTable(VOID)
{
    if (m_ucInitCmdIndex < HART_INITCOMMAND_COUNT)
    {
        m_ucInitCmdIndex++;
        return HSYNCSTATUS_KEEP_SYNC;
    }
    m_HChanMode = HCHANMODE_SCAN;
    return HSYNCSTATUS_DROP_SYNC;
}

HSYNCSTATUS clsHartDevDb::ScheduleFromScanTable(VOID)
{
    HSCANMSG newMsg = HSCANMSG_NONE;

    do
    {
        m_ucB2BNo++;
        if (m_ucB2BNo > FINAL_B2B_MSG)
        {
            m_ucB2BNo = FIRST_SCAN_MSG;

            if (HTotalRate == HSCANRATE_1SEC)
            {
                m_ucScanNo++;
                if (m_ucScanNo >= MAX_CYCLE_NUMBER)
                {
                    m_ucScanNo = 0u;
                }
            }
            else
            {
                if (m_sScanCounter <= TICKS_SYNCED_CHAN)
                {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
        }

        if (HTotalRate == HSCANRATE_1SEC)
        {
            newMsg = SetupScanMessage(m_ucScanNo, m_ucB2BNo);
        }
        else
        {
            newMsg = SetupScanMessage(m_ucSavedScanNo, m_ucB2BNo);
        }

        if ((newMsg == HSCANMSG_NONE) && (m_ucB2BNo == FINAL_B2B_MSG))
        {
            if (m_sScanCounter <= TICKS_SYNCED_CHAN)
            {
                m_sScanCounter = TICKS_IN_1_SEC;
            }
            return HSYNCSTATUS_DROP_SYNC;
        }
    } while (newMsg == HSCANMSG_NONE);

    m_ucLastReqCmd  = m_ucNextReqCmd;
    m_ucpLastXmtPtr = m_ucpNextXmtPtr;
    m_ScanMsg       = newMsg;

    if (newMsg == HSCANMSG_PST)
    {
        clsHartPst **pstTable = clsHartPst::PassThroughTable(HartGetModemForChannel(m_cucParent));
        m_HChanType = HCHANTYPE_PASSTHROUGH;
        if ((pstTable != NULL) && (pstTable[m_ucPstRemIndex] != NULL))
        {
            pstTable[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;
        }
    }
    else
    {
        m_HChanType = HCHANTYPE_CHANNEL;
    }

    if (HTotalRate == HSCANRATE_1SEC)
    {
        m_ucScanOverrunCounter = 0u;
        HDevSt[1] &= (UINT8)(~HART_DEVST1_SCANOVRUN_MASK);
    }

    return HSYNCSTATUS_KEEP_SYNC;
}

HSCANMSG clsHartDevDb::SetupScanMessage(UINT8 a_ucScanNo, UINT8 a_ucB2BNo)
{
    if ((a_ucScanNo >= MAX_CYCLE_NUMBER) || (a_ucB2BNo >= MAX_MSGS_IN_A_CYCLE))
    {
        return HSCANMSG_NONE;
    }

    switch (m_ScanMsgTbl[a_ucScanNo][a_ucB2BNo])
    {
        case HSCANMSG_DYN:
            m_ucNextReqCmd = HARTCOMMAND_THREE;
            m_ucDynScan[0] = HARTCOMMAND_THREE;
            m_ucpNextXmtPtr = &m_ucDynScan[0];
            return HSCANMSG_DYN;

        case HSCANMSG_DEV:
            m_ucNextReqCmd = HARTCOMMAND_THIRTYTHREE;
            m_ucDevScan[0] = HARTCOMMAND_THIRTYTHREE;
            m_ucDevScan[1] = (m_ucHartVersion < HARTVERSION_7X) ? HART6_MAXVAR_COUNT : HART_MAXDYNVAR_COUNT;
            m_ucpNextXmtPtr = &m_ucDevScan[0];
            return HSCANMSG_DEV;

        case HSCANMSG_C48:
            if (m_ucSkipC48Cycles > 0u)
            {
                m_ucSkipC48Cycles--;
                return HSCANMSG_NONE;
            }
            m_ucNextReqCmd = HARTCOMMAND_FOURTYEIGHT;
            m_ucpNextXmtPtr = (UINT8 *)&HARTCMD48[0];
            return HSCANMSG_C48;

        case HSCANMSG_PST:
            return SetupPassThrough();

        default:
            break;
    }

    return HSCANMSG_NONE;
}

HSCANMSG clsHartDevDb::SetupPassThrough(VOID)
{
    clsHartPst **pstTable = clsHartPst::PassThroughTable(HartGetModemForChannel(m_cucParent));

    if (pstTable == NULL)
    {
        return HSCANMSG_NONE;
    }

    if (m_HChanType == HCHANTYPE_PASSTHROUGH)
    {
        return HSCANMSG_NONE;
    }

    for (UINT8 count = 0u, pstIndex = m_ucPstRemIndex; count < HPST_OBJECTCOUNT; count++)
    {
        pstIndex++;
        if (pstIndex >= HPST_OBJECTCOUNT)
        {
            pstIndex = 0u;
        }

        clsHartPst *pst = pstTable[pstIndex];
        if ((pst == NULL) ||
            (pst->m_ucSlotNumber != m_cucParent) ||
            (pst->m_PstStatus != HPSTSTATUS_INIT))
        {
            continue;
        }

        m_ucPstRemIndex = pstIndex;
#if defined(IOMTYPE_UIO)
        UINT8 *req = g_ucHPstReqBuffer[HartGetModemForChannel(m_cucParent)][m_ucPstRemIndex];
#else
        UINT8 *req = g_ucHPstReqBuffer[m_ucPstRemIndex];
#endif

        if ((req[HPST_DELIMITER_OFFSET] & HART_ADDR_TYPE_MASK) == 0u)
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        if ((m_UniqueAddress.ucBytes[0] & HART_MANUFACTURE_ID_MASK) !=
            (req[HPST_ADDRESS_OFFSET] & HART_MANUFACTURE_ID_MASK))
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        BOOL addressMatch = TRUE;
        for (UINT8 addr = 1u; addr < HART_LONGADDR_LENGTH; addr++)
        {
            if (m_UniqueAddress.ucBytes[addr] != req[(UINT8)(HPST_ADDRESS_OFFSET + addr)])
            {
                addressMatch = FALSE;
                break;
            }
        }

        if (addressMatch == FALSE)
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        HARTCOMMAND pstCmd = (HARTCOMMAND)req[HPST_COMMAND_OFFSET];
        if ((pstCmd == HARTCOMMAND_ZERO) || (pstCmd == HARTCOMMAND_THIRTYEIGHT))
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        m_ucNextReqCmd = (UINT8)pstCmd;
        m_ucpNextXmtPtr = req;
        pst->m_PstRcvBuffer.Flush();

        if ((m_ucDeviceStatus & (HART_DEVSTS_COLD_START | HART_DEVSTS_CFG_CHANGED)) == 0u)
        {
            m_ucPstPresentCounter = TICKS_IN_16_SEC;
        }

        return HSCANMSG_PST;
    }

    return HSCANMSG_NONE;
}

VOID clsHartDevDb::SetScanCounterForRediscovery(UINT8 a_PointType)
{
    /* Legacy-compatible behavior without depending on the old PNTTYPE enum.
     * In the original code PNTTYPE_NOTCONFIGURED is zero. */
    const UINT8 PNTTYPE_NOTCONFIGURED_LOCAL = 0u;

    if (a_PointType != PNTTYPE_NOTCONFIGURED_LOCAL)
    {
        if ((m_pHartCfgDb != NULL) && (m_pHartCfgDb->HEnable == TRUE))
        {
            m_sScanCounter = (INT16)(TICKS_IN_30_SEC + m_cucParent);
        }
        else
        {
            InitDevDb(TRUE);
        }
    }
    else
    {
        m_sScanCounter = TICKS_IN_60_SEC;
    }
}

HREPLYSTATUS clsHartDevDb::UpdateDatabase(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    HARTCMDHANDLER handler;

    if ((rsp == NULL) || !rsp->valid || !rsp->checksumOk)
    {
        SetHComSts(HCOMSTS_IOMFOUNDERROR);
        return HREPLYSTATUS_BAD;
    }

    m_ucLastReqCmd = rsp->command;
    m_ucLastRespCode = rsp->status0;
    m_ucDeviceStatus = rsp->status1;
    m_ucRcvMsgLen = rsp->payloadLen;
    m_ucRcvBufIndex = 3u;
    SetHDevSt(0u, m_ucDeviceStatus);

    if (m_ucLastReqCmd >= HARTCMDHANDLER_COUNT)
    {
        SetHCmdFail(HARTCOMMAND_INVALID, HART_INVALID_PARAMETER_CODE);
        return HREPLYSTATUS_BAD;
    }

    handler = HartCmdHandler[m_ucLastReqCmd];
    if (rsp->status0 == HART_RESPCODE_SUCCESS)
    {
        if (handler.GoodHandler != NULL)
        {
            return (this->*handler.GoodHandler)();
        }
        return HREPLYSTATUS_GOOD;
    }

    if (rsp->status0 == HART_RESPCODE_DEVICE_BUSY)
    {
        return HREPLYSTATUS_BUSY;
    }

    if (handler.BadHandler != NULL)
    {
        return (this->*handler.BadHandler)(rsp->status0);
    }

    SetHCmdFail((HARTCOMMAND)rsp->command, rsp->status0);
    return HREPLYSTATUS_BAD;
}

FLOAT32 clsHartDevDb::GetHartLoading(VOID)
{
    return 0.0f;
}

VOID clsHartDevDb::LoadParsedResponse(const HartParsedResponse_t *a_pResponse)
{
    m_ChanRcvBuffer.Flush();
    memset(&m_LastParsedResponse, 0, sizeof(m_LastParsedResponse));

    if (a_pResponse == NULL)
    {
        return;
    }

    m_LastParsedResponse = *a_pResponse;
    m_ucLastReqCmd = a_pResponse->command;
    m_ucRcvMsgLen = a_pResponse->payloadLen;
    m_ucLastRespCode = a_pResponse->status0;
    m_ucDeviceStatus = a_pResponse->status1;

    m_ChanRcvBuffer = (UINT8)(a_pResponse->payloadLen + 2u);
    m_ChanRcvBuffer = a_pResponse->status0;
    m_ChanRcvBuffer = a_pResponse->status1;
    for (UINT8 i = 0u; i < a_pResponse->payloadLen; i++)
    {
        m_ChanRcvBuffer = a_pResponse->payload[i];
    }
}

/*******************************************************************************
*                         clsHartDevDb::Cmd0GoodHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd0GoodHandler(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;

    HartDb_CopyPayload(HCmd0.ucBytes, sizeof(HCmd0.ucBytes), rsp);

    if (rsp->payloadLen >= HART_DEVICEID_SIZE + 9u)
    {
        m_UniqueAddress.ucBytes[0] = rsp->longAddr[0];
        m_UniqueAddress.ucBytes[1] = rsp->longAddr[1];
        m_UniqueAddress.ucBytes[2] = rsp->longAddr[2];
        m_UniqueAddress.ucBytes[3] = rsp->longAddr[3];
        m_UniqueAddress.ucBytes[4] = rsp->longAddr[4];

        m_ucReqdPreambles = rsp->responsePreambles;
        m_ucHartVersion = rsp->hartRevision;
        m_ucDeviceRevision = rsp->deviceRevision;
    }

    if (m_ucHartVersion >= HARTVERSION_6X)
    {
        m_ucDevScan[0] = HARTCOMMAND_NINE;
    }
    else if (m_ucHartVersion == HARTVERSION_5X)
    {
        m_ucDevScan[0] = HARTCOMMAND_THIRTYTHREE;
    }
    else
    {
        m_ucHartVersion = HARTVERSION_MISMATCH;
    }

    if (m_ucHartVersion == HARTVERSION_MISMATCH)
    {
        return Cmd0BadHandler(HARTVERSION_MISMATCH);
    }

    if (HCmdFail == HARTCOMMAND_ZERO)
    {
        SetHCmdFail(HARTCOMMAND_INVALID, HART_RESPCODE_SUCCESS);
    }

    SetHComSts(HCOMSTS_GOOD);
    return HREPLYSTATUS_GOOD;
}

HREPLYSTATUS clsHartDevDb::Cmd0BadHandler(UINT8 a_ucRespCode)
{
    SetHCmdFail(HARTCOMMAND_ZERO, a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}

/*******************************************************************************
*                          clsHartDevDb::Cmd3GoodHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd3GoodHandler(VOID)
{
    /* Legacy flow: read dynamic variables and loop current from the command-3
     * response payload, then update the same HDynVal[] / HDynEu[] database
     * members used by the old module.  HART floats are transmitted MSB first;
     * the RT1024 is little-endian, so HartDb_ReadFloatBe() replaces the H8
     * direct DATABYTES overlay while keeping the legacy variable names. */
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    HARTCMD3RESPONSE *pResponse = &HCmd3;
    DATABYTES DataQvVal;
    DATABYTES DataTvVal;
    DATABYTES DataSvVal;
    DATABYTES DataPvVal;
    DATABYTES DataLoopCurrent;

    HartDb_CopyPayload(HCmd3.ucBytes, sizeof(HCmd3.ucBytes), rsp);

    DataLoopCurrent.f32Val = HartDb_NaN();
    DataQvVal.f32Val = HartDb_NaN();
    DataTvVal.f32Val = HartDb_NaN();
    DataSvVal.f32Val = HartDb_NaN();
    DataPvVal.f32Val = HartDb_NaN();

    if (m_ucRcvMsgLen >= sizeof(FLOAT32))
    {
        DataLoopCurrent.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfLoopCurrent);
    }

    if (m_ucRcvMsgLen >= HART_CMD3_4VAR_RESPONSE_SIZE)
    {
        DataQvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfQvVal);
        HDynVal[3] = DataQvVal.f32Val;
        HDynEu[3] = pResponse->str.ucQvUnitCode;
        HDynSt[3] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[3] = HartDb_NaN();
        HDynEu[3] = 0u;
        HDynSt[3] = HART_DATA_NOT_AVAILABLE;
    }

    if (m_ucRcvMsgLen >= HART_CMD3_3VAR_RESPONSE_SIZE)
    {
        DataTvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfTvVal);
        HDynVal[2] = DataTvVal.f32Val;
        HDynEu[2] = pResponse->str.ucTvUnitCode;
        HDynSt[2] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[2] = HartDb_NaN();
        HDynEu[2] = 0u;
        HDynSt[2] = HART_DATA_NOT_AVAILABLE;
    }

    if (m_ucRcvMsgLen >= HART_CMD3_2VAR_RESPONSE_SIZE)
    {
        DataSvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfSvVal);
        HDynVal[1] = DataSvVal.f32Val;
        HDynEu[1] = pResponse->str.ucSvUnitCode;
        HDynSt[1] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[1] = HartDb_NaN();
        HDynEu[1] = 0u;
        HDynSt[1] = HART_DATA_NOT_AVAILABLE;
    }

    if (m_ucRcvMsgLen >= HART_CMD3_1VAR_RESPONSE_SIZE)
    {
        DataPvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfPvVal);
        HDynVal[0] = DataPvVal.f32Val;
        HDynEu[0] = pResponse->str.ucPvUnitCode;
        HDynSt[0] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[0] = HartDb_NaN();
        HDynEu[0] = 0u;
        HDynSt[0] = HART_DATA_NOT_AVAILABLE;
    }

    g_hartDevice.loopCurrentMa = DataLoopCurrent.f32Val;

    m_ulDynGoodCount++;
    if (HCmdFail == HARTCOMMAND_THREE)
    {
        SetHCmdFail(HARTCOMMAND_INVALID, HART_RESPCODE_SUCCESS);
    }

    return HREPLYSTATUS_GOOD;
}

HREPLYSTATUS clsHartDevDb::Cmd3BadHandler(UINT8 a_ucRespCode)
{
    if (a_ucRespCode == HART_RESPCODE_DATA_DID_NOT_CHANGE)
    {
        return Cmd3GoodHandler();
    }

    SetHCmdFail(HARTCOMMAND_THREE, a_ucRespCode);
    for (UINT8 ucCount = 0u; ucCount < HART_MAXDYNVAR_COUNT; ucCount++)
    {
        HDynVal[ucCount] = HartDb_NaN();
        HDynEu[ucCount] = 0u;
        HDynSt[ucCount] = HART_DATA_NOT_AVAILABLE;
    }
    g_hartDevice.dynamicValid = FALSE;
    g_hartDevice.dynamicCount = 0u;
    g_hartDevice.loopCurrentMa = HartDb_NaN();

    return HREPLYSTATUS_CONTINUE;
}

HREPLYSTATUS clsHartDevDb::Cmd6GoodHandler(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    if (rsp->payloadLen > 0u)
    {
        m_ucPollingAddress = (UINT8)(rsp->payload[0] & HART_POLLING_ADDR_MASK);
    }
    if (HCmdFail == HARTCOMMAND_SIX)
    {
        SetHCmdFail(HARTCOMMAND_INVALID, HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}

HREPLYSTATUS clsHartDevDb::Cmd6BadHandler(UINT8 a_ucRespCode)
{
    SetHCmdFail(HARTCOMMAND_SIX, a_ucRespCode);
    return HREPLYSTATUS_CONTINUE;
}

HREPLYSTATUS clsHartDevDb::Cmd9GoodHandler(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    UINT8 maxVars = (UINT8)((rsp->payloadLen > 1u) ? ((rsp->payloadLen - 1u) / HART_SIZEOFVAR0) : 0u);
    if (maxVars > HART_MAXVAR_COUNT)
    {
        maxVars = HART_MAXVAR_COUNT;
    }

    for (UINT8 i = 0u; i < maxVars; i++)
    {
        UINT8 off = (UINT8)(1u + (i * HART_SIZEOFVAR0));
        HSlotEu[i] = rsp->payload[off + 2u];
        HSlotVal[i] = HartDb_ReadFloatBe(&rsp->payload[off + 3u]);
        HSlotSt[i] = rsp->payload[off + 7u];
    }

    m_ulDevGoodCount++;
    return HREPLYSTATUS_GOOD;
}

HREPLYSTATUS clsHartDevDb::Cmd9BadHandler(UINT8 a_ucRespCode)
{
    SetHCmdFail(HARTCOMMAND_NINE, a_ucRespCode);
    return HREPLYSTATUS_CONTINUE;
}

HREPLYSTATUS clsHartDevDb::Cmd12GoodHandler(VOID)
{
    HartDb_CopyPayload(HCmd12.ucBytes, sizeof(HCmd12.ucBytes), &m_LastParsedResponse);
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd12BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_TWELVE, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd13GoodHandler(VOID)
{
    HartDb_CopyPayload(HCmd13.ucBytes, sizeof(HCmd13.ucBytes), &m_LastParsedResponse);
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd13BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_THIRTEEN, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd14GoodHandler(VOID)
{
    HartDb_CopyPayload(HCmd14.ucBytes, sizeof(HCmd14.ucBytes), &m_LastParsedResponse);
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd14BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_FOURTEEN, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd15GoodHandler(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    HartDb_CopyPayload(HCmd15.ucBytes, sizeof(HCmd15.ucBytes), rsp);
    if (rsp->payloadLen >= HART_CMD15_RESPONSE_SIZE)
    {
        StiEu = rsp->payload[2];
        Urv = HartDb_ReadFloatBe(&rsp->payload[3]);
        Lrv = HartDb_ReadFloatBe(&rsp->payload[7]);
        Damping = HartDb_ReadFloatBe(&rsp->payload[11]);
    }
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd15BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_FIFTEEN, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd16GoodHandler(VOID)
{
    HartDb_CopyPayload(HCmd16.ucBytes, sizeof(HCmd16.ucBytes), &m_LastParsedResponse);
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd16BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_SIXTEEN, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd20GoodHandler(VOID)
{
    HartDb_CopyPayload(HLongTag.ucBytes, sizeof(HLongTag.ucBytes), &m_LastParsedResponse);
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd20BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_TWENTY, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd33GoodHandler(VOID)
{
    /* Legacy flow: command 33 reads device variables into HSlotVal[] and
     * HSlotEu[], after checking that the response variable code matches the
     * requested device-variable scan table entry. */
    HARTCMD33RESPONSE Cmd33Response;
    DATABYTES DataVar0Val;
    DATABYTES DataVar1Val;
    DATABYTES DataVar2Val;
    DATABYTES DataVar3Val;

    memset(&Cmd33Response, 0, sizeof(Cmd33Response));
    HartDb_CopyPayload(Cmd33Response.ucBytes, sizeof(Cmd33Response.ucBytes), &m_LastParsedResponse);

    DataVar0Val.f32Val = HartDb_NaN();
    DataVar1Val.f32Val = HartDb_NaN();
    DataVar2Val.f32Val = HartDb_NaN();
    DataVar3Val.f32Val = HartDb_NaN();

    if (m_ucRcvMsgLen >= HART_CMD33_4VAR_RESPONSE_SIZE)
    {
        DataVar3Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar3Val);
    }
    if (m_ucRcvMsgLen >= HART_CMD33_3VAR_RESPONSE_SIZE)
    {
        DataVar2Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar2Val);
    }
    if (m_ucRcvMsgLen >= HART_CMD33_2VAR_RESPONSE_SIZE)
    {
        DataVar1Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar1Val);
    }
    if (m_ucRcvMsgLen >= HART_CMD33_1VAR_RESPONSE_SIZE)
    {
        DataVar0Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar0Val);
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_4VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[5] == Cmd33Response.str.ucVar3Code))
    {
        HSlotEu[3] = Cmd33Response.str.ucVar3Unit;
        HSlotVal[3] = DataVar3Val.f32Val;
        HSlotSt[3] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[3] = 0u;
        HSlotVal[3] = HartDb_NaN();
        HSlotSt[3] = HART_DATA_NOT_AVAILABLE;
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_3VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[4] == Cmd33Response.str.ucVar2Code))
    {
        HSlotEu[2] = Cmd33Response.str.ucVar2Unit;
        HSlotVal[2] = DataVar2Val.f32Val;
        HSlotSt[2] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[2] = 0u;
        HSlotVal[2] = HartDb_NaN();
        HSlotSt[2] = HART_DATA_NOT_AVAILABLE;
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_2VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[3] == Cmd33Response.str.ucVar1Code))
    {
        HSlotEu[1] = Cmd33Response.str.ucVar1Unit;
        HSlotVal[1] = DataVar1Val.f32Val;
        HSlotSt[1] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[1] = 0u;
        HSlotVal[1] = HartDb_NaN();
        HSlotSt[1] = HART_DATA_NOT_AVAILABLE;
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_1VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[2] == Cmd33Response.str.ucVar0Code))
    {
        HSlotEu[0] = Cmd33Response.str.ucVar0Unit;
        HSlotVal[0] = DataVar0Val.f32Val;
        HSlotSt[0] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[0] = 0u;
        HSlotVal[0] = HartDb_NaN();
        HSlotSt[0] = HART_DATA_NOT_AVAILABLE;
    }

    m_ulDevGoodCount++;

    if (HCmdFail == HARTCOMMAND_THIRTYTHREE)
    {
        SetHCmdFail(HARTCOMMAND_INVALID, HART_RESPCODE_SUCCESS);
    }

    return HREPLYSTATUS_GOOD;
}

HREPLYSTATUS clsHartDevDb::Cmd33BadHandler(UINT8 a_ucRespCode)
{
    if (a_ucRespCode == HART_RESPCODE_DATA_DID_NOT_CHANGE)
    {
        return Cmd33GoodHandler();
    }

    SetHCmdFail(HARTCOMMAND_THIRTYTHREE, a_ucRespCode);
    for (UINT8 ucCount = 0u; ucCount < HART_MAXVAR_COUNT; ucCount++)
    {
        HSlotVal[ucCount] = HartDb_NaN();
        HSlotEu[ucCount] = 0u;
        HSlotSt[ucCount] = HART_DATA_NOT_AVAILABLE;
    }

    return HREPLYSTATUS_CONTINUE;
}

HREPLYSTATUS clsHartDevDb::Cmd38GoodHandler(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    if (rsp->payloadLen >= sizeof(HART7_CMD38) - 2u)
    {
        HART7_CMD38[0] = HARTCOMMAND_THIRTYEIGHT;
        HART7_CMD38[1] = HART_CMD38_RESPONSE_SIZE;
        HART7_CMD38[2] = rsp->payload[0];
        HART7_CMD38[3] = rsp->payload[1];
    }
    m_bCmd38FailReported = FALSE;
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd38BadHandler(UINT8 a_ucRespCode) { m_bCmd38FailReported = TRUE; SetHCmdFail(HARTCOMMAND_THIRTYEIGHT, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd48GoodHandler(VOID)
{
    HartDb_CopyPayload(HCmd48.ucBytes, sizeof(HCmd48.ucBytes), &m_LastParsedResponse);
    memcpy(HCmd48Lrs, HCmd48.ucBytes, sizeof(HCmd48Lrs));
    m_bCmd48FailReported = FALSE;
    m_ulC48GoodCount++;
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd48BadHandler(UINT8 a_ucRespCode) { m_bCmd48FailReported = TRUE; SetHCmdFail(HARTCOMMAND_FOURTYEIGHT, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd50GoodHandler(VOID)
{
    HartDb_CopyPayload(HCmd50.ucBytes, sizeof(HCmd50.ucBytes), &m_LastParsedResponse);
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd50BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_FIFTY, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd59GoodHandler(VOID)
{
    HartDb_CopyPayload(HCmd59.ucBytes, sizeof(HCmd59.ucBytes), &m_LastParsedResponse);
    if (m_LastParsedResponse.payloadLen > 0u)
    {
        m_ucReqdPreambles = m_LastParsedResponse.payload[0];
    }
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd59BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_FIFTYNINE, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

HREPLYSTATUS clsHartDevDb::Cmd109GoodHandler(VOID)
{
    return HREPLYSTATUS_GOOD;
}
HREPLYSTATUS clsHartDevDb::Cmd109BadHandler(UINT8 a_ucRespCode) { SetHCmdFail(HARTCOMMAND_HUNDREDNINE, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }

VOID HartDb_Clear(VOID)
{
    memset(&g_hartDevice, 0, sizeof(g_hartDevice));
    g_HartDevDb.InitDevDb(TRUE);
}

BOOL HartDb_UpdateFromCmd0(UINT8 channel,
                           UINT8 modem,
                           UINT8 pollAddr,
                           const HartParsedResponse_t *cmd0,
                           const UINT8 longAddr[HART_LONGADDR_LENGTH],
                           UINT8 responsePreambles)
{
    if ((cmd0 == NULL) || !cmd0->valid || !cmd0->checksumOk || (cmd0->command != HARTCOMMAND_ZERO))
    {
        return FALSE;
    }

    if (cmd0->payloadLen < HART_CMD0_ID_RESPONSE_SIZE)
    {
        return FALSE;
    }

    memset(&g_hartDevice, 0, sizeof(g_hartDevice));
    g_hartDevice.valid = TRUE;
    g_hartDevice.channel = channel;
    g_hartDevice.modem = modem;
    g_hartDevice.pollAddr = pollAddr;
    g_hartDevice.responsePreambles = responsePreambles;

    for (UINT8 i = 0u; i < HART_LONGADDR_LENGTH; i++)
    {
        g_hartDevice.longAddr[i] = longAddr[i];
    }

    g_hartDevice.expandedDeviceType = cmd0->payload[0];
    g_hartDevice.manufacturer = cmd0->payload[1];
    g_hartDevice.deviceType = cmd0->payload[2];
    g_hartDevice.hartRevision = cmd0->payload[4];
    g_hartDevice.deviceRevision = cmd0->payload[5];
    g_hartDevice.softwareRevision = cmd0->payload[6];
    g_hartDevice.hardwareRevisionPhysical = cmd0->payload[7];
    g_hartDevice.flags = cmd0->payload[8];
    g_hartDevice.uniqueId[0] = cmd0->payload[9];
    g_hartDevice.uniqueId[1] = cmd0->payload[10];
    g_hartDevice.uniqueId[2] = cmd0->payload[11];
    g_hartDevice.cmd0Status0 = cmd0->status0;
    g_hartDevice.cmd0Status1 = cmd0->status1;

    g_HartDevDb.LoadParsedResponse(cmd0);
    (void)g_HartDevDb.UpdateDatabase();

    return TRUE;
}

VOID HartDb_UpdateCmd48Status(UINT8 status0, UINT8 status1)
{
    g_hartDevice.cmd48Status0 = status0;
    g_hartDevice.cmd48Status1 = status1;
}

VOID HartDb_UpdateCmd59Status(UINT8 status0, UINT8 status1)
{
    g_hartDevice.cmd59Status0 = status0;
    g_hartDevice.cmd59Status1 = status1;
}

BOOL HartDb_UpdateDynamicFromCmd3(const HartParsedResponse_t *cmd3)
{
    if ((cmd3 == NULL) || !cmd3->valid || !cmd3->checksumOk || (cmd3->command != HARTCOMMAND_THREE))
    {
        return FALSE;
    }

    g_HartDevDb.LoadParsedResponse(cmd3);
    if (g_HartDevDb.UpdateDatabase() == HREPLYSTATUS_BAD)
    {
        g_hartDevice.dynamicValid = FALSE;
        g_hartDevice.dynamicCount = 0u;
        return FALSE;
    }

    for (UINT8 i = 0u; i < HART_MAXDYNVAR_COUNT; i++)
    {
        g_hartDevice.dynamicUnit[i] = 0u;
        g_hartDevice.dynamicValue[i] = HartDb_NaN();
    }
    g_hartDevice.dynamicCount = 0u;

    if ((cmd3->status0 != HART_RESPCODE_SUCCESS) ||
        (cmd3->status1 != 0u) ||
        (cmd3->payloadLen < HART_CMD3_1VAR_RESPONSE_SIZE))
    {
        g_hartDevice.dynamicValid = FALSE;
        return FALSE;
    }

    g_hartDevice.loopCurrentMa = HartDb_ReadFloatBe(&cmd3->payload[0]);

    for (UINT8 i = 0u; i < HART_MAXDYNVAR_COUNT; i++)
    {
        if (g_HartDevDb.HDynSt[i] == HART_DATA_AVAILABLE)
        {
            g_hartDevice.dynamicUnit[i] = g_HartDevDb.HDynEu[i];
            g_hartDevice.dynamicValue[i] = g_HartDevDb.HDynVal[i];
            g_hartDevice.dynamicCount = (UINT8)(i + 1u);
        }
    }

    g_hartDevice.dynamicValid = (g_hartDevice.dynamicCount > 0u) ? TRUE : FALSE;
    return g_hartDevice.dynamicValid;
}

BOOL HartDb_HasDevice(VOID)
{
    return g_hartDevice.valid;
}

const HartDeviceInfo_t *HartDb_GetDevice(VOID)
{
    return &g_hartDevice;
}

clsHartDevDb *HartDb_GetHartDevDb(VOID)
{
    return &g_HartDevDb;
}

HREPLYSTATUS HartDb_HandleResponse(const HartParsedResponse_t *response)
{
    if (response == NULL)
    {
        return HREPLYSTATUS_BAD;
    }

    g_HartDevDb.LoadParsedResponse(response);
    return g_HartDevDb.UpdateDatabase();
}

BOOL HartDb_GetPrimaryVariable(FLOAT32 *pvOut, UINT8 *unitOut)
{
    if ((g_hartDevice.dynamicValid == FALSE) && (g_HartDevDb.HDynSt[0] != HART_DATA_AVAILABLE))
    {
        return FALSE;
    }

    if (pvOut != NULL)
    {
        *pvOut = g_HartDevDb.HDynVal[0];
    }

    if (unitOut != NULL)
    {
        *unitOut = g_HartDevDb.HDynEu[0];
    }

    return TRUE;
}
