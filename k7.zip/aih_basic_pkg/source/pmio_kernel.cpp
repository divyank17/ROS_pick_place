/*******************************************************************************
*    File Name   : pmio_kernel.cpp
*    Description : Board entry for HART discovery.
*******************************************************************************/

#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "peripherals.h"
#include "hal_fpga.h"
#include "hal_gpio.h"
#include "hart.h"
#include "hartstack.hpp"

#ifndef HART_RUN_DISCOVERY_ONCE
#define HART_RUN_DISCOVERY_ONCE          (1u)
#endif

/*
 * HART channels and deriving the modem from the channel group:
 *   CH1..CH4   -> modem0
 *   CH5..CH8   -> modem1
 *   CH9..CH12  -> modem2
 *   CH13..CH16 -> modem3

 */
#ifndef HART_SCAN_CHANNEL_START
#define HART_SCAN_CHANNEL_START          (1u)
#endif

#ifndef HART_SCAN_CHANNEL_END
#define HART_SCAN_CHANNEL_END            (16u)
#endif

static void RunHartScanOnce(void)
{
    HARTDISCOVERYRESULT result;

    result = HartScanChannels((UINT8)HART_SCAN_CHANNEL_START,
                              (UINT8)HART_SCAN_CHANNEL_END);

    HartReportFinalResponse(HartGetActiveChannel(),
                            HartGetActiveModem(),
                            result);
}

int main(void)
{
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    hal_gpio_init();
    BOARD_InitBootPeripherals();
    BOARD_InitDebugConsole();

    hal_fpga_init();
    HartStack_IdleWait(100000u);
    CheckAndInitHart();

#if HART_RUN_DISCOVERY_ONCE
    RunHartScanOnce();

    while (1)
    {
        HartStack_IdleWait(5000000u);
    }
#else
    while (1)
    {
        RunHartScanOnce();
        HartStack_IdleWait(5000000u);
    }
#endif
}
