/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : utils.h                                                     *
*    Description : Common utility declarations for RT1024/QEMU.                *
*                  Stripped to portable functions only (no H8S register access).*
*******************************************************************************/
#ifndef __UTILS_H__
#define __UTILS_H__

#include "datatype.h"
#include "hardfail.h"

/* RETURNSTATUS is defined in global.h — include global.h before this header */
#include "global.h"

/*******************************************************************************
*                         HARD FAIL FUNCTION                                   *
*  Prototype — implementation in hardfail.cpp                                  *
*******************************************************************************/
#ifdef __cplusplus
void HardFail(HARDFAILTYPE a_HfCode, FILE_NAME a_FlIdx = UNKNOWN_FILE,
              UINT16 a_LnNo = 0, UINT8 a_Parm1 = 0, UINT8 a_Parm2 = 0);
#else
void HardFail(HARDFAILTYPE a_HfCode, FILE_NAME a_FlIdx, UINT16 a_LnNo,
              UINT8 a_Parm1, UINT8 a_Parm2);
#endif

/*******************************************************************************
*                         MAXUINT CONSTANTS                                    *
*  MAXUINT8, MAXUINT16, MAXUINT32 are already defined as macros in datatype.h *
*******************************************************************************/

/* TRUE / FALSE / NULL are also in datatype.h */

#endif /* __UTILS_H__ */
