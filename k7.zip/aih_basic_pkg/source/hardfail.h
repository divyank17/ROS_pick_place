/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hardfail.h                                                  *
*    Description : Hard failure type enumeration for RT1024/QEMU.              *
*                  Aligned with Experion database pm_iomlhfst.enm.xml.         *
*******************************************************************************/
#ifndef HARDFAIL_H
#define HARDFAIL_H

typedef enum tagHardfailType {
    HF_UNKNOWN              = 0,
    HF_POWERDOWN            = 1,
    HF_INVPROGRAMEXEC       = 2,
    HF_EPROMCHKERROR        = 3,
    HF_RAMCONTERROR         = 4,
    HF_RAMADDRERROR         = 5,
    HF_DPAERROR             = 6,
    HF_DSAERROR             = 7,
    HF_RCVBUFOVERFLOW       = 8,
    HF_IOLJABBERFIRED       = 9,
    HF_SRAMFAIL             = 10,
    HF_BADPROGRAMJUMP       = 11,
    HF_ADCINCOMPLETE        = 12,
    HF_ADOUTOVERFLOW        = 13,
    HF_ADOUTUNDERFLOW       = 14,
    HF_ADCCALIBERROR        = 15,
    HF_BADDCLTC             = 16,
    HF_DMCTIMEOUT           = 17,
    HF_MULTIPLEOUTPUT       = 18,
    HF_PIDATBUSDIAG         = 19,
    HF_BADDARANGE           = 20,
    HF_MASTERTIMEOUT        = 21,
    HF_UM51WATCHDOG         = 22,
    HF_COUNTERCIRCUIT       = 23,
    HF_SOECOUNTERFAIL       = 24,
    HF_OUTPUTCONTROL        = 25,
    HF_BD_OUTPUT_MUX        = 26,
    HF_APPCRCFAIL           = 27,
    HF_PSCODEMISMATCH       = 28,
    HF_PARITYHWFAIL         = 29,
    HF_TASKSTACKSTART       = 30,
    HF_STACKOVERRURN        = 31,
    HF_WDTTIMEOUT           = 32,
    HF_ILLEGALWRITE         = 33,
    HF_PARITYERROR          = 34,
    HF_IOMUSERRESET         = 35,
    HF_ZEROREFFAIL          = 36,
    HF_REFINPFAIL           = 37,
    HF_FPGARDBKFAIL         = 38,
    HF_PSISOPUFAIL          = 39,
    HF_TCRAMDIAGFAIL        = 40,
    HF_TCCAPSEMPHOREFAIL    = 41,
    HF_TCCPUDIAGFAIL        = 42,
    HF_TCILLEGALISR         = 43,
    HF_TCDATABUSERROR       = 44,
    HF_TCAPPIOTAERROR       = 45,
    HF_TCAPPBOARDPOWERR     = 46,
    HF_TCEXTRAMCONTERROR    = 47,
    HF_TCKERNALPOWERFAIL    = 48,
    HF_TCCPLD_VER_FAIL      = 49,
    HF_TCPARITYFAIL         = 50,
    HF_TCXREADYFAIL         = 51,
    HF_TCLVDTADCFAIL        = 52,
    HF_TCDACRBFAIL          = 53,
    HF_TCAPPWDTTIMEOUT      = 54,
    HF_AODACFAIL            = 55,
    HF_FPGAIRQFAIL          = 56,
    HF_OSCFAIL              = 57,
    HF_COUNTERFAIL          = 58,
    HF_FIRSTUNUSEDENUM      = 59
} HARDFAILTYPE;

/* File name indices for HardFail() caller identification */
typedef enum tagFileName {
    UNKNOWN_FILE        = 0,
    BOXSLOT_HPP         = 1,
    BOXSLOT_CPP         = 2,
    IOMSLOT_HPP         = 3,
    IOMSLOT_CPP         = 4,
    ECL_HPP             = 5,
    ECL_CPP             = 6,
    IOL_HPP             = 7,
    IOL_CPP             = 8,
    TRACELOG_HPP        = 9,
    TRACELOG_CPP        = 10,
    UTILS_CPP           = 11,
    SCHEDULER_CPP       = 12,
    SCHEDULER_HPP       = 13,
    ROOT_CPP            = 14,
    AIHBOXSLOT_HPP      = 15,
    AIHBOXSLOT_CPP      = 16,
    DIAG_CPP            = 17,
    EVRCTASK_CPP        = 18,
    WRDBTASK_CPP        = 19,
    DEBUG_CPP           = 20,
    HARDFAIL_CPP        = 21,
    MAIN_CPP            = 22
} FILE_NAME;

#endif /* HARDFAIL_H */
