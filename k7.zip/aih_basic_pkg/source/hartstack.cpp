/*******************************************************************************
*    File Name   : hartstack.cpp
*    Description : HART protocol stack implementation.
*
*    This file preserves the source HART stack object names and entry points.
*    The UART and mux hardware accesses are routed through hal_fpga.h for the
*    RT1024 FPGA design. Logging is compiled out so HART never blocks IO-Link
*    messages.
*******************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include "hartstack.hpp"
#include "hartdb.hpp"
#include "hal_fpga.h"
#include <string.h>

/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
clsHartQueue HartQueue;
static clsHartModem HartModem0(0);
static clsHartModem HartModem1(1);
static clsHartModem HartModem2(2);
static clsHartModem HartModem3(3);
clsHartModem *pHartModem[HARTMODEM_COUNT] = { &HartModem0, &HartModem1, &HartModem2, &HartModem3 };

UINT8  clsHartModem::m_ucHartMuxEnbl        = 0x00u;
UINT16 clsHartModem::m_usHartMuxAddr        = 0xC840u;
UINT8  clsHartModem::m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT;
UINT8  clsHartModem::m_ucFailedChannel      = 0u;
UINT32 clsHartModem::m_sulMDiagCount        = 0u;

clsClientBuffer::clsClientBuffer(UINT16 a_usBufSize, UINT8 *a_ucpBuf) :
    m_BUFSIZE(a_usBufSize),
    m_ucpBuffer(a_ucpBuf),
    m_usIndex(0)
{
    Flush();
}

VOID clsClientBuffer::Flush(VOID)
{
    for (m_usIndex = 0; m_usIndex < m_BUFSIZE; m_usIndex++)
    {
        m_ucpBuffer[m_usIndex] = 0;
    }
    m_usIndex = 0;
}

UINT8 clsClientBuffer::At(UINT16 a_usIndex)
{
    return (a_usIndex < m_BUFSIZE) ? m_ucpBuffer[a_usIndex] : 0;
}

UINT8 *clsClientBuffer::AddrAt(UINT16 a_usIndex)
{
    return (a_usIndex < m_BUFSIZE) ? &m_ucpBuffer[a_usIndex] : NULL;
}

clsClientBuffer& clsClientBuffer::operator=(const UINT8 a_ucData)
{
    if (m_usIndex < m_BUFSIZE)
    {
        m_ucpBuffer[m_usIndex++] = a_ucData;
    }
    return *this;
}

clsHartQueue::clsHartQueue(VOID) : m_ucNextIndex(0)
{
    memset(m_ucBuffer, 0, sizeof(m_ucBuffer));
}

VOID *clsHartQueue::operator new(size_t, UINT8)
{
    return NULL;
}

BOOL clsHartQueue::AddToQueue(UINT8 a_ucChan)
{
    if ((a_ucChan == 0u) || (m_ucNextIndex >= HARTQUEUE_BUFFER_SIZE))
    {
        return FALSE;
    }

    /* Legacy behavior: reject duplicate client/channel requests already in
     * queue, and reject a request that is already being processed by a modem. */
    for (UINT8 ucCount = 0u; ucCount < m_ucNextIndex; ucCount++)
    {
        if (m_ucBuffer[ucCount] == a_ucChan)
        {
            return FALSE;
        }
    }

    for (UINT8 ucCount = 0u; ucCount < HARTMODEM_COUNT; ucCount++)
    {
        if ((pHartModem[ucCount] != NULL) &&
            (pHartModem[ucCount]->GetModemState() != HMODEMSTATE_DIAG) &&
            (pHartModem[ucCount]->GetConnectedChannel() == a_ucChan))
        {
            return FALSE;
        }
    }

    m_ucBuffer[m_ucNextIndex++] = a_ucChan;
    return TRUE;
}

BOOL clsHartQueue::RemoveFromQueue(UINT8 a_ucChan)
{
    for (UINT8 ucCount = 0u; ucCount < m_ucNextIndex; ucCount++)
    {
        if (m_ucBuffer[ucCount] == a_ucChan)
        {
            for (UINT8 shift = ucCount; shift < (UINT8)(m_ucNextIndex - 1u); shift++)
            {
                m_ucBuffer[shift] = m_ucBuffer[shift + 1u];
            }

            m_ucNextIndex--;
            m_ucBuffer[m_ucNextIndex] = 0u;
            return TRUE;
        }
    }

    return FALSE;
}

VOID clsHartQueue::ProcessQueue(UINT8 a_ucModemNumber)
{
    if (m_ucNextIndex == 0u)
    {
        return;
    }

    for (UINT8 ucCount = 0u; ucCount < m_ucNextIndex; ucCount++)
    {
        UINT8 ucChan = m_ucBuffer[ucCount];
        UINT8 ucRouteModem = HartGetModemForChannel(ucChan);

        if (ucRouteModem == a_ucModemNumber)
        {
            HARTDISCOVERYRESULT result = HART_DISCOVERY_FAILED;

            if (pHartModem[a_ucModemNumber] != NULL)
            {
                pHartModem[a_ucModemNumber]->Connect(ucChan);
            }

            /* Legacy source flow is queue -> modem -> Connect().  On RT1024,
             * the physical transaction is executed here through the proven
             * FPGA/HART transaction path so refresh integration can still call
             * InitHartConnection()/ProcessHartInterrupt() like old code. */
            result = HartDiscoverOnRoute(ucChan, a_ucModemNumber);
            HartSetLastTransactionResult(ucChan, a_ucModemNumber, result);

            if (pHartModem[a_ucModemNumber] != NULL)
            {
                pHartModem[a_ucModemNumber]->Disconnect();
            }

            for (UINT8 shift = ucCount; shift < (UINT8)(m_ucNextIndex - 1u); shift++)
            {
                m_ucBuffer[shift] = m_ucBuffer[shift + 1u];
            }
            m_ucNextIndex--;
            m_ucBuffer[m_ucNextIndex] = 0u;
            return;
        }
    }
}

BOOL clsHartQueue::IsModemQueueEmpty(VOID)
{
    return (m_ucNextIndex == 0u) ? TRUE : FALSE;
}

clsModemBuffer::clsModemBuffer(VOID)
{
    Flush();
}

unsigned short clsModemBuffer::GetLength(void)
{
    return m_ucCount;
}

VOID clsModemBuffer::Flush(VOID)
{
    m_ucpAppend = m_ucpRemove = m_ucBuffer;
    while (m_ucpAppend < (m_ucBuffer + HARTMODEM_BUFFER_SIZE))
    {
        *m_ucpAppend++ = 0;
    }
    m_ucpAppend = m_ucpRemove;
    m_ucCount = 0;
}

UINT8 clsModemBuffer::PopChar(VOID)
{
    UINT8 ucChar = *m_ucpRemove;
    if (m_ucCount > 0)
    {
        *m_ucpRemove++ = 0;
        m_ucCount--;
        if (m_ucpRemove == (m_ucBuffer + HARTMODEM_BUFFER_SIZE))
        {
            m_ucpRemove = m_ucBuffer;
        }
    }
    return ucChar;
}

VOID clsModemBuffer::ThrowLastRcvd(VOID)
{
    if (m_ucCount > 0)
    {
        *m_ucpAppend = 0;
        m_ucCount--;
        if (m_ucpAppend == m_ucBuffer)
        {
            m_ucpAppend = m_ucBuffer + HARTMODEM_BUFFER_SIZE - 1;
        }
        else
        {
            m_ucpAppend--;
        }
    }
}

clsModemBuffer& clsModemBuffer::operator=(const UINT8 a_cucData)
{
    if (m_ucCount < HARTMODEM_BUFFER_SIZE)
    {
        *m_ucpAppend++ = a_cucData;
        m_ucCount++;
        if (m_ucpAppend == (m_ucBuffer + HARTMODEM_BUFFER_SIZE))
        {
            m_ucpAppend = m_ucBuffer;
        }
    }
    return *this;
}

clsHartModem::clsHartModem(UINT8 a_ucModemNumber) :
    m_ucModemNumber(a_ucModemNumber),
    m_ucModemTimer(0),
    m_ModemState(HMODEMSTATE_IDLE),
    m_ucConnectedChannel(0),
    m_cucpXmtBuffer(NULL),
    m_ModemRcvBuffer(),
    m_ucPollingAddress(0),
    m_ucXmtCommand(HARTCOMMAND_INVALID),
    m_ucBytesInRequest(0),
    m_ucBytesInResponse(HART_MAX_BYTECOUNT),
    m_XmtRcvContext(XMTRCVCONTEXT_UNKNOWN),
    m_RcvMsgType(HMSGTYPE_UNKNOWN),
    m_RcvMsgStatus(HMSGSTATUS_BAD),
    m_ucCheckSum(0),
    m_ucRemPreambles(0),
    m_ucRcvdDelimiter(0),
    m_ucRetryCount(HART_MAX_RETRIES),
    m_bBurstDeviceFound(FALSE),
    m_ucModemDiagCount(0),
    m_bRequestDisconnect(FALSE),
    m_bHartStackProc(FALSE)
{
    memset(&m_UniqueAddress, 0, sizeof(m_UniqueAddress));
}

VOID clsHartModem::HartModemInterrupt(HINTRTYPE a_IntrType)
{
    /* Legacy interrupt front-end behavior: ignore idle/bad modems, honor a
     * requested disconnect first, then act according to the DUART interrupt
     * source.  The RT1024 hardware path is polled/transactional, so this keeps
     * the same state flow without reading the old memory-mapped DUART object. */
    if ((m_ModemState == HMODEMSTATE_BAD) || (m_ModemState == HMODEMSTATE_IDLE))
    {
        return;
    }

    if (m_bRequestDisconnect == TRUE)
    {
        Disconnect();
        return;
    }

    switch (a_IntrType)
    {
        case HINTRTYPE_XMTFIFOEMPTY:
            if (m_ModemState == HMODEMSTATE_XMTING)
            {
                if (m_ucBytesInRequest == 0u)
                {
                    SetState(HMODEMSTATE_RCVING, HART_SLAVE_TIME_OUT);
                }
                else
                {
                    TransmitRequest();
                }
            }
            break;

        case HINTRTYPE_CARRIERDETECT:
            if ((m_ModemState == HMODEMSTATE_RCVING) ||
                (m_ModemState == HMODEMSTATE_RCVWAIT) ||
                (m_ModemState == HMODEMSTATE_SUSPECT))
            {
                m_ModemState = HMODEMSTATE_RCVING;
                if (m_ucModemTimer < UART_RCV_FIFO_SIZE)
                {
                    m_ucModemTimer = UART_RCV_FIFO_SIZE;
                }
            }
            else if (m_ModemState == HMODEMSTATE_SYNCWAIT)
            {
                m_ucModemTimer = UART_RCV_FIFO_SIZE;
            }
            break;

        case HINTRTYPE_RCVFIFOFULL:
        case HINTRTYPE_RCVFIFOTOUT:
        case HINTRTYPE_CARRIERDROP:
            if (m_ModemState == HMODEMSTATE_DIAG)
            {
                ProcessDiagModem();
            }
            else
            {
                if (m_ModemState == HMODEMSTATE_SUSPECT)
                {
                    m_ModemState = HMODEMSTATE_RCVING;
                }
                ProcessResponse();
            }
            break;

        default:
            break;
    }
}

VOID clsHartModem::HartModemHeartbeat(VOID)
{
    for (UINT8 modem = 0; modem < HARTMODEM_COUNT; modem++)
    {
        clsHartModem *pModem = pHartModem[modem];
        if (pModem == NULL)
        {
            continue;
        }

        if (pModem->m_bRequestDisconnect != FALSE)
        {
            pModem->Disconnect();
            continue;
        }

        if (pModem->m_ucModemTimer > 0u)
        {
            pModem->m_ucModemTimer--;
            if (pModem->m_ucModemTimer == 0u)
            {
                pModem->ModemTimeout();
            }
        }
    }
}

UINT8 clsHartModem::HartMuxLoopbackTest(VOID)
{
    return TRUE;
}

VOID clsHartModem::Connect(UINT8 a_ucChan)
{
    m_ucConnectedChannel = a_ucChan;
    m_ucPollingAddress = 0u;
    m_ucXmtCommand = HARTCOMMAND_ZERO;
    m_ucBytesInRequest = 0u;
    m_ucBytesInResponse = HART_MAX_BYTECOUNT;
    m_XmtRcvContext = XMTRCVCONTEXT_PREAMBLE;
    m_RcvMsgType = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus = HMSGSTATUS_BAD;
    m_ucCheckSum = 0u;
    m_ucRemPreambles = 0u;
    m_ucRcvdDelimiter = 0u;
    m_ucRetryCount = HART_MAX_RETRIES;
    m_bBurstDeviceFound = FALSE;
    m_bRequestDisconnect = FALSE;
    m_bHartStackProc = TRUE;
    m_ModemRcvBuffer.Flush();
    SwitchMux(a_ucChan);
    SetState(HMODEMSTATE_SYNCWAIT, HART_LINK_GRANT_TIME);
}

VOID clsHartModem::Disconnect(BOOL bResetState)
{
    Disconnect();

    /* Legacy UIO behavior allowed callers to keep m_bHartStackProc asserted
     * when a disconnect is followed immediately by PST scanning. */
    if (bResetState == FALSE)
    {
        m_bHartStackProc = TRUE;
    }
}

VOID clsHartModem::Disconnect(VOID)
{
    m_ucConnectedChannel = 0u;
    m_ucModemTimer = 0u;
    m_cucpXmtBuffer = NULL;
    m_ucBytesInRequest = 0u;
    m_ucBytesInResponse = HART_MAX_BYTECOUNT;
    m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
    m_RcvMsgType = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus = HMSGSTATUS_BAD;
    m_ucRemPreambles = 0u;
    m_ucCheckSum = 0u;
    m_bRequestDisconnect = FALSE;
    m_bHartStackProc = FALSE;
    m_ModemRcvBuffer.Flush();
    m_ModemState = HMODEMSTATE_IDLE;
}

VOID clsHartModem::DiagConnect(UINT8 a_ucChan)
{
    Connect(a_ucChan);
    m_ModemState = HMODEMSTATE_DIAG;
    m_sulMDiagCount++;
}

VOID clsHartModem::SwitchMux(UINT8 a_ucChan)
{
    UINT8 modem = HartGetModemForChannel(a_ucChan);
    UINT16 muxAddr = (UINT16)(1u << ((a_ucChan - 1u) & 0x0Fu));
    UINT8 muxEnable = (UINT8)(1u << modem);

    m_usHartMuxAddr = muxAddr;
    m_ucHartMuxEnbl = muxEnable;

    hal_fpga_hart_mux_set16(m_usHartMuxAddr);
    hal_fpga_hart_mux_enable(m_ucHartMuxEnbl);
}

VOID clsHartModem::ReinstateModem(VOID)
{
    m_ucModemDiagCount++;
    m_ModemState = HMODEMSTATE_SYNCWAIT;
    m_ucModemTimer = HART_LINK_GRANT_TIME;
    m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT;
}

VOID clsHartModem::SetModemBad(VOID)
{
    UINT8 failedChannel = m_ucConnectedChannel;
    Disconnect();
    m_ucFailedChannel = failedChannel;
    m_ModemState = HMODEMSTATE_BAD;
}

VOID clsHartModem::ClearModemBad(VOID)
{
    m_ucFailedChannel = 0;
    if (m_ModemState == HMODEMSTATE_BAD)
    {
        m_ModemState = HMODEMSTATE_IDLE;
    }
}

VOID clsHartModem::ClearTxRxFIFOs(VOID)
{
    HART_UART_InitHART16550(m_ucModemNumber);
}

VOID *clsHartModem::operator new(size_t, UINT8)
{
    return NULL;
}

VOID clsHartModem::SetState(HMODEMSTATE a_ModemState, UINT8 a_ucTimer)
{
    m_ModemState = a_ModemState;
    m_ucModemTimer = a_ucTimer;
}

VOID clsHartModem::ModemTimeout(VOID)
{
    m_ucModemTimer = 0u;
    if (m_ModemState != HMODEMSTATE_BAD)
    {
        m_ModemState = HMODEMSTATE_IDLE;
    }
}

VOID clsHartModem::TransmitRequest(VOID)
{
    m_XmtRcvContext = XMTRCVCONTEXT_PREAMBLE;
    m_RcvMsgType = HMSGTYPE_STXFROMME;
    m_ModemState = HMODEMSTATE_XMTING;
}

VOID clsHartModem::ProcessResponse(VOID)
{
    m_XmtRcvContext = XMTRCVCONTEXT_DELIMITER;
    m_RcvMsgType = HMSGTYPE_ACKTOME;
    m_ModemState = HMODEMSTATE_RCVING;
}

VOID clsHartModem::DecodeResponse(VOID)
{
    m_RcvMsgStatus = HMSGSTATUS_GOOD;
    m_ModemState = HMODEMSTATE_IDLE;
}

VOID clsHartModem::ActOnResponse(VOID)
{
    m_bRequestDisconnect = FALSE;
}

VOID clsHartModem::SetupRetry(UINT8 a_ucRetryReason)
{
    (void)a_ucRetryReason;
    m_ucModemTimer = HART_LINK_GRANT_TIME;
    m_ModemState = HMODEMSTATE_SYNCWAIT;
}

VOID clsHartModem::HandleReceiveError(VOID)
{
    m_ucModemDiagCount++;
    m_RcvMsgStatus = HMSGSTATUS_BAD;
    m_ModemState = HMODEMSTATE_SUSPECT;
}

VOID clsHartModem::ProcessDiagModem(VOID)
{
    m_ModemState = HMODEMSTATE_DIAG;
}



/*******************************************************************************
* User settings
*******************************************************************************/
#define HART_DEFAULT_CHANNEL              (16u)
#define HART_DEFAULT_MODEM                (3u)
#define HART_POLL_ADDR_START           (0u)
#define HART_POLL_ADDR_END             (0u)

/* Discovery behavior:
 * The HART stack keeps the proven HART transaction style and only
 * adds parsing + CMD48/CMD59 after a valid CMD0.
 */
#define HART_ENABLE_CMD48_CMD59         (1u)
#define HART_PRIMARY_GPWR_BIT3          (1u)
#define HART_CMD0_RETRY_COUNT           (3u)

/* Try GPWR HART power bit from hal_fpga.h enable in addition to no-GPWR case. */
#define HART_TRY_GPWR_BIT3             (1u)

/* HART heartbeat: one HART character time approximately 9.187 ms.
 * This is a busy-loop approximation; exact value is not critical for
 * diagnostics, but state transitions now happen like HART modem heartbeat.
 */
#define HART_MODEM_HEARTBEAT_LOOPS     (920000u)

/* Number of modem-heartbeat ticks allowed for each state. */
#define HART_SYNCWAIT_TICKS            (8u)
#define HART_RCVWAIT_TICKS             (80u)
#define HART_RCVING_IDLE_TICKS         (35u)

/* Reset and setup timing */
#define HART_RESET_HOLD_LOOPS          (250000u)
#define HART_RESET_SETTLE_LOOPS        (600000u)
#define HART_MUX_SETTLE_LOOPS          (200000u)
#define HART_RTS_PRE_TX_TICKS          (2u)
#define HART_TX_TO_RX_GUARD_TICKS      (2u)

#define HART_INITIAL_MAR           ((UINT16)HART_DEFAULT_MAR_CH1_M0)
#define HART_INITIAL_MER           ((UINT8)HART_DEFAULT_MER_NONE)

/*******************************************************************************
* Register map location
*******************************************************************************/
/*
 * The HART stack keeps all FPGA, UART, BRG, HART mux, GPWR and HART protocol register
 * values in source/hal/hal_fpga.h.
 *
 * pmio_kernel.cpp now contains only the bring-up/state-machine logic.
 */

/*******************************************************************************
* HART modem object state
*******************************************************************************/
typedef enum
{
    HART_MODEM_IDLE = 0,
    HART_MODEM_SYNCWAIT,
    HART_MODEM_XMITTING,
    HART_MODEM_RCVWAIT,
    HART_MODEM_RCVING,
    HART_MODEM_DONE,
    HART_MODEM_TIMEOUT,
    HART_MODEM_BAD
} HartModemState_t;

typedef struct
{
    UINT8 modem;
    UINT8 channel;
    UINT8 pollAddr;

    UINT8 txFrame[32];
    UINT32 txLen;
    UINT32 txIndex;

    UINT8 rxBuf[128];          /* cleaned bytes used by parser */
    UINT32 rxCount;
    UINT8 rxRawBuf[160];       /* raw bytes seen before status-echo filtering */
    UINT32 rxRawCount;
    UINT32 rxDroppedStatusEcho;
    UINT32 rxExpectedLen;
    UINT32 preambleCount;

    HartModemState_t state;
    UINT32 tickInState;
    UINT32 totalTicks;

    UINT32 msrChanges;
    UINT32 irqChanges;
    UINT32 iirChanges;
    UINT32 uartErrors;
    UINT32 dcdHighTicks;
    UINT32 riHighTicks;
    UINT32 dsrHighTicks;
    UINT32 ctsHighTicks;

    UINT8 lastMsr;
    UINT8 lastIir;
    UINT8 lastIrq;

    bool gpwrEnable;
    bool sawDcd;
    bool completed;
} HartModemObject_t;

/*******************************************************************************
* HART request/response helpers
*******************************************************************************/
/* HART constants are centralized in hal_fpga.h. */

/* HartParsedResponse_t is declared in hartstack.hpp. */

typedef struct
{
    bool useLongAddress;
    UINT8 command;
    UINT8 pollAddr;
    UINT8 longAddr[5];
    UINT8 data[16];
    UINT8 dataLen;
    const char *label;
} HartRequest_t;

static HartRequest_t g_HartRequest;


/*******************************************************************************
* Globals matching old names
*******************************************************************************/
static UINT16 m_usHartMuxAddr = HART_INITIAL_MAR;
static UINT8  m_ucHartMuxEnbl = HART_INITIAL_MER;
static UINT8  m_ucConnectedChannel = HART_DEFAULT_CHANNEL;
static UINT8  m_ucModemNumber = HART_DEFAULT_MODEM;
static UINT8  m_ucRemPreambles = 0u;

static const UINT8 g_uartBase[UART_COUNT] =
{
    UART0_BASE,
    UART1_BASE,
    UART2_BASE,
    UART3_BASE
};

static const UINT8 g_uartReset[UART_COUNT] =
{
    UART0_RESET,
    UART1_RESET,
    UART2_RESET,
    UART3_RESET
};

/*******************************************************************************
* Delay
*******************************************************************************/
static void IdleWait(volatile UINT32 loops)
{
    while (loops-- > 0u)
    {
        __asm volatile ("nop");
    }
}

static void HartCharacterDelayTicks(UINT32 ticks)
{
    for (UINT32 i = 0u; i < ticks; i++)
    {
        IdleWait(HART_MODEM_HEARTBEAT_LOOPS);
    }
}

/*******************************************************************************
* FPGA helpers
*******************************************************************************/
static UINT16 Read16(UINT8 addr)
{
    return hal_fpga_read(addr);
}

static UINT8 Read8(UINT8 addr)
{
    return (UINT8)((Read16(addr) >> 8) & 0xFFu);
}

static UINT8 ReadLsb(UINT8 addr)
{
    return (UINT8)(Read16(addr) & 0xFFu);
}

static void Write16(UINT8 addr, UINT16 value)
{
    hal_fpga_write(addr, value);
}

static void Write8(UINT8 addr, UINT8 value)
{
    hal_fpga_write(addr, (UINT16)((UINT16)value << 8));
}

static UINT8 UartReg(UINT8 modem, UINT8 reg)
{
    return (UINT8)(g_uartBase[modem] + reg);
}

/* UART read and write address helpers.
 * FPGA UART read addresses are 0x80/0x90/0xA0/0xB0 + offset.
 * FPGA UART write addresses are 0x00/0x10/0x20/0x30 + offset.
 */
static UINT8 UartReadRegAddr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_READ_BASE(modem) + reg);
}

static UINT8 UartWriteRegAddr(UINT8 modem, UINT8 reg)
{
    return (UINT8)(UART_WRITE_BASE(modem) + reg);
}

static UINT8 UartRead8(UINT8 modem, UINT8 reg)
{
    return Read8(UartReadRegAddr(modem, reg));
}

static void UartWrite8(UINT8 modem, UINT8 reg, UINT8 value)
{
    Write8(UartWriteRegAddr(modem, reg), value);
}

static void UartForceNormalLineMode(UINT8 modem)
{
    UartWrite8(modem, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    IdleWait(1200u);
}

static UINT16 StableRead16(UINT8 addr, const char *name)
{
    UINT16 r[5];
    UINT16 best = 0u;
    UINT8 bestCount = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        r[i] = Read16(addr);
        IdleWait(2000u);
    }

    for (UINT8 i = 0u; i < 5u; i++)
    {
        UINT8 count = 0u;

        for (UINT8 j = 0u; j < 5u; j++)
        {
            if (r[i] == r[j])
            {
                count++;
            }
        }

        if (count > bestCount)
        {
            bestCount = count;
            best = r[i];
        }
    }

    

    return best;
}

/*******************************************************************************
* Trace helpers
*******************************************************************************/
static const char *StateName(HartModemState_t s)
{
    switch (s)
    {
        case HART_MODEM_IDLE:     return "IDLE";
        case HART_MODEM_SYNCWAIT: return "SYNCWAIT";
        case HART_MODEM_XMITTING: return "XMITTING";
        case HART_MODEM_RCVWAIT:  return "RCVWAIT";
        case HART_MODEM_RCVING:   return "RCVING";
        case HART_MODEM_DONE:     return "DONE";
        case HART_MODEM_TIMEOUT:  return "TIMEOUT";
        case HART_MODEM_BAD:      return "BAD";
        default:                  return "UNKNOWN";
    }
}

static void TraceMsrBits(UINT8 msr)
{
    
}

static void DumpCommon(const char *tag)
{
    
}

static void DumpUart(UINT8 modem, const char *tag)
{
    UINT8 ier = UartRead8(modem, UART_IER);
    UINT8 iir = UartRead8(modem, UART_IIR_FCR);
    UINT8 lcr = UartRead8(modem, UART_LCR);
    UINT8 mcr = UartRead8(modem, UART_MCR);
    UINT8 lsr = UartRead8(modem, UART_LSR);
    UINT8 msr = UartRead8(modem, UART_MSR);
    UINT8 scr = UartRead8(modem, UART_SCR);

    (void)ier;
    (void)iir;
    (void)lcr;
    (void)mcr;
    (void)lsr;
    (void)scr;

    
    TraceMsrBits(msr);
    
}

/*******************************************************************************
* UART and modem setup
*******************************************************************************/
static void ResetUartAndHartModem(UINT8 modem)
{
    

    Write8(g_uartReset[modem], 0x01u);
    IdleWait(HART_RESET_HOLD_LOOPS);

    

    Write8(g_uartReset[modem], 0x00u);
    IdleWait(HART_RESET_SETTLE_LOOPS);
}

static void ClearTxRxFIFOs(UINT8 modem)
{
    UartWrite8(modem, UART_IIR_FCR, 0xC7u);
    IdleWait(8000u);
    UartWrite8(modem, UART_IIR_FCR, 0xC1u);
    IdleWait(8000u);

    for (UINT32 guard = 0u; guard < 256u; guard++)
    {
        if ((UartRead8(modem, UART_LSR) & UART_LSR_DR) == 0u)
        {
            break;
        }

        (void)UartRead8(modem, UART_RBR_THR);
    }
}

static void InitUart(UINT8 modem)
{
    ResetUartAndHartModem(modem);

    UartWrite8(modem, UART_MCR, 0x00u);   /* /RTS inactive high */
    UartWrite8(modem, UART_IER, 0x00u);
    UartWrite8(modem, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    ClearTxRxFIFOs(modem);
    UartWrite8(modem, UART_SCR, 0xDBu);
    IdleWait(20000u);

    DumpUart(modem, "AFTER_UART_INIT");
}

static bool WaitTxReady(UINT8 modem)
{
    for (UINT32 guard = 0u; guard < 150000u; guard++)
    {
        if ((UartRead8(modem, UART_LSR) & UART_LSR_THRE) != 0u)
        {
            return true;
        }
    }

    return false;
}

static bool WaitTxEmpty(UINT8 modem)
{
    for (UINT32 guard = 0u; guard < 350000u; guard++)
    {
        UINT8 lsr = UartRead8(modem, UART_LSR);

        if ((lsr & (UART_LSR_THRE | UART_LSR_TEMT)) == (UART_LSR_THRE | UART_LSR_TEMT))
        {
            return true;
        }
    }

    return false;
}

static void SetMcr(UINT8 modem, UINT8 mcr, const char *tag)
{
    mcr = (UINT8)(mcr & (UINT8)(~UART_MCR_LOOPBACK));
    UartWrite8(modem, UART_MCR, mcr);
    IdleWait(12000u);

    
}

static void WriteTxByte(UINT8 modem, UINT8 byte)
{
    if (!WaitTxReady(modem))
    {
        
    }

    UartWrite8(modem, UART_RBR_THR, byte);
}

/*******************************************************************************
* BRG, MUX, GPWR
*******************************************************************************/
static void ConfigureHartBaud(void)
{
    /* Corrected from FPGA design document:
     *   0x40 = common BRG DLL
     *   0x41 = common BRG DLM
     *   0x42 = BRG MUX SELECT
     *
     * 0x04E2 is the HART baud divisor:
     *   DLL = 0xE2
     *   DLM = 0x04
     *
     * Do NOT use 0x50/0x51 for baud. 0x50 is AO Output Control /
     * AI Wiggle PV register.
     */
    

    Write8(FPGA_BRG_DLL, 0xE2u);
    IdleWait(20000u);

    Write8(FPGA_BRG_DLM, 0x04u);
    IdleWait(20000u);

    /* BRG MUX select: use 0 first. If RX still fails, next stage can scan this.
     * The current priority is to stop writing baud into wrong register 0x50.
     */
    Write8(FPGA_BRG_MUX, 0x00u);
    IdleWait(20000u);

    
}

static void SwitchMux(UINT8 channel, UINT8 modem)
{
    UINT16 usAddr;
    UINT16 clearMask;

    m_ucConnectedChannel = channel;
    m_ucModemNumber = modem;
    m_usHartMuxAddr = HART_INITIAL_MAR;
    m_ucHartMuxEnbl = HART_INITIAL_MER;

    if (channel == 0u)
    {
        channel = 1u;
    }

    usAddr = (UINT16)((channel - 1u) & 0x000Fu);
    usAddr = (UINT16)(usAddr << (modem * 4u));

    switch (modem)
    {
        case 0u: clearMask = 0xFFF0u; break;
        case 1u: clearMask = 0xFF0Fu; break;
        case 2u: clearMask = 0xF0FFu; break;
        case 3u: clearMask = 0x0FFFu; break;
        default: clearMask = 0xFFFFu; break;
    }

    m_usHartMuxAddr &= clearMask;
    m_usHartMuxAddr |= usAddr;
    m_ucHartMuxEnbl |= (UINT8)(0x01u << modem);

    Write16(FPGA_MAR, m_usHartMuxAddr);
    IdleWait(HART_MUX_SETTLE_LOOPS);

    Write16(FPGA_MER, (UINT16)m_ucHartMuxEnbl);
    IdleWait(HART_MUX_SETTLE_LOOPS);

    
}

static void GpwrMaskData(UINT8 mask, UINT8 data)
{
    if (mask == 0u)
    {
        
        return;
    }

    Write16(FPGA_GPWR, (UINT16)(((UINT16)mask << 8) | (UINT16)data));
    IdleWait(80000u);

    
}

/*******************************************************************************
* HART frame
*******************************************************************************/
static void SetShortRequest(UINT8 command, UINT8 pollAddr, const UINT8 *data, UINT8 dataLen, const char *label)
{
    g_HartRequest.useLongAddress = false;
    g_HartRequest.command = command;
    g_HartRequest.pollAddr = pollAddr;
    g_HartRequest.dataLen = dataLen;
    g_HartRequest.label = label;

    for (UINT8 i = 0u; i < sizeof(g_HartRequest.data); i++)
    {
        g_HartRequest.data[i] = 0u;
    }

    for (UINT8 i = 0u; (i < dataLen) && (i < sizeof(g_HartRequest.data)); i++)
    {
        g_HartRequest.data[i] = data[i];
    }
}

static void SetLongRequest(UINT8 command, const UINT8 longAddr[5], const UINT8 *data, UINT8 dataLen, const char *label)
{
    g_HartRequest.useLongAddress = true;
    g_HartRequest.command = command;
    g_HartRequest.pollAddr = 0u;
    g_HartRequest.dataLen = dataLen;
    g_HartRequest.label = label;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        g_HartRequest.longAddr[i] = longAddr[i];
    }

    for (UINT8 i = 0u; i < sizeof(g_HartRequest.data); i++)
    {
        g_HartRequest.data[i] = 0u;
    }

    for (UINT8 i = 0u; (i < dataLen) && (i < sizeof(g_HartRequest.data)); i++)
    {
        g_HartRequest.data[i] = data[i];
    }
}

static void BuildShortFrame(UINT8 pollAddr,
                            UINT8 command,
                            const UINT8 *data,
                            UINT8 dataLen,
                            UINT8 *out,
                            UINT32 *outLen)
{
    UINT32 idx = 0u;
    UINT8 addr = (UINT8)(HART_MASTER_ADDR_MASK | (pollAddr & 0x0Fu));
    UINT8 checksum = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = HART_PREAMBLE_BYTE;
    }

    out[idx++] = HART_DELIMITER_SHORT_MASTER_REQ;
    checksum ^= HART_DELIMITER_SHORT_MASTER_REQ;

    out[idx++] = addr;
    checksum ^= addr;

    out[idx++] = command;
    checksum ^= command;

    out[idx++] = dataLen;
    checksum ^= dataLen;

    for (UINT8 i = 0u; i < dataLen; i++)
    {
        out[idx++] = data[i];
        checksum ^= data[i];
    }

    out[idx++] = checksum;

    /* HART pad byte */
    out[idx++] = HART_PREAMBLE_BYTE;

    *outLen = idx;
}

static void BuildLongFrame(const UINT8 longAddr[5],
                           UINT8 command,
                           const UINT8 *data,
                           UINT8 dataLen,
                           UINT8 *out,
                           UINT32 *outLen)
{
    UINT32 idx = 0u;
    UINT8 checksum = 0u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = HART_PREAMBLE_BYTE;
    }

    /* HART uses HART_UNIQUE_DELIMITER = 0x82 for all non-CMD0 channel requests. */
    out[idx++] = 0x82u;
    checksum ^= 0x82u;

    for (UINT8 i = 0u; i < 5u; i++)
    {
        out[idx++] = longAddr[i];
        checksum ^= longAddr[i];
    }

    out[idx++] = command;
    checksum ^= command;

    out[idx++] = dataLen;
    checksum ^= dataLen;

    for (UINT8 i = 0u; i < dataLen; i++)
    {
        out[idx++] = data[i];
        checksum ^= data[i];
    }

    out[idx++] = checksum;

    /* HART pad byte */
    out[idx++] = HART_PREAMBLE_BYTE;

    *outLen = idx;
}

static void BuildCurrentHartRequest(UINT8 pollAddr, UINT8 *out, UINT32 *outLen)
{
    if (g_HartRequest.useLongAddress)
    {
        BuildLongFrame(g_HartRequest.longAddr,
                       g_HartRequest.command,
                       g_HartRequest.data,
                       g_HartRequest.dataLen,
                       out,
                       outLen);
    }
    else
    {
        BuildShortFrame(pollAddr,
                        g_HartRequest.command,
                        g_HartRequest.data,
                        g_HartRequest.dataLen,
                        out,
                        outLen);
    }
}

static void BuildCmd0(UINT8 pollAddr, UINT8 *out, UINT32 *outLen)
{
    SetShortRequest(HARTCOMMAND_ZERO, pollAddr, NULL, 0u, "CMD0");
    BuildCurrentHartRequest(pollAddr, out, outLen);
}

static void TraceFrame(const UINT8 *buf, UINT32 len)
{
    const char *label = (g_HartRequest.label != NULL) ? g_HartRequest.label : "UNKNOWN";

    

    for (UINT32 i = 0u; i < len; i++)
    {
        
    }

    
}

static void TraceBytesInfo(const char *tag, const UINT8 *buf, UINT32 len)
{
    if ((tag == NULL) || (buf == NULL))
    {
        return;
    }

    

    for (UINT32 i = 0u; i < len; i++)
    {
        
    }

    
}

static bool CheckHartChecksum(const UINT8 *rx, UINT32 frameStart, UINT32 checksumIndex, UINT8 *calcOut)
{
    UINT8 calc = 0u;

    for (UINT32 i = frameStart; i < checksumIndex; i++)
    {
        calc ^= rx[i];
    }

    *calcOut = calc;
    return (calc == rx[checksumIndex]);
}

static bool ParseHartFrameAtOffset(const UINT8 *rx, UINT32 rxLen, UINT32 offset, HartParsedResponse_t *out, bool requireChecksum)
{
    UINT32 idx = offset;
    UINT32 frameStart;
    UINT32 checksumIndex;
    UINT8 calc = 0u;

    for (UINT32 i = 0u; i < sizeof(*out); i++)
    {
        ((UINT8 *)out)[i] = 0u;
    }

    while ((idx < rxLen) && (rx[idx] == HART_PREAMBLE_BYTE))
    {
        out->preambleCount++;
        idx++;
    }

    if (out->preambleCount == 0u)
    {
        return false;
    }

    if ((idx + 4u) >= rxLen)
    {
        return false;
    }

    frameStart = idx;
    out->delimiter = rx[idx++];

    /* Known response delimiters:
     * 0x06 = short address slave response, already observed on hardware.
     * 0x86/0x8E/0x96 = possible long response variants depending on stack/device.
     */
    if (!((out->delimiter == 0x06u) ||
          (out->delimiter == 0x86u) ||
          (out->delimiter == 0x8Eu) ||
          (out->delimiter == 0x96u) ||
          ((out->delimiter & 0x80u) != 0u)))
    {
        return false;
    }

    if ((out->delimiter & 0x80u) != 0u)
    {
        out->isLongAddress = true;
        out->addressLen = 5u;

        if ((idx + 5u + 3u) >= rxLen)
        {
            return false;
        }

        for (UINT8 i = 0u; i < 5u; i++)
        {
            out->address[i] = rx[idx++];
        }
    }
    else
    {
        out->isLongAddress = false;
        out->addressLen = 1u;
        out->address[0] = rx[idx++];
    }

    out->command = rx[idx++];
    out->byteCount = rx[idx++];

    if (out->byteCount > sizeof(out->payload))
    {
        return false;
    }

    checksumIndex = idx + out->byteCount;

    if (checksumIndex >= rxLen)
    {
        return false;
    }

    if (out->byteCount >= 2u)
    {
        out->hasStatus = true;
        out->status0 = rx[idx++];
        out->status1 = rx[idx++];
        out->payloadLen = (UINT8)(out->byteCount - 2u);
    }
    else
    {
        out->payloadLen = out->byteCount;
    }

    for (UINT8 i = 0u; i < out->payloadLen; i++)
    {
        out->payload[i] = rx[idx++];
    }

    out->checksumRx = rx[checksumIndex];
    out->checksumOk = CheckHartChecksum(rx, frameStart, checksumIndex, &calc);
    out->checksumCalc = calc;

    if (requireChecksum && !out->checksumOk)
    {
        return false;
    }

    out->valid = true;
    return true;
}

static bool ParseHartResponse(const UINT8 *rx, UINT32 rxLen, HartParsedResponse_t *out)
{
    for (UINT32 offset = 0u; offset < rxLen; offset++)
    {
        if (rx[offset] != HART_PREAMBLE_BYTE)
        {
            continue;
        }

        if (ParseHartFrameAtOffset(rx, rxLen, offset, out, true))
        {
            
            break;
        }
    }

    if (!out->valid)
    {
        
        TraceBytesInfo("PARSE_FAIL_CLEAN_RX", rx, rxLen);
        return false;
    }

    

    if (out->payloadLen > 0u)
    {
        
        for (UINT8 i = 0u; i < out->payloadLen; i++)
        {
            
        }
        
    }

    return true;
}

static bool ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[5], UINT8 *respPreambles)
{
    if (!cmd0->valid || !cmd0->checksumOk || (cmd0->command != HARTCOMMAND_ZERO))
    {
        
        return false;
    }

    if (cmd0->payloadLen < HART_CMD0_ID_RESPONSE_SIZE)
    {
        
        return false;
    }

    /* HART stack fix:
     * Stage 27 proved the real clean CMD0 response is:
     *   FF FF FF 06 80 00 0E 00 00 FE AA 04 05 05 0A 01 09 04 00 00 30 EE
     *
     * Parsed payloadLen = 12:
     *   payload[0]  = 0xFE
     *   payload[1]  = expanded/manufacturer byte = 0xAA
     *   payload[2]  = device type = 0x04
     *   payload[3]  = response preambles = 0x05
     *   payload[4]  = HART revision = 0x05
     *   payload[5]  = device revision = 0x0A
     *   payload[6]  = software revision = 0x01
     *   payload[7]  = hardware revision / physical signaling = 0x09
     *   payload[8]  = flags / device profile = 0x04
     *   payload[9..11] = unique ID = 00 00 30
     *
     * Cmd0GoodHandler addressing:
     *   unique[0] = payload[1]
     *   unique[1] = payload[2]
     *   unique[2..4] = payload[9..11]
     */
    longAddr[0] = cmd0->payload[1];
    longAddr[1] = cmd0->payload[2];
    longAddr[2] = cmd0->payload[9];
    longAddr[3] = cmd0->payload[10];
    longAddr[4] = cmd0->payload[11];

    *respPreambles = cmd0->payload[3];
    if (*respPreambles < 5u)
    {
        *respPreambles = 5u;
    }

    
    for (UINT8 i = 0u; i < cmd0->payloadLen; i++)
    {
        
    }
    

    

    

    return true;
}



/*******************************************************************************
* Modem object helpers
*******************************************************************************/
static void HartModemSetState(HartModemObject_t *obj, HartModemState_t newState, const char *reason)
{
    

    obj->state = newState;
    obj->tickInState = 0u;
}


static bool HartIsValidResponseDelimiter(UINT8 b)
{
    return ((b == 0x06u) || (b == 0x86u) || (b == 0x8Eu) || (b == 0x96u));
}

static bool HartLooksLikeStatusEcho(UINT8 b)
{
    return ((b == 0x60u) || (b == 0x61u) || (b == 0xC1u) ||
            (b == 0x88u) || (b == 0x09u) || (b == 0x08u) ||
            (b == 0x02u));
}

static UINT32 HartFindDelimiterIndex(const HartModemObject_t *obj)
{
    for (UINT32 i = 0u; i < obj->rxCount; i++)
    {
        if (obj->rxBuf[i] != HART_PREAMBLE_BYTE)
        {
            return i;
        }
    }
    return 0xFFFFFFFFu;
}

static void HartUpdateExpectedLength(HartModemObject_t *obj)
{
    UINT32 d;
    UINT8 delimiter;
    UINT32 byteCountIndex;
    UINT8 byteCount;

    if (obj->rxExpectedLen != 0u)
    {
        return;
    }

    d = HartFindDelimiterIndex(obj);
    if (d == 0xFFFFFFFFu)
    {
        return;
    }

    delimiter = obj->rxBuf[d];
    byteCountIndex = ((delimiter & 0x80u) != 0u) ? (d + 7u) : (d + 3u);

    if (obj->rxCount <= byteCountIndex)
    {
        return;
    }

    byteCount = obj->rxBuf[byteCountIndex];
    if (byteCount > 64u)
    {
        return;
    }

    obj->rxExpectedLen = ((delimiter & 0x80u) != 0u) ? (d + 9u + byteCount) : (d + 5u + byteCount);

    
}

static bool HartByteAllowedAtCleanIndex(HartModemObject_t *obj, UINT8 b, UINT8 lsrBefore)
{
    UINT32 d;
    UINT32 pos;

    if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
    {
        return false;
    }

    if (obj->rxCount == 0u)
    {
        return (b == HART_PREAMBLE_BYTE);
    }

    d = HartFindDelimiterIndex(obj);
    if (d == 0xFFFFFFFFu)
    {
        if (b == HART_PREAMBLE_BYTE)
        {
            return true;
        }
        if ((obj->rxCount >= 2u) && HartIsValidResponseDelimiter(b))
        {
            return true;
        }
        return false;
    }

    pos = obj->rxCount - d;

    if ((obj->rxBuf[d] & 0x80u) == 0u)
    {
        if (pos == 1u)
        {
            if ((b != (UINT8)(HART_MASTER_ADDR_MASK | (obj->pollAddr & 0x0Fu))) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 2u)
        {
            if ((b != g_HartRequest.command) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 3u)
        {
            if ((b > 64u) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
    }
    else
    {
        if (pos == 6u)
        {
            if ((b != g_HartRequest.command) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
        else if (pos == 7u)
        {
            if ((b > 64u) && HartLooksLikeStatusEcho(b))
            {
                return false;
            }
        }
    }

    if ((b == lsrBefore) && HartLooksLikeStatusEcho(b))
    {
        return false;
    }

    return true;
}

static void HartAppendRxByte(HartModemObject_t *obj, UINT8 b, UINT8 lsrBefore)
{
    if (obj->rxRawCount < sizeof(obj->rxRawBuf))
    {
        obj->rxRawBuf[obj->rxRawCount] = b;
    }
    obj->rxRawCount++;

    if (!HartByteAllowedAtCleanIndex(obj, b, lsrBefore))
    {
        obj->rxDroppedStatusEcho++;
        
        return;
    }

    if (obj->rxCount < sizeof(obj->rxBuf))
    {
        obj->rxBuf[obj->rxCount] = b;
    }

    if (b == HART_PREAMBLE_BYTE)
    {
        obj->preambleCount++;
        m_ucRemPreambles++;
    }

    

    obj->rxCount++;
    HartUpdateExpectedLength(obj);
}

static void HartDrainRxFifoClean(HartModemObject_t *obj, UINT8 firstLsr)
{
    UINT8 lsr = firstLsr;

    for (UINT32 guard = 0u; guard < 64u; guard++)
    {
        if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
        {
            
            break;
        }

        if ((lsr & UART_LSR_DR) == 0u)
        {
            break;
        }

        UartForceNormalLineMode(obj->modem);
        IdleWait(2500u);

        UINT8 b = UartRead8(obj->modem, UART_RBR_THR);
        HartAppendRxByte(obj, b, lsr);

        IdleWait(2500u);
        lsr = UartRead8(obj->modem, UART_LSR);
    }
}

static void HartModemSampleStatus(HartModemObject_t *obj)
{
    UINT8 lsr = UartRead8(obj->modem, UART_LSR);

    if ((lsr & UART_LSR_DR) != 0u)
    {
        HartDrainRxFifoClean(obj, lsr);
    }

    lsr = UartRead8(obj->modem, UART_LSR);
    UINT8 msr = UartRead8(obj->modem, UART_MSR);
    UINT8 iir = UartRead8(obj->modem, UART_IIR_FCR);
    UINT8 irq = Read8(FPGA_IRQ_STATUS);

    if (msr != obj->lastMsr)
    {
        obj->msrChanges++;
        
        TraceMsrBits(msr);
        
        obj->lastMsr = msr;
    }

    if (iir != obj->lastIir)
    {
        obj->iirChanges++;
        
        obj->lastIir = iir;
    }

    if (irq != obj->lastIrq)
    {
        obj->irqChanges++;
        
        obj->lastIrq = irq;
    }

    if ((msr & UART_MSR_DCD) != 0u)
    {
        obj->dcdHighTicks++;
        obj->sawDcd = true;
    }

    if ((msr & UART_MSR_RI) != 0u)  { obj->riHighTicks++;  }
    if ((msr & UART_MSR_DSR) != 0u) { obj->dsrHighTicks++; }
    if ((msr & UART_MSR_CTS) != 0u) { obj->ctsHighTicks++; }

    if ((lsr & (UART_LSR_OE | UART_LSR_PE | UART_LSR_FE | UART_LSR_BI)) != 0u)
    {
        obj->uartErrors++;
        
    }

}

static void HartModemTraceTick(HartModemObject_t *obj)
{
    UINT8 lsr = UartRead8(obj->modem, UART_LSR);
    UINT8 msr = UartRead8(obj->modem, UART_MSR);
    UINT8 iir = UartRead8(obj->modem, UART_IIR_FCR);
    UINT8 irq = Read8(FPGA_IRQ_STATUS);

    
    TraceMsrBits(msr);
    
}

static void HartModemPrepareTransaction(HartModemObject_t *obj, UINT8 channel, UINT8 modem, UINT8 pollAddr, bool gpwrEnable)
{
    obj->modem = modem;
    obj->channel = channel;
    obj->pollAddr = pollAddr;
    obj->txLen = 0u;
    obj->txIndex = 0u;
    obj->rxCount = 0u;
    obj->rxRawCount = 0u;
    obj->rxDroppedStatusEcho = 0u;
    obj->rxExpectedLen = 0u;
    obj->preambleCount = 0u;
    obj->state = HART_MODEM_IDLE;
    obj->tickInState = 0u;
    obj->totalTicks = 0u;
    obj->msrChanges = 0u;
    obj->irqChanges = 0u;
    obj->iirChanges = 0u;
    obj->uartErrors = 0u;
    obj->dcdHighTicks = 0u;
    obj->riHighTicks = 0u;
    obj->dsrHighTicks = 0u;
    obj->ctsHighTicks = 0u;
    obj->gpwrEnable = gpwrEnable;
    obj->sawDcd = false;
    obj->completed = false;

    BuildCurrentHartRequest(pollAddr, obj->txFrame, &obj->txLen);

    obj->lastMsr = UartRead8(modem, UART_MSR);
    obj->lastIir = UartRead8(modem, UART_IIR_FCR);
    obj->lastIrq = Read8(FPGA_IRQ_STATUS);
}

static void HartModemEnterSyncWait(HartModemObject_t *obj)
{
    ClearTxRxFIFOs(obj->modem);

    /* Connect and stay connected. */
    SwitchMux(obj->channel, obj->modem);

    if (obj->gpwrEnable)
    {
        GpwrMaskData(0x08u, 0x08u);
    }
    else
    {
        GpwrMaskData(0x00u, 0x00u);
    }

    /* Receive mode before transmit: /RTS inactive high, RX+modem status enabled. */
    SetMcr(obj->modem, 0x00u, "SYNCWAIT_RX_RTS_INACTIVE");
    UartWrite8(obj->modem, UART_IER, HART_IER_RX_MODEM_STATUS);
    DumpUart(obj->modem, "ENTER_SYNCWAIT");
    
    TraceFrame(obj->txFrame, obj->txLen);

    HartModemSetState(obj, HART_MODEM_SYNCWAIT, "connected modem and waiting before transmit");
}

static void HartModemEnterTransmit(HartModemObject_t *obj)
{
    if (obj->gpwrEnable)
    {
        GpwrMaskData(0x08u, 0x08u);
    }

    /* HARTRTSx_n active-low: MCR.RTS=1 asserts the external /RTS low. */
    SetMcr(obj->modem, UART_MCR_RTS, "XMITTING_ASSERT_RTS_ACTIVE_LOW");
    UartWrite8(obj->modem, UART_IER, HART_IER_TX_EMPTY);
    HartCharacterDelayTicks(HART_RTS_PRE_TX_TICKS);

    DumpUart(obj->modem, "ENTER_XMITTING");
    HartModemSetState(obj, HART_MODEM_XMITTING, "RTS asserted active-low");
}

static void HartModemTransmitAll(HartModemObject_t *obj)
{
    while (obj->txIndex < obj->txLen)
    {
        WriteTxByte(obj->modem, obj->txFrame[obj->txIndex]);
        obj->txIndex++;
    }

    UartWrite8(obj->modem, UART_IER, HART_IER_TX_EMPTY);

    if (!WaitTxEmpty(obj->modem))
    {
        
    }

    DumpUart(obj->modem, "AFTER_TX_DRAIN");
}

static void HartModemEnterRcvWait(HartModemObject_t *obj)
{
    HartCharacterDelayTicks(HART_TX_TO_RX_GUARD_TICKS);

    /* Receive mode: /RTS inactive high. */
    SetMcr(obj->modem, 0x00u, "RCVWAIT_DEASSERT_RTS_FOR_RX");
    UartWrite8(obj->modem, UART_IER, HART_IER_RX_MODEM_STATUS);

    if (obj->gpwrEnable)
    {
        /* Keep bit3 on while receiving first. If this is a TX enable bit only,
         * later logs will still tell us DCD/RX behavior.
         */
        GpwrMaskData(0x08u, 0x08u);
    }

    DumpUart(obj->modem, "ENTER_RCVWAIT");
    HartModemSetState(obj, HART_MODEM_RCVWAIT, "TX complete and waiting for carrier/RX");
}

static void HartModemTick(HartModemObject_t *obj)
{
    UINT32 rxBefore = obj->rxCount;

    obj->totalTicks++;
    obj->tickInState++;

    HartModemSampleStatus(obj);

    /*
     * Important after compiling out debug output:
     * The old debug-heavy loop was accidentally giving the UART more real time
     * between state ticks. With clean logs the loop is faster, so do not treat
     * RCVING idle timeout as "time since entering RCVING"; treat it as
     * "time since the last received byte".
     */
    if ((obj->state == HART_MODEM_RCVING) && (obj->rxCount > rxBefore))
    {
        obj->tickInState = 0u;
    }

    if ((obj->totalTicks % 5u) == 0u)
    {
        HartModemTraceTick(obj);
    }

    switch (obj->state)
    {
        case HART_MODEM_IDLE:
            HartModemEnterSyncWait(obj);
            break;

        case HART_MODEM_SYNCWAIT:
            if (obj->tickInState >= HART_SYNCWAIT_TICKS)
            {
                HartModemEnterTransmit(obj);
            }
            break;

        case HART_MODEM_XMITTING:
            HartModemTransmitAll(obj);
            HartModemEnterRcvWait(obj);
            break;

        case HART_MODEM_RCVWAIT:
            if (obj->rxCount > 0u)
            {
                HartModemSetState(obj, HART_MODEM_RCVING, "RX byte arrived");
            }
            else if (obj->sawDcd)
            {
                HartModemSetState(obj, HART_MODEM_RCVING, "carrier detected");
            }
            else if (obj->tickInState >= HART_RCVWAIT_TICKS)
            {
                HartModemSetState(obj, HART_MODEM_TIMEOUT, "no carrier/RX during receive wait");
            }
            break;

        case HART_MODEM_RCVING:
            if ((obj->rxExpectedLen != 0u) && (obj->rxCount >= obj->rxExpectedLen))
            {
                HartModemSetState(obj, HART_MODEM_DONE, "RX completed by expected frame length");
            }
            else if (obj->rxCount > 0u)
            {
                if (obj->tickInState >= HART_RCVING_IDLE_TICKS)
                {
                    HartModemSetState(obj, HART_MODEM_DONE, "RX completed by idle timeout");
                }
            }
            else if (obj->tickInState >= HART_RCVING_IDLE_TICKS)
            {
                HartModemSetState(obj, HART_MODEM_TIMEOUT, "carrier seen but no RX byte");
            }
            break;

        case HART_MODEM_DONE:
        case HART_MODEM_TIMEOUT:
        case HART_MODEM_BAD:
        default:
            obj->completed = true;
            break;
    }
}

static void HartModemRun(HartModemObject_t *obj)
{
    while (!obj->completed)
    {
        HartModemTick(obj);

        if (obj->completed)
        {
            break;
        }

        HartCharacterDelayTicks(1u);
    }
}

static void HartModemTraceResult(HartModemObject_t *obj, const char *caseName)
{
    

    if (obj->rxCount > 0u)
    {
        
        for (UINT32 i = 0u; (i < obj->rxCount) && (i < sizeof(obj->rxBuf)); i++)
        {
            
        }
        
    }

    if (obj->rxRawCount > 0u)
    {
        UINT32 rawToTrace = obj->rxRawCount;
        if (rawToTrace > sizeof(obj->rxRawBuf))
        {
            rawToTrace = sizeof(obj->rxRawBuf);
        }

        
        for (UINT32 i = 0u; i < rawToTrace; i++)
        {
            
        }
        
    }
}

/*******************************************************************************
* Self-check
*******************************************************************************/
static bool SelfCheck(void)
{
    UINT16 ver;
    UINT16 rev;
    UINT16 mod;

    DumpCommon("BOOT_RAW");

    ver = StableRead16(FPGA_VERSION, "C5_VERSION");
    rev = StableRead16(FPGA_REVISION, "C6_REVISION");
    mod = StableRead16(FPGA_MODNUM, "C8_MODNUM");

    

    if ((((ver >> 8) & 0xFFu) != 0x6Du) ||
        (((rev >> 8) & 0xFFu) != 0x03u))
    {
        
        return false;
    }

    if ((((mod >> 8) & 0xFFu) != 0x13u) &&
        (((mod >> 8) & 0xFFu) != 0x14u))
    {
        
    }

    
    return true;
}

/*******************************************************************************
* HART stack
*******************************************************************************/
static UINT32 RunHartTransaction(UINT8 channel,
                                      UINT8 modem,
                                      UINT8 pollAddr,
                                      bool gpwr,
                                      HartParsedResponse_t *parsedOut)
{
    HartModemObject_t obj;
    const char *caseName = (g_HartRequest.label != NULL) ? g_HartRequest.label : "REQ";

    
    
    

    /* IMPORTANT:
     * Keep proven working behavior: each transaction gets the same
     * reset/baud/mux/write sequence that proved TX/RX on hardware.
     */
    InitUart(modem);
    ConfigureHartBaud();

    HartModemPrepareTransaction(&obj, channel, modem, pollAddr, gpwr);
    HartModemRun(&obj);
    HartModemTraceResult(&obj, caseName);

    if (obj.rxCount > 0u)
    {
        
        if (parsedOut != NULL)
        {
            bool parseOk = ParseHartResponse(obj.rxBuf, obj.rxCount, parsedOut);
            if (!parseOk)
            {
                TraceBytesInfo("PARSE_FAIL_RAW_RX", obj.rxRawBuf, obj.rxRawCount);
                
            }
        }
    }
    else if (obj.sawDcd)
    {
        
    }
    else
    {
        
    }

    return obj.rxCount;
}

static bool GetCleanCmd0Response(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out)
{
    for (UINT8 attempt = 1u; attempt <= HART_CMD0_RETRY_COUNT; attempt++)
    {
        

        SetShortRequest(HARTCOMMAND_ZERO, pollAddr, NULL, 0u, "CMD0");

        if (RunHartTransaction(channel, modem, pollAddr, true, cmd0Out) == 0u)
        {
            
            continue;
        }

        if (!cmd0Out->valid || !cmd0Out->checksumOk)
        {
            
            continue;
        }

        if (cmd0Out->command != HARTCOMMAND_ZERO)
        {
            
            continue;
        }

        

        return true;
    }

    return false;
}



/*******************************************************************************
* HART command coverage table
*******************************************************************************/
static const HartCommandInfo_t g_HartCommandTable[] =
{
    { HARTCOMMAND_ZERO,        "CMD0_READ_UNIQUE_ID",                TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_THREE,       "CMD3_READ_DYNAMIC_VARS",             TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_SIX,         "CMD6_WRITE_POLLING_ADDRESS",         TRUE,  FALSE, TRUE  },
    { HARTCOMMAND_NINE,        "CMD9_READ_DEVICE_VARIABLE_STATUS",   TRUE,  FALSE, FALSE },
    { HARTCOMMAND_TWELVE,      "CMD12_READ_MESSAGE",                 TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_THIRTEEN,    "CMD13_READ_TAG_DESCRIPTOR_DATE",     TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_FOURTEEN,    "CMD14_READ_PV_TRANSDUCER_INFO",      TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_FIFTEEN,     "CMD15_READ_DEVICE_INFO",             TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_SIXTEEN,     "CMD16_READ_FINAL_ASSEMBLY",          TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_TWENTY,      "CMD20_READ_LONG_TAG",                TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_THIRTYTHREE, "CMD33_READ_DEVICE_VARIABLES",        TRUE,  FALSE, FALSE },
    { HARTCOMMAND_THIRTYEIGHT, "CMD38_RESET_CONFIG_CHANGED",         TRUE,  FALSE, TRUE  },
    { HARTCOMMAND_FOURTYEIGHT,  "CMD48_READ_ADDITIONAL_STATUS",       TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_FIFTY,       "CMD50_READ_DYNAMIC_ASSOCIATION",     TRUE,  TRUE,  FALSE },
    { HARTCOMMAND_FIFTYNINE,   "CMD59_SET_RESPONSE_PREAMBLES",       TRUE,  TRUE,  TRUE  },
    { HARTCOMMAND_HUNDREDNINE, "CMD109_DISABLE_BURST_MODE",          TRUE,  FALSE, TRUE  }
};

/*******************************************************************************
* Public utility
*******************************************************************************/
VOID HartStack_Reset(VOID)
{
    for (UINT8 modem = 0u; modem < UART_COUNT; modem++)
    {
        ResetUartAndHartModem(modem);
    }
}

/*******************************************************************************
* Public wrappers
*******************************************************************************/
VOID HartStack_IdleWait(UINT32 loops)
{
    IdleWait(loops);
}

BOOL HartStack_SelfCheck(VOID)
{
    return SelfCheck();
}

VOID HartStack_SetShortRequest(UINT8 command, UINT8 pollAddr, const UINT8 *data, UINT8 dataLen, const char *label)
{
    SetShortRequest(command, pollAddr, data, dataLen, label);
}

VOID HartStack_SetLongRequest(UINT8 command, const UINT8 longAddr[HART_LONGADDR_LENGTH], const UINT8 *data, UINT8 dataLen, const char *label)
{
    SetLongRequest(command, longAddr, data, dataLen, label);
}

UINT32 HartStack_RunTransaction(UINT8 channel, UINT8 modem, UINT8 pollAddr, BOOL gpwr, HartParsedResponse_t *parsedOut)
{
    return RunHartTransaction(channel, modem, pollAddr, gpwr, parsedOut);
}

BOOL HartStack_RunLongCommand(UINT8 channel,
                              UINT8 modem,
                              UINT8 pollAddr,
                              const UINT8 longAddr[5],
                              UINT8 command,
                              const UINT8 *data,
                              UINT8 dataLen,
                              const char *label,
                              HartParsedResponse_t *parsedOut)
{
    HartStack_SetLongRequest(command, longAddr, data, dataLen, label);

    if (HartStack_RunTransaction(channel, modem, pollAddr, true, parsedOut) == 0u)
    {
        return false;
    }

    return ((parsedOut != NULL) && parsedOut->valid && parsedOut->checksumOk);
}

const HartCommandInfo_t *HartStack_GetCommandTable(UINT8 *countOut)
{
    if (countOut != NULL)
    {
        *countOut = (UINT8)(sizeof(g_HartCommandTable) / sizeof(g_HartCommandTable[0]));
    }

    return g_HartCommandTable;
}

BOOL HartStack_GetCleanCmd0(UINT8 channel, UINT8 modem, UINT8 pollAddr, HartParsedResponse_t *cmd0Out)
{
    return GetCleanCmd0Response(channel, modem, pollAddr, cmd0Out);
}

BOOL HartStack_ExtractLongAddressFromCmd0(const HartParsedResponse_t *cmd0, UINT8 longAddr[HART_LONGADDR_LENGTH], UINT8 *respPreambles)
{
    return ExtractLongAddressFromCmd0(cmd0, longAddr, respPreambles);
}

BOOL HartStack_ParseHartResponse(const UINT8 *rx, UINT32 rxLen, HartParsedResponse_t *out)
{
    return ParseHartResponse(rx, rxLen, out);
}
