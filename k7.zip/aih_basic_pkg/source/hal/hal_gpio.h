/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_gpio.h                                                  *
*    Description : GPIO abstraction interface.                                 *
*                  Abstracts digital I/O pin access that was previously done   *
*                  via H8S port registers (P0-PG) or LPC17xx bitband macros.  *
*                                                                              *
*    Pin definitions will be provided later when RT1024 pin mapping is known.  *
*    For now, this defines the abstract interface and the logical signal names *
*    used by the application code.                                             *
*******************************************************************************/
#ifndef HAL_GPIO_H
#define HAL_GPIO_H

#include "hal_platform.h"
#include "datatype.h"

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
*                      LOGICAL SIGNAL NAMES                                    *
*  These are the application-level signals used by boxslot, diag, IOL, etc.   *
*  The H8S code used direct port bit references like RIP_n, DIP, CLR_RIP_n.   *
*  We abstract them here so the application code doesn't change.              *
*******************************************************************************/
typedef enum {
    /* Module status signals */
    HAL_PIN_RIP_n,          /**< Reset In Progress (active low)             */
    HAL_PIN_CLR_RIP_n,      /**< Clear RIP latch                           */
    HAL_PIN_DIP,            /**< Diagnostic In Progress                     */
    HAL_PIN_SET_DIP,        /**< Set DIP latch                             */

    /* Redundancy interface signals */
    HAL_PIN_BUPREQ_OUT,     /**< Backup request output to partner module    */
    HAL_PIN_BUPREQ_IN,      /**< Backup request input from partner module   */
    HAL_PIN_REDSWITCH,      /**< Redundancy switch input                   */
    HAL_PIN_BOTTOM,         /**< Module position (top/bottom slot)          */

    /* Watchdog */
    HAL_PIN_WDT_EN_n,       /**< Watchdog enable (active low)              */
    HAL_PIN_WDTRFS_n,       /**< Watchdog refresh strobe (active low)      */
    HAL_PIN_WDTODCLR_n,     /**< Watchdog timeout diagnostic clear (low)   */

    /* Status LED (direct to FPGA GPWR on RT1024, see hal_fpga.h) */
    HAL_PIN_STATUS_LED,     /**< Module status LED                         */

    /* IOLink */
    HAL_PIN_IOL_TX_EN,      /**< IOLink transmitter enable                 */
    HAL_PIN_TXREQ_n,        /**< IOL transmit request (active low)         */
    HAL_PIN_JABRES_n,       /**< Anti-jabber reset (active low)            */
    HAL_PIN_RCVSELA_n,      /**< Receiver select Channel A (active low)    */
    HAL_PIN_CLRGHL_n,       /**< Clear GHO latch interrupt (active low)    */
    HAL_PIN_GHOIRQ_n,       /**< GHO interrupt request input (active low)  */

    /* HART modem control */
    HAL_PIN_HART_RTS,       /**< HART modem request-to-send                */
    HAL_PIN_HART_CD,        /**< HART modem carrier detect                 */

    /* Diagnostic */
    HAL_PIN_DIAGFAIL_n,     /**< Diagnostic fail output (active low)       */
    HAL_PIN_REBOOT_n,       /**< Reboot request output (active low)        */

    /* Readback / DPA */
    HAL_PIN_RDBK_SEL0,      /**< Readback register select bit 0            */
    HAL_PIN_RDBK_SEL1,      /**< Readback register select bit 1            */
    HAL_PIN_RDBK_SEL2,      /**< Readback register select bit 2            */

    /* FPGA / CPLD interface */
    HAL_PIN_FPGA_DONE,      /**< FPGA configuration done                   */
    HAL_PIN_FPGA_IRQ,       /**< FPGA interrupt request                    */
    HAL_PIN_FPGA_PROGRAM_n, /**< FPGA program/erase (active low)           */
    HAL_PIN_FPGA_INIT_n,    /**< FPGA init status (active low input)       */

    /* ADC Mux Selection — direct GPIO (new in RT1024, HDD Table 56)       */
    /* These replace the FPGA-routed WIGLPVCR mux control for faster       */
    /* channel switching.  Can also serve as address bits A0:A6 for the     */
    /* mock parallel interface.                                             */
    HAL_PIN_MUXAD0,         /**< ADC mux select bit 0 / Address bit A0     */
    HAL_PIN_MUXAD1,         /**< ADC mux select bit 1 / Address bit A1     */
    HAL_PIN_ENBMX0,         /**< ADC mux enable 0 / Address bit A2         */
    HAL_PIN_ENBMX1,         /**< ADC mux enable 1 / Address bit A3         */
    HAL_PIN_ENBMX2,         /**< ADC mux enable 2 / Address bit A4         */
    HAL_PIN_ENBMX3,         /**< ADC mux enable 3 / Address bit A5         */
    HAL_PIN_ENBMX4,         /**< ADC mux enable 4 / Address bit A6         */

    HAL_PIN_COUNT            /**< Total number of logical pins              */
} HAL_PIN_ID;

typedef enum {
    HAL_PIN_DIR_INPUT  = 0,
    HAL_PIN_DIR_OUTPUT = 1
} HAL_PIN_DIR;

/*******************************************************************************
*                           GPIO API                                           *
*******************************************************************************/

/**
 * @brief Initialize all GPIO pins to their default directions and states.
 */
void hal_gpio_init(void);

/**
 * @brief Set a logical pin direction.
 */
void hal_gpio_set_direction(HAL_PIN_ID pin, HAL_PIN_DIR dir);

/**
 * @brief Write a logical output pin (1 = high, 0 = low).
 */
void hal_gpio_write(HAL_PIN_ID pin, UINT8 value);

/**
 * @brief Read a logical pin state (1 = high, 0 = low).
 */
UINT8 hal_gpio_read(HAL_PIN_ID pin);

/**
 * @brief Toggle a logical output pin.
 */
void hal_gpio_toggle(HAL_PIN_ID pin);

/*******************************************************************************
*  COMPATIBILITY MACROS                                                        *
*  These let existing code like "CLR_RIP_n = 0" compile with minimal changes. *
*  They expand to hal_gpio_write() / hal_gpio_read() calls.                   *
*******************************************************************************/

/* Read macros (used in conditionals like "if (RIP_n) ...") */
#define RIP_n           hal_gpio_read(HAL_PIN_RIP_n)
#define BUPREQ_IN       hal_gpio_read(HAL_PIN_BUPREQ_IN)
#define BOTTOM          hal_gpio_read(HAL_PIN_BOTTOM)
#define HART_CD         hal_gpio_read(HAL_PIN_HART_CD)
#define FPGA_DONE       hal_gpio_read(HAL_PIN_FPGA_DONE)

/* Note: Write macros like CLR_RIP_n = 0 cannot be done with C macros as lvalues.
 * Application code that writes these must be updated to use:
 *   hal_gpio_write(HAL_PIN_CLR_RIP_n, 0);
 * We define helper functions for the most common patterns instead. */

static inline void SetClrRipN(UINT8 val)   { hal_gpio_write(HAL_PIN_CLR_RIP_n, val); }
static inline void SetDip(UINT8 val)       { hal_gpio_write(HAL_PIN_SET_DIP, val); }
static inline void SetWdtEnN(UINT8 val)    { hal_gpio_write(HAL_PIN_WDT_EN_n, val); }
static inline void SetWdtRfsN(UINT8 val)   { hal_gpio_write(HAL_PIN_WDTRFS_n, val); }
static inline void SetStatusLed(UINT8 val) { hal_gpio_write(HAL_PIN_STATUS_LED, val); }
static inline void SetIolTxEn(UINT8 val)   { hal_gpio_write(HAL_PIN_IOL_TX_EN, val); }
static inline void SetBupreqOut(UINT8 val) { hal_gpio_write(HAL_PIN_BUPREQ_OUT, val); }

#ifdef __cplusplus
}
#endif

#endif /* HAL_GPIO_H */
