/*******************************************************************************
*    File Name   : hal_fpga.h
*    Description : Minimal RT1024 -> FPGA SPI register access map used by the
*                  HART module.
*
*    Cleanup note:
*      This header intentionally keeps only the FPGA/UART register constants and
*      helpers referenced by the current k5 HART path. Legacy HART protocol
*      constants remain in hart.h, so this file no longer redefines command/
*      delimiter/HARTCOMMAND names and no longer pollutes hart.cpp/hartstack.cpp
*      with duplicate macros.
*******************************************************************************/

#ifndef HAL_FPGA_H
#define HAL_FPGA_H

#include "datatype.h"

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
* FPGA common register map used by HART
*******************************************************************************/
#define FPGA_BRG_DLL                          ((UINT8)0x40u)
#define FPGA_BRG_DLM                          ((UINT8)0x41u)
#define FPGA_BRG_MUX                          ((UINT8)0x42u)

#define FPGA_IRQ_STATUS                       ((UINT8)0xC4u)
#define FPGA_VERSION                          ((UINT8)0xC5u)
#define FPGA_REVISION                         ((UINT8)0xC6u)
#define FPGA_MODNUM                           ((UINT8)0xC8u)
#define FPGA_MAR                              ((UINT8)0xCDu)
#define FPGA_MER                              ((UINT8)0xCEu)
#define FPGA_GPWR                             ((UINT8)0xCFu)

/* Proven/current HART mux defaults used by hartstack.cpp. */
#define HART_DEFAULT_MAR_CH1_M0               ((UINT16)0xC840u)
#define HART_DEFAULT_MER_NONE                 ((UINT8)0x00u)

/*******************************************************************************
* FPGA UART16550 register map used by HART
*******************************************************************************/
#define UART_COUNT                            ((UINT8)4u)
#define UART_STRIDE                           ((UINT8)0x10u)

#define UART0_WRITE_BASE                      ((UINT8)0x00u)
#define UART1_WRITE_BASE                      ((UINT8)0x10u)
#define UART2_WRITE_BASE                      ((UINT8)0x20u)
#define UART3_WRITE_BASE                      ((UINT8)0x30u)

#define UART0_READ_BASE                       ((UINT8)0x80u)
#define UART1_READ_BASE                       ((UINT8)0x90u)
#define UART2_READ_BASE                       ((UINT8)0xA0u)
#define UART3_READ_BASE                       ((UINT8)0xB0u)

/* Backward-compatible base names used by the current HART stack file. */
#define UART0_BASE                            UART0_READ_BASE
#define UART1_BASE                            UART1_READ_BASE
#define UART2_BASE                            UART2_READ_BASE
#define UART3_BASE                            UART3_READ_BASE

#define UART_READ_BASE(modem)                 ((UINT8)(UART0_READ_BASE  + ((UINT8)((modem) & 0x03u) * UART_STRIDE)))
#define UART_WRITE_BASE(modem)                ((UINT8)(UART0_WRITE_BASE + ((UINT8)((modem) & 0x03u) * UART_STRIDE)))

#define UART0_RESET                           ((UINT8)0x08u)
#define UART1_RESET                           ((UINT8)0x18u)
#define UART2_RESET                           ((UINT8)0x28u)
#define UART3_RESET                           ((UINT8)0x38u)

#define UART_RBR_THR                          ((UINT8)0x00u)
#define UART_IER                              ((UINT8)0x01u)
#define UART_IIR_FCR                          ((UINT8)0x02u)
#define UART_LCR                              ((UINT8)0x03u)
#define UART_MCR                              ((UINT8)0x04u)
#define UART_LSR                              ((UINT8)0x05u)
#define UART_MSR                              ((UINT8)0x06u)
#define UART_SCR                              ((UINT8)0x07u)

#define UART_LSR_DR                           ((UINT8)0x01u)
#define UART_LSR_OE                           ((UINT8)0x02u)
#define UART_LSR_PE                           ((UINT8)0x04u)
#define UART_LSR_FE                           ((UINT8)0x08u)
#define UART_LSR_BI                           ((UINT8)0x10u)
#define UART_LSR_THRE                         ((UINT8)0x20u)
#define UART_LSR_TEMT                         ((UINT8)0x40u)

#define UART_MCR_RTS                          ((UINT8)0x02u)
#define UART_MCR_LOOPBACK                     ((UINT8)0x10u)

#define UART_MSR_DCD                          ((UINT8)0x80u)
#define UART_MSR_RI                           ((UINT8)0x40u)
#define UART_MSR_DSR                          ((UINT8)0x20u)
#define UART_MSR_CTS                          ((UINT8)0x10u)

#define UART_LCR_8O1_ODD_PARITY               ((UINT8)0x0Bu)

#define HART_IER_RX_MODEM_STATUS              ((UINT8)0x09u)
#define HART_IER_TX_EMPTY                     ((UINT8)0x02u)

/* Minimal HART helper constants used by the RT1024 transport adapter.
 * The full protocol enum/table remains in hart.h/hartdb.hpp. */
#define HART_DELIMITER_SHORT_MASTER_REQ       ((UINT8)0x02u)
#define HART_CMD0_ID_RESPONSE_SIZE            ((UINT8)12u)

/*******************************************************************************
* Low-level FPGA access functions implemented by hal_fpga_spi.c
*******************************************************************************/
void   hal_fpga_init(void);
UINT16 hal_fpga_read(UINT8 addr);
void   hal_fpga_write(UINT8 addr, UINT16 data);

/*******************************************************************************
* Small helpers used by hart.cpp/hartstack.cpp
*******************************************************************************/
static inline UINT8 hal_fpga_read8(UINT8 addr)
{
    return (UINT8)((hal_fpga_read(addr) >> 8) & 0xFFu);
}

static inline void hal_fpga_write8(UINT8 addr, UINT8 data)
{
    hal_fpga_write(addr, (UINT16)((UINT16)data << 8));
}

static inline UINT8 hal_fpga_uart_read(UINT8 modem, UINT8 reg)
{
    return hal_fpga_read8((UINT8)(UART_READ_BASE(modem) + reg));
}

static inline void hal_fpga_uart_write(UINT8 modem, UINT8 reg, UINT8 data)
{
    hal_fpga_write8((UINT8)(UART_WRITE_BASE(modem) + reg), data);
}

static inline void hal_fpga_hart_mux_set16(UINT16 muxAddr)
{
    hal_fpga_write(FPGA_MAR, muxAddr);
}

static inline void hal_fpga_hart_mux_enable(UINT8 muxEnableMask)
{
    hal_fpga_write8(FPGA_MER, muxEnableMask);
}

static inline UINT16 hal_fpga_hart_mux_get_addr16(void)
{
    return hal_fpga_read(FPGA_MAR);
}

static inline UINT8 hal_fpga_hart_mux_get_enable(void)
{
    return hal_fpga_read8(FPGA_MER);
}

static inline void HART_UART_InitHART16550(UINT8 uart)
{
    hal_fpga_uart_write(uart, UART_IER, 0x00u);
    hal_fpga_uart_write(uart, UART_LCR, UART_LCR_8O1_ODD_PARITY);
    hal_fpga_uart_write(uart, UART_IIR_FCR, 0xC1u);
    hal_fpga_uart_write(uart, UART_SCR, 0xDBu);
}

#ifdef __cplusplus
}
#endif

#endif /* HAL_FPGA_H */
