/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_gpio.c                                                  *
*    Description : GPIO abstraction implementation for iMXRT1024.              *
*                  Maps HAL_PIN_ID logical signals to physical GPIO pads.      *
*                                                                              *
*    Pin assignments are derived from epicio_aih.mex (MCUXpresso Config).      *
*    This file is compiled ONLY for RT1024_BUILD.                              *
*******************************************************************************/
#include "hal_platform.h"

#if defined(RT1024_BUILD)

#include "hal_gpio.h"
#include "fsl_gpio.h"
#include "fsl_iomuxc.h"
#include "fsl_clock.h"

/*******************************************************************************
*  PIN MAP TABLE                                                               *
*  Each entry maps a HAL_PIN_ID to its physical GPIO port, pin number,         *
*  default direction, and default output value.                                *
*                                                                              *
*  From epicio_aih.mex pin_label assignments:                                  *
*    GPIO_AD_B0_xx → GPIO1, pin = xx                                          *
*    GPIO_AD_B1_xx → GPIO1, pin = 16 + xx                                     *
*    GPIO_EMC_xx   → GPIO2 (for xx=0..31), GPIO3 (for xx=32..41 → pin=xx-32) *
*                    Actually EMC_xx<32 → GPIO4, pin=xx on some RT1024 banks.  *
*                    RT1024 mapping: GPIO_EMC_00..31 → GPIO4_IO00..31          *
*                                   GPIO_EMC_32..41 → GPIO3_IO18..27          *
*                    But with iomuxc alt5: GPIO_EMC_26 → GPIO2_IO26            *
*                                          GPIO_EMC_20 → GPIO2_IO20           *
*                    (The IOMUXC defines confirm the GPIO instance.)            *
*******************************************************************************/

typedef struct {
    GPIO_Type  *port;       /* GPIO1, GPIO2, etc. */
    uint32_t    pin;        /* Pin number within port */
    uint8_t     direction;  /* 0=input, 1=output */
    uint8_t     initValue;  /* Initial output value (for outputs) */
} gpio_pin_map_t;

/* Default: unmapped pins point to GPIO1 pin 0 with input direction.
 * Only IOL-critical and actively-used pins are mapped below for now. */
#define UNMAP  { (GPIO_Type *)0, 0, 0, 0 }

static const gpio_pin_map_t s_pinMap[HAL_PIN_COUNT] = {
    /* HAL_PIN_RIP_n          */ { GPIO2, 23, 0, 0 },  /* GPIO_EMC_23, input */
    /* HAL_PIN_CLR_RIP_n      */ { GPIO1, 13, 1, 1 },  /* GPIO_AD_B0_13, output, default high (inactive) */
    /* HAL_PIN_DIP             */ UNMAP,                /* TODO: map when needed */
    /* HAL_PIN_SET_DIP         */ UNMAP,                /* TODO: map when needed */
    /* HAL_PIN_BUPREQ_OUT     */ { GPIO1, 27, 1, 1 },  /* GPIO_AD_B1_11, output, default high */
    /* HAL_PIN_BUPREQ_IN      */ { GPIO1, 28, 0, 0 },  /* GPIO_AD_B1_12, input */
    /* HAL_PIN_REDSWITCH      */ { GPIO2, 21, 0, 0 },  /* GPIO_EMC_21, input */
    /* HAL_PIN_BOTTOM         */ { GPIO2, 20, 0, 0 },  /* GPIO_EMC_20, input */
    /* HAL_PIN_WDT_EN_n       */ { GPIO1, 24, 1, 1 },  /* GPIO_AD_B1_08, output, default high (disabled) */
    /* HAL_PIN_WDTRFS_n       */ { GPIO1, 11, 1, 1 },  /* GPIO_AD_B0_11, output, default high */
    /* HAL_PIN_WDTODCLR_n     */ { GPIO1, 12, 1, 1 },  /* GPIO_AD_B0_12, output, default high */
    /* HAL_PIN_STATUS_LED     */ UNMAP,                 /* LED driven via FPGA GPWR, not direct GPIO */
    /* HAL_PIN_IOL_TX_EN      */ { GPIO2, 26, 1, 1 },  /* GPIO_EMC_26, output, default high (driver OFF) */
    /* HAL_PIN_TXREQ_n        */ { GPIO1, 22, 1, 1 },  /* GPIO_AD_B1_06, output, default high (inactive) */
    /* HAL_PIN_JABRES_n       */ { GPIO1, 13, 1, 1 },  /* GPIO_AD_B0_13, output, default high */
    /* HAL_PIN_RCVSELA_n      */ { GPIO1, 23, 1, 1 },  /* GPIO_AD_B1_07, output, default high */
    /* HAL_PIN_CLRGHL_n       */ { GPIO3, 16, 1, 1 },  /* GPIO_SD_B0_03, output, default high (inactive) */
    /* HAL_PIN_GHOIRQ_n       */ { GPIO3, 17, 0, 0 },  /* GPIO_SD_B0_04, input */
    /* HAL_PIN_HART_RTS       */ UNMAP,                 /* HART via FPGA—not direct GPIO */
    /* HAL_PIN_HART_CD        */ UNMAP,                 /* HART via FPGA—not direct GPIO */
    /* HAL_PIN_DIAGFAIL_n     */ { GPIO1, 26, 1, 1 },  /* GPIO_AD_B1_10, output, default high */
    /* HAL_PIN_REBOOT_n       */ { GPIO1, 15, 1, 1 },  /* GPIO_AD_B0_15, output, default high */
    /* HAL_PIN_RDBK_SEL0      */ UNMAP,
    /* HAL_PIN_RDBK_SEL1      */ UNMAP,
    /* HAL_PIN_RDBK_SEL2      */ UNMAP,
    /* HAL_PIN_FPGA_DONE      */ { GPIO2, 22, 0, 0 },  /* GPIO_EMC_22, input */
    /* HAL_PIN_FPGA_IRQ       */ { GPIO3, 18, 0, 0 },  /* GPIO_SD_B0_05, input */
    /* HAL_PIN_FPGA_PROGRAM_n */ { GPIO1, 30, 1, 1 },  /* GPIO_AD_B1_14, output, default high */
    /* HAL_PIN_FPGA_INIT_n    */ { GPIO1, 31, 0, 0 },  /* GPIO_AD_B1_15, input */
    /* HAL_PIN_MUXAD0         */ { GPIO3,  8, 1, 0 },  /* GPIO_EMC_40 → GPIO3_IO08, output */
    /* HAL_PIN_MUXAD1         */ { GPIO3,  9, 1, 0 },  /* GPIO_EMC_41 → GPIO3_IO09, output */
    /* HAL_PIN_ENBMX0         */ { GPIO2, 15, 1, 0 },  /* GPIO_EMC_15, output */
    /* HAL_PIN_ENBMX1         */ { GPIO2, 16, 1, 0 },  /* GPIO_EMC_16, output */
    /* HAL_PIN_ENBMX2         */ { GPIO2, 17, 1, 0 },  /* GPIO_EMC_17, output */
    /* HAL_PIN_ENBMX3         */ { GPIO2, 18, 1, 0 },  /* GPIO_EMC_18, output */
    /* HAL_PIN_ENBMX4         */ { GPIO2, 19, 1, 0 },  /* GPIO_EMC_19, output */
};

/*******************************************************************************
*                       hal_gpio_init                                          *
*                       =============                                          *
* PURPOSE:                                                                     *
*    Configure all mapped GPIO pins to their default direction and value.      *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    IOMUXC mux selection (ALT5) is assumed done in pin_mux.c.                *
*******************************************************************************/
void hal_gpio_init(void)
{
    /* Enable GPIO clock gates */
    CLOCK_EnableClock(kCLOCK_Gpio1);
    CLOCK_EnableClock(kCLOCK_Gpio2);
    CLOCK_EnableClock(kCLOCK_Gpio3);

    gpio_pin_config_t cfg;

    for (unsigned i = 0; i < HAL_PIN_COUNT; i++) {
        const gpio_pin_map_t *m = &s_pinMap[i];
        if (m->port == NULL) continue;  /* skip unmapped */

        cfg.direction     = m->direction ? kGPIO_DigitalOutput : kGPIO_DigitalInput;
        cfg.outputLogic   = m->initValue;
        cfg.interruptMode = kGPIO_NoIntmode;

        GPIO_PinInit(m->port, m->pin, &cfg);
    }
}

/*******************************************************************************
*                       hal_gpio_set_direction                                 *
*                       ======================                                 *
* PURPOSE:                                                                     *
*    Change the direction (input/output) of a single GPIO pin.                 *
* ARGUMENTS:                                                                   *
*    pin : HAL_PIN_ID identifying the pin.                                     *
*    dir : HAL_PIN_DIR_INPUT or HAL_PIN_DIR_OUTPUT.                            *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_gpio_set_direction(HAL_PIN_ID pin, HAL_PIN_DIR dir)
{
    if ((unsigned)pin >= HAL_PIN_COUNT) return;
    const gpio_pin_map_t *m = &s_pinMap[pin];
    if (m->port == NULL) return;

    gpio_pin_config_t cfg;
    cfg.direction     = (dir == HAL_PIN_DIR_OUTPUT) ? kGPIO_DigitalOutput : kGPIO_DigitalInput;
    cfg.outputLogic   = 0;
    cfg.interruptMode = kGPIO_NoIntmode;

    GPIO_PinInit(m->port, m->pin, &cfg);
}

/*******************************************************************************
*                       hal_gpio_write                                         *
*                       ==============                                         *
* PURPOSE:                                                                     *
*    Write a logic level (0 or 1) to a mapped GPIO output pin.                *
* ARGUMENTS:                                                                   *
*    pin   : HAL_PIN_ID identifying the pin.                                   *
*    value : 0 = low, non-zero = high.                                         *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_gpio_write(HAL_PIN_ID pin, UINT8 value)
{
    if ((unsigned)pin >= HAL_PIN_COUNT) return;
    const gpio_pin_map_t *m = &s_pinMap[pin];
    if (m->port == NULL) return;

    GPIO_PinWrite(m->port, m->pin, value ? 1 : 0);
}

/*******************************************************************************
*                       hal_gpio_read                                          *
*                       =============                                          *
* PURPOSE:                                                                     *
*    Read the current logic level of a mapped GPIO pin.                        *
* ARGUMENTS:                                                                   *
*    pin : HAL_PIN_ID identifying the pin.                                     *
* RETURN:                                                                      *
*    UINT8 (0 or 1).                                                           *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
UINT8 hal_gpio_read(HAL_PIN_ID pin)
{
    if ((unsigned)pin >= HAL_PIN_COUNT) return 0;
    const gpio_pin_map_t *m = &s_pinMap[pin];
    if (m->port == NULL) return 0;

    return (UINT8)GPIO_PinRead(m->port, m->pin);
}

/*******************************************************************************
*                       hal_gpio_toggle                                        *
*                       ===============                                        *
* PURPOSE:                                                                     *
*    Toggle the current output level of a mapped GPIO pin.                     *
* ARGUMENTS:                                                                   *
*    pin : HAL_PIN_ID identifying the pin.                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_gpio_toggle(HAL_PIN_ID pin)
{
    if ((unsigned)pin >= HAL_PIN_COUNT) return;
    const gpio_pin_map_t *m = &s_pinMap[pin];
    if (m->port == NULL) return;

    /* Read current output and invert */
    uint32_t current = (m->port->DR >> m->pin) & 1u;
    GPIO_PinWrite(m->port, m->pin, current ? 0 : 1);
}

#endif /* RT1024_BUILD */
