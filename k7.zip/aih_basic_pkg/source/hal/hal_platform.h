/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_platform.h                                              *
*    Description : Platform detection and build configuration.                 *
*                  Defines exactly ONE of:                                      *
*                    RT1024_BUILD  - iMXRT1024 MCUXpresso target               *
*                    QEMU_BUILD    - MPS2-AN500 QEMU emulation target          *
*                    UNIT_TEST_BUILD - Host PC GoogleTest target                *
*******************************************************************************/
#ifndef HAL_PLATFORM_H
#define HAL_PLATFORM_H

/*******************************************************************************
*  Platform detection — only one should be active at build time.               *
*  The build system (CMake, Makefile, MCUXpresso) defines one of these.        *
*******************************************************************************/
#if defined(UNIT_TEST_BUILD)
    /* Tier 1: GoogleTest on host PC — no hardware at all */
#elif defined(QEMU_BUILD)
    /* Tier 2: MPS2-AN500 QEMU emulation — Cortex-M7, CMSDK peripherals */
#elif defined(RT1024_BUILD) || defined(CPU_MIMXRT1024DAG5A) || defined(CPU_MIMXRT1024DAG5B)
    /* Tier 3: Real hardware — NXP iMXRT1024 */
    #ifndef RT1024_BUILD
    #define RT1024_BUILD 1
    #endif
    /* Enable real SPI drivers for FPGA, ADC, EEPROM */
    #ifndef HAL_FPGA_SPI_ENABLED
    #define HAL_FPGA_SPI_ENABLED 1
    #endif
#else
    /* Default to RT1024 if building from MCUXpresso which defines the CPU */
    #define RT1024_BUILD 1
    #define HAL_FPGA_SPI_ENABLED 1
#endif

/* Module type — AIH only for this repository (no conditional compilation) */
#define IOMTYPE_AIH 1

/* High-End Kernel — AIH uses CPLD, FPGA, external SRAM */
#define HEK 1

/* Not low-cost (AIH with HART is full-featured) */
#define LOWCOST 0

#define NOP  __asm volatile("nop")

/**********************************************************************************
*  UART ASSIGNMENT — Prototype Board Configuration                                *
*                                                                                 *
*  Define AIH_PROTO_V1 to select the CURRENT prototype board wiring:             *
*    AIH_PROTO_V1 defined  (Proto1):  IOLink = LPUART1, DebugPort = LPUART2      *
*    HLAI_PROTO_V1 undefined (Proto1b): IOLink = LPUART2, DebugPort = LPUART1     *
*                            (Proto1b matches RT1024 serial downloader on LPUART1)*
*                                                                                 *
*  The Proto1b board revision will NOT define AIH_PROTO_V1.                      *
*  Set this via build system: -DAIH_PROTO_V1=1                                   *
***********************************************************************************/
#if !defined(AIH_PROTO_V1)
    /* Default: uncomment below for current prototype, or pass -DAIH_PROTO_V1=1 */
    #define AIH_PROTO_V1 0 // PROTO 2

#endif

#endif /* HAL_PLATFORM_H */
