/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_uart.c                                                  *
*    Description : UART abstraction implementation for iMXRT1024.              *
*                  Wraps NXP fsl_lpuart driver for IOLink and Debug channels.  *
*                                                                              *
*    This file is compiled ONLY for RT1024_BUILD.                              *
*                                                                              *
*    IOLink UART configuration:                                                *
*      - 9-bit data mode (address-mark framing)                                *
*      - 750000 baud (Honeywell proprietary IOLink)                            *
*      - No parity (9th bit used as address/data marker)                       *
*      - 1 stop bit                                                            *
*      - LPUART1 on AIH_PROTO_V1, LPUART2 on next revision                    *
*******************************************************************************/
#include "hal_platform.h"

#if defined(RT1024_BUILD)

#include "hal_uart.h"
#include "hal_timer.h"      /* HAL_IRQ_PRIO_IOL_UART, HAL_IRQ_PRIO_DBG_UART */
#include "fsl_lpuart.h"
#include "fsl_clock.h"

/*******************************************************************************
*                       INTERNAL STATE                                         *
*******************************************************************************/

/** Resolve logical UART ID to physical LPUART base pointer */
static LPUART_Type * const s_uartBase[HAL_UART_COUNT] = {
    [HAL_UART_IOL]   = HAL_UART_IOL_BASE,
    [HAL_UART_DEBUG] = HAL_UART_DBG_BASE,
    [HAL_UART_HART]  = NULL   /* HART uses FPGA SPI, not an LPUART */
};

/** Resolve logical UART ID to NVIC IRQ number */
static const IRQn_Type s_uartIRQn[HAL_UART_COUNT] = {
    [HAL_UART_IOL]   = HAL_UART_IOL_IRQn,
    [HAL_UART_DEBUG] = HAL_UART_DBG_IRQn,
    [HAL_UART_HART]  = (IRQn_Type)0
};

/** ISR callback table: one per (channel, irq_type) */
static hal_uart_isr_t s_isrCallbacks[HAL_UART_COUNT][4];

/** Map HAL_UART_IRQ_TYPE to NXP SDK interrupt enable mask */
static const uint32_t s_irqMask[] = {
    [HAL_UART_IRQ_RX_DATA]  = (uint32_t)kLPUART_RxDataRegFullInterruptEnable,
    [HAL_UART_IRQ_TX_EMPTY] = (uint32_t)kLPUART_TxDataRegEmptyInterruptEnable,
    [HAL_UART_IRQ_TX_DONE]  = (uint32_t)kLPUART_TransmissionCompleteInterruptEnable,
    [HAL_UART_IRQ_RX_ERROR] = (uint32_t)(kLPUART_RxOverrunInterruptEnable |
                                          kLPUART_FramingErrorInterruptEnable |
                                          kLPUART_NoiseErrorInterruptEnable)
};

/*******************************************************************************
*                       hal_uart_get_src_clock                                 *
*                       ======================                                 *
* PURPOSE:                                                                     *
*    Return the LPUART source clock frequency.                                 *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    uint32_t clock frequency in Hz.                                           *
* NOTES:                                                                       *
*    UART_CLK_ROOT configured to 80 MHz in clock_config.c.                    *
*******************************************************************************/
static uint32_t hal_uart_get_src_clock(void)
{
    uint32_t freq;

    /* To make it simple, we assume default PLL and divider settings, and the only variable
       from application is use PLL3 source or OSC source */
    if (CLOCK_GetMux(kCLOCK_UartMux) == 0) /* PLL3 div6 80M */
    {
        freq = (CLOCK_GetPllFreq(kCLOCK_PllUsb1) / 6U) / (CLOCK_GetDiv(kCLOCK_UartDiv) + 1U);
    }
    else
    {
        freq = CLOCK_GetOscFreq() / (CLOCK_GetDiv(kCLOCK_UartDiv) + 1U);
    }

    return freq;

    /* UART_CLK_ROOT configured to 80 MHz in clock_config.c */
    // return CLOCK_GetFreq(kCLOCK_UartClkRoot);
}

/*******************************************************************************
*                       hal_uart_init                                          *
*                       =============                                          *
* PURPOSE:                                                                     *
*    Initialise a physical LPUART peripheral with the given configuration.     *
* ARGUMENTS:                                                                   *
*    id     : logical UART channel (HAL_UART_IOL, HAL_UART_DEBUG, etc.).       *
*    config : pointer to baud/parity/stop-bit configuration struct.            *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    IOLink: 750000 baud, 8N1 + 9-bit mode for address-mark framing.          *
*******************************************************************************/
void hal_uart_init(HAL_UART_ID id, const hal_uart_config_t *config)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    /* Enable LPUART clock gate (in case clock_config left it gated) */
    if (base == LPUART1) {
        CLOCK_EnableClock(kCLOCK_Lpuart1);
    } else if (base == LPUART2) {
        CLOCK_EnableClock(kCLOCK_Lpuart2);
    } else if (base == LPUART3) {
        CLOCK_EnableClock(kCLOCK_Lpuart3);
    }

    lpuart_config_t lpuartCfg;
    LPUART_GetDefaultConfig(&lpuartCfg);

    lpuartCfg.baudRate_Bps = config->baudrate;
    lpuartCfg.dataBitsCount = kLPUART_EightDataBits;
    lpuartCfg.stopBitCount  = (config->stop_bits == 2)
                                ? kLPUART_TwoStopBit
                                : kLPUART_OneStopBit;

    switch (config->parity) {
        case 1:  lpuartCfg.parityMode = kLPUART_ParityOdd;      break;
        case 2:  lpuartCfg.parityMode = kLPUART_ParityEven;     break;
        default: lpuartCfg.parityMode = kLPUART_ParityDisabled;  break;
    }

    /* Start with TX and RX disabled — caller enables when ready */
    lpuartCfg.enableTx = false;
    lpuartCfg.enableRx = false;

    LPUART_Init(base, &lpuartCfg, hal_uart_get_src_clock());

    /* IOLink channel: enable 9-bit mode for address-mark framing.
     * The 9th bit (T9/R9) is controlled per-byte via IOL_TxAlert/IOL_RxAlert
     * in commonelectronics.h, which calls hal_uart_set_tx_9bit/hal_uart_get_rx_9bit. */
    if (id == HAL_UART_IOL) {
        LPUART_Enable9bitMode(base, true);
    }

    /* Enable NVIC for this LPUART.
     * IOL UART gets high ARM priority (low number) so only LVLPRI_HIGHEST
     * can mask it via BASEPRI.  Debug UART gets low priority. */
    NVIC_SetPriority(s_uartIRQn[id],
        (id == HAL_UART_IOL) ? HAL_IRQ_PRIO_IOL_UART : HAL_IRQ_PRIO_DBG_UART);
    EnableIRQ(s_uartIRQn[id]);
}

/*******************************************************************************
*                       hal_uart_tx_enable / hal_uart_rx_enable                *
*                       ==========================================             *
* PURPOSE:                                                                     *
*    Enable or disable the transmitter or receiver on the given UART channel.  *
* ARGUMENTS:                                                                   *
*    id     : logical UART channel.                                            *
*    enable : TRUE to enable, FALSE to disable.                                *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_uart_tx_enable(HAL_UART_ID id, BOOL enable)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    if (enable) {
        base->CTRL |= LPUART_CTRL_TE_MASK;
    } else {
        base->CTRL &= ~LPUART_CTRL_TE_MASK;
    }
}

void hal_uart_rx_enable(HAL_UART_ID id, BOOL enable)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    if (enable) {
        base->CTRL |= LPUART_CTRL_RE_MASK;
    } else {
        base->CTRL &= ~LPUART_CTRL_RE_MASK;
    }
}

/*******************************************************************************
*                       hal_uart_write_byte / hal_uart_read_byte               *
*                       =======================================                *
* PURPOSE:                                                                     *
*    Write one byte to / read one byte from the given UART channel.            *
* ARGUMENTS:                                                                   *
*    id   : logical UART channel.                                              *
*    data : (write only) byte to transmit.                                     *
* RETURN:                                                                      *
*    (read only) received byte, or 0 if channel invalid.                       *
* NOTES:                                                                       *
*    In 9-bit mode, T8 is set separately via hal_uart_set_tx_9bit().          *
*******************************************************************************/
void hal_uart_write_byte(HAL_UART_ID id, UINT8 data)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    /* In 9-bit mode the T8 bit in DATA register is set separately via
     * hal_uart_set_tx_9bit() before calling this function. Writing to
     * DATA[R7:R0] triggers transmission including the existing T8 state. */
    LPUART_WriteByte(base, data);
}

UINT8 hal_uart_read_byte(HAL_UART_ID id)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return 0;

    return LPUART_ReadByte(base);
}

void hal_uart_write_byte9(HAL_UART_ID id, UINT8 data, UINT8 bit9) {

	LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    while ((base->STAT & LPUART_STAT_TDRE_MASK) == 0U) {
    }

    base->DATA = ((uint32_t)data & 0xFFU) | ((bit9 ? 1UL : 0UL) << LPUART_DATA_R8T8_SHIFT);
}

uint16_t hal_uart_read_byte9(HAL_UART_ID id) {

    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return 0;

    /* Returns bits [8:0] of the DATA register:
     *   bit  8   : 9th received bit (address/data marker in 9-bit mode)
     *   bits 7:0 : 8 data bits
     * Bits [15:11] of DATA hold status flags (NOISY, PARITYE, FRETSC, RXEMPT, IDLINE).
     * We mask to [15:0] so callers can inspect error flags if needed. */
    return (uint16_t)(base->DATA & 0xFFFFU);
}

/*******************************************************************************
*                       hal_uart_tx_ready / hal_uart_rx_ready                  *
*                       =====================================                  *
* PURPOSE:                                                                     *
*    Check whether the TX data register is empty / RX data register is full.   *
* ARGUMENTS:                                                                   *
*    id : logical UART channel.                                                *
* RETURN:                                                                      *
*    TRUE if ready, FALSE otherwise.                                           *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
BOOL hal_uart_tx_ready(HAL_UART_ID id)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return FALSE;

    return (LPUART_GetStatusFlags(base) & (uint32_t)kLPUART_TxDataRegEmptyFlag) ? TRUE : FALSE;
}

BOOL hal_uart_tx_complete(HAL_UART_ID id)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return FALSE;

    return (LPUART_GetStatusFlags(base) & (uint32_t)kLPUART_TransmissionCompleteFlag) ? TRUE : FALSE;
}

BOOL hal_uart_rx_ready(HAL_UART_ID id)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return FALSE;

    return (LPUART_GetStatusFlags(base) & (uint32_t)kLPUART_RxDataRegFullFlag) ? TRUE : FALSE;
}

/*******************************************************************************
*                       hal_uart_register_isr                                  *
*                       =====================                                  *
* PURPOSE:                                                                     *
*    Register an ISR callback for a specific interrupt type on a UART channel. *
* ARGUMENTS:                                                                   *
*    id       : logical UART channel.                                          *
*    irq_type : HAL_UART_IRQ_TYPE (RX_DATA, TX_EMPTY, TX_DONE, RX_ERROR).     *
*    callback : function pointer to call when the interrupt fires.             *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_uart_register_isr(HAL_UART_ID id, HAL_UART_IRQ_TYPE irq_type,
                           hal_uart_isr_t callback)
{
    if ((unsigned)id < HAL_UART_COUNT && (unsigned)irq_type < 4) {
        s_isrCallbacks[id][irq_type] = callback;
    }
}

/*******************************************************************************
*                       hal_uart_irq_enable                                    *
*                       ===================                                    *
* PURPOSE:                                                                     *
*    Enable or disable a specific interrupt type on a UART channel.            *
* ARGUMENTS:                                                                   *
*    id       : logical UART channel.                                          *
*    irq_type : HAL_UART_IRQ_TYPE to enable/disable.                           *
*    enable   : TRUE to enable, FALSE to disable.                              *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_uart_irq_enable(HAL_UART_ID id, HAL_UART_IRQ_TYPE irq_type, BOOL enable)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    if (enable) {
        LPUART_EnableInterrupts(base, s_irqMask[irq_type]);
    } else {
        LPUART_DisableInterrupts(base, s_irqMask[irq_type]);
    }
}

/*******************************************************************************
*                       hal_uart_clear_flags                                   *
*                       =====================                                  *
* PURPOSE:                                                                     *
*    Clear selected flags on a UART channel.                                   *
* ARGUMENTS:                                                                   *
*    id : logical UART channel.                                                *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_uart_clear_flag(HAL_UART_ID id, HAL_UART_IRQ_TYPE irq_type)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    LPUART_ClearStatusFlags(base, s_irqMask[irq_type]);
}

/*******************************************************************************
*                       hal_uart_clear_errors                                  *
*                       =====================                                  *
* PURPOSE:                                                                     *
*    Clear all receive error flags on a UART channel.                          *
* ARGUMENTS:                                                                   *
*    id : logical UART channel.                                                *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_uart_clear_errors(HAL_UART_ID id)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    LPUART_ClearStatusFlags(base,
        (uint32_t)kLPUART_RxOverrunFlag |
        (uint32_t)kLPUART_FramingErrorFlag |
        (uint32_t)kLPUART_NoiseErrorFlag |
        (uint32_t)kLPUART_ParityErrorFlag);
}

/*******************************************************************************
*                       hal_uart_puts                                          *
*                       =============                                          *
* PURPOSE:                                                                     *
*    Blocking write of a null-terminated string to a UART channel.             *
* ARGUMENTS:                                                                   *
*    id  : logical UART channel.                                               *
*    str : null-terminated string to send.                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    Spins until each byte is transmitted; debug use only.                     *
*******************************************************************************/
void hal_uart_puts(HAL_UART_ID id, const char *str)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    while (*str) {
        while (!(LPUART_GetStatusFlags(base) & (uint32_t)kLPUART_TxDataRegEmptyFlag)) {
            /* spin */
        }
        LPUART_WriteByte(base, (uint8_t)*str++);
    }
    /* Wait for last byte to complete */
    while (!(LPUART_GetStatusFlags(base) & (uint32_t)kLPUART_TransmissionCompleteFlag)) {
        /* spin */
    }
}

/*******************************************************************************
*                       9-BIT MODE HELPERS                                     *
*                       ==================                                     *
* PURPOSE:                                                                     *
*    IOLink address-mark framing: the 9th bit (T8/R8 in LPUART DATA register) *
*    marks address frames (=1) vs data frames (=0).                            *
* ARGUMENTS:                                                                   *
*    id   : UART channel (should be HAL_UART_IOL).                             *
*    bit9 : (set only) 1 = address frame, 0 = data frame.                     *
* RETURN:                                                                      *
*    (get only) 1 if address frame, 0 if data frame.                           *
* NOTES:                                                                       *
*    LPUART DATA bit 8 (T8 write / R8 read) carries the 9th bit.              *
*******************************************************************************/

/** Set the 9th transmit bit for the NEXT byte written via hal_uart_write_byte.
 *  @param id   UART channel (should be HAL_UART_IOL)
 *  @param bit9 1 = address frame, 0 = data frame                             */
void hal_uart_set_tx_9bit(HAL_UART_ID id, UINT8 bit9)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    if (bit9) {
        /* Set CTRL.R9T8 — this is the T8 bit for the next TX byte */
        base->CTRL |= LPUART_CTRL_R9T8_MASK;
    } else {
        base->CTRL &= ~LPUART_CTRL_R9T8_MASK;
    }
}

/** Read the 9th receive bit from the last received byte.
 *  @param id   UART channel (should be HAL_UART_IOL)
 *  @return 1 if address frame, 0 if data frame                                */
UINT8 hal_uart_get_rx_9bit(HAL_UART_ID id)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return 0;

    /* R8T9 in CTRL represents the 9th received bit when reading */
    return (base->CTRL & LPUART_CTRL_R8T9_MASK) ? 1u : 0u;
}

/*******************************************************************************
*                       hal_uart_irq_dispatch                                  *
*                       =====================                                  *
* PURPOSE:                                                                     *
*    Common LPUART IRQ dispatcher — checks status flags and calls registered   *
*    callbacks for RX data, TX empty, TX done and RX error.                    *
* ARGUMENTS:                                                                   *
*    id : logical UART channel that triggered the interrupt.                   *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    Called from LPUART1_IRQHandler / LPUART2_IRQHandler.                      *
*******************************************************************************/
static void hal_uart_irq_dispatch(HAL_UART_ID id)
{
    LPUART_Type *base = s_uartBase[id];
    if (base == NULL) return;

    uint32_t status  = LPUART_GetStatusFlags(base);
    uint32_t enabled = base->CTRL;

    /* RX data available */
    if ((status & (uint32_t)kLPUART_RxDataRegFullFlag) &&
        (enabled & LPUART_CTRL_RIE_MASK)) {
        if (s_isrCallbacks[id][HAL_UART_IRQ_RX_DATA]) {
            s_isrCallbacks[id][HAL_UART_IRQ_RX_DATA]();
        }
    }

    /* TX data register empty */
    if ((status & (uint32_t)kLPUART_TxDataRegEmptyFlag) &&
        (enabled & LPUART_CTRL_TIE_MASK)) {
        if (s_isrCallbacks[id][HAL_UART_IRQ_TX_EMPTY]) {
            s_isrCallbacks[id][HAL_UART_IRQ_TX_EMPTY]();
        }
    }

    /* Transmission complete */
    if ((status & (uint32_t)kLPUART_TransmissionCompleteFlag) &&
        (enabled & LPUART_CTRL_TCIE_MASK)) {
        if (s_isrCallbacks[id][HAL_UART_IRQ_TX_DONE]) {
            s_isrCallbacks[id][HAL_UART_IRQ_TX_DONE]();
        }
    }

    /* Receive errors */
    if (status & ((uint32_t)kLPUART_RxOverrunFlag |
                  (uint32_t)kLPUART_FramingErrorFlag |
                  (uint32_t)kLPUART_NoiseErrorFlag)) {
        /* Clear error flags */
        LPUART_ClearStatusFlags(base,
            (uint32_t)kLPUART_RxOverrunFlag |
            (uint32_t)kLPUART_FramingErrorFlag |
            (uint32_t)kLPUART_NoiseErrorFlag |
            (uint32_t)kLPUART_ParityErrorFlag);

        if (s_isrCallbacks[id][HAL_UART_IRQ_RX_ERROR]) {
            s_isrCallbacks[id][HAL_UART_IRQ_RX_ERROR]();
        }
    }
}

/*******************************************************************************
*                       LPUART1 / LPUART2 ISR Entry Points                     *
*                       ======================================                 *
* PURPOSE:                                                                     *
*    Vector table entry points for LPUART1 and LPUART2 interrupts.             *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    IOL/DBG mapping depends on AIH_PROTO_V1 (Proto1 vs Proto1b).             *
*******************************************************************************/
//void __attribute__((weak)) LPUART1_IRQHandler(void)
void LPUART1_IRQHandler(void)
{
#if defined(AIH_PROTO_V1) && AIH_PROTO_V1
    hal_uart_irq_dispatch(HAL_UART_IOL);
#else
    hal_uart_irq_dispatch(HAL_UART_DEBUG);
#endif
}

void LPUART3_IRQHandler(void)
{
#if defined(AIH_PROTO_V1) && AIH_PROTO_V1
    hal_uart_irq_dispatch(HAL_UART_DEBUG);
#else
    hal_uart_irq_dispatch(HAL_UART_IOL);
#endif
}

#endif /* RT1024_BUILD */
