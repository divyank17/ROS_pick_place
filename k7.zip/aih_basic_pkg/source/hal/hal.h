/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal.h                                                       *
*    Description : Master HAL include — pulls in all HAL sub-headers.          *
*                  Application code includes this instead of individual files.  *
*******************************************************************************/
#ifndef HAL_H
#define HAL_H

#include "hal_platform.h"
//#include "hal_types.h"
#include "hal_timer.h"
#include "hal_gpio.h"
//#include "hal_spi.h"
#include "hal_uart.h"
//#include "hal_adc.h"
//#include "hal_watchdog.h"
#include "hal_fpga.h"

#endif /* HAL_H */
