/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_timer.c                                                 *
*    Description : Application timer implementation for iMXRT1024.             *
*                                                                              *
*    IOL Silence / Gap Timer (HAL_TIMER_IOL_SIL):                              *
*      Uses the Cortex-M7 DWT cycle counter (DWT->CYCCNT) as a free-running   *
*      microsecond counter.  No extra peripheral needed.                       *
*                                                                              *
*      LPC17xx used LPC_TIM1->TC (Timer1 counter register).                   *
*      H8S used TPU4_TCNT.                                                     *
*      RT1024 equivalent: DWT->CYCCNT / (SystemCoreClock / 1000000)            *
*                                                                              *
*    This file is compiled ONLY for RT1024_BUILD.                              *
*******************************************************************************/
#include "hal_platform.h"

#if defined(RT1024_BUILD)

#include "hal_timer.h"
#include "fsl_clock.h"

/*******************************************************************************
*                       DWT Cycle Counter                                      *
*                       =================                                      *
* PURPOSE:                                                                     *
*    Microsecond-resolution free-running counter using DWT CYCCNT.             *
*    At 600 MHz, wraps every ~7.16 seconds — fine for IOL gap timing.         *
* ARGUMENTS:                                                                   *
*    N/A (internal state declarations).                                        *
* RETURN:                                                                      *
*    N/A.                                                                      *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/

/* Saved CYCCNT value at last timer start/reset */
static UINT32 s_iolSilStartCycle;

/* Cycles per microsecond (computed once at init) */
static UINT32 s_cyclesPerUs;

/* Silence timer callback and period for interrupt-based use */
static hal_timer_callback_t s_timerCallbacks[HAL_TIMER_COUNT];
static UINT32               s_timerPeriodUs[HAL_TIMER_COUNT];
static BOOL                 s_timerRunning[HAL_TIMER_COUNT];

/*******************************************************************************
*                       hal_timer_init_dwt                                     *
*                       ==================                                     *
* PURPOSE:                                                                     *
*    Enable DWT cycle counter (called once at startup).                        *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    Requires CoreDebug TRCENA to be enabled.                                  *
*******************************************************************************/
static void hal_timer_init_dwt(void)
{
    /* Enable trace — required for DWT to function */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;

    /* Reset and enable the cycle counter */
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    /* Cache cycles-per-microsecond */
    s_cyclesPerUs = SystemCoreClock / 1000000u;
    if (s_cyclesPerUs == 0) {
        s_cyclesPerUs = 1;  /* safety: avoid divide-by-zero */
    }
}

/* Ensure DWT is initialised before first use */
static BOOL s_dwtInitDone = FALSE;

static void hal_timer_ensure_dwt(void)
{
    if (!s_dwtInitDone) {
        hal_timer_init_dwt();
        s_dwtInitDone = TRUE;
    }
}

/*******************************************************************************
*                       hal_timer_configure                                    *
*                       ===================                                    *
* PURPOSE:                                                                     *
*    Register a timer period and optional callback for a logical timer ID.     *
* ARGUMENTS:                                                                   *
*    timer_id  : HAL_TIMER_ID.                                                 *
*    period_us : period in microseconds.                                       *
*    callback  : function to call on timer expiry (may be NULL).               *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_timer_configure(HAL_TIMER_ID timer_id, UINT32 period_us, 
                         hal_timer_callback_t callback)
{
    if ((unsigned)timer_id < HAL_TIMER_COUNT) {
        s_timerPeriodUs[timer_id]  = period_us;
        s_timerCallbacks[timer_id] = callback;
    }
}

/*******************************************************************************
*                       hal_timer_start                                        *
*                       ===============                                        *
* PURPOSE:                                                                     *
*    Start a logical timer.  For IOL_SIL, captures DWT start cycle.            *
* ARGUMENTS:                                                                   *
*    timer_id : HAL_TIMER_ID.                                                  *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_timer_start(HAL_TIMER_ID timer_id)
{
    hal_timer_ensure_dwt();

    if (timer_id == HAL_TIMER_IOL_SIL) {
        /* Capture start cycle — GetGapTimerCnt returns elapsed us from here */
        s_iolSilStartCycle = DWT->CYCCNT;
    }
    if ((unsigned)timer_id < HAL_TIMER_COUNT) {
        s_timerRunning[timer_id] = TRUE;
    }
}

/*******************************************************************************
*                       hal_timer_stop                                         *
*                       ==============                                         *
* PURPOSE:                                                                     *
*    Stop a logical timer.                                                     *
* ARGUMENTS:                                                                   *
*    timer_id : HAL_TIMER_ID.                                                  *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_timer_stop(HAL_TIMER_ID timer_id)
{
    if ((unsigned)timer_id < HAL_TIMER_COUNT) {
        s_timerRunning[timer_id] = FALSE;
    }
}

/*******************************************************************************
*                       hal_timer_get_count                                    *
*                       ==================                                     *
* PURPOSE:                                                                     *
*    Return elapsed microseconds since last start for IOL_SIL timer.           *
* ARGUMENTS:                                                                   *
*    timer_id : HAL_TIMER_ID.                                                  *
* RETURN:                                                                      *
*    UINT32 elapsed microseconds (0 if timer_id is not IOL_SIL).               *
* NOTES:                                                                       *
*    Maps to the old LPC_TIM1->TC / TPU4_TCNT read.                           *
*******************************************************************************/
UINT32 hal_timer_get_count(HAL_TIMER_ID timer_id)
{
    hal_timer_ensure_dwt();

    if (timer_id == HAL_TIMER_IOL_SIL) {
        UINT32 elapsed = DWT->CYCCNT - s_iolSilStartCycle;
        return elapsed / s_cyclesPerUs;
    }

    return 0;
}

/*******************************************************************************
*                       hal_timer_start_counter / counter_arrived              *
*                       =========================================              *
* PURPOSE:                                                                     *
*    Busy-wait counter used by WDT factory test.                               *
* ARGUMENTS:                                                                   *
*    resolution_us : (start_counter) resolution in microseconds.               *
* RETURN:                                                                      *
*    (counter_arrived) TRUE if the period has elapsed.                         *
* NOTES:                                                                       *
*    Replaces LPC StartCounter.                                                *
*******************************************************************************/
static UINT32 s_busyWaitStartCycle;
static UINT32 s_busyWaitPeriodCycles;

void hal_timer_start_counter(UINT16 resolution_us)
{
    hal_timer_ensure_dwt();
    s_busyWaitStartCycle   = DWT->CYCCNT;
    s_busyWaitPeriodCycles = (UINT32)resolution_us * s_cyclesPerUs;
}

BOOL hal_timer_counter_arrived(void)
{
    UINT32 elapsed = DWT->CYCCNT - s_busyWaitStartCycle;
    return (elapsed >= s_busyWaitPeriodCycles) ? TRUE : FALSE;
}

/*******************************************************************************
*                       SysTick (STC) accessors                                *
*                       =======================                                *
* PURPOSE:                                                                     *
*    Return SysTick current value and reload registers for scheduler latency.  *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    UINT32 register value.                                                    *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
UINT32 hal_stc_get_count(void)
{
    return SysTick->VAL;
}

UINT32 hal_stc_get_reload(void)
{
    return SysTick->LOAD;
}

/*******************************************************************************
*                       hal_interrupt_set_mask / get_mask                      *
*                       ====================================                   *
* PURPOSE:                                                                     *
*    Map H8S interrupt priority levels (0–7) to ARM BASEPRI register.          *
*    Level 0=all enabled, 7=all masked.  ARM: BASEPRI masks interrupts with    *
*    priority >= threshold.  Lookup table inverts numbering.                   *
* ARGUMENTS:                                                                   *
*    level : H8S priority level (0–7) or raw BASEPRI value (>7) for restore.  *
* RETURN:                                                                      *
*    UINT32 previous BASEPRI value.                                            *
* NOTES:                                                                       *
*    RT1024 CHANGES: H8S set_imask_exr replaced with ARM BASEPRI.             *
*******************************************************************************/

/* H8S level (index) -> ARM BASEPRI register value */
static const UINT32 s_level_to_basepri[8] = {
    0x00u,  /* 0  LOWEST  : all enabled                        */
    0xC0u,  /* 1  TASK    : blocks ARM prio >= 12 (Debug UART) */
    0xB0u,  /* 2          : blocks ARM prio >= 11              */
    0xA0u,  /* 3          : blocks ARM prio >= 10              */
    0x80u,  /* 4  GHO     : blocks ARM prio >= 8  (+ GHO GPIO) */
    0x60u,  /* 5  TICK    : blocks ARM prio >= 6  (+ SysTick)  */
    0x40u,  /* 6          : blocks ARM prio >= 4               */
    0x10u,  /* 7  HIGHEST : blocks ARM prio >= 1  (everything) */
};

UINT32 hal_interrupt_set_mask(UINT32 level)
{
    UINT32 prev = __get_BASEPRI();
    if (level == 0u) {
        __set_BASEPRI(0u);                          /* Enable all */
    } else if (level <= 7u) {
        __set_BASEPRI(s_level_to_basepri[level]);    /* H8S level -> BASEPRI */
    } else {
        __set_BASEPRI(level);                        /* Raw BASEPRI restore */
    }
    return prev;
}

UINT32 hal_interrupt_get_mask(void)
{
    return __get_BASEPRI();
}

void hal_interrupt_disable_all(void)
{
    __disable_irq();
}

void hal_interrupt_enable_all(void)
{
    __enable_irq();
    __set_BASEPRI(0);
}

/*******************************************************************************
*                       hal_delay_us                                           *
*                       ============                                           *
* PURPOSE:                                                                     *
*    Busy-wait delay using DWT cycle counter.                                  *
* ARGUMENTS:                                                                   *
*    us : delay in microseconds.                                               *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
void hal_delay_us(UINT32 us)
{
    hal_timer_ensure_dwt();
    UINT32 startCycle = DWT->CYCCNT;
    UINT32 delayCycles = us * s_cyclesPerUs;
    while ((DWT->CYCCNT - startCycle) < delayCycles) {
        /* spin */
    }
}

#endif /* RT1024_BUILD */
