/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_uart.h                                                  *
*    Description : UART abstraction interface.                                 *
*                  Abstracts serial communication for IOLink, HART modems,     *
*                  and debug console.                                          *
*                                                                              *
*    H8S:    SCI0 (IOLink), SCI1 (debug), SCI2 (HART modem ISRs)             *
*    RT1024:  LPUART1 + LPUART2 (assignment swappable via AIH_PROTO_V1)      *
*             Proto V1: IOL=LPUART1, Debug=LPUART2                            *
*             Next Rev: IOL=LPUART2, Debug=LPUART1 (serial downloader)       *
*    QEMU:    CMSDK APB UART0 (debug), simulated IOL/HART via pipe            *
*******************************************************************************/
#ifndef HAL_UART_H
#define HAL_UART_H

#include "hal_platform.h"
#include "datatype.h"

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
*                           UART CHANNEL IDs                                   *
*  These are LOGICAL identifiers used by application code.                     *
*  The physical LPUART mapping is controlled by AIH_PROTO_V1 in hal_platform.h *
*******************************************************************************/
typedef enum {
    HAL_UART_IOL     = 0,  /**< IOLink communication (was SCI0 on H8S)      */
    HAL_UART_DEBUG   = 1,  /**< Debug console (was SCI1 on H8S)             */
    HAL_UART_HART    = 2,  /**< HART modem (via FPGA, not an LPUART)        */
    HAL_UART_COUNT   = 3
} HAL_UART_ID;

/*******************************************************************************
*                    PHYSICAL LPUART MAPPING                                   *
*                                                                              *
*  AIH_PROTO_V1 (Proto1 board):                                                *
*    IOLink  → LPUART1  (GPIO_AD_B0_06 TX / GPIO_AD_B0_07 RX)                *
*    Debug   → LPUART2  (GPIO_AD_B1_08 TX / GPIO_AD_B1_09 RX)                *
*                                                                              *
*  Proto1b board (AIH_PROTO_V1 not defined):                                   *
*    Debug   → LPUART1  (shares serial downloader pins)                       *
*    IOLink  → LPUART2                                                        *
*******************************************************************************/
#if !defined(UNIT_TEST_BUILD) && !defined(QEMU_BUILD)
#include "fsl_lpuart.h"

#if defined(AIH_PROTO_V1) && AIH_PROTO_V1
    /* Proto1: IOL on LPUART1, Debug on LPUART2 */
    #define HAL_UART_IOL_INSTANCE     1U
    #define HAL_UART_IOL_BASE         LPUART1
    #define HAL_UART_IOL_IRQn         LPUART1_IRQn
    #define HAL_UART_IOL_IRQ_HANDLER  LPUART1_IRQHandler

    #define HAL_UART_DBG_INSTANCE     3U
    #define HAL_UART_DBG_BASE         LPUART3
    #define HAL_UART_DBG_IRQn         LPUART3_IRQn
    #define HAL_UART_DBG_IRQ_HANDLER  LPUART3_IRQHandler
#else
    /* Proto1b: Debug on LPUART1 (serial downloader), IOL on LPUART2 */
	#define HAL_UART_IOL_INSTANCE     3U
	#define HAL_UART_IOL_BASE         LPUART3
	#define HAL_UART_IOL_IRQn         LPUART3_IRQn
	#define HAL_UART_IOL_IRQ_HANDLER  LPUART3_IRQHandler

    #define HAL_UART_DBG_INSTANCE     1U
    #define HAL_UART_DBG_BASE         LPUART1
    #define HAL_UART_DBG_IRQn         LPUART1_IRQn
    #define HAL_UART_DBG_IRQ_HANDLER  LPUART1_IRQHandler
#endif

#endif /* !UNIT_TEST_BUILD && !QEMU_BUILD */

/*******************************************************************************
*                           UART INTERRUPT TYPES                               *
*******************************************************************************/
typedef enum {
    HAL_UART_IRQ_RX_DATA  = 0,  /**< Receive data available                 */
    HAL_UART_IRQ_TX_EMPTY = 1,  /**< Transmit data register empty           */
    HAL_UART_IRQ_TX_DONE  = 2,  /**< Transmission complete                  */
    HAL_UART_IRQ_RX_ERROR = 3   /**< Receive error (overrun/framing/parity) */
} HAL_UART_IRQ_TYPE;

typedef void (*hal_uart_isr_t)(void);

/*******************************************************************************
*                           UART CONFIGURATION                                 *
*******************************************************************************/
typedef struct {
    UINT32 baudrate;     /**< Baud rate (e.g., 38400, 750000 for IOL)       */
    UINT8  data_bits;    /**< 7 or 8                                         */
    UINT8  stop_bits;    /**< 1 or 2                                         */
    UINT8  parity;       /**< 0=none, 1=odd, 2=even                         */
} hal_uart_config_t;

/*******************************************************************************
*                           UART API                                           *
*******************************************************************************/

/**
 * @brief Initialize a UART channel with the specified configuration.
 */
void hal_uart_init(HAL_UART_ID id, const hal_uart_config_t *config);

/**
 * @brief Enable/disable the UART transmitter.
 */
void hal_uart_tx_enable(HAL_UART_ID id, BOOL enable);

/**
 * @brief Enable/disable the UART receiver.
 */
void hal_uart_rx_enable(HAL_UART_ID id, BOOL enable);

/**
 * @brief Write a byte to the UART transmit register.
 */
void hal_uart_write_byte(HAL_UART_ID id, UINT8 data);

/**
 * @brief Read a byte from the UART receive register.
 */
UINT8 hal_uart_read_byte(HAL_UART_ID id);

/**
 * @brief Read a 9-bit frame from the UART DATA register.
 * @return bits[8:0] of the DATA register:
 *           bit  8 = 9th received bit (address/data marker)
 *           bits 7:0 = 8 data bits
 *         bits[15:11] contain status flags: NOISY(15), PARITYE(14),
 *           FRETSC(13 = framing error), RXEMPT(12), IDLINE(11).
 *         Check (retval & 0xF800) == 0 for a clean receive.
 */
uint16_t hal_uart_read_byte9(HAL_UART_ID id);
/**
 * @brief write a 9-bit frame to the UART DATA register.
 * @return bits[8:0] of the DATA register:
 *           bit  8 = 9th received bit (address/data marker)
 *           bits 7:0 = 8 data bits
 *         bits[15:11] contain status flags: NOISY(15), PARITYE(14),
 *           FRETSC(13 = framing error), RXEMPT(12), IDLINE(11).
 *         Check (retval & 0xF800) == 0 for a clean receive.
 */
void hal_uart_write_byte9(HAL_UART_ID id, UINT8 data, UINT8 bit9);

/**
 * @brief Check if the transmit data register is empty (ready for next byte).
 */
BOOL hal_uart_tx_ready(HAL_UART_ID id);

/**
 * @brief Check if transmitter is fully complete (shift register empty).
 */
BOOL hal_uart_tx_complete(HAL_UART_ID id);

/**
 * @brief Check if receive data is available.
 */
BOOL hal_uart_rx_ready(HAL_UART_ID id);

/**
 * @brief Register an ISR callback for a specific UART interrupt type.
 */
void hal_uart_register_isr(HAL_UART_ID id, HAL_UART_IRQ_TYPE irq_type,
                           hal_uart_isr_t callback);

/**
 * @brief Enable/disable a specific UART interrupt.
 */
void hal_uart_irq_enable(HAL_UART_ID id, HAL_UART_IRQ_TYPE irq_type, BOOL enable);

/**
 * @brief Clear UART flags (RxData, TxEmpty, TxDone).
 */
void hal_uart_clear_flag(HAL_UART_ID id, HAL_UART_IRQ_TYPE irq_type);

/**
 * @brief Clear UART error flags (overrun, framing, parity).
 */
void hal_uart_clear_errors(HAL_UART_ID id);

/**
 * @brief Set the 9th transmit bit for the next byte (9-bit address-mark mode).
 * @param id   UART channel (typically HAL_UART_IOL)
 * @param bit9 1 = address frame, 0 = data frame
 */
void hal_uart_set_tx_9bit(HAL_UART_ID id, UINT8 bit9);

/**
 * @brief Read the 9th receive bit from the last received byte.
 * @param id   UART channel (typically HAL_UART_IOL)
 * @return 1 if address frame, 0 if data frame
 */
UINT8 hal_uart_get_rx_9bit(HAL_UART_ID id);

/**
 * @brief Blocking string output (debug only).
 */
void hal_uart_puts(HAL_UART_ID id, const char *str);

#ifdef __cplusplus
}
#endif

#endif /* HAL_UART_H */
