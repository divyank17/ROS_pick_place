# HART stack review after HART_LOG removal

Compared files:

- Legacy: `s1(3).zip/src/hartstack.cpp` and `hartstack.hpp`
- Updated project: `aih_basic_pkg/source/hartstack.cpp` and `hartstack.hpp`

## HART_LOG review

`HART_LOG` was not present in the legacy HART files. It was present only in the previously generated integration zip as a suppressed diagnostic macro.

Current status in this update:

- `HART_LOG` macro removed from `hartstack.cpp`
- `HartLogSuppressed()` removed from `hartstack.cpp`
- All `HART_LOG(...)` call sites removed from `hartstack.cpp`
- Remaining `HART_LOG` references in updated HART files: `0`

## Legacy stack method coverage

Legacy class-level stack functions found: 21
Updated class-level stack functions found: 34

Missing legacy class-level methods after this update:

```
None
```

Extra class-level methods retained in the updated project:

```
clsClientBuffer::At
clsClientBuffer::Flush
clsClientBuffer::clsClientBuffer
clsHartModem::ClearModemBad
clsHartModem::ClearTxRxFIFOs
clsHartModem::Disconnect
clsHartModem::ReinstateModem
clsHartModem::SetModemBad
clsModemBuffer::Flush
clsModemBuffer::GetLength
clsModemBuffer::PopChar
clsModemBuffer::ThrowLastRcvd
clsModemBuffer::clsModemBuffer
```

The extra class-level methods are compatibility/helper methods that were inline in the old header or needed in the RT1024 implementation. They do not replace legacy command handlers.

## Important flow comparison

| Function area | Current status |
|---|---|
| `clsHartQueue` variable names | Updated closer to legacy: `m_ucNextIndex` and `m_ucBuffer[]` are used instead of ring-buffer-style names. |
| `clsHartQueue::AddToQueue()` | Same logical flow as legacy: reject invalid/full queue, reject duplicate queued channel, reject already-active channel, then append to queue. Interrupt-mask calls are not copied because the RT1024 clean project does not have `get_imask_exr()/set_imask_exr()`. |
| `clsHartQueue::RemoveFromQueue()` | Same logical flow as legacy: find channel, shift remaining entries left, clear tail, decrement index. |
| `clsHartQueue::IsModemQueueEmpty()` | Same logical flow as legacy: returns true when queue index is zero. |
| `clsHartQueue::ProcessQueue()` | Source-facing flow remains queue -> modem -> `Connect()`. Difference: RT1024 still executes `HartDiscoverOnRoute()` inside this path because the clean project does not have the old interrupt-driven client callback framework. |
| `clsHartModem::Disconnect(BOOL)` | Added compatibility overload. It calls `Disconnect()` and preserves the old UIO-style `bResetState == FALSE` behavior by keeping `m_bHartStackProc` true. |
| `clsHartModem::Connect()` / `SwitchMux()` | Same purpose as legacy, but hardware writes are routed through `hal_fpga_*` functions instead of old `HART_MUXADDR/HART_MUXENBL` register objects. |
| Interrupt/byte state machine methods | Names are present, but full old DUART interrupt byte-by-byte implementation is not copied. The RT1024 project uses the proven FPGA transaction helper path for actual command execution. |
| Static `HartStack_*` APIs and helper functions | These are not in legacy `s1`, but are retained because the present RT1024 project needs them for SPI/FPGA/HART command execution and CMD0/CMD3/CMD48/CMD59 parsing. |

## Summary

The updated file is now cleaner for refresh integration because non-legacy `HART_LOG` has been removed and the queue/member names are closer to the old code. The class-level legacy function surface is covered. The only remaining differences are intentional hardware/adaptation differences where the old source depended on the legacy slot/client/interrupt framework that is not available in the clean RT1024 project.
