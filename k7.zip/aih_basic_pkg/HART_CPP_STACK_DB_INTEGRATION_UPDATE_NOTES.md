# HART legacy comparison and integration update

This project was compared against the old legacy `s1` HART files for:

- `hart.cpp` / `hart.h`
- `hartstack.cpp` / `hartstack.hpp`
- `hartdb.cpp` / `hartdb.hpp`

## 1. hart.cpp status

Legacy global HART entry points now present in the updated project:

- `isHartCapable()`
- `CheckAndInitHart()`
- `ResetHart()`
- `TestHartAddressMux()`
- `InitHartConnection()`
- `AbortHartConnection()`
- `ProcessHartInterrupt()`

`HartTask(TASKCONTEXT)` is added as an optional compatibility wrapper. It is guarded by:

```c
#define HART_ENABLE_LEGACY_TASK_API (0u)
```

Set this to `1` only when integrating into a refresh project that expects the old scheduler-style `HartTask(TASKCONTEXT)` API. It is disabled by default so the clean RT1024 validation project does not introduce scheduler type conflicts.

Remaining legacy functions not added to this clean project are slot/box-slot functions, not pure HART module functions:

- `clsAihSlot::GetRcvBufObject()`
- `clsAihSlot::PreCommand()` / `PostCommand()`
- `clsAihSlot::PreHEnable()` / `PostHEnable()`
- `clsAihSlot::PreHAlarmEnable()` / `PostHAlarmEnable()`
- `clsAihSlot::PreHScanCfg()` / `PostHScanCfg()`
- `clsAihSlot::PreHComThrs()`
- `clsAihSlot::PreHComHys()`
- `clsAihSlot::PostHDevIdCd()`
- `clsAihSlot::PreHDvMfgCd()` / `PreHDvMfgCd7()`
- `clsAihSlot::PreHDvTypCd()` / `PreHDvTypCd7()`
- `clsAihSlot::PreHDvRevCd()`
- `clsAihSlot::PreHDdRevCd()`
- `clsAihSlot::PreHEuRngExt()`
- `clsAihBoxSlot::PreHADCEnable()` / `PostHADCEnable()`
- `clsAohBoxSlot::PreHADCEnable()` / `PostHADCEnable()`
- `clsAohBoxSlot::PreHAutoDet()` / `PostHAutoDet()`

Reason: those functions depend on old AIH/AOH slot classes, box-slot objects, point type objects, and parameter database framework. They should remain in the refresh slot layer, not inside this clean RT1024 HART bring-up package.

## 2. hartstack.cpp status

The updated project now keeps the legacy stack-facing class method names for:

- `clsClientBuffer`
- `clsHartQueue`
- `clsModemBuffer`
- `clsHartModem`

Useful alignment added:

- `clsHartModem::HartModemInterrupt()` now maps interrupt types into the modem state helpers instead of being a no-op.
- `clsHartModem::HartModemHeartbeat()` now behaves more like the legacy timer path by counting modem timers down and processing disconnect requests.
- `clsHartModem::Connect()` now uses `SetState(HMODEMSTATE_SYNCWAIT, HART_LINK_GRANT_TIME)`.
- `clsHartModem::SetModemBad()` now preserves the failed channel before disconnecting.

The RT1024 implementation still keeps the proven polling/FPGA backend helper functions, such as:

- `HartStack_GetCleanCmd0()`
- `HartStack_RunLongCommand()`
- `HartStack_ParseHartResponse()`
- `HartStack_GetCommandTable()`

These are extra integration helpers and should be kept.

## 3. hartdb.cpp / hartdb.hpp status

The previous CMD3 alignment is retained, and this update adds more legacy compatibility:

- `clsHartDevDb::SetScanCounterForRediscovery(UINT8)` added.
- `clsHartPst` expanded with legacy fields:
  - `m_ucHandle`
  - `m_ucSlotNumber`
  - `m_ucPstMsgTimeout`
  - `m_PstStatus`
  - `m_PstRcvBuffer`
- `clsHartPst::PassThroughTable(UINT8)` added.
- `pHartPst[]`, `g_ucHPstReqBuffer`, and `g_ucHPstRcvBuffer` added for legacy pass-through integration.
- `clsHartDevDb::BuildScanTable()` now follows the old rate-table concept more closely.
- `clsHartDevDb::SetupScanMessage()` now sets legacy next-command pointers:
  - `m_ucNextReqCmd`
  - `m_ucpNextXmtPtr`
- `clsHartDevDb::ScheduleFromScanTable()` now has the old back-to-back scan flow shape.
- `clsHartDevDb::SetupPassThrough()` now scans the pass-through table and blocks invalid CMD0/CMD38 pass-through requests like legacy.
- `clsHartDevDb::ProcessHartEvents()` is no longer a pure stub; it follows the old `ChannelHeartbeat()` -> `ProcessHartEvents()` -> queue request pattern in a compact RT1024-compatible way.

## 4. What is still intentionally not fully ported

The old code depends heavily on full product framework objects such as:

- `BOX`
- `SLOT()`
- `AIH_SLOT()` / `AOH_SLOT()`
- old scheduler/DMC framework
- old event manager and soft-fail/hard-fail infrastructure
- old point execution state and module status database

Those objects are not present in this clean RT1024 validation package. So the updated files preserve names, state variables, handlers, scan/pass-through flow shape, and wrapper APIs, but hardware/product-framework-specific behavior remains compact and RT1024-safe.

## 5. Syntax validation done here

The changed HART files were syntax-checked with a host C++ compiler using a small debug-console stub for `PRINTF`:

- `source/hart.cpp`
- `source/hartdb.cpp`
- `source/hartstack.cpp`

A full MCUXpresso ARM build still has to be run in MCUXpresso because this environment does not include the NXP ARM toolchain/runtime headers such as `arm_acle.h`.
