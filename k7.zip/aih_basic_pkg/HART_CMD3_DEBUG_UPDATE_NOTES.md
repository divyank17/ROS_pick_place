# HART CMD3 dynamic value debug update

This package keeps the previous legacy-flow implementation and adds a board-validation print for the complete CMD3 dynamic-variable response.

## Why this change was made

The route scan was working and reporting correct channel/modem values, but the terminal output showed only PV. The old HART flow expects CMD3 to provide:

- loop current
- PV unit and PV value
- SV unit and SV value
- TV unit and TV value
- QV unit and QV value

The code was already decoding those values in `clsHartDevDb::Cmd3GoodHandler()`, but only `HDynVal[0]` was printed.

## What was added

### `hart.h`

Added this test switch:

```c
#ifndef HART_ENABLE_CMD3_RESPONSE_PRINT
#define HART_ENABLE_CMD3_RESPONSE_PRINT          (1u)
#endif
```

Added prototype:

```c
VOID HartReportCmd3Response(UINT8 channel, UINT8 modem);
```

### `hart.cpp`

Added:

```c
static BOOL HartIsValidFloat(FLOAT32 value);
static VOID HartPrintFloat3(FLOAT32 value);
VOID HartReportCmd3Response(UINT8 channel, UINT8 modem);
```

`HartReportCmd3Response()` prints one complete CMD3 diagnostic line using the same old database path updated by `Cmd3GoodHandler()`:

- loop current from CMD3 payload / `HartDeviceInfo_t::loopCurrentMa`
- PV/SV/TV/QV values from `clsHartDevDb::HDynVal[]`
- PV/SV/TV/QV units from `clsHartDevDb::HDynEu[]`
- availability from `clsHartDevDb::HDynSt[]`

The final PV report now prints:

```text
HART_RESPONSE PV=<pv> CHANNEL=<channel> MODEM=<modem>
HART_CMD3 LOOP_CURRENT_MA=<ma> PV_UNIT=<unit> PV=<pv> SV_UNIT=<unit> SV=<sv> TV_UNIT=<unit> TV=<tv> QV_UNIT=<unit> QV=<qv> DYN_COUNT=<count> CHANNEL=<channel> MODEM=<modem>
```

## Important print-format detail

The code still avoids `%f`, `%lu`, and `%03lu` because the debug-console configuration in this project previously printed values like `lu.lu`. All floating-point values are printed with manual integer/decimal digit formatting using only simple `%d` conversions.

## Production integration

For IO-Link integration / production, disable the diagnostic line:

```c
#define HART_ENABLE_CMD3_RESPONSE_PRINT          (0u)
```

To disable all normal HART terminal output:

```c
#define HART_ENABLE_FINAL_RESPONSE_PRINT         (0u)
```
