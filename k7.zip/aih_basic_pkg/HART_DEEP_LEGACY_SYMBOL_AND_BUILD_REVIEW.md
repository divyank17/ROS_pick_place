# HART Deep Legacy Symbol and Build Review

Baseline compared:
- Legacy source: `s1(3).zip`
- Working source used as base: `aih_hart_no_hartlog_legacy_flow_update.zip`

Files reviewed:
- `source/hart.cpp` / `source/hart.h`
- `source/hartdb.cpp` / `source/hartdb.hpp`
- `source/hartstack.cpp` / `source/hartstack.hpp`

## Result summary

The refresh-facing HART command/database/stack entry points are present and build-check clean in this update.  The remaining legacy functions that are not implemented are not pure HART module functions; they are old slot/box-slot framework member functions such as `clsAihSlot::PreHEnable()` and `clsAohSlot::PreHEnable()`. Those classes are not part of the clean RT1024 project, so adding those functions directly in this HART module would create class-definition conflicts during real refresh integration.

## `hart.cpp` comparison

Legacy global HART functions present in the updated project:

- `isHartCapable()`
- `CheckAndInitHart()`
- `ResetHart()`
- `TestHartAddressMux()`
- `InitHartConnection(UINT8)`
- `AbortHartConnection(UINT8)`
- `ProcessHartInterrupt()`

Compatibility storage names added back:

- `g_ucHChanRcvBuffer`
- `g_pucHChanRcvBuffer`
- `g_usHPstObjMemory`
- `g_usModemObjectMemory`
- `g_usHartQueueObjectMemory`

Loop constants in `ProcessHartInterrupt()` and `AbortHartConnection()` now use `HARTMODEM_COUNT` instead of hard-coded `4`.

Legacy functions intentionally not added here because the clean project does not contain those classes:

- `clsAihSlot::*`
- `clsAohSlot::*`
- `clsAihBoxSlot::*`
- `clsAohBoxSlot::*`

These should remain in the refresh slot/database layer, not in this standalone HART module.

## `hartdb.cpp` comparison

All main legacy `clsHartDevDb` functions and command handlers are present:

- `InitDevDb()`
- `SetHComSts()`
- `SetHDevSt()`
- `SetHCmdFail()`
- `IncrementHCfgChCounter()`
- `IncrementHDevStCounter()`
- `ChannelHeartbeat()`
- `PostHComFail()`
- `PostHAlmOptChgEvent()`
- `ProcessHartEvents()`
- `ReceptionComplete()`
- `LogEvent()`
- `BuildScanTable()`
- `ControlStateChange()`
- `CheckDevMismatch()`
- `CheckRangeMismatch()`
- `WriteHCmdData()`
- `BumpPollingAddress()`
- `ScheduleFromInitTable()`
- `ScheduleFromScanTable()`
- `SetupScanMessage()`
- `SetupPassThrough()`
- `SetScanCounterForRediscovery()`
- `UpdateDatabase()`
- `GetHartLoading()`

All command Good/Bad handlers are present:

- `Cmd0GoodHandler()` / `Cmd0BadHandler()`
- `Cmd3GoodHandler()` / `Cmd3BadHandler()`
- `Cmd6GoodHandler()` / `Cmd6BadHandler()`
- `Cmd9GoodHandler()` / `Cmd9BadHandler()`
- `Cmd12GoodHandler()` / `Cmd12BadHandler()`
- `Cmd13GoodHandler()` / `Cmd13BadHandler()`
- `Cmd14GoodHandler()` / `Cmd14BadHandler()`
- `Cmd15GoodHandler()` / `Cmd15BadHandler()`
- `Cmd16GoodHandler()` / `Cmd16BadHandler()`
- `Cmd20GoodHandler()` / `Cmd20BadHandler()`
- `Cmd33GoodHandler()` / `Cmd33BadHandler()`
- `Cmd38GoodHandler()` / `Cmd38BadHandler()`
- `Cmd48GoodHandler()` / `Cmd48BadHandler()`
- `Cmd50GoodHandler()` / `Cmd50BadHandler()`
- `Cmd59GoodHandler()` / `Cmd59BadHandler()`
- `Cmd109GoodHandler()` / `Cmd109BadHandler()`

Pass-through names present:

- `clsHartPst::PassThroughTable(UINT8)`
- `g_ucHPstReqBuffer`
- `g_ucHPstRcvBuffer`
- `g_pucHPstRcvBuffer`
- `pHartPst`

RT1024 helper wrappers intentionally retained because `hart.cpp` uses them to bridge parsed FPGA/HART responses into the legacy DB:

- `HartDb_Clear()`
- `HartDb_UpdateFromCmd0()`
- `HartDb_UpdateDynamicFromCmd3()`
- `HartDb_UpdateCmd48Status()`
- `HartDb_UpdateCmd59Status()`
- `HartDb_HandleResponse()`
- `HartDb_GetPrimaryVariable()`

## `hartstack.cpp` comparison

All pure legacy HART stack class functions are present:

- `clsHartQueue::operator new()`
- `clsHartQueue::clsHartQueue()`
- `clsHartQueue::AddToQueue()`
- `clsHartQueue::RemoveFromQueue()`
- `clsHartQueue::ProcessQueue()`
- `clsHartQueue::IsModemQueueEmpty()`
- `clsHartModem::operator new()`
- `clsHartModem::clsHartModem()`
- `clsHartModem::Connect()`
- `clsHartModem::Disconnect()`
- `clsHartModem::Disconnect(BOOL)`
- `clsHartModem::SwitchMux()`
- `clsHartModem::HartMuxLoopbackTest()`
- `clsHartModem::DiagConnect()`
- `clsHartModem::ProcessDiagModem()`
- `clsHartModem::HartModemInterrupt()`
- `clsHartModem::HartModemHeartbeat()`
- `clsHartModem::SetState()`
- `clsHartModem::ModemTimeout()`
- `clsHartModem::TransmitRequest()`
- `clsHartModem::ProcessResponse()`
- `clsHartModem::DecodeResponse()`
- `clsHartModem::ActOnResponse()`
- `clsHartModem::SetupRetry()`
- `clsHartModem::HandleReceiveError()`

Legacy modem variable names added back into `clsHartModem`:

- `m_ucHartMuxEnbl`
- `m_usHartMuxAddr`
- `m_ucHDiagUnderRunCount`
- `m_ucFailedChannel`
- `m_sulMDiagCount`
- `m_cucpXmtBuffer`
- `m_ModemRcvBuffer`
- `m_ucPollingAddress`
- `m_UniqueAddress`
- `m_ucXmtCommand`
- `m_ucBytesInRequest`
- `m_ucBytesInResponse`
- `m_XmtRcvContext`
- `m_RcvMsgType`
- `m_RcvMsgStatus`
- `m_ucCheckSum`
- `m_ucRemPreambles`
- `m_ucRcvdDelimiter`
- `m_ucRetryCount`
- `m_bBurstDeviceFound`

`HART_LOG` remains removed. There are no `HART_LOG` or `HartLogSuppressed` references in the updated source.

The old code used memory-mapped `HART_UART(...)`, `HART_MUXADDR`, `HART_MUXENBL`, interrupt mask functions, and old slot callbacks. The updated code keeps the same source-facing names, but routes actual hardware access through the current working RT1024 FPGA path.

## Local build/symbol check performed

Because MCUXpresso/ARM toolchain headers are not available in this environment, I performed a host C++ build check of the changed HART files:

- `source/hart.cpp`
- `source/hartdb.cpp`
- `source/hartstack.cpp`

Host command style used:

```text
g++ -std=c++17 -Wall -Wextra -Wno-unused-parameter -Wno-unused-function \
    -I<stub_debug_console> -Isource -Isource/hal \
    -c source/hart.cpp

g++ -std=c++17 -Wall -Wextra -Wno-unused-parameter -Wno-unused-function \
    -I<stub_debug_console> -Isource -Isource/hal \
    -c source/hartdb.cpp

g++ -std=c++17 -Wall -Wextra -Wno-unused-parameter -Wno-unused-function \
    -I<stub_debug_console> -Isource -Isource/hal \
    -c source/hartstack.cpp
```

Then the three HART objects were linked with small test stubs for FPGA register access. The link completed with no unresolved HART-to-HART references. Remaining undefined symbols in the host ELF are normal C runtime functions only, such as `memset`, `memcpy`, and `printf`.

## Integration note

This update is intended to reduce integration-time errors such as:

- undefined HART stack methods
- missing `clsHartDevDb` command handlers
- missing pass-through table names
- missing legacy HART memory-storage names
- missing modem state/context fields used by old stack logic

The only not-added legacy methods are the old slot/box-slot member functions because their owning classes are outside this clean HART project.
