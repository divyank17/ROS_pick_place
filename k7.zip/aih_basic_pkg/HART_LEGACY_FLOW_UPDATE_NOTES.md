# AIH HART legacy-flow update

This package keeps the RT1024/FPGA hardware access from the working AIH project, but changes the HART module flow back toward the old source model.

## Main flow now

1. `CheckAndInitHart()` initializes HART and resets the HART UART/modem blocks.
2. `HartScanChannels(start,end)` scans logical channels.
3. For each channel, `InitHartConnection(channel)` adds the channel to `HartQueue`.
4. `ProcessHartInterrupt()` services the queue and calls `HartQueue.ProcessQueue(modem)`.
5. `clsHartQueue::ProcessQueue()` assigns the queued channel to the modem calculated by `HartGetModemForChannel(channel)`.
6. `clsHartModem::Connect(channel)` marks the modem active and selects the mux path.
7. The proven RT1024 transaction path runs:
   - CMD0 short address discovery
   - long address extraction
   - CMD48 optional status read
   - CMD3 PV dynamic value read
8. The CMD responses are passed through `HartDb_HandleResponse()` / old-style command handlers.
9. CMD3 stores PV in the old database path:
   - `clsHartDevDb::HDynVal[0]`
   - `clsHartDevDb::HDynEu[0]`
10. The final print uses the last route that successfully completed CMD3:
    - `HART_RESPONSE PV=<value> CHANNEL=<actual-channel> MODEM=<actual-modem>`

## Route behavior

The route is no longer accepted only because channel/modem macros say so.  A route is marked good only when CMD3 PV decode succeeds.

Channel-to-modem mapping:

- CH1..CH4 -> modem 0
- CH5..CH8 -> modem 1
- CH9..CH12 -> modem 2
- CH13..CH16 -> modem 3

## Print behavior

Normal HART logs are still disabled.  Only the final PV response line is printed when `HART_ENABLE_FINAL_RESPONSE_PRINT` is `1`.

## Files changed

- `source/hart.h`
- `source/hart.cpp`
- `source/hartstack.cpp`
- `source/pmio_kernel.cpp` kept using `HartScanChannels()` and final print.

