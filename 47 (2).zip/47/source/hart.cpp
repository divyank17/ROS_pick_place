/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hart.cpp                                                    *
*    Description : HART global data and functions.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/

#include "scheduler.hpp"
#include "hart.h"
#include "hartdb.hpp"
#include "hartstack.hpp"
#include "tracelog.hpp"
#include "fsl_debug_console.h"
#if defined(IOMTYPE_AIH)
#include "aihmain.h"
#endif
#include <string.h>

    // When the compiler first enters hart.cpp UIO_HART_GLOBAL and UIO_HART_SLOTS are not defined.
    // On first pass through hart.cpp define UIO_HART_GLOBAL to process Global Variables and Functions.
    // These are encapsulated by #ifndef UIO_HART_SLOTS and the comments "Start/End Global Variables and Functions".

    // On second pass through hart.cpp change the context by defining UIO_HART_SLOTS, IOMTYPE_AIH, and redefining 
    // SLOT(n) to AIH_SLOT(n). This will process all slot data members and functions conditionally compiled based 
    // on the IOM type. UIO_HART_SLOTS will direct the compiler to skip the Global Functions/Variables and process
    // just the functions encapsulated by #ifndef UIO_HART_GLOBAL and the comments "Start/End Slot Variables and Functions"
    // in the context of the AIH module.

    // On the third and final pass through hart.cpp UIO_HART_SLOTS and IOMTYPE_AIH are defined. Undefine IOMTYPE_AIH,
    // define IOMTYPE_AOH and redefine SLOT(n) to AOH_SLOT(n). This will again skip the Global Functions/Variables and process
    // just the functions encapsulated by #ifndef UIO_HART_GLOBAL and the comments "Start/End Slot Variables and Functions"
    // in the context of the AOH module.

#ifndef HART_SCAN_CHANNEL_START
#define HART_SCAN_CHANNEL_START                 (1u)
#endif

#ifndef HART_SCAN_CHANNEL_END
#define HART_SCAN_CHANNEL_END                   (16u)
#endif

#ifndef HART_DEFAULT_CHANNEL
#define HART_DEFAULT_CHANNEL                    HART_SCAN_CHANNEL_START
#endif

// UIO will compile this file with IOMTYPE_AIH and IOMTYPE_AOH defined.
// Intentionally preventing aihmain.h and aohmain.h from being included in those contexts.
#ifndef HART_DEFAULT_MODEM
#define HART_DEFAULT_MODEM                      ((UINT8)((HART_DEFAULT_CHANNEL - 1u) / 4u))
#endif

#if defined(IOMTYPE_AOH)
#include "aohmain.h"
#endif

#ifndef HART_POLL_ADDR_START
#define HART_POLL_ADDR_START                    (0u)
#endif

#ifndef HART_POLL_ADDR_END
#define HART_POLL_ADDR_END                      (0u)
#endif
/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
// Memory for HART channels receive buffers

#ifndef HART_MAXSLOTS
#define HART_MAXSLOTS 16u
#endif

UINT8  g_ucHChanRcvBuffer[HART_CHANBUFFER_SIZE * HART_MAXSLOTS];
UINT8 *g_pucHChanRcvBuffer = g_ucHChanRcvBuffer;
UINT8  g_ucHPstReqBuffer[HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];
clsHartPst *pHartPst[HPST_OBJECTCOUNT];
UINT16 g_usHPstObjMemory[CLSHARTPST_SIZE * HPST_OBJECTCOUNT];
UINT16 g_usModemObjectMemory[HARTMODEM_COUNT * CLSHARTMODEM_SIZE];
UINT16 g_usHartQueueObjectMemory[HARTMODEM_COUNT * CLSHARTQUEUE_SIZE];

static UINT8 g_runtimeLongAddr[HART_LONGADDR_LENGTH] = {0u, 0u, 0u, 0u, 0u};
static UINT8 g_runtimePollAddr = 0u;
static bool  g_haveLongAddr = false;

static UINT8 g_activeChannel = (UINT8)HART_DEFAULT_CHANNEL;
static UINT8 g_activeModem = (UINT8)HART_DEFAULT_MODEM;
static volatile BOOL g_hartPrintPending = FALSE;
static UINT8 g_hartPrintChannel = 0u;
static UINT8 g_hartPrintModem = 0u;
static FLOAT32 g_hartPrintPv = 0.0F;

/* HartTask runs every 250 ms. Eight quiet cycles reserve approximately two
 * seconds for a Control Builder database-write burst before HART resumes. */
#define HART_IOL_QUIET_CYCLES (8u)
static volatile UINT8 g_ucHartIolQuietCycles = HART_IOL_QUIET_CYCLES;

VOID HartDeferTransactions(VOID)
{
    g_ucHartIolQuietCycles = HART_IOL_QUIET_CYCLES;
}

/*******************************************************************************
*                               isHartCapable                                  *
*                               =============                                  *
* PURPOSE: Determine if the HW is HART capable                                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Called by aihmain and aohmain. Meaningless if it is called by di/do   *
*        If MUXADDR (0x80010) is Read Only, the module is Hartless             *
*******************************************************************************/
BOOL isHartCapable(VOID)
{
    return TRUE;
}

static BOOL HartPrimaryStateAllowsScanning(VOID)
{
    UINT8 ucDsa = BOX->GetDSA();
#if HART_ALLOW_DSA0
    if (ucDsa == 0u)
    {
        ucDsa = 1u;
    }
#endif
    return ((ucDsa > 0u) && (ucDsa <= MAXDSA)) ? TRUE : FALSE;
}

static VOID HartArmEnabledChannelStateMachines(VOID)
{
#if HART_STATE_MACHINE_AUTO_ARM
    if ((BOX == NULL) || (HartPrimaryStateAllowsScanning() == FALSE))
    {
        return;
    }

    for (UINT8 ucChannel = 1u; ucChannel <= MAXSLOTS; ucChannel++)
    {
        if (pDatabase[ucChannel] == NULL)
        {
            continue;
        }

        clsAihSlot *pSlot = SLOT(ucChannel);
        clsHartDevDb &HartDevDb = pSlot->GetHartDevDb();
        clsHartCfgDb &HartCfgDb = pSlot->GetHartCfgDb();

        if (HartCfgDb.HEnable == FALSE)
        {
            continue;
        }

        if ((HartDevDb.m_HChanMode == HCHANMODE_INIT) &&
            (HartDevDb.m_ucInitCmdIndex == 0u) &&
            (HartDevDb.m_sScanCounter == TICKS_DISABLE_SCAN))
        {
            HartDevDb.m_HDataInit = HDATAINIT_PENDING;
            HartDevDb.m_HEventInit = HEVENTINIT_PENDING;
            HartDevDb.m_ucPollingAddress = 0u;
            HartDevDb.m_ucNextReqCmd = HARTCMD0[0];
            HartDevDb.m_ucpNextXmtPtr = (UINT8 *)&HARTCMD0[0];
            HartDevDb.m_ucLastReqCmd = HARTCMD0[0];
            HartDevDb.m_ucpLastXmtPtr = (UINT8 *)&HARTCMD0[0];
            HartDevDb.m_sScanCounter =
                (INT16)(HART_STATE_MACHINE_REARM_TICKS + ((ucChannel - 1u) & 0x03u));
        }
    }
#endif
}

/*******************************************************************************
*                               CheckAndInitHart                               *
*                               ================                               *
* PURPOSE:      Initialize HART registers for HART modules                     *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is HART            *
*******************************************************************************/
VOID CheckAndInitHart(VOID){
    static BOOL bHartObjectsCreated = FALSE;

    HartInit();
    ResetHart();

    if (FALSE == bHartObjectsCreated)
    {
        for (UINT8 index = 0u; index < HPST_OBJECTCOUNT; index++)
        {
            pHartPst[index] = new(index) clsHartPst();
        }
        bHartObjectsCreated = TRUE;
    }

    HartArmEnabledChannelStateMachines();
}

/*******************************************************************************
*                               ResetHart                                      *
*                               =========                                      *
* PURPOSE:      Reset Hart UARTS                                               *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is Hartless        *
*******************************************************************************/
VOID ResetHart(VOID)
{
    HartStack_Reset();
    // HART modems are reset automatically at power-up.
}


/******************************************************************************
*                               TestHartAddressMux                            *
*                               ==================                            *
* PURPOSE:                                                                    *
*   Write to the H_MA register and readback what was written to verify that   *
*   the HART address multiplexer is working.                                  *
* ARGUMENTS:                                                                  *
*   NONE                                                                      *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   This diagnostic should only be run on the secondary.  The primary         *
*   performs a similar diagnostic when HART communication is initiated for    *
*   a channel.                                                                *
******************************************************************************/
VOID TestHartAddressMux(VOID)
{
    static UINT8 sucHartAddressMuxCurrentSlot = 1u;
    UINT8 modem = HartGetModemForChannel(sucHartAddressMuxCurrentSlot);
    UINT16 muxMask = (UINT16)(0x000Fu << (modem * 4u));
    UINT16 expectedAddr = (UINT16)((UINT16)((sucHartAddressMuxCurrentSlot - 1u) & 0x0Fu) << (modem * 4u));
    UINT8 expectedEnable = (UINT8)(1u << modem);

    hal_fpga_hart_mux_set16((UINT16)((HART_DEFAULT_MAR_CH1_M0 & (UINT16)(~muxMask)) | expectedAddr));
    hal_fpga_hart_mux_enable(expectedEnable);

    UINT16 readAddr = hal_fpga_hart_mux_get_addr16();
    UINT8 readEnable = hal_fpga_hart_mux_get_enable();

    if (((readAddr & muxMask) != expectedAddr) || ((readEnable & expectedEnable) == 0u))
    {
        if ((modem < HARTMODEM_COUNT) && (pHartModem[modem] != NULL))
        {
            // Read back failed...
            pHartModem[modem]->SetModemBad();
        }
    }

    sucHartAddressMuxCurrentSlot++;
    if (sucHartAddressMuxCurrentSlot > 16u)
    {
        sucHartAddressMuxCurrentSlot = 1u;
    }
}


#if HART_ENABLE_TASK_API
/*******************************************************************************
*                                    HartTask                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN HartTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_HARTTASK);

#if HART_ALLOW_DSA0
    if (BOX->GetDSA() > MAXDSA) {
#else
    if ((BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA)) {
#endif
        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
#if defined(IOMTYPE_UIO)
            if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT){
               AIH_SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
               AIH_SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
               AIH_SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
            }
            else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT){
               AOH_SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
               AOH_SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
               AOH_SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
            }
#else
            SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
#endif
        }
        
#if defined (IOMTYPE_UIO)
        // Test the HART address multiplexer for one channel everytime the
        // HART task runs (250ms) on the secondary.
        TestHartAddressMux();
#endif
    }

    HartArmEnabledChannelStateMachines();

    static UINT8 sucHChanToProcess = 1;
    const  UINT8 CHANNELS_PER_CYCLE = 4;

#if defined(IOMTYPE_UIO)
    // Regular HART processing is halted during factory HART testing
    if(FALSE == HartLoopBkTestInProgress)
    {
#endif
        for (UINT8 ucChan = 0; ucChan < CHANNELS_PER_CYCLE; ucChan++) 
        {
#if defined(IOMTYPE_UIO)
           UINT16 ChanToProcessOnBoard1 = sucHChanToProcess;
           UINT16 ChanToProcessOnBoard2 = sucHChanToProcess + SLOTSPERMODEM;
    
           // Process a channel on IoBoard1
           if(BOX->GetInitPntType(ChanToProcessOnBoard1) == PNTTYPE_ANALOGINPUT){
              AIH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ChannelHeartbeat();
              AIH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
           else if(BOX->GetInitPntType(ChanToProcessOnBoard1) == PNTTYPE_ANALOGOUTPUT){
              AOH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ChannelHeartbeat();
              AOH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
    
           // Process a channel on IoBoard2
           if(BOX->GetInitPntType(ChanToProcessOnBoard2) == PNTTYPE_ANALOGINPUT){
              AIH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ChannelHeartbeat();
              AIH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
           else if(BOX->GetInitPntType(ChanToProcessOnBoard2) == PNTTYPE_ANALOGOUTPUT){
              AOH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ChannelHeartbeat();
              AOH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
    
           sucHChanToProcess++;
    
#else
            SLOT(sucHChanToProcess)->GetHartDevDb().ChannelHeartbeat();
            SLOT(sucHChanToProcess++)->GetHartDevDb().ProcessHartEvents(FALSE);
#endif
        }
    
#if defined(IOMTYPE_UIO)
        // One channel on each board is processed every pass through HartTask().
        // After all the slots per modem are processed:
        //   1) Reset channel to process counter
        //   2) Compute Hart load HCUAVAIL at this time for each modem.
        //   3) For both modems, check if modem is idle, there are no requests from any channels, 
        //      module is primary and HartStack is currently is not processing FDM queue.  If all
        //      cases are true, set up pass through requests.
        if (sucHChanToProcess > SLOTSPERMODEM) {
            sucHChanToProcess = 1;
    
            for (int modem = 0; modem < HARTMODEM_COUNT; modem++) {
                // Update HCuAvail
                FLOAT32 fTotalHartLoad = 100.0;
    
                for (UINT8 ucChan = ((modem*SLOTSPERMODEM)+1); ucChan <= ((modem+1)*SLOTSPERMODEM); ucChan++) {
                    if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT) {
                        fTotalHartLoad -= AIH_SLOT(ucChan)->GetHartDevDb().GetHartLoading();
                    }
                    else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT) {
                        fTotalHartLoad -= AOH_SLOT(ucChan)->GetHartDevDb().GetHartLoading();
                    }
                }
                BOX->SetHCuAvail(fTotalHartLoad, modem);
            
                if ((TRUE == pHartQueue[modem]->IsModemQueueEmpty()) && 
                    (HMODEMSTATE_IDLE == pHartModem[modem]->GetModemState()) && 
                    (FALSE == pHartModem[modem]->IsHartStackProc()) &&
                    (!(BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA))) {
                    // Check for number of PST's available in PST queue
                    // If FDM sessions are present
                    if(BOX->PassthroughInQueue(modem) != FALSE) {
                        // Set up passthrough
                        BOX->SearchForPassthrough(modem);
                    }
                }
            }
        }
#else
        if (sucHChanToProcess > MAXSLOTS) {
            sucHChanToProcess = 1;
            
            // Update HCuAvail
            FLOAT32 fTotalHartLoad = 100.0;
            for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) { 
                fTotalHartLoad -= SLOT(ucChan)->GetHartDevDb().GetHartLoading();
            }
            BOX->SetHCuAvail(fTotalHartLoad);
        }
#endif

#if defined(IOMTYPE_UIO)
    }
    else
    {
       sucHChanToProcess = 1;
    }
#endif

    /*
     * IO-Link database writes have priority over the synchronous RT1024 HART
     * transport. The scheduler is cooperative, so do not begin another HART
     * transaction while a write is pending or during the short post-write
     * quiet period.
     */
    if (WriteMsgQueue.IsRcvBfrEmpty() == FALSE) {
        HartDeferTransactions();
    }
    else if (g_ucHartIolQuietCycles > 0u) {
        --g_ucHartIolQuietCycles;
    }
    else {
        ProcessHartInterrupt();
    }

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucReserved      = 0u;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
#endif
/*******************************************************************************
*                              InitHartConnection                              *
*                              ==================                              *
* PURPOSE:                                                                     *
*    Initiate a HART transaction.                                              *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel object number which requests connection.            *
* RETURN:                                                                      *
*    Boolean. TRUE if request is accepted; FALSE if rejected.                  *
* PROCESS:                                                                     *
*    1. Add a_pClient to the stack queue.                                      *
* NOTES:                                                                       *
*    1. This function is used by channel object to initiate HART transaction.  *
*    2. Modem objects periodically checks the stack queue and uses the client  *
*       reference and callback interface to carry out the HART transaction.    *
*******************************************************************************/
BOOL InitHartConnection(UINT8 a_ucChan) {
#if defined(IOMTYPE_UIO)   
    return pHartQueue[FPGA.GetChannelModem(a_ucChan)]->AddToQueue(a_ucChan);
#else
    return HartQueue.AddToQueue(a_ucChan);
#endif
}
/*******************************************************************************
*                             AbortHartConnection                              *
*                             ===================                              *
* PURPOSE:                                                                     *
*    Abort a previously initiated HART transaction.                            *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if transaction is aborted; FALSE if any transaction with    *
*    the specified client is not found.                                        *
* PROCESS:                                                                     *
*    1. Check the stack queue for the passed reference and remove from queue   *
*       if it is found.                                                        *
*    2. Otherwise check each modem object for their client references and      *
*       disconnect the modem if a match with the passed reference is found.    *
* NOTES:                                                                       *
*    1. Note that Disconnect method a private method in clsModem and cannot be *
*       called from here. Instead a request is made is to the modem object     *
*       which will be processed subsequently by the modem interrupt routines.  *
*       Disconnect need to be protected as private method to streamline the    *
*       modem state change.                                                    *
*******************************************************************************/
BOOL AbortHartConnection(UINT8 a_ucChan) {

#if defined(IOMTYPE_UIO)  
    // If the request is in the queue, remove it
    if (pHartQueue[FPGA.GetChannelModem(a_ucChan)]->RemoveFromQueue(a_ucChan) == TRUE) 
    {
        return TRUE;
    }
#else
    // If the request is in the queue, remove it
    if (HartQueue.RemoveFromQueue(a_ucChan) == TRUE) {
        return TRUE;
    }
#endif
    
    // If not in the queue, check whether any modem is 
    // processing it. If yes, disconnect and free the modem.
    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) {
        if (pHartModem[ucModem]->GetConnectedChannel() == a_ucChan) { 
            pHartModem[ucModem]->RequestDisconnect();
            return TRUE;
        }
    }

    // No match for the passed refence is found. Nothing to abort.
    return FALSE;
}
/*******************************************************************************
*                             ProcessHartInterrupt                             *
*                             ====================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID ProcessHartInterrupt(VOID)
{
    clsHartModem::HartModemHeartbeat();
}



#ifndef HART_ENABLE_REFRESH_SLOT_API
#define HART_ENABLE_REFRESH_SLOT_API 1
#endif

#if HART_ENABLE_REFRESH_SLOT_API
#if defined(IOMTYPE_AIH)
#include "aihmain.h"
#endif

#ifndef UIO_HART_GLOBAL
// ----------------------------------
// Start Slot Variables and Functions
// ----------------------------------

/*******************************************************************************
*                         clsAihSlot::GetRcvBufObject                          *
*                         clsAohSlot::GetRcvBufObject                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
clsClientBuffer& clsAihSlot::GetRcvBufObject(VOID) {
#endif
#ifdef IOMTYPE_AOH
clsClientBuffer& clsAohSlot::GetRcvBufObject(VOID) {
#endif
    if (HCHANTYPE_CHANNEL == HartDevDb.m_HChanType) {
        return HartDevDb.m_ChanRcvBuffer; 
    }
    else if (HCHANTYPE_PASSTHROUGH == HartDevDb.m_HChanType) {
#if defined(IOMTYPE_UIO)
        clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(ChanNum));
#endif
        return pHartPst[HartDevDb.m_ucPstRemIndex]->m_PstRcvBuffer;
    }
    else {
        HardFail(HF_INVPROGRAMEXEC,HART_CPP,__LINE__);
        // Return value is just to silence compiler.
        return HartDevDb.m_ChanRcvBuffer; 
    }
}
/*******************************************************************************
*                           clsAihSlot::PreCommand                             *
*                           clsAohSlot::PreCommand                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreCommand(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreCommand(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if ((*(COMMAND *)a_WriteBuffer < COMMAND_ACCEPTCFG) ||
        (*(COMMAND *)a_WriteBuffer > COMMAND_RESETHCOMERR)) {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostCommand                            *
*                           clsAohSlot::PostCommand                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostCommand(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostCommand(UINT8) {
#endif
    if (COMMAND_RESETHCOMERR == HartDevDb.Command) {
        HartDevDb.HComSts     = HCOMSTS_GOOD;
        HartDevDb.HLComFail   = HCOMSTS_GOOD;
        HartDevDb.HNComErr    = 0;
        HartDevDb.HCmdFail    = HARTCOMMAND_INVALID;
        HartDevDb.HCmdResp    = 0;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_EXCOMMERR_MASK;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_CMDFAIL_MASK;
#if defined (IOMTYPE_UIO)

        UINT8 modem = FPGA.GetChannelModem(ChanNum);

        // Only clear the modem status for the modem associated with this channel
        pHartModem[modem]->ClearModemBad();

        // Clear HART Chan Fail for all AI/AO channels associated with this modem
        for (UINT8 ucChan = ((modem*SLOTSPERMODEM)+1); ucChan <= ((modem+1)*SLOTSPERMODEM); ucChan++)
        {
            if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT)
            {
                AIH_SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
            }
            else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT)
            {
                AOH_SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
            }
        }
#else
        for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
        {
            pHartModem[ucModem]->ClearModemBad();
        }

        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++)
        {
            SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
        }
#endif
    }
    
    // No need to do anything for accept configuratoin as the controller 
    // is going to write HDVxxCD parameters to the IOM. PostHDevIdCd will 
    // take care resetting any mismatch alarms present.

    HartDevDb.Command = COMMAND_UNDEFINED;
}
/*******************************************************************************
*                           clsAihSlot::PreHEnable                             *
*                           clsAohSlot::PreHEnable                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHEnable(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHEnable(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (*(UINT8 *)a_WriteBuffer > TRUE) {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHEnable                            *
*                           clsAohSlot::PostHEnable                            *
*                           =======================                            *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHEnable(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHEnable(UINT8) {
#endif
    if ((PNTTYPE_NOTCONFIGURED != PntType) || BOX->GetHADCEnable(ChanNum)) { // if channel is configured or STAC ops
        if (TRUE == HartCfgDb.HEnable) {
#ifdef IOMTYPE_AIH
            // Sensor type is not loaded for HART enabled channels as it is
            // greyed out on the forms. Default it to 1 to 5V and execute
            // PostSensorTyp for initializing ADRaw and RawSpan correctly.
            SensrTyp = SENSRTYP_1to5_V;
            PostSensrTyp(ALVL_PBD);
            BOX->SetHADCStatus(ChanNum, HART_DATA_PENDING);
#endif
            if (HCHANMODE_INIT == HartDevDb.m_HChanMode) {
#ifdef IOMTYPE_AOH
                if (!isnan(OpFinal) && (OpFinal > OP_LOLIMIT))
#endif
                {
                    // Initialization commands not completed yet
                    HartDevDb.m_HDataInit = HDATAINIT_PENDING;
                    if (HartDevDb.m_ucInitCmdIndex < 1) {
                        // if first C48 is not complete yet
                        HartDevDb.m_HEventInit = HEVENTINIT_PENDING;
                    }
                }
            }

            UINT8 ucDsa = BOX->GetDSA();
#if HART_ALLOW_DSA0
            if (ucDsa == 0u) {
                ucDsa = 1u;
            }
#endif
            if ((ucDsa > 0) && (ucDsa <= MAXDSA)) {
                // IOM is primary is channel configued with HART enabled.
                // Start HART scanning in this cycle.
                HartDevDb.m_sScanCounter = TICKS_IN_1_SEC;
            }
        }
        else { // Channel configured with HART disabled.
            HartDevDb.InitDevDb(TRUE);
            BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
        }
    }
#ifdef IOMTYPE_AOH
    else // Channel deleted
        BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
#endif
}
/*******************************************************************************
*                           clsAihSlot::PreHAlarmEnable                        *
*                           clsAohSlot::PreHAlarmEnable                        *
*                           ===========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHAlarmEnable(UINT8 *a_WriteBuffer,UINT8 a_ucAccLvl) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHAlarmEnable(UINT8 *a_WriteBuffer,UINT8 a_ucAccLvl) {
#endif
    // Save current configuration
    ScratchPad = HartCfgDb.HAlarmEnable;

    if (ALVL_IUSER == a_ucAccLvl) {
        // If warm restore and checkpoint restore is 
        // going on accept the write value as it is.
        return PA_OK;
    }

    // Update the writebuffer according to write value coming down.
    switch (*a_WriteBuffer) {
    case HALARMENABLE_ALMENBSTATE_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_ALMENBSTATE_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_JOURNALONLY_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_JOURNALONLY_MASK;
        break;
    default:
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;
}
/*******************************************************************************
*                          clsAihSlot::PostHAlarmEnable                        *
*                          clsAohSlot::PostHAlarmEnable                        *
*                          ============================                        *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHAlarmEnable(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHAlarmEnable(UINT8) {
#endif
    // Check for bits changed in HAlarmEnable
    ScratchPad ^= HartCfgDb.HAlarmEnable;

    if (ScratchPad > 0) { // either or both bits got changed
        if (ScratchPad & HALARMENABLE_ALMENBSTATE_MASK) {
            // ALMENBSTATE bit changed
            if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) {
                // Alarms got enabled - regen current HART event state
                HartDevDb.m_bReReportEvents = TRUE;
            }
        }
        
        if (ScratchPad & HALARMENABLE_JOURNALONLY_MASK) {
            // JOURNALONLY bit changed
            if (0 == (HartCfgDb.HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK)) {
                // Alarms got unsuppressed - if ALENBSTATE is enabled 
                // then regen current HART event state.
                if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) {
                    HartDevDb.m_bReReportEvents = TRUE;
                }
            }
        }

        // Post appropriate alarm option change event.
        // Pass FALSE as argument for normal event reporting.
        HartDevDb.PostHAlmOptChgEvent(FALSE);
    }
}
/*******************************************************************************
*                           clsAihSlot::PreHScanCfg                            *
*                           clsAohSlot::PreHScanCfg                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHScanCfg(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHScanCfg(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (TRUE == HartCfgDb.HEnable) { 
        if ((*a_WriteBuffer > HSCANCFG_UNDEFINED) && 
            (*a_WriteBuffer <= HSCANCFG_STATUSONLY)) {
            return PA_OK;
        }
    }
    else if (HSCANCFG_UNDEFINED == *a_WriteBuffer) {
        return PA_OK;
    }

    return DO_ILLEGAL_VALUE;
}
/*******************************************************************************
*                           clsAihSlot::PostHScanCfg                           *
*                           clsAohSlot::PostHScanCfg                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHScanCfg(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHScanCfg(UINT8) {
#endif
    HartDevDb.BuildScanTable();
}
/*******************************************************************************
*                           clsAihSlot::PreHComThrs                            *
*                           clsAohSlot::PreHComThrs                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHComThrs(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHComThrs(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (0 == *(UINT16 *)a_WriteBuffer) {
        *(UINT16 *)a_WriteBuffer = 1;
        return DO_VALUE_CLAMPED_ERROR;
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PreHComHys                            *
*                            clsAohSlot::PreHComHys                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHComHys(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHComHys(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (*(UINT16 *)a_WriteBuffer > HartCfgDb.HComThrs) {
        *(UINT16 *)a_WriteBuffer = HartCfgDb.HComThrs;
    }
    
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHDevIdCd                           *
*                           clsAohSlot::PostHDevIdCd                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHDevIdCd(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHDevIdCd(UINT8) {
#endif
    HartDevDb.CheckDevMismatch();
#ifdef IOMTYPE_AIH
    HartDevDb.CheckRangeMismatch();
#endif
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd                            *
*                           clsAohSlot::PreHDvMfgCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvMfgCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvMfgCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvMfgCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd7                            *
*                           clsAohSlot::PreHDvMfgCd7                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvMfgCd7(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvMfgCd7(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if ((*(UINT16 *)HartCfgDb7.HDvMfgCd7) != *(UINT16 *)a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd                            *
*                           clsAohSlot::PreHDvTypCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvTypCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvTypCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvTypCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd7                           *
*                           clsAohSlot::PreHDvTypCd7                           *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvTypCd7(UINT8 *a_WriteBuffer,UINT8){
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvTypCd7(UINT8 *a_WriteBuffer,UINT8){
#endif
    if ((*(UINT16 *)HartCfgDb7.HDvTypCd7) != *(UINT16 *)a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvRevCd                            *
*                           clsAohSlot::PreHDvRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvRevCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDdRevCd                            *
*                           clsAohSlot::PreHDdRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDdRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDdRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDdRevCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHEuRngExt                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHEuRngExt(UINT8 *a_WriteBuffer,UINT8) {
    if (PTEXECST_INACTIVE != PtExecSt) {
        return DO_POINT_MUST_BE_INACTIVE;
    }

    for (UINT8 ucCount = 0; HEuRngExt[ucCount] > 0; ucCount++) {
        DATABYTES RangeData;
        for (UINT8 ucByte = 0; ucByte < sizeof(FLOAT32); ucByte++) {
            RangeData.ucBytes[ucByte] = *a_WriteBuffer++;
        }
        if (isnan(RangeData.f32Val)) return DO_SOURCE_OF_REQUEST_INVALID;
    }

    // If the above cheks passes, default the current value of ranges so that  
    // the individual pre functions will not fail with range cross-over error.
    PvEUHi = NaN;
    PvEULo = NaN;
    PvExEUHi = NaN;
    PvExEULo = NaN;
    
    return PA_OK;
}
#endif
#ifndef IOMTYPE_UIO
#ifdef IOMTYPE_AIH
/*******************************************************************************
*                          clsAihBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAihBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::PostHADCEnable(UINT8) {
    PNTTYPE PointType = SLOT(WriteIndex)->GetPntType();
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    SetAdcCycleCount(WriteIndex,0);
    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        // Save present value of HEnable
        HEnableSaved[WriteIndex - 1] = SLOT(WriteIndex)->GetHEnable();
        // If channel is loaded and HEnable is FALSE set it to TRUE
        if ((PNTTYPE_ANALOGINPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(TRUE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        // If channel is loaded restore old value of HEnable if it was FALSE
        if ((PNTTYPE_ANALOGINPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(FALSE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
    }
}
#endif // ifdef IOMTYPE_AIH
#ifdef IOMTYPE_AOH
/*******************************************************************************
*                          clsAohBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if (TRUE == SLOT(WriteIndex)->IsRedTagged())
        return DO_POINT_IS_RED_TAGGED;
    if (TRUE == HAutoDet[WriteIndex - 1])
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::PostHADCEnable(UINT8) {
    PNTTYPE PointType = SLOT(WriteIndex)->GetPntType();
    FLOAT32 fOp;
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        // Save present OP value
        Op_Saved[WriteIndex - 1] = GetOp(WriteIndex);
        // If there is not presently enough current
        // Drive output current to the minimum necessary for device discovery
        if (HART_AUTODETECT_OP > SLOT(WriteIndex)->GetOpFinal()) {
            fOp = HART_AUTODETECT_OP;
            if (TRUE == SLOT(WriteIndex)->GetOpChar()) fOp = SLOT(WriteIndex)->ChrcBkwrd(HART_AUTODETECT_OP);
            if (OPTDIR_REVERSE == SLOT(WriteIndex)->GetOptDir()) fOp = ((FLOAT32) 100.0) - fOp;
            SetOp(WriteIndex,fOp);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
        HEnableSaved[WriteIndex - 1] = SLOT(WriteIndex)->GetHEnable();
        // If channel is loaded and HEnable is FALSE set it to TRUE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(TRUE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        // If channel is loaded restore old value of HEnable if it was FALSE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(FALSE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
        // If channel current was forced to the min value restore it to old value
        if (HART_AUTODETECT_OP > Op_Saved[WriteIndex - 1]) {
            SetOp(WriteIndex,Op_Saved[WriteIndex - 1]);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
    }
}
/*******************************************************************************
*                          clsAohBoxSlot::PreHAutoDet                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHAutoDet(UINT8 *a_WriteBuffer,UINT8) {
#if defined(IOPTYPE_AO16)
	if (TRUE == *(BOOL *)a_WriteBuffer) {
		if (BOX->GetFtaPres() == FTA_MISSING) {
			return DO_INITIALIZATION_ERROR;
		}
	}
#else
	if ((TRUE == *(BOOL *)a_WriteBuffer) && 
        (PNTTYPE_NOTCONFIGURED != SLOT(WriteIndex)->GetPntType())) {
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    if (TRUE == HADCEnable[WriteIndex - 1]) {
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    }
#endif
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHAutoDet                         *
*                          ===========================                         *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsAohBoxSlot::PostHAutoDet(UINT8) {
    /* Removed the check of Primary Module to Fix
       PAR 1-2KSQYU: AO-HART secondary IOM momentarily goes to IDLE 
                     while loading a channel with HAUTODET
    */  
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);
    
    if (TRUE == HAutoDet[WriteIndex - 1]) {
        // Drive output current for auto detection.
        SetOp(WriteIndex,HART_AUTODETECT_OP); // Drive 3.2 mA for auto detection
        SetHADCStatus(WriteIndex,HART_DATA_PENDING);
        SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
    }
    else {
        SetOp(WriteIndex,OP_LOLIMIT); // Drive 0 mA at output
        // If auto detection is disabled, schedule scan counter for
        // four seconds. This helps in keeping the HART discovery 
        // information, if auto detection was disabled by a channel 
        // load operation and there is enough current for HART. If 
        // there is not enough current, HART database will be fully
        // initialized later.
        SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
    }
}
#endif // ifdef IOMTYPE_AOH
#endif // end ifndef IOMTYPE_UIO

// --------------------------------
// End Slot Variables and Functions
// --------------------------------
#endif // not UIO_HART_GLOBAL

#endif /* HART_ENABLE_REFRESH_SLOT_API */



static VOID HartClearRuntimeState(VOID)
{
    HartDb_Clear();
    g_haveLongAddr = false;
    g_runtimePollAddr = (UINT8)HART_POLL_ADDR_START;
    memset(g_runtimeLongAddr, 0, sizeof(g_runtimeLongAddr));
}

static VOID HartSetActiveRoute(UINT8 channel, UINT8 modem)
{
    if (channel < 1u)
    {
        channel = 1u;
    }

    if (channel > 16u)
    {
        channel = 16u;
    }

    if (modem > 3u)
    {
        modem = HartGetModemForChannel(channel);
    }

    g_activeChannel = channel;
    g_activeModem = modem;
    HartClearRuntimeState();
}

VOID HartSetRoute(UINT8 channel, UINT8 modem)
{
    if (channel < 1u)
    {
        channel = 1u;
    }
    if (channel > MAXSLOTS)
    {
        channel = MAXSLOTS;
    }
    if (modem >= HARTMODEM_COUNT)
    {
        modem = HartGetModemForChannel(channel);
    }

    g_activeChannel = channel;
    g_activeModem = modem;
}

UINT8 HartGetActiveChannel(VOID)
{
    return g_activeChannel;
}

static BOOL HartRunCommand(UINT8 command,
                           const UINT8 *data,
                           UINT8 dataLen,
                           HartParsedResponse_t *responseOut)
{
    HartParsedResponse_t localResponse;
    HartParsedResponse_t *rsp = (responseOut != NULL) ? responseOut : &localResponse;

    if (!g_haveLongAddr)
    {
        return FALSE;
    }

    for (UINT8 attempt = 0u; attempt < HART_MAX_RETRIES; attempt++)
    {
        if (!HartStack_RunLongCommand(g_activeChannel,
                                      g_activeModem,
                                      g_runtimePollAddr,
                                      g_runtimeLongAddr,
                                      command,
                                      data,
                                      dataLen,
                                      rsp))
        {
            continue;
        }

        if (HartStack_ResponseHasRequiredPayload(command, rsp) == FALSE)
        {
            /*
             * Command 3 is the dynamic-value publication gate and therefore
             * still requires its mandatory payload.  The remaining callers
             * are initialization-table commands.  A valid framed response to
             * one of those commands proves that the device and route are
             * alive, even if that optional database field was truncated.
             * Leave the corresponding legacy value at its initialized
             * default and continue the established initialization order.
             */
            if (command == HARTCOMMAND_THREE)
            {
                continue;
            }
            return TRUE;
        }

        if (command == HARTCOMMAND_THREE)
        {
            return (rsp->status0 == HART_RESPCODE_SUCCESS) ? TRUE : FALSE;
        }

        HREPLYSTATUS status = HartDb_HandleResponse(rsp);

        if ((status == HREPLYSTATUS_GOOD) || (status == HREPLYSTATUS_CONTINUE) ||
            (status == HREPLYSTATUS_MORE))
        {
            return TRUE;
        }
        if (status == HREPLYSTATUS_REINIT)
        {
            /*
             * HartRunCommand() is used here only by the synchronous RT1024
             * initialization adapter and by the strict Command 3 read below.
             * Keep the legacy handler result and HCmdFail/HCmdResp updates,
             * but do not turn a completed optional initialization response
             * into a transport failure that restarts CMD0 forever.  This is
             * the completion policy used by the hardware-proven transport
             * baseline; CMD0 discovery and Command 3 remain strict.
             */
            return (command == HARTCOMMAND_THREE) ? FALSE : TRUE;
        }
    }

    return FALSE;
}

static const UINT8 *HartGetInitCommand(UINT8 hartRevision, UINT8 index, UINT8 *rowSize)
{
    if (index >= HART_INITCOMMAND_COUNT)
    {
        if (rowSize != NULL)
        {
            *rowSize = 0u;
        }
        return NULL;
    }

    if (hartRevision >= HARTVERSION_7X)
    {
        if (rowSize != NULL)
        {
            *rowSize = sizeof(HART7_INIT_COMMANDS[0]);
        }
        return HART7_INIT_COMMANDS[index];
    }

    if (hartRevision >= HARTVERSION_6X)
    {
        if (rowSize != NULL)
        {
            *rowSize = sizeof(HART6_INIT_COMMANDS[0]);
        }
        return HART6_INIT_COMMANDS[index];
    }

    if (rowSize != NULL)
    {
        *rowSize = sizeof(HART5_INIT_COMMANDS[0]);
    }
    return HART5_INIT_COMMANDS[index];
}

static VOID HartBuildInitCommandData(UINT8 command,
                                     UINT8 hartRevision,
                                     UINT8 responsePreambles,
                                     UINT8 *data,
                                     UINT8 *dataLen)
{
    clsHartDevDb *db = HartDb_GetHartDevDb();

    if ((data == NULL) || (dataLen == NULL))
    {
        return;
    }

    *dataLen = 0u;
    data[0] = 0u;
    data[1] = 0u;

    switch (command)
    {
        case HARTCOMMAND_FIFTYNINE:
            data[0] = responsePreambles;
            if (data[0] < HART_MIN_PREAMBLES)
            {
                data[0] = HART_MIN_PREAMBLES;
            }
            *dataLen = 1u;
            break;

        case HARTCOMMAND_SIX:
            data[0] = g_runtimePollAddr;
            if (hartRevision <= HARTVERSION_5X)
            {
                *dataLen = 1u;
            }
            else
            {
                data[1] = HART_LOOP_CURRENT_ENABLED;
                *dataLen = 2u;
            }
            break;

        case HARTCOMMAND_THIRTYEIGHT:
            if ((hartRevision >= HARTVERSION_7X) && (db != NULL))
            {
                data[0] = db->HCmd0.str.ucusConfigChgCnt[0];
                data[1] = db->HCmd0.str.ucusConfigChgCnt[1];
                *dataLen = 2u;
            }
            break;

        case HARTCOMMAND_HUNDREDNINE:
            data[0] = HART_BURSTMODE_OFF;
            *dataLen = 1u;
            break;

        default:
            break;
    }
}

static BOOL HartRunInitCommandTable(UINT8 responsePreambles, UINT8 hartRevision)
{
    clsHartDevDb *db = HartDb_GetHartDevDb();

    if (db != NULL)
    {
        db->m_HChanMode = HCHANMODE_INIT;
        db->m_ucInitCmdIndex = 0u;
    }

    for (UINT8 index = 0u; index < HART_INITCOMMAND_COUNT; index++)
    {
        UINT8 rowSize = 0u;
        const UINT8 *row = HartGetInitCommand(hartRevision, index, &rowSize);
        UINT8 command;
        UINT8 data[2] = {0u, 0u};
        UINT8 dataLen = 0u;
        HartParsedResponse_t rsp;

        if ((row == NULL) || (rowSize < 2u))
        {
            continue;
        }

        command = row[0];

        /* Legacy skips Command 6 when the polling address is already zero. */
        if ((command == HARTCOMMAND_SIX) && (g_runtimePollAddr == 0u))
        {
            continue;
        }

        HartBuildInitCommandData(command, hartRevision, responsePreambles, data, &dataLen);

        if (db != NULL)
        {
            /* Match the legacy one-based initialization state. */
            db->m_ucInitCmdIndex = (UINT8)(index + 1u);
            db->m_ucLastReqCmd = command;
            db->m_ucpLastXmtPtr = (UINT8 *)row;
        }

        BOOL completed = HartRunCommand(command,
                                        (dataLen > 0u) ? data : NULL,
                                        dataLen,
                                        &rsp);

        /* CONTINUE responses from optional legacy commands are returned as
         * completed by HartRunCommand. FALSE means a communication failure
         * or a legacy REINIT result, so discovery must stop immediately. */
        if (completed == FALSE)
        {
            return FALSE;
        }

    }

    if (db != NULL)
    {
        /* Legacy completion is strictly greater than the table count. */
        db->m_ucInitCmdIndex = (UINT8)(HART_INITCOMMAND_COUNT + 1u);
        db->m_HChanMode = HCHANMODE_SCAN;
        db->m_sScanCounter = TICKS_IN_1_SEC;
        db->BuildScanTable();
    }

    return TRUE;
}

BOOL HartReadDynamicValues(VOID)
{
    HartParsedResponse_t cmd3;

    if (!HartRunCommand(HARTCOMMAND_THREE, NULL, 0u, &cmd3))
    {
        return FALSE;
    }

    if (cmd3.status0 != HART_RESPCODE_SUCCESS)
    {
        return FALSE;
    }

    if (!HartDb_UpdateDynamicFromCmd3(&cmd3))
    {
        return FALSE;
    }

    return TRUE;
}

VOID HartInit(VOID)
{
    g_activeChannel = (UINT8)HART_DEFAULT_CHANNEL;
    g_activeModem = (UINT8)HART_DEFAULT_MODEM;
    HartClearRuntimeState();
}

HARTDISCOVERYRESULT HartDiscover(VOID)
{
    HartParsedResponse_t cmd0;
    HartParsedResponse_t cmd48;
    UINT8 respPreambles = HART_DEFAULT_PREAMBLECOUNT;

    for (UINT8 pa = HART_POLL_ADDR_START; pa <= HART_POLL_ADDR_END; pa++)
    {
        if (!HartStack_GetCleanCmd0(g_activeChannel,
                                    g_activeModem,
                                    pa,
                                    &cmd0))
        {
            continue;
        }

        if (!HartStack_ExtractLongAddressFromCmd0(&cmd0, g_runtimeLongAddr, &respPreambles))
        {
            return HART_DISCOVERY_CMD0_OK;
        }

        g_runtimePollAddr = pa;
        g_haveLongAddr = true;

        if (!HartDb_UpdateFromCmd0(g_activeChannel, &cmd0))
        {
            return HART_DISCOVERY_CMD0_OK;
        }

        (void)cmd48;

#if !HART_RUN_INIT_COMMAND_TABLE_AFTER_PV
        if (!HartRunInitCommandTable(respPreambles, cmd0.hartRevision))
        {
            HartClearRuntimeState();
            continue;
        }
#endif

        if (!HartReadDynamicValues())
        {
            HartClearRuntimeState();
            continue;
        }

#if HART_RUN_INIT_COMMAND_TABLE_AFTER_PV
#if HART_ENABLE_FINAL_RESPONSE_PRINT
        HartReportDynamicResult(g_activeChannel, g_activeModem);
#endif
        if (!HartRunInitCommandTable(respPreambles, cmd0.hartRevision))
        {
            HartClearRuntimeState();
            continue;
        }
#endif

        return HART_DISCOVERY_COMPLETE;
    }

    return HART_DISCOVERY_FAILED;
}

HARTDISCOVERYRESULT HartDiscoverOnRoute(UINT8 channel, UINT8 modem)
{
    HARTDISCOVERYRESULT result;

    HartSetActiveRoute(channel, modem);
    result = HartDiscover();

    return result;
}

UINT8 HartGetModemForChannel(UINT8 logicalChannel)
{
    if (logicalChannel < 1u)
    {
        logicalChannel = 1u;
    }

    if (logicalChannel > 16u)
    {
        logicalChannel = 16u;
    }

    return (UINT8)((logicalChannel - 1u) / 4u);
}

static BOOL HartIsValidFloat(FLOAT32 value)
{
    return ((value == value) && (value > -2000000.0f) &&
            (value < 2000000.0f)) ? TRUE : FALSE;
}

static VOID HartFormatFloat3(FLOAT32 value, char *buffer, UINT32 bufferSize)
{
    INT32 scaled;
    UINT32 magnitude;
    UINT32 whole;
    UINT32 frac;
    UINT32 divisor = 1u;
    UINT32 wholeDigits = 1u;
    UINT32 index = 0u;

    if ((buffer == NULL) || (bufferSize == 0u))
    {
        return;
    }

    buffer[0] = '\0';
    if (HartIsValidFloat(value) == FALSE)
    {
        if (bufferSize >= 3u)
        {
            buffer[0] = 'N';
            buffer[1] = 'A';
            buffer[2] = '\0';
        }
        return;
    }

    scaled = (value >= 0.0f) ?
             (INT32)((value * 1000.0f) + 0.5f) :
             (INT32)((value * 1000.0f) - 0.5f);

    if (scaled < 0)
    {
        if ((index + 1u) >= bufferSize) { return; }
        buffer[index++] = '-';
        magnitude = (UINT32)(-(scaled + 1)) + 1u;
    }
    else
    {
        magnitude = (UINT32)scaled;
    }

    whole = magnitude / 1000u;
    frac = magnitude % 1000u;
    while ((whole / divisor) >= 10u)
    {
        divisor *= 10u;
        wholeDigits++;
    }

    if ((index + wholeDigits + 4u) >= bufferSize)
    {
        buffer[0] = '\0';
        return;
    }

    do
    {
        buffer[index++] = (char)('0' + ((whole / divisor) % 10u));
        divisor /= 10u;
    } while (divisor > 0u);

    buffer[index++] = '.';
    buffer[index++] = (char)('0' + ((frac / 100u) % 10u));
    buffer[index++] = (char)('0' + ((frac / 10u) % 10u));
    buffer[index++] = (char)('0' + (frac % 10u));
    buffer[index] = '\0';
}



VOID HartReportDynamicResult(UINT8 channel, UINT8 modem)
{
    FLOAT32 primaryValue;
    UINT8 primaryUnit = 0u;

    if ((HartDb_GetPrimaryVariableForChannel(channel, &primaryValue, &primaryUnit) == FALSE) ||
        (HartIsValidFloat(primaryValue) == FALSE))
    {
        return;
    }

    (void)primaryUnit;

    g_hartPrintChannel = channel;
    g_hartPrintModem = modem;
    g_hartPrintPv = primaryValue;
    g_hartPrintPending = TRUE;
}

VOID HartServiceLowPriorityPrint(VOID)
{
#if HART_ENABLE_FINAL_RESPONSE_PRINT
    static UINT8 waitSeconds = 0u;
    char pvText[24];

    if (waitSeconds > 0u)
    {
        waitSeconds--;
        return;
    }

    if (g_hartPrintPending == FALSE)
    {
        return;
    }

    g_hartPrintPending = FALSE;
    HartFormatFloat3(g_hartPrintPv, pvText, (UINT32)sizeof(pvText));
    PRINTF("HART CHANNEL=%d MODEM=%d PV=%s\r\n",
           (int)g_hartPrintChannel, (int)g_hartPrintModem, pvText);
    waitSeconds = (UINT8)HART_LOW_PRIORITY_PRINT_PERIOD_SEC;
#endif
}

VOID HartReportFinalResponse(UINT8 channel, UINT8 modem, HARTDISCOVERYRESULT result)
{
#if HART_ENABLE_FINAL_RESPONSE_PRINT
#if !HART_RUN_INIT_COMMAND_TABLE_AFTER_PV
    if (result == HART_DISCOVERY_COMPLETE)
    {
        HartReportDynamicResult(channel, modem);
    }
#else
    (void)channel;
    (void)modem;
    (void)result;
#endif
#else
    (void)channel;
    (void)modem;
    (void)result;
#endif
}
