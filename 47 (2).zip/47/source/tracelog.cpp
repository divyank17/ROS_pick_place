/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tracelog.cpp                                                *
*    Description : TraceLog class implementation.                              *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#if !defined(CPU_MIMXRT1024CAG4B)
#include <machine.h>
#endif
#include "utils.h"
#include "scheduler.hpp"
#include "tracelog.hpp"
#include "debug.hpp"
#include "boxslot.hpp"
#if defined(CPU_MIMXRT1024CAG4B)
#include "tracelog_flash.hpp"
#endif
/*******************************************************************************
*                            clsTraceLog::clsTraceLog                          *
*                            ========================                          *
*  Constructor. TraceLog Class Data members are initialize only when IOM is    *
*  power recycled. Trace memory is preserved so when it is restarted by        *
*  pressing reset button to recover from a hard failure.                       *
*******************************************************************************/
clsTraceLog::clsTraceLog(VOID)
{
#if !defined(CPU_MIMXRT1024CAG4B)
    if (FALSE == BOX->GetIomRebooted()) {
#else
    /* RT1024 restores the retained legacy object from U30 after SPI startup. */
    {
#endif
        // Initialize object only in case of power-on-restart.
        m_TraceLevel = 0;
        m_ucAppIndex = 0;
        pad = 0;

        for (UINT8 ucCount = 0; ucCount < NO_OF_TRACERECORDS; ucCount++) {
            TraceRecord[ucCount].code = 0;
            TraceRecord[ucCount].data = 0;
            TraceRecord[ucCount].time = 0;
        }

        clsBoxSlot::ResetTraceLogTime();

    #if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))

        m_pAppTraceLog = NULL;

    #endif

    }

#if defined(CPU_MIMXRT1024CAG4B)
    TraceLogFlashBind(&m_ucAppIndex, &m_TraceLevel, TraceRecord);
#endif
}
/*******************************************************************************
*                            clsTraceLog::AddToTrace                           *
*                            =======================                           *
*  Adds traces to the tracelog table and updates the append index.             *
*******************************************************************************/
VOID clsTraceLog::AddToTrace(TRACEID a_TraceId,IOBreadCrumb crumb,UINT32 data)
{
    if ((TRACEID_GENERIC == a_TraceId) || (a_TraceId & m_TraceLevel))
    {
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);  // Disable all interrupts

        UINT8 ucIndex = m_ucAppIndex;   // Reserve index for this log
        // Check for wrap around and update current index.
        // Do not allow to overwrite crash traces.
        m_ucAppIndex = (LASTTRACEINDEX <= m_ucAppIndex) ? 0 : (m_ucAppIndex+1);

        set_imask_exr(ucSaveExr);

        // Log the trace.
        TraceRecord[ucIndex].code = crumb;
        TraceRecord[ucIndex].data = data;
        TraceRecord[ucIndex].time = clsBoxSlot::GetTraceLogTime();
#if defined(CPU_MIMXRT1024CAG4B)
        TraceLogFlashMarkRecordDirty(ucIndex);
#endif
    }
}
/*******************************************************************************
*                          clsTraceLog::CopyCrashTraceBlock                    *
*                          ================================                    *
*  Copies the last 20 traces to crash block (records 80-100) which is an area  *
*  that will never be overwritten by the new traces. Called from HardFail.     *
*******************************************************************************/
VOID clsTraceLog::CopyCrashTraceBlock(VOID)
{
    UINT8 ucSrcIndex = 0,ucDstIndex = CRASHBLKSTARTINDEX;

    // If the latest trace index is greater than 20, the scenario is simple.
    // The last 20 traces are copied to the crash block (records 80-100).
    if ( m_ucAppIndex >= CRASHBLOCKSIZE )
    {
        // Start from the trace which is 20 traces away from current AppIndex.
        ucSrcIndex = m_ucAppIndex - CRASHBLOCKSIZE;
        while (ucDstIndex < NO_OF_TRACERECORDS)
        {
            TraceRecord[ucDstIndex].time = TraceRecord[ucSrcIndex].time;
            TraceRecord[ucDstIndex].code = TraceRecord[ucSrcIndex].code;
            TraceRecord[ucDstIndex++].data = TraceRecord[ucSrcIndex++].data;
        }
    }

    else
    {   // If the latest trace index is < 20, there may be a wrap around.

        if (TraceRecord[LASTTRACEINDEX].code > 0)
        {
            // A valid code at the last trace index means there was a wrap-
            // around and the last 20 traces are split at the end and
            // beginning of the array. First copy the older traces which are
            // at the end of the array.
            ucSrcIndex = (CRASHBLKSTARTINDEX - (CRASHBLOCKSIZE-m_ucAppIndex));

            while (ucSrcIndex < CRASHBLKSTARTINDEX)
            {
                TraceRecord[ucDstIndex].time = TraceRecord[ucSrcIndex].time;
                TraceRecord[ucDstIndex].code = TraceRecord[ucSrcIndex].code;
                TraceRecord[ucDstIndex++].data = TraceRecord[ucSrcIndex++].data;
            }
        }

        // Copy the newer traces which are at the beginning of the array.
        // NOTE: In the case where there was no wrap around, the loop below
        // starts with ucSrcIndex = 0 and ucDstIndex = CRASHBLKSTARTINDEX
        // and continues until (ucSrcIndex < m_ucAppIndex).
        // In the case where there was a wrap around, the loop starts with
        // the values determined by the previous while loop. In this case,
        // both conditions below go FALSE at the same time. ucDstIndex check
        // ensures that write never goes beyond allocated trace memory.
        while ((ucSrcIndex < m_ucAppIndex) && (ucDstIndex < NO_OF_TRACERECORDS))
        {
            TraceRecord[ucDstIndex].time = TraceRecord[ucSrcIndex].time;
            TraceRecord[ucDstIndex].code = TraceRecord[ucSrcIndex].code;
            TraceRecord[ucDstIndex++].data = TraceRecord[ucSrcIndex++].data;
        }
    }
#if defined(CPU_MIMXRT1024CAG4B)
    TraceLogFlashPersistCrashBlock();
#endif
}

#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))
/*******************************************************************************
*                          clsTraceLog::GetTracelog                            *
*                          ================================                    *
*                                                                              *
*  Redirects reads to app trace log based on trace level setting               *
*******************************************************************************/
VOID* clsTraceLog::GetTracelog(VOID)
{
    if((TRACEID_APPLOG & m_TraceLevel) && m_pAppTraceLog)
    {
        LockAppTraceLog();
        return m_pAppTraceLog->GetTracelog();
    }
    else
    {
        return TraceRecord;
    }
}
/*******************************************************************************
*                          clsTraceLog::GetLatestTraceIndex                    *
*                          ================================                    *
*                                                                              *
*  Redirects reads to app trace log based on trace level setting               *
*******************************************************************************/
UINT8 clsTraceLog::GetLatestTraceIndex(VOID)
{
    if((TRACEID_APPLOG & m_TraceLevel) && m_pAppTraceLog)
    {
        return m_pAppTraceLog->GetLatestTraceIndex();
    }
    else
    {
        return m_ucAppIndex;
    }
}
/*******************************************************************************
*                          clsTraceLog::LockAppTraceLog                        *
*                          ================================                    *
*                                                                              *
*  Ask app processor not to log        ...........................             *
*******************************************************************************/
VOID clsTraceLog::LockAppTraceLog(VOID)
{
    if(m_pAppTraceLog)
    {
        AutoUnlockCount = AUTO_UNLOCK_DELAY_COUNT;
        m_pAppTraceLog->SetFlags(COPY_IN_PROGRESS);
    }
}
/*******************************************************************************
*                          clsTraceLog::UnlockAppTraceLog                      *
*                          ================================                    *
*                                                                              *
*  Tell app processor it is free to log        ...........................     *
*******************************************************************************/
VOID clsTraceLog::UnlockAppTraceLog(VOID)
{
    if(m_pAppTraceLog)
    {
        AutoUnlockCount = 0;
        m_pAppTraceLog->ClearFlags(COPY_IN_PROGRESS);
    }
}
/*******************************************************************************
*                          clsTraceLog::LockTimeoutProc                      *
*                          ================================                    *
*                                                                              *
*  Tell app processor it is free to log        ...........................     *
*******************************************************************************/
VOID clsTraceLog::LockTimeoutProc(VOID)
{
    if(AutoUnlockCount > 0)
    {
        if(--AutoUnlockCount == 0)
        {
            UnlockAppTraceLog();
        }
    }
}

#endif // SP or SVP
/**/
