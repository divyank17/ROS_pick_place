/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
* ============================================================================ *
*    File Name   : tracelog_flash.cpp                                          *
*    Description : RT1024 external-flash adapter for the legacy TraceLog.       *
*******************************************************************************/
#include "tracelog_flash.hpp"

#if defined(CPU_MIMXRT1024CAG4B)

#include <string.h>
#include "utils.h"
#include "boxslot.hpp"
#include "fsl_debug_console.h"
#include "hal/hal_tracestore.h"

/*******************************************************************************
*                       EXTERNAL-FLASH STORAGE FORMAT                          *
*******************************************************************************/
#define TRACELOG_FLASH_MAGIC          (0x544C4F47u) /* "TLOG" */
#define TRACELOG_FLASH_VERSION        (2u)
#define TRACELOG_HEADER_A_ADDRESS     (0x0000u)
#define TRACELOG_HEADER_B_ADDRESS     (0x0020u)
#define TRACELOG_RECORDS_ADDRESS      (0x0040u)

#pragma pack(push, 1)
typedef struct tagTracePersistentHeader
{
    UINT32 Magic;
    UINT16 Version;
    UINT16 HeaderBytes;
    UINT32 Generation;
    UINT32 BootCount;
    UINT32 TraceTime;
    UINT8  AppIndex;
    UINT8  Reserved;
    UINT16 TraceLevel;
    UINT32 Crc32;
} TRACEPERSISTENTHEADER;
#pragma pack(pop)

static_assert(sizeof(TRACERECORD) == 10u,
              "TRACERECORD must retain the legacy 10-byte layout");
static_assert(sizeof(clsTraceLog) == 1004u,
              "clsTraceLog must retain the legacy AIH object layout");
static_assert(sizeof(TRACEPERSISTENTHEADER) == 28u,
              "Trace flash header layout changed");
static_assert((TRACELOG_RECORDS_ADDRESS +
               (NO_OF_TRACERECORDS * sizeof(TRACERECORD))) <=
              HAL_TRACESTORE_CAPACITY_BYTES,
              "Trace log exceeds logical flash-store capacity");

/*******************************************************************************
*                              ADAPTER STATE                                   *
*******************************************************************************/
static UINT8       *s_pucTraceAppIndex = NULL;
static UINT16      *s_pTraceLevel = NULL;
static TRACERECORD *s_pTraceRecord = NULL;

static UINT8  s_ucActiveHeader = 0u;
static UINT32 s_ulGeneration = 0u;
static UINT32 s_ulBootCount = 0u;
static BOOL   s_bFlashInitialized = FALSE;
static BOOL   s_bFlashReady = FALSE;
static BOOL   s_bFlashInitPassed = FALSE;
static BOOL   s_bRestoredExistingState = FALSE;

/* AddToTrace() only marks RAM records dirty. LowPriorityTask performs the
 * external SPI work so the legacy trace call path remains short. */
static volatile UINT8 s_aucRecordDirty[NO_OF_TRACERECORDS] = {0u};
static volatile BOOL  s_bHeaderDirty = FALSE;

#if TRACELOG_STARTUP_STATUS_PRINT
static BOOL s_bStartupStatusPrinted = FALSE;
#endif

/*******************************************************************************
*                              LOCAL HELPERS                                   *
*******************************************************************************/
static UINT32 TraceLogFlashCrc32(const UINT8 *a_pData, UINT32 a_ulLength)
{
    UINT32 ulCrc = 0xFFFFFFFFu;

    for (UINT32 ulIndex = 0u; ulIndex < a_ulLength; ++ulIndex)
    {
        ulCrc ^= a_pData[ulIndex];
        for (UINT8 ucBit = 0u; ucBit < 8u; ++ucBit)
        {
            const UINT32 ulMask = (UINT32)(0u - (ulCrc & 1u));
            ulCrc = (ulCrc >> 1) ^ (0xEDB88320u & ulMask);
        }
    }

    return ~ulCrc;
}

static BOOL TraceLogFlashHeaderIsValid(
    const TRACEPERSISTENTHEADER &a_Header)
{
    if ((a_Header.Magic != TRACELOG_FLASH_MAGIC) ||
        (a_Header.Version != TRACELOG_FLASH_VERSION) ||
        (a_Header.HeaderBytes != sizeof(TRACEPERSISTENTHEADER)) ||
        (a_Header.AppIndex > LASTTRACEINDEX))
    {
        return FALSE;
    }

    const UINT32 ulExpectedCrc = TraceLogFlashCrc32(
        reinterpret_cast<const UINT8 *>(&a_Header),
        (UINT32)(sizeof(TRACEPERSISTENTHEADER) - sizeof(a_Header.Crc32)));

    return (ulExpectedCrc == a_Header.Crc32) ? TRUE : FALSE;
}

static BOOL TraceLogFlashGenerationIsNewer(UINT32 a_ulLeft,
                                            UINT32 a_ulRight)
{
    return ((INT32)(a_ulLeft - a_ulRight) > 0) ? TRUE : FALSE;
}

static BOOL TraceLogFlashCommitHeader(VOID)
{
    if ((s_bFlashReady == FALSE) ||
        (s_pucTraceAppIndex == NULL) ||
        (s_pTraceLevel == NULL))
    {
        return FALSE;
    }

    TRACEPERSISTENTHEADER Header;
    TRACEPERSISTENTHEADER Verify;
    const UINT8 ucTarget = (UINT8)(s_ucActiveHeader ^ 1u);
    const UINT32 ulAddress = (ucTarget == 0u) ?
        TRACELOG_HEADER_A_ADDRESS : TRACELOG_HEADER_B_ADDRESS;

    memset(&Header, 0, sizeof(Header));
    Header.Magic = TRACELOG_FLASH_MAGIC;
    Header.Version = TRACELOG_FLASH_VERSION;
    Header.HeaderBytes = sizeof(TRACEPERSISTENTHEADER);
    Header.Generation = s_ulGeneration + 1u;
    Header.BootCount = s_ulBootCount;
    Header.TraceTime = clsBoxSlot::GetTraceLogTime();
    Header.AppIndex = *s_pucTraceAppIndex;
    Header.TraceLevel = *s_pTraceLevel;
    Header.Crc32 = TraceLogFlashCrc32(
        reinterpret_cast<const UINT8 *>(&Header),
        (UINT32)(sizeof(Header) - sizeof(Header.Crc32)));

    if (!hal_tracestore_write(ulAddress, &Header, sizeof(Header)) ||
        !hal_tracestore_read(ulAddress, &Verify, sizeof(Verify)) ||
        (memcmp(&Header, &Verify, sizeof(Header)) != 0))
    {
        return FALSE;
    }

    s_ulGeneration = Header.Generation;
    s_ucActiveHeader = ucTarget;
    return TRUE;
}

static BOOL TraceLogFlashInitializePersistentState(VOID)
{
    if ((s_pucTraceAppIndex == NULL) ||
        (s_pTraceLevel == NULL) ||
        (s_pTraceRecord == NULL))
    {
        return FALSE;
    }

    memset(s_pTraceRecord, 0,
           (size_t)NO_OF_TRACERECORDS * sizeof(TRACERECORD));
    *s_pucTraceAppIndex = 0u;
    *s_pTraceLevel = 0u;
    s_ulGeneration = 0u;
    s_ulBootCount = 1u;
    s_bRestoredExistingState = FALSE;
    clsBoxSlot::ResetTraceLogTime();
    s_ucActiveHeader = 1u; /* First commit targets header A. */

    if (!hal_tracestore_write(
            TRACELOG_RECORDS_ADDRESS,
            s_pTraceRecord,
            (size_t)NO_OF_TRACERECORDS * sizeof(TRACERECORD)))
    {
        s_bFlashReady = FALSE;
        return FALSE;
    }

    /* Initialize both alternating headers. */
    if ((TraceLogFlashCommitHeader() == FALSE) ||
        (TraceLogFlashCommitHeader() == FALSE))
    {
        s_bFlashReady = FALSE;
        return FALSE;
    }

    memset((void *)s_aucRecordDirty, 0, sizeof(s_aucRecordDirty));
    s_bHeaderDirty = FALSE;
    return TRUE;
}

static BOOL TraceLogFlashHasDirtyRecords(VOID)
{
    for (UINT8 ucIndex = 0u; ucIndex < NO_OF_TRACERECORDS; ++ucIndex)
    {
        if (s_aucRecordDirty[ucIndex] != 0u)
        {
            return TRUE;
        }
    }

    return FALSE;
}

/*******************************************************************************
*                        LEGACY TRACELOG HOOKS                                 *
*******************************************************************************/
VOID TraceLogFlashBind(UINT8 *a_pucAppIndex,
                       UINT16 *a_pTraceLevel,
                       TRACERECORD *a_pTraceRecord)
{
    s_pucTraceAppIndex = a_pucAppIndex;
    s_pTraceLevel = a_pTraceLevel;
    s_pTraceRecord = a_pTraceRecord;
}

VOID TraceLogFlashMarkRecordDirty(UINT8 a_ucIndex)
{
    if ((s_bFlashReady == FALSE) ||
        (s_pTraceRecord == NULL) ||
        (a_ucIndex >= NO_OF_TRACERECORDS))
    {
        return;
    }

    const UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    s_aucRecordDirty[a_ucIndex] = 1u;
    s_bHeaderDirty = TRUE;
    set_imask_exr(ucSaveExr);
}

VOID TraceLogFlashPersistCrashBlock(VOID)
{
    if ((s_bFlashReady == FALSE) || (s_pTraceRecord == NULL))
    {
        return;
    }

    const UINT32 ulAddress = TRACELOG_RECORDS_ADDRESS +
        ((UINT32)CRASHBLKSTARTINDEX * (UINT32)sizeof(TRACERECORD));

    if (hal_tracestore_write(
            ulAddress,
            &s_pTraceRecord[CRASHBLKSTARTINDEX],
            (size_t)CRASHBLOCKSIZE * sizeof(TRACERECORD)))
    {
        (void)TraceLogFlashCommitHeader();
    }
}

/*******************************************************************************
*                       RT1024 PLATFORM LIFECYCLE                              *
*******************************************************************************/
BOOL TraceLogFlashInit(VOID)
{
    if (s_bFlashInitialized != FALSE)
    {
        return s_bFlashInitPassed;
    }

    s_bFlashInitialized = TRUE;

    if ((s_pucTraceAppIndex == NULL) ||
        (s_pTraceLevel == NULL) ||
        (s_pTraceRecord == NULL))
    {
        return FALSE;
    }

    s_bFlashReady = hal_tracestore_init() ? TRUE : FALSE;
    if (s_bFlashReady == FALSE)
    {
        return FALSE;
    }

    TRACEPERSISTENTHEADER HeaderA;
    TRACEPERSISTENTHEADER HeaderB;
    const BOOL bReadA = hal_tracestore_read(
        TRACELOG_HEADER_A_ADDRESS, &HeaderA, sizeof(HeaderA)) ? TRUE : FALSE;
    const BOOL bReadB = hal_tracestore_read(
        TRACELOG_HEADER_B_ADDRESS, &HeaderB, sizeof(HeaderB)) ? TRUE : FALSE;
    const BOOL bValidA = (bReadA != FALSE) ?
        TraceLogFlashHeaderIsValid(HeaderA) : FALSE;
    const BOOL bValidB = (bReadB != FALSE) ?
        TraceLogFlashHeaderIsValid(HeaderB) : FALSE;
    const TRACEPERSISTENTHEADER *pSelected = NULL;

    if ((bValidA == FALSE) && (bValidB == FALSE))
    {
        s_bFlashInitPassed = TraceLogFlashInitializePersistentState();
        return s_bFlashInitPassed;
    }

    if ((bValidA != FALSE) &&
        ((bValidB == FALSE) ||
         TraceLogFlashGenerationIsNewer(
             HeaderA.Generation, HeaderB.Generation)))
    {
        pSelected = &HeaderA;
        s_ucActiveHeader = 0u;
    }
    else
    {
        pSelected = &HeaderB;
        s_ucActiveHeader = 1u;
    }

    if (!hal_tracestore_read(
            TRACELOG_RECORDS_ADDRESS,
            s_pTraceRecord,
            (size_t)NO_OF_TRACERECORDS * sizeof(TRACERECORD)))
    {
        return FALSE;
    }

    s_bRestoredExistingState = TRUE;
    *s_pucTraceAppIndex = pSelected->AppIndex;
    *s_pTraceLevel = pSelected->TraceLevel;
    s_ulGeneration = pSelected->Generation;
    s_ulBootCount = pSelected->BootCount + 1u;
    clsBoxSlot::RestoreTraceLogTime(pSelected->TraceTime);

    memset((void *)s_aucRecordDirty, 0, sizeof(s_aucRecordDirty));
    s_bHeaderDirty = FALSE;

    s_bFlashInitPassed = TraceLogFlashCommitHeader();
    return s_bFlashInitPassed;
}

VOID TraceLogFlashService(VOID)
{
    if ((s_bFlashReady == FALSE) || (s_pTraceRecord == NULL))
    {
        return;
    }

    UINT8 ucFlushed = 0u;

    for (UINT8 ucIndex = 0u;
         (ucIndex < NO_OF_TRACERECORDS) &&
         (ucFlushed < (UINT8)TRACELOG_FLASH_RECORDS_PER_SERVICE);
         ++ucIndex)
    {
        BOOL bWriteRecord = FALSE;

        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        if (s_aucRecordDirty[ucIndex] != 0u)
        {
            s_aucRecordDirty[ucIndex] = 0u;
            bWriteRecord = TRUE;
        }
        set_imask_exr(ucSaveExr);

        if (bWriteRecord == FALSE)
        {
            continue;
        }

        const UINT32 ulAddress = TRACELOG_RECORDS_ADDRESS +
            ((UINT32)ucIndex * (UINT32)sizeof(TRACERECORD));

        if (!hal_tracestore_write(
                ulAddress,
                &s_pTraceRecord[ucIndex],
                sizeof(TRACERECORD)))
        {
            ucSaveExr = get_imask_exr();
            set_imask_exr(LVLPRI_HIGHEST);
            s_aucRecordDirty[ucIndex] = 1u;
            s_bHeaderDirty = TRUE;
            set_imask_exr(ucSaveExr);
            return;
        }

        ++ucFlushed;
    }

    BOOL bCommitHeader = FALSE;
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    if ((s_bHeaderDirty != FALSE) &&
        (TraceLogFlashHasDirtyRecords() == FALSE))
    {
        s_bHeaderDirty = FALSE;
        bCommitHeader = TRUE;
    }
    set_imask_exr(ucSaveExr);

    if ((bCommitHeader != FALSE) &&
        (TraceLogFlashCommitHeader() == FALSE))
    {
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        s_bHeaderDirty = TRUE;
        set_imask_exr(ucSaveExr);
    }
}

VOID TraceLogPrintStartupStatus(VOID)
{
#if TRACELOG_STARTUP_STATUS_PRINT
    if (s_bStartupStatusPrinted != FALSE)
    {
        return;
    }

    s_bStartupStatusPrinted = TRUE;
    const UINT32 ulErrorCount = hal_tracestore_get_error_count();
    const BOOL bStatusOk =
        ((s_bFlashInitPassed != FALSE) &&
         (ulErrorCount == 0u)) ? TRUE : FALSE;

    PRINTF("TRACELOG %s JEDEC=%06X RESTORED=%u BOOT=%u ERR=%u\r\n",
           (bStatusOk != FALSE) ? "OK" : "ERROR",
           (unsigned int)hal_tracestore_get_jedec_id(),
           (unsigned int)s_bRestoredExistingState,
           (unsigned int)s_ulBootCount,
           (unsigned int)ulErrorCount);
#endif
}

#endif /* CPU_MIMXRT1024CAG4B */
