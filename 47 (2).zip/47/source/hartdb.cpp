/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hartdb.cpp                                                  *
*    Description : HART database implementation.                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <string.h>
#include <stdint.h>
#include "hartdb.hpp"
#ifdef IOMTYPE_AIH
    #include "aihmain.h"

static VOID memcopy(UINT8 *a_pDestination, const UINT8 *a_pSource, UINT32 a_ulLength)
{
    if ((a_pDestination != NULL) && (a_pSource != NULL) && (a_ulLength > 0u))
    {
        memcpy(a_pDestination, a_pSource, a_ulLength);
    }
}
#endif
#ifdef IOMTYPE_AOH
    #include "aohmain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif

static UINT8 HartGetEffectiveDsa(VOID);
static VOID HartDb_ReverseField(UINT8 *a_pData, UINT8 a_ucOffset, UINT8 a_ucLength, UINT8 a_ucPayloadLength);

const UINT8 clsHartCfgDb::HDevCd[] = {
    PARAMID_HDEVIDCD,
    PARAMID_HDVMFGCD,
    PARAMID_HDVTYPCD,
    PARAMID_HDEVIDCD,
    PARAMID_HDVREVCD,
    PARAMID_HDDREVCD,
    0 // Terminator
};

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
const UINT8 clsHartDevDb::HDvRngExt[] = {
    PARAMID_URV,
    PARAMID_LRV,
    PARAMID_URL,
    PARAMID_LRL,
    0 // Terminator
};
#endif

EVENTRECORD clsHartDevDb::HAlmOptChgEvent = {};
static clsHartDevDb *HartDb_GetChannelDevDb(UINT8 channel)
{
#if defined(IOMTYPE_AIH)
    if ((channel >= 1u) && (channel <= MAXSLOTS) && (pDatabase[channel] != NULL))
    {
        return &SLOT(channel)->GetHartDevDb();
    }
#endif
    return NULL;
}

UINT8 clsHartDevDb::m_stucNoOf1SecChannels = 0u;
const HARTCMDHANDLER clsHartDevDb::HartCmdHandler[] = {
    { &clsHartDevDb::Cmd0GoodHandler, &clsHartDevDb::Cmd0BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd3GoodHandler, &clsHartDevDb::Cmd3BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd6GoodHandler, &clsHartDevDb::Cmd6BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd9GoodHandler, &clsHartDevDb::Cmd9BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd12GoodHandler, &clsHartDevDb::Cmd12BadHandler },
    { &clsHartDevDb::Cmd13GoodHandler, &clsHartDevDb::Cmd13BadHandler },
    { &clsHartDevDb::Cmd14GoodHandler, &clsHartDevDb::Cmd14BadHandler },
    { &clsHartDevDb::Cmd15GoodHandler, &clsHartDevDb::Cmd15BadHandler },
    { &clsHartDevDb::Cmd16GoodHandler, &clsHartDevDb::Cmd16BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd20GoodHandler, &clsHartDevDb::Cmd20BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd33GoodHandler, &clsHartDevDb::Cmd33BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd38GoodHandler, &clsHartDevDb::Cmd38BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd48GoodHandler, &clsHartDevDb::Cmd48BadHandler },
    { NULL, NULL },
    { &clsHartDevDb::Cmd50GoodHandler, &clsHartDevDb::Cmd50BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd59GoodHandler, &clsHartDevDb::Cmd59BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd109GoodHandler, &clsHartDevDb::Cmd109BadHandler }
};
/*******************************************************************************
*                           HART pass-through storage                          *
*******************************************************************************/

UINT8 g_ucHPstRcvBuffer[HART_MAX_BYTECOUNT * HPST_OBJECTCOUNT];
UINT8 *g_pucHPstRcvBuffer = g_ucHPstRcvBuffer;

/*******************************************************************************
*                           clsHartPst::operator new                           *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsHartPst::operator new(size_t, UINT8 a_PstNo) {
    return (g_usHPstObjMemory + (a_PstNo * CLSHARTPST_SIZE));
}
/*******************************************************************************
*                            clsHartPst::clsHartPst                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsHartPst::clsHartPst(VOID) : m_PstRcvBuffer(HART_MAX_BYTECOUNT,g_pucHPstRcvBuffer) {
    m_ucHandle         = INVALID_HANDLE;
    m_ucSlotNumber     = INVALID_SLOTNUM;
    m_ucPstMsgTimeout  = 0; 
    m_PstStatus        = HPSTSTATUS_DEAD;

    // Advance the buffer pointer for next object
    g_pucHPstRcvBuffer += HART_MAX_BYTECOUNT;
}

/*******************************************************************************
*                         clsHartPst::PassThroughTable                         *
*                         ============================                         *
* PURPOSE:                                                                     *
*   Returns a pointer to the pass through table for the modem                  *
* ARGUMENTS:                                                                   *
*   a_ucModemNum - Modem number, 0-based                                       *
* RETURN:                                                                      *
*   Pointer to the pass through table.                                         *
* NOTES:                                                                       *
*   None                                                                       *
*******************************************************************************/
clsHartPst** clsHartPst::PassThroughTable(UINT8 a_ucModemNum)
{
#if defined(IOMTYPE_UIO)
    return pUioHartPst[a_ucModemNum];
#else
    (void)a_ucModemNum;
    return pHartPst;
#endif
}


/*******************************************************************************
*                             clsHartCfgDb::InitCfgDb                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartCfgDb::InitCfgDb(VOID) {
    HEnable     = FALSE;
    HScanCfg    = HSCANCFG_UNDEFINED;
    for (UINT8 ucCount = 0; ucCount < HART6_MAXVAR_COUNT; ucCount++) {
        HSlotDvc[ucCount] = 0;
    }
    HComThrs    = HCOMTHRS_DEFAULT;
    HComHys     = HCOMHYS_DEFAULT;
    HDvMfgCd    = 0;
    for (UINT8 ucCount = 0; ucCount < HART_DEVICEID_SIZE; ucCount++) {
        HDevIdCd[ucCount] = 0;
    }
    HDvTypCd    = 0;
    HDvRevCd    = 0;
    HDdRevCd    = 0;
    for (UINT8 ucCount = 0; ucCount < HNTFYCFG_BYTECOUNT; ucCount++) {
        HNtfyCfg[ucCount] = 0;
    }
    HAlarmEnable = HALARMENABLE_ALMENBSTATE_MASK;
    HAlarmEnableLrs = HALARMENABLE_ALMENBSTATE_MASK;
}

/*******************************************************************************
*                             clsHartCfgDb7::InitCfgDb                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartCfgDb7::InitCfgDb(VOID) {
    for (UINT8 ucCount = 0; ucCount < HART_MAXVAR_COUNT; ucCount++) {
        HSlotDvc7[ucCount] = 0;
    }
    HDvMfgCd7[0]= 0;
    HDvMfgCd7[1]= 0;
    HDvTypCd7[0]= 0;
    HDvTypCd7[1]= 0;
}
/*******************************************************************************
*                            clsHartDevDb::clsHartDevDb                        *
*                            ==========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsHartDevDb::clsHartDevDb(UINT8 a_ucChan,clsHartCfgDb *a_pHartCfgDb,
                                       clsHartCfgDb7 *a_pHartCfgDb7) : 
m_cucParent(a_ucChan),m_pHartCfgDb(a_pHartCfgDb),m_pHartCfgDb7(a_pHartCfgDb7),
m_ChanRcvBuffer(HART_CHANBUFFER_SIZE,g_pucHChanRcvBuffer) { 
    g_pucHChanRcvBuffer += HART_CHANBUFFER_SIZE;

    HComSts         = HCOMSTS_NORESPONSE;
    HLComFail       = HCOMSTS_NORESPONSE;
    HNComErr        = 0;
    HDynRate        = HSCANRATE_NONE;
    HDevRate        = HSCANRATE_NONE;
    Command         = COMMAND_UNDEFINED;

    m_ucLastDsa     = 0xFF;
    m_HDataInit     = HDATAINIT_PENDING;
    m_HEventInit    = HEVENTINIT_PENDING;

    InitDevDb(TRUE); 
    m_bAtLeastOneTry = FALSE;
    m_bHartChanFail = FALSE;

    HAlmOptChgEvent.Overflow      = FALSE;
    HAlmOptChgEvent.ContactCutout = FALSE;
    HAlmOptChgEvent.Qualifier     = EVENTTYPE_NORMAL;
    HAlmOptChgEvent.CurrentState  = EVENTSTATE_RETURN;
    HAlmOptChgEvent.EventPacket   = EVENTPACKET_SYSTEM;
    HAlmOptChgEvent.SystemEvent.SoftfailStatus = FALSE;
}


/*******************************************************************************
*                             clsHartDevDb::InitDevDb                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::InitDevDb(BOOL a_bCompleteInit) {
    UINT8 ucCount;
    
#if defined(IOMTYPE_UIO)
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(m_cucParent));
#endif

    if (TRUE == a_bCompleteInit) {
        m_HChanMode  = HCHANMODE_INIT;
        m_HChanType  = HCHANTYPE_CHANNEL;

        // Initialize scan realted members.
        for (ucCount = 0; ucCount < MAX_CYCLE_NUMBER; ucCount++) {
            for (UINT8 ucMsg = 0; ucMsg < MAX_MSGS_IN_A_CYCLE; ucMsg++) {
                m_ScanMsgTbl[ucCount][ucMsg] = HSCANMSG_NONE;
            }
        }
        m_sScanCounter    = TICKS_DISABLE_SCAN;
        m_ucScanNo        = MIN_CYCLE_NUMBER;
        m_ucSavedScanNo   = m_ucScanNo;
        m_ucB2BNo         = FIRST_SCAN_MSG;
        m_ucSkipC48Cycles = 0;

        // Initialize device attributes
        for (ucCount = 0; ucCount < HART_LONGADDR_LENGTH; ucCount++) {
            m_UniqueAddress.ucBytes[ucCount] = 0;
        }
        m_ucPollingAddress  = 0;
        m_ucHartVersion     = HARTVERSION_UNDEFINED;
        m_ucDeviceRevision  = 0;
        m_ucReqdPreambles   = HART_DEFAULT_PREAMBLECOUNT;

        // Initialize members for handling requests and responses
        m_ChanRcvBuffer.Flush();
        m_ucInitCmdIndex     = 0;
        m_ucPstAppIndex      = HPST_OBJECTCOUNT;
        m_ucPstRemIndex      = HPST_OBJECTCOUNT;
        m_ucB2BPstMsgCount   = 0;
        m_ucLastReqCmd       = HARTCMD0[0];
        m_ucpLastXmtPtr      = (UINT8 *)&HARTCMD0[0];
        m_ucLastRespCode     = HART_RESPCODE_SUCCESS;
        m_ucNextReqCmd       = HARTCMD0[0];
        m_ucpNextXmtPtr      = (UINT8 *)&HARTCMD0[0];
#if defined (IOMTYPE_UIO)
        m_ucpLastPstXmtPtr = NULL;
        m_ucpNextPstXmtPtr = NULL;
        m_ucLastPstCmd = HARTCMD0[0];
        m_ucNextPstCmd = HARTCMD0[0];
#endif
        m_ucRcvBufIndex      = 0;
        m_ucRcvMsgLen        = 0;
        m_ucDynScan[0]       = HARTCOMMAND_THREE;
        m_ucDevScan[0]       = HARTCOMMAND_THIRTYTHREE; 
        for (ucCount = 1; ucCount < HART_SCANMSG_SIZE; ucCount++) {
            m_ucDynScan[ucCount]  = 0;
            m_ucDevScan[ucCount]  = 0;
        }

        m_ucCommStatus            = HCOMSTS_NORESPONSE;
        m_ucDeviceStatus          = 0;
        m_ucSecMasterResetCounter = 0;
        m_ucScanOverrunCounter    = 0;
        m_ucPstPresentCounter     = 0;
        m_bCmd38FailReported      = FALSE;
        m_bCmd48FailReported      = FALSE;
        m_bReReportEvents         = FALSE;
        m_ucTemplateChangeWaitCount = 0;

        HART7_CMD38[0] = HARTCOMMAND_THIRTYEIGHT;
        HART7_CMD38[1] = HART_CMD38_RESPONSE_SIZE;
        for(ucCount = 0;ucCount < HART_CMD38_RESPONSE_SIZE; ucCount++) {
            HART7_CMD38[2 + ucCount] = 0;
        }
        /*
        HART7_CMD48[0] = HARTCOMMAND_FOURTYEIGHT;
        HART7_CMD48[1] = HART7_CMD48_REQUESTDATA_SIZE;
        for(ucCount = 0;ucCount < HART_CMD48_RESPONSE_SIZE; ucCount++) {
            HART7_CMD48[2 + ucCount] = 0;
        }
        */
        HT5_CfgChngCnt = 0;
        if ((BOX == NULL) || (HartGetEffectiveDsa() == 0u) || (FALSE == m_pHartCfgDb->HEnable)) {
            HNComErr = 0;
        }

        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);

        if ((BOX != NULL) && (HartGetEffectiveDsa() > 0u) && (HartGetEffectiveDsa() <= MAXDSA)) { // IOM is primary
            // Set communication status if it not already set
            if (HCOMSTS_GOOD == HComSts) {
                SetHComSts(HCOMSTS_NORESPONSE);
            }

            // Initialize HDevSt bytes. 
            SetHDevSt(0,0);
            BOX->SetHGDevSt(m_cucParent,0);
            // Make sure COMFAIL bit and EXCOMERR if exists, does not clear.
            if (HDevSt[1] & HART_DEVST1_EXCOMMERR_MASK) {
                SetHDevSt(1,(HART_DEVST1_COMMFAIL_MASK | HART_DEVST1_EXCOMMERR_MASK));
            }
            else {
                SetHDevSt(1,HART_DEVST1_COMMFAIL_MASK);
            }
            SetHDevSt(2,0);
            SetHDevSt(3,0);
        }
        else { // IOM is secondary.
            if (pDatabase[m_cucParent] != NULL) { AbortHartConnection(m_cucParent); } // abort any pending request
            // Clear device status and command 48 status and LRS bits.
            for (UINT8 ucCount = 0; ucCount < HART_DEVST_BYTECOUNT; ucCount++) {
                HDevSt[ucCount] = 0;
                HDevStLrs[ucCount] = 0;
            }
            for (UINT8 ucCount = 0; ucCount < HART_CMD48_RESPONSE_SIZE; ucCount++) {
                HCmd48.ucBytes[ucCount] = 0;
                HCmd48Lrs[ucCount] = 0;
            }
            m_HDataInit = HDATAINIT_PENDING;
            m_HEventInit = HEVENTINIT_PENDING;
            HComSts = HCOMSTS_NORESPONSE;
        }

        for (ucCount = 0; ucCount < HART_MAXDYNVAR_COUNT; ucCount++) {
            HDynDvc[ucCount] = HART_INVALID_PARAMETER_CODE;
        }

        // Initializae command data. NOTE: Passing NULL as second parameter
        // makes WriteHCmdData to initialize the command data structure.
        WriteHCmdData(HARTCOMMAND_ZERO,NULL);
        WriteHCmdData(HARTCOMMAND_TWELVE,NULL);
        WriteHCmdData(HARTCOMMAND_THIRTEEN,NULL);
        WriteHCmdData(HARTCOMMAND_FOURTEEN,NULL);
        WriteHCmdData(HARTCOMMAND_FIFTEEN,NULL);
        WriteHCmdData(HARTCOMMAND_SIXTEEN,NULL);
        WriteHCmdData(HARTCOMMAND_TWENTY,NULL);
        WriteHCmdData(HARTCOMMAND_FOURTYEIGHT,NULL);
        if (BOX != NULL) { BOX->InitHGCfgChgCnt(m_cucParent); }

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO)) 
        Lrv     = NaN;
        Urv     = NaN;
        Lrl     = NaN;
        Url     = NaN;
        Damping = NaN;
        StiEu   = MAXUINT8;
#endif

        // Initialize pass-through status table if any message is pending
        for (UINT8 ucPstIndex = 0; ucPstIndex < HPST_OBJECTCOUNT; ucPstIndex++) 
        {
            if ((pHartPst[ucPstIndex] != NULL) && (pHartPst[ucPstIndex]->m_ucSlotNumber == m_cucParent))
            {
                pHartPst[ucPstIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
                pHartPst[ucPstIndex]->m_PstStatus = HPSTSTATUS_DEAD;
            }
        }

        m_ulDynGoodCount = 0;
        m_ulDevGoodCount = 0;
        m_ulC48GoodCount = 0;
    }
    m_ScanMsg = HSCANMSG_NONE;
    for (ucCount = 0; ucCount < HART_MAXVAR_COUNT; ucCount++) {
        HSlotVal[ucCount]   = NaN;
        HSlotSt[ucCount]    = 0;
        HSlotCc[ucCount]    = 0;
        HSlotEu[ucCount]    = 0;
    }
    HDevSlot0DTS = 0;
    for (ucCount = 0; ucCount < HART_MAXDYNVAR_COUNT; ucCount++) {
        HDynVal[ucCount]    = NaN;
        HDynSt[ucCount]     = 0;
        HDynCc[ucCount]     = 0;
        HDynEu[ucCount]     = 0;
    }

    if ((pDatabase[m_cucParent] == NULL) || (SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED)) {
        // Clear device status and command 48 LRS bits 
        // only in case of point delete initializaiton.
        for (ucCount = 0; ucCount < HART_DEVST_BYTECOUNT; ucCount++) {
            HDevStLrs[ucCount] = 0;
        }
        for (ucCount = 0; ucCount < HART_CMD48_RESPONSE_SIZE; ucCount++) {
            HCmd48Lrs[ucCount] = 0;
        }
    }
}



/*******************************************************************************
*                             clsHartDevDb::SetHComSts                         *
*                             ========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::SetHComSts(HCOMSTS a_HComSts) {
    if (HCOMSTS_GOOD != a_HComSts) {
        if (TRUE == m_pHartCfgDb->HEnable) {
            BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_COMMSTATUS_BIT);
            BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_INITCMPLT_BIT);
            if (TRUE == m_bAtLeastOneTry) {
                // Set the communication failue bit only if the 
                // HART communciation was attempted at least once.
                HDevSt[1] |= HART_DEVST1_COMMFAIL_MASK;
            }
            m_HDataInit = HDATAINIT_COMPLETE;
            m_HEventInit = HEVENTINIT_COMFAIL;
            // if m_bReReportEvents is set, regen the ComFail event
            PostHComFail(m_bReReportEvents);
        }
#if defined(IOMTYPE_AIH)
        if ((FALSE == SLOT(m_cucParent)->GetHEnable()) && (PNTTYPE_NOTCONFIGURED != SLOT(m_cucParent)->GetPntType()))
            BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
        else if (0 == BOX->GetAdcCycleCount(m_cucParent))
            BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
        else
            BOX->DecAdcCycleCount(m_cucParent);
#endif
#if defined(IOMTYPE_AOH)
        if ((HART_AUTODETECT_OP > SLOT(m_cucParent)->GetOpFinal()) ||
                ((PNTTYPE_NOTCONFIGURED != SLOT(m_cucParent)->GetPntType())
                && (FALSE == SLOT(m_cucParent)->GetHEnable())))
            BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
        else if (0 == BOX->GetAdcCycleCount(m_cucParent))
            BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
        else
            BOX->DecAdcCycleCount(m_cucParent);
#endif
#if defined(IOMTYPE_UIO)
        PNTTYPE ChanType = BOX->GetInitPntType(m_cucParent);
        if (PNTTYPE_ANALOGINPUT == ChanType) {
            if (FALSE == AIH_SLOT(m_cucParent)->GetHEnable())
                BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
            else if (0 == BOX->GetAdcCycleCount(m_cucParent))
                BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
            else
                BOX->DecAdcCycleCount(m_cucParent);
        }
        else if (PNTTYPE_ANALOGOUTPUT == ChanType) {
            if ((HART_AUTODETECT_OP > AOH_SLOT(m_cucParent)->GetOpFinal()) ||
                (FALSE == AOH_SLOT(m_cucParent)->GetHEnable()))
                BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
            else if (0 == BOX->GetAdcCycleCount(m_cucParent))
                BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
            else
                BOX->DecAdcCycleCount(m_cucParent);
        }
#endif
    }
    else {
        HDevSt[1] &= ~HART_DEVST1_COMMFAIL_MASK;
        if (TRUE == m_pHartCfgDb->HEnable) {
            BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_COMMSTATUS_BIT);
        }
    }

    if (HCOMSTS_GOOD != HComSts) {
        // Transfer only bad status to HLComFail.
        HLComFail = HComSts;
    }
    HComSts = a_HComSts;
}
/*******************************************************************************
*                             clsHartDevDb::SetHDevSt                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::SetHDevSt(UINT8 a_ucIdx,UINT8 a_ucSts) {
    if (FALSE == m_bAtLeastOneTry) {
        // if HART communication was not attempted even once,
        // do not set the communication failure bit.
        a_ucSts &= ~HART_DEVST1_COMMFAIL_MASK;
    }
    if (TRUE == m_pHartCfgDb->HEnable) {
        if ((0 == a_ucIdx) && (HDevSt[0] != a_ucSts)) {
            IncrementHDevStCounter();
        }
        HDevSt[a_ucIdx] = a_ucSts;
    }
    else { // if HART disabled clear all HDevSt bits
        HDevSt[a_ucIdx] = 0;
    }
}
/*******************************************************************************
*                             clsHartDevDb::SetHCmdFail                        *
*                             =========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::SetHCmdFail(HARTCOMMAND a_HartCmd,UINT8 a_ucRespCode) {
    if (HARTCOMMAND_INVALID == a_HartCmd) {
        HDevSt[1] &= ~HART_DEVST1_CMDFAIL_MASK;
    }
    else if ((TRUE == m_pHartCfgDb->HEnable) && 
        (HART_RESPCODE_CMD_NOT_IMPLEMENTED != a_ucRespCode)) {
        HDevSt[1] |= HART_DEVST1_CMDFAIL_MASK;
    }

    HCmdFail = a_HartCmd;
    HCmdResp = a_ucRespCode;
}
/*******************************************************************************
*                       clsHartDevDb::IncrementHCfgChCounter                   *
*                       ====================================                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::IncrementHCfgChCounter(VOID) {
    // Flip least significant bit
    BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_CONFIGCOUNT_BIT0);
    // Flip most significant bit if least significant bit turned OFF 
    if (BOX->GetHGChngFlBit(m_cucParent,HGCHNGFL_CONFIGCOUNT_BIT0) == 0) {
        BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_CONFIGCOUNT_BIT1);
    }
}
/*******************************************************************************
*                       clsHartDevDb::IncrementHDevStCounter                   *
*                       ====================================                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::IncrementHDevStCounter(VOID) {
    // Flip least significant bit
    BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_STATUSCOUNT_BIT0);
    // Flip most significant bit if least significant bit turned OFF 
    if (BOX->GetHGChngFlBit(m_cucParent,HGCHNGFL_STATUSCOUNT_BIT0) == 0) {
        BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_STATUSCOUNT_BIT1);
    }
}

static UINT8 HartGetEffectiveDsa(VOID)
{
    if (BOX == NULL)
    {
        return 0u;
    }

    UINT8 ucDsa = BOX->GetDSA();
#if HART_ALLOW_DSA0
    if (ucDsa == 0u)
    {
        ucDsa = 1u;
    }
#endif
    return ucDsa;
}

/*******************************************************************************
*                         clsHartDevDb::ChannelHeartbeat                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
*    Perform HART channel processing activities periodically once every second.*
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Decrement scan counter. If the scan counter decrements to 0, add the   *
*       request for next transaction to the queue.                             *
*    2. Verify current requirements and make sure that this is the primary IOM *
*       before requesting modem services.                                      *
*    3. If request is successfully queued, setup transmit buffer pointer for   *
*       the current transaction and scan counter for next period. Otherwise,   *
*       setup scan counter for retry in the next cycle. Update scan overrun    *
*       alarm status.                                                          *
* NOTES:                                                                       *
*    1. This method is called HartTask once every second.                      *
*    2. To optimize the load, 4 channels processed at every quarter second     *
*       interval, resulting in one second processing per channel.              *
*******************************************************************************/
VOID clsHartDevDb::ChannelHeartbeat(VOID) {
    //set_imask_exr(LVLPRI_HART);

#if defined(IOMTYPE_UIO)
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(m_cucParent));
#endif

    if (m_bHartChanFail == TRUE)
    {
        // If HART channel failure is detected, initialize the HART live database
        // report softfail and discontinue all HART scanning for this channel.
        InitDevDb(TRUE);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_HARTCHANFAIL, TRUE, m_cucParent);
        return;
    }
    else
    {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_HARTCHANFAIL, FALSE, m_cucParent);
    }

    UINT8 ucDsa = HartGetEffectiveDsa();
    if (ucDsa != m_ucLastDsa) { // IOM configuration changed
        m_ucLastDsa = ucDsa;
        if (0 == ucDsa) { // IOM is secondary now
            InitDevDb(TRUE);
        }

        if ((ucDsa > 0) && (ucDsa <= MAXDSA)) {
            // If IOP is now configured as primary.
            BuildScanTable();

            if (SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED) { 
                // If channel block is not configured schedule discovery
                // according to the channel location after 16 seconds.
                // Channel number is used to scatter discovery scheduling
                // in case a number of unconfigured channels exists.
                m_sScanCounter = TICKS_IN_16_SEC + (m_cucParent * TICKS_IN_4_SEC); 
            }
            else { // if channel configuration is present 
                if (TRUE == m_pHartCfgDb->HEnable) {
                    // Schedule discovery according to the configured rates.
                    if (HTotalRate >= HSCANRATE_2SEC) {
                        m_sScanCounter = TICKS_IN_1_SEC;
                    }
                    else if (HTotalRate == HSCANRATE_4SEC) {
                        m_sScanCounter = TICKS_IN_2_SEC;
                    }
                    else { // if less than four second rate 
                        m_sScanCounter = TICKS_IN_4_SEC;
                    }
                }
                // For handling the case where HART is disabled, all
                // transactions are already disabled.
            }
        }
    } // IOM load or unload

#if (defined(IOPTYPE_HLAI) || defined(IOMTYPE_AIH))
	// fix for reopened PAR 1-DVVRRFR (HLAIH) (continous detection)
	if ((SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED)
	&& (FALSE == m_pHartCfgDb->HEnable)
	&& (m_sScanCounter < 1)) {

		BOX->SetHADCStatus(m_cucParent, HART_DATA_PENDING);
		m_sScanCounter = TICKS_IN_16_SEC +(m_cucParent * TICKS_IN_4_SEC);
	}
#elif defined(IOPTYPE_AO16)
	// fix for reopened PAR 1-DVN1QD5 (continous detection)
	if ((SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED)
		&& (FALSE == m_pHartCfgDb->HEnable)
		&& (TRUE == BOX->GetHAutoDet(m_cucParent))
		&& (m_sScanCounter < 1)) {
		// Drive output current for auto detection.
		BOX->SetHADCStatus(m_cucParent, HART_DATA_PENDING);
		m_sScanCounter = TICKS_IN_1_SEC;
	}
#endif

    // Check and update excessive communication alarm status
    if ((m_pHartCfgDb->HComThrs > 0) && (HNComErr >= m_pHartCfgDb->HComThrs) &&
        (HNComErr < HART_COMMERROR_MAXCOUNT) && (TRUE == m_pHartCfgDb->HEnable)) {
        HDevSt[1] |= HART_DEVST1_EXCOMMERR_MASK;
    }
    else {
        HDevSt[1] &= ~HART_DEVST1_EXCOMMERR_MASK;
    }

    // Decrement passthrough present throttling counter. This counter is used
    // to delay device re-discovery when passthrough is being processed.
    if (m_ucPstPresentCounter > 0) {
        m_ucPstPresentCounter--;
    }

    // Check secondary master reset counter and post/clear secondary master 
    // alarm bit in the device status byte. Clear the counter in case of 
    // commmunicaiton failure also.
    if ((m_ucSecMasterResetCounter > 0) &&  (HCOMSTS_GOOD == HComSts)) {
        HDevSt[1] |= HART_DEVST1_SECMASTER_MASK;
        BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_SECMASTER_BIT);
        m_ucSecMasterResetCounter--;
    }
    else {
        m_ucSecMasterResetCounter = 0;
        HDevSt[1] &= ~HART_DEVST1_SECMASTER_MASK;
        BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_SECMASTER_BIT);
    }

    // Update HGChngFl init complete and PST status bits. This is required to be done
    // periodically as the HGCHNGFL bit may not have been updated if the HENABLE was
    // not set, when the actual init was complete or controls state change occurred.
    if ((HartGetEffectiveDsa() > 0) && (HartGetEffectiveDsa() <= MAXDSA) && (TRUE == m_pHartCfgDb->HEnable)) {
        if (m_ucInitCmdIndex > HART_INITCOMMAND_COUNT) {
            BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_INITCMPLT_BIT);
        }

        if ((BOX->GetModuleStatus() == MODSTATUS_RUN) &&
            (SLOT(m_cucParent)->GetPtExecSt() == PTEXECST_ACTIVE)) {
            BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_PSTSTATUS_BIT);
        }
        else { // inactive or idle
            BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_PSTSTATUS_BIT);
        }
    }
    else { // Module is secondary or HART is not enabled - zero out HGCHNGFL bit
        BOX->InitHGChngFl(m_cucParent);

    }
    if ((HartGetEffectiveDsa() > 0) && (HartGetEffectiveDsa() <= MAXDSA) && (m_ucInitCmdIndex > HART_INITCOMMAND_COUNT))
        BOX->SetHADCStatus(m_cucParent, HART_DATA_AVAILABLE);
#if defined(IOMTYPE_UIO)
    if (BOX->GetInitPntType(m_cucParent) == PNTTYPE_ANALOGOUTPUT) {
        // Stop AO16H transaction if OpFinal is less than or equal to  -6.9%. 
        FLOAT32 fOpFinal = AOH_SLOT(m_cucParent)->GetOpFinal();
        if (isnan(fOpFinal) || (fOpFinal <= OP_LOLIMIT)) {
            AbortHartConnection(m_cucParent); // abort any pending request
            if ((HartGetEffectiveDsa() > 0) && (HartGetEffectiveDsa() <= MAXDSA)) {
                SetHComSts(HCOMSTS_NORESPONSE);
                InitDevDb(TRUE);

                // Schedule next scan depending on configuration.
                SetScanCounterForRediscovery(SLOT(m_cucParent)->GetPntType());
            }

            return;

        }
    }
#endif

#ifdef IOMTYPE_AOH
    // Stop AO16H transaction if OpFinal is less than or equal to  -6.9%. 
    FLOAT32 fOpFinal = SLOT(m_cucParent)->GetOpFinal();
    if (isnan(fOpFinal) || (fOpFinal <= OP_LOLIMIT)) {
        if (TRUE == BOX->GetHAutoDet(m_cucParent)) {
            // This situation can come after a IOM switch over since 
            // PostHAutoDet does not get called when HAUTODET value gets dumped. 
            BOX->SetOp(m_cucParent,HART_AUTODETECT_OP); 
            SLOT(m_cucParent)->GetHartDevDb().BuildScanTable();
            SLOT(m_cucParent)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
        else {
            AbortHartConnection(m_cucParent); // abort any pending request
            if ((HartGetEffectiveDsa() > 0) && (HartGetEffectiveDsa() <= MAXDSA)) {
                SetHComSts(HCOMSTS_NORESPONSE);
                InitDevDb(TRUE);

                // Schedule next scan depending on configuration.
                // AF:  How does UIO handle rediscovery if the channel is unconfigured??  AOH sets m_sScanCounter = TICKS_IN_60_SEC;
                SetScanCounterForRediscovery(SLOT(m_cucParent)->GetPntType());
            }

            return;
        }
    }

#ifdef DEBUG
    // If a DSA is assigned and current is driven using debug terminal, do not enable
    // HART auto device detection to kick-in. Otherwise it will affect hardware teams
    // measurements when they use pset and drvop commands during chamber testing. This 
    // check need to be done only in debug modes since the current will not be driven
    // without configuring a channel in release modes.
    if ((FALSE == BOX->GetHAutoDet(m_cucParent)) && (FALSE == m_pHartCfgDb->HEnable)) {
        InitDevDb(TRUE);
        return;
    }
#endif
#endif

    if (m_sScanCounter > 0) {
        m_sScanCounter--;

        if (0 == m_sScanCounter) {
            HSCANMSG NewMsg = HSCANMSG_NONE;
            if (HCHANMODE_SCAN == m_HChanMode) { // Start processing scan table.
                m_ucScanNo++;                
                if (m_ucScanNo > MAX_CYCLE_NUMBER) {
                    m_ucScanNo = MIN_CYCLE_NUMBER;
                }
                NewMsg = SetupScanMessage(m_ucScanNo,FIRST_SCAN_MSG);
                if (HSCANMSG_NONE == NewMsg) {
                    // If no scan is configured for this cycle, setup
                    // scan counter for the next one second interval.
                    m_sScanCounter = TICKS_IN_1_SEC;
#if defined (IOMTYPE_UIO)
                    // Decrement overrun counter.
                    if (m_ucScanOverrunCounter > 0) {
                        m_ucScanOverrunCounter--;
                    }

                    if (m_ucScanOverrunCounter == 0) {
                        // If scan overrun count is now zero, 
                        // return scan overrun alarm to normal.
                        HDevSt[1] &= ~HART_DEVST1_SCANOVRUN_MASK;
                    }
#endif
                    return;
                }
            }
            // else CHANMODE is INIT and a command from initialization table
            // would have already been setup.

            // Do not initiate HART communication if this is not primary IOM or 
            // if this is a pure analog channel (configured but HART disabled).
#if defined(IOPTYPE_AO16)
			// fix for PAR 1-DVN1QD5 (AO16H)
            if ((HartGetEffectiveDsa() < 1) || (HartGetEffectiveDsa() > MAXDSA) ||
                ((FALSE == m_pHartCfgDb->HEnable) && 				 
				 (SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED) &&
				 (FALSE == BOX->GetHAutoDet(m_cucParent)))) {
#elif (defined(IOPTYPE_HLAI) || defined(IOMTYPE_AIH))
			// fix for PAR 1-DVVRRFR (HLAIH)
			if ((HartGetEffectiveDsa() < 1) || (HartGetEffectiveDsa() > MAXDSA)) {
#else
			if ((HartGetEffectiveDsa() < 1) || (HartGetEffectiveDsa() > MAXDSA) ||
				((FALSE == m_pHartCfgDb->HEnable) &&
                 (SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED))) {
#endif
                InitDevDb(TRUE);
                return;
            }

            // Add the next request to the queue
            if (TRUE == InitHartConnection(m_cucParent)) { 
                // Request is successfully queued.
#if defined(IOPTYPE_AO16)
				// fix for PAR 1-DVN1QD5 (AO16H)
				if ((SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED) &&
					(FALSE == BOX->GetHAutoDet(m_cucParent)))			
#elif !(defined(IOPTYPE_HLAI) || defined(IOMTYPE_AIH))
				// fix for PAR 1-DVVRRFR (HLAIH)
                if (SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED)
#endif				
				{
                    // Set m_bAtLeastOneTry to TRUE only if the channel is configured.
                    // The objective is to exclude setting this parameter on HART transactions
                    // generated by HAutoDet. This flag is used to delay the reporting of
                    // HART communication failure when the channel configuration is loaded.
                    m_bAtLeastOneTry = TRUE;
                }
                // Setup transmit buffer and command.
                m_ucLastReqCmd = m_ucNextReqCmd;
                m_ucpLastXmtPtr = m_ucpNextXmtPtr;
                m_ScanMsg       = NewMsg;
                // Set client type to PST if the current scan is passthrough.
                if (HSCANMSG_PST == NewMsg) {
                    m_HChanType = HCHANTYPE_PASSTHROUGH;
                    pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;
                }
                else {
                    m_HChanType = HCHANTYPE_CHANNEL;
                }

                // Decrement overrun counter.
                if (m_ucScanOverrunCounter > 0) {
                    m_ucScanOverrunCounter--;
                }

                if (m_ucScanOverrunCounter == 0) {
                    // If scan overrun count is now zero, 
                    // return scan overrun alarm to normal.
                    HDevSt[1] &= ~HART_DEVST1_SCANOVRUN_MASK;
                }

                // If CHANMODE is INIT, disable scan counter 
                // until all initialization commands are complete.
                if (HCHANMODE_INIT == m_HChanMode) {
                    m_sScanCounter = TICKS_SYNCED_CHAN;
                }
                else {
                    // Save current scan table row # for ScheduleFromScanTable.
                    m_ucSavedScanNo = m_ucScanNo;

                    // Disable scan counter for active & run 1 second channels.
                    // Otherwise schedule next cycle after one second.
                    if ((HSCANRATE_1SEC == HTotalRate) &&
                        (MODSTATUS_RUN == BOX->GetModuleStatus()) && 
                        (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt())) {
                        m_sScanCounter = TICKS_SYNCED_CHAN;
                    }
                    else {
                        m_sScanCounter = TICKS_IN_1_SEC;
                    }
                }
            }
            else {
                // A request from this channel is already in the queue or
                // being processed by a modem. Increment scan overrun counter
                // and set scan overrun bit if maximum overrun count exceeded.
                // NOTE: Scan overrun will not reported for channels doing
                // device discovery or in inactive state or for channels with 
                // dedicated modem.
                if ((TRUE == m_pHartCfgDb->HEnable) && 
                    (HCHANMODE_SCAN == m_HChanMode) && (NewMsg != HSCANMSG_PST) &&
                    ((MODSTATUS_RUN == BOX->GetModuleStatus()) && 
                    (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt()))) {
                    m_ucScanOverrunCounter++;
                    // Do not post scan overrun for regular one second channel.
                    if ((HTotalRate < HSCANRATE_1SEC) &&
#if defined (IOMTYPE_UIO)
                        // For Series 8 AIH and AOH IOM, scan overrun threshold is increased by factor of 4
                        // becuase four modem's from Series C has been reduced to one modem
                        (m_ucScanOverrunCounter > (UINT8) ((HSCANRATE_1SEC / HTotalRate)*4))) {
#else
                        (m_ucScanOverrunCounter > (UINT8) (HSCANRATE_1SEC / HTotalRate))) {
#endif
                        HDevSt[1] |= HART_DEVST1_SCANOVRUN_MASK;
                        m_ucScanOverrunCounter = (UINT8) (TICKS_IN_64_SEC / HTotalRate);
                    }
                } 

                if (HSCANMSG_PST == NewMsg) {
                    // If this was a pass-through request, decrement the index so that
                    // SetupPassThrough will re-processs this index.
                    if  (m_ucPstRemIndex > 0) {
                        m_ucPstRemIndex--;
                    }
                    else {
                        m_ucPstRemIndex = HPST_OBJECTCOUNT - 1;
                    }
                }
                
                // Disable scan counter for active & run 1 second channels.
                // Otherwise schedule next scan in the next cycle.
                if ((HSCANRATE_1SEC == HTotalRate) &&
                    ((MODSTATUS_RUN == BOX->GetModuleStatus()) && 
                    (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt()))) {
                    m_sScanCounter = TICKS_SYNCED_CHAN;
                }
                else {
                    m_sScanCounter = TICKS_IN_1_SEC;

                    if (HCHANMODE_SCAN == m_HChanMode) {
                        m_ucScanNo--;
                    }
                }
            } // If (TRUE == RequestConnection())
        } // If (m_sScanCounter == 0)
    } //if (m_sScanCounter > 0)

    // Restore original interrupt masks.
}
/*******************************************************************************
*                           clsHartDevDb::PostHComFail                         *
*                           ==========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsHartDevDb::PostHComFail(BOOL a_bIsRegen) {
    if ((0 == (HDevSt[1] & HART_DEVST1_COMMFAIL_MASK)) ||
        (0 == (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK))) {
        // Exit immediately if HART alarming is disabled
        // or if HCOMFAIL bit is not set.
        return TRUE;
    }

    // RT1024 uses the scheduler/FPGA HAL synchronization; no H8 EXR mask is required.

    // Create HART event record and initialize
    EVENTRECORD HEvent;
#if defined(IOMTYPE_UIO)
    HEvent.EventPacket = EVENTPACKET_32CHAN_HART;
#else    
    HEvent.EventPacket = EVENTPACKET_HART;
#endif
    HEvent.Qualifier = a_bIsRegen;
    HEvent.CurrentState = ON;
    if (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK) {
        HEvent.HartEvent.AlarmOn = OFF;
    }
    else {
        HEvent.HartEvent.AlarmOn = ON;
    }
    HEvent.HartEvent.C48Event = OFF;

    HEvent.HartEvent.ChannelNumber = m_cucParent;

    if ((TRUE == a_bIsRegen) || (0 == (HDevStLrs[1] & HART_DEVST1_COMMFAIL_MASK))) {
        HEvent.HartEvent.HEventCode = HEVENT_COMFAIL;
        if (TRUE == BOX->AddNrmEclEvent(&HEvent)) {
            HDevStLrs[1] |= HART_DEVST1_COMMFAIL_MASK;

            if (TRUE == a_bIsRegen) {
                // Set only LRS bit corresponding to HCOMFAIL alarm and clear 
                // all other HDEVST and HCMD48 LRS bits if HART communication 
                // failure exists during event recovery.                        
                UINT8 ucByteCount;
                for (ucByteCount = 0; ucByteCount < HART_DEVST_BYTECOUNT; ucByteCount++) {
                    if (1 == ucByteCount) {
                        HDevStLrs[ucByteCount] = HART_DEVST1_COMMFAIL_MASK;
                    }
                    else {
                        HDevStLrs[ucByteCount] = 0;
                    }
                }
                for (ucByteCount = 0; ucByteCount < HART_CMD48_RESPONSE_SIZE; ucByteCount++) {
                    HCmd48Lrs[ucByteCount] = 0;
                }
            }
        }
        else {
            //set_imask_exr(ucSaveExr);
            return FALSE;
        }
    }

    // If this is event recovery or HART alarm reenabling, check and recover 
    // excessive communication error alarm also. This is required since, 
    // unlike other alarms, execssive communication error bit is not cleared
    // on a HART communication failure.
    if (((TRUE == a_bIsRegen) && HDevSt[1] & HART_DEVST1_EXCOMMERR_MASK)) {
        HEvent.HartEvent.HEventCode = HEVENT_EXCOMFAIL;
        if (TRUE == BOX->AddNrmEclEvent(&HEvent)) {
            HDevStLrs[1] |= HART_DEVST1_EXCOMMERR_MASK;
        }
        else {
            //set_imask_exr(ucSaveExr);
            return FALSE;
        }
    }

    //set_imask_exr(ucSaveExr);
    return TRUE;
}
/*******************************************************************************
*                        clsHartDevDb::PostHAlmOptChgEvent                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsHartDevDb::PostHAlmOptChgEvent(BOOL a_bIsRegen) {
    UINT8 ucChangedBits;

    UINT8 ucSaveExr = get_imask_exr();
    //set_imask_exr(LVLPRI_HART);

    if (FALSE == a_bIsRegen) {
        ucChangedBits = m_pHartCfgDb->HAlarmEnable ^ m_pHartCfgDb->HAlarmEnableLrs;
    }
    else { // Regen the current HART alarm state.
        if (0 == (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK)) {
            ucChangedBits = HALARMENABLE_ALMENBSTATE_MASK;
        }
        else if (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK) {
            ucChangedBits = HALARMENABLE_JOURNALONLY_MASK;
        }
        else {
            ucChangedBits = HALARMENABLE_ALMENBSTATE_MASK;
        }
    }

    if (ucChangedBits & HALARMENABLE_ALMENBSTATE_MASK) {
        // ALMENBSTATE bit got changed
        if (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) {
            HAlmOptChgEvent.SystemEvent.EventSubType = EVENTSUBTYPE_ENABLEALARM;
        }
        else {
            HAlmOptChgEvent.SystemEvent.EventSubType = EVENTSUBTYPE_DISABLEALARM;
        }
    }
    else if (ucChangedBits & HALARMENABLE_JOURNALONLY_MASK) {
        // JOURNALONLY bit got changed
        if (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK) {
            HAlmOptChgEvent.SystemEvent.EventSubType = EVENTSUBTYPE_SUPPRESSALARM;
        }
        else {
            HAlmOptChgEvent.SystemEvent.EventSubType = EVENTSUBTYPE_UNSUPPRESSALARM;
        }
    }
    else {
        // if no bit got changed then exit.
        set_imask_exr(ucSaveExr);
        return TRUE;
    }

    // Report the alarm option change event.
    HAlmOptChgEvent.SystemEvent.ChannelNumber = m_cucParent;
    if (BOX->AddNrmEclEvent(&HAlmOptChgEvent) == TRUE) {
        if (TRUE == a_bIsRegen) {
            set_imask_exr(ucSaveExr);
            return TRUE; 
        }

        // Event posting is successful. Update LRS bit for normal event processing.
        switch (HAlmOptChgEvent.SystemEvent.EventSubType) {
        case EVENTSUBTYPE_ENABLEALARM:
            m_pHartCfgDb->HAlarmEnableLrs |= HALARMENABLE_ALMENBSTATE_MASK;
            break;
        case EVENTSUBTYPE_DISABLEALARM:
            m_pHartCfgDb->HAlarmEnableLrs &= ~HALARMENABLE_ALMENBSTATE_MASK;
            break;
        case EVENTSUBTYPE_SUPPRESSALARM:
            m_pHartCfgDb->HAlarmEnableLrs |= HALARMENABLE_JOURNALONLY_MASK;
            break;
        case EVENTSUBTYPE_UNSUPPRESSALARM:
            m_pHartCfgDb->HAlarmEnableLrs &= ~HALARMENABLE_JOURNALONLY_MASK;
            break;
        }

      //  set_imask_exr(ucSaveExr);
        return TRUE;
    }

    //set_imask_exr(ucSaveExr);
    return FALSE;
}
/*******************************************************************************
*                         clsHartDevDb::ProcessHartEvents                      *
*                         ===============================                      *
*  This function does both regular HART event processing and HART event regen  *
*  depending on the boolean argument. Prcessing is arranged to three sections  *
*  for saving execution context if the event regen has to be suspended due to  *
*  not enough memory in event object. Instead of checking space before adding  *
*  every event, the test is done only before each byte in the device status or *
*  command 48 database is processed. Note that context saving is made use only *
*  by event regen task to resume from where it left off in the previous cycle. *
*  Regular event processing always start from zeroth context and rely on the   *
*  LRS mechanism to identify what to report during each cycle.                 *
*******************************************************************************/
BOOL clsHartDevDb::ProcessHartEvents(BOOL a_bIsRegen) {
    // Static variables to save context during event regen if event regen task
    // gets suspended. Only one set of variables are provided for all sixteen
    // channels as the event regen is processed sequentially for each channel.
    static UINT8 sucRegenByteCount = 0;
    static CONTEXT sRegenContext = CONTEXT_ZERO;

    CONTEXT CurContext;
    UINT8 ucByteCount,ucBitCount,ucBitMask,ucChangedBits;

    EVENTRECORD HEvent;
#if defined(IOMTYPE_UIO)
    HEvent.EventPacket = EVENTPACKET_32CHAN_HART;
#else    
    HEvent.EventPacket = EVENTPACKET_HART;
#endif
    HEvent.Qualifier = a_bIsRegen;
    HEvent.HartEvent.ChannelNumber = m_cucParent;


    // For event regen, restart from the last saved context.
    // For regular event processing, always start from the beginning.
    if (TRUE == a_bIsRegen) {
        CurContext = sRegenContext;
        ucByteCount = sucRegenByteCount;
    }
    else {
        CurContext = CONTEXT_ZERO;
        ucByteCount = 0;
    }

    // Do HART event processing only if IOM is configured and HART is enabled.
    if ((TRUE == m_pHartCfgDb->HEnable) && (HartGetEffectiveDsa() > 0u) && (HartGetEffectiveDsa() <= MAXDSA)) {
        switch (CurContext) {
        case CONTEXT_ZERO:
            // Room for regen is not checked in the context zero because at most only two 
            // events will be added at most in this context - HAlarm option change and/or HComFail.
            // Also there is no need to save context as this is the default starting context.

            if (HEVENTINIT_PENDING == m_HEventInit) {
                // Return FALSE if event initialization is pending
                // so that event recovery task will get suspended.
                return FALSE;
            }

            // Suspend normal event processing if HART template configuration got changed.
            if ((FALSE == a_bIsRegen) && (m_ucTemplateChangeWaitCount > 0)) {
                if (HALF_TEMPLATECHANGE_WAITCOUNT == m_ucTemplateChangeWaitCount) {
                    // If this is the half time of the wait period, report HART alarm
                    // disable event to clear current alarms reported with old template.
                    HAlmOptChgEvent.SystemEvent.EventSubType = EVENTSUBTYPE_DISABLEALARM;
                    HAlmOptChgEvent.SystemEvent.ChannelNumber = m_cucParent;
                    if (FALSE == BOX->AddNrmEclEvent(&HAlmOptChgEvent)) {
                        return FALSE;
                    }
                }

                m_ucTemplateChangeWaitCount--;

                if (0 ==  m_ucTemplateChangeWaitCount) {
                    // Re-report the current HART alarm state at the end of the wait period
                    // after a template change. Make sure that the wait counter goes to zero
                    // only if the HART alarm state event is successfully posted. Also there
                    // is no need to re-report anything if the HART alarm state is is disabled.
                    if ((m_pHartCfgDb->HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) != 0) {
                        if (FALSE == PostHAlmOptChgEvent(TRUE)) {
                            m_ucTemplateChangeWaitCount = 1;
                        }
                        else {
                            // Enable re-reporting of current HART   
                            // alarms and events with new template.
                            m_bReReportEvents = TRUE;
                        }
                    }
                }

                return FALSE;
            }

            // Report any unreported or regen HART alarm state.
            if (FALSE == PostHAlmOptChgEvent(a_bIsRegen)) {
                return FALSE;
            }

            // Abort further HART alarm/event processing if alarm state is disabled
            if (0 == (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK)) { 
                return TRUE;
            }

            if (TRUE == m_bReReportEvents) { 
                // m_bReReportEvents gets set when HAlarmEnable gets changed to enabled state
                // or when the HART template configuration is changed. Force re-reporting of 
                // HART events for this channel by clearing all LRS bits.
                m_bReReportEvents = FALSE;
                for (UINT8 ucCount = 0; ucCount < HART_DEVST_BYTECOUNT; ucCount++) {
                    HDevStLrs[ucCount] = 0;
                }
                for (UINT8 ucCount = 0; ucCount < HART_CMD48_RESPONSE_SIZE; ucCount++) {
                    HCmd48Lrs[ucCount] = 0;
                }
            }

            if (HEVENTINIT_COMFAIL == m_HEventInit) {
                // If HART communication failure, check the LRS bit and post the
                // alarm if needed. Bypass the rest or the HART event processing.
                return PostHComFail(a_bIsRegen);
            }
            
            // Advance to next context - DevSt byte processing.
            ucByteCount = 0;
            CurContext = CONTEXT_ONE;

            // NOTE: break statement is intentionally omitted to let the execution fall through.

        case CONTEXT_ONE: 
            HEvent.HartEvent.AlarmOn = ON; 
            HEvent.HartEvent.C48Event = OFF;

            // Disable HART interrupts so that the live HART event 
            // database does not get updated during event processing.
            //set_imask_exr(LVLPRI_HART); 

            // Check and report device status events. The for loop initializer below is intentionally 
            // omitted as ucByteCount is already initialized at the end of the previous context.
            for (/*See comment above*/; ucByteCount < HART_DEVST_BYTECOUNT; ucByteCount++) {
                if (TRUE == a_bIsRegen) { 
                    // First check whether there is space in event queue for regen.
                    // If not return FALSE to suspend the event regen task.
                    if (BOX->IsRoomForRegen() == FALSE) {
                        sRegenContext = CurContext;
                        sucRegenByteCount = ucByteCount;
                        return FALSE;
                    }
                    // Report all current events if regen
                    ucChangedBits = HDevSt[ucByteCount]; 
                }
                else { // Report only unreported events
                    ucChangedBits = HDevSt[ucByteCount] ^ HDevStLrs[ucByteCount];
                }

                // Bypass the bit loop if no events to be reported for this byte.
                if (0 == ucChangedBits) continue;

                for (ucBitCount = 0,ucBitMask = 0x01; ucBitCount < BYTESIZE; ucBitCount++,ucBitMask <<= 1) {                   
                    if ((ucChangedBits & ucBitMask) && (HART_DEVST_EVENT_ENABLE[ucByteCount] & ucBitMask)) { 
                        // There are events to report and the event is enabled
                        HEvent.CurrentState = (HDevSt[ucByteCount] & ucBitMask) ? ON : OFF;
                        HEvent.HartEvent.HEventCode = (ucByteCount * BYTESIZE) + ucBitCount;

                        // Turn off the alarm bit if alarm for command failed and
                        // more status available events and if JOURNALONLY bit is set.
                        if ((0 == (HART_DEVST_ALARM_ENABLE[ucByteCount] & ucBitMask)) ||
                            (m_pHartCfgDb->HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK)) {
                            HEvent.HartEvent.AlarmOn = OFF;
                        }
                        else {
                            HEvent.HartEvent.AlarmOn = ON;
                        }

                        if (TRUE == BOX->AddNrmEclEvent(&HEvent)) {
                            if (FALSE == a_bIsRegen) { 
                                // Update LRS bits only for normal events.
                                if (HEvent.CurrentState) {
                                    HDevStLrs[ucByteCount] |= ucBitMask;
                                }
                                else {
                                    HDevStLrs[ucByteCount] &= ~ucBitMask;
                                }
                            }
                        }
                        else { // Event reporting failed. Exit with FALSE return value.
                            // If event regen is going on, save the current context.
                            if (TRUE == a_bIsRegen) {
                                sRegenContext = CurContext;
                                sucRegenByteCount = ucByteCount;
                            }
                            return FALSE;
                        }
                    }
                } // bit loop

                // Momentarily return back to task level priority between 
                // each byte so that any pending HART interrupts will get executed.
               // set_imask_exr(LVLPRI_HART);
            } // end of device status event handling

            // Advance to next context - command 48 event handling.
            ucByteCount = 0;
            CurContext = CONTEXT_TWO;
            
            // NOTE: break statement is intnetionally omitted to let the execution fall through.

        case CONTEXT_TWO:        
            // Do command 48 events and alarms only if command 48 was successfully executed.
            if (HEVENTINIT_C48FAIL != m_HEventInit) {
                HEvent.HartEvent.AlarmOn = OFF;
                HEvent.HartEvent.C48Event = ON;

                // Check and report command 48 events. The for loop initializer below is intentionally
                // omitted as ucByteCount is already initialized at the end of the previous context.
                for (/*See comment above*/; ucByteCount < HART_CMD48_RESPONSE_SIZE; ucByteCount++) {
                    if (TRUE == a_bIsRegen) { 
                        // First check whether there is space in event queue for regen. If not,
                        // save current context and return FALSE to suspend the event regen task.
                        if (BOX->IsRoomForRegen() == FALSE) {
                            sRegenContext = CurContext;
                            sucRegenByteCount = ucByteCount;
                            return FALSE;
                        }

                        // Report all current events if regen
                        ucChangedBits = HCmd48.ucBytes[ucByteCount];
                    }
                    else { // Report only unreported events
                        ucChangedBits = HCmd48.ucBytes[ucByteCount] ^ HCmd48Lrs[ucByteCount];
                    }

                    // Bypass the bit loop if no events to be reported for this byte.
                    if (0 == ucChangedBits) continue;

                    for (ucBitCount = 0,ucBitMask = 0x01; ucBitCount < BYTESIZE; ucBitCount++,ucBitMask <<= 1) {                    
                        if ((ucChangedBits & ucBitMask) && (m_pHartCfgDb->HNtfyCfg[ucByteCount] & ucBitMask)) { 
                            // There are events to report and event reporting is enabled
                            HEvent.CurrentState = (HCmd48.ucBytes[ucByteCount] & ucBitMask) ? ON : OFF;
                            HEvent.HartEvent.HEventCode = (ucByteCount * BYTESIZE) + ucBitCount;
                        
                            // Set alarm bit if configured for reporting alarm
                            if ((m_pHartCfgDb->HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK) ||
                                (0 == (m_pHartCfgDb->HNtfyCfg[HART_CMD48_RESPONSE_SIZE + ucByteCount] & ucBitMask))) {
                                HEvent.HartEvent.AlarmOn = OFF;
                            }
                            else {
                                HEvent.HartEvent.AlarmOn = ON;
                            }

                            if (TRUE == BOX->AddNrmEclEvent(&HEvent)) {
                                if (FALSE == a_bIsRegen) { 
                                    // Update LRS bits only for normal events.
                                    if (HEvent.CurrentState) {
                                        HCmd48Lrs[ucByteCount] |= ucBitMask;
                                    }
                                    else {
                                        HCmd48Lrs[ucByteCount] &= ~ucBitMask;
                                    }
                                }
                            }
                            else { // Event reporting failed. Exit with FALSE return value.
                                // If event regen is going on, save the current context.
                                if (TRUE == a_bIsRegen) {
                                    sRegenContext = CurContext;
                                    sucRegenByteCount = ucByteCount;
                                }
                                return FALSE;
                            }
                        }
                    } // C48 bit loop

                    // Momentarily return back to task level priority between 
                    // each byte so that any pending HART interrupts will get executed.
                    //set_imask_exr(LVLPRI_HART);
                } // end of C48 byte loop
            } // end of C48 event handling

            // Reset context and byte count for the next channel event handling
            ucByteCount = 0;
            CurContext = CONTEXT_ZERO;
            break;

        default:
            CurContext = CONTEXT_ZERO;
            ucByteCount = 0u;
            break;
        } // end of switch context statement
    }

    if (TRUE == a_bIsRegen) {
        sRegenContext = CurContext;
        sucRegenByteCount = ucByteCount;
    }

    return TRUE;
}
/*******************************************************************************
*                          clsHartDevDb::ReceptionComplete                     *
*                          ===============================                     *
* PURPOSE:                                                                     *
*    Callback used by the modem object to notify the channel that reception of *
*    a HART message from the link is complete.                                 *
* ARGUMENTS:                                                                   *
*    a_HartMsgStatus - Status of the received message GOOD, BAD or DEVICERROR. *
* RETURN:                                                                      *
*    HSYNCSTATUS - KEEP_SYNC for back-to-back message without disconnect.      *
*                  DROP_SYNC to release the modem and to schedule later.       *
* PROCESS:                                                                     *
*    1. Handle the received message depending on HART channel type and message *
*       status given by the modem object. For channel objects, update commn    *
*       status and call UpdataeDatabase method if the status is good. For      *
*       passthrough objects, simply update the status as the response data is  *
*       already received in passthrough response buffer.                       *
*    2. Update HDATAINIT status if required and setup next HART command to     *
*       process. Invoke BumpPollingAddress method if the last command failed   *
*       command zero. Setup CMD48 scan if more status available bit toggles.   *
*       Setup rediscovery if cold start or configuration changed is reported   *
*       or in case of any commn error. Otherwise setup next command from the   *
*       initialization table or scan table depending on channel mode.          *
*    3. Return appropriate status to request the modem object to handle next   *
*       transaction as a back-to-back message without disconnecting modem or   *
*       to release the modem and let it process other channels. In the latter  *
*       case, modem services will be requested again when scan counter expires.*
* NOTES:                                                                       *
*    1. If IOLP RAM diagnostics is not stopped by locking SemDiag, IOLP will   *
*       hard fail, if the database update was done at the same time when IOLP  *
*       doing diagnostics on a database location.                              *
*    2. This method is called from modem object methods - ActOnResponse and    *
*       SetupRetry.                                                            *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::ReceptionComplete(HMSGSTATUS a_HartMsgStatus) {
    HREPLYSTATUS HartReplyStatus = HREPLYSTATUS_BAD;
    HSYNCSTATUS  HartSyncStatus  = HSYNCSTATUS_DROP_SYNC;

#if defined(IOMTYPE_UIO)
    // Get the modem number associated with the channel
    UINT8 modem = FPGA.GetChannelModem(m_cucParent);
    
    // Get the pass through table for the modem
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(modem);


    // Factory test support
    // Check for hart loop back test status first.
    if(TRUE == HartLoopBkTestInProgress) 
    {
        // Check for Message status
        // If it is good, set loopback status as success.
        // If it is bad, set loopback status as fail.
        if(HMSGSTATUS_GOOD == a_HartMsgStatus) 
        {
            BOX->SetLpBkStat(LOOPBACK_SUCCESS);
        }
        else 
        {
            // Place the channel number in the first nibble of status
            BOX->SetLpBkStat((HARTLPBKSTAT)((m_cucParent << 2) & 0xFC ));
        }

        // Flush Channel receive buffer
        m_ChanRcvBuffer.Flush();
        // Drop sync
        return HartSyncStatus;
    }

#endif

#if HART_ALLOW_DSA0
    if (BOX->GetDSA() > MAXDSA) {
#else
    if ((BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA)) {
#endif
        // IOM is not primary anymore. Drop connection to the modem.
        return HartSyncStatus;
    }

    if ((HARTCOMMAND_ZERO == m_ucLastReqCmd) && (HMSGSTATUS_GOOD != a_HartMsgStatus)) {
        // If the current command was a command zero poll and it failed,
        // increment polling next address for the next command zero poll.
        HartSyncStatus = BumpPollingAddress();
        return HartSyncStatus;
    }

    if (HMSGSTATUS_GOOD == a_HartMsgStatus) { 
        if (HCHANTYPE_CHANNEL == m_HChanType) {
            // Update communication status byte.
            SetHComSts(HCOMSTS_GOOD);

            // Update the database with the received data
            HartReplyStatus = UpdateDatabase(); 

            // Update DATAINIT status. This parameter is used by the IOM 
            // to decide whether to return data or remote fetch pending in
            // response to a read request after an IOM switch over.
            if ((HDATAINIT_PENDING == m_HDataInit) && (HCHANMODE_SCAN == m_HChanMode)) {
                if ((MODSTATUS_IDLE == BOX->GetModuleStatus()) || 
                    (PTEXECST_INACTIVE == SLOT(m_cucParent)->GetPtExecSt()) ||
                    ((HSCANRATE_NONE == HDynRate) && (HSCANRATE_NONE == HDevRate)) ||
                    (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK)) {
                    m_HDataInit = HDATAINIT_COMPLETE;
                }
                else if ((m_ucLastReqCmd == m_ucDynScan[0]) && (m_ScanMsg == HSCANMSG_DYN)) {
                    // if dynamic scan just completed
                    if ((HSCANRATE_NONE == HDevRate) || (HDynRate < HDevRate)) {
                        // If DEVRATE is greater than DYNRATE, a device scan
                        // would have been completed already.
                        m_HDataInit = HDATAINIT_COMPLETE;
                    }
                }
                else if ((m_ucLastReqCmd == m_ucDevScan[0]) && (m_ScanMsg == HSCANMSG_DEV)) {
                    // if device scan just completed
                    if ((HSCANRATE_NONE == HDynRate) || (HDevRate <= HDynRate)) {
                        // If DEVRATE is less than or equal to DYNRATE, 
                        // a dynamic scan would have been completed already.
                        m_HDataInit = HDATAINIT_COMPLETE;
                    }
                }
            }
        }
        else if (HCHANTYPE_PASSTHROUGH ==  m_HChanType) { 
            // Update passthrough status table.
            pHartPst[m_ucPstRemIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_SUCCESS;
            HartReplyStatus = HREPLYSTATUS_GOOD;
        }
        else {
            HardFail(HF_INVPROGRAMEXEC,HARTDB_CPP,__LINE__);
        }
    }      
    else { // Message had some communication problem and transaction failed.
        if (HCHANTYPE_CHANNEL == m_HChanType) {
            // Update communication status byte in database.
            if (HComSts != m_ucCommStatus) {
                SetHComSts(m_ucCommStatus);
            }
        }
        else if (HCHANTYPE_PASSTHROUGH == m_HChanType) { 
            // Update passthrough status table.
            pHartPst[m_ucPstRemIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_DEAD;
            // For passthrough message, make reply status as good, even if transaction failed
            // so that next message in the scan table will be processed. 
            HartReplyStatus = HREPLYSTATUS_GOOD;
        }
        else {
            HardFail(HF_INVPROGRAMEXEC,HARTDB_CPP,__LINE__);
        }
    }

    // Current transaction is complete. Initialize communication 
    // status and the receive buffer for the next transaction.
    m_ucCommStatus = HCOMSTS_GOOD;
    m_ChanRcvBuffer.Flush();
    m_ScanMsg      = HSCANMSG_NONE;
    // If the channel is doing pass-through and the last request was successfully processed,
    // check the pass-through queue again to allow pass-through message bunching.
#if defined (IOMTYPE_UIO)
    if ((m_HChanType == HCHANTYPE_PASSTHROUGH) && 
        (HartReplyStatus == HREPLYSTATUS_GOOD)) 
    {
        // Back-2-Back messages are calculated based on the ucB2BPSTCount calculated in SearchForPST() function
        // in boxslot.cpp
        if(m_ucB2BPstMsgCount < BOX->ucB2BPSTCount[modem]) 
        {
            // Change ChanType to CHANNEL so that SetupPassThrough() will
            // process passthrough queue. This was necessitated because
            // as per the current implementation SetupPassThrough() will
            // process the next pass-through message only if the last one
            // was complete and it checks the ChanType for this decision.
            m_HChanType = HCHANTYPE_CHANNEL;

            if (SetupPassThrough() == HSCANMSG_PST) 
            {
                // Found another pass-through message to the same device
                // waiting in the pass-through queue. Update last command 
                // and transmit pointer since this is a back-to-back message.
                m_ucLastPstCmd = m_ucNextPstCmd;
                m_ucpLastPstXmtPtr = m_ucpNextPstXmtPtr;

                m_ScanMsg       = HSCANMSG_PST;
                m_ucB2BPstMsgCount++;
                m_HChanType = HCHANTYPE_PASSTHROUGH;
                pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;

                // Schedule next request without disconnecting modem.
                return HSYNCSTATUS_KEEP_SYNC;
            }
            else 
            {
                m_ucB2BPstMsgCount = 0;
                // Change the channel type to channel so that status update is done after PST
                m_HChanType = HCHANTYPE_CHANNEL;
                return HSYNCSTATUS_DROP_SYNC;
            }
        }
        else 
        {
            m_ucB2BPstMsgCount = 0;
            // Change the channel type to channel so that status update is done after PST
            m_HChanType = HCHANTYPE_CHANNEL;
            return HSYNCSTATUS_DROP_SYNC;
        }
    }
#else
    if ((m_HChanType == HCHANTYPE_PASSTHROUGH) && 
        (HartReplyStatus == HREPLYSTATUS_GOOD) &&
        (m_ucB2BPstMsgCount < HPST_B2BMSG_MAXCOUNT)) 
    {
        
        // Change ChanType to CHANNEL so that SetupPassThrough() will
        // process passthrough queue. This was necessitated because
        // as per the current implementation SetupPassThrough() will
        // process the next pass-through message only if the last one
        // was complete and it checks the ChanType for this decision.
        m_HChanType = HCHANTYPE_CHANNEL;

        if (SetupPassThrough() == HSCANMSG_PST) 
        {
            // Found another pass-through message to the same device
            // waiting in the pass-through queue. Update last command 
            // and transmit pointer since this is a back-to-back message.
            m_ucLastReqCmd  = m_ucNextReqCmd;
            m_ucpLastXmtPtr = m_ucpNextXmtPtr;
            m_ScanMsg       = HSCANMSG_PST;
            m_ucB2BPstMsgCount++;
            m_HChanType = HCHANTYPE_PASSTHROUGH;
            pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;

            // Schedule next request without disconnecting modem.
            return HSYNCSTATUS_KEEP_SYNC;
        }
    }
#endif

    // There is no back-to-back passthrough message.
    // Reset back-to-back passthrough count and 
    // return back to normal channel scanning.
    m_ucB2BPstMsgCount = 0;
    m_HChanType = HCHANTYPE_CHANNEL;

    if ((HREPLYSTATUS_GOOD == HartReplyStatus) || (HREPLYSTATUS_CONTINUE == HartReplyStatus)) { 
        // Last transaction completed successfully or it is OK to continue.
        if (HCHANMODE_INIT == m_HChanMode) {
            HartSyncStatus = ScheduleFromInitTable();
        }
        else if (HCHANMODE_SCAN == m_HChanMode) {
            if ((TRUE == m_bCmd38FailReported) && (HARTCOMMAND_FOURTYEIGHT == m_ucLastReqCmd)) {
                // If command 38 had failed with a write protect error earlier,
                // schedule it once again after a command 48. Since command 48 
                // is scheduled once every 64 second or in response to a device
                // status change, this helps to detect any change in write 
                // protect status of the device approximately once every minute.
                if ( m_ucHartVersion >= HARTVERSION_7X) {
                    memcopy(&HART7_CMD38[2],HCmd0.str.ucusConfigChgCnt,sizeof(HCmd0.str.ucusConfigChgCnt));
                    m_ucNextReqCmd   = HART7_CMD38[0];
                    m_ucpNextXmtPtr = (UINT8 *) &HART7_CMD38[0];
                }
                else {
                    m_ucNextReqCmd   = HARTCMD38[0];
                    m_ucpNextXmtPtr = (UINT8 *) &HARTCMD38[0];
                }
                m_ucLastReqCmd   = m_ucNextReqCmd;
                m_ucpLastXmtPtr  = m_ucpNextXmtPtr;
                m_ScanMsg        = HSCANMSG_NONE;
                HartSyncStatus = HSYNCSTATUS_KEEP_SYNC;
            }
            else {
                HartSyncStatus = ScheduleFromScanTable(); 
            }
        }
    }
    else if (HREPLYSTATUS_MORE == HartReplyStatus) { 
        // Last transaction inidicates that extended status is available.
        // Setup a back-to-back command 48 scan.
        m_ucNextReqCmd  = HARTCMD48[0];
        m_ucpNextXmtPtr = (UINT8 *) &HARTCMD48[0];
        /*
        if ( m_ucHartVersion >= HARTVERSION_7X) {
            memcopy(&HART7_CMD48[2],HCmd48.ucBytes,HART_CMD48_RESPONSE_SIZE);
            m_ucNextReqCmd  = HART7_CMD48[0];
            m_ucpNextXmtPtr = (UINT8 *) &HART7_CMD48[0];

        } else {
            m_ucNextReqCmd  = HARTCMD48[0];
            m_ucpNextXmtPtr = (UINT8 *) &HARTCMD48[0];
        }
        */
        m_ucLastReqCmd  = m_ucNextReqCmd;
        m_ucpLastXmtPtr = m_ucpNextXmtPtr;
        m_ScanMsg       = HSCANMSG_C48;
        HartSyncStatus  = HSYNCSTATUS_KEEP_SYNC;
    }
    else if (HREPLYSTATUS_REINIT == HartReplyStatus) { 
        // Configuration changed or the cold start bit is set in the last 
        // response. Rediscover the device. NOTE : HART dynamic and device 
        // variables are not invalidated.
        m_HChanMode        = HCHANMODE_INIT;
        m_sScanCounter     = TICKS_DISABLE_SCAN;
        m_ucInitCmdIndex   = 0;
        m_ucPollingAddress = 0;
        m_ucNextReqCmd     = HARTCMD0[0];
        m_ucpNextXmtPtr    = (UINT8 *)&HARTCMD0[0];
        m_ucLastReqCmd     = m_ucNextReqCmd;
        m_ucpLastXmtPtr    = m_ucpNextXmtPtr;
        m_ScanMsg          = HSCANMSG_NONE;
        HartSyncStatus     = HSYNCSTATUS_KEEP_SYNC; 
    }
    else if (HREPLYSTATUS_BUSY == HartReplyStatus) {
        // Device responded with response code 32 (busy). Drop sync keeping
        // the present state and retry after four seconds.
        m_sScanCounter = TICKS_IN_4_SEC;
        HartSyncStatus = HSYNCSTATUS_DROP_SYNC;
    }
    else { 
        // Last transaction failed completely. Initialize all HART variables, 
        // stop scanning and try to rediscover depending on configuration. 
        InitDevDb(TRUE);
        SetScanCounterForRediscovery(SLOT(m_cucParent)->GetPntType());
        HartSyncStatus = HSYNCSTATUS_DROP_SYNC;
    }

    return HartSyncStatus;
}
/*******************************************************************************
*                              clsHartDevDb::LogEvent                          *
*                              ======================                          *
* PURPOSE:                                                                     *
*    Callback used by the modem object to notify the client about various      *
*    reception events.                                                         *
* ARGUMENTS:                                                                   *
*    a_HartEventType - HART event type.                                        *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Update m_ucCommStatus according to the logged event and update IOM     *
*       database if required. Increment communication error count and update   *
*       excessive communication alarm status.                                  *
*    2. Schedule CMD109 if a burst mode device is detected. Setup secondary    *
*       master throttling counter for one minute in case secondary master is   *
*       detected. Flush the channel receive buffer for retry requests.         *
* NOTES:                                                                       *
*    1. This method is called from various modem object methods.               *
*******************************************************************************/
VOID clsHartDevDb::LogEvent(HEVENTTYPE a_HartEventType) {

#if defined(IOMTYPE_UIO)
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(m_cucParent));
#endif

    // Check and update excessive communication alarm status
    // only if command zero has been successfully completed.
    if (m_ucInitCmdIndex > 0) { 
        // if command 0 completed successfully
        if ((HEVENTTYPE_COMMERROR == a_HartEventType) || 
            (HEVENTTYPE_NORESPONSE == a_HartEventType) ||
            (HEVENTTYPE_DEVICEERROR == a_HartEventType)) {
            if (HNComErr < HART_COMMERROR_MAXCOUNT) {
                HNComErr++;
            }
            if ((m_pHartCfgDb->HComThrs > 0) && (HNComErr >= m_pHartCfgDb->HComThrs)) {
                HNComErr = m_pHartCfgDb->HComThrs;
                if ((HNComErr < HART_COMMERROR_MAXCOUNT) && (TRUE == m_pHartCfgDb->HEnable)) {
                    HDevSt[1] |= HART_DEVST1_EXCOMMERR_MASK;
                }
            }
        }
    }

    switch (a_HartEventType) {
    case HEVENTTYPE_COMMERROR:
        if (m_ucCommStatus < HCOMSTS_DEVFOUNDERROR) {
            m_ucCommStatus = HCOMSTS_IOMFOUNDERROR;
        }
        else {
            m_ucCommStatus = HCOMSTS_CHANNELERROR;
        }
        break;       
    case HEVENTTYPE_NORESPONSE:
        if (m_ucCommStatus < HCOMSTS_DEVFOUNDERROR) {
            m_ucCommStatus = HCOMSTS_NORESPONSE;
        }
        else {
            m_ucCommStatus = HCOMSTS_CHANNELERROR;
        }
        break;       
    case HEVENTTYPE_DEVICEERROR:
        if ((m_ucCommStatus == HCOMSTS_GOOD) || 
            (m_ucCommStatus == HCOMSTS_DEVFOUNDERROR)) {
            m_ucCommStatus = HCOMSTS_DEVFOUNDERROR;
        }
        else {
            m_ucCommStatus = HCOMSTS_CHANNELERROR;
        }
        break;       
    case HEVENTTYPE_RETRY:
            // Flush channel buffer as modem is about fetch new response.
        if (HCHANTYPE_CHANNEL == m_HChanType) {
            m_ChanRcvBuffer.Flush();
        }
        else if (HCHANTYPE_PASSTHROUGH == m_HChanType) {
            pHartPst[m_ucPstRemIndex]->m_PstRcvBuffer.Flush();
        }
        else {
            HardFail(HF_INVPROGRAMEXEC,HARTDB_CPP,__LINE__);
        }
        break;    
    case HEVENTTYPE_BURSTMODE:
        if (HCHANTYPE_CHANNEL == m_HChanType) {
            // Setup command 109 for turning off burst mode.
            m_ChanRcvBuffer.Flush();
            m_ucNextReqCmd  = HARTCMD109[0];
            m_ucpNextXmtPtr = (UINT8 *) &HARTCMD109[0];
            // Update last command also since this is a back-to-back message
            m_ucLastReqCmd  = m_ucNextReqCmd;
            m_ucpLastXmtPtr = m_ucpNextXmtPtr;
            m_ScanMsg       = HSCANMSG_NONE;
        }
        break;
    case HEVENTTYPE_SECMASTER:
        // Setup secondary master throttling count for three minutes.
        m_ucSecMasterResetCounter = 3 * TICKS_IN_60_SEC;
        break;
    case HEVENTTYPE_RCVRERROR:
    case HEVENTTYPE_PRIMASTER:
        m_ucCommStatus = HCOMSTS_CHANNELERROR;
        break;
    default:
        HardFail(HF_BADPROGRAMJUMP,HARTDB_CPP,__LINE__);

    }
}
/*******************************************************************************
*                          clsHartDevDb::BuildScanTable                        *
*                          ============================                        *
* PURPOSE:                                                                     *
*    Build HART scan scheduler.                                                *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Initialize the entire table with SCANMSG_NONE entries and if HART is   *
*       not enabled, return with defaulted scan table.                         *
*    2. Update HDynRate and HDevRate from HScanCfg if the channel is not marked*
*       as one second overrun channel. These channels run with degraded values *
*       for HDynRate and HDevRate, which is different from configured values.  *
*    3. If channel is not configured, configure only one C48 entry. When a C48 *
*       scan completes, m_ucSkipC48Cycles will be setup to skip this command   *
*       for three cycles, resulting a command 48 scan once every 64 seconds.   *
*    4. If control state is inactive or idle, or if device/revision mismatch   *
*       is set, populate a C48 for the first row first column and passthrough  *
*       messages in the first column of all other rows. Make sure that command *
*       48 will be scheduled at 16 seconds rateby disabling m_ucSkipC48Cycles. *
*    5. If control state is active, populate m_ScanMsgTbl with SCNMSG entries  *
*       depending on dynamic and device rate. If dyanmic and device rates are  *
*       both 0, make sure that m_ucSkipC48Cycles is disabled so that command   *
*       48 scan will be schedule at least once every 16 seconds.               *
*    6. If control state is active, make sure that there are at least three    *
*       passthrough message entries, preferably as back-to-back commands.      *
*    7. If device scan is configured, build device scan transmit buffer.       *
* NOTES:                                                                       *
*    1. This method is called from ScheduleFromInitTable from various HART     *
*       parameter post functions.                                              *
*    2. Even though passthrough scan is setup for one second rate when control *
*       state is inactive, if HCUAVAIL is greater then 40%, a dedicated modem  *
*       will be assigned for passthrough. So, if SWMUX is queing up requests,  *
*       maximum possible performance will be achieved.                         *
*    3. If either dynamic or device rate is configured, cyclic command 48 scan *
*       is delayed to once every 64 second using m_ucSkipC48Cycles. But this   *
*       does not delay scheduling of command 48 in response to toggling bits   *
*       in device status byte.                                                 *
*******************************************************************************/
VOID clsHartDevDb::BuildScanTable(VOID) {
    // For UIO, PST is removed from scan table entry, in place of PST, NONE is added
    unsigned short ucRow,ucCol;
  
    // Initialize scan table with NONE entries.
    for (ucRow = 0; ucRow < MAX_CYCLE_NUMBER; ucRow++) {
        for (ucCol = 0; ucCol < MAX_MSGS_IN_A_CYCLE; ucCol++) {
            m_ScanMsgTbl[ucRow][ucCol] = HSCANMSG_NONE;
        }
    }

#if !(defined(IOPTYPE_HLAI) || defined(IOMTYPE_AIH))
	// fix for PAR 1-DVVRRFR (HLAIH)
#if defined(IOPTYPE_AO16)
	// fix for PAR 1-DVN1QD5 (AO16H)
	if ((FALSE == m_pHartCfgDb->HEnable) &&
		(SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED) &&
		(FALSE == BOX->GetHAutoDet(m_cucParent))) {
#else
	// If slot is configured and HART is not enabled, this is a pure analog
	// channel. Leave the scan table  in the initialized state.
	if ((FALSE == m_pHartCfgDb->HEnable) &&
        (SLOT(m_cucParent)->GetPntType() != PNTTYPE_NOTCONFIGURED)) {
#endif
        return;
    }
#endif
    
    HDevRate = HSCANCFG_TABLE[m_pHartCfgDb->HScanCfg][0];
    HDynRate = HSCANCFG_TABLE[m_pHartCfgDb->HScanCfg][1];
    if ((HDynRate > HSCANRATE_NONE) || (HDevRate > HSCANRATE_NONE)) {
        HTotalRate = (HSCANRATE)(HDynRate + HDevRate);
    }
    else HTotalRate = HSCANRATE_16SEC;
    
#if defined(IOMTYPE_UIO)
    if ((SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED)) {
        return;
    }
#else
    if ((SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED) && (FALSE == BOX->GetHADCEnable(m_cucParent))) {
        m_ScanMsgTbl[0][FIRST_SCAN_MSG] = HSCANMSG_C48;
    }
#endif
    else if ((MODSTATUS_IDLE == BOX->GetModuleStatus()) ||
        (PTEXECST_INACTIVE == SLOT(m_cucParent)->GetPtExecSt()) ||
        (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK)) {
#if !defined(IOMTYPE_UIO)
        // If control state is inactive or idle or device mismatch error exits,
        // allocate passthrough once every second and C48 scan once in 16 second.
        //
        // NOTE:  This code is not compiled in for UIO because UIO is following
        //        changes made for VW/Series 8 pass through functionality.
        for (ucRow = 1; ucRow < MAX_CYCLE_NUMBER; ucRow++) {
            m_ScanMsgTbl[ucRow][FIRST_SCAN_MSG] = HSCANMSG_PST;
        }
        m_ScanMsgTbl[0][FIRST_B2B_MSG] = HSCANMSG_PST;
#endif
        m_ScanMsgTbl[0][FIRST_SCAN_MSG] = HSCANMSG_C48;        
        m_ucSkipC48Cycles = 0;
    }
    else { // If channel configuration is present without any error and 
        // control state is active and running
        if ((HSCANRATE_NONE == HDynRate) && (HSCANRATE_NONE == HDevRate)) {
            // If DynRate and DevRate are zero, add a single command 48
            m_ScanMsgTbl[0][FIRST_SCAN_MSG] = HSCANMSG_C48;
            m_ucSkipC48Cycles = 0;
        }
        else { // Either dynrate or devrate is greater than zero.
            if ((HDynRate > HSCANRATE_NONE) && (HDynRate >= HDevRate)) {
                ucCol = HSCANRATE_1SEC / HDynRate;
                if (HSCANRATE_1SEC == HTotalRate) {
                    ucCol = 1;
                }
                // Configure dynamic scan as the first command.
                for (ucRow = 0; ucRow < MAX_CYCLE_NUMBER; ucRow++) {
                    if (0 == (ucRow % ucCol)) {
                        m_ScanMsgTbl[ucRow][FIRST_SCAN_MSG] = HSCANMSG_DYN;
                    }
                }
                if (HDevRate > HSCANRATE_NONE) {
                    // Configure device scan as the back-to-back command.
                    ucCol = HSCANRATE_1SEC / HDevRate;
                    if (HSCANRATE_1SEC == HTotalRate) {
                        ucCol = 1;
                    }
                    for (ucRow = 0; ucRow < MAX_CYCLE_NUMBER; ucRow++) {
                        if (0 == (ucRow % ucCol)) {
                            m_ScanMsgTbl[ucRow][FIRST_B2B_MSG] = HSCANMSG_DEV;
                        }
                    }
                }
            }
            else if (HDevRate > HSCANRATE_NONE) {
                ucCol = HSCANRATE_1SEC / HDevRate;
                // Configure device scan as the first command.
                for (ucRow = 0; ucRow < MAX_CYCLE_NUMBER; ucRow++) {
                    if (0 == (ucRow % ucCol)) {
                        m_ScanMsgTbl[ucRow][FIRST_SCAN_MSG] = HSCANMSG_DEV;
                    }
                }
                if (HDynRate > 0) {
                    // Configure dynamic scan as the back-to-back command.
                    ucCol = HSCANRATE_1SEC / HDynRate;
                    for (ucRow = 0; ucRow < MAX_CYCLE_NUMBER; ucRow++) {
                        if (0 == (ucRow % ucCol)) {
                            m_ScanMsgTbl[ucRow][FIRST_B2B_MSG] = HSCANMSG_DYN;
                        }
                    }
                }
            }

            // Make sure that there is at least one command 48 entry
            // as a back-to-back message to save modem switching time.
            ucRow = 0; ucCol = FIRST_B2B_MSG;
            do {
                if ((m_ScanMsgTbl[ucRow][FIRST_SCAN_MSG] != HSCANMSG_NONE) && 
                    (m_ScanMsgTbl[ucRow][ucCol] == HSCANMSG_NONE)) {
                    m_ScanMsgTbl[ucRow][ucCol] = HSCANMSG_C48;
                    break;
                }
                else {
                    ucRow++;
                    if (ucRow == MAX_CYCLE_NUMBER) {
                        ucRow = 0;
                        if (ucCol < FINAL_B2B_MSG) {
                            ucCol = FINAL_B2B_MSG;
                        }
                        else {
                            HardFail(HF_INVPROGRAMEXEC,HARTDB_CPP,__LINE__);
                        }
                    }
                }
            } while (m_ScanMsgTbl[ucRow][ucCol] != HSCANMSG_C48);
        }
#if !defined(IOMTYPE_UIO)
        // Fill HPST entries in each row of the scan table so that passthrough
        // queue will be checked every second. For this, each column is checked 
        // starting from the third. Intention is to schedule pass-through as a 
        // back-to-back message as far as possible to save modem switch time.
        for (ucRow = 0; ucRow < MAX_CYCLE_NUMBER; ucRow++)
        {
            if ((m_ScanMsgTbl[ucRow][FINAL_B2B_MSG] == HSCANMSG_NONE) &&
                (m_ScanMsgTbl[ucRow][FIRST_B2B_MSG] != HSCANMSG_NONE))
            {
                m_ScanMsgTbl[ucRow][FINAL_B2B_MSG] = HSCANMSG_PST;
            }
            else if ((m_ScanMsgTbl[ucRow][FIRST_B2B_MSG] == HSCANMSG_NONE) &&
                (m_ScanMsgTbl[ucRow][FIRST_SCAN_MSG] != HSCANMSG_NONE))
            {
                m_ScanMsgTbl[ucRow][FIRST_B2B_MSG] = HSCANMSG_PST;
            }
            else if (m_ScanMsgTbl[ucRow][FIRST_SCAN_MSG] == HSCANMSG_NONE)
            {
                m_ScanMsgTbl[ucRow][FIRST_SCAN_MSG] = HSCANMSG_PST;
            }
        }
#endif
        // Build device scan message transmit buffer.
        m_ucDevScan[1] = 0;
        for (ucRow = 0; ucRow < HART_MAXVAR_COUNT; ucRow++) {
            if (m_pHartCfgDb7->HSlotDvc7[ucRow] != HART_INVALID_PARAMETER_CODE) { 
                m_ucDevScan[1]++;
                m_ucDevScan[m_ucDevScan[1] + 1] = m_pHartCfgDb7->HSlotDvc7[ucRow];
            }
        }
    }

    m_ucScanNo = MIN_CYCLE_NUMBER;
    m_ucB2BNo  = FIRST_SCAN_MSG;
}
/*******************************************************************************
*                         clsHartDevDb::ControlStateChange                     *
*                         ================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::ControlStateChange(VOID) {
    // Module status or point execution state changed. 
    // Build scan table and  configure scan counter for the new state.
    UINT8 ucDsa = HartGetEffectiveDsa();
    if ((TRUE == m_pHartCfgDb->HEnable) && (ucDsa > 0) && (ucDsa <= MAXDSA)) { 
        // if this is primary IOM and HART is configured
        if ((BOX->GetModuleStatus() == MODSTATUS_IDLE) ||
            (SLOT(m_cucParent)->GetPtExecSt() == PTEXECST_INACTIVE)) {
            // Ensure that the scan overrun counter is reset and the alarm
            // bit is reset for any channel which is now inactivate or idle.
            m_ucScanOverrunCounter = 0;
            HDevSt[1] &= ~HART_DEVST1_SCANOVRUN_MASK;
        }

        // Rebuild the scan table.
        BuildScanTable();
        if ((BOX->GetModuleStatus() == MODSTATUS_RUN) &&
            (SLOT(m_cucParent)->GetPtExecSt() == PTEXECST_ACTIVE)) {
            m_ulDynGoodCount = 0;
            m_ulDevGoodCount = 0;
            m_ulC48GoodCount = 0;
            m_sScanCounter = TICKS_IN_1_SEC;
            BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_PSTSTATUS_BIT);
        }
        else { // inactive or idle
            InitDevDb(FALSE);
            m_sScanCounter = TICKS_IN_4_SEC;
            m_ucSkipC48Cycles = 0;
            BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_PSTSTATUS_BIT);
        }
    }
}
/*******************************************************************************
*                         clsHartDevDb::CheckDevMismatch                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::CheckDevMismatch(VOID) {
    
    UINT16 usManufacterId,usDeviceType,usDvMfgCd,usDvTypCd;
    if ( m_ucHartVersion >= HARTVERSION_7X) {
        usManufacterId = (((UINT16)HCmd0.str.ucusManufactureId[0]) << 8)|
                          ((UINT16)HCmd0.str.ucusManufactureId[1]);
        usDeviceType   = (((UINT16)HCmd0.str.ucusExpDeviceType[0]) << 8)|
                          ((UINT16)HCmd0.str.ucusExpDeviceType[1]) ;
        usDvMfgCd      = (((UINT16)m_pHartCfgDb7->HDvMfgCd7[0]) << 8) |
                          ((UINT16)m_pHartCfgDb7->HDvMfgCd7[1]);
        usDvTypCd      = (((UINT16)m_pHartCfgDb7->HDvTypCd7[0]) << 8)|
                          ((UINT16)m_pHartCfgDb7->HDvTypCd7[1]);  
        if((usDvMfgCd == 0) || (usDvTypCd == 0))
        {
          //If database is not migrated, hdvmfgcd7 & hdvtypcd7will not be available
          //If a HART 7 device is connected with database not migrated, there will be DevMismatch
          //because hdvmfgcd7(0) & hdvtypcd7(0) is compared with m_usManufactureId & m_usDeviceType respectively
          //so initialize hdvmfgcd7 with hdvmfgcd and hdvtypcd7 with hdvtypcd.
          usDvMfgCd      = (UINT16)(m_pHartCfgDb->HDvMfgCd);
          usDvTypCd      = (UINT16)(m_pHartCfgDb->HDvTypCd);
        }
    }
    else {
        usManufacterId = (UINT16)(HCmd0.str.ucusExpDeviceType[0]);
        usDeviceType   = (UINT16)(HCmd0.str.ucusExpDeviceType[1]);
        usDvMfgCd      = (UINT16)(m_pHartCfgDb->HDvMfgCd);
        usDvTypCd      = (UINT16)(m_pHartCfgDb->HDvTypCd);
    }

    // Process device mismatch, revision mismatch and device changed events.
    if ((m_ucInitCmdIndex > 0) && (TRUE == m_pHartCfgDb->HEnable)) {
        // If HART is enabled and command 0 has completed successfully
        if (HART_GENERIC_MANUFACTURE_ID != usDvMfgCd) {
            // Compare manufacture id, type and revision only if
            // configured manufacture id is not generic.
            if ((usDvMfgCd != usManufacterId) ||
                (usDvTypCd != usDeviceType)) {
                if (0 == (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK)) {
                    // if device mismatch is not set yet
                    HDevSt[1] |= HART_DEVST1_DEVMISMATCH_MASK;
                    if (HCHANMODE_SCAN == m_HChanMode) {
                        InitDevDb(FALSE);
                        BuildScanTable();
                        m_sScanCounter = TICKS_IN_16_SEC;
                    }
                }
            }
            else if (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK) {
                // Device mismatch was present earlier, now got cleared.
                HDevSt[1] &= ~HART_DEVST1_DEVMISMATCH_MASK;
                if (HCHANMODE_SCAN == m_HChanMode) {
                    BuildScanTable();
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
            }

            if (0 == (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK)) {
                // Check rev mismatch only if device mismatch is not set
                if (m_pHartCfgDb->HDvRevCd != m_ucDeviceRevision) {
                    HDevSt[1] |= HART_DEVST1_REVMISMATCH_MASK;
                }
                else {
                    HDevSt[1] &= ~HART_DEVST1_REVMISMATCH_MASK;
                }
            }
        }
        else { 
            // Generic template is loaded. Reset mismatches if already set.
            HDevSt[1] &= ~HART_DEVST1_REVMISMATCH_MASK;

            if (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK) {
                HDevSt[1] &= ~HART_DEVST1_DEVMISMATCH_MASK;
                if (HCHANMODE_SCAN == m_HChanMode) {
                    BuildScanTable();
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
            }
        }

        BOOL bDevChanged = FALSE;
        for (UINT8 ucCount = 0; ucCount < HART_DEVICEID_SIZE; ucCount++) {
            if (m_pHartCfgDb->HDevIdCd[ucCount] != m_UniqueAddress.str.ucDeviceId[ucCount]) {
                bDevChanged = TRUE;
            }
        }
        if (TRUE == bDevChanged) {
            HDevSt[1] |= HART_DEVST1_DEVCHANGED_MASK;
        }
        else {
            HDevSt[1] &= ~HART_DEVST1_DEVCHANGED_MASK;
        }
    }
}
/*******************************************************************************
*                        clsHartDevDb::CheckRangeMismatch                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
VOID clsHartDevDb::CheckRangeMismatch(VOID) {
#if defined(IOMTYPE_UIO)
    // Only for AIH
    if (AIH_SLOT(m_cucParent)->GetPvChar() == PVCHAR_DEVRANGE) {
        if (m_ucInitCmdIndex > HART_INITCMD14_INDEX) {
            // if command 14 has completed
            if ((AIH_SLOT(m_cucParent)->GetPvExEUHi() != Url) ||
                (AIH_SLOT(m_cucParent)->GetPvExEULo() != Lrl)) {
                HDevSt[2] |= HART_DEVST2_RANGEMISMATCH_MASK;
            }
            else if (m_ucInitCmdIndex > HART_INITCMD15_INDEX)  {
                // if command 15 has completed
                if ((AIH_SLOT(m_cucParent)->GetPvEUHi() != Urv) ||
                    (AIH_SLOT(m_cucParent)->GetPvEULo() != Lrv)) {
                    HDevSt[2] |= HART_DEVST2_RANGEMISMATCH_MASK;
                }
                else {
                    HDevSt[2] &= ~HART_DEVST2_RANGEMISMATCH_MASK;
                }
            }
        }
    }    
    else {
        HDevSt[2] &= ~HART_DEVST2_RANGEMISMATCH_MASK;
    }       

#else
    if (SLOT(m_cucParent)->GetPvChar() == PVCHAR_DEVRANGE) {
        if (m_ucInitCmdIndex > HART_INITCMD14_INDEX) {
            // if command 14 has completed
            if ((SLOT(m_cucParent)->GetPvExEUHi() != Url) ||
                (SLOT(m_cucParent)->GetPvExEULo() != Lrl)) {
                HDevSt[2] |= HART_DEVST2_RANGEMISMATCH_MASK;
            }
            else if (m_ucInitCmdIndex > HART_INITCMD15_INDEX)  {
                // if command 15 has completed
                if ((SLOT(m_cucParent)->GetPvEUHi() != Urv) ||
                    (SLOT(m_cucParent)->GetPvEULo() != Lrv)) {
                    HDevSt[2] |= HART_DEVST2_RANGEMISMATCH_MASK;
                }
                else {
                    HDevSt[2] &= ~HART_DEVST2_RANGEMISMATCH_MASK;
                }
            }
        }
    }    
    else {
        HDevSt[2] &= ~HART_DEVST2_RANGEMISMATCH_MASK;
    }
#endif    
}
#endif
/*******************************************************************************
*                            clsHartDevDb::WriteHCmdData                       *
*                            ===========================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::WriteHCmdData(HARTCOMMAND a_HartCmd,UINT8 *a_ucDataPtr) {
    UINT8 *ucPtr,ucSize,ucDefData = 0;
    
    switch (a_HartCmd) {
    case HARTCOMMAND_ZERO:
        ucPtr = HCmd0.ucBytes;
        ucSize = HART_CMD0_RESPONSE_SIZE;
        break;
    case HARTCOMMAND_TWELVE:
        ucPtr = HCmd12.ucBytes;
        ucSize = HART_CMD12_RESPONSE_SIZE;
        ucDefData = 0xFF;
        break;
    case HARTCOMMAND_THIRTEEN:
        ucPtr = HCmd13.ucBytes;
        ucSize = HART_CMD13_RESPONSE_SIZE;
        ucDefData = 0xFF;
        break;
    case HARTCOMMAND_FOURTEEN:
        ucPtr = HCmd14.ucBytes;
        ucSize = HART_CMD14_RESPONSE_SIZE;
        ucDefData = 0xFF;
        break;
    case HARTCOMMAND_FIFTEEN:
        ucPtr = HCmd15.ucBytes;
        ucSize = HART_CMD15_RESPONSE_SIZE;
        ucDefData = 0xFF;
        break;
    case HARTCOMMAND_SIXTEEN:
        ucPtr = HCmd16.ucBytes;
        ucSize = HART_CMD16_RESPONSE_SIZE;
        break;
    case HARTCOMMAND_TWENTY:
        ucPtr = HLongTag.ucBytes;
        ucSize = HART_CMD20_RESPONSE_SIZE;
        // Uninitialised strings must be set to the '?' (0x3F) character. 
        //Reference: Page 16 (section 5.1.2) of HCF_SPEC-99, Revision 9.0
        ucDefData = 0x3F; 
        break;
    case HARTCOMMAND_FOURTYEIGHT:
        ucPtr = HCmd48.ucBytes;
        ucSize = HART_CMD48_RESPONSE_SIZE;
        break;
    default:
        HardFail(HF_BADPROGRAMJUMP,HARTDB_CPP,__LINE__);
    }

    if (NULL == a_ucDataPtr) { // Initialize the command data
        while (ucSize > 0) {
            ucPtr[--ucSize] = ucDefData;
        }

        if (HARTCOMMAND_FOURTEEN == a_HartCmd) {
            // Special case of command 14 to initialize transducer serial number to
            // zero while rest of the command data should be initialized with 0xFF.
            for (ucSize = 0 ; ucSize < HART_TRSERIALNUMBER_SIZE; ucSize++) {
                HCmd14.ucBytes[ucSize] = 0;
            }
        }
    }
    else { // Update the command data with the new value
        for (UINT8 ucCount = 0; ucCount < ucSize;) {
            ucPtr[ucCount++] = *a_ucDataPtr++;
        }
    }
}
/*******************************************************************************
*                        clsHartDevDb::BumpPollingAddress                      *
*                        ================================                      *
* PURPOSE:                                                                     *
*    Increment polling address for device discovery.                           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HSYNCSTATUS - always returns HSYNCSTATUS_DROPSYNC to release the modem.   *
* PROCESS:                                                                     *
*    1. If this method was called just after command 0 poll failed for address *
*       zero, initialize entire HART database.                                 *
*    2. Increment the polling address and set scan counter for scheduling the  *
*       the next command 0 poll depending on the configuration.                *
*    3. If all 16 addresses are tried, suspend command zero poll for a longer  *
*       interval based on the configuration.                                   *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete method.                   *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::BumpPollingAddress(VOID) {
    // If the command zero poll failed for address 0, 
    // initialize the HART database fully.
    if (0 == m_ucPollingAddress) {
        InitDevDb(TRUE); 
    }

    SetHComSts(HCOMSTS_NORESPONSE);
    // Reset communication status to good for next transaction.
    m_ucCommStatus = HCOMSTS_GOOD;

    if (m_ucPollingAddress < HART_POLADDR_MAXVAL) {
        m_ucPollingAddress++; 

        // Schedule next polling command accoring to the configuration.
        SetScanCounterForRediscovery(SLOT(m_cucParent)->GetPntType());
    }
    else {
        // If no device is found after all 16 polling addresses,
        // reset polling address, and start all over again after a minute.
        m_ucPollingAddress = 0;
        m_sScanCounter = TICKS_IN_60_SEC;
    }

    return HSYNCSTATUS_DROP_SYNC;
}
/*******************************************************************************
*                       clsHartDevDb::ScheduleFromInitTable                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
*    Schedule the next initialization command.                                 *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HSYNCSTATUS - KEEP_SYNC for back-to-back message without releasing modem. *
*                  DROP_SYNC to release the modem and to schedule later.       *
* PROCESS:                                                                     *
*    1. Advance m_ucInitCmdIndex and setup channel object for scheduling the   *
*       command specified at this index in the initialization table unless the *
*       last message was not command 109. If the last message is 109, it menas *
*       that a bursting device was discovered and command 109 was issued to    *
*       turn off the burst mode, but it did not result in configuration change.*
*       In that case, initialize HART database and schedule next command zero  *
*       poll after four seconds.                                               *
*    2. If all commands in the initialization table completed, change channel  *
*       state to SCAN, notify SWMUX that initialization is complete and build  *
*       the scan table. Setup scan counter according to the channel state and  *
*       configuration.                                                         *
*    3. Otherwise, if the last command was not command 48, schedule the next   *
*       command from the INIT table as back-to-back messsage and disable scan  *
*       counter. If last command was C48, break the intialization sequence and *
*       setup scan counter to continue after 2 seconds. This is done to speed  *
*       up the HART event recovery for all channels.                           *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete method.                   *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::ScheduleFromInitTable(VOID) {

#if defined(IOMTYPE_UIO)
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(m_cucParent));
#endif

    // If discovery operation is going on, advance m_ucInitCmdIndex to 
    // the next message if the last command was not command 109.
    if (HARTCOMMAND_HUNDREDNINE != m_ucLastReqCmd) {
        m_ucInitCmdIndex++;
    }
    else { // if last command was 109 and configuration change did not result
        InitDevDb(TRUE);
        m_sScanCounter = TICKS_IN_4_SEC;
        return HSYNCSTATUS_DROP_SYNC; 
    }
    m_ScanMsg   = HSCANMSG_NONE;
    if (m_ucInitCmdIndex > HART_INITCOMMAND_COUNT) { 
        // Initialization commands completed
        if (TRUE == m_pHartCfgDb->HEnable) {
            BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_INITCMPLT_BIT);
            IncrementHCfgChCounter();
        }
        m_HChanMode = HCHANMODE_SCAN;
        BuildScanTable();
        if ((MODSTATUS_RUN == BOX->GetModuleStatus()) && 
            (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt())) {          
            HSCANMSG NewMsg = SetupScanMessage(m_ucScanNo,m_ucB2BNo);
            m_ScanMsg       = NewMsg;
            if (HSCANMSG_NONE != NewMsg) {
                // If a scan is configured for this cycle, process the first
                // row of the scan table without dropping sync. Update last 
                // command also since this is a back-to-back message.
                m_ucLastReqCmd  = m_ucNextReqCmd;
                m_ucpLastXmtPtr = m_ucpNextXmtPtr;
                if (HSCANMSG_PST == NewMsg) {
                    m_HChanType = HCHANTYPE_PASSTHROUGH;
                    pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;
                }
                else {
                    m_HChanType = HCHANTYPE_CHANNEL;
                }

                // Disable scan counter since back-to-back message is scheduled.
                m_sScanCounter = TICKS_SYNCED_CHAN;
                return HSYNCSTATUS_KEEP_SYNC;
            }
        }
        else {
            // Control state is inactive or idle. 
            // Set data initialization complete
            m_HDataInit = HDATAINIT_COMPLETE;
        }

        // No back-to-back message. Release modem.
        m_sScanCounter = TICKS_IN_1_SEC;
        return HSYNCSTATUS_DROP_SYNC;
    }
    else { // Initialization is not complete. 

#if !defined(IOMTYPE_UIO)
        // FOR UIO:
        // Pass through scheduling is removed, because after command 0 and command 48 scheduling
        // during initializing, channel is disconnected, during which PST's are searched and scheduled.

        if (m_ucInitCmdIndex > 1) 
        {
            // Command 48 and hence event initialization (m_HEventInit) is complete now. 
            // Before further init commands are scheduled, process up to four messages 
            // in the pass-through queue. Ensure that ChanType to CHANNEL so that 
            // SetupPassThrough() will process passthrough queue. This is necessary 
            // because as per the current implementation SetupPassThrough() will process 
            // the next pass-through message only if the last one was complete.
            // This deceision is made by checking the ChanType.
            m_HChanType = HCHANTYPE_CHANNEL;

            if (SetupPassThrough() == HSCANMSG_PST) 
            {
                // Found another pass-through message to the same device
                // waiting in the pass-through queue. Update the last command 
                // and transmit pointer since this is a back-to-back message.
                m_ucLastReqCmd  = m_ucNextReqCmd;
                m_ucpLastXmtPtr = m_ucpNextXmtPtr;
                m_ScanMsg       = HSCANMSG_PST;
                m_ucB2BPstMsgCount++;
                m_HChanType = HCHANTYPE_PASSTHROUGH;
                pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;

                // Schedule next request without disconnecting modem.
                return HSYNCSTATUS_KEEP_SYNC;
            }
        }

        // Passthrough processing is complete. Reset ChanType   
        // to CHANNEL and schedule next initialization command.
#endif
        m_HChanType = HCHANTYPE_CHANNEL;
        if (HARTVERSION_5X == m_ucHartVersion) {
            if ((HART5_INIT_COMMANDS[m_ucInitCmdIndex - 1][0] == HARTCOMMAND_SIX) && (0 == m_ucPollingAddress)) {
                // If polling address is already zero
                // there is no need to issue command 6
                m_ucInitCmdIndex++; 
            }           
            m_ucNextReqCmd  = HART5_INIT_COMMANDS[m_ucInitCmdIndex - 1][0];
            m_ucpNextXmtPtr    = (UINT8 *) &HART5_INIT_COMMANDS[m_ucInitCmdIndex - 1][0];
        }
        else if (HARTVERSION_6X == m_ucHartVersion)
        {  // (HARTVERSION_60 == Version) 
            if ((HART6_INIT_COMMANDS[m_ucInitCmdIndex - 1][0] == HARTCOMMAND_SIX) && (0 == m_ucPollingAddress)) {
                // If polling address is already zero
                // there is no need to issue command 6
                m_ucInitCmdIndex++; 
            }
            m_ucNextReqCmd  = HART6_INIT_COMMANDS[m_ucInitCmdIndex - 1][0];
            m_ucpNextXmtPtr = (UINT8 *) &HART6_INIT_COMMANDS[m_ucInitCmdIndex - 1][0];
        }
        else if(m_ucHartVersion >= HARTVERSION_7X){
            if ((HART7_INIT_COMMANDS[m_ucInitCmdIndex - 1][0] == HARTCOMMAND_SIX) && (0 == m_ucPollingAddress)) {
                // If polling address is already zero
                // there is no need to issue command 6
                m_ucInitCmdIndex ++;
            }

            if(HART7_INIT_COMMANDS[m_ucInitCmdIndex - 1][0] == HARTCOMMAND_THIRTYEIGHT){
                //Current config change counter is required for CMD38.
                //HART 7 device does not reset config change flag if there is a config change count mismatch.
                //So CMD 00 is sent before CMD 38 to get config change counter.
                if(HARTCOMMAND_ZERO == m_ucLastReqCmd) {
                   memcopy(&HART7_CMD38[2],HCmd0.str.ucusConfigChgCnt,sizeof(HCmd0.str.ucusConfigChgCnt));
                   m_ucNextReqCmd   = HART7_CMD38[0];
                   m_ucpNextXmtPtr = (UINT8 *) &HART7_CMD38[0];
                }
                else {
                     m_ucNextReqCmd   = HARTCMD0[0];
                     m_ucpNextXmtPtr = (UINT8 *)&HARTCMD0[0];
                     m_ucInitCmdIndex --;
                }
            }
            /*
            else if(HART7_INIT_COMMANDS[m_ucInitCmdIndex - 1][0] == HARTCOMMAND_FOURTYEIGHT){
                memcopy(&HART7_CMD48[2],HCmd48.ucBytes,HART7_CMD48_REQUESTDATA_SIZE);
                m_ucNextReqCmd  = HART7_CMD48[0];
                m_ucpNextXmtPtr = (UINT8 *) &HART7_CMD48[0];
            }
            */
            else {
                m_ucNextReqCmd  = HART7_INIT_COMMANDS[m_ucInitCmdIndex - 1][0];
                m_ucpNextXmtPtr = (UINT8 *) &HART7_INIT_COMMANDS[m_ucInitCmdIndex - 1][0];
            }
        }


        // If channel is not configured, release the modem so that
        // configured channels get the most of the modem bandwidth.
        if (SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED) {
            m_sScanCounter = TICKS_IN_16_SEC;
            return HSYNCSTATUS_DROP_SYNC;
        }

        if ((HSCANRATE_1SEC == HTotalRate) || (HARTCOMMAND_FOURTYEIGHT == m_ucNextReqCmd)) {
            // Do not release the modem for one second channels. Also, do not release  
            // modem for all channels in case next command is command 48. This is to   
            // allow event recovery to be completed quickly for all channels. Update   
            // last command also since this is a back-to-back message.
            m_ucLastReqCmd  = m_ucNextReqCmd;
            m_ucpLastXmtPtr = m_ucpNextXmtPtr;
            m_HChanType     = HCHANTYPE_CHANNEL;
            return HSYNCSTATUS_KEEP_SYNC;
        }

        // Release modem after each init command in all other cases.
        // Set scan counter for next schedule based on the configured rates.
        m_sScanCounter = (HSCANRATE_2SEC / HTotalRate); 

        // Make sure that the interval is not more than 4 second for any rate.
        if (m_sScanCounter > TICKS_IN_4_SEC) m_sScanCounter = TICKS_IN_4_SEC;
        return HSYNCSTATUS_DROP_SYNC;
    }
}
/*******************************************************************************
*                       clsHartDevDb::ScheduleFromScanTable                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
*    Process the second and third columns of the scan table                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HSYNCSTATUS - KEEP_SYNC for back-to-back message without releasing modem. *
*                  DROP_SYNC to release the modem and to schedule later.       *
* PROCESS:                                                                     *
*    1. Advance m_ucB2BNo (column number) to check scan table for any message  *
*       configured in the next column of the current row. If yes, schedule it  *
*       as back-to-back message without releasing the modem.                   *
*    2. If all messages in a row are completed, return DROP_SYNC to release    *
*       the modem for non-synced channels. For synced channels, advance to the *
*       next row, search until the next valid entry is found and schedule it   *
*       as back-to-back message without disconnecting from the current modem.  *
*    3. If passthrough is going on for this channel and the control state is   *
*       inactive or idle and HCUAVAIL is greater than 40%, schedule next pass  *
*       through as back-to-back message. If there is no passthrough pending in *
*       the queue, schedule command 48 to keep the modem synced.               *
*       NOTE that comparison of HCUAVAIL is done with 10.0. This is becuase    *
*       30% of HCUAVAIL is already accounted on this channel since it is doing *
*       passthrough. So value of 10.0 really means that HCUAVAIL was 40% just  *
*       before passthrough on this channel started.                            *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete method.                   *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::ScheduleFromScanTable(VOID) {

#if defined(IOMTYPE_UIO)
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(m_cucParent));
#endif

    HSCANMSG NewMsg = HSCANMSG_NONE;

    do {
        m_ucB2BNo++;
        if (m_ucB2BNo > FINAL_B2B_MSG) {
            // Final back-to-back message just finished
            m_ucB2BNo = FIRST_SCAN_MSG;

            BOOL bModemNeedDiag = FALSE;

            // Modem will never be called out as suspect in UIO.
#if !defined(IOMTYPE_UIO)
            for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) {
                if (pHartModem[ucModem]->GetModemState() == HMODEMSTATE_SUSPECT) {
                    bModemNeedDiag = TRUE;
                    break;
                }
            }
#endif
            if ((HartGetEffectiveDsa() == 0u) || 
                (bModemNeedDiag == TRUE) ||
                (MODSTATUS_IDLE == BOX->GetModuleStatus()) ||
                (PTEXECST_INACTIVE == SLOT(m_cucParent)->GetPtExecSt())) {
                // If IOM is idled or unloaded or became secondary or 
                // channel is inactivated or any modem requires diagnostics
                // then release the current modem. 
                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
            if (HSCANRATE_1SEC == HTotalRate) {
                // If the total scan rate is one second, process the next 
                // row of the scan table without releasing the modem.
                m_ucScanNo++;
                if (m_ucScanNo > MAX_CYCLE_NUMBER) {
                    m_ucScanNo = MIN_CYCLE_NUMBER;
                }
            }
            else {
                // If the total rate is less than one second rate, release
                // modem to let it process other channels. Next row will be
                // processed when scan counter expires. Make sure that the
                // scan counter is not disabled when releasing the modem.
                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
        }

        if (HSCANRATE_1SEC == HTotalRate) {
            NewMsg = SetupScanMessage(m_ucScanNo,m_ucB2BNo);
#if defined (IOMTYPE_UIO)
            m_ScanMsg = NewMsg;
            // Check added to exit the loop if no scan message is present in the scan table
            if(NewMsg == HSCANMSG_NONE) {
                m_ucB2BNo = FIRST_SCAN_MSG;
                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
#endif
        }
        else {
            NewMsg = SetupScanMessage(m_ucSavedScanNo,m_ucB2BNo);
#if defined(IOMTYPE_UIO)
            m_ScanMsg = NewMsg;
            // Check added to exit the loop if no scan message is present in the scan table
            if(NewMsg == HSCANMSG_NONE) {
                m_ucB2BNo = FIRST_SCAN_MSG;
                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
#endif
        }

        // Loop until a valid message is found. If the total scan rate is less
        // than one second rate, this method would have returned, when the
        // final back-to-back message for this scan cycle (current row of scan 
        // table) is complete.
    } while (HSCANMSG_NONE == NewMsg);

    // Update last command also since this is a back-to-back message
    m_ucLastReqCmd  = m_ucNextReqCmd;
    m_ucpLastXmtPtr = m_ucpNextXmtPtr;
#if !defined(IOMTYPE_UIO)
    m_ScanMsg       = NewMsg;
#endif
    if (HSCANMSG_PST == NewMsg) {
        m_HChanType = HCHANTYPE_PASSTHROUGH;
        pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;
    }
    else {
        m_HChanType = HCHANTYPE_CHANNEL;
    }

    if (HSCANRATE_1SEC ==  HTotalRate) {
        // Make sure that no scan overrun alarm is posted for 
        // this channel as it is operating with dedicated modem now.
        m_ucScanOverrunCounter = 0;
        HDevSt[1] &= ~HART_DEVST1_SCANOVRUN_MASK;
    }

    return HSYNCSTATUS_KEEP_SYNC;
}
/*******************************************************************************
*                         clsHartDevDb::SetupScanMessage                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
*    Initialize transmit and receive pointers and other channel members for a  *
*    scheduling a specificed command from the scan table.                      *
* ARGUMENTS:                                                                   *
*    1. a_ucRowNo - Scan table row number.                                     *
*    2. a_ucColNo - Scan table column number.                                  *
* RETURN:                                                                      *
*    HSCANMSG - DYN for dynamic scan, DEV for device scan, C48 for command 48  *
*               scan, PST for passthrough message and NONE for no message.     *
* PROCESS:                                                                     *
*    1. Setup channel object according to the HSCANMSG entry at the specified  *
*       row and column of the scan table.                                      *
*    2. If SCNMSG entry is C48, check the value of m_ucSkipC48Cycles and if it *
*       is greater than zero, decrement it and return NONE to skip this cycle. *
*    3. If SCNMSG entry is PST, call SetupPassthrough to check the passthrough *
*       queue in the shared RAM. If any pending request is found, schedule it; *
*       otherwise return NONE.                                                 *
* NOTES:                                                                       *
*    1. This method is called from the following methods - ChannelHeartbeat,   *
*       ScheduleFromInitTable and ScheduleFromScanTable.                       *
*******************************************************************************/
HSCANMSG clsHartDevDb::SetupScanMessage(UINT8 a_ucRowNo,UINT8 a_ucColNo) {
    switch (m_ScanMsgTbl[a_ucRowNo - 1][a_ucColNo]) {
    case HSCANMSG_NONE:
        return HSCANMSG_NONE;
    case HSCANMSG_DYN:
        m_ucNextReqCmd  = m_ucDynScan[0];
        m_ucpNextXmtPtr = &m_ucDynScan[0];
        return HSCANMSG_DYN;
    case HSCANMSG_DEV:
        if ( m_ucHartVersion < HARTVERSION_7X) {
            //Maximum of 4 device variables for hart revision < 7.
            if(m_ucDevScan[1] > HART6_MAXVAR_COUNT) {
                m_ucDevScan[1] = HART6_MAXVAR_COUNT;
            }
        }
        m_ucNextReqCmd  = m_ucDevScan[0];
        m_ucpNextXmtPtr = &m_ucDevScan[0];
        return HSCANMSG_DEV;
    case HSCANMSG_C48:
        if (m_ucSkipC48Cycles > 0) {
            m_ucSkipC48Cycles--;
            return HSCANMSG_NONE;
        }
        m_ucNextReqCmd   = HARTCMD48[0];
        m_ucpNextXmtPtr  = (UINT8 *) &HARTCMD48[0];
        /*
        if ( m_ucHartVersion >= HARTVERSION_7X) {
            memcopy(&HART7_CMD48[2],HCmd48.ucBytes,HART7_CMD48_REQUESTDATA_SIZE);
            m_ucNextReqCmd  = HART7_CMD48[0];
            m_ucpNextXmtPtr = (UINT8 *) &HART7_CMD48[0];
        } else { 
            m_ucNextReqCmd   = HARTCMD48[0];
            m_ucpNextXmtPtr  = (UINT8 *) &HARTCMD48[0];
        }
        */
        return HSCANMSG_C48;
#if !defined(IOMTYPE_UIO)
    case HSCANMSG_PST:
        return SetupPassThrough();
#endif
    }

    return HSCANMSG_NONE;
}
/*******************************************************************************
*                          clsHartDevDb::SetupPassThrough                      *
*                          ==============================                      *
* PURPOSE:                                                                     *
*    Check passthrough request queue and schedule any pending message.         *
* ARGUMENTS:                                                                   *
*    NONE.                                                                     *
* RETURN:                                                                      *
*    HSCANMSG - PST if a passthrough message is pending; otherwise NONE.       *
* PROCESS:                                                                     *
*    1. If last passthrough message is still running, return.                  *
*    2. Scan the passthrough queue for any pending message for this channel.   *
*       The channel object member m_ucPstRemIndex tracks the next index in the *
*       passthrough queue to be examined.                                      *
*    3. Check command amd address before scheduling. Always block command zero *
*       and command 38. If the address does not match with the address in the  *
*       channel object, return DEAD status in passsthrough status table.       *
*    4. If the above tests pass, prepare channel object for passthrough and    *
*       flush the passthrough response buffer. Return PST to schedule it.      *
* NOTES:                                                                       *
*    1. This method is called from SetupScanMessage, ScheduleFromInitTable,    *
*       and ReceptionComplete.                                                 *
*******************************************************************************/
HSCANMSG clsHartDevDb::SetupPassThrough(VOID) 
{
#if defined(IOMTYPE_UIO)
    UINT8 modem = FPGA.GetChannelModem(m_cucParent);
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(modem);
#endif

#if !defined(IOMTYPE_UIO)
// AF: VW removed this
    // If the last passthrough transaction has not completed 
    // do not process queue for new passthrough message.
    if (HCHANTYPE_PASSTHROUGH == m_HChanType) 
    {
        return HSCANMSG_NONE;
    }
#endif

#if defined (IOMTYPE_UIO)
    if (BOX->GetInitPntType(m_cucParent) == PNTTYPE_ANALOGOUTPUT) 
    {
        // Stop all passthrough communication if AO channel is red tagged.
        if (AOH_SLOT(m_cucParent)->IsRedTagged() == TRUE) 
        {
            return HSCANMSG_NONE;
        }
    }
#elif defined(IOMTYPE_AOH)
    // Stop all passthrough communication if AO channel is red tagged.
    if (SLOT(m_cucParent)->IsRedTagged() == TRUE) 
    {
        return HSCANMSG_NONE;
    }
#endif

#if defined (IOMTYPE_UIO)
    if((SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED) ||
       (m_pHartCfgDb->HEnable == FALSE) ||
       (m_HDataInit != HDATAINIT_COMPLETE))
    {
       return HSCANMSG_NONE;
    }
#endif

    HARTCOMMAND PstCmd;
    for (UINT8 ucCount = 0, ucPstIndex = m_ucPstRemIndex; ucCount < HPST_OBJECTCOUNT; ucCount++) {
        // Increment the pass-through index first so that we will not keep looking 
        // at the last index all the time. Note that m_ucPstRemIndex is initialized
        // to 16 by constructor so that it will start processing at index 0.
        ucPstIndex++;
        if (ucPstIndex >= HPST_OBJECTCOUNT) {
            ucPstIndex = 0;
        }

        if ((pHartPst[ucPstIndex]->m_ucSlotNumber == m_cucParent) && 
            (pHartPst[ucPstIndex]->m_PstStatus == HPSTSTATUS_INIT)) {
            m_ucPstRemIndex = ucPstIndex;
#if defined (IOMTYPE_UIO)
            // Channel has HART communication failure
            // Mark the PST as dead and continue, so that all PST for this channel is marked as dead
            if(m_bHartChanFail == TRUE) 
            {
                pHartPst[ucPstIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
                pHartPst[ucPstIndex]->m_PstStatus = HPSTSTATUS_DEAD;
                continue;
            }
#endif
            // Check delimiter of the passthrough message. HARTP will not
            // passthrough any message with a delimiter for polling address.
            // NOTE: Passthrough request starts with delimiter. SWMUX strips
            // all preamble bytes before sending passthrough message to IOP.
#if defined(IOMTYPE_UIO)
            if ((g_ucHPstReqBuffer[modem][m_ucPstRemIndex][HPST_DELIMITER_OFFSET] & HART_ADDR_TYPE_MASK) == 0) {
#else
            if ((g_ucHPstReqBuffer[m_ucPstRemIndex][HPST_DELIMITER_OFFSET] & HART_ADDR_TYPE_MASK) == 0) {
#endif
                // Bit for unique address in the delimiter is not set.
                // Update passthrough status table for message failed.
                pHartPst[m_ucPstRemIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
                pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_DEAD;
                continue; // Check next passthrough index
            }
            else { // Passthrough message has unique address. Compare the 
                // address with the address in the channel object. If the
                // addreess does not match, there is no point to send this
                // request. Return failed status immediately.
                if ((m_UniqueAddress.ucBytes[0] & HART_MANUFACTURE_ID_MASK)
#if defined(IOMTYPE_UIO)
                    != (g_ucHPstReqBuffer[modem][m_ucPstRemIndex][HPST_ADDRESS_OFFSET] & HART_MANUFACTURE_ID_MASK)) {
#else
                    != (g_ucHPstReqBuffer[m_ucPstRemIndex][HPST_ADDRESS_OFFSET] & HART_MANUFACTURE_ID_MASK)) {
#endif
                    pHartPst[m_ucPstRemIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
                    pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_DEAD;
                    continue; // Check next passthrough index
                }
                
                for (UINT8 ucAddr = 1; ucAddr < HART_LONGADDR_LENGTH; ucAddr++) {
                    if (m_UniqueAddress.ucBytes[ucAddr] != 
#if defined(IOMTYPE_UIO)
                        g_ucHPstReqBuffer[modem][m_ucPstRemIndex][ucAddr + HPST_ADDRESS_OFFSET]) {
#else
                        g_ucHPstReqBuffer[m_ucPstRemIndex][ucAddr + HPST_ADDRESS_OFFSET]) {
#endif
                        pHartPst[m_ucPstRemIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
                        pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_DEAD;
                        continue; // Check next passthrough index
                    }
                }

                // Check the command byte in the passthrough message. HARTP
                // will not passthrough command 0 and 38 at any time.
#if defined(IOMTYPE_UIO)
                PstCmd = (HARTCOMMAND)g_ucHPstReqBuffer[modem][m_ucPstRemIndex][HPST_COMMAND_OFFSET];
#else
                PstCmd = (HARTCOMMAND)g_ucHPstReqBuffer[m_ucPstRemIndex][HPST_COMMAND_OFFSET];
#endif
                if ((PstCmd == HARTCOMMAND_ZERO) || (PstCmd == HARTCOMMAND_THIRTYEIGHT)) {
                    pHartPst[m_ucPstRemIndex]->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
                    pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_DEAD;
                    continue; // Check next passthrough index
                }
            }

            // All tests passed. Return HSCANMSG_PST so that channel object
            // will submit this request to stack.
#if defined(IOMTYPE_UIO)
            m_ucNextPstCmd  = PstCmd;
            m_ucpNextPstXmtPtr = g_ucHPstReqBuffer[modem][m_ucPstRemIndex];
#else
            m_ucNextReqCmd  = PstCmd;
            m_ucpNextXmtPtr = g_ucHPstReqBuffer[m_ucPstRemIndex]; 
#endif
            // Clear the response buffer at the current index.
            pHartPst[m_ucPstRemIndex]->m_PstRcvBuffer.Flush();

            // Setup passthrough present throttling count for 16 seconds only if 
            // cold start bit or configuration changed bit is not set. If either 
            // of these bits is set, let the passthrough present throttling count 
            // to expire so that device re-dsicovery will be scheduled.
            if (0 == (m_ucDeviceStatus & (HART_DEVSTS_COLD_START | HART_DEVSTS_CFG_CHANGED))) {
                m_ucPstPresentCounter = TICKS_IN_16_SEC;
            }
            return HSCANMSG_PST;
        }
    }

    // No passthrough message to process for this channel
    return HSCANMSG_NONE;
}
/*******************************************************************************
*                          clsHartDevDb::UpdateDatabase                        *
*                          ============================                        *
* PURPOSE:                                                                     *
*    Update the IOM database with HART data from the received response.        *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HREPLYSTATUS - GOOD, CONTINUE for scheduling next message.                *
*                   BAD, REINIT for rediscovering the device.                  *
*                   MORE for issuing command 48.                               *
* PROCESS:                                                                     *
*    1. Update the device status byte in the database. If the channel mode is  *
*       SCAN, check inidividual bits and rediscover or issue C48 as required.  *
*    2. Call the good handler or bad handler depending on the command and the  *
*       response code.                                                         *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete.                          *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::UpdateDatabase(VOID) {
    m_ucRcvBufIndex = 0;

    // UpdateDatabase will be called only for good messages. So the status
    // bytes will be response code and device status respectively.
    m_ucRcvMsgLen    = m_ChanRcvBuffer.At(m_ucRcvBufIndex++) - 2;
    m_ucLastRespCode = m_ChanRcvBuffer.At(m_ucRcvBufIndex++);
    m_ucDeviceStatus = m_ChanRcvBuffer.At(m_ucRcvBufIndex++);

#if defined(PMIO_DEBUG) && (0)
	if ((m_ucLastReqCmd == HARTCOMMAND_NINE) ||
		(m_ucLastReqCmd == HARTCOMMAND_THIRTYTHREE))
	{
		ucDbgCnt = 0;
		ucDumpBuff[ucDbgCnt++] = m_ucLastReqCmd;  //09 (09)
		ucDumpBuff[ucDbgCnt++] = m_ucRcvMsgLen;   //25 (37)
		ucDumpBuff[ucDbgCnt++] = m_ucLastRespCode;//1E (30)
		ucDumpBuff[ucDbgCnt++] = m_ucDeviceStatus;//00
		ucDumpBuff[ucDbgCnt++] = HDevSt[0];       //00
		ucDumpBuff[ucDbgCnt++] = m_cucParent;     //01
		ucDumpBuff[ucDbgCnt++] = m_HChanMode;     //01
		ucDumpBuff[ucDbgCnt++] = m_ucPstPresentCounter; //00
		ucDumpBuff[ucDbgCnt++] = m_bCmd38FailReported;  //00  
		ucDumpBuff[ucDbgCnt++] = m_ucHartVersion;//07
		ucDumpBuff[ucDbgCnt++] = m_ucDynScan[0]; //09
		ucDumpBuff[ucDbgCnt++] = m_ScanMsg;      //02
	}
#endif

    if ((HARTCOMMAND_SIX == m_ucLastReqCmd) ||
        (HARTCOMMAND_FIFTYNINE == m_ucLastReqCmd)) {
        // Reset the config changed bit in the device status byte if the last
        // command was 6 or 59. These are the isssued by the firmware during
        // initialization and we do not want to send the configuration change
        // alarm that may result from these write commands.
        m_ucDeviceStatus &= ~HART_DEVSTS_CFG_CHANGED;
    }

    UINT8 ucNewSts = HDevSt[0] ^ m_ucDeviceStatus;
    SetHDevSt(0,m_ucDeviceStatus);
    BOX->SetHGDevSt(m_cucParent,m_ucDeviceStatus);
    if (HCHANMODE_SCAN == m_HChanMode) {
        HREPLYSTATUS ReplyStatus = HREPLYSTATUS_GOOD;
        // First check whether cold start bit is set
        if (m_ucDeviceStatus & HART_DEVSTS_COLD_START) {
            // Return REINIT to rediscover the device. Delay rediscovery
            // until the passthrough present throttling counter expires.
            if (0 == m_ucPstPresentCounter) {
                ReplyStatus = HREPLYSTATUS_REINIT; 
            }
        }

        // Check whether config change bit has set.
        if (m_ucDeviceStatus & HART_DEVSTS_CFG_CHANGED) {
            // Return REINIT to rediscover the device. Delay rediscovery
            // until the passthrough present throttling counter expires.
            // Also, check that m_bCmd38FailReported is not set. If it is
            // set, it means that the device is write protected with config
            // changed bit set and is not allowing to reset it. There is no
            // point in reinitializing here. Instead, command 38 will be 
            // scheduled once a minute to detect any change in write protect
            // status in future.
            if ((0 == m_ucPstPresentCounter) && (FALSE == m_bCmd38FailReported)) {
                // Check for HART command 50 is added to have at least one 
                // dynamic scan to happen before the re-initializaiton happens.

                //HART 5 does not support config change counter. So increment member variable.
                if ( m_ucHartVersion < HARTVERSION_6X) { 
                    HT5_CfgChngCnt ++; 
                }
                ReplyStatus = HREPLYSTATUS_REINIT; 
            }
        }

        if (ucNewSts) { 
            // Check device malfunction bit has toggled.
            if (ucNewSts & HART_DEVSTS_DEV_MALFUNCTION) {
                // Do not reschedule command 48 immediately if it is just
                // scheduled. Also a command 38 might follow a command 48
                // to check the write protect status. In both cases, hold
                // command 48 scanning until next cycle.
                if ((HARTCOMMAND_FOURTYEIGHT != m_ucLastReqCmd) && 
                    (HARTCOMMAND_THIRTYEIGHT != m_ucLastReqCmd)) {
                    ReplyStatus = HREPLYSTATUS_MORE; 
                }
            }

            // Then check more status available bit has toggled.
            if (ucNewSts & HART_DEVSTS_MORE_STATUS) {
                // Do not reschedule command 48 immediately if it is just
                // scheduled. Also a command 38 might follow a command 48
                // to check the write protect status. In both cases, hold
                // command 48 scanning until next cycle.
                if ((HARTCOMMAND_FOURTYEIGHT != m_ucLastReqCmd) &&
                    (HARTCOMMAND_THIRTYEIGHT != m_ucLastReqCmd)) {
                    ReplyStatus = HREPLYSTATUS_MORE; 
                }
            }
        }

#if defined(PMIO_DEBUG) && (0)
		if (m_ucLastReqCmd == HARTCOMMAND_NINE)
		{
			ucDumpBuff[ucDbgCnt++] = ReplyStatus;
		}
#endif

        if ((HREPLYSTATUS_GOOD != ReplyStatus) && 
			(HART_RESPCODE_SUCCESS == m_ucLastRespCode)) {
            // There is a change is normal scheduling due to a bit set
            // in device status byte. If the last command fetched good data,
            // update the database before changing the schedule of commands.
            (this->*HartCmdHandler[m_ucLastReqCmd].GoodHandler)();
            return ReplyStatus;
        }

    }
    
#if !defined(IOPTYPE_SCIOM) // for both HLAIH & AO16H
	if((HART_RESPCODE_SUCCESS == m_ucLastRespCode) ||
	  ((HART_RESPCODE_RESTRUNCATED == m_ucLastRespCode) && (HARTCOMMAND_NINE == m_ucLastReqCmd))) {
#else
    if (HART_RESPCODE_SUCCESS == m_ucLastRespCode) {
#endif
        return (this->*HartCmdHandler[m_ucLastReqCmd].GoodHandler)();
    }
    else if (HART_RESPCODE_DEVICE_BUSY == m_ucLastRespCode) {
        return HREPLYSTATUS_BUSY;
    }
    else {
        return (this->*HartCmdHandler[m_ucLastReqCmd].BadHandler)(m_ucLastRespCode);
    }
}
/*******************************************************************************
*                         clsHartDevDb::GetHartLoading                         *
*                         ============================                         *
* PURPOSE:                                                                     *
*    Return HART loading factor to update HCUAVAIL parameter.                  *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    float - HART loading factor for this channel.                             *
* PROCESS:                                                                     *
*    1. 0% load for all HART disabled channels or if IOP is secondary.         *
*    2. 1% load for all unconfigured channels.                                 *
*    3. 1.6% load if channel is inactive or idle for C48 monitoring.           *
*    4. If channel mode is INIT, return 15% to account for device discovery.   *
*    5. If passthrough is being done in inactive state, return 25%.            *
*    5. Return 30% load for active and run 1-second channels.                  *
*    6. For active and run non-synced channels, calculate loading factor based *
*       on dynamic and device reate. Add 10% if passthrough is being done.     *
* NOTES:                                                                       *
*    1. This method is called from HART task once every second.                *
*******************************************************************************/
FLOAT32 clsHartDevDb::GetHartLoading(VOID) {
    UINT8 ucDsa = HartGetEffectiveDsa();
    if ((ucDsa == 0) || (ucDsa > MAXDSA) || 
        (FALSE == m_pHartCfgDb->HEnable) ||
        (SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED)) {
        return 0.0;
    }
   
#if defined (IOMTYPE_UIO)
    if (HSCANRATE_1SEC == HTotalRate) {
        return 100.0;
    }
#else
    if (HSCANRATE_1SEC == HTotalRate) {
        return 30.0;
    }
#endif

    FLOAT32 fHartLoad = (FLOAT32)(HTotalRate * 100.0);
    if (0.0 == fHartLoad) {
        fHartLoad = (FLOAT32)(HSCANRATE_16SEC * 100.0);
    }
#if defined (IOMTYPE_UIO)
    // There are two modems on the UIO but each is dedicated to a set of channels.
    // HART Load is based on one modem.
    return (fHartLoad / ((FLOAT32) (HSCANRATE_1SEC)));
#else
    return (fHartLoad / ((FLOAT32) (HARTMODEM_COUNT * HSCANRATE_1SEC)));
#endif
}
/*******************************************************************************
*                         clsHartDevDb::Cmd0GoodHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd0GoodHandler(VOID) { // Read unique identifier.
    UINT8 ucCount;
    HARTCMD0RESPONSE *pResponse = (HARTCMD0RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    m_UniqueAddress.str.ucExpDeviceType1 = pResponse->str.ucusExpDeviceType[0];
    m_UniqueAddress.str.ucExpDeviceType2 = pResponse->str.ucusExpDeviceType[1];

    for (ucCount = 0; ucCount < HART_DEVICEID_SIZE; ucCount++) {
        m_UniqueAddress.str.ucDeviceId[ucCount] = pResponse->str.ucDeviceId[ucCount];
    }
    m_ucReqdPreambles = pResponse->str.ucReqdPreambleBytes;
    m_ucDeviceRevision = pResponse->str.ucDeviceRevisionLevel;
    m_ucHartVersion = pResponse->str.ucHARTMajorRevision;

    if ( m_ucHartVersion >= HARTVERSION_6X) {
        m_ucDevScan[0] = HARTCOMMAND_NINE;
    }
    else if (HARTVERSION_5X == pResponse->str.ucHARTMajorRevision) {
        m_ucDevScan[0] = HARTCOMMAND_THIRTYTHREE; 
    }
    else {
        m_ucHartVersion = HARTVERSION_MISMATCH;
    }

    // Update command data
    WriteHCmdData(HARTCOMMAND_ZERO,(UINT8 *)pResponse);
    //HART revision 5 and less does not support config change counter.
    //so update member variable which is incremented when config changed.
    if ( m_ucHartVersion < HARTVERSION_6X) {
        HCmd0.str.ucusConfigChgCnt[0] = (UINT8)(HT5_CfgChngCnt >> 8);
        HCmd0.str.ucusConfigChgCnt[1] = (UINT8)HT5_CfgChngCnt;
        BOX->SetHGCfgChgCnt(m_cucParent,HT5_CfgChngCnt);
    }
    else {
        // The receive adapter presents this field in processor byte order.
        BOX->SetHGCfgChgCnt(m_cucParent,(*(UINT16 *)pResponse->str.ucusConfigChgCnt));
    }

    if (HARTVERSION_MISMATCH == m_ucHartVersion) {
        return Cmd0BadHandler(HARTVERSION_MISMATCH);  
    }

    if (HARTCOMMAND_ZERO == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }

    // All tests passed - good transaction.
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd0BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd0BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_ZERO,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd3GoodHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd3GoodHandler(VOID) {
    // Read dynamic variables and loop current.

    HARTCMD3RESPONSE *pResponse = (HARTCMD3RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    DATABYTES DataQvVal,DataTvVal,DataSvVal,DataPvVal;
    for (UINT8 ucIndex = 0; ucIndex < sizeof(FLOAT32); ucIndex++) {
        DataQvVal.ucBytes[ucIndex] = pResponse->str.ucfQvVal[ucIndex];
        DataTvVal.ucBytes[ucIndex] = pResponse->str.ucfTvVal[ucIndex];
        DataSvVal.ucBytes[ucIndex] = pResponse->str.ucfSvVal[ucIndex];
        DataPvVal.ucBytes[ucIndex] = pResponse->str.ucfPvVal[ucIndex];
    }

    if ((MODSTATUS_RUN == BOX->GetModuleStatus()) && 
        (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt())) {
        if (m_ucRcvMsgLen >= HART_CMD3_4VAR_RESPONSE_SIZE) {
            HDynVal[3] = DataQvVal.f32Val;
            HDynEu[3] = pResponse->str.ucQvUnitCode;
        }
        else {
            HDynVal[3] = NaN;
            HDynEu[3] = 0;
        }
        
        if (m_ucRcvMsgLen >= HART_CMD3_3VAR_RESPONSE_SIZE) {
            HDynVal[2] = DataTvVal.f32Val;
            HDynEu[2] = pResponse->str.ucTvUnitCode;
        }
        else {
            HDynVal[2] = NaN;
            HDynEu[2] = 0;
        }
    
        if (m_ucRcvMsgLen >= HART_CMD3_2VAR_RESPONSE_SIZE) {
            HDynVal[1] = DataSvVal.f32Val;
            HDynEu[1] = pResponse->str.ucSvUnitCode;
        }
        else {
            HDynVal[1] = NaN;
            HDynEu[1] = 0;
        }
    
        if (m_ucRcvMsgLen >= HART_CMD3_1VAR_RESPONSE_SIZE) {
            HDynVal[0] = DataPvVal.f32Val;
            HDynEu[0] = pResponse->str.ucPvUnitCode;
        }
        else {
            HDynVal[0] = NaN;
            HDynEu[0] = 0;
        }
    }


    m_ulDynGoodCount++;

    if (HARTCOMMAND_THREE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd3BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd3BadHandler(UINT8 a_ucRespCode) {
    if (HART_RESPCODE_DATA_DID_NOT_CHANGE == a_ucRespCode) {
        return Cmd3GoodHandler();
    }

    SetHCmdFail(HARTCOMMAND_THREE,a_ucRespCode);
    for (UINT8 ucCount = 0; ucCount < HART_MAXDYNVAR_COUNT; ucCount++) {
        HDynVal[ucCount]    = NaN;
        HDynEu[ucCount]     = 0;
    }

    // Return reply status continue so that next message 
    // of the scan table will be scheduled.
    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd6GoodHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd6GoodHandler(VOID) {
    // Write polling address and loop current mode
    HARTCMD6RESPONSE *pResponse = (HARTCMD6RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    if ((pResponse->str.ucPollingAddress & HART_POLLING_ADDR_MASK) != 0) {
        SetHCmdFail(HARTCOMMAND_SIX,HART_RESPCODE_DATA_DID_NOT_CHANGE);
        return HREPLYSTATUS_REINIT;
    }
    else {
        m_ucPollingAddress = 0;
    }

    if (( m_ucHartVersion >= HARTVERSION_6X) && 
        (HART_LOOP_CURRENT_ENABLED != pResponse->str.ucLoopCurMode)) {
        SetHCmdFail(HARTCOMMAND_SIX,HART_RESPCODE_DATA_DID_NOT_CHANGE);
        return HREPLYSTATUS_REINIT;
    }
 
    if (HARTCOMMAND_SIX == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    // All tests passed - good transaction.
    //Command 6 is configuration change command,so increment config change counter.
    HT5_CfgChngCnt ++;
    
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd6BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd6BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_SIX,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd9GoodHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd9GoodHandler() {
    
    UINT8 ucVarCnt = 0; 
    UINT8 ucSlot0DTSIndex = 0;

    // Read device variables with status
    HARTCMD9RESPONSE *pResponse = (HARTCMD9RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    DATABYTES DataVar0Val,DataVar1Val,DataVar2Val,DataVar3Val;
    DATABYTES DataVar4Val,DataVar5Val,DataVar6Val,DataVar7Val;
    DATABYTES Slot0TS;
    for (UINT8 ucIndex = 0; ucIndex < sizeof(FLOAT32); ucIndex++) {
        DataVar0Val.ucBytes[ucIndex] = pResponse->str.ucfVar0Val[ucIndex];
        DataVar1Val.ucBytes[ucIndex] = pResponse->str.ucfVar1Val[ucIndex];
        DataVar2Val.ucBytes[ucIndex] = pResponse->str.ucfVar2Val[ucIndex];
        DataVar3Val.ucBytes[ucIndex] = pResponse->str.ucfVar3Val[ucIndex];
        if ( m_ucHartVersion >= HARTVERSION_7X) {
            DataVar4Val.ucBytes[ucIndex] = pResponse->str.ucfVar4Val[ucIndex];
            DataVar5Val.ucBytes[ucIndex] = pResponse->str.ucfVar5Val[ucIndex];
            DataVar6Val.ucBytes[ucIndex] = pResponse->str.ucfVar6Val[ucIndex];
            DataVar7Val.ucBytes[ucIndex] = pResponse->str.ucfVar7Val[ucIndex];
        }
    }
    for (UINT8 ucIndex = 0; ucIndex < HART_MAXVAR_COUNT; ucIndex++) {
        if(m_ucRcvMsgLen >= (HART_CMD9_1VAR_RESPONSE_SIZE + (HART_SIZEOFVAR0*ucIndex))){
            ucVarCnt ++;
        }
        else {
            if(ucIndex < HART_MAXDYNVAR_COUNT) {
                if(m_ScanMsg == HSCANMSG_DYN)
                {
                    HDynCc[ucIndex]   = 0;
                    HDynEu[ucIndex]   = 0;
                    HDynVal[ucIndex]  = NaN;
                    HDynSt[ucIndex]   = 0;
                }
            }
            if(m_ScanMsg == HSCANMSG_DEV)
            {
                HSlotCc[ucIndex]  = 0;
                HSlotEu[ucIndex]  = 0;
                HSlotVal[ucIndex] = NaN;
                HSlotSt[ucIndex]  = 0;
            }
        }

    }
    // Update extended device status in HDEVST byte #3.
    HDevSt[3] = pResponse->str.ucExtDevSts;

    
    if ((MODSTATUS_RUN == BOX->GetModuleStatus()) && 
        (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt())) {
        if ((HARTCOMMAND_NINE == m_ucDynScan[0]) && (m_ScanMsg == HSCANMSG_DYN)){
            if ((m_ucRcvMsgLen >= HART_CMD9_4VAR_RESPONSE_SIZE) &&
                (m_ucDynScan[5] == pResponse->str.ucVar3Code)) {
                HDynCc[3]  = pResponse->str.ucVar3Class;
                HDynEu[3]  = pResponse->str.ucVar3Unit;
                HDynVal[3] = DataVar3Val.f32Val;
                HDynSt[3]  = pResponse->str.ucVar3Sts;
            }
        
            if ((m_ucRcvMsgLen >= HART_CMD9_3VAR_RESPONSE_SIZE) &&
                (m_ucDynScan[4] == pResponse->str.ucVar2Code)) {
                HDynCc[2]  = pResponse->str.ucVar2Class;
                HDynEu[2]  = pResponse->str.ucVar2Unit;
                HDynVal[2] = DataVar2Val.f32Val;
                HDynSt[2]  = pResponse->str.ucVar2Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_2VAR_RESPONSE_SIZE) &&
                (m_ucDynScan[3] == pResponse->str.ucVar1Code)) {
                HDynCc[1]  = pResponse->str.ucVar1Class;
                HDynEu[1]  = pResponse->str.ucVar1Unit;
                HDynVal[1] = DataVar1Val.f32Val;
                HDynSt[1]  = pResponse->str.ucVar1Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_1VAR_RESPONSE_SIZE) &&
                (m_ucDynScan[2] == pResponse->str.ucVar0Code)) {
                HDynCc[0]  = pResponse->str.ucVar0Class;
                HDynEu[0]  = pResponse->str.ucVar0Unit;
                HDynVal[0] = DataVar0Val.f32Val;
                HDynSt[0]  = pResponse->str.ucVar0Sts;
            }
            m_ulDynGoodCount++;
        }

        if ((HARTCOMMAND_NINE == m_ucDevScan[0]) && (m_ScanMsg == HSCANMSG_DEV)) {
            if ((m_ucRcvMsgLen >= HART_CMD9_8VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[9] == pResponse->str.ucVar7Code)) {
                HSlotCc[7]  = pResponse->str.ucVar7Class;
                HSlotEu[7]  = pResponse->str.ucVar7Unit;
                HSlotVal[7] = DataVar7Val.f32Val;
                HSlotSt[7]  = pResponse->str.ucVar7Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_7VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[8] == pResponse->str.ucVar6Code)) {
                HSlotCc[6]  = pResponse->str.ucVar6Class;
                HSlotEu[6]  = pResponse->str.ucVar6Unit;
                HSlotVal[6] = DataVar6Val.f32Val;
                HSlotSt[6]  = pResponse->str.ucVar6Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_6VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[7] == pResponse->str.ucVar5Code)) {
                HSlotCc[5]  = pResponse->str.ucVar5Class;
                HSlotEu[5]  = pResponse->str.ucVar5Unit;
                HSlotVal[5] = DataVar5Val.f32Val;
                HSlotSt[5]  = pResponse->str.ucVar5Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_5VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[6] == pResponse->str.ucVar4Code)) {
                HSlotCc[4]  = pResponse->str.ucVar4Class;
                HSlotEu[4]  = pResponse->str.ucVar4Unit;
                HSlotVal[4] = DataVar4Val.f32Val;
                HSlotSt[4]  = pResponse->str.ucVar4Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_4VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[5] == pResponse->str.ucVar3Code)) {
                HSlotCc[3]  = pResponse->str.ucVar3Class;
                HSlotEu[3]  = pResponse->str.ucVar3Unit;
                HSlotVal[3] = DataVar3Val.f32Val;
                HSlotSt[3]  = pResponse->str.ucVar3Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_3VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[4] == pResponse->str.ucVar2Code)) {
                HSlotCc[2]  = pResponse->str.ucVar2Class;
                HSlotEu[2]  = pResponse->str.ucVar2Unit;
                HSlotVal[2] = DataVar2Val.f32Val;
                HSlotSt[2]  = pResponse->str.ucVar2Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_2VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[3] == pResponse->str.ucVar1Code)) {
                HSlotCc[1]  = pResponse->str.ucVar1Class;
                HSlotEu[1]  = pResponse->str.ucVar1Unit;
                HSlotVal[1] = DataVar1Val.f32Val;
                HSlotSt[1]  = pResponse->str.ucVar1Sts;
            }
            if ((m_ucRcvMsgLen >= HART_CMD9_1VAR_RESPONSE_SIZE) &&
                (m_ucDevScan[2] == pResponse->str.ucVar0Code)) {
                HSlotCc[0]  = pResponse->str.ucVar0Class;
                HSlotEu[0]  = pResponse->str.ucVar0Unit;
                HSlotVal[0] = DataVar0Val.f32Val;
                HSlotSt[0]  = pResponse->str.ucVar0Sts;
            }
            m_ulDevGoodCount++;
        }
        if ( m_ucHartVersion >= HARTVERSION_7X) { 
          ucSlot0DTSIndex = (ucVarCnt * HART_SIZEOFVAR0)+ sizeof(UINT8);
          for (UINT8 ucIndex = 0; ucIndex < sizeof(UINT32); ucIndex++) {
             Slot0TS.ucBytes[ucIndex] = pResponse->ucBytes[ucSlot0DTSIndex +ucIndex];
          }
          HDevSlot0DTS = (Slot0TS.ui32Val/HART_SLT0TS_MSEC) * HART_SLT0TS_TIMEOFDAY;
        }
    }
    if (HARTCOMMAND_NINE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd9BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd9BadHandler(UINT8 a_ucRespCode) {
    if (HART_RESPCODE_DATA_DID_NOT_CHANGE == a_ucRespCode) {
        return Cmd9GoodHandler();
    }

    SetHCmdFail(HARTCOMMAND_NINE,a_ucRespCode);

    if ((HARTCOMMAND_NINE == m_ucDynScan[0]) && (m_ScanMsg == HSCANMSG_DYN)) {
        for (UINT8 ucCount = 0; ucCount < HART_MAXDYNVAR_COUNT; ucCount++) {
            HDynVal[0] = NaN;
        }
        
        // Change dynamic scan command to HARTCOMMAND_THREE.
        for (UINT8 ucCount = 0; ucCount < HART_MAXDYNVAR_COUNT; ucCount++) {
            HDynDvc[ucCount] = 0;
        }

        m_ucDynScan[0] = HARTCOMMAND_THREE;
        m_ucDynScan[1] = 0;
        
    }
    else if ((HARTCOMMAND_NINE == m_ucDevScan[0]) && (m_ScanMsg == HSCANMSG_DEV)) {
        for (UINT8 ucCount = 0; ucCount < HART_MAXVAR_COUNT; ucCount++) {
            HSlotVal[0] = NaN;
        }
    }

    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd12GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd12GoodHandler(VOID) {
    HARTCMD12RESPONSE *pResponse = (HARTCMD12RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_TWELVE,(UINT8 *)pResponse);

    if (HARTCOMMAND_TWELVE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd12BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd12BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_TWELVE,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd13GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd13GoodHandler(VOID) {
    // Read Tag, Descriptor, Date
    HARTCMD13RESPONSE *pResponse = (HARTCMD13RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_THIRTEEN,(UINT8 *)pResponse);

    if (HARTCOMMAND_THIRTEEN == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd13BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd13BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_THIRTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd14GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd14GoodHandler(VOID) {
    HARTCMD14RESPONSE *pResponse = (HARTCMD14RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))

    #ifdef IOMTYPE_UIO
       if(BOX->GetInitPntType(m_cucParent) == PNTTYPE_ANALOGINPUT){  
    #endif    
          DATABYTES DataUpperTrLimit,DataLowerTrLimit;
          for (UINT8 ucIndex = 0; ucIndex < sizeof(FLOAT32); ucIndex++) {
               DataUpperTrLimit.ucBytes[ucIndex] = pResponse->str.ucfUpperTrLimit[ucIndex];
               DataLowerTrLimit.ucBytes[ucIndex] = pResponse->str.ucfLowerTrLimit[ucIndex];
          }

          StiEu = pResponse->str.ucTrUnitsCode;
          Lrl   = DataLowerTrLimit.f32Val;
          Url   = DataUpperTrLimit.f32Val;

    #ifdef IOMTYPE_UIO
       }
    #endif
#endif

    WriteHCmdData(HARTCOMMAND_FOURTEEN,(UINT8 *)pResponse);
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))

    #ifdef IOMTYPE_UIO
       if(BOX->GetInitPntType(m_cucParent) == PNTTYPE_ANALOGINPUT){  
    #endif
    
    CheckRangeMismatch();
    
    #ifdef IOMTYPE_UIO
       }
    #endif    
#endif

    if (HARTCOMMAND_FOURTEEN == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd14BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd14BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_FOURTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd15GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd15GoodHandler(VOID) {
    // Read device information
    HARTCMD15RESPONSE *pResponse = (HARTCMD15RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))

    #ifdef IOMTYPE_UIO
       if(BOX->GetInitPntType(m_cucParent) == PNTTYPE_ANALOGINPUT){  
    #endif 
    
       DATABYTES DataPvDampVal,DataPvLRngVal,DataPvURngVal;
       for (UINT8 ucIndex = 0; ucIndex < sizeof(FLOAT32); ucIndex++) {
            DataPvDampVal.ucBytes[ucIndex] = pResponse->str.ucfPvDampVal[ucIndex];
            DataPvLRngVal.ucBytes[ucIndex] = pResponse->str.ucfPvLRngVal[ucIndex];
            DataPvURngVal.ucBytes[ucIndex] = pResponse->str.ucfPvURngVal[ucIndex];
       }

       Damping = DataPvDampVal.f32Val;
       Lrv     = DataPvLRngVal.f32Val;
       Urv     = DataPvURngVal.f32Val;

    #ifdef IOMTYPE_UIO
       }
    #endif    
#endif

    WriteHCmdData(HARTCOMMAND_FIFTEEN,(UINT8 *)pResponse);
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))

    #ifdef IOMTYPE_UIO
       if(BOX->GetInitPntType(m_cucParent) == PNTTYPE_ANALOGINPUT){  
    #endif 
    
    CheckRangeMismatch();

    #ifdef IOMTYPE_UIO
       }
    #endif    
#endif

    if (HARTCOMMAND_FIFTEEN == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd15BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd15BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_FIFTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd16GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd16GoodHandler(VOID) {
    // Read final assembly number
    HARTCMD16RESPONSE *pResponse = (HARTCMD16RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_SIXTEEN,(UINT8 *)pResponse);
    if (HARTCOMMAND_SIXTEEN == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd16BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd16BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_SIXTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}

/*******************************************************************************
*                          clsHartDevDb::Cmd20GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd20GoodHandler(VOID) {
    HARTLONGTAG_RESPONSE *pResponse = (HARTLONGTAG_RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_TWENTY,(UINT8 *)pResponse);
    if (HARTCOMMAND_TWENTY == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd20BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd20BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_TWENTY,a_ucRespCode);
    return HREPLYSTATUS_CONTINUE;
}

/*******************************************************************************
*                          clsHartDevDb::Cmd33GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd33GoodHandler(VOID) { // Ready device variables  
    
    HARTCMD33RESPONSE *pResponse = (HARTCMD33RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

	DATABYTES DataVar0Val, DataVar1Val, DataVar2Val, DataVar3Val;

	for (UINT8 ucIndex = 0; ucIndex < sizeof(FLOAT32); ucIndex++) {
		DataVar0Val.ucBytes[ucIndex] = pResponse->str.ucfVar0Val[ucIndex];
		DataVar1Val.ucBytes[ucIndex] = pResponse->str.ucfVar1Val[ucIndex];
		DataVar2Val.ucBytes[ucIndex] = pResponse->str.ucfVar2Val[ucIndex];
		DataVar3Val.ucBytes[ucIndex] = pResponse->str.ucfVar3Val[ucIndex];
	}

    if ((MODSTATUS_RUN == BOX->GetModuleStatus()) &&
        (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt())) {
        if ((m_ucRcvMsgLen >= HART_CMD33_4VAR_RESPONSE_SIZE) &&
            (m_ucDevScan[5] == pResponse->str.ucVar3Code)) {
            HSlotEu[3]  = pResponse->str.ucVar3Unit;
          //HSlotVal[3] = pResponse->str.fVar3Val;
			HSlotVal[3] = DataVar3Val.f32Val;
        }
        else {
            HSlotEu[3]  = 0;
            HSlotVal[3] = NaN;
        }
    
        if ((m_ucRcvMsgLen >= HART_CMD33_3VAR_RESPONSE_SIZE) &&
            (m_ucDevScan[4] == pResponse->str.ucVar2Code)) {
            HSlotEu[2]  = pResponse->str.ucVar2Unit;
          //HSlotVal[2] = pResponse->str.fVar2Val;
			HSlotVal[2] = DataVar2Val.f32Val;
        }
        else {
            HSlotEu[2]  = 0;
            HSlotVal[2] = NaN;
        }

        if ((m_ucRcvMsgLen >= HART_CMD33_2VAR_RESPONSE_SIZE) &&
            (m_ucDevScan[3] == pResponse->str.ucVar1Code)) {
            HSlotEu[1]  = pResponse->str.ucVar1Unit;
          //HSlotVal[1] = pResponse->str.fVar1Val;
			HSlotVal[1] = DataVar1Val.f32Val;
        }
        else {
            HSlotEu[1]  = 0;
            HSlotVal[1] = NaN;
        }
        
        if ((m_ucRcvMsgLen >= HART_CMD33_1VAR_RESPONSE_SIZE) &&
            (m_ucDevScan[2] == pResponse->str.ucVar0Code)) {
            HSlotEu[0]  = pResponse->str.ucVar0Unit;
          //HSlotVal[0] = pResponse->str.fVar0Val;
			HSlotVal[0] = DataVar0Val.f32Val;
        }
        else {
            HSlotEu[0]  = 0;
            HSlotVal[0] = NaN;
        }
    }

    m_ulDevGoodCount++;
    
    if (HARTCOMMAND_THIRTYTHREE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd33BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd33BadHandler(UINT8 a_ucRespCode) {
    if (HART_RESPCODE_DATA_DID_NOT_CHANGE == a_ucRespCode) {
        return Cmd33GoodHandler();
    }

    SetHCmdFail(HARTCOMMAND_THIRTYTHREE,a_ucRespCode);
    for (UINT8 ucCount = 0; ucCount < HART_MAXVAR_COUNT; ucCount++) {
        HSlotVal[0] = NaN;
    }

    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd38GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd38GoodHandler(VOID) {    
    HARTCMD38RESPONSE *pResponse = (HARTCMD38RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    if (HARTCOMMAND_THIRTYEIGHT == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }

    if (TRUE == m_bCmd38FailReported) {
        // Device was write protected earlier and is now write protection is
        // disabled. Schedule rediscovery so that any configuration change 
        // will be updated in the device database.
        m_bCmd38FailReported = FALSE;
        return HREPLYSTATUS_REINIT;
    }
    //Update the config change counter for HART revision greater than or equal to 7.
    //HART version less than 7 does not receive config change counter in CMD38 response.
    if ( m_ucHartVersion >= HARTVERSION_7X) {
        HCmd0.str.ucusConfigChgCnt[0] = pResponse->str.ucusConfigChgCnt[1];
        HCmd0.str.ucusConfigChgCnt[1] = pResponse->str.ucusConfigChgCnt[0];
        BOX->SetHGCfgChgCnt(m_cucParent,*(UINT16 *)(pResponse->str.ucusConfigChgCnt));
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd38BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd38BadHandler(UINT8 a_ucRespCode) {
    if (FALSE == m_bCmd38FailReported) {
        // If command 38 failed with write protected error, set the database
        // flag to notify scheduler to continue dynamic scan and schedule
        // command 38 once every minute to recheck write protect status.
        if (HART_RESPCODE_WRITE_PROTECTED == a_ucRespCode){
            m_bCmd38FailReported = TRUE;
        }
        
        SetHCmdFail(HARTCOMMAND_THIRTYEIGHT,a_ucRespCode);
    }

    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd48GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd48GoodHandler(VOID) {
    // Read additional device status
    HARTCMD48RESPONSE *pResponse = (HARTCMD48RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    if ((TRUE == m_pHartCfgDb->HEnable) && (0 == (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK))) {
        WriteHCmdData(HARTCOMMAND_FOURTYEIGHT,(UINT8 *)pResponse);
    }
    // Set event init status to success for the channel.
    if (HCHANMODE_INIT == m_HChanMode) {
        m_HEventInit = HEVENTINIT_SUCCESS;
        // Process device mismatch, revision mismatch and deviceid alarms.
        CheckDevMismatch();
    }

    // If either HDYNRATE or HDEVRATE is configured and control state is
    // active and run, or if this a monitoring operation for an unloaded 
    // channel with a discovered HART device, slow down command 48 scanning 
    // to once every 64 seconds. This is done by ignoring command 48 scan 
    // three times. Since scan table completely get proceed in 16 seconds, 
    // and there is only one entry for command 48 in the entire scan table, 
    // this results in command 48 scan of once every 64 seconds.
    if ((SLOT(m_cucParent)->GetPntType() == PNTTYPE_NOTCONFIGURED) || 
        (((MODSTATUS_RUN == BOX->GetModuleStatus()) && 
          (PTEXECST_ACTIVE == SLOT(m_cucParent)->GetPtExecSt())) &&
          ((HDynRate > HSCANRATE_NONE) || (HDevRate > HSCANRATE_NONE)))) {
            m_ucSkipC48Cycles = 3;
    }

    m_ulC48GoodCount++;
    
    if (HARTCOMMAND_FOURTYEIGHT == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }

    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd48BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd48BadHandler (UINT8 a_ucRespCode) {
    if (HART_RESPCODE_DATA_DID_NOT_CHANGE == a_ucRespCode) {
        m_ucSkipC48Cycles = 0;
        if (HCHANMODE_INIT == m_HChanMode) {
            m_HEventInit = HEVENTINIT_SUCCESS;
        }

        // Process device mismatch, revision mismatch and deviceid alarms.
        CheckDevMismatch();
        return HREPLYSTATUS_CONTINUE;
    }

    if (FALSE == m_bCmd48FailReported) {
        // Report command 48 failure once when the channel is scan mode.
        if (HCHANMODE_SCAN == m_HChanMode) {
            m_bCmd48FailReported = TRUE;
        }
        SetHCmdFail(HARTCOMMAND_FOURTYEIGHT,a_ucRespCode);
    }
    
    if (HCHANMODE_INIT== m_HChanMode) {
        m_HEventInit = HEVENTINIT_C48FAIL;
    }

    // Process device mismatch, revision mismatch and deviceid alarms.
    CheckDevMismatch();
    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd50GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd50GoodHandler(VOID) {
    // Read dynamic variable association
    HARTCMD50RESPONSE *pResponse = (HARTCMD50RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    if ( m_ucHartVersion >= HARTVERSION_6X) {
        m_ucDynScan[0] = HARTCOMMAND_NINE;
    }
    else {
        m_ucDynScan[0] = HARTCOMMAND_THREE;
    }
    m_ucDynScan[1] = 0;

    if (pResponse->str.ucDynVar0Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar0Code;
        }
        HDynDvc[0] = pResponse->str.ucDynVar0Code;
    }

    if (pResponse->str.ucDynVar1Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar1Code;
        }
        HDynDvc[1] = pResponse->str.ucDynVar1Code;
    }

    if (pResponse->str.ucDynVar2Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar2Code;
        }
        HDynDvc[2] = pResponse->str.ucDynVar2Code;
    }

    if (pResponse->str.ucDynVar3Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar3Code;
        }
        HDynDvc[3] = pResponse->str.ucDynVar3Code;
    }
    
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd50BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd50BadHandler (UINT8 a_ucRespCode) {
    // Schedule Command 3 for dynamic variable scanning.
    // HDYNDVC is updated with NONE (variable code 250)
    m_ucDynScan[0] = HARTCOMMAND_THREE;
    m_ucDynScan[1] = 0;

    for (UINT8 ucCount = 0; ucCount < HART_MAXDYNVAR_COUNT; ucCount++) {
        HDynDvc[ucCount] = HART_INVALID_PARAMETER_CODE;
        m_ucDynScan[2 + ucCount] = 0;
    }
    SetHCmdFail(HARTCOMMAND_FIFTY,a_ucRespCode);
    return HREPLYSTATUS_CONTINUE; 
}
/*******************************************************************************
*                          clsHartDevDb::Cmd59GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd59GoodHandler(VOID) {
    HT5_CfgChngCnt ++;
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd59BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd59BadHandler(UINT8) {
    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd109GoodHandler                     *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd109GoodHandler(VOID) {
    if (HARTCOMMAND_HUNDREDNINE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd109BadHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd109BadHandler (UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_HUNDREDNINE,a_ucRespCode);
    return HREPLYSTATUS_BAD;
}
static VOID HartDb_ReverseField(UINT8 *a_pData, UINT8 a_ucOffset, UINT8 a_ucLength, UINT8 a_ucPayloadLength)
{
    if ((a_pData == NULL) || ((UINT16)a_ucOffset + a_ucLength > a_ucPayloadLength))
    {
        return;
    }

    for (UINT8 left = 0u, right = (UINT8)(a_ucLength - 1u); left < right; left++, right--)
    {
        UINT8 value = a_pData[(UINT8)(a_ucOffset + left)];
        a_pData[(UINT8)(a_ucOffset + left)] = a_pData[(UINT8)(a_ucOffset + right)];
        a_pData[(UINT8)(a_ucOffset + right)] = value;
    }
}

VOID HartDb_LoadParsedResponse(clsHartDevDb *a_pHartDevDb,
                               const HartParsedResponse_t *a_pResponse)
{
    if (a_pHartDevDb == NULL)
    {
        return;
    }

    clsHartDevDb &HartDevDb = *a_pHartDevDb;
    UINT8 payload[HART_MAX_BYTECOUNT];

    HartDevDb.m_ChanRcvBuffer.Flush();
    memset(payload, 0, sizeof(payload));

    if (a_pResponse == NULL)
    {
        return;
    }

    HartDevDb.m_ucLastReqCmd = a_pResponse->command;
    HartDevDb.m_ucLastRespCode = a_pResponse->status0;
    HartDevDb.m_ucDeviceStatus = a_pResponse->status1;

    UINT8 payloadLength = a_pResponse->payloadLen;
    if (payloadLength > HART_MAX_BYTECOUNT)
    {
        payloadLength = HART_MAX_BYTECOUNT;
    }
    for (UINT8 index = 0u; index < payloadLength; index++)
    {
        payload[index] = a_pResponse->payload[index];
    }

    /* Keep the fixed 18-byte legacy/IOLINK Command 15 database layout while
     * supporting devices that return only the 16 mandatory bytes. */
    if ((a_pResponse->command == HARTCOMMAND_FIFTEEN) &&
        (a_pResponse->status0 == HART_RESPCODE_SUCCESS) &&
        (payloadLength >= HART_CMD15_MANDATORY_RESPONSE_SIZE) &&
        (payloadLength < HART_CMD15_RESPONSE_SIZE))
    {
        while (payloadLength < HART_CMD15_RESPONSE_SIZE)
        {
            payload[payloadLength++] = 0xFFu;
        }
    }

    HartDevDb.m_ucRcvMsgLen = payloadLength;

    switch (a_pResponse->command)
    {
        case HARTCOMMAND_ZERO:
            HartDb_ReverseField(payload,14u,2u,payloadLength);
            break;
        case HARTCOMMAND_THREE:
            for (UINT8 offset = 0u; offset <= 20u; offset = (UINT8)(offset + 5u))
            {
                HartDb_ReverseField(payload,offset,4u,payloadLength);
            }
            break;
        case HARTCOMMAND_NINE:
            for (UINT8 offset = 4u; offset <= 60u; offset = (UINT8)(offset + 8u))
            {
                HartDb_ReverseField(payload,offset,4u,payloadLength);
            }
            HartDb_ReverseField(payload,65u,4u,payloadLength);
            break;
        case HARTCOMMAND_FOURTEEN:
            HartDb_ReverseField(payload,4u,4u,payloadLength);
            HartDb_ReverseField(payload,8u,4u,payloadLength);
            HartDb_ReverseField(payload,12u,4u,payloadLength);
            break;
        case HARTCOMMAND_FIFTEEN:
            HartDb_ReverseField(payload,3u,4u,payloadLength);
            HartDb_ReverseField(payload,7u,4u,payloadLength);
            HartDb_ReverseField(payload,11u,4u,payloadLength);
            break;
        case HARTCOMMAND_THIRTYTHREE:
            HartDb_ReverseField(payload,2u,4u,payloadLength);
            HartDb_ReverseField(payload,8u,4u,payloadLength);
            HartDb_ReverseField(payload,14u,4u,payloadLength);
            HartDb_ReverseField(payload,20u,4u,payloadLength);
            break;
        case HARTCOMMAND_THIRTYEIGHT:
            HartDb_ReverseField(payload,0u,2u,payloadLength);
            break;
        default:
            break;
    }

    HartDevDb.m_ChanRcvBuffer = (UINT8)(payloadLength + 2u);
    HartDevDb.m_ChanRcvBuffer = a_pResponse->status0;
    HartDevDb.m_ChanRcvBuffer = a_pResponse->status1;
    for (UINT8 index = 0u; index < payloadLength; index++)
    {
        HartDevDb.m_ChanRcvBuffer = payload[index];
    }
}

static VOID HartDb_RestoreWireCommandBlock(clsHartDevDb *a_pHartDevDb,
                                              const HartParsedResponse_t *a_pResponse)
{
    UINT8 *pDestination = NULL;
    UINT8 destinationSize = 0u;
    UINT8 defaultValue = 0u;

    if ((a_pHartDevDb == NULL) || (a_pResponse == NULL) ||
        (a_pResponse->status0 != HART_RESPCODE_SUCCESS))
    {
        return;
    }

    switch (a_pResponse->command)
    {
        case HARTCOMMAND_ZERO:
            pDestination = a_pHartDevDb->HCmd0.ucBytes;
            destinationSize = HART_CMD0_RESPONSE_SIZE;
            break;
        case HARTCOMMAND_THIRTEEN:
            pDestination = a_pHartDevDb->HCmd13.ucBytes;
            destinationSize = HART_CMD13_RESPONSE_SIZE;
            defaultValue = 0xFFu;
            break;
        case HARTCOMMAND_FOURTEEN:
            pDestination = a_pHartDevDb->HCmd14.ucBytes;
            destinationSize = HART_CMD14_RESPONSE_SIZE;
            defaultValue = 0xFFu;
            break;
        case HARTCOMMAND_FIFTEEN:
            pDestination = a_pHartDevDb->HCmd15.ucBytes;
            destinationSize = HART_CMD15_RESPONSE_SIZE;
            defaultValue = 0xFFu;
            break;
        default:
            return;
    }

    for (UINT8 index = 0u; index < destinationSize; index++)
    {
        pDestination[index] = defaultValue;
    }

    UINT8 copyLength = a_pResponse->payloadLen;
    if (copyLength > destinationSize)
    {
        copyLength = destinationSize;
    }

    for (UINT8 index = 0u; index < copyLength; index++)
    {
        pDestination[index] = a_pResponse->payload[index];
    }
}

VOID HartDb_Clear(VOID)
{
    const UINT8 channel = HartGetActiveChannel();

    clsHartDevDb *db = HartDb_GetChannelDevDb(channel);
    if (db != NULL)
    {
        db->InitDevDb(TRUE);
    }
}

VOID HartDb_FinalizeSynchronousDiscovery(UINT8 channel,
                                         HARTDISCOVERYRESULT result)
{
    clsHartDevDb *pHartDevDb = HartDb_GetChannelDevDb(channel);

    if (pHartDevDb == NULL)
    {
        return;
    }

    pHartDevDb->m_bAtLeastOneTry = TRUE;

    if (result == HART_DISCOVERY_COMPLETE)
    {
        pHartDevDb->m_ucCommStatus = HCOMSTS_GOOD;
        // Publish the same legacy database state that ReceptionComplete()
        // publishes after a successful channel transaction.
        pHartDevDb->SetHComSts(HCOMSTS_GOOD);
        pHartDevDb->HLComFail = HCOMSTS_GOOD;
        pHartDevDb->m_HChanMode = HCHANMODE_SCAN;
        pHartDevDb->m_HDataInit = HDATAINIT_COMPLETE;
        pHartDevDb->m_sScanCounter = TICKS_IN_1_SEC;
        pHartDevDb->BuildScanTable();
        /* Legacy ReceptionComplete/ChannelHeartbeat publication contract:
           indexed HART parameters are readable as soon as init completes. */
        BOX->SetHADCStatus(channel, HART_DATA_AVAILABLE);
    }
    else
    {
        pHartDevDb->m_ucCommStatus = HCOMSTS_NORESPONSE;
        pHartDevDb->m_HChanMode = HCHANMODE_INIT;
        pHartDevDb->SetHComSts(HCOMSTS_NORESPONSE);
        pHartDevDb->HLComFail = HCOMSTS_NORESPONSE;
        pHartDevDb->m_sScanCounter =
            (INT16)(TICKS_IN_30_SEC + channel);
    }
}


BOOL HartDb_UpdateFromCmd0(UINT8 channel,
                           const HartParsedResponse_t *cmd0)
{
    if ((cmd0 == NULL) || !cmd0->valid || !cmd0->checksumOk || (cmd0->command != HARTCOMMAND_ZERO))
    {
        return FALSE;
    }

    if (cmd0->payloadLen < HART_CMD0_ID_RESPONSE_SIZE)
    {
        return FALSE;
    }

    clsHartDevDb *db = HartDb_GetChannelDevDb(channel);
    if (db == NULL)
    {
        return FALSE;
    }
    HartDb_LoadParsedResponse(db, cmd0);
    (void)db->UpdateDatabase();
    HartDb_RestoreWireCommandBlock(db, cmd0);

    return TRUE;
}

BOOL HartDb_UpdateDynamicFromCmd3(const HartParsedResponse_t *cmd3)
{
    clsHartDevDb *db;
    HREPLYSTATUS replyStatus;

    if ((cmd3 == NULL) || !cmd3->valid || !cmd3->checksumOk ||
        (cmd3->command != HARTCOMMAND_THREE) ||
        (cmd3->status0 != HART_RESPCODE_SUCCESS) ||
        (cmd3->payloadLen < HART_CMD3_1VAR_RESPONSE_SIZE))
    {
        return FALSE;
    }

    db = HartDb_GetChannelDevDb(HartGetActiveChannel());
    if (db == NULL)
    {
        return FALSE;
    }

    /* The RT1024 adapter converts the wire bytes, then the original
     * Cmd3GoodHandler updates HDynVal/HDynEu. Do not decode the dynamic
     * variables a second time into a parallel redesign-only cache. */
    HartDb_LoadParsedResponse(db, cmd3);
    replyStatus = db->UpdateDatabase();

    if ((replyStatus != HREPLYSTATUS_GOOD) &&
        (replyStatus != HREPLYSTATUS_CONTINUE) &&
        (replyStatus != HREPLYSTATUS_MORE))
    {
        return FALSE;
    }

    /* A valid CMD3 transaction is successful even when the legacy RUN/ACTIVE
     * gate intentionally holds HDynVal. Discovery completion must therefore
     * follow the command result, while readers continue to require
     * m_HDataInit and a valid per-channel HDynVal. */
    return TRUE;
}

clsHartDevDb *HartDb_GetHartDevDb(VOID)
{
    return HartDb_GetChannelDevDb(HartGetActiveChannel());
}

HREPLYSTATUS HartDb_HandleResponse(const HartParsedResponse_t *response)
{
    clsHartDevDb *db;

    if (response == NULL)
    {
        return HREPLYSTATUS_BAD;
    }

    db = HartDb_GetChannelDevDb(HartGetActiveChannel());
    if (db == NULL)
    {
        return HREPLYSTATUS_BAD;
    }
    HartDb_LoadParsedResponse(db, response);
    HREPLYSTATUS replyStatus = db->UpdateDatabase();
    HartDb_RestoreWireCommandBlock(db, response);
    return replyStatus;
}

BOOL HartDb_GetPrimaryVariableForChannel(UINT8 channel,
                                         FLOAT32 *pvOut,
                                         UINT8 *unitOut)
{
    clsHartDevDb *db;

    if ((channel < 1u) || (channel > MAXSLOTS))
    {
        return FALSE;
    }

    db = HartDb_GetChannelDevDb(channel);
    if ((db == NULL) ||
        (db->m_HChanMode != HCHANMODE_SCAN) ||
        (db->m_HDataInit != HDATAINIT_COMPLETE) ||
        (db->HDynVal[0] != db->HDynVal[0]))
    {
        return FALSE;
    }

    /* HDynSt is defined only for HART 6 and later. HART 5 CMD3 has no
     * per-variable status byte, so m_HDataInit and the valid FLOAT32 are the
     * legacy availability indicators for that revision. */
    if ((db->m_ucHartVersion >= HARTVERSION_6X) &&
        (db->m_ucDynScan[0] == HARTCOMMAND_NINE) &&
        (db->HDynSt[0] != HART_DATA_AVAILABLE))
    {
        return FALSE;
    }

    if (pvOut != NULL)
    {
        *pvOut = db->HDynVal[0];
    }
    if (unitOut != NULL)
    {
        *unitOut = db->HDynEu[0];
    }
    return TRUE;
}
