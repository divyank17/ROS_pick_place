/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hartdb.cpp                                                  *
*    Description : HART database implementation.                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <string.h>
#include <stdint.h>

#include "hartdb.hpp"
#if defined(IOMTYPE_AIH)
#include "aihmain.h"
#endif



static FLOAT32 HartDb_ReadFloatBe(const UINT8 *bytes);
static FLOAT32 HartDb_NaN(VOID);
static VOID HartDb_CopyPayload(UINT8 *dst, UINT32 dstLen, const HartParsedResponse_t *rsp);

static HartDeviceInfo_t g_hartDevice;

const UINT8 clsHartCfgDb::HDevCd[] = {
    PARAMID_HDEVIDCD,
    PARAMID_HDVMFGCD,
    PARAMID_HDVTYPCD,
    PARAMID_HDEVIDCD,
    PARAMID_HDVREVCD,
    PARAMID_HDDREVCD,
    0
};

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
const UINT8 clsHartDevDb::HDvRngExt[] = {
    PARAMID_URV,
    PARAMID_LRV,
    PARAMID_URL,
    PARAMID_LRL,
    0
};
#endif

EVENTRECORD clsHartDevDb::HAlmOptChgEvent = {};
static clsHartCfgDb     g_HartCfgDb;
static clsHartCfgDb7    g_HartCfgDb7;
static clsHartDevDb     g_HartDevDb(16u, &g_HartCfgDb, &g_HartCfgDb7);

static clsHartDevDb *HartDb_GetChannelDevDb(UINT8 channel)
{
#if defined(IOMTYPE_AIH)
    if ((channel >= 1u) && (channel <= MAXSLOTS) && (pDatabase[channel] != NULL))
    {
        return &SLOT(channel)->GetHartDevDb();
    }
#endif
    return &g_HartDevDb;
}

UINT8 clsHartDevDb::m_stucNoOf1SecChannels = 0u;
const HARTCMDHANDLER clsHartDevDb::HartCmdHandler[clsHartDevDb::HARTCMDHANDLER_COUNT] = {
    { &clsHartDevDb::Cmd0GoodHandler, &clsHartDevDb::Cmd0BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd3GoodHandler, &clsHartDevDb::Cmd3BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd6GoodHandler, &clsHartDevDb::Cmd6BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd9GoodHandler, &clsHartDevDb::Cmd9BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd12GoodHandler, &clsHartDevDb::Cmd12BadHandler },
    { &clsHartDevDb::Cmd13GoodHandler, &clsHartDevDb::Cmd13BadHandler },
    { &clsHartDevDb::Cmd14GoodHandler, &clsHartDevDb::Cmd14BadHandler },
    { &clsHartDevDb::Cmd15GoodHandler, &clsHartDevDb::Cmd15BadHandler },
    { &clsHartDevDb::Cmd16GoodHandler, &clsHartDevDb::Cmd16BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd20GoodHandler, &clsHartDevDb::Cmd20BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd33GoodHandler, &clsHartDevDb::Cmd33BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd38GoodHandler, &clsHartDevDb::Cmd38BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd48GoodHandler, &clsHartDevDb::Cmd48BadHandler },
    { NULL, NULL },
    { &clsHartDevDb::Cmd50GoodHandler, &clsHartDevDb::Cmd50BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd59GoodHandler, &clsHartDevDb::Cmd59BadHandler },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { NULL, NULL },
    { &clsHartDevDb::Cmd109GoodHandler, &clsHartDevDb::Cmd109BadHandler }
};
/*******************************************************************************
*                           HART pass-through storage                          *
*******************************************************************************/

UINT8 g_ucHPstRcvBuffer[HART_MAX_BYTECOUNT * HPST_OBJECTCOUNT];
UINT8 *g_pucHPstRcvBuffer = g_ucHPstRcvBuffer;

/*******************************************************************************
*                           clsHartPst::operator new                           *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsHartPst::operator new(size_t, UINT8 a_PstNo) {
    return (g_usHPstObjMemory + (a_PstNo * CLSHARTPST_SIZE));
}
/*******************************************************************************
*                            clsHartPst::clsHartPst                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsHartPst::clsHartPst(VOID) : m_PstRcvBuffer(HART_MAX_BYTECOUNT,g_pucHPstRcvBuffer) {
    m_ucHandle         = INVALID_HANDLE;
    m_ucSlotNumber     = INVALID_SLOTNUM;
    m_ucPstMsgTimeout  = 0; 
    m_PstStatus        = HPSTSTATUS_DEAD;

    // Advance the buffer pointer for next object
    g_pucHPstRcvBuffer += HART_MAX_BYTECOUNT;
}

/*******************************************************************************
*                         clsHartPst::PassThroughTable                         *
*                         ============================                         *
* PURPOSE:                                                                     *
*   Returns a pointer to the pass through table for the modem                  *
* ARGUMENTS:                                                                   *
*   a_ucModemNum - Modem number, 0-based                                       *
* RETURN:                                                                      *
*   Pointer to the pass through table.                                         *
* NOTES:                                                                       *
*   None                                                                       *
*******************************************************************************/
clsHartPst** clsHartPst::PassThroughTable(UINT8 a_ucModemNum)
{
#if defined(IOMTYPE_UIO)
    return pUioHartPst[a_ucModemNum];
#else
    (void)a_ucModemNum;
    return pHartPst;
#endif
}


/*******************************************************************************
*                             clsHartCfgDb::InitCfgDb                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartCfgDb::InitCfgDb(VOID)
{
    HEnable = FALSE;
    HScanCfg = HSCANCFG_UNDEFINED;
    for (UINT8 ucCount = 0u; ucCount < HART6_MAXVAR_COUNT; ucCount++)
    {
        HSlotDvc[ucCount] = 0u;
    }
    HComThrs = HCOMTHRS_DEFAULT;
    HComHys = HCOMHYS_DEFAULT;
    HDvMfgCd = 0u;
    for (UINT8 ucCount = 0u; ucCount < HART_DEVICEID_SIZE; ucCount++)
    {
        HDevIdCd[ucCount] = 0u;
    }
    HDvTypCd = 0u;
    HDvRevCd = 0u;
    HDdRevCd = 0u;
    for (UINT8 ucCount = 0u; ucCount < HNTFYCFG_BYTECOUNT; ucCount++)
    {
        HNtfyCfg[ucCount] = 0u;
    }
    HAlarmEnable = HALARMENABLE_ALMENBSTATE_MASK;
    HAlarmEnableLrs = HALARMENABLE_ALMENBSTATE_MASK;
}

/*******************************************************************************
*                             clsHartCfgDb7::InitCfgDb                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartCfgDb7::InitCfgDb(VOID)
{
    for (UINT8 ucCount = 0u; ucCount < HART_MAXVAR_COUNT; ucCount++)
    {
        HSlotDvc7[ucCount] = 0u;
    }
    HDvMfgCd7[0] = 0u;
    HDvMfgCd7[1] = 0u;
    HDvTypCd7[0] = 0u;
    HDvTypCd7[1] = 0u;
    HSlot0TS = 0.0f;
}
/*******************************************************************************
*                            clsHartDevDb::clsHartDevDb                        *
*                            ==========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsHartDevDb::clsHartDevDb(UINT8 a_ucParent, clsHartCfgDb *a_pHartCfgDb, clsHartCfgDb7 *a_pHartCfgDb7) :
    m_cucParent(a_ucParent),
    m_pHartCfgDb(a_pHartCfgDb),
    m_pHartCfgDb7(a_pHartCfgDb7),
    m_ChanRcvBuffer(HART_MAX_BYTECOUNT, m_ChanRcvMemory)
{
    InitDevDb(TRUE);
}


/*******************************************************************************
*                             clsHartDevDb::InitDevDb                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::InitDevDb(BOOL a_bInitAll)
{
    (void)a_bInitAll;

    memset(&m_LastParsedResponse, 0, sizeof(m_LastParsedResponse));
    memset(m_ChanRcvMemory, 0, sizeof(m_ChanRcvMemory));
    memset(m_ScanMsgTbl, 0, sizeof(m_ScanMsgTbl));
    memset(&m_UniqueAddress, 0, sizeof(m_UniqueAddress));
    memset(m_ucDynScan, 0, sizeof(m_ucDynScan));
    memset(m_ucDevScan, 0, sizeof(m_ucDevScan));
    m_ucDynScan[0] = HARTCOMMAND_THREE;
    m_ucDevScan[0] = HARTCOMMAND_THIRTYTHREE;
    m_ucDevScan[1] = HART_MAXDYNVAR_COUNT;
    for (UINT8 idx = 0u; idx < HART_MAXDYNVAR_COUNT; idx++)
    {
        m_ucDevScan[(UINT8)(2u + idx)] = idx;
    }
    memset(HDevSt, 0, sizeof(HDevSt));
    memset(HDevStLrs, 0, sizeof(HDevStLrs));
    memset(HDynDvc, 0, sizeof(HDynDvc));
    memset(&HCmd0, 0, sizeof(HCmd0));
    memset(&HCmd3, 0, sizeof(HCmd3));
    memset(&HCmd12, 0, sizeof(HCmd12));
    memset(&HCmd13, 0, sizeof(HCmd13));
    memset(&HCmd14, 0, sizeof(HCmd14));
    memset(&HCmd15, 0, sizeof(HCmd15));
    memset(&HCmd16, 0, sizeof(HCmd16));
    memset(&HLongTag, 0, sizeof(HLongTag));
    memset(&HCmd48, 0, sizeof(HCmd48));
    memset(HCmd48Lrs, 0, sizeof(HCmd48Lrs));
    memset(&HCmd50, 0, sizeof(HCmd50));
    memset(&HCmd59, 0, sizeof(HCmd59));
    memset(HART7_CMD38, 0, sizeof(HART7_CMD38));

    m_HChanMode = HCHANMODE_INIT;
    m_HChanType = HCHANTYPE_CHANNEL;
    m_HDataInit = HDATAINIT_PENDING;
    m_HEventInit = HEVENTINIT_PENDING;
    m_ucLastDsa = 0u;
    m_sScanCounter = TICKS_DISABLE_SCAN;
    m_ucScanNo = 0u;
    m_ucSavedScanNo = 0u;
    m_ucB2BNo = 0u;
    m_ucSkipC48Cycles = 0u;
    m_ucPollingAddress = 0u;
    m_ucHartVersion = HARTVERSION_UNDEFINED;
    m_ucDeviceRevision = 0u;
    m_ucReqdPreambles = HART_DEFAULT_PREAMBLECOUNT;
    m_ucInitCmdIndex = 0u;
    m_ucPstAppIndex = 0u;
    m_ucPstRemIndex = 0u;
    m_ucLastReqCmd = HARTCOMMAND_ZERO;
    m_ucB2BPstMsgCount = 0u;
    m_ucpLastXmtPtr = NULL;
    m_ucLastRespCode = HART_RESPCODE_SUCCESS;
    m_ucNextReqCmd = HARTCOMMAND_ZERO;
    m_ucpNextXmtPtr = (UINT8 *)HARTCMD0;
    m_ucRcvBufIndex = 0u;
    m_ucRcvMsgLen = 0u;
    m_ucCommStatus = HCOMSTS_NORESPONSE;
    m_ucDeviceStatus = 0u;
    m_ucSecMasterResetCounter = 0u;
    m_ucScanOverrunCounter = 0u;
    m_ucPstPresentCounter = 0u;
    m_bCmd38FailReported = FALSE;
    m_bCmd48FailReported = FALSE;
    m_bReReportEvents = FALSE;
    m_ucTemplateChangeWaitCount = 0u;
    m_bHartChanFail = FALSE;
    HComSts = HCOMSTS_NORESPONSE;
    HLComFail = HCOMSTS_NORESPONSE;
    HNComErr = 0u;
    HCmdFail = HARTCOMMAND_INVALID;
    HCmdResp = HART_RESPCODE_SUCCESS;
    State = 0u;
    HDynRate = HSCANRATE_1SEC;
    HDevRate = HSCANRATE_16SEC;
    HTotalRate = HSCANRATE_1SEC;
    Command = COMMAND_UNDEFINED;
    Lrv = HartDb_NaN();
    Urv = HartDb_NaN();
    Lrl = HartDb_NaN();
    Url = HartDb_NaN();
    Damping = HartDb_NaN();
    StiEu = MAXUINT8;
    for (UINT8 i = 0u; i < HART_MAXDYNVAR_COUNT; i++)
    {
        HDynVal[i] = HartDb_NaN();
        HDynSt[i] = HART_DATA_NOT_AVAILABLE;
        HDynCc[i] = 0u;
        HDynEu[i] = 0u;
    }
    for (UINT8 i = 0u; i < HART_MAXVAR_COUNT; i++)
    {
        HSlotVal[i] = HartDb_NaN();
        HSlotSt[i] = HART_DATA_NOT_AVAILABLE;
        HSlotCc[i] = 0u;
        HSlotEu[i] = 0u;
    }
    HDevSlot0DTS = 0u;
    m_bAtLeastOneTry = FALSE;
    m_ulDynGoodCount = 0u;
    m_ulDevGoodCount = 0u;
    m_ulC48GoodCount = 0u;
    HT5_CfgChngCnt = 0u;
    m_ScanMsg = HSCANMSG_NONE;
}


/*******************************************************************************
*                             clsHartDevDb::SetHComSts                         *
*                             ========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::SetHComSts(HCOMSTS a_HComSts){
//    if (HCOMSTS_GOOD != a_HComSts) {
//        if (TRUE == m_pHartCfgDb->HEnable) {
//            BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_COMMSTATUS_BIT);
//            BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_INITCMPLT_BIT);
//            if (TRUE == m_bAtLeastOneTry) {
//                // Set the communication failue bit only if the
//                // HART communciation was attempted at least once.
//                HDevSt[1] |= HART_DEVST1_COMMFAIL_MASK;
//            }
//            m_HDataInit = HDATAINIT_COMPLETE;
//            m_HEventInit = HEVENTINIT_COMFAIL;
//            // if m_bReReportEvents is set, regen the ComFail event
//            PostHComFail(m_bReReportEvents);
//        }
//#if defined(IOMTYPE_AIH)
//        if ((FALSE == SLOT(m_cucParent)->GetHEnable()) && (PNTTYPE_NOTCONFIGURED != SLOT(m_cucParent)->GetPntType()))
//            BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
//        else if (0 == BOX->GetAdcCycleCount(m_cucParent))
//            BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
//        else
//            BOX->DecAdcCycleCount(m_cucParent);
//#endif
//#if defined(IOMTYPE_AOH)
//        if ((HART_AUTODETECT_OP > SLOT(m_cucParent)->GetOpFinal()) ||
//                ((PNTTYPE_NOTCONFIGURED != SLOT(m_cucParent)->GetPntType())
//                && (FALSE == SLOT(m_cucParent)->GetHEnable())))
//            BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
//        else if (0 == BOX->GetAdcCycleCount(m_cucParent))
//            BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
//        else
//            BOX->DecAdcCycleCount(m_cucParent);
//#endif
//#if defined(IOMTYPE_UIO)
//        PNTTYPE ChanType = BOX->GetInitPntType(m_cucParent);
//        if (PNTTYPE_ANALOGINPUT == ChanType) {
//            if (FALSE == AIH_SLOT(m_cucParent)->GetHEnable())
//                BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
//            else if (0 == BOX->GetAdcCycleCount(m_cucParent))
//                BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
//            else
//                BOX->DecAdcCycleCount(m_cucParent);
//        }
//        else if (PNTTYPE_ANALOGOUTPUT == ChanType) {
//            if ((HART_AUTODETECT_OP > AOH_SLOT(m_cucParent)->GetOpFinal()) ||
//                (FALSE == AOH_SLOT(m_cucParent)->GetHEnable()))
//                BOX->SetHADCStatus(m_cucParent, HART_DATA_UNKNOWN);
//            else if (0 == BOX->GetAdcCycleCount(m_cucParent))
//                BOX->SetHADCStatus(m_cucParent, HART_DATA_NOT_AVAILABLE);
//            else
//                BOX->DecAdcCycleCount(m_cucParent);
//        }
//#endif
//    }
//    else {
//        HDevSt[1] &= ~HART_DEVST1_COMMFAIL_MASK;
//        if (TRUE == m_pHartCfgDb->HEnable) {
//            BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_COMMSTATUS_BIT);
//        }
//    }
//
//    if (HCOMSTS_GOOD != HComSts) {
//        // Transfer only bad status to HLComFail.
//        HLComFail = HComSts;
//    }
    HComSts = a_HComSts;
}
/*******************************************************************************
*                             clsHartDevDb::SetHDevSt                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::SetHDevSt(UINT8 a_ucIdx,UINT8 a_ucSts) {
    if (FALSE == m_bAtLeastOneTry) {
        // if HART communication was not attempted even once,
        // do not set the communication failure bit.
        a_ucSts &= ~HART_DEVST1_COMMFAIL_MASK;
    }
    if (TRUE == m_pHartCfgDb->HEnable) {
        if ((0 == a_ucIdx) && (HDevSt[0] != a_ucSts)) {
            IncrementHDevStCounter();
        }
        HDevSt[a_ucIdx] = a_ucSts;
    }
    else { // if HART disabled clear all HDevSt bits
        HDevSt[a_ucIdx] = 0;
    }
}
/*******************************************************************************
*                             clsHartDevDb::SetHCmdFail                        *
*                             =========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::SetHCmdFail(HARTCOMMAND a_HartCmd,UINT8 a_ucRespCode) {
    if (HARTCOMMAND_INVALID == a_HartCmd) {
        HDevSt[1] &= ~HART_DEVST1_CMDFAIL_MASK;
    }
    else if ((TRUE == m_pHartCfgDb->HEnable) && 
        (HART_RESPCODE_CMD_NOT_IMPLEMENTED != a_ucRespCode)) {
        HDevSt[1] |= HART_DEVST1_CMDFAIL_MASK;
    }

    HCmdFail = a_HartCmd;
    HCmdResp = a_ucRespCode;
}
/*******************************************************************************
*                       clsHartDevDb::IncrementHCfgChCounter                   *
*                       ====================================                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::IncrementHCfgChCounter(VOID){
//	BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_CONFIGCOUNT_BIT0);
    // Flip most significant bit if least significant bit turned OFF 
//    if (BOX->GetHGChngFlBit(m_cucParent,HGCHNGFL_CONFIGCOUNT_BIT0) == 0) {
//        BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_CONFIGCOUNT_BIT1);
//    }

    HT5_CfgChngCnt++;
}
/*******************************************************************************
*                       clsHartDevDb::IncrementHDevStCounter                   *
*                       ====================================                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::IncrementHDevStCounter(VOID)
{
//    BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_STATUSCOUNT_BIT0);
    // Flip most significant bit if least significant bit turned OFF 
//    if (BOX->GetHGChngFlBit(m_cucParent,HGCHNGFL_STATUSCOUNT_BIT0) == 0) {
//        BOX->ToggleHGChngFlBit(m_cucParent,HGCHNGFL_STATUSCOUNT_BIT1);
}


/*******************************************************************************
*                         clsHartDevDb::ChannelHeartbeat                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
*    Perform HART channel processing activities periodically once every second.*
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Decrement scan counter. If the scan counter decrements to 0, add the   *
*       request for next transaction to the queue.                             *
*    2. Verify current requirements and make sure that this is the primary IOM *
*       before requesting modem services.                                      *
*    3. If request is successfully queued, setup transmit buffer pointer for   *
*       the current transaction and scan counter for next period. Otherwise,   *
*       setup scan counter for retry in the next cycle. Update scan overrun    *
*       alarm status.                                                          *
* NOTES:                                                                       *
*    1. This method is called HartTask once every second.                      *
*    2. To optimize the load, 4 channels processed at every quarter second     *
*       interval, resulting in one second processing per channel.              *
*******************************************************************************/
VOID clsHartDevDb::ChannelHeartbeat(VOID)
{
    if (m_sScanCounter > 0)
    {
        m_sScanCounter--;
    }
}


/*******************************************************************************
*                           clsHartDevDb::PostHComFail                         *
*                           ==========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsHartDevDb::PostHComFail(BOOL a_bIsRegen)
{
    (void)a_bIsRegen;
    return TRUE;
}
/*******************************************************************************
*                        clsHartDevDb::PostHAlmOptChgEvent                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsHartDevDb::PostHAlmOptChgEvent(BOOL a_bIsRegen)
{
    (void)a_bIsRegen;
    return TRUE;
}


/*******************************************************************************
*                         clsHartDevDb::ProcessHartEvents                      *
*                         ===============================                      *
*  This function does both regular HART event processing and HART event regen  *
*  depending on the boolean argument. Prcessing is arranged to three sections  *
*  for saving execution context if the event regen has to be suspended due to  *
*  not enough memory in event object. Instead of checking space before adding  *
*  every event, the test is done only before each byte in the device status or *
*  command 48 database is processed. Note that context saving is made use only *
*  by event regen task to resume from where it left off in the previous cycle. *
*  Regular event processing always start from zeroth context and rely on the   *
*  LRS mechanism to identify what to report during each cycle.                 *
*******************************************************************************/
BOOL clsHartDevDb::ProcessHartEvents(BOOL a_bIsRegen)
{
    (void)a_bIsRegen;

    if (m_pHartCfgDb == NULL)
    {
        return FALSE;
    }

    if (m_pHartCfgDb->HEnable == FALSE)
    {
        return TRUE;
    }

    if (m_sScanCounter == TICKS_DISABLE_SCAN)
    {
        return TRUE;
    }

    if (m_sScanCounter > 0)
    {
        return TRUE;
    }

    HSCANMSG newMsg = HSCANMSG_NONE;
    if (m_HChanMode == HCHANMODE_SCAN)
    {
        m_ucScanNo++;
        if (m_ucScanNo >= MAX_CYCLE_NUMBER)
        {
            m_ucScanNo = 0u;
        }

        newMsg = SetupScanMessage(m_ucScanNo, FIRST_SCAN_MSG);
        if (newMsg == HSCANMSG_NONE)
        {
            m_sScanCounter = TICKS_IN_1_SEC;
            return TRUE;
        }
    }
    else
    {
        if (m_ucInitCmdIndex >= HART_INITCOMMAND_COUNT)
        {
            m_HChanMode = HCHANMODE_SCAN;
            BuildScanTable();
            m_sScanCounter = TICKS_IN_1_SEC;
            return TRUE;
        }
    }

    if (InitHartConnection(m_cucParent) == TRUE)
    {
        m_bAtLeastOneTry = TRUE;
        m_ucSavedScanNo = m_ucScanNo;
        if (m_HChanMode == HCHANMODE_INIT)
        {
            m_sScanCounter = TICKS_SYNCED_CHAN;
        }
        else if (HTotalRate == HSCANRATE_1SEC)
        {
            m_sScanCounter = TICKS_SYNCED_CHAN;
        }
        else
        {
            m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    else
    {
        if (m_ucScanOverrunCounter < MAXUINT8)
        {
            m_ucScanOverrunCounter++;
        }
        m_sScanCounter = TICKS_IN_1_SEC;
    }

    return TRUE;
}


/*******************************************************************************
*                          clsHartDevDb::ReceptionComplete                     *
*                          ===============================                     *
* PURPOSE:                                                                     *
*    Callback used by the modem object to notify the channel that reception of *
*    a HART message from the link is complete.                                 *
* ARGUMENTS:                                                                   *
*    a_HartMsgStatus - Status of the received message GOOD, BAD or DEVICERROR. *
* RETURN:                                                                      *
*    HSYNCSTATUS - KEEP_SYNC for back-to-back message without disconnect.      *
*                  DROP_SYNC to release the modem and to schedule later.       *
* PROCESS:                                                                     *
*    1. Handle the received message depending on HART channel type and message *
*       status given by the modem object. For channel objects, update commn    *
*       status and call UpdataeDatabase method if the status is good. For      *
*       passthrough objects, simply update the status as the response data is  *
*       already received in passthrough response buffer.                       *
*    2. Update HDATAINIT status if required and setup next HART command to     *
*       process. Invoke BumpPollingAddress method if the last command failed   *
*       command zero. Setup CMD48 scan if more status available bit toggles.   *
*       Setup rediscovery if cold start or configuration changed is reported   *
*       or in case of any commn error. Otherwise setup next command from the   *
*       initialization table or scan table depending on channel mode.          *
*    3. Return appropriate status to request the modem object to handle next   *
*       transaction as a back-to-back message without disconnecting modem or   *
*       to release the modem and let it process other channels. In the latter  *
*       case, modem services will be requested again when scan counter expires.*
* NOTES:                                                                       *
*    1. If IOLP RAM diagnostics is not stopped by locking SemDiag, IOLP will   *
*       hard fail, if the database update was done at the same time when IOLP  *
*       doing diagnostics on a database location.                              *
*    2. This method is called from modem object methods - ActOnResponse and    *
*       SetupRetry.                                                            *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::ReceptionComplete(HMSGSTATUS a_HartMsgStatus){
    if (HMSGSTATUS_GOOD == a_HartMsgStatus)
    {
        (void)UpdateDatabase();
        return HSYNCSTATUS_DROP_SYNC;
    }

    SetHComSts(HCOMSTS_IOMFOUNDERROR);
    return HSYNCSTATUS_DROP_SYNC;
}


/*******************************************************************************
*                              clsHartDevDb::LogEvent                          *
*                              ======================                          *
* PURPOSE:                                                                     *
*    Callback used by the modem object to notify the client about various      *
*    reception events.                                                         *
* ARGUMENTS:                                                                   *
*    a_HartEventType - HART event type.                                        *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Update m_ucCommStatus according to the logged event and update IOM     *
*       database if required. Increment communication error count and update   *
*       excessive communication alarm status.                                  *
*    2. Schedule CMD109 if a burst mode device is detected. Setup secondary    *
*       master throttling counter for one minute in case secondary master is   *
*       detected. Flush the channel receive buffer for retry requests.         *
* NOTES:                                                                       *
*    1. This method is called from various modem object methods.               *
*******************************************************************************/
VOID clsHartDevDb::LogEvent(HEVENTTYPE a_HartEventType){
    (void)a_HartEventType;
}


/*******************************************************************************
*                          clsHartDevDb::BuildScanTable                        *
*                          ============================                        *
* PURPOSE:                                                                     *
*    Build HART scan scheduler.                                                *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Initialize the entire table with SCANMSG_NONE entries and if HART is   *
*       not enabled, return with defaulted scan table.                         *
*    2. Update HDynRate and HDevRate from HScanCfg if the channel is not marked*
*       as one second overrun channel. These channels run with degraded values *
*       for HDynRate and HDevRate, which is different from configured values.  *
*    3. If channel is not configured, configure only one C48 entry. When a C48 *
*       scan completes, m_ucSkipC48Cycles will be setup to skip this command   *
*       for three cycles, resulting a command 48 scan once every 64 seconds.   *
*    4. If control state is inactive or idle, or if device/revision mismatch   *
*       is set, populate a C48 for the first row first column and passthrough  *
*       messages in the first column of all other rows. Make sure that command *
*       48 will be scheduled at 16 seconds rateby disabling m_ucSkipC48Cycles. *
*    5. If control state is active, populate m_ScanMsgTbl with SCNMSG entries  *
*       depending on dynamic and device rate. If dyanmic and device rates are  *
*       both 0, make sure that m_ucSkipC48Cycles is disabled so that command   *
*       48 scan will be schedule at least once every 16 seconds.               *
*    6. If control state is active, make sure that there are at least three    *
*       passthrough message entries, preferably as back-to-back commands.      *
*    7. If device scan is configured, build device scan transmit buffer.       *
* NOTES:                                                                       *
*    1. This method is called from ScheduleFromInitTable from various HART     *
*       parameter post functions.                                              *
*    2. Even though passthrough scan is setup for one second rate when control *
*       state is inactive, if HCUAVAIL is greater then 40%, a dedicated modem  *
*       will be assigned for passthrough. So, if SWMUX is queing up requests,  *
*       maximum possible performance will be achieved.                         *
*    3. If either dynamic or device rate is configured, cyclic command 48 scan *
*       is delayed to once every 64 second using m_ucSkipC48Cycles. But this   *
*       does not delay scheduling of command 48 in response to toggling bits   *
*       in device status byte.                                                 *
*******************************************************************************/
VOID clsHartDevDb::BuildScanTable(VOID) {
    // For UIO, PST is removed from scan table entry, in place of PST, NONE is added
    unsigned short ucRow,ucCol;
  
    // Initialize scan table with NONE entries.
    for (ucRow = 0; ucRow < MAX_CYCLE_NUMBER; ucRow++) {
        for (ucCol = 0; ucCol < MAX_MSGS_IN_A_CYCLE; ucCol++) {
            m_ScanMsgTbl[ucRow][ucCol] = HSCANMSG_NONE;
        }
    }

    if ((m_pHartCfgDb == NULL) || (m_pHartCfgDb->HEnable == FALSE))
    {
        HDynRate = HSCANRATE_NONE;
        HDevRate = HSCANRATE_NONE;
        HTotalRate = HSCANRATE_NONE;
        return;
    }

    HSCANCFG scanCfg = m_pHartCfgDb->HScanCfg;
    if (scanCfg > HSCANCFG_STATUSONLY)
    {
        scanCfg = HSCANCFG_1SECDYN;
    }

    HDevRate = HSCANCFG_TABLE[scanCfg][0];
    HDynRate = HSCANCFG_TABLE[scanCfg][1];
    if ((HDynRate > HSCANRATE_NONE) || (HDevRate > HSCANRATE_NONE))
    {
        HTotalRate = (HSCANRATE)(HDynRate + HDevRate);
    }
    else
    {
        HTotalRate = HSCANRATE_16SEC;
    }

    if ((HDynRate == HSCANRATE_NONE) && (HDevRate == HSCANRATE_NONE))
    {
        m_ScanMsgTbl[0u][FIRST_SCAN_MSG] = HSCANMSG_C48;
        m_ucSkipC48Cycles = 0u;
        return;
    }

    if ((HDynRate > HSCANRATE_NONE) && (HDynRate >= HDevRate))
    {
        UINT8 period = (UINT8)(HSCANRATE_1SEC / HDynRate);
        if ((period == 0u) || (HTotalRate == HSCANRATE_1SEC))
        {
            period = 1u;
        }
        for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
        {
            if ((row % period) == 0u)
            {
                m_ScanMsgTbl[row][FIRST_SCAN_MSG] = HSCANMSG_DYN;
            }
        }

        if (HDevRate > HSCANRATE_NONE)
        {
            period = (UINT8)(HSCANRATE_1SEC / HDevRate);
            if ((period == 0u) || (HTotalRate == HSCANRATE_1SEC))
            {
                period = 1u;
            }
            for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
            {
                if ((row % period) == 0u)
                {
                    m_ScanMsgTbl[row][FIRST_B2B_MSG] = HSCANMSG_DEV;
                }
            }
        }
    }
    else if (HDevRate > HSCANRATE_NONE)
    {
        UINT8 period = (UINT8)(HSCANRATE_1SEC / HDevRate);
        if (period == 0u)
        {
            period = 1u;
        }
        for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
        {
            if ((row % period) == 0u)
            {
                m_ScanMsgTbl[row][FIRST_SCAN_MSG] = HSCANMSG_DEV;
            }
        }

        if (HDynRate > HSCANRATE_NONE)
        {
            period = (UINT8)(HSCANRATE_1SEC / HDynRate);
            if (period == 0u)
            {
                period = 1u;
            }
            for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
            {
                if ((row % period) == 0u)
                {
                    m_ScanMsgTbl[row][FIRST_B2B_MSG] = HSCANMSG_DYN;
                }
            }
        }
    }

    for (UINT8 row = 0u; row < MAX_CYCLE_NUMBER; row++)
    {
        if ((m_ScanMsgTbl[row][FIRST_SCAN_MSG] != HSCANMSG_NONE) &&
            (m_ScanMsgTbl[row][FIRST_B2B_MSG] == HSCANMSG_NONE))
        {
            m_ScanMsgTbl[row][FIRST_B2B_MSG] = HSCANMSG_C48;
            m_ucSkipC48Cycles = 0u;
            return;
        }
    }

    m_ScanMsgTbl[0u][FIRST_SCAN_MSG] = HSCANMSG_C48;
    m_ucSkipC48Cycles = 0u;
}


/*******************************************************************************
*                         clsHartDevDb::ControlStateChange                     *
*                         ================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::ControlStateChange(VOID)
{
    if ((m_pHartCfgDb != NULL) && (TRUE == m_pHartCfgDb->HEnable))
    {
            // Ensure that the scan overrun counter is reset and the alarm
            // bit is reset for any channel which is now inactivate or idle.
        m_ucScanOverrunCounter = 0u;
        HDevSt[1] &= (UINT8)~HART_DEVST1_SCANOVRUN_MASK;
        BuildScanTable();
//        if ((BOX->GetModuleStatus() == MODSTATUS_RUN) &&
//            (SLOT(m_cucParent)->GetPtExecSt() == PTEXECST_ACTIVE)) {
        m_ulDynGoodCount = 0u;
        m_ulDevGoodCount = 0u;
        m_ulC48GoodCount = 0u;
        m_sScanCounter = TICKS_IN_1_SEC;
//            BOX->ResetHGChngFlBit(m_cucParent,HGCHNGFL_PSTSTATUS_BIT);
    }
    else
    {
        InitDevDb(FALSE);
        m_sScanCounter = TICKS_IN_4_SEC;
        m_ucSkipC48Cycles = 0u;
//            BOX->SetHGChngFlBit(m_cucParent,HGCHNGFL_PSTSTATUS_BIT);
//        }
    }
}
/*******************************************************************************
*                         clsHartDevDb::CheckDevMismatch                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::CheckDevMismatch(VOID)
{
    UINT16 usManufacterId;
    UINT16 usDeviceType;
    UINT16 usDvMfgCd;
    UINT16 usDvTypCd;

    if (m_ucHartVersion >= HARTVERSION_7X)
    {
        usManufacterId = (UINT16)((((UINT16)HCmd0.str.ucusManufactureId[0]) << 8) |
                                  ((UINT16)HCmd0.str.ucusManufactureId[1]));
        usDeviceType = (UINT16)((((UINT16)HCmd0.str.ucusExpDeviceType[0]) << 8) |
                                ((UINT16)HCmd0.str.ucusExpDeviceType[1]));
        usDvMfgCd = *((UINT16 *)m_pHartCfgDb7->HDvMfgCd7);
        usDvTypCd = *((UINT16 *)m_pHartCfgDb7->HDvTypCd7);
        if ((usDvMfgCd == 0u) || (usDvTypCd == 0u))
        {
            usDvMfgCd = (UINT16)m_pHartCfgDb->HDvMfgCd;
            usDvTypCd = (UINT16)m_pHartCfgDb->HDvTypCd;
        }
    }
    else
    {
        usManufacterId = (UINT16)HCmd0.str.ucusExpDeviceType[0];
        usDeviceType = (UINT16)HCmd0.str.ucusExpDeviceType[1];
        usDvMfgCd = (UINT16)m_pHartCfgDb->HDvMfgCd;
        usDvTypCd = (UINT16)m_pHartCfgDb->HDvTypCd;
    }

    if ((m_ucInitCmdIndex > 0u) && (TRUE == m_pHartCfgDb->HEnable))
    {
        if (HART_GENERIC_MANUFACTURE_ID != usDvMfgCd)
        {
            if ((usDvMfgCd != usManufacterId) || (usDvTypCd != usDeviceType))
            {
                if (0u == (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK))
                {
                    HDevSt[1] |= HART_DEVST1_DEVMISMATCH_MASK;
                    if (HCHANMODE_SCAN == m_HChanMode)
                    {
                        InitDevDb(FALSE);
                        BuildScanTable();
                        m_sScanCounter = TICKS_IN_16_SEC;
                    }
                }
            }
            else if (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK)
            {
                HDevSt[1] &= (UINT8)~HART_DEVST1_DEVMISMATCH_MASK;
                if (HCHANMODE_SCAN == m_HChanMode)
                {
                    BuildScanTable();
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
            }

            if (0u == (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK))
            {
                if (m_pHartCfgDb->HDvRevCd != m_ucDeviceRevision)
                {
                    HDevSt[1] |= HART_DEVST1_REVMISMATCH_MASK;
                }
                else
                {
                    HDevSt[1] &= (UINT8)~HART_DEVST1_REVMISMATCH_MASK;
                }
            }
        }
        else
        {
            HDevSt[1] &= (UINT8)~HART_DEVST1_REVMISMATCH_MASK;
            if (HDevSt[1] & HART_DEVST1_DEVMISMATCH_MASK)
            {
                HDevSt[1] &= (UINT8)~HART_DEVST1_DEVMISMATCH_MASK;
                if (HCHANMODE_SCAN == m_HChanMode)
                {
                    BuildScanTable();
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
            }
        }

        BOOL bDevChanged = FALSE;
        for (UINT8 ucCount = 0u; ucCount < HART_DEVICEID_SIZE; ucCount++)
        {
            if (m_pHartCfgDb->HDevIdCd[ucCount] != m_UniqueAddress.str.ucDeviceId[ucCount])
            {
                bDevChanged = TRUE;
            }
        }
        if (TRUE == bDevChanged)
        {
            HDevSt[1] |= HART_DEVST1_DEVCHANGED_MASK;
        }
        else
        {
            HDevSt[1] &= (UINT8)~HART_DEVST1_DEVCHANGED_MASK;
        }
    }
}
/*******************************************************************************
*                        clsHartDevDb::CheckRangeMismatch                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::CheckRangeMismatch(VOID)
{
    if (m_ucInitCmdIndex <= HART_INITCMD14_INDEX)
    {
        return;
    }

    if ((HART_DATA_AVAILABLE == HSlotSt[0]) &&
        (HART_DATA_AVAILABLE == HSlotSt[1]) &&
        (Url < Lrl))
    {
        HDevSt[2] |= HART_DEVST2_RANGEMISMATCH_MASK;
    }
    else
    {
        HDevSt[2] &= (UINT8)~HART_DEVST2_RANGEMISMATCH_MASK;
    }
}
/*******************************************************************************
*                            clsHartDevDb::WriteHCmdData                       *
*                            ===========================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsHartDevDb::WriteHCmdData(HARTCOMMAND a_HCommand, UINT8 *a_pData)
{
    if (a_pData == NULL)
    {
        return;
    }

    switch (a_HCommand)
    {
        case HARTCOMMAND_ZERO:        memcpy(HCmd0.ucBytes, a_pData, sizeof(HCmd0.ucBytes)); break;
        case HARTCOMMAND_THREE:       memcpy(HCmd3.ucBytes, a_pData, sizeof(HCmd3.ucBytes)); break;
        case HARTCOMMAND_TWELVE:      memcpy(HCmd12.ucBytes, a_pData, sizeof(HCmd12.ucBytes)); break;
        case HARTCOMMAND_THIRTEEN:    memcpy(HCmd13.ucBytes, a_pData, sizeof(HCmd13.ucBytes)); break;
        case HARTCOMMAND_FOURTEEN:    memcpy(HCmd14.ucBytes, a_pData, sizeof(HCmd14.ucBytes)); break;
        case HARTCOMMAND_FIFTEEN:     memcpy(HCmd15.ucBytes, a_pData, sizeof(HCmd15.ucBytes)); break;
        case HARTCOMMAND_SIXTEEN:     memcpy(HCmd16.ucBytes, a_pData, sizeof(HCmd16.ucBytes)); break;
        case HARTCOMMAND_TWENTY:      memcpy(HLongTag.ucBytes, a_pData, sizeof(HLongTag.ucBytes)); break;
        case HARTCOMMAND_FOURTYEIGHT: memcpy(HCmd48.ucBytes, a_pData, sizeof(HCmd48.ucBytes)); break;
        case HARTCOMMAND_FIFTY:       memcpy(HCmd50.ucBytes, a_pData, sizeof(HCmd50.ucBytes)); break;
        case HARTCOMMAND_FIFTYNINE:   memcpy(HCmd59.ucBytes, a_pData, sizeof(HCmd59.ucBytes)); break;
        default: break;
    }
}


/*******************************************************************************
*                        clsHartDevDb::BumpPollingAddress                      *
*                        ================================                      *
* PURPOSE:                                                                     *
*    Increment polling address for device discovery.                           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HSYNCSTATUS - always returns HSYNCSTATUS_DROPSYNC to release the modem.   *
* PROCESS:                                                                     *
*    1. If this method was called just after command 0 poll failed for address *
*       zero, initialize entire HART database.                                 *
*    2. Increment the polling address and set scan counter for scheduling the  *
*       the next command 0 poll depending on the configuration.                *
*    3. If all 16 addresses are tried, suspend command zero poll for a longer  *
*       interval based on the configuration.                                   *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete method.                   *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::BumpPollingAddress(VOID){
    if (0 == m_ucPollingAddress) {
        InitDevDb(TRUE); 
    }
    if (m_ucPollingAddress < HART_POLADDR_MAXVAL){
        m_ucPollingAddress++;
        return HSYNCSTATUS_KEEP_SYNC;
    }
    return HSYNCSTATUS_DROP_SYNC;
}
/*******************************************************************************
*                       clsHartDevDb::ScheduleFromInitTable                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
*    Schedule the next initialization command.                                 *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HSYNCSTATUS - KEEP_SYNC for back-to-back message without releasing modem. *
*                  DROP_SYNC to release the modem and to schedule later.       *
* PROCESS:                                                                     *
*    1. Advance m_ucInitCmdIndex and setup channel object for scheduling the   *
*       command specified at this index in the initialization table unless the *
*       last message was not command 109. If the last message is 109, it menas *
*       that a bursting device was discovered and command 109 was issued to    *
*       turn off the burst mode, but it did not result in configuration change.*
*       In that case, initialize HART database and schedule next command zero  *
*       poll after four seconds.                                               *
*    2. If all commands in the initialization table completed, change channel  *
*       state to SCAN, notify SWMUX that initialization is complete and build  *
*       the scan table. Setup scan counter according to the channel state and  *
*       configuration.                                                         *
*    3. Otherwise, if the last command was not command 48, schedule the next   *
*       command from the INIT table as back-to-back messsage and disable scan  *
*       counter. If last command was C48, break the intialization sequence and *
*       setup scan counter to continue after 2 seconds. This is done to speed  *
*       up the HART event recovery for all channels.                           *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete method.                   *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::ScheduleFromInitTable(VOID)
{
    if (m_ucInitCmdIndex < HART_INITCOMMAND_COUNT)
    {
        m_ucInitCmdIndex++;
        return HSYNCSTATUS_KEEP_SYNC;
    }
    m_HChanMode = HCHANMODE_SCAN;
    return HSYNCSTATUS_DROP_SYNC;
}


/*******************************************************************************
*                       clsHartDevDb::ScheduleFromScanTable                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
*    Process the second and third columns of the scan table                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HSYNCSTATUS - KEEP_SYNC for back-to-back message without releasing modem. *
*                  DROP_SYNC to release the modem and to schedule later.       *
* PROCESS:                                                                     *
*    1. Advance m_ucB2BNo (column number) to check scan table for any message  *
*       configured in the next column of the current row. If yes, schedule it  *
*       as back-to-back message without releasing the modem.                   *
*    2. If all messages in a row are completed, return DROP_SYNC to release    *
*       the modem for non-synced channels. For synced channels, advance to the *
*       next row, search until the next valid entry is found and schedule it   *
*       as back-to-back message without disconnecting from the current modem.  *
*    3. If passthrough is going on for this channel and the control state is   *
*       inactive or idle and HCUAVAIL is greater than 40%, schedule next pass  *
*       through as back-to-back message. If there is no passthrough pending in *
*       the queue, schedule command 48 to keep the modem synced.               *
*       NOTE that comparison of HCUAVAIL is done with 10.0. This is becuase    *
*       30% of HCUAVAIL is already accounted on this channel since it is doing *
*       passthrough. So value of 10.0 really means that HCUAVAIL was 40% just  *
*       before passthrough on this channel started.                            *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete method.                   *
*******************************************************************************/
HSYNCSTATUS clsHartDevDb::ScheduleFromScanTable(VOID) {

#if defined(IOMTYPE_UIO)
    clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(m_cucParent));
#endif

    HSCANMSG NewMsg = HSCANMSG_NONE;

    do {
        m_ucB2BNo++;
        if (m_ucB2BNo > FINAL_B2B_MSG) {
            // Final back-to-back message just finished
            m_ucB2BNo = FIRST_SCAN_MSG;

            BOOL bModemNeedDiag = FALSE;

            // Modem will never be called out as suspect in UIO.
#if !defined(IOMTYPE_UIO)
            for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) {
                if (pHartModem[ucModem]->GetModemState() == HMODEMSTATE_SUSPECT) {
                    bModemNeedDiag = TRUE;
                    break;
                }
            }
#endif
//            if ((BOX->GetDSA() == 0) ||
//                (bModemNeedDiag == TRUE) ||
//                (MODSTATUS_IDLE == BOX->GetModuleStatus()) ||
//                (PTEXECST_INACTIVE == SLOT(m_cucParent)->GetPtExecSt())) {
//                // If IOM is idled or unloaded or became secondary or
//                // channel is inactivated or any modem requires diagnostics
//                // then release the current modem.
//                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
//                    m_sScanCounter = TICKS_IN_1_SEC;
//                }
//                return HSYNCSTATUS_DROP_SYNC;
//            }
            if (HSCANRATE_1SEC == HTotalRate) {
                // If the total scan rate is one second, process the next 
                // row of the scan table without releasing the modem.
                m_ucScanNo++;
                if (m_ucScanNo > MAX_CYCLE_NUMBER) {
                    m_ucScanNo = MIN_CYCLE_NUMBER;
                }
            }
            else {
                // If the total rate is less than one second rate, release
                // modem to let it process other channels. Next row will be
                // processed when scan counter expires. Make sure that the
                // scan counter is not disabled when releasing the modem.
                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
        }

        if (HSCANRATE_1SEC == HTotalRate) {
            NewMsg = SetupScanMessage(m_ucScanNo,m_ucB2BNo);
#if defined (IOMTYPE_UIO)
            m_ScanMsg = NewMsg;
            // Check added to exit the loop if no scan message is present in the scan table
            if(NewMsg == HSCANMSG_NONE) {
                m_ucB2BNo = FIRST_SCAN_MSG;
                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
#endif
        }
        else {
            NewMsg = SetupScanMessage(m_ucSavedScanNo,m_ucB2BNo);
#if defined(IOMTYPE_UIO)
            m_ScanMsg = NewMsg;
            // Check added to exit the loop if no scan message is present in the scan table
            if(NewMsg == HSCANMSG_NONE) {
                m_ucB2BNo = FIRST_SCAN_MSG;
                if (m_sScanCounter <= TICKS_SYNCED_CHAN) {
                    m_sScanCounter = TICKS_IN_1_SEC;
                }
                return HSYNCSTATUS_DROP_SYNC;
            }
#endif
        }

        // Loop until a valid message is found. If the total scan rate is less
        // than one second rate, this method would have returned, when the
        // final back-to-back message for this scan cycle (current row of scan 
        // table) is complete.
    } while (HSCANMSG_NONE == NewMsg);

    // Update last command also since this is a back-to-back message
    m_ucLastReqCmd  = m_ucNextReqCmd;
    m_ucpLastXmtPtr = m_ucpNextXmtPtr;
#if !defined(IOMTYPE_UIO)
    m_ScanMsg       = NewMsg;
#endif
    if (HSCANMSG_PST == NewMsg) {
        m_HChanType = HCHANTYPE_PASSTHROUGH;
        pHartPst[m_ucPstRemIndex]->m_PstStatus = HPSTSTATUS_RUNNING;
    }
    else {
        m_HChanType = HCHANTYPE_CHANNEL;
    }

    if (HSCANRATE_1SEC ==  HTotalRate) {
        // Make sure that no scan overrun alarm is posted for 
        // this channel as it is operating with dedicated modem now.
        m_ucScanOverrunCounter = 0;
        HDevSt[1] &= ~HART_DEVST1_SCANOVRUN_MASK;
    }

    return HSYNCSTATUS_KEEP_SYNC;
}
/*******************************************************************************
*                         clsHartDevDb::SetupScanMessage                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
*    Initialize transmit and receive pointers and other channel members for a  *
*    scheduling a specificed command from the scan table.                      *
* ARGUMENTS:                                                                   *
*    1. a_ucRowNo - Scan table row number.                                     *
*    2. a_ucColNo - Scan table column number.                                  *
* RETURN:                                                                      *
*    HSCANMSG - DYN for dynamic scan, DEV for device scan, C48 for command 48  *
*               scan, PST for passthrough message and NONE for no message.     *
* PROCESS:                                                                     *
*    1. Setup channel object according to the HSCANMSG entry at the specified  *
*       row and column of the scan table.                                      *
*    2. If SCNMSG entry is C48, check the value of m_ucSkipC48Cycles and if it *
*       is greater than zero, decrement it and return NONE to skip this cycle. *
*    3. If SCNMSG entry is PST, call SetupPassthrough to check the passthrough *
*       queue in the shared RAM. If any pending request is found, schedule it; *
*       otherwise return NONE.                                                 *
* NOTES:                                                                       *
*    1. This method is called from the following methods - ChannelHeartbeat,   *
*       ScheduleFromInitTable and ScheduleFromScanTable.                       *
*******************************************************************************/
HSCANMSG clsHartDevDb::SetupScanMessage(UINT8 a_ucScanNo, UINT8 a_ucB2BNo)
{
    if ((a_ucScanNo >= MAX_CYCLE_NUMBER) || (a_ucB2BNo >= MAX_MSGS_IN_A_CYCLE))
    {
        return HSCANMSG_NONE;
    }

    switch (m_ScanMsgTbl[a_ucScanNo][a_ucB2BNo])
    {
        case HSCANMSG_DYN:
            m_ucNextReqCmd = HARTCOMMAND_THREE;
            m_ucDynScan[0] = HARTCOMMAND_THREE;
            m_ucpNextXmtPtr = &m_ucDynScan[0];
            return HSCANMSG_DYN;

        case HSCANMSG_DEV:
            m_ucNextReqCmd = HARTCOMMAND_THIRTYTHREE;
            m_ucDevScan[0] = HARTCOMMAND_THIRTYTHREE;
            m_ucDevScan[1] = (m_ucHartVersion < HARTVERSION_7X) ? HART6_MAXVAR_COUNT : HART_MAXDYNVAR_COUNT;
            m_ucpNextXmtPtr = &m_ucDevScan[0];
            return HSCANMSG_DEV;

        case HSCANMSG_C48:
            if (m_ucSkipC48Cycles > 0u)
            {
                m_ucSkipC48Cycles--;
                return HSCANMSG_NONE;
            }
            m_ucNextReqCmd = HARTCOMMAND_FOURTYEIGHT;
            m_ucpNextXmtPtr = (UINT8 *)&HARTCMD48[0];
            return HSCANMSG_C48;

        case HSCANMSG_PST:
            return SetupPassThrough();

        default:
            break;
    }

    return HSCANMSG_NONE;
}
/*******************************************************************************
*                          clsHartDevDb::SetupPassThrough                      *
*                          ==============================                      *
* PURPOSE:                                                                     *
*    Check passthrough request queue and schedule any pending message.         *
* ARGUMENTS:                                                                   *
*    NONE.                                                                     *
* RETURN:                                                                      *
*    HSCANMSG - PST if a passthrough message is pending; otherwise NONE.       *
* PROCESS:                                                                     *
*    1. If last passthrough message is still running, return.                  *
*    2. Scan the passthrough queue for any pending message for this channel.   *
*       The channel object member m_ucPstRemIndex tracks the next index in the *
*       passthrough queue to be examined.                                      *
*    3. Check command amd address before scheduling. Always block command zero *
*       and command 38. If the address does not match with the address in the  *
*       channel object, return DEAD status in passsthrough status table.       *
*    4. If the above tests pass, prepare channel object for passthrough and    *
*       flush the passthrough response buffer. Return PST to schedule it.      *
* NOTES:                                                                       *
*    1. This method is called from SetupScanMessage, ScheduleFromInitTable,    *
*       and ReceptionComplete.                                                 *
*******************************************************************************/
HSCANMSG clsHartDevDb::SetupPassThrough(VOID) 
{
    clsHartPst **pstTable = clsHartPst::PassThroughTable(HartGetModemForChannel(m_cucParent));

    if (pstTable == NULL)
    {
        return HSCANMSG_NONE;
    }

    if (m_HChanType == HCHANTYPE_PASSTHROUGH)
    {
        return HSCANMSG_NONE;
    }

    for (UINT8 count = 0u, pstIndex = m_ucPstRemIndex; count < HPST_OBJECTCOUNT; count++)
    {
        pstIndex++;
        if (pstIndex >= HPST_OBJECTCOUNT)
        {
            pstIndex = 0u;
        }

        clsHartPst *pst = pstTable[pstIndex];
        if ((pst == NULL) ||
            (pst->m_ucSlotNumber != m_cucParent) ||
            (pst->m_PstStatus != HPSTSTATUS_INIT))
        {
            continue;
        }

        m_ucPstRemIndex = pstIndex;
#if defined(IOMTYPE_UIO)
        UINT8 *req = g_ucHPstReqBuffer[HartGetModemForChannel(m_cucParent)][m_ucPstRemIndex];
#else
        UINT8 *req = g_ucHPstReqBuffer[m_ucPstRemIndex];
#endif

        if ((req[HPST_DELIMITER_OFFSET] & HART_ADDR_TYPE_MASK) == 0u)
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        if ((m_UniqueAddress.ucBytes[0] & HART_MANUFACTURE_ID_MASK) !=
            (req[HPST_ADDRESS_OFFSET] & HART_MANUFACTURE_ID_MASK))
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        BOOL addressMatch = TRUE;
        for (UINT8 addr = 1u; addr < HART_LONGADDR_LENGTH; addr++)
        {
            if (m_UniqueAddress.ucBytes[addr] != req[(UINT8)(HPST_ADDRESS_OFFSET + addr)])
            {
                addressMatch = FALSE;
                break;
            }
        }

        if (addressMatch == FALSE)
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        HARTCOMMAND pstCmd = (HARTCOMMAND)req[HPST_COMMAND_OFFSET];
        if ((pstCmd == HARTCOMMAND_ZERO) || (pstCmd == HARTCOMMAND_THIRTYEIGHT))
        {
            pst->m_ucPstMsgTimeout = HPST_TIMEOUT_COUNT;
            pst->m_PstStatus = HPSTSTATUS_DEAD;
            continue;
        }

        m_ucNextReqCmd = (UINT8)pstCmd;
        m_ucpNextXmtPtr = req;
        pst->m_PstRcvBuffer.Flush();

        if ((m_ucDeviceStatus & (HART_DEVSTS_COLD_START | HART_DEVSTS_CFG_CHANGED)) == 0u)
        {
            m_ucPstPresentCounter = TICKS_IN_16_SEC;
        }

        return HSCANMSG_PST;
    }

    // No passthrough message to process for this channel
    return HSCANMSG_NONE;
}
/*******************************************************************************
*                          clsHartDevDb::UpdateDatabase                        *
*                          ============================                        *
* PURPOSE:                                                                     *
*    Update the IOM database with HART data from the received response.        *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    HREPLYSTATUS - GOOD, CONTINUE for scheduling next message.                *
*                   BAD, REINIT for rediscovering the device.                  *
*                   MORE for issuing command 48.                               *
* PROCESS:                                                                     *
*    1. Update the device status byte in the database. If the channel mode is  *
*       SCAN, check inidividual bits and rediscover or issue C48 as required.  *
*    2. Call the good handler or bad handler depending on the command and the  *
*       response code.                                                         *
* NOTES:                                                                       *
*    1. This method is called from ReceptionComplete.                          *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::UpdateDatabase(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    HARTCMDHANDLER handler;

    if ((rsp == NULL) || !rsp->valid || !rsp->checksumOk)
    {
        SetHComSts(HCOMSTS_IOMFOUNDERROR);
        return HREPLYSTATUS_BAD;
    }

    m_ucLastReqCmd = rsp->command;
    m_ucLastRespCode = rsp->status0;
    m_ucDeviceStatus = rsp->status1;
    m_ucRcvMsgLen = rsp->payloadLen;
    m_ucRcvBufIndex = 3u;
    SetHDevSt(0u, m_ucDeviceStatus);

    if (m_ucLastReqCmd >= HARTCMDHANDLER_COUNT)
    {
        SetHCmdFail(HARTCOMMAND_INVALID, HART_INVALID_PARAMETER_CODE);
        return HREPLYSTATUS_BAD;
    }

    handler = HartCmdHandler[m_ucLastReqCmd];
    if (rsp->status0 == HART_RESPCODE_SUCCESS)
    {
        if (handler.GoodHandler != NULL)
        {
            return (this->*handler.GoodHandler)();
        }
        return HREPLYSTATUS_GOOD;
    }

    if (rsp->status0 == HART_RESPCODE_DEVICE_BUSY)
    {
        return HREPLYSTATUS_BUSY;
    }

    if (handler.BadHandler != NULL)
    {
        return (this->*handler.BadHandler)(rsp->status0);
    }

    SetHCmdFail((HARTCOMMAND)rsp->command, rsp->status0);
    return HREPLYSTATUS_BAD;
}
/*******************************************************************************
*                         clsHartDevDb::GetHartLoading                         *
*                         ============================                         *
* PURPOSE:                                                                     *
*    Return HART loading factor to update HCUAVAIL parameter.                  *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    float - HART loading factor for this channel.                             *
* PROCESS:                                                                     *
*    1. 0% load for all HART disabled channels or if IOP is secondary.         *
*    2. 1% load for all unconfigured channels.                                 *
*    3. 1.6% load if channel is inactive or idle for C48 monitoring.           *
*    4. If channel mode is INIT, return 15% to account for device discovery.   *
*    5. If passthrough is being done in inactive state, return 25%.            *
*    5. Return 30% load for active and run 1-second channels.                  *
*    6. For active and run non-synced channels, calculate loading factor based *
*       on dynamic and device reate. Add 10% if passthrough is being done.     *
* NOTES:                                                                       *
*    1. This method is called from HART task once every second.                *
*******************************************************************************/
FLOAT32 clsHartDevDb::GetHartLoading(VOID){

    return 0.0f;
}


/*******************************************************************************
*                         clsHartDevDb::Cmd0GoodHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd0GoodHandler(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;

    HartDb_CopyPayload(HCmd0.ucBytes, sizeof(HCmd0.ucBytes), rsp);

    if (rsp->payloadLen >= HART_DEVICEID_SIZE + 9u)
    {
        m_UniqueAddress.ucBytes[0] = rsp->longAddr[0];
        m_UniqueAddress.ucBytes[1] = rsp->longAddr[1];
        m_UniqueAddress.ucBytes[2] = rsp->longAddr[2];
        m_UniqueAddress.ucBytes[3] = rsp->longAddr[3];
        m_UniqueAddress.ucBytes[4] = rsp->longAddr[4];

        m_ucReqdPreambles = rsp->responsePreambles;
        m_ucHartVersion = rsp->hartRevision;
        m_ucDeviceRevision = rsp->deviceRevision;
    }

    if ( m_ucHartVersion >= HARTVERSION_6X) {
        m_ucDevScan[0] = HARTCOMMAND_NINE;
    }
    else if (m_ucHartVersion == HARTVERSION_5X)
    {
        m_ucDevScan[0] = HARTCOMMAND_THIRTYTHREE;
    }
    else {
        m_ucHartVersion = HARTVERSION_MISMATCH;
    }

    if (m_ucHartVersion == HARTVERSION_MISMATCH)
    {
        return Cmd0BadHandler(HARTVERSION_MISMATCH);
    }

    if (HARTCOMMAND_ZERO == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }

    SetHComSts(HCOMSTS_GOOD);
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd0BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd0BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_ZERO,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd3GoodHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd3GoodHandler(VOID) {
    // Read dynamic variables and loop current.

    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    HARTCMD3RESPONSE *pResponse = &HCmd3;
    DATABYTES DataQvVal;
    DATABYTES DataTvVal;
    DATABYTES DataSvVal;
    DATABYTES DataPvVal;
    DATABYTES DataLoopCurrent;

    HartDb_CopyPayload(HCmd3.ucBytes, sizeof(HCmd3.ucBytes), rsp);

    DataLoopCurrent.f32Val = HartDb_NaN();
    DataQvVal.f32Val = HartDb_NaN();
    DataTvVal.f32Val = HartDb_NaN();
    DataSvVal.f32Val = HartDb_NaN();
    DataPvVal.f32Val = HartDb_NaN();

    if (m_ucRcvMsgLen >= sizeof(FLOAT32))
    {
        DataLoopCurrent.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfLoopCurrent);
    }

    if (m_ucRcvMsgLen >= HART_CMD3_4VAR_RESPONSE_SIZE)
    {
        DataQvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfQvVal);
        HDynVal[3] = DataQvVal.f32Val;
        HDynEu[3] = pResponse->str.ucQvUnitCode;
        HDynSt[3] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[3] = HartDb_NaN();
        HDynEu[3] = 0u;
        HDynSt[3] = HART_DATA_NOT_AVAILABLE;
    }

    if (m_ucRcvMsgLen >= HART_CMD3_3VAR_RESPONSE_SIZE)
    {
        DataTvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfTvVal);
        HDynVal[2] = DataTvVal.f32Val;
        HDynEu[2] = pResponse->str.ucTvUnitCode;
        HDynSt[2] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[2] = HartDb_NaN();
        HDynEu[2] = 0u;
        HDynSt[2] = HART_DATA_NOT_AVAILABLE;
    }

    if (m_ucRcvMsgLen >= HART_CMD3_2VAR_RESPONSE_SIZE)
    {
        DataSvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfSvVal);
        HDynVal[1] = DataSvVal.f32Val;
        HDynEu[1] = pResponse->str.ucSvUnitCode;
        HDynSt[1] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[1] = HartDb_NaN();
        HDynEu[1] = 0u;
        HDynSt[1] = HART_DATA_NOT_AVAILABLE;
    }

    if (m_ucRcvMsgLen >= HART_CMD3_1VAR_RESPONSE_SIZE)
    {
        DataPvVal.f32Val = HartDb_ReadFloatBe(pResponse->str.ucfPvVal);
        HDynVal[0] = DataPvVal.f32Val;
        HDynEu[0] = pResponse->str.ucPvUnitCode;
        HDynSt[0] = HART_DATA_AVAILABLE;
    }
    else
    {
        HDynVal[0] = HartDb_NaN();
        HDynEu[0] = 0u;
        HDynSt[0] = HART_DATA_NOT_AVAILABLE;
    }

    g_hartDevice.loopCurrentMa = DataLoopCurrent.f32Val;

    m_ulDynGoodCount++;
    if (HARTCOMMAND_THREE == HCmdFail){
        SetHCmdFail(HARTCOMMAND_INVALID, HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd3BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd3BadHandler(UINT8 a_ucRespCode) {
    if (HART_RESPCODE_DATA_DID_NOT_CHANGE == a_ucRespCode) {
        return Cmd3GoodHandler();
    }

    SetHCmdFail(HARTCOMMAND_THREE, a_ucRespCode);
    for (UINT8 ucCount = 0u; ucCount < HART_MAXDYNVAR_COUNT; ucCount++)
    {
        HDynVal[ucCount] = HartDb_NaN();
        HDynEu[ucCount] = 0u;
        HDynSt[ucCount] = HART_DATA_NOT_AVAILABLE;
    }
    g_hartDevice.dynamicValid = FALSE;
    g_hartDevice.dynamicCount = 0u;
    g_hartDevice.loopCurrentMa = HartDb_NaN();

    // Return reply status continue so that next message 
    // of the scan table will be scheduled.
    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd6GoodHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd6GoodHandler(VOID) {
    // Write polling address and loop current mode
    HARTCMD6RESPONSE *pResponse = (HARTCMD6RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    if ((pResponse->str.ucPollingAddress & HART_POLLING_ADDR_MASK) != 0) {
        SetHCmdFail(HARTCOMMAND_SIX,HART_RESPCODE_DATA_DID_NOT_CHANGE);
        return HREPLYSTATUS_REINIT;
    }
    else {
        m_ucPollingAddress = 0;
    }

    if (( m_ucHartVersion >= HARTVERSION_6X) && 
        (HART_LOOP_CURRENT_ENABLED != pResponse->str.ucLoopCurMode)) {
        SetHCmdFail(HARTCOMMAND_SIX,HART_RESPCODE_DATA_DID_NOT_CHANGE);
        return HREPLYSTATUS_REINIT;
    }
 
    if (HARTCOMMAND_SIX == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    // All tests passed - good transaction.
    //Command 6 is configuration change command,so increment config change counter.
    HT5_CfgChngCnt ++;
    
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd6BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd6BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_SIX,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd9GoodHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd9GoodHandler(VOID)
{
    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    UINT8 maxVars = (UINT8)((rsp->payloadLen > 1u) ? ((rsp->payloadLen - 1u) / HART_SIZEOFVAR0) : 0u);
    if (maxVars > HART_MAXVAR_COUNT)
    {
        maxVars = HART_MAXVAR_COUNT;
    }

    for (UINT8 i = 0u; i < maxVars; i++)
    {
        UINT8 off = (UINT8)(1u + (i * HART_SIZEOFVAR0));
        HSlotEu[i] = rsp->payload[off + 2u];
        HSlotVal[i] = HartDb_ReadFloatBe(&rsp->payload[off + 3u]);
        HSlotSt[i] = rsp->payload[off + 7u];
    }

    m_ulDevGoodCount++;
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd9BadHandler                        *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd9BadHandler(UINT8 a_ucRespCode){

    SetHCmdFail(HARTCOMMAND_NINE, a_ucRespCode);
    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd12GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd12GoodHandler(VOID) {
    HARTCMD12RESPONSE *pResponse = (HARTCMD12RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_TWELVE,(UINT8 *)pResponse);

    if (HARTCOMMAND_TWELVE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd12BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd12BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_TWELVE,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd13GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd13GoodHandler(VOID) {
    // Read Tag, Descriptor, Date
    HARTCMD13RESPONSE *pResponse = (HARTCMD13RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_THIRTEEN,(UINT8 *)pResponse);

    if (HARTCOMMAND_THIRTEEN == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd13BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd13BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_THIRTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd14GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd14GoodHandler(VOID){
    HartDb_CopyPayload(HCmd14.ucBytes, sizeof(HCmd14.ucBytes), &m_LastParsedResponse);
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd14BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd14BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_FOURTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd15GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd15GoodHandler(VOID){

    const HartParsedResponse_t *rsp = &m_LastParsedResponse;
    HartDb_CopyPayload(HCmd15.ucBytes, sizeof(HCmd15.ucBytes), rsp);
    if (rsp->payloadLen >= HART_CMD15_RESPONSE_SIZE)
    {
        StiEu = rsp->payload[2];
        Urv = HartDb_ReadFloatBe(&rsp->payload[3]);
        Lrv = HartDb_ReadFloatBe(&rsp->payload[7]);
        Damping = HartDb_ReadFloatBe(&rsp->payload[11]);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd15BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd15BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_FIFTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd16GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd16GoodHandler(VOID) {
    // Read final assembly number
    HARTCMD16RESPONSE *pResponse = (HARTCMD16RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_SIXTEEN,(UINT8 *)pResponse);
    if (HARTCOMMAND_SIXTEEN == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd16BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd16BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_SIXTEEN,a_ucRespCode);
    return HREPLYSTATUS_REINIT;
}

/*******************************************************************************
*                          clsHartDevDb::Cmd20GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd20GoodHandler(VOID) {
    HARTLONGTAG_RESPONSE *pResponse = (HARTLONGTAG_RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    WriteHCmdData(HARTCOMMAND_TWENTY,(UINT8 *)pResponse);
    if (HARTCOMMAND_TWENTY == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd20BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd20BadHandler(UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_TWENTY,a_ucRespCode);
    return HREPLYSTATUS_CONTINUE;
}

/*******************************************************************************
*                          clsHartDevDb::Cmd33GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd33GoodHandler(VOID) { // Ready device variables  
    
    HARTCMD33RESPONSE Cmd33Response;
    DATABYTES DataVar0Val;
    DATABYTES DataVar1Val;
    DATABYTES DataVar2Val;
    DATABYTES DataVar3Val;

    memset(&Cmd33Response, 0, sizeof(Cmd33Response));
    HartDb_CopyPayload(Cmd33Response.ucBytes, sizeof(Cmd33Response.ucBytes), &m_LastParsedResponse);

    DataVar0Val.f32Val = HartDb_NaN();
    DataVar1Val.f32Val = HartDb_NaN();
    DataVar2Val.f32Val = HartDb_NaN();
    DataVar3Val.f32Val = HartDb_NaN();

    if (m_ucRcvMsgLen >= HART_CMD33_4VAR_RESPONSE_SIZE)
    {
        DataVar3Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar3Val);
    }
    if (m_ucRcvMsgLen >= HART_CMD33_3VAR_RESPONSE_SIZE)
    {
        DataVar2Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar2Val);
    }
    if (m_ucRcvMsgLen >= HART_CMD33_2VAR_RESPONSE_SIZE)
    {
        DataVar1Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar1Val);
    }
    if (m_ucRcvMsgLen >= HART_CMD33_1VAR_RESPONSE_SIZE)
    {
        DataVar0Val.f32Val = HartDb_ReadFloatBe(Cmd33Response.str.ucfVar0Val);
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_4VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[5] == Cmd33Response.str.ucVar3Code))
    {
        HSlotEu[3] = Cmd33Response.str.ucVar3Unit;
		//HSlotVal[3] = pResponse->str.fVar3Val;
        HSlotVal[3] = DataVar3Val.f32Val;
        HSlotSt[3] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[3] = 0u;
        HSlotVal[3] = HartDb_NaN();
        HSlotSt[3] = HART_DATA_NOT_AVAILABLE;
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_3VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[4] == Cmd33Response.str.ucVar2Code))
    {
        HSlotEu[2] = Cmd33Response.str.ucVar2Unit;
        HSlotVal[2] = DataVar2Val.f32Val;
        HSlotSt[2] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[2] = 0u;
        HSlotVal[2] = HartDb_NaN();
        HSlotSt[2] = HART_DATA_NOT_AVAILABLE;
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_2VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[3] == Cmd33Response.str.ucVar1Code))
    {
        HSlotEu[1] = Cmd33Response.str.ucVar1Unit;
        HSlotVal[1] = DataVar1Val.f32Val;
        HSlotSt[1] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[1] = 0u;
        HSlotVal[1] = HartDb_NaN();
        HSlotSt[1] = HART_DATA_NOT_AVAILABLE;
    }

    if ((m_ucRcvMsgLen >= HART_CMD33_1VAR_RESPONSE_SIZE) &&
        (m_ucDevScan[2] == Cmd33Response.str.ucVar0Code))
    {
        HSlotEu[0] = Cmd33Response.str.ucVar0Unit;
        HSlotVal[0] = DataVar0Val.f32Val;
        HSlotSt[0] = HART_DATA_AVAILABLE;
    }
    else
    {
        HSlotEu[0] = 0u;
        HSlotVal[0] = HartDb_NaN();
        HSlotSt[0] = HART_DATA_NOT_AVAILABLE;
    }

    m_ulDevGoodCount++;
    
    if (HARTCOMMAND_THIRTYTHREE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd33BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd33BadHandler(UINT8 a_ucRespCode) {
    if (HART_RESPCODE_DATA_DID_NOT_CHANGE == a_ucRespCode) {
        return Cmd33GoodHandler();
    }

    SetHCmdFail(HARTCOMMAND_THIRTYTHREE, a_ucRespCode);
    for (UINT8 ucCount = 0u; ucCount < HART_MAXVAR_COUNT; ucCount++)
    {
        HSlotVal[ucCount] = HartDb_NaN();
        HSlotEu[ucCount] = 0u;
        HSlotSt[ucCount] = HART_DATA_NOT_AVAILABLE;
    }

    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd38GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd38GoodHandler(VOID) {    
    HARTCMD38RESPONSE *pResponse = (HARTCMD38RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);
    if (HARTCOMMAND_THIRTYEIGHT == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }

    if (TRUE == m_bCmd38FailReported) {
        // Device was write protected earlier and is now write protection is
        // disabled. Schedule rediscovery so that any configuration change 
        // will be updated in the device database.
        m_bCmd38FailReported = FALSE;
        return HREPLYSTATUS_REINIT;
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd38BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd38BadHandler(UINT8 a_ucRespCode) {
    if (FALSE == m_bCmd38FailReported) {
        // If command 38 failed with write protected error, set the database
        // flag to notify scheduler to continue dynamic scan and schedule
        // command 38 once every minute to recheck write protect status.
        if (HART_RESPCODE_WRITE_PROTECTED == a_ucRespCode){
            m_bCmd38FailReported = TRUE;
        }
        
        SetHCmdFail(HARTCOMMAND_THIRTYEIGHT,a_ucRespCode);
    }

    return HREPLYSTATUS_CONTINUE;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd48GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd48GoodHandler(VOID){
    HartDb_CopyPayload(HCmd48.ucBytes, sizeof(HCmd48.ucBytes), &m_LastParsedResponse);
    memcpy(HCmd48Lrs, HCmd48.ucBytes, sizeof(HCmd48Lrs));
    m_bCmd48FailReported = FALSE;
    m_ulC48GoodCount++;
    
    if (HARTCOMMAND_FOURTYEIGHT == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }

    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd48BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd48BadHandler(UINT8 a_ucRespCode) { 
m_bCmd48FailReported = TRUE; SetHCmdFail(HARTCOMMAND_FOURTYEIGHT, a_ucRespCode); return HREPLYSTATUS_CONTINUE; }


/*******************************************************************************
*                          clsHartDevDb::Cmd50GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd50GoodHandler(VOID) {
    // Read dynamic variable association
    HARTCMD50RESPONSE *pResponse = (HARTCMD50RESPONSE *)m_ChanRcvBuffer.AddrAt(m_ucRcvBufIndex);

    if ( m_ucHartVersion >= HARTVERSION_6X) {
        m_ucDynScan[0] = HARTCOMMAND_NINE;
    }
    else {
        m_ucDynScan[0] = HARTCOMMAND_THREE;
    }
    m_ucDynScan[1] = 0;

    if (pResponse->str.ucDynVar0Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar0Code;
        }
        HDynDvc[0] = pResponse->str.ucDynVar0Code;
    }

    if (pResponse->str.ucDynVar1Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar1Code;
        }
        HDynDvc[1] = pResponse->str.ucDynVar1Code;
    }

    if (pResponse->str.ucDynVar2Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar2Code;
        }
        HDynDvc[2] = pResponse->str.ucDynVar2Code;
    }

    if (pResponse->str.ucDynVar3Code != HART_INVALID_PARAMETER_CODE) {
        if ( m_ucHartVersion >= HARTVERSION_6X) {
            m_ucDynScan[1]++;
            m_ucDynScan[m_ucDynScan[1] + 1] = pResponse->str.ucDynVar3Code;
        }
        HDynDvc[3] = pResponse->str.ucDynVar3Code;
    }
    
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd50BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd50BadHandler (UINT8 a_ucRespCode) {
    // Schedule Command 3 for dynamic variable scanning.
    // HDYNDVC is updated with NONE (variable code 250)
    m_ucDynScan[0] = HARTCOMMAND_THREE;
    m_ucDynScan[1] = 0;

    for (UINT8 ucCount = 0; ucCount < HART_MAXDYNVAR_COUNT; ucCount++) {
        HDynDvc[ucCount] = HART_INVALID_PARAMETER_CODE;
        m_ucDynScan[2 + ucCount] = 0;
    }
    SetHCmdFail(HARTCOMMAND_FIFTY,a_ucRespCode);
    return HREPLYSTATUS_CONTINUE; 
}
/*******************************************************************************
*                          clsHartDevDb::Cmd59GoodHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd59GoodHandler(VOID) {
    HT5_CfgChngCnt ++;
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd59BadHandler                       *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd59BadHandler(UINT8 a_ucRespCode) {
	 SetHCmdFail(HARTCOMMAND_FIFTYNINE, a_ucRespCode); return HREPLYSTATUS_CONTINUE; 
	 
}
/*******************************************************************************
*                          clsHartDevDb::Cmd109GoodHandler                     *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd109GoodHandler(VOID) {
    if (HARTCOMMAND_HUNDREDNINE == HCmdFail) {
        SetHCmdFail(HARTCOMMAND_INVALID,HART_RESPCODE_SUCCESS);
    }
    return HREPLYSTATUS_GOOD;
}
/*******************************************************************************
*                          clsHartDevDb::Cmd109BadHandler                      *
*******************************************************************************/
HREPLYSTATUS clsHartDevDb::Cmd109BadHandler (UINT8 a_ucRespCode) {
    SetHCmdFail(HARTCOMMAND_HUNDREDNINE,a_ucRespCode);
    return HREPLYSTATUS_BAD;
}


static FLOAT32 HartDb_ReadFloatBe(const UINT8 *bytes)
{
    union
    {
        UINT32 u32;
        FLOAT32 f32;
    } v;

    v.u32 = (((UINT32)bytes[0]) << 24) |
            (((UINT32)bytes[1]) << 16) |
            (((UINT32)bytes[2]) << 8)  |
            ((UINT32)bytes[3]);

    return v.f32;
}




static FLOAT32 HartDb_NaN(VOID)
{
    NANINIT nanValue;
    nanValue.ulDword = SIGNL_NAN;
    return nanValue.fVal;
}


static VOID HartDb_CopyPayload(UINT8 *dst, UINT32 dstLen, const HartParsedResponse_t *rsp)
{
    UINT32 count = 0u;

    if ((dst == NULL) || (dstLen == 0u))
    {
        return;
    }

    memset(dst, 0, dstLen);
    if (rsp == NULL)
    {
        return;
    }

    count = (rsp->payloadLen < dstLen) ? rsp->payloadLen : dstLen;
    for (UINT32 i = 0u; i < count; i++)
    {
        dst[i] = rsp->payload[i];
    }
}


VOID clsHartDevDb::SetScanCounterForRediscovery(UINT8 a_PointType)
{
   
    const UINT8 PNTTYPE_NOTCONFIGURED_LOCAL = 0u;

    if (a_PointType != PNTTYPE_NOTCONFIGURED_LOCAL)
    {
        if ((m_pHartCfgDb != NULL) && (m_pHartCfgDb->HEnable == TRUE))
        {
            m_sScanCounter = (INT16)(TICKS_IN_30_SEC + m_cucParent);
        }
        else
        {
            InitDevDb(TRUE);
        }
    }
    else
    {
        m_sScanCounter = TICKS_IN_60_SEC;
    }
}


VOID clsHartDevDb::LoadParsedResponse(const HartParsedResponse_t *a_pResponse)
{
    m_ChanRcvBuffer.Flush();
    memset(&m_LastParsedResponse, 0, sizeof(m_LastParsedResponse));

    if (a_pResponse == NULL)
    {
        return;
    }

    m_LastParsedResponse = *a_pResponse;
    m_ucLastReqCmd = a_pResponse->command;
    m_ucRcvMsgLen = a_pResponse->payloadLen;
    m_ucLastRespCode = a_pResponse->status0;
    m_ucDeviceStatus = a_pResponse->status1;

    m_ChanRcvBuffer = (UINT8)(a_pResponse->payloadLen + 2u);
    m_ChanRcvBuffer = a_pResponse->status0;
    m_ChanRcvBuffer = a_pResponse->status1;
    for (UINT8 i = 0u; i < a_pResponse->payloadLen; i++)
    {
        m_ChanRcvBuffer = a_pResponse->payload[i];
    }
}


VOID HartDb_Clear(VOID)
{
    memset(&g_hartDevice, 0, sizeof(g_hartDevice));
    g_HartDevDb.InitDevDb(TRUE);
}


BOOL HartDb_UpdateFromCmd0(UINT8 channel,
                           UINT8 modem,
                           UINT8 pollAddr,
                           const HartParsedResponse_t *cmd0,
                           const UINT8 longAddr[HART_LONGADDR_LENGTH],
                           UINT8 responsePreambles)
{
    if ((cmd0 == NULL) || !cmd0->valid || !cmd0->checksumOk || (cmd0->command != HARTCOMMAND_ZERO))
    {
        return FALSE;
    }

    if (cmd0->payloadLen < HART_CMD0_ID_RESPONSE_SIZE)
    {
        return FALSE;
    }

    memset(&g_hartDevice, 0, sizeof(g_hartDevice));
    g_hartDevice.valid = TRUE;
    g_hartDevice.channel = channel;
    g_hartDevice.modem = modem;
    g_hartDevice.pollAddr = pollAddr;
    g_hartDevice.responsePreambles = responsePreambles;

    for (UINT8 i = 0u; i < HART_LONGADDR_LENGTH; i++)
    {
        g_hartDevice.longAddr[i] = longAddr[i];
    }

    g_hartDevice.expandedDeviceType = cmd0->payload[0];
    g_hartDevice.manufacturer = cmd0->payload[1];
    g_hartDevice.deviceType = cmd0->payload[2];
    g_hartDevice.hartRevision = cmd0->payload[4];
    g_hartDevice.deviceRevision = cmd0->payload[5];
    g_hartDevice.softwareRevision = cmd0->payload[6];
    g_hartDevice.hardwareRevisionPhysical = cmd0->payload[7];
    g_hartDevice.flags = cmd0->payload[8];
    g_hartDevice.uniqueId[0] = cmd0->payload[9];
    g_hartDevice.uniqueId[1] = cmd0->payload[10];
    g_hartDevice.uniqueId[2] = cmd0->payload[11];
    g_hartDevice.cmd0Status0 = cmd0->status0;
    g_hartDevice.cmd0Status1 = cmd0->status1;

    clsHartDevDb *db = HartDb_GetChannelDevDb(channel);
    db->LoadParsedResponse(cmd0);
    (void)db->UpdateDatabase();
    if (db != &g_HartDevDb)
    {
        g_HartDevDb.LoadParsedResponse(cmd0);
        (void)g_HartDevDb.UpdateDatabase();
    }

    return TRUE;
}

VOID HartDb_UpdateCmd48Status(UINT8 status0, UINT8 status1)
{
    g_hartDevice.cmd48Status0 = status0;
    g_hartDevice.cmd48Status1 = status1;
}

VOID HartDb_UpdateCmd59Status(UINT8 status0, UINT8 status1)
{
    g_hartDevice.cmd59Status0 = status0;
    g_hartDevice.cmd59Status1 = status1;
}

BOOL HartDb_UpdateDynamicFromCmd3(const HartParsedResponse_t *cmd3)
{
    if ((cmd3 == NULL) || !cmd3->valid || !cmd3->checksumOk || (cmd3->command != HARTCOMMAND_THREE))
    {
        return FALSE;
    }

    clsHartDevDb *db = HartDb_GetChannelDevDb(HartGetActiveChannel());
    db->LoadParsedResponse(cmd3);
    if (db->UpdateDatabase() == HREPLYSTATUS_BAD)
    {
        g_hartDevice.dynamicValid = FALSE;
        g_hartDevice.dynamicCount = 0u;
        return FALSE;
    }
    if (db != &g_HartDevDb)
    {
        g_HartDevDb.LoadParsedResponse(cmd3);
        (void)g_HartDevDb.UpdateDatabase();
    }

    for (UINT8 i = 0u; i < HART_MAXDYNVAR_COUNT; i++)
    {
        g_hartDevice.dynamicUnit[i] = 0u;
        g_hartDevice.dynamicValue[i] = HartDb_NaN();
    }
    g_hartDevice.dynamicCount = 0u;

    if ((cmd3->status0 != HART_RESPCODE_SUCCESS) ||
        (cmd3->status1 != 0u) ||
        (cmd3->payloadLen < HART_CMD3_1VAR_RESPONSE_SIZE))
    {
        g_hartDevice.dynamicValid = FALSE;
        return FALSE;
    }

    g_hartDevice.loopCurrentMa = HartDb_ReadFloatBe(&cmd3->payload[0]);

    for (UINT8 i = 0u; i < HART_MAXDYNVAR_COUNT; i++)
    {
        if (db->HDynSt[i] == HART_DATA_AVAILABLE)
        {
            g_hartDevice.dynamicUnit[i] = db->HDynEu[i];
            g_hartDevice.dynamicValue[i] = db->HDynVal[i];
            g_hartDevice.dynamicCount = (UINT8)(i + 1u);
        }
    }

    g_hartDevice.dynamicValid = (g_hartDevice.dynamicCount > 0u) ? TRUE : FALSE;
    return g_hartDevice.dynamicValid;
}

BOOL HartDb_HasDevice(VOID)
{
    return g_hartDevice.valid;
}

const HartDeviceInfo_t *HartDb_GetDevice(VOID)
{
    return &g_hartDevice;
}


clsHartDevDb *HartDb_GetHartDevDb(VOID)
{
    return HartDb_GetChannelDevDb(HartGetActiveChannel());
}


HREPLYSTATUS HartDb_HandleResponse(const HartParsedResponse_t *response)
{
    if (response == NULL)
    {
        return HREPLYSTATUS_BAD;
    }

    g_HartDevDb.LoadParsedResponse(response);
    return g_HartDevDb.UpdateDatabase();
}

BOOL HartDb_GetPrimaryVariable(FLOAT32 *pvOut, UINT8 *unitOut)
{
    if ((g_hartDevice.dynamicValid == FALSE) && (g_HartDevDb.HDynSt[0] != HART_DATA_AVAILABLE))
    {
        return FALSE;
    }

    if (pvOut != NULL)
    {
        *pvOut = g_HartDevDb.HDynVal[0];
    }

    if (unitOut != NULL)
    {
        *unitOut = g_HartDevDb.HDynEu[0];
    }

    return TRUE;
}

