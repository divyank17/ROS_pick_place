/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_fpga_spi.c                                             *
*    Description : FPGA register access via LPSPI2 for iMXRT1024.             *
*                                                                              *
*    Implements the hal_fpga API using the RT1024's LPSPI2 peripheral.         *
*    The Lattice MACHXO3LF FPGA operates as SPI slave.                        *
*                                                                              *
*    SPI Configuration (per HDD Table 51/52):                                  *
*      - Peripheral: LPSPI2                                                    *
*      - Clock:      10 MHz (max per FPGA spec)                                *
*      - Mode:       CPOL=0, CPHA=0 (SPI Mode 0)                              *
*      - Frame:      8-bit, MSB first                                          *
*      - CS:         PCS0 (hardware-managed chip select)                       *
*                                                                              *
*    This file is compiled ONLY for RT1024_BUILD.                              *
*******************************************************************************/
#include "hal_platform.h"

#include "hal_platform.h"

#if defined(RT1024_BUILD) && defined(HAL_FPGA_SPI_ENABLED)

#include "hal_fpga.h"
#include "fsl_lpspi.h"
#include "fsl_clock.h"
#include "hal_timer.h"      /* HAL_IRQ_PRIO_DBG_UART */

/*******************************************************************************
*                          LPSPI2 PIN CONFIGURATION                            *
*                                                                              *
*  From HDD Table 51 — Pin Mapping for LPSPI2:                                *
*    LPSPI2_SCK    — GPIO_SD_B1_07 (pad L3)                                   *
*    LPSPI2_PCS0   — GPIO_SD_B1_06 (pad K1)   Chip Select for FPGA            *
*    LPSPI2_SDO    — GPIO_SD_B1_08 (pad M3)   MOSI → FPGA SPI_DIN            *
*    LPSPI2_SDI    — GPIO_SD_B1_09 (pad M4)   MISO ← FPGA SPI_DOUT           *
*******************************************************************************/

/* LPSPI2 peripheral base pointer (from NXP SDK) */
#define FPGA_SPI_BASE       LPSPI2
#define FPGA_SPI_CLOCK_FREQ CLOCK_GetFreq(kCLOCK_Usb1PllPfd0Clk)
#define FPGA_SPI_BAUDRATE   10000000u   /* 10 MHz */
#define FPGA_SPI_PCS        kLPSPI_Pcs0

/* SPI command byte: bit 7 = R/~W, bits 6:0 = address */
#define SPI_CMD_READ(addr)  (UINT8)(0x80 | ((addr) & 0x7F))
#define SPI_CMD_WRITE(addr) (UINT8)(0x00 | ((addr) & 0x7F))

/*******************************************************************************
*                  Non-blocking IOTA status read state machine                *
*  See hal_fpga_start_iota_read() etc. in hal_fpga.h for rationale: lets a
*  low-priority periodic caller (CheckFtaPresence()) kick off a read and
*  check back later instead of blocking/spinning on the transfer.
*******************************************************************************/
static lpspi_master_handle_t s_fpgaSpiHandle;
static UINT8  s_iotaTxBuf[3];
static UINT8  s_iotaRxBuf[3];
static volatile BOOL s_iotaReadPending = FALSE;
static volatile BOOL s_iotaReadDone    = FALSE;

static void FpgaSpi_MasterCallback(LPSPI_Type *base, lpspi_master_handle_t *handle,
                                   status_t status, void *userData)
{
    (void)base;
    (void)handle;
    (void)userData;
    if (status == kStatus_Success) {
        s_iotaReadDone = TRUE;
    } else {
        /* Transfer failed/timed out at the driver level — drop it so the
         * next hal_fpga_start_iota_read() can retry from a clean state. */
        s_iotaReadPending = FALSE;
    }
}

void LPSPI2_IRQHandler(void)
{
    LPSPI_MasterTransferHandleIRQ(FPGA_SPI_BASE, &s_fpgaSpiHandle);
}

void hal_fpga_start_iota_read(void)
{
    if (s_iotaReadPending) {
        return;   /* already in flight */
    }

    s_iotaTxBuf[0] = SPI_CMD_READ(FPGA_IOLIOTASR);
    s_iotaTxBuf[1] = 0x00;
    s_iotaTxBuf[2] = 0x00;

    lpspi_transfer_t xfer;
    xfer.txData      = s_iotaTxBuf;
    xfer.rxData      = s_iotaRxBuf;
    xfer.dataSize    = 3;
    xfer.configFlags = FPGA_SPI_PCS | kLPSPI_MasterPcsContinuous;

    s_iotaReadDone    = FALSE;
    s_iotaReadPending = TRUE;

    if (LPSPI_MasterTransferNonBlocking(FPGA_SPI_BASE, &s_fpgaSpiHandle, &xfer) != kStatus_Success) {
        /* Bus busy with something else right now — try again next call. */
        s_iotaReadPending = FALSE;
    }
}

BOOL hal_fpga_iota_read_pending(void)
{
    return s_iotaReadPending;
}

BOOL hal_fpga_iota_read_ready(void)
{
    return s_iotaReadDone;
}

UINT8 hal_fpga_get_iota_result(void)
{
    UINT8 result = s_iotaRxBuf[1];   /* matches hal_fpga_read()'s (rxBuf[1]<<8)|rxBuf[2] >> 8 convention */
    s_iotaReadPending = FALSE;
    s_iotaReadDone    = FALSE;
    return result;
}

/*******************************************************************************
*                          hal_fpga_init                                       *
*******************************************************************************/
void hal_fpga_init(void)
{
    lpspi_master_config_t config;

    LPSPI_MasterGetDefaultConfig(&config);
    config.baudRate     = FPGA_SPI_BAUDRATE;
    config.cpol         = kLPSPI_ClockPolarityActiveHigh;   /* CPOL=0 */
    config.cpha         = kLPSPI_ClockPhaseFirstEdge;       /* CPHA=0 */
    config.direction    = kLPSPI_MsbFirst;
    config.pcsToSckDelayInNanoSec    = 100;
    config.lastSckToPcsDelayInNanoSec = 100;
    config.betweenTransferDelayInNanoSec = 200;  /* Clock stretch gap */
    config.whichPcs     = FPGA_SPI_PCS;
    config.pcsActiveHighOrLow = kLPSPI_PcsActiveLow;

    LPSPI_MasterInit(FPGA_SPI_BASE, &config, FPGA_SPI_CLOCK_FREQ);

    /* Handle + IRQ for the non-blocking IOTA status read path (see above). */
    LPSPI_MasterTransferCreateHandle(FPGA_SPI_BASE, &s_fpgaSpiHandle, FpgaSpi_MasterCallback, NULL);
    NVIC_SetPriority(LPSPI2_IRQn, HAL_IRQ_PRIO_DBG_UART);
    EnableIRQ(LPSPI2_IRQn);
}

/*******************************************************************************
*                          hal_fpga_read                                       *
*  SPI Read Transaction (3 bytes):                                             *
*    TX: [1_ADDR6..0] [0x00] [0x00]                                           *
*    RX: [ignored]    [D15:8] [D7:0]                                           *
*******************************************************************************/
UINT16 hal_fpga_read(UINT8 addr)
{
    UINT8 txBuf[3];
    UINT8 rxBuf[3];

    txBuf[0] = SPI_CMD_READ(addr);
    txBuf[1] = 0x00;
    txBuf[2] = 0x00;

    lpspi_transfer_t xfer;
    xfer.txData   = txBuf;
    xfer.rxData   = rxBuf;
    xfer.dataSize = 3;
    xfer.configFlags = FPGA_SPI_PCS | kLPSPI_MasterPcsContinuous;

    LPSPI_MasterTransferBlocking(FPGA_SPI_BASE, &xfer);

    /* Response in bytes 1-2: MSB first */
    return (UINT16)((UINT16)rxBuf[1] << 8) | (UINT16)rxBuf[2];
}

/*******************************************************************************
*                          hal_fpga_write                                      *
*  SPI Write Transaction (3 bytes):                                            *
*    TX: [0_ADDR6..0] [D15:8] [D7:0]                                          *
*    RX: [don't care]                                                          *
*******************************************************************************/
void hal_fpga_write(UINT8 addr, UINT16 data)
{
    UINT8 txBuf[3];

    txBuf[0] = SPI_CMD_WRITE(addr);
    txBuf[1] = (UINT8)(data >> 8);     /* MSB */
    txBuf[2] = (UINT8)(data & 0xFF);   /* LSB */

    lpspi_transfer_t xfer;
    xfer.txData   = txBuf;
    xfer.rxData   = NULL;
    xfer.dataSize = 3;
    xfer.configFlags = FPGA_SPI_PCS | kLPSPI_MasterPcsContinuous;

    LPSPI_MasterTransferBlocking(FPGA_SPI_BASE, &xfer);
}

#endif /* RT1024_BUILD */
