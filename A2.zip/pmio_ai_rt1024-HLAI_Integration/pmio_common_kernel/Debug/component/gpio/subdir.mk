################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../component/gpio/fsl_adapter_gpio.c 

C_DEPS += \
./component/gpio/fsl_adapter_gpio.d 

OBJS += \
./component/gpio/fsl_adapter_gpio.o 


# Each subdirectory must supply rules for building sources it contributes
component/gpio/%.o: ../component/gpio/%.c component/gpio/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\board" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\source\hal" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\source" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\drivers" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\utilities\debug_console_lite" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\utilities\str" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\device" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\component\uart" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\component\gpio" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\utilities" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\CMSIS" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\CMSIS\m-profile" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\xip" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-component-2f-gpio

clean-component-2f-gpio:
	-$(RM) ./component/gpio/fsl_adapter_gpio.d ./component/gpio/fsl_adapter_gpio.o

.PHONY: clean-component-2f-gpio

