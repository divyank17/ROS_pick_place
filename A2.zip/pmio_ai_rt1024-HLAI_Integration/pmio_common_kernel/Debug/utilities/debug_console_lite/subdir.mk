################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../utilities/debug_console_lite/fsl_debug_console.c 

C_DEPS += \
./utilities/debug_console_lite/fsl_debug_console.d 

OBJS += \
./utilities/debug_console_lite/fsl_debug_console.o 


# Each subdirectory must supply rules for building sources it contributes
utilities/debug_console_lite/%.o: ../utilities/debug_console_lite/%.c utilities/debug_console_lite/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\board" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\source\hal" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\source" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\drivers" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\utilities\debug_console_lite" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\utilities\str" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\device" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\component\uart" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\component\gpio" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\utilities" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\CMSIS" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\CMSIS\m-profile" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\xip" -I"C:\Users\E829166\Documents\MCUXpressoIDE_25.6.136\workspace\pmio_common_kernel\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-utilities-2f-debug_console_lite

clean-utilities-2f-debug_console_lite:
	-$(RM) ./utilities/debug_console_lite/fsl_debug_console.d ./utilities/debug_console_lite/fsl_debug_console.o

.PHONY: clean-utilities-2f-debug_console_lite

