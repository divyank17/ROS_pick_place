/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohmain.h                                                   *
*    Description : Master include for AOH module — RT1024/QEMU.               *
*                  Replaces the epicio_src/aohmain.h which included            *
*                  everything + H8S hardware definitions.                      *
*******************************************************************************/

#ifndef __AOHMAIN_H__
#define __AOHMAIN_H__

/*******************************************************************************
*                           HAL + PLATFORM                                     *
*******************************************************************************/
#include "fsl_debug_console.h"
#include "hal/hal.h"
/*******************************************************************************
*                           CORE TYPES                                         *
*******************************************************************************/
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "softfail.h"
//#include "dac.hpp"
#include "aohardware.hpp"
#include "eeprom.hpp"
#include "fpga.hpp"
/*******************************************************************************
*                           SCHEDULER                                          *
*******************************************************************************/
#include "scheduler.hpp"

/*******************************************************************************
*                           TRACELOG / ECL                                      *
*******************************************************************************/
//#include "tracelog.hpp"
#include "ecl.hpp"

/*******************************************************************************
*                           HART PASSTHROUGH TYPES                             *
*******************************************************************************/
//#include "hartpst.hpp"

/*******************************************************************************
*                           IOL COMMUNICATION                                  *
*******************************************************************************/
#include "iol.hpp"
#include "wrmsgque.hpp"

/*******************************************************************************
*                           DATABASE CLASSES                                   *
*******************************************************************************/
#include "iomslot.hpp"
#include "boxslot.hpp"
#include "aohslot.hpp"
#include "aohboxslot.hpp"
#include "aohversion.h"

/*******************************************************************************
*                           DIAGNOSTICS / DEBUG                                *
*******************************************************************************/
#include "diag.h"
#include "hardfail.h"
#include "debug.hpp"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsAoHardware AoHardware;

#endif /* __AOHMAIN_H__ */
