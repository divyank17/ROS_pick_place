/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohversion.h                                                *
*    Description : RT1024 / QEMU hardware abstraction.                         *
*                  Replaces the H8S register definitions with HAL calls.       *
*                  This file is included by legacy code that expects it.       *
*******************************************************************************/
#ifndef __AOHVERSION_H__
#define __AOHVERSION_H__
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/

// starting version with 1 is not working with c300, seems like there is a minimum version required.
const UINT8 VERSION_NUMBER  = 44;
const UINT8 REVISION_NUMBER = 2;
const UINT8 BUILD_NUMBER    = 4;

#endif /* __AOHVERSION_H__ */
