/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohardware.hpp                                              *
*    Description : Analog output hardware encapsulation.                       *
*******************************************************************************/
#ifndef __AOHARDWARE_HPP__
#define __AOHARDWARE_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
#include "hal_fpga.h"
#include "fsl_gpio.h"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/

/*******************************************************************************
*                          LPSPI4 (DAC SPI) CONFIGURATION                      *
*                                                                              *
*  Pin mapping (from pin_mux.c):                                               *
*    LPSPI4_SCK   — GPIO_EMC_32  (pad 124)                                     *
*    LPSPI4_PCS0  — GPIO_EMC_33  (pad 123)   chip-select to DAC                *
*    LPSPI4_SDO   — GPIO_EMC_34  (pad 122)   MOSI                              *
*    LPSPI4_SDI   — GPIO_EMC_35  (pad 121)   MISO                              *
*                                                                              *
*  SPI Configuration:                                                          *
*    Mode:    CPOL=0, CPHA=0 (SPI Mode 0), 8-bit frames, MSB first             *
*    Clock:   4 MHz                                                            *
*    CS:      PCS0, active-low                                                 *
*******************************************************************************/
#define DAC_SPI_BASE        LPSPI4
/* LPSPI functional clock root actually feeding LPSPI4 (see board/clock_config.c:
 * CLOCK_SetMux(kCLOCK_LpspiMux, 2) -> SysPllClk, CLOCK_SetDiv(kCLOCK_LpspiDiv, 4)
 * -> divide by 5), NOT the USB1 PLL PFD0 clock. Using the wrong source here
 * causes LPSPI_MasterInit() to mis-calculate the baud-rate/delay dividers. */
#define DAC_SPI_CLOCK_FREQ  CLOCK_GetClockRootFreq(kCLOCK_LpspiClkRoot)
#define DAC_SPI_BAUDRATE    4000000u   /* 4 MHz */
#define DAC_SPI_PCS         kLPSPI_Pcs0

const UINT8   DAC_RESOLUTION                = 12;    // 12 bit DAC
const UINT16  DAC_SETTLE_TIME               = 50;    // In units of micro sec.

const UINT16  MAXCURRENT_OUTPUT_DACCOUNT    = 0xFFF; // 25 mA
const UINT16  MINCURRENT_OUTPUT_DACCOUNT    = 0x080; // 0 mA
const UINT16  TWENTY_MA_H_OUTPUT_DACCOUNT   = 0xD1A;
const UINT16  TWENTY_MA_L_OUTPUT_DACCOUNT   = 0xCB4;
const UINT16  FOUR_MA_H_OUTPUT_DACCOUNT     = 0x32E;
const UINT16  FOUR_MA_L_OUTPUT_DACCOUNT     = 0x2C8;
const UINT16  MAX_FIVE_V_OUTPUT_DACCOUNT    = 0xCC6;
const UINT16  MIN_FIVE_V_OUTPUT_DACCOUNT    = 0xB97;
const UINT16  MAX_ONE_V_OUTPUT_DACCOUNT     = 0x33F;
const UINT16  MIN_ONE_V_OUTPUT_DACCOUNT     = 0x275;
const UINT16  MAX_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x82D;
const UINT16  MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x738;

const UINT16  FACCAL_OUTPUT_DACCOUNT        = 0x8F7;
const UINT16  MINHIZERO_LOOPBACK_DACCOUNT   = 0x070; // TBD
const UINT16  MAXHIZERO_LOOPBACK_DACCOUNT   = 0x090; // TBD 
const UINT16  MINCURRENT_LOOPBACK_DACCOUNT  = 0x0ED;
const UINT16  MAXCURRENT_LOOPBACK_DACCOUNT  = 0xF08;

const UINT16  MAXIMUM_CURRENT_SWING         = 25; // In units of mA.

const UINT16  OUTPUT_DACCOUNT_PER_MILLIAMP  = (MAXCURRENT_OUTPUT_DACCOUNT - MINCURRENT_OUTPUT_DACCOUNT)
                                              / MAXIMUM_CURRENT_SWING;
const UINT16  FOUR_PRECENT_LOOPBACK_DACCOUNT= (MAXCURRENT_LOOPBACK_DACCOUNT - MINCURRENT_LOOPBACK_DACCOUNT) * 4 / 100;

const UINT8  MUX_ENABLE                     = 0x80;
const UINT8  OUTPUT_ADDRESS_READBACK_MASK   = 0x8F;

const UINT8  LOOPBACK_ADDRESS_READBACK_MASK = 0x9F;

const UINT8  MUX_READBACK_RETRYCOUNT        = 4;
const UINT8  MUX_CHANNELSEL_SETTLE_TIME     = 1;

const UINT16 DEFAULT_OUTPUT_CAPACITORCHARGE_TIME       = 300;          //300 us
const UINT16 CALIBRATION_EXTENDED_CAPACITORCHARGE_TIME = 10000;        //10  ms
const UINT16 CALIBRATION_MINIMUM_CAPACITORCHARGE_TIME  = 150;          //150 us
const UINT16 LOOPBACK_COMPARATORSETTLE_TIME            = 150;          //150 us

const UINT8 SNSCAL1 = 0x00;
const UINT8 SNSV1   = 0x01;
const UINT8 SNSV2   = 0x02;
const UINT8 SNSV3   = 0x03;
const UINT8 SNSV4   = 0x04;
const UINT8 HIZERO1 = 0x05;
const UINT8 SNSV5   = 0x06;
const UINT8 SNSV6   = 0x07;

const UINT8 FACCAL  = 0x08;
const UINT8 SNSV7   = 0x09;
const UINT8 CALCHK  = 0x0A;
const UINT8 HIZERO2 = 0x0B;
const UINT8 SNSCAL2 = 0x0C;
const UINT8 SNSV8   = 0x0D;
const UINT8 SNSV9   = 0x0E;
const UINT8 SNSV10  = 0x0F;

const UINT8 SNSV11  = 0x10;
const UINT8 SNSV12  = 0x11;
const UINT8 SNSCAL3 = 0x12;
const UINT8 SNSV13  = 0x13;
const UINT8 SNSV14  = 0x14;
const UINT8 SNSV15  = 0x15;
const UINT8 SNSV16  = 0x16;
const UINT8 HIZERO3 = 0x17;

const UINT8 LOOPBACK_ADDRESS[] = {
    SNSV1,  //Address:: 0x01 - 1
    SNSV2,  //Address:: 0x02 - 2
    SNSV3,  //Address:: 0x03 - 3
    SNSV4,  //Address:: 0x04 - 4
    SNSV5,  //Address:: 0x06 - 5
    SNSV6,  //Address:: 0x07 - 6
    SNSV7,  //Address:: 0x09 - 7
    SNSV8,  //Address:: 0x0D - 8
    SNSV9,  //Address:: 0x0E - 9
    SNSV10, //Address:: 0x0F - 10
    SNSV11, //Address:: 0x10 - 11
    SNSV12, //Address:: 0x11 - 12
    SNSV13, //Address:: 0x13 - 13
    SNSV14, //Address:: 0x14 - 14
    SNSV15, //Address:: 0x15 - 15
    SNSV16, //Address:: 0x16 - 16
    HIZERO1,//Address:: 0x05 - 17
    HIZERO2,//Address:: 0x0B - 18
    HIZERO3,//Address:: 0x17 - 19
    SNSCAL1,//Address:: 0x00 - 20
    SNSCAL2,//Address:: 0x0C - 21
    SNSCAL3,//Address:: 0x12 - 22
    CALCHK, //Address:: 0x0A - 23
    FACCAL  //Address:: 0x08 - 24
};

//Array Index positions in the LOOPBACK_ADDRESS array
const UINT8 HIZERO1_OFFSET = 17;
const UINT8 HIZERO2_OFFSET = 18;
const UINT8 HIZERO3_OFFSET = 19;
const UINT8 SNSCAL1_OFFSET = 20;
const UINT8 SNSCAL2_OFFSET = 21;
const UINT8 SNSCAL3_OFFSET = 22;
const UINT8 CALCHK_OFFSET  = 23;
const UINT8 FACCAL_OFFSET  = 24;

//Redundancy Related Constant Declarations
// Status of switches with Test switch in Normal state 

const UINT8 INH_ON_ON   = 0x00; //a and b on
const UINT8 INH_ON_OFF  = 0x04; //b sws on
const UINT8 INH_OFF_ON  = 0x1C; //a sws on
const UINT8 INH_OFF_OFF = 0x0C; //a and b off 

const UINT8 INH_OFF_ON_TST_ON   = 0x1C; //a sws on
const UINT8 INH_OFF_OFF_TST_ON  = 0x0C; //a sws on

const UINT8 DIS_ON_ON   = 0xE0;
const UINT8 DIS_OFF_ON  = 0x60;

const UINT8 DIS_ON_OFF  = 0x80; // a sws on 
const UINT8 DIS_OFF_OFF = 0x00; // a and b off

const UINT8 TST_ON        = 0x02;
const UINT8 TST_OFF       = 0x00;
const UINT8 TST_DISABLED  = 0x02; 
const UINT8 TST_ENABLED   = 0x00;
const UINT8 TSTn_DISABLED = 0;
const UINT8 TSTn_ENABLED  = 1;

const UINT16 READ_DELAY_TIME = 250;     //250us Read delay 
const UINT16 TST_READ_DELAY_TIME = 20;  //20us Read delay
const UINT16 DIS_READ_DELAY_TIME = 20; 
const UINT16 INH_READ_DELAY_TIME = 300; 

//Constants that can be moved to outslot    
const UINT8 SW_ON       = 0x1;
const UINT8 SW_OFF      = 0x0;

//wait time for primary to change role on a commanded swap
const UINT16 SWAP_RESPNSE_TIME_DELAY = 300;


const UINT8 DIS_SWA_SET  = 0x80;
const UINT8 DIS_SWB1_SET = 0x40;
const UINT8 DIS_SWB2_SET = 0x20;

const UINT8 TST_SET      = 0x02;

const UINT8 INH_SWA_SET    = 0x10;
const UINT8 INH_SWB1_SET   = 0x08;
const UINT8 INH_SWB2_SET   = 0x04;

/*******************************************************************************
*                             TYPES & ENUMERATIONS                             *
*******************************************************************************/

typedef union tagDacByte {
    UINT8 ucByte[2];
    struct {
        UINT16 Commmand : 3;
        UINT16 Count    : 12;
        UINT16 SubBit   : 1;
    } DAC;
} DACBYTE;

//DAC Commands 
typedef enum DAC_CMDS{
    NO_OPERATION                      = 0x0,
    LD_INPUT_REG                      = 0x1,
    LD_INPUT_AND_DAC_REG              = 0x2,
    UPDATE_DAC_REG_FROM_INPUT_REG     = 0x3,
    SHUTDOWN_DAC                      = 0x4,
    UPO_LOW                           = 0x5,
    UPO_HIGH                          = 0x6,
    MODE1                             = 0x7,
    MODE0                             = 0x7
}DAC_CMDS;

typedef enum DELAY_TYPE {
    NormalOutput                 = 0,
    CalibrationWithExtendedDelay = 1,
    CalibrationWithMinimumDelay  = 2
}DELAY_TYPE;

typedef enum SWITCH_TYPE{
    DIS_SWCH              = 0x0,
    TST_SWCH              = 0x1,
    INH_SWCH              = 0x2
}SWITCH_TYPE;

/*******************************************************************************
*                                 clsAoHardware                                *
*                                 =============                                *
*******************************************************************************/

class clsAoHardware
{
    DACBYTE DacByte;

    clsAoHardware(const clsAoHardware&); // Safeguard against default copy constructor.
    clsAoHardware& operator=(const clsAoHardware&); // Sefeguard against default assignment.

public:
    clsAoHardware(VOID);
    ~clsAoHardware(VOID) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__); }

    VOID Init(VOID); // Configure LPSPI4 for the DAC; call after clocks are initialised.

    VOID *operator new(size_t) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__);  return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__); }

    VOID DriveDac(UINT16);
    VOID DriveOutput(UINT8 a_ucSlotNum, 
                     DELAY_TYPE a_eDelayType = NormalOutput);
    BOOL ReadComparatorOutput(VOID);
    BOOL OpenLoopbackMux(UINT8,BOOL);

    inline VOID CloseLoopbackMux(UINT8 a_ucChanNum) {
        hal_fpga_write(FPGA_INPSEL, a_ucChanNum & (~MUX_ENABLE));
    }

    BOOL   TestSwitchDiagnostics(UINT8);
    BOOL   InhibitSwitchDiagnostics(UINT8);
    BOOL   DisableSwitchDiagnostics(UINT8);  
    
    UINT8  GetSwitchStatus(SWITCH_TYPE);  
    VOID   VerifySwitchState(SWITCH_TYPE,UINT8); 
};

#endif //__AOHARDWARE_HPP__
