/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : boxslot.hpp                                                 *
*    Description : Class clsBoxSlot for RT1024/QEMU — AOH-only.                *
*                  Box-level database, module status, redundancy, ECL,         *
*                  soft-fail management, IOLink addressing.                    *
*******************************************************************************/
#ifndef __BOXSLOT_HPP__
#define __BOXSLOT_HPP__

#include "commonelectronics.h"
#include "global.h"
#include "iomslot.hpp"
#include "softfail.h"
#include "hardfail.h"
#include "ecl.hpp"

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagIOLDevType {
    IOLDEVTYPE_SLAVE   = 0,
    IOLDEVTYPE_MASTER1 = 1,
    IOLDEVTYPE_MASTER2 = 2,
    IOLDEVTYPE_MASTER3 = 3
} IOLDEVTYPE;

typedef union tagRevCode {
    UINT8 ucByte;
    struct {
        UINT8 ucRevision : 4;
        UINT8 ucVersion  : 4;
    };
} REVCODE;

#pragma pack(push, 1)

typedef struct tagHwInfo {
    UINT32 SerialNumber;
    UINT16 VendorID;
    UINT16 ProductType;
    UINT16 ProductCode;
    UINT8  HwRevLetter;
    UINT8  HwRevNumber;
    UINT8  Pld1RevLetter;
    UINT8  Pld1RevNumber;
    UINT8  Pld2RevLetter;
    UINT8  Pld2RevNumber;
} HWINFO;

typedef union tagMODSTAT1 {
#ifdef BIG_ENDIAN
    struct {
        UINT8 BuSyncd  : 1;
        UINT8 Unused   : 4;
        UINT8 Factory  : 1;
        UINT8 Status   : 2;
    };
#else
    struct {
        UINT8 Status   : 2;
        UINT8 Factory  : 1;
        UINT8 Unused   : 4;
        UINT8 BuSyncd  : 1;
    };
#endif
    UINT8 BYTE;
} MODSTAT1;

#ifdef BIG_ENDIAN
typedef union tagMODSTAT2 {
    struct {
        UINT8 DbNotDeflt:1;
        UINT8 BuReqIn   :1;
        UINT8 StndbyMan :1;
        UINT8 FtaPres   :1;
        UINT8 HF        :1;
        UINT8 SF        :1;
        UINT8 CommErr   :1;
        UINT8 IotaPos   :1;
    };
    UINT8 BYTE;
}MODSTAT2;
#else
typedef union tagMODSTAT2 {
    struct {
        UINT8 IotaPos    : 1;
        UINT8 CommErr    : 1;
        UINT8 SF         : 1;
        UINT8 HF         : 1;
        UINT8 FtaPres    : 1;
        UINT8 StndbyMan  : 1;
        UINT8 BuReqIn    : 1;
        UINT8 DbNotDeflt : 1;
    };
    UINT8 BYTE;
} MODSTAT2;
#endif

typedef union tagMODSTAT3 {
    struct {
        UINT8 Unused   : 6;
        UINT8 PairInSF : 1;
        UINT8 OutCtl   : 1;
    };
    UINT8 BYTE;
} MODSTAT3;

typedef struct tagCOMMSTAT {
    UINT8 Unused : 3;
    UINT8 LEA    : 1;
    UINT8 LEB    : 1;
    UINT8 LSA    : 1;
    UINT8 LSB    : 1;
    UINT8 PRC    : 1;
} COMMSTAT;

typedef struct tagTRACELOGDATA {
    UINT32 TracelogTime;
    UINT8  LatestIndex;
} TRACELOGDATA;

typedef struct tagREDDATA {
    UINT8 Unused     : 3;
    UINT8 WiggleSF   : 1;
    UINT8 WiggleStat : 1;
    UINT8 SFFOEnable : 1;
    UINT8 RedConfig  : 1;
    UINT8 BURequest  : 1;
    UINT8 RedState;
} REDDATA;

typedef struct tagBrdpStsTable {
    UINT8  Handle;
    UINT8  SlotNum;
    UINT8  MsgStatus;
    UINT8  Timeout;
} BRDPSTSTABLE;

typedef struct tagHndlStsTable {
    UINT8  Handle;
    UINT8  Timeout;
} HNDLSTSTABLE;

#pragma pack(pop)

#ifdef __cplusplus
static_assert(sizeof(HWINFO) == 16, "HWINFO size mismatch");
static_assert(sizeof(REVCODE) == 1, "REVCODE size mismatch");
static_assert(sizeof(MODSTAT1) == 1, "MODSTAT1 size mismatch");
static_assert(sizeof(MODSTAT2) == 1, "MODSTAT2 size mismatch");
static_assert(sizeof(MODSTAT3) == 1, "MODSTAT3 size mismatch");
static_assert(sizeof(COMMSTAT) == 1, "COMMSTAT size mismatch");
static_assert(sizeof(TRACELOGDATA) == 5, "TRACELOGDATA size mismatch");
#endif

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8 MODSTATUS_ALIVE = 0;
const UINT8 MODSTATUS_IDLE  = 1;
const UINT8 MODSTATUS_RUN   = 2;
const UINT8 MODSTATUS_FAIL  = 3;
const UINT8 MODSTATUS_MASK  = 0x03;

const UINT8 MODSTATUS_IDLE_LRSBIT = 0x01;
const UINT8 MODSTATUS_RUN_LRSBIT  = 0x02;

const UINT8 MODSTATUS_NO_TRANS   = 0;
const UINT8 MODSTATUS_IDLE_IDLE  = 1;
const UINT8 MODSTATUS_IDLE_RUN   = 2;
const UINT8 MODSTATUS_RUN_IDLE   = 3;
const UINT8 MODSTATUS_RUN_RUN    = 4;

const UINT8 BUREQ_ASSERTED  = 0;
const UINT8 BUREQ_NEGATED   = 1;
const UINT8 BURFB_ASSERTED  = 1;
const UINT8 BURFB_NEGATED   = 0;
const UINT8 BURIN_ASSERTED  = 1;
const UINT8 BURIN_NEGATED   = 0;

const UINT8 PAIR_IN_SF      = 1;
const UINT8 PAIR_NO_SF      = 0;

const UINT8 OUTCTL_MINE     = 1;
const UINT8 OUTCTL_PARTNER  = 0;
const UINT8 INHIN_ASSERTED  = 0;
const UINT8 INHIN_NEGATED   = 1;

/* Redundancy data bits */
const UINT8 RDBIT_SET = 0x80;
const UINT8 RDBIT_CLR = 0x00;

const UINT8 REDDATA_SIZE = 2;
const UINT8 REDDATA_BITS = 0x1F;

#ifdef __cplusplus
static_assert(sizeof(REDDATA) == REDDATA_SIZE, "REDDATA size mismatch");
#endif

const UINT8 REDDATA_BURQST = 1;
const UINT8 REDDATA_REDCFG = 2;
const UINT8 REDDATA_SFFOEN = 4;
const UINT8 REDDATA_WIGGLE = 8;
const UINT8 REDDATA_WIGLSF = 16;

const UINT8 REDDATA_BURQST_BITNUM = 1;
const UINT8 REDDATA_REDCFG_BITNUM = 2;
const UINT8 REDDATA_SFFOEN_BITNUM = 3;
const UINT8 REDDATA_WIGGLE_BITNUM = 4;
const UINT8 REDDATA_WIGLSF_BITNUM = 5;
const UINT8 REDDATA_RSRVD6_BITNUM = 6;
const UINT8 REDDATA_RSRVD7_BITNUM = 7;
const UINT8 REDDATA_RSRVD8_BITNUM = 8;

const UINT8 REDSTATE_NULL                = 0;
const UINT8 REDSTATE_NOT_SYNCD           = 1;
const UINT8 REDSTATE_DUMP_FAILED         = 2;
const UINT8 REDSTATE_FREEZE_NOT_ACCEPTED = 3;
const UINT8 REDSTATE_SYNC_FAILED         = 4;
const UINT8 REDSTATE_SPARE05             = 5;
const UINT8 REDSTATE_IOL_TIMEOUT         = 0x10;
const UINT8 REDSTATE_SYNCD               = 0x80;
const UINT8 REDSTATE_DUMP_COMPLETE       = 0x81;
const UINT8 REDSTATE_FREEZE_PERMITTED    = 0x82;
const UINT8 REDSTATE_FREEZE_ACCEPTED     = 0x83;
const UINT8 REDSTATE_FO_IN_PROG          = 0x84;
const UINT8 REDSTATE_FO_COMPLETE         = 0x85;
const UINT8 REDSTATE_SWAP_IN_PROG        = 0x86;
const UINT8 REDSTATE_SWAP_COMPLETE       = 0x87;
const UINT8 REDSTATE_FROZEN              = 0xA0;
const UINT8 REDSTATE_DUMP_START          = 0xA1;
const UINT8 REDSTATE_MAX                 = 0xCE;

const UINT8 SYNCVER_SIZE        =   4;
#if !defined(IOPTYPE_SCIOM)
// for redesign PMIO redundant Sync Versions
const UINT8 AI_SYNC_VERSION     =   2;
const UINT8 AO_SYNC_VERSION     =   2;
#else
const UINT8 AI_SYNC_VERSION     =   1;
const UINT8 AO_SYNC_VERSION     =   1;
#endif
const UINT8 DI_SYNC_VERSION     =   1;
const UINT8 DO_SYNC_VERSION     =   2;
const UINT8 DISOE_SYNC_VERSION  =   1;
const UINT8 LL_SYNC_VERSION     =   1;

const UINT8 PI_SYNC_VERSION     =   1;
const UINT8 UIO_SYNC_VERSION    =   1;

const UINT8 DB_VALID   = 0;
const UINT8 DB_INVALID = 1;

const UINT8 IOPDESC_SIZE      = 8;
const UINT8 SFBYTES_SIZE      = 32;
const UINT8 SLOTINFAIL_SIZE   = 16;
const UINT8 TSTFUNCT_SIZE   = 4;

const UINT8 BOXSLOT_SPARESIZE = 16;

const UINT8 SLOTINFAIL_MASKINIT = 0x80;

const UINT8  COMTOGBIT = 0x01;
const UINT8  CTLTOGBIT = 0x02;

// This constant was changed from 4 secs to 10 secs for the following PAR fix. The
// actuak fix should have been in supervsior. However were dropped as it would
// affect C300 performance.
// 1-2LZHA1- On C300 switchover control sheds and Series C output IOM's shed to FAULTOPT.
const UINT16 TOGTIMEOUT  = 1000;

// for redesign PMIO, MODNUM BITS are different (7 - PARITY; 6:4 - FILE; 3:0 - SLOT)
const UINT8 MODNUMBITS = 0x7F;

const UINT8  RELAYBIT = 0x40;   // temporary use for Pass 1 relay IOTAs
const UINT8  IOLIDBIT = 0x80;

const UINT8 MAXSLOTS = 16;

const UINT8 LPBKSTAT_RCVCHNLENDBIT = 6;
const UINT8 LPBKSTAT_CHNLENDBIT = 4;
const UINT8 LPBKTST_MAX_RETRIES = 3;

// HART BRDP related contants
const UINT16 ALLHNDLBUSY        = 0xFFFF;
const UINT8 BRDP_HNDL_MSK       = 0x78;     // XSSSSNNN  S-slot number
const UINT8 MAXNOOFHANDLES      = 128;

const UINT8 MAXBRDPMSGS         = 16;       // Max 16 PassThrough Messages at any time.

const UINT8 BRDPStsTableSize    = 4;
const UINT8 HNDLStsTableSize    = 2;
#ifdef __cplusplus
static_assert(sizeof(BRDPSTSTABLE) == BRDPStsTableSize,
              "BRDPSTSTABLE size mismatch");
static_assert(sizeof(HNDLSTSTABLE) == HNDLStsTableSize,
              "HNDLSTSTABLE size mismatch");
#endif
const UINT8 BRDP_HNDL_TIMEOUT   = 180; // Handle Timeout in seconds
const UINT8 INVALID_HANDLE      = 0xFF;
const UINT8 INVALID_SLOTNUM     = 0xFF;
const UINT8 INVALID_HANDLE_MASK = 0x80;
const UINT8 BRDPSESSION_OPEN    = 0x01;
const UINT8 BRDPSESSION_CLOSE   = 0x00;
const UINT8 HARTMSG_LEN_OFFSET  = 0x07;
const UINT8 DEFAULT_HART_MSG_LEN = 0x09;
const UINT8 BRDPFIELDCOUNT      = 0x04;  //Information characters in def index paramem write
//The HART message size is calculated as
// Delimiter(1) + UniqueAddr(5) + Cmd(1) + ByetCount(1) + Data(255 Max) + Checksum(1) = 264
#define HARTREQMSGSIZE    264
// Delimiter(1) + UniqueAddr(5) + Cmd(1) + ByetCount(1) + Data(255 Max) + Checksum(1) = 264
#define HARTRESMSGSIZE    264

// C300/IOLIM has 128 byte buffers. Normally HART passthrough commands are less than 128 bytes
// long. The requests/responses which are longer than 128 are sent as split req/responses
// using multiple IOL messages. max length of the message would be 264 bytes. So it is splited
// in 3 requests.
const UINT8  HART_SPLIT_PACKET_MASK = 0x03;
// D N S C SltNum ParamNo Handle Header and 2 checksum bytes = 10
// So total HART request data per split request is 128-10=118
const UINT8 HART_REQ_BYTES_PER_IOL_MSG    = 118;
// Maximum number of bytes that can be sent out with each IOL Message
// Note: C300/IOLIM has 100 bytes wide response buffers. That includes D N S C
// and Checksum bytes from IOLINK message. 1 header byte for response is also required.
// it implies that maximum hart response bytes that can be sent out is 100-7=93 bytes.
const UINT8  HART_RESP_BYTES_PER_IOL_MSG  = 93;
const UINT8  HART_COMPLETE_RESPONSE     = 0;
const UINT8  HART_PARTIAL_RESPONSE      = 1;
// Split Request constants
const UINT8  BRDP_SPLIT_REQUEST     = 0x80;
const UINT8  BRDP_SPLIT_LAST_REQ    = 0xC0;

// Offset in InfoField Data in Deferred Index Write commmand
const UINT8  BRDP_SLOTNO_OFFSET     = 0;
const UINT8  BRDP_PARAMCODE_OFFSET  = 1;
const UINT8  BRDP_HANDLE_OFFSET     = 2;
const UINT8  BRDP_HEADER_OFFSET     = 3;
const UINT8  BRDP_MSGNO_OFFSET      = 4;

/* Parameter IDs (subset needed for core operation) */
//PARAMETER NUMBER CONTANTS
#define PARAMID_SLOTSFBITS      35  // SlotSfBits
#define PARAMID_MAPSLOTINFAIL   37  // MapSlotInFail
#define PARAMID_CHNERRA         38  // ChnErrA
#define PARAMID_CHNERRB         39  // ChnErrB
#define PARAMID_CHNSILA         40  // ChnSilA
#define PARAMID_CHNSILB         41  // ChnSilB
#define PARAMID_FPGAREVCODE     42  // FPGA RevCode
#define PARAMID_CPLDREVCODE     43  // CPLD RevCode
#define PARAMID_SUP300          47  // Sup300
#define PARAMID_BOXSFBITS       251 // Box Soft Fails
#define PARAMID_COMMERR         54  // CommErr
#define PARAMID_COMMSTAT        55  // CommStat
#define PARAMID_DPA             56  // Dpa
#define PARAMID_DSA             57  // Dsa
#define PARAMID_BA              60  // Ba
#define PARAMID_IOLDEVTYPE      64  // IolDevType
// for redesign PMIO, non avail params
#define PARAMID_LASTFAIL        65  // LastFail
#define PARAMID_HWREVCODE       63  // HwRevCode
#define PARAMID_SWREVCODE       72  // SwRevCode
#define PARAMID_MODSTAT1        67  // ModStat1
#define PARAMID_MODSTAT2        68  // ModStat2
#define PARAMID_MODLTYPE        69  // ModlType
#define PARAMID_NTH             70  // Nth
#define PARAMID_REDDATA         77  // RedData
#define PARAMID_DBVALID         78  // DbValid
#define PARAMID_SFACTNTBL       79  // SfActionTbl
#define PARAMID_FREQ6050        82  // FREQ6050
#define PARAMID_FL_UNPWRD_BX    91  // Box Fault Unpowered
#define PARAMID_HAUTODET        110 // HAUTODET
#define PARAMID_MAXSLOTS        116 // MaxSlots
#define PARAMID_BOXCHKPNT       143 // CheckPoint
#define PARAMID_BRDP            151 // BRDP (BOX)
#define PARAMID_TEMPHILM        208 // TempHiLm
#define PARAMID_TEMPLOLM        209 // TempLoLm
#define PARAMID_HBRDP           232 // HBRDP (SLOT)
#define PARAMID_BOXCHKPNTVER    243 // BoxChekpointVerNum
#define PARAMID_SLTCHKPNTVER    245 // SlotChekpointVerNum

// Constants used for SPI EEPROM
// INSTRUCTION SET
//const UINT8 EEPROM_WREN   = 0x06;
//const UINT8 EEPROM_WRDI   = 0x04;
//const UINT8 EEPROM_RDSR   = 0x05;
//const UINT8 EEPROM_WRSR   = 0x01;
//const UINT8 EEPROM_RDLO   = 0x03;
//const UINT8 EEPROM_RDHI   = 0x0B;
//const UINT8 EEPROM_WRLO   = 0x02;
//const UINT8 EEPROM_WRHI   = 0x0A;

// PTEXECST LRS BITS
const UINT8 PTEXECST_OFF_LRSBIT = 0x01;
const UINT8 PTEXECST_ON_LRSBIT  = 0x02;
// PTEXECST ON/OFF SUB EVENTS
const UINT8 PTEXECST_OFF_SUBEVT = 0x84;
const UINT8 PTEXECST_ON_SUBEVT  = 0x85;

/*
for redesign PMIO, xRAM related constants
This is status register value for xRAM.
01000000 (default - 0x40)
||||||||_Bit0 - dont care (default 0)
|||||||__Bit1 - WEL (0 - write disable default)
||||||___Bit2 - BP0 (Block Protect bit0, default 0)
|||||____Bit3 - BP1 (Block Protect bit1, default 0)
||||_____Bit4 - dont care (default 0)
|||______Bit5 - dont care (default 0)
||_______Bit6 - dont care (default 1)
|________Bit7 - WPEN (0 - Write protect disable default)
*/
#define xRAM_PRESENT          0x40                   // Default value of the xRAM status register (used for its presence)
#define xRAM_READ             0x03                   // xRAM read opcode
#define xRAM_WRITE            0x02                   // xRAM write opcode
#define xRAM_SPI              EEPROM_SPI             // xRAM SPI register structure (same as EEPROM)
#define SS_xRAM               SS_EEPROM              // xRAM Slave Select Byte (same as EEPROM)
#define DUMMYBYTE             0x00                   // Dummy byte
#define xRAM_WREN             EEPROM_WREN            // xRAM Write Enable (same as EEPROM)
#define xRAM_WRDI             EEPROM_WRDI            // xRAM Write Disable (same as EEPROM)
#define xRAM_WP_n             EEPROM_WP_n            // xRAM Write Protect pin (same as EEPROM)
#define xRAM_ADDR_START       0x00001000             // In xRAM, start address for required backup data (as like PMIO battery backed SRAM)
#define xRAM_SIZE             0x00020000             // xRAM total size (1 Mbit / 128KByte)
#define xRAM_ADDR_END         (xRAM_SIZE-1)          // xRAM last address
#define xRAM_CHKPNT_ADRS      xRAM_ADDR_START        // checkpoint parameters start address in xRAM
#define xRAM_CHKPNT_BLOCK     200                    // block size for checkpoint parameters in xRAM
#define xRAM_CALIB_DONE       (xRAM_CHKPNT_BLOCK-40) // 0x103C byte is to store recently calib done
#define xRAM_LAST_DPA         (xRAM_CHKPNT_BLOCK-39) // 0x103D byte is to store LAST DPA (work around for IDL mode when module remove from chasis)
#define xRAM_APP_CRC          (xRAM_CHKPNT_BLOCK-38) // From 0x103E - 0x1041 is to store APP CRC Checking
#define xRAM_CHKPNT_CKSM      (xRAM_CHKPNT_BLOCK-34) // Last 34 bytes of box checkpoint block reserved for checksum of box and slot checkpoints

#define xRAM_CHKPNT_PRMXSZ    0x52                   // Maximum size (+2) of parameter in xRAM

#define xRAM_CHKSM_SIZE       0x02                   // Size of checksum for checkpoints in xRAM

const UINT8 SRAM_WRMR = 0x01;

extern VOID xRamInit(VOID);

extern VOID xRamWrite(UINT32 ulAddress, UINT8 *pucData, UINT16 uiCount);
extern VOID xRamRead(UINT32 ulAddress, UINT8 *pucData, UINT16 uiCount);

//const UINT8 EEPROM_STSMASK  = 0xFC;
//const UINT8 EEPROM_SELECT   = 0xFD;
//const UINT8 EEPROM_DESELECT = 0x02;

/*******************************************************************************
*                                  clsBoxSlot                                  *
*******************************************************************************/
class clsBoxSlot : public clsIomSlot
{

private:
    clsEcl       *pNrmEcl;

public:
    // BRDP database
    UINT8       BRDPOneSecCounter;
    // These 2 bytes keep the status of available resources for brdp.
    // Each bit corressponds one resource pool which contains 
    // 1 request buffer & 1 response buffer.
    UINT16      BRDPResourceStatus;
    // Handle, Status
    HNDLSTSTABLE    HNDLStatusTable[MAXBRDPMSGS];
    // Stores the message number (Buffer Number ) where the split message is copied.
    UINT8       SPLTRequestHndlTable[MAXNOOFHANDLES];
    // Stores the offset in case of split message responses.
    UINT8       SPLTResponseOffsetTable[MAXBRDPMSGS];
    // End BRDP database

protected:
    HWINFO       HwInfo;
    REVCODE      AppSwRevCode;
    REVCODE      BootSwRevCode;

    MODLTYPE     ModlType;
    UINT8        ModlNum;
    UINT8        IolId;
    UINT8        Dpa;
    UINT8        Dsa;
    UINT8        Ba;
    UINT8        Nth;
    IOLDEVTYPE   IolDevType;
    UINT8        ModStat1Lrs;
    MODSTAT2     ModStat2;
    MODSTAT3     ModStat3;
    UINT8        MesNo;
    UINT8        CommErr;
    COMMSTAT     CommStat;
    UINT8        ChnErrA;
    UINT8        ChnErrB;
    UINT8        ChnSilA;
    UINT8        ChnSilB;
    FLOAT32      CpuFreeMin; 
    FLOAT32      CpuFreeAvg; 
    BOOL         StatReset;
    UINT8        CPLDRegData;
    BOOL         CtlTog;
    BOOL         ComTog;
    BOOL         CtlWasAlive;

    //FLOAT32      CpuFreeMin;
    //FLOAT32      CpuFreeAvg;
    //BOOL         StatReset;

    HARDFAILTYPE LastFail;
    UINT8        SuprCtrl;
    UINT16       ToknStll;
    UINT16       CheckSum[MAXSLOTS + 1];
    BLIND        BoxSfBits[SFBYTES_SIZE];
    BLIND        SlotSfBits[SFBYTES_SIZE];
    BLIND        MapSlotInFail[SLOTINFAIL_SIZE];
    BLIND        BoxSfLrs[SFBYTES_SIZE];
    UINT8        BoxSfCounter;
    UINT8        SlotSfCounter;
    BLIND        SfActionTbl[SFBYTES_SIZE];
    BOOL         WithBias;
    BLIND        SyncVer[SYNCVER_SIZE];
    BLIND        RedData[REDDATA_SIZE];
    //TRACELOGDATA TraceLogInfo;
    UINT8        LedBlinkCounter;
    //BOOL         LedOn;
    UINT8        LpBkStat;
    static INT32 TstFunctTime;
    BOOL         bStcSyncRestart;
    //BOOL         bWdtIntProcessed;

    // to fix flood alarms
    SOFTFAILTYPE    LastSfCode;
    SOFTFAILTYPE    SfCodeLrs;
    UINT8           ucOutputFailCounter;
    /* Dump record sync area (must be last group before spare) */
    MODSTAT1     ModStat1;
    BOOL         DbValid;
    UINT8        MaxSlots;
    //UINT8        BoxSlotSpare[BOXSLOT_SPARESIZE];

#if !defined(IOPTYPE_SCIOM)
    // for redesign PMIO, non avail params
    static const UINT8 IomDtl[];
    static const UINT8 IolSup[];
    static const UINT8 IopDesc[];
#endif
    clsBoxSlot(MODLTYPE a_ModlType, UINT8 a_MaxSlots);
    virtual ~clsBoxSlot(void) {}

    PASTATUS PreModStat1(UINT8*, UINT8);
    VOID PostModStat1(UINT8);
//    PASTATUS PreSyncVer(UINT8*, UINT8);
//    PASTATUS PreRedData(UINT8*, UINT8);
//    VOID PostRedData(UINT8);
//    PASTATUS PreStatReset(UINT8*, UINT8);
//    VOID PostStatReset(UINT8);
//    PASTATUS PreCPLDRegData(UINT8*, UINT8);
//    VOID PostCPLDRegData(UINT8);

    /* Housekeeping slot rotation counter */
    //UINT8        HouseKeepingSlot;

    inline VOID PostSfActionTbl(UINT8)
    {
        // for redesign PMIO, it disabled due to sync fail
        //clear the sf action table bit for SF_OUTPUTFL
       SfActionTbl[2] &=0x7F;
       //TraceLog.AddToTrace(TRACEID_GENERIC,bcSfActionTable);
    }

    static HARDFAILTYPE FailCode;
    //static BOOL IomRebooted;

    static const UINT8 Bits[];
    static const SOFTFAILTYPE SlotSfMap[BYTESIZE];
    static const UINT8 ModStatType[];
    static const UINT8 Sup300[];
    static const UINT8 SfInfo300[];

    inline VOID *GetChnErrAPtr(VOID) { return &ChnErrA; }
    inline VOID *GetChnErrBPtr(VOID) { return &ChnErrB; }
    inline VOID *GetChnSilAPtr(VOID) { return &ChnSilA; }
    inline VOID *GetChnSilBPtr(VOID) { return &ChnSilB; }
    inline VOID *GetCtlTogPtr(VOID)     {return &CtlTog;}
    inline VOID *GetComTogPtr(VOID)     {return &ComTog;}
    inline VOID *GetCheckSumPtr(VOID) { return CheckSum; }
    inline VOID *GetBoxSfBitsPtr(VOID) { return BoxSfBits; }
    inline VOID *GetBoxSfLrsPtr(VOID) { return BoxSfLrs; }
    inline VOID *GetSlotSfBitsPtr(VOID) { return SlotSfBits; }
    inline VOID *GetMapSlotInFailPtr(VOID) { return MapSlotInFail; }
    inline VOID *GetModStatTypePtr(VOID) { return (VOID *)ModStatType; }
    inline VOID *GetSup300Ptr(VOID) { return (VOID *)Sup300; }
    inline VOID *GetCircListStPtr(VOID) { return &pNrmEcl->CircListSt; }
    inline VOID *GetCommErrPtr(VOID) { return &CommErr; }
    inline VOID *GetCommStatPtr(VOID) { return &CommStat; }
    inline VOID *GetDpaPtr(VOID) { return &Dpa; }
    inline VOID *GetDsaPtr(VOID) { return &Dsa; }
    inline VOID *GetEvntAppPtrPtr(VOID) { return &pNrmEcl->EvntAppPtr; }
    inline VOID *GetEvntRemPtrPtr(VOID) { return &pNrmEcl->EvntRemPtr; }
    inline VOID *GetBaPtr(VOID) { return &Ba; }
    inline VOID *GetSyncVerPtr(VOID) { return SyncVer; }
    inline VOID *GetFailCodePtr(VOID) { return &FailCode; }
    inline VOID *GetHwInfoPtr(VOID) { return &HwInfo; }
    inline VOID *GetHwRevCodePtr(VOID) { return &HwInfo.HwRevLetter; }
    inline VOID *GetAppSwRevCodePtr(VOID) { return &AppSwRevCode; }
    inline VOID *GetBootSwRevCodePtr(VOID) { return &BootSwRevCode; }
    inline VOID *GetAppBuildNoPtr(VOID) { return APP_BUILD_NUMBER_PTR; }   // read from flash
    inline VOID *GetBootBuildNoPtr(VOID) { return BOOT_BUILD_NUMBER_PTR; } // read from flash
    inline VOID *GetIolDevTypePtr(VOID) { return &IolDevType; }
    inline VOID *GetLastFailPtr(VOID) { return &LastFail; }
    inline VOID *GetMesNoPtr(VOID) { return &MesNo; }
    inline VOID *GetModStat1Ptr(VOID) { return &ModStat1.BYTE; }
    inline VOID *GetModStat2Ptr(VOID) { return &ModStat2; }
    inline VOID *GetModlTypePtr(VOID) { return &ModlType; }
    inline VOID *GetNthPtr(VOID)      { return &Nth; }
    inline VOID *GetTstFunctTimePtr(VOID) { return &TstFunctTime; }
    inline VOID *GetSfInfo300Ptr(VOID) { return (VOID *)SfInfo300; }
    inline VOID *GetWithBiasPtr(VOID) { return &WithBias; }
    inline VOID *GetRedDataPtr(VOID) { return RedData; }
    inline VOID *GetDbValidPtr(VOID) { return &DbValid; }
    inline VOID *GetSfActionTblPtr(VOID) { return SfActionTbl; }
    inline VOID *GetMaxSlotsPtr(VOID) { return &MaxSlots; }
    inline VOID *GetCpuFreeMinPtr(VOID) { return &CpuFreeMin; }
    inline VOID *GetCpuFreeAvgPtr(VOID) { return &CpuFreeAvg; }
    inline VOID *GetStatResetPtr(VOID) { return &StatReset; }
    inline VOID *GetLpBkStatPtr(VOID) { return &LpBkStat;}

#if !defined(IOPTYPE_SCIOM)
    // for redesign PMIO, non available param
    inline VOID *GetIopDescPtr(VOID)   { return (VOID *)IopDesc; }
    inline VOID *GetIomDtlPtr(VOID)    { return (VOID *)IomDtl; }
    inline VOID *GetIolSupPtr(VOID)    { return (VOID *)IolSup; }
    inline VOID *GetSuperCtrlPtr(VOID) { return &SuprCtrl; }
    inline VOID *GetToknStallPtr(VOID) { return &ToknStll; }
#endif

    VOID PpxConfig(UINT32 uSec, hal_timer_callback_t callback) {

        hal_timer_stop(HAL_TIMER_PPX);
        hal_timer_configure(HAL_TIMER_PPX, uSec, callback);
        hal_timer_start(HAL_TIMER_PPX);
    }

public:

    /* Virtual hooks for derived class (AIHBoxSlot) */
    virtual void AppStcProcessing(void)  {}
    virtual void AppInitialization(void) {}

    virtual BOOL GetCalibAllState(VOID) { return FALSE; }

    inline HARDFAILTYPE GetFailCode(VOID) { return FailCode; }
    inline VOID SetFailCode(HARDFAILTYPE a_FailCode) { FailCode = a_FailCode; }

    BOOL AddModStatEvent(EVENTTYPE);

    BOOL FlashHWRevCode(VOID);
    VOID StoreDatabase(UINT8, BOOL);
    inline UINT8 GetDPA(void) { return Dpa; }
    inline UINT8 GetDSA(void) { return Dsa; }
    inline UINT8 GetBA(void)  { return Ba; }
    inline void SetDSA(UINT8 a_ucDsa) { Dsa = a_ucDsa; Ba = 0xFF; }
    inline void SetBA(UINT8 a_ucBa)   { Ba = a_ucBa; Dsa = 0; }

    /* Communication channel management */
    inline UINT8 GetPRC(void)  { return CommStat.PRC ? 1 : 0; }
    inline void SetPRC(void)   { CommStat.PRC = TRUE; }
    inline void ResetPRC(void) { CommStat.PRC = FALSE; }
    inline UINT8 SwapPRC(void)
    {
        if (CommStat.PRC)
        {
            CommStat.LSB = TRUE;
            if (ChnSilB < MAXUINT8) ChnSilB++;
            CommStat.PRC = FALSE;
            return 0;
        }
        else
        {
            CommStat.LSA = TRUE;
            if (ChnSilA < MAXUINT8) ChnSilA++;
            CommStat.PRC = TRUE;
            return 1;
        }
    }
    inline UINT16 GetSilenceCount(void) { return (ChnSilA + ChnSilB); }
    inline UINT8 GetBoxSfByte(UINT8 a_ucIndex) { return BoxSfBits[a_ucIndex]; }

    inline UINT8 GetModuleStatus(VOID) { return ModStat1.Status; }
    inline VOID DoAliveToIdleChange(VOID) {

        if (MODSTATUS_ALIVE == ModStat1.Status) {

            ModStat1.Status = MODSTATUS_IDLE;
            AddModStatEvent(EVENTTYPE_NORMAL);
        }
    }

    inline BOOL  IsRoomForRegen(VOID) { return pNrmEcl->IsRoomForRegen(); }

    inline VOID UpdateTOG(UINT8 ucTog)
    {
        if(ucTog && COMTOGBIT) ComTog = TRUE;
        if(ucTog && CTLTOGBIT) CtlTog = TRUE;
    }

    inline BOOL GetComTog(VOID)      { return ComTog; }
    inline BOOL GetCtlTog(VOID)      { return CtlTog; }
    inline BOOL GetCtlWasAlive(VOID) { return CtlWasAlive; }

    /* Comm error management */
    inline void SetCommError(PASTATUS a_uiError) {
        CommErr = (UINT8)a_uiError;
        if (CommStat.PRC) {
            CommStat.LEB = TRUE;
            if (ChnErrB < MAXUINT8) ChnErrB++;
        } else {
            CommStat.LEA = TRUE;
            if (ChnErrA < MAXUINT8) ChnErrA++;
        }
        ModStat2.CommErr = TRUE;
    }
    inline void ResetCommErrs(void) {
        CommStat.LEA = CommStat.LEB = CommStat.LSA = CommStat.LSB = FALSE;
        CommErr = PA_OK;
        ChnErrA = ChnErrB = ChnSilA = ChnSilB = 0;
        ModStat2.CommErr = FALSE;
    }

    inline BOOL  GetFtaPres(VOID)     { return ModStat2.FtaPres; }
    inline BOOL  GetIotaPos(VOID)     { return ModStat2.IotaPos; }
    inline UINT8 GetModStat1(VOID)    { return ModStat1.Status; }
    inline UINT8 GetModStat3(VOID)    { return ModStat3.BYTE; }
    inline UINT8 CheckForFactoryTestMode(VOID) {return ModStat1.Factory;}

    inline VOID SetFtaPres(BOOL bState)  { ModStat2.FtaPres = bState; }
    inline VOID SetIotaPos(BOOL bState)  { ModStat2.IotaPos = bState; }

    /* IOL ID check */
    inline BOOL IsIolCorrect(UINT8 ucIolId) { return !(ucIolId ^ IolId); }

    /* Link error and redundancy channel management */
    inline BOOL AreLinkErrorsSet(UINT8 ucPRC) {
        return (ucPRC ? (ChnSilB > 0) : (ChnSilA > 0));
    }

    inline UINT8 GetNrmEclStatus(VOID) { return pNrmEcl->GetStatus(); }

    inline BOOL AddNrmEclEvent(EVENTRECORD *a_pEventRecord)
    {
        return pNrmEcl->AddEvent(a_pEventRecord);
    }

    inline UINT16 CollectNrmEclInfo(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes)
    {
        return pNrmEcl->CollectEclInfo(a_pBuffer, a_uiMaxBytes);
    }

    inline VOID CollectNrmEclData(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes)
    {
        pNrmEcl->CollectEclData(a_pBuffer, a_uiMaxBytes);
    }

    inline VOID UpdateNrmEclRemPtr(UINT16 a_uiNewRemPtr)
    {
        pNrmEcl->UpdateRemPtr(a_uiNewRemPtr);
    }

    inline VOID BlinkLed(UINT8 a_ucBlinkCount) {
    // Twice of desired blinks should be assigned to
    // counter because 2 means one OFF and one ON
      LedBlinkCounter = 2 * a_ucBlinkCount;
    }
#if 0   // ANIL_RE_VISIT
    inline VOID *GetTraceLogInfoPtr(VOID)
    {
        TraceLogInfo.TracelogTime = TracelogTimeCntr;
        TraceLogInfo.LatestIndex  = TraceLog.GetLatestTraceIndex();
        return &TraceLogInfo;
    }

    inline VOID SetTraceTime(VOID) { TracelogTimeCntr++; }
    inline VOID *GetTracelogPtr(VOID) { return TraceLog.GetTracelog(); }
    inline VOID *GetTracelevelPtr(VOID) { return TraceLog.GetTracelevel(); }
#endif
    inline VOID MarkStcCounter(BOOL bPrimary)
{
#if 0 // temp for testing
        if (bPrimary == TRUE) Tpu5_Pri = TPU5_TCNT;
        else Tpu5_Sec = TPU5_TCNT;
#endif
    }
    inline VOID SyncStcCounter(BOOL bPrimary) {
#if 0 // temp for testing
        if (bPrimary == FALSE) {
            bStcSyncRestart = TRUE;
            TPU5_TCNT = Tpu5_Pri + (TPU5_TCNT - Tpu5_Sec);
        }
        TPU3_TCNT = 0;
#endif
    }
    inline BOOL GetStcSyncReset(VOID) {return bStcSyncRestart;}

    /* Checksum management */
    inline VOID SetCheckSum(UINT8 a_ucChanNum, UINT a_ulChecksumVal) {

        if (a_ucChanNum <= MAXSLOTS) CheckSum[a_ucChanNum] = a_ulChecksumVal;
    }
    inline UINT16 GetCheckSum(UINT8 a_ucChanNum) {

        return (a_ucChanNum <= MAXSLOTS) ? CheckSum[a_ucChanNum] : 0;
    }

    inline UINT16 *GetPmioCheckSumPtr(UINT8 a_ucChanNum) { return &CheckSum[a_ucChanNum]; }

    inline BOOL CheckRedData(UINT8 ucBit) {return (RedData[0] & ucBit);}
    inline UINT8 GetRedData(VOID) {return (UINT8)RedData[0];}
    inline void SetRedData(UINT8 ucBit)   { RedData[0] |= ucBit; }
    inline void ResetRedData(UINT8 ucBit) { RedData[0] &= ~ucBit; }
    inline VOID UpdateRedData(UINT8 ucnewRedData) {

        UINT8 ucBitnum = ucnewRedData & 0x7F;

        if (ucnewRedData & 0x80)  {
            SetRedData(Bits[ucBitnum]);
        }
        else {
            ResetRedData(Bits[ucBitnum]);
        }
    }
    inline UINT8 GetRedState(VOID) {return (UINT8)RedData[1];}
    inline VOID SetRedState(BLIND ucRedState) {RedData[1] = ucRedState;}
    BOOL AddPtExecStEvent(EVENTRECORD *pPtExecStEvent);

    inline BOOL GetPartnersBackupStatus(VOID){
#if 0
        #if !AIAO
            RDBK_SEL = RDBK_IOTA;          // Select proper bank for BUPREQ_IN
        #endif // !AIAO
#endif
            return (BUPREQ_IN);
    }

    inline BOOL GetMyBackupStatus(VOID) {
        return (CheckRedData(REDDATA_BURQST));
    }

    inline VOID AssertBackup(VOID) {
        SetRedData(REDDATA_BURQST);
        //SWBUREQ_n = 0;
        SetBupreqOut(0);
    }
    inline VOID DeAssertBackup(VOID) {
        ResetRedData(REDDATA_BURQST);
        //SWBUREQ_n = 1;
        SetBupreqOut(1);
    }

    inline VOID SetTstFunctTime(INT32 Time){TstFunctTime = Time;}
    inline VOID SetTstFunctTimeStsToFail(VOID){TstFunctTime = -1;}
    inline VOID ResetTstFunctTime(VOID){TstFunctTime = 0;}
	
	    inline VOID *GetCPLDRegDataPtr(VOID){return &CPLDRegData;}

    inline STATUSLED LED_PINS(BOOL a_bSet, STATUSLED a_Status = STATUSLED_OFF) {

        UINT16 m_uiStatus = (UINT16)a_Status;

        if (a_bSet)
            hal_fpga_write(FPGA_STATUS_LED, m_uiStatus);
        else
            m_uiStatus = hal_fpga_read(FPGA_STATUS_LED) | 0x0300;

        return (STATUSLED)m_uiStatus;
    }

    BOOL AddSoftfailEvent(EVENTTYPE, SOFTFAILTYPE, BOOL, UINT8);
    
    BOOL AddBracketEvent(EVENTSUBTYPE);

    BOOL RegenSoftfails(VOID);
    VOID BoxHouseKeeping(VOID);

    static VOID BlinkLEDInterruptHandler(VOID);

    VOID ManageRedIO(VOID);
    VOID DropSync(VOID);

    RETURNSTATUS HartLoopBackTest(VOID);

    inline VOID SetLpBkStat(HARTLPBKSTAT Sts){ LpBkStat = (UINT8)Sts; }
    inline HARTLPBKSTAT GetLpBkStat(VOID) { return (HARTLPBKSTAT)LpBkStat; }

    BOOL isOddParity(UINT8 ucBinary);
    VOID SetFactoryTestMode(VOID);

#if 1 // testing
    inline VOID SetModStat1(UINT8 Val) { ModStat1.Status = Val; }
    inline VOID SetDbValid(BOOL Val)   { DbValid = Val; }
    inline BOOL GetFactoryTestMode(VOID) { return ModStat1.Factory; }
    inline UINT8 GetHwRevLetter(VOID)   { return HwInfo.HwRevLetter; }
    inline UINT8 GetHwRevNumber(VOID)   { return HwInfo.HwRevNumber; }
#endif
}; //clsBoxSlot

#endif /* __BOXSLOT_HPP__ */
