/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : boxslot.cpp                                                 *
*    Description : clsBoxSlot implementation for RT1024/QEMU — AOH-only.       *
*                  Full implementation: soft-fail management, status           *
*                  transitions, ECL events, BRDP handle management,            *
*                  parameter read/write, checksum, CPU free tracking.          *
**************************`*****************************************************/
#if 1   // ANIL_RE_VISIT
#include "aohmain.h"
#endif

/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/

#if 0   // ANIL_RE_VISIT
extern clsHartPst *pHartPst[];

/* pDatabase: slot 0 = BOX, slots 1..MAXSLOTS = channel objects */
extern clsIomSlot *pDatabase[];

#endif
#if 0//def DEBUG
extern BOOL g_bTppInProgress;
#endif
BOOL HartLoopBkTestInProgress;
BOOL FactryModeWDTUTest;
BOOL FactryModeJabberTest;
BOOL HWRevCodeWriteInProgress;
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/

//#pragma section REBOOT_SECTION
//BOOL clsBoxSlot::IomRebooted;
HARDFAILTYPE clsBoxSlot::FailCode;
//Time stamp for traces added to IOM tracelog.
//UINT32 clsBoxSlot::TracelogTimeCntr;
INT32 clsBoxSlot::TstFunctTime;
//#pragma section

const UINT8 clsBoxSlot::Bits[] = {0,1,2,4,8,16,32,64,128};

const UINT8 VersionInfo[] = {
    VERSION_NUMBER,
    REVISION_NUMBER,
    BUILD_NUMBER
};

const UINT8 clsBoxSlot::ModStatType[] = {
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT1,
    PARAMID_MODSTAT2,
    0 // Terminator
};

const UINT8 clsBoxSlot::Sup300[] = {
    PARAMID_DSA,
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT2,
    PARAMID_NTH,
    PARAMID_COMMSTAT,
    PARAMID_COMMERR,
    PARAMID_CHNERRA,
    PARAMID_CHNERRB,
    PARAMID_CHNSILA,
    PARAMID_CHNSILB,
    PARAMID_BA,
    PARAMID_REDDATA,
    PARAMID_DBVALID,
    0 // Terminator
};

const UINT8 clsBoxSlot::SfInfo300[] = {

    // added to fix in DO, PAR#1 - 91X5DJ1
    // in DI, observed similar issue in experion setup
    //PARAMID_DO_BOXSFAIL,

    PARAMID_BOXSFBITS,
    PARAMID_SLOTSFBITS,
    PARAMID_MAPSLOTINFAIL,
    0 // Terminator
};

#if !defined(IOPTYPE_SCIOM)
//for redesign PMIO, non available param set tables
const UINT8 clsBoxSlot::IomDtl[] = {
    PARAMID_MODLTYPE,
    PARAMID_LASTFAIL,
    PARAMID_HWREVCODE,
    PARAMID_SWREVCODE,
    PARAMID_MODSTAT1,
    PARAMID_MODSTAT2,
    PARAMID_BOXSFBITS,
    PARAMID_SLOTSFBITS,
    PARAMID_MAPSLOTINFAIL,
    0 // Terminator
};
const UINT8 clsBoxSlot::IolSup[] = {
    PARAMID_DSA,
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT2,
    PARAMID_NTH,
    PARAMID_COMMSTAT,
    PARAMID_COMMERR,
    PARAMID_CHNERRA,
    PARAMID_CHNERRB,
    PARAMID_CHNSILA,
    PARAMID_CHNSILB,
    0 // Terminator
};
#endif

/*******************************************************************************
*                       clsBoxSlot::clsBoxSlot                                 *
*                       ======================                                 *
* PURPOSE:                                                                     *
*    Constructor — initialise module identity, status, softfail bitmaps, ECL,  *
*    BRDP table and LED housekeeping state.                                    *
* ARGUMENTS:                                                                   *
*    a_ModlType : MODLTYPE identifying this module (AOH, UIO, etc.).           *
*    a_MaxSlots : number of channel slots this module supports.                *
* RETURN:                                                                      *
*    None (constructor).                                                       *
* NOTES:                                                                       *
*    RT1024 CHANGES: MODNUM read via hal_fpga_get_modnum() SPI abstraction.    *
*******************************************************************************/
clsBoxSlot::clsBoxSlot(MODLTYPE a_ModlType, UINT8 a_MaxSlots) : clsIomSlot(0)
{
    pNrmEcl = new clsEcl(ECLTYPE_NORMAL);

    /* Module identity */
    ModlType = a_ModlType;
    MaxSlots = a_MaxSlots;
#if defined(EVK)
    HwInfo.HwRevLetter = Eeprom.ReadByte(EE_HARDWARE_REVCODE); //0x10; // temp value for testing
    HwInfo.HwRevNumber = Eeprom.ReadByte(EE_HARDWARE_REVNUMBER); //0x00;
#endif
    AppSwRevCode.ucVersion = VersionInfo[0];
    AppSwRevCode.ucRevision = VersionInfo[1];

    /* Read module number from FPGA MODNUM register via SPI (HDD Table 29).
       MODNUM[7:0] comes from backplane DIP switches into FPGA, exposed at
       SPI register 0x64. Bits [5:0] = BCD device address, bit 7 = IOL ID. */
    UINT8 modnum_raw = Fpga.GetModnumRegister();
    ModlNum = modnum_raw & MODNUMBITS;
    IolId   = modnum_raw & IOLIDBIT;

    // DPA formation with File & Slot configuration
    // ModlNum Bit 0:3 - Slot number
    // ModlNum Bit 4:6 - File number
    // ModlNUm Bit 7   - Parity bit

    // always odd no of one's should be in the file code (inclusive parity-Bit7)
    if (isOddParity((ModlNum + IolId) >> 4))
        Dpa = (0x80 | ModlNum);
    else
        HardFail(HF_PARITYERROR, BOXSLOT_CPP, __LINE__);

    // added to fix PAR #1-72NBQP7 (HLAI), #1-7KEY6J5 (AO16) - (IOL COMM Errors issues)
    IolId = IOLIDBIT;
    Dsa     = 0;
    Ba      = 0xFF;
    Nth     = 0;
    IolDevType = IOLDEVTYPE_SLAVE;

    /* Module status */
    ModStat1.BYTE = 0;
    ModStat1.Status = MODSTATUS_ALIVE;
    ModStat1Lrs   = 0;
    ModStat2.BYTE = 0x45;
    ModStat3.BYTE = 0;
    //MesNo    = 0;
    CommErr  = PA_OK;
    CommStat = {0};
    ChnErrA  = 0;
    ChnErrB  = 0;
    ChnSilA  = 0;
    ChnSilB  = 0;
    //CpuFreeMin = 0.0f;
    //CpuFreeAvg = 0.0f;
    //StatReset  = FALSE;

    LastFail = HF_UNKNOWN;
    FailCode = HF_UNKNOWN;

    for (UINT8 ucCount = 0; ucCount < SFBYTES_SIZE; ucCount++)
    {
        BoxSfBits[ucCount]   = 0;
        SlotSfBits[ucCount]  = 0;
        BoxSfLrs[ucCount]    = 0;
        SfActionTbl[ucCount] = 0;
        if (ucCount < SLOTINFAIL_SIZE)
        {
            MapSlotInFail[ucCount] = 0;
        }
    }

    //SuprCtrl  = 0;
    //ToknStll  = 0;
    DbValid   = DB_INVALID;
    //WithBias  = FALSE;
    //LedBlinkCounter = 0;
    //LedOn     = FALSE;
    //LpBkStat  = 0;
    bStcSyncRestart  = FALSE;
    //bWdtIntProcessed = FALSE;

    /* Zero bit-field arrays * /
    for (UINT8 i = 0; i < SFBYTES_SIZE; i++) {
        BoxSfBits[i]   = 0;
        SlotSfBits[i]  = 0;
        BoxSfLrs[i]    = 0;
        SfActionTbl[i] = 0;
    }
    for (UINT8 i = 0; i < SLOTINFAIL_SIZE; i++) {
        MapSlotInFail[i] = 0;
    }
    for (UINT8 i = 0; i < SYNCVER_SIZE; i++) {
        SyncVer[i] = 0;
    } */
    RedData[0] = REDDATA_SFFOEN | REDDATA_BURQST;
    RedData[1] = 0;
    /*
    for (UINT8 i = 0; i <= MAXSLOTS; i++) {
        CheckSum[i] = 0;
    }
    for (UINT8 i = 0; i < BOXSLOT_SPARESIZE; i++) {
        BoxSlotSpare[i] = 0;
    }*/

    BoxSfCounter  = 0;
    SlotSfCounter = 0;

    FactryModeJabberTest     = FALSE;
    FactryModeWDTUTest       = FALSE;
    // ANIL_RE_VISIT
    HartLoopBkTestInProgress = FALSE;

    HWRevCodeWriteInProgress = FALSE;

    //TraceLogInfo.TracelogTime = 0;
    //TraceLogInfo.LatestIndex  = 0;

    /* HW info — will be populated from EEPROM/flash at init time */
    //HwInfo = {0};
    //AppSwRevCode.ucByte  = 0;
    BootSwRevCode.ucByte = 0;

    /* BRDP */
    //InitBRDPDatabase();

    /* Housekeeping rotation */
    //HouseKeepingSlot = 0;

    /* Configure LED blink timer interrupt.
       Period: 500ms (500,000 microseconds) — typical for status LED blinking.
       Callback: BlinkLEDInterruptHandler will be invoked periodically. */
       // It is handling STCInterruptHandler()
    //hal_timer_configure(HAL_TIMER_LED_BLINK, 500000, (hal_timer_callback_t)BlinkLEDInterruptHandler);
    //hal_timer_start(HAL_TIMER_LED_BLINK);
}

/*******************************************************************************
*                     clsBoxSlot::BlinkLEDInterruptHandler                     *
*                     ====================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::BlinkLEDInterruptHandler(VOID)
{
    //TPU3_TGFA = 0; // Acknowledge the compare match interrupt
    if (BOX->GetFailCode() >= HF_POWERDOWN)
    {

        BOX->LED_PINS(WRITE, STATUSLED_RED);
    }
    else if ((BOX->BoxSfCounter > 0) || (BOX->SlotSfCounter > 0) || (BOX->LedBlinkCounter > 0)) {

        if (BOX->LedBlinkCounter > 0) {
            --(BOX->LedBlinkCounter);
        }

        else if (TRUE == BOX->GetCalibAllState()) {
            // If calibration is progress and there is no request to blink the LED by
            // by the calibration function, switch off the LED and return.
            BOX->LED_PINS(WRITE, STATUSLED_OFF);
            return;
        }

        if (STATUSLED_OFF == BOX->LED_PINS(READ)) {
            (BOX->GetDSA()) ? BOX->LED_PINS(WRITE, STATUSLED_GREEN)
                            : BOX->LED_PINS(WRITE, STATUSLED_AMBER);
        }
        else BOX->LED_PINS(WRITE, STATUSLED_OFF);
    }
    else {
        if (TRUE == BOX->GetCalibAllState()) {
            BOX->LED_PINS(WRITE, STATUSLED_OFF);
        }
        else {
            (BOX->GetDSA()) ? BOX->LED_PINS(WRITE, STATUSLED_GREEN)
                            : BOX->LED_PINS(WRITE, STATUSLED_AMBER);
        }
    }
}

/*******************************************************************************
*                           clsBoxSlot::ManageRedIO                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::ManageRedIO(VOID) {

    switch(Iol.AddressChange()) {
    case ADDCHG_NONE:
        break;
    case ADDCHG_NEW:
        if(Iol.AmPrimary()) {
            DeAssertBackup();
        }
        SetRedState(REDSTATE_NOT_SYNCD);
        //TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0x55555555);
        break;
    case ADDCHG_DROPPED:
        if(REDSTATE_IOL_TIMEOUT != GetRedState()){
            DropSync();
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0xAAAAAAAA);
        }
        break;
    }
}

/*******************************************************************************
*                           clsBoxSlot::DropSync                               *
*                           ====================                               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::DropSync(VOID) {
    if(REDSTATE_FREEZE_PERMITTED != GetRedState()){
       if(REDSTATE_SYNC_FAILED != GetRedState()) SetRedState(REDSTATE_NOT_SYNCD);
       if(!Iol.AmPrimary()) AssertBackup();
    }
}

/*******************************************************************************
*                          clsBoxSlot::AddModStatEvent                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddModStatEvent(EVENTTYPE a_EventType) {
    EVENTRECORD ModStatEvent;
    UINT8 CurrentLrsMask, PreviousLrsMask,PreviousModStat;
    EVENTSUBTYPE CurrentSubType, PreviousSubType;

    // Initialize event record.
    ModStatEvent.Overflow      = FALSE;
    ModStatEvent.ContactCutout = FALSE;
    ModStatEvent.Qualifier     = a_EventType;
    ModStatEvent.CurrentState  = EVENTSTATE_RETURN;
    ModStatEvent.EventPacket   = EVENTPACKET_SYSTEM;
    ModStatEvent.SystemEvent.SoftfailStatus = FALSE;
    ModStatEvent.SystemEvent.ChannelNumber  = 0;
    if (ModStat1.Status == MODSTATUS_IDLE) {
        CurrentLrsMask     = MODSTATUS_IDLE_LRSBIT;
        PreviousLrsMask    = MODSTATUS_RUN_LRSBIT;
        CurrentSubType     = EVENTSUBTYPE_IDLE;
        PreviousSubType    = EVENTSUBTYPE_RUN;
        PreviousModStat    = MODSTATUS_RUN;
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        CurrentLrsMask     = MODSTATUS_RUN_LRSBIT;
        PreviousLrsMask    = MODSTATUS_IDLE_LRSBIT;
        CurrentSubType     = EVENTSUBTYPE_RUN;
        PreviousSubType    = EVENTSUBTYPE_IDLE;
        PreviousModStat    = MODSTATUS_IDLE;
    }
    // Set LRS bit only for normal events.
    if (EVENTTYPE_NORMAL == a_EventType) {
        ModStat1Lrs |= CurrentLrsMask;
    }
    // If last module state change is not reported yet, report it.
    if (ModStat1Lrs & PreviousLrsMask) {
        ModStatEvent.SystemEvent.EventSubType = PreviousSubType;
        if (EVENTTYPE_RECOVERY == a_EventType) {
            if (pNrmEcl->IsRoomForRegen() == FALSE) {
                return FALSE;
            }
        }
        else {
            // Set ECL module status only for normal events.
            pNrmEcl->SetEclModStat(PreviousModStat);
        }
        // Do not update LRS for recovery events.
        if (pNrmEcl->AddEvent(&ModStatEvent) == TRUE) {
            if (EVENTTYPE_NORMAL == a_EventType) {
                ModStat1Lrs &= (~PreviousLrsMask);
            }
        }
        else {
            return FALSE;
        }
    }
    // Report current state change to idle.
    ModStatEvent.SystemEvent.EventSubType = CurrentSubType;
    if (EVENTTYPE_RECOVERY == a_EventType) {
        if (pNrmEcl->IsRoomForRegen() == FALSE) {
            return FALSE;
        }
    }
    else {
        // Set ECL module status only for normal events.
        pNrmEcl->SetEclModStat(ModStat1.Status);
    }
    // Do not update lrs for recovery events.
    if (pNrmEcl->AddEvent(&ModStatEvent) == TRUE) {
        if (EVENTTYPE_NORMAL == a_EventType) {
            ModStat1Lrs &= (~CurrentLrsMask);
        }
        return TRUE;
    }
    return FALSE;
}

BOOL clsBoxSlot::AddPtExecStEvent(EVENTRECORD *pPtExecStEvent)
{
    pNrmEcl->SetStatus(ECLSTATUS_NORMAL);

    return pNrmEcl->AddEvent(pPtExecStEvent);
}

/*******************************************************************************
*                         clsBoxSlot::AddSoftfailEvent                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddSoftfailEvent(EVENTTYPE a_EventType,
                                  SOFTFAILTYPE a_SoftfailType,
                                  BOOL a_bDirection, UINT8 a_ucSltNm) {
    EVENTRECORD SoftfailEvent;
    // Initialize event record.
    SoftfailEvent.Overflow      = FALSE;
    SoftfailEvent.ContactCutout = FALSE;
    SoftfailEvent.Qualifier     = a_EventType;
    SoftfailEvent.EventPacket   = EVENTPACKET_SYSTEM;
    SoftfailEvent.SystemEvent.ChannelNumber = a_ucSltNm;
    SoftfailEvent.SystemEvent.EventSubType  = a_SoftfailType;

    UINT8 ucSfByte,ucLrsByte,ucByteOffset,ucBitOffset=0x01;
    UINT8 ucSfActByteOffset,ucSfActBitOffset=0x01;


    // added to fix unwanted softfails with the greater than SFail code 127
    // root cause: Legacy has BoxSfBits[16], where as redesign BoxSfBits[32]
    // modification: so supressed to 128 SFail codes (16 x 8bits)
    if (a_SoftfailType > SF_IDLE)
    {
        return FALSE;
    }

    // Generate ByteOffset and BitOffsets for SfActionTable search
    ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
    ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);

    // Set SfByte and LrsByte according to the slot number and softail type.
    if (0 == a_ucSltNm) {
        ucByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
        ucBitOffset <<= (a_SoftfailType % BYTESIZE);
        ucSfByte  = BoxSfBits[ucByteOffset];
        ucLrsByte = BoxSfLrs[ucByteOffset];
    }
    else {
        for (ucByteOffset = 0; ucByteOffset < BYTESIZE; ucByteOffset++) {
            if (SlotSfMap[ucByteOffset] == a_SoftfailType) {
                break;
            }
            ucBitOffset <<= 1;
        }
        if (BYTESIZE == ucByteOffset) {
            return FALSE;
        }
        ucSfByte  = SLOT(a_ucSltNm)->GetSlotSfBt();
        ucLrsByte = SLOT(a_ucSltNm)->GetSlotSfLrs();
    }

    if (TRUE == a_bDirection) {
        SoftfailEvent.CurrentState = EVENTSTATE_ALARM;
        if (EVENTTYPE_NORMAL == a_EventType) {
            //Initiate a SoftFail Failover if enabled and appropriate
            if (REDSTATE_SYNCD == GetRedState() &&       // if modules syncd
                CheckRedData(REDDATA_SFFOEN) &&          // + SF FO enabled
                (SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset))// + FO for this SF
            {
                if ((!GetFtaPres() || !GetPartnersBackupStatus()) && Iol.AmPrimary())
                {
                // added to fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
                    LastSfCode = a_SoftfailType;
                    Iol.DropDSA();
                    BOX->SetDSA(0);
                }
                AssertBackup();
                ResetRedData(REDDATA_SFFOEN);
            }
        }
    }
    else SoftfailEvent.CurrentState = EVENTSTATE_RETURN;

    UINT8 ucSaveExr = get_imask_exr();
    if (EVENTTYPE_NORMAL == a_EventType) {
        // Elevate the priority of executing thread to STC level
        // when SfBits and Sfcounter in database are updated.
        set_imask_exr(LVLPRI_TICK);

        if ((ucSfByte & ucBitOffset) && (FALSE == a_bDirection)) {
            // SfByte bit is set and the softfail is returning
            ucSfByte &= ~ucBitOffset; // reset SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter > 0) BoxSfCounter--;
            }
            else {
                if (SlotSfCounter > 0) SlotSfCounter--;

                // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
                if ((SF_OUTPUTFL == a_SoftfailType) && (ucOutputFailCounter))
                {
                    ucOutputFailCounter--;
                }
            }
        }
        else if ((!(ucSfByte & ucBitOffset)) && (TRUE == a_bDirection)) {
            // SfByte bit is not set and the softfail is being reported
            ucSfByte |= ucBitOffset; // set SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter < MAXUINT8) BoxSfCounter++;
            }
            else {
                if (SlotSfCounter < MAXUINT8) SlotSfCounter++;

                // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
                SfCodeLrs = a_SoftfailType;

                if (SF_OUTPUTFL == a_SoftfailType)
                    ucOutputFailCounter++;
            }
        }

#if defined(PMIO_DEBUG) && (0)
        if (ucDbgPnt == NRML_DBGPNT)
        {
            if (ucDbgCnt < DMPBUF_SIZE - 5)
            {
                ucDumpBuff[ucDbgCnt++] = a_SoftfailType;
                ucDumpBuff[ucDbgCnt++] = ((a_ucSltNm << 4) | a_bDirection);
            }
            else ucDbgCnt = 0;
        }
#endif

        // Update SfByte in the box/slot database.
        if (0 == a_ucSltNm) {
            BoxSfBits[ucByteOffset] = ucSfByte;
        }
        else {
            SLOT(a_ucSltNm)->SetSlotSfBt(ucSfByte);
        }

        // Database update complete.
        // Restore original interrupt priority.
        set_imask_exr(ucSaveExr);
    }

    if ((0 == BoxSfCounter) && (0 == SlotSfCounter)) {
        SoftfailEvent.SystemEvent.SoftfailStatus = FALSE;
        pNrmEcl->ResetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = FALSE;
        SetRedData(REDDATA_SFFOEN);
        if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) {
            if (GetCalibAllState() != TRUE) {
                DeAssertBackup();
            }
        }
    }
    else {
        SoftfailEvent.SystemEvent.SoftfailStatus = TRUE;
        pNrmEcl->SetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = TRUE;
    }

    // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (SEC is going into SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion on power up)
    if ((!Iol.AmPrimary())
    && (SF_OUTPUTFL == a_SoftfailType)
    && (GetPartnersBackupStatus()));
#if 0   // ANIL_RE_VISIT
    && (INHIN_NEGATED != INHIN_FB_n))
    {
        LastSfCode = SF_OUTPUTFL;
    }
#endif
    if (MODSTATUS_FAIL != ModStat1.Status) {
        // Add softfail event to the normal event circular list if this is
        // event recovery OR if SfByte and LrsByte are not matching.
        if ((EVENTTYPE_RECOVERY == a_EventType) ||
            (ucLrsByte ^ ucSfByte) & ucBitOffset) {
            if (EVENTTYPE_RECOVERY == a_EventType) {
                if (pNrmEcl->IsRoomForRegen() == FALSE) {
                    return FALSE;
                }
            }

            if (TRUE == pNrmEcl->AddEvent(&SoftfailEvent)) {
                if (EVENTTYPE_NORMAL == a_EventType) {
                    // Update LRS byte only for normal events.
                    if (TRUE == a_bDirection) {
                        ucLrsByte |= ucBitOffset;
                    }
                    else {
                        ucLrsByte &= ~ucBitOffset;
                    }
                }

                // Elevate the priority of executing thread to
                // STC level when LRS byte in database is updated.
                set_imask_exr(LVLPRI_TICK);
                if (0 == a_ucSltNm) {
                    BoxSfLrs[ucByteOffset] = ucLrsByte;
                }
                else {
                    SLOT(a_ucSltNm)->SetSlotSfLrs(ucLrsByte);
                }
                // Database update complete.
                // Restore original interrupt priority.
                set_imask_exr(ucSaveExr);

                return TRUE;
            }
            else { // AddEvent failed
                return FALSE;
            }
        }
    }

    // Execution reaches here only if
    // there is nothing to report.
    return TRUE;
}

/*******************************************************************************
*                           clsBoxSlot::AddBrackEvent                          *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddBracketEvent(EVENTSUBTYPE a_EventSubType)
{
    EVENTRECORD EventBracket;

    // Create start backet
    EventBracket.Overflow      = FALSE;
    EventBracket.ContactCutout = FALSE;
    EventBracket.Qualifier     = EVENTTYPE_RECOVERY;
    EventBracket.CurrentState  = EVENTSTATE_RETURN;
    EventBracket.EventPacket   = EVENTPACKET_SYSTEM;
    EventBracket.SystemEvent.SoftfailStatus = FALSE;
    EventBracket.SystemEvent.ChannelNumber  = 0;
    EventBracket.SystemEvent.EventSubType   = a_EventSubType;
    if (pNrmEcl->IsRoomForRegen() == TRUE) {
        return pNrmEcl->AddEvent(&EventBracket);
    }
    return FALSE;
}

/*******************************************************************************
*                           clsBoxSlot::RegenSoftfails                         *
*                           ==========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::RegenSoftfails(VOID) {

    static UINT8 ucByteCount = 0,ucBitCount = 0,ucMask = 0x01;

    // Iterate for 32 BoxSfBytes and each SlotSfByte.
    while (ucByteCount <= (SFBYTES_SIZE + MaxSlots)) {

        UINT8 ucSfByte,ucSlotNum;
        if (ucByteCount < SFBYTES_SIZE) { //get box softfail byte

            ucSlotNum = 0;
            ucSfByte = BoxSfBits[ucByteCount];
        }
        else { //get slot soft fail byte

            if (SFBYTES_SIZE == ucByteCount) {

                // Return FALSE so that event recovery task will suspend before
                // recovering slot softfails. Increment ucByteCount before
                // returning so that this function will continue with slot soft
                // fail recovery when scheduler resumes event recovery task.
                ucByteCount++;
                return FALSE;
            }
            ucSlotNum = ucByteCount - SFBYTES_SIZE;
            ucSfByte = SLOT(ucSlotNum)->GetSlotSfBt();
        }

        if (ucSfByte > 0) { // any soft fails exists

            while (ucBitCount < BYTESIZE) {

                if (ucSfByte & ucMask) { // Regenerate softfail event

                    SOFTFAILTYPE SoftfailType;
                    if (ucByteCount < SFBYTES_SIZE) { // box softfail

                        SoftfailType = (SOFTFAILTYPE)
                                       ((ucByteCount * BYTESIZE) + ucBitCount);
                    }
                    else { //slot softfail

                        SoftfailType = (SOFTFAILTYPE)SlotSfMap[ucBitCount];
                    }
                    if (FALSE == AddSoftfailEvent(EVENTTYPE_RECOVERY,SoftfailType, TRUE,ucSlotNum))
                    {
                        // Return FALSE so that task will suspend.
                        return FALSE;
                    }
                }
                ucMask <<= 1;
                ucBitCount++;
            }
        }
        // Reinitialize ucMask and ucBitCount for next regeneration.
        ucMask = 0x01;
        ucBitCount = 0;
        ucByteCount++;
    }
    // Reinitialize ucByteCount for next regeneration.
    ucByteCount = 0;

    return TRUE; // Mark end of the softfail recovery.
}

/*******************************************************************************
*                          clsBoxSlot::BoxHouseKeeping                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::BoxHouseKeeping(VOID)
{
    CheckFtaPresence();

#if 1
    // Save current interrupt masks and set current masks
    // so that STC or point processing cannot come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    UINT8 ucCount,ucIndex = 0,ucCompositeByte = 0,ucMask = SLOTINFAIL_MASKINIT;
    UINT8 ucByteOffset,ucBitOffset;

    CheckFtaPresence();

    // Update MapSlotInFail parameter
    for (ucCount = 1; ucCount <= MaxSlots; ucCount++) {

        if ((ucByteOffset = SLOT(ucCount)->GetSlotSfBt()) > 0) {

            ucCompositeByte |= ucByteOffset;
            MapSlotInFail[ucIndex] |= ucMask;
        }
        else {

            MapSlotInFail[ucIndex] &= ~ucMask;
        }
        ucMask >>= 1;
        if (0 == ucMask) {

            ucMask = SLOTINFAIL_MASKINIT;
            ucIndex++;
        }

        // Allow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr);
        set_imask_exr(LVLPRI_TICK);
    }

    // Update SlotSfBits from individual SlotSfBt.
    ucMask = 0x01;
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++) {

        if (SF_UNKNOWN != SlotSfMap[ucCount]) {

            ucByteOffset = SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;

            if (ucCompositeByte & ucMask) {

                SlotSfBits[ucByteOffset] |= ucBoxSfMask;
            }
            else {

                SlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
            }
        }
        ucMask <<= 1;

        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr);
        set_imask_exr(LVLPRI_TICK);
    }

    // Count down SlotSfThrottleCount in all slots.
    for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {

        SLOT(ucCount)->CountDownSlotSfThrottle();
    }

    // Rereport ModStat event if required
    if (ModStat1Lrs > 0) {

        AddModStatEvent(EVENTTYPE_NORMAL);
    }

    // Alow STC to run to avoid STC overruns.
    set_imask_exr(ucSaveExr);
    set_imask_exr(LVLPRI_TICK);

    // Periodically recompute database checksums.
    static UINT8 sucSlot = 0;

    // Storing the dump data into the battery backed SRAM slot wise.
    BOX->StoreDatabase(sucSlot, FALSE); // Store database without checksum

    pDatabase[sucSlot++]->ComputeCheckSum();

    if (sucSlot > MAXSLOTS) {
        sucSlot = 0;
    }

    // Restore original interrupt mask and return.
    set_imask_exr(ucSaveExr);
#endif
}

/********************************************************************************************
*                            clsBoxSlot::PreModStat1                                        *
*                            =======================                                        *
* PURPOSE:   Pre Receiver-Beware function for ModStat1 parameter. Checks for module status. *
* ARGUMENTS: a_Writebuffer   -   Pointer to the data to be written.                         *
*            a_ucAccLvl      -   Access level for check                                     *
* RETURN:    PA_OK           -   If pre check is succesfull                                 *
* NOTES:     This method will update ModStat1Trans flag if there is any                     *
*            change in the module status.                                                   *
*********************************************************************************************/
PASTATUS clsBoxSlot::PreModStat1(UINT8 *a_Writebuffer,UINT8) {

    const UINT8 FACTORYMODE_BIT = 0x04; //3rd bit in ModStat1 byte is Factory Mode bit
    UINT8 ucNewMod1State = *(UINT8*)a_Writebuffer;

    if (ucNewMod1State > MODSTATUS_FAIL) {

      return DO_ILLEGAL_VALUE;
    }

    // Return error is module is in the Alive state.
    if (ModStat1.Status == MODSTATUS_ALIVE) {

        return DO_STATE_MUST_BE_IDLE_OR_RUN;
    }

    // Check if calibration is in progress for analog IOMs. 
    // This virtual function returns always FALSE for digtial IOMs.
    if (TRUE == GetCalibAllState()) {

        return DO_CALIB_IN_PROGRESS;
    }

    // Shutdown the IOM if the new value is ALIVE or FAILED.
    if ((MODSTATUS_ALIVE == ucNewMod1State) || (MODSTATUS_FAIL == ucNewMod1State)) {

        if (ModStat1.Status == MODSTATUS_IDLE) {

            //TraceLog.AddToTrace(TRACEID_GENERIC,bcIdleToAlive);

            // Make sure the FaultOpt values are resetted to UNPOWER so that they will
            // Come as UNPOWERED when Module Reboots in ALIVE Mode

            // Update the FailCode and shutdown IOM.
            FailCode = HF_IOMUSERRESET;
            ShutdownIom();
        }
        else
        {
            return DO_STATE_MUST_BE_IDLE;
        }
    }

    this->ScratchPad = MODSTATUS_NO_TRANS;
    if (ModStat1.Status == MODSTATUS_IDLE) {
        if (ucNewMod1State == MODSTATUS_IDLE) {
            this->ScratchPad  = MODSTATUS_IDLE_IDLE;
        }
        else if (ucNewMod1State == MODSTATUS_RUN) {
            this->ScratchPad  = MODSTATUS_IDLE_RUN;
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcIdleToRun);
        }
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        if (ucNewMod1State == MODSTATUS_IDLE) {
            this->ScratchPad  = MODSTATUS_RUN_IDLE;
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcRunToIdle);
        }
        else if (ucNewMod1State == MODSTATUS_RUN) {
            this->ScratchPad  = MODSTATUS_RUN_RUN;
        }
    }

    //Retain the state of Factory Mode bit when Module state is changed
    if (CheckForFactoryTestMode()) {
        *(UINT8*)a_Writebuffer |= FACTORYMODE_BIT;//Factory Bit
    }

    return PA_OK;
}
/********************************************************************************
*                         clsBoxSlot::PostModStat1                              *
*                         ========================                              *
* PURPOSE:   Post Receiver-Beware function for ModStat1 parameter.  After a     *
*            successfull module status change, this method invokes the Post     *
*            method for Point Execution State parameter (PtExecSt) on each slot.*
*            If there is a module transition from RUN to IDLE or vice versa,    *
*            this generates a module status event.  If the new module state is  *
*            RUN,sets DbValid flag to DB_VALID.                                 *
* ARGUMENTS: a_ucAccLvl      -   Access level for check                         *
* RETURN:    PA_OK           -   If post check is succesfull                    *
* NOTES:     !ToDo! FPGA control on transitions of module status                *
*********************************************************************************/
VOID clsBoxSlot::PostModStat1(UINT8) 
{
    // ANIL_RE_VISIT
    #if 1 //(defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++)
    {
        SLOT(ucSlotNum)->InactivateSlot();
        if(ScratchPad == MODSTATUS_IDLE_RUN) {
            SLOT(ucSlotNum)->ResetLpBkPassCount();
        }
    }
    #endif

    if (ModStat1.Status == MODSTATUS_RUN)
    {
        // Mark the Database to be valid.
        DbValid = DB_VALID; 
    }

    if ((ScratchPad == MODSTATUS_IDLE_RUN) || (ScratchPad == MODSTATUS_RUN_IDLE))
    {
        AddModStatEvent(EVENTTYPE_NORMAL);
#if 0// ANIL_RE_VISIT
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++)
        {
            SLOT(ucSlotNum)->GetHartDevDb().ControlStateChange();
        }
#endif
    }
}
#if 0   // ANIL_RE_VISIT

/*******************************************************************************
*                            clsBoxSlot::PreSyncVer                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsBoxSlot::PreSyncVer(UINT8 *,UINT8) {
    UINT8 ucSlotNum;

    // If this is initial sync and this is the backup module
    // Calculate the normal checksum for all slots
    if ((Data.ucBytes[0] != 0) && (!Iol.AmPrimary())) {
        ComputeCheckSum();
        for (ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            SLOT(ucSlotNum)->ComputeCheckSum();
        }
    }

    // Put the SYNC VERSION in the first byte of SYNCVER
    Data.ucBytes[0] = AO_SYNC_VERSION;

    // Put the next message number in the second byte of SYNCVER
    Data.ucBytes[1] = 1 + MesNo;

    return PA_OK;
}

/*******************************************************************************
*                            clsBoxSlot::PreRedData                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: The database image of REDDATA is comprised of two bytes:              *
*        Byte 1 - REDDATA bits that reflect IOM redundancy status              *
*        Byte 2 - REDSTATE, an enum that indicates the IOM redundancy state    *
*        Writes to REDDATA are always to only one of these values at a time    *
*******************************************************************************/
PASTATUS clsBoxSlot::PreRedData(UINT8 *, UINT8) {
    PASTATUS ucStatus = PA_OK;

    if ((Data.ucBytes[0] == 0 && Data.ucBytes[1] == 0) ||
        (Data.ucBytes[0] != 0 && Data.ucBytes[1] != 0)) {
        ucStatus = DO_ILLEGAL_VALUE;
    }
    else {
        if (Data.ucBytes[1] != 0) {                 // Process Write to REDSTATE
            Data.ucBytes[2] = 0;                    // New RedData for PostRedData
            Data.ucBytes[3] = GetRedState();        // Save old value for PostRedState
            SetRedState(Data.ucBytes[1]);
        }
        else {                                               // Write to REDDATA
            Data.ucBytes[2] = Data.ucBytes[0]; // Save new value for PostRedData
            switch (Data.ucBytes[0] & REDDATA_BITS) {// Validate and set the bits
                case REDDATA_REDCFG_BITNUM:
                    if ((ModlType == MODLTYPE_LLMUX) || (ModlType == MODLTYPE_LLMUX_S8)) {
                        ucStatus = DO_CONFIGURATION_MISMATCH_ERROR;
                        break;
                    }
                case REDDATA_BURQST_BITNUM:
                case REDDATA_SFFOEN_BITNUM:
                case REDDATA_WIGGLE_BITNUM:
                case REDDATA_WIGLSF_BITNUM:
                    UpdateRedData(Data.ucBytes[0]);
                    ucStatus = PA_REDDATA_BYPASS;
                    break;
                default:
                    ucStatus = DO_PARAMETER_INVALID;
                    break;
            }
        }
    }
    return ucStatus;
}

/*******************************************************************************
*                           clsBoxSlot::PostRedData                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::PostRedData(UINT8) {
    switch (Data.ucBytes[2]) {
        case 0:         // If the new RedData is zero then RedState was changed
            break;
        case RDBIT_CLR + REDDATA_BURQST_BITNUM: // If RedData.BuRqst was cleared
        case RDBIT_SET + REDDATA_BURQST_BITNUM: // If RedData.BuRqst was set
        default:
            break;
    }
}

/*******************************************************************************
*                           clsBoxSlot::PreStatReset                           *
*                           =======================                            *
* PURPOSE: Pre Receiver-Beware function for StatReset parameter                *
*                                                                              *
* ARGUMENTS:a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:  PA_OK           -   If pre check is succesfull                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
PASTATUS clsBoxSlot::PreStatReset(UINT8 *a_Writebuffer,UINT8 ) {
    if ((*a_Writebuffer != OFF) && (*a_Writebuffer != ON))
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    return PA_OK;
}

/*******************************************************************************
*                           clsBoxSlot::PostStatReset                          *
*                           ========================                           *
* PURPOSE:   Post Receiver-Beware function for StatReset parameter             *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::PostStatReset(UINT8) {
    //Reset the  Statistics calculated for the Module
    //as operator has set the option to reset all stats calculated
    if (StatReset)
    {
        CpuFreeAvg = 0.0f; //Reset the CPUFreeAverage Parameter
        //Reset the CPUFreeMin Parameter
        CpuFreeMin = 100.0f; //In the beginning the module is approx 100 % free.
        //Reset the  ResetStat Flag to start recalculation
        StatReset = OFF;
    }
}

/*******************************************************************************
*                          clsBoxSlot::PreCPLDRegData                          *
*                          ========================                            *
* PURPOSE:   Pre Receiver-Beware function for CPLDRegData parameter            *
* ARGUMENTS: a_Writebuffer   -   Pointer to the data to be written.             *
*            a_ucAccLvl      -   Access level for check                        *
* RETURN:    PA_OK           -   If pre check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsBoxSlot::PreCPLDRegData(UINT8 *, UINT8) {
    return PA_OK;
}

/*******************************************************************************
*                          clsBoxSlot::PostCPLDRegData                         *
*                          =========================                           *
* PURPOSE:   Post Receiver-Beware function for CPLDRegData parameter           *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::PostCPLDRegData(UINT8) {
}

#endif

/*******************************************************************************
*                           clsBoxSlot::HartLoopBackTest                       *
*                           ============================                       *
* PURPOSE: Tests the Hart modems and UARTS of in Analog Module                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
// ANIL_RE_VISIT
#if 0 //(defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH)) && !LOWCOST
RETURNSTATUS clsBoxSlot::HartLoopBackTest(VOID) {
    static BOOL  sbLoopbackSuccess;
    static UINT8 sucXmtModem,sucXmtChan,sucRcvModem,sucRcvCount,sucPreambleCount;
    static CONTEXT Context = CONTEXT_ZERO;

#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
    static char s_cInputBuffer[SMALL_INPUT_BUFFER_SIZE];
    FLOAT32 fOp;
#endif
#endif

    UINT16 usMuxAddr;
    UINT8  ucCount,ucStatus,ucData;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;

    switch (Context) {
    case CONTEXT_ZERO:
        BOX->SetLpBkStat(LOOPBACK_RUNNING);
        sucXmtModem = 0;
        sucXmtChan  = 0;
        sucRcvModem = 0;
        sucRcvCount = 0;

        TPU2_CST = 0; // Stop HART modem heartbeat timer.
        // Abort HART transaction going on if any
        for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {
            AbortHartConnection(ucCount);
        }
        
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.PrintString("\n\rHART Loopback");
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
        break;
   case CONTEXT_ONE:
#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.PrintString("...OP :");
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
#else //IOMTYPE_AIH
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
        break;
    case CONTEXT_TWO:
#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif  
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
        break;
    case CONTEXT_THREE:
#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        fOp = atof(s_cInputBuffer);
        if (!isnan(fOp) && (fOp >= OP_LOLIMIT) && (fOp <= OP_HILIMIT)) {
            for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {
                BOX->SetOp(ucCount,fOp);
            }
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_INVALID));
            Context = CONTEXT_TEN; // Abort the test.
            RtnSts = RETURNSTATUS_COMPLETE;
        }
#else // RELEASE BUILD in factory mode drive 50% OP
        for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {
            ((clsAohBoxSlot *)pDatabase[0])->SetOp(ucCount,50.0);
        }
#endif
#endif
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_FOUR: // Prepare the hardware for the test.
        HART_MUXENBL.ALL_FOUR = 0; // Disable all four modem/multiplexors.
        for (ucCount = 0; ucCount < HARTMODEM_COUNT; ucCount++) { 
            // Reset modem and UART. This is to avoid the known FPGA problem
            // with break condition that we are working with Xilinx now.
            HART_UART(ucCount).RESET = 1; 
            // Modem control register - Disable RTS.
            HART_UART(ucCount).REQUEST_TO_SEND = 0;
            // Configure UART for 8 bits per character, odd parity and one stop bit.
            HART_UART(ucCount).BITS_PER_CHAR = HART_UART_8BITS_PER_CHAR;
            HART_UART(ucCount).PARITY_ENBL = 1; 
            HART_UART(ucCount).INTR_ENBL_REGISTER = 0;
            HART_UART(ucCount).REQUEST_TO_SEND = 0;
            HART_UART(ucCount).FIFO_ENBL = 1;
            HART_UART(ucCount).XMT_FIFO_CLEAR = 1;
            HART_UART(ucCount).RCV_FIFO_CLEAR = 1;
        }
        // Reprogram baud rate register
        HART_BAUDRATE_REGISTER.LOBYTE = 0xE2;
        HART_BAUDRATE_REGISTER.HIBYTE = 0x04;

#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.PrintString("\n\r  Xmt modem %d chan %d",
                 (sucXmtModem + 1),(sucXmtChan + 1));
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif

        break;
    case CONTEXT_FIVE: // Transmit context.
        usMuxAddr = sucXmtChan;
        for (ucCount = 0; ucCount < (HARTMODEM_COUNT - 1); ucCount++) {
            usMuxAddr <<= HARTMODEM_COUNT;
            usMuxAddr |= sucXmtChan;
        }

        HART_MUXADDR = usMuxAddr;
        IdleWait(1); // Wait one mirco second for the MUX address to settle.
        HART_MUXENBL.ALL_FOUR = HART_ENABLE_ALL_MUXES;

        // Wait for 33 character times (link quiet time) before RTS is asserted.
        ucStatus = get_imask_exr();
        set_imask_exr(LVLPRI_IOPROC);
        for (ucCount = 0; ucCount < HART_PRIMARY_QUIET_TIME; ucCount++) {
            IdleWait(HART_BYTE_TIME);
        }
        set_imask_exr(ucStatus);
        
        HART_UART(sucXmtModem).REQUEST_TO_SEND = 1;
        // Transmit using the test modem
        for (ucCount = 0; ucCount < HART_LOOPBACK_SIZE+2; ucCount++) { 
            if (ucCount < 2) { // Transmit two preamble bytes
                HART_UART(sucXmtModem).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
            }
            else { // Then transmit the loopback test pattern
                HART_UART(sucXmtModem).XMTHOLD_REGISTER = HART_LOOPBACK_PATTERN[ucCount-2];
            }
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_SIX:
        // Wait until all characters are transmitted
        if (HART_UART(sucXmtModem).XMT_COMPLETE == 0) {
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else {
            HART_UART(sucXmtModem).REQUEST_TO_SEND = 0;
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
            RtnSts = DebugPort.PrintString("...done");
#else
            RtnSts = RETURNSTATUS_COMPLETE;
#endif
        }
        break;
    case CONTEXT_SEVEN:
        while (sucRcvModem < HARTMODEM_COUNT){
            if (sucRcvModem == sucXmtModem) { // Do not test the transmit modem
                sucRcvModem++;
                if (HARTMODEM_COUNT == sucRcvModem) {
                    sucRcvModem = 0;
                    Context = CONTEXT_NINE; 
                    RtnSts = RETURNSTATUS_COMPLETE;
                    break;
                }
            }
            // Wait until the carrier drops.
            if (HART_UART(sucRcvModem).CARRIER_DETECT != 0) {
                //RtnSts = RETURNSTATUS_INPROGRESS;
                continue;
            }
            else {
                sucRcvCount = 0;
                sucPreambleCount = 0;
                sbLoopbackSuccess = TRUE;
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                RtnSts = DebugPort.PrintString("\n\r\tChecking modem %d Rcvbuffer",(sucRcvModem+1));
#endif
            }
            while(sucRcvCount < HART_LOOPBACK_SIZE){
                if (HART_UART(sucRcvModem).DATA_READY) {
                    ucStatus = HART_UART(sucRcvModem).LINE_STS_REGISTER;
                    ucData = HART_UART(sucRcvModem).RCVBUF_REGISTER;
                    if ((sucRcvCount == 0) && (HART_LOOPBACK_PATTERN[0] != ucData)) {
                        sucPreambleCount++;
                        if (sucPreambleCount <= 2) {
                            // Wait until loopback pattern begins
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" %x",ucData));
#endif
                            //return RETURNSTATUS_INPROGRESS;//changedTD1
                            continue;
                        }
                        else { // Did not find start of the pattern.
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" %x abort",ucData));
#endif
                            sbLoopbackSuccess = FALSE;
                            Context = CONTEXT_NINE;
                            return RETURNSTATUS_INPROGRESS;
                        }
                    }
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" %x",ucData));
#endif
                    if ((HART_LOOPBACK_PATTERN[sucRcvCount] != ucData) ||
                        (ucStatus & HART_UART_LINE_STS_ERROR_BITS)) {
                        sbLoopbackSuccess = FALSE;
                        Context = CONTEXT_NINE; 
                        return RETURNSTATUS_INPROGRESS;
                    }
                    sucRcvCount++;
                }//DATA_READY
                else {
                        if (sucRcvCount != HART_LOOPBACK_SIZE) {
                            sbLoopbackSuccess = FALSE;
                            Context = CONTEXT_NINE;
                            return RETURNSTATUS_INPROGRESS;
                        }
                }
             }//Rcvcount while loop
            sucRcvModem++;
        }//RcvModem while loop
        if(HARTMODEM_COUNT == sucRcvModem){
            sucRcvModem = 0;
            Context = CONTEXT_NINE; 
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case CONTEXT_NINE:
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        if (TRUE == sbLoopbackSuccess) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" Passed"));
        }
        else 
        {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" Failed"));
        }
#endif
        if(FALSE == sbLoopbackSuccess){
            BOX->SetLpBkStatXmtModem(sucXmtModem);
            BOX->SetLpBkStatRcvModem(sucRcvModem);
            BOX->SetLpBkStatChan(sucXmtChan);
            Context = CONTEXT_TEN; // Exit the test
            RtnSts = RETURNSTATUS_COMPLETE;
            break;
        }
//#endif
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
   case CONTEXT_TEN:
        sucXmtChan++;
        if (MAXSLOTS == sucXmtChan) {
            sucXmtChan = 0;
            sucXmtModem++;
            if (HARTMODEM_COUNT == sucXmtModem) {
                RtnSts = RETURNSTATUS_COMPLETE;
                break;
            }   
        }
        Context = CONTEXT_THREE;
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    default:
        Context = CONTEXT_TEN;
        RtnSts = RETURNSTATUS_COMPLETE;
    }

    if (RtnSts == RETURNSTATUS_COMPLETE) {
        Context = (CONTEXT)((UINT8)Context + 1);
        if (Context > CONTEXT_TEN) {
            //if the test has passed successfully for all channels and modems
            
            if (TRUE == sbLoopbackSuccess){
                BOX->SetLpBkStat(LOOPBACK_SUCCESS);
            }
            HART_MUXENBL.ALL_FOUR = 0; // Disable all four modem/multiplexors.
            
            for (ucCount = 0; ucCount < HARTMODEM_COUNT; ucCount++) { 
                HART_UART(ucCount).INTR_ENBL_REGISTER = 0;
                HART_UART(ucCount).REQUEST_TO_SEND = 0;
                HART_UART(ucCount).XMT_FIFO_CLEAR = 1;
                HART_UART(ucCount).RCV_FIFO_CLEAR = 1;
            }
            HartLoopBkTestInProgress = FALSE;
            Context = CONTEXT_ZERO;
            TPU2_CST = 1; // Restart HART modem heartbeat timer.
            return RETURNSTATUS_COMPLETE;
        }
    }
    return RETURNSTATUS_INPROGRESS;
}
#endif
/*******************************************************************************
*                           clsBoxSlot::FlashHWRevCode()                       *
*                           ============================                       *
* PURPOSE: Writes HWREVCODE and SERIAL_NO into flash in factory mode           *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
#if 1 //ndef DEBUG
BOOL clsBoxSlot::FlashHWRevCode(VOID) {
#if 0 // temp for testing
    UINT8 *ucBufferPtr;
    UINT8 *ModuleInfoTopBufferPtr;
    UINT8 *ModuleInfoBottomBufferPtr;
    volatile UINT8 *ModuleInfoTopFlashPtr  = (UINT8 *)MODULEINFO_START_ADDRESS;//0x00007000
    volatile UINT8 *ModuleInfoBottomFlashPtr = (UINT8 *)(MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1); //0x00007FFF
    UINT8 HwRevCode[sizeof(UINT16)];
    UINT8 SubCommand;
    UINT8 SerialNoPtr[sizeof(UINT32)];
    UINT8 ProductCode[sizeof(UINT16)];
    UINT8 ProductType[sizeof(UINT16)];

    //Get the HWREV CODE from the Rcvr Buffer
    ucBufferPtr = WriteMsgQueue.GetRcvBufPtr();// get ptr to rcv buffer

    SubCommand = ucBufferPtr[IOLREQ_SUBCMD];

    switch (SubCommand){
    case UPDT_HWVER_NO:
        HwRevCode[0] = ucBufferPtr[IOLREQ_HWREVDATA];
        HwRevCode[1] = ucBufferPtr[IOLREQ_HWREVDATA + 1];
        break;
    case UPDT_SERIAL_NO:
        for( UINT8 i= 0 ; i < sizeof(UINT32);i++)
          SerialNoPtr[i] = ucBufferPtr[IOLREQ_SERNO + i];
        break;
    case UPDT_PROD_CODE:
        ProductCode[0] = ucBufferPtr[IOLREQ_PRODCODE];
        ProductCode[1] = ucBufferPtr[IOLREQ_PRODCODE + 1];
        break;
    case UPDT_PROD_TYPE:
        ProductType[0] = ucBufferPtr[IOLREQ_PRODTYPE];
        ProductType[1] = ucBufferPtr[IOLREQ_PRODTYPE + 1]; 
        break;
    default:
        return FALSE;
    }

    //Since the Digital Module do not have memory, the write message queue memory
    //is utilized. Since this module is rebooted after the operation, this approach
    //should not have any adverse effect.
    ucBufferPtr = WriteMsgQueue.GetMsgBufferPtr();// get ptr to Write Messege Queue
    ModuleInfoTopBufferPtr = ucBufferPtr;
    //Top buffer should be at least 10+256+16 bytes. Therefore Bottom buffer starts 
    //after 384bytes (3*128).
    ModuleInfoBottomBufferPtr = ucBufferPtr + (3*FLASH_PROGRAM_BLOCK_SIZE);

    //Copy the data from ModuleInfoTop Block
    ucBufferPtr = ModuleInfoTopBufferPtr;
    for (UINT16 ucCount = 0; ucCount < (3*FLASH_PROGRAM_BLOCK_SIZE); ucCount++){
        *ucBufferPtr = *ModuleInfoTopFlashPtr;
        ucBufferPtr++;
        ModuleInfoTopFlashPtr++;
    }


    //Copy the data from ModuleInfo Bottom Block
    ucBufferPtr = ModuleInfoBottomBufferPtr;
    for (UINT8 ucCount = 0; ucCount < FLASH_PROGRAM_BLOCK_SIZE; ucCount++){
        *ucBufferPtr = *ModuleInfoBottomFlashPtr;
        ucBufferPtr++;
        ModuleInfoBottomFlashPtr++;
    }        

    // Fill the data received in the top of the module info block.
    ucBufferPtr = ModuleInfoTopBufferPtr;
    switch (SubCommand){
    case UPDT_HWVER_NO:
        ucBufferPtr += HWREV_CODE_ADDR_OFFSET;
        *((UINT8*)ucBufferPtr) = HwRevCode[0];
        ucBufferPtr++;
        *((UINT8*)ucBufferPtr) = HwRevCode[1];
        break;
    case UPDT_SERIAL_NO:
        ucBufferPtr += HW_SL_NO_ADDR_OFFSET;
        for( UINT8 i= 0 ; i < sizeof(UINT32);i++){
            *((UINT8 *)ucBufferPtr) = SerialNoPtr[i];
            ucBufferPtr++;
        }
        break;
    case UPDT_PROD_CODE:
        ucBufferPtr += HW_PROD_CODE_OFFSET;
        *((UINT8*)ucBufferPtr) = ProductCode[0];
        ucBufferPtr++;
        *((UINT8*)ucBufferPtr) = ProductCode[1];
        break;
    case UPDT_PROD_TYPE:
        ucBufferPtr += HW_PROD_TYPE_OFFSET;
        *((UINT8*)ucBufferPtr) = ProductType[0];
        ucBufferPtr++;
        *((UINT8*)ucBufferPtr) = ProductType[1];
        break;
    default:
        return FALSE;
    }

    // Fill information at the bottom of module info block.
    ucBufferPtr = ModuleInfoBottomBufferPtr + FLASH_PROGRAM_BLOCK_SIZE - CRC_LOC_OFFSET;
    *((UINT16 *)ucBufferPtr) = 0; // Replace this CRC value later.


    //MODULEINFO_WRITE_FLAGS 
    ucBufferPtr+=sizeof(UINT16);
    *((UINT16 *)ucBufferPtr) = MODULINFO_WRITE_COMPLETE;

    // Program number of times module info section is programmed.
    ucBufferPtr+=sizeof(UINT16);
    *((UINT16 *)ucBufferPtr) =  MODULEINFO_WRITECOUNT + 1;
    if (0 == *((UINT16 *)ucBufferPtr)) {
        *((UINT16 *)ucBufferPtr) = 1;
    }


    if (EraseFlash(MODULE_INFO_FLASH_BLOCK)) {
#if H8S_2319C
        if (ProgramFlash(MODULEINFO_START_ADDRESS,ModuleInfoTopBufferPtr)) {
#else
        if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS,ModuleInfoTopBufferPtr)) {
#endif
#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP)|| defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
            if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS + FLASH_PROGRAM_BLOCK_SIZE,
                ModuleInfoTopBufferPtr + FLASH_PROGRAM_BLOCK_SIZE)) {
                if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS + 2*FLASH_PROGRAM_BLOCK_SIZE,
                    ModuleInfoTopBufferPtr + 2*FLASH_PROGRAM_BLOCK_SIZE)) {
#endif
#if H8S_2319C
                    if (ProgramFlash((MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1),
                        ModuleInfoBottomBufferPtr)) {
#else
                    if (ProgramFlash((UINT8 *)(MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1),
                        ModuleInfoBottomBufferPtr)) {
#endif
                        return TRUE;
                    }
#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_SVP)||defined(IOMTYPE_SP)|| defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
                }
            }
#endif
        }
    }
#endif // temp for testing
    return FALSE;
}
#endif //#ifndef DEBUG

/*******************************************************************************
*                                    isOddParity                               *
*                                    ===========                               *
* PURPOSE   : Test for odd no of 1's in a binary number.                       *
* ARGUMENTS : UINT8 - variable to be tested.                                   *
* RETURN    : TRUE if the variable is ODD, else FALSE.                         *
* NOTES     :                                                                  *
*******************************************************************************/
BOOL clsBoxSlot::isOddParity(UINT8 ucBinary)
{
    BOOL bParity = 0;

    while (ucBinary)
    {
        bParity = !bParity;

        ucBinary &= (ucBinary - 1);
    }

    return bParity;
}

/*******************************************************************************
*                              SetFactoryTestMode                              *
*                              ==================                              *
* PURPOSE   : Check factory test hardware and set factory test bit accordingly *
* ARGUMENTS : NONE                                                             *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsBoxSlot::SetFactoryTestMode(VOID)
{
    UINT8 iotabits = Fpga.GetIotaRegister();

    ModStat1.Factory = 0;

    // if FPGA_IOTA_REDUNT_n=1 (FTA missing), BOTTOM=0 (IOPB) & BUPREQ_IN=0(SWITCHED=0), set IOP in Factory Test Mode.
    if ((TRUE  == (iotabits & FPGA_IOTA_REDUNT_n))      // FTA missing
    &&  (FALSE == (iotabits & FPGA_IOTA_BOTTOM))        // IOP is on bottom (IOPB)
    &&  (FALSE == (iotabits & FPGA_IOTA_BUPREQ_IN))) {  // Backup request is not asserted
        
        ModStat1.Factory = 1;
    }
}

// added to fix following issue, 
// Backup failed to retain the db upon power cycle, when the primary is loaded first and then backup inserted later.
// Hence storing the database into xRAM, when primary dumps the database during sync operation.
VOID clsBoxSlot::StoreDatabase(UINT8 ucSlotNum, BOOL bForce)
{
    static BOOL bLastStoredBoxSlot = FALSE;
    static UINT32 ulLastStoredSlot = 0;

    if (!Iol.AmPrimary())
    {
        // Reset last stored flags, immediately after syncing with primary
        if (TRUE == bForce) {
            bLastStoredBoxSlot = FALSE;
            ulLastStoredSlot = 0;
        }
        else {
            // store boxslot database into xRAM
            if (ucSlotNum == 0 && !bLastStoredBoxSlot) {

                BOX->PmioCheckPointRestore(TRUE);

                bLastStoredBoxSlot = TRUE;
            }
            // store slot database into xRAM
            else if ((ucSlotNum < MAXSLOTS) && !(ulLastStoredSlot & (1 << ucSlotNum))) {

                pDatabase[ucSlotNum]->PmioCheckPointRestore(TRUE);

                ulLastStoredSlot |= (1 << ucSlotNum);
            }
        }
    }
}

