/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohardware.cpp                                              *
*    Description : Analog output hardware encapsulation.                       *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aohardware.hpp"
#include "aohslot.hpp"
#include "aohboxslot.hpp"
#include "fsl_lpspi.h"
#include "diag.h"

/*******************************************************************************
*                        clsAoHardware::clsAoHardware                          *
*                        ============================                          *
* PURPOSE:                                                                     *
*    Sets the SPI interface and transfers the DAC Word                         *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
clsAoHardware::clsAoHardware(VOID)
{
    // LPSPI4 is initialised in Init(), after BOARD_InitBootClocks() has run.
    // This global object is constructed before main(), and clock_config.c
    // gates the LPSPI4 clock later.
}

VOID clsAoHardware::Init(VOID)
{
    lpspi_master_config_t config;

    CLOCK_EnableClock(kCLOCK_Lpspi4);

    LPSPI_MasterGetDefaultConfig(&config);
    config.baudRate                      = DAC_SPI_BAUDRATE;
    config.cpol                          = kLPSPI_ClockPolarityActiveHigh;   /* CPOL=0 */
    config.cpha                          = kLPSPI_ClockPhaseFirstEdge;       /* CPHA=0 */
    config.direction                     = kLPSPI_MsbFirst;
    config.whichPcs                      = DAC_SPI_PCS;
    config.pcsActiveHighOrLow            = kLPSPI_PcsActiveLow;
    config.pcsToSckDelayInNanoSec        = 100u;
    config.lastSckToPcsDelayInNanoSec    = 100u;
    config.betweenTransferDelayInNanoSec = 200u;

    LPSPI_MasterInit(DAC_SPI_BASE, &config, DAC_SPI_CLOCK_FREQ);

#if 0 // ANIL_RE_VISIT
    DacByte.DAC.Commmand = LD_INPUT_AND_DAC_REG;
    DacByte.DAC.SubBit   = 0;
    DacByte.DAC.Count    = 0;

 //   SPIRESET = 0x1;

    //Initialize the Global Interrupt Enable for SPI Interface access
    DAC_SPI.IGER = 0x80;
    //Initialize the Individual Interrupt Enable for SPI Interface access
    DAC_SPI.IER = 0x00;//no interrupts enabled 

    //Write into the SPI Control register:low byte
    // Bit No ------- Functionality     
    //--------------------------------------------   
    // 7: Manual SS Assertion Enable : "1"
    // 6:
    // 5:
    // 4:
    // 3:
    // 2:Master Setting             : "1"
    // 1:SPI System Enable          : "1"
    // 0:  
    DAC_SPI.CRL = 0x86;
    //Write into the SPI Control register:high byte
    // Bit No ------- Functionality     
    //--------------------------------------------   
    // 7: Master Transaction Inhibit : "0"
    // 6:
    // 5:
    // 4:
    // 3:
    // 2:
    // 1:
    // 0:  
    DAC_SPI.CRH = 0x00; 

    //Write into the SPI Slave Select register:
    // Bit No ------- Functionality     
    //--------------------------------------------   
    // 7: 
    // 6:
    // 5:
    // 4:
    // 3:
    // 2:
    // 1:
    // 0:Select slave CSEL0_n :    "1"
    DAC_SPI.SSR = 0xFF; 
#endif
}
/*******************************************************************************
*                           clsAoHardware::DriveDac                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::DriveDac(UINT16 a_uiDacCount) {
    // Form 16-bit DAC word, MSB first: Command[15:13], Count[12:1], SubBit[0].
    UINT16 uiWord = (UINT16)(((UINT16)LD_INPUT_AND_DAC_REG << 13) | ((a_uiDacCount & 0x0FFF) << 1));

    // Flush FIFOs and clear status.
    DAC_SPI_BASE->CR |= LPSPI_CR_RTF_MASK | LPSPI_CR_RRF_MASK;
    DAC_SPI_BASE->SR = kLPSPI_AllStatusFlag;

    // Assert slave select (PCS0), keep it asserted across both bytes.
    DAC_SPI_BASE->TCR = (LPSPI_GetTcr(DAC_SPI_BASE) & (~LPSPI_TCR_PCS_MASK)) | LPSPI_TCR_PCS((UINT8)DAC_SPI_PCS);
    DAC_SPI_BASE->TCR = LPSPI_GetTcr(DAC_SPI_BASE) | LPSPI_TCR_CONT_MASK;

    // TCR shares the TX FIFO, so wait for it to be consumed.
    while (((DAC_SPI_BASE->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT) != 0) { }

    DAC_SPI_BASE->TDR = (UINT8)(uiWord >> 8);   // Transmit DAC byte 0 (MSB)
    DAC_SPI_BASE->TDR = (UINT8)(uiWord & 0xFF); // Transmit DAC byte 1 (LSB)

    // Release PCS once all data is pushed to the FIFO.
    DAC_SPI_BASE->TCR = LPSPI_GetTcr(DAC_SPI_BASE) & ~LPSPI_TCR_CONT_MASK;

    // Wait until all transmit data is sent.
    while (((DAC_SPI_BASE->FSR & LPSPI_FSR_TXCOUNT_MASK) >> LPSPI_FSR_TXCOUNT_SHIFT) != 0) { }
    while (0u == (DAC_SPI_BASE->SR & LPSPI_SR_TCF_MASK)) { }

    // Discard received bytes.
    DAC_SPI_BASE->CR |= LPSPI_CR_RRF_MASK;

    IdleWait(DAC_SETTLE_TIME);
}
/*******************************************************************************
*                         clsAoHardware::DriveOutput                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::DriveOutput(UINT8 a_ucSlotNum, DELAY_TYPE a_eDelayType)
{
    // First of all block execution of loopback test.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    UINT16 uiDacCount = ((clsAohSlot *)pDatabase[a_ucSlotNum])->GetOutDACImg();
    DriveDac(uiDacCount);

    // Open output mux channel.
    UINT8 ucChanAddr = a_ucSlotNum - 1;

    // Block all interrupts during MUX channel selection 
    // so that UKEY monoshot will not expire.
    // NOTE : It is important to keep ALL the interrupts disabled until
    // the MUX is enabled. Both address selection and enabling of the MUX
    // take place in one UKEY trigger. The channel settle time is only one 
    // micro second and this is not expected to affect IOL operation. It was
    // observed that if IOL interrupt was enabled for the one micro second 
    // duration for which we wait for MUX channel settling, the MUX enabling
    // could fail some times. This happens if the IOL interrupt took exact
    // amount of time as the UKEY pulse time (40 micro second) and when it 
    // returned the UKEY pulse was terminating. Even having a second UKEY
    // trigger will not solve the problem as the UKEY is not retriggerable.
    set_imask_exr(LVLPRI_HIGHEST);
    hal_fpga_write(FPGA_UKEY, 1); // Trigger oneshot.
    hal_fpga_write(FPGA_OUTSEL, ucChanAddr); // Drive address lines D3 to D0.
    IdleWait(MUX_CHANNELSEL_SETTLE_TIME);
    ucChanAddr |= MUX_ENABLE;
    hal_fpga_write(FPGA_OUTSEL, ucChanAddr); // Enable or open MUX channel.
    set_imask_exr(LVLPRI_TICK);

    // Readback and test MUX channel selection.
    if ((hal_fpga_read(FPGA_OUTSEL) & OUTPUT_ADDRESS_READBACK_MASK) != ucChanAddr) {
        HardFail(HF_BD_OUTPUT_MUX,AOHARDWARE_CPP,__LINE__);
    }

    UINT16 usIteration = 1;
    UINT16 usCapChargeTime = DEFAULT_OUTPUT_CAPACITORCHARGE_TIME;
    switch (a_eDelayType) {
        case CalibrationWithExtendedDelay : //100 ms
            // Allow STC when waiting for extended delay so that watchdog refresh
            // will take place. There is no issue with the loopback as extended delay
            // is called only during calibration when the loopback is anyway disabled.
            set_imask_exr(LVLPRI_IOPROC);
            usIteration = 10; //10 times 10 ms. This mechanism avoids overflow of UINT16
            usCapChargeTime = CALIBRATION_EXTENDED_CAPACITORCHARGE_TIME;
            break;
        case CalibrationWithMinimumDelay:   //150 us
            usIteration = 1;
            usCapChargeTime = CALIBRATION_MINIMUM_CAPACITORCHARGE_TIME;
            break;
        case NormalOutput:  // ANIL_RE_VISIT This case is not required as it is already initialized to default values. But keeping it for clarity.
             break;
    }

    do { IdleWait(usCapChargeTime); } while(--usIteration);

    ucChanAddr &= ~MUX_ENABLE;
    // Block all interrupts again for protecting UKEY trigger.
    set_imask_exr(LVLPRI_HIGHEST);
    hal_fpga_write(FPGA_UKEY, 1); // Trigger oneshot.
    hal_fpga_write(FPGA_OUTSEL, ucChanAddr); // Disable or close mux channel.

    // Restore original interrupt mask.
    set_imask_exr(ucSaveExr);
}

/*******************************************************************************
*                    clsAoHardware::OpenLoopbackMux                            *
*                    ==============================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::OpenLoopbackMux(UINT8 a_ucSlotNum, BOOL bProcSF)
{
    UINT8 ucChan = LOOPBACK_ADDRESS[a_ucSlotNum - 1];
    hal_fpga_write(FPGA_INPSEL, ucChan); // Drive address lines 
    IdleWait(MUX_CHANNELSEL_SETTLE_TIME); // Wait 1 micro second

    UINT8 ucRetryCount;
    for (ucRetryCount = 0; ucRetryCount < MUX_READBACK_RETRYCOUNT; ucRetryCount++) {
        if ((hal_fpga_read(FPGA_INPSEL) & LOOPBACK_ADDRESS_READBACK_MASK) == ucChan ) break;
        hal_fpga_write(FPGA_INPSEL, ucChan); // Enable or open MUX channel.
    }
    if (bProcSF) {
        ((clsAohBoxSlot *)pDatabase[0])->AddSoftfailEvent(
        EVENTTYPE_NORMAL,SF_DIAGCTFL,(MUX_READBACK_RETRYCOUNT == ucRetryCount),0);
    }
    IdleWait(LOOPBACK_COMPARATORSETTLE_TIME - DAC_SETTLE_TIME);
    return (MUX_READBACK_RETRYCOUNT == ucRetryCount);
}
/*******************************************************************************
*                               ReadComparatorOutput                           *
*                               ====================                           *
* PURPOSE:                                                                     *
*                                                                              *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::ReadComparatorOutput(VOID) {
    const UINT8 _MAX_READINGS_ = 3;
    UINT8 ucRdbk = 0;
    for (UINT8 ucCount = 0; ucCount < _MAX_READINGS_; ucCount++)
    {
#if 0  // ANIL_RE_VISIT
        if (ANALOG_RDBK) ucRdbk++; // If bit is set, increment the count
#endif
        IdleWait(1); // Wait for 1 microsec
    }
    return (ucRdbk >= 2);
}

/*******************************************************************************
*                     GetSwitchStatus                                          *
*                     ================                                         *
* PURPOSE:                                                                     *
*       Reads the CPLD switch register and returns the switch status           *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*          UINT8 value indicates switch status                                 *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAoHardware::GetSwitchStatus(SWITCH_TYPE eswtype)
{
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_IOL);
    UINT8 ucTemp = 0x00,ucRetryCntr;
    for (ucRetryCntr=3; ucRetryCntr>0; ucRetryCntr--)
    {
#if 0   // ANIL_RE_VISIT
        switch(eswtype)
        {
        case DIS_SWCH:
            if(OP_DISA_FB_n)
                ucTemp = ucTemp | DIS_SWA_SET;
            if(OP_DISB_FB1_n)
                ucTemp = ucTemp | DIS_SWB1_SET;
            if(OP_DISB_FB2_n)
                ucTemp = ucTemp | DIS_SWB2_SET;
            break;
        case TST_SWCH:
            if(TST)
                ucTemp = ucTemp | TST_SET;
            break;
        case INH_SWCH:
            if(INHST2_FB)
                ucTemp = ucTemp | INH_SWA_SET;
            if(INHST1_FB1)
                ucTemp = ucTemp | INH_SWB1_SET;
            if(INHST1_FB2)
                ucTemp = ucTemp | INH_SWB2_SET;
            break;
        }
#endif
    }
    set_imask_exr(ucSaveExr);
    return ucTemp;
}

/*******************************************************************************
*                     VerifySwitchState                                        *
*                     =================                                        *
* PURPOSE:                                                                     * 
*      Reads the current status of the switches,compares it with whats expected*
*      status,if a mismatch is found the state of the switch is modified with  *
*      expected switch state                                                   *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAoHardware::VerifySwitchState(SWITCH_TYPE eswtype,UINT8 a_ucSwitchState)
{
    UINT8 ucFailure = 0;
#if 0   // ANIL_RE_VISIT
    UINT8 ucCountOuter, ucCountInner, ucFailure = 0;
    for (ucCountOuter=3; ucCountOuter>0; ucCountOuter--)
    {
        switch(eswtype){
        case DIS_SWCH:
            ucFailure = 1;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--)
            {
                if (a_ucSwitchState == GetSwitchStatus(DIS_SWCH))
                {
                    return; 
                }
            }

            if (a_ucSwitchState == DIS_ON_ON)
            {
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_ON;
            }
            else if (a_ucSwitchState == DIS_ON_OFF)
            {
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_OFF;
            }
            else if (a_ucSwitchState == DIS_OFF_ON)
            {
                DIS_SWA_n = SW_OFF;
                DIS_SWB_n = SW_ON;
            }
            else if (a_ucSwitchState == DIS_OFF_OFF)
            {
                DIS_SWA_n = SW_OFF;
                DIS_SWB_n = SW_OFF;
            }

            IdleWait(DIS_READ_DELAY_TIME);
            break;
        case TST_SWCH:
            ucFailure = 2;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
                if (a_ucSwitchState == GetSwitchStatus(TST_SWCH)) {
                    return; 
                }
            }
            //Set the switch to desired state
            TST_n = (a_ucSwitchState == TST_DISABLED) ? TSTn_DISABLED : TSTn_ENABLED;
            IdleWait(TST_READ_DELAY_TIME);
            break;
            
        case INH_SWCH:
            ucFailure = 3;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
                if (a_ucSwitchState == GetSwitchStatus(INH_SWCH)) {
                    return;
                }
            }

            if (a_ucSwitchState == INH_ON_ON) {
                INH_SWB = SW_ON;
                INH_SWA = SW_ON;
            }
            else if (a_ucSwitchState == INH_ON_OFF) {
                INH_SWB = SW_ON; 
                INH_SWA = SW_OFF;
            }
            else if (a_ucSwitchState == INH_OFF_ON) {
                INH_SWB = SW_OFF;
                INH_SWA = SW_ON;
            }
            else if (a_ucSwitchState == INH_OFF_OFF) {
                INH_SWA = SW_OFF;
                INH_SWB = SW_OFF;
            }
            IdleWait(INH_READ_DELAY_TIME);
            break;
        }//switch loop
    }//Outer For loop 
#endif
    // 2. added redundant state condition checking to fix PAR,
    //    PAR# 1-DYD1PEV (NR/Satus led RED during removal & reinsertion of IOLink cable A & B of primary)
    // 1. added to resolve, PAR# 1-7LC52TF (NR /Status RED Led Issue)
    //    if FTA missing or Secondary & just got BackupRequest from PRI  
    if ((FtaStatus() != FTA_RETURN_AND_TOUT) ||
        // PAR# 1-DYD1PEV fix - (NR/Status RED Led during removal & reinsertion of IOLink cable A & B of Primary)
        (REDSTATE_IOL_TIMEOUT != BOX->GetRedState()) ||
       ((OUTCTL_PARTNER == BOX->GetModStat3()) && (BUPREQ_IN)))
    {
        return;
    }
    // If the check and overwrite fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL, AOHARDWARE_CPP, __LINE__, ucFailure);
}

/*******************************************************************************
*                             InhibitSwitchDiagnostics                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Inhibit Switch Diagnostics                                                *
* ARGUMENTS:                                                                   *
*    UINT8 ucSubContext                                                        *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    Only one output is changed per diagnostic state and then it is checked in *
*    in the next diagnostic state to confirm the change occurred.              *
*    N.B.: ONLY ONE INH_SW is allowed to be ON during any diagnostic state.    *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::InhibitSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bInhswDiagSts = TRUE;
#if 0   // ANIL_RE_VISIT
    UINT8 ucSaveExr =get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State()) {
        bInhswDiagSts = FALSE;
        switch(ucSubContext){
            case CONTEXT_ZERO:
                INH_SWB = SW_ON;
                bInhswDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(INH_ON_OFF == GetSwitchStatus(INH_SWCH)) {
                    bInhswDiagSts = TRUE;
                    INH_SWB = SW_OFF;
                }
                break;
            case CONTEXT_TWO:
                if(INH_OFF_OFF == GetSwitchStatus(INH_SWCH)) {
                    bInhswDiagSts = TRUE;
                    TST_n = TSTn_ENABLED;
                }
                break;
            case CONTEXT_THREE:
                if(TST_ENABLED == GetSwitchStatus(TST_SWCH)) {
                    bInhswDiagSts = TRUE;
                    INH_SWA = SW_ON;
                }
                break;
            case CONTEXT_FOUR:
                if(INH_OFF_ON_TST_ON == GetSwitchStatus(INH_SWCH))    {
                    bInhswDiagSts = TRUE;
                    INH_SWA = SW_OFF; 
                }
                break;
            case CONTEXT_FIVE:
                if(INH_OFF_OFF_TST_ON == GetSwitchStatus(INH_SWCH)) {
                    bInhswDiagSts = TRUE;
                    TST_n = TSTn_DISABLED; 
                }
                break;
            case CONTEXT_SIX:
                if(TST_DISABLED == GetSwitchStatus(TST_SWCH))
                    bInhswDiagSts = TRUE;
                break;
        }
    }
    set_imask_exr(ucSaveExr);
#endif
    return bInhswDiagSts;
}


/*******************************************************************************
*                             TestSwitchDiagnostics                            *
*                             =====================                            *
* PURPOSE:                                                                     *
*    Test Switch Diagnostics                                                   *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    This control output is changed once per diagnostic state and then it is   *
*    checked in the next diagnostic state to confirm the change occurred.      *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::TestSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bTstswDiagSts = TRUE;
#if 0   // ANIL_RE_VISIT
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State()) {
        bTstswDiagSts = FALSE;
        switch(ucSubContext) {
            case CONTEXT_ZERO:
                TST_n = TSTn_ENABLED;
                bTstswDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(TST_ENABLED == GetSwitchStatus(TST_SWCH)) {
                    bTstswDiagSts = TRUE;
                    TST_n = TSTn_DISABLED;
                }
                break;
            case CONTEXT_TWO:
                if(TST_DISABLED == GetSwitchStatus(TST_SWCH)) {
                    bTstswDiagSts = TRUE;
                }
                break;
        }
    }
    set_imask_exr(ucSaveExr);
#endif
    return bTstswDiagSts;
}


/*******************************************************************************
*                             DisableSwitchDiagnostics                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Disable Switch Diagnostics                                                *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    Only one output is changed per diagnostic state and then it is checked in *
*    in the next diagnostic state to confirm the change occurred.              *
*    N.B.: ONLY ONE DIS_SW is allowed to be ON during any diagnostic state.    *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::DisableSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bDisSwDiagSts = TRUE;
    UINT8 ucSaveExr =get_imask_exr();
    set_imask_exr(LVLPRI_IOL);
    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
#if 0   // ANIL_RE_VISIT
    if(OUTCTL_PARTNER == BOX->GetModStat3State())
    {
        bDisSwDiagSts = FALSE;
        switch(ucSubContext) {
            case CONTEXT_ZERO:
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_OFF;
                bDisSwDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(DIS_ON_OFF == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_OFF;
                }
                break;
            case CONTEXT_TWO:
                if(DIS_OFF_OFF == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_ON;
                }    
                break;
            case CONTEXT_THREE:
                if(DIS_OFF_ON == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_OFF;
                }
                break;
            case CONTEXT_FOUR:
                if(DIS_OFF_OFF == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;  
                }
                break;
        }
    }
#endif
    set_imask_exr(ucSaveExr);
    return bDisSwDiagSts;
}





