/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iol.cpp                                                     *
*    Description : IOL Interface object source file.                           *
*                                                                              *
*    Converted from Renesas H8S/2329 -> NXP LPC1763 -> NXP iMXRT1024.          *
*    - All UART I/O via IOL_WriteByte/ReadByte/etc. wrappers                   *
*      (armsrc precedent; RT1024 maps to HAL LPUART in commonelectronics.h)    *
*    - ISR architecture: extern "C" handlers with friend access (armsrc)       *
*    - Timer: SilenceTimer helpers (armsrc); maps to HAL_TIMER_IOL_SIL         *
*    - GPIO: SetTXREQ_n/SetCLR_GHL_n wrappers (armsrc); maps to HAL GPIO       *
*    - Stripped to AOH-only (no DISOE/DO/LLMUX/SVP/SP/PI/UIO conditionals)     *
*    - Removed S3 FPGA/SCI2 dual-UART paths                                    *
*    - BRDP (HART pass-through) handlers preserved for AOH                     *
*******************************************************************************/

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "iol.hpp"
#include "utils.h"

#include "fsl_debug_console.h"
#include <cstdlib>

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern BOOL FactryModeWDTUTest;
extern BOOL FactryModeJabberTest;
extern BOOL HartLoopBkTestInProgress;
extern BOOL HWRevCodeWriteInProgress;

#if 0   // ANIL_RE_VISIT

    extern clsHartPst *pHartPst[];
    extern UINT8 g_ucHPstReqBuffer[HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];

    bool bHartDataDump;
#endif // ANIL_RE_VISIT
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
clsIol Iol;

#define IOL_DIAG_COLLECT 0
#ifndef IOL_RX_KICK_AFTER_TX
#define IOL_RX_KICK_AFTER_TX 1
#endif
#ifndef IOL_CLEAR_XMIT_LEN_ON_RX
#define IOL_CLEAR_XMIT_LEN_ON_RX 1
#endif

volatile IOLDIAGSTATE g_IolDiag = {0};

#if IOL_DIAG_COLLECT
static inline void IolDiagCaptureState(void)
{
    g_IolDiag.lastStat = IOLINK_UART_BASEADDR->STAT;
    g_IolDiag.lastCtrl = IOLINK_UART_BASEADDR->CTRL;
}
#endif

const CMDINFO clsIol::aCmdInfo[] = {
    {0x04,0x00,&clsIol::DefaultHandler},   // 00 Null
    {0x08,0x04,&clsIol::Cmd01Handler},     // 01 Block Read Absolute
    {0x00,0x00,&clsIol::DefaultHandler},   // 02 Not Supported
    {0x08,0x05,&clsIol::Cmd0AHandler},     // 03 Block Write Absolute
    {0x07,0x05,&clsIol::Cmd04Handler},     // 04 Read Indexed Deferred
    {0x00,0x00,&clsIol::DefaultHandler},   // 05 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 06 Not Supported
    {0x05,0x05,&clsIol::Cmd07Handler},     // 07 Get Deferred Message Status
    {0x06,0x05,&clsIol::Cmd08Handler},     // 08 Read
    {0x00,0x00,&clsIol::DefaultHandler},   // 09 Not Supported
    {0x09,0x05,&clsIol::Cmd0AHandler},     // 0A Write
    {0x05,0x05,&clsIol::Cmd0BHandler},     // 0B Read Deferred Message Response
    {0x0A,0x05,&clsIol::Cmd0CHandler},     // 0C Write Indexed Deferred
    {0x00,0x00,&clsIol::DefaultHandler},   // 0D Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 0E Not Supported
    {0x04,0x05,&clsIol::Cmd0FHandler},     // 0F Dump
    {0x07,0x05,&clsIol::Cmd10Handler},     // 10 Read Indexed
    {0x00,0x00,&clsIol::DefaultHandler},   // 11 Not Supported
    {0x0A,0x05,&clsIol::Cmd0AHandler},     // 12 Write Indexed
    {0x00,0x00,&clsIol::DefaultHandler},   // 13 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 14 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 15 Not Supported
    {0x04,0x08,&clsIol::Cmd16Handler},     // 16 Collect ECL
    {0x04,0x05,&clsIol::Cmd17Handler},     // 17 Get ECL Status
    {0x04,0x00,&clsIol::BroadcastHandler}, // 18 Reserved Broadcast
    {0x00,0x00,&clsIol::DefaultHandler},   // 19 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1A Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1B Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1C Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 1D Not Supported
    {0x04,0x08,&clsIol::DefaultHandler},   // 1E Collect PCL
    {0x05,0x05,&clsIol::Cmd1FHandler},     // 1F Get Write Message Status
    {0x05,0x04,&clsIol::Cmd20Handler},     // 20 Tog Refresh
    {0x00,0x00,&clsIol::DefaultHandler},   // 21 Not Supported
    {0x00,0x05,&clsIol::DefaultHandler},   // 22 NACK
    {0x00,0x00,&clsIol::DefaultHandler},   // 23 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 24 Not Supported
    {0x04,0x04,&clsIol::Cmd25Handler},     // 25 Regenerate Events
    {0x06,0x04,&clsIol::Cmd26Handler},     // 26 Update Event Remove Pointer
    {0x00,0x00,&clsIol::DefaultHandler},   // 27 Not Supported
    {0x05,0x04,&clsIol::Cmd28Handler},     // 28 Assign DSA
    {0x06,0x00,&clsIol::BroadcastHandler}, // 29 Time Sync
    {0x05,0x04,&clsIol::Cmd2AHandler},     // 2A Assign BA
    {0x00,0x00,&clsIol::DefaultHandler},   // 2B Not Supported
    {0x04,0x04,&clsIol::Cmd2CHandler},     // 2C Select Channel A
    {0x04,0x04,&clsIol::Cmd2DHandler},     // 2D Select Channel B
    {0x06,0x04,&clsIol::DefaultHandler},   // 2E Update PV Change Remove Pointer
    {0x04,0x05,&clsIol::Cmd2FHandler},     // 2F Freeze Database
    {0x00,0x00,&clsIol::DefaultHandler},   // 30 Not Supported
    {0x00,0x00,&clsIol::DefaultHandler},   // 31 Not Supported
    {0x04,0x04,&clsIol::Cmd32Handler},     // 32 Reset Communication Errors
    {0x08,0x04,&clsIol::Cmd33Handler},     // 33 Test Hardware Functions
    {0x00,0x00,&clsIol::DefaultHandler},   // 34 Not Supported
    {0x04,0x04,&clsIol::Cmd35Handler},     // 35 Wiggle
    {0x00,0x00,&clsIol::BroadcastHandler}, // 36 Reserved Broadcast
    {0x04,0x04,&clsIol::Cmd37Handler},     // 37 Unfreeze Database
    {0x00,0x00,&clsIol::BroadcastHandler}, // 38 Reserved Broadcast
    {0x00,0x00,&clsIol::DefaultHandler},   // 39 Not Supported
    {0x00,0x00,&clsIol::BroadcastHandler}, // 3A Reserved Broadcast
    {0x00,0x00,&clsIol::DefaultHandler},   // 3B Not Supported
    {0x00,0x00,&clsIol::BroadcastHandler}  // 3C Reserved Broadcast
};
// Define the largest command number processed by the aCmdInfo table.
const UINT8 clsIol::LastCommand = (sizeof (aCmdInfo) / sizeof (CMDINFO)) - 1;

/*******************************************************************************
*                       clsIol::clsIol                                         *
*                       ==============                                         *
* PURPOSE:                                                                     *
*    Constructor \u2014 initialise IOL communication object.                   *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    RT1024 CHANGES: UART I/O replaced with HAL calls.                         *
*******************************************************************************/
clsIol::clsIol(VOID)
{
    // initialize variables
    ChecksumHi  = 0;
    ChecksumLo  = 0;
    ucIolId     = 0xFF;
    ucIolBA     = 0;
    ucIolDPA    = 0;
    ucIolDSA    = 0;
    ucLastDSA   = 0;
    ucMsgNumber = 0;
    ucIdxDump   = 0;
    nCharProcd  = 0;
    txStopCount = 0;
    txActive    = FALSE;
    pRcvBuffer  = NULL;
    ucDest      = 0;
    ucNumber    = 0;
    ucCommand   = 0;
    bCommError  = FALSE;
}

VOID clsIol::DropReceiveUntilNextAddress(VOID)
{
    ChecksumHi = 0;
    ChecksumLo = 0;
    pRcvBuffer[IOLMSG_NUMBER] = 0;
}

/*
 *
 */
VOID clsIol::Enable(VOID) {

    static const hal_uart_config_t IolUartConfig = {
            IOL_BAUDRATE,    // 375 Kbps
                       8,    // data bits
                       2,    // stop bits
                       0    // parity none
    };

    hal_uart_init(HAL_UART_IOL, &IolUartConfig);

    CountErrorA = 0;
    CountErrorB = 0;
    pRcvBuffer = WriteMsgQueue.GetRcvBufPtr();// get ptr to rcv buffer
    ucIolBA  = BOX->GetBA();
    ucIolDPA = BOX->GetDPA();
    ucIolDSA = BOX->GetDSA();

    hal_uart_register_isr(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA,  clsIol::Rcvr);        // handling Receiver callback function
    hal_uart_register_isr(HAL_UART_IOL, HAL_UART_IRQ_TX_EMPTY, clsIol::Xmit);        // handling Transmit callback function
    hal_uart_register_isr(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE,  clsIol::XmitEnd);    // handling Transmit End callback function

    hal_uart_clear_errors(HAL_UART_IOL);

    /* Small settling delay for transceiver to stabilize */
    for (volatile uint32_t dly = 0; dly < 1000; dly++) { NOP; }

    SetJABRES_n(1); /* JABRES_n must be asserted for Tx, to get LinkWindow=0 from FPGA */

    SetTXREQ_n(IOLDRV_OFF); /* TXREQ_n deassert to make DE=0 */

    SetRCVSELA_n(0); /* RCVSELA_n is deasserting to select receiver channel A */

    Iol.ResetSilenceTimer(CNTLNKSIL); // Enable IOL Silence Timer

    IOL_RxEnable();

#if IOL_GHO_ENB
    EnableGHOInt(TRUE);         // Enable GHO_IRQ_n
    SetCLR_GHL_n(GHO_ENABLED);  // Enable GHO interrupt register
#endif
    IOL_RxInterrupt(TRUE);

#if IOL_DIAG_COLLECT
    g_IolDiag.rxIrqEnableCount++;
    IolDiagCaptureState();
#endif

#if 0
    PRINTF("IOL ENABLED\r\n");
#endif
}

VOID clsIol::Disable(VOID) {
    SetTXREQ_n(IOLDRV_OFF); /* TXREQ_n deassert to make DE=0 */
    SetRCVSELA_n(1); /* RCVSELA_n is asserting to deselect receiver channel A */

    IOL_RxInterrupt(FALSE);

#if IOL_DIAG_COLLECT
    g_IolDiag.rxIrqDisableCount++;
    IolDiagCaptureState();
#endif
}
/**************************************************************************************
*                       GHO_IRQHandler                                                *
*                       ==============                                                *
* PURPOSE  : Gap Has Occurred interrupt handler.                                      *
* ARGUMENTS: None.                                                                    *
* RETURN   : None.                                                                    *
* NOTES    : RT1024 CHANGES: Uses HAL GPIO wrappers for GHO control.                  *
*            Called from BOARD_INITIOLINK_PINS_GHOIRQ_n_callback (NXP GPIO adapter).  *
***************************************************************************************/
VOID GHO_IRQHandler(VOID)
{
    GHO_INT_Clr();                       // Reset IRQ interrupt flag
    SetCLR_GHL_n(GHO_DISABLED);          // Clear/disable GHO interrupt register
    SetCLR_GHL_n(GHO_ENABLED);           // Enable GHO interrupt register

    //Iol.ChecksumHi = Iol.ChecksumLo = 0;           // Reset running checksum
    //Iol.pRcvBuffer[IOLMSG_NUMBER] = Iol.xmit_buffer[IOLMSG_NUMBER] = 0;  // Zero N's

    /* Clear error bits + int flags *
    hal_uart_clear_errors(HAL_UART_IOL);
    hal_uart_clear_flag(HAL_UART_IOL, (HAL_UART_IRQ_TYPE)(HAL_UART_IRQ_RX_DATA  |
                                                          HAL_UART_IRQ_TX_EMPTY |
                                                          HAL_UART_IRQ_TX_DONE  |
                                                          HAL_UART_IRQ_RX_ERROR)); */

#if 0
    /* Never touch response-build state while TX is active/in-flight. */
    if (Iol.txActive || (Iol.nCharProcd != 0U)) {
        return;
    }

    /* If UART already has data pending, a frame is starting/active.
     * Do not reset receiver/checksum state from GHO in that window. */
    if (IOL_RxDatReady()) {
        return;
    }
#endif

    IOL_RxInterrupt(TRUE); // Enable rcvr ints
#if IOL_DIAG_COLLECT
    g_IolDiag.rxIrqEnableCount++;
    IolDiagCaptureState();
#endif
}

/* NXP GPIO adapter callback — required name for peripherals.c registration */
extern "C" void BOARD_INITIOLINK_PINS_GHOIRQ_n_callback(void *param) {
    (void)param;
    GHO_IRQHandler();
}
//#if 1   // ANIL_RE_VISIT
/**
 *
 */
VOID clsIol::Rcvr(VOID) {

    /* First byte arrived by IRQ; disable RX IRQ and poll remaining bytes immediately. */
    IOL_RxInterrupt(FALSE);

#if IOL_DIAG_COLLECT
    g_IolDiag.rxIsrCount++;
    g_IolDiag.rxIrqDisableCount++;
    g_IolDiag.lastCommandSeen = 0xFFFFFFFFU;
    g_IolDiag.lastRcvrExitPath = 1U; /* Rcvr entry */
    IolDiagCaptureState();
#endif

    UINT8 *p=Iol.pRcvBuffer;
    UINT8 ucAlertBit;
    UINT16 uiData;
    UINT32 ucTimeOut;
    UINT8 ucCount = 0;
    PASTATUS ucStatus = PA_OK;

#if IOL_BYT_DBG
    UINT8 ucCount1 = 0; // testing
#endif

    Iol.bCommError = FALSE;

#if defined(IOL_CLEAR_XMIT_LEN_ON_RX) && IOL_CLEAR_XMIT_LEN_ON_RX
    Iol.xmit_buffer[IOLMSG_NUMBER] = 0;
#endif

    // *************************************
    //  1. Get Destination Address character
    // *************************************
    uiData = IOL_ReadByte() & 0x1FFU;

    *p = (UINT8)uiData;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);

    if (ucAlertBit != IOL_ALERT_RCV_ADDR)
    {
#if 0 //IOL_ERR_DBG
        PRINTF("RX ER B0 AL (%x) - ", uiData);
#endif
        goto ERROR;
    }
    if (Iol.NotMyAddress(*p))
    {
#if 0 //IOL_ERR_DBG
        PRINTF("RX ER B0 AD (%x) - ", uiData);
#endif
        Iol.ResetSilenceTimer(CNTLNKSIL);

        goto ERROR;
    }
    Iol.ucDest = *p++;
    Iol.Add2Checksum(Iol.ucDest);
    Iol.xmit_buffer[IOLMSG_SOURCE]=Iol.ucDest;
    SilenceTimerStop();                            // stop the silence timer

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.ucDest;
#endif

    // *************************************
    //   2. Get Number character
    // *************************************
    {
        ucTimeOut = NCYCLES_CHARTO;
        while (!IOL_RxDatReady())
        {
            IdleWait(1);
            if (--ucTimeOut == 0)
            {
#if IOL_ERR_DBG
                PRINTF("RX ER B1 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);          // Reset Link Silence Timer
                goto ERROR;
            }
        }
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
        PRINTF("RX ER B1 AL (%x) - ", uiData);
#endif
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }

    *p = (UINT8)uiData;
    Iol.Add2Checksum(*p);
    Iol.ucNumber = *p;
    p++;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.ucNumber;
#endif

    // *************************************
    //   3. Get Source Address character
    // *************************************
    {
        ucTimeOut = NCYCLES_CHARTO;
        while (!IOL_RxDatReady())
        {
            IdleWait(1);
            if (--ucTimeOut == 0)
            {
#if IOL_ERR_DBG
                PRINTF("RX ER B2 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
                goto ERROR;
            }
        }
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
        PRINTF("RX ER B2 AL (%x) - ", uiData);
#endif
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }

    *p = (UINT8)uiData;
    Iol.Add2Checksum(*p);
    Iol.xmit_buffer[IOLMSG_DESTINATION]=*p;
    p++;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.xmit_buffer[IOLMSG_DESTINATION];
#endif


    // *************************************
    //   4. Get Command character
    // *************************************
    {
        ucTimeOut = NCYCLES_CHARTO;
        while (!IOL_RxDatReady())
        {
            IdleWait(1);
            if (--ucTimeOut == 0)
            {
#if IOL_ERR_DBG
                PRINTF("RX ER B3 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
                goto ERROR;
            }
        }
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
        PRINTF("RX ER B3 AL (%x) - ", uiData);
#endif
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }

    *p = (UINT8)uiData;
    Iol.ucCommand = *p;

#if IOL_DIAG_COLLECT
    g_IolDiag.lastCommandSeen = (UINT32)Iol.ucCommand;
#endif

#if 0 // temp commented due to redesign PMIO is not working with this condition
    // Check if link id matches the link id jumpered on the module
    if ((Iol.ucCommand != CMD_TOG) && (!(BOX->IsIolCorrect(Iol.ucIolId))))
    {
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }
#endif

    Iol.Add2Checksum(*p);
    if (Iol.ucCommand <= LastCommand) {
        Iol.xmit_buffer[IOLMSG_NUMBER] = aCmdInfo[Iol.ucCommand].CountResp;
    }
    else {
        Iol.xmit_buffer[IOLMSG_NUMBER] = 0;
    }
    Iol.xmit_buffer[IOLMSG_COMMAND] = Iol.ucCommand | 0x80;
    p++;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = Iol.ucCommand;
#endif

    // *************************************
    //   5. Get Data
    // *************************************
    if (CMD_WRINDEXDEFERRED == Iol.ucCommand)
    {
        if (!Iol.ProcessDefWrCmd())
        {
            goto ERROR;
        }
    }
    else
    {   // Get I field characters
        if (Iol.ucNumber < 4U) {
            BOX->SetCommError(IOL_CHRCT);
            Iol.ResetSilenceTimer(CNTLNKSIL);
            goto ERROR;
        }

        ucCount = Iol.ucNumber - 4;
        while(ucCount--)
        {
            ucTimeOut = NCYCLES_CHARTO;
            while (!IOL_RxDatReady())
            {
                IdleWait(1);
                if (--ucTimeOut == 0)
                {
#if IOL_ERR_DBG
                    PRINTF("RX ER B4 TO (%x) - ", uiData);
#endif
                    BOX->SetCommError(IOL_CHRTM);
                    Iol.ResetSilenceTimer(CNTLNKSIL);
                    goto ERROR;
                }
            }

            uiData = IOL_ReadByte() & 0x1FFU;
            ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
            if (ucAlertBit == IOL_ALERT_RCV_ADDR)
            {
#if IOL_ERR_DBG
                PRINTF("RX ER B4 AL (%x) - ", uiData);
#endif
                Iol.ResetSilenceTimer(CNTLNKSIL);
                goto ERROR;
            }

            *p = (UINT8)uiData;

#if IOL_BYT_DBG
            Iol.TempBuff[ucCount1++] = *p;
#endif

            Iol.Add2Checksum(*p++);
        }
    }

    // ********************************************
    //   6. Get Checksum High character and Check
    // ********************************************
    {
        ucTimeOut = NCYCLES_CHARTO;
        while (!IOL_RxDatReady())
        {
            IdleWait(1);
            if (--ucTimeOut == 0)
            {
#if IOL_ERR_DBG
                PRINTF("RX ER B5 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
                goto ERROR;
            }
        }
    }

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
        PRINTF("RX ER B5 AL (%x) - ", uiData);
#endif
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }

    *p = (UINT8)uiData;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = *p;
#endif

    if ((UINT8)Iol.ChecksumHi != *p)
    {
#if IOL_ERR_DBG
        PRINTF("RX ER B5 CH (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_CHKSM);
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }
    p++;

    // ********************************************
    //   7. Get Checksum Low character and Check
    // ********************************************
    {
        ucTimeOut = NCYCLES_CHARTO;
        while (!IOL_RxDatReady())
        {
            IdleWait(1);
            if (--ucTimeOut == 0)
            {
#if IOL_ERR_DBG
                PRINTF("RX ER B6 TO (%x) - ", uiData);
#endif
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
                goto ERROR;
            }
        }
    }

#if IOL_GHO_ENB
    Iol.StartGapTimer();
#endif

    uiData = IOL_ReadByte() & 0x1FFU;
    ucAlertBit = (UINT8)((uiData >> 8) & 0x01U);
    if (ucAlertBit == IOL_ALERT_RCV_ADDR)
    {
#if IOL_ERR_DBG
        PRINTF("RX ER B6 AL (%x) - ", uiData);
#endif
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }

    *p = (UINT8)uiData;

#if IOL_BYT_DBG
    Iol.TempBuff[ucCount1++] = *p;
#endif

    if ((UINT8)Iol.ChecksumLo != *p)
    {
#if IOL_ERR_DBG
        PRINTF("RX ER B6 CL (%x) - ", uiData);
#endif
        BOX->SetCommError(IOL_CHKSM);
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }

#if 0 //IOL_GHO_ENB
    // IOL_TxInterrupt(TRUE);        // enable transmitter
    SetCLR_GHL_n(GHO_DISABLED);     // Disable GHO interrupt
#endif

#if 1 //IOL_GHO_ENB
    ucTimeOut = 13; //42uS
    while (--ucTimeOut)
    {
        IdleWait(1);
        if (IOL_RxDatReady())
        {
#if IOL_ERR_DBG
            PRINTF("RX ER B7 TCWAIT");
#endif
            BOX->SetCommError(IOL_CHRTM);
            Iol.ResetSilenceTimer(CNTLNKSIL);
            goto ERROR;
        }
    }
#else
    // Test for overrun — Error if another character comes within TcWait
    while (GetGapTimerCnt() < TPU4CNT_TCWAIT);
    if (IOL_RxDatReady())
    {
        BOX->SetCommError(IOL_ORUN);
        Iol.ResetSilenceTimer(CNTLNKSIL);
        goto ERROR;
    }
#endif

#if IOL_GHO_ENB
    // IOL_TxInterrupt(TRUE);        // enable transmitter
    SetCLR_GHL_n(GHO_DISABLED);     // Disable GHO interrupt
#endif

#if IOL_BYT_DBG
    if((ucCount1 > 0) && (Iol.ucDest == 0x81)) {

        PRINTF("\r\nTR: ");
        for (int i = 0; i < ucCount1; i++)
        {
            PRINTF("%02X ", (unsigned)Iol.TempBuff[i]);
        }
    }
#endif

    // ********************************************
    //   Execute appropriate command handler.
    // ********************************************
    if (Iol.ucCommand <= LastCommand)
    {
        ucStatus = (Iol.*(aCmdInfo[Iol.ucCommand].CmdHandler))();    // Call Command Handler
    }
    else
    {
        ucStatus = Iol.DefaultHandler();
    }

    if (Iol.bCommError)
    {
        Iol.ResetSilenceTimer(CNTLNKSIL);     // Reset Link Silence Timer

#if IOL_GHO_ENB
        GHO_INT_Clr();                        // Reset IRQ0 interrupt flag
        SetCLR_GHL_n(GHO_DISABLED);            // Clear/disable GHO interrupt register
        SetCLR_GHL_n(GHO_ENABLED);            // Enable GHO interrupt register
#endif
        //Iol.ChecksumHi = Iol.ChecksumLo = 0;                                    // Reset running checksum
        //Iol.pRcvBuffer[IOLMSG_NUMBER] = Iol.xmit_buffer[IOLMSG_NUMBER] = 0;    // Zero N's

        // Clear error bits + int flags
        //hal_uart_clear_errors();
        //hal_uart_clear_flag(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA  | HAL_UART_IRQ_TX_EMPTY | HAL_UART_IRQ_TX_DONE  | HAL_UART_IRQ_RX_ERROR);

        // Increment Comm error count (not the same as the boxslot's error count) for the appropriate channel.
        if (BOX->GetPRC())
        {
            if (Iol.CountErrorB < MAXUINT8)
                Iol.CountErrorB++;
            else
            {
                Iol.CountErrorB = Iol.CountErrorB - Iol.CountErrorA;
                Iol.CountErrorA = 0;
            }
        }
        else
        {
            if (Iol.CountErrorA < MAXUINT8)
                Iol.CountErrorA++;
            else
            {
                Iol.CountErrorA = Iol.CountErrorA - Iol.CountErrorB;
                Iol.CountErrorB = 0;
            }
        }
        // If one channel is healthier than the other listen to it
        if (Iol.CountErrorA != Iol.CountErrorB)
        {
            if (Iol.CountErrorA < Iol.CountErrorB)
                BOX->ResetPRC();    // Chan A
            else
                BOX->SetPRC();        // Chan B
        }
        goto ERROR;
    }

    // There were no comm errors so dec the count for the appropriate channel
    if (BOX->GetPRC())
    {
        if (Iol.CountErrorB != 0) Iol.CountErrorB--;
    }
    else
    {
        if (Iol.CountErrorA != 0) Iol.CountErrorA--;
    }

    if (ucStatus != PA_OK) {

        Iol.StartNakResponse(ucStatus);
    }

    // If no response is required reset for next request and get out
    if (Iol.xmit_buffer[IOLMSG_NUMBER] == 0)
    {
        Iol.ResetSilenceTimer(CNTLNKSIL);
#if IOL_GHO_ENB
        SetCLR_GHL_n(GHO_ENABLED);        // Enable GHO interrupt register
#endif
        //IOL_DisAllInt() // disable everything
        /* Keep RX path armed even when this request has no response payload. */
        IOL_TxInterrupt(FALSE);
        IOL_TxDoneInterrupt(FALSE);
        IOL_RxInterrupt(TRUE);

#if IOL_DIAG_COLLECT
        g_IolDiag.noResponseCount++;
        g_IolDiag.txIrqDisableCount++;
        g_IolDiag.txDoneDisableCount++;
        g_IolDiag.rxIrqEnableCount++;
        g_IolDiag.lastRcvrExitPath = 2U; /* no-response branch re-armed RX */
        IolDiagCaptureState();
#endif
    }

    Iol.ChecksumLo = Iol.ChecksumHi = 0;

#if 0
    while (TXREQ_n == IOLDRV_ON)        // wait until transmission is complete
    {
        BOX->AppUrgentProcess();
    }
#endif

#if IOL_DIAG_COLLECT
    g_IolDiag.lastRcvrExitPath = 3U; /* normal Rcvr return */
#endif

    return;

ERROR:
#if IOL_BYT_DBG //IOL_ERR_DBG

    if(ucCount1 > 0) {

        PRINTF("\r\nTR: ");
        for (int i = 0; i < ucCount1; i++)
        {
            PRINTF("%02X ", (unsigned)Iol.TempBuff[i]);
        }
        PRINTF(" CH: %02X CL: %02X\r\n", (UINT8)Iol.ChecksumHi, (UINT8)Iol.ChecksumLo);
    }

#endif

    ucCount = 0U;
    hal_uart_clear_errors(HAL_UART_IOL);

#if IOL_DIAG_COLLECT
    g_IolDiag.errorPathCount++;
    g_IolDiag.lastRcvrExitPath = 4U; /* ERROR exit path */
#endif

    Iol.ChecksumHi = Iol.ChecksumLo = 0; // Reset running checksum
    Iol.pRcvBuffer[IOLMSG_NUMBER] = Iol.xmit_buffer[IOLMSG_NUMBER] = 0;
    IOL_FifoEnable();
    IOL_RxInterrupt(TRUE);

#if IOL_DIAG_COLLECT
    g_IolDiag.rxIrqEnableCount++;
    if ((IOLINK_UART_BASEADDR->STAT & LPUART_STAT_RDRF_MASK) != 0U) {
        g_IolDiag.rdrfAfterErrorCount++;
    }
    IolDiagCaptureState();
#endif
}

/**
 *
 */
VOID clsIol::Xmit(VOID) {

#if IOL_DIAG_COLLECT
    g_IolDiag.txIsrCount++;
    IolDiagCaptureState();
#endif

    /*
     * check the loopback recv bytes to confirm successful Tx over IOLink
     * loopback bytes starts receive from the 3rd byte of Tx
     *
    if(Iol.nCharProcd > 1)
    {
        if (IOL_RxDatReady()) {
            if (Iol.xmit_buffer[Iol.nCharProcd - 2] != (IOL_ReadByte() & 0xFFU))
            {
                //SetTXREQ_n(IOLDRV_OFF); // turn off RS-485 transmitter
                //hal_uart_clear_flag(HAL_UART_IRQ_RX_DATA);
                BOX->SetCommError(IOL_LPBK);                // log a loopback error
                Iol.ResetSilenceTimer(CNTLNKSIL);           // Reset Link Silence Timer

                //IOL_DisAllInt();                            // Disable all ints
                //IOL_Disable();

#if 0 //IOL_GHO_ENB
                SetCLR_GHL_n(GHO_ENABLED);        // Enable GHO interrupt register
#endif

                //IOL_TxInterrupt(FALSE);

                //IOL_TxDoneInterrupt(TRUE);

                //if (JABLOCK_n == JABLOCK_ASSERTED) HardFail(HF_IOLJABBERFIRED,IOL_CPP,__LINE__);
                //else BOX->SwapPRC();

                return;
            }
        }
    }*/

    IOL_WriteByte(Iol.xmit_buffer[Iol.nCharProcd], IOL_ALERT_XMIT_DATA);

    Iol.nCharProcd += 1;

    /* clearing Tx Rx int flags */
    //hal_uart_clear_flag(HAL_UART_IOL, HAL_UART_IRQ_RX_DATA);
    //hal_uart_clear_flag(HAL_UART_IOL, HAL_UART_IRQ_TX_EMPTY);

    if(Iol.nCharProcd == Iol.txStopCount)
    {
        // disable RXI, TXI - enable TEI
        IOL_TxInterrupt(FALSE);
        //IOL_RxInterrupt(FALSE);
        IOL_TxDoneInterrupt(TRUE);

#if IOL_DIAG_COLLECT
    g_IolDiag.txIrqDisableCount++;
    g_IolDiag.txDoneEnableCount++;
    IolDiagCaptureState();
#endif

#if IOL_GHO_ENB
        SetCLR_GHL_n(GHO_ENABLED);        // Enable GHO interrupt register
#endif
    }
}

VOID clsIol::XmitEnd(VOID) {

#if IOL_DIAG_COLLECT
    g_IolDiag.txDoneIsrCount++;
    IolDiagCaptureState();
#endif

    /* clearing Tx done flag */
    hal_uart_clear_flag(HAL_UART_IOL, HAL_UART_IRQ_TX_DONE);

    /* Disable TC interrupt */
    IOL_TxDoneInterrupt(FALSE);

#if IOL_DIAG_COLLECT
    g_IolDiag.txDoneDisableCount++;
#endif

    /* disable Tx */
    IOL_TxDisable();

#if 0 //IOL_GHO_ENB
    SetCLR_GHL_n(GHO_ENABLED);    // Enable GHO interrupt register
#endif

    Iol.ResetSilenceTimer(CNTLNKSIL);

    /* Tx driver enable off (DE=0) */
    SetTXREQ_n(IOLDRV_OFF);

    Iol.nCharProcd = 0;
    Iol.txStopCount = 0;
    Iol.txActive = FALSE;

    /* Enable Rx interrupt */
    IOL_RxInterrupt(TRUE);

    #if defined(IOL_RX_KICK_AFTER_TX) && IOL_RX_KICK_AFTER_TX
    /* If a request byte arrived while RX IRQ was masked during TX, service it
     * immediately so a latched RDRF byte cannot strand the link in idle state. */
    if (IOL_RxDatReady()) {
        Rcvr();
    }
    #endif

#if IOL_DIAG_COLLECT
    g_IolDiag.rxIrqEnableCount++;
    IolDiagCaptureState();
#endif
}

/*******************************************************************************
*                       SilenceTimer_IRQHandler                                *
*                       =======================                                *
* PURPOSE:   Link silence timer expired — swap cable channel and check errors. *
* ARGUMENTS: None.                                                             *
* RETURN:    None.                                                             *
* NOTES:     RT1024 CHANGES: Timer via HAL, FPGA register via SPI.             *
*******************************************************************************/
VOID SilenceTimer_IRQHandler(VOID)
{
    UINT8  ucPRC;

    SetCLR_GHL_n(GHO_DISABLED);               // Disable GHO interrupt register
    SilenceTimerIntClr();                     // Clear compare Interrupt flag
    ucPRC = BOX->SwapPRC();                   // swap PRC and log it

    if (BOX->AreLinkErrorsSet(ucPRC))
    {
        ucPRC ^= 0x01;
        if (BOX->AreLinkErrorsSet(ucPRC))

        {
            Iol.ResetSilenceTimer(CNTLNKHUNT);// Set compare register to hunt value
            Iol.LossofCommShed();             // and shed the screws if appropriate
        }
        else
        {
            Iol.ResetSilenceTimer(CNTLNKSIL); // Set compare reg to silence value
        }
    }
    else
    {
        Iol.ResetSilenceTimer(CNTLNKSIL);     // Set compare register to silence value
    }
#if 0 //IOL_GHO_ENB
    SetCLR_GHL_n(GHO_ENABLED);                // Enable GHO interrupt register
#endif
}

/**************************************************************************************
*                       clsIol::LossofCommShed                                        *
*                       ======================                                        *
* PURPOSE:   Detect IOL communication timeout and initiate backup takeover if needed. *
* ARGUMENTS: None.                                                                    *
* RETURN:    None.                                                                    *
* NOTES:     None.                                                                    *
**************************************************************************************/
VOID clsIol::LossofCommShed(VOID)
{
    /*
    UINT16  uiLimit = AmPrimary() ? CNTLNKPRITO : CNTLNKSECTO;
    if (uiLimit < BOX->GetSilenceCount() && !BOX->GetPartnersBackupStatus()) {
        if (REDSTATE_SYNCD == BOX->GetRedState()) {
            BOX->SetRedState(REDSTATE_IOL_TIMEOUT);
            BOX->AssertBackup();
        }
        if (AmPrimary()) {
            DropDSA();
            BOX->SetDSA(0);
        }
    }
    */
}

/*******************************************************************************
*                       clsIol::GetPrimaryResponse                             *
*                       ==========================                             *
* PURPOSE:                                                                     *
*******************************************************************************/
PASTATUS clsIol::GetPrimaryResponse (UINT8 nChar, UINT8 ucWait, UINT8 *p)
{
    PASTATUS    bResponse=PA_OK;
    UINT8       ucCycles;
    
    // Wait for Partner to Respond to the Request
    for (;nChar>0;nChar--) {

        // for, PMIO Redeisgn which is slow responsive compare to series c IOM
        ucCycles = (ucWait + 150);
            
        while (!IOL_RxDatReady()) {
            ucCycles--;
            if(ucCycles==0) {
               bResponse = IOL_CHRTM;
               break;
            }
        }

        if(ucCycles!=0) *p++ = (UINT8)IOL_ReadByte();     // put character into buffer
    }

    return bResponse;
}

/*******************************************************************************
*                       clsIol::ComputeFletcher                                *
*                       =======================                                *
* PURPOSE:                                                                     *
*    Compute Fletcher checksum on an IOL message and either append or compare. *
* ARGUMENTS:                                                                   *
*    p       : pointer to the message buffer.                                  *
*    uAction : FTYP_APPEND to append checksum, FTYP_COMPARE to verify.        *
* RETURN:                                                                      *
*    EXIT_SUCCESS if ok, EXIT_FAILURE if compare mismatch.                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
UINT8 clsIol::ComputeFletcher(UINT8 *p, FLETCHERACTION uAction)
{
    UINT16  ChksumHi = 0, ChksumLo = 0, i;

    for (i=p[1]; i>0; i--) {
        ChksumLo += *p++;
        if (ChksumLo > 0xFF) ChksumLo += 0xFF01;     // if carry, sub 256, add 1
        ChksumHi += ChksumLo;
        if (ChksumHi > 0xFF) ChksumHi += 0xFF01;     // if carry, sub 256, add 1
    }
    if (uAction == FTYP_APPEND) {
        *p++ = ChksumHi;
        *p   = ChksumLo;
        return EXIT_SUCCESS;
    }
    else if (uAction == FTYP_COMPARE) {
        if (p[0] == ChksumHi && p[1] == ChksumLo)
            return EXIT_SUCCESS;
    }
    return EXIT_FAILURE;
}

/*
 * IOLink command handlers
 */
PASTATUS clsIol::Cmd01Handler(VOID){ // Block Read Absolute

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    // Check that requested count is returnable
    UINT8 ucCount = pRcvBuffer[IOLREQ_ABSNUM];
    if (ucCount > IOL_MAXRESPONSE) {
        return DO_ILLEGAL_VALUE;
    }

    // Check for gap error
    if (GHOXXX == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else
    { // if none, build the response

        DATABYTES address;

        xmit_buffer[IOLMSG_NUMBER] += ucCount;
        StartResponse();
        address.ucBytes[0] = 0;
        address.ucBytes[1] = pRcvBuffer[IOLREQ_12DATA];
        address.ucBytes[2] = pRcvBuffer[IOLREQ_12DATA+1];
        address.ucBytes[3] = pRcvBuffer[IOLREQ_12DATA+2];

        // modified for FCT testing (FPGA_IOTA_REDUNT_n & BOTTOM SIGNAL TEST - TEST#2, SUBTEST#3)
        if(address.ui32Val == 0x0000C000)
        { 
            UINT8 iotabits = Fpga.GetIotaRegister();
            
            xmit_buffer[IOLRESP_RDABSDATA]  = (iotabits & FPGA_IOTA_REDUNT_n)  << 7;
            // for AO16, DI24 & DO32 IOPs, BIT.7 & BIT.1 refers to FTA_PRE & FTA_SEC (BOTTOM) signal resp.
            xmit_buffer[IOLRESP_RDABSDATA] |= (iotabits & FPGA_IOTA_BOTTOM) << 1;

        }
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
    }

    return PA_OK;
}

PASTATUS clsIol::Cmd04Handler(VOID) { // Read Deferred Index

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    UINT8 ucSlotNum = pRcvBuffer[IOLREQ_SLOTNUM];

    // Check that slot number is valid
    if (ucSlotNum != 0) {
        return DO_INVALID_SLOT_INDEX;
    }
    // Check if the BRDP handle request 
    if ((PARAMID_BRDP == pRcvBuffer[IOLREQ_PARAMID]) && 0 == ucSlotNum)
    {
        // Get the Handle which is at index byte offset. MSB can not be 1.
        if (INVALID_HANDLE_MASK & pRcvBuffer[IOLREQ_INDEX]) return PA_PS_INVLD_HNDL;
        // Check if the session for this has timed out or not. return Invalid Handle
        // if the session has timedout.
        ucSlotNum = (pRcvBuffer[IOLREQ_INDEX] & BRDP_HNDL_MSK) >> 3;

        if (0 == BOX->HNDLStatusTable[ucSlotNum].Timeout) return PA_PS_INVLD_HNDL;
        // Now handle is valid , find out the message Number
        UINT8 ucTemp=0;

        for (ucTemp=0; ucTemp < MAXBRDPMSGS; ucTemp++)
        {
#if 0 // ANIL_RE_VISIT
            if (pHartPst[ucTemp]->m_ucHandle == pRcvBuffer[IOLREQ_INDEX]) break;
#endif
        }

        if ( MAXBRDPMSGS == ucTemp ) return PA_PS_INVLD_HNDL;
        xmit_buffer[IOLREQ_DEFMSGNO] = ucTemp; // Def Mesnum
                // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
            BOX->HNDLStatusTable[ucSlotNum].Timeout = BRDP_HNDL_TIMEOUT;
        }
        return PA_OK;

    }
    else {

        return DO_PARAMETER_INVALID;
    }
}
PASTATUS clsIol::Cmd07Handler(VOID)
{  // Get BRDP Deferred Message Status

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    UINT8 ucBrdpMsgNum = pRcvBuffer[IOLREQ_12DATA];
    
    //Check if the message number is valid
    if (ucBrdpMsgNum >= MAXBRDPMSGS)
        return PA_PS_INVLD_MSGNO;

    // Check for gap error
    if (GHOXXX == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else
    { // if none, build the response
#if 0 // ANIL_RE_VISIT
        xmit_buffer[IOLRESP_MSGSTS] = pHartPst[ucBrdpMsgNum]->m_PstStatus;
        StartResponse();
        ComputeFletcher(xmit_buffer, FTYP_APPEND);

        // refresh session timeout also
        UINT8 ucSlotNum = pHartPst[ucBrdpMsgNum]->m_ucSlotNumber;
        if (ucSlotNum != 0 && ucSlotNum <= MAXSLOTS) {
            BOX->HNDLStatusTable[ucSlotNum - 1].Timeout = BRDP_HNDL_TIMEOUT;
        }

        // if The response was DR_DEAD, update the status table accordingly.
        if (PA_PS_DEAD == (PASTATUS)pHartPst[ucBrdpMsgNum]->m_PstStatus)
        {
            pHartPst[ucBrdpMsgNum]->m_ucSlotNumber   = INVALID_SLOTNUM;
            pHartPst[ucBrdpMsgNum]->m_ucHandle       = INVALID_HANDLE;
            pHartPst[ucBrdpMsgNum]->m_PstStatus      = HPSTSTATUS_DEAD;
            pHartPst[ucBrdpMsgNum]->m_ucPstMsgTimeout = 0;

            BOX->SPLTResponseOffsetTable[ucBrdpMsgNum] = 0;
            BOX->BRDPResourceStatus &= ~(((UINT16)0x01) << ucBrdpMsgNum);
        }
#endif
    }

    return PA_OK;
}

PASTATUS clsIol::Cmd08Handler(VOID)
{ // Read
    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA)
    {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST)
    {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq)
    {
        return IOL_CHRCT;
    }

    UINT8 ucSlotNum = pRcvBuffer[IOLREQ_SLOTNUM];

    // Check that slot number is valid
    if (ucSlotNum > MAXSLOTS) {
        return DO_INVALID_SLOT_INDEX;
    }

    // Check if the BRDP handle request
    if (PARAMID_HBRDP == pRcvBuffer[IOLREQ_PARAMID]) {
        if (0 == ucSlotNum) return DO_INVALID_SLOT_INDEX;
        if (BRDPSESSION_CLOSE == BOX->HNDLStatusTable[ucSlotNum-1].Handle) {
            // Check for gap error
            if (GetGHOXXX() == GHO_NOTINGAP) {
                BOX->SetCommError(IOL_GAP);
                bCommError = TRUE;
            }
            else { // if none, build the response
                xmit_buffer[IOLMSG_NUMBER] += 1; // parameter size is 1 byte
                StartResponse();
                xmit_buffer[IOLRESP_DATATYPE] = DT_UINT8; // datatyps is UINT8
                // Construct the BRDP handle 
                xmit_buffer[IOLRESP_RDDATA] = ((ucSlotNum-1) & 0x0F)<<3;  // Handle for 16 slots
                ComputeFletcher(xmit_buffer, FTYP_APPEND);
                BOX->HNDLStatusTable[ucSlotNum-1].Handle = BRDPSESSION_OPEN;
                BOX->HNDLStatusTable[ucSlotNum-1].Timeout = BRDP_HNDL_TIMEOUT;                
            }
            return PA_OK;
        }
        else
            return PA_PS_ACQRD_HNDL;
    }

    // Check that parameter number is valid
    // If it is, filter and save the data type for the response
    UINT8 ucDatatype = pDatabase[ucSlotNum]->GetDataType(pRcvBuffer[IOLREQ_PARAMID]);
    if (ucDatatype == DT_NONE) {
        return DO_PARAMETER_INVALID;
    }

    // Check for gap error
    if (GetGHOXXX() == GHO_NOTINGAP)
    {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else // if none, build the response
    {
        xmit_buffer[IOLMSG_NUMBER] += pDatabase[ucSlotNum]->GetParamSize(pRcvBuffer[IOLREQ_PARAMID]);        
        StartResponse();
        xmit_buffer[IOLRESP_DATATYPE] = ucDatatype;
        pDatabase[ucSlotNum]->ReadParamData(&xmit_buffer[IOLRESP_RDDATA],pRcvBuffer[IOLREQ_PARAMID]);
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
    }

    return PA_OK;
}

PASTATUS clsIol::Cmd0AHandler(VOID) { // Block Write Absolute, Write and Write Indexed

    // If I am the backup module and the request was addressed via DSA
    // check primary's response and act accordingly
    if (ucDest == ucIolBA) {

        UINT8 ucPriResponse[6];

        //To ensure that secondary IOM gets all 5 character correctly
        //The secondary should snoop 6 characters and use the 5th character only after the 6th character is received.        
        if (PA_OK != GetPrimaryResponse(6,70,ucPriResponse)) {

            xmit_buffer[IOLMSG_NUMBER] = 0;
            return PA_OK;
        }

        if (WriteMsgQueue.WillRcvBfrOverflow(ucNumber)) {
            if (ucPriResponse[3] != (IOLCMD_NACK | 0x80)) {
                if (BOX->GetRedState() == REDSTATE_FREEZE_ACCEPTED) {
                    BOX->SetRedState(REDSTATE_FREEZE_NOT_ACCEPTED);
                }
            }
            else {
                if (ucCommand == CMD_FREEZE) {
                    if (BOX->GetRedState() == REDSTATE_FREEZE_ACCEPTED) {
                        BOX->SetRedState(REDSTATE_FREEZE_NOT_ACCEPTED);
                    }
                }
                else if (ucPriResponse[4] != IOL_RCVBUFOV) {
                    BOX->DropSync();
                    //TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0xFFFFFFFF);
                }
            }
        }
        else {

            if (ucPriResponse[3] != (ucCommand | 0x80)) {
                if (BOX->GetRedState() == REDSTATE_FREEZE_ACCEPTED) {
                    BOX->SetRedState(REDSTATE_FREEZE_NOT_ACCEPTED);
                }
            }
            else {
                if (ucCommand == CMD_FREEZE) {
                    BOX->SetRedState(REDSTATE_FREEZE_ACCEPTED);
                    ucMsgNumber = ucPriResponse[4];
                }
                else if (ucPriResponse[4] != ucMsgNumber) {
                    BOX->DropSync();
                    //TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0xFFFF0000 + ucPriResponse[4]<<8 + ucMsgNumber);
                    xmit_buffer[IOLMSG_NUMBER] = 0;
                    return PA_OK;
                }
                WriteMsgQueue.AddMessage(ucMsgNumber++,ucNumber);
                pRcvBuffer = WriteMsgQueue.GetRcvBufPtr();
                TaskScheduler.RunTask(TASKID_WRDBTASK);
            }
        }
        
    }
    else {
        // Check for illegal broadcast
        if (ucDest == IOL_BROADCAST) {

            BOX->SetCommError(IOL_DEST);
            bCommError = TRUE;
            return PA_OK;
        }

        // Check that character count is not less than the minimum required
        if (ucNumber < aCmdInfo[ucCommand].CountReq) {

            return IOL_CHRCT;
        }

        // Check receive buffer for exposure to overflow
        if (WriteMsgQueue.WillRcvBfrOverflow(ucNumber)) {

            return IOL_RCVBUFOV;
        }

        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
             BOX->SetCommError(IOL_GAP);
             bCommError = TRUE;
        }
        else { // if none, build the response

            // modified for FCT testing (WATCHDOG TEST - TEST#6, SUBTEST#1)
            if (xmit_buffer[IOLMSG_COMMAND] == 0x83)
            {
                DATABYTES address;
                UINT8 ucDataByte;

                address.ucBytes[0] = 0;
                address.ucBytes[1] = pRcvBuffer[IOLREQ_12DATA + 0];
                address.ucBytes[2] = pRcvBuffer[IOLREQ_12DATA + 1];
                address.ucBytes[3] = pRcvBuffer[IOLREQ_12DATA + 2];
                        ucDataByte = pRcvBuffer[IOLREQ_12DATA + 4];

                if ((address.ui32Val == 0x0000C000) && (ucDataByte == 0x30))                
                {
                    //SWBUREQ_n = ASSERTED;
                    hal_gpio_write(HAL_PIN_BUPREQ_OUT, ASSERTED);
                }
               
                xmit_buffer[IOLRESP_MSGNUM] = ucMsgNumber++;
                StartResponse();
            }
            else 
            {
                // Reject OP/SO write if there is any softfail in that slot
                // except writes with MAN mode and Operator attribute.
                UINT8 ucSlotNum = pRcvBuffer[IOLREQ_SLOTNUM];

                if((ucSlotNum != 0) && (SLOT(ucSlotNum)->IsOutputNotViable(pRcvBuffer[IOLREQ_PARAMID]))) {
                    return DO_INITIALIZATION_ERROR;
                }

                xmit_buffer[IOLRESP_MSGNUM] = ucMsgNumber;
                StartResponse();
                WriteMsgQueue.AddMessage(ucMsgNumber++, ucNumber);
                pRcvBuffer = WriteMsgQueue.GetRcvBufPtr(); // get ptr for next msg
                TaskScheduler.RunTask(TASKID_WRDBTASK);
            } // FCT testing

            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
    }

    return PA_OK;
}

PASTATUS clsIol::Cmd0BHandler(VOID)
{ // Deferred Message Response

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    // Check that Message number is valid
    if (pRcvBuffer[IOLREQ_12DATA] >= MAXBRDPMSGS) {
        return PA_PS_INVLD_MSGNO;
    }
#if 0 // ANIL_RE_VISIT
    // store message number for usage later
    UINT8 ucMsgNum = pRcvBuffer[IOLREQ_12DATA];

   // Header byte to be sent as response
    UINT8 ucRespHeader = HART_COMPLETE_RESPONSE;

    // Get the response Buffer and get the byte count from HART message
    // so that it can be added into the IOL message length byte.
    UINT8 ucMsgLength = pHartPst[ucMsgNum]->m_PstRcvBuffer.At(HARTMSG_LEN_OFFSET) +
        DEFAULT_HART_MSG_LEN;
    // Offset from Split response table
    UINT8 ucSpltRespTblOffset = BOX->SPLTResponseOffsetTable[ucMsgNum];

    // Check if we can send the complete response using 1 IOL message.
    if ((ucMsgLength) > HART_RESP_BYTES_PER_IOL_MSG)
    {
        // Get the offset from SPLTResponseOffsetTable
        if ((ucSpltRespTblOffset+HART_RESP_BYTES_PER_IOL_MSG) > (ucMsgLength+1)) {
            // Set header byte to indicate that this is not complete response and subsequent
            // reads are required.
            ucRespHeader = HART_PARTIAL_RESPONSE; // Header byte
            // Store bytes sent with this message
            ucMsgLength = HART_RESP_BYTES_PER_IOL_MSG;
            xmit_buffer[IOLMSG_NUMBER] += ucMsgLength; 
        }
        else {
            ucRespHeader = HART_COMPLETE_RESPONSE; // Header byte    
            // Store bytes sent with this message
            ucMsgLength = ucMsgLength-ucSpltRespTblOffset;
            xmit_buffer[IOLMSG_NUMBER] += ucMsgLength; 
        }
        xmit_buffer[IOLRESP_DATATYPE] = ucRespHeader; // Store Header byte
    } 
    else {
        xmit_buffer[IOLMSG_NUMBER] += ucMsgLength; 
        xmit_buffer[IOLRESP_DATATYPE] = ucRespHeader; // Header byte
        ucSpltRespTblOffset = 0;
    }
    // Check for gap error
    if (GHOXXX == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else
    { // if none, build the response
        StartResponse();
        for (UINT8 ucCount=0; ucCount < ucMsgLength ; ucCount++ )
            xmit_buffer[IOLRESP_HARTRESP+ucCount] = 
        pHartPst[ucMsgNum]->m_PstRcvBuffer.At(ucCount+ucSpltRespTblOffset); 
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        // Reset the entries in BRDP status table for this request only after
        // complete response is sent out
        if (HART_COMPLETE_RESPONSE == ucRespHeader)
        {

            pHartPst[ucMsgNum]->m_ucSlotNumber   = INVALID_SLOTNUM;
            pHartPst[ucMsgNum]->m_ucHandle       = INVALID_HANDLE;
            pHartPst[ucMsgNum]->m_PstStatus      = HPSTSTATUS_DEAD;
            pHartPst[ucMsgNum]->m_ucPstMsgTimeout= 0;

            //reset the BRDP status bit for this request
            BOX->BRDPResourceStatus &= ~(((UINT16)0x01) << ucMsgNum);
            // reset the bytes sent to 0 for next split message
            BOX->SPLTResponseOffsetTable[ucMsgNum] = 0;
        }
        else
        {
            // Store the number of bytes sent so far.
            BOX->SPLTResponseOffsetTable[ucMsgNum]+=HART_RESP_BYTES_PER_IOL_MSG;
        }

    }
#endif
    return PA_OK;
}

PASTATUS clsIol::Cmd0CHandler(VOID)
{ // Deferred Index Write
    /* here is the command format
    |D|N|S|0x0C|SltNo|ParamNo|Handle|Header|HART Request|CL|CH|
    */

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber < aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    // Check that slot number is 0
    if (Iol.ucBRDPInfoField[BRDP_SLOTNO_OFFSET] != 0) {
        return DO_INVALID_SLOT_INDEX;
    }
#if 0 // ANIL_RE_VISIT
    // Check if the BRDP handle request 
    if (PARAMID_BRDP == Iol.ucBRDPInfoField[BRDP_PARAMCODE_OFFSET]) {

        // Get the Handle which is at index byte offset. MSB can not be 1.
        if (INVALID_HANDLE_MASK & Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET]) return PA_PS_INVLD_HNDL;
        //Check if any room is available to take this message
        if (ALLHNDLBUSY == BOX->BRDPResourceStatus) return PA_PS_BUSY;
        
        // Check if the session for this has timed out or the request has
        // come without acquirng the handle
        UINT8 ucSltNm = (Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET] & BRDP_HNDL_MSK) >> 3;

        if (BRDPSESSION_CLOSE == BOX->HNDLStatusTable[ucSltNm].Handle) return PA_PS_INVLD_HNDL;
        // Check if handle is duplicate
        for (UINT8 ucTemp=0;ucTemp < MAXBRDPMSGS;ucTemp++) {
            if (pHartPst[ucTemp]->m_ucHandle == Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET]) 
                return PA_PS_DUPL_HNDL;
        }
        // Initialize the timeout for this session
        BOX->HNDLStatusTable[ucSltNm].Timeout = BRDP_HNDL_TIMEOUT;

        // Update resource status and BRDP Status Table according to the 
        // place allocated for this request in Cmd0CHandler.
        BOX->BRDPResourceStatus |= (((UINT16)0x01) << Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET]);

        //Update BRDP Status Table
        pHartPst[Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET]]->m_ucSlotNumber   = ucSltNm+1;
        pHartPst[Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET]]->m_ucHandle       = Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET];

        // Set the Passthrough Status to INIT only when complete request is received 
        // in case of Split requests. Non Split messages set HART_INIT rightaway.
        if ((Iol.ucBRDPInfoField[BRDP_HEADER_OFFSET] & BRDP_SPLIT_REQUEST)) { // Split request
            if (BRDP_SPLIT_LAST_REQ == Iol.ucBRDPInfoField[BRDP_HEADER_OFFSET]) {
                pHartPst[Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET]]->m_PstStatus   = HPSTSTATUS_INIT;
                // Reset the message Number since complete request is received.
                BOX->SPLTRequestHndlTable[Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET]] = 0;
            }
            else {
            // Save the message number in SPLTRequestHndlTable for later access to
            // store the reminder of the request
            BOX->SPLTRequestHndlTable[Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET]] 
                = Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET];
            }
        }
        else { // Non Split request
            pHartPst[Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET]]->m_PstStatus = HPSTSTATUS_INIT;
        }
        pHartPst[Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET]]->m_ucPstMsgTimeout= BRDP_HNDL_TIMEOUT;

        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else
        { // if none, build the response
            xmit_buffer[IOLRESP_MSGNUM] = Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET] ;
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
        return PA_OK;
    }
    else
#endif
        return DO_PARAMETER_INVALID;
}

PASTATUS clsIol::Cmd0FHandler(VOID)
{ // Dump
#if 0 // ANIL_RE_VISIT
    UINT8   ucCount,ucDelta,*p;

    if (ucIdxDump > MAXSLOTS)
    {
        ucCount = 0;
    }
    else if (ucIdxDump == 0)
    {
        ucCount = (UINT8) BOX->GetRedBoxSize();
        ucDelta = (UINT8) BOX->GetRedBoxDelta();
        p = BOX->GetRedBoxPointer();
        BOX->AppPreDump();

        if(isHartCapable())
        {
            bHartDataDump = false;
        }
    }
    else
    {
        if(isHartCapable() && (true == bHartDataDump)) {
            ucCount = (UINT8) SLOT(ucIdxDump)->GetRedHartSlotSize();            
            p = SLOT(ucIdxDump)->GetRedHartSlotPointer();
        }
        else 
        {
            ucCount = (UINT8) SLOT(ucIdxDump)->GetRedSlotSize();        
            p = SLOT(ucIdxDump)->GetRedSlotPointer();
        }
        ucDelta = (UINT8) SLOT(ucIdxDump)->GetRedSlotDelta();
    }

    // If I am the backup module and the request was addressed via DSA
    // wait for primary to respond and consume the data
    if (ucDest == ucIolBA)
    {
        UINT8 ucPriResponse[5];
        xmit_buffer[IOLMSG_NUMBER] = 0;
        if(GetPrimaryResponse(5,70,ucPriResponse) != PA_OK)
        {
            BOX->SetRedState(REDSTATE_DUMP_FAILED);
            return PA_OK;
        }

#if defined(PMIO_DEBUG) && (0)
        if (ucDbgPnt == (ucIdxDump+DUMP_DBGPNT))
        {                        
            for (ucDbgCnt = 0; ucDbgCnt < 5; ucDbgCnt++)
            ucDumpBuff[ucDbgCnt] = ucPriResponse[ucDbgCnt];                    
        }        
#endif
        if((ucPriResponse[4] >= REDSTATE_DUMP_START) 
        && (ucPriResponse[4] <= REDSTATE_MAX))
        {
            if (ucPriResponse[1] - 5 == ucCount - ucDelta)
                ucCount -= ucDelta;   

            if(GetPrimaryResponse(ucCount,70,p) == PA_OK) 
            {
                BOX->SetRedState(ucPriResponse[4]);
            }
            else
            {
                BOX->SetRedState(REDSTATE_DUMP_FAILED);
            }
        }
        else if(ucPriResponse[4] == REDSTATE_DUMP_COMPLETE)
        {
            BOX->SetRedState(ucPriResponse[4]);
            //Donot allow update of OpInternal Parameter  b/w period of 
            //dump complete and sync as it will affect redchksum calculation
            BOX->AppPostDump();
            BOX->SyncStcCounter(FALSE);
        }
        else {
            BOX->SetRedState(REDSTATE_DUMP_FAILED);
        }
        if(isHartCapable()) 
        { 
            // if slot hart data completed,
            if(true == bHartDataDump)
            {
                // update for next slot
                ucIdxDump++;
                bHartDataDump = false;
            }
            else if(ucIdxDump)
            {
                // update for slot hart data
                bHartDataDump = true;
            }
            else
            {
                // update from boxslot to slot1
                ucIdxDump++;
            }
        }
        // if nHART or other variants
        else
        {                
            ucIdxDump++;
        }
    }
    // If I am the primary module and the request was addressed via DSA
    // dump the data to the backup module
    else if (ucDest == ucIolDSA)
    {
        if (ucIdxDump > MAXSLOTS)
        {
            xmit_buffer[IOLRESP_REDSTATE] = REDSTATE_DUMP_COMPLETE;
            BOX->SetRedState(REDSTATE_DUMP_COMPLETE);
            //Donot allow update of OpInternal Parameter  b/w period of 
            //dump complete and sync as it will affect redchksum calculation
            BOX->AppPostDump();
            BOX->SyncStcCounter(TRUE);
        }
        else if (ucIdxDump == 0)
        {
            xmit_buffer[IOLRESP_REDSTATE] = REDSTATE_DUMP_START;
            BOX->SetRedState(REDSTATE_DUMP_START);
        }
        else
        {      
            if(isHartCapable())
            {
                if(false == bHartDataDump)
                {
                    xmit_buffer[IOLRESP_REDSTATE] = ((ucIdxDump * 2) - 1) + REDSTATE_DUMP_START;
                    BOX->SetRedState(((ucIdxDump * 2) - 1) + REDSTATE_DUMP_START);
                }
                else
                {
                    xmit_buffer[IOLRESP_REDSTATE] = (ucIdxDump * 2) + REDSTATE_DUMP_START;
                    BOX->SetRedState((ucIdxDump * 2) + REDSTATE_DUMP_START);
                }
            }
            else
            {
                xmit_buffer[IOLRESP_REDSTATE] = ucIdxDump + REDSTATE_DUMP_START;
                BOX->SetRedState(ucIdxDump + REDSTATE_DUMP_START);
            }       
        }
        xmit_buffer[IOLMSG_NUMBER] = ucCount + 5;
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP)
        {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else
        { // if none, build the response
            StartResponse();
            if (ucIdxDump <= MAXSLOTS) {

#if 0 //defined(IOPTYPE_SCIOM)
//#if !defined(IOPTYPE_AO16) && !defined(IOPTYPE_HLAI)
                for (UINT8 ucIdx=0; ucIdx<ucCount; ucIdx++) {
                    xmit_buffer[IOLRESP_DUMPDATA + ucIdx] = p[ucIdx];
                }
#else
                // for redesign PMIO, dump data & its order is different compared to series c.
                if (ucIdxDump == 0)
                    BOX->PmioDumpParam(&xmit_buffer[IOLRESP_DUMPDATA]);
                else
                    SLOT(ucIdxDump)->PmioDumpParam(&xmit_buffer[IOLRESP_DUMPDATA]);
#endif
            }
            ComputeFletcher(xmit_buffer, FTYP_APPEND);

            if(isHartCapable())
            { 
                // if slot hart data completed,
                if(true == bHartDataDump)
                {
                    // update for next slot
                    ucIdxDump++;
                    bHartDataDump = false;
                }
                else if(ucIdxDump)
                {
                    // update for slot hart data
                    bHartDataDump = true;
                }
                else
                {
                    // update from boxslot to slot1
                    ucIdxDump++;
                }
            }
            // if nHART or other variants
            else
            {                
                ucIdxDump++;
            }
        }
    }
    // If not via the DSA, must be addressed via a broadcast or DPA
    // Then it is a communication error
    else {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
    }
#endif
    return PA_OK;
}
PASTATUS clsIol::Cmd10Handler(VOID) {

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    UINT8 ucSlotNum = pRcvBuffer[IOLREQ_SLOTNUM];

    // Check that slot number is valid
    if (ucSlotNum > MAXSLOTS) {
        return DO_INVALID_SLOT_INDEX;
    }

    // Check that parameter number is valid
    // If it is, filter and save the data type for the response
    UINT8 ucParamNumber = pRcvBuffer[IOLREQ_PARAMID];
    UINT8 ucDatatype = pDatabase[ucSlotNum]->GetDataType(ucParamNumber);
    if (ucDatatype == DT_NONE) {
        return DO_PARAMETER_INVALID;
    }
#if 0 // ANIL_RE_VISIT
    // Check whether remote fetch is pending for HART dynamic and device parameters.
    if ((ucSlotNum > 0) && 
        (ucParamNumber >= PARAMID_HDYNVAL) && (ucParamNumber <= PARAMID_HSLOTEU)) {
        if ((TRUE == SLOT(ucSlotNum)->GetHartCfgDb().HEnable) &&
            (HDATAINIT_PENDING == SLOT(ucSlotNum)->GetHartDevDb().m_HDataInit)) {
          return IOL_REMOTE_FETCH_PENDING;
        }
    }
#endif
    // Check for gap error
    if (GHOXXX == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else { // if none, build the response
        xmit_buffer[IOLMSG_NUMBER] += pDatabase[ucSlotNum]->GetParamSize(ucParamNumber);
        StartResponse();
        xmit_buffer[IOLRESP_DATATYPE] = ucDatatype;
        pDatabase[ucSlotNum]->ReadParamData(&xmit_buffer[IOLRESP_RDDATA],ucParamNumber,pRcvBuffer[IOLREQ_INDEX]);
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
    }

    return PA_OK;
}
PASTATUS clsIol::Cmd16Handler(VOID) {

    // If I am the backup module and the request was addressed via DSA, do nothing
    if (ucDest == ucIolBA) {

        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {

        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {

        return IOL_CHRCT;
    }

    // Check for gap error
    if (GHOXXX == GHO_NOTINGAP) {

        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else { // if none, build the response

        UINT16 nCount = BOX->CollectNrmEclInfo(&xmit_buffer[IOLRESP_ECLINFO],IOL_MAXXMT_MSGSIZE-10);
        xmit_buffer[IOLMSG_NUMBER] += (UINT8)nCount;
        BOX->CollectNrmEclData(&xmit_buffer[IOLRESP_ECLDATA],nCount);
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }

    return PA_OK;
}
PASTATUS clsIol::Cmd17Handler(VOID) {

    // Get ECL Status
    if (ucDest == ucIolBA) {

        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    if (ucDest == IOL_BROADCAST) {

        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {

        return IOL_CHRCT;
    }
    if (GetGHOXXX() == GHO_NOTINGAP) {

        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else {

        xmit_buffer[IOLRESP_MSGSTS] = BOX->GetNrmEclStatus();
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }

    return PA_OK;
}
PASTATUS clsIol::Cmd1FHandler(VOID) { // Get Write Message Status

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    // Check that character count is correct
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }

    // Check for gap error
    if (GHOXXX == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else { // if none, build the response
        xmit_buffer[IOLRESP_MSGSTS] = WriteMsgQueue.GetMsgStatus(pRcvBuffer[IOLREQ_12DATA]);
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }

    return PA_OK;
}
PASTATUS clsIol::Cmd20Handler(VOID) {
    
    // for redesign PMIO, no IOL ID Checking required.    
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // observed during FCT communication issue and modified accordingly.
    // For COMTOG (bit 0), Len = 0x06
    // For CTLTOG (bit 1), Len = 0x05
    if ((ucNumber != aCmdInfo[ucCommand].CountReq) && 
        (ucNumber != 0x06))
    {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;     
    }

    // If not a broadcast, build the response
    if (ucDest != IOL_BROADCAST) {
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
    }
    else xmit_buffer[IOLMSG_NUMBER] = 0;
    // ANIL_RE_VISIT
    #if 0 //(defined(IOMTYPE_AOH) || defined(IOMTYPE_DO) || defined(IOMTYPE_PI) || defined(IOMTYPE_SVP) || defined(IOMTYPE_SP) || defined(IOMTYPE_UIO))
    BOX->UpdateTOG(pRcvBuffer[IOLREQ_12DATA]);
    #endif // 

    return PA_OK;
}
PASTATUS clsIol::Cmd25Handler(VOID) { // Regenerate Events

    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }
    if (GetGHOXXX() == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else {
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        TaskScheduler.RunTask(TASKID_EVRCTASK);
        StartResponse();
    }
    return PA_OK;
}

PASTATUS clsIol::Cmd26Handler(VOID) { // Update Event Remove Pointer

    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        return IOL_CHRCT;
    }
    if (GetGHOXXX() == GHO_NOTINGAP) {
        BOX->SetCommError(IOL_GAP);
        bCommError = TRUE;
    }
    else {

        UINT16 nCount = (256 * pRcvBuffer[IOLREQ_12DATA]) + pRcvBuffer[IOLREQ_12DATA+1];
        BOX->UpdateNrmEclRemPtr(nCount);
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
        StartResponse();
    }
    return PA_OK;
}
PASTATUS clsIol::Cmd28Handler(VOID) {

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check that character count is correct
    // If it is not and it is a broadcast log a communication error
    // If it is not and it is not a broadcast respond with a NACK
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // Check if given DSA is valid
    // If so, disable transmission of response if request was not directed to me
    //        else build the class 2 response
    if (ucDest != IOL_BROADCAST) {

        if (pRcvBuffer[IOLREQ_12DATA] > MAXDSA) {
            return DO_ILLEGAL_VALUE;
        }
        // Check for gap error
        if (GetGHOXXX() == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else {// if none, build the response
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
            StartResponse();
        }
    }
    else {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        if (pRcvBuffer[IOLREQ_12DATA] != 0x00) return PA_OK;
    }

    SetIolDSA(pRcvBuffer[IOLREQ_12DATA]);
    BOX->SetDSA(ucIolDSA);

    // disable for AO [RTPN-1064] - AO16 Value drops for 2sec when EHPM is getting loaded even if FAULTOPT is set as HOLD
    if (ucIolDSA == 0) {
        BOX->ResetRedData(REDDATA_REDCFG);
    }

    return PA_OK;
}
PASTATUS clsIol::Cmd2AHandler(VOID) {

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check that character count is correct
    // If it is not and it is a broadcast log a communication error
    // If it is not and it is not a broadcast respond with a NACK
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // Check if given DSA is valid
    // If so, disable transmission of response if request was not directed to me
    //        else build the class 2 response
    if (ucDest != IOL_BROADCAST) {

        if ((pRcvBuffer[IOLREQ_12DATA] != 0xFF) && (pRcvBuffer[IOLREQ_12DATA] > MAXDSA)) {
            return DO_ILLEGAL_VALUE;
        }
        // Check for gap error
        if (GetGHOXXX() == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else {// if none, build the response
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
            StartResponse();
        }
    }
    else {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        if (pRcvBuffer[IOLREQ_12DATA] != 0xFF) return PA_OK;
    }

    SetIolBA(pRcvBuffer[IOLREQ_12DATA]);
    BOX->SetBA(ucIolBA);

    return PA_OK;
}
PASTATUS clsIol::Cmd2CHandler(VOID) { // Select Channel A

    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    // Check that character count is correct
    // If it is not and it is a broadcast log a communication error
    // If it is not and it is not a broadcast respond with a NACK
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // If not a broadcast, build the response
    if (ucDest != IOL_BROADCAST) {
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
    }
    else xmit_buffer[IOLMSG_NUMBER] = 0;

    BOX->ResetPRC();

    return PA_OK;
}
PASTATUS clsIol::Cmd2DHandler(VOID) { // Select Channel B
    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    // Check that character count is correct
    // If it is not and it is a broadcast log a communication error
    // If it is not and it is not a broadcast respond with a NACK
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // If not a broadcast, build the response
    if (ucDest != IOL_BROADCAST) {
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
    }
    else xmit_buffer[IOLMSG_NUMBER] = 0;

    BOX->SetPRC();

    return PA_OK;
}

PASTATUS clsIol::Cmd2FHandler(VOID) {  // Freeze Database

    if (BOX->GetRedState() != REDSTATE_FREEZE_PERMITTED) {
        BOX->SetRedState(REDSTATE_FREEZE_NOT_ACCEPTED);
        if (ucDest == ucIolBA) xmit_buffer[IOLMSG_NUMBER] = 0;
        else return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    else BOX->SetRedState(REDSTATE_FREEZE_ACCEPTED);

    BOX->MarkStcCounter(ucDest != ucIolBA);

    return Cmd0AHandler();
}
PASTATUS clsIol::Cmd32Handler(VOID) { // Reset Communication Errors
    // If I am the backup module and the request was addressed via DSA
    // do nothing
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }
    // Check that character count is correct
    // If it is not and it is a broadcast log a communication error
    // If it is not and it is not a broadcast respond with a NACK
    if (ucNumber != aCmdInfo[ucCommand].CountReq) {
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_CHRCT);
            bCommError = TRUE;
            return PA_OK;
        }
        return IOL_CHRCT;
    }

    // If not a broadcast, build the response
    if (ucDest != IOL_BROADCAST) {
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
    }
    else xmit_buffer[IOLMSG_NUMBER] = 0;

    BOX->ResetCommErrs();

    return PA_OK;
}
PASTATUS clsIol::Cmd33Handler(VOID) { // Test Hardware Functions

    UINT8 ucSubCommand;
    UINT16 usCount = 0;
    UINT16 InvalidCharCnt = NO_INVALID_CHARS;
    UINT8 ChkSumLo = 0;
    UINT8 ucSubCmdData;

    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        return PA_OK;
    }

    // Check for illegal broadcast
    if (ucDest == IOL_BROADCAST) {
        BOX->SetCommError(IOL_DEST);
        bCommError = TRUE;
        return PA_OK;
    }

    ucSubCommand = pRcvBuffer[IOLREQ_SUBCMD];

    switch(ucSubCommand)
    {
    case UPDT_HWVER_NO:
        if (ucNumber != UPDT_HWREVCODE_MSG_CC)//0x09
            return IOL_CHRCT;
        break;
    case UPDT_SERIAL_NO:
        if (ucNumber != UPDT_SERIAL_NO_MSG_CC)//0x0C
            return IOL_CHRCT;
        break;
    case CHNG_SPLSIGNALS:
        if(ucNumber != CHNG_SPLSIGNALS_MSG_CC)
            return IOL_CHRCT;
        break;
    case UPDT_PROD_TYPE:
        if(UPDT_PROD_TYPE_CC != ucNumber)     //0x0D
            return IOL_CHRCT;
        break;
    case UPDT_PROD_CODE:
        if(UPDT_PROD_CODE_CC != ucNumber)     //0x0E
            return IOL_CHRCT;
        break;
    default:
        if (ucNumber != aCmdInfo[ucCommand].CountReq)
                return IOL_CHRCT;
        break;
    }

    //If the Module is not in Factory test Mode return invalid mode error.
    if(!(BOX->CheckForFactoryTestMode()))
         return DO_INVALID_MODE;

    //If this command request does not have security data do not proceed further
    //return back with illegal value.
    if(!((SECURTYDATA1 == pRcvBuffer[IOLREQ_SCRTYDATA]) &&
         (SECURTYDATA2 == pRcvBuffer[IOLREQ_SCRTYDATA+1]) &&
         (SECURTYDATA3 == pRcvBuffer[IOLREQ_SCRTYDATA+2])))
        return DO_ILLEGAL_VALUE;

    switch(ucSubCommand)
    {
    //SeriesC IOMs have windowed WDT.If the WDT is not refreshed between
    //100 & 150msec, the WDT expires and the IOM hard fails. This test
    //verifies this scenario.
    case WDT1_TST://WDT Test
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
#if 0//def DEBUG
        TaskScheduler.EnableWatchdog();
#endif
        BOX->ResetTstFunctTime();

#if (HEK && (defined(IOMTYPE_AOH)))
        while (hal_uart_tx_complete(HAL_UART_IOL) == FALSE); //Wait till Response is sent out
#endif
        FactryModeWDTUTest = TRUE;
        break;

    case GHO_TST://GHO Test
        // Check for gap error
        BOX->SetTstFunctTimeStsToFail();
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
            return PA_OK;
        }
        else { // if none, build the response
            // Send the ACK for the request command.
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
        //The GHO timer resets when there is a 1-0 transistion.ChkSumLo
        //is the last byte to be transmitted in the ACK response.Based
        //on which bit is high the time when the GHO was restarted is determined.
        //At 750Kbps, it takes 1.33usec to transmit one bit which 8 TPU5 counts
        ChkSumLo = xmit_buffer[IOLRESP_ACKCHKSUMLO];
             if(ChkSumLo & 0x80) usCount = BASETPU5COUNT;
        else if(ChkSumLo & 0x40) usCount = BASETPU5COUNT+(BITTPU5COUNT*1);
        else if(ChkSumLo & 0x20) usCount = BASETPU5COUNT+(BITTPU5COUNT*2);
        else if(ChkSumLo & 0x10) usCount = BASETPU5COUNT+(BITTPU5COUNT*3);
        else if(ChkSumLo & 0x08) usCount = BASETPU5COUNT+(BITTPU5COUNT*4);
        else if(ChkSumLo & 0x04) usCount = BASETPU5COUNT+(BITTPU5COUNT*5);
        else if(ChkSumLo & 0x02) usCount = BASETPU5COUNT+(BITTPU5COUNT*6);
        else if(ChkSumLo & 0x01) usCount = BASETPU5COUNT+(BITTPU5COUNT*7);
        else                     usCount = BASETPU5COUNT+(BITTPU5COUNT*8);

#if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        while (hal_uart_tx_complete(HAL_UART_IOL) == FALSE); // Wait until ChecksumLo is finished
#endif

#if 0 // temp for testing
        //usCount -= TPU5_TCNT;  // Add the TPU count when ChecksumLo is finished
        if(TPU5_TCNT > usCount)
            usCount = TPU5_TCNT-usCount;
        else// Handling the wrap around condition
            usCount = (TPUCOUNT_MAXVALUE-usCount)+TPU5_TCNT;

        while (GHOXXX == GHO_NOTINGAP); // Wait till GHO timer expires

        //usCount += TPU5_TCNT;
        if(TPU5_TCNT > usCount)
            usCount = TPU5_TCNT-usCount;
        else
            usCount = (TPUCOUNT_MAXVALUE-usCount)+TPU5_TCNT;

        usCount /= TPUCOUNT_IN_MICROSECOND;  // 1 TPU count = 1/6 micro second
#endif

        BOX->SetTstFunctTime((INT32)usCount);

        break;
    case JABBER_TST://Jabber Test
       BOX->ResetTstFunctTime();
       Iol.xmit_buffer[IOLMSG_NUMBER] = IOL_MAXIFIELD + 4;//Setting for MAX Reply size
       //In this test the transmission of reply message is handled from here.
#if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        // Clear error bits + int flags
        hal_uart_clear_errors(HAL_UART_IOL);
        hal_uart_clear_flag(HAL_UART_IOL, (HAL_UART_IRQ_TYPE)(HAL_UART_IRQ_RX_DATA  |
                                                              HAL_UART_IRQ_TX_EMPTY |
                                                              HAL_UART_IRQ_TX_DONE  |
                                                              HAL_UART_IRQ_RX_ERROR));
       //Ensuring a fresh start of Jabber.
       SetJABRES_n(0);  // Reset jabber lock
       SetJABRES_n(1);  // Arm jabber again
     //while (TPU4_TCNT < TPU4CNT_TMGAP);    // Wait Tmgap before respondng // temp for testing
       IOL_TxEnable();                         // enable transmitter
       SetTXREQ_n(IOLDRV_ON);                // turn on RS-485 transmitter
       hal_uart_clear_flag(HAL_UART_IOL, (HAL_UART_IRQ_TYPE)(HAL_UART_IRQ_TX_EMPTY | HAL_UART_IRQ_TX_DONE));    // Clear TDR int flag
       IOL_WriteByte(xmit_buffer[IOLMSG_DESTINATION], IOL_ALERT_XMIT_ADDR); // set alert bit in first char   
     //usCount = TPU5_TCNT;                  //Save the TPU5_CNT at the start of Jabber Timer // temp for testing
       while(!IOL_TxBufEmpty());             //Wait till TDR is empty
       Iol.TransmitData(Iol.xmit_buffer[IOLMSG_NUMBER], IOL_ALERT_XMIT_DATA);
       Iol.TransmitData(Iol.xmit_buffer[IOLMSG_SOURCE], IOL_ALERT_XMIT_DATA);
       Iol.TransmitData(Iol.xmit_buffer[IOLMSG_COMMAND], IOL_ALERT_XMIT_DATA);
#if 0 //(!AIAO)
       RDBK_SEL =  RDBK_IOTA;    // Set readback register for reading JABLOCK_n
#endif // (!AIAO)
       //JABLOCK_n is a active low signal. It is set to 0 when jabber
       //timer expires.Keep transmitting until JABLOCK_n is set or
       //maximum chars are xmitted out.
       while ((GetJABLOCK_n() == JABLOCK_NEGATED ) && ( InvalidCharCnt > 0))
       {
           Iol.TransmitData(TEST_BYTE, IOL_ALERT_XMIT_DATA);
         //BOX->SetTstFunctTime((UINT32)((TPU5_TCNT - usCount)/TPUCOUNT_IN_MICROSECOND)); // temp for testing
           InvalidCharCnt--;
       }
       if(0 == InvalidCharCnt)
       {
           //For this line to execute the Jabber timer should not have expired
           //even after transmitting 900 chars, which means that there is a
           //problem with it and thus test result is set to -1;
           BOX->SetTstFunctTimeStsToFail();
       }
       IOL_TxDisable();                            // disable transmitter
       SetTXREQ_n(IOLDRV_OFF);                  // turn off RS-485 transmitter
       hal_uart_clear_flag(HAL_UART_IOL, (HAL_UART_IRQ_TYPE)(HAL_UART_IRQ_RX_DATA  | 
                                                             HAL_UART_IRQ_TX_EMPTY | 
                                                             HAL_UART_IRQ_TX_DONE));  // Clear TDR, RDR int flags
       IOL_DisAllInt();                         // Disable all ints                
#endif

#if 0 // temp for testing
       // modified for FCT testing (JABBER TEST - TEST#5)
       if (InvalidCharCnt)
       {
           usCount = (TPU5_TCNT > usCount) ? (TPU5_TCNT - usCount) : (TPUCOUNT_MAXVALUE - usCount) + TPU5_TCNT;
           usCount /= TPUCOUNT_IN_MICROSECOND; // 1 TPU count = 1/6 micro second
           BOX->SetTstFunctTime((INT32)usCount * 4); // adjusting value with 4, as per PMIO limits.
           FactryModeJabberTest = TRUE;
       }
       TPU4_TCNT = 0;                            // reset the counter
#endif
       SetJABRES_n(0);  // Reset jabber lock
       SetJABRES_n(1);  // Arm jabber again
       break;
    case JBR_RES_TST://Jabber Circuit Reset
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else { // if none, build the response
            // modified for FCT testing (JABBER TEST - TEST#5)
            if (TRUE == FactryModeJabberTest)
                FactryModeJabberTest = FALSE;
            else {
                BOX->ResetTstFunctTime();
            }
            SetJABRES_n(0);  // Reset jabber lock
            SetJABRES_n(1);  // Arm jabber again
            #if 0 //(!AIAO)
            RDBK_SEL =  RDBK_IOTA;  // Set readback register for reading JABLOCK_n
            #endif // (!AIAO)

            if(GetJABLOCK_n() == JABLOCK_ASSERTED) { 
                BOX->SetTstFunctTimeStsToFail(); 
            }
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
        }
        break;
    case JBR_RES_XMIT_TST://Jabber Reset and Transmit circuit Test
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else { // if none, build the response
            BOX->ResetTstFunctTime();
            SetJABRES_n(0);  // Reset jabber lock
            StartResponse();        //Start xmitting the response
          //usCount = TPU5_TCNT; // temp for testing
            //It is understood that it takes around 150microsec for the hardware to pull down the IOM when data is xmitted with Jabber ckt unarmed.
          //while ((TPU5_TCNT - usCount) < TPU_TCNT_FOR_150MICROSEC);//Wait 150usec // temp for testing
            //The IOM should hardfail by now. If not set -1 at TstFunctTime param
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
            BOX->SetTstFunctTimeStsToFail();
        }
        break;
    case UPDT_HWVER_NO:
    case UPDT_SERIAL_NO:
    case UPDT_PROD_CODE:
    case UPDT_PROD_TYPE:
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
            while (GetTXREQ_n() == IOLDRV_ON);// wait until transmission is complete
            //Due to limited memory in digital modules,WriteMessage queue
            //is reused as buffer during flash operation. Therefore while  
            //executing the flash routine, IOL needs to be disabled.
            Iol.Disable(); //Disable the IOL. 
            HWRevCodeWriteInProgress = TRUE;

            set_imask_exr(3);//Lower the prioirty of the interrupt.
            if(!BOX->FlashHWRevCode())
                BOX->SetTstFunctTimeStsToFail();
            RebootIom();
        }
        break;
    case HARTLPBK_TST:
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP)
        {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else
        { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
            HartLoopBkTestInProgress = TRUE;
        }
        break;
    case CHNG_SPLSIGNALS:
        //7 bits in the data have the signal id and the MSB will be used to
        //set/reset the signal value. 
        ucSubCmdData = pRcvBuffer[IOLREQ_SPLSGNDATA] & DATA_BITS;
        switch(ucSubCmdData)
        {
            case SWBUREQ_SIGNAL:
                SetBupreqOut(BOOL(pRcvBuffer[IOLREQ_SPLSGNDATA] & SETMODE_BIT));
                break;
    // ANIL_RE_VISIT
    #if 0 //(defined(IOMTYPE_AOH) || defined(IOMTYPE_AO))
            case TST_SW_SIGNAL :
                TST_n  = BOOL(pRcvBuffer[IOLREQ_SPLSGNDATA] & SETMODE_BIT);
                break;
            case INH_SW2_SIGNAL:
                INH_SWB = (pRcvBuffer[IOLREQ_SPLSGNDATA] & SETMODE_BIT);
                break;
            case INH_SW1_SIGNAL:
                INH_SWA = (pRcvBuffer[IOLREQ_SPLSGNDATA] & SETMODE_BIT);
                break;
            case DIS_SW1_SIGNAL:
                DIS_SWA_n = BOOL(pRcvBuffer[IOLREQ_SPLSGNDATA] & SETMODE_BIT);
                break;
            case DIS_SW2_SIGNAL:
                DIS_SWB_n = BOOL(pRcvBuffer[IOLREQ_SPLSGNDATA] & SETMODE_BIT);
                break;
    #endif
            default : return DO_ILLEGAL_VALUE;

        }
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer,FTYP_APPEND);
        }
        break;
    default : 
        return DO_COMMAND_NOT_SUPPORTED;
    }

    return PA_OK;
}

PASTATUS clsIol::Cmd35Handler(VOID) { 

#if defined(IOL_CLEAR_XMIT_LEN_ON_RX) && IOL_CLEAR_XMIT_LEN_ON_RX
    Iol.xmit_buffer[IOLMSG_NUMBER] = 0;
#endif

    return PA_OK;
}
PASTATUS clsIol::Cmd37Handler(VOID) { // Unfreeze Database

    // If I am the backup module and the request was addressed via DSA
    // set REDSTATE and get out
    if (ucDest == ucIolBA) {
        xmit_buffer[IOLMSG_NUMBER] = 0;
        BOX->SetRedState(REDSTATE_FREEZE_PERMITTED);
    }
    else {
        // Check for illegal broadcast
        if (ucDest == IOL_BROADCAST) {
            BOX->SetCommError(IOL_DEST);
            bCommError = TRUE;
            return PA_OK;
        }
        // Could check here for char count but did not for consistency w/ PMIO
        // Check for gap error
        if (GHOXXX == GHO_NOTINGAP) {
            BOX->SetCommError(IOL_GAP);
            bCommError = TRUE;
        }
        else { // if none, build the response
            StartResponse();
            ComputeFletcher(xmit_buffer, FTYP_APPEND);
            BOX->SetRedState(REDSTATE_FREEZE_PERMITTED);
        }
    }

    return PA_OK;
}

PASTATUS clsIol::DefaultHandler(VOID)
{
    if (ucDest != IOL_BROADCAST) {

        BOX->SetCommError(IOL_COMM);
        bCommError = TRUE;
    }

    return PA_OK;
}

PASTATUS clsIol::BroadcastHandler(VOID)
{

    if (ucDest != IOL_BROADCAST) {

        BOX->SetCommError(IOL_COMM);
        ResetSilenceTimer(CNTLNKSIL);
        IOL_TxInterrupt(FALSE);
        IOL_TxDoneInterrupt(FALSE);
        IOL_RxInterrupt(TRUE);
    }

    return PA_OK;
}

VOID clsIol::TransmitData(UINT8 data, UINT8 AlertBit) {
    hal_uart_clear_flag(HAL_UART_IOL, (HAL_UART_IRQ_TYPE)(HAL_UART_IRQ_TX_EMPTY | HAL_UART_IRQ_TX_DONE));    // Clear TDR int flag
    IOL_WriteByte(data, AlertBit);        // send address with 9th bit set
    while(!IOL_TxBufEmpty());           // Wait TX data register ready
}

/*******************************************************************************
*                       clsIol::ProcessDefWrCmd                                *
*                       =======================                                *
* PURPOSE:                                                                     *
*    Process deferred write command (BRDP) I-field extraction.  Get first 4    *
*    I-field characters, then remaining HART request bytes.                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    TRUE if all fields received, FALSE on timeout.                            *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
BOOL clsIol::ProcessDefWrCmd(VOID)
{
#if 0
    // Get first 4 I Field characters in diff location as they are not part of HART
    // Request. Next I field characters are part of HART message, so get them in 
    // appropriate HART Req Buffer after finding if we have space to allocate that.
    UINT16 uiMask = 0x0001;
    UINT8 *p,ucCount,ucTimeOut,ucSlotNum,ucPstIndex,ucBRDPIFieldCount = 0;

    while (ucBRDPIFieldCount != BRDPFIELDCOUNT) {
        ucTimeOut = NCYCLES_CHARTO;
#if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        while (!IOL_RxDatReady()) {                   // Wait for next character
            ucTimeOut--;                                 // Count down counter
            // if TO, log error, reset Link Silence Timer, disable rcvr + return
            if (ucTimeOut == 0) {
                BOX->SetCommError(IOL_CHRTM);
                Iol.ResetSilenceTimer(CNTLNKSIL);
                P_SCI2.SCR.BYTE = 0x00;
                return FALSE;
            }
        }
        P_SCI2.SSR.BIT.RDRF = IOL_RDRF_RESET;            // Clear RDR int flag
        if (P_SCI2.SSR.BIT.MPB == IOL_ALERT_SET) {       // If Alert bit is set
            BOX->SetCommError(IOL_ALERT);                // Error
            Iol.ResetSilenceTimer(CNTLNKSIL);            // Reset Link Silence Timer
            P_SCI2.SCR.BYTE = 0x00;                      // Disable everything
            return FALSE;
        }
        // Copy first 4 I -Filed bytes in temp buffer for processing.
        Iol.ucBRDPInfoField[ucBRDPIFieldCount] = P_SCI2.RDR; // put character into Ifield buffer
#endif

        Iol.Add2Checksum(Iol.ucBRDPInfoField[ucBRDPIFieldCount]);
        if (ucBRDPIFieldCount == BRDP_HANDLE_OFFSET) {
            // Setup the starting index based on the current passthrough append index in the
            // channel object. This will ensure that messages are processed in the order received.
            ucSlotNum = ((Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET] & BRDP_HNDL_MSK) >> 3) + 1;
            ucPstIndex = SLOT(ucSlotNum)->GetHartDevDb().m_ucPstAppIndex + 1;
            if (ucPstIndex >= HPST_OBJECTCOUNT) ucPstIndex = 0;
            uiMask = 0x0001 << ucPstIndex;
        }
        ucBRDPIFieldCount++;
    }

    // Find out whether we can have resources to accept this HART request.
    // Make sure the decision is made within 14 us.
    BOOL bResFull = (ALLHNDLBUSY == BOX->BRDPResourceStatus) ? TRUE :FALSE;

    if (!bResFull) {
        // Start searching from the current PST index in the channel object
        // to ensure that the messages will be processed in the order received.
        UINT8 ucCount = HPST_OBJECTCOUNT;
        while (ucCount) {
            if (!(BOX->BRDPResourceStatus & uiMask)) break;
            uiMask <<= 1;
            if (uiMask == 0) {
                uiMask = 1;
                ucPstIndex = 0;
            }
            else ucPstIndex++;
            ucCount--;
        }
        // Check if the request is Split request and store it at proper offset
        // depending on packet number received.
        if((Iol.ucBRDPInfoField[BRDP_HEADER_OFFSET] & BRDP_SPLIT_REQUEST) && 
            (Iol.ucBRDPInfoField[BRDP_HEADER_OFFSET] & HART_SPLIT_PACKET_MASK)) {
            p = &g_ucHPstReqBuffer[BOX->SPLTRequestHndlTable[Iol.ucBRDPInfoField[BRDP_HANDLE_OFFSET]]][0] + 
                (HART_REQ_BYTES_PER_IOL_MSG * 
                (Iol.ucBRDPInfoField[BRDP_HEADER_OFFSET] & HART_SPLIT_PACKET_MASK));
        }
        else {
            p = &g_ucHPstReqBuffer[ucPstIndex][0];
        }
        // need to save this to use it in Cmd0Chandler.
        Iol.ucBRDPInfoField[BRDP_MSGNO_OFFSET] = ucPstIndex;
    }
    //calculate remaining bytes to be received....
    ucCount = Iol.ucNumber - 4 - BRDPFIELDCOUNT;
    while (ucCount) {
        ucTimeOut = NCYCLES_CHARTO;
        #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        if(FALSE == IsFpgaS2) // S3 FPGA
        {
            while (!P_SCI2.SSR.BIT.RDRF) {                  // Wait for next character
                ucTimeOut--;                                // Count down counter
                // if TO, log error, reset Link Silence Timer, disable rcvr + return
                if (ucTimeOut == 0) {
                    BOX->SetCommError(IOL_CHRTM);
                    Iol.ResetSilenceTimer(CNTLNKSIL);
                    P_SCI2.SCR.BYTE = 0x00;
                    return FALSE;
                }
            }
            P_SCI2.SSR.BIT.RDRF = IOL_RDRF_RESET;           // Clear RDR int flag
            if (P_SCI2.SSR.BIT.MPB == IOL_ALERT_SET) {      // If Alert bit is set
                BOX->SetCommError(IOL_ALERT);               // Error
                Iol.ResetSilenceTimer(CNTLNKSIL);           // Reset Link Silence Timer
                P_SCI2.SCR.BYTE = 0x00;                     // Disable everything 
                return FALSE;
            }
            if (!bResFull) {
                *p = P_SCI2.RDR;                            // put character into buffer
                Iol.Add2Checksum(*p);
                p++;
            }
            else { // do not store the message. we have to discard as we do not have space.
                //however do the checksum calculation.
                Iol.Add2Checksum(P_SCI2.RDR);
            }
        }
        else //if(TRUE = IsFpgaS2)
        #endif
        {        
            while (!IOL_RDRF) {                          // Wait for next character
                ucTimeOut--;                                      // Count down counter
                // if TO, log error, reset Link Silence Timer, disable rcvr + return
                if (ucTimeOut == 0) {
                    BOX->SetCommError(IOL_CHRTM);
                    Iol.ResetSilenceTimer(CNTLNKSIL);
                    IOL_SCR = 0x00;
                    return FALSE;
                }
            }
            IOL_RDRF = IOL_RDRF_RESET;                        // Clear RDR int flag
            if (IOL_ALERT_RCVD == IOL_ALERT_SET) {           // If Alert bit is set
                BOX->SetCommError(IOL_ALERT);                              // Error
                Iol.ResetSilenceTimer(CNTLNKSIL);       // Reset Link Silence Timer
                IOL_SCR = 0x00;                               // Disable everything 
                return FALSE;
            }
            if (!bResFull) {
                *p = IOL_RDR;                              // put character into buffer
                Iol.Add2Checksum(*p);
                p++;
            }
            else { // do not store the message. we have to discard as we do not have space.
                //however do the checksum calculation.
                Iol.Add2Checksum(IOL_RDR);
            }
        }
        ucCount--;
    }

    // Update pass-through append index in the channel object.
    SLOT(ucSlotNum)->GetHartDevDb().m_ucPstAppIndex = ucPstIndex;

#endif // 0
    return TRUE;
}
