/*
 * debug.hpp
 *
 *  Created on: 03-Jun-2026
 *      Author: E829166
 */

#ifndef DEBUG_HPP_
#define DEBUG_HPP_

#include "datatype.h"

#define DBG_PRINT 1

/*******************************************************************************
*                                     clsDebug                                 *
*                                     ========                                 *
*******************************************************************************/
class clsDebug {

private:
    UINT16 TempBuff[255];

public:
    VOID Print(UINT32 ulValue);
};

#endif /* DEBUG_HPP_ */
