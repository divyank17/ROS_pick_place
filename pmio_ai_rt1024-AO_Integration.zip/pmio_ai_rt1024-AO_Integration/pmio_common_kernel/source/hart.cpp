/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hart.cpp                                                    *
*    Description : HART global data and functions.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/

// Intentionally preventing aihmain.h and aohmain.h from being included in those contexts.
#if 0   // ANIL_RE_VISIT
 #include "aohmain.h"


// ------------------------------------
// Start Global Variables and functions
// ------------------------------------

/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/

const UINT8 clsHartCfgDb::HDevCd[] = { 0, 0, 0, 0, 0, 0, 0 };
// ANIL_RE_VISIT

const HARTCMDHANDLER clsHartDevDb::HartCmdHandler[] = { {0, 0} };
UINT8 clsHartDevDb::m_stucNoOf1SecChannels = 0;
EVENTRECORD clsHartDevDb::HAlmOptChgEvent = {};
UINT8 clsHartModem::m_ucFailedChannel = 0;

VOID clsHartDevDb::InitDevDb(BOOL)
{
    m_HChanMode = HCHANMODE_INIT;
    m_HDataInit = HDATAINIT_PENDING;
    m_HEventInit = HEVENTINIT_PENDING;
    m_ucInitCmdIndex = 0;
    m_ucScanNo = 0;
    m_ucSavedScanNo = 0;
    m_ucB2BNo = 0;
    m_ucSkipC48Cycles = 0;
    m_ucTemplateChangeWaitCount = 0;
    m_bReReportEvents = FALSE;
    HComSts = HCOMSTS_GOOD;
    HLComFail = HCOMSTS_GOOD;
    HNComErr = 0;
    HCmdFail = HARTCOMMAND_INVALID;
    HCmdResp = 0;
    Command = COMMAND_UNDEFINED;
    BuildScanTable();
}

BOOL clsHartDevDb::PostHAlmOptChgEvent(BOOL)
{
    return FALSE;
}

VOID clsHartDevDb::BuildScanTable(VOID)
{
    for (UINT8 ucCycle = 0; ucCycle < MAX_CYCLE_NUMBER; ucCycle++) {
        for (UINT8 ucMsg = 0; ucMsg < MAX_MSGS_IN_A_CYCLE; ucMsg++) {
            m_ScanMsgTbl[ucCycle][ucMsg] = HSCANMSG_NONE;
        }
    }
}

/*******************************************************************************
*                               isHartCapable                                  *
*                               =============                                  *
* PURPOSE: Determine if the HW is HART capable                                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Called by aihmain and aohmain. Meaningless if it is called by di/do   *
*        If MUXADDR (0x80010) is Read Only, the module is Hartless             *
*******************************************************************************/
BOOL isHartCapable(VOID)
{
#if 1
    if (HART_MUXADDR == 0x0000)   // initial state?
    {
        HART_MUXADDR = 0xA5A5;   // Write some value
        IdleWait(1);
        if (HART_MUXADDR == 0x0000)
        {
            return FALSE;    // all Read Only, this is Hartless
        }
        else  // writable, HART module
        {
            HART_MUXADDR = 0x0000; // restore the data
        }
    }
    // if not 0, it is already used as HART
#endif
    return TRUE;
}

/*******************************************************************************
*                               CheckAndInitHart                               *
*                               ================                               *
* PURPOSE:      Initialize HART registers for HART modules                     *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is HART            *
*******************************************************************************/
VOID CheckAndInitHart(VOID) {

}
/*******************************************************************************
*                               ResetHart                                      *
*                               =========                                      *
* PURPOSE:      Reset Hart UARTS                                               *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is Hartless        *
*******************************************************************************/
VOID ResetHart(VOID)
{

}


/*******************************************************************************
*                                    HartTask                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN HartTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_HARTTASK);

    if ((BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA)) {
        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {

            SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;

        }


    }

    static UINT8 sucHChanToProcess = 1;
    const  UINT8 CHANNELS_PER_CYCLE = 4;

// ANIL_RE_VISIT
        for (UINT8 ucChan = 0; ucChan < CHANNELS_PER_CYCLE; ucChan++)
        {
            SLOT(sucHChanToProcess)->GetHartDevDb().ChannelHeartbeat();
            SLOT(sucHChanToProcess++)->GetHartDevDb().ProcessHartEvents(FALSE);
        }

        if (sucHChanToProcess > MAXSLOTS) {
            sucHChanToProcess = 1;

            // Update HCuAvail
            FLOAT32 fTotalHartLoad = 100.0;
            for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
                fTotalHartLoad -= SLOT(ucChan)->GetHartDevDb().GetHartLoading();
            }
            BOX->SetHCuAvail(fTotalHartLoad);
        }

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
/*******************************************************************************
*                              InitHartConnection                              *
*                              ==================                              *
* PURPOSE:                                                                     *
*    Initiate a HART transaction.                                              *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel object number which requests connection.            *
* RETURN:                                                                      *
*    Boolean. TRUE if request is accepted; FALSE if rejected.                  *
* PROCESS:                                                                     *
*    1. Add a_pClient to the stack queue.                                      *
* NOTES:                                                                       *
*    1. This function is used by channel object to initiate HART transaction.  *
*    2. Modem objects periodically checks the stack queue and uses the client  *
*       reference and callback interface to carry out the HART transaction.    *
*******************************************************************************/
BOOL InitHartConnection(UINT8 a_ucChan)
{
    return HartQueue.AddToQueue(a_ucChan);
}
/*******************************************************************************
*                             AbortHartConnection                              *
*                             ===================                              *
* PURPOSE:                                                                     *
*    Abort a previously initiated HART transaction.                            *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if transaction is aborted; FALSE if any transaction with    *
*    the specified client is not found.                                        *
* PROCESS:                                                                     *
*    1. Check the stack queue for the passed reference and remove from queue   *
*       if it is found.                                                        *
*    2. Otherwise check each modem object for their client references and      *
*       disconnect the modem if a match with the passed reference is found.    *
* NOTES:                                                                       *
*    1. Note that Disconnect method a private method in clsModem and cannot be *
*       called from here. Instead a request is made is to the modem object     *
*       which will be processed subsequently by the modem interrupt routines.  *
*       Disconnect need to be protected as private method to streamline the    *
*       modem state change.                                                    *
*******************************************************************************/
BOOL AbortHartConnection(UINT8 a_ucChan)
{

    // If the request is in the queue, remove it
    if (HartQueue.RemoveFromQueue(a_ucChan) == TRUE)
    {
        return TRUE;
    }

    // If not in the queue, check whether any modem is
    // processing it. If yes, disconnect and free the modem.
    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) {
        if (pHartModem[ucModem]->GetConnectedChannel() == a_ucChan) {
            pHartModem[ucModem]->RequestDisconnect();
            return TRUE;
        }
    }

    // No match for the passed refence is found. Nothing to abort.
    return FALSE;
}
/*******************************************************************************
*                             ProcessHartInterrupt                             *
*                             ====================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID ProcessHartInterrupt(VOID) {
    // This static variable ensures equal priority for processing all modems.
    //static UINT8 stucModemToProcess = 0;


}

// ----------------------------------
// End Global Variables and Functions
// ----------------------------------


#ifndef UIO_HART_GLOBAL
// ----------------------------------
// Start Slot Variables and Functions
// ----------------------------------

/*******************************************************************************
*                         clsAihSlot::GetRcvBufObject                          *
*                         clsAohSlot::GetRcvBufObject                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

clsClientBuffer& clsAohSlot::GetRcvBufObject(VOID)
{
    extern clsHartPst *pHartPst[];

    if (HCHANTYPE_CHANNEL == HartDevDb.m_HChanType) {
        return HartDevDb.m_ChanRcvBuffer;
    }
    else if (HCHANTYPE_PASSTHROUGH == HartDevDb.m_HChanType)
    {
        return pHartPst[HartDevDb.m_ucPstRemIndex]->m_PstRcvBuffer;
    }
    else
    {
        HardFail(HF_INVPROGRAMEXEC,HART_CPP,__LINE__);
        // Return value is just to silence compiler.
        return HartDevDb.m_ChanRcvBuffer;
    }
}
/*******************************************************************************
*                           clsAihSlot::PreCommand                             *
*                           clsAohSlot::PreCommand                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreCommand(UINT8 *a_WriteBuffer,UINT8)
{
    if ((*(COMMAND *)a_WriteBuffer < COMMAND_ACCEPTCFG) ||
        (*(COMMAND *)a_WriteBuffer > COMMAND_RESETHCOMERR))
    {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostCommand                            *
*                           clsAohSlot::PostCommand                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

VOID clsAohSlot::PostCommand(UINT8)
{
    if (COMMAND_RESETHCOMERR == HartDevDb.Command)
    {
        HartDevDb.HComSts     = HCOMSTS_GOOD;
        HartDevDb.HLComFail   = HCOMSTS_GOOD;
        HartDevDb.HNComErr    = 0;
        HartDevDb.HCmdFail    = HARTCOMMAND_INVALID;
        HartDevDb.HCmdResp    = 0;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_EXCOMMERR_MASK;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_CMDFAIL_MASK;

        for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
        {
            pHartModem[ucModem]->ClearModemBad();
        }

        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++)
        {
            SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
        }
    }

    // No need to do anything for accept configuratoin as the controller
    // is going to write HDVxxCD parameters to the IOM. PostHDevIdCd will
    // take care resetting any mismatch alarms present.

    HartDevDb.Command = COMMAND_UNDEFINED;
}
/*******************************************************************************
*                           clsAihSlot::PreHEnable                             *
*                           clsAohSlot::PreHEnable                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHEnable(UINT8 *a_WriteBuffer,UINT8)
{
    if (*(UINT8 *)a_WriteBuffer > TRUE)
    {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHEnable                            *
*                           clsAohSlot::PostHEnable                            *
*                           =======================                            *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/

VOID clsAohSlot::PostHEnable(UINT8)
{
    if ((PNTTYPE_NOTCONFIGURED != PntType) || BOX->GetHADCEnable(ChanNum))
    { // if channel is configured or STAC ops
        if (TRUE == HartCfgDb.HEnable)
        {
            if (HCHANMODE_INIT == HartDevDb.m_HChanMode)
            {
                if (!isnan(OpFinal) && (OpFinal > OP_LOLIMIT))
                {
                    // Initialization commands not completed yet
                    HartDevDb.m_HDataInit = HDATAINIT_PENDING;
                    if (HartDevDb.m_ucInitCmdIndex < 1)
                    {
                        // if first C48 is not complete yet
                        HartDevDb.m_HEventInit = HEVENTINIT_PENDING;
                    }
                }
            }

            UINT8 ucDsa = BOX->GetDSA();
            if ((ucDsa > 0) && (ucDsa <= MAXDSA))
            {
                // IOM is primary is channel configued with HART enabled.
                // Start HART scanning in this cycle.
                HartDevDb.m_sScanCounter = TICKS_IN_1_SEC;
            }
        }
        else
        { // Channel configured with HART disabled.
            HartDevDb.InitDevDb(TRUE);
            BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
        }
    }
    else // Channel deleted
    {
        BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
    }
}
/*******************************************************************************
*                           clsAihSlot::PreHAlarmEnable                        *
*                           clsAohSlot::PreHAlarmEnable                        *
*                           ===========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHAlarmEnable(UINT8 *a_WriteBuffer,UINT8 a_ucAccLvl)
{
    // Save current configuration
    ScratchPad = HartCfgDb.HAlarmEnable;

    if (ALVL_IUSER == a_ucAccLvl) {
        // If warm restore and checkpoint restore is
        // going on accept the write value as it is.
        return PA_OK;
    }

    // Update the writebuffer according to write value coming down.
    switch (*a_WriteBuffer) {
    case HALARMENABLE_ALMENBSTATE_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_ALMENBSTATE_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_JOURNALONLY_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_JOURNALONLY_MASK;
        break;
    default:
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;
}
/*******************************************************************************
*                          clsAihSlot::PostHAlarmEnable                        *
*                          clsAohSlot::PostHAlarmEnable                        *
*                          ============================                        *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/

VOID clsAohSlot::PostHAlarmEnable(UINT8)
{
    // Check for bits changed in HAlarmEnable
    ScratchPad ^= HartCfgDb.HAlarmEnable;

    if (ScratchPad > 0) { // either or both bits got changed
        if (ScratchPad & HALARMENABLE_ALMENBSTATE_MASK)
        {
            // ALMENBSTATE bit changed
            if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK)
            {
                // Alarms got enabled - regen current HART event state
                HartDevDb.m_bReReportEvents = TRUE;
            }
        }

        if (ScratchPad & HALARMENABLE_JOURNALONLY_MASK)
        {
            // JOURNALONLY bit changed
            if (0 == (HartCfgDb.HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK))
            {
                // Alarms got unsuppressed - if ALENBSTATE is enabled
                // then regen current HART event state.
                if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK)
                {
                    HartDevDb.m_bReReportEvents = TRUE;
                }
            }
        }

        // Post appropriate alarm option change event.
        // Pass FALSE as argument for normal event reporting.
        HartDevDb.PostHAlmOptChgEvent(FALSE);
    }
}
/*******************************************************************************
*                           clsAihSlot::PreHScanCfg                            *
*                           clsAohSlot::PreHScanCfg                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHScanCfg(UINT8 *a_WriteBuffer,UINT8)
{
    if (TRUE == HartCfgDb.HEnable)
    {
        if ((*a_WriteBuffer > HSCANCFG_UNDEFINED) &&
            (*a_WriteBuffer <= HSCANCFG_STATUSONLY))
        {
            return PA_OK;
        }
    }
    else if (HSCANCFG_UNDEFINED == *a_WriteBuffer)
    {
        return PA_OK;
    }

    return DO_ILLEGAL_VALUE;
}
/*******************************************************************************
*                           clsAihSlot::PostHScanCfg                           *
*                           clsAohSlot::PostHScanCfg                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/

VOID clsAohSlot::PostHScanCfg(UINT8)
{
    HartDevDb.BuildScanTable();
}
/*******************************************************************************
*                           clsAihSlot::PreHComThrs                            *
*                           clsAohSlot::PreHComThrs                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHComThrs(UINT8 *a_WriteBuffer,UINT8)
{
    if (0 == *(UINT16 *)a_WriteBuffer)
    {
        *(UINT16 *)a_WriteBuffer = 1;
        return DO_VALUE_CLAMPED_ERROR;
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PreHComHys                            *
*                            clsAohSlot::PreHComHys                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHComHys(UINT8 *a_WriteBuffer,UINT8)
{
    if (*(UINT16 *)a_WriteBuffer > HartCfgDb.HComThrs)
    {
        *(UINT16 *)a_WriteBuffer = HartCfgDb.HComThrs;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHDevIdCd                           *
*                           clsAohSlot::PostHDevIdCd                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/

VOID clsAohSlot::PostHDevIdCd(UINT8)
{
    HartDevDb.CheckDevMismatch();
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd                            *
*                           clsAohSlot::PreHDvMfgCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHDvMfgCd(UINT8 *a_WriteBuffer,UINT8)
{
    if (HartCfgDb.HDvMfgCd != *a_WriteBuffer)
    {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED)
        {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd7                            *
*                           clsAohSlot::PreHDvMfgCd7                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHDvMfgCd7(UINT8 *a_WriteBuffer,UINT8)
{
    if ((*(UINT16 *)HartCfgDb7.HDvMfgCd7) != *(UINT16 *)a_WriteBuffer)
    {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED)
        {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd                            *
*                           clsAohSlot::PreHDvTypCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHDvTypCd(UINT8 *a_WriteBuffer,UINT8)
{
    if (HartCfgDb.HDvTypCd != *a_WriteBuffer)
    {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED)
        {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd7                           *
*                           clsAohSlot::PreHDvTypCd7                           *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHDvTypCd7(UINT8 *a_WriteBuffer,UINT8)
{
    if ((*(UINT16 *)HartCfgDb7.HDvTypCd7) != *(UINT16 *)a_WriteBuffer)
    {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED)
        {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvRevCd                            *
*                           clsAohSlot::PreHDvRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHDvRevCd(UINT8 *a_WriteBuffer,UINT8)
{
    if (HartCfgDb.HDvRevCd != *a_WriteBuffer)
    {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED)
        {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDdRevCd                            *
*                           clsAohSlot::PreHDdRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS clsAohSlot::PreHDdRevCd(UINT8 *a_WriteBuffer,UINT8)
{
    if (HartCfgDb.HDdRevCd != *a_WriteBuffer)
    {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED)
        {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}

#if 1
/*******************************************************************************
*                          clsAohBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if (TRUE == SLOT(WriteIndex)->IsRedTagged())
        return DO_POINT_IS_RED_TAGGED;
    if (TRUE == HAutoDet[WriteIndex - 1])
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::PostHADCEnable(UINT8) {
    PNTTYPE PointType = SLOT(WriteIndex)->GetPntType();
    FLOAT32 fOp;
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        // Save present OP value
        Op_Saved[WriteIndex - 1] = GetOp(WriteIndex);
        // If there is not presently enough current
        // Drive output current to the minimum necessary for device discovery
        if (HART_AUTODETECT_OP > SLOT(WriteIndex)->GetOpFinal()) {
            fOp = HART_AUTODETECT_OP;
            if (TRUE == SLOT(WriteIndex)->GetOpChar()) fOp = SLOT(WriteIndex)->ChrcBkwrd(HART_AUTODETECT_OP);
            if (OPTDIR_REVERSE == SLOT(WriteIndex)->GetOptDir()) fOp = ((FLOAT32) 100.0) - fOp;
            SetOp(WriteIndex,fOp);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
        HEnableSaved[WriteIndex - 1] = SLOT(WriteIndex)->GetHEnable();
        // If channel is loaded and HEnable is FALSE set it to TRUE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(TRUE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        // If channel is loaded restore old value of HEnable if it was FALSE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(FALSE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
        // If channel current was forced to the min value restore it to old value
        if (HART_AUTODETECT_OP > Op_Saved[WriteIndex - 1]) {
            SetOp(WriteIndex,Op_Saved[WriteIndex - 1]);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
    }
}
/*******************************************************************************
*                          clsAohBoxSlot::PreHAutoDet                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHAutoDet(UINT8 *a_WriteBuffer,UINT8) {
#if defined(IOPTYPE_AO16)
    if (TRUE == *(BOOL *)a_WriteBuffer) {
        if (BOX->GetFtaPres() == FTA_MISSING) {
            return DO_INITIALIZATION_ERROR;
        }
    }
#else
    if ((TRUE == *(BOOL *)a_WriteBuffer) &&
        (PNTTYPE_NOTCONFIGURED != SLOT(WriteIndex)->GetPntType())) {
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    if (TRUE == HADCEnable[WriteIndex - 1]) {
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    }
#endif
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHAutoDet                         *
*                          ===========================                         *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsAohBoxSlot::PostHAutoDet(UINT8) {
    /* Removed the check of Primary Module to Fix
       PAR 1-2KSQYU: AO-HART secondary IOM momentarily goes to IDLE
                     while loading a channel with HAUTODET
    */
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    if (TRUE == HAutoDet[WriteIndex - 1]) {
        // Drive output current for auto detection.
        SetOp(WriteIndex,HART_AUTODETECT_OP); // Drive 3.2 mA for auto detection
        SetHADCStatus(WriteIndex,HART_DATA_PENDING);
        SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
    }
    else {
        SetOp(WriteIndex,OP_LOLIMIT); // Drive 0 mA at output
        // If auto detection is disabled, schedule scan counter for
        // four seconds. This helps in keeping the HART discovery
        // information, if auto detection was disabled by a channel
        // load operation and there is enough current for HART. If
        // there is not enough current, HART database will be fully
        // initialized later.
        SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
    }
}
#endif

// --------------------------------
// End Slot Variables and Functions
// --------------------------------
#endif
#endif

