/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : ecl.cpp                                                     *
*    Description : Class clsEcl implementation.                                *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
#include "ecl.hpp"
//#include "tracelog.hpp"
/*******************************************************************************
*                                 clsEcl::clsEcl                               *
*                                 ==============                               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsEcl::clsEcl(const ECLTYPE a_EclType) : EclType(a_EclType) {
    CircListSt = ECLMODSTAT_ALIVE;
    EvntAppPtr = 0;
    EvntRemPtr = 0;
    if(ECLTYPE_NORMAL == a_EclType){
        EclInOverflow = FALSE;
        for (UINT16 uiCount = 0; uiCount < ECL_SIZE; uiCount++) {
        CircularList[uiCount] = 0;
        }
    }
}

clsEcl::~clsEcl(VOID) {
    HardFail(HF_INVPROGRAMEXEC, ECL_HPP, __LINE__);
}
/*******************************************************************************
*                               clsEcl::GetEclSize                             *
*                               ==================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsEcl::GetEclSize(VOID) {
    if (EvntAppPtr > EvntRemPtr) {
        return (EvntAppPtr - EvntRemPtr);
    }
    if (EvntRemPtr > EvntAppPtr) { // Only AppPtr wrapped around
        return (ECL_SIZE - (EvntRemPtr - EvntAppPtr));
    }
    return 0; // AppPtr = RemPtr
}
/*******************************************************************************
*                                clsEcl::AddEvent                              *
*                                ================                              *
*  Copy the event packet to the ECL object buffer. This function must not be   *
*  called from any context that runs higher than LVLPRI_TICK level.            *
*******************************************************************************/
BOOL clsEcl::AddEvent(const EVENTRECORD *a_pEventRecord)
{
    // Place holder for an overflow event
    EVENTRECORD overflowEvent;

    // Get length of the event record
    UINT8 ucPacketSize = 0;
    if ((a_pEventRecord->EventPacket == EVENTPACKET_SYSTEM) ||
        (a_pEventRecord->EventPacket == EVENTPACKET_HART)   ||
        (a_pEventRecord->EventPacket == EVENTPACKET_32CHAN_HART))
    {
            ucPacketSize = EVENTPACKETSIZE_SYSTEM;
    }
    else
    {
        // Unsupported packet type.
        HardFail(HF_INVPROGRAMEXEC,ECL_CPP,__LINE__);
    }

    // Elevate the priority to STC interrupt level. This is to protect
    // ECL buffer integrity since AddEvent is called from multple places.
    UINT32 uiSavedMask = hal_interrupt_set_mask(LVLPRI_TICK);

    // Check whether there is enough free space in the ECL. Always leave space
    // for OVERFLOW event + 1 byte. The additional 1 byte prevents append
    // pointer from catching up with remove pointer which represents empty ECL.
    UINT16 uiEclFreeSpace = ECL_SIZE - GetEclSize();
    if (uiEclFreeSpace >= (ucPacketSize + EVENTPACKETSIZE_OVERFLOW + 1))
    {
        EclInOverflow = FALSE;
    }
    else
    {
        // there is not enough free space
        if (TRUE == EclInOverflow)
        {
            // ECL already in overflow. Overflow event was already reported.
            // Restore original interrupt priority mask and exit.
            hal_interrupt_set_mask(uiSavedMask);
            return FALSE;
        }
        else
        {
            //-----------------------------------
            // Create an overflow event
            //-----------------------------------

            // Make a copy of the existing event...
            overflowEvent               = *a_pEventRecord;

            overflowEvent.Overflow      = TRUE;
            overflowEvent.ContactCutout = FALSE;
            overflowEvent.Qualifier     = EVENTTYPE_NORMAL;
            overflowEvent.CurrentState  = EVENTSTATE_ALARM;
            overflowEvent.EventPacket   = EVENTPACKET_OVERFLOW;

            ucPacketSize  = EVENTPACKETSIZE_OVERFLOW;
            EclInOverflow = TRUE;
        }
    }

    // Copy event to the ECL object buffer. Use a local copy of
    // the EvntAppPtr and update the object member only after
    // the entire event packet is copied. This way, C300 will be
    // collecting only fully formed event packets.
    UINT16 uiAppPtr = EvntAppPtr;
    UINT8 *ucEventRecordBytes = NULL;

    if (EclInOverflow)
    {
        ucEventRecordBytes = (UINT8 *)&overflowEvent;
    }
    else
    {
        ucEventRecordBytes = (UINT8 *)a_pEventRecord;
    }

    for (UINT8 ucCount = 0; ucCount < ucPacketSize; ucCount++)
    {
        CircularList[uiAppPtr] = *ucEventRecordBytes++;
        uiAppPtr++;
        if (uiAppPtr >= ECL_SIZE)
        {
            // wrap around
            uiAppPtr = 0;
        }
    }

    // Update EvntAppPtr in the ECL object.
    EvntAppPtr = uiAppPtr;

    // Set ECL status according to the ECL type
    SetStatus(ECLSTATUS_NORMAL);

    // Restore original interrupt priority mask.
    hal_interrupt_set_mask(uiSavedMask);

    return EclInOverflow ? FALSE : TRUE;
}
/*******************************************************************************
*                             clsEcl::CollectEclInfo                           *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsEcl::CollectEclInfo(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes) {
    // Calculate the current ECL size.
    UINT16 uiEclSize = GetEclSize();

    // Check and adjust to the length that can be transmitted.
    if (uiEclSize < a_uiMaxBytes) {
        a_uiMaxBytes = uiEclSize;
    }

    // Copy remove pointer and the length of the ECL data to the IOL buffer.
    DATABYTES DataBytes;
    DataBytes.ui16Val[0] = EvntRemPtr;
#ifdef BIG_ENDIAN
    *a_pBuffer++ = DataBytes.ucBytes[0];
    *a_pBuffer++ = DataBytes.ucBytes[1];
    DataBytes.ui16Val[0] = uiEclSize;
    *a_pBuffer++ = DataBytes.ucBytes[0];
    *a_pBuffer++ = DataBytes.ucBytes[1];
#else
    *a_pBuffer++ = DataBytes.ucBytes[1];
    *a_pBuffer++ = DataBytes.ucBytes[0];
    DataBytes.ui16Val[0] = uiEclSize;
    *a_pBuffer++ = DataBytes.ucBytes[1];
    *a_pBuffer++ = DataBytes.ucBytes[0];
#endif

    // Return number of bytes that can be copied.
    return a_uiMaxBytes;
}
/*******************************************************************************
*                             clsEcl::CollectEclData                           *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID  clsEcl::CollectEclData(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes) {
    UINT16 uiRemPtr = EvntRemPtr;
    for (UINT16 uiCount = 0; uiCount < a_uiMaxBytes; uiCount++) {
        *a_pBuffer++ = CircularList[uiRemPtr++];
        // Check for wrap around
        if (uiRemPtr >= ECL_SIZE)   {
            uiRemPtr = 0;
        }
    }
}
/*******************************************************************************
*                              clsEcl::UpdateRemPtr                            *
*                              ====================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID  clsEcl::UpdateRemPtr(UINT16 a_uiNewRemPtr) {
    // Check for wrap around and update remove pointer
    if (a_uiNewRemPtr >= ECL_SIZE) {
        a_uiNewRemPtr -= ECL_SIZE;
    }
    EvntRemPtr = a_uiNewRemPtr;
    // Reset ECL status bit if the circular list is empty
    if (EvntRemPtr == EvntAppPtr) {
            ResetStatus(ECLSTATUS_NORMAL);
    }
}
/*******************************************************************************
*                             clsEcl::IsRommForRegen                           *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL  clsEcl::IsRoomForRegen(VOID) {
    // Compute current ECL size and return TRUE if ECL is more than half empty.
    UINT16 uiEclFreeSpace = ECL_SIZE - GetEclSize();
    return (uiEclFreeSpace >= (ECL_SIZE / 2)) ? TRUE : FALSE;
}

BOOL clsEcl::AddAlarmEvent(ALARMEVENTRECORD *pAlarmEvent)
{
    // Elevate the priority to STC interrupt level. This is to protect
    // ECL buffer integrity since AddEvent is called from multple places.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    // Check whether there is enough free space in the ECL. Always leave space
    // for OVERFLOW event + 1 byte. The additional 1 byte prevents append
    // pointer from catching up with remove pointer which represents empty ECL.
    UINT16 uiEclFreeSpace = ECL_SIZE - GetEclSize();
    if (uiEclFreeSpace < (EVENTPACKETSIZE_ALARM + EVENTPACKETSIZE_OVERFLOW + 1))
    {
        // no more space in ECL
        return FALSE;
    }

    // Copy event to the ECL object buffer. Use a local copy of
    // the EvntAppPtr and update the object member only after
    // the entire event packet is copied. This way, C300 will be
    // collecting only fully formed event packets.
    UINT16 uiAppPtr = EvntAppPtr;
    UINT8 *ucEventRecordBytes = (UINT8 *)pAlarmEvent;

    for (UINT8 ucCount = 0; ucCount < EVENTPACKETSIZE_ALARM; ucCount++)
    {
        CircularList[uiAppPtr] = *ucEventRecordBytes++;

        uiAppPtr++;
        if (uiAppPtr >= ECL_SIZE)
        {
            // wrap around
            uiAppPtr = 0;
        }
    }

    // Update EvntAppPtr in the ECL object.
    EvntAppPtr = uiAppPtr;

    // Set ECL status according to the ECL type
    SetStatus(ECLSTATUS_NORMAL);

    // Restore original interrupt priority mask.
    set_imask_exr(ucSaveExr);

    return TRUE;
}
