/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iol.hpp                                                     *
*    Description : IOL Interface class definition file.                        *
*                                                                              *
*    Converted from Renesas H8S/2329 -> NXP LPC1763 -> NXP iMXRT1024.          *
*    - H8S SCI register macros replaced by IOL_WriteByte/ReadByte/etc.         *
*      (armsrc precedent, LPC_UART1 inline wrappers)                           *
*    - RT1024: inline wrappers route through HAL LPUART (see                   *
*      commonelectronics.h for IOL_WriteByte et al. definitions)               *
*    - H8S TPU4 timer replaced by SilenceTimer helpers (armsrc precedent)      *
*    - H8S GPIO (TXREQ_n, CLRGHL_n) replaced by SetTXREQ_n/SetCLR_GHL_n        *
*    - ISR architecture: extern "C" IRQ handlers with friend access            *
*      (armsrc precedent, replaces H8S static ISR members)                     *
*******************************************************************************/
//   - Removed S3 FPGA/SCI2 dual-UART paths (single-channel LPUART)           //
//   - Removed non-AOH IOM types (DISOE, DO, LLMUX, SVP, SP, PI, UIO)         //
//   - ChecksumHi/Lo widened from UINT to UINT16 (armsrc precedent)           //
//   - Preserved all original logic, variable names, and command handlers     //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifndef __IOL_HPP__
#define __IOL_HPP__

#include "commonelectronics.h"
#if 1   // ANIL_RE_VISIT
#include "aohmain.h"
#endif

#define IOL_BYT_DBG 0
#define IOL_ERR_DBG 0

#define IOL_GHO_ENB 1

// ANIL_RE_VISIT
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#if defined(AOH_PROTO_V1) && AOH_PROTO_V1
    #define IOLINK_RX_MUX            IOMUXC_GPIO_AD_B0_07_LPUART1_RX /* GPIO_AD_B0_07 is configured as LPUART1_RX */
    #define IOLINK_TX_MUX            IOMUXC_GPIO_AD_B0_06_LPUART1_TX /* GPIO_AD_B0_06 is configured as LPUART1_TX */

    #define IOLINK_UART_BASEADDR    LPUART1
    #define IOLINK_UART_IRQn        LPUART1_IRQn
    #define IOLINK_UART_IRQHandler    LPUART1_IRQHandler
#else
    #define IOLINK_RX_MUX            IOMUXC_GPIO_AD_B0_15_LPUART3_RX /* GPIO_AD_B0_15 is configured as LPUART3_RX */
    #define IOLINK_TX_MUX            IOMUXC_GPIO_AD_B0_14_LPUART3_TX /* GPIO_AD_B0_14 is configured as LPUART3_TX */

    #define IOLINK_UART_BASEADDR    LPUART3
    #define IOLINK_UART_IRQn        LPUART3_IRQn
    #define IOLINK_UART_IRQHandler    LPUART3_IRQHandler
#endif

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/

const UINT32 IOL_BAUDRATE = 375000;   // 375 kbps IOLink

/* IOL RS-485 transmitter enable (active low on H8S/LPC, same convention)     */
const UINT8 IOLDRV_ON  = 0;
const UINT8 IOLDRV_OFF = 1;

/* GHO interrupt register control                                             */
const UINT8 GHO_ENABLED  = 1;
const UINT8 GHO_DISABLED = 0;
const UINT8 GHO_NOTINGAP = 0;

/* 9-bit alert/address mode */                      
//const UINT8 IOL_ALERT_RESET = 0;
//const UINT8 IOL_ALERT_SET = 1;
const UINT8 IOL_ALERT_XMIT_ADDR = 1;       /* TX 9th bit = 1: address frame       */
const UINT8 IOL_ALERT_XMIT_DATA = 0;       /* TX 9th bit = 0: data frame          */
const UINT8 IOL_ALERT_RCV_ADDR  = 1;       /* RX 9th bit = 1: address frame       */
const UINT8 JABLOCK_ASSERTED = 0;        /* active low anti-jabber               */
const UINT8 JABLOCK_NEGATED = 1;

const UINT8   MAXDSA = 63;
const UINT8   PHI = 24;                                // System Clock (in MHz)
const UINT16  TMRCLKPER = 16000/PHI;            // Timer 4 Clock period (in ns)

#if 1
/* Inter-character timeout budget for byte-to-byte polling loops in Rcvr(). */
const UINT32  NCYCLES_CHARTO = 54;                        // TcWait = ~27.00 us
const UINT32  LNKSILNS = 10000000;                      // Link Silence (in ns)
const UINT32  LNKHUNTNS = 500000;                     // Link hunt time (in ns)
const UINT16  CNTLNKSIL = 10000;                   // 10ms (LNKSILNS/TMRCLKPER)
const UINT16  CNTLNKHUNT = 500;                 // 500 us (LNKHUNTUS/TMRCLKPER)
const UINT16  CNTLNKSECTO = 2 + 40;       // 40ms timeout for the backup module
const UINT16  CNTLNKPRITO = 2 + 120;      // 80ms timeout for the primary module
const UINT16  TPU4CNT_TCWAIT = 16;        // TcWait TPU4_TCNT;=26 * 0.6667=17.3us
const UINT16  TPU4CNT_TMGAP  = 26;        // Tmgap TPU4_TCNT; =41 * 0.6667=27.3us
const UINT8   LOOPCNT50USEC  = 50;
#else
// for PMIO Redesign IOL Comm related timers constants
#if !defined(IOPTYPE_SCIOM)
const UINT8   NCYCLES_CHARTO = 54;          // TcWait = ~40.00 us
const UINT32  LNKSILNS       = 20000000;    // Link Silence (in ns)
const UINT32  LNKHUNTNS      = 1000000;     // Link hunt time (in ns)
const UINT16  CNTLNKSIL      = 20000;       // 20ms (LNKSILNS/TMRCLKPER)
const UINT16  CNTLNKHUNT     = 1000;        // 1000 us (LNKHUNTUS/TMRCLKPER)
const UINT16  CNTLNKSECTO    = 2*(2 + 40);  // 80ms timeout for the backup module
const UINT16  CNTLNKPRITO    = 2*(2 + 120); // 160ms timeout for the primary module
const UINT16  TPU4CNT_TCWAIT = 32;          // TcWait TPU4_TCNT (34.66 us)
const UINT16  TPU4CNT_TMGAP  = 52;          // Tmgap TPU4_TCNT (54.66 us)
//const UINT8   IOL_BAUDRATE   = 1;         // Bit Rate Register Set (N=1 -> 375000bps)
#else // Series C IOL Comm related timers constants
const UINT8   NCYCLES_CHARTO = 48;          // TcWait = ~20.00 us
const UINT32  LNKSILNS = 10000000;          // Link Silence (in ns)
const UINT32  LNKHUNTNS = 500000;           // Link hunt time (in ns)
const UINT16  CNTLNKSIL = 15000;            // 10ms (LNKSILNS/TMRCLKPER)
const UINT16  CNTLNKHUNT = 750;             // 500 us (LNKHUNTUS/TMRCLKPER)
const UINT16  CNTLNKSECTO = 2 + 40;         // 40ms timeout for the backup module
const UINT16  CNTLNKPRITO = 2 + 120;        // 80ms timeout for the primary module
const UINT16  TPU4CNT_TCWAIT = 26;          // TcWait TPU4_TCNT
const UINT16  TPU4CNT_TMGAP = 41;           // Tmgap TPU4_TCNT
//const UINT8   IOL_BAUDRATE = 0;           // Bit Rate Register Set (N=0 -> 750000bps)
#endif
const UINT8 LOOPCNT50USEC = 100;
#endif

//Factory Test Related constants
const UINT8 SECURTYDATA1 = 0x52;
const UINT8 SECURTYDATA2 = 0x57;
const UINT8 SECURTYDATA3 = 0x42;
//Tests
const UINT8 WDT1_TST           = 1;//Tests the Higher limit of the WDT
const UINT8 GHO_TST            = 2;
const UINT8 JABBER_TST         = 3;
const UINT8 JBR_RES_TST        = 4;
const UINT8 JBR_RES_XMIT_TST   = 5;
const UINT8 RDN_HW_TST         = 6;
const UINT8 UPDT_HWVER_NO      = 7;
const UINT8 HARTLPBK_TST       = 8;
const UINT8 WDT2_TST           = 9;
const UINT8 UPDT_SERIAL_NO     = 10;
const UINT8 CHNG_SPLSIGNALS    = 11;//To set/reset SWBUREQ_n,EN_SW,TST_SW,INH_SW2,INH_SW1
const UINT8 UPDT_PROD_TYPE     = 13;
const UINT8 UPDT_PROD_CODE     = 14;
const UINT8 TEST_BYTE = 0xAA;

// modified for FCT testing (GHO TEST - TEST#4)
const UINT8 BITTPU5COUNT = 16;            //At 375kbps,it would takes 2.66usec to xmit a bit. Six TPU5 counts makes one usec.
const UINT8 BASETPU5COUNT = 33;            //This accounts the alert bit and stop bit which follows the MSB of data.
const UINT16 NO_INVALID_CHARS = 400;    //MAX Jabber Time = 6msec,the MIN CHAR TIME = 29.26microsec
                                        //NO_INVALID_CHARS = 6msec/29.26us ==> 205 + Safety Factor ==> 400

// The character count of factory command to initiate UPDT_HWREVCODE_NO subcommand
const UINT8 UPDT_HWREVCODE_MSG_CC   = 0x0A;
// The character count of factory command to initiate UPDT_SERIAL_NO subcommand
const UINT8 UPDT_SERIAL_NO_MSG_CC   = 0x0C;
//The character count of the factory command to initiate CHNG_SPLSIGNALS
const UINT8 CHNG_SPLSIGNALS_MSG_CC  = 0x09;
// The character count of the factory command to initiate UPDT_PROD_CODE
const UINT8 UPDT_PROD_CODE_CC       = 0x0A;
// The character count of the factory command to initiate UPDT_PROD_TYPE
const UINT8 UPDT_PROD_TYPE_CC       = 0x0A;
//Factory Command,CHNG_SPLSIGNALS Sub Command related constants
const UINT8 SETMODE_BIT = 0x80;//MSB Bit
const UINT8 DATA_BITS   = 0x7F;//0-6bits
const UINT8 SWBUREQ_SIGNAL = 0;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum FLETCHERACTION {
    FTYP_APPEND,
    FTYP_COMPARE
}FLETCHERACTION;

#if 1   // ANIL_RE_VISIT
class clsIol; // Forward declaration

typedef struct tagCMDINFO {
    UINT8 CountReq;
    UINT8 CountResp;
    PASTATUS (clsIol::* CmdHandler)(VOID);
}CMDINFO;

typedef struct tagIolDiagState {
    UINT32 rxIsrCount;
    UINT32 txIsrCount;
    UINT32 txDoneIsrCount;
    UINT32 rxIrqEnableCount;
    UINT32 rxIrqDisableCount;
    UINT32 txIrqEnableCount;
    UINT32 txIrqDisableCount;
    UINT32 txDoneEnableCount;
    UINT32 txDoneDisableCount;
    UINT32 startResponseCount;
    UINT32 startResponseBusyDropCount;
    UINT32 errorPathCount;
    UINT32 noResponseCount;
    UINT32 rdrfAfterErrorCount;
    UINT32 lastCommandSeen;
    UINT32 lastRcvrExitPath;
    UINT32 lastStat;
    UINT32 lastCtrl;
} IOLDIAGSTATE;

extern volatile IOLDIAGSTATE g_IolDiag;

extern "C" void GHO_IRQHandler(VOID);
extern "C" void SilenceTimer_IRQHandler(VOID);
extern "C" void BOARD_INITIOLINK_PINS_GHOIRQ_n_callback(void *param);

/*******************************************************************************
*                                     clsIol                                   *
*                                     ======                                   *
*******************************************************************************/
class clsIol {

public:

    clsIol(VOID);
    VOID Enable(VOID);
    VOID Disable(VOID);

private:

    static const UINT8 LastCommand;
    static const CMDINFO aCmdInfo[];

    UINT16 ChecksumHi;
    UINT16 ChecksumLo;
    UINT8 CountErrorA;
    UINT8 CountErrorB;
    UINT8 ucIolId;
    UINT8 ucIolBA;
    UINT8 ucIolDPA;
    UINT8 ucIolDSA;    //when BA!= 0xFF, Dsa=BA
    UINT8 ucLastDSA;
    UINT8 ucMsgNumber;
    UINT8 ucIdxDump;
    UINT8 nCharProcd;
    UINT16 txStopCount;
    UINT8 *pRcvBuffer;
    UINT8 xmit_buffer[IOL_MAXXMT_MSGSIZE+1];
    BOOL  txActive;
    UINT8 ucDest;
    UINT8 ucNumber;
    UINT8 ucCommand;
    BOOL  bCommError;
    UINT8 ucBRDPInfoField[5];   //We need to save these I-Field byte for processing for BRDP.
    // Only 4 bytes are for I-Field. 5th byte is used to save the BRDP MsgNum.

#if IOL_BYT_DBG
    UINT16 TempBuff[64];
#endif

    BOOL NotMyAddress (UINT8 ucAddress)
    {
        return ((ucAddress != 0) && (ucAddress != ucIolDPA) && (ucAddress != ucIolDSA));
    }

    VOID Add2Checksum (UINT8 ucByte)
    {
        ChecksumLo += ucByte;
        if (ChecksumLo > 0xFF) ChecksumLo += 0xFF01;     // if carry, sub 256, add 1
        ChecksumHi += ChecksumLo;
        if (ChecksumHi > 0xFF) ChecksumHi += 0xFF01;     // if carry, sub 256, add 1
    }

    VOID StartNakResponse(PASTATUS ucNack) {

        xmit_buffer[IOLMSG_DESTINATION] = pRcvBuffer[IOLMSG_SOURCE];
        xmit_buffer[IOLMSG_NUMBER]      = aCmdInfo[IOLCMD_NACK].CountResp;
        xmit_buffer[IOLMSG_SOURCE]      = pRcvBuffer[IOLMSG_DESTINATION];
        xmit_buffer[IOLMSG_COMMAND]     = IOLCMD_NACK | 0x80;
        xmit_buffer[IOLNAK_PASTAT]      = ucNack;
        ComputeFletcher(xmit_buffer, FTYP_APPEND);

        StartResponse();
    }

    VOID StartResponse(VOID) {
        g_IolDiag.startResponseCount++;
        /* Never abort/reset an active TX here. Doing so can corrupt shared
         * xmit_buffer state and produce long mixed packets. If TX is active,
         * drop this response attempt and let the in-flight TX complete. */
        if ((nCharProcd != 0U) || txActive) {
            g_IolDiag.startResponseBusyDropCount++;
            return;
        }

        nCharProcd = 0;                      // reset transmitted character count
        txStopCount = (UINT16)xmit_buffer[IOLMSG_NUMBER] + 2U;
        if (txStopCount > (UINT16)(IOL_MAXXMT_MSGSIZE + 1U)) {
            txStopCount = (UINT16)(IOL_MAXXMT_MSGSIZE + 1U);
        }
        txActive = TRUE;

        /* Block RX IRQ while transmitting; loopback bytes must be handled by TX path. */
        IOL_RxInterrupt(FALSE);

        SetTXREQ_n(IOLDRV_ON);               // turn on RS-485 transmitter to tx

        IOL_TxEnable();                         // enable transmitter

        while(!IOL_TxBufEmpty());            // Wait TX data register ready

        IOL_WriteByte(xmit_buffer[nCharProcd++], IOL_ALERT_XMIT_ADDR);    // send address with 9th bit set

        IOL_TxInterrupt(TRUE);
    }

    // IOLink ISR methods (called from extern "C" handlers)
    static VOID Rcvr(VOID);
    static VOID Xmit(VOID);
    static VOID XmitEnd(VOID);

    VOID ResetSilenceTimer(UINT32 uwTimeOut)
    {
        SilenceTimerStop();
        SilenceTimerReset();
        SilenceTimerSetCount(uwTimeOut);
        SilenceTimerStart();
    }

    VOID StartGapTimer(VOID)
    {
        SilenceTimerStop();
        SilenceTimerReset();
        SilenceTimerStart();
    }

    VOID SetIolDSA(UINT8 ucNewDSA)
    {
        ucIolDSA = ucNewDSA;
        ucIolBA = 0xFF;
    }

    VOID DropReceiveUntilNextAddress(VOID);

    UINT8 ComputeFletcher(UINT8 *, FLETCHERACTION);
    VOID LossofCommShed(VOID);
    PASTATUS GetPrimaryResponse(UINT8,UINT8,UINT8 *);
    VOID TransmitData(UINT8 data, UINT8 AlertBit);

    PASTATUS Cmd01Handler(VOID);
    PASTATUS Cmd04Handler(VOID);
    PASTATUS Cmd07Handler(VOID);
    PASTATUS Cmd08Handler(VOID);
    PASTATUS Cmd0AHandler(VOID);
    PASTATUS Cmd0BHandler(VOID);
    PASTATUS Cmd0CHandler(VOID);
    PASTATUS Cmd0FHandler(VOID);
    PASTATUS Cmd10Handler(VOID);
    PASTATUS Cmd16Handler(VOID);
    PASTATUS Cmd17Handler(VOID);
    PASTATUS Cmd1FHandler(VOID);
    PASTATUS Cmd20Handler(VOID);
    PASTATUS Cmd25Handler(VOID);
    PASTATUS Cmd26Handler(VOID);
    PASTATUS Cmd28Handler(VOID);
    PASTATUS Cmd2AHandler(VOID);
    PASTATUS Cmd2CHandler(VOID);
    PASTATUS Cmd2DHandler(VOID);
    PASTATUS Cmd2FHandler(VOID);
    PASTATUS Cmd32Handler(VOID);
    PASTATUS Cmd33Handler(VOID);
    PASTATUS Cmd35Handler(VOID);
    PASTATUS Cmd37Handler(VOID);
    PASTATUS DefaultHandler(VOID);
    PASTATUS BroadcastHandler(VOID);
    BOOL ProcessDefWrCmd(VOID);

public:
    UINT8 GetCountErrorA(VOID) { return CountErrorA; }
    UINT8 GetCountErrorB(VOID) { return CountErrorB; }

    VOID ResetDumpIndex(VOID) {ucIdxDump=0;}
    VOID DropDSA(VOID) {
        ucIolBA = 0xFF;
        ucIolDSA = 0;
        ucLastDSA = 0;
    }
    VOID SetIolBA(UINT8 ucNewBA) {
        ucIolBA = ucNewBA;
        ucIolDSA = (ucIolBA == 0xFF) ? 0 : ucIolBA;
    }
    ADDCHG AddressChange(VOID) {
        ADDCHG RetVal = ADDCHG_DROPPED;
        if (ucIolDSA == ucLastDSA) {
            RetVal = ADDCHG_NONE;
        }
        else if (ucLastDSA == 0) {
            RetVal = ADDCHG_NEW;
        }
        ucLastDSA = ucIolDSA;
        return RetVal;
    }
    BOOL AmPrimary(VOID) {
        BOOL bReturn = TRUE;
        if (ucIolDSA == 0) bReturn = FALSE;
        if (ucIolDSA == ucIolBA) bReturn = FALSE;
        return bReturn;
    }

    friend VOID GHO_IRQHandler(VOID);
    friend VOID SilenceTimer_IRQHandler(VOID);
    friend void BOARD_INITIOLINK_PINS_GHOIRQ_n_callback(void *param);

#if 1 // temp for testing
    VOID SetDSA(UINT8 ucNewDSA)
    {
        ucIolDSA = ucNewDSA;
        ucIolBA = 0xFF;
    }
#endif

}; //clsIol

extern clsIol Iol;

#endif
#endif // IOL_HPP
