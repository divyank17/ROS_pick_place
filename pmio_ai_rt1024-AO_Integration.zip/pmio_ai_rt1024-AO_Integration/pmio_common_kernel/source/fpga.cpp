/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : fpga.cpp                                                    *
*    Description : Implements fpga definitions                                 *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
#include "fpga.hpp"

ClsFpga Fpga;

ClsFpga::~ClsFpga(VOID) {
    HardFail(HF_INVPROGRAMEXEC, FPGA_HPP, __LINE__);
}

UINT8 ClsFpga::GetIotaRegister(VOID) {
    // This function is called every ~100ms from LowPriorityTask
    // (TASKID_LPTASK), which has a limited DMC watchdog budget
    // (DMCPERIOD_LPTASK). hal_fpga_get_iota_status() -> hal_fpga_read()
    // is a BLOCKING SPI transfer (LPSPI_MasterTransferBlocking) — the
    // transfer itself only takes a few microseconds, but under heavy IOL
    // UART interrupt load the CPU's polling loop kept getting preempted,
    // stretching the *wall-clock* stall long enough to blow the DMC
    // budget, causing continuous "DMC EXPIRE" reports for task 2.
    //
    // Instead, mask all interrupts for just this short (~microseconds)
    // transaction so the IOL UART ISR storm cannot preempt the polling
    // wait and stretch it out. This bounds the worst-case stall
    // deterministically without touching any other FPGA access path.
    UINT32 ucSaveExr = hal_interrupt_set_mask(LVLPRI_HIGHEST);
    UINT8 m_u8IotaReg = (UINT8)hal_fpga_get_iota_status();
    hal_interrupt_set_mask(ucSaveExr);

    return m_u8IotaReg;
}

UINT8 ClsFpga::GetMiscRegister(VOID) {

    UINT32 ucSaveExr = hal_interrupt_set_mask(LVLPRI_HIGHEST);
    UINT8 m_u8MiscReg = (UINT8)hal_fpga_get_misc_status();
    hal_interrupt_set_mask(ucSaveExr);

    return m_u8MiscReg;
}

UINT8 ClsFpga::GetModnumRegister(VOID) {

    UINT32 ucSaveExr = hal_interrupt_set_mask(LVLPRI_HIGHEST);
    UINT8 m_u8ModnumReg = (UINT8)hal_fpga_get_modnum();
    hal_interrupt_set_mask(ucSaveExr);

    return m_u8ModnumReg;
}

UINT8 ClsFpga::GetRevLetter(VOID) {
    
    UINT32 ucSaveExr = hal_interrupt_set_mask(LVLPRI_HIGHEST);
    UINT8 m_u8RevLetterReg = (UINT8)hal_fpga_get_rev_letter();
    hal_interrupt_set_mask(ucSaveExr);

    return m_u8RevLetterReg;
}

UINT8 ClsFpga::GetRevNumber(VOID) {

    UINT32 ucSaveExr = hal_interrupt_set_mask(LVLPRI_HIGHEST);
    UINT8 m_u8RevNumberReg = (UINT8)hal_fpga_get_rev_number();
    hal_interrupt_set_mask(ucSaveExr);

    return m_u8RevNumberReg;
}
