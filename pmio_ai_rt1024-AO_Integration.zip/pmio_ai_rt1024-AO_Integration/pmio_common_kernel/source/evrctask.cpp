/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : evrctask.cpp                                                *
*    Description : Event recovery task common to all IOMs.                     *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
 #if 1   // ANIL_RE_VISIT
#include "aohmain.h"
#endif

/*******************************************************************************
*                               EventRecoveryTask                              *
*                               =================                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN EventRecoveryTask(TASKCONTEXT a_TaskContext)
{
    static UINT8 sucSlotNum = 1;

    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    TASKRETURN TaskReturn;
    TaskReturn.TaskReturnState = TASKRETURNSTATE_SUSPEND;
    TaskReturn.TaskContext     = a_TaskContext;
    TaskReturn.ucSuspendTime   = 0;

    if (BOX->IsRoomForRegen() == FALSE) {

        //TraceLog.AddToTrace(TRACEID_GENERIC,bcNoRoomForRegen,(UINT32)a_TaskContext);
        TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
        return TaskReturn;
    }
    switch (TaskReturn.TaskContext)
    {
    case TASKCONTEXT_ZERO:
        //TraceLog.AddToTrace(TRACEID_GENERIC,bcEvrcBegin);
        if (FALSE == BOX->AddBracketEvent(EVENTSUBTYPE_RECOVERYSTART))
        {
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            break;
        }
        TaskReturn.TaskContext = TASKCONTEXT_ONE;
        // break statement is intentionally removed to fall through next context.
    case TASKCONTEXT_ONE:
        if (FALSE == BOX->AddModStatEvent(EVENTTYPE_RECOVERY))
        {
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            break;
        }
        TaskReturn.TaskContext = TASKCONTEXT_TWO;
        // break statement is intentionally removed to fall through next context.
    case TASKCONTEXT_TWO:
        if (TRUE == BOX->RegenSoftfails())
        {
            //TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcExec);
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case TASKCONTEXT_THREE:
        while (sucSlotNum <= MAXSLOTS)
        {
            if (SLOT(sucSlotNum)->RegenChannelEvents() == TRUE)
            {
                //TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcExec,(UINT32)sucSlotNum);
                sucSlotNum++;
            }
            else
            {
                TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
                break;
            }
        }
        if (sucSlotNum > MAXSLOTS)
        {
            sucSlotNum = 1; // Reset for next regen.
            TaskReturn.TaskContext = TASKCONTEXT_SEVEN;
            // break statement is intentionally removed to fall through next context.
        }
        else
        {
            break;
        }
    case TASKCONTEXT_SEVEN:
        if (TRUE == BOX->AddBracketEvent(EVENTSUBTYPE_RECOVERYEND)) {
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    default:
        HardFail(HF_BADPROGRAMJUMP,EVRCTASK_CPP,__LINE__);
    }

    // if the current operation is complete, advance to next context.
    if (RETURNSTATUS_COMPLETE == RtnSts) {
        if (TaskReturn.TaskContext < TASKCONTEXT_FOUR) {
            TaskReturn.TaskContext = (TASKCONTEXT)((UINT8)TaskReturn.TaskContext + 1);
        }
        else { // All contexts finished.
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcEvrcEnd);
            TaskReturn.TaskReturnState = TASKRETURNSTATE_TERMINATE;
        }
    }

    if (TASKRETURNSTATE_TERMINATE == TaskReturn.TaskReturnState) {
        //TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcTerminated);
    }
    else {
        //TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcSuspended, (UINT32)TaskReturn.ucSuspendTime);
    }

    return TaskReturn;
}
