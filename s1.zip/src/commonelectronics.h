/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : commonelectronics.h                                         *
*    Description : Declaration of H8 I/O datatypes and constants for all IOMs. *
*    Definitions : HEK        - AIH, AOH, LLMUX  (2315 processor)              *
*                               PI, UIO          (2329 processor)              *
*                  LOWCOST    - AIHL, AO         (2329 processor)              *
*                  H8S_2319C  - DISOE            (2319 processor)              *
*                  if none of the above 3 defined - DI, DO (2317 processor)    *
*                  IOMTYPE_XX - each module type. use defined()                *
*                             - SPM, SVPM                                      *
*******************************************************************************/
#ifndef __COMMONELECTRONICS_H__
#define __COMMONELECTRONICS_H__

#if defined (IOMTYPE_SVP) || defined (IOMTYPE_SVPBOOT) || defined (IOMTYPE_SP) || defined (IOMTYPE_SPBOOT)
#include "turbineelectronics.h"
#else

#if !defined(IOPTYPE_SCIOM)
// for PMIO Redesign constants

#ifdef DEBUG
#define PMIO_DEBUG
#define PMIO_FCT
//#define BOOT_DEBUG
#else
#define PMIO_RLS
#endif

#if 0 //defined(BOOT_DEBUG)

#define DIG8 8
#define DIG2 2

#define H2AH(VAL)    ((VAL < 10) ? (VAL+'0') : (VAL+'A'-10))

extern UINT8 ucTempBuf[10];
extern VOID DebugPortInit(VOID);
extern VOID PrintStr(const CHAR *a_cstrPrint);
extern VOID PrintHex(UINT32 ulHexVal, UINT8 cDigits);
#endif


#if defined(PMIO_DEBUG) || defined(PMIO_RLS)

#if 0
#define DBG_SIG1    P_P3.DR.BIT.B5
#define DBG_SIG2    P_P5.DR.BIT.B3
#endif

#define DMPBUF_SIZE  400
#define NOOFDBGBYTS  6

#define NRML_DBGPNT  0x00 //Soft Fails
#define FINS_DBGPNT  0x01 //Fault insertion
#define ALRM_DBGPNT  0x10 //Alarm ECL dump
#define DUMP_DBGPNT  0x20 //Dump data capture (0x20 -  0x2F)
#define SVCM_DBGPNT  0x30 //SYNC VER Chksm
#define RDCM_DBGPNT  0x31 //Red dump data chksm display
#define CKSM_DBGPNT  0x32 //Check point database checksum display
#define PVRW_DBGPNT  0x40 //Pv Value calculation display
#define PVCL_DBGPNT  0x41 //Pv Value calculation display
#define DODG_DBGPNT  0x50 //DO diagnostics
#define WGLE_DBGPNT  0x70 //Wiggle test
#define WRDB_DBGPNT  0x80 //Write database
#define WRCM_DBGPNT  0x81 //Write database
#define WRSK_DBGPNT  0x82 //Write database error status message skip
#define RDDB_DBGPNT  0x90 //Read database

extern UINT8 ucDumpBuff[DMPBUF_SIZE];
extern FLOAT32 fDbgFlt;
extern FLOAT32 fDbgFlt1;
extern UINT16 ucDbgCnt;
extern UINT8 ucDbgPnt;
extern UINT16 uiDbgPnt1;
extern UINT16 uiDbgPnt2;
extern UINT8 ucDbgFlag;
//extern UINT16 uiDbgPnt3;
//extern UINT16 uiDbgPnt4;
//extern UINT16 uiDbgPnt5;
//extern UINT16 uiDbgPnt6;
//extern UINT16 uiDbgPnt7;
//extern UINT16 uiDbgPnt8;

extern VOID PrintStr(const CHAR *a_cstrPrint);

#endif

#define IOP_A             TRUE
#define IOP_B             FALSE
#define SWBUREQ_ASSERT    DEASSERTED //0
#define SWBUREQ_DEASSERT  ASSERTED   //1

#define FTA_MISSING         0x00
#define FTA_RETURN_BUT_TOUT 0x01
#define FTA_RETURN_AND_TOUT 0x03

#if defined(IOPTYPE_DO) && defined(DIGTYPE_DO16)
#define PRIMARY_LATCH   0
#define BACKUP_LATCH    1

#define ONE_TO_EIGHT    0
#define NINE_TO_SIXTEEN 1
#endif

#endif

#if ((HEK) && (defined(IOMTYPE_AOHBOOT) || defined(IOMTYPE_AOH)\
           ||  defined(IOMTYPE_AIHBOOT) || defined(IOMTYPE_AIH)))           
//need to be  updated based on CPLD - hard coded to false for now
extern BOOL IsFpgaS2;
#endif

#if LOWCOST
extern "C" {
    void _builtin_nop(void);
}
#define NOP _builtin_nop() 
#endif

/*******************************************************************************
*                             TYPES & ENUMERATIONS                             *
*******************************************************************************/
union un_mstpcr {                 /********************************************/
    UINT16 WORD;                  /*        Module Stop Control Register      */
    struct {                      /*                                          */
        UINT8 H;                  /*   MSTPCRH                                */
        UINT8 L;                  /*   MSTPCRL                                */
    } BYTE;                       /*                                          */
    struct {                      /*                                          */
        UINT8     :1;             /*                                          */
        UINT8 DTC :1;             /*   Data Transfer Controller               */
        UINT8 TPU :1;             /*   16 Bit Timer Pulse Unit                */
        UINT8 TMR :1;             /*   8 bit Timers                           */
        UINT8     :1;             /*                                          */
        UINT8 DAC :1;             /*   Digital to Analog Converter            */
        UINT8 ADC :1;             /*   Analog to Digital Converter            */
        UINT8     :1;             /*                                          */
        UINT8 SCI2:1;             /*   Serial Commn. Interface Channel 2      */
        UINT8 SCI1:1;             /*   Serial Commn. Interface Channel 1      */
        UINT8 SCI0:1;             /*   Serial Commn. Interface Channel 0      */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
    } BIT;                        /*                                          */
};                                /********************************************/

struct st_sci {                   /********************************************/
    union {                       /* Serial Communication Interface           */
        UINT8 BYTE;               /*                                          */
        struct {                  /*  Serial Mode Register                    */
            UINT8 CA  :1;         /*   Communication Mode                     */
            UINT8 CHR :1;         /*   Character Length                       */
            UINT8 PE  :1;         /*   Parity Enable                          */
            UINT8 OE  :1;         /*   Parity Mode                            */
            UINT8 STOP:1;         /*   Number of Stop Bits                    */
            UINT8 MP  :1;         /*   Multiprocessor Mode                    */
            UINT8 CKS :2;         /*   Clock Select 1 and 0                   */
        } BIT;                    /*                                          */
    } SMR;                        /*                                          */
    UINT8 BRR;                    /*  Bit Rate Register                       */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*   Serial Control Register                */
            UINT8 TIE :1;         /*   Transmit Interrupt Enable              */
            UINT8 RIE :1;         /*   Receive Interrupt Enable               */
            UINT8 TE  :1;         /*   Transmitter Enable                     */
            UINT8 RE  :1;         /*   Receiver Enable                        */
            UINT8 MPIE:1;         /*   Multiproc. Interrupt Enable            */
            UINT8 TEIE:1;         /*   Transmit End Interrupt Enable          */
            UINT8 CKE :2;         /*   Clock Enable                           */
        } BIT;                    /*                                          */
    } SCR;                        /*                                          */
    UINT8 TDR;                    /*  Transmit Data Register                  */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*   Serial Status Register                 */
            UINT8 TDRE:1;         /*   Transmit Data Register Empty           */
            UINT8 RDRF:1;         /*   Receive Data Register Full             */
            UINT8 ORER:1;         /*   Overrun Error                          */
            UINT8 FER :1;         /*   Framing Error                          */
            UINT8 PER :1;         /*   Parity Eror                            */
            UINT8 TEND:1;         /*   Transmit End                           */
            UINT8 MPB :1;         /*   Multiprocessor Bit                     */
            UINT8 MPBT:1;         /*   Multiprocessor Bit Transfer            */
        } BIT;                    /*                                          */
    } SSR;                        /*                                          */
    UINT8 RDR;                    /*  Receive Data Register                   */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*   Smart Card Mode Register               */
            UINT8     :4;         /*                                          */
            UINT8 SDIR:1;         /*   Smart Card Data Transfer Direction     */
            UINT8 SINV:1;         /*   Smart Card Data Invert                 */
            UINT8     :1;         /*                                          */
            UINT8 SMIF:1;         /*   Smart Card Interface Mode Select       */
        } BIT;                    /*                                          */
    } SCMR;                       /*                                          */
};                                /********************************************/

struct st_tpu {                   /********************************************/
    union {                       /*    Timer Pulse Unit                      */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Start Register                  */
            UINT8 wk  :2;         /*                                          */
            UINT8 CST5:1;         /*    Counter Start 5                       */
            UINT8 CST4:1;         /*    Counter Start 4                       */
            UINT8 CST3:1;         /*    Counter Start 3                       */
            UINT8 CST2:1;         /*    Counter Start 2                       */
            UINT8 CST1:1;         /*    Counter Start 1                       */
            UINT8 CST0:1;         /*    Counter Start 0                       */
        } BIT;                    /*                                          */
    } TSTR;                       /*                                          */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Synchro Register                */
            UINT8 wk   :2;        /*                                          */
            UINT8 SYNC5:1;        /*    Timer Synchro 5                       */
            UINT8 SYNC4:1;        /*    Timer Synchro 4                       */
            UINT8 SYNC3:1;        /*    Timer Synchro 3                       */
            UINT8 SYNC2:1;        /*    Timer Synchro 2                       */
            UINT8 SYNC1:1;        /*    Timer Synchro 1                       */
            UINT8 SYNC0:1;        /*    Timer Synchro 0                       */
        } BIT;                    /*                                          */
    } TSYR;                       /*                                          */
};                                /********************************************/
               
struct st_tpu0 {                  /********************************************/
    union {                       /*    Timer Pulse Unit 0 & 3                */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Control Register                */
            UINT8 CCLR:3;         /*    Counter Clear Bits 2-0                */
            UINT8 CKEG:2;         /*    Clock Edge Bits 1-0                   */
            UINT8 TPSC:3;         /*    Timer Prescalar Bits 2-0              */
        } BIT;                    /*                                          */
    } TCR;                        /*                                          */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Mode Register                   */
            UINT8 wk :2;          /*                                          */
            UINT8 BFB:1;          /*    Buffer Operation A                    */
            UINT8 BFA:1;          /*    Buffer Operation B                    */
            UINT8 MD :4;          /*    Mode Bits 3-0                         */
        } BIT;                    /*                                          */
    } TMDR;                       /*                                          */
    union {                       /*                                          */
        UINT16 WORD;              /*                                          */
        struct {                  /*    Timer I/O Control  Register           */
            UINT8 H;              /*    Timer I/O Control High Byte           */
            UINT8 L;              /*    Timer I/O Control Low  Byte           */
        } BYTE;                   /*                                          */
        struct {                  /*                                          */
            UINT8 IOB:4;          /*    I/O Control for TGRB                  */
            UINT8 IOA:4;          /*    I/O Control for TGRA                  */
            UINT8 IOD:4;          /*    I/O Control for TGRD                  */
            UINT8 IOC:4;          /*    I/O Control for TGRC                  */
        } BIT;                    /*                                          */
    } TIOR;                       /*                                          */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Interrupt Enable Register       */
            UINT8 TTGE :1;        /*    A/D Conversion Start Request Enable   */
            UINT8      :2;        /*                                          */
            UINT8 TCIEV:1;        /*    Overflow Interrupt Enable             */
            UINT8 TGIED:1;        /*    TGR Interrupt Enable D                */
            UINT8 TGIEC:1;        /*    TGR Interrupt Enable C                */
            UINT8 TGIEB:1;        /*    TGR Interrupt Enable B                */
            UINT8 TGIEA:1;        /*    TGR Interrupt Enable A                */
        } BIT;                    /*                                          */
    } TIER;                       /*                                          */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Status Register                 */
            UINT8 wk  :3;         /*                                          */
            UINT8 TCFV:1;         /*    Overflow Flag                         */
            UINT8 TGFD:1;         /*    Input Capture/Output Compare Flag D   */
            UINT8 TGFC:1;         /*    Input Capture/Output Compare Flag C   */
            UINT8 TGFB:1;         /*    Input Capture/Output Compare Flag B   */
            UINT8 TGFA:1;         /*    Input Capture/Output Compare Flag A   */
        } BIT;                    /*                                          */
    } TSR;                        /*                                          */
    UINT16     TCNT;              /*    Timer Counter Register                */
    UINT16     TGRA;              /*    Timer General Register A              */
    UINT16     TGRB;              /*    Timer General Register B              */
    UINT16     TGRC;              /*    Timer General Register C              */
    UINT16     TGRD;              /*    Timer General Register D              */
};                                /********************************************/

struct st_tpu1 {                  /********************************************/
    union {                       /*    Timer Pulse Unit 1,2,4,5              */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Control Register                */
            UINT8 wk  :1;         /*                                          */
            UINT8 CCLR:2;         /*    Counter Clear Bits 2-0                */
            UINT8 CKEG:2;         /*    Clock Edge Bits 1-0                   */
            UINT8 TPSC:3;         /*    Timer Prescalar Bits 2-0              */
        } BIT;                    /*                                          */
    } TCR;                        /*                                          */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Mode Register                   */
            UINT8 wk:4;           /*                                          */
            UINT8 MD:4;           /*    Mode Bits 3-0                         */
        } BIT;                    /*                                          */
    } TMDR;                       /*                                          */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer I/O Control Register            */
            UINT8 IOB:4;          /*    I/O Control for TGRB                  */
            UINT8 IOA:4;          /*    I/O Control for TGRA                  */
        } BIT;                    /*                                          */
    } TIOR;                       /*                                          */
    char wk;                      /*                                          */
    union {                       /*                                          */
        UINT8 BYTE;               /*                                          */
        struct {                  /*    Timer Interrupt Enable Register       */
            UINT8 TTGE :1;        /*    A/D Conversion Start Request Enable   */
            UINT8      :1;        /*                                          */
            UINT8 TCIEU:1;        /*    Underflow Interrupt Enable            */
            UINT8 TCIEV:1;        /*    Overflow Interrupt Enable             */
            UINT8      :2;        /*                                          */
            UINT8 TGIEB:1;        /*    TGR Interrupt Enable B                */
            UINT8 TGIEA:1;        /*    TGR Interrupt Enable A                */
        } BIT;                    /*                                          */
    } TIER;                       /*                                          */
    union {                       /*    Timer Status Register                 */
        UINT8 BYTE;               /*                                          */
        struct {                  /*                                          */
            UINT8 TCFD:1;         /*    Timer Control Direction Flag          */
            UINT8     :1;         /*                                          */
            UINT8 TCFU:1;         /*    Underflow Flag                        */
            UINT8 TCFV:1;         /*    Overflow Flag                         */
            UINT8     :2;         /*                                          */
            UINT8 TGFB:1;         /*    Input Capture/Output Compare Flag B   */
            UINT8 TGFA:1;         /*    Input Capture/Output Compare Flag A   */
        } BIT;                    /*                                          */
    } TSR;                        /*                                          */
    UINT16     TCNT;              /*    Timer Counter Register                */
    UINT16     TGRA;              /*    Timer General Register A              */
    UINT16     TGRB;              /*    Timer General Register B              */
};                                /********************************************/

// 8-Bit Timers
struct st_tmr {
    UINT8     TCR0;                //  Timer Control Register 0
    UINT8     TCR1;                //  Timer Control Register 0
    UINT8     TCSR0;               //  Timer Control/Status Register 0
    UINT8     TCSR1;               //  Timer Control/Status Register 1
    UINT8     TCORA0;              //  Timer Constant Register A 0
    UINT8     TCORA1;              //  Timer Constant Register A 1
    UINT8     TCORB0;              //  Timer Constant Register B 0
    UINT8     TCORB1;              //  Timer Constant Register B 1
    UINT16    TCNT;                //  Timer Counter, 16 bit access. TCNT0 is the upper byte.
};

struct st_p1 {                                          /* struct P1    */
             unsigned char      DDR;                    /* P1DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P1PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2B0:3;         /*  Bits 2 - 0  */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P1DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
#if !HEK
                          unsigned char B2B0:3;         /*  Bits 2 - 0  */
#else
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
#endif
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
}             ;                                         /*              */
struct st_p2 {                                          /* struct P2    */
             unsigned char      DDR;                    /* P2DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P2PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P2DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
#if (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT))
                   struct {                             /*              */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1_0:2;         /*    Bit 0,1   */
                          }      F;                     /*              */
#endif                   
                   }            DR;                     /*             */
};                                                      /*              */
struct st_p3 {                                          /* struct P3    */
             unsigned char      DDR;                    /* P3DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P3PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:2;           /*    Bit 7,6   */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P3DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:2;           /*    Bit 7,6   */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
             char               wk3[19];                /*              */
             union {                                    /* P3ODR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:2;           /*    Bit 7,6   */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            ODR;                    /*              */
};                                                      /*              */
struct st_p4 {                                          /* struct P4    */
             union {                                    /* P4PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   struct {
                       unsigned char SNS  :4;
                       unsigned char IOTA :4;
                          } NIBBLE;
                   }            PORT;                   /*              */
};                                                      /*              */
#if (LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT)||\
        (HEK &&(defined(IOMTYPE_AOH)|| defined(IOMTYPE_AOHBOOT)|| defined(IOMTYPE_AIH) || defined(IOMTYPE_AIHBOOT)))||\
                defined(IOMTYPE_DO) || defined(IOMTYPE_DOBOOT) || defined(IOMTYPE_DI)  || defined(IOMTYPE_DIBOOT))
//#if (LOWCOST || defined(IOMTYPE_PI)||defined(IOMTYPE_PIBOOT)||defined(IOMTYPE_UIO)||defined(IOMTYPE_UIOBOOT))
struct st_p5 {                                          /* struct P5    */
             unsigned char      DDR;                    /* P5DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P5PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P5DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
#if defined(IOPTYPE_DI)
                          unsigned char B21:2;          /*    Bit 2-1   */
#else
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
#endif
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
                                                        /* P5SYSCR      */
};                                                      /*              */
struct st_p6 {                                          /* struct P6    */
             unsigned char      DDR;                    /* P6DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P6PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
#if defined(DIGTYPE_DO16)
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
#else
                          unsigned char B2B0:3;         /*  Bits 2 - 0  */
#endif
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P6DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
};                                                      /*              */
#endif
struct st_pa {                                          /* struct PA    */
             unsigned char      DDR;                    /* PADDR        */
             char               wk1[159];               /*              */
             union {                                    /* PAPORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* PADR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
             char               wk3[6];                 /*              */
             union {                                    /* PAPCR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PCR;                    /*              */
             char               wk4[6];                 /*              */
             union {                                    /* PAODR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            ODR;                    /*              */
};                                                      /*              */
struct st_pb {                                          /* struct PB    Used for PORT B,C,D,E  */
             unsigned char      DDR;                    /* PBDDR        */
             char               wk1[159];               /*              */
             union {                                    /* PBPORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* PBDR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
#if LOWCOST
                   struct {                             /*  Bit  Access */
#if (defined(IOMTYPE_AOH)|| defined(IOMTYPE_AOHBOOT))                   
                          unsigned char B7B5:3;         /*Bit 7,6,5     */
                          unsigned char B4B0:5;         /*Bit 4,3,2,1,0 */
#else
                          unsigned char B7B4:4;         /* Bit 7,6,5,4  */
                          unsigned char B3B0:4;         /* Bit 3,2,1,0  */
#endif
                          }      C;                     /*              */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5B0:6;         /*Bit5,4,3,2,1,0*/
                          }      E;                     /*              */
#endif
                   }            DR;                     /*              */
             char               wk3[6];                 /*              */
             union {                                    /* PBPCR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PCR;                    /*              */
}; 

#if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE) || defined(IOMTYPE_DO) || defined(IOMTYPE_DOBOOT))
    struct st_pg {                                      /* struct PG    */
                 unsigned char      DDR;                /* PGDDR        */
                 char               wk1[159];           /*              */
                 union {                                /* PGPORT       */
                       unsigned char BYTE;              /*  Byte Access */
                       struct {                         /*  Bit  Access */
                              unsigned char wk:3;       /*    Bit 7,6,5 */
                              unsigned char B4:1;       /*    Bit 4     */
                              unsigned char B3:1;       /*    Bit 3     */
                              unsigned char B2:1;       /*    Bit 2     */
                              unsigned char B1:1;       /*    Bit 1     */
                              unsigned char B0:1;       /*    Bit 0     */
                              }      BIT;               /*              */
                       }            PORT;               /*              */
                 char               wk2[15];            /*              */
                 union {                                /* PGDR         */
                       unsigned char BYTE;              /*  Byte Access */
                       struct {                         /*  Bit  Access */
                              unsigned char wk:3;       /*    Bit 7,6,5 */
#if defined(IOPTYPE_DI) || defined(IOPTYPE_DO)
                              unsigned char B4:1;       /*    Bit 4     */
                              unsigned char B3:1;       /*    Bit 3     */
#else
                              unsigned char B43:2;      /*   Bit 4-3    */
#endif
                              unsigned char B2:1;       /*    Bit 2     */
                              unsigned char B10:2;      /*   Bit 1-0    */
                              }      BIT;               /*              */
                       }            DR;                 /*              */
    };                                     /*              */
#elif HEK
    struct st_pg {                                      /* struct PG    */
                 unsigned char      DDR;                /* PGDDR        */
                 char               wk1[159];           /*              */
                 union {                                /* PGPORT       */
                       unsigned char BYTE;              /*  Byte Access */
                       struct {                         /*  Bit  Access */
                              unsigned char wk:3;       /*    Bit 7,6,5 */
                              unsigned char B4:1;       /*    Bit 4     */
                              unsigned char B3:1;       /*    Bit 3     */
                              unsigned char B2:1;       /*    Bit 2     */
                              unsigned char B1:1;       /*    Bit 1     */
                              unsigned char B0:1;       /*    Bit 0     */
                              }      BIT;               /*              */
                       }            PORT;               /*              */
                 char               wk2[15];            /*              */
                 union {                                /* PGDR         */
                       unsigned char BYTE;              /*  Byte Access */
                       struct {                         /*  Bit  Access */
                              unsigned char wk:3;       /*    Bit 7,6,5 */
                              unsigned char B4:1;       /*    Bit 4     */
                              unsigned char B3:1;       /*    Bit 3     */
                              unsigned char B2:1;       /*    Bit 2     */
                              unsigned char B1:1;       /*    Bit 1     */
                              unsigned char B0:1;       /*    Bit 0     */
                              }      BIT;               /*              */
                       }            DR;                 /*              */
    };                                                  /*              */
#else
    struct st_pg {                                      /* struct PG    */
                 unsigned char      DDR;                /* PGDDR        */
                 char               wk1[159];           /*              */
                 union {                                /* PGPORT       */
                       unsigned char BYTE;              /*  Byte Access */
                       struct {                         /*  Bit  Access */
                              unsigned char wk:3;       /*    Bit 7,6,5 */
                              unsigned char B4:1;       /*    Bit 4     */
                              unsigned char B3:1;       /*    Bit 3     */
                              unsigned char B2:1;       /*    Bit 2     */
                              unsigned char B1:1;       /*    Bit 1     */
                              unsigned char B0:1;       /*    Bit 0     */
                       }      BIT;                      /*              */
                       }            PORT;               /*              */
                 char               wk2[15];            /*              */
                 union {                                /* PGDR         */
                       unsigned char BYTE;              /*  Byte Access */
                       struct {                         /*  Bit  Access */
                              unsigned char wk:3;       /*   Bit 7,6,5  */
                              unsigned char B4:1;       /*   Bit 4      */
                              unsigned char B3:1;       /*   Bit 3      */
                              unsigned char B2:1;       /*   Bit 2      */
                              unsigned char B10:2;      /*   Bit 1-0    */
                              }      BIT;               /*              */
                       }            DR;                 /*              */
    };                                                  /*              */
#endif // IOMTYPE_DI and IOMTYPE_DISOE

struct st_intc {                                        /* struct INTC  */
               union {                                  /* IPRA         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    IRQ0      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    IRQ1      */
                            }      BIT;                 /*              */
                     }          IPRA;                   /*              */
               union {                                  /* IPRB         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    IRQ2,3    */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    IRQ4,5    */
                            }      BIT;                 /*              */
                     }          IPRB;                   /*              */
               union {                                  /* IPRC         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    IRQ6,IRQ7 */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    DTC       */
                            }      BIT;                 /*              */
                     }          IPRC;                   /*              */
               union {                                  /* IPRD         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    WDT       */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    RFSHC     */
                            }      BIT;                 /*              */
                     }          IPRD;                   /*              */
               union {                                  /* IPRE         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :5;       /*              */
                            unsigned char LOW :3;       /*    A/D       */
                            }      BIT;                 /*              */
                     }          IPRE;                   /*              */
               union {                                  /* IPRF         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TPU0      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TPU1      */
                            }      BIT;                 /*              */
                     }          IPRF;                   /*              */
               union {                                  /* IPRG         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TPU2      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TPU3      */
                            }      BIT;                 /*              */
                     }          IPRG;                   /*              */
               union {                                  /* IPRH         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TPU4      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TPU5      */
                            }      BIT;                 /*              */
                     }          IPRH;                   /*              */
               union {                                  /* IPRI         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TMR0      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TMR1      */
                            }      BIT;                 /*              */
                     }          IPRI;                   /*              */
               union {                                  /* IPRJ         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    DMAC      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    SCI0      */
                            }      BIT;                 /*              */
                     }          IPRJ;                   /*              */
               union {                                  /* IPRK         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    SCI1      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    SCI2      */
                            }      BIT;                 /*              */
                     }          IPRK;                   /*              */
               char             wk[93];                 /*              */
               union {                                  /* ISCR         */
                     unsigned int WORD;                 /*  Word Access */
                     struct {                           /*  Byte Access */
                            unsigned char H;            /*    ISCRH     */
                            unsigned char L;            /*    ISCRL     */
                            }     BYTE;                 /*              */
                     struct {                           /*  Bit  Access */
                            unsigned char IRQ7SC:2;     /*    IRQ7SC    */
                            unsigned char IRQ6SC:2;     /*    IRQ6SC    */
                            unsigned char IRQ5SC:2;     /*    IRQ5SC    */
                            unsigned char IRQ4SC:2;     /*    IRQ4SC    */
                            unsigned char IRQ3SC:2;     /*    IRQ3SC    */
                            unsigned char IRQ2SC:2;     /*    IRQ2SC    */
                            unsigned char IRQ1SC:2;     /*    IRQ1SC    */
                            unsigned char IRQ0SC:2;     /*    IRQ0SC    */
                            }     BIT;                  /*              */
                     }          ISCR;                   /*              */
               union {                                  /* IER          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char IRQ7E:1;      /*    IRQ7E     */
                            unsigned char IRQ6E:1;      /*    IRQ6E     */
                            unsigned char IRQ5E:1;      /*    IRQ5E     */
                            unsigned char IRQ4E:1;      /*    IRQ4E     */
                            unsigned char IRQ3E:1;      /*    IRQ3E     */
                            unsigned char IRQ2E:1;      /*    IRQ2E     */
                            unsigned char IRQ1E:1;      /*    IRQ1E     */
                            unsigned char IRQ0E:1;      /*    IRQ0E     */
                            }      BIT;                 /*              */
                     }          IER;                    /*              */
               union {                                  /* ISR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char IRQ7F:1;      /*    IRQ7F     */
                            unsigned char IRQ6F:1;      /*    IRQ6F     */
                            unsigned char IRQ5F:1;      /*    IRQ5F     */
                            unsigned char IRQ4F:1;      /*    IRQ4F     */
                            unsigned char IRQ3F:1;      /*    IRQ3F     */
                            unsigned char IRQ2F:1;      /*    IRQ2F     */
                            unsigned char IRQ1F:1;      /*    IRQ1F     */
                            unsigned char IRQ0F:1;      /*    IRQ0F     */
                            }      BIT;                 /*              */
                     }          ISR;                    /*              */
};                                                      /*              */
struct st_dtc {                                         /* struct DTC   */
              union {                                   /* EA           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    IRQ0      */
                           unsigned char B6:1;          /*    IRQ1      */
                           unsigned char B5:1;          /*    IRQ2      */
                           unsigned char B4:1;          /*    IRQ3      */
                           unsigned char B3:1;          /*    IRQ4      */
                           unsigned char B2:1;          /*    IRQ5      */
                           unsigned char B1:1;          /*    IRQ6      */
                           unsigned char B0:1;          /*    IRQ7      */
                           }      BIT;                  /*              */
                    }           EA;                     /*              */
              union {                                   /* EB           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk:1;          /*              */
                           unsigned char B6:1;          /*    ADI       */
                           unsigned char B5:1;          /*    TGI0A     */
                           unsigned char B4:1;          /*    TGI0B     */
                           unsigned char B3:1;          /*    TGI0C     */
                           unsigned char B2:1;          /*    TGI0D     */
                           unsigned char B1:1;          /*    TGI1A     */
                           unsigned char B0:1;          /*    TGI1B     */
                           }      BIT;                  /*              */
                    }           EB;                     /*              */
              union {                                   /* EC           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    TGI2A     */
                           unsigned char B6:1;          /*    TGI2B     */
                           unsigned char B5:1;          /*    TGI3A     */
                           unsigned char B4:1;          /*    TGI3B     */
                           unsigned char B3:1;          /*    TGI3C     */
                           unsigned char B2:1;          /*    TGI3D     */
                           unsigned char B1:1;          /*    TGI4A     */
                           unsigned char B0:1;          /*    TGI4B     */
                           }      BIT;                  /*              */
                    }           EC;                     /*              */
              union {                                   /* ED           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk:2;          /*              */
                           unsigned char B5:1;          /*    TGI5A     */
                           unsigned char B4:1;          /*    TGI5B     */
                           unsigned char B3:1;          /*    CMI0A     */
                           unsigned char B2:1;          /*    CMI0B     */
                           unsigned char B1:1;          /*    CMI1A     */
                           unsigned char B0:1;          /*    CMI1B     */
                           }      BIT;                  /*              */
                    }           ED;                     /*              */
              union {                                   /* EE           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk:4;          /*              */
                           unsigned char B3:1;          /*    RXI0      */
                           unsigned char B2:1;          /*    TXI0      */
                           unsigned char B1:1;          /*    RXI1      */
                           unsigned char B0:1;          /*    TXI1      */
                           }      BIT;                  /*              */
                    }           EE;                     /*              */
              union {                                   /* EF           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    RXI2      */
                           unsigned char B6:1;          /*    TXI2      */
                           }      BIT;                  /*              */
                    }           EF;                     /*              */
              char              wk;                     /*              */
              union {                                   /* VECR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char SWDTE:1;       /*    SWDTE     */
                           unsigned char DTVEC:7;       /*    DTVEC     */
                           }      BIT;                  /*              */
                    }           VECR;                   /*              */
};                                                      /*              */
union un_sbycr {                                        /* union SBYCR  */
               unsigned char BYTE;                      /*  Byte Access */
               struct {                                 /*  Bit  Access */
                      unsigned char SSBY  :1;           /*    SSBY      */
                      unsigned char STS   :3;           /*    STS       */
                      unsigned char OPE   :1;           /*    OPE       */
                      unsigned char       :2;           /*              */
                      unsigned char IRQ37S:1;           /*    IRQ37S    */
                      }      BIT;                       /*              */
};                                                      /*              */
union un_syscr {                                        /* union SYSCR  */
               unsigned char BYTE;                      /*  Byte Access */
               struct {                                 /*  Bit  Access */
                      unsigned char wk    :2;           /*              */
                      unsigned char INTM  :2;           /*    INTM      */
                      unsigned char NMIEG :1;           /*    NMIEG     */
                      unsigned char LWROD :1;           /*    LWROD     */
                      unsigned char IRQPAS:1;           /*    IRQPAS    */
                      unsigned char RAME  :1;           /*    RAME      */
                      }      BIT;                       /*              */
};                                                      /*              */
union un_sckcr {                                        /* union SCKCR  */
               unsigned char BYTE;                      /*  Byte Access */
               struct {                                 /*  Bit  Access */
                      unsigned char PSTOP:1;            /*    PSTOP     */
                      unsigned char      :1;            /*              */
                      unsigned char DIV  :1;            /*    DIV       */
                      unsigned char      :2;            /*              */
                      unsigned char SCK  :3;            /*    SCK       */
                      }      BIT;                       /*              */
};                                                      /*              */
union un_mdcr {                                         /* union MDCR   */
              unsigned char BYTE;                       /*  Byte Access */
              struct {                                  /*  Bit  Access */
                     unsigned char wk :5;               /*              */
                     unsigned char MDS:3;               /*    MDS       */
                     }      BIT;                        /*              */
};                                                      /*              */
union un_syscr2 {                                       /* union SYSCR2 */
                unsigned char BYTE;                     /*  Byte Access */
                struct {                                /*  Bit  Access */
                       unsigned char wk   :4;           /*              */
                       unsigned char FLSHE:1;           /*    FLSHE     */
                       }      BIT;                      /*              */
};                                                      /*              */

struct st_bsc {                                         /* struct BSC   */
              union {                                   /* ABWCR        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    Bit 7     */
                           unsigned char B6:1;          /*    Bit 6     */
                           unsigned char B5:1;          /*    Bit 5     */
                           unsigned char B4:1;          /*    Bit 4     */
                           unsigned char B3:1;          /*    Bit 3     */
                           unsigned char B2:1;          /*    Bit 2     */
                           unsigned char B1:1;          /*    Bit 1     */
                           unsigned char B0:1;          /*    Bit 0     */
                           }      BIT;                  /*              */
                    }           ABWCR;                  /*              */
              union {                                   /* ASTCR        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    Bit 7     */
                           unsigned char B6:1;          /*    Bit 6     */
                           unsigned char B5:1;          /*    Bit 5     */
                           unsigned char B4:1;          /*    Bit 4     */
                           unsigned char B3:1;          /*    Bit 3     */
                           unsigned char B2:1;          /*    Bit 2     */
                           unsigned char B1:1;          /*    Bit 1     */
                           unsigned char B0:1;          /*    Bit 0     */
                           }      BIT;                  /*              */
                    }           ASTCR;                  /*              */
              union {                                   /* WCR          */
                    unsigned int WORD;                  /*  Word Access */
                    struct {                            /*  Byte Access */
                           unsigned char H;             /*    WCRH      */
                           unsigned char L;             /*    WCRL      */
                           }     BYTE;                  /*              */
                    struct {                            /*  Bit  Access */
                           unsigned char W7:2;          /*    W7        */
                           unsigned char W6:2;          /*    W6        */
                           unsigned char W5:2;          /*    W5        */
                           unsigned char W4:2;          /*    W4        */
                           unsigned char W3:2;          /*    W3        */
                           unsigned char W2:2;          /*    W2        */
                           unsigned char W1:2;          /*    W1        */
                           unsigned char W0:2;          /*    W0        */
                           }     BIT;                   /*              */
                    }           WCR;                    /*              */
              union {                                   /* BCR          */
                    unsigned int WORD;                  /*  Word Access */
                    struct {                            /*  Byte Access */
                           unsigned char H;             /*    BCRH      */
                           unsigned char L;             /*    BCRL      */
                           }     BYTE;                  /*              */
                    struct {                            /*  Bit  Access */
                           unsigned char ICIS1 :1;      /*    ICIS1     */
                           unsigned char ICIS0 :1;      /*    ICIS0     */
                           unsigned char BRSTRM:1;      /*    BRSTRM    */
                           unsigned char BRSTS1:1;      /*    BRSTS1    */
                           unsigned char BRSTS0:1;      /*    BRSTS0    */
                           unsigned char RMTS  :3;      /*    RMTS      */
                           unsigned char BRLE  :1;      /*    BRLE      */
                           unsigned char BREQOE:1;      /*    BREQOE    */
                           unsigned char EAE   :1;      /*    EAE       */
                           unsigned char       :1;      /*              */
                           unsigned char  DDS  :1;      /*    DDS       */
                           unsigned char       :1;      /*              */
                           unsigned char WDBE  :1;      /*    WDBE      */
                           unsigned char WAITE :1;      /*    WAITE     */
                           }     BIT;                   /*              */
                    }           BCR;                    /*              */
              char              wk1[111];               /*              */
              union {                                   /* PFCR1        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char        :4;     /*              */
                           unsigned char A23E   :1;     /*    A23E      */
                           unsigned char A22E   :1;     /*    A22E      */
                           unsigned char A21E   :1;     /*    A21E      */
                           unsigned char A20E   :1;     /*    A20E      */
                           }      BIT;                  /*              */
                    }           PFCR1;                  /*              */
              char              wk2[102];               /*              */
              union {                                   /* PFCR2        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char WAITPS :1;     /*    WAITPS    */
                           unsigned char BREQOPS:1;     /*    BREQOPS   */
                           unsigned char CS167E :1;     /*    CS167E    */
                           unsigned char CS25E  :1;     /*    CS25E     */
                           unsigned char ASOD   :1;     /*    ASOD      */
                           unsigned char        :3;     /*              */
                           }      BIT;                  /*              */
                    }           PFCR2;                  /*              */
};                                                      /*              */
#if H8S_2319C
// 2319c Flash Registers configuration

union un_fccs {                        /* Flash Code Control Select FCCS  IV = 0x80 ,Address = H'FFC4*/ 
    unsigned char BYTE ;               /* Byte access*/
    struct {                           /* Bit  access*/
        unsigned char      : 3;
        unsigned char FLER : 1;        /* FLER*/
        unsigned char      : 3;
        unsigned char SCO  : 1;        /* SCO*/
    }    BIT;
};

union un_fpcs {                        /* FPCS  IV = 0x00 ,Address = H'FFC5*/ 
    unsigned char BYTE ;               /* Byte access*/
    struct {                           /* Bit  access*/
        unsigned char      : 7;
        unsigned char PPVS : 1;        /* PPVS*/
    }    BIT;
};

union un_fecs {                        /* FECS  IV = 0x00 ,Address = H'FFC6*/ 
    unsigned char BYTE ;               /* Byte access*/
    struct {                           /* Bit  access*/
        unsigned char      : 7;
        unsigned char EPVB : 1;        /* EPVB*/
    }    BIT;
};

union un_ramer {                       /* RAMER  IV = 0x00 ,Address = H'FEDB*/ 
    unsigned char BYTE ;               /* Byte access*/
    struct {                           /* Bit  access*/    
        unsigned char          : 4;
        unsigned char RAMS     : 1;
        unsigned char RAM2     : 1;
        unsigned char RAM1     : 1;
        unsigned char RAM0     : 1;
    }    BIT;
};
#endif

// For PI, RED and GREEN Port pins are flipped in Pass 1 compared to other Series C Modules. 
// Presently fixing in firmware. Once it is fixed in Pass 2 Boards will revert back the code changes.
#if (defined(IOMTYPE_PIBOOT)||defined(IOMTYPE_PI))
typedef enum tagStatusLed {
    STATUSLED_AMBER = 0,
    STATUSLED_GREEN = 1,
    STATUSLED_RED   = 2,
    STATUSLED_OFF   = 3
} STATUSLED;
#else
typedef enum tagStatusLed {
    STATUSLED_AMBER = 0,
    STATUSLED_RED   = 1,
    STATUSLED_GREEN = 2,
    STATUSLED_OFF   = 3
} STATUSLED;
#endif

// Define FWtypes
typedef enum tagFwType {
    FWTYPE_BOOT = 0,
    FWTYPE_APP  = 1,
    FWTYPE_FPGA = 2
} FWTYPE;
/*******************************************************************************
*                            CONSTANT DECLARATIONS                             *
*******************************************************************************/
const UINT32 SYSTEM_CLOCK_FREQUENCY = 24000000; // 24 MHz
const UINT32 SECONDS_IN_MINUTE      = 60;
const UINT32 MILLISECONDS_IN_SECOND = 1000; 
const UINT32 MICROSECONDS_IN_MILLISECOND = 1000;
const UINT32 MICROSECONDS_IN_SECOND = MICROSECONDS_IN_MILLISECOND * MILLISECONDS_IN_SECOND;

// Define memory addresses
#define FLASH_START_ADDRESS             (0x00000000)
#define FLASH_PROGRAM_BLOCK_SIZE        (128)

#if (!HEK) && (!LOWCOST)
    #define BOOT_FLASH_START_ADDRESS    (0x00008000)    // Address where boot firmware flashing starts
    #define BOOT_HEADER_START_ADDRESS   (0x000084F0)    // Boot Header start address
    #define BOOT_HEADER_END_ADDRESS     (0x000084FF)    // Boot Header end address
    #define BOOT_BYTECNT_ADDRESS        (0x000084F0)    // Boot Firmware size location
    #define BOOT_CRC_ADDRESS            (0x000084F4)    // Boot 32Bit CRC location
    #define BOOT_MODTYPE_ADDRESS        (0x000084F8)    // Boot Module type location
    #define BOOT_FWTYPE_ADDRESS         (0x000084FA)    // Boot Firmware type location
    #define APP_FLASH_START_ADDRESS     (0x00008000)    // APP Fimrware Start
    #define APP_HEADER_START_ADDRESS    (0x000084F0)    // APP Header Start
    #define APP_HEADER_END_ADDRESS      (0x000084FF)    // APP Header End
    #define APP_BYTECNT_ADDRESS         (0x000084F0)    // APP FW ByteCount
    #define APP_CRC_ADDRESS             (0x000084F4)    // APP FW 32Bit CRC
#elif (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AOHBOOT)\
           ||  defined(IOMTYPE_AIH) || defined(IOMTYPE_AIHBOOT)))
//#elif (H8s2329_MAP_V02)
    #define BOOT_FLASH_START_ADDRESS    (0x00030000)    // Address where boot firmware flashing starts
    #define BOOT_HEADER_START_ADDRESS   (0x000304F0)    // Header start address
    #define BOOT_HEADER_END_ADDRESS     (0x000304FF)    // Boot Header end address
    #define BOOT_BYTECNT_ADDRESS        (0x000304F0)    // Boot Firmware size location
    #define BOOT_CRC_ADDRESS            (0x000304F4)    // Boot 32Bit CRC location
    #define BOOT_MODTYPE_ADDRESS        (0x000304F8)    // Boot Module type location
    #define BOOT_FWTYPE_ADDRESS         (0x000304FA)    // Boot Firmware type location
    #define APP_FLASH_START_ADDRESS     (0x00030000)    // APP Fimrware Start
    #define APP_HEADER_START_ADDRESS    (0x000304F0)    // APP Header Start
    #define APP_HEADER_END_ADDRESS      (0x000304FF)    // APP Header End
    #define APP_BYTECNT_ADDRESS         (0x000304F0)    // APP FW ByteCount
    #define APP_CRC_ADDRESS             (0x000304F4)    // APP FW 32Bit CRC
    #define FPGA_FLASH_START_ADDRESS    (0x00030000)    // Address where fpga firmware flashing starts
    #define FPGA_HEADER_START_ADDRESS   (0x00030000)    // Header start address
    #define FPGA_HEADER_END_ADDRESS     (0x0003000F)    // Fpga Header end address
    #define FPGA_BYTECNT_ADDRESS        (0x00030000)    // Fpga Firmware size location
    #define FPGA_CRC_ADDRESS            (0x00030004)    // Fpga 32Bit CRC location
    #define FPGA_MODTYPE_ADDRESS        (0x00030008)    // Fpga Module type location
    #define FPGA_FWTYPE_ADDRESS         (0x0003000A)    // Fpga Firmware type location
    #define FPGA_STARTS_HERE_IN_H8      (0x00008000)    // Actual location of Fpga in flash
#else 
    #define BOOT_FLASH_START_ADDRESS    (0x00020000)    // Address where boot firmware flashing starts
    #define BOOT_HEADER_START_ADDRESS   (0x000204F0)    // Header start address
    #define BOOT_HEADER_END_ADDRESS     (0x000204FF)    // Boot Header end address
    #define BOOT_BYTECNT_ADDRESS        (0x000204F0)    // Boot Firmware size location
    #define BOOT_CRC_ADDRESS            (0x000204F4)    // Boot 32Bit CRC location
    #define BOOT_MODTYPE_ADDRESS        (0x000204F8)    // Boot Module type location
    #define BOOT_FWTYPE_ADDRESS         (0x000204FA)    // Boot Firmware type location
    #define APP_FLASH_START_ADDRESS     (0x00020000)    // APP Fimrware Start
    #define APP_HEADER_START_ADDRESS    (0x000204F0)    // APP Header Start
    #define APP_HEADER_END_ADDRESS      (0x000204FF)    // APP Header End
    #define APP_BYTECNT_ADDRESS         (0x000204F0)    // APP FW ByteCount
    #define APP_CRC_ADDRESS             (0x000204F4)    // APP FW 32Bit CRC
    #define FPGA_FLASH_START_ADDRESS    (0x00020000)    // Address where fpga firmware flashing starts
    #define FPGA_HEADER_START_ADDRESS   (0x00020000)    // Header start address
    #define FPGA_HEADER_END_ADDRESS     (0x0002000F)    // Fpga Header end address
    #define FPGA_BYTECNT_ADDRESS        (0x00020000)    // Fpga Firmware size location
    #define FPGA_CRC_ADDRESS            (0x00020004)    // Fpga 32Bit CRC location
    #define FPGA_MODTYPE_ADDRESS        (0x00020008)    // Fpga Module type location
    #define FPGA_FWTYPE_ADDRESS         (0x0002000A)    // Fpga Firmware type location
    #define FPGA_STARTS_HERE_IN_H8      (0x00008000)    // Actual location of Fpga in flash
#endif

#ifdef IOMTYPE_DISOE
    #define INTERNAL_RAM_START_ADDRESS  (0x00FFBC00)    // 16K internal RAM
#elif (LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT)|| defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))\
               ||(defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT)|| defined(IOMTYPE_DO)  || defined(IOMTYPE_DOBOOT))
    #define INTERNAL_RAM_START_ADDRESS  (0x00FF7C00)    // 32K internal RAM
#else
    #define INTERNAL_RAM_START_ADDRESS  (0x00FFDC00)    // 8K internal RAM
#endif
#define INTERNAL_RAM_END_ADDRESS        (0x00FFFBFF)

#define P1DR                            (0x00FFFF60)
#define PGDR                            (0x00FFFF6F)

#if (HEK)
    #if (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
        #define FPGA_END_ADDRESS        (0x004021FF)
        #define FLASH_END_ADDRESS       (0x0005FFFF)    // 384K internal ROM       
    #else
        #define FPGA_END_ADDRESS        (0x004000FF)

        #if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AOHBOOT) ||  defined(IOMTYPE_AIH) || defined(IOMTYPE_AIHBOOT))
        //#if (H8s2329_MAP_V02)
            #define FLASH_END_ADDRESS   (0x0005FFFF)    // 384K internal ROM
        #else
            #define FLASH_END_ADDRESS   (0x0003FFFF)    // 256K internal ROM
        #endif

    #endif
    #define EXTERNAL_RAM_START_ADDRESS  (0x00200000)    // 128K external RAM
    #define EXTERNAL_RAM_END_ADDRESS    (0x0021FFFF)
    #define CPLD_START_ADDRESS          (0x00080000)
    #define CPLD_END_ADDRESS            (0x0008001F)
    #define FPGA_START_ADDRESS          (0x00400000)
    #define STACK_SIZE                  0x1000          // 4K bytes stack for HEK debug and release versions.
    #define STACK_SFLIMIT               0x100           // 256 bytes stack guarded area
#else
#if (LOWCOST) ||(defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT)|| defined(IOMTYPE_DO)  || defined(IOMTYPE_DOBOOT)) 
        #define FLASH_END_ADDRESS       (0x0005FFFF)    // 384K internal ROM
    #else
        #define FLASH_END_ADDRESS       (0x0001FFFF)    // 128K internal ROM
    #endif

    #ifdef DEBUG
        #if (defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT)|| defined(IOMTYPE_DO)  || defined(IOMTYPE_DOBOOT))
            #define STACK_SIZE          0x1000          // 4K of stack for PMIO DI/DO module.
        #else
            #define STACK_SIZE          0x3C0           // 960 bytes stack for LEK debug version.
        #endif
    #else
        #ifdef IOMTYPE_DISOE
            #define STACK_SIZE          0x900           // 2.25K of stack for DISOE module.
        #elif LOWCOST ||(defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT)|| defined(IOMTYPE_DO)  || defined(IOMTYPE_DOBOOT)) 
            #define STACK_SIZE          0x1000          // 4K of stack for LOWCOST AI/AO & PMIO DI/DO module.
        #else
            #define STACK_SIZE          0x500           // 1152 bytes stack for LEK release version.
        #endif // DISOE
    #endif

#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT)|| defined(IOMTYPE_DO)  || defined(IOMTYPE_DOBOOT))
    #define STACK_SFLIMIT               0x100           // 256 bytes stack guarded area
#else
    #define STACK_SFLIMIT               0x40            // 64 bytes stack guarded area
#endif
#endif // HEK

#define STACK_BOTTOM                    ((volatile UINT32 *)INTERNAL_RAM_END_ADDRESS)
#define STACK_TOP                       ((volatile UINT32 *)(INTERNAL_RAM_END_ADDRESS + 1 - STACK_SIZE))

// Module Info section definitions
#define MODULE_INFO_FLASH_BLOCK         (7)
#define MODULEINFO_START_ADDRESS        (0x00007000)
#define VENDOR_ID                       (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS)))
#define PRODUCT_TYPE                    (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 2)))
#define PRODUCT_CODE                    (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4)))
#define SERIAL_NUMBER                   (*((volatile UINT32  *)(MODULEINFO_START_ADDRESS + 6)))
#define HARDWARE_REVCODE                (*((volatile UINT8   *)(MODULEINFO_START_ADDRESS + 10)))
#define HARDWARE_REVNUMBER              (*((volatile UINT8   *)(MODULEINFO_START_ADDRESS + 11)))
#define CALIBRATION_MARK                (*((volatile UINT8   *)(MODULEINFO_START_ADDRESS + 15)))

#ifdef IOMTYPE_AIH
    #define CALIBRATION_5VREF_HILIMIT   (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 16)))
    #define CALIBRATION_5VREF_LOLIMIT   (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 20)))
    #define CALIBRATION_SLOPE           (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 24)))
    #define CALIBRATION_OFFSET          (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 28)))
    #define CHANNEL_ZERODRIFT_PTR       ((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 32))
#elif defined(IOMTYPE_AOH)
    #define CHANNEL_OFFSET_PTR          ((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 16))
    #define CALIBRATION_SLOPE           (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 272)))
    #define CALIBRATION_OFFSET          (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 276)))
    #define CALIB_TEST_COUNT            (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 280)))
#endif

#define MODULEINFO_WRITECOUNT           (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4090)))
#define MODULEINFO_WRITE_FLAGS          (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4092)))
#define MODULEINFO_CHKSUM               (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4094)))
#define MODULEINFO_END_ADDRESS          (0x00007FFF)

// Programmable Device Information
const UINT8 PD_REV_A = 1;
const UINT8 PD_REV_B = PD_REV_A + 1;
const UINT8 PD_REV_C = PD_REV_B + 1;
const UINT8 PD_REV_D = PD_REV_C + 1;
const UINT8 PD_REV_E = PD_REV_D + 1;
const UINT8 PD_REV_F = PD_REV_E + 1;
const UINT8 PD_REV_G = PD_REV_F + 1;
const UINT8 PD_REV_H = PD_REV_G + 1;
const UINT8 PD_REV_I = PD_REV_H + 1;
const UINT8 PD_REV_J = PD_REV_I + 1;
const UINT8 PD_REV_K = PD_REV_J + 1;
const UINT8 PD_REV_L = PD_REV_K + 1;
const UINT8 PD_REV_M = PD_REV_L + 1;
const UINT8 PD_REV_N = PD_REV_M + 1;
const UINT8 PD_REV_O = PD_REV_N + 1;
const UINT8 PD_REV_P = PD_REV_O + 1;
const UINT8 PD_REV_Q = PD_REV_P + 1;
const UINT8 PD_REV_R = PD_REV_Q + 1;
const UINT8 PD_REV_S = PD_REV_R + 1;
const UINT8 PD_REV_T = PD_REV_S + 1;
const UINT8 PD_REV_U = PD_REV_T + 1;
const UINT8 PD_REV_V = PD_REV_U + 1;
const UINT8 PD_REV_W = PD_REV_V + 1;
const UINT8 PD_REV_X = PD_REV_W + 1;
const UINT8 PD_REV_Y = PD_REV_X + 1;
const UINT8 PD_REV_Z = PD_REV_Y + 1;

// Offsets in the SPI EEPROM for the calibration and HWINFO.
#if (HEK) || (LOWCOST)
    const UINT8 EE_VENDOR_ID            = 0;
    const UINT8 EE_PRODUCT_TYPE         = 2;
    const UINT8 EE_PRODUCT_CODE         = 4;
    const UINT8 EE_SERIAL_NUMBER        = 6;
    const UINT8 EE_HARDWARE_REVCODE     = 10;
    const UINT8 EE_CALIBRATION_MARK     = 15;
  #ifdef IOMTYPE_AIH 
    const UINT8 EE_CALIBRATION_5VREF_HILIMIT    = 16;
    const UINT8 EE_CALIBRATION_5VREF_LOLIMIT    = 20;
    const UINT8 EE_CALIBRATION_SLOPE            = 24;
    const UINT8 EE_CALIBRATION_OFFSET           = 28;
    #if !LOWCOST
    const UINT8 EE_CHANNEL_ZERODRIFT_PTR        = 32;   // AIH
    #else
    const UINT8 EE_CHANNEL_SLOPE_PTR            = 32;   // LOWCOST
    const UINT8 EE_CHANNEL_OFFSET_PTR           = 96;
    #endif
  #elif defined(IOMTYPE_AOH)
    const UINT8 EE_CHANNEL_OFFSET_PTR           = 16;
    const UINT16 EE_CALIBRATION_SLOPE           = 272;
    const UINT16 EE_CALIBRATION_OFFSET          = 276;
    const UINT16 EE_CALIB_TEST_COUNT            = 280;
  #endif
    const UINT16 EE_MODULEINFO_WRITECOUNT       = 506;
    const UINT16 EE_MODULEINFO_WRITE_FLAGS      = 508;
    const UINT16 EE_MODULEINFO_CHKSUM           = 510;
#endif

#define ADDRESS_RANGE_END           (0x00FFFFFF)
#define EEPROM_ADDR_RANGE_START     (0x00000)
#define EEPROM_ADDR_RANGE_END       (0x001FF)
#define EEPROM_CHKSM_ADDR_END       (0x001FE)
#define MAX_EEPROM_SIZE             512
#define EEPROM_PAGE_SIZE            16
#define EEPROM_LOW_PAGE             256

// Stack pattern bytes to check against stack corruption
const UINT32 STACKTESTPATTERN         = 0xFF5AA5FF; 
const UINT32 MAX_CALIBRATION_COUNT    = 200;
const UINT8  CALIBRATION_DONE         = 0xA5;

const UINT16 MODULINFO_WRITE_COMPLETE = 0x5A5A;
const UINT16 EEPROM_MAXWRCOUNT        = 10000;  //MAx 10,000 writes supported for EEPROM
const UINT8  HWINFO_REVLETTER_MASK    = 0x3F; // to mask out the two unused MSBs.
#if (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT))
const UINT8  FPGA_REVNUMBER_MASK    = 0x3F;
#elif (defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
const UINT8  FPGA_REVNUMBER_MASK    = 0x3F;
const UINT8  CPLD_REVNUMBER_MASK    = 0xFF;
#elif (defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT) || defined(IOMTYPE_DISOE) || defined(IOMTYPE_DISOEBOOT) || defined(IOMTYPE_DO) || defined(IOMTYPE_DOBOOT))
const UINT8  CPLD_REVNUMBER_MASK    = 0x1F;
#else
const UINT8  FPGA_REVNUMBER_MASK    = 0xFF;
const UINT8  CPLD_REVNUMBER_MASK    = 0xFF;
#endif
// Default manufacturing info values - loaded if module info section is not programmed.
const UINT32 DEFAULT_SERIAL_NUMBER    = 1234567890;
const UINT16 HWINFO_VENDOR_ID         = 3;
const UINT16 DEFAULT_PRODUCT_CODE     = 1;
const UINT8  DEFAULT_REVNUMBER        = 255;
const UINT8  REVLETTER_A              = 1;
const UINT8  REVLETTER_Z              = 26;
const UINT8  REVLETTER_ZZ             = 0x3A;

// Flash addresses where boot and application addresses are strored.

// Version Information triplet
#define VERSION_NUMBER_OFFSET       0x70
#define REVISION_NUMBER_OFFSET      0x71
#define BUILD_NUMBER_OFFSET         0x72

#define BOOT_VERSION_BLOCK          0x100   // Note: BLOCK should be 128 byte block boundary (0x80)
#define BOOT_VERSION_NUMBER_PTR     ((UINT8 *)(BOOT_VERSION_BLOCK + VERSION_NUMBER_OFFSET))  // 0x170
#define BOOT_REVISION_NUMBER_PTR    ((UINT8 *)(BOOT_VERSION_BLOCK + REVISION_NUMBER_OFFSET)) // 0x171
#define BOOT_BUILD_NUMBER_PTR       ((UINT8 *)(BOOT_VERSION_BLOCK + BUILD_NUMBER_OFFSET))    // 0x172

#if (!HEK) && (!LOWCOST)
#define APP_VERSION_BLOCK           0x8100
#elif (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AOHBOOT)\
           ||  defined(IOMTYPE_AIH) || defined(IOMTYPE_AIHBOOT)))
#define APP_VERSION_BLOCK           0x30100
#else
#define APP_VERSION_BLOCK           0x20100
#endif
#define APP_VERSION_NUMBER_PTR      ((UINT8 *)(APP_VERSION_BLOCK + VERSION_NUMBER_OFFSET))   // 0x20170
#define APP_REVISION_NUMBER_PTR     ((UINT8 *)(APP_VERSION_BLOCK + REVISION_NUMBER_OFFSET))  // 0x20171
#define APP_BUILD_NUMBER_PTR        ((UINT8 *)(APP_VERSION_BLOCK + BUILD_NUMBER_OFFSET))     // 0x20172

#define P_P1    (*(volatile struct st_p1    *)0xFFFEB0) /* P1    Address*/
#define P_P2    (*(volatile struct st_p2    *)0xFFFEB1) /* P2    Address*/
#define P_P3    (*(volatile struct st_p3    *)0xFFFEB2) /* P3    Address*/
#define P_P4    (*(volatile struct st_p4    *)0xFFFF53) /* P4    Address, PORT Only*/
#define P_P5    (*(volatile struct st_p5    *)0xFFFEB4) /* P5    Address*/
#define P_P6    (*(volatile struct st_p6    *)0xFFFEB5) /* P6    Address*/
#define P_PA    (*(volatile struct st_pa    *)0xFFFEB9) /* PA    Address*/
#define P_PB    (*(volatile struct st_pb    *)0xFFFEBA) /* PB    Address*/
#define P_PC    (*(volatile struct st_pb    *)0xFFFEBB) /* PC    Address*/
#define P_PD    (*(volatile struct st_pb    *)0xFFFEBC) /* PD    Address*/
#define P_PE    (*(volatile struct st_pb    *)0xFFFEBD) /* PE    Address*/
#define P_PF    (*(volatile struct st_p2    *)0xFFFEBE) /* PF    Address*/
#define P_PG    (*(volatile struct st_pg    *)0xFFFEBF) /* PG    Address*/
#define P_INTC  (*(volatile struct st_intc  *)0xFFFEC4) /* INTC  Address*/
#define P_BSC   (*(volatile struct st_bsc   *)0xFFFED0) /* BSC   Address*/
#define P_DTC   (*(volatile struct st_dtc   *)0xFFFF30) /* DTC   Address*/
#define P_SBYCR (*(volatile union  un_sbycr *)0xFFFF38) /* SBYCR Address*/
#define P_SYSCR (*(volatile union  un_syscr *)0xFFFF39) /* SYSCR Address*/
#define P_SCKCR (*(volatile union  un_sckcr *)0xFFFF3A) /* SCKCR Address*/
#define P_MDCR  (*(volatile union  un_mdcr  *)0xFFFF3B) /* MDCR  Address*/
#define P_MSTPCR (*(volatile union  un_mstpcr*)0xFFFF3C) /* MSTPCRAddress*/
#define P_SYSCR2 (*(volatile union  un_syscr2*)0xFFFF42) /* SYSCR2Address*/

#define P_SCI0  (*(volatile struct st_sci   *)0xFFFF78) /* SCI0  Address*/
#define P_SCI1  (*(volatile struct st_sci   *)0xFFFF80) /* SCI1  Address*/
#define P_SCI2  (*(volatile struct st_sci   *)0xFFFF88) /* SCI2  Address*/

#if !(LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
    #define P_SCI_IOL  P_SCI0    
#else  // P_SCI2 for IOL
    #define P_SCI_IOL  P_SCI2
#endif

#if H8S_2319C
    // 2319c Flash registers Memory Map location
    #define P_FCCS  (*(volatile union un_fccs   *)0xFFFFC4) /* FCCS Address*/
    #define P_FPCS  (*(volatile union un_fpcs   *)0xFFFFC5) /* FPCS Address*/
    #define P_FECS  (*(volatile union un_fecs   *)0xFFFFC6) /* FECS Address*/
    #define P_RAMER (*(volatile union un_ramer  *)0xFFFEDB) /* RAMER Address*/
    #define P_FKEY  (*(volatile UINT8   *)0xFFFFC8)         /* FKEY Address*/
    #define P_FMATS (*(volatile UINT8   *)0xFFFFC9)         /* FMATS Address*/
    #define P_FTDAR (*(volatile UINT8   *)0xFFFFCA)         /* FTDAR Address*/
#endif

// Module Stop Control Register
#define MSTPCR          P_MSTPCR.WORD        // Word Access to MSTP
#define MSTPCR_DTC      P_MSTPCR.BIT.DTC     // Data Transfer Controller
#define MSTPCR_TPU      P_MSTPCR.BIT.TPU     // 16 Bit Timer Pulse Unit
#define MSTPCR_TMR      P_MSTPCR.BIT.TMR     // 8 Bit Timers
#define MSTPCR_DAC      P_MSTPCR.BIT.DAC     // Digital to Analog Converter
#define MSTPCR_ADC      P_MSTPCR.BIT.ADC     // Analog to Digital Converter
#define MSTPCR_SCI1     P_MSTPCR.BIT.SCI1    // Serial Commn. Interface Channel 1

#if !(LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
#define MSTPCR_I0L      P_MSTPCR.BIT.SCI0    // Serial Commn. Interface Channel 0
#else   // LOWCOST,PI,UIO
#define MSTPCR_SCI0     P_MSTPCR.BIT.SCI0    // Serial Commn. Interface Channel 0
#define MSTPCR_I0L      P_MSTPCR.BIT.SCI2    // Serial Commn. Interface Channel 2
#endif

const unsigned char MODULE_DISABLED = 1;
const unsigned char MODULE_ENABLED = 0;

// System Control Register
#define SYSCR           P_SYSCR.BYTE         // Byte Access to SYSCR
#define SYSCR_INTM      P_SYSCR.BIT.INTM     // Interrupt Control Mode
#define SYSCR_NMIEG     P_SYSCR.BIT.NMIEG    // NMI Edge Select
#define SYSCR_LWROD     P_SYSCR.BIT.LWROD    // 
#define SYSCR_IRQPAS    P_SYSCR.BIT.IRQPAS   // IRQ Input Pin Select
#define SYSCR_RAME      P_SYSCR.BIT.RAME     // RAM Emulation
const unsigned char SYSCR_ICM2 = 2;
const unsigned char SYSCR_ICM0 = 0;

// Interrupt Control Register
#define INTC_IER        P_INTC.IER.BYTE
#define INTC_IPRA       P_INTC.IPRA.BYTE
#define INTC_IPRB       P_INTC.IPRB.BYTE
#define INTC_IPRC       P_INTC.IPRC.BYTE
#define INTC_IPRD       P_INTC.IPRD.BYTE
#define INTC_IPRE       P_INTC.IPRE.BYTE
#define INTC_IPRF       P_INTC.IPRF.BYTE
#define INTC_IPRG       P_INTC.IPRG.BYTE
#define INTC_IPRH       P_INTC.IPRH.BYTE
#define INTC_IPRI       P_INTC.IPRI.BYTE
#define INTC_IPRJ       P_INTC.IPRJ.BYTE
#define INTC_IPRK       P_INTC.IPRK.BYTE
#define INTC_ISCR       P_INTC.ISCR.WORD
#define INTC_ISR        P_INTC.ISR.BYTE

#define IPRG_SCAN       P_INTC.IPRG.BIT.HIGH
#define IPRG_HART       P_INTC.IPRG.BIT.HIGH // HART timer
#define IPRI_BLINK      P_INTC.IPRG.BIT.LOW  // TGI3A - LED Blink

#define IPRI_GHO        P_INTC.IPRA.BIT.HIGH // IRQ0 - Gap Has Occurred
#define IPRI_PDVC       P_INTC.IPRA.BIT.LOW  // IRQ1 - Programmable Device
#define IPRI_OVERCURNT  P_INTC.IPRB.BIT.HIGH // IRQ0 - Over-current Has Occurred

#if (defined (IOMTYPE_UIO) || defined (IOMTYPE_UIOBOOT))
    #define IPRI_HART     P_INTC.IPRB.BIT.HIGH   // IRQ3, HART UART and SPI
    #define IPRI_WDTO     P_INTC.IPRA.BIT.LOW    // IRQ1, Watchdog Timeout Pending
#else
    #define IPRI_HART     IPRI_PDVC            //   HEK: FPGA - HART UARTS
    #define IPRI_WDTO     IPRI_HART            //   LEK: CPLD - WatchDog TimeOut
#endif

#define IPRI_DTC        P_INTC.IPRC.BIT.LOW  // SWDTEND - Data Transfer Controller
#define IPRI_GAPT       P_INTC.IPRH.BIT.HIGH // TGI4B - Gap/Silence Timer
#define IPRI_TICK       P_INTC.IPRH.BIT.LOW  // TGI5A - System Clock Tick
#define IPRI_IOPROC     P_INTC.IPRF.BIT.HIGH // TGI0A - I/O Processing
#define IPRI_DEBUG      P_INTC.IPRK.BIT.HIGH // SCI1 - Debug port
#if !(LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
#define IPRI_IOL        P_INTC.IPRJ.BIT.LOW  // ERI0, RXI0, TXI0, TEI0 - IOL Serial Port
#else  // LOWCOST, PI , UIO 
#define IPRI_IOL        P_INTC.IPRK.BIT.LOW  // ERI2, RX20, TXI2, TEI2 - IOL Serial Port
#endif

#if (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT)) 
    #define IPRI_PRVPATH    P_INTC.IPRJ.BIT.LOW    // SCI0 - Privath Path between Red IOM
    #if (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT))
        #define IPRI_FPGA       P_INTC.IPRB.BIT.HIGH // IRQ 3 --Integration Period and Power supply errors.
    #endif
#endif

const unsigned char LVLPRI_HIGHEST      = 7;
const unsigned char LVLPRI_GHO          = LVLPRI_HIGHEST;
const unsigned char LVLPRI_IOL          = LVLPRI_HIGHEST;
const unsigned char LVLPRI_IOLN         = 6 ;

#ifdef IOMTYPE_DISOE
  const unsigned char LVLPRI_SOE      = 7;
  const unsigned char LVLPRI_TICK     = 4;
#elif (defined(IOMTYPE_UIO)  || defined(IOMTYPE_UIOBOOT))
  // Make STC interrupt lower priority than WDTO/PDVC. WDTO/PDVC is only raised 
  // when the hardware WDT is about to take down the UIO or the WDT diagnostic is running.
  // It must be processed immediately.
  const unsigned char LVLPRI_TICK     = 4;
#else
  const unsigned char LVLPRI_TICK     = 5;
#endif

//Set priority level of BlinkLedInterruptHandler to be same as of 
//STC interrupt handler.The STC interrupt handler can no longer 
//interrupt BlinkLedInterruptHandler.
const unsigned char LVLPRI_LED          = LVLPRI_TICK;

const unsigned char LVLPRI_IOPROC       = 4;

#if (HEK) || (LOWCOST) || defined(IOMTYPE_DO) || defined(IOPTYPE_DI)
    #ifdef IOMTYPE_AOH
        const unsigned char LVLPRI_EEPRDWR  = LVLPRI_TICK;
    #else
        // Customer(-MiRO) Issue(-CL Fail & EHPM Crash due to HLAI IOL Comm Error) fix
        //const unsigned char LVLPRI_EEPRDWR  = LVLPRI_IOPROC;
        const unsigned char LVLPRI_EEPRDWR  = LVLPRI_TICK;
    #endif
#endif

#if (defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
  // Make WDTO/PDVC higher priority than STC interrupt. WDTO/PDVC interrupt is only raised 
  // when the hardware WDT is about to take down the UIO or the WDT diagnostic is running.
  // It must be processed as soon as possible.
    const unsigned char LVLPRI_PDVC         = 5;
#elif !LOWCOST
    const unsigned char LVLPRI_PDVC         = 3;
#else // LOWCOST
    // Set Priority level of IRQ1Interrupt same as STCInterrupt for Low Cost AI.
    // STCInterrupt handler will no longer interrupt by IRQ1Interrupt. 
    #if defined(IOMTYPE_AIH)
        const unsigned char LVLPRI_PDVC         = LVLPRI_TICK;
    #else
        const unsigned char LVLPRI_PDVC         = 3;
    #endif
#endif

#if (defined (IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))
    // For UIO, WDTOP and HART/SPI interrupts come in on different
    // interrupts.  HART/SPI interrupts need to have a lower priority
    // to prevent WDTOP interrupts from being masked.
    //
    // NOTE: Increased priority of WDTO from 3 to 4.  Level 4 is not
    //       used within UIO so this should be OK.  We could have
    //       decreased the priority of the HART/SPI interrupts to
    //       level 2, but then it would be sharing the same priority
    //       as the silence timer.
    const unsigned char LVLPRI_HART         = 3;
    const unsigned char LVLPRI_WDTO         = LVLPRI_PDVC;
#else
    const unsigned char LVLPRI_HART         = 3;
    const unsigned char LVLPRI_WDTO         = LVLPRI_HART;
#endif

const unsigned char LVLPRI_GAPT         = 2;
const unsigned char LVLPRI_DBUG         = 1;
const unsigned char LVLPRI_TASK         = 0;

// LED blink period in msec during softfail conditions.
const UINT16 STATUSLED_BLINK_PERIOD = 500; 

// Serial Control Interface Channel 1
#define SCIC1_SMR       P_SCI1.SMR.BYTE      // Serial Mode Register 1
#define SCIC1_CA        P_SCI1.SMR.BIT.CA    //  Communication Mode
#define SCIC1_CHR       P_SCI1.SMR.BIT.CHR   //  Character Length
#define SCIC1_PE        P_SCI1.SMR.BIT.PE    //  Parity Enable
#define SCIC1_OE        P_SCI1.SMR.BIT.OE    //  Parity Mode
#define SCIC1_STOP      P_SCI1.SMR.BIT.STOP  //  Number of Stop Bits
#define SCIC1_MP        P_SCI1.SMR.BIT.MP    //  Multiprocessor Mode
#define SCIC1_CKS       P_SCI1.SMR.BIT.CKS   //  Clock Select 1 and 0
#define SCIC1_BRR       P_SCI1.BRR           // Bit Rate Register 1
#define SCIC1_SCR       P_SCI1.SCR.BYTE      // Serial Control Register 1
#define SCIC1_TIE       P_SCI1.SCR.BIT.TIE   //  Transmit Interrupt Enable
#define SCIC1_RIE       P_SCI1.SCR.BIT.RIE   //  Receive Interrupt Enable
#define SCIC1_TE        P_SCI1.SCR.BIT.TE    //  Transmitter Enable
#define SCIC1_RE        P_SCI1.SCR.BIT.RE    //  Receiver Enable
#define SCIC1_MPIE      P_SCI1.SCR.BIT.MPIE  //  Multiprocessor Interrupt Enable
#define SCIC1_TEIE      P_SCI1.SCR.BIT.TEIE  //  Transmit End Interrupt Enable
#define SCIC1_CKE       P_SCI1.SCR.BIT.CKE   //  Clock Enable
#define SCIC1_TDR       P_SCI1.TDR           //  Transmit Data Register
#define SCIC1_SSR       P_SCI1.SSR.BYTE      // Serial Status Register 1
#define SCIC1_TDRE      P_SCI1.SSR.BIT.TDRE  //  Transmit Data Register Empty
#define SCIC1_RDRF      P_SCI1.SSR.BIT.RDRF  //  Receive Data Register Empty
#define SCIC1_ORER      P_SCI1.SSR.BIT.ORER  //  Overrun Error
#define SCIC1_FER       P_SCI1.SSR.BIT.FER   //  Framing Error
#define SCIC1_PER       P_SCI1.SSR.BIT.PER   //  Parity Error
#define SCIC1_TEND      P_SCI1.SSR.BIT.TEND  //  Transmit End
#define SCIC1_MPB       P_SCI1.SSR.BIT.MPB   //  Multiprocessor Bit
#define SCIC1_MPBT      P_SCI1.SSR.BIT.MPBT  //  Multiprocessor Bit Transfer
#define SCIC1_RDR       P_SCI1.RDR           // Receive Data Register 1
#define SCIC1_SCMR      P_SCI1.SCMR.BYTE     // Smart Card Mode Register 1
#define SCIC1_SDIR      P_SCI1.SCMR.BIT.SDIR //  SC Data Transfer Direction
#define SCIC1_SINV      P_SCI1.SCMR.BIT.SINV //  SC Data Invert
#define SCIC1_SMIF      P_SCI1.SCMR.BIT.SMIF //  SC Interface Mode Select

// Timer Pulse Unit
#define TPUC            (*(volatile struct st_tpu *)0xFFFFC0)
#define TPU_TSTR        TPUC.TSTR.BYTE      //  Timer Start Register
#define TPU0_CST        TPUC.TSTR.BIT.CST0  //  Counter 0 Enable
#define TPU1_CST        TPUC.TSTR.BIT.CST1  //  Counter 1 Enable
#define TPU2_CST        TPUC.TSTR.BIT.CST2  //  Counter 2 Enable
#define TPU3_CST        TPUC.TSTR.BIT.CST3  //  Counter 3 Enable
#define TPU4_CST        TPUC.TSTR.BIT.CST4  //  Counter 4 Enable
#define TPU5_CST        TPUC.TSTR.BIT.CST5  //  Counter 5 Enable
#define TPU_TSYR        TPUC.TSYR.BYTE      //  Timer Synchro Register
#define TPU0_SYNC       TPUC.TSYR.BIT.SYNC0 //  Counter 0 Enable
#define TPU1_SYNC       TPUC.TSYR.BIT.SYNC1 //  Counter 1 Enable
#define TPU2_SYNC       TPUC.TSYR.BIT.SYNC2 //  Counter 2 Enable
#define TPU3_SYNC       TPUC.TSYR.BIT.SYNC3 //  Counter 3 Enable
#define TPU4_SYNC       TPUC.TSYR.BIT.SYNC4 //  Counter 4 Enable
#define TPU5_SYNC       TPUC.TSYR.BIT.SYNC5 //  Counter 5 Enable

// Timer Pulse Unit 0
#define TPU0            (*(volatile struct st_tpu0 *)0xFFFFD0)
#define TPU0_TCNT       TPU0.TCNT           //  Timer Counter Register
#define TPU0_TGRA       TPU0.TGRA           //  Timer General Register A
#define TPU0_TGRB       TPU0.TGRB           //  Timer General Register B
#define TPU0_TGRC       TPU0.TGRC           //  Timer General Register C
#define TPU0_TGRD       TPU0.TGRD           //  Timer General Register D
#define TPU0_TSR        TPU0.TSR.BYTE       //  Timer General Register B
#define TPU0_TCFV       TPU0.TSR.BIT.TCFV   //  Overflow Flag
#define TPU0_TGFA       TPU0.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU0_TGFB       TPU0.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU0_TGFC       TPU0.TSR.BIT.TGFC   //  Input Capture/Output Compare Flag C
#define TPU0_TGFD       TPU0.TSR.BIT.TGFD   //  Input Capture/Output Compare Flag D
#define TPU0_TIER       TPU0.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU0_TTGE       TPU0.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU0_TCIEV      TPU0.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU0_TGIEA      TPU0.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU0_TGIEB      TPU0.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU0_TGIEC      TPU0.TIER.BIT.TGIEC //  TGR Interrupt Enable C
#define TPU0_TGIED      TPU0.TIER.BIT.TGIED //  TGR Interrupt Enable D
#define TPU0_TIOR       TPU0.TIOR.WORD      //  Timer I/O Control Register
#define TPU0_IORH       TPU0.TIOR.BYTE.H    //  Timer I/O Control High Byte
#define TPU0_IORL       TPU0.TIOR.BYTE.L    //  Timer I/O Control Low Byte
#define TPU0_IOA        TPU0.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU0_IOB        TPU0.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU0_IOC        TPU0.TIOR.BIT.IOC   //  I/O Control for TGRC
#define TPU0_IOD        TPU0.TIOR.BIT.IOD   //  I/O Control for TGRD
#define TPU0_TMDR       TPU0.TMDR.BYTE      //  Timer Mode Register
#define TPU0_MD         TPU0.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU0_BFA        TPU0.TMDR.BIT.BFA   //  MBuffer Operation A
#define TPU0_BFB        TPU0.TMDR.BIT.BFB   //  Buffer Operation A
#define TPU0_TCR        TPU0.TCR.BYTE       //  Timer Control Register
#define TPU0_CCLR       TPU0.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU0_CKEG       TPU0.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU0_TPSC       TPU0.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 1
#define TPU1            (*(volatile struct st_tpu1 *)0xFFFFE0)
#define TPU1_TCNT       TPU1.TCNT           //  Timer Counter Register
#define TPU1_TGRA       TPU1.TGRA           //  Timer General Register A
#define TPU1_TGRB       TPU1.TGRB           //  Timer General Register B
#define TPU1_TSR        TPU1.TSR.BYTE       //  Timer General Register B
#define TPU1_TCFD       TPU1.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU1_TGFA       TPU1.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU1_TGFB       TPU1.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU1_TCFU       TPU1.TSR.BIT.TCFU   //  Underflow Flag
#define TPU1_TCFV       TPU1.TSR.BIT.TCFV   //  Overflow Flag
#define TPU1_TIER       TPU1.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU1_TTGE       TPU1.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU1_TCIEU      TPU1.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU1_TCIEV      TPU1.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU1_TGIEA      TPU1.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU1_TGIEB      TPU1.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU1_TIOR       TPU1.TIOR.BYTE      //  Timer I/O Control Register
#define TPU1_IOA        TPU1.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU1_IOB        TPU1.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU1_TMDR       TPU1.TMDR.BYTE      //  Timer Mode Register
#define TPU1_MD         TPU1.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU1_TCR        TPU1.TCR.BYTE       //  Timer Control Register
#define TPU1_CCLR       TPU1.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU1_CKEG       TPU1.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU1_TPSC       TPU1.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 2
#define TPU2            (*(volatile struct st_tpu1 *)0xFFFFF0)
#define TPU2_TCNT       TPU2.TCNT           //  Timer Counter Register
#define TPU2_TGRA       TPU2.TGRA           //  Timer General Register A
#define TPU2_TGRB       TPU2.TGRB           //  Timer General Register B
#define TPU2_TSR        TPU2.TSR.BYTE       //  Timer General Register B
#define TPU2_TCFD       TPU2.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU2_TGFA       TPU2.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU2_TGFB       TPU2.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU2_TCFU       TPU2.TSR.BIT.TCFU   //  Underflow Flag
#define TPU2_TCFV       TPU2.TSR.BIT.TCFV   //  Overflow Flag
#define TPU2_TIER       TPU2.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU2_TTGE       TPU2.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU2_TCIEU      TPU2.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU2_TCIEV      TPU2.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU2_TGIEA      TPU2.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU2_TGIEB      TPU2.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU2_TIOR       TPU2.TIOR.BYTE      //  Timer I/O Control Register
#define TPU2_IOA        TPU2.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU2_IOB        TPU2.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU2_TMDR       TPU2.TMDR.BYTE      //  Timer Mode Register
#define TPU2_MD         TPU2.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU2_TCR        TPU2.TCR.BYTE       //  Timer Control Register
#define TPU2_CCLR       TPU2.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU2_CKEG       TPU2.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU2_TPSC       TPU2.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 3
#define TPU3            (*(volatile struct st_tpu0 *)0xFFFE80)
#define TPU3_TCNT       TPU3.TCNT           //  Timer Counter Register
#define TPU3_TGRA       TPU3.TGRA           //  Timer General Register A
#define TPU3_TGRB       TPU3.TGRB           //  Timer General Register B
#define TPU3_TGRC       TPU3.TGRC           //  Timer General Register C
#define TPU3_TGRD       TPU3.TGRD           //  Timer General Register D
#define TPU3_TSR        TPU3.TSR.BYTE       //  Timer General Register B
#define TPU3_TCFV       TPU3.TSR.BIT.TCFV   //  Overflow Flag
#define TPU3_TGFA       TPU3.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU3_TGFB       TPU3.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU3_TGFC       TPU3.TSR.BIT.TGFC   //  Input Capture/Output Compare Flag C
#define TPU3_TGFD       TPU3.TSR.BIT.TGFD   //  Input Capture/Output Compare Flag D
#define TPU3_TIER       TPU3.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU3_TTGE       TPU3.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU3_TCIEV      TPU3.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU3_TGIEA      TPU3.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU3_TGIEB      TPU3.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU3_TGIEC      TPU3.TIER.BIT.TGIEC //  TGR Interrupt Enable C
#define TPU3_TGIED      TPU3.TIER.BIT.TGIED //  TGR Interrupt Enable D
#define TPU3_TIOR       TPU3.TIOR.WORD      //  Timer I/O Control Register
#define TPU3_IORH       TPU3.TIOR.BYTE.H    //  Timer I/O Control High Byte
#define TPU3_IORL       TPU3.TIOR.BYTE.L    //  Timer I/O Control Low Byte
#define TPU3_IOA        TPU3.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU3_IOB        TPU3.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU3_IOC        TPU3.TIOR.BIT.IOC   //  I/O Control for TGRC
#define TPU3_IOD        TPU3.TIOR.BIT.IOD   //  I/O Control for TGRD
#define TPU3_TMDR       TPU3.TMDR.BYTE      //  Timer Mode Register
#define TPU3_MD         TPU3.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU3_BFA        TPU3.TMDR.BIT.BFA   //  MBuffer Operation A
#define TPU3_BFB        TPU3.TMDR.BIT.BFB   //  Buffer Operation A
#define TPU3_TCR        TPU3.TCR.BYTE       //  Timer Control Register
#define TPU3_CCLR       TPU3.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU3_CKEG       TPU3.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU3_TPSC       TPU3.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 4
#define TPU4            (*(volatile struct st_tpu1 *)0xFFFE90)
#define TPU4_TCNT       TPU4.TCNT           //  Timer Counter Register
#define TPU4_TGRA       TPU4.TGRA           //  Timer General Register A
#define TPU4_TGRB       TPU4.TGRB           //  Timer General Register B
#define TPU4_TSR        TPU4.TSR.BYTE       //  Timer General Register B
#define TPU4_TCFD       TPU4.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU4_TGFA       TPU4.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU4_TGFB       TPU4.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU4_TCFU       TPU4.TSR.BIT.TCFU   //  Underflow Flag
#define TPU4_TCFV       TPU4.TSR.BIT.TCFV   //  Overflow Flag
#define TPU4_TIER       TPU4.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU4_TTGE       TPU4.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU4_TCIEU      TPU4.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU4_TCIEV      TPU4.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU4_TGIEA      TPU4.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU4_TGIEB      TPU4.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU4_TIOR       TPU4.TIOR.BYTE      //  Timer I/O Control Register
#define TPU4_IOA        TPU4.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU4_IOB        TPU4.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU4_TMDR       TPU4.TMDR.BYTE      //  Timer Mode Register
#define TPU4_MD         TPU4.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU4_TCR        TPU4.TCR.BYTE       //  Timer Control Register
#define TPU4_CCLR       TPU4.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU4_CKEG       TPU4.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU4_TPSC       TPU4.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 5
#define TPU5            (*(volatile struct st_tpu1 *)0xFFFEA0)
#define TPU5_TCNT       TPU5.TCNT           //  Timer Counter Register
#define TPU5_TGRA       TPU5.TGRA           //  Timer General Register A
#define TPU5_TGRB       TPU5.TGRB           //  Timer General Register B
#define TPU5_TSR        TPU5.TSR.BYTE       //  Timer General Register B
#define TPU5_TCFD       TPU5.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU5_TGFA       TPU5.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU5_TGFB       TPU5.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU5_TCFU       TPU5.TSR.BIT.TCFU   //  Underflow Flag
#define TPU5_TCFV       TPU5.TSR.BIT.TCFV   //  Overflow Flag
#define TPU5_TIER       TPU5.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU5_TTGE       TPU5.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU5_TCIEU      TPU5.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU5_TCIEV      TPU5.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU5_TGIEA      TPU5.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU5_TGIEB      TPU5.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU5_TIOR       TPU5.TIOR.BYTE      //  Timer I/O Control Register
#define TPU5_IOA        TPU5.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU5_IOB        TPU5.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU5_TMDR       TPU5.TMDR.BYTE      //  Timer Mode Register
#define TPU5_MD         TPU5.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU5_TCR        TPU5.TCR.BYTE       //  Timer Control Register
#define TPU5_CCLR       TPU5.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU5_CKEG       TPU5.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU5_TPSC       TPU5.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// 8-Bit Timers
#define TMR_            (*(volatile struct st_tmr *)0xFFFFB0)    // Note: symbol "TMR" is used, so it is "TMR_"
#define TMR_TCNT        TMR_.TCNT            //  Timer Counter. Read as 16 bit data

#define TMR0_TCR        TMR_.TCR0            //  Timer Control Register
#define TMR0_TCSR       TMR_.TCSR0           //  Timer Control/Status Register
#define TMR0_TCORA      TMR_.TCORA0          //  Timer Constant Register A
#define TMR0_TCORB      TMR_.TCORB0          //  Timer Constant Register B

#define TMR1_TCR        TMR_.TCR1            //  Timer Control Register
#define TMR1_TCSR       TMR_.TCSR1           //  Timer Control/Status Register
#define TMR1_TCORA      TMR_.TCORA1          //  Timer Constant Register A
#define TMR1_TCORB      TMR_.TCORB1          //  Timer Constant Register B

#define TMR_OVERFLOW    0x04                 //  for TCR0. count at TCNT1 overflow signal
#define TMR_PHI_8       0x01                 //  for TCR1. count at falling edge of PHI/8

// *************************************
//
//     PORT 1 ~ PORT F
//
// *************************************

#if LOWCOST

// PORT 1
#if (defined(IOMTYPE_AOH)||defined(IOMTYPE_AOHBOOT)) 
    #define INH_SWA       P_P1.DR.BIT.B7     // AO    out
    #define INH_SWB       P_P1.DR.BIT.B6     // AO    out
    #define DAC_LATCH     P_P1.DR.BIT.B5     // AO    out
    #define SDO           P_P1.DR.BIT.B4     // AO    out
    #define RD_n          P_P1.DR.BIT.B3     // AO    out
#else
    // ADC_SPITO--This port pin indicates ADC SPI Timeout happened or not. 
    #define ADC_SPITO     P_P1.PORT.BIT.B5   // AI    IN  
    #define ADC_DIN       P_P1.DR.BIT.B4     // AI    out
    #define ADC_START     P_P1.DR.BIT.B3     // AI    out
#endif

// PORT 2
#define EEP_SCLK        P_P2.DR.BIT.B7    // AI.AO out
#define EEP_DIN         P_P2.DR.BIT.B6    // AI.AO out
#define BUPREQ_n        P_P2.DR.BIT.B5    // AI.AO out
#define CLRGHL_n        P_P2.DR.BIT.B4    // AI.AO out
#define EEPROM_WP_n     P_P2.DR.BIT.B3    // AI.AO out    EEP_WP_n
#define SWBUREQ_n       P_P2.DR.BIT.B2    // AI.AO out
#define EEP_CS          P_P2.DR.BIT.B1    // AI.AO out
#define RCVSELA_n       P_P2.DR.BIT.B0    // AI.AO out

// PORT 3
#if (defined(IOMTYPE_AOH)|| defined(IOMTYPE_AOHBOOT)) 
    #define DAC_SCLK    P_P3.DR.BIT.B5    // AO    out    
#else
    #define ADC_SCLK    P_P3.DR.BIT.B5    // AI    out
#endif
#define DBG_RXD         P_P3.DR.BIT.B3    // AI.AO in
#define DBG_TXD         P_P3.DR.BIT.B1    // AI.AO out

// PORT 4
#define GIIS_IOTA       P_P4.PORT.BIT.B7    // AI.AO in
#define CALIBRATE      !P_P4.PORT.BIT.B6    // AI.AO in     0 when touched
#define FACTCAL         P_P4.PORT.BIT.B5    // AI.AO in
#define REDUNT_n        P_P4.PORT.BIT.B4    // AI,AO in
#define BOTTOM          P_P4.PORT.BIT.B3    // AI.AO in     1 is Bottom (IOTA changes required (AT1))
#define EEP_DOUT        P_P4.PORT.BIT.B2    // AI.AO in
#ifdef IOMTYPE_AOH
    #define ANALOG_RDBK   P_P4.PORT.BIT.B1    // AO    in
#endif

// PORT 5
#if (defined(IOMTYPE_AOH)|| defined(IOMTYPE_AOHBOOT)) 
  #define DIS_SWB_n     P_P5.DR.BIT.B3    // AO out // DIS_SWB_CPLD
  #define DIS_SWA_n     P_P5.DR.BIT.B2    // AO out // DIS_SWA_CPLD
#endif
#define IOL_RXD         P_P5.DR.BIT.B1    // AI.AO uart
#define IOL_TXD         P_P5.DR.BIT.B0    // AI.AO uart

// PORT 6
#define GHOXXX          P_P6.PORT.BIT.B6  // AI.AO in
#define GHOIRQ_n        P_P6.PORT.BIT.B4  // GHO interrupt
#define JTAG_TDO        P_P6.DR.BIT.B3    // AI.AO JTAG   H8_TDO
#define JTAG_TDI        P_P6.DR.BIT.B2    // AI.AO JTAG   H8_TDI
#define JTAG_TCK        P_P6.DR.BIT.B1    // AI.AO JTAG   H8_TCK
#define JTAG_TMS        P_P6.DR.BIT.B0    // AI.AO JTAG   H8_TMS

// PORT A
#define BUPREQ_IN       P_PA.PORT.BIT.B7    // AI.AO in     BUPREQIN
#define DIAGFAIL_n      P_PA.DR.BIT.B5      // AI.AO out
#if (defined(IOMTYPE_AOH)|| defined(IOMTYPE_AOHBOOT)) 
    #define DAC_CLEAR     P_PA.DR.BIT.B2      // AO    out
    #define SDI           P_PA.PORT.BIT.B1    // AO    in
    #define INHIN_FB_n    P_PA.PORT.BIT.B0    // AO    in
#else
    #define ADC_CS_OUT    P_PA.DR.BIT.B2
    #define ADC_DOUT      P_PA.PORT.BIT.B1    // AI    in
    #define ADC_DRDY      P_PA.PORT.BIT.B0    // AI    in
#endif

// PORT B (CPLD Data)
#if defined(IOMTYPE_AOH)||defined(IOMTYPE_AOHBOOT)
    #define OP_DISA_FB_n  0x80   // AO    in     SWA_FDBK
    #define OP_DISB_FB1_n 0x40   // AO    in     SWB_FDBK
    #define INHST1_FB1    0x20   // AO    in 
    #define INHST1_FB2    0x10   // AO    in 
    #define INHST2_FB     0x08   // AO    in 
    #define TST           0x04   // AO    in 

    #define Tst_n         SelCPLD(1);P_PB.DR.BIT.B2 
#endif

#define SWITCH_STATUS_REGISTER ByteCPLD(1)  // AO 

#define CPLD_REVLETTER  ByteCPLD(2)         // AI.AO in     higher byte
#define CPLD_REVNUMBER  ByteCPLD(3)         // AI.AO in     lower byte


#define DIP_n           BitCPLD(5, 0x40)    // AI.AO in     DIP_Stick
#define JABLOCK_n       BitCPLD(5, 0x08)    // AI.AO in


// PORT C
#if (defined(IOMTYPE_AOH)||defined(IOMTYPE_AOHBOOT))
    #define OUTSEL      P_PC.DR.C.B4B0 
#endif
 
#if (defined(IOMTYPE_AOHBOOT)||defined(IOMTYPE_AOH)) 
    #define CPLD_ADDR   P_PC.DR.C.B7B5     
#else
    #define CPLD_ADDR   P_PC.DR.C.B7B4      
#endif
 
// PORT D
#define MODNUM          P_PD.PORT.BYTE      // AI.AO in

// PORT E
#if defined(IOMTYPE_AOH)||defined(IOMTYPE_AOHBOOT)
#define TST_n           P_PE.DR.E.B7     // AO    out
#define WR_n            P_PE.DR.E.B6     // AO    out
#define INPSEL          P_PE.DR.E.B5B0
#endif

// PORT F
#define REBOOT_n        P_PF.DR.BIT.B6    // AI.AO out
#define WDT_EN_n        P_PF.DR.BIT.B5    // AI.AO out
#define CLR_RIP_n       P_PF.DR.BIT.B4    // AI.AO out
#define TXREQ_n         P_PF.DR.BIT.B3    // AI.AO out
#define JABRES_n        P_PF.DR.BIT.B2    // AI.AO out
#define WDTODCLR_n      P_PF.DR.BIT.B1    // AI.AO out
#define WDTRFS_n        P_PF.DR.BIT.B0    // AI.AO out

// PORT G
#define BUPREQ_FB       P_PG.DR.BIT.B4    // AI.AO in 
#define RIP_n           BitCPLD(5, 0x80)  // AI.AO in
#define SET_DIP         P_PG.DR.BIT.B2    // AI.AO out
#define LED_PINS        P_PG.DR.BIT.B10   // AI.AO out

// Constants
#define GOODINPUT       1          // AI, OWD
#define OVERVT_n        1          // AI, Over Voltage is OFF

#elif (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT)) // Pulse Input Module

// PORT 1
#define RCVSELA_n       P_P1.DR.BIT.B7
#define TXREQ_n         P_P1.DR.BIT.B6
#define JABRES_n        P_P1.DR.BIT.B5
#define WDTODCLR_n      P_P1.DR.BIT.B4
#define WDTRFS_n        P_P1.DR.BIT.B3
#define FPGA_ERASE_n    P_P1.DR.BIT.B2  // PROGRAM_n
#define JTAG_TCK        P_P1.DR.BIT.B1  // BD_TCK
#define JTAG_TDO        P_P1.DR.BIT.B0  // BD_TDI

// PORT 2.
#define CLRGHL_n        P_P2.DR.BIT.B7
#define DIAGFAIL_n      P_P2.DR.BIT.B6
#define SWBUREQ_n       P_P2.DR.BIT.B5
#define REBOOT_n        P_P2.DR.BIT.B4
#define WDT_EN_n        P_P2.DR.BIT.B3
#define JTAG_TMS        P_P2.DR.BIT.B1  // BD_TMS

// PORT 3.
#define H8_TRST         P_P3.PORT.BIT.B4
#define PP_RXD          P_P3.DR.BIT.B3
#define DBG_RXD         P_P3.DR.BIT.B2
#define PP_TXD          P_P3.DR.BIT.B1
#define DBG_TXD         P_P3.DR.BIT.B0

// PORT 4.
#define OSC_FFAULT      P_P4.PORT.BIT.B7
#define BAD_DECODE      P_P4.PORT.BIT.B6
#define JABLOCK_n       P_P4.PORT.BIT.B5
#define JTAG_TDI        P_P4.PORT.BIT.B2 // BD_TDO
#define FPGA_DONE       P_P4.PORT.BIT.B1  
#define FPGA_INIT_n     P_P4.PORT.BIT.B0

// PORT 5.
#define RIP_Extn        P_P5.DR.BIT.B3
#define FPGA_RST        P_P5.DR.BIT.B2
#define IOL_RXD         P_P5.DR.BIT.B1    
#define IOL_TXD         P_P5.DR.BIT.B0

// PORT 6.
#define FPGA_IRQ        P_P6.PORT.BIT.B7
#define GHOXXX          P_P6.PORT.BIT.B6
#define GHOIRQ_n        P_P6.PORT.BIT.B4  // GHO interrupt
#define H8_TDO          P_P6.DR.BIT.B3    
#define H8_TDI          P_P6.PORT.BIT.B2    
#define H8_TCK          P_P6.PORT.BIT.B1    
#define H8_TMS          P_P6.PORT.BIT.B0

// General Purpose I/O - PORT A,B,C,D,E
// No definitions. Externel Address and Data bus access ports   

// PORT F.
#define WAIT_n          P_PG.PORT.BIT.B2  
#define LED_PINS        P_PF.DR.F.B1_0

#define FPGA_INIT_DELAY 1000 // FPGA Initialization Delay. 1 msec
#define FPGA_RESET      1
#define FPGA_RUN        0

#elif (defined(IOMTYPE_UIOBOOT) || defined(IOMTYPE_UIO)) //Universal IO

// Explanation of below port pins definitions will be avaialble in Series C UIO FDS stored in the following location.
// (\HIP\Projects\Series C RUPIO\Hardware\Series C UIO FDS.doc) 
// Refer section 4.1.1.5 (Bit I/O)

// PORT 1
#define RCVSELA_n       P_P1.DR.BIT.B7
#define TXREQ_n         P_P1.DR.BIT.B6
#define JABRES_n        P_P1.DR.BIT.B5
#define WDTODCLR_n      P_P1.DR.BIT.B4
#define WDTRFS_n        P_P1.DR.BIT.B3
#define FPGA_ERASE_n    P_P1.DR.BIT.B2  // PROGRAM_n
#define JTAG_TCK        P_P1.DR.BIT.B1  //BD_TCK
#define JTAG_TDO        P_P1.DR.BIT.B0  //BD_TDI

// PORT 2.
#define CLRGHL_n        P_P2.DR.BIT.B7
#define DIAGFAIL_n      P_P2.DR.BIT.B6
#define SWBUREQ_n       P_P2.DR.BIT.B5
#define REBOOT_n        P_P2.DR.BIT.B4
#define WDT_EN_n        P_P2.DR.BIT.B3
#define JTAG_TMS        P_P2.DR.BIT.B1  //BD_TMS

// PORT 3.
#define H8_TRST         P_P3.PORT.BIT.B4
#define DBG_RXD         P_P3.DR.BIT.B3
#define PP_RXD          P_P3.DR.BIT.B2
#define DBG_TXD         P_P3.DR.BIT.B1
#define PP_TXD          P_P3.DR.BIT.B0
#define TOGFAILED_OUT   (P_P3.DR.BIT.B0)
#define TOGFAILED_IN    (P_P3.PORT.BIT.B2)

// PORT 4.
#define JABLOCK_n       P_P4.PORT.BIT.B5
#define JTAG_TDI        P_P4.PORT.BIT.B2 // BD_TDO
#define FPGA_DONE       P_P4.PORT.BIT.B1  
#define FPGA_INIT_n     P_P4.PORT.BIT.B0

// PORT 5.
#define SEC_DRV_FB2     P_P5.PORT.BIT.B3
#define SEC_DRV_FB1     P_P5.PORT.BIT.B2
#define IOL_RXD         P_P5.DR.BIT.B1    
#define IOL_TXD         P_P5.DR.BIT.B0

// PORT 6.
#define FPGA_IRQ        P_P6.PORT.BIT.B7
#define GHOXXX          P_P6.PORT.BIT.B6
#define WDTOPIRQ        P_P6.PORT.BIT.B5
#define GHOIRQ_n        P_P6.PORT.BIT.B4  // GHO interrupt
#define H8_TDO          P_P6.DR.BIT.B3    
#define H8_TDI          P_P6.PORT.BIT.B2    
#define H8_TCK          P_P6.PORT.BIT.B1    
#define H8_TMS          P_P6.PORT.BIT.B0

// General Purpose I/O - PORT A,B,C,D,E
// No definitions. Externel Address and Data bus access ports  
#define FPGARST_n       P_PA.DR.BIT.B4

// PORT F.
#define WAIT_n          P_PG.PORT.BIT.B2  
#define FPGA_INIT_DELAY 1000 // FPGA Initialization Delay. 1 msec   

#else   // Other than LOWCOST

// General Purpose I/O - PORT 1.
#define RCVSELA_n       P_P1.DR.BIT.B7
#define TXREQ_n         P_P1.DR.BIT.B6
#define JABRES_n        P_P1.DR.BIT.B5
#define WDTODCLR_n      P_P1.DR.BIT.B4
#define WDTRFS_n        P_P1.DR.BIT.B3
#if (HEK)
    #define FPGA_ERASE_n P_P1.DR.BIT.B2
    #define JTAG_TCK    P_P1.DR.BIT.B1
    #define JTAG_TDO    P_P1.DR.BIT.B0
#else
    #define RDBK_SEL    P_P1.DR.BIT.B2B0
#endif

// General Purpose I/O - PORT 2.
#define CLRGHL_n        P_P2.DR.BIT.B7
#define DIAGFAIL_n      P_P2.DR.BIT.B6
#define SWBUREQ_n       P_P2.DR.BIT.B5
#define REBOOT_n        P_P2.DR.BIT.B4
#define WDT_EN_n        P_P2.DR.BIT.B3
#if (!HEK)
    #define CLR_RIP_n   P_P2.DR.BIT.B2
#endif

// General Purpose I/O - PORT 3.
#if (!HEK)
    #define SET_DIP     P_P3.DR.BIT.B4
#endif
#define DBG_RXD         P_P3.DR.BIT.B3
#define IOL_RXD         P_P3.DR.BIT.B2
#define DBG_TXD         P_P3.DR.BIT.B1
#define IOL_TXD         P_P3.DR.BIT.B0

// General Purpose I/O - PORT 4.
#if (HEK)
    #define JTAG_TDI    P_P4.PORT.BIT.B2
    #define FPGA_DONE   P_P4.PORT.BIT.B1
    #define FPGA_INIT_n P_P4.PORT.BIT.B0
#else
    // Readback register definitions
    // (valid only for Low End Kernel)
    #define RDBK_BYTE   P_P4.PORT.BYTE
    #define RDBK_D7     P_P4.PORT.BIT.B7
    #define RDBK_D6     P_P4.PORT.BIT.B6
    #define RDBK_D5     P_P4.PORT.BIT.B5
    #define RDBK_D4     P_P4.PORT.BIT.B4
    #define RDBK_D3     P_P4.PORT.BIT.B3
    #define RDBK_D2     P_P4.PORT.BIT.B2
    #define RDBK_D1     P_P4.PORT.BIT.B1
    #define RDBK_D0     P_P4.PORT.BIT.B0

    const unsigned char RSR1 = 0;
    const unsigned char RSR2 = 1;
    const unsigned char RSR3 = 2;
    const unsigned char RSR4 = 3;
    const unsigned char RSR5 = 4;
    const unsigned char RSR6 = 5;
    const unsigned char RSR7 = 6;
    const unsigned char RSR8 = 7;
    const unsigned char RSR9 = 8;
    const unsigned char RSR10 = 9;
    const unsigned char RSR11 = 10;
    const unsigned char RSR12 = 11;
    const unsigned char RSR13 = 12;
    const unsigned char RSR14 = 13;
    const unsigned char RSR15 = 14;
    const unsigned char RSR16 = 15;

    const unsigned char RDBK_MODNUM = 0;
    const unsigned char RDBK_IOTA  = 1;
    const unsigned char RDBK_BANK2 = 2;
    const unsigned char RDBK_BANK3 = 3;
    const unsigned char RDBK_BANK4 = 4;
    const unsigned char RDBK_BANK5 = 5;
    const unsigned char RDBK_CPLD1 = 6;
    const unsigned char RDBK_BANK7 = 7;
    const unsigned char RDBK_ITYPE = 0;
    const unsigned char RDBK_INHSW = 1;
    const unsigned char RDBK_HSOC  = 2;
    const unsigned char RDBK_RSR12 = 3;
    const unsigned char RDBK_PD2REVLO = 4;
    const unsigned char RDBK_PD2REVHI = 5;
    const unsigned char RDBK_PD2BLDLO = 6;
    const unsigned char RDBK_PD2BLDHI = 7;

    // RDBK_MODNUM (Bank 0)
    #define MODNUM    P_P4.PORT.BYTE
    #define MODNUM7   P_P4.PORT.BIT.B7
    #define MODNUM6   P_P4.PORT.BIT.B6
    #define MODNUM5   P_P4.PORT.BIT.B5
    #define MODNUM4   P_P4.PORT.BIT.B4
    #define MODNUM3   P_P4.PORT.BIT.B3
    #define MODNUM2   P_P4.PORT.BIT.B2
    #define MODNUM1   P_P4.PORT.BIT.B1
    #define MODNUM0   P_P4.PORT.BIT.B0

    // RDBK_IOTA (Bank 1)
    #define FTAPRS      P_P4.PORT.BIT.B7
    #define INHINX_n    P_P4.PORT.BIT.B6
    #define BUPREQ_FB   P_P4.PORT.BIT.B5
    #define JABLOCK_n   P_P4.PORT.BIT.B3
    #define BUPREQ_IN   P_P4.PORT.BIT.B2
    #define BOTTOM      P_P4.PORT.BIT.B1
    #define REDUNT_n    P_P4.PORT.BIT.B0

    // RDBK_CPLD (Bank 6 - CPLD Revision Letter)
    // Encoded as below. Use with HWINFO_REVLETTER_MASK.
    //   B7 B6 B5 B4 B3 B2 B1 B0
    //   |  |   |  |           |
    //   |  |   |  |           +--+
    //   |  |   |  |              |-> 0    : Results in blank 
    //   |  |   |  |              |-> 1-26 : Letter A to Z
    //   |  |   |  |              |-> 27-31: Results in blank
    //   |  |   |  +--------------+
    //   |  |   +-------------------> Number of letters (A-Z or AA-ZZ)
    //   |  +---------------------+
    //   |                        |-> Don't care
    //   +------------------------+
    #define CPLD_REVLETTER P_P4.PORT.BYTE

    // RDBK_BANK7 (Bank7 - CPLD Revision Number)
    #define RIP_n          P_P4.PORT.BIT.B7
    #define DIP_n          P_P4.PORT.BIT.B6
    #define HFRESET        P_P4.PORT.BIT.B5  // Used only by DO IOM
    #define CPLD_REVNUMBER P_P4.PORT.BYTE    // B4 to B0 - use with HWINFO_REVNUMBER_MASK
    
  #if (defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT) || defined(IOMTYPE_DISOE) || defined(IOMTYPE_DISOEBOOT))
    #define SNS_CHK     P_P4.PORT.NIBBLE.SNS
#if defined(IOPTYPE_DI)    
    #define DI_IOTA     DI_IOTA_24V
#else
    #define DI_IOTA     P_P4.PORT.NIBBLE.IOTA
#endif

    const UINT8 SNS_CHKA = 0x08;
    const UINT8 SNS_CHKB = 0x04;
    const UINT8 SNS_CHKC = 0x02;
    const UINT8 SNS_CHKD = 0x01;

    const BOOL SNS_NORMAL = 0;    
    const BOOL SNS_OWD    = 1;    

    const UINT8 DI_IOTA_24V  = 0x0F;
    const UINT8 DI_IOTA_110V = 0x0E;
    const UINT8 DI_IOTA_240V = 0x0D; 
    const UINT8 DI_IOTA_24V_IS = 0x0A; 
    const UINT8 DISOE_IOTA_24V = DI_IOTA_24V & 0x07;
    const UINT8 DISOE_IOTA_24V_IS = DI_IOTA_24V_IS & 0x07;
  #endif // DIs or DIBOOTs

  #if (defined(IOMTYPE_DO) || defined(IOMTYPE_DOBOOT))
    #define DO_IOTA     P_P4.PORT.NIBBLE.IOTA

    const UINT8 DO_IOTA_24VBUS = 0x0F;
    const UINT8 DO_IOTA_HV1    = 0x0E;
    const UINT8 DO_IOTA_HV2    = 0x0D;
    const UINT8 DO_IOTA_RELAY  = 0x0C;
    const UINT8 DO_IOTA_24VISO = 0x0B;
    const UINT8 DO_IOTA_24V_IS = 0x0A;

    // RDBK_ITYPE (Bank8)

    // RDBK_INHSW (Bank9)
    #define INHSWV3     P_P4.PORT.BIT.B2
    #define INHSWV2     P_P4.PORT.BIT.B1
    #define INHSWV1     P_P4.PORT.BIT.B0

    // RDBK_HSOC (Bank10)
    #define HSOC        P_P4.PORT.BYTE
    #define HSOC_0      P_P4.PORT.BIT.B0
    #define HSOC_1      P_P4.PORT.BIT.B1
    #define HSOC_2      P_P4.PORT.BIT.B2
    #define HSOC_3      P_P4.PORT.BIT.B3

    // RDBK_PD2REVLO (Bank12)
    #define DO_PD2REVLO P_P4.PORT.NIBBLE.IOTA //b0110

    // RDBK_PD2REVHI (Bank13)
    #define DO_PD2REVHI P_P4.PORT.NIBBLE.IOTA //b0110

    // RDBK_PD2BLDLO (Bank14)
    #define DO_PD2BLDLO P_P4.PORT.NIBBLE.IOTA

    // RDBK_PD2BLDHI (Bank15)
    #define DO_PD2BLDHI P_P4.PORT.NIBBLE.IOTA

  #endif // IOMTYPE_DO or DO_BOOT

#endif // PORT 4 definitions.

// General purpose I/O - Port 5.
#if defined(IOPTYPE_DI)
    #define A5_CNTL     P_P5.DR.BIT.B21
#endif

#if defined(IOPTYPE_DO)
    #define A14A15_PIN  P_P5.DR.BIT.B0
    #define OREGQ2_PIN  P_P5.DR.BIT.B1 // primary latch (01-08)
    #define OREGQ3_PIN  P_P5.DR.BIT.B2 // primary latch (09-16)
    #define OREGQ7_PIN  P_P5.DR.BIT.B3 // Backup latch (01-08)
    #define OREGQ8_PIN  P_P6.DR.BIT.B0 // Backup latch (09-16)
#if defined(DIGTYPE_DO16)
    #define STDBYMN_PIN P_P6.PORT.BIT.B1 // Standby Manual
#endif
    #define WRIOLX_PIN  P_P6.DR.BIT.B2
    #define P16IOL_PIN  P_P6.DR.BIT.B3
#endif

// General Purpose I/O - PORT A.
#if (defined(IOMTYPE_DO) || defined(IOMTYPE_DOBOOT))
    #define EN_SW       P_PA.DR.BIT.B0
    #define TST_SW      P_PA.DR.BIT.B1
    #define INH_SW2     P_PA.DR.BIT.B2
    #define INH_SW1     P_PA.DR.BIT.B3

#if defined(IOPTYPE_DO)
    #define AIOL00_PIN  P_PA.DR.BIT.B4
    #define AIOL01_PIN  P_PA.DR.BIT.B5
    #define AIOL02_PIN  P_PA.DR.BIT.B6
    #define A13A03_PIN  P_PA.DR.BIT.B7
#endif

#endif // IOMTYPE_DO or DO_BOOT

// General Purpose I/O - PORT B,C,D,E - no definitions.

// General Purpose I/O - PORT F.

//#if(H8s2329_IOL_V01)
//#define GHOIRQ_n        P_P6.PORT.BIT.B4 // GHO interrupt
//#else
#define GHOIRQ_n        P_PF.PORT.BIT.B0 // GHO interrupt
//#endif

#if (HEK)
    #define WAIT_n      P_PF.DR.BIT.B2
#else
    #define GHOXXX      P_PF.PORT.BIT.B2 // N.B. excludes support for pass 1 HW
  
  #ifdef IOMTYPE_DISOE
    #define RDBK_SEL3   P_PF.DR.BIT.B3
    #define RDBK_SOECLKHIGH     14      // CPLD read back register for SOE Clock
    #define RDBK_SOECLKMID      13      // CPLD read back register for SOE Clock
    #define RDBK_SOECLKLOW      12      // CPLD read back register for SOE Clock
  #endif


  #ifdef IOMTYPE_DO    
    #define HOLDOUT_n   P_PF.DR.BIT.B6
    #define INHSWV3P1   P_PF.PORT.BIT.B4
    #define INHSWV2P1   P_PF.PORT.BIT.B5
    #define INHSWV1P1   P_PF.PORT.BIT.B3 
  #endif
    #if defined(IOMTYPE_DO) || defined(IOPTYPE_DI)
    #define SRAM_CS     P_PF.DR.BIT.B4    // DI.DO out
    #define SRAM_SCLK   P_PF.DR.BIT.B5    // DI.DO out
    #define SRAM_DOUT   P_PF.PORT.BIT.B7  // DI.DO in
#endif

#endif

// General Purpose I/O - PORT G.
#if HEK
    #define JTAG_TMS    P_PG.DR.BIT.B0
#else
    #define LED_PINS    P_PG.DR.BIT.B10

  #if (defined(IOMTYPE_DI) || defined(IOMTYPE_DIBOOT) || defined(IOMTYPE_DISOE) || defined(IOMTYPE_DISOEBOOT))
#if !defined(IOPTYPE_DI)
    #define A5_CNTL     P_PG.DR.BIT.B43
#endif
    #define HG_SNS      P_PG.DR.BIT.B2
  #endif

  #if (defined(IOMTYPE_DO) || defined(IOMTYPE_DOBOOT))
    #define RDBK_SEL3   P_PG.DR.BIT.B2
    #define RDBK_STRB_n P_PG.DR.BIT.B3
  #endif

  #if defined(IOMTYPE_DO) || defined(IOPTYPE_DI)
    #define SRAM_DIN    P_PG.DR.BIT.B4    // DI.DO out
  #endif

#endif // HEK
#endif // !LOWCOST


// *************************************
//
//     CPLD and FPGA
//
// *************************************

// Struct  (Common to HEK and LOWCOST)

#if !(defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT)) 

    // FPGA SPI definitions, per Xilinx rs01-1999-0229

#if defined (IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT)
    // CRL register masks
    #define CRL_ManualSlaveSelect_MASK  (0x80)
    #define CRL_RxFifoReset_MASK        (0x40)
    #define CRL_TxFifoReset_MASK        (0x20)
    #define CRL_ClockPhaseInv_MASK      (0x10)
    #define CRL_ClockPolarInv_MASK      (0x08)
    #define CRL_MasterMode_MASK         (0x04)
    #define CRL_SpiSystemEnable_MASK    (0x02)
    #define CRL_LocalLoopbackMode_MASK  (0x01)

    // CRH register masks
    #define CRH_MasterInhibit_MASK      (0x80)

    // SR register masks
    #define SR_ModeFaultError_MASK      (0x10)
    #define SR_TxFull_MASK              (0x08)
    #define SR_TxEmpty_MASK             (0x04)
    #define SR_RcFull_MASK              (0x02)
    #define SR_RcEmpty_MASK             (0x01)

    // SSR register masks
    #define SSR_ChipSel1_MASK           (0x02)
    #define SSR_ChipSel0_MASK           (0x01)

    // SPI Master Register Map
    struct st_fpga_spi {
        volatile UINT8 IGER;    // Interrupt Global Enable Register
        volatile UINT8 IR;      // Interrupt Register
        volatile UINT8 IER;     // Interrupt Enable Register
        volatile UINT8 CRL;     // Control Register Low
        volatile UINT8 CRH;     // Control Register High
        volatile UINT8 SR;      // Status Register
        volatile UINT8 TXD;     // Transmit FIFO
        volatile UINT8 RXD;     // Receive FIFO
        volatile UINT8 SSR;     // Slave Select Register

        // CRL methods
        inline VOID SetCRL(UINT8 a_ucCRL) { CRL = a_ucCRL; }
        inline VOID ClearRxFifo(VOID) { CRL |= CRL_RxFifoReset_MASK; }
        inline VOID ClearTxFifo(VOID) { CRL |= CRL_TxFifoReset_MASK; }

        // CRH methods
        inline VOID SetMasterInhibit(VOID)   { CRH = CRH_MasterInhibit_MASK; }
        inline UINT8 ClearMasterInhibit(VOID) { CRH = 0x00; return CRH; }

        // SR methods
        inline BOOL IsRxFifoEmpty(VOID) { return ((SR & SR_RcEmpty_MASK) != 0) ? TRUE : FALSE; }
        inline BOOL IsTxFifoEmpty(VOID) { return ((SR & SR_TxEmpty_MASK) != 0) ? TRUE : FALSE; }

        // send/receive data methods
        inline VOID SendByte(UINT8 a_ucByte) { TXD = a_ucByte; }
        inline UINT8 RecvByte(VOID) { return RXD; }

        // SSR methods
        inline VOID AssertSlaveSelect0(VOID) { SSR = ~SSR_ChipSel0_MASK; }
        inline VOID AssertSlaveSelect1(VOID) { SSR = ~SSR_ChipSel1_MASK; }
        inline VOID DeassertSlaveSelect(VOID) { SSR = 0xFF; }
    };
#else
    struct st_fpga_spi{
        unsigned char   IGER;
        unsigned char   IR;
        unsigned char   IER;
        unsigned char   CRL;
        unsigned char   CRH;
        unsigned char   SR;
        unsigned char   TXD;
        unsigned char   RXD;
        unsigned char   SSR;
    };
#endif

    struct st_fpga_brg{
        UINT8 LOBYTE;
        UINT8 HIBYTE;
    };

    // FPGA UART definitions
    struct st_fpga_uart{
        union {
            unsigned char RCVBUF_REGISTER;
            unsigned char XMTHOLD_REGISTER;
        };
        union {
            unsigned char INTR_ENBL_REGISTER;
            struct {
                unsigned char INTR_ENBL_B7_5        : 4;
                unsigned char MODEMSTS_INTR_ENBL    : 1;
                unsigned char RCVLINESTS_INTR_ENBL  : 1;
                unsigned char XMTREGEMPTY_INTR_ENBL : 1;
                unsigned char RCVDATAAVBL_INTR_ENBL : 1;
            };
        };
        union {
            unsigned char INTR_IDNT_REGISTER;
            struct {
                unsigned char READ_FIFO_ENBL : 2;
                unsigned char INTR_IDNT_B5_4 : 2;
                unsigned char INTR_ID        : 3;
                unsigned char INTR_PENDING   : 1;
            };
            struct {
                unsigned char INTRID_HINIBBLE   : 4;
                unsigned char HART_INTR_ID      : 4;
            };
            unsigned char FIFO_CTRL_REGISTER;
            struct {
                unsigned char RCV_FIFO_TRIG_LEVEL : 2;
                unsigned char FIFO_CTRL_B5_4      : 2;
                unsigned char DMA_MODE_SELECT     : 1;
                unsigned char XMT_FIFO_CLEAR      : 1;
                unsigned char RCV_FIFO_CLEAR      : 1;
                unsigned char FIFO_ENBL           : 1;
            };
        };
        union {
            unsigned char LINE_CTRL_REGISTER;
            struct {
                unsigned char DVSR_LATCH_ACCESS   : 1;
                unsigned char SET_BREAK           : 1;
                unsigned char STICK_PARITY_SELECT : 1;
                unsigned char EVEN_PARITY_SELECT  : 1;
                unsigned char PARITY_ENBL         : 1;
                unsigned char STOP_BITS_SELECT    : 1;
                unsigned char BITS_PER_CHAR       : 2;
            };
        };
        union {
            unsigned char MODEM_CTRL_REGISTER;
            struct {
                unsigned char MODEM_CTRL_B7_5 : 3;
                unsigned char LOOP_BACK_ENBL  : 1;
                unsigned char USER_OUTPUT2    : 1;
                unsigned char USER_OUTPUT1    : 1;
                unsigned char REQUEST_TO_SEND : 1;
                unsigned char DATA_TERM_READY : 1;
            };
        };
        union {
            unsigned char LINE_STS_REGISTER;
            struct {
                unsigned char RCV_FIFO_ERROR : 1;
                unsigned char XMT_COMPLETE   : 1;
                unsigned char XMTREG_EMPTY   : 1;
                unsigned char BREAK_INTR     : 1;
                unsigned char FRAMING_ERROR  : 1;
                unsigned char PARITY_ERROR   : 1;
                unsigned char OVERRUN_ERROR  : 1;
                unsigned char DATA_READY     : 1;
            };
        };
        union {
            unsigned char MODEM_STS_REGISTER;
            struct {
                unsigned char CARRIER_DETECT       : 1;
                unsigned char RING_INDICATER       : 1;
                unsigned char DATASET_READ         : 1;
                unsigned char CLEAR_TO_SEND        : 1;
                unsigned char DELTA_CARRIER_DETECT : 1;
                unsigned char TRAIL_EDGE_INDICATOR : 1;
                unsigned char DELTA_DATASET_READ   : 1;
                unsigned char DELTA_CLEAR_TO_SEND  : 1;
            };
        };
        unsigned char SCRATCH_PAD_REGISTER;
        unsigned char RESET;
    };
    struct st_fpga_uartlite{
        UINT8   RXD;
        UINT8   TXD;
        union {
            UINT8   SR;
            struct {
                UINT8 PARITY_ERROR  : 1;
                UINT8 FRAME_ERROR   : 1;
                UINT8 OVERUN_ERROR  : 1;
                UINT8 INTR_ENABLED  : 1;
                UINT8 TX_FIFO_FULL  : 1;
                UINT8 TX_FIFO_EMPTY : 1;
                UINT8 RX_FIFO_FULL  : 1;
                UINT8 RX_FIFO_DATA  : 1;
            };
        };
        union {
            UINT8   CR;
            struct {
                UINT8               : 3;
                UINT8 ENABLE_INTR   : 1;
                UINT8               : 2;
                UINT8 RESET_RX_FIFO : 1;
                UINT8 RESET_TX_FIFO : 1;
            };
        };
    };

    // FPGA Interrupt Status Register definitions
    union un_fpga_bytebits {
        struct {
            UINT8   B7:1;
            UINT8   B6:1;
            UINT8   B5:1;
            UINT8   B4:1;
            UINT8   B3:1;
            UINT8   B2:1;
            UINT8   B1:1;
            UINT8   B0:1;
        };
        struct {
            UINT8 HiNibble   : 4;
            UINT8 INTFL_HART : 4;
        };
        UINT8 FPGABYTEREG;
    };

    union un_hmuxenbl {
        unsigned int ALL_FOUR;
        struct {
            unsigned int B15_4 : 12;
            unsigned int MUX1  : 1;
            unsigned int MUX2  : 1;
            unsigned int MUX3  : 1;
            unsigned int MUX4  : 1;
        };
    };

    // CPLD Definitions
    union un_cpld_rd {
        struct {
            unsigned int    B15:1;
            unsigned int    B14:1;
            unsigned int    B13:1;
            unsigned int    B12:1;
            unsigned int    B11:1;
            unsigned int    B10:1;
            unsigned int    B9:1;
            unsigned int    B8:1;
            unsigned int    unusedlo:8;
        };
        UINT16 CPLDRDREG;
    };

    struct st_gpr{
        unsigned int    B15   :1;
        unsigned int    B14_9 :4;
        unsigned int    B10   :1;
        unsigned int    B9    :1;
        unsigned int    B8    :1;
        unsigned int    B7_2  :6;
        unsigned int    B1_0  :2;
    };

    // FPGA Analog Input definitions
    struct st_fpga_wcr{
        unsigned char   Rsrvd:1;
        unsigned char   FILTOFF:1;
        unsigned char   UP:1;
        unsigned char   ENB:1;
        unsigned char   CSEL:4;
    };
#endif //!PI

#if LOWCOST  
    #define DummyReg _DUMMYREG
    extern char _DUMMYREG[16];   // Write area for no effects. The memory is reserved in asmutils.asm

    #define HART_BAUDRATE_REGISTER  (*(volatile struct st_fpga_brg *)DummyReg)
    #define FPGA_ISR                (*(volatile union un_fpga_bytebits *)DummyReg)  // read, hart.cpp
    #define WIGLPVCR                (*(volatile struct st_fpga_wcr *)DummyReg)      // only by the .h
    #define OWD_ENB                 WIGLPVCR.ENB
    #define HART_MUXADDR            (*(volatile UINT16 *)DummyReg)      // AI,AO in,out   
    #define HART_MUXENBL            (*(volatile un_hmuxenbl *)DummyReg) //AI,AO in,out

    // HART table, Dummy
    const UINT8  HARTMODEM_COUNT  = 4;
    const UINT32 HART_UART[HARTMODEM_COUNT] = { (UINT32)DummyReg,
                                                (UINT32)DummyReg,
                                                (UINT32)DummyReg,
                                                (UINT32)DummyReg
    };
    #define HART_UART(n)            (*(volatile struct st_fpga_uart *)HART_UART[n])
    const UINT8 HART_XMTINTR_ENABLE     = 0x02; // Enable XMT hold register empty interrupt
    const UINT8 HART_RCVINTR_ENABLE     = 0x09; // Enables RcvData and ModemStatus interrupts
    const UINT8 HART_RCVERROR_PRESENT   = 0x1E; // Break, framing, parity or overrun error.

    // Interrupts
    const UINT8 INTR_ID_RXLINESTATUS = 0x06;
    const UINT8 INTR_ID_RXDATAAVLBLE = 0x04;
    const UINT8 INTR_ID_CHARTIMEOUT  = 0x0C;
    const UINT8 INTR_ID_TXHLDRGEMPTY = 0x02;
    const UINT8 INTR_ID_MODEMSTATUS  = 0x00;

    // EEPROM Slave select constants
    const UINT8 SS_DESELECT = 0xFF;
    const UINT8 SS_EEPROM   = 0xFD;

    // SPI FIFO interrupt definitions 
    const UINT8 SPI_TX_FIFO_EMPTY_MASK= 0x04;
    const UINT8 SPI_RX_FIFO_EMPTY_MASK= 0x01;
    const UINT8 SPI_RX_FIFO_RESET_MASK= 0x40;
    const UINT8 SPI_EEPROM_WIP        = 0x01;

#elif (defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT))  // Pulse Input definitions

    // FPGA Register Definitions

    union un_fpga_wordbits {
        struct {
            unsigned int   B15:1;
            unsigned int   B14:1;
            unsigned int   B13:1;
            unsigned int   B12:1;
            unsigned int   B11:1;
            unsigned int   B10:1;
            unsigned int   B9:1;
            unsigned int   B8:1;
            unsigned int   B7:1;
            unsigned int   B6:1;
            unsigned int   B5:1;
            unsigned int   B4:1;
            unsigned int   B3:1;
            unsigned int   B2:1;
            unsigned int   B1:1;
            unsigned int   B0:1;
        };
        struct {
            UINT8 HIBYTE;
            UINT8 LOBYTE;
        };
        UINT16 FPGAWORDREG;

        struct {
           unsigned int RIP      :1;
           unsigned int DIP      :1;
           unsigned int BLD      :6;
           unsigned int B7_6     :2;
           unsigned int CNT      :1;
           unsigned int REV      :5;
        };

        struct {
           unsigned int B15_14   :2;
           unsigned int B13_12   :2;
           unsigned int B11_8    :4;
           unsigned int B7_0     :8;
        };

        struct {
           unsigned int Spare1   :1;
           unsigned int B14_12   :3;
           unsigned int Spare2   :1;
           unsigned int B10_8    :3;
           unsigned int Spare3   :1;
           unsigned int B6_4     :3;
           unsigned int Spare4   :1;
           unsigned int B2_0     :3;
        };

        struct {
           unsigned int B15_10    :6;
           unsigned int POWERUP2_n:1;
           unsigned int POWERUP_n :1;
           unsigned int Spare     :6;
           unsigned int B1_0      :2;           
        };

    };

    // Boot FPGA Registers
    #define BOOT_FPGA_WR_SR   (*(volatile  UINT16 *)0x400000)    //FPGA Boot FIFO Write Register
    #define BOOT_FPGA_RD_SR   (*(volatile  UINT16 *)0x400002)    //FPGA Boot FIFO Read Register
    #define BOOT_FPGA_CMD_REG (*(volatile  UINT16 *)0x400004)    //FPGA Boot ICAP Control Register

    // APP FPGA Registers    
    #define FPGA_ISR         (*(volatile  union un_fpga_wordbits *)0x400060)
    #define FPGA_ICR         (*(volatile  union un_fpga_wordbits *)0x400062)    
    #define FPGA_VER_REV     (*(volatile  union un_fpga_wordbits *)0x400070)
    #define MAR              (*(volatile  union un_fpga_wordbits *)0x400072)            
    #define DIP_RIP_CR       (*(volatile  union un_fpga_wordbits *)0x400074)
    #define INHSWCR          (*(volatile  union un_fpga_wordbits *)0x400076)    
    #define ITTCR            (*(volatile  union un_fpga_wordbits *)0x400080)   
    #define PMCR             (*(volatile  union un_fpga_wordbits *)0x400082)
    #define OCR              (*(volatile  union un_fpga_wordbits *)0x400084) 
    #define CCCR             (*(volatile  union un_fpga_wordbits *)0x400086)
    #define DCCR             (*(volatile  union un_fpga_wordbits *)0x400088)    
    #define OTR0             (*(volatile  UINT32 *)0x40008A)
    #define OTR1             (*(volatile  UINT32 *)0x40008E)
    #define SR               (*(volatile  union un_fpga_wordbits *)0x400092)
    #define REDCR            (*(volatile  union un_fpga_wordbits *)0x400094)    
    #define IPR1             (*(volatile  union un_fpga_wordbits *)0x400096) 
    #define IPR2             (*(volatile  union un_fpga_wordbits *)0x400098)    
    #define PWRCR            (*(volatile  union un_fpga_wordbits *)0x40009A)
    #define IPVALIDCR        (*(volatile  union un_fpga_wordbits *)0x40009C)        
    #define CSCR             (*(volatile  union un_fpga_wordbits *)0x40009E)    
    #define PSCSR            (*(volatile  union un_fpga_wordbits *)0x4000A0)
    #define DPICR            (*(volatile  union un_fpga_wordbits *)0x4000A2)
    #define DIAGREG          (*(volatile  union un_fpga_wordbits *)0x4000A4)    // Diagnostics Scratchpad Register
    #define PCSR             (*(volatile  union un_fpga_wordbits *)0x4000A6)
    #define PITR             (*(volatile  union un_fpga_wordbits *)0x4000A8)
    #define HLVTSR           (*(volatile  union un_fpga_wordbits *)0x4000AA)
    #define INVALID_LOCATION (*(volatile  UINT16 *)0x4000FE)
    
    // Below provided the base addresses for all counters. while accessing individual
    // counters use following notation based on which channel counter to access.
    // Ex: For Counters access 
    // Channel 1 Counter value is fpgaCOUNTER[ChanNum - 1]
    // Channel 2 Counter value is fpgaCOUNTER[ChanNum - 1]
    // Similarly for all other counters.
    #define fpgaCOUNTER          ((volatile  UINT32 *)0x400100)   // Counters base address for Pulse counting/Frequency calculation
    #define fpgaTIMER            ((volatile  UINT32 *)0x400200)   // Timer Latches for Pulse priod/Width Claculation
    #define fpgaFRC              ((volatile  UINT32 *)0x400400)   // Free Running Counters base address
    #define fpgaCTR_UPDATE       ((volatile  UINT32 *)0x401000)   // Update Counters base address
    #define fpgaGET_CLR_CNT      ((volatile  UINT32 *)0x402100)   // Get and Clear Counters base address
    #define fpgaPV_COUNTER       ((volatile  UINT32 *)0x404000)   // PV Counters

    // FPGA IRQ Status Register
    #define FPGA_INTFL_IP_8       FPGA_ISR.B15           // Channel 8 Integration period interrupt flag
    #define FPGA_INTFL_IP_7       FPGA_ISR.B14           // Channel 7 Integration period interrupt flag
    #define FPGA_INTFL_IP_6       FPGA_ISR.B13           // Channel 6 Integration period interrupt flag
    #define FPGA_INTFL_IP_5       FPGA_ISR.B12           // Channel 5 Integration period interrupt flag
    #define FPGA_INTFL_IP_4       FPGA_ISR.B11           // Channel 4 Integration period interrupt flag
    #define FPGA_INTFL_IP_3       FPGA_ISR.B10           // Channel 3 Integration period interrupt flag
    #define FPGA_INTFL_IP_2       FPGA_ISR.B9            // Channel 2 Integration period interrupt flag
    #define FPGA_INTFL_IP_1       FPGA_ISR.B8            // Channel 1 Integration period interrupt flag
    #define FPGA_INTFL_OSCFAIL    FPGA_ISR.B7            // Oscillator failure interrupt flags
    #define FPGA_INTFL_BDECODE    FPGA_ISR.B6            // BAD_DECODE interrupt flags
    #define FPGA_INTFL_IP         FPGA_ISR.HIBYTE        // Integration period interrupt flags
    #define FPGA_INTFL_LO         FPGA_ISR.LOBYTE        // Other interrupt flags
    #define FPGA_INTFL            FPGA_ISR.FPGAWORDREG   // All interrupt flags

    // FPGA IRQ Control Register
    #define FPGA_CTRLREG_VISO     FPGA_ICR.LOBYTE  // Isolated power supply irq control bits 
    #define FPGA_CTRLREG_IP       FPGA_ICR.HIBYTE  // Integration period irq control bits
    #define FPGA_IRQCR            FPGA_ICR.FPGAWORDREG
    #define IRQ_DIAG_CTRL         FPGA_ICR.B0
    
    // Build and Revision Register
    #define FPGA_REVLETTER        FPGA_VER_REV.LOBYTE
    #define FPGA_REVNUMBER        FPGA_VER_REV.BLD
    #define DIP_n                 FPGA_VER_REV.DIP
    #define RIP_n                 FPGA_VER_REV.RIP  
    #define COUNT                 FPGA_VER_REV.CNT

    // Module Address Register
    #define INHINX_n              MAR.B14
    #define IOTA_TYPE             MAR.B13_12
    #define BUPREQ_FB             MAR.B11
    #define BUPREQ_IN             MAR.B10
    #define REDUNT_n              MAR.B9   
    #define BOTTOM                MAR.B8
    #define MODNUM                MAR.B7_0

    // DIP and RIP Control Register
    #define CLR_RIP_n             DIP_RIP_CR.POWERUP_n      
    #define SET_DIP               DIP_RIP_CR.POWERUP2_n      

   // Input Threshold and Transition Control register
    #define VOLT_THRESHOLD        ITTCR.LOBYTE
    #define EDGE_DETECT           ITTCR.HIBYTE 

   // Pulse Mode Control register 
    #define PULSE_PERIOD_SEL      PMCR.LOBYTE
    #define PULSE_WIDTH_SEL       PMCR.HIBYTE   

   // Output Control Register
    #define SAFE_STATE_n          OCR.B7
    #define OUT_CTRL1             OCR.B6
    #define OUT_SET1              OCR.B5
    #define OUT_SEN1              OCR.B4
    #define OUT_CTRL0             OCR.B2
    #define OUT_SET0              OCR.B1
    #define OUT_SEN0              OCR.B0

   // Counter Clear Control Register
    #define LAT_FRC               CCCR.B8   // This bit will use in Debug code only to verify FRC functionality
    #define CLRCNT_7              CCCR.B7
    #define CLRCNT_6              CCCR.B6
    #define CLRCNT_5              CCCR.B5
    #define CLRCNT_4              CCCR.B4
    #define CLRCNT_3              CCCR.B3
    #define CLRCNT_2              CCCR.B2
    #define CLRCNT_1              CCCR.B1
    #define CLRCNT_0              CCCR.B0
    #define CLEAR_COUNTERS        CCCR.LOBYTE
    #define CLEAR_TIMERS          CCCR.HIBYTE

   // Diagnostic Counter Control Register 
    #define DIAGOSCSTART          DCCR.B15
    #define DIAGOSCTEST           DCCR.B14
    #define DIAGADDARM            DCCR.B13
    #define DIAGADDCLR            DCCR.B12
    #define DIAGOSCCLR            DCCR.B11
    #define DIAGON                DCCR.B10
    #define DIAGWR1               DCCR.B1          
    #define DIAGWR0               DCCR.B0
    #define DIAGWR                DCCR.B1_0

   // Pulse Input Status Register
    #define COMPARING1            SR.B12  
    #define COMPARING0            SR.B11
    #define DIAGON1               SR.B10  
    #define STATUSOUT1            SR.B9  
    #define STATUSOUT0            SR.B8
    #define TIMER_LATCH_STS       SR.LOBYTE

   // Counter Semaphores Configuration Register
   // B00 - Set semaphore for AvRaw Counter 1
   // B01 - Clear semaphore for AvRaw Counter 1
   // B02 - Set semaphore for AvRaw Counter 2
   // B03 - Clear semaphore for AvRaw Counter 2
   // B04 - Set semaphore for AvRaw Counter 3
   // B05 - Clear semaphore for AvRaw Counter 3
   // B06 - Set semaphore for AvRaw Counter 4
   // B07 - Clear semaphore for AvRaw Counter 4
   // B08 - Set semaphore for AvRaw Counter 5
   // B09 - Clear semaphore for AvRaw Counter 5
   // B10 - Set semaphore for AvRaw Counter 6
   // B11 - Clear semaphore for AvRaw Counter 6
   // B12 - Set semaphore for AvRaw Counter 7
   // B13 - Clear semaphore for AvRaw Counter 7
   // B14 - Set semaphore for AvRaw Counter 8
   // B15 - Clear semaphore for AvRaw Counter 8
   // Setting the bit performs the indicated action. Upon completion of
   // the action it is automatically cleared by the FPGA
    #define CNTRSEMCR             CSCR.FPGAWORDREG

   // Isolated Power Supplies Control/Status Register
    #define ISOCHNENB             PSCSR.LOBYTE
    #define ISOCHNGOOD            PSCSR.HIBYTE

   // Dual Pulse Integrity Control register
    #define CHANNEL_TYPE          DPICR.LOBYTE     
    #define CHANNEL_SELECT        DPICR.HIBYTE     
    #define PULSECOPY3            DPICR.B15
    #define PULSECOPY2            DPICR.B14
    #define PULSECOPY1            DPICR.B13
    #define PULSECOPY0            DPICR.B12

   // Diagnostic Scratchpad Register
    #define SCRATCHPADREG         DIAGREG.FPGAWORDREG
    #define DEFAULT_TEST_PATTERN  0x55AA

   // Pulse Capture Status Register
    #define PULSE_VALID_STS       PCSR.LOBYTE
 
   // Redundancy Control Register
    #define COUNT_UPDATE_7          REDCR.B7
    #define COUNT_UPDATE_6          REDCR.B6
    #define COUNT_UPDATE_5          REDCR.B5
    #define COUNT_UPDATE_4          REDCR.B4
    #define COUNT_UPDATE_3          REDCR.B3
    #define COUNT_UPDATE_2          REDCR.B2
    #define COUNT_UPDATE_1          REDCR.B1
    #define COUNT_UPDATE_0          REDCR.B0
    #define COUNT_UPDATE_FLAGS      REDCR.LOBYTE

   // Inhibit switch control register
    #define INHSWV3                 INHSWCR.B10
    #define INHSWV2                 INHSWCR.B9
    #define INHSWV1                 INHSWCR.B8
    #define INHSWV                  INHSWCR.B10_8
    #define EN_SW                   INHSWCR.B3    
    #define TST_SW                  INHSWCR.B2
    #define INH_SW1                 INHSWCR.B1
    #define INH_SW2                 INHSWCR.B0

   // Integration Period Register 1 and 2
    #define INT_PER_CHN8          IPR2.B14_12  
    #define INT_PER_CHN7          IPR2.B10_8
    #define INT_PER_CHN6          IPR2.B6_4
    #define INT_PER_CHN5          IPR2.B2_0
    #define INT_PER_CHN4          IPR1.B14_12  
    #define INT_PER_CHN3          IPR1.B10_8
    #define INT_PER_CHN2          IPR1.B6_4
    #define INT_PER_CHN1          IPR1.B2_0

   // Pulse Width Rejection Control Register 
    #define PW_REJECTION          PWRCR.LOBYTE

   // Integration Period Valid Control Register
    #define IP_VALID_FLAGS        IPVALIDCR.LOBYTE

    // Pulse Input Test Register
    #define PULSEINREG            PITR.LOBYTE
    #define PROVER_PULSE_IN       PITR.B8     
     
    // High/Low Voltage Status Register
    #define IPTHRSHSTS           HLVTSR.LOBYTE

#if defined(DEBUG)
    // Following intermediate counters are used in debug firmware only for frequency test.
    #define INT_COUNTER1     ((volatile  UINT32 *)0x200000)
    #define INT_COUNTER2     ((volatile  UINT32 *)0x200020)
    #define INT_FRC1         ((volatile  UINT32 *)0x200040)
    #define INT_FRC2         ((volatile  UINT32 *)0x200060)
#endif
  

#elif (defined(IOMTYPE_UIO) || defined(IOMTYPE_UIOBOOT))

    // CPLD and FPGA Register definitions and explanation of the bits in the each
    // registers will be avaialble in Series C UIO FDS stored in the following location.
    // (\HIP\Projects\Series C RUPIO\Hardware\Series C UIO FDS.doc)
    // Refer section 4.9(for CPLD Definitions),section 4.15(FPGA register definitions),
    // section 4.16(FPGA UART and SPI registers)

    
    union un_cpld_fpga_wordbits {
         struct {
               unsigned int   B15:1;
               unsigned int   B14:1;
               unsigned int   B13:1;
               unsigned int   B12:1;
               unsigned int   B11:1;
               unsigned int   B10:1;
               unsigned int   B9:1;
               unsigned int   B8:1;
               unsigned int   B7:1;
               unsigned int   B6:1;
               unsigned int   B5:1;
               unsigned int   B4:1;
               unsigned int   B3:1;
               unsigned int   B2:1;
               unsigned int   B1:1;
               unsigned int   B0:1;
         };
         struct {
               UINT8 HIBYTE;
               UINT8 LOBYTE;
         };
         UINT16 CPLDWORDREG;
         UINT16 FPGAWORDREG;

         struct {
               unsigned int   B15_13   :3;
               unsigned int   CPLDREV  :5;
               unsigned int   B7_2     :6;
               unsigned int   B1_0     :2;
         };

         struct {
               unsigned int   B15_14   :2;
               unsigned int   FPGABLD  :6;
               unsigned int   B7_5     :3;
               unsigned int   FPGAREV  :5;
         };

         struct {
               unsigned int   HO_MA_15_12 :4;
               unsigned int   HI_MA_11_8  :4;
               unsigned int   B7_0        :8;
         }; 
         struct {
               unsigned int   B15_10    :6;
               unsigned int   WD7_4     :1;
               unsigned int   WD3_0     :1;
               unsigned int   HO_MA_7_4 :4;
               unsigned int   HI_MA_3_0 :4;
         };

         struct {
               unsigned int   INTFL_HART :2;
               unsigned int   INTFL_SPI  :1;
               unsigned int   B13_0      :13;
         };

         struct {
               unsigned int   B15_9      :7;
               unsigned int   INHOUT     :1;
               unsigned int   B7_1       :7;
               unsigned int   INHIN      :1;
         };

    };

    // CPLD Definitions --CS0(0x080000)    

    #define MNR                    (*(volatile  union un_cpld_fpga_wordbits *)0x080000)          
    #define SPARE                  (*(volatile  union un_cpld_fpga_wordbits *)0x080002)
    #define IOLIOTASR              (*(volatile  union un_cpld_fpga_wordbits *)0x080004)
    #define MSR                    (*(volatile  union un_cpld_fpga_wordbits *)0x080006)
    #define CPLDREVREG             (*(volatile  union un_cpld_fpga_wordbits *)0x080008)
    #define SPARE1                 (*(volatile  union un_cpld_fpga_wordbits *)0x08000A)
    #define SPARE2                 (*(volatile  union un_cpld_fpga_wordbits *)0x08000C)
    #define SPARE3                 (*(volatile  union un_cpld_fpga_wordbits *)0x08000E)
    #define SCRATCHPADREG          (*(volatile  union un_cpld_fpga_wordbits *)0x080010)
    #define HARTMUXENBREG          (*(volatile  union un_cpld_fpga_wordbits *)0x080012)
    #define GPREG                  (*(volatile  union un_cpld_fpga_wordbits *)0x080014)

    // Module Number Register
    #define MODNUM                  MNR.HIBYTE

   // IOL/IOTA Status Register
    #define IOTA_TYPE              IOLIOTASR.B14
    #define BUPREQ_FB              IOLIOTASR.B13
    #define BUPREQ_IN              IOLIOTASR.B10
    #define BOTTOM                 IOLIOTASR.B9
    #define REDUNT_n               IOLIOTASR.B8

    // Miscellaneous Status register
    #define HARTLESS_n             MSR.B14

    // CPLD Revision Register
    #define CPLDCOUNT              CPLDREVREG.B13
    #define CPLD_REVLETTER         CPLDREVREG.CPLDREV
    #define CPLD_REVNUMBER         CPLDREVREG.LOBYTE

    // Hart Mux Enable Register
    #define MODEM1_AI              HARTMUXENBREG.B3           
    #define MODEM0_AI              HARTMUXENBREG.B2

    // General Purpose Register        
    #define DIP_n                  GPREG.B9
    #define SET_DIP                GPREG.B9    
    #define RIP_n                  !GPREG.B8
    #define CLR_RIP_n              GPREG.B8    
    #define LED_PINS               GPREG.B1_0  


    // FPGA Definitions  -- CS2(0x400000),CS3(0x600000) 

    // Boot FPGA Registers
    #define BOOT_FPGA_WR_SR        (*(volatile  UINT16 *)0x400000)    //FPGA Boot FIFO Write Register
    #define BOOT_FPGA_RD_SR        (*(volatile  UINT16 *)0x400002)    //FPGA Boot FIFO Read Register
    #define BOOT_FPGA_CMD_REG      (*(volatile  UINT16 *)0x400004)    //FPGA Boot ICAP Control Register

    // Common register for both FPGA Boot and APP
    #define FPGA_REV_BLD           (*(volatile  union un_cpld_fpga_wordbits *)0x400070)    

    // APP FPGA Registers

    #define FPGA_ISR               (*(volatile  union un_cpld_fpga_wordbits *)0x600800)
    #define HARTCR                 (*(volatile  union un_cpld_fpga_wordbits *)0x600804)
    #define HART_ADD_REG_P         (*(volatile  union un_cpld_fpga_wordbits *)0x600806)    
    #define HART_ADD_REG_S         (*(volatile  union un_cpld_fpga_wordbits *)0x600808)
    #define TST_CNFG_TOG           (*(volatile  union un_cpld_fpga_wordbits *)0x60080C)    // Test Configuration Toggle
    #define INHSWCR                (*(volatile  union un_cpld_fpga_wordbits *)0x60080E)

    // FPGA Build and Revision Letter
    #define FPGA_REVNUMBER         FPGA_REV_BLD.FPGABLD
    #define FPGA_REVLETTER         FPGA_REV_BLD.FPGAREV
    #define FPGACOUNT              FPGA_REV_BLD.B5

    // SPI and Digital Thermometer
    #define THERM_SPI              (*(st_fpga_spi *)0x4001B0)
    #define THERM_SPI_RESET        (*(volatile unsigned char *)0x4001C0)

    // Miscellaneous Flip Flop Control Register 
    union u_fpga_misc_flipflop
    {
        UINT16 word;
        struct
        {
            UINT8 mask;
            UINT8 value;
        } byte;
    };

    #define SMOD_MASK               (0x01)
    #define SPI_RST_MASK            (0x02)
    #define MISCFLIPFLOPCR          (*(volatile  UINT16 *)0x60080A)

    // Inhibit Switch Control Register
    #define INHIN                   INHSWCR.INHIN 

    // ADC Scan Request registers
    struct st_fpga_io_scanrequest
    {
        UINT16 fRB_ACurrent;                // 0x00
        UINT16 fRB_ACurrentP;               // 0x02
        UINT16 RB_ACurrent;                 // 0x04
        UINT16 RB_DCurrent;                 // 0x06
        UINT16 RB_DCurrent_Adjust_ComPP;    // 0x08
        UINT16 RB_Voltages;                 // 0x0A
        UINT16 Ctrl_Ch_Independence;        // 0x0C
        UINT16 Test_Result_pointer;         // 0x0E
        UINT16 Clr_Result_Reg;              // 0x10
    };

    #define ADC_SR_L                (*(volatile st_fpga_io_scanrequest *)0x600200)
    #define ADC_SR_U                (*(volatile st_fpga_io_scanrequest *)0x600600)

    // I/O Board Status registers
    struct st_fpga_statusword
    {
        UINT8 bit15:1;
        UINT8 bit14:1;
        UINT8 DAC_FIFO_FULL:1;
        UINT8 DAC_FIFO_EMPTY:1;
        UINT8 bit11:1;
        UINT8 bit10:1;
        UINT8 ADC_EMPTY:1;
        UINT8 ADC_RDY:1;
        UINT8 byte0;
    };

    #define RD_STATUSWORD_L          (*(volatile  st_fpga_statusword *)0x600354)
    #define RD_STATUSWORD_U          (*(volatile  st_fpga_statusword *)0x600754)

    // ADC ReadBack registers
    struct st_fpga_io_readback
    {
        UINT16 fRB_ACurrent;                // 0x00
        UINT16 fRB_ACurrentP;               // 0x02
        UINT16 RB_ACurrent;                 // 0x04
        UINT16 RB_DCurrent;                 // 0x06
        UINT16 RB_DCurrent_Adjust_ComPP;    // 0x08
        UINT16 RB_Voltages;                 // 0x0A
        UINT16 padding_0C;                  // 0x0C
        UINT16 padding_0E;                  // 0x0E
    };

    #define ADC_READBACK_REG        ((const volatile st_fpga_io_readback *)0x600000)

    // Digital Output registers
    union u_fpga_digital_output
    {
        UINT16 word;
        struct
        {
            UINT8 mask;
            UINT8 SO;
        } byte;
    };

    #define DO_SO_0_7               (*(volatile UINT16 *)0x600370)
    #define DO_SO_8_15              (*(volatile UINT16 *)0x600372)
    #define DO_SO_16_23             (*(volatile UINT16 *)0x600770)
    #define DO_SO_24_31             (*(volatile UINT16 *)0x600772)

    // Analog Output DAC registers
    #define DAC_OP_L                ((volatile  UINT16 *)0x600300)
    #define DAC_OP_U                ((volatile  UINT16 *)0x600700)

    // output DAC index for 5V0 reference adjust
    #define ADJ_5V0_REF_IDX         (17)

    // clear all DACs on I/O board (set to 0mA output)
    #define CLR_DACs_L              (*(volatile  UINT16 *)0x600330)
    #define CLR_DACs_U              (*(volatile  UINT16 *)0x600730)

    // clear the output FIFO for I/O board
    #define CLR_FIFO_L              (*(volatile  UINT16 *)0x600340)
    #define CLR_FIFO_U              (*(volatile  UINT16 *)0x600740)

    // HART Modem and UART Definitions
    const UINT8  HARTMODEM_COUNT  = 2;
    const UINT32 HART_UART_ADDRESS[HARTMODEM_COUNT] = { 0x400100,   // UART 1 Base Address
                                                        0x400110};  // UART 2 Base Address
    const UINT8 HART_INTR_PENDING_MASK  = 0x01;
    const UINT8 HART_XMTINTR_ENABLE     = 0x02; // Enable XMT hold register empty interrupt
    const UINT8 HART_RCVINTR_ENABLE     = 0x09; // Enables RcvData and ModemStatus interrupts
    const UINT8 HART_RCVERROR_PRESENT   = 0x1E; // Break, framing, parity or overrun error.
    #define HART_UART(n)            (*(volatile struct st_fpga_uart *)HART_UART_ADDRESS[n])

    #define FPGA_INTFL_SPI   FPGA_ISR.B13
    #define FPGA_INTFL_UART0 FPGA_ISR.B14
    #define FPGA_INTFL_UART1 FPGA_ISR.B15

    const UINT8 INTR_ID_RXLINESTATUS = 0x06;
    const UINT8 INTR_ID_RXDATAAVLBLE = 0x04;
    const UINT8 INTR_ID_CHARTIMEOUT  = 0x0C;
    const UINT8 INTR_ID_TXHLDRGEMPTY = 0x02;
    const UINT8 INTR_ID_MODEMSTATUS  = 0x00;

    // Pulse Counting Register definitions(channels 15 to 18)

    #define VhighCNT1_Ch15              (*(volatile  UINT16 *)0x600328)
    #define VlowCNT1_Ch15               (*(volatile  UINT16 *)0x60032A)
    #define VhighCNT1_Ch16              (*(volatile  UINT16 *)0x60032C)
    #define VlowCNT1_Ch16               (*(volatile  UINT16 *)0x60032E)
    #define VhighCNT1_Ch17              (*(volatile  UINT16 *)0x60072C)
    #define VlowCNT1_Ch17               (*(volatile  UINT16 *)0x60072E)
    #define VhighCNT1_Ch18              (*(volatile  UINT16 *)0x600728)
    #define VlowCNT1_Ch18               (*(volatile  UINT16 *)0x60072A)

    // Pulse couting read/write registers
    struct st_fpga_pulsecounting
    {
      union{
        UINT16 nReadCounter;
        UINT16 nSetFilter;
      };
        UINT16 nClrCounter;
    };

    #define PC_READBACK_REGS             ((volatile st_fpga_pulsecounting *)0x600820)
    #define PC_CHANNEL1                   15
    #define PC_CHANNEL2                   16
    #define PC_CHANNEL3                   17
    #define PC_CHANNEL4                   18

#elif HEK
    #define MODNUM         ((*(volatile UINT8 *)0x080000))
    #define P_CPLDR02      (*(volatile  un_cpld_rd *)0x080002)
    #define P_CPLDR04      (*(volatile  un_cpld_rd *)0x080004)
    #define P_CPLDR06      (*(volatile  un_cpld_rd *)0x080006)
    #define CPLD_REVLETTER (*(volatile UINT8 *)0x080008)
    #define CPLD_REVNUMBER (*(volatile UINT8 *)0x080009)
    #define HART_MUXADDR   (*(volatile UINT16 *)0x080010)
    #define HART_MUXENBL   (*(volatile un_hmuxenbl *)0x080012)
    #define P_GPR          (*(volatile struct st_gpr *)0x080014)

    #define LED_PINS    P_GPR.B1_0
    #define CLR_RIP_n   P_GPR.B8
    #define RIP_n       !P_GPR.B8
    #define SET_DIP     P_GPR.B9
    #define DIP_n       P_GPR.B9
    #define EEPROM_WP_n P_GPR.B10

    #define OP_DISA_FB_n    P_CPLDR02.B15
    #define OP_DISB_FB1_n   P_CPLDR02.B14
    #define OP_DISB_FB2_n   P_CPLDR02.B13
    #define INHST2_FB       P_CPLDR02.B12
    #define INHST1_FB1      P_CPLDR02.B11
    #define INHST1_FB2      P_CPLDR02.B10
    #define TST             P_CPLDR02.B9
    #define INHIN_FB_n      P_CPLDR02.B8
    #define STBYMAN         P_CPLDR04.B15
    #define GIIS_IOTA       P_CPLDR04.B14
    #define BUPREQ_FB       P_CPLDR04.B13
    #define GHOXXX          P_CPLDR04.B12
    #define JABLOCK_n       P_CPLDR04.B11
#if !defined(IOPTYPE_SCIOM)
// PMIO redesign has inverted signals    
    #define BOTTOM          !P_CPLDR04.B9  //FTASEC- 
#else
    #define BOTTOM          P_CPLDR04.B9    
#endif
    #define BUPREQ_IN       P_CPLDR04.B10
    #define REDUNT_n        P_CPLDR04.B8
    #define GOODINPUT       P_CPLDR06.B13
    #define CALIBRATE       P_CPLDR06.B12
    #define FACTCAL         P_CPLDR06.B11
    #define OVERVT_n        P_CPLDR06.B10
    #ifdef IOMTYPE_AIH
        #define ADC_CLK     P_CPLDR06.B8
    #endif
    #ifdef IOMTYPE_AOH
        #define AOPWR_MON   P_CPLDR06.B9
        #define ANALOG_RDBK P_CPLDR06.B8
    #endif
    #ifdef IOMTYPE_LLMUX
        #define FTA_PWR     P_CPLDR06.B11
    #endif
    
    inline void WriteStrobe() {;}  // CPLD Write Strobe is for LOWCOST AO. Stub is necessary for AOH.

#ifdef IOMTYPE_LLMUX
    const UINT8  NO_OF_FTA = 4;
    const UINT32 FTA_UART[NO_OF_FTA] = { 0x400000,
                                         0x400010,
                                         0x400020,
                                         0x400030 
    };
    #define FTA_UART(n)            (*(volatile struct st_fpga_uart *)FTA_UART[n])
    #define FTA_BAUDRATE_REGISTER  (*(volatile struct st_fpga_brg *)0x400050)

    const UINT8 FTA_UART_8BITS_PER_CHAR      = 0x03;
    const UINT8 FTA_UART_LINE_STS_ERROR_BITS = 0x1E;
#else
    const UINT8  HARTMODEM_COUNT  = 4;
    const UINT32 HART_UART[HARTMODEM_COUNT] = { 0x400000,
                                                0x400010,
                                                0x400020,
                                                0x400030 
    };
    const UINT8 HART_INTR_PENDING_MASK  = 0x01;
    const UINT8 HART_XMTINTR_ENABLE     = 0x02; // Enable XMT hold register empty interrupt
    const UINT8 HART_RCVINTR_ENABLE     = 0x09; // Enables RcvData and ModemStatus interrupts
    const UINT8 HART_RCVERROR_PRESENT   = 0x1E; // Break, framing, parity or overrun error.
    #define HART_UART(n)            (*(volatile struct st_fpga_uart *)HART_UART[n])
    #define HART_BAUDRATE_REGISTER  (*(volatile struct st_fpga_brg *)0x400050)
#endif

    #define UART_LITE   (*(volatile struct st_fpga_uartlite *)0x400040)
    #define FPGA_ISR    (*(volatile union un_fpga_bytebits *)0x400060)
    #define FPGA_INTFL_WDTO  FPGA_ISR.B6
    #define FPGA_INTFL_SPI   FPGA_ISR.B5
    #define FPGA_INTFL_UART4 FPGA_ISR.B4
    #define FPGA_INTFL_UART3 FPGA_ISR.B3
    #define FPGA_INTFL_UART2 FPGA_ISR.B2
    #define FPGA_INTFL_UART1 FPGA_ISR.B1
    #define FPGA_INTFL_UART0 FPGA_ISR.B0

    //Interrupt source mask
    const UINT8 FPGA_INTFL_WDTO_MASK    = 0x40;
    const UINT8 FPGA_INTFL_SPI_MASK     = 0x20;
    const UINT8 FPGA_INTFL_UART4_MASK   = 0x10;
    const UINT8 FPGA_INTFL_UART3_MASK   = 0x08;
    const UINT8 FPGA_INTFL_UART2_MASK   = 0x04;
    const UINT8 FPGA_INTFL_UART1_MASK   = 0x02;
    const UINT8 FPGA_INTFL_UART0_MASK   = 0x01;
    //UART Interrupt Ids
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
    const UINT8 INTR_ID_RXLINESTATUS = 0x06;
    const UINT8 INTR_ID_RXDATAAVLBLE = 0x04;
    const UINT8 INTR_ID_CHARTIMEOUT  = 0x0C;
    const UINT8 INTR_ID_TXHLDRGEMPTY = 0x02;
    const UINT8 INTR_ID_MODEMSTATUS  = 0x00;
#else
    const UINT8 INTR_ID_RXLINESTATUS = 0x03;
    const UINT8 INTR_ID_RXDATAAVLBLE = 0x02;
    const UINT8 INTR_ID_CHARTIMEOUT  = 0x06;
    const UINT8 INTR_ID_TXHLDRGEMPTY = 0x01;
    const UINT8 INTR_ID_MODEMSTATUS  = 0x00;
#endif
    //UART Lite Interrupt Ids
    const UINT8 UARTLITE_PAR_ERROR_MASK    = 0x80;
    const UINT8 UARTLITE_FRAME_ERROR_MASK  = 0x40;
    const UINT8 UARTLITE_OVERUN_ERROR_MASK = 0x20;
    const UINT8 UARTLITE_RCVERROR_MASK     = 0xE0;
    const UINT8 UARTLITE_INTR_ENABLED_MASK = 0x10;
    const UINT8 UARTLITE_TX_FIFO_FULL_MASK = 0x08;
    const UINT8 UARTLITE_TX_FIFO_EMPTY_MASK= 0x04;
    const UINT8 UARTLITE_RX_FIFO_FULL_MASK = 0x02;
    const UINT8 UARTLITE_RX_FIFO_VALID_DATA_MASK = 0x01;
    // FPGA Miscellaneous definitions
    #define FPGA_REVLETTER (*(volatile UINT8 *)0x400070)
    #define FPGA_REVNUMBER (*(volatile UINT8 *)0x400071)

    #define WIGLPVCR    (*(volatile struct st_fpga_wcr *)0x400080)
    // Open wire detection (OWD) feature is implemented using the
    // hardware originally meant for doing SIL wiggle tests on input.
    #define OWD_CSEL    WIGLPVCR.CSEL
    #define OWD_ENB     WIGLPVCR.ENB

    #define INPSEL      (*(volatile UINT8 *)0x4000A0)
    // FPGA Analog Output Control Register definitions
    #define OCWR        (*(volatile union un_fpga_bytebits *)0x400080)
    #define TST_n       OCWR.B4
    #define INH_SWB     OCWR.B3
    #define INH_SWA     OCWR.B2
    #define DIS_SWB_n   OCWR.B1
    #define DIS_SWA_n   OCWR.B0
    #define OUTSEL      (*(volatile UINT8 *)0x400090)
    #define UKEY        (*(volatile UINT8 *)0x400091)

    #define ADC_SPI     (*(volatile struct st_fpga_spi *)0x4000B0)
    #define DAC_SPI     (*(volatile struct st_fpga_spi *)0x4000B0)
    #define EEPROM_SPI  (*(volatile struct st_fpga_spi *)0x4000B0)
    #define SPIRESET    (*(volatile UINT8 *)0x4000B1)
    // Slave select constants
    const UINT8 SS_ADCSPI   = 0xFE;
    const UINT8 SS_DACSPI   = 0xFE;
    const UINT8 SS_EEPROM   = 0xFD;
    const UINT8 SS_DESELECT = 0xFF;
    // SPI FIFO interrupt definitions 
    const UINT8 SPI_TX_FIFO_EMPTY_MASK= 0x04;
    const UINT8 SPI_RX_FIFO_EMPTY_MASK= 0x01;
    const UINT8 SPI_RX_FIFO_RESET_MASK= 0x40;

    const UINT8 SPI_EEPROM_WIP        = 0x01;
#endif  // HEK

// DTC register definition
typedef struct tagDTC_PARM{
  union{
    unsigned char BYTE;
    struct{
      unsigned char SM:2;
      unsigned char DM:2;
      unsigned char MD_DTS:3;
      unsigned char SZ:1;
    }BIT;
  }MRA;
  unsigned char SAR_H;
    unsigned int  SAR_L;
  union{
    unsigned char BYTE;
    struct{
      unsigned char CHNE:1;
      unsigned char DISEL:1;
      unsigned char WK:6;
    }BIT;
  }MRB;
  unsigned char DAR_H;
    unsigned int  DAR_L;
  unsigned int  CRA;
  unsigned int  CRB;
}DTC_PARM;

/* Location of DTC registers */
const unsigned long DTC_PARM_LOC = 0xFFFBC0;
#define P_DTCPARM  (*(volatile DTC_PARM   *)DTC_PARM_LOC)

// DTC registers
#define DTCIOL_SARH     P_DTCPARM.SAR_H
#define DTCIOL_SARL     P_DTCPARM.SAR_L
#define DTCIOL_DARH     P_DTCPARM.DAR_H
#define DTCIOL_DARL     P_DTCPARM.DAR_L
#define DTCIOL_CRA      P_DTCPARM.CRA
#define DTCIOL_CRB      P_DTCPARM.CRB
#define DTCIOL_DM       P_DTCPARM.MRA.BIT.DM
#define DTCIOL_MD_DTS   P_DTCPARM.MRA.BIT.MD_DTS
#define DTCIOL_SM       P_DTCPARM.MRA.BIT.SM
#define DTCIOL_SZ       P_DTCPARM.MRA.BIT.SZ
#define DTCIOL_CHNE     P_DTCPARM.MRB.BIT.CHNE
#define DTCIOL_DISEL    P_DTCPARM.MRB.BIT.DISEL

// IOL
#define IOL_SMR       P_SCI_IOL.SMR.BYTE
#define IOL_BRR       P_SCI_IOL.BRR
#define IOL_SCR       P_SCI_IOL.SCR.BYTE
#define IOL_TDR       P_SCI_IOL.TDR
#define IOL_SSR       P_SCI_IOL.SSR.BYTE
#define IOL_RDR       P_SCI_IOL.RDR
#define IOL_SCMR      P_SCI_IOL.SCMR.BYTE
#define IOL_CA        P_SCI_IOL.SMR.BIT.CA
#define IOL_CHR       P_SCI_IOL.SMR.BIT.CHR
#define IOL_PE        P_SCI_IOL.SMR.BIT.PE
#define IOL_OE        P_SCI_IOL.SMR.BIT.OE
#define IOL_STOP      P_SCI_IOL.SMR.BIT.STOP
#define IOL_MP        P_SCI_IOL.SMR.BIT.MP
#define IOL_CKS       P_SCI_IOL.SMR.BIT.CKS
#define IOL_TIE       P_SCI_IOL.SCR.BIT.TIE
#define IOL_RIE       P_SCI_IOL.SCR.BIT.RIE
#define IOL_TE        P_SCI_IOL.SCR.BIT.TE
#define IOL_RE        P_SCI_IOL.SCR.BIT.RE
#define IOL_MPIE      P_SCI_IOL.SCR.BIT.MPIE
#define IOL_TEIE      P_SCI_IOL.SCR.BIT.TEIE
#define IOL_CKE       P_SCI_IOL.SCR.BIT.CKE
#define IOL_TDRE      P_SCI_IOL.SSR.BIT.TDRE
#define IOL_RDRF      P_SCI_IOL.SSR.BIT.RDRF
#define IOL_ORER      P_SCI_IOL.SSR.BIT.ORER
#define IOL_FER       P_SCI_IOL.SSR.BIT.FER
#define IOL_PER       P_SCI_IOL.SSR.BIT.PER
#define IOL_TEND      P_SCI_IOL.SSR.BIT.TEND
#define IOL_MPB       P_SCI_IOL.SSR.BIT.MPB
#define IOL_MPBT      P_SCI_IOL.SSR.BIT.MPBT
#define IOL_SDIR      P_SCI_IOL.SCMR.BIT.SDIR
#define IOL_SINV      P_SCI_IOL.SCMR.BIT.SINV
#define IOL_SMIF      P_SCI_IOL.SCMR.BIT.SMIF

#if !(LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_UIOBOOT) || defined(IOMTYPE_UIO))    // SCI0
#define IOL_VECTOR_ERI  80
#define IOL_VECTOR_RXI  81
#define IOL_VECTOR_TXI  82
#define IOL_VECTOR_TEI  83
#else  // LOWCOST,Pulse Input, UIO -- SCI2
#define IOL_VECTOR_ERI  88
#define IOL_VECTOR_RXI  89
#define IOL_VECTOR_TXI  90
#define IOL_VECTOR_TEI  91
#endif

#define GHO_IRQ0E   P_INTC.IER.BIT.IRQ0E
#define GHO_IRQ0F   P_INTC.ISR.BIT.IRQ0F
#define GHO_IRQ0SC    P_INTC.ISCR.BIT.IRQ0SC
#define IOL_ALERT_RCVD  IOL_MPB
#define IOL_ALERT_XMIT  IOL_MPBT
const unsigned char GHO_DISABLED = 0;
const unsigned char GHO_ENABLED = 1;
const unsigned char GHO_RESET = 0;
const unsigned char GHO_SET = 1;
const unsigned char GHO_NOTINGAP = 0;
const unsigned char GHO_INGAP = 1;
const unsigned char IRQ_SC_LOW = 0;
const unsigned char IRQ_SC_FALLING = 1;
const unsigned char IRQ_SC_RISING = 2;
const unsigned char IRQ_SC_EDGES = 3;
const unsigned char IOL_RDRF_RESET = 0;
const unsigned char IOL_RDRF_SET = 1;
const unsigned char IOL_XMTR_ENABLED = 1;
const unsigned char IOL_XMTR_DISABLED = 0;
const unsigned char IOL_TDRE_RESET = 0;
const unsigned char IOL_TDRE_SET = 1;
const unsigned char IOL_ALERT_RESET = 0;
const unsigned char IOL_ALERT_SET = 1;
const unsigned char IOLDRV_ON = 0;
const unsigned char IOLDRV_OFF = 1;
const unsigned char JABLOCK_ASSERTED = 0;
const unsigned char JABLOCK_NEGATED = 1;

#define IRQ1_ENABLE     P_INTC.IER.BIT.IRQ1E
#define IRQ1_STATUS     P_INTC.ISR.BIT.IRQ1F
#define IRQ1_SENSECTL   P_INTC.ISCR.BIT.IRQ1SC


#define IRQ3_ENABLE     P_INTC.IER.BIT.IRQ3E
#define IRQ3_STATUS     P_INTC.ISR.BIT.IRQ3F
#define IRQ3_SENSECTL   P_INTC.ISCR.BIT.IRQ3SC

// IOTA definitions
const UINT8 ACTIVE = TRUE;
const UINT8 NOTACTIVE = FALSE;
const UINT8 UPPER = FALSE;
const UINT8 LOWER = TRUE;
const UINT8 RCVSEL_CHANNELA = FALSE;
const UINT8 RCVSEL_CHANNELB = TRUE;

#endif //#ifdef IOMTYPE_SVP

#endif
