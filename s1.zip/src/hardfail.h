/*
COPYRIGHT (C) 2015
Honeywell Measurex (Ireland) Limited

ALL RIGHTS RESERVED
This software is a copyrighted work and/or information protected as a trade
secret.  Legal rights of Honeywell Measurex (Ireland) Limited in this software
is distinct from ownership of any medium in which the software is embodied.
Copyright or trade secret notices included must be reproduced in any document.
*/

/**
    @file
    @brief defines the HARDFAILTYPE enumeration
*/

#if !defined (HARDFAIL_H)
#define HARDFAIL_H

/**
    @brief defines the Series-C hardfail type codes

    These enumerators must align with the Experion database definitions located in
    /db/src/IOLIM/pm_iomlhfst.enm.xml.
*/
typedef enum tagHardfailType {
    HF_UNKNOWN              = 0,   ///< UNKNOWN HARD FAILURE
    HF_POWERDOWN            = 1,   ///< POWER DOWN OCCURED
    HF_INVPROGRAMEXEC       = 2,   ///< INVALID PROGRAM EXECUTION
    HF_EPROMCHKERROR        = 3,   ///< EPROM CHECKSUM ERROR
    HF_RAMCONTERROR         = 4,   ///< RAM CONTENTS ERROR
    HF_RAMADDRERROR         = 5,   ///< RAM ADDRESS DECODING ERROR
    HF_DPAERROR             = 6,   ///< DEVICE PHYSICAL ADDRESS ERROR
    HF_DSAERROR             = 7,   ///< DEVICE SOFT ADDRESS ERROR
    HF_RCVBUFOVERFLOW       = 8,   ///< IOL RCV BUF OVRFLW
    HF_IOLJABBERFIRED       = 9,   ///< IOLINK JABBER CKT FIRED
    HF_SRAMFAIL             = 10,  ///< SRAM FAILURE
    HF_BADPROGRAMJUMP       = 11,  ///< ILLEGAL VALUE OF CASE CONTROL
    HF_ADCINCOMPLETE        = 12,  ///< A/D CONVERSION INCOMPLETE
    HF_ADOUTOVERFLOW        = 13,  ///< A/D CONVERSION VALUE OVERFLOW
    HF_ADOUTUNDERFLOW       = 14,  ///< A/D CONVERSION VALUE <= ZERO
    HF_ADCCALIBERROR        = 15,  ///< ADC CALIBRATION INCORRECT
    HF_BADDCLTC             = 16,  ///< BAD DC LTC
    HF_DMCTIMEOUT           = 17,  ///< DEAD MAN TIMER TIMEOUT
    HF_MULTIPLEOUTPUT       = 18,  ///< MULTIPLE OUTPUT FAILURES
    HF_PIDATBUSDIAG         = 19,  ///< PI DATA BUS DIAG TEST FAILURE
    HF_BADDARANGE           = 20,  ///< BAD D/A RANGE
    HF_MASTERTIMEOUT        = 21,  ///< 68K TIMEOUT
    HF_UM51WATCHDOG         = 22,  ///< UM51 WATCHDOG TIMER TIMED OUT
    HF_COUNTERCIRCUIT       = 23,  ///< IOP COUNTER CIRCUIT FAILURE
    HF_SOECOUNTERFAIL       = 24,  ///< SOE COUNTER FAILURE
    HF_OUTPUTCONTROL        = 25,  ///< OUTPUT CONTROL HW FAIL
    HF_BD_OUTPUT_MUX        = 26,  ///< AO OUTPUT MUX failure
    HF_APPCRCFAIL           = 27,  ///< APP CRC failure indicates bad APP image
    HF_PSCODEMISMATCH       = 28,  ///< PS Code image does not compare to F-ROM
    HF_PARITYHWFAIL         = 29,  ///< Parity detction hardware is not working
    HF_TASKSTACKSTART       = 30,  ///< Can't find stack bottom at task creation time
    HF_STACKOVERRURN        = 31,  ///< Task stack exhausted and overrun memory
    HF_WDTTIMEOUT           = 32,  ///< Task's Watch Dog Timer Timeout
    HF_ILLEGALWRITE         = 33,  ///< Illegal Write to FROM
    HF_PARITYERROR          = 34,  ///< Parity Error with FROM
    HF_IOMUSERRESET         = 35,  ///< IOM Resetted after Push Button is pressed.
    HF_ZEROREFFAIL          = 36,  ///< Zero reference check failed
    HF_REFINPFAIL           = 37,  ///< One of the reference input checks failed
    HF_FPGARDBKFAIL         = 38,  ///< FPGA Readback failure
    HF_PSISOPUFAIL          = 39,  ///< Failure of PI Isolated power supply on power up
    HF_TCRAMDIAGFAIL        = 40,  ///< Failure of FPGA RAM Diagnostics
    HF_TCCAPSEMPHOREFAIL    = 41,  ///< Failure of Capture Semaphore.
    HF_TCCPUDIAGFAIL        = 42,  ///< CPU Regster Dianostics failure.
    HF_TCILLEGALISR         = 43,  ///< For all Illegal ISRs
    HF_TCDATABUSERROR       = 44,  ///< DATA BUS ERROR
    HF_TCAPPIOTAERROR       = 45,  ///< APP BOARD AND IOTA INTEGRITY ERROR
    HF_TCAPPBOARDPOWERR     = 46,  ///< APP BOARD POWER FAILURE
    HF_TCEXTRAMCONTERROR    = 47,  ///< EXTERNAL RAM CONTENTS ERROR
    HF_TCKERNALPOWERFAIL    = 48,  ///< KERNAL POWER SUPPLY FAILURE
    HF_TCCPLD_VER_FAIL      = 49,  ///< CPLD VER FAILURE
    HF_TCPARITYFAIL         = 50,  ///< PARITY  Failure on APP processor
    HF_TCXREADYFAIL         = 51,  ///< Xready and/or Wait_n failure on APP Processor
    HF_TCLVDTADCFAIL        = 52,  ///< LVDT ADC Bus failure on APP Processor
    HF_TCDACRBFAIL          = 53,  ///< Servo DAC read back failure on APP Processor
    HF_TCAPPWDTTIMEOUT      = 54,  ///< Task's Application Processor Watch Dog Timer Timeout
    HF_AODACFAIL            = 55,  ///< AO Channel DAC failure
    HF_FPGAIRQFAIL          = 56,  ///< FPGA IRQ failure
    HF_OSCFAIL              = 57,  ///< Failure of 10MHz Application oscillator
    HF_COUNTERFAIL          = 58,  ///< Pulse Input Counter Failed
    HF_FIRSTUNUSEDENUM      = 59   ///< Unused hard fail enumeration range starts from here
} HARDFAILTYPE;

#endif // HARDFAIL_H
