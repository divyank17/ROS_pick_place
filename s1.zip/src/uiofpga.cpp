/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uiofpga.cpp                                                 *
*    Description : UIO FPGA object source file                                 *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "uiofpga.hpp"
#include "boxslot.hpp" // included for MAXSLOTS definition

/*******************************************************************************
*                                  DEFINITIONS                                 *
*******************************************************************************/

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/

// scan request registers
volatile st_fpga_io_scanrequest * const clsUioFpga::pScanReqRegister[] =
{
    &ADC_SR_L,
    &ADC_SR_U
};

// status registers
volatile st_fpga_statusword * const clsUioFpga::pStatusRegister[] =
{
    &RD_STATUSWORD_L,
    &RD_STATUSWORD_U
};

// DAC registers
volatile UINT16 * const clsUioFpga::pDacRegister[] =
{
    DAC_OP_L,
    DAC_OP_U
};

// digital output registers
volatile UINT16 * const clsUioFpga::pDoRegister[] =
{
    &DO_SO_0_7,
    &DO_SO_8_15,
    &DO_SO_16_23,
    &DO_SO_24_31
};

// Reference voltages taken from UIO Cookbook 2/20/2012
const clsUioFpga::RefVoltageValueTableEntry clsUioFpga::ReferenceVoltageLimits[] =
{
         0,      0,   // eBoardVoltage0
         0,      0,   // eBoardVoltage1
    0x1B09, 0x27B5,   // e3V3BoardVoltage
    0x03A2, 0x04F1,   // eNeg8VBoardVoltage
    0x05A2, 0x0711,   // eNeg12V5BoardVoltage
    0x0F55, 0x18EF,   // e24VBoardVoltage
         0,      0,   // eVersionNr
         0,      0,   // eBoardVoltage7
         0,      0,   // eBoardVoltage8
         0,      0,   // eAD_Tst
         0,      0,   // eBoardVoltage10
         0,      0,   // eVtest
    0x68E0, 0x9720,   // eNeg2V5BoardVoltage
    0x2D58, 0x2F39,   // e4V096BoardVoltage
    0xFC38, 0xFEB8,   // eNeg5VrBoardVoltage
         0,      0    // eBoardVoltage15
};

// Digital Input DAC settings
const UINT16 clsUioFpga::kDigitalInputDacCountHigh = FPGA.MilliampsToDacCount(7.0);
const UINT16 clsUioFpga::kDigitalInputDacCountLow  = FPGA.MilliampsToDacCount(3.5);
const UINT16 clsUioFpga::kPulseCountDacCountHigh   = FPGA.MilliampsToDacCount(20.0);
/*******************************************************************************
*                                 RUNTIME ASSERT                               *
*******************************************************************************/

#define USE_RUNTIME_ASSERT (1) // 0: disable, 1: enable

#if USE_RUNTIME_ASSERT
  #define assert(x) ((x) ? (void)0 : HardFail(HF_BADPROGRAMJUMP, UIOFPGA_CPP, __LINE__))
#else
  #define assert(x) // do nothing, runtime assert is disabled
#endif

/*******************************************************************************
*                              PerformStartupInit                              *
*                                  ==========                                  *
* PURPOSE:   initializes the FPGA hardware at startup                          *
*            - clears the output DACs, sets all channels to the safe state     *
*            - enables the SMOD OptoFETs                                       *
*            - <JRF ToDo> TBD - initializes the digital thermometer            *
*            - <JRF ToDo> TBD - initializes the HART modems                    *
* ARGUMENTS: None                                                              *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::PerformStartupInit(VOID)
{
    // Initialize the DAC outputs to 0mA
    ClearDACs();

    // put all channels into the unconfigured safe state
    for (unsigned int chanNum = 1; chanNum <= MAXSLOTS; chanNum++)
    {
        ConfigureChannel(chanNum, PNTTYPE_NOTCONFIGURED);
    }

    // enable the SMOD OptoFETs
    DriveOptoFETs(TRUE);

    // setup SPI and the digital thermometer
    InitSpi();
    ConfigureThermometer(kDefaultThermConfig);
}

/*******************************************************************************
*                               ConfigureChannel                               *
*                                  ==========                                  *
* PURPOSE:   configures the FPGA I/O hardware for one channel for the          *
*            specified point type                                              *
* ARGUMENTS: chanNum - one-relative channel number                             *
*            pntType - PNTTYPE enumerator specifying the channel type          *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::ConfigureChannel(UINT8 chanNum, PNTTYPE pntType)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));

    // process according to the PNTTYPE
    switch (pntType)
    {
        case PNTTYPE_NOTCONFIGURED:
            {
                // put this channel into the unconfigured safe state

                // turn digital output off
                WriteDigitalOutput(chanNum, FALSE);

                // set DAC to 0%
                DriveDAC(chanNum, 0);
            }
            break;

        case PNTTYPE_ANALOGINPUT:
            {
                // configure channel for analog input

                // turn digital output off
                WriteDigitalOutput(chanNum, FALSE);

                // set DAC to 100% on
                DriveDAC(chanNum, 0x0FFF);
            }
            break;

        case PNTTYPE_ANALOGOUTPUT:
            {
                // configure channel for analog output

                // turn digital output off
                WriteDigitalOutput(chanNum, FALSE);

                // set DAC to 0%
                DriveDAC(chanNum, 0);
            }
            break;

        case PNTTYPE_DIGITALINPUT:
            {
                // configure channel for digital input

                // turn digital output off
                WriteDigitalOutput(chanNum, FALSE);

                // set DAC to 7mA
                SetDigitalInputDacHigh(chanNum);
            }
            break;

        case PNTTYPE_DIGITALOUTPUT:
            {
                // configure channel for digital output

                // turn digital output off
                WriteDigitalOutput(chanNum, FALSE);

                // set DAC to 0%
                DriveDAC(chanNum, 0);
            }
            break;

        default:
            {
                // invalid or unsupported PNTTYPE
                HardFail(HF_BADPROGRAMJUMP, UIOFPGA_CPP, __LINE__);
            }
            break;
    }
}

/*******************************************************************************
*                               IssueScanRequest                               *
*                                  ==========                                  *
* PURPOSE:   requests ADC scan on the specified I/O board                      *
* ARGUMENTS: ioBoard - enumerator specifying the I/O board                     *
*            scanType - enumerator specifying the type of scann requested      *
*            chanReqMask - mask specifying the channels to be scanned          *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::IssueScanRequest(IOBOARD ioBoard, SCANTYPE scanType, UINT16 chanReqMask)
{
    assert(ioBoard < eMaxNumIoBoards);

    // process according to SCANTYPE
    switch (scanType)
    {
        case eFilteredAnalogCurrent:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->fRB_ACurrent = chanReqMask;
            }
            break;

        case eFilteredPartialAnalogCurrent:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->fRB_ACurrentP = chanReqMask;
            }
            break;

        case eAnalogCurrent:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->RB_ACurrent = chanReqMask;
            }
            break;

        case eDigitalCurrent:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->RB_DCurrent = chanReqMask;
            }
            break;

        case eDigitalCurrentAdj:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->RB_DCurrent_Adjust_ComPP = chanReqMask;
            }
            break;

        case eVoltages:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->RB_Voltages = chanReqMask;
            }
            break;

        case eCtrlChInd:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->Ctrl_Ch_Independence = chanReqMask;
            }
            break;

        case eClrResultReg:
            {
                // request the scan by writing the mask to the FPGA register
                pScanReqRegister[ioBoard]->Clr_Result_Reg = chanReqMask;
            }
            break;

        default:
            // invalid SCANTYPE
            HardFail(HF_BADPROGRAMJUMP, UIOFPGA_CPP, __LINE__);
            break;
    }
}

/*******************************************************************************
*                                IsScanComplete                                *
*                                  ==========                                  *
* PURPOSE:   returns completion status of the previously issued scan request   *
* ARGUMENTS: ioBoard - enumerator specifying the I/O board                     *
* RETURN:    TRUE - scan has completed                                         *
*            FALSE - scan is in progress                                       *
* NOTES:     return is valid for the last scan request that was issued on the  *
*            specified I/O board                                               *
*******************************************************************************/
BOOL clsUioFpga::IsScanComplete(IOBOARD ioBoard)
{
    assert(ioBoard < eMaxNumIoBoards);
    return (pStatusRegister[ioBoard]->ADC_RDY != 0) ? TRUE : FALSE;
}

/*******************************************************************************
*                                 IsDacFifoFull                                *
*                                  ==========                                  *
* PURPOSE:   returns FIFO status for the output DACs                           *
* ARGUMENTS: ioBoard - enumerator specifying the I/O board                     *
* RETURN:    TRUE - output DAC FIFO is full                                    *
*            FALSE - output DAC FIFO is not full                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsUioFpga::IsDacFifoFull(IOBOARD ioBoard)
{
    assert(ioBoard < eMaxNumIoBoards);
    return (pStatusRegister[ioBoard]->DAC_FIFO_FULL != 0) ? TRUE : FALSE;
}

/*******************************************************************************
*                               ReadDigitalInput                               *
*                                  ==========                                  *
* PURPOSE:   reads digital input for the specified channel                     *
* ARGUMENTS: chanNum - one-relative channel number                             *
* RETURN:    BOOL - ADC read converted to TRUE/FALSE digital input value       *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsUioFpga::ReadDigitalInput(UINT8 chanNum, BOOL bLastRead)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));

    BOOL bDigitalRead = FALSE;
    UINT16 uRawAdc = 0;

    // read the raw ADC count from the hardware
    uRawAdc = Read_fRB_ACurrent(chanNum);

    // convert the raw ADC count to digital On/Off
    if (uRawAdc >= kDiMinOnThreshold)
    {
        bDigitalRead = TRUE;
    }
    else if (uRawAdc < kDiMaxOffThreshold)
    {
        bDigitalRead = FALSE;
    }
    else
    {
        // raw ADC value is in the "deadband", return same as last read
        bDigitalRead = bLastRead;
    }

    return bDigitalRead;
}

/******************************************************************************
*                               ReadDigitalOutput                             *
*                               =================                             *
* PURPOSE:                                                                    *
*   Reads the digital output value for the specified channel.                 *
* ARGUMENTS:                                                                  *
*   chanNum - one-relative channel number                                     *
* RETURN:                                                                     *
*   Returns TRUE if the signal is ON; Returns FALSE if the signal is off.     *
* NOTES:                                                                      *
*   This reads from the DO output register; No A/D conversion is performed.   *
*   A/D conversions are performed to check for open-wire, short circuit, and  *
*   output failure conditions.                                                *
*******************************************************************************/
BOOL clsUioFpga::ReadDigitalOutput(UINT8 chanNum)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));
    
    // Register Value
    u_fpga_digital_output locDO;
    
    // Channel Mask
    UINT8 chanMask = 0x01 << ((chanNum - 1) % BYTESIZE);
    
    // Register Number
    UINT8 DoSoReg = ((chanNum - 1) / BYTESIZE);

    // SO value
    BOOL soValue = FALSE;
    
    // Read the register 
    locDO.word = *(pDoRegister[DoSoReg]);
    
    if ((locDO.byte.SO & chanMask) > 0)
    {
        soValue = TRUE;
    }
    
    return soValue;
}

/******************************************************************************
*                             TestDigitalOutputPins                           *
*                               =================                             *
* PURPOSE:                                                                    *
*   Checks the last commanded DO signals from the H8 match the output from    *
*   the FPGA. This tests the FPGA and is not a readback from the screws.      *
* ARGUMENTS:                                                                  *
*   None.                                                                     *
* RETURN:                                                                     *
*   Returns a bitstring where '1' means the pin comparison failed for that    *
*   channel (channel 32 is MSB, channel 1 is LSB).                            *
* NOTES:                                                                      *
*   This reads from the DO output register.                                   *
*******************************************************************************/
UINT32 clsUioFpga::TestDigitalOutputPins(VOID)
{  
    // Register Value
    u_fpga_digital_output locDO;
    UINT32 failedPins = 0;

    // Read a DO register then compare the upper byte (FPGA output pins)
    // to the lower byte (commanded outputs from H8 as received by FPGA).
    for (unsigned int DoSoReg = 0; DoSoReg < eMaxNumDoSoRegs; DoSoReg++)
    {
        locDO.word = *(pDoRegister[DoSoReg]);
        failedPins |= (((UINT32)(locDO.byte.mask ^ locDO.byte.SO)) << (DoSoReg* BYTESIZE));
    }

    // Return any differences as a bistring.
    return failedPins;
}

/*******************************************************************************
*                             WriteDigitalOutputAll                            *
*                                  ==========                                  *
* PURPOSE:   writes digital outputs for the specified channels                 *
* ARGUMENTS: chanMask - mask specifying the channels to be written             *
*            SO - bit-packed digital output values                             *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::WriteDigitalOutputAll(UINT32 chanMask, UINT32 SO)
{
    for (unsigned int DoSoReg = 0; DoSoReg < eMaxNumDoSoRegs; DoSoReg++)
    {
        UINT8 shiftSize   = DoSoReg * BYTESIZE;
        UINT8 locChanMask = (UINT8)(chanMask >> shiftSize);
        UINT8 locSO       = (UINT8)(SO >> shiftSize);

        // write to the hardware, if changes are applicable to this register
        if (locChanMask != 0)
        {
            DriveDo((DOSOREGISTER)DoSoReg, locChanMask, locSO);
        }
    }
}

/*******************************************************************************
*                              WriteDigitalOutput                              *
*                                  ==========                                  *
* PURPOSE:   writes digital output for the specified channel                   *
* ARGUMENTS: chanNum - one-relative channel number                             *
*            bSO - ON/OFF digital output value                                 *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::WriteDigitalOutput(UINT8 chanNum, BOOL bSO)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));

    // get the register number
    UINT8 DoSoReg = ((chanNum - 1) / BYTESIZE);

    // form the channel mask and the SO mask
    UINT8 chanMask = 0x01 << ((chanNum - 1) % BYTESIZE);
    UINT8 uSO = (bSO) ? chanMask : 0;

    // write to the hardware
    DriveDo((DOSOREGISTER)DoSoReg, chanMask, uSO);
}

/*******************************************************************************
*                           IsAboveNanEnterThreshold                           *
*                                  ==========                                  *
* PURPOSE:   returns if the last converted analog input value is above         *
*            the limit which is expressed as NaN (-24%).                       *
* ARGUMENTS: chanNum - one-relative channel number                             *
* RETURN:    TRUE - greater than specified NaN threshold                       *
*            FALSE - below the Nan threshold                                   *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsUioFpga::IsAboveNanEnterThreshold(UINT8 chanNum)
{
    return ( Read_fRB_ACurrent(chanNum) > kEnterNaNThreshold );
}

/*******************************************************************************
*                             IsAboveNanExitThreshold                          *
*                                  ==========                                  *
* PURPOSE:   returns if the last converted analog input value is above the     *
*            deadband allowing the process value to maked as no longer NaN     *
* ARGUMENTS: chanNum - one-relative channel number                             *
* RETURN:    TRUE - greater than specified NaN threshold plus deadband         *
*            FALSE - below the Nan threshold plus deadband                     *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsUioFpga::IsAboveNanExitThreshold(UINT8 chanNum)
{
    return ( Read_fRB_ACurrent(chanNum) > kExitNaNThreshold );
}

/*******************************************************************************
*                              Read4v096Averaged                               *
*                              =================                               *
* PURPOSE:                                                                     *
* Read the ADC count for the 4v096 board voltage multiple times and return the *
* averaged ADC count from those samples.                                       *
*                                                                              *
* ARGUMENTS:                                                                   *
* ioBoard = specifies which I/O board should be calibrated                     *
* iter = number of iterations (ADC samples) to read and average                *
*                                                                              *
* RETURN:                                                                      *
* The averaged ADC count.                                                      *
*                                                                              *
* NOTES:                                                                       *
* The ADC count for the 4v096 board voltage will be read as many times as      *
* specified, plus two more samples.  From the sample population, the outliers  *
* (1 highest ADC count and 1 lowest ADC count) are discarded and the remaining *
* counts ADC counts are combined into an average.  This average is returned.   *
*******************************************************************************/
UINT16 clsUioFpga::Read4v096Averaged(IOBOARD ioBoard, int iter)
{
    UINT32 adc_accum   = 0;
    UINT16 adc_lowest  = 0xFFFF;
    UINT16 adc_highest = 0;

    for (int i = 0; i < iter + 2; i++)
    {
        UINT16 adc_read = 0;

        // issue scan request for the 4.096V ref
        IssueScanRequest(ioBoard, eVoltages, (0x0001 << e4V096BoardVoltage));
        while (!IsScanComplete(ioBoard));

        // read the result
        adc_read = Read_BoardVoltage(ioBoard, e4V096BoardVoltage);

        // update ADC count accumulation
        adc_accum += adc_read;

        // update the 'lowest' statistic
        if (adc_read < adc_lowest)
        {
            adc_lowest = adc_read;
        }

        // update the 'highest' statistic
        if (adc_read > adc_highest)
        {
            adc_highest = adc_read;
        }
    }

    // discard the highest and lowest ADC results
    adc_accum -= (adc_highest + adc_lowest);

    // generate the average
    return (UINT16)(((FLOAT32)adc_accum + 0.5f) / iter); // +0.5 for proper rounding
}

/*******************************************************************************
*                                CoarseCalibrate                               *
*                               =================                              *
* PURPOSE:                                                                     *
* The coarse calibration routine is executed during startup as the first step  *
* toward full calibration of the I/O boards.  As the name indicates, this      *
* routine is not expected to generate a finely-calibrated I/O board, rather    *
* the goal is to get close to good calibration with a relatively simple        *
* algorithm.                                                                   *
*                                                                              *
* ARGUMENTS:                                                                   *
* ioBoard = specifies which I/O board should be calibrated                     *
*                                                                              *
* RETURN:                                                                      *
* None.                                                                        *
*                                                                              *
* NOTES:                                                                       *
* This method uses successive iterations of linear approximation to calibrate  *
* the specified I/O board.  The relationship between the -5V reference         *
* (measured through the 4v096 board voltage) and the trimmer DAC is measured   *
* and approximated by a linear equation.  This operation is performed          *
* successively, each time with a smaller window (the DAC/ADC points used to    *
* create the linear equation get closer and closer).                           *
*                                                                              *
* Once the successive iterations have completed, the -5V reference voltage     *
* trimmer DAC is set to the coarse-calibrated DAC count.  This leaves the I/O  *
* board in a proper state for the fine calibration steps to proceed.           *
*******************************************************************************/
void clsUioFpga::CoarseCalibrate(IOBOARD ioBoard)
{
    const int kCoarseCalibIters = 3;  // number of coarse calibration iterations
    const int kWindowSize = 0x200;    // initial DAC window size for linear approximation
    const int kWindowReducFactor = 4; // window reduction factor for successive iterations
    const int kAdcSamples = 32;       // number of ADC samples to be averaged

    UINT16 calibWindow = kWindowSize;
    UINT16 dac_result = lastDacCount[ioBoard];

    for (int i = 0; i < kCoarseCalibIters; i++)
    {
        UINT16 dac0 = dac_result + calibWindow;
        UINT16 dac1 = dac_result - calibWindow;

        // set the DAC and read the ADC
        DriveFiveVoltRefDAC(ioBoard, dac0);
        IdleWait(kStartupDAConversionTime);
        UINT16 adc0 = Read4v096Averaged(ioBoard, kAdcSamples);

        // set the DAC and read the ADC
        DriveFiveVoltRefDAC(ioBoard, dac1);
        IdleWait(kStartupDAConversionTime);
        UINT16 adc1 = Read4v096Averaged(ioBoard, kAdcSamples);

        // generate the linear equation constants
        // y = m*x + b, where y = DAC and x = ADC
        FLOAT32 m = ((FLOAT32)dac1 - (FLOAT32)dac0) / ((FLOAT32)adc1 - (FLOAT32)adc0);
        FLOAT32 b = (FLOAT32)dac0 - (m * (FLOAT32)adc0);

        // calculate the 'ideal' DAC value based on this linear approximation
        dac_result = (UINT16)(m * kTargetCalibAdcCount + b + 0.5f); // +0.5 for rounding

        // reduce the window for the next iteration
        calibWindow = calibWindow / kWindowReducFactor;
    }

    // finally, set the reference voltage DAC to the calibrated value
    lastDacCount[ioBoard] = dac_result;
    DriveFiveVoltRefDAC(ioBoard, lastDacCount[ioBoard]);
    IdleWait(kStartupDAConversionTime);
}

/*******************************************************************************
*                               RuntimeCalibrate                               *
*                               ================                               *
* PURPOSE:                                                                     *
* The runtime calibration routine checks the provided ADC count for the 4v096  *
* board voltage, and modifies the I/O board calibration if needed.             *
*                                                                              *
* ARGUMENTS:                                                                   *
* ioBoard = specifies which I/O board should be calibrated                     *
* adc_4v096 = ADC count for the 4v096 board voltage                            *
*                                                                              *
* RETURN:                                                                      *
* 'TRUE' if the -5V reference voltage is within the target calibration range   *
* and does not need to be tuned.                                               *
* 'FALSE' if the -5V reference voltage is outside the target calibration range *
* and calibration tuning has been performed.                                   *
*                                                                              *
* NOTES:                                                                       *
* This method is executed at runtime, therefore it must not be disruptive.  As *
* such, the -5V reference DAC is only modified by one count at a time.  If a   *
* larger adjustment is required to maintain good calibration, it is achieved   *
* through multiple executions of this method.                                  *
*******************************************************************************/
BOOL clsUioFpga::RuntimeCalibrate(IOBOARD ioBoard, UINT16 adc_4v096)
{
    assert(ioBoard < eMaxNumIoBoards);

    BOOL bCalibrated = FALSE;
    int error = kTargetCalibAdcCount - adc_4v096;

    // handle too much positive error
    if (error > kCalibAdcThreshold)
    {
        // ADC result is too low, decrease the DAC
        if (lastDacCount[ioBoard] > kMinCalibDacCount)
        {
            lastDacCount[ioBoard]--;
            DriveFiveVoltRefDAC(ioBoard, lastDacCount[ioBoard]);
            IdleWait(kDAConversionTime);
        }
    }

    // handle too much negative error
    else if (error < -kCalibAdcThreshold)
    {
        if (lastDacCount[ioBoard] < kMaxCalibDacCount)
        {
            // ADC result is too high, increase the DAC
            lastDacCount[ioBoard]++;
            DriveFiveVoltRefDAC(ioBoard, lastDacCount[ioBoard]);
            IdleWait(kDAConversionTime);
        }
    }

    // no need to adjust, the board is now calibrated
    else
    {
        bCalibrated = TRUE;
    }

    return bCalibrated;
}

/*******************************************************************************
*                               StartupCalibrate                               *
*                               ================                               *
* PURPOSE:                                                                     *
* Calibrate the I/O hardware during startup and initialization.  Because this  *
* occurs during startup (not during runtime), this routine is allowed to take  *
* a long time to finely calibrate the board.                                   *
*                                                                              *
* ARGUMENTS:                                                                   *
* ioBoard = specifies which I/O board should be calibrated                     *
*                                                                              *
* RETURN:                                                                      *
* 'TRUE' if calibration completes successfully, otherwise 'FALSE'.             *
*                                                                              *
* ARGUMENTS:                                                                   *
* ioBoard = specifies which I/O board should be calibrated                     *
*                                                                              *
* NOTES:                                                                       *
* This method will calibrate the -5V reference voltage of the specified I/O    *
* board.  At startup, the -5V reference voltage will not be accurate and       *
* therefore needs to be calibrated.  This -5V reference voltage is used for    *
* precise input and output, for both analog and digital channel types.         *
*                                                                              *
* The -5V reference voltage is monitored indirectly by measuring the 4v096     *
* board voltage.  When the ADC conversion of the 4v096 board voltage is equal  *
* to 0x2E49, the -5V reference voltage is determined to be ideally calibrated. *
* The -5V reference voltage (and consequently the 4v096 board voltage) can be  *
* trimmed, and brought into good calibration, by setting the -5V reference     *
* DAC.  This DAC is the control used to bring the -5V reference into good      *
* calibration.                                                                 *
*                                                                              *
* Details about this -5V reference voltage and the calibration circuit can be  *
* found in section 3.1.15.3 of the RIO MDR 6552.                               *
*                                                                              *
* This method uses the 'CoarseCalibrate' method to get close to the target     *
* calibration range.  Afterwards, the 'RuntimeCalibrate' method is executed    *
* repeatedly until the I/O board is brought into the target calibration range. *
* The 'RuntimeCalibrate' method will be executed a maximum of 32 times.  If    *
* the I/O board cannot be calibrated in 32 iterations or less, the startup     *
* calibration is determined to be 'failed', and this function return 'FALSE'.  *
*******************************************************************************/
BOOL clsUioFpga::StartupCalibrate(IOBOARD ioBoard)
{
    assert(ioBoard < eMaxNumIoBoards);

    const int kAdcSamples = 32;     // number of ADC samples to be averaged
    int uiRemainingIters = 32;      // number of allowed calibration iterations
    BOOL bIsCalibrated = FALSE;

    // first, perform a coarse calibration
    CoarseCalibrate(ioBoard);

    // second, do the runtime calibration as needed to fine-calibrate
    do
    {
        // read the ADC
        UINT16 adc_read = Read4v096Averaged(ioBoard, kAdcSamples);

        // check the calibration and adjust as needed
        bIsCalibrated = RuntimeCalibrate(ioBoard, adc_read);

        uiRemainingIters--;
    }
    while (!bIsCalibrated && (uiRemainingIters > 0));

    TraceLog.AddToTrace(TRACEID_GENERIC, bcCalibrationComplete,
        (UINT32)ioBoard << 24 | (UINT32)bIsCalibrated << 16 | (32 - uiRemainingIters));

    return bIsCalibrated;
}

/*******************************************************************************
*                              DriveFiveVoltRefDAC                             *
*                                  ==========                                  *
* PURPOSE:   write raw dac count to the FPGA for the five volt ref adjust      *
* ARGUMENTS: ioBoard - enumerator specifying the I/O board                     *
*            uDacCount - raw DAC count                                         *
* RETURN:    None                                                              *
* NOTES:     DAC is 12-bit                                                     *
*******************************************************************************/
VOID clsUioFpga::DriveFiveVoltRefDAC(IOBOARD ioBoard, UINT16 uDacCount)
{
    (pDacRegister[ioBoard])[ADJ_5V0_REF_IDX] = 0x0FFF & uDacCount;
}

/*******************************************************************************
*                                  ClearDACs                                   *
*                                  ==========                                  *
* PURPOSE:   clears the DAC FIFO on each I/O board                             *
* ARGUMENTS: None                                                              *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::ClearDACs(VOID)
{
    CLR_DACs_L = 0;
    CLR_DACs_U = 0;
}

/*******************************************************************************
*                                   DriveDo                                    *
*                                  ==========                                  *
* PURPOSE:   writes digital output values to the FPGA                          *
* ARGUMENTS: DoSoReg - enumerator specifying the digital output register       *
*            chanMask - mask specifying the channels to be written             *
*            uSO - bit-packed digital output values                            *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::DriveDo(DOSOREGISTER DoSoReg, UINT8 chanMask, UINT8 uSO)
{
    u_fpga_digital_output locDO;

    // fill the structure
    locDO.byte.mask = chanMask;
    locDO.byte.SO   = uSO;

    // write to the FPGA according to DoSoReg
    *(pDoRegister[DoSoReg]) = locDO.word;
}

/*******************************************************************************
*                                 DriveOptoFETs                                *
*                                  ==========                                  *
* PURPOSE:   enables/disables the Secondary Mode of Disconnect OptoFETs        *
* ARGUMENTS: bEn - desired ON/OFF state of the OptoFETs                        *
* RETURN:    None                                                              *
* NOTES:     Pass1 hardware has inverted SMOD OptoFET logic, therefore we      *
*            check for Pass1 hardware and invert the bEn flag in order to      *
*            correctly set the control register                                *
*******************************************************************************/
VOID clsUioFpga::DriveOptoFETs(BOOL bEn)
{
    u_fpga_misc_flipflop locFF;

    // check for Pass1 hardware, which will have an invalid HwRevLetter
    UINT8 HwRevLetter = HARDWARE_REVCODE & HWINFO_REVLETTER_MASK;
    if ((HwRevLetter < REVLETTER_A) || (HwRevLetter > REVLETTER_Z))
    {
        // invert to support Pass1 inverted SMOD logic
        bEn = !bEn;
    }

    // setup the mask and value fields
    locFF.byte.mask  = SMOD_MASK;
    locFF.byte.value = (bEn) ? SMOD_MASK : 0;

    // write to the hardware
    MISCFLIPFLOPCR = locFF.word;
}

/*******************************************************************************
*                                   ResetSPI                                   *
*                                  ==========                                  *
* PURPOSE:   resets the FPGA's SPI interface                                   *
* ARGUMENTS: None                                                              *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioFpga::ResetSPI(VOID)
{
    u_fpga_misc_flipflop locFF;

    // setup the mask and value fields
    locFF.byte.mask  = SPI_RST_MASK;
    locFF.byte.value = SPI_RST_MASK;

    // write to the hardware
    MISCFLIPFLOPCR = locFF.word;
}

/*******************************************************************************
*                              AreRefVoltagesGood                              *
*                                  ==========                                  *
* PURPOSE:   checks all board reference voltages are within predefined ranges  *
* ARGUMENTS: ioBoard - enumerator specifying the I/O board                     *
* RETURN:    BOOL  - pass (TRUE) or fail (FALSE) of all voltage checks         *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsUioFpga::AreRefVoltagesGood(IOBOARD ioBoard)
{
    assert(ioBoard < eMaxNumIoBoards);

    BOOL bRefIsGood = TRUE;
    UINT16 ulRefVoltageMask;
    unsigned int idx = 0;
    UINT16 uRawADC = 0;

    for(ulRefVoltageMask = 1; idx < eMaxNumBoardVoltages; idx++,ulRefVoltageMask <<= 1)
    {
        if(SCAN_REF_VOLTAGES & ulRefVoltageMask)
        {
            uRawADC = Read_BoardVoltage(ioBoard, idx);

            // check if the reference voltage is outside the acceptable operating range
            // if so mark the test as failed and do not check the remaining voltages
            if((uRawADC < ReferenceVoltageLimits[idx].MinAdcCount) || (uRawADC > ReferenceVoltageLimits[idx].MaxAdcCount))
            {
                bRefIsGood = FALSE;
                break;
            }
        }
    }

    return bRefIsGood;
}

/*******************************************************************************
*                              IsShortCircuit                                  *
*                              ==============                                  *
* PURPOSE:                                                                     *
*   Checks to see if a short circuit condition exists for a DO channel.        *
* ARGUMENTS:                                                                   *
*   chanOn  - Flag used to indicate if the channel is on                       *
*   chanNum - one-relative channel number                                      *
* RETURN:                                                                      *
*   TRUE if short circuit condition exists; Otherwise returns FALSE            *
* NOTES:                                                                       *
*   Scan request for RB ACurrent must be issued before calling this function.  *
*******************************************************************************/
BOOL clsUioFpga::IsShortCircuit(BOOL chanOn, UINT8 chanNum)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));
   
    // Measured analog current
    UINT16 aCurrent = Read_RB_ACurrent(chanNum);
    
    // Flag used to indicate if a short circuit exists
    BOOL shortCircuitExists = FALSE;
         
    if (chanOn)
    {
        // If the measured analog current is greater than the threshold,
        // a short exists.
        if (aCurrent > kDoACurrentLow)
        {        
            shortCircuitExists = TRUE;
        }
    }
    
    return shortCircuitExists;
}

/*******************************************************************************
*                               IsOpenWireDO                                   *
*                               ============                                   *
* PURPOSE:                                                                     *
*   Checks to see if an open wire condition exists for a DO channel.           *
* ARGUMENTS:                                                                   *
*   chanOn  - Flag used to indicate if the channel is on                       *
*   chanNum - one-relative channel number                                      *
* RETURN:                                                                      *
*   TRUE open wire condition exists; Otherwise returns FALSE                   *
* NOTES:                                                                       *
*   Scan requests for RB ACurrent and RB DCurrent must be issued before        *
*   calling this function.                                                     *
*******************************************************************************/
BOOL clsUioFpga::IsOpenWireDO(BOOL chanOn, UINT8 chanNum)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));
    
    // Flag used to indicate if an open wire condition exists
    BOOL openWireExists = FALSE;
    
    // Measured analog current
    UINT16 aCurrent = Read_RB_ACurrent(chanNum);
    
    // Measured digital current
    UINT16 dCurrent = Read_RB_DCurrent(chanNum);
    
    if (chanOn)
    {
        // Channel has been commanded on...
        if ((dCurrent < kDoOnReadbackThreshold) && (aCurrent < kDoACurrentLow))
        {
            openWireExists = TRUE;
        }
    }
    else
    {
        // Channel has been commanded off...
        if ((dCurrent < kDoOffReadbackThreshold) && (aCurrent < kDoACurrentLow))
        {
            openWireExists = TRUE;
        }
    }

    return openWireExists;
}

/*******************************************************************************
*                             IsOutputFailureDO                                *
*                             =================                                *
* PURPOSE:                                                                     *
*   Compares the expected state of a DO channel to the actual state at the     *
*   screws.  If expected state does not match the actual state, an output      *
*            failure exists.                                                   *
* ARGUMENTS:                                                                   *
*   chanOn  - Flag used to indicate if the channel is on                       *
*   chanNum - one-relative channel number                                      *
* RETURN:                                                                      *
*   TRUE if output failure exists; Otherwise returns FALSE                     *
* NOTES:                                                                       *
*   Scan requests for RB ACurrent and RB DCurrent must be issued before        *
*   calling this function.                                                     *
*******************************************************************************/
BOOL clsUioFpga::IsOutputFailureDO(BOOL chanOn, UINT8 chanNum)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));
    
    // Flag used to indicate if an output failure exists
    BOOL outputFailExists = FALSE;
    
    // Measured analog current
    UINT16 aCurrent = Read_RB_ACurrent(chanNum);
    
    // Measured digital current
    UINT16 dCurrent = Read_RB_DCurrent(chanNum);
        
 
    if (chanOn)
    {
        // Channel has been commanded on
        if ((dCurrent < kDoOnReadbackThreshold) && (aCurrent < kDoACurrentLow))
        {
            outputFailExists = TRUE;
        }
    }
    else
    {
        // Channel has been commanded off
        if (dCurrent > kDoOffReadbackThreshold)
        {
            outputFailExists = TRUE;
        }
    }

    return outputFailExists;
}

/******************************************************************************
*                         EnableHartTransmitter                               *
*                         =====================                               *
* PURPOSE:                                                                    *
*   Enables/disables the HART transmitter for the specified channel           *
* ARGUMENTS:                                                                  *
*   chanNum - one-relative channel number                                     *
*   enable  - Flag used to indicate if the transmitter should be enabled or   *
*             disabled.                                                       *
* RETURN:                                                                     *
*   None                                                                      *
* NOTES:                                                                      * 
*   None                                                                      *
******************************************************************************/
VOID clsUioFpga::EnableHartTransmitter(UINT8 chanNum, BOOL enable)
{    
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));
    
    // Local copy of the HART control register to write
    un_cpld_fpga_wordbits hartControlReg;
    
    // Zero it out...
    hartControlReg.FPGAWORDREG = 0;
    
    switch(GetChannelIoBoard(chanNum))
    {
        case eIoBoard1:
            hartControlReg.B2  = (enable) ? 0 : 1;
            hartControlReg.B10 = 1;
            break;
        
        case eIoBoard2:
            hartControlReg.B3  = (enable) ? 0 : 1;
            hartControlReg.B11 = 1;
            break;
        
        default:
            // Unknown board
            HardFail(HF_BADPROGRAMJUMP, UIOFPGA_CPP, __LINE__);
            break;
    }
       
    // Update HARTCR in the FPGA
    HARTCR.FPGAWORDREG = hartControlReg.FPGAWORDREG;    
}

/*******************************************************************************
*                   clsUioFpga::ConfigureHartAmplifierGain                     *
*                   ======================================                     *
* PURPOSE:                                                                     *
*    Configures the amplifier gain based on the connected channel (AI or AO)   *
* ARGUMENTS:                                                                   *
*    a_ChanNum - one-relative channel number                                   *
*    a_PntType - PNTTYPE of the channel (either AI or AO)                      *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
VOID clsUioFpga::ConfigureHartAmplifierGain(UINT8 a_ChanNum, PNTTYPE a_PntType)
{
    assert((a_ChanNum > 0) && (a_ChanNum <= MAXSLOTS));
    assert((PNTTYPE_ANALOGINPUT == a_PntType) || (PNTTYPE_ANALOGOUTPUT == a_PntType));

    // set AI mode according to the PNTTYPE
    unsigned int aiMode = (PNTTYPE_ANALOGINPUT == a_PntType) ? 1 : 0;

    // set gain on the proper modem for this channel
    if (GetChannelModem(a_ChanNum) == 0)
    {
        MODEM0_AI = aiMode;
    }
    else
    {
        MODEM1_AI = aiMode;
    }
}

/******************************************************************************
*                              SetHartAddress                                 *
*                              ==============                                 *
* PURPOSE:                                                                    *
*   Sets the address bits for the HART multiplexer                            *
* ARGUMENTS:                                                                  *
*   chanNum - one-relative channel number                                     *
* RETURN:                                                                     *
*   None                                                                      *
* NOTES:                                                                      * 
*   None                                                                      *
******************************************************************************/
VOID clsUioFpga::SetHartAddress(UINT8 chanNum)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));
    
    // Representation of a HART address register (P, S)
    un_cpld_fpga_wordbits hartAddrP;
    un_cpld_fpga_wordbits hartAddrS;
    
    UINT16 usAddr = chanNum - 1;
    
    switch (GetChannelModem(chanNum))
    {
        //---------------------------------------
        // Modem 0 (Channels 1 - 16)
        //---------------------------------------
        case 0:
            
            usAddr = usAddr & 0x000f;
            
            // Update HART address register P
            hartAddrP.HO_MA_7_4 = usAddr;
            hartAddrP.HI_MA_3_0 = 0;
            hartAddrP.WD7_4     = 1;
            hartAddrP.WD3_0     = 0;
            
            // Update HART address register S
            hartAddrS.HO_MA_7_4 = 0;
            hartAddrS.HI_MA_3_0 = usAddr;
            hartAddrS.WD7_4     = 0;
            hartAddrS.WD3_0     = 1;
            
            break;
            
        //---------------------------------------
        // Modem 1 (Channels 17 - 32)
        //---------------------------------------
        case 1:
            
            usAddr = (~(usAddr - 16)) & 0x000f;
            
            // Update HART address register P
            hartAddrP.HO_MA_7_4 = 0;
            hartAddrP.HI_MA_3_0 = usAddr;
            hartAddrP.WD7_4     = 0;
            hartAddrP.WD3_0     = 1;
            
            // Update HART address register S
            hartAddrS.HO_MA_7_4 = usAddr;
            hartAddrS.HI_MA_3_0 = 0;
            hartAddrS.WD7_4     = 1;
            hartAddrS.WD3_0     = 0;
            
            break;
        
        default:
        
            // We should not get here...UIO only supports 2 (two) modems
            HardFail(HF_BADPROGRAMJUMP,UIOFPGA_CPP,__LINE__);
            break;
    }
    
    // Write to the address registers in the FPGA
    HART_ADD_REG_P.FPGAWORDREG = hartAddrP.FPGAWORDREG;
    HART_ADD_REG_S.FPGAWORDREG = hartAddrS.FPGAWORDREG;
}

/******************************************************************************
*                           IsHartCommInProgress                              *
*                           ====================                              *
* PURPOSE:                                                                    *
*   Checks to see if HART communication is in progress for the given channel  *
* ARGUMENTS:                                                                  *
*   chanNum - one-relative channel number                                     *
* RETURN:                                                                     *
*   TRUE if communication is in progress; otherwise FALSE                     *
* NOTES:                                                                      * 
*   None                                                                      *
******************************************************************************/
BOOL clsUioFpga::IsHartCommInProgress(UINT8 chanNum)
{
    assert((chanNum > 0) && (chanNum <= MAXSLOTS));
    
    // Representation of a HART address register (P, S)
    un_cpld_fpga_wordbits hartAddrP;
    un_cpld_fpga_wordbits hartAddrS;
    
    hartAddrP.FPGAWORDREG = HART_ADD_REG_P.FPGAWORDREG;
    hartAddrS.FPGAWORDREG = HART_ADD_REG_S.FPGAWORDREG;
    
    // Assume no communication is in progress
    BOOL communicationInProgress = FALSE;
    
    // Modem for the given channel
    UINT8 modem = GetChannelModem(chanNum);
    
    // Current state of the modem
    HMODEMSTATE modemState = pHartModem[modem]->GetModemState();
        
    if ((modemState == HMODEMSTATE_XMTING) ||
        (modemState == HMODEMSTATE_RCVING))
    {
        // The modem is active.  Find out which channel is busy.
        
        UINT16 modemAddress = chanNum - 1;
        
        switch(modem)
        {
            case 0:
            
                modemAddress = modemAddress & 0x000f;
                
                if ((modemAddress == hartAddrP.HO_MA_7_4) &&
                    (modemAddress == hartAddrS.HI_MA_3_0))
                {
                    communicationInProgress = TRUE;
                }
                
                break;
                
            case 1:
                
                modemAddress = (~(modemAddress - 16)) & 0x000f;
                
                if ((modemAddress == hartAddrP.HI_MA_3_0) &&
                    (modemAddress == hartAddrS.HO_MA_7_4))
                {
                    communicationInProgress = TRUE;
                }
                
                break;
                
            default:
            
                // We should not get here...UIO only supports 2 (two) modems
                HardFail(HF_BADPROGRAMJUMP,UIOFPGA_CPP,__LINE__);
                break;
        }
    }
    
    return communicationInProgress;
}

/******************************************************************************
*                         IsHartAddressRegisterValid                          *
*                         ==========================                          *
* PURPOSE:                                                                    *
*   Checks to see if the value written to the HART address registers for the  *
*   given modem matches the value read back from the FPGA.                    *
* ARGUMENTS:                                                                  *
*   modem - zero-relative modem number
* RETURN:                                                                     *
*   None                                                                      *
* NOTES:                                                                      * 
*   None                                                                      *
******************************************************************************/
BOOL clsUioFpga::IsHartAddressRegisterValid(UINT8 modem)
{    
    // Representation of a HART address register (P, S)
    un_cpld_fpga_wordbits hartAddrP;
    un_cpld_fpga_wordbits hartAddrS;
    
    // Flag used to indicate if the address registers are valid
    BOOL valid = FALSE;
    
    hartAddrP.FPGAWORDREG = HART_ADD_REG_P.FPGAWORDREG;
    hartAddrS.FPGAWORDREG = HART_ADD_REG_S.FPGAWORDREG;
    
    switch(modem)
    {
        // Modem 0 (Channels 1 - 16)
        case 0:

            if ((hartAddrP.HO_MA_15_12 == hartAddrP.HO_MA_7_4) &&
                (hartAddrS.HI_MA_11_8  == hartAddrS.HI_MA_3_0))
            {
                valid = TRUE;
            }
            
            break;
            
        // Modem 1 (Channels 17 - 32)
        case 1:
            
            if ((hartAddrP.HI_MA_11_8  == hartAddrP.HI_MA_3_0) &&
                (hartAddrS.HO_MA_15_12 == hartAddrS.HO_MA_7_4))
            {
                valid = TRUE;
            }
                               
            break;
            
        default:
            // We should never get here
            HardFail(HF_BADPROGRAMJUMP,UIOFPGA_CPP,__LINE__);
            break;
    }
    
    return valid;  
}

/*******************************************************************************
*                                   InitSpi                                    *
*                                  ==========                                  *
* PURPOSE:   Configures the SPI controller in the FPGA for communication with  *
*            the Dallas Semiconductor DS1722 digital thermometer               *
* ARGUMENTS: None                                                              *
* RETURN:    None                                                              *
* NOTES:     See the Xilinx rs01-1999-0229 specification for config details    *
*******************************************************************************/
VOID clsUioFpga::InitSpi(VOID)
{
    // reset the SPI controller
    THERM_SPI_RESET = 0x00; // write resets the SPI controller, the value does not matter

    // configure the SPI controller
    THERM_SPI.SetCRL(CRL_ManualSlaveSelect_MASK |   // enable manual slave select
                     CRL_ClockPhaseInv_MASK |       // inverted CLK phase
                     CRL_MasterMode_MASK |          // enable Master mode
                     CRL_SpiSystemEnable_MASK);     // enable the SPI interface

    // clear the Master Transaction inhibit flag
    THERM_SPI.ClearMasterInhibit();
}

/*******************************************************************************
*                             ConfigureThermometer                             *
*                                  ==========                                  *
* PURPOSE:   Configures the Dallas Semiconductor DS1722 digital thermometer    *
* ARGUMENTS: a_kConfigByte - configuration byte for the thermometer            *
* RETURN:    None                                                              *
* NOTES:     see the Dallas Semiconductor DS1722 datasheet for config details  *
*******************************************************************************/
VOID clsUioFpga::ConfigureThermometer(const UINT8 a_kConfigByte)
{
    UINT8 ConfigRead = 0;

    // reset the FIFOs
    THERM_SPI.ClearRxFifo();
    THERM_SPI.ClearTxFifo();

    // send configuration byte to the thermometer
    THERM_SPI.AssertSlaveSelect0();
    THERM_SPI.SendByte(kThermAddrWriteConfig);  // send the config write address
    THERM_SPI.SendByte(a_kConfigByte);          // send the config byte
    while (!THERM_SPI.IsTxFifoEmpty());         // wait for transmit FIFO to clear
    THERM_SPI.DeassertSlaveSelect();

    // readback the thermometer configuration
    ReadThermometer(&ConfigRead);
    if (a_kConfigByte != ConfigRead)
    {
        HardFail(HF_INVPROGRAMEXEC, UIOFPGA_CPP, __LINE__);
    }
}

/*******************************************************************************
*                                ReadThermometer                               *
*                                  ==========                                  *
* PURPOSE:   Reads the configuration byte and temperature from the thermometer *
* ARGUMENTS: a_pConfigByte - out-parameter for the configuration byte, this    *
*               argument may be omitted (default value is NULL)                *
* RETURN:    FLOAT32 - current temperature expressed in degrees celsius        *
* NOTES:     see the Dallas Semiconductor DS1722 datasheet for details         *
*******************************************************************************/
FLOAT32 clsUioFpga::ReadThermometer(UINT8 * const a_pConfigByte)
{
    FLOAT32 temperature = NaN;
    UINT16 u16Temperature = 0;
    uThermRead ThermRead;
    ThermRead.dword = 0;

    // reset the FIFOs
    THERM_SPI.ClearRxFifo();
    THERM_SPI.ClearTxFifo();

    // read the configuration and temperature from the thermometer
    THERM_SPI.AssertSlaveSelect0();
    THERM_SPI.SendByte(kThermAddrReadConfig);   // send the config read address
    THERM_SPI.SendByte(0x00);                   // transmit a zero byte to clock-in the configuration byte
    THERM_SPI.SendByte(0x00);                   // transmit a zero byte to clock-in the temperature LSB
    THERM_SPI.SendByte(0x00);                   // transmit a zero byte to clock-in the temperature MSB
    while (!THERM_SPI.IsTxFifoEmpty());         // wait for transmit FIFO to clear
    THERM_SPI.DeassertSlaveSelect();

    // read continuously from the Rx FIFO until the Rx FIFO is empty
    while (!THERM_SPI.IsRxFifoEmpty())
    {
        ThermRead.dword <<= BYTESIZE;
        ThermRead.dword |= THERM_SPI.RecvByte();
    }

    // compute the temperature in degrees Celsius.
    // The temperature MSB contains whole degrees Celsius, while the temperature LSB
    // contains the hexidecimal fraction of a whole degree Celsius. Therefore, 1�C is
    // represented by 0x0100. We must divide by 0x0100 (decimal 256) to normalize the
    // temperature to whole degrees Celsius.
    //  - combine the temperature bytes from the thermometer
    //  - evaluate as a signed integer, divide by 256 to normalize to whole degrees celsius
    u16Temperature = ((UINT16)ThermRead.bytes.TempMSB << BYTESIZE) | ThermRead.bytes.TempLSB;
    temperature = ((INT16)u16Temperature) / 256.0;

    // provide the configuration byte, if required
    if (NULL != a_pConfigByte)
    {
        *a_pConfigByte = ThermRead.bytes.ConfigByte;
    }

    return temperature;
}

/******************************************************************************
*                   clsUioFpga::InitializeHardwareForPulseCount               *
*                          ==================================                 *
* PURPOSE:Sets the Voltage and Filter for the pulse counting channel          *
* ARGUMENTS:                                                                  *
*   ChanNum - channel number                                                  *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
******************************************************************************/
VOID clsUioFpga::InitializeHardwareForPulseCount(UINT8 ChanNum)
{
    switch(ChanNum)
    {
       case PC_CHANNEL1:
           VhighCNT1_Ch15 = kThresholdHighConfig;
           VlowCNT1_Ch15  = kThresholdLowConfig;
         break;
       case PC_CHANNEL2:
           VhighCNT1_Ch16 = kThresholdHighConfig;
           VlowCNT1_Ch16  = kThresholdLowConfig;
         break;
       case PC_CHANNEL3:
           VhighCNT1_Ch17 = kThresholdHighConfig;
           VlowCNT1_Ch17  = kThresholdLowConfig;
         break;
       case PC_CHANNEL4:
           VhighCNT1_Ch18 = kThresholdHighConfig;
           VlowCNT1_Ch18  = kThresholdLowConfig;
         break;
       default:
         break;
    }

    BOX->StoreAvRaw(ChanNum,0);
    ClrCounter(ChanNum);
}

