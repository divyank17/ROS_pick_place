/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcsvpregctlslot.hpp                                         *
*    Description : Class clsSvpRegCtlSlot declarations.                       *
*******************************************************************************/
#ifndef __TCSVPREGCTLSLOT_HPP__
#define __TCSVPREGCTLSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define SVPREGCTL_SLOTSIZE ((sizeof(clsSvpRegCtlSlot) + (sizeof(clsSvpRegCtlSlot) % 2)) / 2)

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SVPREGCTL_SYNC_VER_1;

#define SVPREGCTL_OPEXHILM      (FLOAT32)106.9
#define SVPREGCTL_OPEXLOLM      (FLOAT32)-6.9

const FLOAT32  kSmallestEuSpan     = 0.001;
const FLOAT32  kHundred            = 100;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
// control equation
enum enmCtlEqn
{
    kCtlEqnA = 0, 
    kCtlEqnB = 1, 
    kCtlEqnC = 2, 
    kCtlEqnD = 3, 
    kCtlEqnE = 4, 
    kCtlEqnF = 5, 
    kCtlEqnG = 6,
    kCtlEqnSISO = 7
};

struct CtlEqnInfo
{
    BOOL         HasPropTerm;
    BOOL         HasIntegTerm;
    BOOL         HasDerivTerm;
};

enum enmGainOpt
{
    kLinGain    = 0, 
    kGapGain    = 1
};

//lint -esym(14,kMaxGainOpt) suppress message Symbol 'kMaxGainOpt' previously defined 
static const    int kMaxGainOpt = 3;

enum enmEqnEUnitsOpt
{
   kEUs                 = 0,
   kPercent             = 1
};

enum enmCtlActn{
    kDirectCtlActn  =0,
    kReverseCtlActn =1
};

enum    enmPvTrackOpt
{
    kNoPvTrack  = 0,
    kPvTrack    = 1
};

//Enum for PvSel
typedef enum tagPvSel{
    PVSEL_PV1 =0,
    PVSEL_PV2 =1
}PVSEL;

namespace CF
{

////////////////////////////////////////////////////////////////////////
// enumerations used by Discrete Devices, Reg Control, Data Acq., and Analog I/O Channels:
// enmAccLock (Access Lock) is the enum used to specify who can change a FB's state (such as Flag FB),
// using PV and PVFL

enum enmAccLock
    {
    kOperatorAccess   = 0,
    kEngineerAccess   = 1,
    kOtherFBAccess    = 2
    };

enum enmAccSts    // used for all xx.AccSts variables of SCO FB; also used for TypeConvert FB
    {
    kNoErrorAccSts  = 0,  // final set of members is still TBD
    kCommError      = 1,
    kConfigError    = 2,
    kRangeError     = 3,
    kExprError      = 4,
    kCtrlReqError   = 5,
    kDataTypeError  = 6
    };

enum enmCtlMode
    {
    kManCtlMode     = 0, 
//  SVP IOM :commented the following modes as SVP are supporting Man and Cas modes in SVP IOM
//  kAutoCtlMode    = 1,
    kCasCtlMode     = 2, 
//  SVP IOM :commented the following modes as SVP are supporting Man and Cas modes in SVP IOM
//  kBcasCtlMode    = 3, 
    kNoneCtlMode    = 4, 
    kNormalCtlMode  = 5
    };

// maximum size of enum enmCtlMode
enum {kMaxCtlMode = 3};//5};

enum enmModeAttr 
    {
    kNone   = 0,  //lint !e578
    kOper   = 1,
    kProg   = 2,
    kNormal = 3
    };

// maximum size of enum enmModeAttr
enum {kModeAttrMax = 3};

enum enmPvSource 
    {
       kSub   = 0,
       kMan   = 1,
       kAuto  = 2,
       kTrack = 3
    } ;

// maximum size of enum enmPvSource
enum {kPvSourceMax = 3};


// maximum size of enum enmPvSrcOpt
enum {kPvSourceOptMax = 1};
       
enum enmAlarmDbu
    {
    kPercentDbu = 0,
    kEuDbu = 1
    };

// maximum size of enum enmAlarmDbu
enum {kAlarmDbuMax = 1};

enum enmAlarmPr
    {
    kEmergencyPr = 0,
    kHighPr      = 1,
    kLowPr       = 2,
    kJournalPr   = 3,
    kPrinterPr   = 4,
    kJnlPrintPr  = 5,
    kNoActionPr  = 6
    };

// maximum size of enum enmAlarmPr
enum {kAlarmPrMax = 6};

// Anti-Reset Windup (ARW) Status
enum enmArw
    {
    kNormalArw  = 0, 
    kHiArw      = 1, 
    kLoArw      = 2, 
    kHiLoArw    = 3
    };

// maximum size of enum enmArw
enum {kRegMaxArw = 3};

enum enmEnableSt
    {
    kDisableSt = 0,
    kEnableSt  = 1
    } ;

// maximum size of enum enmEnable
enum {kEnableStMax = 1};

// Override Status
enum enmOvrdStatus
    {
    kNotConnected = 0, 
    kSelected     = 1, 
    kNotSelected  = 2
    };

// maximum size of enum enmOvrdStatus
enum {kMaxOvrdStatus = 2};

enum enmExecState
{
    kInactive= 0,
    kActive  = 1
};

enum enmBadCtlOpt
{
    kNoShed     = 0,
    kShedHold   = 1,
    kShedLow    = 2,
    kShedHigh   = 3,
    kShedSafe   = 4
};

}///CF

enum enmRegCtlClassId
{
  kRegPidClassId         = 1//9,
};


enum    enmCtlState
{
    kFwdCtlState  = 0, 
    kHoldCtlState = 1, 
    kInitCtlState = 2, 
    kManCtlState  = 3
};

enum enmOutInd
{
    kDirect         = 0,
    kReverse        = 1, 
    kDirectDispInd  = 2,
    kReverseDispInd = 3
};

// Mode Permissive
//
enum    enmPermissive
{
    kNotPerm = 0,
    kPermit  = 1 
};

enum    enmValSts
{                           // dir   ValueValid
    kBadValSts          = 0,    // F/B    X  whole data is invalid due to comm error
    kUncertainValSts    = 1,    // F      O
    kNormalValSts       = 2,    // F/B    O
    kManualValSts       = 3,    // F      O
    kInitAckValSts      = 4,    // F      O
    kInitReqValSts      = 5,    // B      O
    kInitBadValSts      = 6     // F/B    X  the focused value (OP,InitVal,..) is bad
};

typedef enum tagAlmDbu{
    PERCENT =0,
    ENGG_UNIT =1

}ALMDBU;

typedef enum tagNumPvSrc{
    NUMPVSRC0 =0,
    NUMPVSRC1 =1,
    NUMPVSRC2 =2
}NUMPVSRC;

typedef enum tagPrefPvSrc{
    PREFPVSRC_NONE =0,
    PREFPVSRC_PVSP_PV_01 =1,
    PREFPVSRC_PVSP_PV_02 =2
}PREFPVSRC;

typedef enum tagEqnEUnitsOpt{
    ENGG_UNITS=0,
    EQN_PERCENT =1
}EQNEUNITSOPT;

/*
     Redundacy dump record structure
*/

struct strSvpRegctlSlotDumpData 
{
    UINT16     Version;     // The first two bytes of dump record should always represent version. Do not change this. 
    PNTTYPE    PntType;
    PTEXECST   PtExecSt;
    CF::enmCtlMode   Mode;
    CF::enmModeAttr  ModeAttr;
    CF::enmCtlMode   NormMode;
    CF::enmModeAttr  NormModeAttr;
    enmPermissive    ModePerm;
    BOOL             Redtag;
    PREFPVSRC        PrefPvSrc;
    FLOAT32          PvEUHi;
    FLOAT32          PvEULo;
    INT32            Pv1ConnectionData;
    INT32            Pv2ConnectionData;
    enmCtlActn       CtlActn;
    enmCtlEqn        CtlEqn;
    FLOAT32          T1;
    FLOAT32          T1HiLm;
    FLOAT32          T1LoLm;
    FLOAT32          T2;
    FLOAT32          T2HiLm;
    FLOAT32          T2LoLm;
    FLOAT32          GainHiLm;
    FLOAT32          GainLoLm;
    FLOAT32          K;   
    EQNEUNITSOPT     EqnEUnitsOpt; 
    FLOAT32          OpHiLm;
    FLOAT32          OpLoLm;
    FLOAT32          OpExHiLm;
    FLOAT32          OpExLoLm;
    FLOAT32          OpMinChg;
    FLOAT32          SafeOp;
    FLOAT32          OpTol;
    enmOutInd        OutInd;
    FLOAT32          Sp;
    FLOAT32          SpTol;
    FLOAT32          SpHiLm;
    FLOAT32          SpLoLm;
    CF::enmCtlMode   TmOutMode;
    UINT32           TmOutTime; 
    INT32            TimeoutCount;
    CF::enmBadCtlOpt BadCtlOpt;
    FLOAT32          CvEuHi;
    FLOAT32          CvEuLo;
    FLOAT32          OpBiasFixed;
    FLOAT32          OpBiasRate;
    FLOAT32          OpBias;
    FLOAT32          OpEu;
    FLOAT32          Op;    
};

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsSvpRegCtlSlot; // forward declaration
typedef struct tagPidSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsSvpRegCtlSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsSvpRegCtlSlot::* PostPtr)(UINT8);
    VOID *   (clsSvpRegCtlSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} PIDSLOTPARAMINFO;

/*******************************************************************************
*                                   clsSvpRegCtlSlot                          *
*                                   ==========                                 *
*******************************************************************************/
class clsCfRegInput
{
public: // data members

    INT32       TimeoutCount;
    UINT32      TimeOutValue ;
    CF::enmArw  ArwNet;
    BOOL        TimeoutFlag;
    BOOL        PrimaryInputHi;
    BOOL        PrimaryInputLo;
    BOOL        PrimaryIsConnected;
    BOOL        PrimaryIsInitializable;
    UINT16      PriOpIndex; 
    PVSEL       PvSel;
    VOID *operator new(UINT32){return NULL;}; 
    VOID operator delete(VOID *){};
};

class clsCfRegOP
{
public: // data members
    FLOAT32        Cv;
    FLOAT32        CvEuHi;
    FLOAT32        CvEuLo;
    FLOAT32        CvEuSpanBy100;
    FLOAT32        Op;
    FLOAT32        OpBiasFixed;
    FLOAT32        OpBiasFloat;
    FLOAT32        OpBiasRate;
    FLOAT32        OpBias;
    FLOAT32        OpEu;
    FLOAT32        NewOp;
    FLOAT32        LastOp;
    INT32          LastOneshotSeqNum; 
    CF::enmArw     LastArwSts;      
    CF::enmArw     ArwOp;

    BOOL           OpExHiFl;
    BOOL           OpExLoFl;
    
    VOID *operator new(UINT32){return NULL;};
    VOID operator delete(VOID *){};
};

class clsSvpRegCtlSlot : public clsIomSlot 
{
protected:
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const PIDSLOTPARAMINFO tblParamInfo[256];
    static UINT8 SvpRegCtlSlotChkpntVersion;
    
    PNTTYPE          PntType;
    PTEXECST         PtExecSt;

    clsCfRegOP       OpData;
    clsCfRegInput    InputData;
   
    CF::enmCtlMode   Mode;
    CF::enmModeAttr  ModeAttr;
    CF::enmCtlMode   NormMode;
    CF::enmModeAttr  NormModeAttr;
    enmPermissive    ModePerm;
    BOOL             Redtag;

    PREFPVSRC        PrefPvSrc;
    FLOAT32          Pv;
    BOOL             BadPvFl;
    FLOAT32          PvEUHi;
    FLOAT32          PvEULo;
    FLOAT32          Pv1;
    FLOAT32          Pv2;
    INT32            Pv1ConnectionData;
    INT32            Pv2ConnectionData;
    FLOAT32          LastGoodPv;

    enmCtlActn       CtlActn;
    enmCtlEqn        CtlEqn;
    FLOAT32          T1;
    FLOAT32          T1HiLm;
    FLOAT32          T1LoLm;
    FLOAT32          T2;
    FLOAT32          T2HiLm;
    FLOAT32          T2LoLm;
    FLOAT32          GainHiLm;
    FLOAT32          GainLoLm;
    enmGainOpt       GainOpt;
    FLOAT32          K;   
    EQNEUNITSOPT     EqnEUnitsOpt; 

    FLOAT32          OpHiLm;
    FLOAT32          OpLoLm;
    FLOAT32          OpExHiLm;
    FLOAT32          OpExLoLm;
    BOOL             OpHiFl;
    BOOL             OpLoFl;
    FLOAT32          OpMinChgLm;
    FLOAT32          SafeOp;
    FLOAT32          OpTol;
    enmOutInd        OutInd;

    enmPvTrackOpt    PvTrakOpt;
    enmPvTrackOpt    PvTrakOptAi;

    FLOAT32          Sp;
    FLOAT32          SpTol;
    FLOAT32          SpHiLm;
    FLOAT32          SpLoLm;
    FLOAT32          SpExEuLo;
    FLOAT32          SpExEuHi;
    FLOAT32          SpEuHi;
    FLOAT32          SpEuLo;
    BOOL             SpHiFl;
    BOOL             SpLoFl;
    BOOL             InitReq;
    CF::enmCtlMode   TmOutMode;
    UINT32           TmOutTime; 

    BOOL             BadCtlFl;
    CF::enmBadCtlOpt BadCtlOpt;

    FLOAT32          InitVal;
    BOOL             InitMan;

    BOOL             CtlInit;
    enmCtlState      CtlState;

    CF::enmArw       ArwOp;
    CF::enmArw       ArwNet;
    CF::enmArw       ArwSts;

    enmValSts        PvSts;
    enmValSts        Pv1Sts;
    enmValSts        Pv2Sts;

    FLOAT32          SecInitVal;
    UINT8            SecStatus;
    CF::enmArw       SecArwSts;

    FLOAT32          PriInitVal;
    UINT8            PriStatus;
    CF::enmArw       PriArwSts;

    REGCTLSHRAMSLOTDATA *pRegCtlShramSlotData;

    VOID InitPidSlot(VOID);

    VOID *GetPntTypePtr(VOID);
    VOID *GetPtExecStPtr(VOID); 
    
    VOID *GetModeAttrPtr(VOID);
    VOID *GetModePtr(VOID);
    VOID *GetNormModeAttrPtr(VOID);
    VOID *GetNormModePtr(VOID);
    VOID *GetModePermPtr(VOID);
    VOID *GetRedTagPtr(VOID);

    VOID *GetPrefPvSrcPtr(VOID);
    VOID *GetPvPtr(VOID);
    VOID *GetBadPvFlPtr(VOID);
    VOID *GetPvEUHiPtr(VOID);
    VOID *GetPvEULoPtr(VOID);
    VOID *GetPv1(VOID);
    VOID *GetPv2(VOID);
    VOID *GetPv1ConnectionDataPtr(VOID);
    VOID *GetPv2ConnectionDataPtr(VOID);
    VOID *GetLastGoodPvPtr(VOID);

    VOID *GetCtlEqnPtr(VOID);   
    VOID *GetCtlActnPtr(VOID);  
    VOID *GetT1Ptr(VOID);       
    VOID *GetT1LoLmPtr(VOID);   
    VOID *GetT1HiLmPtr(VOID);   
    VOID *GetT2Ptr(VOID);       
    VOID *GetT2LoLmPtr(VOID);   
    VOID *GetT2HiLmPtr(VOID);   
    VOID *GetGainLoLmPtr(VOID);   
    VOID *GetGainHiLmPtr(VOID);   
    VOID *GetGainOptPtr(VOID);  
    VOID *GetKPtr(VOID);
    VOID *GetEqnEUnitsOptPtr(VOID);
    
    VOID *GetOpPtr(VOID);      
    VOID *GetOpEuPtr(VOID);    
    VOID *GetOpExLoLmPtr(VOID);
    VOID *GetOpExLoFlPtr(VOID);
    VOID *GetOpExHiLmPtr(VOID);
    VOID *GetOpExHiFlPtr(VOID);
    VOID *GetOpLoLmPtr(VOID);  
    VOID *GetOpLoFlPtr(VOID);  
    VOID *GetOpHiFlPtr(VOID);  
    VOID *GetOpHiLmPtr(VOID);  
    VOID *GetOpMinChgLmPtr(VOID);
    VOID *GetOpTolPtr(VOID);   
    VOID *GetOpBiasPtr(VOID);  
    VOID *GetOpBiasFixPtr(VOID);
    VOID *GetSafeOpPtr(VOID);   
    VOID *GetOpBiasRatePtr(VOID);
    VOID *GetOutIndPtr(VOID);   
    
    VOID *GetPvTrakOptPtr(VOID);
    VOID *GetPvTrakOptAiPtr(VOID);
    
    VOID *GetSpPtr(VOID);    
    VOID *GetSpLoLmPtr(VOID);
    VOID *GetSpLoFlPtr(VOID);
    VOID *GetSpHiLmPtr(VOID);
    VOID *GetSpHiFlPtr(VOID);
    VOID *GetPvSelPtr(VOID);
    VOID *GetOpBiasFloatPtr(VOID);
    VOID *GetSpTolPtr(VOID); 
    VOID *GetTmOutTimePtr(VOID);
    VOID *GetTmOutModePtr(VOID);
    VOID *GetInitReqPtr(VOID);

    VOID *GetCvPtr(VOID);       
    VOID *GetCvEuLoPtr(VOID);   
    VOID *GetCvEuHiPtr(VOID);   

    VOID *GetBadCtlOptPtr(VOID);
    VOID *GetBadCtlFlPtr(VOID); 
        
    VOID *GetInitValPtr(VOID);  
    VOID *GetInitManPtr(VOID);  

    VOID *GetCtlInitPtr(VOID);  
    VOID *GetCtlStatePtr(VOID); 

    VOID *GetArwNetPtr(VOID);   
    VOID *GetArwOpPtr(VOID);    
    VOID *GetArwStsPtr(VOID);   

    VOID *GetPriInitValPtr(VOID);
    VOID *GetPriInitStsPtr(VOID);
    VOID *GetPriArwStsPtr(VOID);

    VOID *GetSecInitValPtr(VOID);
    VOID *GetSecInitStsPtr(VOID);
    VOID *GetSecArwStsPtr(VOID); 
    VOID *GetPvSts(VOID);
    VOID *GetPv1Sts(VOID);
    VOID *GetPv2Sts(VOID);
    VOID *GetTimeoutFlag(VOID);
    VOID *GetTimeoutCountPtr(VOID);

    VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams; }
    VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SvpRegCtlSlotChkpntVersion-1].CheckPointPtr; }
    VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SvpRegCtlSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SvpRegCtlSlotChkpntVersion;}

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsSvpRegCtlSlot(const clsSvpRegCtlSlot&); // Safeguard against default copy constructor
    clsSvpRegCtlSlot& operator=(const clsSvpRegCtlSlot&); // and default assignment  
public:
    clsSvpRegCtlSlot(UINT8); 
    ~clsSvpRegCtlSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);

    VOID InitSlotDatabase(BOOL bFullInit);

    inline UINT32 GetRedSlotDelta(VOID) {return 0;}

    // redundancy dump related Fucntions
    PASTATUS  GetDumpData(UINT8* const pDump, const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    inline UINT32 GetRedSlotSize(VOID) {
        return (sizeof(strSvpRegctlSlotDumpData));
    }
    
    inline UINT8 *GetRedSlotPointer(VOID) {
        return NULL;
    }
};

#endif // __TCSVPREGCTLSLOT_HPP__
