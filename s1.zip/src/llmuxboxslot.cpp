/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : llmuxboxslot.cpp                                            *
*    Description : Class clsclsLLBoxSlot definition.                           *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "llmuxmain.h"
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
BOOL LLMuxFTAUARTLoopBkTestInProg;

const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_FTAMSMCH,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN
};

const UINT8 clsLLBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_FREQ6050,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsLLBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 4 }
};

UINT8 clsLLBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

const SOFTFAILTYPE clsLLBoxSlot::FtaSoftFails[][NO_OF_FTA] = {
    SF_FTA1FAIL, SF_FTA2FAIL, SF_FTA3FAIL, SF_FTA4FAIL,
    SF_F1_IDERR, SF_F2_IDERR, SF_F3_IDERR, SF_F4_IDERR,
    SF_F1COM_FL, SF_F2COM_FL, SF_F3COM_FL, SF_F4COM_FL,
    SF_F1VREFFL, SF_F2VREFFL, SF_F3VREFFL, SF_F4VREFFL,
    SF_F1CAL_FL, SF_F2CAL_FL, SF_F3CAL_FL, SF_F4CAL_FL,
    SF_F1NOTCAL, SF_F2NOTCAL, SF_F3NOTCAL, SF_F4NOTCAL
};

const BOXPARAMINFO clsLLBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       //03 ModStatType
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //30
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      //35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   //37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          //38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          //39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          //40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          //41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          //43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      //44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    //45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           //47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       //48 AppBuildNo
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //50
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       //51 BoxSfBits 
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        //52 BoxSfLrs 
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       //53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          //54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         //55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              //56 DPA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              //57 DSA
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      //58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      //59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               //60 BA
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                //61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         //62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        //63 HWRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,TRUE,                        //64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          //65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            //66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,PreModStat1,PostModStat1,GetModStat1Ptr,TRUE,    //67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         //68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,TRUE,                           //69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              //70 NTH
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //71
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     //72 SwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //73
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     //74 TstFunctTime
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        //75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          //76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,0,GetRedDataPtr,FALSE,                //77 RedData
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           //78 DbValid
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,0,GetSfActionTblPtr,FALSE,                    //79 SfActionTbl
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,PreCalibFta,PostCalibFta,GetCalibFtaPtr,FALSE,      //80 CalibFta
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //81
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,PreFreq6050,PostFreq6050,GetFreq6050Ptr,TRUE,       //82 Freq6050
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //83
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //84
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //90
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //91
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //92
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetFtaTypePtr,FALSE,                           //93 FtaType
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //99
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //100
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //101
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //102
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //103
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //104
    DT_BLIND,192,AT_MBYTE,ALCK_VIEW,0,0,GetPvScanRecPtr,FALSE,                      //105 PvScanRec
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //106
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //109
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //110
    DT_BLIND,192,AT_MBYTE,ALCK_VIEW,0,0,GetPvScanRec2Ptr,FALSE,                     //111 PvScanRec2
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //112
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //113
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //114
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //115
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                         //116 MaxSlots
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //118
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //120
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //121
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //122
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //123
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //124
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //132
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //133
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //134
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //135
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //136
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //142
    DT_BLIND,4,AT_PSET,ALCK_VIEW,PreCheckPoint,0,GetCheckPointPtr,TRUE,                         //143 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //152
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //153
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //154
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //156
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //157
    DT_BLIND,130,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                       //158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     //159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     //160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostStatReset,GetStatResetPtr,FALSE,  //161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       //165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     //166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      //167 TraceLevel
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //168
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //169
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //170
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //171
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //172
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //173
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //174
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //175
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //176
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //177
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //178
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //179
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //180
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //181
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //182
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //183
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //184
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //185
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //186
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //187
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //188
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //189
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //190
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //191
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //192
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //193
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //194
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //195
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //196
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //197
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //198
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //199
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //201
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //202
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //203
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //204
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //207
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //208
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //209
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //210
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //211
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //237
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //238
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //239
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //240
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //241
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //242
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 //243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //246
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //247
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //248
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //249
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //253
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        //254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         //255
};
/*******************************************************************************
*                          clsLLBoxSlot::clsLLBoxSlot                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsLLBoxSlot::clsLLBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType,MAXSLOTS){
    LLMuxHardware.Initialize();
    Freq6050  = FREQ6050_SIXTYHZ;
    PeriodicScanInProgress = FALSE;
    for (UINT8 ucIndex = 0; ucIndex < HALFMAXSLOTS; ucIndex++) {
        PvScanRec[ucIndex].Pv                       = NaN;
        PvScanRec[ucIndex].PvSts                    = PVVALST_BAD;
        PvScanRec[ucIndex].Sequence                 = 0;
        PvScanRec2[HALFMAXSLOTS-ucIndex-1].Pv       = NaN;
        PvScanRec2[HALFMAXSLOTS-ucIndex-1].PvSts    = PVVALST_BAD;
        PvScanRec2[HALFMAXSLOTS-ucIndex-1].Sequence = 0;
        if (ucIndex < NO_OF_FTA) {
            CurrentScanCycle[ucIndex] = (UINT8)CONTEXT_ZERO;
            CurrentSlot[ucIndex]   = 0;
            FtaNoRespCount[ucIndex]= 0;
            ReconfigInProgress[ucIndex] = FALSE;
            FtaPresent[ucIndex]    = FALSE;
            DenyScanRetry[ucIndex] = FALSE;
            SkipDummySlot[ucIndex] = FALSE;
            FtaType[ucIndex]      = FTATYPE_NULL;
            FtaUnitId[ucIndex]    = BOOL(ucIndex % 2);
            CalibFta[ucIndex]     = FALSE;
            CalibInProgress[ucIndex]=FALSE;
            FlushFifo(ucIndex);
            SetPointBuildStatus(ucIndex,0x00);
            FtaSoftFailTable[ucIndex] = 0;
        }

    HwInfo.ProductType = PRODTYPE_LLMUX;
    if(a_MdType == MODLTYPE_LLMUX)
        HwInfo.ProductCode = PRODCODE_LLMUX;
    else
        HwInfo.ProductCode = PRODCODE_LLMUX_S8;

    }
    LLMuxFTAUARTLoopBkTestInProg = FALSE;
    // Setup TPU0 as Ppx interrupt timer for every 50 msec.
    TPU0_TCR    = 0x23; // Divide/64 clock, rising edge, clear TCNT on TGRA match.
    TPU0_TMDR   = 0xC0; // TPU0 normal mode operation
    TPU0_TIER   = 0x01; // TGIEA interrupt enabled with TGRA match
    // Seed TGRA for 50 msec interrupt with system clock divide by 64 configuration.
    TPU0_TGRA   = (UINT16)((SYSTEM_CLOCK_FREQUENCY / 64) / 
                           (MILLISECONDS_IN_SECOND / LLMUX_PPX_PERIOD));
    IPRI_IOPROC = LVLPRI_IOPROC; // Set interrupt priority level 4 for Ppx
   

}
/*******************************************************************************
*                         clsLLBoxSlot::AppInitialization                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLBoxSlot::AppInitialization(VOID)  {
    IRQ1_STATUS = DISABLE;         // Clear the IRQ1 status flag
    IRQ1_ENABLE = ENABLE;          // Enable IRQ1 (FPGA interrupt).
    UINT8 ucFtaNum = 0;
    for(ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
        LLMuxHardware.CreateAndSendRequest(ucFtaNum,REQ_STATUS);
    }
    IdleWait(20000); //Wait for 20 ms for response
    for(ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
        if(TRUE == LLMuxHardware.GetTimeoutFlag(ucFtaNum)) {//If FTA does not respond
            FtaPresent[ucFtaNum] = FALSE;
            FtaType[ucFtaNum]    = FTATYPE_NULL;
        }
        else {
            FtaPresent[ucFtaNum] = TRUE;
            DenyScanRetry[ucFtaNum] = TRUE;
            //Commented out below code to fix "1-1F741A FTA Identification 
            //failure SF is reported if the jumper setting for FTA numbering 
            //is changed online." The FTA unit ID should not be ignored 
            //if not in the order 0,1,0,1 for Ftas 1,2,3 and 4 respectively
            /*
            if(STATUS_WRONGUNITID == LLMuxHardware.GetResponse(ucFtaNum).Status) {//Required to ignore wrong unit Id. 
                FtaUnitId[ucFtaNum] = !FtaUnitId[ucFtaNum]; //Next request will be sent
            }                                               //with correct Id
            */
            if(FALSE == CheckResponseForErrors(ucFtaNum)) { //No error
                FtaType[ucFtaNum] = LLMuxHardware.GetResponse(ucFtaNum).FtaType ?
                                    FTATYPE_TC : 
                                    FTATYPE_RTD;
                switch(LLMuxHardware.GetResponse(ucFtaNum).Status) {
                case STATUS_CALIBINPROGRESS:
                case STATUS_VREF_FAILURE:
                case STATUS_SCANINPROGRESS:
                    FtaPresent[ucFtaNum] = FALSE;
                    break;
                default:
                    FtaPresent[ucFtaNum] = FALSE;
                    break;
                }
            }
        }
    }
    for(ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
        if(TRUE == FtaPresent[ucFtaNum]) {
            LLMuxHardware.CreateAndSendRequest(ucFtaNum,REQ_FREQSEL);
        }
    }
    IdleWait(20000); //Wait for 20 ms for response
    for(ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
        if(TRUE == FtaPresent[ucFtaNum]) {
            if(TRUE == LLMuxHardware.GetTimeoutFlag(ucFtaNum)) {//If FTA does not respond
                FtaPresent[ucFtaNum] = FALSE;
            }
            else {
                FtaPresent[ucFtaNum] = TRUE;;
                DenyScanRetry[ucFtaNum] = TRUE;
                if(FALSE == CheckResponseForErrors(ucFtaNum)) { //No error
                    switch(LLMuxHardware.GetResponse(ucFtaNum).Status) {
                    case STATUS_CALIBINPROGRESS:
                    case STATUS_VREF_FAILURE:
                    case STATUS_SCANINPROGRESS:
                        FtaPresent[ucFtaNum] = FALSE;
                        break;
                    default:
                        FtaPresent[ucFtaNum] = FALSE;
                        break;
                    }
                }
            }
        }
    }
    TPU0_CST = 1; // Start LLMUX point processing timer
}
/*******************************************************************************
*                          clsLLBoxSlot::AppUrgentProcess                      *
*                          ==============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLBoxSlot::AppUrgentProcess(VOID) {

    //By pass the execution of this routine in factory mode to enable testing of
    //TRANSx_n signals.
    if (((TRUE == BOX->IsFactoryMode()) && (FALSE == LLMuxFTAUARTLoopBkTestInProg)))
        return;

    //Scan all FTA's for XmitEnd
    for (UINT8 FtaNum=0; FtaNum < NO_OF_FTA; FtaNum++) {
        if (FTA_UART(FtaNum).XMT_COMPLETE && FTA_UART(FtaNum).REQUEST_TO_SEND) {
            FTA_UART(FtaNum).REQUEST_TO_SEND = 0;
            FTA_UART(FtaNum).XMTREGEMPTY_INTR_ENBL = DISABLE;//Disable Tx interrupt
            FTA_UART(FtaNum).RCVLINESTS_INTR_ENBL  = ENABLE; //Enable Rx line status interrupt
            FTA_UART(FtaNum).RCVDATAAVBL_INTR_ENBL = ENABLE; //Enable Rx data available interrupt
        }
    }
}
/*******************************************************************************
*                          clsLLBoxSlot::GetDataType                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsLLBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsLLBoxSlot::GetAccessType                        *
*                          ============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsLLBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                          clsLLBoxSlot::GetParamSize                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsLLBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                          clsLLBoxSlot::GetParamPtr                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsLLBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                         clsLLBoxSlot::GetAccessLock                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsLLBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                    clsLLBoxSlot::GetIsDbChecksumed                           *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsLLBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                        clsLLBoxSlot::VerifyControlState                      *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}
/*******************************************************************************
*                        clsLLBoxSlot::ExecutePreFunction                      *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsLLBoxSlot::ExecutePostFunction                     *
*                        ==================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::AreAllFtaPresent                        *
*                        ==============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsLLBoxSlot::AreAllFtaPresent()  {
    for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
        if(FALSE == FtaPresent[ucFtaNum]) return FALSE;
    return TRUE;
}
/*******************************************************************************
*                        clsLLBoxSlot::AreAllScanCyclesComplete                *
*                        ======================================                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsLLBoxSlot::AreAllScanCyclesComplete()  {
    for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
        if(END_SCAN_TIMESLOT != CurrentScanCycle[ucFtaNum]) return FALSE;
    return TRUE;
}
/*******************************************************************************
*                        clsLLBoxSlot::IsAnyFtaReconfigTakingPlace             *
*                        =========================================             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsLLBoxSlot::IsAnyFtaReconfigTakingPlace()  {
    for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
        if(TRUE == ReconfigInProgress[ucFtaNum]) return TRUE;
    return FALSE;
}
/*******************************************************************************
*                        clsLLBoxSlot::AreOnlyReconfigFtasPending              *
*                        ========================================              *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsLLBoxSlot::AreOnlyReconfigFtasPending() {
    for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
        if((END_SCAN_TIMESLOT != CurrentScanCycle[ucFtaNum]) && 
           (FALSE == ReconfigInProgress[ucFtaNum])) {
            return FALSE;
        }
    }
    return TRUE;
}
/*******************************************************************************
*                        clsLLBoxSlot::IssueSfToFta                            *
*                        ==========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLBoxSlot::IssueSfToFta(UINT8 a_FtaNum, UINT8 a_SfType, BOOL a_Issue) {
    UpdateFtaSoftFailTable(a_FtaNum,a_SfType,a_Issue);
    AddSoftfailEvent(EVENTTYPE_NORMAL,FtaSoftFails[SF_FTAFAIL][a_FtaNum],IsFtaInSoftFail(a_FtaNum),0);
    AddSoftfailEvent(EVENTTYPE_NORMAL,FtaSoftFails[a_SfType][a_FtaNum],a_Issue,0);
}
/*******************************************************************************
*                       clsAihBoxSlot::PpxInterruptHandler                     *
*                       ==================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLBoxSlot::PpxInterruptHandler(VOID)  {
    TPU0_TGFA = 0; // Acknowledge the compare match interrupt
    clsLLBoxSlot *pBox = BOX;
#ifdef DEBUG
    if(FALSE == g_bStopFtaScan) {
#endif
      if(MODSTATUS_RUN == pBox->GetModuleStatus()) {
          for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
              (TRUE == pBox->GetFtaPresence(ucFtaNum)) ?
              pBox->ScanFtaAndCollectPv(ucFtaNum) : //Collect data if Fta present
              pBox->DoFtaStatusCollection(ucFtaNum);//else scan the Fta
              if((FTATYPE_NULL != pBox->GetFtaType(ucFtaNum)) && 
                 (0 == pBox->GetPointBuildStatus(ucFtaNum)))
                  pBox->IssueSfToFta(ucFtaNum,SF_FCOM_FL,FALSE);
          }
          if(TRUE == pBox->AreAllFtaPresent()) {
              if(TRUE == pBox->AreAllScanCyclesComplete()) {
                  for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
                      pBox->SetPresentScanCycle(ucFtaNum,0);
              }
              else {
                //If there is any FTA under re-configuration then 
                //do not hold other FTAs who have finished their scan.
                  if(TRUE == pBox->IsAnyFtaReconfigTakingPlace()) {
                      if(TRUE == pBox->AreOnlyReconfigFtasPending()) {
                          for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
                              if(FALSE == pBox->IsReconfigInProgress(ucFtaNum)) {
                                  pBox->SetPresentScanCycle(ucFtaNum,0);
                              }
                          }
                      }
                  }
              }
          }
          else {
              for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
                  if(END_SCAN_TIMESLOT == pBox->GetPresentScanCycle(ucFtaNum))
                    pBox->SetPresentScanCycle(ucFtaNum,0);
              }
          }
      }
      else {//Module is in IDLE
          if (TRUE == BOX->IsFactoryMode())
          {
              if(TRUE == LLMuxFTAUARTLoopBkTestInProg) {
              //Perform Loopback test if requested
                  LLMuxFTAUARTLoopBkTestInProg = (RETURNSTATUS_INPROGRESS == BOX->LLMuxUartLoopBackTest());
              }
          }
          else {
              for(UINT8 ucChanNum = 1; ucChanNum <= MAXSLOTS; ucChanNum++)
                  SLOT(ucChanNum)->ProcessInput();
              for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
                  pBox->DoFtaStatusCollection(ucFtaNum);

              if(TRUE == pBox->AreAllFtaPresent()) {
                  if(TRUE == pBox->AreAllScanCyclesComplete()) {
                      for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
                          pBox->SetPresentScanCycle(ucFtaNum,0);
                  }
              }
              else {
                  for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++) {
                      if(END_SCAN_TIMESLOT == pBox->GetPresentScanCycle(ucFtaNum))
                        pBox->SetPresentScanCycle(ucFtaNum,0);
                  }
              }
          }
      }
#ifdef DEBUG
    }
#endif
}
/*******************************************************************************
*                        clsLLBoxSlot::ScanFtaAndCollectPv                     *
*                        =================================                     *
* PURPOSE: This routine is formulated as a 22 case statement. The first 20     *
* cases are assigned to handle 20 time slots of the one second cycle to kick   *
* off pv conversion, do pv collection, and pv processing for the four FTAs. If *
* the change request fifo is empty then the fifo processing slot is skipped    *
* and is replaced by a dummy time slot (slot #21). In case of overrun due to   *
* retries have been attempted, the 22nd case can be used as a dummy state      *
* where the FTA which completes the processing cycle first can wait for the    *
* other FTA to complete its cycle.                                             *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ScanFtaAndCollectPv(UINT8 FtaNum) {
    CONTEXT TimeSlot = CONTEXT(CurrentScanCycle[FtaNum]);
    if(CONTEXT_ZERO == TimeSlot) {
        LLMuxHardware.CreateAndSendRequest(FtaNum,REQ_STARTSCAN);
        SkipDummySlot[FtaNum] = FALSE;
        ++CurrentScanCycle[FtaNum];
    }
    else if (CONTEXT_ONE == TimeSlot) {
        ProcessResponse(FtaNum);//Process the response for SCAN request
        if(FALSE == LLMuxHardware.GetTimeoutFlag(FtaNum)) {//If FTA responds
            if(TRUE == BadTxFlag[FtaNum]) {//error
                if(FALSE == FtaPresent[FtaNum]) 
                    CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
            }
            else {//No error
                SCI_RXSTATUS RxStatus = (SCI_RXSTATUS)LLMuxHardware.GetResponse(FtaNum).Status;
                if((STATUS_ACK == RxStatus)||(STATUS_ACKNOCALIB == RxStatus)) {
                    ++CurrentScanCycle[FtaNum];
                    CurrentSlot[FtaNum] = 0;
                    LLMuxHardware.CreateAndSendRequest(FtaNum,REQ_POINTDATA,CurrentSlot[FtaNum]);
                }
            }
        }
    }
    else if ((CONTEXT_TWO <= TimeSlot) && (CONTEXT_SEVENTEEN >= TimeSlot))
        ProcessOldPVAndRequestNewData(FtaNum);
    else if (CONTEXT_EIGHTEEN == TimeSlot)
        FinishScanAndProcessFifo(FtaNum);
    else if (CONTEXT_NINETEEN == TimeSlot) {
        ProcChangeReqFifo(FtaNum);
        if(FALSE == SkipDummySlot[FtaNum])//SkipDummySlot will remain TRUE as long as there
            ++CurrentScanCycle[FtaNum];   //are requests in the FIFO. The time-slice will not
    }                                     //be incremented until FIFO is empty.
    else if (CONTEXT_TWENTY == TimeSlot) {
        ++CurrentScanCycle[FtaNum];
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::DoFtaStatusCollection                   *
*                        ===================================                   *
* PURPOSE: This routine performs a one second periodic check on the FTA's      *
* status when the communication between the IOM and the FTA's is assumed to be *
* lost or incorrectly established, as well as when the module is put into idle *
* mode. The routine is designed to be a 20 case statement to fit the one       *
* second cycle with 20 invocations of 50 ms each. The first time slot is for   *
* sending status request to the FTAs. The second time slot is for processing   *
* the status response from the FTAs and start servicing the change request     *
* fifos if they are not empty. The third time slot is for processing the       *
* change request status responses. Because change request processing time slot *
* is skipped when the fifo is empty, another dummy time slot is added to make  *
* up for it.                                                                   *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::DoFtaStatusCollection(UINT8 FtaNum) {
    PeriodicScanInProgress = TRUE;
    CONTEXT TimeSlot = CONTEXT(CurrentScanCycle[FtaNum]);
    if(CONTEXT_ZERO == TimeSlot) {
        LLMuxHardware.CreateAndSendRequest(FtaNum,REQ_STATUS);
        FtaNoRespCount[FtaNum] = 0;
        SkipDummySlot[FtaNum] = FALSE;
        ++CurrentScanCycle[FtaNum];
    }
    else if (CONTEXT_ONE == TimeSlot) {
        ProcessResponse(FtaNum);
        if(TRUE == LLMuxHardware.GetTimeoutFlag(FtaNum)) {//If FTA does not respond
            ++CurrentScanCycle[FtaNum];
            FlushFifo(FtaNum);
            FtaType[FtaNum] = FTATYPE_NULL;
        }
        else {//Response received
            if(TRUE == BadTxFlag[FtaNum]) {//error
                if(FALSE == FtaPresent[FtaNum]) {
                    CurrentScanCycle[FtaNum] += 2; //Skip Fifo processing
                    FtaType[FtaNum] = FTATYPE_NULL;
                }
            }
            else { ProcessStatusResponse(FtaNum); }
        }
    }
    else if ((TimeSlot >= CONTEXT_TWO) && (TimeSlot <= CONTEXT_NINETEEN)) {
        if(TRUE == SkipDummySlot[FtaNum]) {
            ProcChangeReqFifo(FtaNum);
            ++CurrentScanCycle[FtaNum];
            if(CurrentScanCycle[FtaNum] > (UINT8)CONTEXT_NINETEEN) 
                CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_NINETEEN;
        }
        else { ++CurrentScanCycle[FtaNum]; }
    }
    else if (CONTEXT_TWENTY == TimeSlot) {
        ++CurrentScanCycle[FtaNum]; //Increment the time slot so that when next PPX interrupt
                                    //comes and other FTAs are done with their scanning, they
                                    //all should get synced during that time slice only.
                                    //Change done to fix [1-20MHBJ]. Deviation from PMIO
        if(FTATYPE_NULL != FtaType[FtaNum]) {
            if(MODSTATUS_RUN == ModStat1.Status) {
                FtaPresent[FtaNum] = TRUE;
                ReloadFtaPoints(FtaNum);
                ReconfigInProgress[FtaNum] = TRUE;
            }
        }
    }
    PeriodicScanInProgress = FALSE;
}
/*******************************************************************************
*                  clsLLBoxSlot::ProcessOldPVAndRequestNewData                 *
*                  ===========================================                 *
* PURPOSE: This routine will process the previous 50ms DATA stored in          *
* the FTA's buffer, collect new DATA, stored it in the  FTA's buffer for next  *
* scan processing, and then request for next point DATA, or scan complete if   *
* all the points have been processed.                                          *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ProcessOldPVAndRequestNewData(UINT8 FtaNum) {
    UINT8 ucSlotNum = MAXSLOTS_PER_FTA * FtaNum + CurrentSlot[FtaNum] + 1;
    ProcessResponse(FtaNum);
    if(FALSE == LLMuxHardware.GetTimeoutFlag(FtaNum)) {//If FTA responds
        if(TRUE == BadTxFlag[FtaNum]) {//error
            if(FALSE == FtaPresent[FtaNum]) {
                CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
			}
        }
        else {
            if(TRUE == LLMuxHardware.GetResponse(FtaNum).PtDataFlag) {//PV received
                CollectData(FtaNum);
                ++CurrentScanCycle[FtaNum];
                ++CurrentSlot[FtaNum];
                LAST_PTDATA_TIMESLOT == CurrentScanCycle[FtaNum] ?
                LLMuxHardware.CreateAndSendRequest(FtaNum,REQ_SCANCOMPLETE) :
                LLMuxHardware.CreateAndSendRequest(FtaNum,REQ_POINTDATA,CurrentSlot[FtaNum]);
            }
        }
    }
    if(TRUE == SLOT(ucSlotNum)->GetInitFlg()) {
        SLOT(ucSlotNum)->SetInitFlg(FALSE);
    }
    else { //Process the PVRAW obtained above
        SLOT(ucSlotNum)->ProcessInput();
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::FinishScanAndProcessFifo                *
*                        ======================================                *
* PURPOSE: This routine will process the status of the scan                    *
* complete request and then check the change request fifo. If the fifo         *
* is empty then the step number will be set to end of cycle, else it           *
* will be increased to service the fifo in the next invocation.                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::FinishScanAndProcessFifo(UINT8 FtaNum) {
    ProcessResponse(FtaNum);//Process the response for SCAN request
    if(FALSE == LLMuxHardware.GetTimeoutFlag(FtaNum)) {//If FTA responds
        if(TRUE == BadTxFlag[FtaNum]) {//error
            if(FALSE == FtaPresent[FtaNum]) 
                CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
        }
        else {//No error
            SCI_RXSTATUS RxStatus = (SCI_RXSTATUS)LLMuxHardware.GetResponse(FtaNum).Status;
            if((STATUS_ACK == RxStatus)||(STATUS_ACKNOCALIB == RxStatus)) {
                IssueSfToFta(FtaNum,SF_FVREFFL,FALSE);
                ++CurrentScanCycle[FtaNum];
                ReadFifo(FtaNum);
            }
        }
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::CollectData                             *
*                        =========================                             *
* PURPOSE: This routine will collect PV values from the FTAs, multiply them    *
* with the correct factors to yield actual measurements in                     *
* microvolts(TC/linear) or milliohms(RTD), then store the values into DB       *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::CollectData(UINT8 FtaNum) {
    UINT8 ucSlotNum = MAXSLOTS_PER_FTA * FtaNum + CurrentSlot[FtaNum] + 1;
    SCIPTDATARESPONSE Resp; Resp.LONG = LLMuxHardware.GetResponse(FtaNum).LONG;
    FLOAT32 CollectedPvRaw = NaN;
    if(PTEXECST_ACTIVE == SLOT(ucSlotNum)->GetPtExecSt()) {
        if(MAXUINT16 != Resp.PtData) { //Good PV
            CollectedPvRaw = Resp.Sign ? -((FLOAT32)Resp.PtData):(FLOAT32)Resp.PtData;
            // Check for input type. The multiplicative factor is as follows:
            //*2 microvolts/bit for TC or linear input (FtaType=1)
            //*8 milliohms/bit for RTD input (FtaType=0)
            CollectedPvRaw *= Resp.FtaType ? 2 : 8;
        }
    }
    SLOT(ucSlotNum)->SetPvRawInt(CollectedPvRaw);
}
/*******************************************************************************
*                        clsLLBoxSlot::ReloadFtaPoints                         *
*                        =============================                         *
* PURPOSE: This routine submits the frequency selection, deconfig all the      *
* points before redownloading the configuration for active points. Config      *
* mismatch error also being detected at this level                             *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ReloadFtaPoints(UINT8 FtaNum) {
    UINT8 ucTargetSlot = 0;
    UINT8 ucExpectedFtaType = FTATYPE_NULL;
    SubmitReqToFifo(FtaNum,REQ_FREQSEL);
    for(UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS_PER_FTA; ucSlotNum++) {
        ucTargetSlot = MAXSLOTS_PER_FTA * FtaNum + ucSlotNum;
        SLOT(ucTargetSlot)->SetInitFlg(TRUE);
        SubmitReqToFifo(FtaNum,REQ_DECONFIGPOINT,ucSlotNum);
        if(PTEXECST_ACTIVE == SLOT(ucTargetSlot)->GetPtExecSt()) {
            ucExpectedFtaType = (SENSRTYP_RTD == SLOT(ucTargetSlot)->GetSensrTyp()) ? 
                                 FTATYPE_RTD : FTATYPE_TC;
            if(ucExpectedFtaType == FtaType[FtaNum]) {
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FTAMSMCH,FALSE,ucTargetSlot);
                SubmitReqToFifo(FtaNum,REQ_LOADCONFIGDATA,ucSlotNum);
            }
            else {
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FTAMSMCH,TRUE,ucTargetSlot);
            }
        }
    }
}
/*******************************************************************************
*                    clsLLBoxSlot::ProcessStatusResponse                       *
*                    ===================================                       *
* PURPOSE: This routine handles all different cases of status responses        *
* received from the FTA when doing a one second status request                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ProcessStatusResponse(UINT8 FtaNum) {
    SCI_RXSTATUS RxStatus = (SCI_RXSTATUS)LLMuxHardware.GetResponse(FtaNum).Status;
    switch(RxStatus) {
        case STATUS_ACK:
        case STATUS_ACKNOCALIB:
            IssueSfToFta(FtaNum,SF_FVREFFL,FALSE);
            if(TRUE == CalibInProgress[FtaNum]) {
                if(TRUE == CalibFta[FtaNum]) {
                    CalibFta[FtaNum] = FALSE;
                    CalibInProgress[FtaNum] = FALSE;
                    IssueSfToFta(FtaNum,SF_FCAL_FL,FALSE);
                }
            }
            ++CurrentScanCycle[FtaNum];
            FtaType[FtaNum] = LLMuxHardware.GetResponse(FtaNum).FtaType ?
                              FTATYPE_TC : FTATYPE_RTD;
            ReadFifo(FtaNum);
            break;
        case STATUS_VREF_FAILURE:
            IssueSfToFta(FtaNum,SF_FVREFFL,TRUE);
            CurrentScanCycle[FtaNum] += 2; //Skip Fifo processing
            FlushFifo(FtaNum);
            FtaType[FtaNum] = FTATYPE_NULL;
            break;
        case STATUS_CALIBFAILURE:
            IssueSfToFta(FtaNum,SF_FCAL_FL,TRUE);
            CalibInProgress[FtaNum] = FALSE;
            ++CurrentScanCycle[FtaNum];
            if(TRUE == CalibFta[FtaNum]) CalibFta[FtaNum] = FALSE;
            FtaType[FtaNum] = LLMuxHardware.GetResponse(FtaNum).FtaType ?
                              FTATYPE_TC : FTATYPE_RTD;
            ReadFifo(FtaNum);
            break;
        case STATUS_BADCHECKSUM:
        case STATUS_WRONGUNITID:
            if(FALSE == DenyScanRetry[FtaNum]) {
                CurrentScanCycle[FtaNum] += 2; //Skip Fifo processing
                FlushFifo(FtaNum);
                FtaType[FtaNum] = FTATYPE_NULL;
            }
            break;
        default:
            CurrentScanCycle[FtaNum] += 2; //Skip Fifo processing
            break;
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::ProcessResponse                         *
*                        =============================                         *
* PURPOSE: Handle Fta/Comm errors during serial communication                  *
* ARGUMENTS:                                                                   *
* RETURN: Rx status                                                            *
* NOTES: TBD: This function call can be avoided by having function pointers    * 
* for error handling routines in an static array indexed based on error code   *
* Verified with PMIO                                                           *
*******************************************************************************/
VOID clsLLBoxSlot::ProcessResponse(UINT8 FtaNum) {
    if(TRUE == LLMuxHardware.GetTimeoutFlag(FtaNum)) {
        ProcessNoResponse(FtaNum);
    }
    else {
        if(FALSE == CheckResponseForErrors(FtaNum)) {//No errors
            DenyScanRetry[FtaNum]  = FALSE;
            FtaNoRespCount[FtaNum] = 0;
            if(FALSE == LLMuxHardware.GetResponse(FtaNum).PtDataFlag) {
                switch(LLMuxHardware.GetResponse(FtaNum).Status) {
                    case STATUS_ACK:
                    case STATUS_ACKNOCALIB: 
                        ProcessNormalResponse(FtaNum); 
                        break;
                    case STATUS_SCANINPROGRESS:
                        FtaPresent[FtaNum] = FALSE;
                        CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
                        break;
                    case STATUS_VREF_FAILURE: 
                        FtaPresent[FtaNum] = FALSE;
                        CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
                        IssueSfToFta(FtaNum,SF_FVREFFL,TRUE);
                        FlushFifo(FtaNum);
                        break;
                    default:
                        FtaPresent[FtaNum] = FALSE;
                        CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
                        break;
                }
            }
        }
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::ProcessBadChecksum                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ProcessBadChecksum(UINT8 FtaNum) {
    FtaNoRespCount[FtaNum] = 0;
    if (FALSE == DenyScanRetry[FtaNum]) { //If retry is allowed
        SkipDummySlot[FtaNum] = TRUE; //Dummy slot not needed if retry is performed.
        DenyScanRetry[FtaNum] = TRUE; //Don't retry scanning
        LLMuxHardware.CreateAndSendRequest(FtaNum,
                                           LLMuxHardware.GetLastRequest(FtaNum),
                                           CurrentSlot[FtaNum]);
    }
    else {
        DenyScanRetry[FtaNum] = FALSE; //Enable scan retry
        FtaPresent[FtaNum]    = FALSE; //FTA not present
        if(MODSTATUS_ALIVE != ModStat1.Status) {
            if(0 != GetPointBuildStatus(FtaNum)) {//Are any points built in FTA
                IssueSfToFta(FtaNum,SF_FCOM_FL,TRUE);
                SetSlotsBad(FtaNum);
            }
        }
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::ProcessWrongFtaId                       *
*                        ===============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Assume Odd FTA Ids as 0                                               *
* Verified with PMIO                                                           *
*******************************************************************************/
VOID clsLLBoxSlot::ProcessWrongFtaId(UINT8 FtaNum) {
    //Commented out below code to fix "1-1F741A FTA Identification 
    //failure SF is reported if the jumper setting for FTA numbering 
    //is changed online." The FTA unit ID should not be ignored 
    //if not in the order 0,1,0,1 for Ftas 1,2,3 and 4 respectively
    /*
    FtaUnitId[FtaNum]  = !FtaUnitId[FtaNum];
    */
    FtaPresent[FtaNum] = FALSE;
    DenyScanRetry[FtaNum] = FALSE;
    FtaNoRespCount[FtaNum]= 0;
    if(MODSTATUS_ALIVE != ModStat1.Status) {
        if(0 != GetPointBuildStatus(FtaNum)) {//Are any points built in FTA
            IssueSfToFta(FtaNum,SF_F_IDERR,TRUE);
            SetSlotsBad(FtaNum);
        }
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::ProcessNoResponse                       *
*                        ===============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ProcessNoResponse(UINT8 FtaNum) {
    if(PeriodicScanInProgress) {
        FtaPresent[FtaNum] = FALSE;
        ++CurrentScanCycle[FtaNum];
    }
    else {
        if(FtaNoRespCount[FtaNum] < MAX_RETRIES) {
            ++FtaNoRespCount[FtaNum];
            SkipDummySlot[FtaNum] = TRUE; //Dummy slot not needed with retry
            LLMuxHardware.CreateAndSendRequest(FtaNum,
                                               LLMuxHardware.GetLastRequest(FtaNum),
                                               CurrentSlot[FtaNum]);
        }
        else {
            FtaPresent[FtaNum] = FALSE;
            CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
        }
    }
    if(FALSE == FtaPresent[FtaNum]) {
        if(0 != GetPointBuildStatus(FtaNum)) {//Are any points built in FTA
            IssueSfToFta(FtaNum,SF_FCOM_FL,TRUE);
            SetSlotsBad(FtaNum);
        }
    }
}
/*******************************************************************************
*                      clsLLBoxSlot::ProcessNormalResponse                     *
*                      ===================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ProcessNormalResponse(UINT8 FtaNum) {
    IssueSfToFta(FtaNum,
        SF_FNOTCAL,
        STATUS_ACKNOCALIB == LLMuxHardware.GetResponse(FtaNum).Status);
}
/*******************************************************************************
*                      clsLLBoxSlot::CheckResponseForErrors                    *
*                      ====================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
BOOL clsLLBoxSlot::CheckResponseForErrors(UINT8 FtaNum) {
    BadTxFlag[FtaNum] = FALSE;
    SCIRESPONSE Resp  = LLMuxHardware.GetResponse(FtaNum);
    if(Resp.CheckSum != LLMuxHardware.ComputeChecksum(Resp.LONG)) {
        BadTxFlag[FtaNum] = TRUE;
        ProcessBadChecksum(FtaNum);
        TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxBadRxFromFta,(UINT32)FtaNum << 8 | (UINT32)LLMuxHardware.GetLastRequest(FtaNum));
    }
    else {
        if(STATUS_ACK != Resp.Status && TRUE != Resp.PtDataFlag) {
			TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxErrFromFta,(UINT32)Resp.Status << 24 | (UINT32)FtaNum << 8 | (UINT32)LLMuxHardware.GetLastRequest(FtaNum));
        }
        IssueSfToFta(FtaNum,SF_FCOM_FL,FALSE);
        if(Resp.FtaId != FtaUnitId[FtaNum]) {
            BadTxFlag[FtaNum] = TRUE;
            ProcessWrongFtaId(FtaNum);
        }
        else { IssueSfToFta(FtaNum,SF_F_IDERR,FALSE); }
    }
    return BadTxFlag[FtaNum];
}
/*******************************************************************************
*                      clsLLBoxSlot::SetSlotsBad                               *
*                      =========================                               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::SetSlotsBad(UINT8 FtaNum) {
    if(MODSTATUS_RUN == ModStat1.Status) {
        for(UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS_PER_FTA; ucSlotNum++) {
            SLOT(MAXSLOTS_PER_FTA*FtaNum+ucSlotNum)->SetPvRawInt(NaN);
            SLOT(MAXSLOTS_PER_FTA*FtaNum+ucSlotNum)->ProcessInput();
        }
    }
}
/*******************************************************************************
*                      clsLLBoxSlot::SubmitReqToFifo                           *
*                      =============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: First nibble contains point number between 0 - 15, if any. Last       *
*        nibble has request type                                               *
*Verified with PMIO                                                            *
*******************************************************************************/
VOID clsLLBoxSlot::SubmitReqToFifo(UINT8 FtaNum, SCI_CMDS Req, UINT8 Slot) {
    ChangeReqFifo[FtaNum][AppendOffset[FtaNum]++] = UINT8(((Slot-1) << 4) | (UINT8)Req);
}
/*******************************************************************************
*                      clsLLBoxSlot::ReadFifo                                  *
*                      ======================                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ReadFifo(UINT8 FtaNum) {
    if(AppendOffset[FtaNum] > 0) { //Any request in FIFO
        if(AppendOffset[FtaNum] == ServicedReqOffset[FtaNum]) {//All have been serviced
            FlushFifo(FtaNum);
            ++CurrentScanCycle[FtaNum];
            SkipDummySlot[FtaNum] = FALSE;
            ReconfigInProgress[FtaNum] = FALSE;
        }
        else {//More pending requests
            SkipDummySlot[FtaNum] = TRUE;
            SendChangeRequest(FtaNum);
            ++ServicedReqOffset[FtaNum];
        }
    }
    else {
        /*
        SkipDummySlot[FtaNum] is made false below in order to fix the problem of
        module stopping to communicate to the FTA in case of bad checksum responses.
        This problem exists in PMIO but is being fixed in Series C.
        */
        SkipDummySlot[FtaNum] = FALSE;
        ++CurrentScanCycle[FtaNum];
    }
}
/*******************************************************************************
*                        clsLLBoxSlot::ProcChangeReqFifo                       *
*                        ===============================                       *
* PURPOSE: This routine will process any change request entered                *
* into the fifo such as frequency selection, download configuration due        *
* to ptexecst active, calibration request,...The step number will not be       *
* updated until all requests in the fifo have been serviced.                   *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::ProcChangeReqFifo(UINT8 FtaNum) {
    ProcessResponse(FtaNum);
    if(FALSE == LLMuxHardware.GetTimeoutFlag(FtaNum)) {//If FTA responds
        if(TRUE == BadTxFlag[FtaNum]) {//error
            if(TRUE == PeriodicScanInProgress) {
                if(FALSE == FtaPresent[FtaNum]) ++CurrentScanCycle[FtaNum];
            }
            else {
                if(FALSE == FtaPresent[FtaNum]) 
                    CurrentScanCycle[FtaNum] = (UINT8)CONTEXT_ZERO;
            }
        }
        else {//No error
            SCI_RXSTATUS RxStatus = (SCI_RXSTATUS)LLMuxHardware.GetResponse(FtaNum).Status;
            if(REQ_CALIBRATE == LLMuxHardware.GetLastRequest(FtaNum))
                CalibInProgress[FtaNum] = TRUE;
            if((STATUS_ACK == RxStatus)||(STATUS_ACKNOCALIB == RxStatus)||(STATUS_NACK == RxStatus))
                ReadFifo(FtaNum);
            else if((STATUS_CALIBINPROGRESS == RxStatus)||(STATUS_SCANINPROGRESS == RxStatus))
                ++CurrentScanCycle[FtaNum];
        }
    }
}
/*******************************************************************************
*                      clsLLBoxSlot::FlushFifo                                 *
*                      =======================                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::FlushFifo(UINT8 FtaNum) {
    AppendOffset[FtaNum] = 0;
    ServicedReqOffset[FtaNum] = 0;
    for(UINT8 ucIndex = 0; ucIndex < FIFO_SIZE; ucIndex++)
        ChangeReqFifo[FtaNum][ucIndex] = 0;
}
/*******************************************************************************
*                      clsLLBoxSlot::SendChangeRequest                         *
*                      ===============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::SendChangeRequest(UINT8 FtaNum) {
    UINT8 Slot = (ChangeReqFifo[FtaNum][ServicedReqOffset[FtaNum]] & 0xF0) >> 4;
    UINT8 Req  =  ChangeReqFifo[FtaNum][ServicedReqOffset[FtaNum]] & 0x0F;
    switch(Req) {
    case REQ_LOADCONFIGDATA:
    case REQ_DECONFIGPOINT:
        CurrentSlot[FtaNum] = Slot;
        LLMuxHardware.CreateAndSendRequest(FtaNum,(SCI_CMDS)Req,CurrentSlot[FtaNum]);
        break;
    case REQ_FREQSEL:
    case REQ_CALIBRATE:
        LLMuxHardware.CreateAndSendRequest(FtaNum,(SCI_CMDS)Req);
        break;
    }
}
/*******************************************************************************
*                          clsLLBoxSlot::PreModStat1                           *
*                          ==========================                          *
* PURPOSE:  Pre Receiver-Beware function for ModStat1 parameter. Checks for    *
*           module status.                                                     *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesful                      *
* NOTES:    This method will update ModStat1Trans flag if there is any         *
*           change in the module status.                                       *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
PASTATUS clsLLBoxSlot::PreModStat1(UINT8 *a_Writebuffer,UINT8) {
    UINT8 ucNewMod1State = *(UINT8*)a_Writebuffer;
    if (ucNewMod1State > MODSTATUS_FAIL) {
      return DO_ILLEGAL_VALUE;
    }
    // Return error is module is in the Alive state.
    if (ModStat1.Status == MODSTATUS_ALIVE) {
        return DO_STATE_MUST_BE_IDLE_OR_RUN;
    }
    // Check if calibration is in progress for analog IOMs. 
    for(UINT8 ucIndex = 0; ucIndex < NO_OF_FTA; ucIndex++)
    {
        if(TRUE == CalibFta[ucIndex]) return DO_CALIB_IN_PROGRESS;
    }

    // Shutdown the IOM if the new value is ALIVE or FAILED.
    if ((MODSTATUS_ALIVE == ucNewMod1State) || (MODSTATUS_FAIL == ucNewMod1State)) 
    {
        if (ModStat1.Status == MODSTATUS_IDLE) 
        {
            // Update the FailCode and shutdown IOM.
            FailCode = HF_IOMUSERRESET;
            ShutdownIom();
        }
        else
        {
            return DO_STATE_MUST_BE_IDLE;
        }
    }

    this->ScratchPad = MODSTATUS_NO_TRANS;
    if (ModStat1.Status == MODSTATUS_IDLE) {
        this->ScratchPad = ucNewMod1State == MODSTATUS_IDLE ? 
                           MODSTATUS_IDLE_IDLE : MODSTATUS_IDLE_RUN;
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        this->ScratchPad = ucNewMod1State == MODSTATUS_IDLE ? 
                           MODSTATUS_RUN_IDLE : MODSTATUS_RUN_RUN;
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsLLBoxSlot::PostModStat1                           *
*                         ===========================                          *
* PURPOSE:  Post Receiver-Beware function for ModStat1 parameter.  After a     *
*           successfull module status change, this method invokes the Post     *
*           method for Point Execution State parameter (PtExecSt) on each slot.*
*           If there is a module transition from RUN to IDLE or vice versa,    *
*           this generates a module status event.  If the new module state is  *
*           RUN,sets DbValid flag to DB_VALID.                                 *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesful                     *
* NOTES: Verified with PMIO                                                    *
*******************************************************************************/
VOID clsLLBoxSlot::PostModStat1(UINT8) {
    if (ModStat1.Status == MODSTATUS_IDLE) {
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            SLOT(ucSlotNum)->InitSlot(WARM_INIT);
            UINT8 ucSaveExr = get_imask_exr();
            if (ucSaveExr > LVLPRI_IOPROC) {
                // Allow a pre-emption point so that STC can run. InitSlot 
                // which internally calls ComputeChecksum, takes about 600 
                // micro seccond per channel. For LLMUX with 64 channels,
                // this may lead to watchdog timeout if STC is blocked for 
                // the entire duration.
                set_imask_exr(LVLPRI_IOPROC);
                set_imask_exr(ucSaveExr);
            }
        }
    }
    if (ModStat1.Status == MODSTATUS_RUN) {
        DbValid = DB_VALID;// Mark the Database to be valid.
    }
    if(ScratchPad == MODSTATUS_IDLE_RUN) {
        for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
            CurrentScanCycle[ucFtaNum] = (UINT8)CONTEXT_ZERO;
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++)
            SLOT(ucSlotNum)->SetInitFlg(TRUE);
        AddModStatEvent(EVENTTYPE_NORMAL);
    }
    else if(ScratchPad == MODSTATUS_RUN_IDLE) {
        for(UINT8 ucFtaNum = 0; ucFtaNum < NO_OF_FTA; ucFtaNum++)
            CurrentScanCycle[ucFtaNum] = (UINT8)CONTEXT_ZERO;
        AddModStatEvent(EVENTTYPE_NORMAL);
    }
}
/*******************************************************************************
*                      clsLLBoxSlot::LLMuxIRQ1InterruptHandler                 *
*                      =======================================                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLBoxSlot::LLMuxIRQ1InterruptHandler(VOID) {
    UINT8 FtaNum = 0xFF;
    UINT8 ucMask = 0;
    
    while((ucMask = FPGA_ISR.FPGABYTEREG) != 0) {//TBD : This method gives priority to UART0. Implement RR
        if(ucMask & FPGA_INTFL_UART0_MASK) { FtaNum = 0;}//16550 UART interrupt
        else if(ucMask & FPGA_INTFL_UART1_MASK) { FtaNum = 1;}
        else if(ucMask & FPGA_INTFL_UART2_MASK) { FtaNum = 2;}
        else if(ucMask & FPGA_INTFL_UART3_MASK) { FtaNum = 3;}
        else {
	        TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxUnsourcedInt,(UINT32)ucMask);
            return;
        }
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        UINT8 IID = FTA_UART(FtaNum).INTR_ID;
        set_imask_exr(ucSaveExr);
        switch(IID) {
            case INTR_ID_CHARTIMEOUT:  //Get the character from FIFO
                {
                    FTA_UART(FtaNum).INTR_ENBL_REGISTER = DISABLE;
                    LLMuxHardware.CopyRxFromFifo(FtaNum);
	                TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxCharTmoutInt,(UINT32)FtaNum);
                }
                break;
            case INTR_ID_RXLINESTATUS: //Error condition. Trash RX
                TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxLneStatusInt,(UINT32)FtaNum);
                break;
            case INTR_ID_RXDATAAVLBLE: //Go grab the data from FIFO
                {
                    FTA_UART(FtaNum).INTR_ENBL_REGISTER = DISABLE;
                    LLMuxHardware.CopyRxFromFifo(FtaNum);
                }
                break;
            case INTR_ID_TXHLDRGEMPTY:
                {
                    while(FALSE == FTA_UART(FtaNum).XMT_COMPLETE);
                    FTA_UART(FtaNum).REQUEST_TO_SEND = 0;     //Disable transmitter
                    FTA_UART(FtaNum).XMTREGEMPTY_INTR_ENBL = DISABLE;//Disable Tx interrupt
                    FTA_UART(FtaNum).RCVLINESTS_INTR_ENBL  = ENABLE; //Enable Rx line status interrupt
                    FTA_UART(FtaNum).RCVDATAAVBL_INTR_ENBL = ENABLE; //Enable Rx data available interrupt
                }
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxUnknownInt,(UINT32)ucMask << 16 | (UINT32)IID);
                break;
        }
    }
}
/*******************************************************************************
*                          clsLLBoxSlot::PreCalibFta                           *
*                          ==========================                          *
* PURPOSE:  Pre Receiver-Beware function for CalibFta parameter.               *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesful                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
PASTATUS clsLLBoxSlot::PreCalibFta(UINT8 *a_Writebuffer, UINT8) {
    if(ModStat1.Status == MODSTATUS_RUN)//Not allowed in RUN
        return DO_STATE_MUST_BE_IDLE;
    if(TRUE == CalibFta[GetWriteIndex()-1]) {//If already CALIB in progress
        if(FTATYPE_NULL != FtaType[GetWriteIndex()-1]) //and Fta is present
            return DO_CALIB_IN_PROGRESS;//return progress
        if (TRUE == *(BOOL *)a_Writebuffer)//else return error
            return COM_FTA_MISSING_ERROR;  //if CALIB is requested
    }
    else {//If CALIB is not in progress
        if(FTATYPE_NULL == FtaType[GetWriteIndex()-1])//and FTA is not present
            return COM_FTA_MISSING_ERROR;//return error
        if(FTATYPE_RTD == FtaType[GetWriteIndex()-1])//return error if RTD type
            return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    return PA_OK;
}
/*******************************************************************************
*                          clsLLBoxSlot::PostCalibFta                          *
*                          ===========================                         *
* PURPOSE:  Post Receiver-Beware function for CalibFta  parameter.             *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesful                      *
* NOTES:                                                                       *
*           .                                                                  *
*******************************************************************************/
VOID clsLLBoxSlot::PostCalibFta(UINT8) {
    if(TRUE == CalibFta[GetWriteIndex()-1])
        SubmitReqToFifo(GetWriteIndex()-1,REQ_CALIBRATE);
}
/*******************************************************************************
*                          clsLLBoxSlot::PreFreq6050                           *
*                          ==========================                          *
* PURPOSE:  Pre Receiver-Beware function for Freq6050 parameter.               *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesful                      *
* NOTES:                                                                       *
*           .                                                                  *
*******************************************************************************/
PASTATUS  clsLLBoxSlot::PreFreq6050(UINT8 *a_Writebuffer, UINT8) {
  if (*(UINT8 *)a_Writebuffer > FREQ6050_FIFTYHZ)
      return DO_PARAMETER_INVALID;
  ScratchPad = Freq6050;
  if(Freq6050 != *(UINT8 *)a_Writebuffer)
    if ( GetModuleStatus() != MODSTATUS_IDLE )
        return DO_STATE_MUST_BE_IDLE;
  return PA_OK;
}
/*******************************************************************************
*                          clsLLBoxSlot::PostFreq6050                          *
*                          ==========================                          *
* PURPOSE:  Post Receiver-Beware function for Freq6050 parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesful                      *
* NOTES:                                                                       *
*           .                                                                  *
*******************************************************************************/
VOID clsLLBoxSlot::PostFreq6050(UINT8) {
    SLOT(1)->SetFreq6050(Freq6050);
  if(ScratchPad != Freq6050) {
    for(UINT8 ucIndex = 0; ucIndex < NO_OF_FTA; ucIndex++) {
      if(TRUE == FtaPresent[ucIndex]) {
          SubmitReqToFifo(ucIndex,REQ_FREQSEL);
      }
    }
  }
}
/*******************************************************************************
*                         clsLLBoxSlot::PreCheckPoint                         *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsLLBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    Freq6050 = FREQ6050_SIXTYHZ;
    return PA_OK;
}
/*******************************************************************************
*                          clsLLBoxSlot::LLMuxUartLoopBackTest                 *
*                          ===================================                 *
* PURPOSE:  Performs the Loopback test of FTA Uarts and posts the status in #74*
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
RETURNSTATUS clsLLBoxSlot::LLMuxUartLoopBackTest(VOID){
    SCIMESSAGE TestPattern;TestPattern.LONG = 0x07135700;
    static UINT8 sucXmtUart = 0;
    static UINT8 sucRcvUart = 0;
    static CONTEXT Context = CONTEXT_ZERO;
    const UINT8 UART_PAIR2 = 2; //UARTS 3 & 4
    UINT8 ucSaveExr;
    UARTLPBKSTS Status;
       
    switch (Context){//Transmit Context
    case CONTEXT_ZERO:
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        LLMuxHardware.SendRequest(sucXmtUart,TestPattern.LONG);
        FTA_UART(sucXmtUart).INTR_ENBL_REGISTER = DISABLE;
        set_imask_exr(ucSaveExr);
        break;
    case CONTEXT_ONE://Receive Context
        if(sucRcvUart == sucXmtUart){//Skip the uart which is under test
            sucRcvUart++;
        }
            Status = FactoryTestRxProcessing(sucRcvUart);
            SetFtaUartLpbkSts(sucRcvUart,Status);
            sucXmtUart++;
            if (sucXmtUart < UART_PAIR2)
                sucRcvUart = 0;//UART 0 & 1 pair
            else 
                sucRcvUart = UART_PAIR2;//UART 2 & 3 pair
            //Initialize and clear the Response[] buffer to have clean start with next UART
            LLMuxHardware.Initialize();
        break;
    default:
        return RETURNSTATUS_COMPLETE;
    }
    Context = CONTEXT(((Context+1)%2));

    if (sucXmtUart == NO_OF_FTA){
        LLMuxFTAUARTLoopBkTestInProg = FALSE;
        Context = CONTEXT_ZERO;
        sucXmtUart = 0;
        sucRcvUart = 0;
        return RETURNSTATUS_COMPLETE;
    }
    return RETURNSTATUS_INPROGRESS;
}
/*******************************************************************************
*                          clsLLBoxSlot::FactoryTestRxProcessing               *
*                          ==========================                          *
* PURPOSE:  Gathers the data recieved in Rcv Buffer and verifies the contents  *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UARTLPBKSTS clsLLBoxSlot::FactoryTestRxProcessing(UINT8 sucRcvUart) {
    const UINT8 REF_FTA_ID = 0;//In this test the FTA ID is always 0 in the message sent
    UARTLPBKSTS Status = OK;
    LLMuxHardware.CopyRxFromFifo(sucRcvUart);//Get the data from Rcv Buffer
    SCIRESPONSE Resp  = LLMuxHardware.GetResponse(sucRcvUart);
    if(0 == Resp.LONG) {
        Status = NO_RESP;
    }
    else if(Resp.CheckSum != LLMuxHardware.ComputeChecksum(Resp.LONG)) {
        Status = BAD_CKSM;
    }
    else if(REF_FTA_ID != Resp.FtaId) {
        Status = WRONG_ID;
    }
    return Status;
}

//Stubs
VOID clsLLBoxSlot::AppColdInit(VOID) {
}
VOID clsLLBoxSlot::AppPostSwap(VOID) {
}
VOID clsLLBoxSlot::AppPostSync(VOID) {
}

