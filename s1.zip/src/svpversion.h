/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : svpversion.h                                                *
*    Description : Turbine SVP IOM firmware version declaration.               *
*******************************************************************************/
#ifndef SVPVERSION_H
#define SVPVERSION_H
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#ifdef DEVELOPER_BUILD_OVERRIDE
const UINT8 VERSION_NUMBER  = VERSION;
const UINT8 REVISION_NUMBER = REVISION;
const UINT8 BUILD_NUMBER    = BUILD;
#else
const UINT8 VERSION_NUMBER  = 2;
const UINT8 REVISION_NUMBER = 2;
const UINT8 BUILD_NUMBER    = 1;
#endif

#endif
