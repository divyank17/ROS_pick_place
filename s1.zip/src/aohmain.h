/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohmain.h                                                   *
*    Description : common defines used by module                               *
*******************************************************************************/
#ifndef __AOHMAIN_H__
#define __AOHMAIN_H__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "utils.h"
#include "commonelectronics.h"
#include "tracelog.hpp"
#include "iol.hpp"
#include "hartstack.hpp"
#include "debug.hpp"
#include "scheduler.hpp"
#include "diag.h"
#include "wrmsgque.hpp"
#if !LOWCOST
#include "aohversion.h"
#else
#include "aoversion.h"
#endif
#include "aohslot.hpp"
#include "aohboxslot.hpp"
#include "aohardware.hpp"
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsAoHardware AoHardware;
extern clsEeprom Eeprom;
#endif 
