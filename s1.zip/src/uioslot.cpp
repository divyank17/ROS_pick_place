/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uioslot.cpp                                                 *
*    Description : Class clsUioSlot definition.                                *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "uioslot.hpp"
#include "uioboxslot.hpp"

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/

/*******************************************************************************
*                                 operator new                                 *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           a_ucSltNm    -   Slot number (0-relative SLOT number)              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID * clsUioSlot::operator new(UINT32, UINT8 a_ucSltNm)
{
    return (ucIomDbMemory + UIOBOXSLOT_SIZE + (a_ucSltNm * UIOSLOT_SIZE));
}

/*******************************************************************************
*                                  constructor                                 *
*                                  ==========                                  *
* PURPOSE: Constructor of clsUioSlot Class. This calls InitUioSlot() which     *
*          initializes clsUioSlot class members.                               *
* ARGUMENTS:                                                                   *
*           a_ucSltNm    -   Slot number (1-relative SLOT number)              *
* RETURN:   NONE                                                               *
* NOTES:    This constructor will internally invokes clsIoSlot class           *
*                   constructor.                                               *
*******************************************************************************/
clsUioSlot::clsUioSlot(UINT8 a_ucSltNm) : clsIoSlot(PNTTYPE_NOTCONFIGURED, a_ucSltNm)
{
    // validate the size of the configured slot does not exceed the external RAM
    _CompileAssert(CONFIGUREDSLOT_SIZE < MAX_CONFIGUREDSLOT_SIZE);

    // CONFIGUREDSLOT_SIZE is based on size of AO slot (clsAohSlot)...
    // must ensure the AO slot is the largest of the supported channel types
    _CompileAssert(sizeof(clsAohSlot) >= sizeof(clsDiSlot));
    _CompileAssert(sizeof(clsAohSlot) >= sizeof(clsAihSlot));
    _CompileAssert(sizeof(clsAohSlot) >= sizeof(clsDoSlot));

    // Commented for future maintenance
    //InitUioSlot(TRUE, TRUE);

    for (UINT8 ucCount = 0; ucCount < UIOSLOT_SPARESIZE; ucCount++) 
    {
        UioSlotSpare[ucCount] = 0;
    }
}

/*******************************************************************************
*                                  InitUioSlot                                 *
*                                  ==========                                  *
* PURPOSE: InitUioSlot function which initializes clsUioSlot class members.    *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
// Commented for future maintenance
/*VOID clsUioSlot::InitUioSlot(BOOL bFullInit, BOOL)
{
    if(bFullInit)
    {

    }
}*/

/*******************************************************************************
*                                  GetDataType                                 *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsUioSlot::GetDataType(UINT8 a_ucParamNumber)
{
    DATATYPE rtnDataType = DT_NONE;

    // check for INITPNTTYPE
    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        rtnDataType = DT_ENUM;
    }

    // check for CFGRESTORE
    else if (PARAMID_CFGRESTORE == a_ucParamNumber)
    {
        // <JRF ToDo> should this be requested from the configured slot?
        rtnDataType = DT_BLIND;
    }

    return rtnDataType;
}

/*******************************************************************************
*                                 GetAccessType                                *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsUioSlot::GetAccessType(UINT8 a_ucParamNumber)
{
    ACCESSTYPE rtnAccessType = AT_NONE;
    
    // check for INITPNTTYPE
    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        rtnAccessType = AT_SBYTE;
    }

    // check for CFGRESTORE
    else if (PARAMID_CFGRESTORE == a_ucParamNumber)
    {
        // <JRF ToDo> should this be requested from the configured slot?
        rtnAccessType = AT_PSET;
    }

    return rtnAccessType;
}

/*******************************************************************************
*                                 GetParamSize                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
*   Returns the size (in bytes) of the specified parameter                     *
* ARGUMENTS:                                                                   *
*   a_ucParamNumber - Parameter code                                           *
* RETURN:                                                                      *
*   Size of the specified parameter (in bytes)                                 *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsUioSlot::GetParamSize(UINT8 a_ucParamNumber)
{
    UINT8 rtnParamSize = 0;

    // check for INITPNTTYPE
    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        rtnParamSize = 1;
    }

    // check for CFGRESTORE
    else if (PARAMID_CFGRESTORE == a_ucParamNumber)
    {
        rtnParamSize = MAX_CHECKPOINT_SIZE;
    }

    return rtnParamSize;
}

/*******************************************************************************
*                                  GetParamPtr                                 *
*                                  ==========                                  *
* PURPOSE:                                                                     *
*   Returns a pointer to the parameter being read/written                      *
* ARGUMENTS:                                                                   *
*   a_ucParamNumber - Parameter code                                           *
* RETURN:                                                                      *
*   Pointer to the parameter being read/written                                *
* NOTES:                                                                       *
*   INITPNTTYPE is the only parameter supported                                *
*******************************************************************************/
UINT8 * clsUioSlot::GetParamPtr(UINT8 a_ucParamNumber)
{
    UINT8 * pRtnParamPtr = 0;

    // check for INITPNTTYPE
    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        pRtnParamPtr = (UINT8 *)(BOX->GetInitPntTypePtr(ChanNum));
    }

    return pRtnParamPtr;
}

/*******************************************************************************
*                                 GetAccessLock                                *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsUioSlot::GetAccessLock(UINT8 a_ucParamNumber)
{
    ACCESSLOCK rtnAccessLock = ALCK_VIEW;

    // check for INITPNTTYPE
    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        rtnAccessLock = ALCK_PBD; // AppDevOnly
    }

    // check for CFGRESTORE
    else if (PARAMID_CFGRESTORE == a_ucParamNumber)
    {
        // <JRF ToDo> should this be requested from the configured slot?
        rtnAccessLock = ALCK_VIEW; // ViewOnly
    }

    return rtnAccessLock;
}

/*******************************************************************************
*                               GetIsDbChecksumed                              *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsUioSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber)
{
    BOOL rtnIsDbChecksumed = FALSE;

    // check for INITPNTTYPE
    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        rtnIsDbChecksumed = FALSE;
    }

    // check for CFGRESTORE
    else if (PARAMID_CFGRESTORE == a_ucParamNumber)
    {
        // <JRF ToDo> should this be requested from the configured slot?
        rtnIsDbChecksumed = TRUE;
    }

    return rtnIsDbChecksumed;
}

/*******************************************************************************
*                              VerifyControlState                              *
*                              ==================                              *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsUioSlot::VerifyControlState(UINT8 a_ucParamNumber)
{
    PASTATUS rtnStatus = DO_ILLEGAL_VALUE;

    // check for INITPNTTYPE
    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        // INITPNTTYPE has ControlState of CONTROLSTATE_NONE
        // therefore, always return good status
        rtnStatus = PA_OK;
    }

    // check for CFGRESTORE
    else if (PARAMID_CFGRESTORE == a_ucParamNumber)
    {
        // checkpoint parameter has ControlState of CONTROLSTATE_NONE
        // therefore, always return good status
        rtnStatus = PA_OK;
    }

    return rtnStatus;
}

/*******************************************************************************
*                               InitSlotDatabase                               *
*                                  ==========                                  *
* PURPOSE:  Utility function which initializes the slot depending on point     *
*           configuration.                                                     *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioSlot::InitSlotDatabase(BOOL bFullInit)
{
    // <JRF ToDo> what needs to be done here?

    BOOL bObjCreate = FALSE;

    // <JRF ToDo> the clsUioSlot PntType has no meaning, should this call to 
    //            InitIoSlot() pass PNTTYPE_NOTCONFIGURED instead of PntType?
    InitIoSlot(PntType, bFullInit, bObjCreate);
    // Commented for future maintenance
    //InitUioSlot(bFullInit, bObjCreate);

    // <JRF ToDo> should we delete the configured slot if it exists?
    //            should we erase the configured slot memory?

    // Recompute SLOT checksum
    ComputeCheckSum();
}

/*******************************************************************************
*                                InactivateSlot                                *
*                                ==============                                *
* PURPOSE:                                                                     *
    Inactivates the slot                                                       *
* ARGUMENTS:                                                                   *
*   None                                                                       *                   
* RETURN:                                                                      *
*   None                                                                       *
* NOTES:                                                                       *
*   The UIO slot provides no *real* functionality, so slot is inactive by      *
*   default.                                                                   *
*******************************************************************************/
VOID clsUioSlot::InactivateSlot(VOID)
{
    // Nothing to do here...
    ;
}

/*******************************************************************************
*                                GetRedParamsPtr                               *
*                                ===============                               *
* PURPOSE: Return a pointer to redundant parameter structure                   *
* ARGUMENTS:                                                                   *
* RETURN: NULL                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID * clsUioSlot::GetRedParamsPtr(VOID)
{
    // UIO slot does not have any redundant parameter structure.
    // Nothing to do here. Return NULL
    return NULL;
}

/*******************************************************************************
*                               GetCheckPointPtr                               *
*                               ================                               *
* PURPOSE:                                                                     *
*   Returns a pointer to the channel's checkpoint structure                    *
* ARGUMENTS:                                                                   *
*   a_ucVer - Checkpoint Version                                               *
* RETURN:                                                                      *
    NULL; There is no checkpoint structure for a UIO slot                      *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
VOID * clsUioSlot::GetCheckPointPtr(UINT8)
{
    return NULL;
}

/*******************************************************************************
*                               GetCheckPointSize                              *
*                               =================                              *
* PURPOSE:                                                                     *
*   Returns the size (in bytes) of the channels checkpoint structure           *
* ARGUMENTS:                                                                   *
*   a_ucVer - Checkpoint Version                                               *
* RETURN:                                                                      *
*   200 (two hundred) bytes                                                    *
* NOTES:                                                                       *
*   The UIO slot has no checkpoint data                                        *
*******************************************************************************/
UINT8 clsUioSlot::GetCheckPointSize(UINT8)
{
    return MAX_CHECKPOINT_SIZE;
}

/*******************************************************************************
*                             CreateConfiguredSlot                             *
*                             ====================                             *
* PURPOSE:                                                                     *
*   Creates a channel of the specified type in external RAM.                   *
* ARGUMENTS:                                                                   *
*   InitPntType - The type of channel to create                                *
* RETURN:                                                                      *
*   NONE                                                                       *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
PASTATUS clsUioSlot::CreateConfiguredSlot(PNTTYPE InitPntType)
{   
    PASTATUS PaStatus = PA_OK;

    if ((PNTTYPE_ANALOGINPUT   != InitPntType) &&
        (PNTTYPE_ANALOGOUTPUT  != InitPntType) &&
        (PNTTYPE_DIGITALINPUT  != InitPntType) &&
        (PNTTYPE_DIGITALOUTPUT != InitPntType))
    {
        PaStatus = DO_ILLEGAL_VALUE;
    }
    else
    {
        // erase the configured slot memory in external RAM
        UINT16 * pConfSlot = EXTRAM_SLOT_ADDR(ChanNum);
        for (unsigned int i = 0; i < CONFIGUREDSLOT_SIZE; i++)
        {
            pConfSlot[i] = 0;
        }

        // Call HW interface to setup hardware for channel
        FPGA.ConfigureChannel(ChanNum, InitPntType);
        
        // create the configured slot
        switch (InitPntType)
        {            
            case PNTTYPE_DIGITALINPUT:
                pDatabase[ChanNum] = new(ChanNum - 1) clsDiSlot(ChanNum);
                TraceLog.AddToTrace(TRACEID_GENERIC, bcDiSlotLoaded, ChanNum);
                break;

            case PNTTYPE_ANALOGINPUT:
                pDatabase[ChanNum] = new(ChanNum - 1) clsAihSlot(ChanNum);
                TraceLog.AddToTrace(TRACEID_GENERIC, bcAiSlotLoaded, ChanNum);
                break;
           
            case PNTTYPE_DIGITALOUTPUT:
                pDatabase[ChanNum] = new(ChanNum - 1) clsDoSlot(ChanNum);
                TraceLog.AddToTrace(TRACEID_GENERIC, bcDoSlotLoaded, ChanNum);
                break;

            case PNTTYPE_ANALOGOUTPUT:
                pDatabase[ChanNum] = new(ChanNum - 1) clsAohSlot(ChanNum);
                TraceLog.AddToTrace(TRACEID_GENERIC, bcAoSlotLoaded, ChanNum);
                break;

            default:
                // unsupported point type, how did we get here?
                HardFail(HF_BADPROGRAMJUMP, UIOSLOT_CPP, __LINE__);
                break;
        }

        // set the InitPntType on the BoxSlot
        BOX->InitializeChannelData(ChanNum, InitPntType);
    }

    return PaStatus;
}

/*******************************************************************************
*                             DeleteConfiguredSlot                             *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioSlot::DeleteConfiguredSlot(VOID)
{
    // get the active softfails from the SLOT
    SlotSfBt = SLOT(ChanNum)->GetSlotSfBt();
    SlotSfLrs = SLOT(ChanNum)->GetSlotSfLrs();

    // Initialize the scan record 
    // NOTE: 
    //   Point type will be set to PNTTYPE_NOTCONFIGURED and channel masks
    //   will be cleared.
    BOX->InitializeChannelData(ChanNum, PNTTYPE_NOTCONFIGURED);

    // Update pDatabase to point to this UIO slot
    pDatabase[ChanNum] = this;

    // Call HW interface to place hardware in safe state
    FPGA.ConfigureChannel(ChanNum, PNTTYPE_NOTCONFIGURED);

    // perform full init on this UIO slot
    InitSlotDatabase(TRUE);

    // clear all active softfails for this channel
    SlotSfThrottleCount = 0;
    SlotSfThrottleByte  = 0;
    for (unsigned int sfIdx = 0; sfIdx < BYTESIZE; sfIdx++)
    {
        if (GetBit(SlotSfBt, sfIdx))
        {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, BOX->GetSlotSfMapEntry(sfIdx), FALSE, ChanNum);
        }
    }

    TraceLog.AddToTrace(TRACEID_GENERIC, bcConfiguredSlotDeleted, ChanNum);
}

/*******************************************************************************
*                                  GetPtExecSt                                 *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PTEXECST clsUioSlot::GetPtExecSt(VOID)
{
    return PTEXECST_INACTIVE;
}

/*******************************************************************************
*                                  GetPntType                                  *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PNTTYPE clsUioSlot::GetPntType(VOID)
{
    return PNTTYPE_NOTCONFIGURED;
}

/*******************************************************************************
*                             GetPtExecStParamId                               *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsUioSlot::GetPtExecStParamId(VOID)
{  
    // Point not configured
    return 0;
}

/*******************************************************************************
*                              GetLatestSlotChkPntVersion                      *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsUioSlot::GetLatestSlotChkPntVersion(VOID)
{
    UINT8 ucLatestChkPntVersion = 0;

    return ucLatestChkPntVersion;
}

/*******************************************************************************
*                                WriteParamData                                *
*                                ==============                                *
* PURPOSE:                                                                     *
*   During configuration restore, this method creates the channel type being   *
*   restored and forwards the write parameter request to the newly created     *
*   channel. In the case where configuration restore is not occurring, the     *
*   base class handles the write request.                                      *
* ARGUMENTS:                                                                   *
*   a_WriteBuffer   - Pointer to data that needs to be written                 *
*   a_ucParamNumber - Paramter Code                                            *
*   a_ucAccessLevel - Access Level                                             *
*   a_bDoChkSm      - Flag used to indicate if checksum should be calculated   *
*                     after the write.                                         *
* RETURN:                                                                      *
*   PA_OK if the write succeeded.                                              *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
PASTATUS clsUioSlot::WriteParamData(UINT8 *a_WriteBuffer,
                                    UINT8 a_ucParamNumber,
                                    UINT8 a_ucAccessLevel,
                                    BOOL  a_bDoChkSm)
{
    PASTATUS PaStatus = DO_PARAMETER_INVALID;

    if (PARAMID_INITPNTTYPE == a_ucParamNumber)
    {
        // create the channel in external RAM, the first byte in the write buffer is the point type
        PaStatus = CreateConfiguredSlot((PNTTYPE)a_WriteBuffer[0]);
    }

    else if (PARAMID_CFGRESTORE == a_ucParamNumber)
    {
        // create the channel in external RAM, the second byte in the write buffer is the point type
        PaStatus = CreateConfiguredSlot((PNTTYPE)a_WriteBuffer[1]);

        if (PA_OK == PaStatus)
        {
            UINT8 chkPntParamId = pDatabase[ChanNum]->GetSlotChkPntParamId();

            // Call WriteParamData on the newly created channel to restore the configuration,
            // use the slot's checkpoint paramId so all WriteParamData processing for checkpoint will be performed correctly
            PaStatus = pDatabase[ChanNum]->WriteParamData(a_WriteBuffer, chkPntParamId, a_ucAccessLevel, a_bDoChkSm);

            if (PA_OK != PaStatus)
            {
                // restore failed, delete the configured slot
                DeleteConfiguredSlot();
                TraceLog.AddToTrace(TRACEID_GENERIC, bcConfigRestoreFailed, ChanNum);
            }
        }
    }

    return PaStatus;
}

/*******************************************************************************
*                                WriteParamData                                *
*                                ==============                                *
* PURPOSE:                                                                     *
*   Write indexed parameter data.                                              *
* ARGUMENTS:                                                                   *
*   a_WriteBuffer   - Pointer to data that needs to be written                 *
*   a_ucParamNumber - Paramter Code                                            *
*   a_ucAccessLevel - Access Level                                             *
*   a_ucIndex       - Write Index                                              *
* RETURN:                                                                      *
*   PA_OK if the write succeeded.                                              *
* NOTES:                                                                       *
*   Call is forwarded to the base class.                                       *
*******************************************************************************/
PASTATUS clsUioSlot::WriteParamData(UINT8 *, UINT8, UINT8, UINT8)
{
    // Uio Slot doesn't support any indexed parameters
    return DO_PARAMETER_INVALID;
}

