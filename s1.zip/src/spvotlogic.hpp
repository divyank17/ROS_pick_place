/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spvotlogic.hpp                                              *
*    Description : Class clsVotLogicSlot declaration.                          *
*******************************************************************************/
#ifndef __SPVOTLOGIC_HPP__
#define __SPVOTLOGIC_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define SPVOTLOGIC_SIZE ((sizeof(clsVotLogicSlot)+(sizeof(clsVotLogicSlot )%2)) / 2)

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT8 SPDVOTE_SYNCREC_VER_1;

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
/* Voting Algortihm Options */
typedef enum tagVotAlg{
    NO_ALG = 0,
    MED = 1
}VOTALGGRP;

/* Group Channel Enable Options */
typedef enum tagGrpChEnab{
    CHANNEL_ONE = 0,
    CHANNEL_TWO = 1,
    CHANNEL_THREE = 2,
    CHANNEL_FOUR = 3
}GRP1VOTCHENB,GRP2VOTCHENB;

/* Group Min Inputs Options */
typedef enum tagGrpNMin{
    GRPNMIN_ONE = 0,
    GRPNMIN_TWO = 1,
    GRPNMIN_THREE = 2
}GRPNMIN;

/* Median Options */
typedef enum tagMedOpt{
    MEDOPT_MIN = 0,
    MEDOPT_MAX = 1
}MEDOPT;

/* PV Connections Options */
typedef enum tagPvConnect{
    PV_NONE = 0,
    PV_CHANNEL1 = 1,
    PV_CHANNEL2 = 2,
    PV_CHANNEL3 = 3,
    PV_CHANNEL4 = 4
}PVCONNECT;

class clsVotLogicSlot ; // forward declaration

/* Slot Database Parameter Info */
typedef struct tagVotBlockParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsVotLogicSlot ::* PrePtr)(UINT8 *,UINT8);
    VOID     (clsVotLogicSlot ::* PostPtr)(UINT8);
    VOID *   (clsVotLogicSlot ::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} VOTBLOCKPARAMINFO;

/*******************************************************************************
*                                   clsVotLogicSlot                            *
*                                   ===============                            *
*******************************************************************************/
class clsVotLogicSlot : public clsIomSlot 
{
protected:
    // Member variables
    static UINT8 SpSpdVoteSlotChkpntVersion;

    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SpSpdVoteSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SpSpdVoteSlotChkpntVersion;}
private:
    //Connection Parameters
    FLOAT32   Pv1;
    FLOAT32   Pv2;
    FLOAT32   Pv3;
    FLOAT32   Pv4;
    INT32     Pv1Connect;
    INT32     Pv2Connect;
    INT32     Pv3Connect;
    INT32     Pv4Connect;
    FLOAT32   VotPv1100;
    FLOAT32   VotPv2100;
    //

    //Confiuration Parameters
    VOTALGGRP VotAlgGrp1;      // Voting algorithm for group1
    VOTALGGRP VotAlgGrp2;      // Voting algorithm for group2
    BOOL      Grp1VotChEnb[4]; // Group 1 Voting channels enable
    BOOL      Grp2VotChEnb[4]; // Group 2 Voting channels enable
    GRPNMIN   Grp1nMin;        // Number of valid input channels in group1
    GRPNMIN   Grp2nMin;        // Number of valid input channels in group2
    MEDOPT    MedOpt1;         // Median Option (Min or Max) for group1
    MEDOPT    MedOpt2;         // Median Option (Min or Max) for group2
    BOOL      VotPV1OvrTstEnb;
    BOOL      VotPV2OvrTstEnb;
    //

    //Monitoring Parameters
    BOOL      Grp1IgnFl;
    BOOL      Grp2IgnFl;
    BOOL      Grp1IgnoredFl[4];
    BOOL      Grp2IgnoredFl[4];
    FLOAT32   VotPV1;
    FLOAT32   VotPV2;
    FLOAT32   VotROC1;
    FLOAT32   VotROC2;
    PVVALST   VotPV1Sts;
    PVVALST   VotPV2Sts;
    PVVALST   VotROC1Sts;
    PVVALST   VotROC2Sts;
    FLOAT32   LastVotPV1;
    FLOAT32   LastVotPV2;
    FLOAT32   LastVotROC1;
    FLOAT32   LastVotROC2;
    FLOAT32   VotPVMax;
    FLOAT32   VotPVOnTrip;
    FLOAT32   VotROCPosHhOnTrip;
    BOOL      ResetTrip;  
    //

    //Trip Parameters
    FLOAT32     VotPv1HiAlmTp;
    FLOAT32     VotPv2HiAlmTp;
    FLOAT32     VotPv1HhAlmTp;
    FLOAT32     VotPv2HhAlmTp;
    FLOAT32     VotRoc1PosHiAlmTp;
    FLOAT32     VotRoc2PosHiAlmTp;
    FLOAT32     VotRoc1PosHhAlmTp;
    FLOAT32     VotRoc2PosHhAlmTp;
    FLOAT32     VotRoc1NegAlmTp;
    FLOAT32     VotRoc2NegAlmTp;
    BOOL        VotPv1HiAlmFl;
    BOOL        VotPv2HiAlmFl;
    BOOL        VotPv1HhAlmFl;
    BOOL        VotPv1HhAlmFlWrst;
    BOOL        VotPv2HhAlmFl;
    BOOL        VotPv2HhAlmFlWrst;
    BOOL        VotRoc1PosHiAlmFl;
    BOOL        VotRoc2PosHiAlmFl;
    BOOL        VotRoc1PosHhAlmFl;
    BOOL        VotRoc2PosHhAlmFl;
    BOOL        VotRoc1PosHhAlmFlWrst;
    BOOL        VotRoc2PosHhAlmFlWrst;
    //

    //Not Used
    FLOAT32     VotRoc1PosAlmTp;
    FLOAT32     VotRoc2PosAlmTp;
    BOOL        VotRoc1NegAlmFl;
    BOOL        VotRoc2NegAlmFl;
    INT8        VotRoc1PosAlmLmt;
    INT8        VotRoc2PosAlmLmt;
    INT8        VotRoc1NegAlmLmt;
    INT8        VotRoc2NegAlmLmt;
    //

    //Shared ram slot data pointer
    VOTESHRAMSLOTDATA *pVoteShramSlotData;      
    //

    //Static Member variables
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const VOTBLOCKPARAMINFO tblParamInfo[256];
    //

    //Method to Initial member variables
    VOID InitVotBlock(BOOL bFullInit, BOOL bObjCreate);
    //

    //clsVotLogicSlot Class Varibles GetPtr methods
    VOID *GetPntTypePtr(VOID); 
    VOID *GetPtExecStPtr(VOID); 
    VOID *GetVotPV1OvrTstEnbPtr(VOID);
    VOID *GetVotPV2OvrTstEnbPtr(VOID);
    VOID *GetResetTripPtr(VOID);
    VOID *GetVotROCPosHhOnTripPtr(VOID);
    VOID *GetVotPVOnTripPtr(VOID);
    VOID *GetVotPVMaxPtr(VOID);
    VOID *GetVotPV1Ptr(VOID);  
    VOID *GetVotPV2Ptr(VOID);  
    VOID *GetVotPV1100Ptr(VOID);  
    VOID *GetVotPV2100Ptr(VOID);  
    VOID *GetVotROC1Ptr(VOID); 
    VOID *GetVotROC2Ptr(VOID); 
    VOID *GetPv1Ptr(VOID);
    VOID *GetPv2Ptr(VOID);
    VOID *GetPv3Ptr(VOID);
    VOID *GetPv4Ptr(VOID);
    VOID *GetPv1ConnectPtr(VOID);
    VOID *GetPv2ConnectPtr(VOID);
    VOID *GetPv3ConnectPtr(VOID);
    VOID *GetPv4ConnectPtr(VOID);
    VOID *GetGrp1IgnFlPtr(VOID);    
    VOID *GetGrp2IgnFlPtr(VOID);    
    VOID *GetGrp1IgnoredFlPtr(VOID);
    VOID *GetGrp2IgnoredFlPtr(VOID);
    VOID *GetVotAlgGrp1Ptr(VOID);
    VOID *GetVotAlgGrp2Ptr(VOID);
    VOID *GetGrp1VotChEnbPtr(VOID);
    VOID *GetGrp2VotChEnbPtr(VOID);
    VOID *GetGrp1nMinPtr(VOID);
    VOID *GetGrp2nMinPtr(VOID);
    VOID *GetMedOpt1Ptr(VOID); 
    VOID *GetMedOpt2Ptr(VOID); 
    VOID *GetVotPV1StsPtr(VOID);  
    VOID *GetVotPV2StsPtr(VOID);  
    VOID *GetVotROC1StsPtr(VOID); 
    VOID *GetVotROC2StsPtr(VOID); 
    VOID *GetLastVotPV1Ptr(VOID); 
    VOID *GetLastVotPV2Ptr(VOID); 
    VOID *GetLastVotROC1Ptr(VOID);
    VOID *GetLastVotROC2Ptr(VOID);
    VOID *GetVotPv1HiAlmTpPtr(VOID);
    VOID *GetVotPv2HiAlmTpPtr(VOID);
    VOID *GetVotPv1HhAlmTpPtr(VOID);
    VOID *GetVotPv2HhAlmTpPtr(VOID);
    VOID *GetVotRoc1PosHiAlmTpPtr(VOID);
    VOID *GetVotRoc2PosHiAlmTpPtr(VOID);
    VOID *GetVotRoc1PosHhAlmTpPtr(VOID);
    VOID *GetVotRoc2PosHhAlmTpPtr(VOID);
    VOID *GetVotRoc1NegAlmTpPtr(VOID);
    VOID *GetVotRoc2NegAlmTpPtr(VOID);
    VOID *GetVotPv1HiAlmFlPtr(VOID);
    VOID *GetVotPv1HiAlmInvFlPtr(VOID);
    VOID *GetVotPv2HiAlmFlPtr(VOID);
    VOID *GetVotPv2HiAlmInvFlPtr(VOID);
    VOID *GetVotPv1HhAlmFlPtr(VOID);
    VOID *GetVotPv1HhAlmInvFlPtr(VOID);
    VOID *GetVotPv1HhAlmFlWrstPtr(VOID);
    VOID *GetVotPv1HhAlmInvFlWrstPtr(VOID);
    VOID *GetVotPv2HhAlmFlPtr(VOID);
    VOID *GetVotPv2HhAlmInvFlPtr(VOID);
    VOID *GetVotPv2HhAlmFlWrstPtr(VOID);
    VOID *GetVotPv2HhAlmInvFlWrstPtr(VOID);    
    VOID *GetVotRoc1NegAlmFlPtr(VOID);
    VOID *GetVotRoc2NegAlmFlPtr(VOID);
    VOID *GetVotRoc1NegAlmInvFlPtr(VOID);
    VOID *GetVotRoc2NegAlmInvFlPtr(VOID);
    VOID *GetVotRoc1PosHiAlmFlPtr(VOID);  
    VOID *GetVotRoc1PosHiAlmInvFlPtr(VOID);  
    VOID *GetVotRoc2PosHiAlmFlPtr(VOID);  
    VOID *GetVotRoc2PosHiAlmInvFlPtr(VOID);  
    VOID *GetVotRoc1PosHhAlmFlPtr(VOID);  
    VOID *GetVotRoc1PosHhAlmInvFlPtr(VOID);  
    VOID *GetVotRoc1PosHhAlmFlWrstPtr(VOID);
    VOID *GetVotRoc1PosHhAlmInvFlWrstPtr(VOID);
    VOID *GetVotRoc2PosHhAlmFlPtr(VOID);  
    VOID *GetVotRoc2PosHhAlmInvFlPtr(VOID); 
    VOID *GetVotRoc2PosHhAlmFlWrstPtr(VOID);  
    VOID *GetVotRoc2PosHhAlmInvFlWrstPtr(VOID);
    VOID *GetVotRoc1PosAlmLmtPtr(VOID); 
    VOID *GetVotRoc2PosAlmLmtPtr(VOID); 
    VOID *GetVotRoc1NegAlmLmtPtr(VOID); 
    VOID *GetVotRoc2NegAlmLmtPtr(VOID); 
    VOID *GetVotRoc1PosAlmTpPtr(VOID); 
    VOID *GetVotRoc2PosAlmTpPtr(VOID); 
    //

    //Static Varibles GetPtr methods
    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[SpSpdVoteSlotChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetRedParamsPtr(VOID)  { return (VOID *)RedParams; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    //  

    //Database Access Related Methods
    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    //

    clsVotLogicSlot (const clsVotLogicSlot &); // Safeguard against def copy constr.
    clsVotLogicSlot & operator=(const clsVotLogicSlot &); // and default assignment.
public:
    clsVotLogicSlot (UINT8);
    ~clsVotLogicSlot (VOID) { HardFail(HF_INVPROGRAMEXEC,TCSPVOTBLOCK_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,TCSPVOTBLOCK_HPP,__LINE__); }

    //Database Access Related Methods    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    virtual UINT8 *GetParameterPtr(UINT8 a_ucParamNumber){ return GetParamPtr(a_ucParamNumber); }
    //

    //Method to Initial member variables
    VOID InitSlotDatabase(BOOL bFullInit);
    //

    //Redundacny Dump Related Struct and Methods
    // Pack the sync record as tightly as possible to 
    // minimize iolink transmission time.
    // Wherever multiple parameters are packed within
    // a byte, the zero indexed item is stored in the 
    // least significant bits.
    #pragma pack 2
    typedef struct strSpVoteSyncRec
    {
        UINT16    Header;             // The first two bytes of dump record should always represent version. Do not change this. 
        UINT8     PntType;            // from clsIomSlot
        UINT8     PtExecSt;           // from clsIomSlot
        UINT8     VotAlgGrpAll;       // Voting algorithm for grp1 and grp2
        UINT8     GrpVotChEnbAll;     // Group 1 and 2 Voting channels enable.
        UINT8     GrpAllnMin;         // Number of valid input channels in grp1 and grp2
        UINT8     MedOptAll;          // Median Option (Min or Max) for grp1 and grp2
        UINT8     VotPVAllOvrTstEnb;  
        UINT8     GrpxIgnoredFlCopy;
        UINT8     VotPv1HhAlmFlWrst;
        UINT8     VotPv2HhAlmFlWrst;
        UINT8     VotRoc1PosHhAlmFlWrst;
        UINT8     VotRoc2PosHhAlmFlWrst;
        FLOAT32   VotPVOnTrip;
        FLOAT32   VotROCPosHhOnTrip;
        FLOAT32   VotPv1HiAlmTp;
        FLOAT32   VotPv2HiAlmTp;
        FLOAT32   VotPv1HhAlmTp;
        FLOAT32   VotRoc1PosHiAlmTp;
        FLOAT32   VotRoc2PosHiAlmTp;
        FLOAT32   VotRoc1PosHhAlmTp;
        FLOAT32   VotRoc2PosHhAlmTp;
        FLOAT32   VotRoc1NegAlmTp;
        FLOAT32   VotRoc2NegAlmTp;
        FLOAT32   VotPv2HhAlmTp;
        INT32     Pv1Connect;
        INT32     Pv2Connect;
        INT32     Pv3Connect;
        INT32     Pv4Connect;
        FLOAT32   VotPvMax;
    }SYNCRECORD,*PSYNCRECORD;
    #pragma unpack
    UINT32      GetRedSlotSize(VOID) { return sizeof(SYNCRECORD); }
    PASTATUS    GetDumpData(UINT8* const pDump,const UINT8 MaxSize);
    PASTATUS    StoreDumpData(UINT8* const pDump);
    //
};

#endif //__SPVOTLOGIC_HPP__