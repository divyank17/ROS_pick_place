/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcdoslot.hpp                                                *
*    Description : Class clsDoSlot declaration.                                *
*******************************************************************************/
#ifndef __TCDOSLOT_HPP__
#define __TCDOSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define TCDOSLOT_SIZE ((sizeof(clsDoSlot) + (sizeof(clsDoSlot) % 2)) / 2)

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SPDO_SYNC_VER_1;
//

const FLOAT32 OP_MAXVALUE      = 100.0;
const FLOAT32 OP_MINVALUE      = 0.0;
const FLOAT32 PULSE_MAXVALUE   = 60.0;
const FLOAT32 PULSE_MINVALUE   = 0.0;
const FLOAT32 MAX_PERIOD       = 120.0;
const FLOAT32 MIN_PERIOD       = 1.0;

#define NUM_ONE             1
#define NUM_TWENTY          20
#define NUM_TWENTY_TWO      22
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
/* DO Type Options*/
typedef enum tagDoType {
    DOTYPE_STATUS   = 0,
    DOTYPE_PWM      = 1,
    DOTYPE_ONPULSE  = 2,
    DOTYPE_OFFPULSE = 3
}DOTYPE;

/* Interlock Direction Options */
typedef enum tagIntLckInptDxn {
    INTERLOCK_DIRECT   = 0,
    INTERLOCK_REVERS  = 1
}INTLCKINPTDXN;

class clsDoSlot; // forward declaration

/* Slot Database Parameter Info */
typedef struct tagDoSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsDoSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsDoSlot::* PostPtr)(UINT8);
    VOID *   (clsDoSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} DOSLOTPARAMINFO;
/*******************************************************************************
*                                   clsDoSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsDoSlot : public clsOutSlot {
protected:

    //Member Variables
    BOOL    SO;
    BOOL    LastSO;
    BOOL    SoInitVal;
    BOOL    SoReadFailFlag;
    BOOL    InitReq;
    FLOAT32 OnPulse;
    DOTYPE  DOType;
    BOOL    StdbyMan;
    INT32 IntLck1Src;
    INT32 IntLck2Src;
    INT32 IntLck3Src;
    INT32 IntLck4Src;
    INT32 IntLck5Src;
    INT32 IntLck6Src;
    INT32 IntLck7Src;
    INT32 IntLck8Src;
    INTLCKINPTDXN IntLck1Dxn;
    INTLCKINPTDXN IntLck2Dxn;
    INTLCKINPTDXN IntLck3Dxn;
    INTLCKINPTDXN IntLck4Dxn;
    INTLCKINPTDXN IntLck5Dxn;
    INTLCKINPTDXN IntLck6Dxn;
    INTLCKINPTDXN IntLck7Dxn;
    INTLCKINPTDXN IntLck8Dxn;
    BOOL IntLck1Status;     
    BOOL IntLck2Status;     
    BOOL IntLck3Status;     
    BOOL IntLck4Status;     
    BOOL IntLck5Status;     
    BOOL IntLck6Status;     
    BOOL IntLck7Status;     
    BOOL IntLck8Status;
    BOOL IntLck1;     
    BOOL IntLck2;     
    BOOL IntLck3;     
    BOOL IntLck4;     
    BOOL IntLck5;     
    BOOL IntLck6;     
    BOOL IntLck7;     
    BOOL IntLck8;
    UINT8 LastTripSrc;
    BLIND   StartNext;
    UINT16  PRDTime;
    UINT16  PWMPulseTime;
    FLOAT32 OffPulse;
    FLOAT32 Op;
    FLOAT32 DO_Op;
    FLOAT32 Period;
    UINT32  TPStart;
    UINT32  TPEnd;
    UINT16  PulseInProgress;
    BOOL    PWMInitR;
    BOOL    ReadyToGo;
    //

    //Shared ram slot data pointer
    DOSHRAMSLOTDATA *pDoShramSlotData;

    //Static Member variables
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const DOSLOTPARAMINFO tblParamInfo[256];
    static UINT8 SpDoSlotChkpntVersion;
    //

    //Method to Initial member variables
    VOID InitDoSlot(BOOL bFullInit, BOOL bObjCreate);

    //Overrided clsIoSlot Class Varibles GetPtr methods
    VOID *GetPntTypePtr(VOID); 
    VOID *GetPtExecStPtr(VOID);
    //

    //clsDoSlot Class Varibles GetPtr methods
    inline VOID *GetLocalManPtr(VOID)       { return &LocalMan; }
    inline VOID *GetOptDirPtr(VOID)         { return &OptDir; }
    VOID *GetFaultStatePtr(VOID);
    VOID *GetFaultOptPtr(VOID);
    VOID *GetFaultValuePtr(VOID);
    VOID *GetModePtr(VOID);
    VOID *GetModeAttrPtr(VOID);
    VOID *GetModePermPtr(VOID);
    VOID *GetNModePtr(VOID);
    VOID *GetNModeAttrPtr(VOID);
    VOID *GetRedTagPtr(VOID);
    VOID *GetStdbyManPtr(VOID);
    VOID *GetSoInitValPtr(VOID);   
    VOID *GetSoReadFailFlPtr(VOID);
    VOID *GetSOPtr(VOID);     
    VOID *GetOnPulsePtr(VOID);
    VOID *GetDOTypePtr(VOID);
    VOID *GetInitReqPtr(VOID);
    VOID *GetIntLck1SrcPtr(VOID);
    VOID *GetIntLck2SrcPtr(VOID);
    VOID *GetIntLck3SrcPtr(VOID);
    VOID *GetIntLck4SrcPtr(VOID);
    VOID *GetIntLck5SrcPtr(VOID);
    VOID *GetIntLck6SrcPtr(VOID);
    VOID *GetIntLck7SrcPtr(VOID);
    VOID *GetIntLck8SrcPtr(VOID);
    VOID *GetReadyToGoPtr(VOID);
    VOID *GetIntLck1DxnPtr(VOID);
    VOID *GetIntLck2DxnPtr(VOID);
    VOID *GetIntLck3DxnPtr(VOID);
    VOID *GetIntLck4DxnPtr(VOID);
    VOID *GetIntLck5DxnPtr(VOID);
    VOID *GetIntLck6DxnPtr(VOID);
    VOID *GetIntLck7DxnPtr(VOID);
    VOID *GetIntLck8DxnPtr(VOID);
    VOID *GetIntLck1Ptr(VOID);
    VOID *GetIntLck2Ptr(VOID);
    VOID *GetIntLck3Ptr(VOID);
    VOID *GetIntLck4Ptr(VOID);
    VOID *GetIntLck5Ptr(VOID);
    VOID *GetIntLck6Ptr(VOID);
    VOID *GetIntLck7Ptr(VOID);
    VOID *GetIntLck8Ptr(VOID);
    VOID *GetIntLck1StatusPtr(VOID);
    VOID *GetIntLck2StatusPtr(VOID);
    VOID *GetIntLck3StatusPtr(VOID);
    VOID *GetIntLck4StatusPtr(VOID);
    VOID *GetIntLck5StatusPtr(VOID);
    VOID *GetIntLck6StatusPtr(VOID);
    VOID *GetIntLck7StatusPtr(VOID);
    VOID *GetIntLck8StatusPtr(VOID);
    VOID *GetLastTripSrcPtr(VOID);
    inline VOID *GetPeriodPtr(VOID)         {return &Period;}
    inline VOID *GetOffPulsePtr(VOID)       {return &OffPulse;}
    inline VOID *GetPRDTimePtr(VOID)        {return &PRDTime;}
    inline VOID *GetPWMPulseTimePtr(VOID)   {return &PWMPulseTime;}
    inline VOID *GetStartNextPtr(VOID)      {return &StartNext;}
    inline VOID *GetTPStartPtr(VOID)        {return &TPStart;}
    inline VOID *GetTPEndPtr(VOID)          {return &TPEnd;}
    inline VOID *GetPWMInitRPtr(VOID)       {return &PWMInitR;}
    inline VOID *GetOpPtr(VOID)             {return &Op;};
    //

    //Static Varibles GetPtr methods
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SpDoSlotChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    //

    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SpDoSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SpDoSlotChkpntVersion;}

    //Database Access Related Methods
    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    //

    clsDoSlot(const clsDoSlot&); // Safeguard against default copy constructor
    clsDoSlot& operator=(const clsDoSlot&); // and default assignment
public:
    clsDoSlot(UINT8);
    ~clsDoSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,TCDOSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,TCDOSLOT_HPP,__LINE__); }

    //Database Access Related Methods    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    //

    //Method to Initial member variables
    VOID InitSlotDatabase(BOOL bFullInit);
    //

    //Redundacny Dump Related Struct and Methods
    #pragma pack 2
    typedef struct strSpDoSyncRec
    {
        UINT16      Header;     // The first two bytes of dump record should always represent version. Do not change this. 
        UINT8       PntType;
        UINT8       PtExecSt;
        UINT8       FaultState;
        UINT8       FaultOpt;
        UINT8       Mode;
        UINT8       ModeAttr;
        UINT8       ModePerm;
        UINT8       NMode;
        UINT8       NModeAttr;
        UINT8       RedTag;
        UINT8       LocalMan;
        UINT8       SoInitVal;
        UINT8       SoReadFailFlag;
        UINT8       InitReq;
        UINT8       DOType;
        INT32       IntLck1Src;
        INT32       IntLck2Src;
        INT32       IntLck3Src;
        INT32       IntLck4Src;
        INT32       IntLck5Src;
        INT32       IntLck6Src;
        INT32       IntLck7Src;
        INT32       IntLck8Src;
        UINT8       IntLck1Dxn;
        UINT8       IntLck2Dxn;
        UINT8       IntLck3Dxn;
        UINT8       IntLck4Dxn;
        UINT8       IntLck5Dxn;
        UINT8       IntLck6Dxn;
        UINT8       IntLck7Dxn;
        UINT8       IntLck8Dxn;
        UINT8       Unused;
        FLOAT32     OnPulse;
        FLOAT32     FaultValue;
        UINT8       SO;
        UINT8       LastSO;
        UINT32  TPEnd;
        UINT16  PulseInProgress;
        UINT8 LastTripSrc;
    } SYNCRECORD,*PSYNCRECORD;
    #pragma unpack    
    UINT32 GetRedSlotSize(VOID) { return sizeof(SYNCRECORD); }
    PASTATUS GetDumpData(UINT8* const pDump,const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    //
};

#endif
