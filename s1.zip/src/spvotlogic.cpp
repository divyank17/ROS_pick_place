/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spvotlogic.cpp                                              *
*    Description : Class clsVotLogicSlot definition                            *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern SHRAMDATA ShramData;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsVotLogicSlot::RedParams[] = {
    kSpSpdVotPnPntType,
    kSpSpdVotPnVotAlgGrp1,
    kSpSpdVotPnVotAlgGrp2,
    kSpSpdVotPnVotPv1hiAlm_Tp,
    kSpSpdVotPnVotPv1HhAlm_Tp,
    kSpSpdVotPnVotRoc1PosHiAlm_Tp,
    kSpSpdVotPnVotRoc1PosHhAlm_Tp,
    kSpSpdVotPnVotPv2hiAlm_Tp,
    kSpSpdVotPnVotPv2HhAlm_Tp,
    kSpSpdVotPnVotRoc2PosHiAlm_Tp,
    kSpSpdVotPnVotRoc2PosHhAlm_Tp,
    kSpSpdVotPnMedOpt1,
    kSpSpdVotPnMedOpt2,
    kSpSpdVotPnGrp1NMin,
    kSpSpdVotPnGRP2NMin,
    kSpSpdVotPnPv1Conn,
    kSpSpdVotPnPv2Conn,
    kSpSpdVotPnPv3Conn,
    kSpSpdVotPnPv4Conn,
    kSpSpdVotPnVotPv1OvrtStEnb,
    kSpSpdVotPnVotPv2OvrtStEnb,
    kSpSpdVotPnGrp1VotChnbBlind,
    kSpSpdVotPnGrp2VotChnbBlind,
    kSpSpdVotPnPtExecSt,
    kSpSpdVotPnVotPv1HhAlm_Flwrst,
    kSpSpdVotPnVotPv2HhAlm_Flwrst,
    kSpSpdVotPnVotRoc1PosHhAlm_Flwrst,
    kSpSpdVotPnVotRoc2PosHhAlm_Flwrst,
    0 // Terminator
};

const VOTBLOCKPARAMINFO clsVotLogicSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 29
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetGrp1VotChEnbPtr,TRUE,                     // 30 GRP1VOTCHENB
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetGrp2VotChEnbPtr,TRUE,                     // 31 GRP2VOTCHENB
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 44
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPV1100Ptr,FALSE,                      // 45 VotPV1100
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPV2100Ptr,FALSE,                      // 46 VotPV2100
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPntTypePtr,TRUE,                             // 51 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPtExecStPtr,TRUE,                           // 52 PtExecSt
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetVotAlgGrp1Ptr,TRUE,                          // 53 VotAlgGrp1
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetVotAlgGrp2Ptr,TRUE,                          // 54 VotAlgGrp2
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetGrp1VotChEnbPtr,FALSE,                       // 55 Grp1VotChEnb
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetGrp2VotChEnbPtr,FALSE,                       // 56 Grp2VotChEnb
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetGrp1nMinPtr,TRUE,                            // 57 Grp1nMin
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetGrp2nMinPtr,TRUE,                            // 58 Grp2nMin
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetMedOpt1Ptr,TRUE,                             // 59 MedOpt1
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetMedOpt2Ptr,TRUE,                             // 60 MedOpt2
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotPV1OvrTstEnbPtr,TRUE,                    // 61 VotPV1OvrTstEnb
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotPV2OvrTstEnbPtr,TRUE,                    // 62 VotPV2OvrTstEnb
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetGrp1IgnFlPtr,FALSE,                         // 63 Grp1IgnFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetGrp2IgnFlPtr,FALSE,                         // 64 Grp2IgnFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetGrp1IgnoredFlPtr,FALSE,                     // 65 Grp1IgnoredFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetGrp2IgnoredFlPtr,FALSE,                     // 66 Grp2IgnoredFl
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPV1StsPtr,FALSE,                         // 67 VotPV1Sts
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPV2StsPtr,FALSE,                         // 68 VotPV2Sts
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotROC1StsPtr,FALSE,                        // 69 VotROC1Sts
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotROC2StsPtr,FALSE,                        // 70 VotROC2Sts
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastVotPV1Ptr,FALSE,                     // 71 LastVotPV1
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastVotPV2Ptr,FALSE,                     // 72 LastVotPV2
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastVotROC1Ptr,FALSE,                    // 73 LastVotROC1
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastVotROC2Ptr,FALSE,                    // 74 LastVotROC2
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPV1Ptr,FALSE,                         // 75 VotPV1
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPV2Ptr,FALSE,                         // 76 VotPV2
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotROC1Ptr,FALSE,                        // 77 VotROC1
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotROC2Ptr,FALSE,                        // 78 VotROC2
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 79
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPVMaxPtr,FALSE,                       // 80 VotPVMax
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPVOnTripPtr,FALSE,                    // 81 VotPVOnTrip
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotROCPosHhOnTripPtr,FALSE,              // 82 VotROCPosHhOnTrip
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 84    
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 87
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotPv1HiAlmTpPtr,TRUE,                   // 88 VotPv1HiAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 93
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPv1HiAlmFlPtr,FALSE,                     // 94 VotPv1HiAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 95
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotPv2HiAlmTpPtr,TRUE,                   // 96 VotPv2HiAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 101
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPv2HiAlmFlPtr,FALSE,                     // 102 VotPv2HiAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 103
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotPv1HhAlmTpPtr,TRUE,                   // 104 VotPv1HhAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 109
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPv1HhAlmFlPtr,FALSE,                     // 110 VotPv1HhAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 111
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPv1HhAlmFlWrstPtr,FALSE,                 // 112 VotPv1HhAlmFlWrst
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 113
    DT_BLIND,75,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCheckPointPtr,FALSE,                       // 114 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 116
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 119
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPv2HhAlmFlPtr,FALSE,                     // 120 VotPv2HhAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 121
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotPv2HhAlmFlWrstPtr,FALSE,                 // 122 VotPv2HhAlmFlWrst
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 123
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc1PosHiAlmTpPtr,TRUE,               // 124 VotRoc1PosHiAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 126
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc1PosHiAlmFlPtr,FALSE,                 // 127 VotRoc1PosHiAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 128
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc2PosHiAlmTpPtr,TRUE,               // 129 VotRoc2PosHiAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 131
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc2PosHiAlmFlPtr,FALSE,                 // 132 VotRoc2PosHiAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 133
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc1PosHhAlmTpPtr,TRUE,               // 134 VotRoc1PosHhAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 136
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc1PosHhAlmFlPtr,FALSE,                 // 137 VotRoc1PosHhAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 138
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc1PosHhAlmFlWrstPtr,FALSE,             // 139 VotRoc1PosHhAlmIFlWrst
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 140
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc2PosHhAlmTpPtr,TRUE,               // 141 VotRoc2PosHhAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 142
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 143
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc2PosHhAlmFlPtr,FALSE,                 // 144 VotRoc2PosHhAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 145
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc2PosHhAlmFlWrstPtr,FALSE,             // 146 VotRoc2PosHhAlmIFlWrst
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 147
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc1NegAlmTpPtr,TRUE,                 // 148 VotRoc1NegAlmTp
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 150
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc1NegAlmFlPtr,FALSE,                   // 151 VotRoc1NegAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 152
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc2NegAlmTpPtr,TRUE,                 // 153 VotRoc2NegAlmTp
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 155
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetVotRoc2NegAlmFlPtr,FALSE,                   // 156 VotRoc2NegAlmFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 157
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc1PosHiAlmTpPtr,FALSE,              // 158 VotRoc1PosHiAlmTp
    DT_UINT8,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc1PosAlmLmtPtr,FALSE,                 // 159 VotRoc1PosAlmLmt
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc2PosAlmTpPtr,FALSE,                // 160 VotRoc2PosAlmTp
    DT_UINT8,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc2PosAlmLmtPtr,FALSE,                 // 161 VotRoc2PosAlmLmt
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc1NegAlmTpPtr,FALSE,                // 162 VotRoc1NegAlmTp
    DT_UINT8,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc1NegAlmLmtPtr,FALSE,                 // 163 VotRoc1NegAlmLmt
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc2NegAlmTpPtr,FALSE,                // 164 VotRoc2NegAlmTp
    DT_UINT8,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotRoc2NegAlmLmtPtr,FALSE,                 // 165 VotRoc2NegAlmLmt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv1Ptr,FALSE,                            // 166 Pv1
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv2Ptr,FALSE,                            // 167 Pv2   
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv3Ptr,FALSE,                            // 168 Pv3
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv4Ptr,FALSE,                            // 169 Pv4
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPv1ConnectPtr,TRUE,                         // 170 Pv1Connect
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPv2ConnectPtr,TRUE,                         // 171 Pv2Connect
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPv3ConnectPtr,TRUE,                         // 172 Pv3Connect
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPv4ConnectPtr,TRUE,                         // 173 Pv4Connect 
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVotPv2HhAlmTpPtr,TRUE,                   // 174 VotPv2HhAlmTp  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 185    
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 243
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,                // 244 SlotChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE                                         // 255
};

/*******************************************************************************
*                            clsVotLogicSlot::clsVotLogicSlot                  *
*                            ================================                  *
* PURPOSE   : Constructor of clsVotLogicSlot Class. which initializes  class         *
*             members.                                                         *
* ARGUMENTS : a_ucSltNm - Slot Number                                          *
* RETURN    : NONE                                                             *
* NOTES:    :                                                                  *
*******************************************************************************/
clsVotLogicSlot::clsVotLogicSlot(UINT8 a_ucSltNm) : clsIomSlot( a_ucSltNm) 
{
    //Get the slot shared ram pointer into local variable
    pVoteShramSlotData = &ShramData.ShramSlotData.VoteShramSlotData;

    //Initialize Member Variables
    InitVotBlock(TRUE, TRUE);
}

/*******************************************************************************
*                           clsVotLogicSlot::operator new                      *
*                           =============================                      *
* PURPOSE  : Overrided new Operator to allocate memory to Slot                 *
* ARGUMENTS: a_ucSltNm - Slot Number                                           *
* RETURN   : returns slot memory pointer                                       *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::operator new(UINT32, UINT8 a_ucSltNm) { 

    return (ucIomDbMemory + SPBOXSLOT_SIZE + (AI_MAXSLOTS * TCSPAISLOT_SIZE)+ 
           (AO_MAXSLOTS * TCSPAOSLOT_SIZE)+ (DI_MAXSLOTS * DISLOT_SIZE) +
           (DO_MAXSLOTS* TCDOSLOT_SIZE) + (SP_MAXSLOTS * SPSLOT_SIZE) +
           (a_ucSltNm - VOTLOGIC_BLOCK_START) * SPVOTLOGIC_SIZE);
}

/*******************************************************************************
*                          clsVotLogicSlot::GetDataType                        *
*                          ============================                        *
* PURPOSE  : This function returns data type of the parameter.                 *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : DataType of the parameter                                         *
* NOTES    :                                                                   *
*******************************************************************************/
DATATYPE clsVotLogicSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsVotLogicSlot::GetAccessType                      *
*                          ==============================                      *
* PURPOSE  : This function returns accesstype of the parameter.                *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : AccessType of the parameter.                                      *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSTYPE clsVotLogicSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                          clsVotLogicSlot::GetParamSize                       *
*                          =============================                       *
* PURPOSE  : This function returns size of the parameter                       *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsVotLogicSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                          clsVotLogicSlot::GetParamPtr                        *
*                          ============================                        *
* PURPOSE  : This function returns pointer of the parameter                    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsVotLogicSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                         clsVotLogicSlot::GetAccessLock                       *
*                         ==============================                       *
* PURPOSE  : This function returns Access Lock of the parameter.               *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Access Lock of the parameter number.                              *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSLOCK clsVotLogicSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                    clsVotLogicSlot::GetIsDbChecksumed                        *
*                    ==================================                        *
* PURPOSE  : This function returns whether parameter.is checkpointed or not    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : BOOL - TRUE if parameter is checkpoint paramter, else FALSE       *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsVotLogicSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                        clsVotLogicSlot::VerifyControlState                   *
*                        ===================================                   *
* PURPOSE  : This function checks the contorl state assigned to the parameter  *
*            to actual present control state of the channel and IOM module     *
*            itself,before the actual write to the parameter.                  *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    : This function decides whether the write can be done or not to the *
*            paramerter under current channel or IOM state.                    *
*******************************************************************************/
PASTATUS clsVotLogicSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x912,tblParamInfo[a_ucParamNumber].ControlState);
        break;
    }    
    return PA_OK;
}

/*******************************************************************************
*                        clsVotLogicSlot::ExecutePreFunction                   *
*                        ===================================                   *
* PURPOSE  : This function invokes the pre-function for the given writable     *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber  - Parameter Number                               *
*            a_Buffer         - Pointer to the data                            *
*            a_ucAccessLevel  - Access level of the parameter                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsVotLogicSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                             UINT8 *a_Buffer,
                                             UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                        clsVotLogicSlot::ExecutePostFunction                  *
*                        ====================================                  *
* PURPOSE  : This function invokes the post-function for the given writable    *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber - Parameter Number                                *
*            a_ucAccessLevel - Access level of the parameter                   *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsVotLogicSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                          UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
    return;
}

/*******************************************************************************
*                           clsVotLogicSlot::InitSlotDatabase                  *
*                           =================================                  *
* PURPOSE  : Initialize the entire channel database. Calls the Init function   *
*            for each class in the channel object hierarchy and recompute      *
*            database checksum.                                                *
* ARGUMENTS: bFullInit - lag utilised when slots have to be reinitialized      *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsVotLogicSlot::InitSlotDatabase(BOOL bFullInit) 
{
    BOOL bObjCreate = FALSE; // This variable turns off the compiler warning
    
    InitVotBlock(bFullInit, bObjCreate);
    
    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                           clsVotLogicSlot::InitVotBlock                      *
*                           =============================                      *
* PURPOSE:   Initialization function for clsVotLogicSlot data members          *
* ARGUMENTS: bFullInit   - Flag utilised when slots have to be reinitialized   *
*            bObjCreate  - Flag utilised when slots have to be reinitialized   *
* RETURN:    NONE                                                              *
* NOTES:     This function is called when slot parameters                      *
*            need to be reinitialized                                          *
*******************************************************************************/
VOID clsVotLogicSlot::InitVotBlock(BOOL bFullInit, BOOL) 
{
    if(bFullInit == TRUE)
    {
        Pv1 = NaN;
        Pv2 = NaN;
        Pv3 = NaN;
        Pv4 = NaN;
        Pv1Connect = PV_NONE;
        Pv2Connect = PV_NONE;
        Pv3Connect = PV_NONE;
        Pv4Connect = PV_NONE;
        VotPv1100 = NaN;
        VotPv2100 = NaN;

        VotAlgGrp1 = MED;
        VotAlgGrp2 = MED;
        Grp1IgnFl  = 0;
        Grp2IgnFl  = 0;
        for(UINT8 iCount = 0; iCount < 4; iCount++)
        {
            Grp1VotChEnb[iCount] = 0;
            Grp2VotChEnb[iCount] = 0;
            Grp1IgnoredFl[iCount] = 0;
            Grp2IgnoredFl[iCount] = 0;
        }

        Grp1nMin = GRPNMIN_ONE; // Equalent macro
        Grp2nMin = GRPNMIN_ONE; // Equalent macro
        MedOpt1  = MEDOPT_MIN;  // MIN is 0
        MedOpt2  = MEDOPT_MIN;
        ResetTrip = 0;

        VotPV1      = NaN;;
        VotPV2      = NaN;;
        VotROC1     = NaN;;
        VotROC2     = NaN;;
        VotPV1Sts   = PVVALST_BAD;
        VotPV2Sts   = PVVALST_BAD;;
        VotROC1Sts  = PVVALST_BAD;;
        VotROC2Sts  = PVVALST_BAD;;
        LastVotPV1  = NaN;;
        LastVotPV2  = NaN;;
        LastVotROC1 = NaN;;
        LastVotROC2 = NaN;;
        VotPVMax    = NaN;;
        VotPVOnTrip = NaN;;
        VotROCPosHhOnTrip = NaN;

        VotPv1HiAlmTp = NaN;
        VotPv2HiAlmTp = NaN;
        VotPv1HhAlmTp = NaN;
        VotPv2HhAlmTp = NaN;
        VotRoc1PosHiAlmTp = NaN;
        VotRoc2PosHiAlmTp = NaN;
        VotRoc1PosHhAlmTp = NaN;
        VotRoc2PosHhAlmTp = NaN;
        VotRoc1NegAlmTp = NaN;
        VotRoc2NegAlmTp = NaN;
        VotPv1HiAlmFl = FALSE;
        VotPv2HiAlmFl = FALSE;
        VotPv1HhAlmFl = FALSE;
        VotPv1HhAlmFlWrst = FALSE;
        VotPv2HhAlmFl = FALSE;
        VotPv2HhAlmFlWrst = FALSE;
        VotRoc1PosHiAlmFl = FALSE;
        VotRoc2PosHiAlmFl = FALSE;
        VotRoc1PosHhAlmFl = FALSE;
        VotRoc2PosHhAlmFl = FALSE;
        VotRoc1PosHhAlmFlWrst = FALSE;
        VotRoc2PosHhAlmFlWrst = FALSE;

        VotRoc1PosAlmTp = NaN;
        VotRoc2PosAlmTp = NaN;
        VotRoc1NegAlmFl = FALSE;
        VotRoc2NegAlmFl = FALSE;
        VotRoc1PosAlmLmt = 0;
        VotRoc2PosAlmLmt = 0;
        VotRoc1NegAlmLmt = 0;
        VotRoc2NegAlmLmt = 0;
   }
}

/*******************************************************************************
*                    Get Methods for DI Channels Parameters                    *
*******************************************************************************/
///////////////////////////////////////////////////////////////////////////////////////////
//Getting the data from shared ram database into local copy and returns the pointers
//////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
//Overrided clsIoSlot Class Varibles GetPtr methods
//////////////////////////////////////////////////////////
/*******************************************************************************
*                         clsVotLogicSlot::GetPntTypePtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns PntType Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPntTypePtr(VOID)    
{
    PntType    = (PNTTYPE)pVoteShramSlotData->PntType;

    return &PntType; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPtExecStPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns PtExecSt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPtExecStPtr(VOID)   
{ 
    PtExecSt   = (PTEXECST)pVoteShramSlotData->PtExecSt;
    
    return &PtExecSt; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv1Ptr                           *
*                         ==========================                           *
* PURPOSE  : This function returns Pv1 Parameter Pointer                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv1Ptr(VOID)  
{
    Pv1   = (FLOAT32)pVoteShramSlotData->Pv1;

    return &Pv1; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv2Ptr                           *
*                         ==========================                           *
* PURPOSE  : This function returns Pv2 Parameter Pointer                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv2Ptr(VOID)  
{ 
    Pv2   = (FLOAT32)pVoteShramSlotData->Pv2;

    return &Pv2; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv3Ptr                           *
*                         ==========================                           *
* PURPOSE  : This function returns Pv3 Parameter Pointer                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv3Ptr(VOID)  
{ 
    Pv3   = (FLOAT32)pVoteShramSlotData->Pv3;

    return &Pv3; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv4Ptr                           *
*                         ==========================                           *
* PURPOSE  : This function returns Pv4 Parameter Pointer                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv4Ptr(VOID)  
{ 
    Pv4   = (FLOAT32)pVoteShramSlotData->Pv4;

    return &Pv4; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv1ConnectPtr                    *
*                         =================================                    *
* PURPOSE  : This function returns Pv1Connect Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv1ConnectPtr(VOID)  
{ 
    Pv1Connect   = (INT32)pVoteShramSlotData->Pv1Connect;

    return &Pv1Connect; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv2ConnectPtr                    *
*                         =================================                    *
* PURPOSE  : This function returns Pv2Connect Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv2ConnectPtr(VOID)
{ 
    Pv2Connect   = (INT32)pVoteShramSlotData->Pv2Connect;

    return &Pv2Connect; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv3ConnectPtr                    *
*                         =================================                    *
* PURPOSE  : This function returns Pv3Connect Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv3ConnectPtr(VOID)  
{ 
    Pv3Connect   = (INT32)pVoteShramSlotData->Pv3Connect;

    return &Pv3Connect; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPv4ConnectPtr                    *
*                         =================================                    *
* PURPOSE  : This function returns Pv4Connect Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetPv4ConnectPtr(VOID)  
{ 
    Pv4Connect   = (INT32)pVoteShramSlotData->Pv4Connect;

    return &Pv4Connect; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp1IgnFlPtr                     *
*                         ================================                     *
* PURPOSE  : This function returns Grp1IgnFl Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp1IgnFlPtr(VOID)  
{ 
    Grp1IgnFl   = (BOOL)pVoteShramSlotData->Grp1IgnFl;

    return &Grp1IgnFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp2IgnFlPtr                     *
*                         ================================                     *
* PURPOSE  : This function returns Grp2IgnFl Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp2IgnFlPtr(VOID)  
{ 
    Grp2IgnFl   = (BOOL)pVoteShramSlotData->Grp2IgnFl;

    return &Grp2IgnFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp1IgnoredFlPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns Grp1IgnoredFl Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp1IgnoredFlPtr(VOID)  
{ 
    for(int idx=0;idx<4;idx++)
    {
        Grp1IgnoredFl[idx]   = (BOOL)pVoteShramSlotData->Grp1IgnoredFl[idx];
    }

    return &Grp1IgnoredFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp2IgnoredFlPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns Grp2IgnoredFl Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp2IgnoredFlPtr(VOID)  
{
    for(int idx=0;idx<4;idx++)
    {
        Grp2IgnoredFl[idx]   = (BOOL)pVoteShramSlotData->Grp2IgnoredFl[idx];
    }

    return &Grp2IgnoredFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotAlgGrp1Ptr                    *
*                         =================================                    *
* PURPOSE  : This function returns VotAlgGrp1 Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotAlgGrp1Ptr(VOID)  
{ 
    VotAlgGrp1   = (VOTALGGRP)pVoteShramSlotData->VotAlgGrp1;

    return &VotAlgGrp1; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotAlgGrp2Ptr                    *
*                         =================================                    *
* PURPOSE  : This function returns VotAlgGrp2 Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotAlgGrp2Ptr(VOID)  
{ 
    VotAlgGrp2   = (VOTALGGRP)pVoteShramSlotData->VotAlgGrp2;

    return &VotAlgGrp2; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp1VotChEnbPtr                  *
*                         ===================================                  *
* PURPOSE  : This function returns Grp1VotChEnb Parameter Pointer              *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp1VotChEnbPtr(VOID)  
{ 
    for(int idx=0;idx<4;idx++)
    {   
        Grp1VotChEnb[idx]   = (BOOL)pVoteShramSlotData->Grp1VotChEnb[idx];
    }

    return &Grp1VotChEnb; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp2VotChEnbPtr                  *
*                         ===================================                  *
* PURPOSE  : This function returns Grp2VotChEnb Parameter Pointer              *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp2VotChEnbPtr(VOID)  
{ 
    for(int idx=0;idx<4;idx++)
    {   
        Grp2VotChEnb[idx]   = (BOOL)pVoteShramSlotData->Grp2VotChEnb[idx];
    }

    return &Grp2VotChEnb; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp1nMinPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns Grp1nMin Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp1nMinPtr(VOID)  
{ 
    Grp1nMin   = (GRPNMIN)pVoteShramSlotData->Grp1nMin;

    return &Grp1nMin; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetGrp2nMinPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns Grp2nMin Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetGrp2nMinPtr(VOID)  
{ 
    Grp2nMin   = (GRPNMIN)pVoteShramSlotData->Grp2nMin;

    return &Grp2nMin; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetMedOpt1Ptr                       *
*                         ==============================                       *
* PURPOSE  : This function returns MedOpt1 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetMedOpt1Ptr(VOID)  
{ 
    MedOpt1   = (MEDOPT)pVoteShramSlotData->MedOpt1;

    return &MedOpt1; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetMedOpt2Ptr                       *
*                         ==============================                       *
* PURPOSE  : This function returns MedOpt2 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetMedOpt2Ptr(VOID)  
{ 
    MedOpt2   = (MEDOPT)pVoteShramSlotData->MedOpt2;

    return &MedOpt2; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPV1StsPtr                     *
*                         ================================                     *
* PURPOSE  : This function returns VotPV1Sts Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV1StsPtr(VOID)  
{ 
    VotPV1Sts   = (PVVALST)pVoteShramSlotData->VotPV1Sts;

    return &VotPV1Sts; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPV2StsPtr                     *
*                         ================================                     *
* PURPOSE  : This function returns VotPV2Sts Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV2StsPtr(VOID)  
{ 
    VotPV2Sts   = (PVVALST)pVoteShramSlotData->VotPV2Sts;

    return &VotPV2Sts; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotROC1StsPtr                    *
*                         =================================                    *
* PURPOSE  : This function returns VotROC1Sts Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotROC1StsPtr(VOID)  
{ 
    VotROC1Sts   = (PVVALST)pVoteShramSlotData->VotROC1Sts;

    return &VotROC1Sts; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotROC2StsPtr                    *
*                         =================================                    *
* PURPOSE  : This function returns VotROC2Sts Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotROC2StsPtr(VOID)  
{ 
    VotROC2Sts   = (PVVALST)pVoteShramSlotData->VotROC2Sts;

    return &VotROC2Sts; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetLastVotPV1Ptr                    *
*                         =================================                    *
* PURPOSE  : This function returns LastVotPV1 Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetLastVotPV1Ptr(VOID)  
{ 
    LastVotPV1   = (FLOAT32)pVoteShramSlotData->LastVotPV1;

    return &LastVotPV1; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetLastVotPV2Ptr                    *
*                         =================================                    *
* PURPOSE  : This function returns LastVotPV2 Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetLastVotPV2Ptr(VOID)  
{ 
    LastVotPV2   = (FLOAT32)pVoteShramSlotData->LastVotPV2;

    return &LastVotPV2; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetLastVotROC1Ptr                   *
*                         ==================================                   *
* PURPOSE  : This function returns LastVotROC1 Parameter Pointer               *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetLastVotROC1Ptr(VOID)  
{ 
    LastVotROC1   = (FLOAT32)pVoteShramSlotData->LastVotROC1;

    return &LastVotROC1; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPntTypePtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns PntType Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetLastVotROC2Ptr(VOID)  
{ 
    LastVotROC2   = (FLOAT32)pVoteShramSlotData->LastVotROC2;

    return &LastVotROC2; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPntTypePtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns PntType Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV1OvrTstEnbPtr(VOID)  
{ 
    VotPV1OvrTstEnb   = (BOOL)pVoteShramSlotData->VotPV1OvrTstEnb;

    return &VotPV1OvrTstEnb; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetPntTypePtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns PntType Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV2OvrTstEnbPtr(VOID)  
{ 
    VotPV2OvrTstEnb   = (BOOL)pVoteShramSlotData->VotPV2OvrTstEnb;

    return &VotPV2OvrTstEnb; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotROCPosHhOnTripPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotROCPosHhOnTrip Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotROCPosHhOnTripPtr(VOID)  
{ 
    VotROCPosHhOnTrip   = (FLOAT32)pVoteShramSlotData->VotROCPosHhOnTrip;

    return &VotROCPosHhOnTrip; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPVOnTripPtr                   *
*                         ==================================                   *
* PURPOSE  : This function returns VotPVOnTrip Parameter Pointer               *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPVOnTripPtr(VOID)  
{ 
    VotPVOnTrip   = (FLOAT32)pVoteShramSlotData->VotPVOnTrip;

    return &VotPVOnTrip; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPVMaxPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns VotPVMax Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPVMaxPtr(VOID)  
{
    VotPVMax   = (FLOAT32)pVoteShramSlotData->VotPVMax;

    return &VotPVMax; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPV1Ptr                        *
*                         =============================                        *
* PURPOSE  : This function returns VotPV1 Parameter Pointer                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV1Ptr(VOID)  
{ 
    VotPV1   = (FLOAT32)pVoteShramSlotData->VotPV1;

    return &VotPV1; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPV2Ptr                        *
*                         =============================                        *
* PURPOSE  : This function returns VotPV2 Parameter Pointer                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV2Ptr(VOID)  
{ 
    VotPV2   = (FLOAT32)pVoteShramSlotData->VotPV2;

    return &VotPV2; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv1100Ptr                     *
*                         ================================                     *
* PURPOSE  : This function returns VotPv1100 Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV1100Ptr(VOID)  
{
    VotPv1100 = (FLOAT32)pVoteShramSlotData->VotPV1;

    FLOAT32 NSpd = 0;
    UINT8 SlotNum = 0;
    
    //Get the PV connection Pin information
    Pv1Connect = (INT32)pVoteShramSlotData->Pv1Connect;
    Pv2Connect = (INT32)pVoteShramSlotData->Pv2Connect;
    Pv3Connect = (INT32)pVoteShramSlotData->Pv3Connect;
    Pv4Connect = (INT32)pVoteShramSlotData->Pv4Connect;;
    
    //Check the PV1 connection is connected get the correspoinding Nominal Speed
    if(Pv1Connect != 0)
    {
        SlotNum = Pv1Connect & 0xFF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }
    
    //If Nominal Speed is zero and check the PV2 connection is connected get the correspoinding Nominal Speed
    if(NSpd == 0 && Pv2Connect != 0)
    {
        SlotNum = Pv2Connect & 0xFF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }
    
    //If Nominal Speed is zero and check the PV3 connection is connected get the correspoinding Nominal Speed
    if(NSpd == 0 && Pv3Connect != 0)
    {
        SlotNum = Pv3Connect & 0x0FF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }
    
    //If Nominal Speed is zero and check the PV4 connection is connected get the correspoinding Nominal Speed
    if(NSpd == 0 && Pv4Connect != 0)
    {
        SlotNum = Pv4Connect & 0xFF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }
    
    //If Nominal Speed is not equal zero then
    //Calculate PV using the formala PV (range from 0 to 100) = (Pv/NominalSpeed) * 100%
    if(NSpd != 0) {
        VotPv1100 = (VotPv1100/NSpd) * 100;
    }
    else { //If Zero, PV is NaN
        VotPv1100 = NaN;
    }

    return &VotPv1100; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv2100Ptr                     *
*                         ================================                     *
* PURPOSE  : This function returns VotPv2100 Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPV2100Ptr(VOID)  
{
    //Get the PV connection Pin information
    VotPv2100   = (FLOAT32)pVoteShramSlotData->VotPV2;

    FLOAT32 NSpd = 0;
    UINT8 SlotNum = 0;

    //Get the PV connection Pin information
    Pv1Connect = (INT32)pVoteShramSlotData->Pv1Connect;
    Pv2Connect = (INT32)pVoteShramSlotData->Pv2Connect;
    Pv3Connect = (INT32)pVoteShramSlotData->Pv3Connect;
    Pv4Connect = (INT32)pVoteShramSlotData->Pv4Connect;
    
    //Check the PV1 connection is connected get the correspoinding Nominal Speed
    if(Pv1Connect != 0)
    {
        SlotNum = Pv1Connect & 0xFF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }
    
    //If Nominal Speed is zero and check the PV2 connection is connected get the correspoinding Nominal Speed
    if(NSpd == 0 && Pv2Connect != 0)
    {
        SlotNum = Pv2Connect & 0xFF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }
    
    //If Nominal Speed is zero and check the PV2 connection is connected get the correspoinding Nominal Speed
    if(NSpd == 0 && Pv3Connect != 0)
    {
        SlotNum = Pv3Connect & 0xFF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }
    
    //If Nominal Speed is zero and check the PV2 connection is connected get the correspoinding Nominal Speed
    if(NSpd == 0 && Pv4Connect != 0)
    {
        SlotNum = Pv4Connect & 0xFF;
        NSpd = ShramData.ShramSlotData.SpeedShramSlotData[SlotNum - SP_CH_START].NominalSpd;
    }

    //If Nominal Speed is not equal zero then
    //Calculate PV using the formala PV (range from 0 to 100) = (Pv/NominalSpeed) * 100%
    if(NSpd != 0) {
        VotPv2100 = (VotPv2100/NSpd) * 100;
    }
    else { //If Zero, PV is NaN
        VotPv2100 = NaN;
    }

    return &VotPv2100; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotROC1Ptr                       *
*                         ==============================                       *
* PURPOSE  : This function returns VotROC1 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotROC1Ptr(VOID)  
{ 
    VotROC1   = (FLOAT32)pVoteShramSlotData->VotROC1;

    return &VotROC1; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotROC2Ptr                       *
*                         ==============================                       *
* PURPOSE  : This function returns VotROC2 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotROC2Ptr(VOID)  
{ 
    VotROC2   = (FLOAT32)pVoteShramSlotData->VotROC2;

    return &VotROC2; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv1HiAlmTpPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv1HiAlmTp Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv1HiAlmTpPtr(VOID)
{ 
    VotPv1HiAlmTp   = (FLOAT32)pVoteShramSlotData->VotPv1HiAlmTp;

    return &VotPv1HiAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv2HiAlmTpPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv2HiAlmTp Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv2HiAlmTpPtr(VOID)
{ 
    VotPv2HiAlmTp   = (FLOAT32)pVoteShramSlotData->VotPv2HiAlmTp;

    return &VotPv2HiAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv1HhAlmTpPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv1HhAlmTp Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv1HhAlmTpPtr(VOID)
{ 
    VotPv1HhAlmTp   = (FLOAT32)pVoteShramSlotData->VotPv1HhAlmTp;

    return &VotPv1HhAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv2HhAlmTpPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv2HhAlmTp Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv2HhAlmTpPtr(VOID)
{ 
    VotPv2HhAlmTp   = (FLOAT32)pVoteShramSlotData->VotPv2HhAlmTp;

    return &VotPv2HhAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1PosHiAlmTpPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotRoc1PosHiAlmTp Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1PosHiAlmTpPtr(VOID)
{ 
    VotRoc1PosHiAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc1PosHiAlmTp;

    return &VotRoc1PosHiAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1PosHhAlmTpPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotRoc1PosHhAlmTp Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1PosHhAlmTpPtr(VOID)
{ 
    VotRoc1PosHhAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc1PosHhAlmTp;

    return &VotRoc1PosHhAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2PosHhAlmTpPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotRoc2PosHhAlmTp Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2PosHhAlmTpPtr(VOID)
{ 
    VotRoc2PosHhAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc2PosHhAlmTp;

    return &VotRoc2PosHhAlmTp;  
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2PosHiAlmTpPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotRoc2PosHiAlmTp Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2PosHiAlmTpPtr(VOID)
{ 
    VotRoc2PosHiAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc2PosHiAlmTp;

    return &VotRoc2PosHiAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1NegAlmTpPtr               *
*                         ======================================               *
* PURPOSE  : This function returns VotRoc1NegAlmTp Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1NegAlmTpPtr(VOID)
{ 
    VotRoc1NegAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc1NegAlmTp;

    return &VotRoc1NegAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2NegAlmTpPtr               *
*                         ======================================               *
* PURPOSE  : This function returns VotRoc2NegAlmTp Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2NegAlmTpPtr(VOID)
{ 
    VotRoc2NegAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc2NegAlmTp;

    return &VotRoc2NegAlmTp; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv1HiAlmFlPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv1HiAlmFl Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv1HiAlmFlPtr(VOID)
{ 
    VotPv1HiAlmFl   = (BOOL)pVoteShramSlotData->VotPv1HiAlmFl;

    return &VotPv1HiAlmFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv2HiAlmFlPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv2HiAlmFl Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv2HiAlmFlPtr(VOID)
{ 
    VotPv2HiAlmFl   = (BOOL)pVoteShramSlotData->VotPv2HiAlmFl;

    return &VotPv2HiAlmFl; 
}


/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv1HhAlmFlPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv1HhAlmFl Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv1HhAlmFlPtr(VOID)
{ 
    VotPv1HhAlmFl   = (BOOL)pVoteShramSlotData->VotPv1HhAlmFl;

    return &VotPv1HhAlmFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv1HhAlmFlWrstPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotPv1HhAlmFlWrst Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv1HhAlmFlWrstPtr(VOID)
{ 
    VotPv1HhAlmFlWrst   = (BOOL)pVoteShramSlotData->VotPv1HhAlmFlWrst;

    return &VotPv1HhAlmFlWrst; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv2HhAlmFlPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns VotPv2HhAlmFl Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv2HhAlmFlPtr(VOID)
{ 
    VotPv2HhAlmFl   = (BOOL)pVoteShramSlotData->VotPv2HhAlmFl;

    return &VotPv2HhAlmFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotPv2HhAlmFlWrstPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotPv2HhAlmFlWrst Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotPv2HhAlmFlWrstPtr(VOID)
{ 
    VotPv2HhAlmFlWrst   = (BOOL)pVoteShramSlotData->VotPv2HhAlmFlWrst;

    return &VotPv2HhAlmFlWrst; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1PosHiAlmFlPtr             *
*                         ========================================             *
* PURPOSE  : This function returns VotRoc1PosHiAlmFl Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1PosHiAlmFlPtr(VOID)
{ 
    VotRoc1PosHiAlmFl   = (BOOL)pVoteShramSlotData->VotRoc1PosHiAlmFl;

    return &VotRoc1PosHiAlmFl; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2PosHiAlmFlPtr             *
*                         ========================================             *
* PURPOSE  : This function returns PntType Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2PosHiAlmFlPtr(VOID)
{ 
    VotRoc2PosHiAlmFl   = (BOOL)pVoteShramSlotData->VotRoc2PosHiAlmFl;

    return &VotRoc2PosHiAlmFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1PosHhAlmFlPtr                  *
*                         ==================================                   *
* PURPOSE  : This function returns VotRoc1PosHhAlmFl Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1PosHhAlmFlPtr(VOID)
{ 
    VotRoc1PosHhAlmFl   = (BOOL)pVoteShramSlotData->VotRoc1PosHhAlmFl;

    return &VotRoc1PosHhAlmFl; 
}    

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2PosHhAlmFlPtr                   *
*                         ==================================                   *
* PURPOSE  : This function returns VotRoc2PosHhAlmFl Parameter Pointer         *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2PosHhAlmFlPtr(VOID)  
{ 
    VotRoc2PosHhAlmFl   = (BOOL)pVoteShramSlotData->VotRoc2PosHhAlmFl;

    return &VotRoc2PosHhAlmFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2PosHhAlmFlWrstPtr         *
*                         ============================================         *
* PURPOSE  : This function returns VotRoc2PosHhAlmFlWrst Parameter Pointer     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2PosHhAlmFlWrstPtr(VOID)
{ 
    VotRoc2PosHhAlmFlWrst   = (BOOL)pVoteShramSlotData->VotRoc2PosHhAlmFlWrst;

    return &VotRoc2PosHhAlmFlWrst; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1NegAlmFlPtr               *
*                         ======================================               *
* PURPOSE  : This function returns VotRoc1NegAlmFl Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1NegAlmFlPtr(VOID)
{
    VotRoc1NegAlmFl   = (BOOL)pVoteShramSlotData->VotRoc1NegAlmFl;

    return &VotRoc1NegAlmFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2NegAlmFlPtr               *
*                         ======================================               *
* PURPOSE  : This function returns VotRoc2NegAlmFl Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2NegAlmFlPtr(VOID)
{
    VotRoc2NegAlmFl   = (BOOL)pVoteShramSlotData->VotRoc2NegAlmFl;

    return &VotRoc2NegAlmFl; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1PosHhAlmFlWrstPtr         *
*                         ============================================         *
* PURPOSE  : This function returns VotRoc1PosHhAlmFlWrst Parameter Pointer     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1PosHhAlmFlWrstPtr(VOID)
{ 
    VotRoc1PosHhAlmFlWrst   = (BOOL)pVoteShramSlotData->VotRoc1PosHhAlmFlWrst;

    return &VotRoc1PosHhAlmFlWrst; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1PosAlmLmtPtr              *
*                         =======================================              *
* PURPOSE  : This function returns VotRoc1PosAlmLmt Parameter Pointer          *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1PosAlmLmtPtr(VOID) 
{ 
    VotRoc1PosAlmLmt   = (INT8)pVoteShramSlotData->VotRoc1PosAlmLmt;
    return &VotRoc1PosAlmLmt; 
}

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2PosAlmLmtPtr              *
*                         =======================================              *
* PURPOSE  : This function returns VotRoc2PosAlmLmt Parameter Pointer          *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2PosAlmLmtPtr(VOID)
{ 
    VotRoc2PosAlmLmt   = (INT8)pVoteShramSlotData->VotRoc2PosAlmLmt;
    return &VotRoc2PosAlmLmt; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1NegAlmLmtPtr              *
*                         =======================================              *
* PURPOSE  : This function returns VotRoc1NegAlmLmt Parameter Pointer          *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1NegAlmLmtPtr(VOID) 
{ 
    VotRoc1NegAlmLmt   = (INT8)pVoteShramSlotData->VotRoc1NegAlmLmt;
    return &VotRoc1NegAlmLmt; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2NegAlmLmtPtr              *
*                         =======================================              *
* PURPOSE  : This function returns VotRoc2NegAlmLmt Parameter Pointer          *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2NegAlmLmtPtr(VOID) 
{ 
    VotRoc2NegAlmLmt   = (INT8)pVoteShramSlotData->VotRoc2NegAlmLmt;

    return &VotRoc2NegAlmLmt; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc1PosAlmTpPtr               *
*                         ======================================               *
* PURPOSE  : This function returns VotRoc1PosAlmTp Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc1PosAlmTpPtr(VOID)
{ 
    VotRoc1PosAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc1PosAlmTp;

    return &VotRoc1PosAlmTp; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetVotRoc2PosAlmTpPtr               *
*                         ======================================               *
* PURPOSE  : This function returns VotRoc2PosAlmTp Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsVotLogicSlot::GetVotRoc2PosAlmTpPtr(VOID) 
{ 
    VotRoc2PosAlmTp   = (FLOAT32)pVoteShramSlotData->VotRoc2PosAlmTp;

    return &VotRoc2PosAlmTp; 
} 

/*******************************************************************************
*                         clsVotLogicSlot::GetDumpData                         *
*                         ============================                         *
* PURPOSE  : This method will copy the redundancy dump data to buffer transmit *
*            to the secondary IOM                                              *
* ARGUMENTS: pDump - Dump Pointer                                              *
*            MaxSize - Dump Size                                               *
* RETURN   : PA_OK - getdump is succesful                                      *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsVotLogicSlot::GetDumpData(UINT8* const pDump,const UINT8 MaxSize)
{   // Note: pDump must point to an an even address.
    PASTATUS retVal = PA_NULL;
    if(pDump && IS_EVEN(pDump) && sizeof(SYNCRECORD) < MaxSize)
    {
        PSYNCRECORD pSyncRec        = (PSYNCRECORD)pDump;
        VOTESHRAMSLOTDATA* pSlotDB  = pVoteShramSlotData;
        
        /// SYNCRECORD fields must be updated from top to bottom in order of declaration.
        /// This updation must happen quicker than byte transmission over iolink.
        pSyncRec->Header            = PACK2_AS_UI16(SPDVOTE_SYNCREC_VER_1,0);
        pSyncRec->PntType           = (UINT8)pSlotDB->PntType;
        pSyncRec->PtExecSt          = (UINT8)pSlotDB->PtExecSt;
        pSyncRec->VotAlgGrpAll      = PACK2_AS_UI8(pSlotDB->VotAlgGrp2,pSlotDB->VotAlgGrp1);
        pSyncRec->GrpVotChEnbAll    = PACK8_AS_UI8(pSlotDB->Grp2VotChEnb[3],pSlotDB->Grp2VotChEnb[2],pSlotDB->Grp2VotChEnb[1],pSlotDB->Grp2VotChEnb[0],pSlotDB->Grp1VotChEnb[3],pSlotDB->Grp1VotChEnb[2],pSlotDB->Grp1VotChEnb[1],pSlotDB->Grp1VotChEnb[0]);        
        pSyncRec->GrpAllnMin        = PACK2_AS_UI8(pSlotDB->Grp2nMin,pSlotDB->Grp1nMin);         
        pSyncRec->MedOptAll         = PACK2_AS_UI8(pSlotDB->MedOpt2,pSlotDB->MedOpt1);
        pSyncRec->VotPVAllOvrTstEnb = PACK2_AS_UI8(pSlotDB->VotPV2OvrTstEnb,pSlotDB->VotPV1OvrTstEnb);

        pSyncRec->VotPv1HhAlmFlWrst     = (UINT8)pSlotDB->VotPv1HhAlmFlWrst;
        pSyncRec->VotPv2HhAlmFlWrst     = (UINT8)pSlotDB->VotPv2HhAlmFlWrst;
        pSyncRec->VotRoc1PosHhAlmFlWrst = (UINT8)pSlotDB->VotRoc1PosHhAlmFlWrst;
        pSyncRec->VotRoc2PosHhAlmFlWrst = (UINT8)pSlotDB->VotRoc2PosHhAlmFlWrst;

        pSyncRec->VotPVOnTrip       = pSlotDB->VotPVOnTrip;
        pSyncRec->VotROCPosHhOnTrip = pSlotDB->VotROCPosHhOnTrip;

        pSyncRec->VotPv1HiAlmTp         = pSlotDB->VotPv1HiAlmTp;
        pSyncRec->VotPv2HiAlmTp         = pSlotDB->VotPv2HiAlmTp;
        pSyncRec->VotPv1HhAlmTp         = pSlotDB->VotPv1HhAlmTp;
        pSyncRec->VotRoc1PosHiAlmTp     = pSlotDB->VotRoc1PosHiAlmTp;
        pSyncRec->VotRoc2PosHiAlmTp     = pSlotDB->VotRoc2PosHiAlmTp;
        pSyncRec->VotRoc1PosHhAlmTp     = pSlotDB->VotRoc1PosHhAlmTp;
        pSyncRec->VotRoc2PosHhAlmTp     = pSlotDB->VotRoc2PosHhAlmTp;
        pSyncRec->VotRoc1NegAlmTp       = pSlotDB->VotRoc1NegAlmTp;
        pSyncRec->VotRoc2NegAlmTp       = pSlotDB->VotRoc2NegAlmTp;
        pSyncRec->VotPv2HhAlmTp         = pSlotDB->VotPv2HhAlmTp;
        pSyncRec->Pv1Connect        = pSlotDB->Pv1Connect;
        pSyncRec->Pv2Connect        = pSlotDB->Pv2Connect;
        pSyncRec->Pv3Connect        = pSlotDB->Pv3Connect;
        pSyncRec->Pv4Connect        = pSlotDB->Pv4Connect;
        
        pSyncRec->VotPvMax              = pSlotDB->VotPVMax;
        ///
        retVal = PA_OK;
    }
    return retVal;
}

/*******************************************************************************
*                         clsVotLogicSlot::StoreDumpData                       *
*                         ==============================                       *
* PURPOSE  : This method will copy the redundancy dump data into local dump    *
*            structure in Primary IOM                                          *
* ARGUMENTS: pDump - Dump Pointer                                              *
* RETURN   : PA_OK -   If dump is succesful                                    *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS  clsVotLogicSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS retVal = PA_NULL;
    if(pDump && IS_EVEN(pDump))
    {   /// copy from pDump to shared ram.
        /// Note: On H8S all multibyte variables must be 
        /// aligned on an even address for assignment to work

        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SPDVOTE_SYNCREC_VER_1)
        {
            PSYNCRECORD pSyncRec        = (PSYNCRECORD)pDump;
            VOTESHRAMSLOTDATA* pSlotDB  = pVoteShramSlotData;        

            pSlotDB->PntType                = (UINT16)pSyncRec->PntType;
            pSlotDB->PtExecSt               = (UINT16)pSyncRec->PtExecSt;            
            UNPACK_UI8_TO2(pSyncRec->VotAlgGrpAll,pSlotDB->VotAlgGrp1,pSlotDB->VotAlgGrp2,UINT16);
            UNPACK_UI8_TO8(pSyncRec->GrpVotChEnbAll,pSlotDB->Grp1VotChEnb[0],pSlotDB->Grp1VotChEnb[1],pSlotDB->Grp1VotChEnb[2],pSlotDB->Grp1VotChEnb[3],pSlotDB->Grp2VotChEnb[0],pSlotDB->Grp2VotChEnb[1],pSlotDB->Grp2VotChEnb[2],pSlotDB->Grp2VotChEnb[3],UINT16);        
            UNPACK_UI8_TO2(pSyncRec->GrpAllnMin,pSlotDB->Grp1nMin,pSlotDB->Grp2nMin,UINT16); 
            UNPACK_UI8_TO2(pSyncRec->MedOptAll,pSlotDB->MedOpt1,pSlotDB->MedOpt2,UINT16);
            UNPACK_UI8_TO2(pSyncRec->VotPVAllOvrTstEnb,pSlotDB->VotPV1OvrTstEnb,pSlotDB->VotPV2OvrTstEnb,UINT16);

            pSlotDB->VotPv1HhAlmFlWrst     = (UINT16)pSyncRec->VotPv1HhAlmFlWrst;
            pSlotDB->VotPv2HhAlmFlWrst     = (UINT16)pSyncRec->VotPv2HhAlmFlWrst;
            pSlotDB->VotRoc1PosHhAlmFlWrst = (UINT16)pSyncRec->VotRoc1PosHhAlmFlWrst;
            pSlotDB->VotRoc2PosHhAlmFlWrst = (UINT16)pSyncRec->VotRoc2PosHhAlmFlWrst;

            pSlotDB->VotPVOnTrip            = pSyncRec->VotPVOnTrip;
            pSlotDB->VotROCPosHhOnTrip      = pSyncRec->VotROCPosHhOnTrip;
 
            pSlotDB->VotPv1HiAlmTp         = pSyncRec->VotPv1HiAlmTp;
            pSlotDB->VotPv2HiAlmTp         = pSyncRec->VotPv2HiAlmTp;
            pSlotDB->VotPv1HhAlmTp         = pSyncRec->VotPv1HhAlmTp;
            pSlotDB->VotRoc1PosHiAlmTp     = pSyncRec->VotRoc1PosHiAlmTp;
            pSlotDB->VotRoc2PosHiAlmTp     = pSyncRec->VotRoc2PosHiAlmTp;
            pSlotDB->VotRoc1PosHhAlmTp     = pSyncRec->VotRoc1PosHhAlmTp;
            pSlotDB->VotRoc2PosHhAlmTp     = pSyncRec->VotRoc2PosHhAlmTp;
            pSlotDB->VotRoc1NegAlmTp       = pSyncRec->VotRoc1NegAlmTp;
            pSlotDB->VotRoc2NegAlmTp       = pSyncRec->VotRoc2NegAlmTp;
            pSlotDB->VotPv2HhAlmTp         = pSyncRec->VotPv2HhAlmTp;
            pSlotDB->Pv1Connect             = pSyncRec->Pv1Connect;
            pSlotDB->Pv2Connect             = pSyncRec->Pv2Connect;
            pSlotDB->Pv3Connect             = pSyncRec->Pv3Connect;
            pSlotDB->Pv4Connect             = pSyncRec->Pv4Connect;

            pSlotDB->VotPVMax = pSyncRec->VotPvMax;

            retVal = PA_OK;
        }        
    }

    return retVal;
}