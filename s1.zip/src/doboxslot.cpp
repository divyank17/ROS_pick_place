/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : doboxslot.cpp                                               *
*    Description : Class clsclsDoBoxSlot definition.                           *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "tracelog.hpp"
#include "doboxslot.hpp"
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
extern clsIol Iol;
const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_OUTPUTFL,
    SF_DIAGCTFL,
    SF_DOVRCRNT,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN
};

const UINT8 clsDoBoxSlot::SoAll[] = {
    PARAMID_OUTRGALL,
    PARAMID_STSINITCPY,
    0 // Terminator
};

#if defined(IOPTYPE_DO)
const UINT8  clsDoBoxSlot::PmioDumpParamTbl[] = {
    PARAMID_MODSTAT1,
    PARAMID_DBVALID,    
    PARAMID_FL_UNPWRD_BX,
#if defined(DIGTYPE_DO32)
    PARAMID_T_FLUID0_PRI,
    PARAMID_T_FLUID1_PRI,
#endif
    0 // Terminator
};

const UINT8 clsDoBoxSlot::CheckPointVer1[] = {  
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    PARAMID_FL_UNPWRD_BX,
    0 // Terminator
};

#if defined(DIGTYPE_DO32)
const UINT8 clsBoxSlot::IopDesc[] = "DO 32   ";
#else
const UINT8 clsBoxSlot::IopDesc[] = "DO 16   ";
#endif

#else
const UINT8 clsDoBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};
#endif

const CHECKPOINT_VER_TABLE clsDoBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 3 }
};

UINT8 clsDoBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

const UINT8 clsDoBoxSlot::RedParams[] = {
    PARAMID_DBVALID,
    PARAMID_IOLDEVTYPE,
    PARAMID_MODLTYPE,
#if defined(DIGTYPE_DO32)
    PARAMID_SFACTNTBL,
    PARAMID_FL_UNPWRD_BX,
#endif
    0 // Terminator
};

volatile UINT8 * clsDoBoxSlot::OutputPorts[] = {
    &P_PB.DR.BYTE, &P_PC.DR.BYTE, &P_PD.DR.BYTE, &P_PE.DR.BYTE
};

const UINT8 clsDoBoxSlot::aMirrorByte[] = {
    0x00,0x80,0x40,0xC0,0x20,0xA0,0x60,0xE0,0x10,0x90,0x50,0xD0,0x30,0xB0,0x70,0xF0,
    0x08,0x88,0x48,0xC8,0x28,0xA8,0x68,0xE8,0x18,0x98,0x58,0xD8,0x38,0xB8,0x78,0xF8,
    0x04,0x84,0x44,0xC4,0x24,0xA4,0x64,0xE4,0x14,0x94,0x54,0xD4,0x34,0xB4,0x74,0xF4,
    0x0C,0x8C,0x4C,0xCC,0x2C,0xAC,0x6C,0xEC,0x1C,0x9C,0x5C,0xDC,0x3C,0xBC,0x7C,0xFC,
    0x02,0x82,0x42,0xC2,0x22,0xA2,0x62,0xE2,0x12,0x92,0x52,0xD2,0x32,0xB2,0x72,0xF2,
    0x0A,0x8A,0x4A,0xCA,0x2A,0xAA,0x6A,0xEA,0x1A,0x9A,0x5A,0xDA,0x3A,0xBA,0x7A,0xFA,
    0x06,0x86,0x46,0xC6,0x26,0xA6,0x66,0xE6,0x16,0x96,0x56,0xD6,0x36,0xB6,0x76,0xF6,
    0x0E,0x8E,0x4E,0xCE,0x2E,0xAE,0x6E,0xEE,0x1E,0x9E,0x5E,0xDE,0x3E,0xBE,0x7E,0xFE,
    0x01,0x81,0x41,0xC1,0x21,0xA1,0x61,0xE1,0x11,0x91,0x51,0xD1,0x31,0xB1,0x71,0xF1,
    0x09,0x89,0x49,0xC9,0x29,0xA9,0x69,0xE9,0x19,0x99,0x59,0xD9,0x39,0xB9,0x79,0xF9,
    0x05,0x85,0x45,0xC5,0x25,0xA5,0x65,0xE5,0x15,0x95,0x55,0xD5,0x35,0xB5,0x75,0xF5,
    0x0D,0x8D,0x4D,0xCD,0x2D,0xAD,0x6D,0xED,0x1D,0x9D,0x5D,0xDD,0x3D,0xBD,0x7D,0xFD,
    0x03,0x83,0x43,0xC3,0x23,0xA3,0x63,0xE3,0x13,0x93,0x53,0xD3,0x33,0xB3,0x73,0xF3,
    0x0B,0x8B,0x4B,0xCB,0x2B,0xAB,0x6B,0xEB,0x1B,0x9B,0x5B,0xDB,0x3B,0xBB,0x7B,0xFB,
    0x07,0x87,0x47,0xC7,0x27,0xA7,0x67,0xE7,0x17,0x97,0x57,0xD7,0x37,0xB7,0x77,0xF7,
    0x0F,0x8F,0x4F,0xCF,0x2F,0xAF,0x6F,0xEF,0x1F,0x9F,0x5F,0xDF,0x3F,0xBF,0x7F,0xFF};

const BOXPARAMINFO clsDoBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      // 35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   // 37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          // 38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          // 39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          // 40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          // 41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          // 43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      // 44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    // 45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           // 47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       // 48 AppBuildNo
#if defined(IOPTYPE_DO)
    DT_BLIND, 22, AT_PSET, ALCK_VIEW, 0, 0, GetIomDtlPtr, FALSE,                    // 49 IOMDTL
    DT_BLIND, 10, AT_PSET, ALCK_VIEW, 0, 0, GetIolSupPtr, FALSE,                    // 50 IOL_SUP
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, 0, 0, GetPmBxSfBitsPtr, FALSE,               // 51 BxSfBits
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 50
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       // 51 BoxSfBits 
#endif
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        // 52 BoxSfLrs 
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       // 53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          // 54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         // 55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              // 56 Dpa
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              // 57 Dsa
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      // 58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      // 59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               // 60 Ba
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                // 61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         // 62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        // 63 HwRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,TRUE,                        // 64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          // 65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            // 66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,PreModStat1,PostModStat1,GetModStat1Ptr,TRUE,    // 67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         // 68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,TRUE,                           // 69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              // 70 Nth
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetSuprCtrlPtr,FALSE,                         // 71 SuprCtrl
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     // 72 SwRevCode
    DT_UINT16,2,AT_MBYTE,ALCK_IUSER,0,0,GetToknStllPtr,FALSE,                       // 73 ToknStll
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     // 74 TstFunctTime
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        // 75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          // 76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,PostRedData,GetRedDataPtr,FALSE,      // 77 RedData
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           // 78 DbValid
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,PostSfActionTbl,GetSfActionTblPtr,FALSE,      // 79 SfActionTbl
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 80
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 81
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 82
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 90
#if defined(IOPTYPE_DO)
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, 0, PostFl_UnPwrd_Bx, GetFl_UnPwrd_BxPtr, TRUE,  // 91 FL_UNPWRD_BX    
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                 // 91
#endif
    DT_BLIND, 8, AT_PSET, ALCK_VIEW, 0, 0, GetSoAllPtr, FALSE,                      // 92 SoAll[]    
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 101
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 102
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 103
    DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, 0, 0, GetStsInitCpyPtr, FALSE,                // 104 StsInitCpy[]
    DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, 0, 0, GetOutRgAllPtr, FALSE,                  // 105 OutRgAll[]
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 114
#if defined(IOPTYPE_DO)
    DT_STRG, 8, AT_MBYTE, ALCK_VIEW, 0, 0, GetIopDescPtr, FALSE,                    // 115 IOPDESC
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 115
#endif
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                         // 116 MaxSlots
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 142
    DT_BLIND, 3, AT_PSET, ALCK_VIEW, PreCheckPoint, 0, GetCheckPointPtr, TRUE,      // 143 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 152
#ifdef IOMTYPE_UIO
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,PreHADCEnable,0,GetHADCEnablePtr,FALSE,             // 153 HADCEnable
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHADCStatusPtr,FALSE,                       // 154 HADCStatus
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 154
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 157
    DT_BLIND,66,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                        // 158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     // 160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostStatReset,GetStatResetPtr,FALSE,  // 161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       // 165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     // 166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      // 167 Tracelevel
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 169
    DT_UINT8,1,AT_SBYTE,ALCK_OPER,PreCPLDRegData,PostCPLDRegData,GetCPLDRegDataPtr,FALSE,// 170 CPLDRegData
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 237
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetCtlTogPtr,FALSE,                            // 238 CtlTog
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetComTogPtr,FALSE,                            // 239 ComTog
#if defined(IOPTYPE_DO)
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetLpbkBdPtr, FALSE,                     // 240 LPBK_BD
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                 // 240
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 242
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 246    
#if defined(DIGTYPE_DO32)
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetT_Fluid0_PriPtr, FALSE,              // 247 T_FUILD0_PRI //DO32 only
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetT_Fluid1_PriPtr, FALSE,              // 248 T_FUILD1_PRI //DO32 only
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                 // 247
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                 // 248
#endif
#if defined(IOPTYPE_DO)
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, 0, 0, GetBoxSfBitsPtr, FALSE,                // 249 BoxSfBits
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetSltCntrPtr, FALSE,                   // 250 SLT_CNTR
    DT_BLIND, 2, AT_MBYTE, ALCK_VIEW, 0, 0, GetOutRegImgPtr, FALSE,                 // 251 OUT_REG_IMG 
    DT_BLIND, 2, AT_MBYTE, ALCK_VIEW, 0, 0, GetFailRgImgPtr, FALSE,                 // 252 FAIL_RG_IMG
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetPrmChngdPtr, FALSE,                   // 253 PRM_CHNGD    
#else    
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 253
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         // 255
};
/*******************************************************************************
*                           clsDoBoxSlot::clsDoBoxSlot                         *
*                           ==========================                         *
* PURPOSE:  Constructor of clsDoBoxSlot Class. Initializes clsDoBoxSlot class  *
*           members.                                                           *
* ARGUMENTS:                                                                   *
*           a_MdType    -   Module type                                        *
* RETURN:   NONE                                                               *
* NOTES:    This constructor will internally invokes clsBoxSlot class          *
*                   constructor.                                               *
*******************************************************************************/
clsDoBoxSlot::clsDoBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType, MAXSLOTS) {
    UINT8 ucCount;

    // Initialize FaultOutput and HoldRegImage with the values on the output ports
    // Repair the stack location just below the high water mark
    *(UINT32 *)FaultOutput = *(STACK_TOP + STACK_SFLIMIT/4);
    *(UINT32 *)HoldRegImage = *(UINT32 *)FaultOutput;
    *(STACK_TOP + STACK_SFLIMIT/4) = 0xFFFFFFFF;

#if defined(IOPTYPE_DO)
    LpbkBd = FALSE;
    OutRegImg = 0;
    FailRgImg = 0;
    SltCntr = 0;
    Fl_UnPwrd_Bx = FL_UNPWRD_UNPOWER;
#endif

    // Initialize OutputBuffer2 with the values on the output ports
    UINT8 ucMask=0x01;
    for (UINT8 ucBank = 0; ucBank < 4; ucBank++) {
        ucMask=0x01;
        for (UINT8 ucChannel = 1; ucChannel <= 8; ucChannel++) {
            UpdateOutputBuffer2((ucChannel+(ucBank*8)), (BOOL)(FaultOutput[ucBank] & ucMask));
            ucMask <<=1;
        }
    }

    // Initialize OutputBuffer1 with the values in OutputBuffer2
    // Update composite feedback variable
    SetOutputBuffer1(GetOutputBuffer2());
    OutRgAll[0] = aMirrorByte[OutputBuffer1[0]];
    OutRgAll[1] = aMirrorByte[OutputBuffer1[1]];
    OutRgAll[2] = aMirrorByte[OutputBuffer1[2]];
    OutRgAll[3] = aMirrorByte[OutputBuffer1[3]];

    *(UINT32 *)StsInitCpy = 0;
    *(UINT32 *)OverCurrent = 0;

#ifdef IOMTYPE_UIO
    for (ucCount = 0; ucCount < MAXSLOTS; ucCount++ ) {
        HADCEnable[ucCount] = FALSE;
        HADCStatus[ucCount] = HART_DATA_UNKNOWN;
    }
#endif

    // If pass 1 hardware get IOTA type from MODNUM bit 6
    // Zero out info for CPLD #2
    // If pass 2 hardware get IOTA type from RSR9 bits 3-0
    // Get info from CPLD #2
    RDBK_SEL = RDBK_CPLD1;
    if (CPLD_REVLETTER == 0x50) {       // Pass 1
        RDBK_SEL = RDBK_MODNUM;
        IotaType = (MODNUM & RELAYBIT) ? DO_IOTA_RELAY : DO_IOTA_24VBUS;
        HwInfo.Pld2RevLetter = 0;
        HwInfo.Pld2RevNumber = 0;
    }
    else {                              // Pass 2
        RDBK_STRB_n = 1;                     // Disable CPLD outputs
        RDBK_SEL3 = 1;
        RDBK_STRB_n = 0;                   // Re-enable CPLD outputs
        RDBK_SEL = RDBK_ITYPE;
        IotaType = DO_IOTA;
        RDBK_SEL = RDBK_PD2REVHI;
        HwInfo.Pld2RevLetter = 16 * DO_PD2REVHI;
        RDBK_SEL = RDBK_PD2REVLO;
        HwInfo.Pld2RevLetter += DO_PD2REVLO;
        RDBK_SEL = RDBK_PD2BLDHI;
        HwInfo.Pld2RevNumber = 16 * DO_PD2BLDHI;
        RDBK_SEL = RDBK_PD2BLDLO;
        HwInfo.Pld2RevNumber += DO_PD2BLDLO;
        RDBK_STRB_n = 1;                     // Disable CPLD outputs
        RDBK_SEL3 = 0;
        RDBK_STRB_n = 0;                   // Re-enable CPLD outputs
        // Initialize IRQ3 interrupt for Over-Current functionality.
        IRQ3_ENABLE = ENABLE;
        IRQ3_STATUS = DISABLE;
        IRQ3_SENSECTL = IRQ_SC_RISING;
        IPRI_OVERCURNT = LVLPRI_DBUG;
    }
    HwInfo.ProductType = PRODTYPE_DO;
    switch (IotaType){
        case DO_IOTA_24VBUS:
        case DO_IOTA_24V_IS:
            HwInfo.ProductCode = PRODCODE_DO_24VBUS;
            break;
        case DO_IOTA_HV1:
            HwInfo.ProductCode = PRODCODE_DO_HV1;
            break;
        case DO_IOTA_HV2:
            HwInfo.ProductCode = PRODCODE_DO_HV2;
            break;
        case DO_IOTA_RELAY:
            HwInfo.ProductCode = PRODCODE_DO_RELAY;
            break;
        case DO_IOTA_24VISO:
            HwInfo.ProductCode = PRODCODE_DO_24VISO;
            break;
        default:
            HardFail(HF_BADPROGRAMJUMP,DOBOXSLOT_CPP,__LINE__);
    }
    DiagCycleCounter = LPBKDIAGCOUNT;
    DiagBankCounter  = 0;
    bDisableFO= FALSE;
    ucCurrentSlotNum = 1;
    for (ucCount = 75; ucCount > 0; ucCount--) IdleWait(20000);
    
#if defined(DIGTYPE_DO32)
    while (!SwitchInit());
#endif
}
/*******************************************************************************
*                          clsDoBoxSlot::GetDataType                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsDoBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsDoBoxSlot::GetAccessType                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsDoBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                          clsDoBoxSlot::GetParamSize                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsDoBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                          clsDoBoxSlot::GetParamPtr                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsDoBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                         clsDoBoxSlot::GetAccessLock                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsDoBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                    clsDoBoxSlot::GetIsDbChecksumed                           *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDoBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                        clsDoBoxSlot::VerifyControlState                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}
/*******************************************************************************
*                        clsDoBoxSlot::ExecutePreFunction                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsDoBoxSlot::ExecutePostFunction                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                         clsDoBoxSlot::PreCheckPoint                         *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsDoBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    return PA_OK;
}

#if defined(IOPTYPE_DO)
/*******************************************************************************
*                         clsAohBoxSlot::PostFl_UnPwrd_Bx                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::PostFl_UnPwrd_Bx(UINT8)
{
    for (UINT8 ucSlot = 1; ucSlot <= MAXSLOTS; ucSlot++) {
        *(FL_UNPWRD *)SLOT(ucSlot)->GetFl_UnPwrdPtr() = Fl_UnPwrd_Bx;
        // fix for PAR# 1-933RWY8 (DO32 module failure option doesn't function correctly when it was selected as "hold")
        SLOT(ucSlot)->PostFl_UnPwrd(TRUE);
    }
}
#endif
/*******************************************************************************
*                      clsDoBoxSlot::AppStcProcessing                          *
*                      ==============================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::AppStcProcessing(VOID) {
#ifdef DEBUG
    uiExecTime = TPU5_TCNT;
#endif
    UINT8 ucSaveExr=get_imask_exr();
    UINT8 ucSaveRdBkSel=RDBK_SEL;
    BOOL  bSaveRdBkStrobe=RDBK_STRB_n;
    
    // If Relay IOTA, Get FTA present
    if (IotaType == DO_IOTA_RELAY) {
        RDBK_SEL = RDBK_IOTA;
        // If the relay extension board is not present, issue a SF
        // And put all channels into INIT
        if (!FTAPRS) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RLYEXTBDMSSNG,FALSE,0);
            for (UINT8 ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++) SLOT(ucSltNm)->CmptInitReq();
        }
        else {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RLYEXTBDMSSNG,TRUE,0);
            *(UINT32 *)StsInitCpy = 0xFFFFFFFF;
        }
    }

#if defined(IOPTYPE_DO)
    FtaStatus();
#endif        

    // Process redundancy inputs, outputs and state here
    ManageRedIO();

    // Do output diagnostics only once every 30ms and only do a bank (8 bits) at a time
    // For all banks it takes 120ms.
    if(ucCurrentSlotNum == 1)
        bDisableFO= FALSE;

    if (DiagCycleCounter == 0) {
        DiagCycleCounter = LPBKDIAGCOUNT;
        if(((OUTCTL_PARTNER == ModStat3.OutCtl)&&(!Iol.AmPrimary()))||
            ((OUTCTL_MINE == ModStat3.OutCtl)&&(Iol.AmPrimary()))){
            // Skip the loopbackDiag cycle for all channels once if SWAP is in Progress.
            // This allows the diagnostic to resume after 120ms (FOR 32 CHANNELS).
            if (GetStcSyncReset()) {
                bStcSyncRestart = FALSE;
#if defined(DIGTYPE_DO16)
                // added due to PAR# 1-90NDJUH (few channels were showing channel soft failure, wrongly)
                // modified diagnostic count for 16 channels
                DiagCycleCounter = LPBKDIAGCOUNT*2;
#else
                DiagCycleCounter = LPBKDIAGCOUNT*4;
#endif
            }
            else {
#if defined(DIGTYPE_DO16)
                // added due to PAR# 1-90NDJUH (few channels were showing channel soft failure, wrongly)
                // modified diagnostic count for 16 channels
                LoopbackDiagnostics(DiagBankCounter%2);
#else
                LoopbackDiagnostics(DiagBankCounter%4);
#endif
                DiagBankCounter++;
            }
        }
    }
    else DiagCycleCounter--;

    UpdateOutputBuffer = TRUE;

    if (CheckRedData(REDDATA_REDCFG) || (!ModStat3.OutCtl && Iol.AmPrimary())) {
        CheckFailOverCondition();
        // If this module is not controlling screws and it is not synced
        // do not recalculate pulsed output and update output buffer
        if (!ModStat3.OutCtl && (REDSTATE_SYNCD != GetRedState())) {
                UpdateOutputBuffer = FALSE;
        }
    }

#if defined(PMIO_DEBUG) && (0)
    if (ucDbgPnt == DODG_DBGPNT)
    {
        ucDbgCnt = 0;
    }
#endif

    // Do output processsing
    for (UINT8 ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) {
        SLOT(ucChannel)->ProcessDoSlot();
    }

#if defined(PMIO_DEBUG) && (0)
if (ucDbgPnt == DODG_DBGPNT)
{    
    //ucDbgCnt = 0;
    ucDumpBuff[ucDbgCnt++] = 0xA5;
    ucDumpBuff[ucDbgCnt++] = OutputBuffer2[3];
    ucDumpBuff[ucDbgCnt++] = OutputBuffer2[2];
    ucDumpBuff[ucDbgCnt++] = OutputBuffer2[1];
    ucDumpBuff[ucDbgCnt++] = OutputBuffer2[0];        
    ucDumpBuff[ucDbgCnt++] = UpdateOutputBuffer;
}
#endif

    // If backup or non-redundant module,
    // Set output buffer with second output buffer
    if (CheckRedData(REDDATA_REDCFG) && ModStat3.OutCtl)
    {
        UpdateOutputBuffer = FALSE;
    }
    else
    {
        SetOutputBuffer1(GetOutputBuffer2());
        UpdateOutputBuffer = TRUE;
    }

    // Update Output Hold Registers only if anything has changed
    if (*(UINT32 *)HoldRegImage != GetAllFaultOutputs()) {
        set_imask_exr(LVLPRI_HIGHEST);               // disable all interrupts
        *OutputPorts[0] = FaultOutput[0];
        *OutputPorts[1] = FaultOutput[1];
        *OutputPorts[2] = FaultOutput[2];
        *OutputPorts[3] = FaultOutput[3];
        HOLDOUT_n = 1;
        HOLDOUT_n = 0;
        *(UINT32 *)HoldRegImage = GetAllFaultOutputs();
    }

#if defined(DIGTYPE_DO16)            
    // Backup latch control signals, driving through firmware
    //
    // only if there is any change in 1-8 channels of (SO) output or PTEXECST_ACTIVE state.
    if (uiEnableOutputLatch & 0x00FF)
    {
        *OutputPorts[0] = FaultOutput[0];

        OutputLatch(ONE_TO_EIGHT, BACKUP_LATCH);
    }

    // only if there is any change in 9-16 channels of (SO) output or PTEXECST_ACTIVE state.
    if (uiEnableOutputLatch & 0xFF00)
    {
        *OutputPorts[1] = FaultOutput[1];

        OutputLatch(NINE_TO_SIXTEEN, BACKUP_LATCH);        
    }
#endif

    // Update Outputs
    *OutputPorts[0] = OutputBuffer1[0];
    *OutputPorts[1] = OutputBuffer1[1];
    *OutputPorts[2] = OutputBuffer1[2];
    *OutputPorts[3] = OutputBuffer1[3];

#if defined(PMIO_DEBUG) && (0)
    if (ucDbgPnt == DODG_DBGPNT)
    {
        ucDumpBuff[ucDbgCnt++] = 0x55;
        ucDumpBuff[ucDbgCnt++] = FaultOutput[3];
        ucDumpBuff[ucDbgCnt++] = FaultOutput[2];
        ucDumpBuff[ucDbgCnt++] = FaultOutput[1];
        ucDumpBuff[ucDbgCnt++] = FaultOutput[0];
        ucDumpBuff[ucDbgCnt++] = UpdateOutputBuffer;
    }
#endif

#if defined(DIGTYPE_DO16)
    // Primary latch control signals, driving through firmware
    // only if there is any change in 1-8 channels of (SO) output or PTEXECST_ACTIVE state.
    if (uiEnableOutputLatch & 0x00FF)
    {
        OutputLatch(ONE_TO_EIGHT, PRIMARY_LATCH);

        uiEnableOutputLatch &= 0xFF00;
    }
    
    // only if there is any change in 9-16 channels of (SO) output or PTEXECST_ACTIVE state.
    if (uiEnableOutputLatch & 0xFF00)
    {
        OutputLatch(NINE_TO_SIXTEEN, PRIMARY_LATCH);

        uiEnableOutputLatch &= 0x00FF;
    }
#endif

    set_imask_exr(ucSaveExr);      // allow an IOL request in here if it comes

    // Now update the OutRgAll with the reverse bit order of the Output Buffer
    set_imask_exr(LVLPRI_HIGHEST);                   // disable all interrupts
    OutRgAll[0] = aMirrorByte[OutputBuffer1[0]];
    OutRgAll[1] = aMirrorByte[OutputBuffer1[1]];
    OutRgAll[2] = aMirrorByte[OutputBuffer1[2]];
    OutRgAll[3] = aMirrorByte[OutputBuffer1[3]];
    set_imask_exr(ucSaveExr);                          // re-enable interrupts

    if (!UpdateOutputBuffer) SetOutputBuffer1(GetOutputBuffer2());

#if defined(PMIO_DEBUG) && (0)
    if (ucDbgPnt == DODG_DBGPNT)
    {
        ucDumpBuff[ucDbgCnt++] = 0x5A;
        ucDumpBuff[ucDbgCnt++] = OutputBuffer1[3];
        ucDumpBuff[ucDbgCnt++] = OutputBuffer1[2];
        ucDumpBuff[ucDbgCnt++] = OutputBuffer1[1];
        ucDumpBuff[ucDbgCnt++] = OutputBuffer1[0];
        ucDumpBuff[ucDbgCnt++] = UpdateOutputBuffer;
    }
#endif
    // Enable the failover only when the loopback test is passed at least once
    // for all the channels.
    if(ucCurrentSlotNum > MAXSLOTS) {
        if ((bDisableFO == FALSE) && (Iol.AmPrimary()) &&
            (REDSTATE_SYNCD == GetRedState())) {
            EnableOutputFailFO();
        }
        DiagBankCounter = 0;
        ucCurrentSlotNum = 1;
    }

#ifdef DEBUG
    UINT16 uiStopTime = TPU5_TCNT;

    if (uiStopTime > uiExecTime) uiExecTime = uiStopTime - uiExecTime;
    else uiExecTime = (TPUCOUNT_MAXVALUE - uiExecTime) + uiStopTime + 1;
    
    if (uiMaxStcTime < uiExecTime) uiMaxStcTime = uiExecTime;

#endif
    RDBK_STRB_n = bSaveRdBkStrobe;                        // restore RDBK_STRB_n
    RDBK_SEL = ucSaveRdBkSel;                                // restore RDBK_SEL
}

#if !defined(DIGTYPE_DO16)
/*******************************************************************************
*                     clsDoBoxSlot::EnableSwitchDiagnostics                    *
*                     =====================================                    *
* PURPOSE:  This is a diganostics for EN_SW (Enable Switch). This is used in   *
*           DO Redundancy. First check whether EN_SW is in ON state. Then check*
*           whether EN_SW is in OFF state. Finally check whether the EN_SW is  *
*           is in ON state. This diagnostic routine is called when the module  *
*           is configured as secondary.                                        *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::EnableSwitchDiagnostics(VOID){
    EnableSwitchCheck(SW_ON);
    EN_SW = SW_OFF;     // Push EN_SW to OFF state.
    EnableSwitchCheck(SW_OFF);
    EN_SW = SW_ON;     // Push EN_SW to ON state.
    EnableSwitchCheck(SW_ON);
}
/*******************************************************************************
*                     clsDoBoxSlot::EnableSwitchCheck                          *
*                     ===============================                          *
* PURPOSE:  This is a Enable Switch check used as a part of EN_SW diagnostics. *
*           This checks EN_SW switch state against the provided state of the   *
*           same switch. Try reading the EN_SW switch 2 times. If error exists *
*           after retries, then write the same value to the switch and try     *
*           reading the switch. If read fails after 2 times of retries, then   *
*           HardFail the module.                                               *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::EnableSwitchCheck(BOOL a_SwitchState){
    UINT8 ucCountOuter,ucCountInner;

    for (ucCountOuter=3; ucCountOuter>0; ucCountOuter--) {
        for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
            if (a_SwitchState == EN_SW) return;
            IdleWait(10);
        }
        // If read fails, force EN_SW to desired state
        EN_SW = a_SwitchState;
    }
    // If the check fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL,DOBOXSLOT_CPP,__LINE__);
}
/*******************************************************************************
*                    clsDoBoxSlot::InhibitSwitchDiagnostics                    *
*                    ======================================                    *
* PURPOSE:  This is a diagnostics routine to check the status of INH_SW1 and   *
*           INH_SW2 switches. This is used as a part of redundancy diagnostics.*
*           If the module is configured as Primary, check whether the EN_SW is *
*           in ON state. then check TST_SW is in OFF state. then check both the*
*           INH_SW1 and INH_SW2 are in ON state.                               *
*           If the module is configured as Secondary,then do EN_SW diagnositcs.*
*           then check both INH_SW1 and INH_SW2 are in OFF state.              *
*           Next try checking correct functioning of INH_SW1 and INH_SW2       *
*           switches. (Make sure that when module is secondary, both these     *
*           switches should not be ON at the same time).                       *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::InhibitSwitchDiagnostics(VOID){
    BOOL    bInhFaulted = FALSE;
    // if module is primary, check EN_SW is ON, check TST_SW is OFF,
    // and check both the INH_SW switches are ON.
    if (OUTCTL_MINE == ModStat3.OutCtl) {
        // Check whether EN_SW is ON
        EnableSwitchCheck(SW_ON);
        // Check whether TST_SW is OFF
        TestSwitchCheck(SW_OFF);
        // Check whether INH_SW switches are ON
        InhibitSwitchCheck(INH_ON_ON);
    }// end of primary 
    else { // the module is secondary
        // Do EN_SW diagnostics.
        EnableSwitchDiagnostics();
        // Make sure both INH_SW switches are OFF
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_OFF);

        // Turn ON the TST_SW
        SetTestSwitch(SW_ON);
        // Change the INH_SW1 to ON and keep INH_SW2 at OFF.
        INH_SW1 = SW_ON;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_ON_OFF);

        // Change the INH_SW1 to OFF.
        INH_SW1 = SW_OFF;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_OFF);

        // Turn OFF the TST_SW
        SetTestSwitch(SW_OFF);
        IdleWait(150);

        // Change the INH_SW2 to ON and keep INH_SW1 at OFF.
        INH_SW2 = SW_ON;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_ON);

        // Change the INH_SW2 to OFF.
        INH_SW2 = SW_OFF;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_OFF);

        // If INHOUT_n is faulted post the SF
        if(bInhFaulted) BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_REDHWFAIL,TRUE,0);
    }
}
/*******************************************************************************
*                      clsDoBoxSlot::InhibitSwitchCheck                        *
*                      ================================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDoBoxSlot::InhibitSwitchCheck(UINT8 a_ucSwitchState) {
    UINT8 ucCountOuter,ucCountInner,ucFeedback;

    for (ucCountInner = 3; ucCountInner>0; ucCountInner--) 
    {
        if (a_ucSwitchState == InhibitSwitchStatus()) return FALSE;
        IdleWait(10);        
    }    
    
    // If the verification fails, try two more times to
    // force the INH_SW1 and INH_SW2 to the desired states and verify it
    for (ucCountOuter=2; ucCountOuter>0; ucCountOuter--) 
    {
        if (a_ucSwitchState == INH_ON_ON) {
            INH_SW1 = SW_ON;
            INH_SW2 = SW_ON;
        }
        else if (a_ucSwitchState == INH_ON_OFF) {
            INH_SW1 = SW_ON;
            INH_SW2 = SW_OFF;
        }
        else if (a_ucSwitchState == INH_OFF_ON) {
            INH_SW1 = SW_OFF;
            INH_SW2 = SW_ON;
        }
        else if (a_ucSwitchState == INH_OFF_OFF) {
            INH_SW1 = SW_OFF;
            INH_SW2 = SW_OFF;
        }        

        IdleWait(150);
        
        for (ucCountInner = 3; ucCountInner>0; ucCountInner--) 
        {
            ucFeedback = InhibitSwitchStatus();
            if (ucFeedback == a_ucSwitchState) return FALSE;
            IdleWait(10);        
        }
    }

    // INHINX_n or INHOUT_n faulted
    if (ucFeedback ^ a_ucSwitchState == INHIBIT_FAULTED)
        // States for a backup module
        if (a_ucSwitchState != INH_ON_ON) return TRUE;

#if defined(IOPTYPE_DO)
        // added to resolve, PAR# 1-7LC52TF (NR /Status RED Led Issue)
        // If FTA missing or Secondary & just got BackupRequest from PRI  
        if ((FtaStatus() != FTA_RETURN_AND_TOUT) ||
            // fix for AO16H PAR# 1-DYD1PEV  - (NR/Status RED Led during removal & reinsertion of IOLink cable A & B of Primary)
            (REDSTATE_IOL_TIMEOUT != BOX->GetRedState()) ||
           ((OUTCTL_PARTNER == BOX->GetModStat3()) && (GetPartnersBackupStatus())))
        {
            return FALSE;
        }
#endif
        
    // If all fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL,DOBOXSLOT_CPP,__LINE__,a_ucSwitchState,ucFeedback);
    return TRUE;
}
/*******************************************************************************
*                     clsDoBoxSlot::InhibitSwitchStatus                        *
*                     =================================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsDoBoxSlot::InhibitSwitchStatus(VOID) {
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    UINT8 ucTemp = 0x00;

    if (HwInfo.Pld2RevLetter == 0) { // Pass 1
        if (INHSWV1P1)
            ucTemp = ucTemp | 0x08;
        if (INHSWV3P1)
            ucTemp = ucTemp | 0x10;
        if (INHSWV2P1)
            ucTemp = ucTemp | 0x20;
    }
    else
    {                            // Pass 2        
        RDBK_STRB_n = 1;            // Disable CPLD outputs
        RDBK_SEL3 = 1;              // Select CPLD 2
        RDBK_STRB_n = 0;            // Re-enable CPLD outputs
        RDBK_SEL  = RDBK_INHSW;
        if (INHSWV1)
            ucTemp = ucTemp | 0x08;
        if (INHSWV3)
            ucTemp = ucTemp | 0x10;
        if (INHSWV2)
            ucTemp = ucTemp | 0x20;
        RDBK_STRB_n = 1;            // Disable CPLD outputs
        RDBK_SEL3 = 0;              // Select CPLD 1
        RDBK_STRB_n = 0;            // Re-enable CPLD outputs
    }
    set_imask_exr(ucSaveExr);
    return ucTemp;
}
/*******************************************************************************
*                        clsDoBoxSlot::TestSwitchCheck                         *
*                        =============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::TestSwitchCheck(BOOL a_SwitchState) {
    UINT8 ucCountOuter,ucCountInner;

    for (ucCountOuter=3; ucCountOuter>0; ucCountOuter--) {
        for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
            if (a_SwitchState == TST_SW) return;
            IdleWait(10);
        }
        // If read fails, force TST_SW to desired state
        TST_SW = a_SwitchState;
    }
    // If the check and force fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL,DOBOXSLOT_CPP,__LINE__);
}
/*******************************************************************************
*                        clsDoBoxSlot::SetTestSwtich                           *
*                        ===========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::SetTestSwitch(BOOL a_State) {
    if (a_State == SW_ON) {
        TestSwitchCheck(SW_OFF);
        TST_SW = SW_ON;
        TestSwitchCheck(SW_ON);
    }
    else if (a_State == SW_OFF) {
        TestSwitchCheck(SW_ON);
        TST_SW = SW_OFF;
        TestSwitchCheck(SW_OFF);
    }
}
#endif
/*******************************************************************************
*                       clsDoBoxSlot::AppColdInit                              *
*                       =========================                              *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::AppColdInit(VOID) {
    if (MODSTATUS_RUN == ModStat1.Status) {
        ModStat1.Status = MODSTATUS_IDLE;
        AddModStatEvent(EVENTTYPE_NORMAL);
    }
    DbValid = DB_INVALID;
    ComputeCheckSum(); // Recompute BOX checksum
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        // Slot checksum is recomputed by InitSlotDatabase
        SLOT(ucSlotNum)->InitSlotDatabase(TRUE);
    }
}
/*******************************************************************************
*                        clsDoBoxSlot::AppFOProcess                            *
*                        ==========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDoBoxSlot::AppFOProcess(VOID) {
    return FALSE;
}
/*******************************************************************************
*                        clsDoBoxSlot::AppPostSwap                             *
*                        =========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::AppPostSwap(VOID) {    
#if defined(DIGTYPE_DO32)
    // Give up control of outputs
    INH_SW1 = SW_OFF;
    INH_SW2 = SW_OFF;
    // 150us wait
    IdleWait(150);
    InhibitSwitchCheck(INH_OFF_OFF);
#endif
    ModStat3.OutCtl = OUTCTL_PARTNER;
}
/*******************************************************************************
*                        clsDoBoxSlot::AppPostSync                             *
*                        =========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::AppPostSync(VOID) {
    // Reset the DiagBankCounter so that both the modules will start doing
    // diagnostics at the same time.
    DiagBankCounter = 0;
    DiagCycleCounter = LPBKDIAGCOUNT;
    ucCurrentSlotNum = 1;
    // Do this only if module is secondary
    BOOL   bSO=FALSE;
    if (!Iol.AmPrimary()) {
        // Reset the Overcurrent so that secondary will return any alarms related to 
        // Overcurrent for any channels.
        for (UINT8 ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++) {
            if (GetOverCurrent(ucSltNm)) {
                SetOverCurrent(ucSltNm, FALSE);
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ucSltNm);
            }
        }

        for (UINT8 ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++) {
            switch(SLOT(ucSltNm)->GetDOType()) {
            case DOTYPE_PWM:
#if defined(DIGTYPE_DO32)
                SLOT(ucSltNm)->InitTPStartEnd();
#endif
                if (TRUE == SLOT(ucSltNm)->GetStartNext())
                    bSO = FALSE;
                else {
                    if(0 == SLOT(ucSltNm)->GetPWMPulseTime())
                        bSO = FALSE;
                    else
                        bSO = TRUE;
                }
                break;
            case DOTYPE_STATUS:
            case DOTYPE_OFFPULSE:
            case DOTYPE_ONPULSE:
                bSO = SLOT(ucSltNm)->GetSO();
                break;
            default:
                break;
            }
            UpdateOutputBuffer2(ucSltNm, bSO);
            SLOT(ucSltNm)->CmptInitReq();
        }
    }
}
/*******************************************************************************
*                        clsDoBoxSlot::SetForPrimary                           *
*                        ===========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::SetForPrimary (VOID) {    
#if defined(DIGTYPE_DO32)
    TST_SW = SW_ON; 
    INH_SW1 = SW_ON;
    INH_SW2 = SW_ON;
    TST_SW = SW_OFF;
    IdleWait(150);
    InhibitSwitchCheck(INH_ON_ON);
#endif
    ModStat3.OutCtl = OUTCTL_MINE;
}
/*******************************************************************************
*                        clsDoBoxSlot::SetForSecondary                         *
*                        =============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::SetForSecondary (BOOL bDoCheck) {
#if defined(DIGTYPE_DO32)
    INH_SW1 = SW_OFF;
    INH_SW2 = SW_OFF;
    if (bDoCheck) { // verify switch states
        IdleWait(150);
        InhibitSwitchCheck(INH_OFF_OFF);
    }
#endif
    ModStat3.OutCtl = OUTCTL_PARTNER;
}
/*******************************************************************************
*                     clsDoBoxSlot::CheckFailOverCondition                     *
*                     ====================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::CheckFailOverCondition(VOID) {
    BOOL bTstSave = TST_SW;                          // Save state of TST switch
    //To allow factory to test this switch. 
    if(!(BOX->CheckForFactoryTestMode())){
        TST_SW = SW_OFF;
    }
    RDBK_SEL = RDBK_IOTA;
    if (ModStat3.OutCtl == OUTCTL_PARTNER) {  // I do not have ctl of the screws
        if (BURIN_ASSERTED == BUPREQ_IN) {     // my partner has asserted BUPREQ
            if (INHIN_NEGATED == INHINX_n) {   // and it has given up the screws
                IdleWait(50);
                if (INHIN_NEGATED == INHINX_n) {  // partner still does not have
                    if (BUREQ_NEGATED == SWBUREQ_n) { // and i have negated BURQ
                        SetForPrimary();
                        if (REDSTATE_FO_IN_PROG == GetRedState())
                            SetRedState(REDSTATE_FO_COMPLETE);
                    }
                }
            }
        }
        if (Iol.AmPrimary()) {
#if defined(IOPTYPE_DO)
            // added, when redesign module fails to swapover/failover from SEC to PRI with Legacy as partner
            // as per PMIO, PRI module should first takeover the output control than SEC.                        
            TST_SW = SW_ON;
            //Shut off the partner outputs from driving the outputs
            INH_SW1 = SW_ON;
            INH_SW2 = SW_ON;
            IdleWait(5000);        // wait for inhibit switches some delay time
            TST_SW = SW_OFF; // To read INHIN, Change Tst SWs to OFF.
            if (INHIN_NEGATED != INHINX_n)
            {
                INH_SW1 = SW_OFF;        // relinquish control of screws
                INH_SW2 = SW_OFF;
            }
#endif
            if (INHIN_NEGATED == INHINX_n) { // and it has given up the screws
                IdleWait(50);
                if (INHIN_NEGATED == INHINX_n) {// partner still does not have
                    // If at this point the expected FO sequence did not occur
                    // properly. So save the state of the BUREQ's & REDSTATE
                    // Then take control of the field terminations
                    TraceLog.AddToTrace(TRACEID_GENERIC,bcFailOver,
                       (UINT32)BUPREQ_IN << 24 | (UINT32)SWBUREQ_n << 16 |
                       (UINT32)GetRedData() << 8 | GetRedState());
                    SetForPrimary();
                    if (REDSTATE_FO_IN_PROG == GetRedState())
                       SetRedState(REDSTATE_FO_COMPLETE);
                }
            }
        }
    }
    else if (!Iol.AmPrimary()) {                // I have control of the screws
                                                   // and have started failover
        if (BUREQ_ASSERTED == SWBUREQ_n) {          // If I am asserting BUPREQ
#if defined(IOPTYPE_DO)
            // if FTA missing or my partner is not asserting BUPREQ
            if (!(GetFtaPres()) || (BURIN_NEGATED == BUPREQ_IN)) {
#else
            if (BURIN_NEGATED == BUPREQ_IN) {          // and my partner is not
#endif           
                SetForSecondary(TRUE);          // assume role of backup module
            }
        }
    }
    TST_SW = bTstSave;                           // Restore state of TST switch
}
#if defined(DIGTYPE_DO32)
/*******************************************************************************
*                         clsDoBoxSlot::SwitchInit                             *
*                         ========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDoBoxSlot::SwitchInit (VOID) {

    EN_SW = SW_ON;                                    // Push EN_SW to ON state
    EnableSwitchCheck(SW_ON);                             // Verify it happened
    RDBK_SEL = RDBK_IOTA;
    UINT8 ucDelay = (BOTTOM) ? 20000 : 10;       // compute variable delay (us)
    if (INHIN_NEGATED == INHINX_n) {       // partner is not controlling screws
        if (BURIN_ASSERTED == BUPREQ_IN) {          // partner asserting BUPREQ
            if (INHIN_NEGATED == INHINX_n) {   // partner still not have screws
                IdleWait(ucDelay);                  // wait for some delay time
                if (INHIN_NEGATED == INHINX_n) { // partnr does not have screws
                    INH_SW1 = SW_ON;            // assume control of the screws
                    INH_SW2 = SW_ON;
                    IdleWait(ucDelay);              // wait for some delay time
                    if (INHIN_NEGATED == INHINX_n) { // partner not have screws
                        SetForPrimary();              // assume role as primary
                        return TRUE;                           // exit finished
                    }
                    else {
                        INH_SW1 = SW_OFF;        // relinquish control of screws
                        INH_SW2 = SW_OFF;
                        IdleWait(ucDelay);          // wait for some delay time
                        return FALSE;                         // exit unfinished
                    }
                }
                else {                         // partner is controlling screws
                    SetForSecondary(TRUE);      // assume role as backup module
                    return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                                 // exit unfinished
            }
        }
        else {
            IdleWait(ucDelay);                      // wait for some delay time
            if (INHIN_NEGATED == INHINX_n) {    // partner does not have screws
                if (BURIN_ASSERTED == BUPREQ_IN) {  // partner asserting BUPREQ
                    return FALSE;                            // exit unfinished
                }
                else {                       // partner is not asserting BUPREQ
                    SetForPrimary();
                    IdleWait(150);                    // wait for 150 microsecs
                    return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                                // exit unfinished
            }
        }
    }
    else {                                 // partner is controlling the screws
        IdleWait (ucDelay);                         // wait for some delay time
        if (INHIN_NEGATED == INHINX_n) {        // partner does not have screws
            return FALSE;                                    // exit unfinished
        }
        else {                             // partner is controlling the screws
            SetForSecondary(TRUE);              // assume role as backup module
            return TRUE;                                       // exit finished
        }
    }
}
#endif
#if defined(DIGTYPE_DO16)
VOID clsDoBoxSlot::OutputLatch(BOOL bChannelGroup, BOOL bLatchType)
{       
    // Primary Latch configuration.
    // SLOT01 - SLOT08 (AIOL02+ : AIOL00+) - 3b010
    // SLOT09 - SLOT16 (AIOL02+ : AIOL00+) - 3b011

    // Backup Latch Configuration.
    // SLOT01 - SLOT08 (AIOL02+ : AIOL00+) - 3b001
    // SLOT09 - SLOT16 (AIOL02+ : AIOL00+) - 3b100
    AIOL00_PIN = (PRIMARY_LATCH == bLatchType) ? ((ONE_TO_EIGHT == bChannelGroup) ? DEASSERTED :   ASSERTED) : \
                                                 ((ONE_TO_EIGHT == bChannelGroup) ?   ASSERTED : DEASSERTED);

    AIOL01_PIN = (PRIMARY_LATCH == bLatchType) ? ASSERTED : DEASSERTED;

    AIOL02_PIN = (PRIMARY_LATCH == bLatchType) ? DEASSERTED : ((ONE_TO_EIGHT == bChannelGroup) ? DEASSERTED : ASSERTED);

    // Generating Low Pulse on following pins, to enable decoder
    // Asserting LOW
    A13A03_PIN = A14A15_PIN = DEASSERTED;
    // informing to the FPGA, that outputs are going to latch
    P16IOL_PIN = WRIOLX_PIN = DEASSERTED;

    // Asserting HIGH
    A13A03_PIN = A14A15_PIN = ASSERTED;
    // informing to the FPGA, that outputs latching done.
    P16IOL_PIN = WRIOLX_PIN = ASSERTED;

    // default setting
    AIOL00_PIN = AIOL01_PIN = AIOL02_PIN = DEASSERTED;    
}
#endif
/*******************************************************************************
*                         clsDoBoxSlot::LoopbackDiagnostics                    *
*                         =================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           Bank number to be checked                                          *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoBoxSlot::LoopbackDiagnostics (UINT8 ucBank)
{
    UINT8   ucIndex,ucResult,ucMask;

#if defined(IOPTYPE_DO)
    //FTA should be present while performing loopback diag
    if (FtaStatus() == FTA_MISSING) return;  
#endif

    // If neither module has control of screws return without performing diags
    if ((INHIN_NEGATED == INHINX_n) && (ModStat3.OutCtl == OUTCTL_PARTNER)) return;

    RDBK_SEL = RDBK_IOTA;
    if (INHIN_NEGATED == INHINX_n) { // I have control of screws
        // If all bits agree clear all SFs and exit
        ucResult = (OverCurrent[ucBank]) | (*OutputPorts[ucBank] ^ GetReadbackRegister(RDBK_BANK2+ucBank));
        if (ucResult == 0) {
            for (ucIndex = 1; ucIndex <= CHANNELSPERBANK; ucIndex++) {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,CHANNELSPERBANK*ucBank+ucIndex);
                ucCurrentSlotNum++;
            }
            return;
        }
    }
    else {                  // I do not have control of screws
        ucResult = (OverCurrent[ucBank]) & (*OutputPorts[ucBank] ^ OutputBuffer1[ucBank]);
        // If all bits agree clear all SFs and exit
        if (ucResult == 0) {
            for (ucIndex = 1; ucIndex <= CHANNELSPERBANK; ucIndex++) {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,CHANNELSPERBANK*ucBank+ucIndex);
                ucCurrentSlotNum++;
            }
            return;
        }
    }

    IdleWait(10);
    // All bits did not agree
    // So process each channel one by one
    RDBK_SEL = RDBK_IOTA;
    ucMask   = 0x01;
    if (INHIN_NEGATED == INHINX_n) { // I have control of screws
        ucResult = (OverCurrent[ucBank]) | (*OutputPorts[ucBank] ^ GetReadbackRegister(RDBK_BANK2+ucBank));
        for (ucIndex = 1; ucIndex <= CHANNELSPERBANK; ucIndex++) {
            if ((ucResult & ucMask) && 
                ((BOX->GetModuleStatus() == MODSTATUS_RUN) && (PTEXECST_ACTIVE == SLOT(CHANNELSPERBANK*ucBank+ucIndex)->GetPtExecSt()))) {
                if (!IsOutputFlActive()){
                TraceLog.AddToTrace(TRACEID_GENERIC,bcDoLpBkDiagPriFail,
               (UINT32)(*OutputPorts[ucBank]) << 24 | (UINT32)(OutputBuffer1[ucBank]) << 16 |
               (UINT32)GetReadbackRegister(RDBK_BANK2+ucBank) << 8 | GetRedState());
                }

                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,TRUE,CHANNELSPERBANK*ucBank+ucIndex);
                
                if (OverCurrent[ucBank] & ucMask) {
                    SLOT((ucIndex+(ucBank*CHANNELSPERBANK)))->OverCurrentAction();
                }
                else {
                    SLOT((ucIndex+(ucBank*CHANNELSPERBANK)))->SetPWMPulseTime(0); // Reset PWM pulse if it exists
                    SLOT((ucIndex+(ucBank*CHANNELSPERBANK)))->BackInit();         // and back initialize
                }
                bDisableFO= TRUE;
            }
            else {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,CHANNELSPERBANK*ucBank+ucIndex);
            }
            ucMask = ucMask << 1;
            ucCurrentSlotNum++;
        }
    }
    else {                  // I do not have control of screws
        ucResult = (OverCurrent[ucBank]) & (*OutputPorts[ucBank] ^ OutputBuffer1[ucBank]);
        for (ucIndex = 1; ucIndex <= CHANNELSPERBANK; ucIndex++) {
            if ((ucResult & ucMask) && 
                ((BOX->GetModuleStatus() == MODSTATUS_RUN) && (PTEXECST_ACTIVE == SLOT(CHANNELSPERBANK*ucBank+ucIndex)->GetPtExecSt()))) {
                if (!IsOutputFlActive()){
                TraceLog.AddToTrace(TRACEID_GENERIC,bcDoLpBkDiagSecFail,
               (UINT32)(*OutputPorts[ucBank]) << 24 | (UINT32)(OutputBuffer1[ucBank]) << 16 |
               (UINT32)GetReadbackRegister(RDBK_BANK2+ucBank) << 8 | GetRedState());
                }

                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,TRUE,CHANNELSPERBANK*ucBank+ucIndex);

                if (OverCurrent[ucBank] & ucMask) {
                    SLOT((ucIndex+(ucBank*CHANNELSPERBANK)))->OverCurrentAction();
                }
                else {
                    SLOT((ucIndex+(ucBank*CHANNELSPERBANK)))->SetPWMPulseTime(0); // Reset PWM pulse if it exists
                    SLOT((ucIndex+(ucBank*CHANNELSPERBANK)))->BackInit();         // and back initialize
                }
                bDisableFO= TRUE;
            }
            else {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,CHANNELSPERBANK*ucBank+ucIndex);
            }
            ucMask = ucMask << 1;
            ucCurrentSlotNum++;
        }
    }
}
/******************************************************************************
*                       clsDoBoxSlot::IRQ3InterruptHandler                    *
*                       ==================================                    *
* PURPOSE: This interrupt handler detects the over current channel and posts  *
*          a soft fail.SF_DOVRCRNT.                                           *
* ARGUMENTS:  NONE                                                            *
* RETURN:     NONE                                                            *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID clsDoBoxSlot::IRQ3InterruptHandler(VOID)  {
#if !defined(IOPTYPE_DO)
    // Reenable the interrupt
    IRQ3_STATUS = DISABLE;
    UINT8 ucResult,ucIndex,ucBank,ucChanInOverCurrent,ucMask;
    UINT8 ucSaveRdBkSel=RDBK_SEL;
    BOOL  bSaveRdBkStrobe=RDBK_STRB_n;

    UINT8 ucSaveExr=get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    // Select Readback register 11 to know the status of High-Side Switch
    RDBK_STRB_n = 1;            // Disable CPLD outputs
    RDBK_SEL3 = 1;              // Select CPLD 2
    RDBK_STRB_n = 0;            // Re-enable CPLD outputs
    RDBK_SEL  = RDBK_HSOC;
    // Read the High Side Switch
    UINT8 ucHsoc = HSOC;
    RDBK_STRB_n = 1;            // Disable CPLD outputs
    RDBK_SEL3 = 0;              // Select CPLD 1
    RDBK_STRB_n = 0;            // Re-enable CPLD outputs
    set_imask_exr(ucSaveExr);

    ucMask = 0x01;
    // Read the actual output at screws and database value
    for (ucBank=0; ucBank < MAXHSOCBANKS; ucBank++) {
        ucChanInOverCurrent = 0x01;
        ucResult = *OutputPorts[ucBank] ^ GetReadbackRegister(RDBK_BANK2+ucBank);
        for (ucIndex = 1; ucIndex <= CHANNELSPERBANK; ucIndex++) {
            if ((ucResult & 0x01) && !(ucHsoc & ucMask)) {
                BOX->OverCurrent[ucBank] |= ucChanInOverCurrent;
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,TRUE,(ucIndex+(ucBank*CHANNELSPERBANK)));
            }
            ucResult >>= 1;
            ucChanInOverCurrent <<= 1;
        }
        ucMask <<=1;
    }

    RDBK_STRB_n = bSaveRdBkStrobe;                        // restore RDBK_STRB_n
    RDBK_SEL = ucSaveRdBkSel;                                // restore RDBK_SEL
#endif
}
