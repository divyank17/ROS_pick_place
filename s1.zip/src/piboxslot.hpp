/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2010                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : piboxslot.hpp                                               *
*    Description : Class clsPiBoxSlot declaration.                             *
*******************************************************************************/
#ifndef __PIBOXSLOT_HPP__
#define __PIBOXSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "boxslot.hpp"
#include "pislot.hpp"
#include "piversion.h"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#define PARAMID_MAINTAINONFAULT 198
#define PARAMID_CONFIGPROVSIG   196
#define PIBOXSLOT_SIZE ((sizeof(clsPiBoxSlot) + (sizeof(clsPiBoxSlot) % 2)) / 2)
#define FORCEDSAFE_ON  0
#define FORCEDSAFE_OFF 1
// SO redundancy definitions
const UINT8 INH_ON_ON   = 0x00;
const UINT8 INH_ON_OFF  = 0x38;
const UINT8 INH_OFF_ON  = 0x08;
const UINT8 INH_OFF_OFF = 0x18;
const UINT8 INHIBIT_FAULTED  = 0x08;
const UINT8 INH_ON_OFF_FLTD  = 0x30;
const UINT8 INH_OFF_ON_FLTD  = 0x00;
const UINT8 INH_OFF_OFF_FLTD = 0x10;
const UINT8 SW_ON       = TRUE;
const UINT8 SW_OFF      = FALSE;
const UINT8 INH_SW_MASK = 0x38;
const UINT8 TST_SW_MASK = 0x02;
const UINT8 EN_SW_MASK  = 0x01;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsPiBoxSlot; // forward declaration
typedef struct tagBoxParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    PASTATUS (clsPiBoxSlot::* PrePtr)(UINT8 *,UINT8);
    VOID     (clsPiBoxSlot::* PostPtr)(UINT8);
    VOID *   (clsPiBoxSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

//To Avoid Padding of structure
#pragma pack 1
typedef struct tagPvScanRec1 {
   FLOAT32    Pv;
   STATUS     PvSts;   
   FLOAT32    Av;   
   STATUS     AvSts;      
   UINT32     AvRaw; 
   STATUS     AvRawSts;
   FLOAT32    Pl;
   STATUS     PlSts;
   UINT16     ResetCount;
} PVSCANREC1;

typedef struct tagPvScanRec2 {
   FLOAT32    Tv;   
   UINT32     TvRaw;      
   BOOL       TvProc;
   BOOL       So;
   BOOL       BadSo;
} PVSCANREC2;
#pragma unpack 

typedef struct tagSTRTVPROC {
   UINT8      TvProc7:1;
   UINT8      TvProc6:1;
   UINT8      TvProc5:1;
   UINT8      TvProc4:1;
   UINT8      TvProc3:1;
   UINT8      TvProc2:1;
   UINT8      TvProc1:1;
   UINT8      TvProc0:1;
} STRTVPROC;

typedef enum tagFcoRdbkSts {
    FCORDBK_FAILED,
    FCORDBK_PASSED
} FCORDBKSTS;

/*******************************************************************************
*                                  clsPiBoxSlot                                *
*                                  ============                                *
*******************************************************************************/
class clsPiBoxSlot : public clsBoxSlot {
private:
    FLOAT64   dTv0;
    FLOAT64   dTv1;
    UINT16    usDPICR;
    UINT16    usIPR1;
    UINT16    usIPR2;
    UINT16    usITTCR;
    UINT16    usOCR;
    UINT16    usPMCR;
    UINT16    usPWRCR;
    UINT8     ucConfigProvSig;
    UINT8     ucActualProvSig;
    BOOL      MaintainOnFault;
    // !!!*** BOXSLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the box slot's redundant synch data area
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedBoxSize() must be updated to
    // reference the new end member. This dump record begins in clsBoxSlot.

#pragma pack 1
        PVSCANREC1   PvScanRec1[MAXSLOTS];
        PVSCANREC2   PvScanRec2[MAXSLOTS];
#pragma unpack 
    UINT8     ucGoodChannels;
    UINT8     ucTickCounter;
    BOOL      bDisableFO;
    STRTVPROC LastTvProc;
    static BOOL bPrototype;
    static BOOL Osc_Test_In_Progress;

    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const BOXPARAMINFO tblParamInfo[256];

    PASTATUS PreCheckPoint(UINT8 *,UINT8);   
    PASTATUS PreConfProvSig(UINT8 *,UINT8);
    VOID     PostConfProvSig(UINT8);
    PASTATUS PreMaintOnFault(UINT8 *,UINT8);
    VOID     PostMaintOnFault(UINT8);


    inline VOID *GetPvScanRec1Ptr(VOID){return PvScanRec1;}
    inline VOID *GetPvScanRec2Ptr(VOID){return PvScanRec2;}

    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[BoxChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams;}
    inline VOID *GetConfProvSigPtr(VOID){return &ucConfigProvSig;}
    inline VOID *GetActualProvSigPtr(VOID){ return &ucActualProvSig;}
    inline VOID *GetMaintOnFaultPtr(VOID){return &MaintainOnFault;}

    friend VOID *clsPiSlot::GetPvPtr(VOID);
    friend VOID *clsPiSlot::GetPvStsPtr(VOID);
    friend VOID *clsPiSlot::GetAvPtr(VOID);
    friend VOID *clsPiSlot::GetAvStsPtr(VOID);
    friend VOID *clsPiSlot::GetAvRawPtr(VOID);
    friend VOID *clsPiSlot::GetAvRawStsPtr(VOID);
    friend VOID *clsPiSlot::GetPlPtr(VOID);
    friend VOID *clsPiSlot::GetPlStsPtr(VOID);
    friend VOID *clsPiSlot::GetTvPtr(VOID);
    friend VOID *clsPiSlot::GetTvRawPtr(VOID);
    friend VOID *clsPiSlot::GetTvProcPtr(VOID);
    friend VOID *clsPiSlot::GetSoPtr(VOID);    
    friend VOID *clsPiSlot::GetBadSoPtr(VOID);

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);


    clsPiBoxSlot(const clsPiBoxSlot&); // Safeguard against default copy constr.
    clsPiBoxSlot& operator=(const clsPiBoxSlot&); // and default assignment.

public:
    clsPiBoxSlot(MODLTYPE);
    ~clsPiBoxSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,PIBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32) { return ucIomDbMemory; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,PIBOXSLOT_HPP,__LINE__); } 

    VOID AppInitialization(VOID);
    VOID AppStcProcessing(VOID);    
    static VOID FpgaInterruptHandler(VOID);

    // Diagnostics functions
    FCORDBKSTS FCODriverReadBackDiagnostic(UINT8 ucChan);

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       AppColdInit(VOID);
    BOOL       AppFOProcess(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);

    BOOL    SwitchInit(VOID);
    VOID    SetTestSwitch(BOOL);
    VOID    TestSwitchCheck(BOOL);
    BOOL    InhibitSwitchCheck(UINT8);
    VOID    InhibitSwitchDiagnostics(VOID);
    VOID    EnableSwitchCheck(BOOL);
    VOID    EnableSwitchDiagnostics(VOID);
    UINT8   InhibitSwitchStatus();
    VOID    SetForPrimary(VOID);
    VOID    SetForSecondary(BOOL);
    VOID    LoopbackDiagnostics(UINT8);
    VOID    CheckFailOverCondition(VOID);
    VOID    SetProverSignal(BOOL);

    VOID SetIntPeriod(UINT8 ucChanNum, FREQPERIOD a_ucIntPeriod);
    VOID EnableFCOFailFO(VOID) { SetSfActionBit(SF_FCO_DIAG_FAIL);}

    inline VOID ClrCounterTimer(UINT8 a_ucChanNum) {
        UINT16 uwbitMask = 0x0101 << (a_ucChanNum - 1);
        CCCR.FPGAWORDREG |= uwbitMask;
        CCCR.FPGAWORDREG &= ~uwbitMask;
        return;
    }

    inline VOID ClrTimer(UINT8 a_ucChanNum) {
        UINT16 uwbitMask = 0x0100 << (a_ucChanNum - 1);
        CCCR.FPGAWORDREG |= uwbitMask;
        CCCR.FPGAWORDREG &= ~uwbitMask;
        return;
    }

    inline UINT8 GetActualProverSignal(VOID) { 
        return ucActualProvSig;
    }
    
    inline FLOAT32 GetAv(UINT8 a_ucChanNum) { 
        return PvScanRec1[a_ucChanNum - 1].Av; 
    }
    
    inline STATUS GetAvSts(UINT8 a_ucChanNum) { 
        return PvScanRec1[a_ucChanNum - 1].AvSts; 
    }

    inline UINT32 GetAvRaw(UINT8 a_ucChanNum) {
        return PvScanRec1[a_ucChanNum-1].AvRaw;
    }

    inline STATUS GetAvRawSts(UINT8 a_ucChanNum) { 
        return PvScanRec1[a_ucChanNum - 1].AvRawSts; 
    }    

    inline BOOL GetBadSo(UINT8 a_ucChanNum){
        return PvScanRec2[a_ucChanNum - 1].BadSo;
    }    

    inline UINT32 GetCounter(UINT8 a_ucChanNum) {
        // See commonelectronics.h for details of the semaphore
        UINT16 usSem = 0x0001 << (2*(a_ucChanNum-1));
        UINT32 ulCount;
        CNTRSEMCR |= usSem;  // Set semaphore - counter can be read reliably 200ns later
        usSem <<= 1;         // This instruction plus the index setup for the read provides 292ns of wait time
        ulCount = fpgaCOUNTER[a_ucChanNum-1];
        CNTRSEMCR |= usSem;  // Clear semaphore
        return ulCount;
    }
    
    inline UINT32 GetFRC(UINT8 a_ucChanNum) { 
        return fpgaFRC[a_ucChanNum-1];
    }
    
    inline UINT8 GetGoodChannels(VOID) { 
        return ucGoodChannels; 
    }

    inline BOOL GetLastTvProc(UINT8 a_ucChanNum){
        BOOL retValue = OFF;
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            retValue = (BOOL)LastTvProc.TvProc6;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            retValue = (BOOL)LastTvProc.TvProc7;
        }
        return retValue;
    }

    inline BOOL GetMainOnFault(VOID) { 
        return MaintainOnFault; 
    }

    inline BOOL GetOutSet(UINT8 a_ucChanNum){
        BOOL retValue;
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            retValue = OUT_SET0;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            retValue = OUT_SET1;
        }
        return retValue;
    }

    inline STATUS GetPlSts(UINT8 a_ucChanNum) { 
        return PvScanRec1[a_ucChanNum - 1].PlSts; 
    }

    inline FLOAT32 GetPv(UINT8 a_ucChanNum) { 
        return PvScanRec1[a_ucChanNum - 1].Pv; 
    }

    inline UINT32 GetPvCounter(UINT8 a_ucChanNum) { 
        return fpgaPV_COUNTER[a_ucChanNum-1];
    }

    inline STATUS GetPvSts(UINT8 a_ucChanNum) { 
        return PvScanRec1[a_ucChanNum - 1].PvSts; 
    }

    inline UINT32 GetRedBoxDelta(VOID) {return 0;}
    inline UINT32 GetRedBoxSize(VOID) {
        return ((UINT32)((UINT8 *)&MaintainOnFault - (UINT8 *)&ModStat1) + sizeof(MaintainOnFault));
    }
        
    inline UINT8 *GetRedBoxPointer(VOID) {
        return (UINT8 *)&ModStat1;
    }

    inline BOOL GetSafeOut(UINT8 a_ucChanNum){
        BOOL retValue = OFF;
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            retValue = OUT_SEN0;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            retValue = OUT_SEN1;
        }
        return retValue;
    }

    inline BOOL GetSo(UINT8 a_ucChanNum){
        BOOL retValue = OFF;
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            retValue = STATUSOUT0;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            retValue = STATUSOUT1;
        }
        return retValue;
    }

    inline UINT32 GetTimer(UINT8 a_ucChanNum) { 
        return fpgaTIMER[a_ucChanNum-1];
    }

    inline FLOAT32 GetTv(UINT8 a_ucChanNum){
        return PvScanRec2[a_ucChanNum - 1].Tv;
    }

    inline BOOL GetTvProc(UINT8 a_ucChanNum){
        BOOL retValue = OFF;
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            retValue = COMPARING0;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            retValue = COMPARING1;
        }
        return retValue;
    }

    inline UINT32 GetTvRaw(UINT8 a_ucChanNum){
        UINT32 retValue = 0;
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            retValue = OTR0;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            retValue = OTR1;
        }
        return retValue;
    }

    inline FLOAT64 GetTvSync(UINT8 a_ucChanNum){
        FLOAT64 retValue;
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            retValue = dTv0;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            retValue = dTv1;
        }
        return retValue;
    }

    inline VOID IncrementResetCount(UINT8 a_ucChanNum) { 
        PvScanRec1[a_ucChanNum - 1].ResetCount++;
        if (0xFFFF == PvScanRec1[a_ucChanNum - 1].ResetCount){
            PvScanRec1[a_ucChanNum - 1].ResetCount++;
        }     
    }

    inline VOID InitializePvScanRec(UINT8 a_ucChanNum){
        // PvScanRec1
        PvScanRec1[a_ucChanNum - 1].Pv          = 0.0;
        PvScanRec1[a_ucChanNum - 1].PvSts       = STATUS_BAD;   
        PvScanRec1[a_ucChanNum - 1].Av          = 0.0;   
        PvScanRec1[a_ucChanNum - 1].AvSts       = STATUS_BAD;      
        PvScanRec1[a_ucChanNum - 1].AvRaw       = 0; 
        PvScanRec1[a_ucChanNum - 1].AvRawSts    = STATUS_BAD;
        PvScanRec1[a_ucChanNum - 1].Pl          = 0.0;
        PvScanRec1[a_ucChanNum - 1].PlSts       = STATUS_BAD;
        PvScanRec1[a_ucChanNum - 1].ResetCount  = 0;

        // PvScanRec2
        PvScanRec2[a_ucChanNum - 1].Tv          = 0.0;   
        PvScanRec2[a_ucChanNum - 1].TvRaw       = 0;      
        PvScanRec2[a_ucChanNum - 1].TvProc      = OFF;
        PvScanRec2[a_ucChanNum - 1].So          = OFF;
        PvScanRec2[a_ucChanNum - 1].BadSo       = OFF;;
    }

    inline VOID SetChannelType(UINT8 a_ucChanNum,INPUTSTREAM a_InputStream){
        if(a_InputStream == SINGLE_PULSE){
           CHANNEL_TYPE &= ~(0x01 << (a_ucChanNum-1)); // Clear bit
        }
        else{                                          // Dual Pulse
           CHANNEL_TYPE |= (0x01 << (a_ucChanNum-1));  // Set bit
           ClrCounterTimer(ChanNum+1);                 // Clear partner counter
        }
        usDPICR = DPICR.FPGAWORDREG; // Update PFGA Sync Parameter
    }

    inline VOID SetCounter(UINT8 a_ucChanNum, UINT32 a_ulRawCount){
        fpgaCTR_UPDATE[a_ucChanNum-1] = a_ulRawCount;
        COUNT_UPDATE_FLAGS = 0x01 << (a_ucChanNum-1);
        COUNT_UPDATE_FLAGS = 0;
    }

    inline VOID SetEdgeDetect(UINT8 a_ucChanNum, EDGEDETECT a_EdgeDetect){
        usITTCR = ITTCR.FPGAWORDREG;
        if(a_EdgeDetect == RISINGEDGE)
            usITTCR |= (0x0100 << (a_ucChanNum-1));   // Set the bit
        else
            usITTCR &= ~(0x0100 << (a_ucChanNum-1));  // Clear the bit     
        ITTCR.FPGAWORDREG = usITTCR;
    }

    inline VOID SetForceSafe(BOOL a_bOnOff){
        SAFE_STATE_n = a_bOnOff;
        usOCR = OCR.FPGAWORDREG; // Update FPGA Sync parameter
    }

    inline VOID SetLastTvProc(UINT8 a_ucChanNum,BOOL a_TvProc){
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            LastTvProc.TvProc6 = a_TvProc;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            LastTvProc.TvProc7 = a_TvProc;
        }
    }

    inline VOID SetPulseMode(UINT8 a_ucChanNum,PULSEMODE a_PulseMode){
        usPMCR = PMCR.FPGAWORDREG;
        if(a_PulseMode == PERIOD){
            usPMCR &= ~(0x0101 << (a_ucChanNum-1)); // Clear both bits
        }
        else if(a_PulseMode == PULSE_HIGH){
            usPMCR |= (0x0101 << (a_ucChanNum-1)); // Set both bits
        }
        else{
            usPMCR |=  (0x0001 << (a_ucChanNum-1)); // Set pulse period select bit
            usPMCR &= ~(0x0100 << (a_ucChanNum-1)); // Clear pulse midth select bit
        }
        PMCR.FPGAWORDREG = usPMCR;
    }

    inline VOID SetPwReject(UINT8 a_ucChanNum,BOOL a_EnPulseWidthRej){
        if(a_EnPulseWidthRej == ON)    
           PW_REJECTION |= (0x01<<(a_ucChanNum-1));
        else
           PW_REJECTION &= ~(0x01<<(a_ucChanNum-1));        
        usPWRCR = PWRCR.FPGAWORDREG; // Update FPGA Sync parameter
    }

    inline VOID SetSafeOut(UINT8 a_ucChanNum,BOOL a_bSafeOut){
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            OUT_SEN0 = a_bSafeOut;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            OUT_SEN1 = a_bSafeOut;
        }
        usOCR = OCR.FPGAWORDREG; // Update FPGA Sync parameter
    }

    inline VOID SetSo(UINT8 a_ucChanNum,BOOL a_ucSo){
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            OUT_CTRL0 = 1;
            OUT_SET0 = a_ucSo;
            OUT_CTRL0 = 0;
            StoreSo(a_ucChanNum, STATUSOUT0);
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            OUT_CTRL1= 1;
            OUT_SET1 = a_ucSo;
            OUT_CTRL1= 0;
            StoreSo(a_ucChanNum, STATUSOUT1);
        }
        usOCR = OCR.FPGAWORDREG; // Update FPGA Sync parameter
    }

    inline VOID SetTvRaw(UINT8 a_ucChanNum){
        UINT32 ulTvRaw;
        // write it to and then read it back from the FPGA and then store it
        if (a_ucChanNum == FASTCUTOFF_CHN0){
            ulTvRaw = (UINT32) (FLOAT64)(SLOT(a_ucChanNum)->GetC2()) / (FLOAT64)(SLOT(a_ucChanNum)->GetC1()) * GetTvSync(a_ucChanNum);
            OTR0 = ulTvRaw;
            StoreTvRaw(a_ucChanNum, OTR0);
            StoreTvProc(a_ucChanNum, GetTvProc(a_ucChanNum));
        }
        else if (a_ucChanNum == FASTCUTOFF_CHN1){
            ulTvRaw = (UINT32) (FLOAT64)(SLOT(a_ucChanNum)->GetC2()) / (FLOAT64)(SLOT(a_ucChanNum)->GetC1()) * GetTvSync(a_ucChanNum);
            OTR1 = ulTvRaw;
            StoreTvRaw(a_ucChanNum, OTR1);
            StoreTvProc(a_ucChanNum, GetTvProc(a_ucChanNum));
        }
    }

    inline VOID SetVoltage(UINT8 a_ucChanNum,VOLTAGE a_Voltage){
        usITTCR = ITTCR.FPGAWORDREG;
        if(a_Voltage == VOLTAGE_HIGH)
            usITTCR |= (0x0001 << (a_ucChanNum-1));   // Set the bit
        else
            usITTCR &= ~(0x0001 << (a_ucChanNum-1));  // Clear the bit 
        ITTCR.FPGAWORDREG = usITTCR;
    }

    inline VOID StoreAv(UINT8 a_ucChanNum,FLOAT32 a_fAv) {
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    // disable IOL interrupts
        PvScanRec1[a_ucChanNum - 1].Av = a_fAv;
        set_imask_exr(ucSaveExr);         // re-enable IOL interrupts
    }
    
    inline VOID StoreAvSts(UINT8 a_ucChanNum, STATUS a_AvSts) { 
        PvScanRec1[a_ucChanNum - 1].AvSts = a_AvSts;
    }   
    
    inline VOID StoreAvRaw(UINT8 a_ucChanNum,UINT32 a_ulAvRaw) {
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    //disable IOL interrupts
        PvScanRec1[a_ucChanNum - 1].AvRaw= a_ulAvRaw;
        set_imask_exr(ucSaveExr);         // re-enable IOL interrupts
    }
    
    inline VOID StoreAvRawSts(UINT8 a_ucChanNum,STATUS a_AvRawSts) { 
        PvScanRec1[a_ucChanNum - 1].AvRawSts = a_AvRawSts;
    }

    inline VOID StoreBadSo(UINT8 a_ucChanNum,UINT8 a_ucBadSo){
        PvScanRec2[a_ucChanNum - 1].BadSo = a_ucBadSo;
    }

    inline VOID StorePl(UINT8 a_ucChanNum,FLOAT32 a_Pl) { 
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    //disable IOL interrupts
        PvScanRec1[a_ucChanNum - 1].Pl = a_Pl;
        set_imask_exr(ucSaveExr);         // re-enable IOL interrupts
    }

    inline VOID StorePlSts(UINT8 a_ucChanNum,STATUS a_PlSts) { 
        PvScanRec1[a_ucChanNum - 1].PlSts = a_PlSts;
    }

    inline VOID StorePv(UINT8 a_ucChanNum, FLOAT32 a_fPv){
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    //disable IOL interrupts
        PvScanRec1[a_ucChanNum - 1].Pv = a_fPv;
        set_imask_exr(ucSaveExr);         // re-enable IOL interrupts
    }

    inline VOID StorePvSts(UINT8 a_ucChanNum,STATUS a_PvSts){
        PvScanRec1[a_ucChanNum - 1].PvSts = a_PvSts;
        SLOT(a_ucChanNum)->UpdateBadPvFl(a_PvSts == STATUS_BAD);
    }

    inline VOID StoreResetCount(UINT8 a_ucChanNum,UINT16 a_ResetCount) { 
        PvScanRec1[a_ucChanNum - 1].ResetCount = a_ResetCount;
    }

    inline VOID StoreSo(UINT8 a_ucChanNum,BOOL a_ucSo){
       PvScanRec2[a_ucChanNum -1].So= a_ucSo;
    }

    inline VOID StoreTv(UINT8 a_ucChanNum,FLOAT32 a_fTv){
       UINT8 ucSaveExr = get_imask_exr();
       set_imask_exr(LVLPRI_HIGHEST);    //disable IOL interrupts
       PvScanRec2[a_ucChanNum - 1].Tv = a_fTv;
       set_imask_exr(ucSaveExr);         // re-enable IOL interrupts
    }

    inline VOID StoreTvProc(UINT8 a_ucChanNum,BOOL a_ucTvProc){
       PvScanRec2[a_ucChanNum - 1].TvProc = a_ucTvProc;
    }

    inline VOID StoreTvRaw(UINT8 a_ucChanNum,UINT32 a_ulTvRaw){
       UINT8 ucSaveExr = get_imask_exr();
       set_imask_exr(LVLPRI_HIGHEST);   //disable IOL interrupts
       PvScanRec2[a_ucChanNum - 1].TvRaw = a_ulTvRaw;
       set_imask_exr(ucSaveExr);        // re-enable IOL interrupts
    }

    inline VOID StoreTvSync(UINT8 a_ucChanNum,FLOAT64 a_dTv){
       if(a_ucChanNum == FASTCUTOFF_CHN0){
           dTv0 = a_dTv;
       }
       else if(a_ucChanNum == FASTCUTOFF_CHN1){
           dTv1 = a_dTv;
       }
    }

    inline VOID SyncFPGA(VOID){
        DPICR.FPGAWORDREG = usDPICR;      // Prover Selects, Channel Types
        ITTCR.FPGAWORDREG = usITTCR;      // Edge Detects, Voltage Thresholds
        PMCR.FPGAWORDREG = usPMCR;        // Pulse counting Modes
        IP_VALID_FLAGS = 0;
        IPR1.FPGAWORDREG = usIPR1;        // Integration Periods
        IPR2.FPGAWORDREG = usIPR2;
        IP_VALID_FLAGS = 0xFF;
        SAFE_STATE_n = FORCEDSAFE_OFF;     // Force Safe Out to OFF
        OUT_SEN0 = (BOOL)(usOCR & 0x0001); // SafeOutput cn 7
        OUT_CTRL0 = 1;
        OUT_SET0 = (BOOL)(usOCR & 0x0002); // Status Output cn 7
        OUT_CTRL0 = 0;
        OUT_SEN1 = (BOOL)(usOCR & 0x0010); // SafeOutput cn 8
        OUT_CTRL1 = 1;
        OUT_SET1 = (BOOL)(usOCR & 0x0020); // Status Output cn 8
        OUT_CTRL1 = 0;
        SAFE_STATE_n = (BOOL)(usOCR & 0x0080); // Force Safe Out
        PWRCR.LOBYTE = (UINT8)usPWRCR;    // Pulse Width Rejects
        SLOT(FASTCUTOFF_CHN0)->StoreTv64(dTv0);    // Target values
        StoreTv(FASTCUTOFF_CHN0,(FLOAT32)dTv0);
        SLOT(FASTCUTOFF_CHN1)->StoreTv64(dTv1);
        StoreTv(FASTCUTOFF_CHN1,(FLOAT32)dTv1);
    }

    inline VOID SyncSo(UINT8 a_ucChanNum){
        if(a_ucChanNum == FASTCUTOFF_CHN0){
            OUT_CTRL0 = 1;
            OUT_SET0 = (BOOL)(usOCR & 0x0002); // Status Output cn 7
            OUT_CTRL0 = 0;
        }
        else if(a_ucChanNum == FASTCUTOFF_CHN1){
            OUT_CTRL1 = 1;
            OUT_SET1 = (BOOL)(usOCR & 0x0020); // Status Output cn 8
            OUT_CTRL1 = 0;
        }
}
};

#endif
