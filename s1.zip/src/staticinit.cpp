/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2010                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : staticinit.cpp                                              *
*    Description : Initialization of static variables common across  IOLINK    *
*                  Processor and Application Processor                         *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_SP
#include "spmain.h"
#endif
#ifdef IOMTYPE_SVP
#include "svpmain.h"
#endif
/*******************************************************************************
*                                 STATIC DATA                                  *
*******************************************************************************/

#ifdef IOMTYPE_SP

/*******************************************************************************
*                                 SP BOX                                       *
*******************************************************************************/
const UINT8 LATEST_BOXCHKPNT_VERSION = 1;
const UINT8 clsSpBoxSlot::CheckPointVer1[] = {
    kSiomBoxChkPntVer,
    kSiomSpPnRevRotChnlA,
    kSiomSpPnRevRotChnlB,
    kSiomPnResetTrip,
    kSiomPnDBVALID,
    kSiomPnModStat1,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsSpBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsSpBoxSlot::SpBoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
#ifdef H8S
const UINT16 SPIOM_SYNC_VER_1 = 0x01;
#endif
/*******************************************************************************
*                                 AI CHANNEL                                   *
*******************************************************************************/                                                                                                                                                                
#ifdef H8S
const UINT16 SPAI_SYNC_VER_1 = 0x01;
#endif
const UINT8 LATEST_SP_AI_SLTCHKPNT_VERSION = 1;

/*******************************************************************************
*                                 AO CHANNEL                                   *
*******************************************************************************/                                                                                                                                                                
#ifdef H8S
const UINT16 SPAO_SYNC_VER_1 = 0x01;
#endif
const UINT8 LATEST_SP_AO_SLTCHKPNT_VERSION = 1;
/*******************************************************************************
*                                 DI CHANNEL                                   *
*******************************************************************************/
const UINT8 LATEST_SP_DI_SLTCHKPNT_VERSION = 1;
const UINT8 clsDiSlot::CheckPointVer1[] = {
    kDiPnChkPntVer,
    kDiPnPntType,
    kDiPnDiType,
    kDiPnInptDir,
    kDiPnPvSrcOpt,
    kDiPnPvSource,
    kDiPnOwdEnbl,
    kDiPnPtExecSt,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsDiSlot::CheckPointVerTable[LATEST_SP_DI_SLTCHKPNT_VERSION] = {
    { CheckPointVer1,  sizeof(CheckPointVer1) }
};

UINT8 clsDiSlot::SpDiSlotChkpntVersion = LATEST_SP_DI_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT16 SPDI_SYNC_VER_1 = 0x01;
#endif
/*******************************************************************************
*                                 DO CHANNEL                                   *
*******************************************************************************/
const UINT8 LATEST_SP_DO_SLTCHKPNT_VERSION = 1;
const UINT8  clsDoSlot::CheckPointVer1[] = {
    kSpDoPnChkPntVer,
    kSpDoPnPntType,
    kSpDoPnDoType,
    kSpDoPnPeriod,
    kSpDoPnModePerm,
    kSpDoPnNMode,
    kSpDoPnNModeAttr,
    kSpDoPnMode,
    kSpDoPnModeAttr,
    kSpDoPnFaultOpt,
    kSpDoPnFaultValue,
    kSpDoPnRedTag,
    kSpDoPnI1Conn,
    kSpDoPnI2Conn,
    kSpDoPnI3Conn,
    kSpDoPnI4Conn,
    kSpDoPnI5Conn,
    kSpDoPnI6Conn,
    kSpDoPnI7Conn,
    kSpDoPnI8Conn,
    kSpDoPnI1InptDir,
    kSpDoPnI2InptDir,
    kSpDoPnI3InptDir,
    kSpDoPnI4InptDir,
    kSpDoPnI5InptDir,
    kSpDoPnI6InptDir,
    kSpDoPnI7InptDir,
    kSpDoPnI8InptDir,
    kSpDoPnPtExecSt,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsDoSlot::CheckPointVerTable[LATEST_SP_DO_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsDoSlot::SpDoSlotChkpntVersion = LATEST_SP_DO_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT16 SPDO_SYNC_VER_1 = 0x01;
#endif
/*******************************************************************************
*                                 SPEED CHANNEL                                *
*******************************************************************************/
const UINT8 LATEST_SP_SPEED_SLTCHKPNT_VERSION = 1;
const UINT8  clsSpSlot::CheckPointVer1[] = {
    kSpSpdPnChkPntVer,
    kSpSpdPnPntType,
    kSpSpdPnSensrType,
    kSpSpdPnTeethCnt,
    kSpSpdPnGearRatio,
    kSpSpdPnEdgDetect,
    kSpSpdPnPvClamp,
    kSpSpdPnPvSrcOpt,
    kSpSpdPnPvSource,
    kSpSpdPnPvhiAlm_Tp,    
    kSpSpdPnPvHhAlm_Tp,    
    kSpSpdPnRocPosHiAlm_Tp,
    kSpSpdPnRocPosHhAlm_Tp,
    kSpSpdPnCrSpeed,
    kSpSpdPnNmSpeed,
    kSpSpdPnFilterTime,
    kSpSpdPnPtExecSt,
    kSpSpdMeasurementType,  
    kSpSpdOrdrerOfKFactor,  
    kSpSpdFirstOrderKFactor,
    kSpSpdMinFlowRate,      
    kSpSpdKMinFlowRate,     
    kSpSpdMaxFlowRate,      
    kSpSpdKMaxFlowRate,
    kSpSpdTimeUnit,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsSpSlot::CheckPointVerTable[LATEST_SP_SPEED_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsSpSlot::SpSpeedSlotChkpntVersion = LATEST_SP_SPEED_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT16 SPEED_SYNC_VER_1 = 0x01;
#endif
/*******************************************************************************
*                                 VOTING BLOCK                                 *
*******************************************************************************/
const UINT8 LATEST_SP_SPDVOTE_SLTCHKPNT_VERSION = 1;
const UINT8  clsVotLogicSlot::CheckPointVer1[] = {
    kSpSpdVotPnChkPntVer,
    kSpSpdVotPnPntType,
    kSpSpdVotPnVotAlgGrp1,    
    kSpSpdVotPnVotAlgGrp2,
    kSpSpdVotPnVotPv1hiAlm_Tp,
    kSpSpdVotPnVotPv1HhAlm_Tp,
    kSpSpdVotPnVotRoc1PosHiAlm_Tp,    
    kSpSpdVotPnVotRoc1PosHhAlm_Tp,
    kSpSpdVotPnVotRoc1NegHiAlm_Tp,
    kSpSpdVotPnVotPv2hiAlm_Tp,
    kSpSpdVotPnVotPv2HhAlm_Tp,
    kSpSpdVotPnVotRoc2PosHiAlm_Tp,
    kSpSpdVotPnVotRoc2PosHhAlm_Tp,
    kSpSpdVotPnVotRoc2NegHiAlm_Tp,
    kSpSpdVotPnMedOpt1,
    kSpSpdVotPnMedOpt2,
    kSpSpdVotPnGrp1NMin,
    kSpSpdVotPnGRP2NMin,
    kSpSpdVotPnPv1Conn,
    kSpSpdVotPnPv2Conn,
    kSpSpdVotPnPv3Conn,
    kSpSpdVotPnPv4Conn,
    kSpSpdVotPnVotPv1OvrtStEnb,
    kSpSpdVotPnVotPv2OvrtStEnb,
    kSpSpdVotPnGrp1VotChnbBlind,
    kSpSpdVotPnGrp2VotChnbBlind,
    kSpSpdVotPnPtExecSt,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsVotLogicSlot::CheckPointVerTable[LATEST_SP_SPDVOTE_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsVotLogicSlot::SpSpdVoteSlotChkpntVersion = LATEST_SP_SPDVOTE_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT8 SPDVOTE_SYNCREC_VER_1  = 0x01;
#endif
#endif //#ifdef IOMTYPE_SP

#ifdef IOMTYPE_SVP

/*******************************************************************************
*                                 SVP BOX                                      *
*******************************************************************************/
const UINT8 LATEST_BOXCHKPNT_VERSION = 1;
const UINT8 clsSvpBoxSlot::CheckPointVer1[] = {
    kSiomBoxChkPntVer,
    kSiomSvpPnExcitFreq,
    kSiomPnDBVALID,
    kSiomPnModStat1,
    kSiomSvpPnServoDriveOption,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsSvpBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsSvpBoxSlot::SvpBoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
#ifdef H8S
const UINT16 SVPIOM_SYNC_VER_1 = 0x01;
#endif
/*******************************************************************************
*                                 AI CHANNEL                                   *
*******************************************************************************/
const UINT8 LATEST_SVP_AI_SLTCHKPNT_VERSION = 1;
const UINT8  clsAiLvdtSlot::CheckPointVer1[] = {
    kSvpAiPnChkPntVer,
    kSvpAiPnPntType,
    kSvpAiPnSensrTyp,
    kSvpAiPnPvChar,
    kSvpAiPnInptDir,
    kSvpAiPnPvExEUHi,
    kSvpAiPnPvEUHi,
    kSvpAiPnPvEULo,
    kSvpAiPnPvExEULo,
    kSvpAiPnPvClamp,
    kSvpAiPnLoCutoff,
    kSvpAiPnTf,
    kSvpAiPnPvTv,
    kSvpAiPnPvSrcOpt,
    kSvpAiPnPvSource,
    kSvpAiPnOwdEnbl,
    kSvpAiPnTxWireSel,
    kSvpAiPnVdtMode,
    kSvpAiPnExVol,      
    kSvpAiPnPtExecSt,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsAiLvdtSlot::CheckPointVerTable[LATEST_SVP_AI_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsAiLvdtSlot::SvpAiSlotChkpntVersion = LATEST_SVP_AI_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT16 SVPAI_SYNC_VER_1 = 0x01;
#endif
/*******************************************************************************
*                                 AO CHANNEL                                   *
*******************************************************************************/
const UINT8 LATEST_SVP_AO_SLTCHKPNT_VERSION = 2;
const UINT8  clsAoServoSlot::CheckPointVer1[] = {
    kSvpAoPnChkPntVer,
    kSvpAoPnPntType,
    kSvpAoPnOpAction,
    kSvpAoPnOptType,
    kSvpAoPnOpHiCurrent,
    kSvpAoPnOpLoCurrent,   
    kSvpAoPnOptDir,
    kSvpAoPnOpChar,
    kSvpAoPnOpIn1,
    kSvpAoPnOpOut1,
    kSvpAoPnOpIn2,
    kSvpAoPnOpOut2,
    kSvpAoPnOpIn3,
    kSvpAoPnOpOut3,
    kSvpAoPnOpIn4,
    kSvpAoPnOpOut4,
    kSvpAoPnModePerm,
    kSvpAoPnNMode,
    kSvpAoPnNModeAttr,
    kSvpAoPnMode,
    kSvpAoPnModeAttr,
    kSvpAoPnFaultOpt,
    kSvpAoPnFaultValue,
    kSvpAoPnRedTag,
    kSvpAoPnDitherFreq,
    kSvpAoPnDitherAmpl,
    kSvpAoPnInLckFlOpt1,
    kSvpAoPnInSelPrcIntLck1,
    kSvpAoPnPrcSafeOp1,
    kSvpAoPnInLckFlOpt2,
    kSvpAoPnInSelPrcIntLck2,
    kSvpAoPnPrcSafeOp2,
    kSvpAoPnOpBiasCurrent,
    kSvpAoPnOpConn,
    kSvpAoSecDiagEnb,
    kSvpAoSecDiagCurr,
    kSvpAoPnPtExecSt,
    0 // Terminator
};

const UINT8  clsAoServoSlot::CheckPointVer2[] = {
    kSvpAoPnChkPntVer,
    kSvpAoPnPntType,
    kSvpAoPnOpAction,
    kSvpAoPnOptType,
    kSvpAoPnOpHiCurrent,
    kSvpAoPnOpLoCurrent,   
    kSvpAoPnOptDir,
    kSvpAoPnOpChar,
    kSvpAoPnOpIn1,
    kSvpAoPnOpOut1,
    kSvpAoPnOpIn2,
    kSvpAoPnOpOut2,
    kSvpAoPnOpIn3,
    kSvpAoPnOpOut3,
    kSvpAoPnOpIn4,
    kSvpAoPnOpOut4,
    kSvpAoPnModePerm,
    kSvpAoPnNMode,
    kSvpAoPnNModeAttr,
    kSvpAoPnMode,
    kSvpAoPnModeAttr,
    kSvpAoPnFaultOpt,
    kSvpAoPnFaultValue,
    kSvpAoPnRedTag,
    kSvpAoPnDitherFreq,
    kSvpAoPnDitherAmpl,
    kSvpAoPnInLckFlOpt1,
    kSvpAoPnInSelPrcIntLck1,
    kSvpAoPnPrcSafeOp1,
    kSvpAoPnInLckFlOpt2,
    kSvpAoPnInSelPrcIntLck2,
    kSvpAoPnPrcSafeOp2,
    kSvpAoPnOpBiasCurrent,
    kSvpAoPnOpConn,
    kSvpAoSecDiagEnb,
    kSvpAoSecDiagCurr,
    kSvpAoPnPtExecSt,
    kSvpAoDitherWaveform,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsAoServoSlot::CheckPointVerTable[LATEST_SVP_AO_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 91 },
    { CheckPointVer2, 92 }
};

UINT8 clsAoServoSlot::SvpAoSlotChkpntVersion = LATEST_SVP_AO_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT16 SVPAO_SYNC_VER_1 = 0x01;
const UINT16 SVPAO_SYNC_VER_2 = 0x02;
#endif
/*******************************************************************************
*                                 DI CHANNEL                                   *
*******************************************************************************/
const UINT8 LATEST_SVP_DI_SLTCHKPNT_VERSION = 1;
const UINT8 clsDiSlot::CheckPointVer1[] = {
    kDiPnChkPntVer,
    kDiPnPntType,
    kDiPnDiType,
    kDiPnInptDir,
    kDiPnPvSrcOpt,
    kDiPnPvSource,
    kDiPnOwdEnbl,
    kDiPnPtExecSt,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsDiSlot::CheckPointVerTable[LATEST_SVP_DI_SLTCHKPNT_VERSION] = {
    { CheckPointVer1,  sizeof(CheckPointVer1) }
};

UINT8 clsDiSlot::SvpDiSlotChkpntVersion = LATEST_SVP_DI_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT16 SVPDI_SYNC_VER_1 = 0x01;
#endif
/*******************************************************************************
*                                 REGCTL CHANNEL                               *
*******************************************************************************/
const UINT8 LATEST_SVP_REGCTL_SLTCHKPNT_VERSION = 1;
const UINT8  clsSvpRegCtlSlot::CheckPointVer1[] = {
   kSvpRegCtlPnChkPntVer,
   kSvpRegCtlPnPntType,
   kSvpRegCtlPnPrefPv,
   kSvpRegCtlPnPvEUHi,
   kSvpRegCtlPnPvEULo,
   kSvpRegCtlPnNormMode,
   kSvpRegCtlPnNormModeAttr,
   kSvpRegCtlPnModePerm,
   kSvpRegCtlPnMode,
   kSvpRegCtlPnModeAttr,
   kSvpRegCtlPnBadCtlOpt,
   kSvpRegCtlPnCtlActn,
   kSvpRegCtlPnCtlEqn,
   kSvpRegCtlPnRedTag,
   kSvpRegCtlPnT1HiLm,
   kSvpRegCtlPnT1LoLm,
   kSvpRegCtlPnT1,
   kSvpRegCtlPnT2HiLm,
   kSvpRegCtlPnT2LoLm,
   kSvpRegCtlPnT2,
   kSvpRegCtlPnGainOpt,
   kSvpRegCtlPnGainHiLm,
   kSvpRegCtlPnGainLoLm,
   kSvpRegCtlPnK,
   kSvpRegCtlPnEqnEUnitsOpt,
   kSvpRegCtlPnSpHiLm,
   kSvpRegCtlPnSpLoLm,
   kSvpRegCtlPnTmOutMode,
   kSvpRegCtlPnTmOutTime,
   kSvpRegCtlPnSpTol,
   kSvpRegCtlPnOpExHiLm,
   kSvpRegCtlPnOpExLoLm,
   kSvpRegCtlPnOpHiLm,
   kSvpRegCtlPnOpMinChg,
   kSvpRegCtlPnOpLoLm,
   kSvpRegCtlPnCvEUHi,
   kSvpRegCtlPnCvEULo,
   kSvpRegCtlPnOpBias_Fix,
   kSvpRegCtlPnOpBias_Rate,
   kSvpRegCtlPnOpTol,
   kSvpRegCtlPnPv1Conn,
   kSvpRegCtlPnPv2Conn, 
   kSvpRegCtlPnPtExecSt,
   0 // Terminator
};

const CHECKPOINT_VER_TABLE clsSvpRegCtlSlot::CheckPointVerTable[LATEST_SVP_REGCTL_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsSvpRegCtlSlot::SvpRegCtlSlotChkpntVersion = LATEST_SVP_REGCTL_SLTCHKPNT_VERSION;
#ifdef H8S
const UINT16 SVPREGCTL_SYNC_VER_1 = 0x01;
#endif
#endif //#ifdef IOMTYPE_SVP




































































































































