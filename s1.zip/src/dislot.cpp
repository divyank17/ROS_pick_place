/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : dislot.cpp                                                  *
*    Description : Class clsDiSlot definition.                                 *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "dislot.hpp"

#if defined (IOMTYPE_UIO)
    #include "uioboxslot.hpp"
#else
    #include "diboxslot.hpp"
#endif

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/

// IOL Parameter number definitions

#if defined(IOMTYPE_UIO)
#define PARAMID_DITYPE      60
#define PARAMID_INPTDIR     64
#define PARAMID_PNTTYPE     70
#define PARAMID_PTEXECST    71
#define PARAMID_PVSOURCE    78
#define PARAMID_PVSRCOPT    79
#define PARAMID_SLTCHKPNT   87
#define PARAMID_C1          114
#define PARAMID_C2          115
#define PARAMID_SLTCHKPNTVER    244

// Slot checkpoint version
#define LATEST_SLTCHKPNT_VERSION LATEST_UIO_DI_SLTCHKPNT_VERSION

// Resolve conflict between AI and DI slot GetPv() by redefining DI version
#define GetPv(ch) GetDiPv(ch)
#endif

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8  clsDiSlot::CheckPointVer1[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_DITYPE,
    PARAMID_INPTDIR,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_OWDENABLE,
    PARAMID_PTEXECST,
#ifdef IOMTYPE_DISOE
    PARAMID_EVTOPT,
    PARAMID_DEBOUNCE,
    PARAMID_PVCHGDLY,
#endif
    0 // Terminator
};

#if defined(IOMTYPE_UIO)
const UINT8  clsDiSlot::CheckPointVer2[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_DITYPE,
    PARAMID_INPTDIR,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_OWDENABLE,
    PARAMID_PTEXECST,
    PARAMID_C1,
    PARAMID_C2,
    0 // Terminator
};
#endif

#ifdef IOMTYPE_DISOE
const CHECKPOINT_VER_TABLE clsDiSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 11 }
};
#elif defined(IOMTYPE_UIO)
const CHECKPOINT_VER_TABLE clsDiSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 8 },
    { CheckPointVer2, 16 }
};
#else // DI

#if !defined(IOPTYPE_DI)

const CHECKPOINT_VER_TABLE clsDiSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 8 }
};

#else

const UINT8 clsDiSlot::CheckPointVer2[] = {
    PARAMID_PNTTYPE,
    PARAMID_PNTFORM,
    PARAMID_DITYPE,
    PARAMID_INPTDIR,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_EVTOPT,
    PARAMID_ALMOPT,
    PARAMID_DLYTIME,
    PARAMID_CONTCUT,
    PARAMID_PVNORMAL,
    PARAMID_AVTV,
    PARAMID_COUNTDWN,
    PARAMID_RESETVAL,
    PARAMID_PTEXECST,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsDiSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 8  },
    { CheckPointVer2, 18 }
};

BOOL bOldStartFl;
BOOL bOldStopFl;
BOOL bOldResetFl;

#define CHKPT_IOPDI 18

// PMIO HLAI BOX DUMP PARAM
const UINT8  clsDiSlot::PmioDumpParamTbl[] = {
    PARAMID_PTEXECST,         // 71 size 1
    PARAMID_PTEXECST_LRS,     //? 247 size 1 2
    PARAMID_PNTFORM,          // 69 size 1 3
    PARAMID_PNTTYPE,          // 70 size 1 4
    PARAMID_CONTCUT,          // 58 size 1 5
    PARAMID_INPTDIR,          // 64 size 1 6
    PARAMID_DITYPE,           // 60 size 1 7
    PARAMID_PVSOURCE,         // 78 size 1 8
    PARAMID_PVSRCOPT,         // 79 size 1 9
    PARAMID_EVTOPT,           // 62 size 1 10
    PARAMID_ALMOPT,           // 51 size 1 11
    PARAMID_PVNORMAL,         // 75 size 1 12
    PARAMID_PVNORMFL,         // 76 size 1 13
    PARAMID_LASTAV,           // 98 size 2 15
    PARAMID_AVTV,             // 54 size 2 17
    PARAMID_DLYTIME,          // 61 size 2 19
    PARAMID_OFFNRMFL,         // 65 size 1 20
    PARAMID_AVTVFL,           // 56 size 1 21
    PARAMID_COUNTDWN,         // 59 size 1 22
    PARAMID_COMMAND,          // 57 size 1 23
    PARAMID_RESETFL,          // 80 size 1 24
    PARAMID_STARTFL,          // 84 size 1 25
    PARAMID_STOPFL,           // 86 size 1 26
    PARAMID_STATE,            // 85 size 1 27
    PARAMID_OVERFLOW,         // 68 size 1 28
    PARAMID_PV_PVFL,          // 74 size 1 29
    PARAMID_LAST_PV,          // 103 size 1 30
    //PARAMID_BADPVFL,
    PARAMID_HIGHAL,           // 63 size 1 31
    PARAMID_PVRAW,            // 77 size 1 32
    PARAMID_PVAUTO,           // 73 size 1 33
    PARAMID_AV,               // 52 size 2 35
    PARAMID_OLDAV,            // 66 size 2 37
    PARAMID_RESETVAL,         // 81 size 2 39
    0 // Terminator           // size 1 39
};

#endif //#if !defined(IOPTYPE_DI)

#endif

#if defined(IOMTYPE_UIO)
UINT8 clsDiSlot::DiSlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
#else
UINT8 clsDiSlot::SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
#endif

const UINT8 clsDiSlot::RedParams[] = {
#if defined(IOPTYPE_DI)
    PARAMID_ALMOPT,
    PARAMID_AVTV,
    PARAMID_COMMAND,
    PARAMID_CONTCUT,
    PARAMID_COUNTDWN,
    PARAMID_DITYPE,
    PARAMID_DLYTIME,
    PARAMID_EVTOPT,
    PARAMID_INPTDIR,
    PARAMID_PNTFORM,
    PARAMID_PNTTYPE,
    PARAMID_PTEXECST,
    PARAMID_PVNORMAL,
    PARAMID_PVNORMFL,
    PARAMID_PVSOURCE,
    PARAMID_PVSRCOPT,
    PARAMID_RESETFL,
    PARAMID_STARTFL,
    PARAMID_STATE,
    PARAMID_STOPFL,
#else
    PARAMID_DITYPE,
    PARAMID_PNTTYPE,
    PARAMID_INPTDIR,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_OWDENABLE,
    PARAMID_PTEXECST,
#ifdef IOMTYPE_DISOE
    PARAMID_EVTOPT,
    PARAMID_DEBOUNCE,
    PARAMID_PVCHGDLY,
#endif
#endif //#if defined(IOPTYPE_DI)
    0 // Terminator
};

#if defined(IOMTYPE_UIO)
const UINT8 clsDiSlot::HEuRngExt[] = {
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    0 // Terminator
};
#endif

const DI_SLOTPARAMINFO clsDiSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 50
#if defined (IOPTYPE_DI)
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVEORIDLE,0,PostAlmOption,GetAlmOptPtr,FALSE,            // 51 AlmOpt
    DT_INT16,2,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetAvPtr,FALSE,                                 // 52 Av
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 51
#if defined (IOMTYPE_UIO)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_OPER, CONTROLSTATE_NONE, PreAv, PostAv, GetAvPtr, FALSE,              // 52 Av
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 52
#endif
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 53
#if defined (IOPTYPE_DI)
    DT_INT16,2,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetAvTvPtr,FALSE,                                // 54 AvTv
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 54
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 55
#if defined(IOPTYPE_DI)
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvTvFlPtr,FALSE,                              // 56 AvTvFl
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreCommand,PostCommand,GetCommandPtr,FALSE,          // 57 Command
    DT_BOOL,1,AT_SBYTE,ALCK_PROG,CONTROLSTATE_NONE,PreContCut,0,GetContCutPtr,FALSE,                    // 58 ContCut
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetCountdownPtr,FALSE,                            // 59 Countdown
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,PreDiType,PostDiType,GetDiTypePtr,TRUE,           // 60 DiType
    DT_INT16,2,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreDelayTime,0,GetDelayTimePtr,FALSE,               // 61 DelayTime
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVEORIDLE,PreEvtOpt,0,GetEvtOptPtr,TRUE,              // 62 EvtOpt
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHighAlPtr,FALSE,                              // 63 HighAl
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,PreInptDir,PostInptDir,GetInptDirPtr,TRUE,        // 64 InptDir
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePv,0,GetOffNrmflPtr,FALSE,                        // 65 OffNrmfl
    DT_INT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOldAvPtr,FALSE,                              // 66 OldAv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOldAvrPtr,FALSE,                           // 67 OldAvr
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOverFlowPtr,FALSE,                            // 68 OverFlow
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPntFormPtr,FALSE,                                // 69 PntFrom
#else
#if defined (IOMTYPE_UIO)
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvTvFlPtr,FALSE,                              // 56 AvTvFl    
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 56
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 57
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 58
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 59
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, 0, PostDiType, GetDiTypePtr, TRUE,           // 60 DiType
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 61
#ifdef IOMTYPE_DISOE
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreEvtOpt, 0, GetEvtOptPtr, TRUE,                // 62 EvtOpt
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 62
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 63
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, PreInptDir, PostInptDir, GetInptDirPtr, TRUE,// 64 InptDir
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 65
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 66
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 67
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 68
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 69
#endif
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePntType,PostPntType,GetPntTypePtr,TRUE,            // 70 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PrePtExecSt,PostPtExecSt,GetPtExecStPtr,TRUE,        // 71 PtExecSt
#if defined (IOMTYPE_UIO)
    DT_SDENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePv,0,GetPvPtr,FALSE,                            // 72 Pv
#else    
    DT_SDENUM,1,AT_BXPACK,ALCK_OPER,CONTROLSTATE_NONE,PrePv,0,GetPvPtr,FALSE,                            // 72 Pv
#endif
    DT_SDENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoPtr,FALSE,                            // 73 PvAuto    
#if defined(IOPTYPE_DI)
    DT_BOOL, 1, AT_BXPACK, ALCK_OPER, CONTROLSTATE_NONE, PrePv, 0, GetPvPtr, FALSE,                     // 74 PvFl (Parameter support only - points to Pv)    
    DT_SDENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPvNormalPtr,FALSE,                            // 75 PvNormal 
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPvNormFlPtr,FALSE,                            // 76 PvNormFl
#else
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePv,0,GetPvPtr,FALSE,                              // 74 PvFl (Parameter support only - points to Pv)    
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 75
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 76
#endif
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvRawPtr,FALSE,                               // 77 PvRaw
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePvSource,PostPvSource,GetPvSourcePtr,TRUE,        // 78 PvSource
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,PrePvSrcOpt,PostPvSrcOpt,GetPvSrcOptPtr,TRUE,         // 79 PvSrcOpt
#if defined (IOPTYPE_DI)
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreResetFl,PostResetFl,GetResetFlPtr,FALSE,          // 80 ResetFl
    DT_INT16,2,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreResetVal,0,GetResetValPtr,FALSE,                 // 81 RESETVAL
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetResetVlrPtr,FALSE,                         // 82 RESETVLR
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,                           // 83 SlotSfBt
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreStartFl,PostStartFl,GetStartFlPtr,FALSE,          // 84 STARTFL
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetStatePtr,FALSE,                               // 85 STATE
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreStopFl,PostStopFl,GetStopFlPtr,FALSE,             // 86 STOPFL
    DT_BLIND,18,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,TRUE,              // 87 CheckPoint
#else
#if defined (IOMTYPE_UIO)
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreResetFl,PostResetFl,GetResetFlPtr,FALSE,          // 80 ResetFl
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 80
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 81 
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 82
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetSlotSfBtPtr, FALSE,                   // 83 SlotSfBt
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 84
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 85
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 86
#ifdef IOMTYPE_DISOE
    DT_BLIND, 11, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, PreCheckPoint, 0, GetCheckPointPtr, TRUE,      // 87 CheckPoint
#elif defined (IOMTYPE_UIO) 
    DT_BLIND, 16, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, PreCheckPoint, 0, GetCheckPointPtr, TRUE,      // 87 CheckPoint
#else
    DT_BLIND,8,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,TRUE,               // 87 CheckPoint
#endif
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 88
#if defined (IOMTYPE_UIO)
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadPvFlPtr,FALSE,                             // 89 BadPvFl
#else       
    DT_BOOL,1,AT_BXPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadPvFlPtr,FALSE,                            // 89 BadPvFl
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 91
#ifdef IOMTYPE_DISOE
    DT_UINT8,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVEORIDLE,PreDebounce,PostDebounce,GetDebouncePtr,TRUE, // 92 Debounce
    DT_UINT8,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PrePvChgDly,PostPvChgDly,GetPvChgDlyPtr,TRUE,       // 93 PvChgDly
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 93
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 97
#ifdef IOPTYPE_DI
    DT_INT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastAvPtr,FALSE,                             // 98 LastAv
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetDlyTimerPtr,FALSE,                          // 99 DLY_TIMER
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 99
#endif
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLatchTimerPtr,FALSE,                        // 100 LatchTimer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfLrsPtr,FALSE,                          // 101 SlotSfLrs    
#ifdef IOPTYPE_DI    
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAlarmLrsPtr,FALSE,                           // 102 ALARM_LRS
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 102
#endif
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastPvPtr,FALSE,                              // 103 LastPv
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 104
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 109
#if defined (IOMTYPE_UIO)
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvStsPtr,FALSE,                               // 110 AvSts
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvRawPtr,FALSE,                             // 111 AvRaw
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvRawStsPtr,FALSE,                            // 112 AvRawSts
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreTv,PostTv,GetTvPtr,FALSE,                      // 113 Tv 
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreC1,0,GetC1Ptr,TRUE,                             // 114 C1
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreC2,0,GetC2Ptr,TRUE,                             // 115 C2
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetTvProcPtr,FALSE,                              // 116 TvProc
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 114
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 116
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 142
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreOwdEnable,0,GetOwdEnablePtr,TRUE,                  // 143 OwdEnable
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 181
#if defined(IOMTYPE_UIO)
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHLongTagPtr,FALSE,                          // 182 HLongTag
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetH7Cmd0Ptr,FALSE,                             // 183 H7Cmd0
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvMfgCd7Ptr,FALSE,                         // 184 HDvMfgCd7
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvTypCd7Ptr,FALSE,                         // 185 HDvTypCd7
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlot0TSPtr,FALSE,                          // 186 HSlot0TS
    DT_BLIND,7,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevCdPtr,FALSE,                              // 187 HDevCd
    DT_BLIND,16,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvRngExtPtr,FALSE,                          // 188 HDvRngExt
    DT_BLIND,16,AT_PSET,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetHEuRngExtPtr,FALSE,                      // 189 HEuRngExt
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHAlarmEnablePtr,FALSE,                        // 190 HAlarmEnable
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetHEnablePtr,FALSE,                         // 191 HEnable
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetHScanCfgPtr,FALSE,                        // 192 HScanCfg
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynRatePtr,FALSE,                           // 193 HDynRate
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevRatePtr,FALSE,                           // 194 HDevRate
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotDvcPtr,FALSE,                            // 195 HSlotDvc[4]
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHComThrsPtr,FALSE,                          // 196 HComThrs
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHComHysPtr,FALSE,                           // 197 HComHys
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHComStsPtr,FALSE,                             // 198 HComSts
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHNComErrPtr,FALSE,                          // 199 HNComErr
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 203
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHLComFailPtr,FALSE,                           // 204 HLComFail
    DT_BLIND,17,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd0Ptr,FALSE,                             // 205 HCmd0
    DT_BLIND,24,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd12Ptr,FALSE,                            // 206 HCmd12
    DT_BLIND,21,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd13Ptr,FALSE,                            // 207 HCmd13
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd14Ptr,FALSE,                            // 208 HCmd14
    DT_BLIND,18,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd15Ptr,FALSE,                            // 209 HCmd15
    DT_BLIND,3,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd16Ptr,FALSE,                             // 210 HCmd16
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynValPtr,FALSE,                          // 211 HDynVal[4]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynStPtr,FALSE,                              // 212 HDynSt[4]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynCcPtr,FALSE,                              // 213 HDynCc[4]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynEuPtr,FALSE,                              // 214 HDynEu[4]
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotValPtr,FALSE,                         // 215 HSlotVal[8]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotStPtr,FALSE,                             // 216 HSlotSt[8]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotCcPtr,FALSE,                             // 217 HSlotCc[8]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotEuPtr,FALSE,                             // 218 HSlotEu[8]
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevStPtr,FALSE,                             // 219 HDevSt[4]
    DT_BLIND,25,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd48Ptr,FALSE,                            // 220 HCmd48
    DT_BOOL,1,AT_BITPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd48Ptr,FALSE,                            // 221 HCmd48BT
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmdFailPtr,FALSE,                            // 222 HCmdFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmdRespPtr,FALSE,                           // 223 HCmdResp
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvMfgCdPtr,FALSE,                            // 224 HDvMfgCd
    DT_BLIND,3,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevIdCdPtr,FALSE,                           // 225 HDevIdCd
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvTypCdPtr,FALSE,                           // 226 HDvTypCd
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvRevCdPtr,FALSE,                           // 227 HDvRevCd
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDdRevCdPtr,FALSE,                           // 228 HDdRevCd
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 229
    DT_BLIND,50,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHNtfyCfgPtr,FALSE,                          // 230 HNtfyCfg
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 231
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 232 HBrdp
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynDvcPtr,FALSE,                             // 233 HDynDvc
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHartVersionPtr,FALSE,                         // 234 HartVersion
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreInitPntType,0,GetPntTypePtr,FALSE,                 // 235 InitPntType
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 235
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 243
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,                  // 244 SlotChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 246
#ifdef IOPTYPE_DI
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPtExecStLrsPtr,TRUE,                          // 247 PtExecSt (same as 71)
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 247
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 252
    
#ifdef IOPTYPE_DI
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCosTimerPtr,FALSE,                          // 253 COS_TIMER
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 253
#endif
#if defined (IOMTYPE_UIO)
    DT_BLIND,16,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCfgRestore,0,GetCheckPointPtr,TRUE,              // 254 CfgRestore
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 254
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE                                           // 255
};
/*******************************************************************************
*                            clsDiSlot::operator new                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS: a_ucSltNm = 0-relative slot number                                *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
#if defined (IOMTYPE_UIO)
    return (EXTRAM_SLOT_ADDR(a_ucSltNm + 1));
#else
    return (ucIomDbMemory + DIBOXSLOT_SIZE + (a_ucSltNm * DISLOT_SIZE));
#endif
}
/*******************************************************************************
*                           clsDiSlot::clsDiSlot                               *
*                           ====================                               *
* PURPOSE: Constructor of clsDiSlot Class. This calls InitDiSlot() which       *
*          initializes clsDiSlot class members.                                *
* ARGUMENTS:                                                                   *
*           a_ucSltNm    -   Slot number                                       *
* RETURN:   NONE                                                               *
* NOTES:    This constructor will internally invokes clsInSlot class          *
*                   constructor.                                               *
*******************************************************************************/
clsDiSlot::clsDiSlot(UINT8 a_ucSltNm) :
#if defined (IOMTYPE_UIO)
    HartDevDb(a_ucSltNm,&HartCfgDb,&HartCfgDb7),
#endif
    clsInSlot(PNTTYPE_NOTCONFIGURED,a_ucSltNm) {

    InitDiSlot(TRUE, TRUE);
    for (UINT8 ucCount = 0; ucCount < DISLOT_SPARESIZE; ucCount++) {
        DiSlotSpare[ucCount] = 0;
    }
}
/*******************************************************************************
*                           clsDiSlot::InitDiSlot                              *
*                           =====================                              *
* PURPOSE: InitDiSlot function which initializes clsDiSlot class members.      *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:   This function is called when Init Slot request comes.               *
*******************************************************************************/
VOID clsDiSlot::InitDiSlot(BOOL bFullInit, BOOL bObjCreate) {
    InptDir     = INPTDIR_DIRECT;  
    PvRaw       = FALSE;
    PvAuto      = OFF;
    LatchTimer  = 0;
#if defined (IOPTYPE_DI)
    DelayTime = 0;
    DlyTimer = 0;
    OffNrmfl = FALSE;
    CosTimer = 0;
    // added to fix the PAR# 1-GLD5D07
    AlmInfo.ucByte = 0x00;
    AlarmLrs.ucByte = 0x00;
    AlmOpt = ALMOPT_NONE;
#endif
#if defined(IOMTYPE_UIO)
    ufC1        = (FLOAT32)1.0;
    ufC2        = (FLOAT32)1.0;
    ResetFl= FALSE;
    TvProc= FALSE;
    // Clear AVRAW Counter
    if(IsPulseAccumCapable())
    {
       BOX->StoreAvRaw(ChanNum,0);
       FPGA.ClrCounter(ChanNum);
       if (bObjCreate || bFullInit)
       {
            BOX->InitializeDiPcScanRec(ChanNum);
       }
    }
#endif
#ifdef IOMTYPE_DISOE
    EvtOpt      = EVTOPT_NONE;
    Debounce    = DEFAULT_DEBOUNCE;
    PvChgDly    = DEFAULT_PVCHGDLY;
    PvChgDlyTimer = 0;
    bPvChgDlyEventSet = FALSE;
#endif
    if (bObjCreate || bFullInit || (DiType != DITYPE_STATUS) || (PvSource != PVSOURCE_MANUAL)) {
        DiType  =   DITYPE_STATUS;
        LastPv  =   OFF;

#if defined(IOMTYPE_UIO)
        if (!BOX->IsDumpInProgress())
#endif
        {
            BOX->SetPv(ChanNum,PvAuto);
        }
    }
}
/*******************************************************************************
*                            clsDiSlot::GetDataType                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsDiSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsDiSlot::GetAccessType                            *
*                          ========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsDiSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                            clsDiSlot::GetParamSize                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsDiSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                            clsDiSlot::GetParamPtr                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsDiSlot::GetParamPtr(UINT8 a_ucParamNumber) {        
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                           clsDiSlot::GetAccessLock                           *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsDiSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                       clsDiSlot::GetIsDbChecksumed                           *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDiSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                         clsDiSlot::VerifyControlState                        *
*                         =============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsDiSlot::ExecutePreFunction                        *
*                         =============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsDiSlot::ExecutePostFunction                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) 
{
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                              clsDiSlot::GetPvPtr                             *
*                              ===================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetPvPtr(VOID) { 
#if defined (IOMTYPE_UIO)
    return &(BOX->PvScanRec.ScanRec[ChanNum-1].DI.PvFl);
#else
    return BOX->PvAll;
#endif    
}
/*******************************************************************************
*                            clsDiSlot::GetBadPvFlPtr                          *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetBadPvFlPtr(VOID) { 
#if defined (IOMTYPE_UIO)
    return &(BOX->PvScanRec.ScanRec[ChanNum-1].DI.BadPvFl);
#else
    return BOX->BadPvAll;
#endif
}
/*******************************************************************************
*                           clsDiSlot::PrePntType                              *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for PntType parameter.                *
*           This method checks for range of the data that can be written to    *
*           PntType parameter, access level check, module status check, point  *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) 
{
    ScratchPad = *(PNTTYPE *)a_Writebuffer;
    UINT8 ucModSts = BOX->GetModuleStatus();
    
    if (((PNTTYPE)ScratchPad != PNTTYPE_NOTCONFIGURED)
        && ((PNTTYPE)ScratchPad != PNTTYPE_DIGITALINPUT)) {
        return DO_ILLEGAL_VALUE;
    }
    if (ucModSts == MODSTATUS_RUN) {
        if (a_ucAccLvl == ALVL_IUSER) { 
            return DO_STATE_MUST_BE_IDLE;
        }
        if (PtExecSt != PTEXECST_INACTIVE) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsDiSlot::PostPntType                             *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
*           If point is already configured, initialize the slot fully or if    *
*           point is retained with old value, just initialize new values.      *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostPntType(UINT8 a_ucAccLvl) 
{
    if (a_ucAccLvl == ALVL_IUSER) {     // if checkpoint restore
        InitSlotDatabase(TRUE);         //    full initialization
        PtExecSt = PTEXECST_INACTIVE;   //    force to INACTIVE
    }
    else {
        if ((PNTTYPE)ScratchPad == PNTTYPE_DIGITALINPUT) {    // if point build
            InitSlotDatabase(FALSE);    //    partial initialization
        }
        else {                          // if point delete
            InitSlotDatabase(TRUE);     // full initialization
#if defined (IOMTYPE_UIO)
            UIO_SLOT(ChanNum)->DeleteConfiguredSlot();
#endif
        }
    }
    UpdateBadPv();                      // test and update BadPvFl, BadPvAll
}
/*******************************************************************************
*                           clsDiSlot::PrePtExecSt                             *
*                           ======================                             *
* PURPOSE:  Pre Receiver-Beware function for PtExecSt parameter.               *
*           This method checks for range of the data that can be written to    *
*           PtExecSt parameter and access level check.                         *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PrePtExecSt(UINT8 *a_Writebuffer,UINT8)
{
#if defined(IOPTYPE_DI)
    // added to fix the PAR# 1-GJ6MQXN
    ScratchPad = PtExecSt; // Save current execution state for post function.
#endif

    if (*(UINT8 *)a_Writebuffer > PTEXECST_ACTIVE)
    {
        return DO_PARAMETER_INVALID;
    }
    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PostPtExecSt                          *
*                             =======================                          *
* PURPOSE:   update BadPvFl, BadPvAll                                          *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostPtExecSt(UINT8) 
{
    if (PtExecSt == PTEXECST_INACTIVE) { 
        InactivateSlot();                           
    }
    UpdateBadPv();
#ifdef IOMTYPE_DISOE
    if (PtExecSt == PTEXECST_ACTIVE)
    {
        // Read the Pv and update it to StMchInputBuf
        GetRawInput();
        ProcessSlot();
        // As the StMchinPutBuf is zero based, channel num is one base, we decrement
        // the channel num by one and send
        BOX->InitSOEState(ChanNum-1, RawInput);
    }
#endif

#if defined(IOPTYPE_DI)
    // added to fix the PAR# 1-GJ6MQXN
    if ((PTEXECST)ScratchPad != PtExecSt)// point execution state changed
    	CreatePtExecStEvt(EVENTTYPE_NORMAL);        
#endif
}

#if defined(IOPTYPE_DI)
// added to fix the PAR# 1-GJ6MQXN
/*******************************************************************************
*                          clsDoSlot::CreatePtExecStEvt                       *
*                          =============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS: a_EventType - Normal / Recovery                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::CreatePtExecStEvt(EVENTTYPE a_EventType) {
    EVENTRECORD PtExecStEvent;

    PtExecStEvent.Overflow = FALSE;
    PtExecStEvent.ContactCutout = FALSE;
    PtExecStEvent.Qualifier = a_EventType;
    PtExecStEvent.CurrentState = EVENTSTATE_RETURN;
    PtExecStEvent.EventPacket = EVENTPACKET_SYSTEM;
    PtExecStEvent.SystemEvent.SoftfailStatus = FALSE;
    PtExecStEvent.SystemEvent.ChannelNumber = ChanNum;

    //IF CURRENT PTEXECST = ON
    if (PTEXECST_ACTIVE == PtExecSt)
    {
        PtExecStLrs |= PTEXECST_ON_LRSBIT;

        if (PtExecStLrs & PTEXECST_OFF_LRSBIT)
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_OFF_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_OFF_LRSBIT;
            }
        }
        else
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_ON_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_ON_LRSBIT;
            }
        }
    }
    else //(PTEXECST_INACTIVE == PtExecSt)
    {
        PtExecStLrs |= PTEXECST_OFF_LRSBIT;

        if (PtExecStLrs & PTEXECST_ON_LRSBIT)
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_ON_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_ON_LRSBIT;
            }
        }
        else
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_OFF_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_OFF_LRSBIT;
            }
        }
    }
}
#endif

/*******************************************************************************
*                             clsDiSlot::PrePvSource                           *
*                             ======================                           *
* PURPOSE:  Allow check point write to go through for component points         *
*           if PvSource is not changed                                         * 
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                          *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PrePvSource(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
{
    if (*(UINT8 *)a_Writebuffer > PVSOURCE_TRACK) 
    {
        return DO_PARAMETER_INVALID;
    }
    
    if (a_ucAccLvl == ALVL_IUSER) {                      // if Chkpnt Restore in progress
        if (*(UINT8 *)a_Writebuffer == PvSource) {      //   and new value = old
            return PA_OK;                            //     return OK 
        }
    }
    if (PvSrcOpt == PVSRCOPT_ONLYAUTO) {
        if (*(UINT8 *)a_Writebuffer != PVSOURCE_AUTO) {
            return DO_PARAMETER_INVALID;
        }
    }
    
    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PostPvSource                          *
*                             =======================                          *
* PURPOSE:  set/reset slot associated PV-bit in PvAll                          *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostPvSource(UINT8) 
{
    if (PvSource != PVSOURCE_MANUAL) {
        DoPvDefault();                 // default PV if idle
    }
    UpdateBadPv();                     // test and update BadPvFl, BadPvAll
#ifdef IOMTYPE_DISOE
    if((DIMODE_SOE == BOX->GetDiMode())&&(PVSOURCE_AUTO == PvSource)) {
        BOX->SetPv(ChanNum,PvAuto);
    }
#endif
}
/*******************************************************************************
*                             clsDiSlot::PrePvSrcOpt                           *
*                             ======================                           *
* PURPOSE:// if Chkpnt Restore in progress and new value = old return OK       *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                          *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PrePvSrcOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) 
{
    if (*(UINT8 *)a_Writebuffer > PVSRCOPT_ALL) 
    {
        return DO_PARAMETER_INVALID;
    }
    if (a_ucAccLvl == ALVL_IUSER) {                      // if Chkpnt Restore in progress
        if (*(UINT8 *)a_Writebuffer == PvSrcOpt) {      //   and new value = old
            return PA_OK;                            //     return OK 
        }
    }
    
    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PostPvSrcOpt                          *
*                             =======================                          *
* PURPOSE: default PV if idle, test and update BadPvFl, BadPvAll               *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostPvSrcOpt(UINT8) 
{
    if (PvSrcOpt == PVSRCOPT_ONLYAUTO) {
        PvSource = PVSOURCE_AUTO; 
        DoPvDefault();                 
    }
    UpdateBadPv();
 #ifdef IOMTYPE_DISOE
    if ((DIMODE_SOE == BOX->GetDiMode())&&(PVSOURCE_AUTO == PvSource)) {
        BOX->SetPv(ChanNum,PvAuto);
    }
 #endif
}
/*******************************************************************************
*                           clsDiSlot::PreDiType                               *
*                           ======================                             *
* PURPOSE:  Pre Receiver-Beware function for DIType parameter.                 *
*                                                                              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreDiType(UINT8 *a_Writebuffer,UINT8 ) 
{
#if defined(IOMTYPE_UIO)
    if ( *(UINT8 *)a_Writebuffer > DITYPE_ACCUM )
    {
        return DO_PARAMETER_INVALID;
    }

    if((ChanNum < PC_CHANNEL1 || ChanNum > PC_CHANNEL4) && (*(UINT8 *)a_Writebuffer == DITYPE_ACCUM))
    {
        return DO_FUNCTION_NOT_IMPLEMENTED;
    }
#else 
#if defined IOPTYPE_DI
    if ( *(UINT8 *)a_Writebuffer > DITYPE_ACCUM )
    {
        return DO_PARAMETER_INVALID;
    }
#else
    if (*(UINT8 *)a_Writebuffer > DITYPE_LATCHED) 
    {
        return DO_PARAMETER_INVALID;
    }
#endif
#endif
#ifdef IOMTYPE_DISOE
    //do not allow latch type when channel has EvtOpt set to SOE
    if ( (*(UINT8 *)a_Writebuffer == DITYPE_LATCHED) && (EVTOPT_SOE == EvtOpt) )
        return DO_ILLEGAL_VALUE;
#endif
    return PA_OK;
}
/*******************************************************************************
*                           clsDiSlot::PostDiType                              *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for DIType parameter.                *
*                                                                              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostDiType(UINT8 ) 
{
#if defined(IOMTYPE_UIO)
    if(IsPulseAccumCapable())
    {
        FPGA.SetPulseCountDacHigh(ChanNum);
        BOX->StoreAvRaw(ChanNum,0);
        FPGA.ClrCounter(ChanNum);
    }
#endif
    UpdateBadPv();// test and update BadPvFl
}
/*******************************************************************************
*                             clsDiSlot::PreInptDir                            *
*                             =======================                          *
* PURPOSE:if Chkpnt Restore in progress  and new value = old return OK         *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreInptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) 
{
    if (*(UINT8 *)a_Writebuffer > INPTDIR_REVERSE)
    {
        return DO_PARAMETER_INVALID;
    }
    if (a_ucAccLvl== ALVL_IUSER) {
        if (*(UINT8 *)a_Writebuffer == InptDir) {
            return PA_OK;
        }
    }
   
    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PostInptDir                           *
*                             =======================                          *
* PURPOSE: Set PvAuto with respect to Direction                                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostInptDir(UINT8 ) 
{
    if (InptDir == INPTDIR_DIRECT) 
        PvAuto = OFF;
    else 
        PvAuto = ON;
       
    if (PvSource != PVSOURCE_MANUAL) 
            DoPvDefault();                 // default PV if idle
}
/*******************************************************************************
*                             clsDiSlot::PrePv                                 *
*                             ================                                 *
* PURPOSE:   check for PvSrcOpt,PvSource, ModStatus                            *
* ARGUMENTS:                                                                   *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PrePv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) 
{
#if defined(IOPTYPE_DI)
    //To fix, PAR #1-98C9P4T (Unable to write into PV of a DI-DI24 point manually after changing.) 
    //if(DITYPE_ACCUM != DiType)
    if (DITYPE_ACCUM == DiType)
    {
      return DO_PARAMETER_INVALID;
    }
#else
    if (*(UINT8 *)a_Writebuffer > 1) 
    {
        return DO_PARAMETER_INVALID;
    }
#endif

    UINT8 ucModSts = BOX->GetModuleStatus();
    if (PvSrcOpt == PVSRCOPT_ONLYAUTO) {
        return DO_READ_ONLY_PARAMETER;
    }
    if (PvSource == PVSOURCE_AUTO) {
        return DO_PVSOURCE_INVALID;
    }
    if (PvSource == PVSOURCE_SUB) {
        if (!(a_ucAccLvl& ALCK_PROG_UMCC_CC)) {
            return DO_PVSOURCE_INVALID;
        }
        if ((ucModSts != MODSTATUS_RUN)
         || (PtExecSt == PTEXECST_INACTIVE)) {
            return DO_PTEXECST_OR_MODLSTAT_INCONSISTENT;
        }
        else { return PA_OK; }
    }
    else if (!(a_ucAccLvl& ALCK_ONPROC)) {
             return DO_PVSOURCE_INVALID;
    }
    return PA_OK;
}
// DISOE IOM related RB Checks.
#ifdef IOMTYPE_DISOE
/*******************************************************************************
*                             clsDiSlot::PreEvtOpt                             *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreEvtOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
{
     ScratchPad = (UINT8)EvtOpt; 
    //if the new value and old value is same, during checkpoint restore
    //return.
    if(ALVL_IUSER == a_ucAccLvl)
    {
        if(*(UINT8 *)a_Writebuffer == ScratchPad)
        {
            return PA_OK;
        }
    }
    //Check the new value is either SOE or NONE.
    if( (*(EVTOPT *)a_Writebuffer) > EVTOPT_SOE )
    {
        return DO_ILLEGAL_VALUE;
    }
    //if the DI type is Latch , do not allow SOE as new value.
    if((DITYPE_LATCHED==DiType) || (DIMODE_LOWLATNCY==BOX->GetDiMode()))
    {
        if(EVTOPT_SOE == *(EVTOPT *)a_Writebuffer)
        {
            return DO_ILLEGAL_VALUE;
        }
    }
   return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PreDebounce                           *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreDebounce(UINT8 *a_Writebuffer , UINT8 )
{
    UINT8 ucModSts = BOX->GetModuleStatus();
    if ((PTEXECST_ACTIVE == PtExecSt) && (MODSTATUS_RUN == ucModSts))
    {
        return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
    }
    else
    {
        //check for the range btw 0-50
        if(*a_Writebuffer > MAXDEBOUNCETIME)
        {
            return DO_LIMIT_OR_RANGE_EXCEEDED;
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PostDebounce                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostDebounce(UINT8 )
{
    BOX->SetStMchInputBufTarget(ChanNum,Debounce);
}
/*******************************************************************************
*                             clsDiSlot::PrePvChgDly                           *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PrePvChgDly(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
{
    if(ALVL_IUSER != a_ucAccLvl)
    {
        if(EVTOPT_SOE != EvtOpt )
        {
            return DO_PARAMETER_INVALID;
        }
    }
    // check for the max value
    if(*a_Writebuffer>MAXPVCHGDLY)
    {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }
    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PostPvChgDly                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostPvChgDly(UINT8)
{
    // if the one second count is already reached 50% of count then increment
    // the delay count (this is to minimize the error time)
    if((0!=PvChgDly) && ((TaskScheduler.Get10msecCounter() % SCHEDULER_TICKS_IN_SECOND) >= 
        (SCHEDULER_TICKS_IN_SECOND/2)))
    {
        PvChgDlyTimer = PvChgDly+1;
    }
    else
    {
        PvChgDlyTimer = PvChgDly;
    }
}
#endif // end if DISOE beware functions
/*******************************************************************************
*                         clsDiSlot::PreOwdEnable                              *
*                         =======================                              *
* Open wire detection is supported only in 24V DI modules. However, we need to *
* support the default writes with FALSE values for checkpoint restore.         *
*******************************************************************************/
PASTATUS clsDiSlot::PreOwdEnable(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) {
    UINT16 ProductCode = BOX->GetProductCode();
    if ((MODLTYPE_DIH == BOX->GetModuleType()) && (TRUE == *(BOOL *)a_Writebuffer)) {
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }

    // For LOWCOST DI and DISOE modules, return Configuration mismatch error if OWD is enabled
    if (((PRODCODE_DI_24V_LC == ProductCode) || (PRODCODE_DI_24V_LC_S8 == ProductCode)
        || (PRODCODE_DISOE_LC_S8 == ProductCode)) && ((TRUE == *(BOOL *)a_Writebuffer))) {
        // Allow if access level in intimate user as Warmstart and check point
        if(a_ucAccLvl == ALVL_IUSER)
            return PA_OK;
        else
            return DO_CONFIGURATION_MISMATCH_ERROR;
    }

    // Allow if acess level is intimate user as Warmstart and check point
    // restores will fail because DiMode default value is SOE and this slot
    // params will be dumped first.
    if(a_ucAccLvl == ALVL_IUSER) {
        return PA_OK;
    }
    // Do not allow to enable openwire detection for SOE/LowLatency modes
    if ((DIMODE_NORMAL != BOX->GetDiMode()) && (TRUE == *(BOOL *)a_Writebuffer)) {
        return DO_INVALID_MODE;
    }
    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::DoPvDefault                           *
*                             =======================                          *
* PURPOSE:   Default the PV to off, along with its bit in PVALL.               *
*            Do this only if the slot is not active or ucModSts = idle.        *
*            Note: 'off' for PV must consider INPTDIR.  To best do this,       *
*            set the PV to the value of PVAUTO, which is given the             *
*            correct value when the point was made inactive or the box idled   *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::DoPvDefault() 
{
    UINT8 ucModSts = BOX->GetModuleStatus();
    
    if ((PtExecSt == PTEXECST_INACTIVE)|| (ucModSts == MODSTATUS_IDLE)) 
    {
        BOX->SetPv(ChanNum,PvAuto);
        LastPv = PvAuto;
    }
}
/*******************************************************************************
*                             clsDiSlot::UpdateBadPv                           *
*                             =======================                          *
* PURPOSE:                                                                     *
*     This routine is called from various locations in the receiver beware code*
*     or the point processor to compute the current value of -BadPvFl-, and to *
*     update the data base with the result.                                    * 
*                                                                              * 
* ARGUMENTS:  None                                                             *
* RETURN:     None                                                             *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::UpdateBadPv() 
{
    UINT8 ucModSts = BOX->GetModuleStatus();
    BOOL  nBadFlag = TRUE;// PV bad          
    
    if (PvSource == PVSOURCE_MANUAL) 
    {
        nBadFlag = FALSE;//  PV OK
    }
    else if (((ucModSts == MODSTATUS_RUN) && (PtExecSt == PTEXECST_ACTIVE)) || BOX->CheckForFactoryTestMode()) 
    { 
#if !defined (IOMTYPE_UIO)

        // BadPv updation should be done based on results of
        // ForcedInputDiag (FID) along with Slot soft fail bits as the 
        // FID softfail is posted at lower speed in BoxHouseKeeping.
        UINT32 ulBitMask = 0x0001;
        ulBitMask = ulBitMask<<(ChanNum-1);
        if((PvSource == PVSOURCE_AUTO) && (0 == SlotSfBt) && 
                (!(ulBitMask & BOX->GetForcedInputDiagStatus())))
        {
            if (!GetOwdEnable()) nBadFlag = FALSE;//  PV OK
            else if (RawInput == OFF
                || (BOX->GetSnsChkOWD() & (SNS_CHKA >> ((ChanNum-1)/8))))
                nBadFlag = FALSE;//  PV OK
        }
        
        if (PvSource != PVSOURCE_AUTO) 
        {
            nBadFlag = FALSE;//  PV OK
        }

#else // IOMTYPE_UIO
       
        // Clear BadPvFlag if:
        // 1) PVSOURCE is not AUTO
        // 2) Or if PVSOURCE is AUTO and no Softfails, meaning Open Wire not detected
        if( (PVSOURCE_AUTO != PvSource) || (0 == SlotSfBt) )
        {
          nBadFlag = FALSE;//  PV OK
        }
#endif
    }
#if defined (IOMTYPE_UIO)
    if (IsPulseAccumCapable())
    {
        nBadFlag = TRUE; // PVFL is invalid when DITYPE is 'Accum', so BADPVFL must always be set
    }
#endif
  
    BOX->SetBadPvFl(ChanNum,nBadFlag);
}
/*******************************************************************************
*                           clsDiSlot::InitSlotDatabase                        *
*                           ===========================                        *
* PURPOSE:  Utility function which initializes the slot depending on point     *
*           configuration.                                                     *
* ARGUMENTS:                                                                   *
*           bFullInit       -   Full init flag.                                *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::InitSlotDatabase(BOOL bFullInit) 
{
    BOOL bObjCreate = FALSE; // This variable turns off the compiler warning
    // "constant in comparison" when Init member functions get inlined.
    InitIoSlot(PntType,bFullInit,bObjCreate);
    InitInSlot(bFullInit,bObjCreate);
    InitDiSlot(bFullInit, bObjCreate);
    ComputeCheckSum(); // Recompute SLOT checksum
}
/*******************************************************************************
*                           clsDiSlot::InactivateSlot                          *
*                           ====================                               *
* PURPOSE:  InactivateSlot                                                     *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot:: InactivateSlot() 
{
    LatchTimer = 0;
    PvRaw      = FALSE;

    // added to fix the PAR# 1-GLD5D07
    OffNrmfl = FALSE;
    AlarmLrs.ucByte = 0;
    AlmInfo.ucByte = 0;
    HighAl = CLEAR_ALARM;
    CosTimer = 0;
    DlyTimer = 0;

    if (InptDir == INPTDIR_DIRECT) PvAuto = OFF;
    else PvAuto = ON;
    
    if (PvSource != PVSOURCE_MANUAL) 
    {
        BOX->SetPv(ChanNum,PvAuto); 
        LastPv = PvAuto; 
    } 
}
#if !defined (IOMTYPE_UIO)
/*******************************************************************************
*                            clsDiSlot::GetRawInput                            *
*                            ======================                            *
* PURPOSE   : Record current input state in the slot database.                 *
* ARGUMENTS : None.                                                            *
* RETURN    : None.                                                            *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsDiSlot::GetRawInput(VOID) {
    if (!BOX->CheckForFactoryTestMode()){
        if ((PTEXECST_INACTIVE == PtExecSt) ||
            (MODSTATUS_IDLE == BOX->GetModuleStatus())) {
            RawInput = FALSE;
            return;
        }
    }

    UINT8 ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
    UINT8 ucBitIndex  = 0x01 << ((ChanNum - 1) & 0x07);
    
    if (BOX->GetModlType() == MODLTYPE_DIH ) {
        if (BOX->DiHvRawInputs[ucByteIndex] & ucBitIndex) {
            RawInput = TRUE;
            return;
        }
    }
    else if (!((*BOX->pInputPorts[ucByteIndex]) & ucBitIndex)) {
        RawInput = TRUE;
        return;
    }

    RawInput = FALSE;
}
#endif // !defined (IOMTYPE_UIO)
/*******************************************************************************
*                           clsDiSlot::ProcessSlot                             *
*                           ======================                             *
* PURPOSE:     This function calculates PV depending on PV read from ports,    *
*              the direction parameter and DiType.                             *
* ARGUMENTS:   None                                                            *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::ProcessSlot(VOID) {
    BOOL bPvRawChange = FALSE;
    //BOOL tmpAvTvFl = FALSE;
    if (RawInput != PvRaw) bPvRawChange = TRUE;

    if (SlotSfBt > 0)
    {
        // This behavior is in accordance with the traditional DI behavior.
        // If any slot or box softfails exist, then PvRaw is defaulted to 
        // FALSE and point processing continues.
        PvRaw = FALSE;
    }
    else 
    {
        // If channel is active and no softfail exist, apply raw input to PvRaw.
        PvRaw = RawInput;
    }

    BOOL NewPvAuto = PvRaw^InptDir; // Apply input direction.
    ONOFF CurPv = BOX->GetPv(ChanNum);

    switch (DiType) 
    {
    case DITYPE_STATUS :
        if (PvAuto != NewPvAuto) PvAuto = (ONOFF)NewPvAuto;      
        if (PvSource == PVSOURCE_AUTO) 
        {
            CurPv = PvAuto;
            BOX->SetPv(ChanNum,CurPv); 
        }
        
        if (LastPv != CurPv) 
        {
          LastPv = CurPv;
#if defined (IOPTYPE_DI)          
          PvclEntryRoutine();
#endif
        }
#if defined (IOPTYPE_DI)
          //DebugPort.PrintString("\n\rDT=%d,",DelayTime);
          //DebugPort.PrintString("\n\rDTr=%d,",DlyTimer);
          AlarmProcessorDI();
#endif
        break;
    case DITYPE_LATCHED:
        if ((NewPvAuto)&&(PvAuto)&&(bPvRawChange))    
        {
            LatchTimer = BOX->GetLatchTimeCnt();
        }
        if (((NewPvAuto)&&(PvAuto)&&(!bPvRawChange)&&(LatchTimer>0))
            || ((NewPvAuto!=1)&&(LatchTimer>0)))
        {
            LatchTimer--;
        }
        if ((NewPvAuto)&&(PvAuto!=1))
        {
            PvAuto=ON;

            LatchTimer = BOX->GetLatchTimeCnt();
        }
        if ((!NewPvAuto)&&(PvAuto)&&(LatchTimer<1))
        {
            PvAuto=OFF;
        }
        if (PvSource == PVSOURCE_AUTO) 
        {
            CurPv = PvAuto;
            BOX->SetPv(ChanNum,CurPv); 
        }
        if (LastPv != CurPv)
        {
            LastPv = CurPv;
#if defined (IOPTYPE_DI)          
          PvclEntryRoutine();
#endif
        }
        break;
#if defined (IOPTYPE_DI)
    case DITYPE_ACCUM:

      if(STOPPED != State)
      {
        if (PvAuto != NewPvAuto) 
        {
          PvAuto = (ONOFF)NewPvAuto;
          if(NewPvAuto)
          {
            if(!Countdown)
            {
              Av++;
              if(Av>0x7FFF)
              {
                OverFlow = TRUE;
                Av = 0;
              }
            }
            else
            {
              Av--;
              if(Av<0)
              {
                OverFlow = TRUE;
                Av = 0x7FFF;
              }
            }
          }
        }
        if(Av!=LastAv)
        {
          LastAv=Av;
        }
        if(Av==AvTv)
        {
          if(!Countdown)
          {
            if(Av<AvTv)
            {
              AvTvFl = FALSE;
            }
            else
            {
              AvTvFl = TRUE;
            }
          }
          else
          {
            if(Av<AvTv)
            {
              AvTvFl = TRUE;
            }
            else
            {
              AvTvFl = FALSE;
            }
          }
        }
      }
      break;
#endif
    }
}

#if defined (IOPTYPE_DI)
/*******************************************************************************
*                            clsDiSlot::PreAlmOption                           *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for AlmOpt parameter.                 *
*           This method checks for , access level check,AlmOpt&AlmOptcheck     *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
//PASTATUS clsDiSlot::PreAlmOption(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
//{
//  if (*(UINT8 *)a_Writebuffer > ALMOPT_OFFNORMAL) 
//  {
//    return DO_PARAMETER_INVALID;
//  }
//
//  if (a_ucAccLvl == ALVL_IUSER) {                      // if Chkpnt Restore in progress
//    if (*(UINT8 *)a_Writebuffer == AlmOpt) {      //   and new value = old
//      return PA_OK;                            //     return OK 
//    }
//  }
//  else
//  {
//    if(*(ALMOPT *)a_Writebuffer == ALMOPT_CMDDIS){
//      return DO_ILLEGAL_VALUE;
//    }
//    else if(*(ALMOPT *)a_Writebuffer != ALMOPT_CHSTOFFN)
//    {
//      if((DITYPE_STATUS == DiType) && (PntForm == PNTFORM_FULL))
//      {
//        return PA_OK;   
//      }        
//    }   
//  }    
//  return PA_OK;
//}
/*******************************************************************************
*                             clsDiSlot::PostAlmOption                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostAlmOption(UINT8 ) 
{
    if ((AlmOpt != ALMOPT_OFFNORMAL) || (AlmOpt != ALMOPT_CHSTOFFN))
    {
          PvNormal = PVNORMAL_OFF;    //PvNormal not supported
    }
}
/*******************************************************************************
*                            clsDiSlot::PreAlmOption                           *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for AvTv parameter.                 *
*           This method checks for , access level check,AvTv&AvTvcheck     *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
//PASTATUS clsDiSlot::PreAvTv(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
//{
//  if(*(INT16 *)a_Writebuffer == AvTv)
//  {
//      return PA_OK;    
//  }
//    if ((a_ucAccLvl != ALVL_IUSER)||(*(INT16 *)a_Writebuffer != AvTv))
//    {
//        if(DITYPE_ACCUM != DiType){
//        return DO_PARAMETER_INVALID;   
//      }        
//    }
//    return PA_OK;
//}

/*******************************************************************************
*                            clsDiSlot::PreCommand                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for Command parameter.                *
*           This method checks for , access level check,Command&Commandcheck   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreCommand(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
{
  UINT8 ucModSts = BOX->GetModuleStatus();

    if(DITYPE_ACCUM != DiType)
    {
        return PA_OK;
    }
    if (*(COMMAND *)a_Writebuffer != START_COM) 
    {
        return PA_OK;
    }
    if ((PtExecSt == PTEXECST_INACTIVE)|| (ucModSts == MODSTATUS_RUN)) 
    {
        //return DO_PTEXECST_OR_MODLSTAT_INCONSISTENT; DEEP To Be Done 
    return PA_OK;
    }
    return PA_OK;
}

/*******************************************************************************
*                             clsDiSlot::PostCommand                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostCommand(UINT8)
{
  switch(Command)
    {
        case NONE:
            Command = NONE;
            break;
        case START_COM:
            State = RUNNING;
            Command = NONE;
            break;
        case STOP_COM:
            State = STOPPED;
            Command = NONE;
            break;
        case RESET_COM:
            OldAv = Av;
            Av = ResetVal;
            OverFlow = false;
            AvTvFl = false;        
            Command = NONE;
            break;
        default:
            Command = NONE;
            break;    
    }
}

/*******************************************************************************
*                            clsDiSlot::PreContCut                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for Command parameter.                *
*           This method checks for , access level check,ContCut&ContCutcheck   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreContCut(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
{
    if ((a_ucAccLvl == ALVL_IUSER)||(*(INT16 *)a_Writebuffer == ContCut))
    {
        return PA_OK;  
    }
    if((DITYPE_STATUS == DiType) && (AlmOpt == ALMOPT_NONE))
    {
        return DO_PARAMETER_INVALID;  
    }    
    
    return PA_OK;  
}
/*******************************************************************************
*                            clsDiSlot::PrePntFrom                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for Command parameter.                *
*           This method checks for , access level check,PntFrom&PntFromCheck   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS PrePntFrom(UINT8 *a_Writebuffer, UINT8 AccLvl)
{
  if (*(INT16 *)a_Writebuffer != PNTFORM_FULL)
  {
    return PA_OK;   
  }
  else
  {
    return DO_PARAMETER_INVALID;
  }
}
/*******************************************************************************
*                            clsDiSlot::PreCountdown                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for Countdown parameter.              *
*           This method checks for access level check,Countdown&Countdowncheck *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
//PASTATUS clsDiSlot::PreCountdown(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
//{
//  if (a_ucAccLvl != ALVL_IUSER)
//    {
//    if(DITYPE_ACCUM == DiType)
//    {
//        return PA_OK;   
//    }        
//    }
//  else
//  {
//    if(*(INT16 *)a_Writebuffer != Countdown)
//    {
//            return PA_OK;   
//    }
//  }
//    return PA_OK;     
//}
/*******************************************************************************
*                            clsDiSlot::PreDelayTime                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for Countdown parameter.              *
*           This method checks for access level check,DelayTime&DelayTimecheck *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreDelayTime(UINT8 *writebuffer, UINT8 a_ucAccLvl)
{
  if(a_ucAccLvl == ALVL_IUSER)
  {
    return PA_OK;
  }
  if(AlmOpt == ALMOPT_NONE)
  {
    return DO_PARAMETER_INVALID;
  }
  return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PreEvtOpt                             *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreEvtOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
{
     ScratchPad = (UINT8)EvtOpt; 
    //if the new value and old value is same, during checkpoint restore
    //return.
    if(ALVL_IUSER == a_ucAccLvl)
    {
        if(*(UINT8 *)a_Writebuffer == ScratchPad)
        {
            return PA_OK;
        }
    }
    if(DITYPE_ACCUM==DiType)
    {
      return DO_PARAMETER_INVALID;
    }
    //Check the new value is either SOE or NONE.
    if( (*(EVTOPT *)a_Writebuffer) > EVTOPT_SOE )
    {
        return DO_ILLEGAL_VALUE;
    }
    //if the DI type is Latch , do not allow SOE as new value.
    if(DITYPE_LATCHED==DiType) //|| (DIMODE_LOWLATNCY==BOX->GetDiMode()))
    {
        if((EVTOPT_SOE == *(EVTOPT *)a_Writebuffer) || (EVTOPT_EIPSOE == *(EVTOPT *)a_Writebuffer))
        {
            return DO_ILLEGAL_VALUE;
        }
    }
   return PA_OK;
}

/*******************************************************************************
*                             clsDiSlot::PrePntForm                                *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
//PASTATUS clsDiSlot::PrePntForm(UINT8 *writebuffer, UINT8 AccLvl)
//{
//  return PA_OK;
//}
/*******************************************************************************
*                             clsDiSlot::PrePvNormal                           *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
//PASTATUS clsDiSlot::PrePvNormal(UINT8 *writebuffer, UINT8 AccLvl)
//{
//  return PA_OK;
//}
/*******************************************************************************
*                             clsDiSlot::PrePvNormFl                           *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
//PASTATUS clsDiSlot::PrePvNormFl(UINT8 *writebuffer, UINT8 AccLvl)
//{
//  return PA_OK;
//}

/*******************************************************************************
*                             clsDiSlot::PostPv                                *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
//VOID  clsDiSlot::PostPv(UINT8)
//{
//  BOX->PvAll[ChanNum-1] = Pv;
//}
/*******************************************************************************
*                            clsDiSlot::PreResetVal                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for ResetFl parameter.                *
*           This method checks for Channel active and AV is NaN                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreResetVal(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl)
{
    if (a_ucAccLvl == ALVL_IUSER)               // if Chkpnt Restore in progress
    {                      
      if (*(UINT8 *)a_Writebuffer == ResetVal)  //   and new value = old
      {      
        return PA_OK;                           //     return OK 
      }
    }
    else if (DiType == DITYPE_ACCUM)            //   DiType is DITYPE_ACCUM
    {             
      return PA_OK;                             //     return OK 
    }
    return PA_OK;
}
/*******************************************************************************
*                            clsDiSlot::PreResetFl                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for ResetFl parameter.                *
*           This method checks for Channel active and AV is NaN                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreStartFl(UINT8 *a_writebuffer,UINT8 a_ucAccLvl)
{
    bOldStartFl = StartFl;
    if (DiType == DITYPE_ACCUM)               //   DiType is DITYPE_ACCUM
    {             
      *a_writebuffer = StartFl;
      //return PA_OK;                           //     return OK 
    }

    return PA_OK;
}
/*******************************************************************************
*                             clsDiSlot::PostStartFl                           *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostStartFl(UINT8)
{
  if (bOldStartFl != StartFl)  //new value != old
  {    
    if(bOldStartFl == true)
    {
      State = RUNNING;                      //Set State to RUNNING
    }
  }
}

/*******************************************************************************
*                            clsDiSlot::PreStopFl                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for StopFl parameter.                *
*           This method checks for Channel active and AV is NaN                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreStopFl(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl)
{
    bOldStopFl = StopFl;
    if (DiType == DITYPE_ACCUM)               //   DiType is DITYPE_ACCUM
    {             
      *a_Writebuffer = StopFl;
      //return PA_OK;                         //     return OK 
    }

    return PA_OK;                         //     return OK
}
/*******************************************************************************
*                             clsDiSlot::PostStopFl                            *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostStopFl(UINT8)
{
  if (bOldStopFl != StopFl)  //new value != old
  {    
    if(bOldStopFl == true)
    {
      State = STOPPED;                      //Set State to RUNNING
    }
  }
}
/*******************************************************************************
*                            clsDiSlot::PreResetFl                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for ResetFl parameter.                *
*           This method checks for Channel active and AV is NaN                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreResetFl(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl)
{
  bOldResetFl = ResetFl;
    if (DiType == DITYPE_ACCUM)               //   DiType is DITYPE_ACCUM
    {             
      *a_Writebuffer = ResetFl;
      //return PA_OK;                         //     return OK 
    }

    return PA_OK;                         //     return OK 
}

/*******************************************************************************
*                             clsDiSlot::PostResetFl                           *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostResetFl(UINT8)
{  
  //INT16 tmpAv;
  if (bOldResetFl != ResetFl)  //new value != old
  {    
    if(bOldResetFl == true)
    {
      //tmpAv = Av;
      Av = LastAv;
      OverFlow = false;
      AvTvFl = false;
    }
  }
}



#endif  // IOPTYPE_DI

#ifdef IOMTYPE_DISOE
/*******************************************************************************
*                           clsDiSlot::ProcessLatchedTimer                     *
*                           ======================                             *
* PURPOSE:     This function calculates LatchedTimer values.                   *
*              If timer is expired this slot is processed                      *
* ARGUMENTS:   None                                                            *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::ProcessLatchedTimer(VOID)
{
    if(DITYPE_LATCHED == DiType)
    {
        // decrement the timer if running,else do slot processing
        if(LatchTimer>0)
        {
            LatchTimer--;
        }
        else
        {
            ProcessSlot();
        }
    }// if DiType
}
/*******************************************************************************
*                           clsDiSlot::ProcessPvChgDly                         *
*                           ======================                             *
* PURPOSE:     This function calculates PvChgDlyTimer values.                  *
*              If timer is zero and there is an Pv change packet for this slot *
*              then post the event to PVCL as timer has expired                *
* ARGUMENTS:   None                                                            *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::ProcessPvChgDly(VOID)
{
    // start decrementing the PvChgDly once the timer started
    if( (PvChgDlyTimer >0) && (TRUE == bPvChgDlyEventSet) )
    {
        PvChgDlyTimer = PvChgDlyTimer -1;
    }
    if( (0==PvChgDlyTimer) && (TRUE == bPvChgDlyEventSet) )
    {
       if( DelayedPvChgPkt.CurrentState != DelayedPvChgPkt.LastReportedSt)
        {
            // if the Pv is different from last reoprted event, post the event
            // from fifo to PVCL as PvChgDly has expired with new state time stamp
            PVCLEVTRECORD PvchgPkt;
            UINT16 SyncId = DelayedPvChgPkt.SyncID;
            UINT32 TimeStamp = (UINT32)DelayedPvChgPkt.EventTimeStamp;
            PvchgPkt.Qualifier = EVENTTYPE_PVCLNORMAL;
            PvchgPkt.TimeStampFlag = TRUE;
            PvchgPkt.EventPktType = EVENTPACKET_SOEPVC;
            PvchgPkt.PVCL_PVCHANGEPKT.PVCHG_PV = DelayedPvChgPkt.CurrentState;
            PvchgPkt.PVCL_PVCHANGEPKT.PVCHGSOEslot = DelayedPvChgPkt.SOEslot;
            PvchgPkt.PVCL_PVCHANGEPKT.SyncIDHigh = (UINT8)(SyncId>>8);
            PvchgPkt.PVCL_PVCHANGEPKT.SyncIDLow = (UINT8)(SyncId);
            PvchgPkt.PVCL_PVCHANGEPKT.TimeStampHigh = (UINT8)(TimeStamp>>16);
            PvchgPkt.PVCL_PVCHANGEPKT.TimeStampMid = (UINT8)(TimeStamp>>8);
            PvchgPkt.PVCL_PVCHANGEPKT.TimeStampLow = (UINT8)(TimeStamp);
            BOX->AddNrmPVCLEvent(&PvchgPkt);
        } // if Pv is changed
        // load the Delay time to timer for the next cycle of PvChgDlyTimer
        PvChgDlyTimer = PvChgDly;
        bPvChgDlyEventSet = FALSE;
    }// PvChgDly has expired
}
/*******************************************************************************
*                           clsDiSlot::StorePvChgDlyPacket                     *
*                           ======================                             *
* PURPOSE:     This function stores Pv change packet                           *
* ARGUMENTS:   None                                                            *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::StorePvChgDlyPacket(BOOL PvState,UINT32 EvtTimeStmp,UINT16 SyncID)
{
    if(TRUE == bPvChgDlyEventSet)
    {
        // Set the flag to indicate Pv has changed
        DelayedPvChgPkt.SOEslot = ChanNum;
        DelayedPvChgPkt.CurrentState = PvState;
        DelayedPvChgPkt.EventTimeStamp = EvtTimeStmp;
        DelayedPvChgPkt.SyncID = SyncID;
    }
    else
    {
        // else, this is the first event detected after PvChgDly set
        // save the Pv state which used at the time of Timer Expire
        DelayedPvChgPkt.LastReportedSt = PvState;
        DelayedPvChgPkt.CurrentState = PvState;
        // set the flag to inidicate event state saved and to kick off the timer
        bPvChgDlyEventSet = TRUE;
    }
}
#endif

#if defined (IOMTYPE_UIO)

/*******************************************************************************
*                          clsDiSlot::GetSlotChkPntParamId                     *
*                           ==============================                     *
* PURPOSE:                                                                     *
*   Checks to see if the given parameter code is for the checkpoint /          *
*   configuration restore parameter.                                           *
* ARGUMENTS:                                                                   *
*   a_ucParamNumber - Parameter code to check                                  *
* RETURN:                                                                      *
*   TRUE if the given parameter code is for checkpoint / configuration restore *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsDiSlot::GetSlotChkPntParamId(VOID)
{
    return PARAMID_SLTCHKPNT;
}

/*******************************************************************************
*                           clsDiSlot::GetPtExecStParamId                      *
*                           =============================                      *
* PURPOSE:                                                                     *
*   Returns the parameter code for the point execution state parameter.        *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   Parameter code for the point execution state parameter                     *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsDiSlot::GetPtExecStParamId(VOID)
{
    return PARAMID_PTEXECST;
}

/*******************************************************************************
*                       clsDiSlot::GetLatestSlotChkPntVersion                  *
*                       =====================================                  *
* PURPOSE:                                                                     *
*   Returns the latest slot checkpoint version number                          *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   Latest slot checkpoint version number                                      *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsDiSlot::GetLatestSlotChkPntVersion(VOID)
{
    return LATEST_SLTCHKPNT_VERSION;
}

/*******************************************************************************
*                          clsDiSlot::PreInitPntType                           *
*                          =========================                           *
* PURPOSE:                                                                     *
*   This methods checks to see if the InitPntType parameter can be written     *
*   to the slot.                                                               *
* ARGUMENTS:                                                                   *
*   a_WriteBuffer - Pointer to data for the InitPntType parameter              *
*   a_ucAccLvl    - Access level of the InitPntType parameter.                 *
* RETURN:                                                                      *
*   Returns PA_OK if the parameter can be written.                             *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreInitPntType(UINT8 *a_Writebuffer, UINT8)
{
    // Value of the parameter being written
    PNTTYPE valueBeingWritten = *(PNTTYPE *)a_Writebuffer;

    // Return Value (assume failure)
    PASTATUS rtnValue = DO_ILLEGAL_VALUE;
    
    // If the value being written is PNTTYPE_DIGITALINPUT,
    // allow the store to occur.
    if (valueBeingWritten == PNTTYPE_DIGITALINPUT) 
    {
        rtnValue = PA_OK;
    }

    return rtnValue;
}
/*******************************************************************************
*                            clsDiSlot::PreAv                                  *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for AV parameter.                     *
*           This method checks for , access level check,PvSrcOpt&PvSourcecheck *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreAv(UINT8 *a_writebuffer, UINT8 a_ucAccLvl) 
{
    if(!IsPulseAccumCapable() && !(a_ucAccLvl & ALCK_ONPROC_IUSER)){
        return DO_FUNCTION_NOT_IMPLEMENTED;
    }

    if (PvSrcOpt == PVSRCOPT_ONLYAUTO) 
        return DO_READ_ONLY_PARAMETER;

    if (PvSource == PVSOURCE_AUTO)
        return DO_PVSOURCE_INVALID;

    //Access lock = prog OR cc OR umcc OR iuser
    if ((PvSource == PVSOURCE_MANUAL) && (a_ucAccLvl & ALCK_PROG_UMCC_CC_IUSER))
        return DO_PVSOURCE_INVALID;

    if (isnan(*(FLOAT32*)a_writebuffer)) return PA_OK;

    return PA_OK;

}

/*******************************************************************************
*                           clsDiSlot::PostAv                                  *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for AV parameter.                    *
*           (1) Checks for NaN,and checks Pv source.for Av Status              *
* ARGUMENTS:                                                                   *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostAv(UINT8) 
{
}

/*******************************************************************************
*                            clsDiSlot::PreC1                                  *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for C1 parameter.                     *
*           This method checks for NaN,and Zero                                *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreC1(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
{
    if(!IsPulseAccumCapable() && !(a_ucAccLvl & ALCK_ONPROC_IUSER)){
        return DO_FUNCTION_NOT_IMPLEMENTED;
    }

    FLOAT32 ufNewVal = *(FLOAT32*)a_Writebuffer;

    if(isnan(ufNewVal) || (ufNewVal == (FLOAT32)0.0))
        return DO_ILLEGAL_VALUE;
   
    return PA_OK;
}

/*******************************************************************************
*                            clsDiSlot::PreC2                                  *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for C2 parameter.                     *
*           This method checks for NaN,and Zero                                *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreC2(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
{
    if(!IsPulseAccumCapable() && !(a_ucAccLvl & ALCK_ONPROC_IUSER)){
        return DO_FUNCTION_NOT_IMPLEMENTED;
    }

    FLOAT32 ufNewVal = *(FLOAT32 *)a_Writebuffer;

    if(isnan(ufNewVal) || (ufNewVal == (FLOAT32)0.0))
       return DO_ILLEGAL_VALUE;

  return PA_OK;
}

/*******************************************************************************
*                            clsDiSlot::PreResetFl                             *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for ResetFl parameter.                *
*           This method checks for Channel active and AV is NaN                *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreResetFl(UINT8 *,UINT8 a_ucAccLvl) 
{
    if(!IsPulseAccumCapable() && !(a_ucAccLvl & ALCK_ONPROC_IUSER)){
        return DO_FUNCTION_NOT_IMPLEMENTED;
    }

    // check for channel active, if inactive return an error
    if (PTEXECST_INACTIVE == PtExecSt){
        return DO_STATE_MUST_BE_RUN;
    }

    // check for valid AV, if NaN return an error
    if(isnan(BOX->GetAv(ChanNum))){
        return DO_POINT_IS_IN_BADCTL;
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsDiSlot::PostResetFl                             *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for ResetFl parameter.               *
*           (1) incrments the ResetCount,and clears the AVRAW counter         *
* ARGUMENTS:                                                                   *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostResetFl(UINT8) 
{
    if(ResetFl == TRUE)
    {    
        // Increment the reset count
        BOX->IncrementResetCount(ChanNum);

        BOX->StoreAvRaw(ChanNum,0);
        FPGA.ClrCounter(ChanNum);

        //Clear the reset flag
        ResetFl = FALSE;
        BOX->StoreAvTvFl(ChanNum,FALSE);
        TvProc = FALSE;
    }
}
/*******************************************************************************
*                            clsDiSlot::GetAvPtr                               *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetAvPtr(VOID) { 
    return &(BOX->PcScanRec.ScanRec[ChanNum-PC_CHANNEL1].DIPC.Av);
}
/*******************************************************************************
*                            clsDiSlot::GetAvStsPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetAvStsPtr(VOID) { 
    return &(BOX->PcScanRec.ScanRec[ChanNum-PC_CHANNEL1].DIPC.AvSts);
}
/*******************************************************************************
*                            clsDiSlot::GetAvRawPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetAvRawPtr(VOID) { 
    return &(BOX->PcScanRec.ScanRec[ChanNum-PC_CHANNEL1].DIPC.AvRaw);
}
/*******************************************************************************
*                            clsDiSlot::GetAvRawStsPtr                         *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetAvRawStsPtr(VOID) { 
    return &(BOX->PcScanRec.ScanRec[ChanNum-PC_CHANNEL1].DIPC.AvRawSts);
}
/*******************************************************************************
*                            clsDiSlot::GetAvTvFlPtr                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetAvTvFlPtr(VOID) { 
    return &(BOX->PcScanRec.ScanRec[ChanNum-PC_CHANNEL1].DIPC.AvTvFl);
}
/*******************************************************************************
*                            clsDiSlot::GetTvPtr                               *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDiSlot::GetTvPtr(VOID) { 
    return &(BOX->PcScanRec.ScanRec[ChanNum-PC_CHANNEL1].DIPC.Tv);
}
/*******************************************************************************
*                            clsDiSlot::PreTv                                  *
*                            =================                                 *
* PURPOSE:  Pre Receiver-Beware function for TV parameter.                     *
*           This method checks for , access level check,PvSrcOpt&PvSourcecheck *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiSlot::PreTv(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) 
{
    if(!IsPulseAccumCapable() && !(a_ucAccLvl & ALCK_ONPROC_IUSER)){
        return DO_FUNCTION_NOT_IMPLEMENTED;
    }

    FLOAT32 tvNewVal = *(FLOAT32 *)a_Writebuffer;

    if(isnan(tvNewVal))
       return DO_ILLEGAL_VALUE;

    if(isnan(BOX->GetAv(ChanNum)))
      return DO_POINT_IS_IN_BADCTL;

    return PA_OK;
}

/*******************************************************************************
*                           clsDiSlot::PostTv                                  *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for Tv parameter.                    *
*           (1) sets the tvproc flag                                           *
* ARGUMENTS:                                                                   *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiSlot::PostTv(UINT8) 
{
    BOX->StoreTvForSync(ChanNum,BOX->GetTv(ChanNum));
    TvProc = TRUE;
}
#endif

#if defined (IOPTYPE_DI)
/*******************************************************************************
*                           clsDiSlot::PvclEntryRoutine                        *
*                           ======================                             *
*******************************************************************************/
VOID clsDiSlot::PvclEntryRoutine(VOID){
  ONOFF CurPv = BOX->GetPv(ChanNum);
  PVCLEVTRECORD PvclEvtRecord;
  if(EVTOPT_NONE != EvtOpt)
  {
    if(EVTOPT_EIP == EvtOpt)
    {      
      PvclEvtRecord.EventPktType = EEENTPACKET_EIP;
      PvclEvtRecord.TimeStampFlag = 0;
      PvclEvtRecord.PVCL_PVCHANGEPKT.PVCHGSOEslot = ChanNum;
      PvclEvtRecord.PVCL_PVCHANGEPKT.PVCHG_PV = CurPv;
    }
    else if((EVTOPT_EIPSOE == EvtOpt)||(EVTOPT_SOE == EvtOpt))
    {
      UINT32 tmpTimeStamp = BOX->GetFrcCount();
      PvclEvtRecord.EventPktType = EVENTPACKET_IOLTSB;
      PvclEvtRecord.TimeStampFlag = 1;
      PvclEvtRecord.PVCL_PVCHANGEPKT.PVCHGSOEslot = ChanNum;
      PvclEvtRecord.PVCL_PVCHANGEPKT.PVCHG_PV = CurPv;
      PvclEvtRecord.PVCL_PVCHANGEPKT.TimeStampHigh = (UINT8)(tmpTimeStamp>>16);
      PvclEvtRecord.PVCL_PVCHANGEPKT.TimeStampMid = (UINT8)(tmpTimeStamp>>8);
      PvclEvtRecord.PVCL_PVCHANGEPKT.TimeStampLow = (UINT8)(tmpTimeStamp);
    }    
    BOX->AddNrmPVCLEvent(&PvclEvtRecord);
  }

}

/*******************************************************************************
*                           clsDiSlot::AlarmProcessorDI                        *
*                           ======================                             *
*******************************************************************************/
VOID clsDiSlot::AlarmProcessorDI(VOID)
{  
    // added to fix the PAR# 1-GJ6MQXN
    if (PtExecSt != PTEXECST_ACTIVE) return;

    if (AlmOpt!=ALMOPT_NONE)
    {
        if(AlmOpt==ALMOPT_OFFNORMAL)
          ProcessOffNormal();
        else
        {
          //if(AlmOpt==ALMOPT_CHNGOFST)
            ProcessChangeOfState();
        }
        //else
        //{
        //    if(AlmOpt==ALMOPT_CHNGOFST)
        //    {
        //      ProcessOffNormal();
        //      //ProcessChangeOfState();
        //    }
        //    ProcessChangeOfState();
        //}
    }
}

/*******************************************************************************
*                           clsDiSlot::AlarmEvents                             *
*                           ======================                             *
* modified this function to fix the folloing PARs
* PAR# 1-GJ6MQXN - DI & DI-24 inactive alarm icon is not changing to grey when channel is inactivated.
* PAR# 1-GLD5D07 - OFF-Normal alarm icon shows gray color (inactive alarm) after removal primary IOP of DI-24.
* PAR# 1-GJDDRTJ - COS Alarms reappearing in alarm summary with the new time stamp when reinserting the backup IOP.
* PAR# 1-GFATMDB - DI-24V IOP OFFNORMAL alarm not reporting in overflow condition and unexpected behaviors may occur.
*******************************************************************************/
// modified below changes to fix PAR# 1-GJ6MQXN (DI & DI-24 inactive alarm icon is not changing to grey when channel is inactivated)
BOOL clsDiSlot::AlarmEvents(EVENTTYPE a_EventType)
{
    ONOFF CurPv = BOX->GetPv(ChanNum);
    BOOL CurAlm = BOX->GetAlmAll(ChanNum);
    ALARMEVENTRECORD AlarmEvent;
    UINT8 u8ChangeInAlarms;
    
    // during primary takeover, alarm bits may clear, hence retaining last state for its alarm recovery
    if(EVENTTYPE_RECOVERY == a_EventType) {

        AlmInfo.Bit.ucOffNormFl = OffNrmfl;
    }
    
    u8ChangeInAlarms = (EVENTTYPE_NORMAL == a_EventType) ? (AlmInfo.ucByte ^ AlarmLrs.ucByte) : AlmInfo.ucByte;

    // Masking State of change alarm bit to, do not generate seperate alarm along with ON/OFF cos alarms
    u8ChangeInAlarms &= 0xFE;

    for (UINT8 u8Mask = 2; u8Mask < 0x80; u8Mask*=2)
    {
        if(u8ChangeInAlarms & u8Mask) {

            // added to fix PAR# 1-98FQ9K3 (DI Module Alarm Reporting and RTN is not consistent)
            AlarmEvent.NotUsed       = 0;

            AlarmEvent.ContactCutout = ContCut;
            AlarmEvent.Qualifier     = a_EventType;
            if(AlmOpt==ALMOPT_CHNGOFST)
            {
                //AlarmEvent.Pv = AlmInfo.Bit.ucStateFl;
                AlarmEvent.Pv = CurPv;
                AlarmEvent.Direction = EVENTSTATE_ALARM;
                AlarmEvent.AlarmCode = CHNGOFSTATE_ALM;
            }
            else
            {
                AlarmEvent.Pv = CurPv;
                AlarmEvent.Direction = (AlmInfo.Bit.ucOffNormFl) ? EVENTSTATE_ALARM : EVENTSTATE_RETURN;
                AlarmEvent.AlarmCode = OFFNORMAL_ALM;
            }
            AlarmEvent.EventPacket = EVENTPACKET_DI;
            AlarmEvent.ChannelNumber = ChanNum;
            AlarmEvent.SysOrBracket  = FALSE;
            
            if (BOX->AddAiAlarmEvent(&AlarmEvent) == TRUE)
            {
               if (AlmInfo.ucByte & u8Mask)
               {
                   AlarmLrs.ucByte |= u8Mask;
               }
               else
               {
                   AlarmLrs.ucByte &= ~u8Mask;
               }
            }
        }
    }
    return TRUE;
}


/*******************************************************************************
*                           clsDiSlot::ProcessOffNormal                        *
*                           ======================                             *
* modified this function to fix following PARs,
* PAR# 1-GJ6MQXN - DI & DI-24 inactive alarm icon is not changing to grey when channel is inactivated.
* PAR# 1-GLD5D07 - OFF-Normal alarm icon shows gray color (inactive alarm) after removal primary IOP of DI-24.
* PAR# 1-GFATMDB - DI-24V IOP OFFNORMAL alarm not reporting in overflow condition and unexpected behaviors may occur.
*******************************************************************************/
VOID clsDiSlot::ProcessOffNormal(VOID)
{
  if(DlyTimer!=0)
  {
    if(BOX->GetOneSecFlagDI(ChanNum))
    {
      DlyTimer--;
      BOX->ResetOneSecFlagDI(ChanNum);
    }
  }
  else
  {
      ONOFF CurPv = BOX->GetPv(ChanNum);

      if(PvNormal == CurPv)
      {
          // Normal condition occured
          if(TRUE == OffNrmfl)
          {
#if defined(PMIO_DEBUG) && (0)
            DebugPort.PrintString("\n\rT1=%l,", (UINT32)DlyTimer);
#endif
            BOX->SetAlmAll(ChanNum, OFF);
            HighAl = CLEAR_ALARM;
            AlmInfo.Bit.ucOffNormFl = FALSE;
            if (TRUE == AlarmEvents(EVENTTYPE_NORMAL))
            {
              OffNrmfl = FALSE;              
            }
          }
      }
      else
      {
          // Offnormal condition occured
          if(FALSE == OffNrmfl)
          {
            DlyTimer = DelayTime;
#if defined(PMIO_DEBUG) && (0)
            DebugPort.PrintString("\n\rT2=%l,",(UINT32)DlyTimer);
#endif
            BOX->SetAlmAll(ChanNum, ON);
            HighAl = OFFNORM_ALARM;
            AlmInfo.Bit.ucOffNormFl = TRUE;
            if (TRUE == AlarmEvents(EVENTTYPE_NORMAL))
            {
              OffNrmfl = TRUE;
            } 
          }
      }
  }
}

/*******************************************************************************
*                           clsDiSlot::ChangeOfState                        *
*                           ======================                             *
* modified this function to fix the following PAR,
* PAR# 1-GJDDRTJ - COS Alarms reappearing in alarm summary with the new time stamp when reinserting the backup IOP.
*******************************************************************************/
VOID clsDiSlot::ProcessChangeOfState(VOID)
{  
  BOOL CurPv;
  CurPv = BOX->GetPv(ChanNum);
  
 //new alarms

  if(CosTimer!=0)
  {
    if(BOX->GetOneSecFlagDI(ChanNum))
    {
        CosTimer--;
        BOX->ResetOneSecFlagDI(ChanNum);
    }
  }
  else //if(CosTimer==0)
  {
    if(AlarmLrs.Bit.ucStateLrs ^ CurPv)
    {
        AlarmLrs.Bit.ucStateLrs = CurPv;

        //Setting LRS bits, because cos alarms are tobe generated without returning the alarm
        if(AlarmLrs.Bit.ucStateLrs)
        {
            AlarmLrs.Bit.ucOnLrs = TRUE;
        }
        else //if(AlarmLrs.Bit.ucStateLrs == OFF)
        {
            AlarmLrs.Bit.ucOffLrs = TRUE;
        }

        CosTimer = DelayTime;        
    }
  }

  if((TRUE == AlarmLrs.Bit.ucOffLrs) 
  || (TRUE == AlarmLrs.Bit.ucOnLrs))
  { 
    AlarmEvents(EVENTTYPE_NORMAL);
  }

}

#endif


