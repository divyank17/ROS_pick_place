/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uioboxslot.cpp                                              *
*    Description : Class clsUioBoxSlot definition.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "tracelog.hpp"
#include "uioboxslot.hpp"
#ifdef DEBUG
#include "debug.hpp"
#endif

/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/
extern clsIol Iol;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/

const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_DOVRCRNT,
    SF_OUTPUTFL,
    SF_OPENWIRE,
    SF_RDBKRGDIAGFL,
    SF_HARTCHANFAIL,
    SF_UNKNOWN, 
    SF_UNKNOWN,
    SF_UNKNOWN
};

const UINT8 clsUioBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_TEMPHILM,
    PARAMID_TEMPLOLM,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsUioBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 7 }
};


UINT8 clsUioBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

const UINT8 clsUioBoxSlot::RedParams[] = {
    PARAMID_DBVALID,
    PARAMID_IOLDEVTYPE,
    PARAMID_MODLTYPE,
    PARAMID_MAXSLOTS,
    0 // Terminator
};

const BOXPARAMINFO clsUioBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       // 03 ModStatType
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 30 HAUTODETBLND (not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      // 35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   // 37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          // 38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          // 39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          // 40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          // 41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          // 43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      // 44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    // 45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           // 47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       // 48 AppBuildNo
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 50
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       // 51 BoxSfBits
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        // 52 BoxSfLrs
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       // 53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          // 54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         // 55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              // 56 Dpa
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              // 57 Dsa
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      // 58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      // 59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               // 60 Ba
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                // 61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         // 62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        // 63 HwRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,TRUE,                        // 64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          // 65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            // 66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,PreModStat1,PostModStat1,GetModStat1Ptr,TRUE,    // 67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         // 68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,TRUE,                           // 69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              // 70 NthExt
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 71 SuprCtrl (Not supported in UIO)
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     // 72 SwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 73 ToknStll (Not supported in UIO)
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     // 74 TstFunct
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        // 75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          // 76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,PostRedData,GetRedDataPtr,FALSE,      // 77 RedData
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           // 78 DbValid
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,PostSfActionTbl,GetSfActionTblPtr,FALSE,      // 79 SfActionTbl
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 80 CalibAll (Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 81
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 82 Freq6050 (Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 92 SoAll (DO only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 101 PvAll (DI only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 102 PvChApp (DI only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 103 PvChRem (DI only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 104 StsInitCpy (DO), PvStAll (DI) (Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 105 OutRgAll(DO), PvScanRec AI) (Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 110 HAutoDet (AI/DO), BadPvAll (DI) (Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 112
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetLpBkStatPtr,FALSE,                         // 113 Loop back Status (Factory Support)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 114
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 115
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                         // 116 MaxSlots
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 120
    DT_BLIND,64,AT_MBYTE,ALCK_VIEW,0,0,GetHGCfgChgCntPtr,FALSE,                     // 121 HGCFGCHG
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetHGChngFlPtr,FALSE,                        // 122 HGChngFl 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 123
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetHCuAvailBoard1Ptr,FALSE,                 // 124 HCuAvail (Board 1 modem resources)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 134
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetHGDevStPtr,FALSE,                         // 135 HGDevSt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetHCuAvailBoard2Ptr,FALSE,                 // 136 HCuAvail2 (Board 2 modem resources)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 142
    DT_BLIND,7,AT_PSET,ALCK_VIEW,PreCheckPoint,0,GetCheckPointPtr,TRUE,             // 143 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 152 OpScanRec (AO only, Not supported in UIO)
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,PreHADCEnable,PostHADCEnable,GetHADCEnablePtr,FALSE,// 153 HADCEnable
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHADCStatusPtr,FALSE,                       // 154 HADCStatus
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 157
    DT_BLIND,66,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                        // 158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     // 160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostStatReset,GetStatResetPtr,FALSE,  // 161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       // 165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     // 166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      // 167 Tracelevel
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,PreDiMode,0,GetDiModePtr,FALSE,                     // 168 DiMode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 169
    DT_BLIND,4,AT_MBYTE,ALCK_OPER,PreSetConfData,PostSetConfData,GetSetConfPtr,FALSE, // 170 HartTestData(Factory Support)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 171 SOEHandler OverRuns (DISOE only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 172 SOEHandler max over time (DISOE only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 173 SOEHandler last overrun time (DISOE only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 174 Reset SOEHandler Overrun data (DISOE only, Not supported in UIO)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 201
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetTempCurPtr,FALSE,                        // 202 TempCur
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetTempMaxPtr,FALSE,                        // 203 TempMax
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetTempMinPtr,FALSE,                        // 204 TempMin
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 207
    DT_INT16,2,AT_MBYTE,ALCK_ENGR,PreTempHiLm,PostTempLm,GetTempHiLmPtr,TRUE,       // 208 TempHiLm
    DT_INT16,2,AT_MBYTE,ALCK_ENGR,PreTempLoLm,PostTempLm,GetTempLoLmPtr,TRUE,       // 209 TempLoLm
    DT_BLIND,PVSCANRECSIZE,AT_MBYTE,ALCK_VIEW,0,0,GetPvScanRecPtr,FALSE,            // 210 PvScanRec
    DT_BLIND,PCSCANRECSIZE,AT_MBYTE,ALCK_VIEW,0,0,GetPcScanRecPtr,FALSE,            // 211 PcScanRec
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 238 CtlTog (DO only)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 239 ComTog (DO only)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 240
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,0,0,GetCtlTogPtr,FALSE,                            // 241 CtlTog
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,0,0,GetComTogPtr,FALSE,                            // 242 ComTog
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         // 255
};
/*******************************************************************************
*                           clsUioBoxSlot::clsUioBoxSlot                       *
*                           ==========================                         *
* PURPOSE:    Constructor                                                      *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsUioBoxSlot::clsUioBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType, MAXSLOTS) 
{
    // ensure correct size of the PvScanRec structures
    _CompileAssert(CHAN_SCANRECSIZE >= sizeof(AIHPVSCANREC))
    _CompileAssert(CHAN_SCANRECSIZE >= sizeof(AOHPVSCANREC))
    _CompileAssert(CHAN_SCANRECSIZE >= sizeof(DIPVSCANREC))
    _CompileAssert(CHAN_SCANRECSIZE >= sizeof(DOPVSCANREC))

    // Initialize database parameters.

    for (UINT8 ucChanNum = 1; ucChanNum <= MAXSLOTS; ucChanNum++)
    {
        InitializeChannelData(ucChanNum, PNTTYPE_NOTCONFIGURED);
        InitHGCfgChgCnt(ucChanNum);
        InitHGChngFl(ucChanNum);
        ResetHADCEnable(ucChanNum);
        SetHADCStatus(ucChanNum,HART_DATA_UNKNOWN);
    }

    // Initialize DI Pulse Counting scan record
    for(UINT8 ucChanNum = PC_CHANNEL1; ucChanNum<=PC_CHANNEL4; ucChanNum++)
    {
        FPGA.InitializeHardwareForPulseCount(ucChanNum);
        InitializeDiPcScanRec(ucChanNum);
    }

    HwInfo.ProductType = PRODTYPE_UIO;
    HwInfo.ProductCode = PRODCODE_UIO;

    bCalibrationGood  = FALSE;
    bRefVoltagesGood  = FALSE;

    CycleCounter = 1;
    CalibrationCheckCounter = 1;
    DoPinDiagnosticCounter = 1;
    DoLineMonitoringDiagnosticCounter = 1;

    ucCurrentSlotNum   = 1;
    bSampleAllChannels = TRUE;   // After module startup sample and convert all inputs
    bCheckCalibration  = FALSE;  // Module is calibrated on startup, wait 10 seconds
    bExecuteAoReadbackDiagnostic = FALSE;
    bExecuteDoPinDiagnostic = FALSE;
    bExecuteDoLineMonitoringDiagnostic = FALSE;
    bExecuteAoDacFullLoadDiagnostic = FALSE;
    bScheduleAoDacFullLoadDiagnostic = FALSE;
    ucIolChannelToExecuteAoDacFullDiagnostic = 0;
    ucChannelToExecuteAoDacFullDiagnostic = 0;

    bScheduleAppColdInit = FALSE;

    // No channels
    DiChannelMask  = 0;
    AoChannelMask  = 0;
    DoChannelMask  = 0;
    DoDiagChannelState = 0;

    TempCur = NaN;
    TempMax = NaN;
    TempMin = NaN;
    TempHiLm = kMaxTempAlarmLimit;
    TempLoLm = kMinTempAlarmLimit;

    // DI Defaults
    DiMode = DIMODE_NORMAL;
    LatchTimeCnt = LATCHTIMECONST;  // Defaults to value for DIMODE = Normal

    // AIH Defaults
    HCuAvail[0] = 100.0;
    HCuAvail[1] = 100.0;

    DoOutputBuffer1 = 0;
    DoOutputBuffer2 = 0;
    DoOverCurrent   = 0;

    // AO defaults
    //Both the Modules will come as secondary
    ModStat3.OutCtl = OUTCTL_PARTNER;
    bDisOpInternlUpdte = FALSE;    

    AoDisableOutputFailFO_Mask = 0xFFFFFFFF;
    DoDisableOutputFailFO_Mask = 0xFFFFFFFF;
    DiDisableOpenWireFO_Mask   = 0xFFFFFFFF;
    DoDisableOpenWireFO_Mask   = 0xFFFFFFFF;
    AiDisableOpenWireFO_Mask   = 0xFFFFFFFF;

    HiTempAlarmThrottleCount = 0;
    LoTempAlarmThrottleCount = 0;

    // Factory test suppport varaibles for Hart loopback test
    HartTestData.NumOfChannels   = (UINT8)ONECHANNEL;
    HartTestData.StartChannelNum = (UINT8)1;
    ucCurrentChannel = (UINT8)1;
    ucNextChannel    = (UINT8)1;

    // AO DAC Full Diagnostics failover mask.
    // initialize the mask to indicate no AO DAC faults detected.
    AoDisableDacFullFailFO_Mask = 0;
}

/*******************************************************************************
*                          clsUioBoxSlot::GetDataType                          *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsUioBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsUioBoxSlot::GetAccessType                        *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsUioBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                          clsUioBoxSlot::GetParamSize                         *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsUioBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                          clsUioBoxSlot::GetParamPtr                          *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsUioBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                         clsUioBoxSlot::GetAccessLock                         *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsUioBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                    clsUioBoxSlot::GetIsDbChecksumed                          *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsUioBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                        clsUioBoxSlot::VerifyControlState                     *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsUioBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}
/*******************************************************************************
*                        clsUioBoxSlot::ExecutePreFunction                     *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsUioBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsUioBoxSlot::ExecutePostFunction                    *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
} 
/*******************************************************************************
*                         clsUioBoxSlot::PreCheckPoint                         *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsUioBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    return PA_OK;
}

/*******************************************************************************
*                         clsUioBoxSlot::AppInitialization                     *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::AppInitialization(VOID)
{   
    // initialize the hardware
    FPGA.PerformStartupInit();

    // calibrate both I/O boards
    FPGA.StartupCalibrate(eIoBoard1);
    FPGA.StartupCalibrate(eIoBoard2);
    bCalibrationGood = FPGA.IsCalibrationGood(eIoBoard1) && FPGA.IsCalibrationGood(eIoBoard2);

    // report calibration softfail if board 1 or board 2 did not successfully calibrate
    AddSoftfailEvent(EVENTTYPE_NORMAL, SF_ADOUTCAL, !bCalibrationGood, 0);

    // seed the reference voltage running averages for calibration
    Avg4v096[eIoBoard1].reset(FPGA.Read_BoardVoltage(eIoBoard1, e4V096BoardVoltage));
    Avg4v096[eIoBoard2].reset(FPGA.Read_BoardVoltage(eIoBoard2, e4V096BoardVoltage));

    // wait about 600msec to allow the hardware to settle
    for (UINT8 ucCount = 30; ucCount > 0; ucCount--)
    {
        IdleWait(20000);
    }

    // negotiate Primary/Secondary role
    while (!SwitchInit());
}

/*******************************************************************************
*                         clsUioBoxSlot::AppStcProcessing                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::AppStcProcessing(VOID)
{
    // if DSA was cleared, we must cold initialize
    if (bScheduleAppColdInit)
    {
        bScheduleAppColdInit = FALSE;
        AppColdInit();
    }

    // FPGA continually runs the CRC diagnostic.  Check if the test has failed.
    // This check is disabled until the HW team fixes the CRC readback check in the FPGA (1-S49ZTL)
    FPGA.TestFPGAConfigurationReadback();

    ManageRedIO(); // Process redundancy inputs and state

    // Validate the control on screws
    if (CheckRedData(REDDATA_REDCFG) || (!ModStat3.OutCtl && Iol.AmPrimary())) {
        CheckFailOverCondition();
    }

    // initialize the "disable failover" flags, will be cleared by the output 
    // diagnostics that are executed in later cycles
    if (1 == CycleCounter)
    {        
        AoDisableOutputFailFO_Mask = 0xFFFFFFFF;
        DoDisableOutputFailFO_Mask = 0xFFFFFFFF;
        DiDisableOpenWireFO_Mask   = 0xFFFFFFFF;
        DoDisableOpenWireFO_Mask   = 0xFFFFFFFF;
        AiDisableOpenWireFO_Mask   = 0xFFFFFFFF;
    }

  /* Comments to support the review
    // AppStcProcessing is done across a 50 msec macrocycle. 
    // An independent cycle counter (CycleCounter) is used to track cycles within the macrocycle.  This gives the ability to control the actions of the next execution
    // without making assumptions about the scheduler's 10 msec timer.  For instance, if the reference voltages go bad for a few seconds we need to be able to be able to 
    // restart the macrocycle when the ref voltages are back within operational ranges.
    // CycleCounter is used to determine if it is time to sample all inputs or just digital inputs and which block of AI channels need to be processed in this cycle.

    // Digital Inputs are processed every 10 msec.  Estimated time for processing max 1.5msec.
    // Analog Inputs are processed in groups of 7 every 10 msec.  
    // The last cycle only processes 4 AIs.  Recalibration should be done on this cycle.
    //
    // All Inputs must be sampled every 50msec.
    // Only Digital Inputs are sampled every 10 msec in between.
    // Reference voltages must be checked every time Inputs are sampled.  
  End of comments to support the review */
    
    // Issue input scan conversions - This is mandatory at the start of each cycle to prepare the FPGA registers.
    CommandConversions();

    // Reference voltages must be verified every cycle that inputs are sampled
    MonitorCalibrationAndReferenceVoltages();
    
    if (bCalibrationGood && bRefVoltagesGood)
    {
        // Process all Digital Input channels every 10 msec
        DigitalInputProcessing();

        // All analog input channels will be processed in 50 msec or less.  
        // On the first cycle the inputs are sampled and 7 channels are processed.
        // Each 10 msec cycle 7 more channels are processed until all AI channels are complete.
        // The scan record will be updated in such a way that all values are from the same same period.
        AnalogInputProcessing();

        // Process Digital Output channels
        DigitalOutputProcessing();

        if (bExecuteAoReadbackDiagnostic)
        {
            // Get the channel number set by the iolink for executing the Ao Dac Full diagnostic .
            ucChannelToExecuteAoDacFullDiagnostic = ucIolChannelToExecuteAoDacFullDiagnostic;

            ExecuteAoReadbackDiagnostic();
        }

        if (bExecuteDoPinDiagnostic)
        {
            ExecuteDoPinDiagnostic();
        }
        
        if (bExecuteDoLineMonitoringDiagnostic)
        {
            ExecuteDoLineMonitoringDiagnostic();
        }
    }
    else
    {
        // Ref voltage or calibration failure.
        // Set all PVs to Bad.
        // Stop scannning until these checks pass.  Reset cycle count and current AI channel count.
        SetBadPVs();
    }

    MaintainCounters();

    // Enable the failover only when the output failure diagnostics 
    // passed at least once for all the channels.
    if ((0 == DoDisableOutputFailFO_Mask)  &&   // all DO diagnostics passed
        (0 == AoDisableOutputFailFO_Mask)  &&   // all AO diagnostics passed
        (0 == AoDisableDacFullFailFO_Mask) &&   // all AO DAC Full diagnostics passed
        (Iol.AmPrimary()) &&                    // module is primary
        (REDSTATE_SYNCD == GetRedState()))      // modules are sync'd
    {
        EnableOutputFailFO();
    }
    
    // Enable the failover only when the open wire diagnostics 
    // passed at least once for all the channels.
    if ((0 == DiDisableOpenWireFO_Mask) &&    // all DI diagnostics passed
        (0 == DoDisableOpenWireFO_Mask) &&    // all DO diagnostics passed
        (0 == AiDisableOpenWireFO_Mask) &&    // all AI diagnostics passed
        (Iol.AmPrimary()) &&                  // module is primary
        (REDSTATE_SYNCD == GetRedState()))    // modules are sync'd   
    {
        EnableOpenWireFO();
    }
}

VOID clsUioBoxSlot::CommandConversions(VOID)
{
    // Step 1 - Initiate Reference Voltage Scan Requests before processing input values
    // -------------------------------------------------------------------------
    FPGA.IssueScanRequest(eIoBoard1, eVoltages, SCAN_REF_VOLTAGES);
    FPGA.IssueScanRequest(eIoBoard2, eVoltages, SCAN_REF_VOLTAGES);       

    // Step 2 - Wait for Reference Voltage Conversions on both boards (122.6uS)
    // -------------------------------------------------------------------------
    while(!FPGA.IsScanComplete(eIoBoard1) || !FPGA.IsScanComplete(eIoBoard2)){};

    if(bSampleAllChannels)
    {
        // Step 3 - Command FPGA to scan analog and digital inputs on both boards
        // -------------------------------------------------------------------------
        FPGA.IssueScanRequest(eIoBoard1, eFilteredAnalogCurrent, SCAN_ALL_CHANNELS);
        FPGA.IssueScanRequest(eIoBoard2, eFilteredAnalogCurrent, SCAN_ALL_CHANNELS);
    }
    else
    {
        // On cycles 2-5 command FPGA to scan digital inputs on both boards
        FPGA.IssueScanRequest(eIoBoard1, eFilteredAnalogCurrent, (UINT16)(DiChannelMask & 0x0000ffff));
        FPGA.IssueScanRequest(eIoBoard2, eFilteredAnalogCurrent, (UINT16)((DiChannelMask >> 16) & 0x0000ffff));
    }
    // Wait for Input Conversions on both boards (max 272 uSec)
    // -------------------------------------------------------------------------
    while(!FPGA.IsScanComplete(eIoBoard1) || !FPGA.IsScanComplete(eIoBoard2)){};

    //--------------------------------------------------------------------------
    // Scan current for AO and DO diagnostics
    //--------------------------------------------------------------------------
    if ((bExecuteAoReadbackDiagnostic) || 
        (bExecuteDoLineMonitoringDiagnostic))
    {
        // Analog Current Scan Mask
        UINT32 aCurrentMask = 0;
        
        // If an AO diagnostic needs to run, add the AO channels to mask
        if (bExecuteAoReadbackDiagnostic)
            aCurrentMask |= AoChannelMask;
            
        // If a DO diagnostic needs to run, add the DO channels to the mask
        if (bExecuteDoLineMonitoringDiagnostic)
            aCurrentMask |= DoChannelMask;
         
        if (aCurrentMask > 0)
        {        
            //-------------------------------------------------
            // Scan the analog current (unfiltered)
            //-------------------------------------------------
            
            // Issue scan for channels 1 - 16
            FPGA.IssueScanRequest(eIoBoard1, eAnalogCurrent, 
                (UINT16)(aCurrentMask & 0x0000ffff));
                
            // Issue scan for channels 17 - 32 
            FPGA.IssueScanRequest(eIoBoard2, eAnalogCurrent, 
                (UINT16)((aCurrentMask >> 16) & 0x0000ffff));
            
            // Wait for the scan to complete...
            while(!FPGA.IsScanComplete(eIoBoard1) || !FPGA.IsScanComplete(eIoBoard2)){};
        }
        
        if (bExecuteDoLineMonitoringDiagnostic)
        {
            // Clear DO diagnostic channel states (all channels off)
            DoDiagChannelState = 0;
            
            // Find out which DO channels have been commaned to be on...
            for (unsigned int ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++)
            {
                if(PvScanRec.pntType[ucChannel-1] == PNTTYPE_DIGITALOUTPUT)
                {
                    if (FPGA.ReadDigitalOutput(ucChannel))
                    {
                        SetBit(&DoDiagChannelState, ucChannel - 1);
                        // if output ganged enabled for the current channel,
                        // we will need measure digital current for adjacent channels 
                        if (DO_SLOT(ucChannel)->GetEnblGangedOutputs())  
                        {   
                            UINT8 nNumOfChnlsGanged = DO_SLOT(ucChannel)->GetNumOfChnlsGanged();
                            for(UINT8 nChanCount=1;nChanCount<nNumOfChnlsGanged;nChanCount++)
                            {
                                SetBit(&DoDiagChannelState, (ucChannel+nChanCount) - 1);
                            }
                        }
                    }
                }
            }

            if (DoChannelMask > 0)
            {
                //----------------------------------------------
                // Scan the digital current for all DO channels
                //----------------------------------------------
                
                // Issue scan for channels 1 - 16
                FPGA.IssueScanRequest(eIoBoard1, eDigitalCurrent, 
                    (UINT16)(DoChannelMask & 0x0000ffff));
                
                // Issue scan for channels 17 - 32 
                FPGA.IssueScanRequest(eIoBoard2, eDigitalCurrent, 
                    (UINT16)((DoChannelMask >> 16) & 0x0000ffff));        
            
                // Wait for the scan to complete...
                while(!FPGA.IsScanComplete(eIoBoard1) || !FPGA.IsScanComplete(eIoBoard2)){};   
            }
        }
    }
}


// Pre-condition:  Reference Voltage scan has completed
VOID clsUioBoxSlot::MonitorCalibrationAndReferenceVoltages()
{
    // Check if either board has a bad ref voltage
    // -------------------------------------------------------------------------
    bRefVoltagesGood = (FPGA.AreRefVoltagesGood(eIoBoard1) && FPGA.AreRefVoltagesGood(eIoBoard2));

    // Report vreffail softfail if board 1 or board 2 reference voltages are not within operational limits.
    AddSoftfailEvent(EVENTTYPE_NORMAL, SF_VREFFAIL, !bRefVoltagesGood, 0);

    // update the reference voltage running average for calibration
    Avg4v096[eIoBoard1].update(FPGA.Read_BoardVoltage(eIoBoard1, e4V096BoardVoltage));
    Avg4v096[eIoBoard2].update(FPGA.Read_BoardVoltage(eIoBoard2, e4V096BoardVoltage));

    // Every 10 seconds and if Reference Voltage are good then check if calibration is required
    if (bCheckCalibration)
    {
        // If reference voltage failure then calibration cannot be considered valid
        bCalibrationGood = bRefVoltagesGood;

        if (bRefVoltagesGood)
        {
            for (int ucBoardNum = 0; ucBoardNum < eMaxNumIoBoards; ucBoardNum++)
            {
                // maintain calibration
                FPGA.RuntimeCalibrate((IOBOARD)ucBoardNum, Avg4v096[ucBoardNum].average());

                // check for calibration issue
                bCalibrationGood = bCalibrationGood && FPGA.IsCalibrationGood((IOBOARD)ucBoardNum);
            }
        }

        // Report calibration softfail
        AddSoftfailEvent(EVENTTYPE_NORMAL, SF_ADOUTCAL, !bCalibrationGood, 0);
    }
}


// Prepare counter and flags for the next iteration through AppStcProcessing
VOID clsUioBoxSlot::MaintainCounters(VOID)
{
    // If calibration and reference voltage checks pass then perform normal processing.
    // If either are bad AppStcProcessing should just continue to monitor the reference voltages
    // until they are normal again.
    if(bCalibrationGood && bRefVoltagesGood)
    {
        // Cycle counts are 1-5.  If this is the 4th cycle set up the 5th cycle to do calibration checks.
        // This will allow recabliration attempts to happen in the least loaded cycle.
        if((CalibrationCheckCounter >= CALIB_CHECK_CYCLECOUNT) && (4 == CycleCounter))
        {
            bCheckCalibration = TRUE;
            CalibrationCheckCounter = 0;
        }
        else
        {
            bCheckCalibration = FALSE;
            CalibrationCheckCounter++;
        }

        if((DoPinDiagnosticCounter >= PIN_DIAG_CYCLECOUNT) && (4 == CycleCounter))
        {       
            bExecuteDoPinDiagnostic = TRUE;
            DoPinDiagnosticCounter = 0;
        }
        else
        {
            bExecuteDoPinDiagnostic = FALSE;
            DoPinDiagnosticCounter++;
        }

        if((DoLineMonitoringDiagnosticCounter >= DO_LINE_MONITORING_CYCLECOUNT) && (4 == CycleCounter))
        {    
            // Only scan inputs/run diagnostic if we are the primary
            if ((OUTCTL_MINE == ModStat3.OutCtl)&&(Iol.AmPrimary()))
            {
                bExecuteDoLineMonitoringDiagnostic = TRUE;
            }
            else
            {
                // No control on screws. Return SF to Normal 
                for(int ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++)
                {
                    if(PvScanRec.pntType[ucChannel-1] == PNTTYPE_DIGITALOUTPUT)
                    {
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, FALSE, ucChannel);
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, FALSE, ucChannel);
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_DOVRCRNT, FALSE, ucChannel);
                        SetOverCurrent(ucChannel, FALSE);
                        if (DO_SLOT(ucChannel)->GetEnblGangedOutputs())
                        {
                            UINT8 nNumOfChnlsGanged = DO_SLOT(ucChannel)->GetNumOfChnlsGanged();
                            for(UINT8 nChanCount = 1; nChanCount < nNumOfChnlsGanged; nChanCount++)
                            {
                                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, FALSE, ucChannel+nChanCount);
                                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, FALSE, ucChannel+nChanCount);
                                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_DOVRCRNT, FALSE, ucChannel+nChanCount);
                                SetOverCurrent(ucChannel+nChanCount, FALSE);
                            }
                        }
                    }
                }
            }

            DoLineMonitoringDiagnosticCounter = 0;
        }
        else
        {
            bExecuteDoLineMonitoringDiagnostic = FALSE;
            DoLineMonitoringDiagnosticCounter++;
        }
        
        // On the second and fourth cycles do AO Readback Diagnostics.
        if((1 == CycleCounter) || (3 == CycleCounter))
        {
            bExecuteAoReadbackDiagnostic = TRUE;
        }
        else
        {
            bExecuteAoReadbackDiagnostic = FALSE;
        }
        
        // If this is the 5th cycle reset the cycle count and prepare to start the macrocycle again.
        // This involves preparing to scan all inputs and resetting the AI channel counter to 1.
        if(CycleCounter >= MACROCYCLE_CYCLECOUNT) 
        {
            bSampleAllChannels = TRUE;
            ucCurrentSlotNum = 1;
            CycleCounter=1;
        }
        else
        {
            bSampleAllChannels = FALSE;
            CycleCounter++;
        }
    }
    else
    {
        // Reference Voltages are bad, or Calibration was unsuccessful, or a board recalibrated 6 times successively
        // Calibration timer should be maintained to keep retrying calibration every 10 seconds
        // Set all other flags and counters to the start of the cycle in case the conditions improve
        if(CalibrationCheckCounter >= CALIB_CHECK_CYCLECOUNT)
        {
            bCheckCalibration = TRUE;
            CalibrationCheckCounter = 0;
        }
        else
        {
            bCheckCalibration = FALSE;
            CalibrationCheckCounter++;
        }

        // Keep running pin diagnostic
        if(DoPinDiagnosticCounter >= PIN_DIAG_CYCLECOUNT)
        {
            bExecuteDoPinDiagnostic = TRUE;
            DoPinDiagnosticCounter = 0;
        }
        else
        {
            bExecuteDoPinDiagnostic = FALSE;
            DoPinDiagnosticCounter++;
        }

        bSampleAllChannels = TRUE;
        ucCurrentSlotNum = 1;
        CycleCounter=1;
    }
}

VOID clsUioBoxSlot::SetBadPVs(VOID)
{
    for (unsigned int ucChan = 1;ucChan <= MAXSLOTS; ucChan++ )
    {
        switch(PvScanRec.pntType[ucChan-1])
        {
            case PNTTYPE_ANALOGINPUT :
                AIH_SLOT(ucChan)->ProcessSlot(NaN);
                break;
            case PNTTYPE_DIGITALINPUT :
                SetBadPvFl(ucChan, TRUE);
                DI_SLOT(ucChan)->SetRawInput(FALSE);
                DI_SLOT(ucChan)->ProcessSlot();
            break;
            default:
               break;
        }
    }
               
}
/*******************************************************************************
*                           clsUioBoxSlot::AppColdInit                         *
*                           ==========================                         *
* PURPOSE: Cold initialize the IOM database and set the Module state to Idle   *
*          and Dbvalid flag to Invalid                                         *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::AppColdInit(VOID) {
    if (MODSTATUS_RUN == ModStat1.Status) {
        ModStat1.Status = MODSTATUS_IDLE;
        AddModStatEvent(EVENTTYPE_NORMAL);
    }
    DbValid = DB_INVALID;
    ComputeCheckSum(); // Recompute BOX checksum
        
    // as a part of database initialization delete the configured slots
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        if (PNTTYPE_NOTCONFIGURED != GetInitPntType(ucSlotNum)) {
            UIO_SLOT(ucSlotNum)->DeleteConfiguredSlot();
        }
    }
}

BOOL clsUioBoxSlot::AppFOProcess(VOID) {
    return FALSE;
}
/*******************************************************************************
*                           clsAohBoxSlot::AppPostSwap                         *
*                           ==========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::AppPostSwap(VOID) {
    //Change the Module switch state to secondary state
    //This change will avoid the switches to be operated twice when the 
    //modules changes the role.
    SetForSecondary();
}
/*******************************************************************************
*                           clsUioBoxSlot::AppPostSync                         *
*                           ==========================                         *
*  AppPostSync is called from PostRedState for application specific actions    *
*  after a database dump.                                                      *
*******************************************************************************/
VOID clsUioBoxSlot::AppPostSync(VOID)
{
    // This function is a combination of AppPostSync() in aihboxslot.cpp,aohboxslot.cpp
    // diboxslot.cpp and doboxslot.cpp file.Removed unnecessary logic in case of UIO

    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++)
    {
        switch(PvScanRec.pntType[ucSlotNum - 1])
        {

            case PNTTYPE_ANALOGINPUT:
                // Noting to do for AI channels.UIO will not support 1-sec channel hart scan configuration. 
                // Recomputing and updating the number of 1 sec channels not required for UIO.
                break;

            case PNTTYPE_ANALOGOUTPUT:
                if(!Iol.AmPrimary())
                {
                    // set the output to the value synced from the primary
                    float fOpval = AOH_SLOT(ucSlotNum)->GetOpInternl();
                    BOX->SetOp(ucSlotNum, fOpval);

                    // Allow to run readback diagnostics as secondary contributed to the screws.
                    AOH_SLOT(ucSlotNum)->SetOTPT_Unused(FALSE);
                }
                else // Primary
                {

                }

                 // skip the readback diagnostic for 2 seconds on both modules,
                 // by this time secondary module begins to contribute to the output.

                 // 2 seconds is selected because it is the slowest OP
                 // update rate (based on 2 second CM execution in CEE)

                 // 80 = 2 (sec) * 2 (diag/cycle) / 0.05 (sec/cycle)
                 AOH_SLOT(ucSlotNum)->ResetSkipLpBkTst(80);


                 // On Switchover reset AO DAC Full Diagnostic flags
                 bScheduleAoDacFullLoadDiagnostic = FALSE; 
                 ucChannelToExecuteAoDacFullDiagnostic = 0;

                break;

            case PNTTYPE_DIGITALINPUT:
                 if(!Iol.AmPrimary())
                 {
                    if(DI_SLOT(ucSlotNum)->IsPulseAccumCapable())
                    {
                        FPGA.SetPulseCountDacHigh(ucSlotNum);    // Drive 20.0ma on the screws to enable pulse counting
                        StoreAvRaw(ucSlotNum,0);
                        FPGA.ClrCounter(ucSlotNum);
                    }
                }
                DI_SLOT(ucSlotNum)->UpdateBadPv();
                break;

            case PNTTYPE_DIGITALOUTPUT:
                // Do this only if module is secondary
                if (!Iol.AmPrimary()) 
                {
                    BOOL bSO = FALSE;

                    // Reset the Overcurrent so that secondary will return any alarms related to 
                    // Overcurrent for any channels.

                    if (GetOverCurrent(ucSlotNum)) 
                    {
                        SetOverCurrent(ucSlotNum, FALSE);
                        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ucSlotNum);
                    }
                    DO_SLOT(ucSlotNum)->ClearOverCurrentSfForAdjChnls();

                    // If open-wire detection is enabled, enable the DAC
                    if (DO_SLOT(ucSlotNum)->GetOwdEnable())
                    {
                        FPGA.EnableDigitalOutputDac(ucSlotNum);
                    }
                    // if output ganged enabled for the current channel,
                    // Enable the DAC to support open wire detection for adjacent channels
                    if (DO_SLOT(ucSlotNum)->GetEnblGangedOutputs())  
                    {   
                        DO_SLOT(ucSlotNum)->ConfigureAdjacentChannels(ucSlotNum+1);
                    }

                    switch(DO_SLOT(ucSlotNum)->GetDOType()) 
                    {
                        case DOTYPE_PWM:
                            if (TRUE == DO_SLOT(ucSlotNum)->GetStartNext())
                            {
                                bSO = FALSE;
                            }
                            else 
                            {
                                if(0 == DO_SLOT(ucSlotNum)->GetPWMPulseTime())
                                {
                                    bSO = FALSE;
                                }
                                else
                                {
                                    bSO = TRUE;
                                }
                            }
                            break;

                        case DOTYPE_STATUS:
                        case DOTYPE_OFFPULSE:
                        case DOTYPE_ONPULSE:
                            bSO = DO_SLOT(ucSlotNum)->GetSO();
                            break;

                        default:
                            break;
                    }

                    UpdateOutputBuffer2(ucSlotNum, bSO);
                    DO_SLOT(ucSlotNum)->CmptInitReq();
                }
                break;

            default:
                break;
        }
     }
}

/*******************************************************************************
*                           clsAohBoxSlot::AppPostDump                         *
*                           ==========================                         *
* PURPOSE: Donot allow update of OpInternal Parameter  b/w period of dump      *
*          complete and sync as it will affect redchksum calculation           *
* ARGUMENTS:                                                                   *
*      NONE                                                                    *
* RETURN:                                                                      *
*      NONE                                                                    *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::AppPostDump(VOID) 
{   
   bDisOpInternlUpdte = TRUE;
}

/*******************************************************************************
*                         clsUioBoxSlot::PostStatReset                         *
*                           ========================                           *
* PURPOSE:   Post Receiver-Beware function for StatReset parameter.  This      *
*            function resets the UIO-specific BoxSlot statistics, then calls   *
*            clsBoxSlot::PostStatReset() to reset common BoxSlot statistics.   *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::PostStatReset(UINT8 a_ucAccessLevel) 
{
    // Reset the Temperature Monitoring statistics
    if(StatReset)
    {
        TempMax = TempCur;
        TempMin = TempCur;
    }

    // Reset the BoxSlot statistics
    clsBoxSlot::PostStatReset(a_ucAccessLevel);
}

/*******************************************************************************
*                             clsDiBoxSlot::PreDiMode                          *
*                             =======================                          *
* PURPOSE: If the Module is in RUN state do not allow to change the DiMode     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsUioBoxSlot::PreDiMode(UINT8 *a_Writebuffer, UINT8)
{
    UINT8 ucModSts = BOX->GetModuleStatus();

    if (DIMODE_NORMAL != *a_Writebuffer)
    {
        return DO_ILLEGAL_VALUE;
    }

    if (MODSTATUS_RUN == ucModSts)
    {
        return DO_STATE_MUST_BE_IDLE;
    }

    return PA_OK;
}

/*******************************************************************************
*                          clsUioBoxSlot::PreTempHiLm                          *
*                           ========================                           *
* PURPOSE:   Validate TEMPHILM parameter store                                 *
*            TEMPLOLM follows TEMPHILM in LoadOrder, therefore we cannot       *
*            validate here that TEMPLOLM is less than TEMPHILM when the access *
*            level indicates a load scenario (ALVL_PBD == a_ucAccLvl).         *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsUioBoxSlot::PreTempHiLm(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl)
{
    PASTATUS rtn = PA_OK;
    INT16 NewVal = *(INT16 *)a_Writebuffer;

    // check new value against the min and max alarm limits
    if ((NewVal > kMaxTempAlarmLimit) ||
        (NewVal <= kMinTempAlarmLimit))
    {
        rtn = DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    // check new TEMPHILM value against the TEMPLOLM
    // this check is defeated if access level is AppDevOnly (aka ALVL_PBD,
    // occurs during block load and checkpoint restore).  The LoadOrder of
    // TempHiLm and TempLoLm requires this check only be performed after both
    // values have been loaded (check occurs in the PreTempLoLm function).
    else if ((ALVL_PBD != a_ucAccLvl) && (NewVal <= TempLoLm))
    {
        rtn = DO_ILLEGAL_VALUE;
    }

    return rtn;
}

/*******************************************************************************
*                          clsUioBoxSlot::PreTempLoLm                          *
*                           ========================                           *
* PURPOSE:   Validate TEMPLOLM parameter store                                 *
*            TEMPLOLM follows TEMPHILM in LoadOrder, therefore we can validate *
*            here that TEMPLOLM is less than TEMPHILM                          *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsUioBoxSlot::PreTempLoLm(UINT8 *a_Writebuffer,UINT8)
{
    PASTATUS rtn = PA_OK;
    INT16 NewVal = *(INT16 *)a_Writebuffer;

    // check new value against the min and max alarm limits
    if ((NewVal >= kMaxTempAlarmLimit) ||
        (NewVal < kMinTempAlarmLimit))
    {
        rtn = DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    // check new TEMPLOLM value against the TEMPHILM
    else if (NewVal >= TempHiLm)
    {
        rtn = DO_ILLEGAL_VALUE;
    }

    return rtn;
}

/*******************************************************************************
*                           clsUioBoxSlot::PostTempLm                          *
*                           ========================                           *
* PURPOSE:   Post- method for both TempHiLm and TempLoLm parameters. After the *
*            temperature alarm limit has been changed, perform an on-demand    *
*            (aka non-periodic) read of the thermometer and update the soft-   *
*            fails with respect to the new alarm limit.                        *
* ARGUMENTS: UINT8 a_ucAccessLevel - not used                                  *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::PostTempLm(UINT8)
{
    BOOL bThrottleRtn = FALSE;
    MonitorTemperature(bThrottleRtn);
}
/*******************************************************************************
*                            clsUioBoxSlot::PreSetConfData                        *
*                            ==========================                        *
* PURPOSE: Pre Receiver-Beware function for SetConfData parameter              *
*                                                                              * 
* ARGUMENTS:a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:  PA_OK           -   If pre check is succesfull                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
PASTATUS clsUioBoxSlot::PreSetConfData(UINT8 *a_Writebuffer,UINT8) 
{

    UINT8 ucNoOfChans = *(UINT8*)(a_Writebuffer);
    UINT8 ucChanNum   = *(UINT8*)(a_Writebuffer+1);

    if(ucNoOfChans > THIRTYTWOCHANNEL) 
    {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    if((ucChanNum == 0) || (ucChanNum > MAXSLOTS)) 
    {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    // Validate channel type
    if((BOX->GetInitPntType(ucChanNum) != PNTTYPE_ANALOGINPUT) &&
       (BOX->GetInitPntType(ucChanNum) != PNTTYPE_ANALOGOUTPUT)) 
    {
        return DO_ILLEGAL_VALUE;
    } 

    return PA_OK;
}

/*******************************************************************************
*                           clsUioBoxSlot::PostSetConfData                        *
*                           ===========================                        *
* PURPOSE:   Post Receiver-Beware function for SetConfData parameter           *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::PostSetConfData(UINT8) 
{
    // Copy Start channel number to NextChannel
    ucNextChannel = HartTestData.StartChannelNum;
}
/*******************************************************************************
*                      clsUioBoxSlot::MonitorTemperature                       *
*                           ========================                           *
* PURPOSE:   Read board temperature from the hardware,                         *
*            record min and max observed temperatures, and                     *
*            check for alarm conditions (temperature limit exceeded)           *
* ARGUMENTS: BOOL bThrottleRtn - throttle the return to normal of the softfail *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::MonitorTemperature(BOOL a_bThrottleRtn)
{
    BOOL bSfDirection = FALSE;

    // get temperature from the thermometer
    TempCur = FPGA.ReadThermometer();

    // record maximum temperature
    if ((TempCur > TempMax) || isnan(TempMax))
    {
        TempMax = TempCur;
    }

    // record minimum temperature
    if ((TempCur < TempMin) || isnan(TempMin))
    {
        TempMin = TempCur;
    }

    // check for high temperature exceeded, throttle the softfail return to normal
    bSfDirection = (TempCur > TempHiLm) ? TRUE : FALSE;
    if (!a_bThrottleRtn || bSfDirection || (0 == HiTempAlarmThrottleCount))
    {
        AddSoftfailEvent(EVENTTYPE_NORMAL, SF_TEMPHILM, bSfDirection, 0);

        // set the throttle counter
        HiTempAlarmThrottleCount = (bSfDirection) ? kTempAlarmThrottleCount : 0;
    }

    // check for low temperature exceeded, throttle the softfail return to normal
    bSfDirection = (TempCur < TempLoLm) ? TRUE : FALSE;
    if (!a_bThrottleRtn || bSfDirection || (0 == LoTempAlarmThrottleCount))
    {
        AddSoftfailEvent(EVENTTYPE_NORMAL, SF_TEMPLOLM, bSfDirection, 0);

        // set the throttle counter
        LoTempAlarmThrottleCount = (bSfDirection) ? kTempAlarmThrottleCount : 0;
    }
}

/*******************************************************************************
*                         clsUioBoxSlot::GetInitPntType                        *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PNTTYPE clsUioBoxSlot::GetInitPntType(UINT8 a_ucChanNum)
{
    PNTTYPE rtnInitPntType = PNTTYPE_NOTCONFIGURED;

    if ((a_ucChanNum > 0) && (a_ucChanNum <= MAXSLOTS))
    {
        // subtract 1 from a_ucChanNum to get zero-relative index
        rtnInitPntType = PvScanRec.pntType[a_ucChanNum - 1];
    }

    return rtnInitPntType;
}

/*******************************************************************************
*                        clsUioBoxSlot::GetInitPntTypePtr                      *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PNTTYPE * clsUioBoxSlot::GetInitPntTypePtr(UINT8 a_ucChanNum)
{
    PNTTYPE * rtnInitPntTypePtr = NULL;

    if ((a_ucChanNum > 0) && (a_ucChanNum <= MAXSLOTS))
    {
        // subtract 1 from a_ucChanNum to get zero-relative index
        rtnInitPntTypePtr = (PNTTYPE *)(&PvScanRec.pntType[a_ucChanNum - 1]);
    }

    return rtnInitPntTypePtr;
}

/*******************************************************************************
*                  clsUioBoxSlot::DigitalInputBoxSlotProcessing                *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::DigitalInputProcessing(VOID)
{
    //// Get input value - This is done by the conversion request
    //// Set RawInput = Input Value, or = False if Module Idle or Point Inactive
    //// Check Input Value against Open Wire value, report SF which is used in UpdateBadPvFl
    //// Do UpdateBadPvFl
    //// Slot ProcessSlot
    UINT8 localModuleStatus = BOX->GetModuleStatus();
    BOOL localDoPointProcessing = (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState()));

    for (unsigned int ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++) 
    {
        if(PNTTYPE_DIGITALINPUT == PvScanRec.pntType[ucSltNm-1])
        {
            if( DI_SLOT(ucSltNm)->GetDiType() != DITYPE_ACCUM )
            {
                BOOL localLastRawInput = DI_SLOT(ucSltNm)->GetRawInput();
                BOOL localRawInput = FPGA.ReadDigitalInput(ucSltNm, localLastRawInput);
                BOOL localOwdEnabled = DI_SLOT(ucSltNm)->GetOwdEnable();
                BOOL localIsOpenWire = FALSE;

                if((MODSTATUS_RUN == localModuleStatus) && (PTEXECST_ACTIVE == DI_SLOT(ucSltNm)->GetPtExecSt()))
                {
                    // check for open wire condition
                    localIsOpenWire = (localOwdEnabled && FPGA.IsOpenWireDI(ucSltNm));
                }
                else
                {
                    localRawInput = FALSE;  // Module is Idle or Point is Inactive
                }

                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,localIsOpenWire,ucSltNm);
                
                if (!localIsOpenWire)
                {
                    ClearBit(&DiDisableOpenWireFO_Mask, ucSltNm - 1);
                }

                // Update PV and BadPv for all slots depending on the result of point processing and diagnotics.
                // Inhibit slot processing on backup module during db synchronization
                // Man and Sub PVs could otherwise be inappropriately updated from raw data
                if(localDoPointProcessing)
                {
                    DI_SLOT(ucSltNm)->UpdateBadPv();
                    DI_SLOT(ucSltNm)->SetRawInput(localRawInput);
                    DI_SLOT(ucSltNm)->ProcessSlot();
                }

                // If ADC is not looking for HART devices...
                // when OWD is disabled, we can reduce the DAC current while the
                // raw input is ON to reduce generated heat
                //if (!GetHADCEnable(ucSltNm))
                //{
                    if(!localOwdEnabled && localRawInput)
                    {
                        FPGA.SetDigitalInputDacLow(ucSltNm);
                    }
                    else // set the DAC for the higher DI current
                    {
                        FPGA.SetDigitalInputDacHigh(ucSltNm);
                    }
                //}
            }
            else
            {
                if( ucSltNm >= PC_CHANNEL1 && ucSltNm <= PC_CHANNEL4)
                {
                    ProcessUioDiPulseCountChannel(ucSltNm);
                }
                ClearBit(&DiDisableOpenWireFO_Mask, ucSltNm - 1);
            }
        }
        else
        {
            ClearBit(&DiDisableOpenWireFO_Mask, ucSltNm - 1);
        } // end if channel is DI Type 
    } // end for all channels
}

/******************************************************************************
*                    clsUioBoxSlot::DigitalOutputProcessing                   *
*                    ======================================                   *
* PURPOSE:                                                                    *
*   Write digital outputs                                                     *
* ARGUMENTS:                                                                  *
*   NONE                                                                      *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   Based "loosely" on the DO modules App STC processing code.                *
******************************************************************************/
VOID clsUioBoxSlot::DigitalOutputProcessing(VOID)
{
    // State of interrupts
    UINT8 uiMask = get_imask_exr();
    
    // Flag used to indicate if output buffer should be updated
    BOOL updateOutputBuffer = FALSE;
    
    // Perform slot processing on each DO slot
    for (int ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) 
    {
        if(PvScanRec.pntType[ucChannel-1] == PNTTYPE_DIGITALOUTPUT)
        {
            DO_SLOT(ucChannel)->ProcessDoSlot();
        }
    }
    
    
    // If backup or non-redundant module,
    // Set output buffer with second output buffer
    if (CheckRedData(REDDATA_REDCFG) && ModStat3.OutCtl)
    {
        // Primary in redundant setup...Update output buffer after the write
        updateOutputBuffer = FALSE;
    }
    else 
    {
        // Backup or non-redundant...Update output buffer now
        DoOutputBuffer1 = DoOutputBuffer2;
        updateOutputBuffer = TRUE;
    }
        
            
    // Write outputs
    if (DoChannelMask > 0)            
    {
        FPGA.WriteDigitalOutputAll(DoChannelMask, DoOutputBuffer1);
    }
        
    // Disable interrupts
    set_imask_exr(LVLPRI_HIGHEST);
    
    // Update the scan record
    PvScanRec.doSoAll = DoOutputBuffer1;
            
    // Enable interrupts
    set_imask_exr(uiMask); 
    
    if (!updateOutputBuffer) 
    {
        DoOutputBuffer1 = DoOutputBuffer2;
    }
}

/*******************************************************************************
*                      clsUioBoxSlot::AnalogInputProcessing                    *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::AnalogInputProcessing()
{
    // Check is calibration is good
    // Else if Module is Idle, Clear OW SF, Do Idle Diagnostics, ProcesSlot with NaN
    // Else if Module is Run, 
    //   Do Reference Voltage Checks
    //   Get Raw Data
    //   Do Nan Threshold
    //   Convert RawDataCount to True Voltage

    for(unsigned int ucChanCount = 1; ((ucChanCount <= AI_SLOTS_PER_CYCLE) && (ucCurrentSlotNum <= MAXSLOTS)); ucChanCount++)
    {
        if (MODSTATUS_IDLE == BOX->ModStat1.Status)
        {
           if(PNTTYPE_ANALOGINPUT == PvScanRec.pntType[ucCurrentSlotNum-1])
           {
               BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ucCurrentSlotNum);
               
               if (PTEXECST_ACTIVE == AIH_SLOT(ucCurrentSlotNum)->GetPtExecSt()) 
               {
                   AIH_SLOT(ucCurrentSlotNum)->ProcessSlot(NaN);
               }
           }
           
           // Not an AI channel or open wire check not being performed (module is IDLE)
           ClearBit(&AiDisableOpenWireFO_Mask, (ucCurrentSlotNum - 1));  
        }
        else if (MODSTATUS_RUN == BOX->ModStat1.Status)
        {    
           if(PNTTYPE_ANALOGINPUT == PvScanRec.pntType[ucCurrentSlotNum-1])
           {
               if ((AIH_SLOT(ucCurrentSlotNum)->GetOwdEnable() == FALSE) || 
                   (AIH_SLOT(ucCurrentSlotNum)->GetPtExecSt() != PTEXECST_ACTIVE)) 
               {
                   BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ucCurrentSlotNum);
                   
                   // No open wire exists...
                   ClearBit(&AiDisableOpenWireFO_Mask, (ucCurrentSlotNum - 1));
               }
 
               // Get value
               FLOAT32 fAnalogReadBack = FPGA.ReadAnalogInput(ucCurrentSlotNum);
               FLOAT32 fRawData = NaN;
 
               // Threshold values based on the Board Type. Applied to 1-5V configuration.
               // The NaN Threshold corresponds to -24% (1-5V).
               if(FPGA.IsAboveNanEnterThreshold(ucCurrentSlotNum))
               {
                   // RawData is greater than NaN threshold.
                   if (TRUE == AIH_SLOT(ucCurrentSlotNum)->WasInputBelowDeadband()) 
                   {
                       // Input was below deadband in previous cycle. Continue raw value
                       // calculation, only if it had risen above deadband in this cycle.
                       // This allows a hysteris to set in once input goes below NaN threshold.
                       if (FPGA.IsAboveNanExitThreshold(ucCurrentSlotNum))
                       {
                           AIH_SLOT(ucCurrentSlotNum)->SetInputBelowDeadband(FALSE);
                           fRawData = fAnalogReadBack;
                       }
                   }
                   else 
                   { 
                       // Input was above NaN threshold in previous cycle.
                       fRawData = (FLOAT32)fAnalogReadBack;
                   }
               }
               else if (SENSRTYP_0to5_V == AIH_SLOT(ucCurrentSlotNum)->GetSensorType()) 
               {
                   AIH_SLOT(ucCurrentSlotNum)->SetInputBelowDeadband(FALSE);
                   fRawData = fAnalogReadBack;
               } 
               else 
               { 
                   // Input is below NaN threshold and sensor type is not 0to5V.
                   AIH_SLOT(ucCurrentSlotNum)->SetInputBelowDeadband(TRUE);
               }
 
               AIH_SLOT(ucCurrentSlotNum)->ProcessSlot(fRawData); // Do slot processing
               
               // Check and see if an open wire was detected
               if (!AIH_SLOT(ucCurrentSlotNum)->IsOwdSfBtSet())
               {
                   // No open wire seen...
                   ClearBit(&AiDisableOpenWireFO_Mask, (ucCurrentSlotNum - 1));
               }
           }
           else
           {
                // Not an AI channel
                ClearBit(&AiDisableOpenWireFO_Mask, (ucCurrentSlotNum - 1));
           }
                
        } // end of Module State = Run 

        ucCurrentSlotNum++;

    } // end of for loop
}

/*******************************************************************************
*                     clsUioBoxSlot::ExecuteAoReadbackDiagnostic               *
*                     ==========================================               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::ExecuteAoReadbackDiagnostic(VOID)
{
    // Get the redundancy state
    UINT8 redState = GetRedState();

    // Do a readback of the channel output only if
    // - Primary should have control on screws.
    // - Secondary redundant state should be synced.
    if ( ( (OUTCTL_MINE == ModStat3.OutCtl) && (Iol.AmPrimary())     ) ||
         ( (REDSTATE_SYNCD == redState) && (!Iol.AmPrimary()) ) )
    {
        for (unsigned int ucChan = 1; ucChan <= MAXSLOTS; ucChan++)
        {
            if (PNTTYPE_ANALOGOUTPUT == PvScanRec.pntType[ucChan-1])
            {                
                if ((MODSTATUS_RUN == ModStat1.Status) &&                   // module is active
                    (AOH_SLOT(ucChan)->GetPtExecSt() == PTEXECST_ACTIVE) && // channel is active
                    (AOH_SLOT(ucChan)->GetOTPT_Unused() == FALSE) &&        // channel is in use
                    (redState != REDSTATE_FO_IN_PROG) &&                    // failover not in progress
                    (redState != REDSTATE_FO_COMPLETE) &&                   // failover not in progress
                    (redState != REDSTATE_DUMP_START) &&                    // dumping not active
                    (redState != REDSTATE_DUMP_COMPLETE))                   // dumping not active
                {
                    // check if AO readback test is being skipped (in case of recent switchover)
                    if(0 == AOH_SLOT(ucChan)->GetSkipLpBkTst())
                    {
                        // Perform readback check
                        UINT8 LpbkSts = AOH_SLOT(ucChan)->DoReadBackTest(FPGA.ReadAnalogOutput(ucChan));

                        if (AOLPBK_PASSED == LpbkSts) 
                        {
                            // Loopback test passed, reset fail count
                            AOH_SLOT(ucChan)->ResetAoReadBackFailCount();

                            // Clear the AoDisableFO bit for this channel
                            ClearBit(&AoDisableOutputFailFO_Mask, ucChan - 1);

                            // Check for AO DAC Full Diagnostic scheduled for this channel
                            if((TRUE == bScheduleAoDacFullLoadDiagnostic) &&
                               (ucChan == ucChannelToExecuteAoDacFullDiagnostic))
                            {
                                ExecuteAoDacFullLoadDiagnostic();
                                bScheduleAoDacFullLoadDiagnostic = FALSE;
                                ucChannelToExecuteAoDacFullDiagnostic = 0;
                            }

                            // If AO DAC Full Diagnostic is scheduled for this channel and it is failed
                            // don't clear the soft failure.
                            if(FALSE == GetBit(AoDisableDacFullFailFO_Mask, ucChan - 1))
                            {
                               //loopback test and AO DAC Full diagnostic passed, clear the softfail
                               AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, FALSE, ucChan);
                            }
                        }
                        else
                        {
                            // loopback test failed, check if softfail should be raised
                            if (AOH_SLOT(ucChan)->GetAoReadBackFailCount() > kMaxAoReadBackFailCount)
                            {
                                if (!Iol.AmPrimary() && TOGFAILED_IN && 
                                    (FAULTSTATE_NORMAL == AOH_SLOT(ucChan)->GetFaultState()))
                                {
                                    // I am the secondary module, my partner (the primary) is faulted,
                                    // but I am not.  My readback test may fail because the primary
                                    // outputs the fault value, while I output the last OP value.

                                    // do not raise a softfail in this condition
                                }

                                else if ((redState >= REDSTATE_SYNCD) && Iol.AmPrimary() && !TOGFAILED_IN &&
                                         (FAULTSTATE_FAULTED == AOH_SLOT(ucChan)->GetFaultState()))
                                {
                                    // I am the primary module, I am faulted, but my partner (the secondary)
                                    // is not faulted.  My readback test may fail because I output the
                                    // fault value while the secondary outputs the last OP value.

                                    // do not raise a softfail in this condition
                                }

                                else
                                {
                                    AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, TRUE, ucChan);
                                }
                            }
                            else
                            {
                                AOH_SLOT(ucChan)->IncAoReadBackFailCount(); // Increment the counter
                            }

                            // Reset AO DAC Full Diagnostic flags
                            if((TRUE == bScheduleAoDacFullLoadDiagnostic) &&
                               (ucChan == ucChannelToExecuteAoDacFullDiagnostic))
                            {
                                bScheduleAoDacFullLoadDiagnostic = FALSE;
                                ucChannelToExecuteAoDacFullDiagnostic = 0;
                            }
                        }
                    }
                    else
                    {
                        // Decrement the Ao read back test skip counter
                        AOH_SLOT(ucChan)->DecrSkipLpBkTst();
                    }
                }
                else
                {
                    // module is idle or channel is inactive or channel is not in use
                    // clear the softfail and reset the counter
                    AOH_SLOT(ucChan)->ResetAoReadBackFailCount();
                    ClearBit(&AoDisableOutputFailFO_Mask, ucChan - 1);

                    // Reset AO DAC Full Diagnostic flags and reset fail count.
                    if((TRUE == bScheduleAoDacFullLoadDiagnostic) &&
                        (ucChan == ucChannelToExecuteAoDacFullDiagnostic))
                    {
                        bScheduleAoDacFullLoadDiagnostic = FALSE;
                        ucChannelToExecuteAoDacFullDiagnostic = 0;

                        // Clear the AoDAcFullFO mask if
                        // Module is IDLE
                        // Channel is INACTIVE
                        if ((MODSTATUS_IDLE == ModStat1.Status) || // module is IDLE
                            (AOH_SLOT(ucChan)->GetPtExecSt() == PTEXECST_INACTIVE)) // channel is inactive
                        {
                            AOH_SLOT(ucChan)->ResetAoDacFailCount();
                            ClearBit(&AoDisableDacFullFailFO_Mask, ucChan - 1);
                        }
                    }

                    // If AoDacFail soft fail reports and after switchover
                    // new primary should not clear the soft failure if failure 
                    // still exists.
                    if(FALSE == GetBit(AoDisableDacFullFailFO_Mask, ucChan - 1))
                    {
                        //loopback test and AO DAC Full diagnostic passed, clear the softfail
                        AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, FALSE, ucChan);
                    }
                }

                // Update Init Request with latest state of the slot soft failure
                AOH_SLOT(ucChan)->CmptInitReq();
            }
            else // not an AO channel
            {
                // clear the AoDisableFO bit for this channel
                ClearBit(&AoDisableOutputFailFO_Mask, ucChan - 1);

                // Reset AO DAC Full Diagnostic flags and fail count.
                // Clear AoDacFullFO bit for this channel
                if((TRUE == bScheduleAoDacFullLoadDiagnostic) &&
                    (ucChan == ucChannelToExecuteAoDacFullDiagnostic))
                {
                    bScheduleAoDacFullLoadDiagnostic = FALSE;
                    ucChannelToExecuteAoDacFullDiagnostic = 0;
                }
                ClearBit(&AoDisableDacFullFailFO_Mask, ucChan - 1);
            }
        }
    }
}

/******************************************************************************
*                          clsUioBoxSlot::UpdateOutputBuffer2                 *
*                          ==================================                 *
* PURPOSE:                                                                    *
*   Updates the DO output buffer to reflect the desired signal state for the  *
*   channel.                                                                  *
* ARGUMENTS:                                                                  *
*   a_ucChanNum - DO channel number                                           *
*   a_bOutput   - State of the output signal (ON/OFF)                         *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   This method was originally defined in clsDoBoxSlot and ported here to be  *
*   compatible with clsDoSlot.                                                *
******************************************************************************/
VOID clsUioBoxSlot::UpdateOutputBuffer2(UINT8 a_ucChanNum, BOOL a_bOutput) 
{
    if (a_bOutput)
    {
        // Set
        SetBit(&DoOutputBuffer2, a_ucChanNum - 1);

        // Turn on the DAC (if OWD is not enabled) to support detection
        // of short circuit conditions.
        if (!DO_SLOT(a_ucChanNum)->GetOwdEnable())
        {
            FPGA.EnableDigitalOutputDac(a_ucChanNum);
        }

        //if output ganged enabled for current channel,
        //Set Do output to adjacent channels
        if (DO_SLOT(a_ucChanNum)->GetEnblGangedOutputs())  
        {   
            UINT8 nNumOfChnlsGanged = DO_SLOT(a_ucChanNum)->GetNumOfChnlsGanged();
            for(UINT8 nChanCount = 1; nChanCount < nNumOfChnlsGanged; nChanCount++)
            {
                // Set
                SetBit(&DoOutputBuffer2, (a_ucChanNum + nChanCount) - 1);
                
                // Turn on the DAC (if OWD is not enabled) to support detection
                // of short circuit conditions for adjacent channels.
                if (!DO_SLOT(a_ucChanNum)->GetOwdEnable())
                {
                    FPGA.EnableDigitalOutputDac(a_ucChanNum + nChanCount);
                }
            }     
        }
    }
    else
    {
        // Clear
        ClearBit(&DoOutputBuffer2, a_ucChanNum - 1);

        // Turn off the DAC (if OWD is not enabled) since short
        // circuit detection is not possible when the channel is
        // off.
        if (!DO_SLOT(a_ucChanNum)->GetOwdEnable())
        {
            FPGA.DisableDigitalOutputDac(a_ucChanNum);
        }

        //if output ganged enabled for current channel,
        //Clear Do output to adjacent channels
        if (DO_SLOT(a_ucChanNum)->GetEnblGangedOutputs()) 
        {   
            UINT8 nNumOfChnlsGanged = DO_SLOT(a_ucChanNum)->GetNumOfChnlsGanged();
            for(UINT8 nChanCount = 1;nChanCount < nNumOfChnlsGanged; nChanCount++)
            {
                // Clear
                ClearBit(&DoOutputBuffer2, (a_ucChanNum + nChanCount) - 1);

                // Turn off the DAC (if OWD is not enabled) since short
                // circuit detection is not possible when the channel is
                // off for all ganged channels.
                if (!DO_SLOT(a_ucChanNum)->GetOwdEnable())
                {
                    FPGA.DisableDigitalOutputDac(a_ucChanNum + nChanCount);
                }
            }     
        }
    }
                
    if ((DO_SLOT(a_ucChanNum)->GetDOType() == DOTYPE_ONPULSE) || 
        (DO_SLOT(a_ucChanNum)->GetDOType() == DOTYPE_OFFPULSE))
    {
        DO_SLOT(a_ucChanNum)->SetSO(a_bOutput);
    }
}

/******************************************************************************
*                  clUioBoxSlot::ExecuteDoLineMonitoringDiagnostic            *
*                  ===============================================            *
* PURPOSE:                                                                    *
*   Check for short circuit, open wire, and output failure conditions on DO   *
*   channels.
* ARGUMENTS:                                                                  *
*   NONE                                                                      *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   NONE
******************************************************************************/
VOID clsUioBoxSlot::ExecuteDoLineMonitoringDiagnostic(VOID)
{          
    // Only primary will perform this diagnostic and role should be stable
    if((OUTCTL_MINE == ModStat3.OutCtl)&&(Iol.AmPrimary()))
    {               
        // Execute diagnostic if DO channels have been configured.
        if (DoChannelMask > 0)
        {            
            for (int ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++)
            {
                if(PvScanRec.pntType[ucChannel-1] == PNTTYPE_DIGITALOUTPUT)
                {   
                    BOOL chanOn = FALSE;
                    
                    // Check to see if the channel was on when the analog
                    // and digital currents were read.
                    if (GetBit(DoDiagChannelState, ucChannel - 1))
                    {
                        chanOn = TRUE;
                    }
                    
                    // Assume no open wire exists...
                    BOOL openWireExists      = FALSE; 
                    
                    // Flag used to indicate if the module is running
                    // and the channel is active
                    BOOL ModRunChActive = (MODSTATUS_RUN == ModStat1.Status) && 
                        (DO_SLOT(ucChannel)->GetPtExecSt() == PTEXECST_ACTIVE);
                        
                                                     
                    // Test for short circuit
                    if (FPGA.IsShortCircuit(chanOn, ucChannel))
                    {
                        // Short circuit detected
                        // Update the overcurrent table
                        SetOverCurrent(ucChannel, TRUE);
                        
                        // Force the signal off
                        FPGA.WriteDigitalOutput(ucChannel, FALSE);
                        
                        // Let the slot know there's an overcurrent/short circuit condition
                        // so that it can stop it's processing.
                        DO_SLOT(ucChannel)->OverCurrentAction();
                              
                        // Add soft failure
                        // NOTE: Soft failure will be cleared when:
                        //   a) Channel is deleted
                        //   b) Channel state changes (activated/deactivated, SO value changes, etc.)
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_DOVRCRNT, TRUE, ucChannel);
                    }

                    if (DO_SLOT(ucChannel)->GetEnblGangedOutputs())
                    {
                        UINT8 nNumOfChnlsGanged = DO_SLOT(ucChannel)->GetNumOfChnlsGanged();
                        for(UINT8 nChanCount = 1; nChanCount < nNumOfChnlsGanged; nChanCount++)
                        {
                            // Check to see if the channel was on when the analog
                            // and digital currents were read.
                            if (GetBit(DoDiagChannelState, (ucChannel+nChanCount) - 1))
                            {
                                chanOn = TRUE;
                            }

                            // Test for short circuit
                            if (FPGA.IsShortCircuit(chanOn, ucChannel + nChanCount))
                            {
                                // Short circuit detected
                                // Update the overcurrent table
                                SetOverCurrent(ucChannel + nChanCount, TRUE);
                        
                                // Let the slot know there's an overcurrent/short circuit condition
                                // so that it can stop it's processing.
                                DO_SLOT(ucChannel)->OverCurrentAction();

                                // Force the signal off
                                FPGA.WriteDigitalOutput(ucChannel + nChanCount, FALSE);
                        
                                // Add soft failure
                                // NOTE: Soft failure will be cleared when:
                                //   a) Channel is deleted
                                //   b) Channel state changes (activated/deactivated, SO value changes, etc.)
                                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_DOVRCRNT, TRUE, ucChannel + nChanCount);
                            }
                        }

                        // Test for open wire 
                        // if DO output ganged enabled
                        // check for open wire condition for all ganged channels
                        for(UINT8 nChanCount = 0; nChanCount < nNumOfChnlsGanged; nChanCount++)
                        {
                            openWireExists = FALSE;
                            if(DO_SLOT(ucChannel)->GetOwdEnable() && ModRunChActive)
                            {
                                // check for open wire condition for channel
                                if(FPGA.IsOpenWireDO(chanOn, ucChannel + nChanCount))
                                {
                                    openWireExists = TRUE;
                                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, TRUE, ucChannel + nChanCount);
                                }
                            }

                            if(FALSE == openWireExists)
                            {
                                // No open wire condition exists or the user doesn't want
                                // to detect open wire conditions...Clear soft failure.
                                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, FALSE, ucChannel + nChanCount);
                            
                                ClearBit(&DoDisableOpenWireFO_Mask, (ucChannel + nChanCount) - 1);
                            }

                            // Assume no output failure exists...
                            BOOL outputfailureExists      = FALSE; 
                            // Test for output failure (commanded state != actual state)
                            if (ModRunChActive &&
                                (!openWireExists))
                            {
                                if(GetOverCurrent(ucChannel + nChanCount) ||
                                  (FPGA.IsOutputFailureDO(chanOn, ucChannel + nChanCount)))
                                {
                                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, TRUE, ucChannel + nChanCount);
                                    outputfailureExists = TRUE;
                                }
                            }

                            if(FALSE == outputfailureExists)
                            {
                                // No output failure detected.  Clear the soft failure.
                                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, FALSE, ucChannel + nChanCount);
                            
                                ClearBit(&DoDisableOutputFailFO_Mask, (ucChannel + nChanCount) - 1);
                            }       
                        }
                    }
                    else
                    {
                        // Test for open wire
                        if (ModRunChActive &&
                            (DO_SLOT(ucChannel)->GetOwdEnable()) &&
                            (FPGA.IsOpenWireDO(chanOn, ucChannel)))
                        {
                            openWireExists = TRUE;
                                
                            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, TRUE, ucChannel);
                        }
                        else
                        {
                            // No open wire condition exists or the user doesn't want
                            // to detect open wire conditions...Clear soft failure.
                            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OPENWIRE, FALSE, ucChannel);
                                
                            ClearBit(&DoDisableOpenWireFO_Mask, ucChannel - 1);
                        }
                        
                        // Test for output failure (commanded state != actual state)
                        if (ModRunChActive &&
                            (!openWireExists) &&
                            (GetOverCurrent(ucChannel) ||
                            (FPGA.IsOutputFailureDO(chanOn, ucChannel))))
                        {
                            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, TRUE, ucChannel);
                        }
                        else
                        {
                            // No output failure detected.  Clear the soft failure.
                            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, FALSE, ucChannel);
                            
                            ClearBit(&DoDisableOutputFailFO_Mask, ucChannel - 1);
                        }       
                    }
                }

                else // not a DO channel
                {
                    // Clear failover bits for this channel
                    ClearBit(&DoDisableOutputFailFO_Mask, ucChannel - 1);
                    ClearBit(&DoDisableOpenWireFO_Mask, ucChannel - 1);
                }
            }
        }

        else // no DO channels configured
        {
            // clear all failover bits
            DoDisableOutputFailFO_Mask = 0;
            DoDisableOpenWireFO_Mask = 0;
        }
    }
}

/******************************************************************************
*                       clsUioBoxSlot::ExecuteDoPinDiagnostic                 *
*                      ========================================               *
* PURPOSE:                                                                    *
*   Checks FPGA DO registers match for commanded and actual SO bits           *
* ARGUMENTS:                                                                  *
*   NONE                                                                      *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   This method will set diagnostic register readback soft failures if        *
*   the actual outputs from the FPGA do not match the last comanded values.   *
******************************************************************************/
VOID clsUioBoxSlot::ExecuteDoPinDiagnostic(VOID)
{
    if(((OUTCTL_PARTNER == ModStat3.OutCtl)&&(!Iol.AmPrimary()))||
        ((OUTCTL_MINE == ModStat3.OutCtl)&&(Iol.AmPrimary())))
    {
        if(MODSTATUS_RUN == ModStat1.Status)
        {
            UINT32 ulFailedDoRegisterPins = FPGA.TestDigitalOutputPins();

            for(unsigned int ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++)
            {
                BOOL alarmDirection = FALSE;

                if(SLOT(ucChannel)->GetPtExecSt() == PTEXECST_ACTIVE)
                {
                    alarmDirection = GetBit(ulFailedDoRegisterPins, ucChannel - 1);
                }

                // Bad pin
                switch (PvScanRec.pntType[ucChannel - 1])
                {
                    case PNTTYPE_DIGITALOUTPUT:
                        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RDBKRGDIAGFL,alarmDirection,ucChannel);
                        
                        // if output ganged enabled for the current channel,
                        // check for readback failure for adjacent channels, if failure is not detected on parent channel
                        if (DO_SLOT(ucChannel)->GetEnblGangedOutputs())
                        {
                            UINT8 nNumOfChnlsGanged = DO_SLOT(ucChannel)->GetNumOfChnlsGanged();
                            for(UINT8 nChanCount = 1; nChanCount  <nNumOfChnlsGanged; nChanCount++)
                            {
                                BOOL alarmDirectionForAdjcentChnls = FALSE;
    
                                if(SLOT(ucChannel)->GetPtExecSt() == PTEXECST_ACTIVE)
                                {
                                    alarmDirectionForAdjcentChnls = GetBit(ulFailedDoRegisterPins,(ucChannel + nChanCount) - 1);
                                }
                                
                                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RDBKRGDIAGFL,alarmDirectionForAdjcentChnls,ucChannel+nChanCount);
                            }

                        }
                        break;
                    case PNTTYPE_ANALOGOUTPUT:
                    case PNTTYPE_ANALOGINPUT:
                    case PNTTYPE_DIGITALINPUT:
                    case PNTTYPE_NOTCONFIGURED:
                        // Do nothing
                        break;
                    default:
                        break;
                }
            }
        }
        else
        {
            // If module is Idle return the Output Fail soft failure and set InitReq
            for (unsigned int ucChan = 1;ucChan <= MAXSLOTS; ucChan++ )
            {
                if(PNTTYPE_DIGITALOUTPUT == PvScanRec.pntType[ucChan-1])
                {
                    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RDBKRGDIAGFL,FALSE,ucChan);
                    if (DO_SLOT(ucChan)->GetEnblGangedOutputs())
                    {
                        UINT8 nNumOfChnlsGanged = DO_SLOT(ucChan)->GetNumOfChnlsGanged();
                        for(UINT8 nChanCount = 1; nChanCount < nNumOfChnlsGanged; nChanCount++)
                        {
                            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RDBKRGDIAGFL,FALSE,ucChan + nChanCount);
                        }
                    }
                }
            }
        }
    }
}


/******************************************************************************
*                     clsUioBoxSlot::InitializeChannelData                    *
*                     ====================================                    *
* PURPOSE:                                                                    *
*   1) Updates the scan record with the specified point type                  *
*   2) Clears scan record data when the point type is PNTTYPE_NOTCONFIGURED   *
*   3) Updates DI/DO channel masks when the point type is PNTTYPE_DIGITALINPUT*
*      or PNTTYPE_DIGITALOUTPUT.                                              *
* ARGUMENTS:                                                                  *
*   a_ucChanNum - Channel/Slot number                                         *
*   pntType     - Channel/Slot point type                                     *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   NONE                                                                      *
******************************************************************************/
VOID clsUioBoxSlot::InitializeChannelData(UINT8 a_ucChanNum, PNTTYPE pntType)
{
    if ((a_ucChanNum > 0) && (a_ucChanNum <= MAXSLOTS))
    {
        // Setup the point type
        PvScanRec.pntType[a_ucChanNum - 1] = pntType;

        switch (PvScanRec.pntType[a_ucChanNum - 1])
        {
            case PNTTYPE_NOTCONFIGURED:

                // Clear initialization request
                SetInitReq(a_ucChanNum, FALSE);

                // Clear SO
                ClearBit(&PvScanRec.doSoAll, a_ucChanNum - 1);

                // Clear channel data
                for (int i = 0; i < CHAN_SCANRECSIZE; i++)
                {
                    PvScanRec.ScanRec[a_ucChanNum - 1].RawData[i] = 0;
                }

                // Clear channel masks
                ClearBit(&DiChannelMask, a_ucChanNum - 1);
                ClearBit(&DoChannelMask, a_ucChanNum - 1);
                ClearBit(&AoChannelMask, a_ucChanNum - 1);
                
                // Clear overcurrent flag
                SetOverCurrent(a_ucChanNum, FALSE);
                
                break;

            case PNTTYPE_DIGITALINPUT:

                // Setup the channel mask
                SetBit(&DiChannelMask, a_ucChanNum - 1);
                break;

            case PNTTYPE_DIGITALOUTPUT:

                // Setup the channel mask
                SetBit(&DoChannelMask, a_ucChanNum - 1);
                break;

            case PNTTYPE_ANALOGOUTPUT:

                // Setup the channel mask
                SetBit(&AoChannelMask, a_ucChanNum - 1);
                break;

            default:
                break;
        }
    }
}

/******************************************************************************
*                       clsUioBoxSlot::IRQ3InterruptHandler                   *
*                       ===================================                   *
* PURPOSE:                                                                    * 
*  Service HART UART and SPI interrupts detected by the FPGA.                 *
* ARGUMENTS:                                                                  * 
*  None.                                                                      *
* RETURN:                                                                     *
*  None.                                                                      *
* NOTES:                                                                      *
*  SPI devices (thermometer, etc.) should not cause an interrupt. If a SPI    *
*  interrupt is detected, the module will hard fail.                          *
******************************************************************************/
VOID clsUioBoxSlot::IRQ3InterruptHandler(VOID)
{
    IRQ3_STATUS = DISABLE; // Clear the interrupt flag

    // Don't exit until all sources of this interrupt have been dealt with
    while (FPGA_ISR.FPGAWORDREG > 0)
    {
        // Check for SPI interrupt
        // NOTE: SPI thermometer should not interrupt the H8
        if(FPGA_ISR.INTFL_SPI > 0)
        {
            TraceLog.AddToTrace(TRACEID_GENERIC, bcSpiIntDetected);
            HardFail(HF_INVPROGRAMEXEC, UIOBOXSLOT_CPP, __LINE__);
        }

        // Check for HART interrupt
        if(FPGA_ISR.INTFL_HART > 0)
        {
            // Modem interrupt
            ProcessHartInterrupt();
        }
    }
}

/******************************************************************************
*                       clsUioBoxSlot::PostUioBoxSlotDump                     *
*                      ==================================                     *
* PURPOSE:                                                                    *
*   Create all 32 channels after UioBoxSlot database is dumped from Primary   *
*   based on PntType[] available in PvScanRec structure.                      *
* ARGUMENTS:                                                                  *
*   NONE                                                                      *
* RETURN:                                                                     *
*         PA_OK  - Channel creation is Success................................*
*     Not PA_OK  - Channel creation failed     ...............................*
* NOTES:                                                                      *
******************************************************************************/
PASTATUS clsUioBoxSlot::PostUioBoxSlotDump(VOID)
{    
    PASTATUS PaStatus = PA_OK;
    
    for (unsigned int idx = 0; (idx < MAXSLOTS) && (PA_OK == PaStatus); idx++)
    {
        PNTTYPE scanRecPntType = PvScanRec.pntType[idx];
            
        // Create channel if pnyType is not configured and 
        // PntType from scan rec should not equal to existing channel type.
        // Second condition is to avoid recreation of the channel.
        if ((PNTTYPE_NOTCONFIGURED != scanRecPntType) && 
            (SLOT(idx + 1)->GetPntType() != scanRecPntType))
        {
            PaStatus = UIO_SLOT(idx + 1)->CreateConfiguredSlot(scanRecPntType);
        }
    }

    return PaStatus;
}
/*******************************************************************************
*                        clsUioBoxSlot::SetForPrimary                          *
*                        ============================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*      NONE                                                                    *
* RETURN:                                                                      *
*      NONE                                                                    *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::SetForPrimary () {
    
    un_cpld_fpga_wordbits InhSwCr;

    // Inhibit Partners output
    InhSwCr.INHOUT = 1;
    INHSWCR.FPGAWORDREG = InhSwCr.FPGAWORDREG;
    IdleWait(100);

    ModStat3.OutCtl = OUTCTL_MINE;

    for (UINT8 ucSlotNum = PC_CHANNEL1; ucSlotNum <= PC_CHANNEL4; ucSlotNum++)
    {
       switch(PvScanRec.pntType[ucSlotNum - 1])
       {
         case PNTTYPE_DIGITALINPUT:
            if( DITYPE_ACCUM == DI_SLOT(ucSlotNum)->GetDiType() )
            {
                StoreAvRaw(ucSlotNum,0);

                //Reset AV to Zero
                if((PTEXECST_ACTIVE == DI_SLOT(ucSlotNum)->GetPtExecSt()) && 
                   (MODSTATUS_RUN == BOX->GetModuleStatus()) &&
                   (PVSOURCE_AUTO == DI_SLOT(ucSlotNum)->GetPvSource()))
                {
                    StoreAv(ucSlotNum,0);
                }
                //

                FPGA.ClrCounter(ucSlotNum);
            }
            break;
         default:
            break;
       }
    }
}

/*******************************************************************************
*                        clsUioBoxSlot::SetForSecondary                        *
*                        ==============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*      NONE                                                                    *
* RETURN:                                                                      *
*      NONE                                                                    *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::SetForSecondary (BOOL) {
    un_cpld_fpga_wordbits InhSwCr;

    // Inhibit your own outputs
    InhSwCr.INHOUT = 0;
    INHSWCR.FPGAWORDREG = InhSwCr.FPGAWORDREG;
    IdleWait(100);
  
    ModStat3.OutCtl = OUTCTL_PARTNER;
    
    // Delay readback diagnostics for AO channels until
    // we can start contributing current.
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++)
    {
       switch(PvScanRec.pntType[ucSlotNum - 1])
       {
         case PNTTYPE_ANALOGOUTPUT:
            AOH_SLOT(ucSlotNum)->SetOTPT_Unused(TRUE);
            break;
         default:
            break;
       }
    }
}
/*******************************************************************************
*                         clsUioBoxSlot::SwitchInit                            *
*                         ========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*      NONE                                                                    *
* RETURN:                                                                      *
*      NONE                                                                    *
* NOTES: This function completely reused from DoBoxSlot::SwitchInit() function *
*        with necessary changes for UIO                                        *
*******************************************************************************/
BOOL clsUioBoxSlot::SwitchInit (VOID) {

    un_cpld_fpga_wordbits InhSwCr;

    //Allow one module to come up earlier than other module
    UINT8 ucDelay = (BOTTOM) ? 20000 : 10;          // compute variable delay (us)

    if (INH_IN_NEGATED == INHIN) {                   // partner is not controlling screws
        if (BURIN_ASSERTED == BUPREQ_IN) {          // partner asserting BUPREQ
            if (INH_IN_NEGATED == INHIN) {           // partner still not have screws
                IdleWait(ucDelay);                  // wait for some delay time
                if (INH_IN_NEGATED == INHIN) {       // partnr does not have screws

                    InhSwCr.INHOUT = 1;             // assume control of the screws
                    INHSWCR.FPGAWORDREG = InhSwCr.FPGAWORDREG;
                    IdleWait(ucDelay);              // wait for some delay time

                    if (INH_IN_NEGATED == INHIN) {   // partner not have screws
                        SetForPrimary();            // assume role as primary
                        return TRUE;                // exit finished
                    }
                    else {
                        InhSwCr.INHOUT = 0;         // relinquish control of screws
                        INHSWCR.FPGAWORDREG = InhSwCr.FPGAWORDREG; 
                        IdleWait(ucDelay);          // wait for some delay time

                        return FALSE;               // exit unfinished
                    }
                }
                else {                              // partner is controlling screws
                    SetForSecondary();              // assume role as backup module
                    return TRUE;                    // exit finished
                }
            }
            else {                                  // partner is controlling screws
                return FALSE;                       // exit unfinished
            }
        }
        else {
            IdleWait(ucDelay);                      // wait for some delay time
            if (INH_IN_NEGATED == INHIN) {           // partner does not have screws
                if (BURIN_ASSERTED == BUPREQ_IN) {  // partner asserting BUPREQ
                    return FALSE;                   // exit unfinished
                }
                else {                              // partner is not asserting BUPREQ
                    SetForPrimary();
                    IdleWait(150);                  // wait for 150 microsecs
                    return TRUE;                    // exit finished
                }
            }
            else {                                  // partner is controlling screws
                return FALSE;                       // exit unfinished
            }
        }
    }
    else {                                          // partner is controlling the screws
        IdleWait (ucDelay);                         // wait for some delay time
        if (INH_IN_NEGATED == INHIN) {               // partner does not have screws
            return FALSE;                           // exit unfinished
        }
        else {                                      // partner is controlling the screws
            SetForSecondary();                      // assume role as backup module
            return TRUE;                            // exit finished
        }
    }
}
/*******************************************************************************
*                     clsUioBoxSlot::CheckFailOverCondition                    *
*                     =====================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*      NONE                                                                    *
* RETURN:                                                                      *
*      NONE                                                                    *
* NOTES:This function is completely reused from                                *
*  DoBoxSlot::CheckFailOverCondition() function with necessary changes for UIO *
*******************************************************************************/
VOID clsUioBoxSlot::CheckFailOverCondition(VOID) {

    if (ModStat3.OutCtl == OUTCTL_PARTNER) {          // I do not have ctl of the screws
        if (BURIN_ASSERTED == BUPREQ_IN) {            // my partner has asserted BUPREQ
            if (INH_IN_NEGATED == INHIN) {            // and it has given up the screws
                IdleWait(50);
                if (INH_IN_NEGATED == INHIN) {        // partner still does not have
                    if (BUREQ_NEGATED == SWBUREQ_n) { // and i have negated BURQ
                        SetForPrimary();
                        if (REDSTATE_FO_IN_PROG == GetRedState())
                            SetRedState(REDSTATE_FO_COMPLETE);
                    }
                }
            }
        }
        if (Iol.AmPrimary()) {
            if (INH_IN_NEGATED == INHIN) {            // and it has given up the screws
                IdleWait(50);
                if (INH_IN_NEGATED == INHIN) {        // partner still does not have
                    // If at this point the expected FO sequence did not occur
                    // properly. So save the state of the BUREQ's & REDSTATE
                    // Then take control of the field terminations
                    TraceLog.AddToTrace(TRACEID_GENERIC,bcFailOver,
                       (UINT32)BUPREQ_IN << 24 | (UINT32)SWBUREQ_n << 16 |
                       (UINT32)GetRedData() << 8 | GetRedState());
                    SetForPrimary();
                    if (REDSTATE_FO_IN_PROG == GetRedState())
                       SetRedState(REDSTATE_FO_COMPLETE);
                }
            }
        }
    }
    else if (!Iol.AmPrimary()) {                      // I have control of the screws
                                                      // and have started failover
        if (BUREQ_ASSERTED == SWBUREQ_n) {            // If I am asserting BUPREQ
            if (BURIN_NEGATED == BUPREQ_IN) {         // and my partner is not
                SetForSecondary();                    // assume role of backup module
            }
        }
    }

}

/*******************************************************************************
*                           clsUioBoxSlot::HartLoopBackTest                    *
*                           ============================                       *
* PURPOSE: Tests the Hart circuitray(Modems,UARTs and MUX)                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
RETURNSTATUS clsUioBoxSlot::HartLoopBackTest(VOID) 
{
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static UINT8 ucNumChanProc = 0;

    switch(Context) 
    {
      case CONTEXT_ZERO:
          switch(HartTestData.NumOfChannels) 
          {
             case ONECHANNEL:
                 ucNumChanProc = 1;
                 break;
  
             case TWOCHANNEL:
                 ucNumChanProc = 2;
                 break;
  
             case FOURCHANNEL:
                 ucNumChanProc = 4;
                 break;
  
             case EIGHTCHANNEL:
                 ucNumChanProc = 8;
                 break;
  
             case SIXTEENCHANNEL:
                 ucNumChanProc = 16;
                 break;
  
             case THIRTYTWOCHANNEL:
                 ucNumChanProc = 32;
                 break;
  
             default:
                 HardFail(HF_BADPROGRAMJUMP,BOXSLOT_CPP,__LINE__);
                 break;
          }
  
          Context = CONTEXT_ONE;
          RtnSts = RETURNSTATUS_INPROGRESS;
          break;
      case CONTEXT_ONE:
          // Set status to running
          BOX->SetLpBkStat(LOOPBACK_RUNNING);
          // Abort any ongoing communication
          AbortHartConnection(ucCurrentChannel);
  
          if (SLOT(ucCurrentChannel)->GetPntType() == PNTTYPE_ANALOGINPUT)
          {
          
              // Initialise Hart db database
              AIH_SLOT(ucCurrentChannel)->GetHartDevDb().InitDevDb(TRUE);
          }
          else if(SLOT(ucCurrentChannel)->GetPntType() == PNTTYPE_ANALOGOUTPUT)
          {
              // Initialise Hart db database
              AOH_SLOT(ucCurrentChannel)->GetHartDevDb().InitDevDb(TRUE);
      
              // Driving 50% current for AO before starting HART Testing
              BOX->SetOp(ucCurrentChannel,50.0);
          }
          else
          {
              // Current channel is DI or DO or Not Configured. 
              // Stop hart loop back testing and set the status to channel fail code.
              Context = CONTEXT_ZERO;
              HartLoopBkTestInProgress = FALSE;
              ucNumChanProc = 0;
              LpBkStat = (HARTLPBKSTAT)((ucCurrentChannel << 2) & 0xFC );
              RtnSts = RETURNSTATUS_COMPLETE;
              break;
          }
  
          // Change context
          Context = CONTEXT_TWO;
          RtnSts = RETURNSTATUS_INPROGRESS;
          break;
  
      case CONTEXT_TWO:
          // Add request to Modem queue
          if(TRUE == InitHartConnection(ucCurrentChannel)) 
          {
              Context = CONTEXT_THREE;
          }
          RtnSts = RETURNSTATUS_INPROGRESS;
          break;
  
      case CONTEXT_THREE:
          if((LOOPBACK_RUNNING != (HARTLPBKSTAT)LpBkStat) && (LOOPBACK_WARNING != (HARTLPBKSTAT)LpBkStat)) 
          {
              if(LOOPBACK_SUCCESS == (HARTLPBKSTAT)LpBkStat) 
              {

                  if(ucNumChanProc != (UINT8)0)
                  {
                     ucNumChanProc--;
                  }
  
                  // Increment Next channel
                  ucNextChannel++;

                  // Boundary checking
                  ucNextChannel %= 32;
                  if(ucNextChannel == 0)
                  {
                      ucNextChannel = 32;
                  }
  
                  if(ucNumChanProc == 0) 
                  {
                      Context = CONTEXT_ZERO;
                      // All channels are processed, exit the test
                      HartLoopBkTestInProgress = FALSE;
                      RtnSts = RETURNSTATUS_COMPLETE;
                  }
                  else 
                  {
                      // Proceed to testing of next channel
                      Context = CONTEXT_ONE;
                      ucCurrentChannel = ucNextChannel;
                      RtnSts = RETURNSTATUS_INPROGRESS;
                  }
              }
              // In case of failure, exit the test and ucNextchannel is not incremented
              else 
              {
                  Context = CONTEXT_ZERO;
                  HartLoopBkTestInProgress = FALSE;
                  ucNumChanProc = 0;
                  RtnSts = RETURNSTATUS_COMPLETE;
              }
          }
          break;
  
      default:
          break;
    }
    return RtnSts;
}

/*******************************************************************************
*              clsUioBoxSlot::ProcessUioDiPulseCountChannel                    *
*                        ========================                              *
* PURPOSE: Does the Pulse counting channel point processing                    *
*          1)calculates AV,AvRaw and sets the Status For AV,AvRaw              *
* ARGUMENTS:ucSltNm - Channel number                                           *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::ProcessUioDiPulseCountChannel (UINT8 ucSltNm)
{
    BOOL bLocalDiPointProcessing = (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState()));
    UINT32 ulTvRaw;

    // Update AV and AVRAW and AV,AVRAW STATUS for all slots depending on the result of point 
    // processing and diagnotics.
    // Inhibit slot processing on backup module during db synchronization
    // Man and Sub PVs could otherwise be inappropriately updated from raw data
    if(bLocalDiPointProcessing)
    {
        PTEXECST nPtExecSt = DI_SLOT(ucSltNm)->GetPtExecSt();
        PVSOURCE nPvSource = DI_SLOT(ucSltNm)->GetPvSource();
        UINT8 nLocalModuleStatus = BOX->GetModuleStatus();
        UINT32 CurrentAvRawCount = GetAvRaw(ucSltNm);

        if ((MODSTATUS_RUN == nLocalModuleStatus) && (PTEXECST_ACTIVE == nPtExecSt))
        {
            UINT16 ulFpgaCount= FPGA.GetCounter(ucSltNm);
            UINT16 ulFpgaLastCount = FPGA.LastCounterVal[ucSltNm-PC_CHANNEL1];

            // Get AvRaw
            CurrentAvRawCount += (ulFpgaCount - ulFpgaLastCount);

            FPGA.LastCounterVal[ucSltNm-PC_CHANNEL1]= ulFpgaCount;

            StoreAvRaw(ucSltNm,CurrentAvRawCount);
            StoreAvRawSts(ucSltNm, STATUS_NORMAL);
        }
        else
        {
            StoreAvRaw(ucSltNm,0);
            StoreAvRawSts(ucSltNm, STATUS_BAD);

            // clear the counter...
            // after Activation and Run, the AVRAW will accumulate starting from 0
            FPGA.ClrCounter(ucSltNm);

            StoreAvTvFl(ucSltNm,FALSE);
            DI_SLOT(ucSltNm)->SetTvProc(FALSE);
        }

        if(nPvSource == PVSOURCE_AUTO)
        {
            if((PTEXECST_ACTIVE == nPtExecSt) && (MODSTATUS_RUN == nLocalModuleStatus))
            {
                // Compute Av and store it
                FLOAT32 ufAv = (DI_SLOT(ucSltNm)->GetC1() / (DI_SLOT(ucSltNm)->GetC2()) * (FLOAT32) CurrentAvRawCount);
                StoreAv(ucSltNm, ufAv);
                StoreAvSts(ucSltNm,STATUS_NORMAL);
            }
            else
            {
                StoreAv(ucSltNm, NaN);
                StoreAvSts(ucSltNm,STATUS_BAD);
            }
        }
        else if(isnan(GetAv(ucSltNm)))
        {
            StoreAvSts(ucSltNm,STATUS_BAD);
        }
        else
        {
            StoreAvSts(ucSltNm,STATUS_MANUAL);
        }
        // set AV,TV range violation flag
        if(DI_SLOT(ucSltNm)->GetTvProc() == TRUE)
        {
            if(nPvSource != PVSOURCE_AUTO)
            {
                if((isnan(GetAv(ucSltNm))) || (isnan(GetTv(ucSltNm)))){
                    StoreAvTvFl(ucSltNm,FALSE);
                }
                else
                {
                    if(GetTv(ucSltNm) <= GetAv(ucSltNm)){
                        StoreAvTvFl(ucSltNm,TRUE);
                        DI_SLOT(ucSltNm)->SetTvProc(FALSE);
                    }
                    else{
                        StoreAvTvFl(ucSltNm,FALSE);
                    }
                }
            }
            else
            {
                if(isnan(GetTv(ucSltNm))){
                    StoreAvTvFl(ucSltNm,FALSE);
                }
                else
                {
                    ulTvRaw = (UINT32) ((DI_SLOT(ucSltNm)->GetC2() / DI_SLOT(ucSltNm)->GetC1()) * GetTv(ucSltNm));
                    if(ulTvRaw <= GetAvRaw(ucSltNm)){
                        StoreAvTvFl(ucSltNm,TRUE);
                        DI_SLOT(ucSltNm)->SetTvProc(FALSE);
                    }
                    else{
                        StoreAvTvFl(ucSltNm,FALSE);
                    }
                }
            }
        }

        DI_SLOT(ucSltNm)->UpdateBadPv();
    }
}

/*******************************************************************************
*                   clsUioBoxSlot::ExecuteAoDacFullLoadDiagnostic              *
*                   =============================================              *
* PURPOSE:                                                                     *
*   Detect DAC failures for AO channels                                        *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   NONE                                                                       *
* NOTES:                                                                       *
*   Scan for unfiltered values must be performed before this method is called. *
*******************************************************************************/
VOID clsUioBoxSlot::ExecuteAoDacFullLoadDiagnostic(VOID)
{
    // Positive adjustment made to each AO channel's OP to perform
    // the diagnostic.
    // NOTE: 16 counts = 0.6 % of Full OP range, 80 counts = 3%
    // NOTE: HW team provided this value
    const UINT16 OP_WRITE_DELTA = 0x0050;
    
    // Increase in OP expected to be seen for channels that
    // have their OP adjusted.
    // NOTE: HW team provided this value
    const UINT16 OP_READBACK_DELTA = 0x0096;
   
    // Minimum time to wait for the adjusted OP to settle (microseconds)
    // NOTE: HW team provided this value
    const UINT16 MIN_WAIT_TIME = 700;
        
    // Current redundancy state
    UINT8 redState = GetRedState();
        
    // Adjusted OP for channel being tested
    UINT32 adjustedOp = 0;
    
    // Expected OP value to be read back
    // after OP adjustment have been made.
    UINT16 expectedOp = 0;
    
    // Mask used to specify which channels to scan for input
    UINT32 scanMask = 0;

    // Flag used for executing this diagnostic
    BOOL bRunAoDacFullDiagnostic = TRUE; 
                                                            
    // In case of secondary, modules should be in sync to run the diagnostic
    if((redState != REDSTATE_SYNCD) && 
        (!Iol.AmPrimary()))
    {
        bRunAoDacFullDiagnostic = FALSE;
    }

    // Calculate the adjusted OP value for channel to test
    adjustedOp = AOH_SLOT(ucChannelToExecuteAoDacFullDiagnostic)->GetOutDACImg() + OP_WRITE_DELTA;

    // Only run the diagnostic for this channel if:
    //   1) For secondary, modules should be synchronized. For Primary always.
    //   2) Adjusted OP will not overflow 12 bits
    //   3) HART communication for the channel is not active
    if ((bRunAoDacFullDiagnostic == TRUE) &&
        (adjustedOp <= 0x00000FFF) &&
        (FPGA.IsHartCommInProgress(ucChannelToExecuteAoDacFullDiagnostic) != TRUE))
    {
                            
        // Calculate the expected OP value to see after the
        // adjustment occurs.
        expectedOp = FPGA.ReadAnalogOutput(ucChannelToExecuteAoDacFullDiagnostic) + OP_READBACK_DELTA;
                   
        // Update the scan mask
        SetBit(&scanMask, (ucChannelToExecuteAoDacFullDiagnostic - 1));

        // Adjust OP
        FPGA.WriteAnalogOutput(ucChannelToExecuteAoDacFullDiagnostic, (UINT16)adjustedOp);

        // Wait for OP change to settle...
        IdleWait(MIN_WAIT_TIME);

        if(ucChannelToExecuteAoDacFullDiagnostic <= 16)
        {
            // Issue scan for channels 1 - 16
            FPGA.IssueScanRequest(eIoBoard1, eAnalogCurrent,(UINT16)(scanMask & 0x0000ffff));

            // Wait for the scan to complete...
            while(!FPGA.IsScanComplete(eIoBoard1)){};
        }
        else
        {
            // Issue scan for channels 17 - 32 
            FPGA.IssueScanRequest(eIoBoard2, eAnalogCurrent,(UINT16)((scanMask >> 16) & 0x0000ffff));

            // Wait for the scan to complete...
            while(!FPGA.IsScanComplete(eIoBoard2)){};
        }

        // Restore the original OP for each AO channel
        FPGA.WriteAnalogOutput(ucChannelToExecuteAoDacFullDiagnostic, (UINT16)(AOH_SLOT(ucChannelToExecuteAoDacFullDiagnostic)->GetOutDACImg()));

        // Check the readback for AO channel to see if we can detect
        // the small OP change that was made earlier.

        // Read back the ADC result
        UINT16 readback = FPGA.ReadAnalogOutput(ucChannelToExecuteAoDacFullDiagnostic);
                                
        // If the OP did not increase and the loop back status does not
        // indicate a failure on the low side, increment the DAC
        // failure count.
        if (readback < expectedOp)
        {                    
            // If the number of consecutive failures exceeds the
            // defined maximum, issue a soft failure.
            if ((AOH_SLOT(ucChannelToExecuteAoDacFullDiagnostic)->GetAoDacFailCount() + 1) > kMaxAoDacFullDiagFailCount)
            {
                // Set the AoDacFullFO bit for this channel and report sf
                SetBit(&AoDisableDacFullFailFO_Mask, ucChannelToExecuteAoDacFullDiagnostic - 1);
                AddSoftfailEvent(EVENTTYPE_NORMAL, SF_OUTPUTFL, TRUE, ucChannelToExecuteAoDacFullDiagnostic);
            }
            else
            {
                // Increment the fail count
                AOH_SLOT(ucChannelToExecuteAoDacFullDiagnostic)->IncAoDacFailCount();
            }
        }
        else
        {   
            // Test passed. Reset fail count and clear bit in the mask
            AOH_SLOT(ucChannelToExecuteAoDacFullDiagnostic)->ResetAoDacFailCount();
            ClearBit(&AoDisableDacFullFailFO_Mask, ucChannelToExecuteAoDacFullDiagnostic - 1);
        }
    }
    else
    {
        // Not running the diagnostic...reset fail count and clear bit in the mask
        // if there is no HART communication in progess.
        if (FPGA.IsHartCommInProgress(ucChannelToExecuteAoDacFullDiagnostic) != TRUE)
        {
            AOH_SLOT(ucChannelToExecuteAoDacFullDiagnostic)->ResetAoDacFailCount();
            ClearBit(&AoDisableDacFullFailFO_Mask, ucChannelToExecuteAoDacFullDiagnostic - 1);
        }
    }
}
/*******************************************************************************
*                          clsUioBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsUioBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if ((PNTTYPE_ANALOGOUTPUT == SLOT(WriteIndex)->GetPntType()) && 
        (TRUE == AOH_SLOT(WriteIndex)->IsRedTagged()))
        return DO_POINT_IS_RED_TAGGED;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsUioBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsUioBoxSlot::PostHADCEnable(UINT8) {
    UINT8 Idx = WriteIndex;

    TraceLog.AddToTrace(TRACEID_GENERIC,bcHAdcEnable,Idx<<24 + Data.ucBytes[1]<<16 + GetInitPntType(Idx)<<8 + GetHADCStatus(Idx));
    SetAdcCycleCount(WriteIndex,0);
    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        if (PNTTYPE_NOTCONFIGURED == GetInitPntType(Idx)) {
            HEnableSaved[Idx - 1] = FALSE;
            // Configure channel as an AI so that the module can communicate with any HART device
            Op_Saved[Idx - 1] = HART_UNCONFIGURED_OP;
            UIO_SLOT(Idx)->CreateConfiguredSlot(PNTTYPE_ANALOGINPUT);
            AIH_SLOT(Idx)->SetHEnable(TRUE);
            AIH_SLOT(Idx)->PostHEnable(ALVL_PBD);
            SetHADCStatus(Idx,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            AIH_SLOT(Idx)->GetHartDevDb().BuildScanTable();
            AIH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
        else if (PNTTYPE_ANALOGINPUT == GetInitPntType(Idx)) {
            HEnableSaved[Idx - 1] = AIH_SLOT(Idx)->GetHEnable();
            // If HEnable is FALSE set it to TRUE
            if (FALSE==HEnableSaved[Idx - 1]) {
                AIH_SLOT(Idx)->SetHEnable(TRUE);
                AIH_SLOT(Idx)->PostHEnable(ALVL_PBD);
                SetHADCStatus(Idx,HART_DATA_PENDING);
                AIH_SLOT(Idx)->GetHartDevDb().BuildScanTable();
                AIH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
            }
        }
        else if (PNTTYPE_ANALOGOUTPUT == GetInitPntType(Idx)) {
            FLOAT32 fOp;
            AOH_SLOT(Idx)->GetHartDevDb().InitDevDb(FALSE);
            // Save present OP value
            Op_Saved[Idx - 1] = GetOp(Idx);
            // If there is not presently enough current
            // Drive output current to the minimum necessary for device discovery
            if (HART_AUTODETECT_OP > AOH_SLOT(Idx)->GetOpFinal()) {
                fOp = HART_AUTODETECT_OP;
                if (TRUE == AOH_SLOT(Idx)->GetOpChar()) fOp = AOH_SLOT(Idx)->ChrcBkwrd(HART_AUTODETECT_OP);
                if (OPTDIR_REVERSE == AOH_SLOT(Idx)->GetOptDir()) fOp = ((FLOAT32) 100.0) - fOp;
                SetOp(Idx,fOp);
                SetHADCStatus(Idx,HART_DATA_PENDING);
                SetAdcCycleCount(WriteIndex,1);
                AOH_SLOT(Idx)->GetHartDevDb().BuildScanTable();
                AOH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
            }
            HEnableSaved[Idx - 1] = AOH_SLOT(Idx)->GetHEnable();
            // If HEnable is FALSE set it to TRUE
            if (FALSE==HEnableSaved[Idx - 1]) {
                AOH_SLOT(Idx)->SetHEnable(TRUE);
                AOH_SLOT(Idx)->PostHEnable(ALVL_PBD);
                SetHADCStatus(Idx,HART_DATA_PENDING);
                SetAdcCycleCount(WriteIndex,1);
                AOH_SLOT(Idx)->GetHartDevDb().BuildScanTable();
                AOH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
            }
        }
        else if (PNTTYPE_DIGITALINPUT == GetInitPntType(Idx)) {
            //FPGA.SetDigitalInputDacAdc(Idx);
            //SetHADCStatus(Idx,HART_DATA_PENDING);
            //DI_SLOT(Idx)->GetHartDevDb().BuildScanTable();
            //DI_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
        else if (PNTTYPE_DIGITALOUTPUT == GetInitPntType(Idx)) {
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        if (PNTTYPE_ANALOGINPUT == GetInitPntType(Idx)) {
            if (HART_UNCONFIGURED_OP == Op_Saved[Idx - 1]) {
                // Unconfigured channel: Clear HART db, update status, and delete channel config
                AIH_SLOT(Idx)->SetHEnable(FALSE);
                AIH_SLOT(Idx)->PostHEnable(ALVL_PBD);
                SetHADCStatus(Idx,HART_DATA_UNKNOWN);
                AbortHartConnection(Idx);
                AIH_SLOT(Idx)->GetHartDevDb().InitDevDb(TRUE);
                AIH_SLOT(Idx)->GetHartDevDb().BuildScanTable();
                AIH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
                UIO_SLOT(Idx)->DeleteConfiguredSlot();
                Op_Saved[Idx - 1] = OP_LOLIMIT;
            }
            else {
                // Restore old value of HEnable if it was FALSE
                if (FALSE==HEnableSaved[Idx - 1]) {
                    AIH_SLOT(Idx)->SetHEnable(FALSE);
                    AIH_SLOT(Idx)->PostHEnable(ALVL_PBD);
                    SetHADCStatus(Idx,HART_DATA_UNKNOWN);
                    AIH_SLOT(Idx)->GetHartDevDb().InitDevDb(TRUE);
                    AIH_SLOT(Idx)->GetHartDevDb().BuildScanTable();
                    AIH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
                }
            }
        }
        else if (PNTTYPE_ANALOGOUTPUT == GetInitPntType(Idx)) {
            // Restore old value of HEnable if it was FALSE
            if (FALSE==HEnableSaved[Idx - 1]) {
                AOH_SLOT(Idx)->SetHEnable(FALSE);
                AOH_SLOT(Idx)->PostHEnable(ALVL_PBD);
                SetHADCStatus(Idx,HART_DATA_UNKNOWN);
                AOH_SLOT(Idx)->GetHartDevDb().InitDevDb(TRUE);
                AOH_SLOT(Idx)->GetHartDevDb().BuildScanTable();
                AOH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
            }
            // Drive to old value, clear HART db, and update status
            SetOp(Idx,Op_Saved[Idx - 1]);
            AOH_SLOT(Idx)->GetHartDevDb().InitDevDb(TRUE);
            BOX->SetHADCStatus(WriteIndex, HART_DATA_UNKNOWN);
            AOH_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
            Op_Saved[Idx - 1] = OP_LOLIMIT;
        }
        else if (PNTTYPE_DIGITALINPUT == GetInitPntType(Idx)) {
            //FPGA.SetDigitalInputDacHigh(Idx);
            //SetHADCStatus(Idx,HART_DATA_UNKNOWN);
            //DI_SLOT(Idx)->GetHartDevDb().InitDevDb(TRUE);
            //DI_SLOT(Idx)->GetHartDevDb().BuildScanTable();
            //DI_SLOT(Idx)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
        else if (PNTTYPE_DIGITALOUTPUT == GetInitPntType(Idx)) {
        }
    }
    TraceLog.AddToTrace(TRACEID_GENERIC,bcHAdcEnable,Idx<<24 + Data.ucBytes[1]<<16 + GetInitPntType(Idx)<<8 + GetHADCStatus(Idx));
}

