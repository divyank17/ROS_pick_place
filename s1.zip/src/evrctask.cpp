/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : evrctask.cpp                                                *
*    Description : Event recovery task common to all IOMs.                     *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif
#ifdef IOMTYPE_AOH
#include "aohmain.h"
#endif
#if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
#include "dimain.h"
#endif
#ifdef IOMTYPE_DO
#include "domain.h"
#endif
#ifdef IOMTYPE_LLMUX
#include "llmuxmain.h"
#endif
#ifdef IOMTYPE_SVP
#include "svpmain.h"
#endif
#ifdef IOMTYPE_SP
#include "spmain.h"
#endif
#ifdef IOMTYPE_PI
#include "pimain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif
/*******************************************************************************
*                               EventRecoveryTask                              *
*                               =================                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN EventRecoveryTask(TASKCONTEXT a_TaskContext) 
{
    static UINT8 sucSlotNum = 1;

    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    TASKRETURN TaskReturn;
    TaskReturn.TaskReturnState = TASKRETURNSTATE_SUSPEND;
    TaskReturn.TaskContext     = a_TaskContext;
    TaskReturn.ucSuspendTime   = 0;
#ifdef IOMTYPE_DISOE
    if(TASKCONTEXT_FOUR <= a_TaskContext) {
        if (FALSE == BOX->IsRoomForPVCLRegen()) {
            TraceLog.AddToTrace(TRACEID_GENERIC,bcNoRoomForRegen,(UINT32)a_TaskContext);
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            return TaskReturn;
        }
    }
    else {
#endif
        if (BOX->IsRoomForRegen() == FALSE) {
            TraceLog.AddToTrace(TRACEID_GENERIC,bcNoRoomForRegen,(UINT32)a_TaskContext);
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            return TaskReturn;
        }
#ifdef IOMTYPE_DISOE
    }
#endif
    switch (TaskReturn.TaskContext) {
    case TASKCONTEXT_ZERO:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcEvrcBegin);
        if (FALSE == BOX->AddBracketEvent(EVENTSUBTYPE_RECOVERYSTART)) {
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            break; 
        }
        TaskReturn.TaskContext = TASKCONTEXT_ONE;
        // break statement is intentionally removed to fall through next context.
    case TASKCONTEXT_ONE:
        if (FALSE == BOX->AddModStatEvent(EVENTTYPE_RECOVERY)) {
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            break;
        }
        TaskReturn.TaskContext = TASKCONTEXT_TWO;
        // break statement is intentionally removed to fall through next context.
    case TASKCONTEXT_TWO:
        if (TRUE == BOX->RegenSoftfails()) {
            TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcExec);
            RtnSts = RETURNSTATUS_COMPLETE; 
        }
        break;
    case TASKCONTEXT_THREE:
        while (sucSlotNum <= MAXSLOTS) {
#if defined(IOPTYPE_HLAI)            
            // Modified to resolve, PAR# 1-7HX4J5B
            if (SLOT(sucSlotNum)->AlarmEvents(EVENTTYPE_RECOVERY) == TRUE) {
#elif defined(IOPTYPE_DI)
            // for PAR#1-98BB9AN (DI24), PAR#1-987WTI3 (DI), PAR#1-98BB9B9 (DI/DI24) fixing
            if (SLOT(sucSlotNum)->AlarmEvents(EVENTTYPE_RECOVERY) == TRUE) {
#else
            if (SLOT(sucSlotNum)->RegenChannelEvents() == TRUE) {
#endif
                TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcExec,(UINT32)sucSlotNum);
                sucSlotNum++; 
            }
            else {
                TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
                break;
            }
        }
        if (sucSlotNum > MAXSLOTS) {
            sucSlotNum = 1; // Reset for next regen.
            #ifdef IOMTYPE_DISOE
            TaskReturn.TaskContext = TASKCONTEXT_FOUR;
            #else
            TaskReturn.TaskContext = TASKCONTEXT_SEVEN;
            #endif
            // break statement is intentionally removed to fall through next context.
        }
        else {
            break;
        }
#ifdef IOMTYPE_DISOE
    case TASKCONTEXT_FOUR:
        // start regeneration of PVCL events
        TraceLog.AddToTrace(TRACEID_GENERIC,bcEvrcBegin);
        if (FALSE == BOX->AddPVCLBracketEvent(EVENTSUBTYPE_RECOVERYSTART)) {
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            break; 
        }
        TaskReturn.TaskContext = TASKCONTEXT_FIVE;
        // break statement is intentionally removed to fall through next context.
    case TASKCONTEXT_FIVE:
        if (FALSE == BOX->PVCLEvtRegen()) {
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            break;
        }
        TaskReturn.TaskContext = TASKCONTEXT_SIX;
        break;
    case TASKCONTEXT_SIX:
        if (FALSE == BOX->AddPVCLBracketEvent(EVENTSUBTYPE_RECOVERYEND)) {
            TaskReturn.ucSuspendTime = EVERC_SUSPENDTIME;
            break;
        }
        BOX->SetPVCLEvtRegInProgress(FALSE);
        TaskReturn.TaskContext = TASKCONTEXT_SEVEN;
        // break statement is intentionally removed to fall through next context.
#endif
    case TASKCONTEXT_SEVEN:
        if (TRUE == BOX->AddBracketEvent(EVENTSUBTYPE_RECOVERYEND)) {
            RtnSts = RETURNSTATUS_COMPLETE; 
        }
        break;
    default:
        HardFail(HF_BADPROGRAMJUMP,EVRCTASK_CPP,__LINE__);
    }

    // if the current operation is complete, advance to next context.
    if (RETURNSTATUS_COMPLETE == RtnSts) {
        if (TaskReturn.TaskContext < TASKCONTEXT_FOUR) {
            TaskReturn.TaskContext = (TASKCONTEXT)((UINT8)TaskReturn.TaskContext + 1);
        }
        else { // All contexts finished.
            TraceLog.AddToTrace(TRACEID_GENERIC,bcEvrcEnd);
            TaskReturn.TaskReturnState = TASKRETURNSTATE_TERMINATE;
        }
    }

    if (TASKRETURNSTATE_TERMINATE == TaskReturn.TaskReturnState) {
        TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcTerminated);
    }
    else {
        TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcSuspended,
                            (UINT32)TaskReturn.ucSuspendTime);
    }

    return TaskReturn;
}
#ifdef IOMTYPE_DISOE
/*******************************************************************************
*                               EventManagerTask                               *
*                               =================                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN EventManagerTask(TASKCONTEXT a_TaskContext)
{
    // The SUSPEND_TIME is preset to two seconds, and the Restore Unsent
    // Packets routine is called.  This routine checks the PV Change Log for packets
    // that did not make it to the PV Change Circular List, and attempts to send
    // those packets.  Upon return, if the SUSPEND_TIME has changed, then the Restore
    // Unsent Packets routine took some action, requiring an immediate suspend for
    // the new SUSPEND_TIME.

    // If the Restore Unsent Packets routine takes no action, then the Discard
    // Old Packets routine is called to throw away packets in the PV Change Log that
    // are over twenty seconds old.  If any packets are discarded, the SUSPEND_TIME
    // will be updated (by the Discard Old Packets routine).  The Executive Task
    // Suspend routine is then called to suspend the task.

    TASKRETURN TaskReturn;
    TaskReturn.TaskReturnState = TASKRETURNSTATE_SUSPEND;
    TaskReturn.TaskContext     = a_TaskContext;
    TaskReturn.ucSuspendTime   = TWO_SEC_SUSPEND;
    TaskReturn.ucSuspendTime = BOX->Restore_Unsent_Pkts();
    if(TaskReturn.ucSuspendTime == TWO_SEC_SUSPEND)
    {
        TaskReturn.ucSuspendTime = BOX->Discard_Old_Pkts(TaskReturn.ucSuspendTime);
    }
    //TraceLog.AddToTrace(TRACEID_EVRCTASK,bcEvrcSuspended);
    return TaskReturn;
}
#endif
