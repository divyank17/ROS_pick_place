/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : dimain.h                                                    *
*    Description : common defines used by module                               *
*******************************************************************************/
#ifndef __DIMAIN_H__
#define __DIMAIN_H__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "commonelectronics.h"
#include "tracelog.hpp"
#include "debug.hpp"
#include "scheduler.hpp"
#include "diag.h"
#include "wrmsgque.hpp"
#ifdef IOMTYPE_DISOE
#include "disoeversion.h"
#else
#include "diversion.h"
#endif
#include "diboxslot.hpp"
#include "dislot.hpp"

#endif 
