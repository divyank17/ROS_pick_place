/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uiofpga.hpp                                                 *
*    Description : UIO FPGA class definition file                              *
*******************************************************************************/
#ifndef __UIOFPGA_HPP__
#define __UIOFPGA_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "datatype.h"
#include "commonelectronics.h" // included for FPGA register definitions
#include "ioslot.hpp" // included for PNTTYPE definition

class clsUioFpga;
extern clsUioFpga FPGA;

enum IOBOARD
{
    eIoBoard1     = 0, // channels 1 through 16
    eIoBoard2     = 1, // channels 17 through 32

    eMaxNumIoBoards = 2
};

enum SCANTYPE
{
    eFilteredAnalogCurrent        = 0, // fRB_ACurrent
    eFilteredPartialAnalogCurrent = 1, // fRB_ACurrentP
    eAnalogCurrent                = 2, // RB_ACurrent
    eDigitalCurrent               = 3, // RB_DCurrent
    eDigitalCurrentAdj            = 4, // RB_DCurrent_Adjust_ComPP
    eVoltages                     = 5, // RB_Voltages
    eCtrlChInd                    = 6, // Ctrl_Ch_Independence
    eClrResultReg                 = 7  // Clr_Result_Reg
};

enum DOSOREGISTER
{
    eDoSoRegister0 = 0, // channels 1 through 8
    eDoSoRegister1 = 1, // channels 9 through 16
    eDoSoRegister2 = 2, // channels 17 through 24
    eDoSoRegister3 = 3, // channels 25 through 32

    eMaxNumDoSoRegs = 4
};

enum BOARDVOLTAGE
{
    eBoardVoltage0          = 0,  // not used
    eBoardVoltage1          = 1,  // not used
    e3V3BoardVoltage        = 2,
    eNeg8VBoardVoltage      = 3,
    eNeg12V5BoardVoltage    = 4,
    e24VBoardVoltage        = 5,
    eVersionNr              = 6,
    eBoardVoltage7          = 7,  // not used
    eBoardVoltage8          = 8,  // not used
    eAD_Tst                 = 9,
    eBoardVoltage10         = 10, // not used
    eVtest                  = 11,
    eNeg2V5BoardVoltage     = 12,
    e4V096BoardVoltage      = 13,
    eNeg5VrBoardVoltage     = 14,
    eBoardVoltage15         = 15, // not used

    eMaxNumBoardVoltages    = 16

};

// Common per board channel selection masks
#define SCAN_ALL_CHANNELS       (UINT16)0xFFFF  // Bit mask to select all channels of an IO Board

#define SCAN_REF_VOLTAGES       (UINT16)((UINT16)0x1 << e3V3BoardVoltage      | \
                                         (UINT16)0x1 << eNeg8VBoardVoltage    | \
                                         (UINT16)0x1 << eNeg12V5BoardVoltage  | \
                                         (UINT16)0x1 << e24VBoardVoltage      | \
                                         (UINT16)0x1 << eNeg2V5BoardVoltage   | \
                                         (UINT16)0x1 << e4V096BoardVoltage    | \
                                         (UINT16)0x1 << eNeg5VrBoardVoltage)

/*******************************************************************************
*                                  clsUioFpga                                  *
*                                  ==========                                  *
*******************************************************************************/
class clsUioFpga 
{
    private:

        // constants
        enum { kChansPerIoBoard   = 16 };
        enum { kModemsPerIoBoard  = 1  };

        // constants for Digital Input, 
        // <JRF ToDo> per UIO Cookbook 2/20/12, chapter 33
        enum { kDiMaxOffThreshold = 0x126F };
        enum { kDiMinOnThreshold  = 0x1581 };

        // constants for openwire detection.(UIO Cookbook 03/23/2012, chapter 30,32)
        enum { kDiOpenWireThreshold = 0x06E9 }; // DI channel open wire threshold ADC raw count
        enum { kAiOpenWireThreshold = 0x275A }; // AI channel open wire threshold ADC raw count

        // scan request registers
        static volatile st_fpga_io_scanrequest * const pScanReqRegister[eMaxNumIoBoards];

        // IO board status registers
        static volatile st_fpga_statusword * const pStatusRegister[eMaxNumIoBoards];

        // DAC registers
        static volatile UINT16 * const pDacRegister[eMaxNumIoBoards];

        // digital output registers
        static volatile UINT16 * const pDoRegister[eMaxNumDoSoRegs];

        // Constants for Digital Output diagnostics 
        enum { kDoDacEnable             = 0x00CE }; // 1 mA (UIO Cookbook 08/28/2012, Chapters 11, 12)
        enum { kDoDacDisable            = 0x0000 }; // DAC disabled
        enum { kDoACurrentLow           = 0x04AA }; // 0.5 mA
        enum { kDoOnReadbackThreshold   = 0x0171 }; // 11 mA nominal (low sensitivity)
        enum { kDoOffReadbackThreshold  = 0x031C }; // 9 uA nominal (high sensitivity)

        // constants for calibration
        enum { kInitialCalibDacCount   = 0x0C00 };
        enum { kMinCalibDacCount       = 0x0000 };
        enum { kMaxCalibDacCount       = 0x0FFF };
        enum { kTargetCalibAdcCount    = 0x2E49 };
        enum { kCalibAdcThreshold      =      4 };
        enum { kDAConversionTime       =    300 };  // 300 uSec for runtime DA conversion delay (from rusio)
        enum { kStartupDAConversionTime =   5000 };  // 5 mSec for startup DA conversion delay

        // constants for Analog Input Nan Threshold
        enum { kEnterNaNThreshold      = 0x01A3 };    // Enter NaN at -24% or 0.16 mA
        enum { kExitNaNThreshold       = 0x020B };    // Exit NaN at -23.75% or 0.20 mA

        // Accesses Min and Max Reference voltages values from a table
        struct RefVoltageValueTableEntry
        {
            UINT16     MinAdcCount;
            UINT16     MaxAdcCount;
        };

        // Reference Voltage Ranges
        static const RefVoltageValueTableEntry ReferenceVoltageLimits[]; 

        // Digital Input DAC constants
        static const UINT16 kDigitalInputDacCountHigh;
        static const UINT16 kDigitalInputDacCountLow;
        static const UINT16 kPulseCountDacCountHigh;
        // default thermometer configuration
            // per Dallas Semiconductor DS1722 datasheet
            // 1110 1000  = 0xE8
            // |||| ||||
            // |||| |||+- SD    : Shutdown bit. We do not shutdown, so bit is cleared
            // |||| ||+-- R0    : 0
            // |||| |+--- R1    : 0
            // |||| +---- R2    : 1   R0, R1 and R2 are set for 12-bit resolution
            // ||||
            // |||+------ 1SHOT : One-shot mode. We use continuous mode, so bit is cleared
            // +++------- N/A   : defaults to 1
        enum { kDefaultThermConfig  = 0xE8 };

        // thermometer register addresses
        enum { kThermAddrReadConfig  = 0x00 };
        enum { kThermAddrWriteConfig = 0x80 };

        // thermometer read structure
        union uThermRead
        {
            UINT32 dword;
            struct 
            {
                UINT8 NotUsed;
                UINT8 ConfigByte;
                UINT8 TempLSB;
                UINT8 TempMSB;
            } bytes;
        };

        // Pulse counting voltage threshold constants
        enum {kThresholdHighConfig = 0x0490};  // corresponds to -4.2V
        enum {kThresholdLowConfig  = 0x0490};  // corresponds to -4.94v

    public:
        UINT16 LastCounterVal[4];    // Stores the previous FPGA counter value for pulse count

        clsUioFpga(VOID) 
        { 
            lastDacCount[eIoBoard1] = lastDacCount[eIoBoard2] = kInitialCalibDacCount;
        }

        // hardware setup methods
        VOID PerformStartupInit(VOID);
        VOID ConfigureChannel(UINT8 chanNum, PNTTYPE pntType);

        // I/O board status accessors
        BOOL IsScanComplete(IOBOARD ioBoard);
        BOOL IsDacFifoFull(IOBOARD ioBoard);

        // input/output read methods
        inline UINT16 MilliampsToAdcCount(FLOAT32 fCurrent) { return (UINT16)((0xFFFF / 25.0) * fCurrent); }
        VOID    IssueScanRequest(IOBOARD ioBoard, SCANTYPE scanType, UINT16 chanReqMask);
        inline FLOAT32 ReadAnalogInput(UINT8 chanNum) { return ((FLOAT32)Read_fRB_ACurrent(chanNum)); }
        BOOL    ReadDigitalInput(UINT8 chanNum, BOOL bLastRead);
        UINT16 ReadAnalogOutput(UINT8 chanNum) { return (Read_RB_ACurrent(chanNum)); }
        BOOL    ReadDigitalOutput(UINT8 chanNum);

        // digital input DAC adjustment methods
        inline VOID SetDigitalInputDacHigh(UINT8 chanNum) { DriveDAC(chanNum, kDigitalInputDacCountHigh); }
        inline VOID SetDigitalInputDacLow(UINT8 chanNum) { DriveDAC(chanNum, kDigitalInputDacCountLow); }
        inline VOID SetPulseCountDacHigh(UINT8 chanNum) { DriveDAC(chanNum, kPulseCountDacCountHigh); }

        // returns a status of 1 for each pin which is bad
        UINT32 TestDigitalOutputPins(VOID);

        // hard fail if the FPGA CRC check has failed
        VOID TestFPGAConfigurationReadback(VOID) { if(0 == FPGA_INIT_n) HardFail(HF_FPGARDBKFAIL, UIOFPGA_HPP, __LINE__); }

        // analog output write methods
        inline UINT16 MilliampsToDacCount(FLOAT32 fCurrent) { return ((UINT16)(166.2 * fCurrent) + 40); }
        inline VOID WriteAnalogOutput(UINT8 chanNum, UINT16 uDacCount)
        {
            uDacCount =  0x0FFF & uDacCount;
            DriveDAC(chanNum, uDacCount);
        }
        inline VOID WriteAnalogOutput(UINT8 chanNum, FLOAT32 fCurrent)
        {
            UINT16 uDacCount =  0x0FFF & MilliampsToDacCount(fCurrent);
            DriveDAC(chanNum, uDacCount);
        }

        // digital output write methods
        VOID WriteDigitalOutput(UINT8 chanNum, BOOL bSO);
        VOID WriteDigitalOutputAll(UINT32 chanMask, UINT32 SO);

        // diagnostics

        // checks for open wire condition on an AI channel
        inline BOOL IsOpenWireAI(UINT8 chanNum)
        {
            return (Read_fRB_ACurrent(chanNum) < kAiOpenWireThreshold);
        }
        // checks for open wire condition on a DI channel
        inline BOOL IsOpenWireDI(UINT8 chanNum)
        {
            return (Read_fRB_ACurrent(chanNum) < kDiOpenWireThreshold);
        }
        
        BOOL IsAboveNanEnterThreshold(UINT8 chanNum);
        BOOL IsAboveNanExitThreshold(UINT8 chanNum);
        BOOL AreRefVoltagesGood(IOBOARD ioBoard);
        BOOL IsShortCircuit(BOOL chanOn, UINT8 chanNum);
        BOOL IsOpenWireDO(BOOL chanOn, UINT8 chanNum);
        BOOL IsOutputFailureDO(BOOL chanOn, UINT8 chanNum);
        BOOL IsHartAddressRegisterValid(UINT8 modem);
        
        inline void EnableDigitalOutputDac(UINT8 chanNum) 
        {
            DriveDAC(chanNum, kDoDacEnable);
        }
        
        inline void DisableDigitalOutputDac(UINT8 chanNum) 
        {
            DriveDAC(chanNum, kDoDacDisable);
        }        

        // calibration methods
        UINT16 Read4v096Averaged(IOBOARD ioBoard, int iter);
        void CoarseCalibrate(IOBOARD ioBoard);
        BOOL RuntimeCalibrate(IOBOARD ioBoard, UINT16 adc_4v096);
        BOOL StartupCalibrate(IOBOARD ioBoard);
        BOOL IsCalibrationGood(IOBOARD ioBoard)
        {
            BOOL bCalibrationGood = TRUE;

            if ((lastDacCount[ioBoard] <= kMinCalibDacCount) ||
                (lastDacCount[ioBoard] >= kMaxCalibDacCount))
            {
                bCalibrationGood = FALSE;
            }

            return bCalibrationGood;
        }

        // HART methods
        
        // Returns the modem for the given channel
        inline UINT8 GetChannelModem(UINT8 chanNum)
        {
            // One modem per IO board....
            // Board 1 => Modem 0
            // Board 2 => Modem 1
            return (UINT8)GetChannelIoBoard(chanNum);
        }
        
        // Returns the IOBOARD for the given channel
        inline IOBOARD GetChannelIoBoard(UINT8 chanNum)
        {           
            return (IOBOARD)((chanNum - 1) / kChansPerIoBoard);
        }    
        
        // Returns the IOBOARD for the given modem
        inline IOBOARD GetModemIoBoard(UINT8 modem)
        {
            return (IOBOARD)((modem) / kModemsPerIoBoard);
        }
        
        // Enable/Disable HART transmitter
        VOID EnableHartTransmitter(UINT8 chanNum, BOOL enable);
        
        // Configure the amplifier gain for the HART modem
        VOID ConfigureHartAmplifierGain(UINT8 a_ChanNum, PNTTYPE a_PntType);
        
        // Sets the address bits for the HART multiplexer
        VOID SetHartAddress(UINT8 chanNum);
        
        // Returns TRUE if HART communication is in progress for the given channel
        BOOL IsHartCommInProgress(UINT8 chanNum);

        // digital thermometer
        FLOAT32 ReadThermometer(UINT8 * const a_pConfigByte = NULL);

        // pulse counting inline functions
        inline UINT16 GetCounter(UINT8 chanNum)
        {
            unsigned int nIdx = chanNum - PC_CHANNEL1;
            return (PC_READBACK_REGS[nIdx].nReadCounter);
        }

        inline VOID SetFilter(UINT8 chanNum,UINT16 uFilterCount)
        {
            unsigned int nIdx = chanNum - PC_CHANNEL1;
            PC_READBACK_REGS[nIdx].nSetFilter = (uFilterCount & 0x00FF);
        }

        inline VOID ClrCounter(UINT8 chanNum)
        {
            unsigned int nIdx = chanNum - PC_CHANNEL1;
            PC_READBACK_REGS[nIdx].nClrCounter = 0x0000;
            LastCounterVal[nIdx] = 0x0000;
        }

        VOID InitializeHardwareForPulseCount(UINT8 ChanNum);  // Sets the Voltage and Filter for the pulse counting channel

        inline UINT16 Read_BoardVoltage(IOBOARD ioBoard, unsigned int boardVoltage) { return (ADC_READBACK_REG[boardVoltage + (ioBoard * kChansPerIoBoard)].RB_Voltages); }

    // the following methods are private, except in the DEBUG image where they are accessed in debug.cpp
#if !defined (DEBUG)
    private:
#endif // !defubed (DEBUG)
        UINT16 lastDacCount[eMaxNumIoBoards];

        // DAC access
        inline VOID DriveDAC(UINT8 chanNum, UINT16 uDacCount)
        {
            IOBOARD ioBoard = (IOBOARD)((chanNum - 1) / kChansPerIoBoard);
            unsigned int idx = (chanNum - 1) % kChansPerIoBoard;
            (pDacRegister[ioBoard])[idx] = 0x0FFF & uDacCount;
        }
        VOID DriveFiveVoltRefDAC(IOBOARD ioBoard, UINT16 uDacCount);
        VOID ClearDACs(VOID);

        // Digital Output access
        VOID DriveDo(DOSOREGISTER DoSoReg, UINT8 chanMask, UINT8 uSO);

        // Misc Flip Flop register access
        VOID DriveOptoFETs(BOOL bEn);
        VOID ResetSPI(VOID);

        // ADC access
        inline UINT16 Read_fRB_ACurrent(UINT8 chanNum)
        {
            unsigned int idx = chanNum - 1;
            return (ADC_READBACK_REG[idx].fRB_ACurrent);
        }
        
        inline UINT16 Read_RB_ACurrent(UINT8 chanNum)
        {
            unsigned int idx = chanNum - 1;
            return (ADC_READBACK_REG[idx].RB_ACurrent);
        }
        
        inline UINT16 Read_RB_DCurrent(UINT8 chanNum)
        {
            unsigned int idx = chanNum - 1;
            return (ADC_READBACK_REG[idx].RB_DCurrent);
        }

        // SPI and digital thermometer setup methods
        VOID InitSpi(VOID);
        VOID ConfigureThermometer(const UINT8 a_ConfigByte);

}; // clsUioFpga

#endif // __UIOFPGA_HPP__
