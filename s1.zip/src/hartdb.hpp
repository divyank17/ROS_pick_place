/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hartdb.hpp                                                  *
*    Description : HART database classes declaration.                          *
*******************************************************************************/
#ifndef __HARTDB_HPP__
#define __HARTDB_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "hart.h"
#include "hartstack.hpp"
#include "ecl.hpp"
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagHScanCfg {
    HSCANCFG_UNDEFINED      = 0,
    HSCANCFG_1SECDEV        = 1,
    HSCANCFG_1SECDYN        = 2,
    HSCANCFG_2SECDEV        = 3,
    HSCANCFG_2SECDYN        = 4,
    HSCANCFG_2SECDEVDYN     = 5,
    HSCANCFG_4SECDEV        = 6,
    HSCANCFG_4SECDYN        = 7,
    HSCANCFG_4SECDEVDYN     = 8,
    HSCANCFG_8SECDEV        = 9,
    HSCANCFG_8SECDYN        = 10,
    HSCANCFG_8SECDEVDYN     = 11,
    HSCANCFG_16SECDEV       = 12,
    HSCANCFG_16SECDYN       = 13,
    HSCANCFG_16SECDEVDYN    = 14,
    HSCANCFG_STATUSONLY     = 15
} HSCANCFG;

typedef enum tagHScanRate {
    HSCANRATE_NONE  = 0,
    HSCANRATE_16SEC = 1,
    HSCANRATE_8SEC  = 2,
    HSCANRATE_4SEC  = 4,
    HSCANRATE_2SEC  = 8,
    HSCANRATE_1SEC  = 16
} HSCANRATE;

typedef enum tagHComSts {
    HCOMSTS_GOOD          = 0,
    HCOMSTS_NORESPONSE    = 1,
    HCOMSTS_IOMFOUNDERROR = 2,
    HCOMSTS_DEVFOUNDERROR = 3,
    HCOMSTS_CHANNELERROR  = 4
} HCOMSTS;

typedef enum tagCommand {
    COMMAND_UNDEFINED    = 0,
    COMMAND_ACCEPTCFG    = 9,
    COMMAND_RESETHCOMERR = 10
} COMMAND;

// HCHANTYPE represents the type of current HART message -
// channel initiated or passthrogh message.
typedef enum tagHChanType { 
    HCHANTYPE_UNKNOWN,    // Initialization value.
    HCHANTYPE_CHANNEL,    // Channel initiated message.
    HCHANTYPE_PASSTHROUGH // Pass through client.
} HCHANTYPE;

// HCHANMODE defines the state of HART channel.
typedef enum tagHChanMode { 
    HCHANMODE_INIT,  // Scheduling HART commands from init table.
    HCHANMODE_SCAN   // Scheduling HART commands from scan table.
} HCHANMODE; 

// Defines the scan configuration in the channel scan table.
typedef enum tagHScanMsg { 
    HSCANMSG_NONE, // No scan configured.
    HSCANMSG_DYN,  // Dynamic scan.
    HSCANMSG_DEV,  // Device scan.
    HSCANMSG_C48,  // Command 48 scan.
    HSCANMSG_PST   // Passthrough message.
} HSCANMSG;

// Data initialization status for remote fetch pending.
typedef enum tagHDataInit {
    HDATAINIT_PENDING  = 0,
    HDATAINIT_COMPLETE = 1
} HDATAINIT;

// HEVENTINIT - Event intialization status for IOLP event recovery task
typedef enum tagHEventInit {
    HEVENTINIT_PENDING = 0,
    HEVENTINIT_COMFAIL = 1,
    HEVENTINIT_C48FAIL = 2,
    HEVENTINIT_SUCCESS = 3
} HEVENTINIT;

// Defines the status of the decoded response and the action to be followed.
typedef enum tagHReplyStatus { 
    HREPLYSTATUS_GOOD,     // Good response.
    HREPLYSTATUS_CONTINUE, // Warnings present, but continue.
    HREPLYSTATUS_BUSY,     // Device is busy, continue after a wait.
    HREPLYSTATUS_MORE,     // Response indicates to issue CMD48.
    HREPLYSTATUS_REINIT,   // Response indicates to rediscover.
    HREPLYSTATUS_BAD       // Bad response.
} HREPLYSTATUS;

typedef enum tagHPstStatus {
    HPSTSTATUS_IDLE         = 0,    
    HPSTSTATUS_BUSY         = 0xCA, // Not used now.
    HPSTSTATUS_RUNNING      = 0xCB, // IOM waiting for response.
    HPSTSTATUS_INIT         = 0xCC, // IOM just queued a request.
    HPSTSTATUS_DEAD         = 0xCD, // Passthrough aborted/failed.
    HPSTSTATUS_SUCCESS      = 0xCE  // Completed successfully.
} HPSTSTATUS;

// HART_CMD_HANDLER_TBL defines GOOD_HANDLER and BAD_HANDLER for each supported
// HART commands. GOOD_HANDLER and BAD_HANDLER are function pointer types. These
// handlers are invoked based on the HART communication status and the response 
// code returned by the device.
class clsHartDevDb; // Forward declaration
typedef struct tagHartCmdHandler {
    HREPLYSTATUS (clsHartDevDb::* GoodHandler)(VOID);
    HREPLYSTATUS (clsHartDevDb::* BadHandler)(UINT8);
} HARTCMDHANDLER;
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Size defined in UINT16 units so as that the object is aligned in even memory
// boundary. This is required to ensure the alignment of individual members.
#define CLSHARTPST_SIZE ((sizeof(clsHartPst)+(sizeof(clsHartPst)%2)) / 2)

const UINT8  HART6_MAXVAR_COUNT = 4; //Max Device variables till HART revision 6.
const UINT8  HART_MAXVAR_COUNT  = 8; //Device variables in HART revision > 7
const UINT8  HART_MAXDYNVAR_COUNT= 4; //Dynamic variables
const UINT8  HNTFYCFG_BYTECOUNT = HART_CMD48_RESPONSE_SIZE * 2;
const UINT16 HCOMTHRS_DEFAULT   = 100;
const UINT16 HCOMHYS_DEFAULT    = 10;

// The following constants are used for defining the scan table. Scan table 
// has 16 rows and 3 columns of HSCANMSG entries. HART processing task processes
// each row per second, allowing a maximum of three messages per cycle. The
// term B2B refres to back-to-back messages that will be scheduled without 
// disconnecting from the currently connected modem.
const UINT8 MIN_CYCLE_NUMBER    = 1;
const UINT8 MAX_CYCLE_NUMBER    = 16;
const UINT8 MAX_MSGS_IN_A_CYCLE = 3;
const UINT8 FIRST_SCAN_MSG      = 0; // For accessing first column
const UINT8 FIRST_B2B_MSG       = 1; // For accessing second column
const UINT8 FINAL_B2B_MSG       = 2; // For accessing third column

// Following constants defines number of channel heartbeats for different 
// scan rates. These constants are used to define values for the channel 
// object memeber m_sScanCounter to time the scheduling of scan messages 
// to HART queue. If a channel is configured for one second scan, a modem
// gets dedicated to the channel and the scheduling is done back-to-back 
// without the use of the queue. So, for these one second channels, scan
// counter will be set to TICKS_SYNCED_CHAN which is equal to zero. For 
// channels with HENABLE = FALSE, scan counter is set to TICKS_DISABLE_SCAN 
// which is defined as -1 so thatT disabled channel can be differentiated 
// from a synced channel.
const INT16 TICKS_IN_1_SEC      = 1; // No of channel heartbeats in one second.
const INT16 TICKS_IN_2_SEC      = TICKS_IN_1_SEC * 2;
const INT16 TICKS_IN_4_SEC      = TICKS_IN_1_SEC * 4;
const INT16 TICKS_IN_8_SEC      = TICKS_IN_1_SEC * 8;
const INT16 TICKS_IN_16_SEC     = TICKS_IN_1_SEC * 16;
const INT16 TICKS_IN_30_SEC     = TICKS_IN_1_SEC * 30;
const INT16 TICKS_IN_60_SEC     = TICKS_IN_1_SEC * 60;
const INT16 TICKS_IN_64_SEC     = TICKS_IN_1_SEC * 64;
const INT16 TICKS_SYNCED_CHAN   = 0;  // For a 1 second channel.
const INT16 TICKS_DISABLE_SCAN  = -1; // HART scan is disabled.

const HSCANRATE HSCANCFG_TABLE[HSCANCFG_STATUSONLY+1][2] = {
    HSCANRATE_NONE, HSCANRATE_NONE,
    HSCANRATE_1SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_1SEC,
    HSCANRATE_2SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_2SEC,
    HSCANRATE_2SEC, HSCANRATE_2SEC,
    HSCANRATE_4SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_4SEC,
    HSCANRATE_4SEC, HSCANRATE_4SEC,
    HSCANRATE_8SEC, HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_8SEC,
    HSCANRATE_8SEC, HSCANRATE_8SEC,
    HSCANRATE_16SEC,HSCANRATE_NONE,
    HSCANRATE_NONE, HSCANRATE_16SEC,
    HSCANRATE_16SEC,HSCANRATE_16SEC,
    HSCANRATE_NONE, HSCANRATE_NONE    
};

// In order to perform a HART transaction, client objects will pass only the
// message buffer containing command, byte count and data to the modem objects. 
// Other fields of the HART message are constructed by the modem object as 
// explained below.
//
// Delimiter - modem object determines depending on the current command.
// Address - after discovery, address of the device is stored as a channel
// object member. Modem object uses the callback interface to get address.
// Checksum - computed by the modem object after framing the request.
//
// The above sheme helps in declaring only one set of constant transmit buffer 
// per command in the flash memory which can be shared by all channel objects. 
// Had fully formed transmit messages are to be passed to the modem objects, 
// each channel object would have to have separate transmit buffers in RAM as 
// the address handled by each channel object is different and variable.

// HART message definitions for channel objects (used as XMT buffer).
const UINT8 HARTCMD0[]   = { HARTCOMMAND_ZERO,0 };         // Read unique identifier.
const UINT8 HARTCMD38[]  = { HARTCOMMAND_THIRTYEIGHT,0 };  // Reset config changed bit.
const UINT8 HARTCMD48[]  = { HARTCOMMAND_FOURTYEIGHT,0 };  // Read additional device status.
const UINT8 HARTCMD109[] = { HARTCOMMAND_HUNDREDNINE,1,0}; // Turn off burst mode.

// Number of HART initialization commands that will be issued during discovery.
const UINT8 HART_INITCOMMAND_COUNT  = 11;
const UINT8 HART_INITCMD14_INDEX    = 6;
const UINT8 HART_INITCMD15_INDEX    = 7;

// Initialization commands for HART revision 5 devices (used as XMT buffer).
const UINT8 HART5_INIT_COMMANDS[HART_INITCOMMAND_COUNT][3] = { 
    { HARTCOMMAND_FOURTYEIGHT,0 }, // Read additional device status.
    { HARTCOMMAND_FIFTYNINE,1,5 }, // Set no. of response preambles to 5. 
    { HARTCOMMAND_SIX,1,0 },       // Set polling address to zero.
    { HARTCOMMAND_THIRTYEIGHT,0 }, // Reset config changed bit.
    { HARTCOMMAND_TWELVE,0 },      // Read message.
    { HARTCOMMAND_THIRTEEN,0 },    // Read tag, descriptor and date.
    { HARTCOMMAND_FOURTEEN,0 },    // Read primary variable transducer information.
    { HARTCOMMAND_FIFTEEN,0 },     // Read device information.
    { HARTCOMMAND_SIXTEEN,0 },     // Read final assembly number.
    { HARTCOMMAND_TWENTY, 0},      // Long Tag.
    { HARTCOMMAND_FIFTY,0 }        // Read dynamic variable association.
};

// Initialization commands for HART revision 6 devices (used as XMT buffer).
const UINT8 HART6_INIT_COMMANDS[HART_INITCOMMAND_COUNT][4] = { 
    { HARTCOMMAND_FOURTYEIGHT,0 }, // Read additional device status.
    { HARTCOMMAND_FIFTYNINE,1,5 }, // Set no. of response preambles to 5.
    { HARTCOMMAND_SIX,2,0,1 },     // Set polling addr to 0 and enable loop current mode.
    { HARTCOMMAND_THIRTYEIGHT,0 }, // Reset config changed bit.
    { HARTCOMMAND_TWELVE,0 },      // Read message.
    { HARTCOMMAND_THIRTEEN,0 },    // Read tag, descriptor and date.
    { HARTCOMMAND_FOURTEEN,0 },    // Read primary variable transducer information.
    { HARTCOMMAND_FIFTEEN,0 },     // Read device information.
    { HARTCOMMAND_SIXTEEN,0 },     // Read final assembly number.
    { HARTCOMMAND_TWENTY, 0},      // Long Tag.
    { HARTCOMMAND_FIFTY,0 }        // Read dynamic variable association.
};

// Initialization commands for HART revision 7 devices (used as XMT buffer).
const UINT8 HART7_INIT_COMMANDS[HART_INITCOMMAND_COUNT][4] = { 
    { HARTCOMMAND_FOURTYEIGHT,0}, // Read additional device status.
    { HARTCOMMAND_FIFTYNINE,1,5 }, // Set no. of response preambles to 5.
    { HARTCOMMAND_SIX,2,0,1 },     // Set polling addr to 0 and enable loop current mode.
    { HARTCOMMAND_THIRTYEIGHT,2,0,0},// Reset config changed bit.
    { HARTCOMMAND_TWELVE,0 },      // Read message.
    { HARTCOMMAND_THIRTEEN,0 },    // Read tag, descriptor and date.
    { HARTCOMMAND_FOURTEEN,0 },    // Read primary variable transducer information.
    { HARTCOMMAND_FIFTEEN,0 },     // Read device information.
    { HARTCOMMAND_SIXTEEN,0 },     // Read final assembly number.
    { HARTCOMMAND_TWENTY, 0},      // Long Tag.
    { HARTCOMMAND_FIFTY,0 }        // Read dynamic variable association.
};


// HGChngFl bit definitions for SWMUX.
const UINT8 HGCHNGFL_STATUSCOUNT_BIT0 = 0x01;
const UINT8 HGCHNGFL_STATUSCOUNT_BIT1 = 0x02;
const UINT8 HGCHNGFL_CONFIGCOUNT_BIT0 = 0x04;
const UINT8 HGCHNGFL_CONFIGCOUNT_BIT1 = 0x08;
const UINT8 HGCHNGFL_INITCMPLT_BIT    = 0x10;
const UINT8 HGCHNGFL_COMMSTATUS_BIT   = 0x20;
const UINT8 HGCHNGFL_SECMASTER_BIT    = 0x40;
const UINT8 HGCHNGFL_PSTSTATUS_BIT    = 0x80;

// Length of a scan message from command to checksum.
// 1 command + 1 byte count + 8 variable codes.
const UINT8 HART_SCANMSG_SIZE = 10; 

// Channel object will handle only universal and common practise commands. 
// The largest reply length is for HART 7 command 9 and it is 69 bytes. 
// Allocate 84 bytes as maximum channel buffer size.
const UINT8 HART_CHANBUFFER_SIZE = 84;

// Default preamble bytes used during command 0 polling.
const UINT8 HART_DEFAULT_PREAMBLECOUNT = 10; 

// Retry count for channels with no configuration during auto discovery.
const UINT8 HART_AUTODISCOVERY_RETRYCOUNT = 1;

// Largest value of communication error count
const UINT16 HART_COMMERROR_MAXCOUNT = MAXUINT16;

// Delay time for HART event processing during channel reload
const UINT8 MAX_TEMPLATECHANGE_WAITCOUNT = 16; // 16 seconds.
const UINT8 HALF_TEMPLATECHANGE_WAITCOUNT = MAX_TEMPLATECHANGE_WAITCOUNT/2;

// Maximum number of channels with dedicated modem.
// NOTE: UIO does not support 1-second channels
#if defined(IOMTYPE_UIO)
const UINT8 MAX_1SEC_CHANNELS = 0; 
#else
const UINT8 MAX_1SEC_CHANNELS = 2; 
#endif

// Number of passthrough buffers
const UINT8 HPST_OBJECTCOUNT    = 16;
const UINT8 HPST_TIMEOUT_COUNT  = 180;

// Maximum number of passthrough messages that will be scheduled back-to-back.
// Note that total messages that will be processed in one stretch will be 
// HPST_B2BMSG_MAXCOUNT + 1 (which is the original one schedule for this cycle).
const UINT8 HPST_B2BMSG_MAXCOUNT = 3;

// SWMUX removes all preamble bytes before sending a passthrough request to
// IOP. All passthrough requests in the queue starts with the delimiter and
// the following offsets are from the delimiter byte position.
const UINT8 HPST_DELIMITER_OFFSET = 0;
const UINT8 HPST_ADDRESS_OFFSET   = 1;
const UINT8 HPST_COMMAND_OFFSET   = 6;
const UINT8 HPST_BYTECOUNT_OFFSET = 7;
// Passthrough message overhead is used by modem object to compute the number of
// transmit bytes. It is the number of bytes in the transmit frame, other than
// the number indicated by the byte count field, but without preamble bytes.
// = 1 delim + 5 addr + 1 cmd + 1 bytecount + 1 chkbyte + 1 pad char = 10 bytes.
const UINT8 HPST_MESSAGE_OVERHEAD = 10;

// length (in bytes) of a HART6 CMD0 response
const UINT8 HART6_CMD0_RESPONSE_SIZE = 17;

#define PARAMID_HALARMENABLE 190
#define PARAMID_HENABLE     191
#define PARAMID_HSCANCFG    192

#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
#define PARAMID_SLOTCFGD     39
#define PARAMID_HDYNRATE    193
#define PARAMID_HDEVRATE    194
#endif
#define PARAMID_HSLOTDVC    195
#define PARAMID_HCOMTHRS    196
#define PARAMID_HCOMHYS     197
#define PARAMID_HDYNVAL     211
#define PARAMID_HSLOTEU     218
#define PARAMID_HDVMFGCD    224
#define PARAMID_HDEVIDCD    225
#define PARAMID_HDVTYPCD    226
#define PARAMID_HDVREVCD    227
#define PARAMID_HDDREVCD    228
#define PARAMID_HNTFYCFG    230
#define PARAMID_HDVMFGCD7   184
#define PARAMID_HDVTYPCD7   185
#define PARAMID_HSLOT0TS    186

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
#define PARAMID_LRV         132
#define PARAMID_URV         133
#define PARAMID_LRL         134
#define PARAMID_URL         135
#if defined(IOPTYPE_HLAI)
#define PARAMID_DAMPING     138
#define PARAMID_STATE       141
#endif
#endif
// HSLOTDVCBLND is an IOM internal param used only for checkpoint operations
// on HSLOTDVC. Since paramset read/write cannot support indexed parameters, 
// this internal paramter defines HSLOTDVC as a blind record. The checkpoint 
// structure contains PARAMID_HSLOTDVCBLND instead of PARAMID_HSLOTDVC.
#define PARAMID_HAUTODETBLND 30
#define PARAMID_HSLOTDVCBLND 40
#define PARAMID_HSLOTDVCBLND7 41

#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
const UINT8 PARAMID_H7SLDVC_SIZE = 8;
#endif

const UINT8 HART_DEVST_BYTECOUNT = 4;
//SLOT0 time stamp has resolution of 1/32 msec. Time of day has a resolution of 1/10msec.
//HART_SLT0TS_TIMEOFDAY is used for converting Slot0 time stamp into time of day.
const UINT8  HART_SLT0TS_MSEC =  32;  //constant used for converting slot 0 time stamp to milli seconds.
const UINT8  HART_SLT0TS_TIMEOFDAY  = 10; //constant used for converting milliseconds to TIMEOFDAY datatype.

// HDEVST byte 0 (Device status byte sent from the device)
const UINT8 HART_DEVST0_PRIVAROUTLIMIT_MASK     = 0x01; // Alarm
const UINT8 HART_DEVST0_NPRIVAROUTLIMIT_MASK    = 0x02; // Alarm
const UINT8 HART_DEVST0_LOOPCURSATURATED_MASK   = 0x04; // Alarm
const UINT8 HART_DEVST0_LOOPCURFIXED_MASK       = 0x08; // Alarm
const UINT8 HART_DEVST0_MORESTATUSAVLBL_MASK    = 0x10; // None
const UINT8 HART_DEVST0_DEVICECOLDSTART_MASK    = 0x20; // Alarm
const UINT8 HART_DEVST0_CONFIGCHANGED_MASK      = 0x40; // Event
const UINT8 HART_DEVST0_DEVICEMALFUNCTION_MASK  = 0x80; // Alarm

// HDEVST byte 1 (Determined by the IOM)
const UINT8 HART_DEVST1_DEVMISMATCH_MASK = 0x01; // Alarm
const UINT8 HART_DEVST1_REVMISMATCH_MASK = 0x02; // Alarm
const UINT8 HART_DEVST1_DEVCHANGED_MASK  = 0x04; // Alarm
const UINT8 HART_DEVST1_SECMASTER_MASK   = 0x08; // Alarm
const UINT8 HART_DEVST1_COMMFAIL_MASK    = 0x10; // Alarm
const UINT8 HART_DEVST1_EXCOMMERR_MASK   = 0x20; // Alarm
const UINT8 HART_DEVST1_CMDFAIL_MASK     = 0x40; // Event
const UINT8 HART_DEVST1_SCANOVRUN_MASK   = 0x80; // Alarm

// HDEVST byte 2 (Determined by the IOM)
const UINT8 HART_DEVST2_RANGEMISMATCH_MASK  = 0x01; // Alarm
const UINT8 HART_DEVST2_SPAREBIT1_MASK      = 0x02; // None
const UINT8 HART_DEVST2_SPAREBIT2_MASK      = 0x04; // None
const UINT8 HART_DEVST2_SPAREBIT3_MASK      = 0x08; // None
const UINT8 HART_DEVST2_SPAREBIT4_MASK      = 0x10; // None
const UINT8 HART_DEVST2_SPAREBIT5_MASK      = 0x20; // None
const UINT8 HART_DEVST2_SPAREBIT6_MASK      = 0x40; // None
const UINT8 HART_DEVST2_SPAREBIT7_MASK      = 0x80; // None

// HDEVST byte 3 (Extended device status sent from HART 6.0 devices)
const UINT8 HART_DEVST3_MAINTAINREQD_MASK   = 0x01; // Alarm
const UINT8 HART_DEVST3_DEVVALALERT_MASK    = 0x02; // Alarm
const UINT8 HART_DEVST3_RESERVEDBIT2_MASK   = 0x04; // None
const UINT8 HART_DEVST3_RESERVEDBIT3_MASK   = 0x08; // None
const UINT8 HART_DEVST3_RESERVEDBIT4_MASK   = 0x10; // None
const UINT8 HART_DEVST3_RESERVEDBIT5_MASK   = 0x20; // None
const UINT8 HART_DEVST3_RESERVEDBIT6_MASK   = 0x40; // None
const UINT8 HART_DEVST3_RESERVEDBIT7_MASK   = 0x80; // None

const UINT8 HART_DEVST_EVENT_ENABLE[HART_DEVST_BYTECOUNT] = { 0xEF,0xFF,0x01,0x03 };
const UINT8 HART_DEVST_ALARM_ENABLE[HART_DEVST_BYTECOUNT] = { 0xAF,0xBF,0x01,0x03 };

// All other HART event codes are computed at run time based on the bit position.
const UINT8 HEVENT_COMFAIL   = 12; // HART communication failed event code
const UINT8 HEVENT_EXCOMFAIL = 13; // HART excessive communication error event code.

// HAlarmEnable bit defintions and write values
const UINT8 HALARMENABLE_ALMENBSTATE_MASK = 0x01;
const UINT8 HALARMENABLE_JOURNALONLY_MASK = 0x80;
const UINT8 HALARMENABLE_ALMENBSTATE_RSTVAL = 0x00;
const UINT8 HALARMENABLE_ALMENBSTATE_SETVAL = 0x01;
const UINT8 HALARMENABLE_JOURNALONLY_RSTVAL = 0x40;
const UINT8 HALARMENABLE_JOURNALONLY_SETVAL = 0x80;
/*******************************************************************************
*                                 clsHartCfgDb                                 *
*                                 ============                                 *
*******************************************************************************/
class clsHartCfgDb {
public:
    BOOL        HEnable;
    HSCANCFG    HScanCfg;
    BLIND       HSlotDvc[HART6_MAXVAR_COUNT];
    UINT16      HComThrs;
    UINT16      HComHys;
    BLIND       HDvMfgCd;
    BLIND       HDevIdCd[HART_DEVICEID_SIZE];
    BLIND       HDvTypCd;
    BLIND       HDvRevCd;
    BLIND       HDdRevCd;
    BLIND       HNtfyCfg[HNTFYCFG_BYTECOUNT];
    BOOL        HAlarmEnable;
    BOOL        HAlarmEnableLrs;

    static const UINT8 HDevCd[];
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); } 
    clsHartCfgDb(const clsHartCfgDb&); // Safeguard against default copy constructor
    clsHartCfgDb& operator=(const clsHartCfgDb&); // and default assignment

    clsHartCfgDb(VOID) { InitCfgDb(); }
    ~clsHartCfgDb(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }

    VOID InitCfgDb(VOID); 
};

/*******************************************************************************
*                                 clsHartCfgDb7                                 *
*                                 ============  
*    Added for HART revision greter than 7.                               *
*******************************************************************************/
class clsHartCfgDb7 {
public:
    BLIND       HSlotDvc7[HART_MAXVAR_COUNT];
    BLIND       HDvMfgCd7[sizeof(UINT16)];
    BLIND       HDvTypCd7[sizeof(UINT16)];
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); } 
    clsHartCfgDb7(const clsHartCfgDb7&); // Safeguard against default copy constructor
    clsHartCfgDb7& operator=(const clsHartCfgDb7&); // and default assignment

    clsHartCfgDb7(VOID) { InitCfgDb(); }
    ~clsHartCfgDb7(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }

    VOID InitCfgDb(VOID); 
};
/*******************************************************************************
*                                  clsHartDevDb                                *
*                                  ============                                *
*******************************************************************************/
class clsHartDevDb {
    const UINT8 m_cucParent;
    clsHartCfgDb * const m_pHartCfgDb; 
    clsHartCfgDb7 * const m_pHartCfgDb7;
    static const HARTCMDHANDLER HartCmdHandler[];
    static UINT8 m_stucNoOf1SecChannels;

public:
    HCHANMODE   m_HChanMode;
    HCHANTYPE   m_HChanType;
    HDATAINIT   m_HDataInit;
    HEVENTINIT  m_HEventInit;
    UINT8       m_ucLastDsa;

    // Scan table related members. Scan table is a 16 x 3 table that
    // specifies HART command sequence when channel is in scan mode.
    HSCANMSG    m_ScanMsgTbl[MAX_CYCLE_NUMBER][MAX_MSGS_IN_A_CYCLE];
    INT16       m_sScanCounter;  // Channel heartbeats to the next scan.
    UINT8       m_ucScanNo;      // Next row of scan table to process.
    UINT8       m_ucSavedScanNo; // Scan table row for the current scan.
    UINT8       m_ucB2BNo;       // Scan table column for the current scan.
    UINT8       m_ucSkipC48Cycles; // Number of command 48 scans to skip.

    // Attributes of the discovered device.
    HARTUNIQUEADDR  m_UniqueAddress;    
    UINT8           m_ucPollingAddress; 
    UINT8           m_ucHartVersion;
    UINT8           m_ucDeviceRevision; 
    UINT8           m_ucReqdPreambles;  // Preambles required by the device.

    // Members for handling requests and response messages.
    clsClientBuffer m_ChanRcvBuffer;// Channel receive buffer object.
    UINT8   m_ucInitCmdIndex;       // Index to the array of init commands.
    UINT8   m_ucPstAppIndex;        // Index at which last PST message was queued.
    UINT8   m_ucPstRemIndex;        // Next PST Q index to be processed.
    UINT8   m_ucLastReqCmd;         // Last command that was just processed.
    UINT8   m_ucB2BPstMsgCount;     // Number of back-to-back PST requests.
    UINT8   *m_ucpLastXmtPtr;       // XMT buffer pointer to the last CMD.
    UINT8   m_ucLastRespCode;       // Response code the last message.
    UINT8   m_ucNextReqCmd;         // Next command that will be processed.
    UINT8   *m_ucpNextXmtPtr;       // XMT buffer pointer to the next CMD.
#if defined (IOMTYPE_UIO)
    UINT8   *m_ucpLastPstXmtPtr;    // Transmit buffer pointer to last PST
    UINT8   *m_ucpNextPstXmtPtr;    // Transmit buffer pointer to next PST
    UINT8   m_ucLastPstCmd;         // Last PST command transmitted
    UINT8   m_ucNextPstCmd;         // Next PST command that will be processed
#endif
    UINT8   m_ucRcvBufIndex;        // Index in the receive buffer.
    UINT8   m_ucRcvMsgLen;          // Length of the received response.
    UINT8   m_ucDynScan[HART_SCANMSG_SIZE]; // Dynamic scan XMT buffer. 
    UINT8   m_ucDevScan[HART_SCANMSG_SIZE]; // Device scan XMT buffer

    HCOMSTS m_ucCommStatus;     // Current commn status returned by stack.
    UINT8   m_ucDeviceStatus;   // Device status byte in the response. 
    UINT8   m_ucSecMasterResetCounter;  // To throttle SecMaster alarm.
    UINT8   m_ucScanOverrunCounter;     // To throttle ScanOverrun alarm.
    UINT8   m_ucPstPresentCounter;
    BOOL    m_bCmd38FailReported;   // To avoid repeated posting of alarm.
    BOOL    m_bCmd48FailReported;   // To avoid repeated posting of alarm.
    BOOL    m_bReReportEvents;      // Re-report HART events.
    UINT8   m_ucTemplateChangeWaitCount;// To temporarily suspend HART events on template change.
    BOOL    m_bHartChanFail;

    HCOMSTS     HComSts;
    HCOMSTS     HLComFail;
    UINT16      HNComErr;
    HARTCOMMAND HCmdFail;
    BLIND       HCmdResp;

    BLIND       HDevSt[HART_DEVST_BYTECOUNT];
    BLIND       HDevStLrs[HART_DEVST_BYTECOUNT];
    BLIND       HDynDvc[HART_MAXDYNVAR_COUNT];
    HSCANRATE   HDynRate;
    HSCANRATE   HDevRate;
    HSCANRATE   HTotalRate;
    COMMAND     Command;

    HARTCMD0RESPONSE    HCmd0;
    HARTCMD3RESPONSE    HCmd12;
    HARTCMD13RESPONSE   HCmd13;
    HARTCMD14RESPONSE   HCmd14;
    HARTCMD15RESPONSE   HCmd15;
    HARTCMD16RESPONSE   HCmd16;
    HARTLONGTAG_RESPONSE   HLongTag;
    HARTCMD48RESPONSE   HCmd48;
    BLIND HCmd48Lrs[HART_CMD48_RESPONSE_SIZE];

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    FLOAT32 Lrv;
    FLOAT32 Urv;
    FLOAT32 Lrl;
    FLOAT32 Url;
    FLOAT32 Damping;
    BLIND   StiEu;
#if defined(IOPTYPE_HLAI)
    BLIND   State;
#endif

    static const UINT8 HDvRngExt[];
#endif

    FLOAT32 HDynVal[HART_MAXDYNVAR_COUNT];
    BLIND   HDynSt[HART_MAXDYNVAR_COUNT];
    BLIND   HDynCc[HART_MAXDYNVAR_COUNT];
    BLIND   HDynEu[HART_MAXDYNVAR_COUNT];

    FLOAT32 HSlotVal[HART_MAXVAR_COUNT];
    BLIND   HSlotSt[HART_MAXVAR_COUNT];
    BLIND   HSlotCc[HART_MAXVAR_COUNT];
    BLIND   HSlotEu[HART_MAXVAR_COUNT];
    UINT32  HDevSlot0DTS;

    BOOL    m_bAtLeastOneTry;
    UINT32  m_ulDynGoodCount;
    UINT32  m_ulDevGoodCount;
    UINT32  m_ulC48GoodCount;

    static EVENTRECORD HAlmOptChgEvent;

    UINT8 HART7_CMD38[HART_CMD38_RESPONSE_SIZE + 2];
    //UINT8 HART7_CMD48[HART7_CMD48_REQUESTDATA_SIZE+2];
    UINT16 HT5_CfgChngCnt; //Configuration Change counter for HART revision 5.
    HSCANMSG m_ScanMsg; //Parameter to identify which scan is completed.
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); } 
    clsHartDevDb(const clsHartDevDb&); // Safeguard against default copy constructor
    clsHartDevDb& operator=(const clsHartDevDb&); // and default assignment

    clsHartDevDb(UINT8,clsHartCfgDb *,clsHartCfgDb7 *);
    ~clsHartDevDb(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }

    VOID InitDevDb(BOOL); 
    VOID SetHComSts(HCOMSTS);
    BOOL PostHComFail(BOOL);
    BOOL PostHAlmOptChgEvent(BOOL);
    VOID SetHDevSt(UINT8,UINT8);
    VOID SetHCmdFail(HARTCOMMAND,UINT8);
    VOID IncrementHCfgChCounter(VOID);
    VOID IncrementHDevStCounter(VOID);
    VOID ChannelHeartbeat(VOID);
    BOOL ProcessHartEvents(BOOL);
    HSYNCSTATUS ReceptionComplete(HMSGSTATUS);
    VOID LogEvent(HEVENTTYPE);
    VOID BuildScanTable(VOID);
    VOID ControlStateChange(VOID);
    VOID CheckDevMismatch(VOID);
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    VOID CheckRangeMismatch(VOID);
#endif

    VOID WriteHCmdData(HARTCOMMAND,UINT8 *);
    HSYNCSTATUS BumpPollingAddress(VOID);
    HSYNCSTATUS ScheduleFromInitTable(VOID);
    HSYNCSTATUS ScheduleFromScanTable(VOID);
    HSCANMSG SetupScanMessage(UINT8,UINT8);
    HSCANMSG SetupPassThrough(VOID);
    HREPLYSTATUS UpdateDatabase(VOID);
    FLOAT32 GetHartLoading(VOID);

    inline static UINT8 GetNoOf1SecChannels(VOID) { return m_stucNoOf1SecChannels; }
    inline static VOID SetNoOf1SecChannels(UINT8 a_ucCount) {
        m_stucNoOf1SecChannels = a_ucCount; 
    }
    inline static VOID Increment1SecChannels(VOID) { m_stucNoOf1SecChannels++; }
    inline static VOID Decrement1SecChannels(VOID) { 
        if (m_stucNoOf1SecChannels > 0) m_stucNoOf1SecChannels--; 
    }

    inline VOID SetScanCounterForRediscovery(PNTTYPE a_PointType) {
        if (a_PointType != PNTTYPE_NOTCONFIGURED) { // If channel is configured
            if (TRUE == m_pHartCfgDb->HEnable) {    // and HART is enabled, phase rediscovery
                m_sScanCounter = TICKS_IN_30_SEC + m_cucParent;  // based on the channel number.
            }
            else InitDevDb(TRUE);                   // No rediscovery if HART is disabled
        }
        else { // Rediscover after a minute if channel is not configured.
            m_sScanCounter = TICKS_IN_60_SEC;
        }
    }

    inline VOID SetHartChanFail(VOID) { m_bHartChanFail = TRUE; }
    inline VOID ClearHartChanFail(VOID) 
    { 
        m_bHartChanFail = FALSE;
        m_sScanCounter = TICKS_IN_16_SEC;
    }

    HREPLYSTATUS Cmd0GoodHandler(VOID);
    HREPLYSTATUS Cmd0BadHandler(UINT8);
    HREPLYSTATUS Cmd3GoodHandler(VOID);
    HREPLYSTATUS Cmd3BadHandler(UINT8);
    HREPLYSTATUS Cmd6GoodHandler(VOID);
    HREPLYSTATUS Cmd6BadHandler(UINT8);
    HREPLYSTATUS Cmd9GoodHandler(VOID);
    HREPLYSTATUS Cmd9BadHandler(UINT8);
    HREPLYSTATUS Cmd12GoodHandler(VOID);
    HREPLYSTATUS Cmd12BadHandler(UINT8);
    HREPLYSTATUS Cmd13GoodHandler(VOID);
    HREPLYSTATUS Cmd13BadHandler(UINT8);
    HREPLYSTATUS Cmd14GoodHandler(VOID);
    HREPLYSTATUS Cmd14BadHandler(UINT8);
    HREPLYSTATUS Cmd15GoodHandler(VOID);
    HREPLYSTATUS Cmd15BadHandler(UINT8);
    HREPLYSTATUS Cmd16GoodHandler(VOID);
    HREPLYSTATUS Cmd16BadHandler(UINT8);
    HREPLYSTATUS Cmd20GoodHandler(VOID);
    HREPLYSTATUS Cmd20BadHandler(UINT8);
    HREPLYSTATUS Cmd33GoodHandler(VOID);
    HREPLYSTATUS Cmd33BadHandler(UINT8);
    HREPLYSTATUS Cmd38GoodHandler(VOID);
    HREPLYSTATUS Cmd38BadHandler(UINT8);
    HREPLYSTATUS Cmd48GoodHandler(VOID);
    HREPLYSTATUS Cmd48BadHandler(UINT8);
    HREPLYSTATUS Cmd50GoodHandler(VOID);
    HREPLYSTATUS Cmd50BadHandler(UINT8);
    HREPLYSTATUS Cmd59GoodHandler(VOID);
    HREPLYSTATUS Cmd59BadHandler(UINT8);
    HREPLYSTATUS Cmd109GoodHandler(VOID);
    HREPLYSTATUS Cmd109BadHandler(UINT8);
};
/*******************************************************************************
*                                  clsHartPst                                  *
*                                  ==========                                  *
*******************************************************************************/
class clsHartPst {
public:
    // This is BRDP Status table which maintains the Status of Pass through 
    // messages. Currently we support 16 messages.
    UINT8           m_ucHandle;
    UINT8           m_ucSlotNumber;
    UINT8           m_ucPstMsgTimeout;
    HPSTSTATUS      m_PstStatus;

    clsClientBuffer m_PstRcvBuffer;  

    clsHartPst(const clsHartPst&); // Safeguard against default copy constructor
    clsHartPst& operator=(const clsHartPst&); // and default assignment

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }

    clsHartPst(VOID);
    ~clsHartPst(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTDB_HPP,__LINE__); }
 
#if defined(IOMTYPE_UIO)
    static clsHartPst** PassThroughTable(UINT8 a_ucModemNum);
#endif
};

#if defined(IOMTYPE_UIO)
// Global PST structure, which defines the number of back-2-back PST based
// on number of FDM sessions and scan configurations of HART enabled channels
extern const UINT8 HartPst[MAX_FDM_SESSIONS][MAX_SCAN_CONFIG_ALLOWED];
#endif

#endif
