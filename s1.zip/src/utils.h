/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : utils.h                                                     *
*    Description : Constants and data types for common utility functions.      *
*******************************************************************************/
#ifndef __UTILS_H__
#define __UTILS_H__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <math.h>
#include <machine.h>
#include "datatype.h"
#include "global.h"
#include "commonelectronics.h"
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef BOOL (*FlashErasePtr)(UINT8);
typedef BOOL (*FlashProgramPtr)(UINT8*, UINT8*);
#if H8S_2319C
typedef UINT8 (*Erase018FlashPtr)(UINT8);
typedef UINT8 (*Program018FlashPtr)(UINT32, UINT8*);
typedef VOID  (*DummyFuncPtr)(UINT32, UINT32);
typedef UINT8 (*FlashUtilsPtr)(VOID);
#endif
/*******************************************************************************
*                            CONSTANT DECLARATIONS                             *
*******************************************************************************/
// TPU1 uses divide by 16 clock of twice the system clock.
#define  frequency                     2400 // CPU clock * 100
const UINT8 TPU1_TICKS_IN_MICROSECOND = (SYSTEM_CLOCK_FREQUENCY / 8) / MICROSECONDS_IN_SECOND;
#if H8S_2319C
//* WARNING:
// Please make sure that the address specified in the makefile for BCPYFLHUTIL_RAM
// should match the address below. Also this address is different from other IOMs
// as the flash algorith for H8S/2319C (for DISOE IOM) is different.
#define  FLASHUTIL_RAM_ADDRESS         0xFFDC00
#define  INIT_PROGRAM_ADDRESS          FLASHUTIL_RAM_ADDRESS+32
#define  INIT_ERASE_ADDRESS            INIT_PROGRAM_ADDRESS
#define  PROGRAM_ROUTINE_ADDRESS       FLASHUTIL_RAM_ADDRESS+16
#define  ERASE_ROUTINE_ADDRESS         PROGRAM_ROUTINE_ADDRESS
#define  FTDAR_START_ADDRESS           0x02
#define  FLASH_NO_ERROR                0x00
#define  FLASH_PROG_ERASE_DOWNLD_ERROR 0x02
#define  FLASH_INIT_ERROR              0x04
#define  FLASH_PROGRAMMING_ERROR       0x08
#define  FLASH_ERASING_ERROR           0x10
#define  FLASH_UTIL_SIZE               0xC0
#define  FLASH_DUMMYFUNC_SIZE          0x10
#define  MAXFLASHBLOCK                 16
#define  MAXFLASHADDRESS               0x07FFFF
#else
const UINT16 FLASH_UTIL_FUNCTION_SIZE       = 0x300;
#endif
#if (defined (IOMTYPE_SP) || defined(IOMTYPE_SVP))
const UINT32 FLASH_UTIL_RELOCATION_ADDRESS  = 0xFFE600;
#elif HEK && (!defined(IOMTYPE_PI))
const UINT32 FLASH_UTIL_RELOCATION_ADDRESS  = 0x21F000;
#else // digital and LOWCOST AI, AO modules
//In the case of digitals and lowcost AIAO we do not have enough memory to execute flash related 
//routines. Therefore when we are using the memory allocated for ucMsgBuffer in
//Write Message queue while flashing the HWREVCODE and SERIAL NUMBER data in
//factory mode. 
//This space is left for copying the existing flash data before erasing.

//PIM does not have SRAM like other HEK modules, so procedure used for LOWCOST AIAO
//and digitals are followed for PIM.
const UINT16 FLASH_UTIL_RELOC_WRTMSGQUE_OFFSET  = 0x500;
#endif

#if defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_LLMUX) || \
defined(IOMTYPE_DI)      || defined(IOMTYPE_DO)  || defined(IOMTYPE_DISOE) || \
defined(IOMTYPE_SVP)     || defined(IOMTYPE_SP)  || defined(IOMTYPE_PI)    || \
defined(IOMTYPE_UIO)
typedef enum tagFileName {
    NO_FILE,                // 0
    ADC_CPP,                // 1
    ADC_HPP,                // 2
    AIHBOXSLOT_CPP,         // 3 
    AIHBOXSLOT_HPP,         // 4
    AIHMAIN_CPP,            // 5
    AIHMAIN_H,              // 6
    AIHSLOT_CPP,            // 7
    AIHSLOT_HPP,            // 8
    AIHVERSION_H,           // 9
    AIXSLOT_CPP,            // 10
    AIXSLOT_HPP,            // 11
    AOHARDWARE_CPP,         // 12
    AOHARDWARE_HPP,         // 13
    AOHBOXSLOT_CPP,         // 14
    AOHBOXSLOT_HPP,         // 15
    AOHMAIN_CPP,            // 16
    AOHMAIN_H,              // 17
    AOHSLOT_CPP,            // 18
    AOHSLOT_HPP,            // 19
    AOHVERSION_H,           // 20
    ASMUTILS_ASM,           // 21    
    BOXSLOT_CPP,            // 22
    BOXSLOT_HPP,            // 23
    COMMONELECTRONICS_H,    // 24
    DATATYPE_H,             // 25
    DEBUG_CPP,              // 26
    DEBUG_HPP,              // 27
    DIAG_CPP,               // 28
    DIAG_H,                 // 29
    DIBOXSLOT_CPP,          // 30
    DIBOXSLOT_HPP,          // 31
    DIMAIN_CPP,             // 32
    DIMAIN_H,               // 33
    DISOEVERSION_H,         // 34
    DISLOT_CPP,             // 35
    DISLOT_HPP,             // 36
    DIVERSION_H,            // 37
    DOBOXSLOT_CPP,          // 38
    DOBOXSLOT_HPP,          // 39
    DOMAIN_CPP,             // 40
    DOMAIN_H,               // 41
    DOSLOT_CPP,             // 42
    DOSLOT_HPP,             // 43
    DOVERSION_H,            // 44
    ECL_CPP,                // 45
    ECL_HPP,                // 46
    EVRCTASK_CPP,           // 47
    GLOBAL_H,               // 48
    HART_CPP,               // 49
    HART_H,                 // 50
    HARTDB_CPP,             // 51
    HARTDB_HPP,             // 52
    HARTSTACK_CPP,          // 53
    HARTSTACK_HPP,          // 54
    INSLOT_HPP,             // 55
    IOL_CPP,                // 56
    IOL_HPP,                // 57
    IOMSLOT_CPP,            // 58
    IOMSLOT_HPP,            // 59
    IOSLOT_HPP,             // 60
    LLHARDWARE_CPP,         // 61
    LLHARDWARE_HPP,         // 62
    LLMUXBOXSLOT_CPP,       // 63
    LLMUXBOXSLOT_HPP,       // 64
    LLMUXMAIN_CPP,          // 65
    LLMUXMAIN_H,            // 66
    LLMUXSLOT_CPP,          // 67
    LLMUXSLOT_HPP,          // 68
    LLMUXVERSION_H,         // 69
    OUTSLOT_HPP,            // 70
    ROOT_CPP,               // 71
    SCHEDULER_CPP,          // 72
    SCHEDULER_HPP,          // 73
    TRACELOG_CPP,           // 74
    TRACELOG_HPP,           // 75
    UTILS_CPP,              // 76
    UTILS_H,                // 77
    WRDBTASK_CPP,           // 78
    WRMSGQUE_HPP,           // 79
    FPGA_HPP,               // 80
    FPGA_CPP,               // 81
//Turbine control SVP Files
    TCCOMMONSLOT_CPP,          // 82
    TCCOMMONSLOT_HPP,          // 83
    SVPBOXSLOT_CPP,         // 84
    SVPBOXSLOT_HPP,         // 85
    SVPMAIN_CPP,            // 86
    SVPMAIN_H,              // 87
    SVPSLOT_CPP,            // 88
    SVPSLOT_HPP,            // 89
    SVPVERSION_H,            // 90
    //Turbine control SP Files
    SPBOXSLOT_CPP,         // 91
    SPBOXSLOT_HPP,         // 92
    SPMAIN_CPP,            // 93
    SPMAIN_H,              // 94
    SPSLOT_CPP,            // 95
    SPSLOT_HPP,            // 96
    SPVERSION_H,            // 97
    TCAILVDTSLOT_CPP,       // 98
    TCAILVDTSLOT_HPP,       // 99
    TCAOSERVOSLOT_CPP,       // 100
    TCAOSERVOSLOT_HPP,       // 101
    TCDISLOT_CPP,       // 102
    TCDISLOT_HPP,       // 103
    TCDOSLOT_CPP,       // 104
    TCDOSLOT_HPP,       // 105
    TCSPVOTBLOCK_HPP,   // 106
    //Pulse input module files    
    PIMAIN_CPP,         // 107
    PIMAIN_H,           // 108
    PIBOXSLOT_CPP,      // 109
    PIBOXSLOT_HPP,        // 110
    PISLOT_CPP,         // 111
    PISLOT_HPP,         // 112
    PIVERSION_H,        // 113
    UIOMAIN_CPP,        // 114  
    UIOMAIN_H,          // 115
    UIOBOXSLOT_CPP,     // 116
    UIOBOXSLOT_HPP,     // 117
    UIOSLOT_CPP,        // 118
    UIOSLOT_HPP,        // 119
    UIOFPGA_CPP,        // 120
    UIOFPGA_HPP,        // 121
    UIOVERSION_H        // 122
} FILE_NAME;
#endif
/*******************************************************************************
*                                GLOBAL FUNCTIONS                              *
*******************************************************************************/
#if defined(IOMTYPE_AIHBOOT)   || defined(IOMTYPE_AOHBOOT)   || \
defined(IOMTYPE_LLMUXBOOT)     || defined(IOMTYPE_DIBOOT)    || \
defined(IOMTYPE_DOBOOT)        || defined(IOMTYPE_DISOEBOOT) || \
defined(IOMTYPE_SVPBOOT)       || defined(IOMTYPE_SPBOOT)    || \
defined(IOMTYPE_PIBOOT)        || defined(IOMTYPE_UIOBOOT)  
extern VOID HardFail(HARDFAILTYPE,UINT8 a_Source=0,UINT8 a_Parm1=0,UINT8 a_Parm2=0);
#else
extern VOID HardFail(HARDFAILTYPE,FILE_NAME,UINT16,UINT8 a_Parm1 = 0,UINT8 a_Parm2 = 0);
#endif

#if !defined(IOPTYPE_SCIOM)
extern BOOL isOddParity(UINT8 ucBinary);
#endif

extern VOID memcopy(UINT8 *,const UINT8 *,UINT16);

extern BOOL RealCompare(FLOAT32, FLOAT32);
extern FLOAT32 fabs(FLOAT32);
extern "C" VOID abort(VOID);

#if !H8S_2319C
extern BOOL EraseFlash(UINT8);
extern BOOL ProgramFlash(UINT8 *,UINT8 *);
#endif
#if H8S_2319C
extern UINT8 EraseFlash(UINT8);
extern UINT8 ProgramFlash(UINT32 ,UINT8 *);
UINT8 Erase018FlashBlock(UINT8);
UINT8 Program018FlashLine(UINT32, UINT8*);
VOID  DummyFunc(UINT32, UINT32);
#endif

#ifdef DEBUG
extern INT16 atoi(const CHAR *);
extern VOID  itoa(UINT32 ,CHAR *);
extern UINT32 atoh(const CHAR *);
extern FLOAT32 atof(const CHAR *);
extern SIZE_T strlen(const CHAR *);
extern BOOL strcmp(const CHAR *,const CHAR *);
extern VOID strcpy(CHAR *,const CHAR *);
extern VOID snprintf(CHAR *,const CHAR *,CHAR *,UINT8);
#endif
#if !AIAO
extern UINT8 GetReadbackRegister(UINT8);
#endif // !AIAO
#if LOWCOST
extern UINT8 ReadCPLDRegister(UINT8);
#endif
/*******************************************************************************
*                               clsOlympicAverage                              *
*                               =================                              *
*******************************************************************************/
class clsOlympicAverage {
    UINT8   ucNoOfSamples;
#if LOWCOST
    UINT32  uiHiSample;
    UINT32  uiLoSample;
#else
    UINT16  uiHiSample;
    UINT16  uiLoSample;
#endif
    FLOAT32 fAccumulator;

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    #if defined(IOMTYPE_AIHBOOT) || defined(IOMTYPE_AOHBOOT)   || \
    defined(IOMTYPE_LLMUXBOOT)   || defined(IOMTYPE_DIBOOT)    || \
    defined(IOMTYPE_DOBOOT)      || defined(IOMTYPE_DISOEBOOT) || \
    defined(IOMTYPE_SVPBOOT)     || defined(IOMTYPE_SPBOOT)    || \
    defined(IOMTYPE_PIBOOT)      || defined(IOMTYPE_UIOBOOT)
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC); } 
    #else
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,UTILS_H,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,UTILS_H,__LINE__); } 
    #endif
    clsOlympicAverage(const clsOlympicAverage&); // Safeguard against def copy constr.
    clsOlympicAverage& operator=(const clsOlympicAverage&); // and default assignment.

public:
    clsOlympicAverage(VOID) { Initialize(); }
    ~clsOlympicAverage(VOID) {}

    VOID Initialize(VOID) {
        ucNoOfSamples = 0;
        uiHiSample    = 0;
#if LOWCOST
        uiLoSample    = MAXUINT32;
#else
        uiLoSample    = MAXUINT16;
#endif
        fAccumulator  = 0.0;
    }

#if LOWCOST
    VOID AddSample(UINT32 a_uiSample) {
#else
    VOID AddSample(UINT16 a_uiSample) {
#endif
        ucNoOfSamples++;
        fAccumulator += (FLOAT32)a_uiSample;
        if (a_uiSample > uiHiSample) uiHiSample = a_uiSample;
        if (a_uiSample < uiLoSample) uiLoSample = a_uiSample;
    }

    FLOAT32 GetResult(VOID) {
        // It was observed that the code fAccumulator -= (uiHiSample + uiLoSample) 
        // could not be used (uiHiSample + uiLoSample) resulted in UINT16 overflow. 
        fAccumulator -= (FLOAT32)uiHiSample;
        fAccumulator -= (FLOAT32)uiLoSample;
        ucNoOfSamples -= 2;
        fAccumulator /= (FLOAT32)ucNoOfSamples;
        FLOAT32 fCeil = ceil(fAccumulator);
        if ((fCeil - fAccumulator) <= (FLOAT32)0.5) fAccumulator = fCeil;
        return fAccumulator;
    }

#if LOWCOST
    UINT32 GetHiSample(VOID) { return uiHiSample; }
    UINT32 GetLoSample(VOID) { return uiLoSample; }
#else
    UINT16 GetHiSample(VOID) { return uiHiSample; }
    UINT16 GetLoSample(VOID) { return uiLoSample; }
#endif
};
/*******************************************************************************
*                                  RebootIom                                   *
*                                  =========                                   *
* PURPOSE : Reset the CPU and restart IOM.                                     *
*******************************************************************************/
inline VOID RebootIom(VOID) {
    set_imask_exr(LVLPRI_HIGHEST);
    TXREQ_n = IOLDRV_OFF; // ensure IOL RS-485 transmitter is disabled
    SWBUREQ_n = 0;        // assert backup request
#if (defined(IOMTYPE_PIBOOT) || defined(IOMTYPE_PI))
    CLR_RIP_n = 1;        // Arm RIP Latch
#endif
    REBOOT_n = 0;
    while (TRUE);
}
/*******************************************************************************
*                                 ShutdownIom                                  *
*                                 ===========                                  *
* PURPOSE : Reboot the module to ALIVE state.                                  *
*******************************************************************************/
inline VOID ShutdownIom(VOID) {
    SET_DIP  = 1; // Set DIP pin so the boot will stay in ALIVE state
    RebootIom();
}
/*******************************************************************************
*                                    IdleWait                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES: Valid input range = 1 to 21845 (1us to 21.845ms)                      *
*******************************************************************************/
inline VOID IdleWait(UINT16 a_uiWaitTime)
{

    UINT16 uiSaveTpu = 0;
    if (TPU1_CST != 0) {
        uiSaveTpu = TPU1_TCNT;
    }
    
    TPU1_TCNT = 0;     // Reset TPU1 counter.
    TPU1_CST  = 1;     // Start TPU1 counter.
    
    a_uiWaitTime *= TPU1_TICKS_IN_MICROSECOND; // Convert wait time to TPU count.
    
    while (TPU1_TCNT <= a_uiWaitTime);
    
    if (uiSaveTpu > 0) {
        TPU1_TCNT = uiSaveTpu;
    }
    else {
        TPU1_CST  = 0; // Stop TPU1 counter.
    }
}
/*******************************************************************************
*                                    isnan                                     *
*                                    =====                                     *
* PURPOSE   : Test for all types of NaNs.                                      *
* ARGUMENTS : FLOAT32 - variable to be tested.                                 *
* RETURN    : TRUE if the variable is NaN, else FALSE.                         *
* NOTES     : This inline function is used only in iomslot.cpp by the write    *
*             param functions for checking FLOAT32 values coming over IOL. All *
*             NaN values within firmware will be QNAN, so all internal checks  *
*             for NaN should use the simple isnan function.                    *
*******************************************************************************/
inline BOOL isnan(FLOAT32 a_fVal) { 
    NANINIT TestNaN;
    TestNaN.fVal = a_fVal;
    BOOL bIsNaN = FALSE;

    // if all exponent bits are set and the mantissa is non-zero
    if (TESTNAN_EXPONENT == (TestNaN.ulDword & TESTNAN_EXPONENT))  { 
        if (TestNaN.ulDword & TESTNAN_MANTISSA) { 
            bIsNaN = TRUE;
        }
    }

    return bIsNaN;
}
/*******************************************************************************
*                                    isnan                                     *
*                                    =====                                     *
* PURPOSE   : Test for all types of NaNs.                                      *
* ARGUMENTS : FLOAT64 - variable to be tested.                                 *
* RETURN    : TRUE if the variable is NaN, else FALSE.                         *
* NOTES     : This function is an overload of a FLOAT32 version                    *
*******************************************************************************/
inline BOOL isnan(FLOAT64 a_dVal) { 
    DNANINIT TestDNaN;
    TestDNaN.dVal = a_dVal;
    BOOL bIsDNaN = FALSE;

    // if all exponent bits are set and the mantissa is non-zero
    if ((TESTDNAN_EXPONENT_HI == (TestDNaN.uqWord.ulDwordHi & TESTDNAN_EXPONENT_HI)) &&
        (TESTDNAN_EXPONENT_LO == TestDNaN.uqWord.ulDwordLo)) { 
        if ((TestDNaN.uqWord.ulDwordHi & TESTDNAN_MANTISSA_HI) ||
            TestDNaN.uqWord.ulDwordLo) { 
            bIsDNaN = TRUE;
        }
    }

    return bIsDNaN;
}
#if LOWCOST
/*******************************************************************************
*                              CPLD Access Utility                             *
*                              ===================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AIHBOOT))
inline BOOL BitCPLD(UINT8 addr, UINT8 bitMap) 
{
    CPLD_ADDR = addr;         // Select
    NOP;
    return (P_PB.PORT.BYTE & bitMap);   // test the bit
}
inline UINT8 ByteCPLD(UINT8 addr) {
    CPLD_ADDR = addr;        // Select
    NOP;
    return P_PB.PORT.BYTE;
}
#else
inline BOOL BitCPLD(UINT8 addr, UINT8 bitMap){  
    BOOL data;
    CPLD_ADDR = addr;       // Select
    RD_n = 1;  // Read Strobe OFF
    data = (P_PB.PORT.BYTE & bitMap);   // test the bit
    RD_n = 0;  // Read Strobe ON
    return data;
}

inline UINT8 ByteCPLD(UINT8 addr) {
    UINT8 data;
    CPLD_ADDR = addr;       // Select
    RD_n = 1;  // Read Strobe OFF
    data = P_PB.PORT.BYTE;            // read the byte data
    RD_n = 0;  // Read Strobe ON
    return data;
}
inline void SelCPLD(UINT8 addr){
    CPLD_ADDR = addr;       // Select CPLD, for Write operation
    NOP;
}
#endif
#endif

#if defined (IOMTYPE_UIO)
/*******************************************************************************
*                                    SetBit                                    *
*                                    ======                                    *
* PURPOSE:   Utilities to set a bit within a bit field                         *
* ARGUMENTS: a_pBitField - pointer to the bit field                            *
*            a_BitIdx    - index of the bit to set                             *
* RETURN:    N/A                                                               *
* NOTES:     Overloaded function to support 8-, 16- and 32-bit fields          *
*******************************************************************************/
inline VOID SetBit(UINT8 * const a_pBitField, const UINT8 a_BitIdx) {
    *a_pBitField |= ((UINT8)1 << a_BitIdx);
}

inline VOID SetBit(UINT16 * const a_pBitField, const UINT8 a_BitIdx) {
    *a_pBitField |= ((UINT16)1 << a_BitIdx);
}

inline VOID SetBit(UINT32 * const a_pBitField, const UINT8 a_BitIdx) {
    *a_pBitField |= ((UINT32)1 << a_BitIdx);
}

/*******************************************************************************
*                                   ClearBit                                   *
*                                    ======                                    *
* PURPOSE:   Utilities to clear a bit within a bit field                       *
* ARGUMENTS: a_pBitField - pointer to the bit field                            *
*            a_BitIdx    - index of the bit to clear                           *
* RETURN:    N/A                                                               *
* NOTES:     Overloaded function to support 8-, 16- and 32-bit fields          *
*******************************************************************************/
inline VOID ClearBit(UINT8 * const a_pBitField, const UINT8 a_BitIdx) {
    *a_pBitField &= ~((UINT8)1 << a_BitIdx);
}

inline VOID ClearBit(UINT16 * const a_pBitField, const UINT8 a_BitIdx) {
    *a_pBitField &= ~((UINT16)1 << a_BitIdx);
}

inline VOID ClearBit(UINT32 * const a_pBitField, const UINT8 a_BitIdx) {
    *a_pBitField &= ~((UINT32)1 << a_BitIdx);
}

/*******************************************************************************
*                                    GetBit                                    *
*                                    ======                                    *
* PURPOSE:   Utilities to get a bit status within a bit field                  *
* ARGUMENTS: a_BitField - the bit field                                        *
*            a_BitIdx   - index of the bit of interest                         *
* RETURN:    BOOL - TRUE/FALSE indicating 1 or 0 status of the bit of interest *
* NOTES:     Overloaded function to support 8-, 16- and 32-bit fields          *
*******************************************************************************/
inline BOOL GetBit(const UINT8 a_BitField, const UINT8 a_BitIdx) {
    return ((a_BitField & ((UINT8)1 << a_BitIdx)) != 0) ? TRUE : FALSE;
}

inline BOOL GetBit(const UINT16 a_BitField, const UINT8 a_BitIdx) {
    return ((a_BitField & ((UINT16)1 << a_BitIdx)) != 0) ? TRUE : FALSE;
}

inline BOOL GetBit(const UINT32 a_BitField, const UINT8 a_BitIdx) {
    return ((a_BitField & ((UINT32)1 << a_BitIdx)) != 0) ? TRUE : FALSE;
}
#endif // defined (IOMTYPE_UIO)

#endif // __UTILS_H__
