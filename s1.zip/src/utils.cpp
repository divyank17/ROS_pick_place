/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : utils.cpp                                                   *
*    Description : Common utility functions.                                   *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "utils.h"
#include "scheduler.hpp"
#include "tracelog.hpp"
#include "debug.hpp"
#include "boxslot.hpp"
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
#ifdef DEBUG
extern CHAR g_strDebugPrompt[];
#endif
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
extern "C" BOOL _EraseFlashBlock(UINT8);
extern "C" BOOL _ProgramFlash(UINT8*, UINT8*);
extern clsWriteMsgQueue WriteMsgQueue;
#if(!HEK) || (defined(IOMTYPE_PI))
UINT8 *Flash_Util_Relocation_Address_Ptr = (WriteMsgQueue.GetMsgBufferPtr() + 
                                                FLASH_UTIL_RELOC_WRTMSGQUE_OFFSET);
#if H8S_2319C
UINT8 *DummyFunc_address = (WriteMsgQueue.GetMsgBufferPtr() + 
                                         FLASH_UTIL_RELOC_WRTMSGQUE_OFFSET+FLASH_UTIL_SIZE);
#endif // ifdef H8S_2319C
#endif
/*******************************************************************************
*                                     abort                                    *
*                                     =====                                    *
* PURPOSE:                                                                     *
*    This function is required for the time being by the tool set.             *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function may be removed or renamed in future.                        *
*******************************************************************************/
extern "C" VOID abort(VOID) {
    while (true);
}

/*******************************************************************************
*                                     HardFail                                 *
*                                     ========                                 *
*  HardFail is called when an unrecoverable HW or SW error is detected by the  *
*  firmware. This function responds in three separate ways:                    *
*  1) If this is release build, fail code and trace information is saved and   *
*     DIAGFAIL is asserted, immediately taking down the module.                *
*  2) If this is debug build and the fault is detected during startup (before  *
*     scheduler timer starts), debug prompt is updated to indicate the failure *
*     code and the function returns back to the calling code. This is to allow *
*     modules with HW failures to be started up suceessfully in debug mode so  *
*     that diagnosis of the problem can be performed.                          *
*  3) If this is debug build and the fault is detected after startup, module   *
*     goes to a debug-only mode by stopping all the tasks and interrupts.      *
*******************************************************************************/
VOID HardFail(HARDFAILTYPE a_HfCode,const FILE_NAME a_FlIdx,UINT16 a_LnNo,  
                                               UINT8 a_Parm1,UINT8 a_Parm2)
{
#ifdef DEBUG    
#if defined(PMIO_DEBUG) && (0)
	while (RETURNSTATUS_COMPLETE != DebugPort.PrintString("\n\rHF%2d, F: %d, L: %d, P1: %d, P2: %d",
                                  a_HfCode, a_FlIdx, a_LnNo, a_Parm1, a_Parm2));      
	if (0 == TPU5_CST) {
		// If scheduler has not started yet and this is debug mode,  
		// ignore the failure and return back to the intialization. 
		return;
	}
#else
    snprintf(g_strDebugPrompt,"\n\rHF%02d>",(CHAR *)&a_HfCode,SMALL_INPUT_BUFFER_SIZE);

    if (0 == TPU5_CST) {
        // If scheduler has not started yet and this is debug mode,  
        // ignore the failure and return back to the intialization. 
        return;
    }
#endif
#endif

    set_imask_exr(LVLPRI_HIGHEST);    // Disable all interrupts
    TXREQ_n = IOLDRV_OFF;             // ensure RS-485 transmitter is disabled
    SWBUREQ_n = 0;                    // assert backup request
    BOX->SetFailCode(a_HfCode);       // Save fail code in IOM database.

    // Log crash information in trace memory. 
    TraceLog.AddToTrace(TRACEID_GENERIC,bcHardFail1,    // HFCODE | FILE | LINE
        (((UINT32)a_HfCode << (WORDSIZE+BYTESIZE)) | 
         ((UINT32)a_FlIdx  << WORDSIZE) | a_LnNo));
    TraceLog.AddToTrace(TRACEID_GENERIC,bcHardFail2,    // DSA | BA | PARM1 | PARM2
        (((UINT32)BOX->GetDSA() << (WORDSIZE+BYTESIZE)) | 
         ((UINT32)BOX->GetBA() << WORDSIZE) | 
         (a_Parm1 << BYTESIZE) | a_Parm2));
    TraceLog.AddToTrace(TRACEID_GENERIC,bcHardFail3,    // MDST2 | MDST3 | RDDT | RDST
        (((UINT32)BOX->GetModStat2() << (WORDSIZE+BYTESIZE)) |
         ((UINT32)BOX->GetModStat3() << WORDSIZE) | 
         (BOX->GetRedData() << BYTESIZE) | BOX->GetRedState()));

    TraceLog.CopyCrashTraceBlock();   // Save last 20 tracelogs.

#ifndef DEBUG
    // Commit suicide if release build.
    DIAGFAIL_n = 0;
    while (TRUE);
#endif

#ifdef DEBUG
    #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
    if(FALSE == IsFpgaS2) // S3 FPGA
    {
        P_INTC.IPRK.BIT.LOW  = 0;
    }
    else //if(TRUE = IsFpgaS2)
    #endif
    {
        IPRI_IOL  = 0;    // Shutdown IOL.
    }
    IPRI_BLINK = 0;   // Stop LED refreshing.
    LED_PINS = STATUSLED_RED;
    set_imask_exr(0); // Enable all interrupts.
    
    while (RETURNSTATUS_COMPLETE != DebugPort.PrintString("\n\r\t***HF%2d***",a_HfCode));

    TASKRETURN TaskReturnValue;
    TaskReturnValue.TaskContext = TASKCONTEXT_ONE;
    // Keep debug task running indefinitely
    while (TRUE) {
        TaskReturnValue = DebugTask(TaskReturnValue.TaskContext);
    }
#endif
}


#if !defined(IOPTYPE_SCIOM)
/*******************************************************************************
*                                    isOddParity                               *
*                                    ===========                               *
* PURPOSE   : Test for odd no of 1's in a binary number.                       *
* ARGUMENTS : UINT8 - variable to be tested.                                   *
* RETURN    : TRUE if the variable is ODD, else FALSE.                         *
* NOTES     :                                                                  *
*******************************************************************************/
BOOL isOddParity(UINT8 ucBinary)
{
    BOOL bParity = 0;

    while (ucBinary)
    {
        bParity = !bParity;

        ucBinary &= (ucBinary - 1);
    }

    return bParity;
}
#endif

/*******************************************************************************
*                               RealCompare                                    *
*                               ===========                                    *
* PURPOSE:   This function compares two REAL values. Returns TRUE if both are  *
*            equal or the same NaN type. Otherwise returns FALSE.              *
*                                                                              *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL RealCompare(FLOAT32 a_flVal, FLOAT32 a_frVal) {
    DATABYTES lVal,rVal;

    lVal.f32Val = a_flVal;
    rVal.f32Val = a_frVal;

#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG) && (0)
    if (ucDbgPnt < 5)
    {
        for (UINT8 ucCount = 0; ucCount < sizeof(FLOAT32); ucCount++)
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n%02x - %02x", lVal.ucBytes[ucCount], rVal.ucBytes[ucCount]));
        ucDbgPnt++;
    }    
#endif

    for (UINT8 ucCount = 0; ucCount < sizeof(FLOAT32); ucCount++) {
        if (lVal.ucBytes[ucCount] != rVal.ucBytes[ucCount]) {
#if !defined(IOPTYPE_SCIOM)
            if ((ucCount!=0) || (lVal.ucBytes[0] != 0xFF) || (rVal.ucBytes[0] != 0x7F))
#endif
            return FALSE;
        }
    }

    return TRUE;
}
/*******************************************************************************
*                                memcopy                                       *
*                                =======                                       *
* PURPOSE:  This function copies block of memeory                              *
* ARGUMENTS: pointer to src and destination                                    *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID memcopy(UINT8 *dest, const UINT8 *src, UINT16 count) {
  while(count--) { *dest++ = *src++; }
}
/*******************************************************************************
*                                  EraseFlash                                  *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
#if !defined(IOPTYPE_SCIOM) //#ifndef DEBUG // Flash programming will not be supported by APP debug build.
#if !H8S_2319C // not for DISOE module
BOOL EraseFlash(UINT8 a_ucBlock) {
    // Copy flash erase function to RAM
#if(HEK) && (!defined(IOMTYPE_PI))
    memcopy((UINT8 *)FLASH_UTIL_RELOCATION_ADDRESS,
            (UINT8 *)_EraseFlashBlock,FLASH_UTIL_FUNCTION_SIZE);
#else //Digitals and LOWCOST AI and AO
    memcopy(Flash_Util_Relocation_Address_Ptr,
            (UINT8 *)_EraseFlashBlock,FLASH_UTIL_FUNCTION_SIZE);
#endif

    // Wait for a watchdog refresh to happen so that there is maximum time is
    // available to the flash uitility before the next watchdog refresh window.
    while (TaskScheduler.GetWdtRefreshCounter() != 0);

    // Disable all interrupts
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    // Erase module info block
#if(HEK) && (!defined(IOMTYPE_PI))
    if ((*(FlashErasePtr)FLASH_UTIL_RELOCATION_ADDRESS)(a_ucBlock) > 0) {
#else
    if ((*(FlashErasePtr)Flash_Util_Relocation_Address_Ptr)(a_ucBlock) > 0){
#endif
        // Restore original interrupt level
        set_imask_exr(ucSaveExr);
        return FALSE;
    }

    // Restore original interrupt level
    set_imask_exr(ucSaveExr);
    return TRUE;
}
#endif // if !H8S_2319C
#endif // ifndef DEBUG
/*******************************************************************************
*                                 ProgramFlash                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:     TRUE if Successful                                               *
* NOTES:                                                                       *
*******************************************************************************/
#if !defined(IOPTYPE_SCIOM) //#ifndef DEBUG // Flash programming will not be supported by APP debug build.
#if !H8S_2319C // not for DISOE
BOOL ProgramFlash(UINT8 *a_ucBlockStartAddr,UINT8 *a_ucData) {
    // Copy flash program function to RAM

#if(HEK) && (!defined(IOMTYPE_PI))
    memcopy((UINT8 *)FLASH_UTIL_RELOCATION_ADDRESS,
            (UINT8 *)_ProgramFlash,FLASH_UTIL_FUNCTION_SIZE);
#else //Digitals and LOWCOST AI and AO modules
    memcopy(Flash_Util_Relocation_Address_Ptr,
            (UINT8 *)_ProgramFlash,FLASH_UTIL_FUNCTION_SIZE);
#endif

    // Wait for a watchdog refresh to happen so that there is maximum time is
    // available to the flash uitility before the next watchdog refresh window.
    while (TaskScheduler.GetWdtRefreshCounter() != 0);

    // Disable all interrupts
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    // Program module info block with new data.
#if(HEK) && (!defined(IOMTYPE_PI))
    if ((*(FlashProgramPtr)FLASH_UTIL_RELOCATION_ADDRESS)(a_ucData,a_ucBlockStartAddr) > 0) {
#else
    if ((*(FlashProgramPtr)Flash_Util_Relocation_Address_Ptr)(a_ucData,a_ucBlockStartAddr) > 0) {
#endif
        // Restore original interrupt level
        set_imask_exr(ucSaveExr);
        return FALSE;   // not zero, Failed
    }

    // Restore original interrupt level
    set_imask_exr(ucSaveExr);
    return TRUE;    // Successful
}
#endif // if !H8S_2319C
#endif // ifndef DEBUG
/*******************************************************************************
*                                  EraseFlash                                  *
*                                  ==========                                  *
* PURPOSE:   Erase Flash for DISOE                                             *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
#ifndef DEBUG // Flash programming will not be supported by APP debug build.
#if H8S_2319C // for DISOE module only
UINT8 EraseFlash(UINT8 a_ucBlock) {
    // Copy Flash Erase and DummyFunc functions to RAM
    memcopy(Flash_Util_Relocation_Address_Ptr,(UINT8 *)Erase018FlashBlock,FLASH_UTIL_SIZE);
    memcopy(DummyFunc_address,(UINT8 *)DummyFunc,FLASH_DUMMYFUNC_SIZE);
    // First down load the Erasing program to RAM
    UINT8 TempRet = (*(Erase018FlashPtr)Flash_Util_Relocation_Address_Ptr)(MAXFLASHBLOCK+1);
    if(TempRet>FLASH_NO_ERROR){
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x771,(UINT32)TempRet);
        return TempRet;
    }

    // Disable all interrupts
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    // Erase Flash block
    TempRet = (*(Erase018FlashPtr)Flash_Util_Relocation_Address_Ptr)(a_ucBlock);
    if( TempRet>FLASH_NO_ERROR){
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x772,(UINT32)TempRet);
        set_imask_exr(ucSaveExr);
        return TempRet;
    }
    // Restore original interrupt level
    set_imask_exr(ucSaveExr);
    return TRUE;
}
#endif // if !H8S_2319C
#endif // ifndef DEBUG
/*******************************************************************************
*                                 ProgramFlash                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
#ifndef DEBUG // Flash programming will not be supported by APP debug build.
#if H8S_2319C // for DISOE module only
UINT8 ProgramFlash(UINT32 a_ucBlockStartAddr,UINT8 *a_ucData) {
    // Copy Flash Program and DummyFunc functions to RAM
    memcopy(Flash_Util_Relocation_Address_Ptr,(UINT8 *)Program018FlashLine,FLASH_UTIL_SIZE);
    memcopy(DummyFunc_address,(UINT8 *)DummyFunc,FLASH_DUMMYFUNC_SIZE);
    
    // First down load the Programming program to RAM
    UINT8 TempRet = (*(Program018FlashPtr)Flash_Util_Relocation_Address_Ptr)(MAXFLASHADDRESS+1,a_ucData); 
    if(TempRet>FLASH_NO_ERROR){
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x773,(UINT32)TempRet);
        return TempRet;
    }

    // Disable all interrupts
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    // Program module info block with new data.
    TempRet = (*(Program018FlashPtr)Flash_Util_Relocation_Address_Ptr)(a_ucBlockStartAddr,a_ucData); 
    if(TempRet>FLASH_NO_ERROR){
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x774,(UINT32)TempRet);
        set_imask_exr(ucSaveExr);
        return TempRet;
    }
    // Restore original interrupt level
    set_imask_exr(ucSaveExr);
    return TRUE;
}
#endif // if H8S_2319C
#endif // ifndef DEBUG
/*******************************************************************************
*                         Erase018FlashBlock                                   *
*                         =======================                              *
* PURPOSE: This function downloads the Erase function from LSI to RAM.         *
*          Also it does Erasing the specified block if Erase routine is already*
*          downloaded.                                                         * 
* ARGUMENTS: Flash Blck                                                        *
* RETURN:    Error Code                                                        *
* NOTES:                                                                       *
*******************************************************************************/
#ifndef DEBUG // Flash programming will not be supported by APP debug build.
#if H8S_2319C // for DISOE module only
UINT8 Erase018FlashBlock(UINT8 FlashBlock)
{
    // flash pass/fail result parameter
    UINT8 fpfr=1;
    // function pointer for calling the initailization and Erase routines
    UINT8 (*fp) (VOID);
    // if the given flash block number is greater than Max flash block(16)
    // down load the Flash Erase routine to RAM from LSI
    if(FlashBlock>MAXFLASHBLOCK)
    {
        // pointer to access the contents of the FTDAR address containg
        volatile UINT8 *dfptr;
        // intialize the dfpr to point to first byte in download area specified by FTDAR
        dfptr = (UINT8 *)FLASHUTIL_RAM_ADDRESS;
        
        P_SYSCR2.BIT.FLSHE = 1;
        // select flash programming program to be downloaded
        P_FECS.BIT.EPVB = 1; // down load the flash erasing program to RAM
        P_FPCS.BIT.PPVS = 0; // do not down load flash programming programm to RAM
        // initialise the contents of dfptr
        *dfptr = 0xff;
        // set the addres where flash prog and erase routines will be loaded
        // these routines will take approx 2kB of RAM
        P_FTDAR = FTDAR_START_ADDRESS;
        // start downloading of flash programming program
        // disable software protection
        P_FKEY = 0xA5;
        P_FCCS.BIT.SCO = 1;
        // give delay
        for(int i=0;i<4;i++);
        // enable software protection
        P_FKEY = 0x00;
        // check that the download had completed successfully
        if(*dfptr != 0)
        {
            // the down load failed for some reason
            P_SYSCR2.BIT.FLSHE = 0;
            return FLASH_PROG_ERASE_DOWNLD_ERROR;
        }
        // set the operating frequency
        (*(DummyFuncPtr)DummyFunc_address)(frequency,0);
        // load the address of erase initialisation routine into the function pointer
        fp = (FlashUtilsPtr)(INIT_ERASE_ADDRESS);
        fpfr = fp();
        // check that the initialisation was done without error
        if(fpfr != 0)
        {
            // there has been an error
            P_SYSCR2.BIT.FLSHE = 0;
            return FLASH_INIT_ERROR;
        }
    }
    else
    {// erase the specified Flash Block

        // variable for calculating the return value
        P_SYSCR2.BIT.FLSHE = 1;
        // disable the software protection
        P_FKEY = 0x5A;
        // pass the block number into ER0 register by calling the DummyFunc()
        (*(DummyFuncPtr)(DummyFunc_address))(FlashBlock,0);
        // call the erasing routine
        fp = (FlashUtilsPtr)(ERASE_ROUTINE_ADDRESS);
        fpfr = fp();
        // enable the software protection
        P_FKEY = 0x00;
        if(fpfr != 0)
        {
            // there has been an programming error
            P_SYSCR2.BIT.FLSHE = 0;
            return FLASH_ERASING_ERROR;
        }
    }
    P_SYSCR2.BIT.FLSHE = 0;
    return FLASH_NO_ERROR;
}
/*******************************************************************************
*                         Program018FlashLine                                  *
*                         =======================                              *
* PURPOSE: This function copies the Flash functions from LSI to RAM to use it. *
*          Also it does the programming if program is already loaded in to RAM *
* ARGUMENTS: Flash Address, and the Data to be written to this address         *
* RETURN:    Error Code                                                        *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 Program018FlashLine(UINT32 Address, UINT8* ProgData)
{
    // flash pass/fail result parameter
    UINT8 fpfr=1;
    // function pointer for calling the initailization and program routines
    UINT8 (*fp) (VOID);
    // if the given flash block number is greater than Max flash block(16)
    // down load the Flash Program routine to RAM from LSI
    if(Address>MAXFLASHADDRESS)
    {
        // pointer to access the contents of the FTDAR address containg
        volatile UINT8 *dfptr;
        // intialize the dfpr to point to first byte in download area specified by FTDAR
        dfptr = (UINT8 *)FLASHUTIL_RAM_ADDRESS;
        P_SYSCR2.BIT.FLSHE = 1;
        // set the addres where flash prog and erase routines will be loaded
        // these routines will take approx 4kB of RAM
        P_FTDAR = FTDAR_START_ADDRESS;
        // select flash programming program to be downloaded
        P_FPCS.BIT.PPVS = 1; // down load flash programming programm to RAM
        P_FECS.BIT.EPVB = 0; // do not down load the flash erasing program to RAM
        // initialise the contents of dfptr
        *dfptr = 0xff;
        // start downloading of flash programming program
        // disable software protection
        P_FKEY = 0xA5;
        P_FCCS.BIT.SCO = 1;
        // give delay
        for(int i=0;i<4;i++);
        // enable software protection
        P_FKEY = 0x00;
        // check that the download had completes successfully
        if(*dfptr != 0)
        {
            // the down load failed for some reason
            P_SYSCR2.BIT.FLSHE = 0;
            return FLASH_PROG_ERASE_DOWNLD_ERROR;
        }
        // set the operating frequency
        (*(DummyFuncPtr)DummyFunc_address)(frequency,0);
        // load the address of init program routine into the function pointer
        fp = (FlashUtilsPtr)(INIT_PROGRAM_ADDRESS);
        // call the initialisation routine
        fpfr = fp();
        // check that the initialisation was done without error
        if(fpfr != 0)
        {
            // there has been an error
            P_SYSCR2.BIT.FLSHE = 0;
            return FLASH_INIT_ERROR;
        }

    }
    else
    {// Program the Flash
        // variables used for prog destination
        UINT32 fmpar,fmpdr;
        // disable the software protection
        fmpar = Address;
        fmpdr = (UINT32)ProgData;
        P_SYSCR2.BIT.FLSHE = 1;
        // disable the software protection
        P_FKEY = 0x5A;
        // pass the addressess to the ER0 ans ER1 registers by calling the DummyFunc().
        (*(DummyFuncPtr)DummyFunc_address)(fmpdr,fmpar);
        // call the programming routine
        fp = (FlashUtilsPtr)(PROGRAM_ROUTINE_ADDRESS);
        fpfr = fp();
        // enable the software protection
        P_FKEY = 0x00;
        if(fpfr != 0)
        {
            // there has been an programming error
            P_SYSCR2.BIT.FLSHE = 0;
            return FLASH_PROGRAMMING_ERROR;
        }
    }
    P_SYSCR2.BIT.FLSHE = 0;
    return FLASH_NO_ERROR;
}
/*******************************************************************************
*                               DummyFunc                                      *
*                         ===================                                  *
* PURPOSE:  dummy function to get the passed values into ER0 and ER1           *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID DummyFunc(UINT32 ul1, UINT32 ul2)
{
    // dummy function to get the passed values into ER0 and ER1
    return;
}
#endif // if H8S_2319C
#endif // ifndef DEBUG
/*******************************************************************************
*                                     fabs                                     *
*                                     =====                                    *
* PURPOSE: Returns the absolute value of FLOAT32                               *
* ARGUMENTS: Value for which absolute value is required                        *
* RETURN: Absolute value                                                       *
* NOTES:                                                                       *
*******************************************************************************/
FLOAT32 fabs (FLOAT32 a_fVal) {
  return !isnan(a_fVal) ? ((a_fVal < (FLOAT32)0.0) ? -a_fVal : a_fVal) : NaN;
}
/*******************************************************************************
*                                     strlen                                   *
*                                     ======                                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef DEBUG
SIZE_T strlen(const CHAR *a_cpString) {
    SIZE_T szStrSize;
    for (szStrSize = 0; *a_cpString++ != NULLCHAR; szStrSize++) ;
    return szStrSize;
}
#endif
/*******************************************************************************
*                                    strcmp                                    *
*                                    ======                                    *
* PURPOSE:                                                                     *
*    Compare two strings for equality.                                         *
* ARGUMENTS:                                                                   *
*    a_cpstrOne, a_cpstrTwo -  strings to be compared.                         *
* RETURN:                                                                      *
*    BOOL - TRUE if strings are identical; else FALSE.                         *
*******************************************************************************/
#ifdef DEBUG
BOOL strcmp(const CHAR *a_cstrOne,const CHAR *a_cstrTwo) {
    while (*a_cstrOne && *a_cstrTwo) {
        if (*a_cstrOne++ != *a_cstrTwo++) return FALSE;
    }
    if (*a_cstrOne == *a_cstrTwo) return TRUE;
    return false;
}
#endif
/*******************************************************************************
*                                    strcpy                                    *
*                                    ======                                    *
* PURPOSE:                                                                     *
*    Copy all characters form source string to destination string.             *
* ARGUMENTS:                                                                   *
*    Source string, destination string.                                        *
* RETURN:                                                                      *
*    None.                                                                     *
*******************************************************************************/
#ifdef DEBUG
VOID strcpy(CHAR *a_cpDest,const CHAR *a_cpSrc) {
    while (*a_cpSrc) {
        *a_cpDest++ = *a_cpSrc++;
    }
    *a_cpDest = '\0';
}
#endif
/*******************************************************************************
*                                      atoi                                    *
*                                      ====                                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef DEBUG
INT16 atoi(const CHAR *a_cpString) {
    const UINT8 MAXLENGTH = 5;
    INT16 iResult = 0, iPower = 1;
    BOOL  bNegative = FALSE;
    UINT8 ucLen = 0;
    if (*a_cpString == '-') {
        bNegative = TRUE;
        a_cpString++;
    }
    while ((*a_cpString) && (ucLen < MAXLENGTH)) {
        if ((*a_cpString >= '0') && (*a_cpString <= '9')) {
            ucLen++;
            a_cpString++;
        }
        else {
            break;
        }
    }
    while (ucLen) {
        iResult += (*--a_cpString - '0') * iPower;
        iPower *= 10;
        ucLen--;
    }
    return bNegative ? -iResult : iResult;
}
#endif
/*******************************************************************************
*                                      itoa                                    *
*                                      ====                                    *
* PURPOSE: Convert integer into string                                         *
* ARGUMENTS:Interger Number, buffer to store string                            *
* RETURN: None.                                                                *
* NOTES: This function is used by only PI debug FW.Max string length is 6      *
*******************************************************************************/
#ifdef DEBUG
VOID itoa(UINT32 a_Number,CHAR *a_cpString) {
  
  for (int i = 6; i > 0; i --)
   *a_cpString ++ = '0';

  *a_cpString-- = NULLCHAR;
  
  while(a_Number/10)
  {
    *a_cpString --  = '0' + (a_Number % 10);
    a_Number /= 10; 
  }

  *a_cpString = '0' + (a_Number % 10);

}
#endif
/*******************************************************************************
*                                     atoh                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
* ARGUMENTS: String containing hex characters                                  *
* RETURN: UINT32 equivalent of string passed                                   *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef DEBUG
UINT32 atoh(const CHAR *a_cpString) { 
    UINT32 ulResult = 0; 
    while (CHAR cDigit = *a_cpString++) {
        if ((cDigit >= '0') && (cDigit <= '9')) {
            cDigit -= '0'; 
        }
        else if ((cDigit >= 'a') && (cDigit <= 'f')) {
            cDigit = cDigit - 'a' + 10; 
        }
        else if ((cDigit >= 'A') && (cDigit <= 'F')) {
            cDigit = cDigit - 'A' + 10; 
        }
        else {
            return 0;
        }
        ulResult = ulResult * 16 + cDigit;
    }
    return ulResult;
}
#endif
/*******************************************************************************
*                                     atof                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
* 1) Accurate only upto two decimal postions.                                  *
*******************************************************************************/
#ifdef DEBUG
FLOAT32 atof(const CHAR *a_cpString) {
    FLOAT32 fResult = 0, fPower = 10.0;
    BOOL bNegative = FALSE;
    if (*a_cpString == '-') {
        bNegative = TRUE;
        a_cpString++;
    }
    fResult = (FLOAT32)atoi(a_cpString); // convert the whole number part
    while (*a_cpString) { // search for decimal point from the beginning
        if ('.' == *a_cpString++) {
            break;
        }
    }
    while (*a_cpString) { // convert the decimal part
        if ((*a_cpString >= '0') && (*a_cpString <= '9')) {
            fResult += (FLOAT32)(*a_cpString++ - '0') / fPower;
            fPower *= 10.0;
        }
        else {
            break;
        }
    }
    return bNegative ? -fResult : fResult;;
}
#endif
/*******************************************************************************
*                                   snprintf                                   *
*                                   ========                                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef DEBUG
VOID snprintf(CHAR *a_cpDest,const CHAR *a_cpSrc,CHAR *a_cpArgs,UINT8 a_ucMaxLen) {
    const UINT8 MAXLENGTH = 8;
    INT32 lVal;
    UINT32 ulVal;
    FLOAT64 fVal;
    CHAR *cpStr;
    UINT8 ucCount,ucFillCount,ucFillChar,ucVarBuffer[MAXLENGTH];
    UINT32 ulDivisor,ulBase;
    while (a_ucMaxLen > 1) {
        switch (*a_cpSrc++) {
        case '\\':
            switch (*a_cpSrc++) {
            case 'n':
                *a_cpDest++ = '\n';
                a_ucMaxLen--;
                break;
            case 'r':
                *a_cpDest++ = '\r';
                a_ucMaxLen--;
                break;
            case 't':
                *a_cpDest++ = '\t';
                a_ucMaxLen--;
                break;
            default:
                *a_cpDest = NULLCHAR;
                return;
            }
            break;
        case '%':
            lVal = 0;
            ulVal = 0;
            fVal = 0.0;
            ucCount = 0;
            ucFillCount = 0;
            ucFillChar = ' ';
            ulBase = 10;
            ulDivisor = 10000000;
            if ('0' == *a_cpSrc) {
                ucFillChar = '0';
                a_cpSrc++;
            }
            if ((*a_cpSrc >= '1') && (*a_cpSrc <= '9')) {
                ucFillCount = *a_cpSrc++ - '0';
            }
            switch (*a_cpSrc++) {
            case 'c':
                *a_cpDest++ = *(a_cpArgs + 1);
                // compiler pushes at least two bytes for even alignement
                a_cpArgs += sizeof(UINT16); 
                a_ucMaxLen--;
                continue;
            case 's':
                cpStr = (CHAR *)*(UINT32 *)a_cpArgs;
                while (*cpStr && (a_ucMaxLen > 1)) {
                    *a_cpDest++ = *cpStr++;
                    a_ucMaxLen--;
                }
                a_cpArgs += sizeof(CHAR *);
                continue;
            case 'f':
                // Compiler always pushes 8 bytes for float.
                // No problem with the typecast since we know the stack
                // arguments are aligned in even address.
                fVal = *(FLOAT64 *)a_cpArgs;
                a_cpArgs += sizeof(FLOAT64); 
                if (fVal < 0) {
                    *a_cpDest++ = '-';
                    a_ucMaxLen--;
                    ulVal = fVal * -1;
                }
                else {
                    ulVal = (UINT32)fVal;
                }
                break;
            case 'i':
                // No problem with the typecast since we know the stack
                // arguments are aligned in even address.
                lVal = *(INT16 *)a_cpArgs;
                a_cpArgs += sizeof(INT16);
                if (lVal < 0) {
                    *a_cpDest++ = '-';
                    a_ucMaxLen--;
                    ulVal = lVal * -1;
                }
                else {
                    ulVal = (UINT32)lVal;
                }
                break;
            case 'd':
                // No problem with the typecast since we know the stack
                // arguments are aligned in even address.
                ulVal = *(UINT16 *)a_cpArgs;
                a_cpArgs += sizeof(UINT16);
                break;
            case 'l':
                // No problem with the typecast since we know the stack
                // arguments are aligned in even address.
                lVal = *(INT32 *)a_cpArgs;
                a_cpArgs += sizeof(INT32);
                if (lVal < 0) {
                    *a_cpDest++ = '-';
                    a_ucMaxLen--;
                    ulVal = lVal * -1;
                }
                else {
                    ulVal = (UINT32)lVal;
                }
                break;
            case 'u':
                // No problem with the typecast since we know the stack
                // arguments are aligned in even address.
                ulVal = *(UINT32 *)a_cpArgs;
                a_cpArgs += sizeof(UINT32);
                break;
            case 'x':
                // No problem with the typecast since we know the stack
                // arguments are aligned in even address.
                ulVal = *(UINT16 *)a_cpArgs;
                a_cpArgs += sizeof(UINT16);
                ulBase = 0x10;
                ulDivisor = 0x10000000;
                break;
            case 'X':
                // No problem with the typecast since we know the stack
                // arguments are aligned in even address.
                ulVal = *(UINT32 *)a_cpArgs;
                a_cpArgs += sizeof(UINT32);
                ulBase = 0x10;
                ulDivisor = 0x10000000;
                break;
            default:
                *a_cpDest = NULLCHAR;
                return;
            }
            if (0 == ulVal) {
                ucVarBuffer[ucCount++] = '0';
            }
            else {
                while ((ulDivisor >= 1) && (ucCount < MAXLENGTH)) {
                    if ((ulVal > 0) && (ulVal >= ulDivisor)) {
                        ucVarBuffer[ucCount] = (UINT8)(ulVal / ulDivisor);
                        ulVal -= ucVarBuffer[ucCount] * ulDivisor;
                        if (ucVarBuffer[ucCount] > 9) {
                            ucVarBuffer[ucCount] = ucVarBuffer[ucCount] - 10 + 'A';
                        }
                        else {
                            ucVarBuffer[ucCount] += '0';
                        }
                        ucCount++;
                    }
                    else if (ucCount > 0) {
                        ucVarBuffer[ucCount++] = '0';
                    }
                    ulDivisor /= ulBase;
                }
            }
            while ((ucFillCount > ucCount) && (a_ucMaxLen > 1)) {
                *a_cpDest++ = ucFillChar;
                a_ucMaxLen--;
                ucFillCount--;
            }
            ucFillCount = 0;
            while ((ucFillCount < ucCount) && (a_ucMaxLen > 1)) {
                *a_cpDest++ = ucVarBuffer[ucFillCount];
                a_ucMaxLen--;
                ucFillCount++;
            }
            break;
        default:
            *a_cpDest++ = *--a_cpSrc;
            a_ucMaxLen--;
            if (NULLCHAR == *a_cpSrc++) {
                return;
            }
        }
    }
    *a_cpDest = NULLCHAR;
}
#endif
#if !AIAO
/*******************************************************************************
*                              GetReadbackRegister                             *
*                              ===================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 GetReadbackRegister(UINT8 a_ucIndex)
{
    RDBK_SEL = a_ucIndex & CPLD_REG_LSELBITS;
#if (defined (IOMTYPE_DO)) || (defined (IOMTYPE_DISOE)) 
    if (a_ucIndex  > RDBK_BANK7) {
      #ifdef IOMTYPE_DISOE
        RDBK_SEL3 = 1;
        UINT8 ucReadback = RDBK_BYTE;
        RDBK_SEL3 = 0;
        return ucReadback;
      #else
        RDBK_STRB_n = 1;                              // Disable CPLD outputs
        RDBK_SEL3 = 1;                                // Select CPLD 2
        RDBK_STRB_n = 0;                              // Re-enable CPLD outputs
        UINT8 ucReadback = RDBK_BYTE;
        RDBK_STRB_n = 1;                              // Disable CPLD outputs
        RDBK_SEL3 = 0;                                // Select CPLD 1
        RDBK_STRB_n = 0;                              // Re-enable CPLD outputs
        return ucReadback;
      #endif
    }
#endif // DO or DISOE
    UINT8 ucReadback = RDBK_BYTE;
    return ucReadback;
}
#endif // !AIAO
#if LOWCOST
/*******************************************************************************
*                              GetReadbackRegister                             *
*                              ===================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 ReadCPLDRegister(UINT8 a_ucIndex)
{   
    UINT8 ucCPLDRegData,ucTempData; 

    ucCPLDRegData = ByteCPLD(a_ucIndex);
    ucTempData = 0;
    if(a_ucIndex == 0x05){
       ucTempData = (BOTTOM)?   (ucTempData | 0x20):(ucTempData | 0x00);
       ucTempData = (REDUNT_n)? (ucTempData | 0x01):(ucTempData | 0x00);     
#ifdef IOMTYPE_AIH
       ucTempData = (!BUPREQ_IN)? (ucTempData | 0x02):(ucTempData | 0x00);  
#else // AO
       ucTempData = (BUPREQ_IN)?  (ucTempData | 0x02):(ucTempData | 0x00);         
#endif
       ucCPLDRegData = (ucCPLDRegData | ucTempData);
    }          
    return ucCPLDRegData;
}
#endif
