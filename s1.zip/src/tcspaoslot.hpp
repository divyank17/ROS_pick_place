/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcspaoslot.hpp                                              *
*    Description : Class clsTcSpAoSlot declaration.                            *
*******************************************************************************/
#ifndef __TCSPAOSLOT_HPP__
#define __TCSPAOSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define TCSPAOSLOT_SIZE ((sizeof(clsTcSpAoSlot) + (sizeof(clsTcSpAoSlot) % 2)) / 2)

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SPAO_SYNC_VER_1;
//

#define HUNDRED                         (FLOAT32)100.0

const UINT8  MUX_CHANNELSEL_SETTLE_TIME     = 1;
const UINT8   PASSCOUNTMAX          = 6;       // 200ms Delay
const UINT8   PASSCOUNTMIN          = 1;       // must be >= 1
typedef union tagDacByte {
    UINT8 ucByte[2];
    struct {
        UINT16 Commmand : 3;
        UINT16 Count    : 12;
        UINT16 SubBit   : 1;
    } DAC;
} DACBYTE;

//DAC Commands 
typedef enum DAC_CMDS{
    NO_OPERATION                      = 0x0,
    LD_INPUT_REG                      = 0x1,
    LD_INPUT_AND_DAC_REG              = 0x2,
    UPDATE_DAC_REG_FROM_INPUT_REG     = 0x3,
    SHUTDOWN_DAC                      = 0x4,
    UPO_LOW                           = 0x5,
    UPO_HIGH                          = 0x6,
    MODE1                             = 0x7,
    MODE0                             = 0x7
}DAC_CMDS;
const UINT16 DEFAULT_OUTPUT_CAPACITORCHARGE_TIME       = 50;           //50 us
const UINT16 CALIBRATION_EXTENDED_CAPACITORCHARGE_TIME = 10000;        //10  ms
const UINT16 CALIBRATION_MINIMUM_CAPACITORCHARGE_TIME  = 150;          //150 us


const UINT8 SNSCAL  = 0x00;
const UINT8 SNSV1   = 0x01;
const UINT8 HIZERO1 = 0x03;
const UINT8 FACCAL  = 0x08;

const UINT8 CALCHK  = 0x05;

const UINT8 LOOPBACK_ADDRESS[] = {
    SNSCAL,
    SNSV1,  
    HIZERO1,
    CALCHK, 
    FACCAL 
};

const UINT8 MUX_READBACK_RETRYCOUNT = 4;
const UINT16 LOOPBACK_COMPARATORSETTLE_TIME = 150;
const UINT16 DAC_SETTLE_TIME = 50;
const FLOAT32 OP_LOLIMIT            = -6.9; 
const FLOAT32 OP_HILIMIT            = 106.9;

const UINT16  MINCURRENT_OUTPUT_DACCOUNT    = 0x080; // 0 mA
const UINT16  MAXCURRENT_OUTPUT_DACCOUNT    = 0xFFF; // 25 mA

//enms for temperature conversion
const  FLOAT32 FARENHEIT_CONV_OFFSET  =   32.0;
const  FLOAT32 FARENHEIT_CONV_NUM     =   9.0;
const  FLOAT32 FARENHEIT_CONV_DEN     =   5.0;
const  FLOAT32 RANKINE_CONV_OFFSET    =   491.69;
const  FLOAT32 RANKINE_CONV_NUM       =   9.0;
const  FLOAT32 RANKINE_CONV_DEN       =   5.0;
const  FLOAT32 KELVIN_CONV_OFFSET     =   273.0;
const UINT8  MUX_ENABLE                     = 0x80;
const UINT16  FACCAL_OUTPUT_DACCOUNT        = 0x8F7;
const UINT16  MINHIZERO_LOOPBACK_DACCOUNT   = 0x055; 
const UINT16  MAXHIZERO_LOOPBACK_DACCOUNT   = 0x090; 
const UINT16  MAX_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x82D;
const UINT16  MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x738;
const UINT16  MAX_FIVE_V_OUTPUT_DACCOUNT    = 0xCC6;
const UINT16  MIN_FIVE_V_OUTPUT_DACCOUNT    = 0xB97;
const UINT16  MAX_ONE_V_OUTPUT_DACCOUNT     = 0x33F;
const UINT16  MIN_ONE_V_OUTPUT_DACCOUNT     = 0x275;
const UINT8   DAC_RESOLUTION                = 12;    // 12 bit DAC

const UINT8  LOOPBACK_ADDRESS_READBACK_MASK = 0x9F;
const UINT16  FOUR_MA_H_OUTPUT_DACCOUNT     = 0x32E;
const UINT16  FOUR_MA_L_OUTPUT_DACCOUNT     = 0x2C8;
const UINT16  TWENTY_MA_H_OUTPUT_DACCOUNT   = 0xD1A;//0xD80;
const UINT16  TWENTY_MA_L_OUTPUT_DACCOUNT   = 0xCB4;
const UINT8 SLOT_SPARESIZE=16;

#define NUM_ONE             1
#define NUM_TWENTY          20
#define NUM_TWENTY_TWO      22

const FLOAT32 EXTENDED_OP_LOLIMIT   = -25.0;
const FLOAT32 EXTENDED_OP_HILIMIT   = 131.187;

//Array Index positions in the LOOPBACK_ADDRESS array
const UINT8 SNSCAL_OFFSET  = 0; 
const UINT8 SNSCAL1_OFFSET = 1; 
const UINT8 HIZERO1_OFFSET = 2;
const UINT8 CALCHK_OFFSET  = 3;
const UINT8 FACCAL_OFFSET  = 4;

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsTcSpAoSlot; // forward declaration

/* Slot Database Parameter Info */
typedef struct tagSpAoSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsTcSpAoSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsTcSpAoSlot::* PostPtr)(UINT8);
    VOID *   (clsTcSpAoSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} SPAOSLOTPARAMINFO;
//

/*******************************************************************************
*                                   clsTcSpAoSlot                              *
*                                   =============                              *
*******************************************************************************/
class clsTcSpAoSlot : public clsOutSlot {
protected:

    //Member Variables
    INT32       OpConn;
    BOOL        OpChar;
    BOOL        OTPT_Unused;
    FLOAT32     OpIn0;
    FLOAT32     OpIn1;
    FLOAT32     OpIn2;
    FLOAT32     OpIn3;
    FLOAT32     OpIn4;
    FLOAT32     OpIn5;
    FLOAT32     OpOut0;
    FLOAT32     OpOut1;
    FLOAT32     OpOut2;
    FLOAT32     OpOut3;
    FLOAT32     OpOut4;
    FLOAT32     OpOut5;
    FLOAT32     OpLoLimitVal;
    FLOAT32     OpHiLimitVal;
    BOOL        StdbyMan;
    BOOL        InitReq;
    BOOL        AoInitReq;
    FLOAT32     B0_LInv;
    FLOAT32     B1_LInv; 
    FLOAT32     B0_Inv;
    FLOAT32     B1_Inv;
    FLOAT32     B0_L;
    FLOAT32     B1_L;
    FLOAT32     B0_O;
    FLOAT32     B1_O;
    FLOAT32     Chrc_S0;
    FLOAT32     Chrc_S1;
    FLOAT32     Chrc_S2;
    FLOAT32     Chrc_S3;
    FLOAT32     Chrc_S4;
    FLOAT32     OpInternl;
    FLOAT32     OpInternal;
    FLOAT32     OpFinal;
    UINT16      OutDACImg;
    UINT16      LoopBackDACImg;
    AOLPBKSTS   LoopBackStatus;
    UINT8       ucPassCount;
    UINT8       ucSkipLpBkTst;
    BOOL        bReadBackrequired;
    DACBYTE     DacData;    
    BOOL        bOpenLoopbackMuxSF;
    //

    //Static Member variables
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const SPAOSLOTPARAMINFO tblParamInfo[256];
    static UINT8 SpAoSlotChkpntVersion;
    //

    //Method to Initial member variables
    VOID InitAoSlot(BOOL, BOOL);
    //

    //Methods to support characterization
    PASTATUS ClampWithWarning(VOID *,UINT8 );
    PASTATUS ChrcPntBnds(FLOAT32 *,FLOAT32,UINT8);
    FLOAT32  ChrcFrwrd(FLOAT32 );
    FLOAT32  ChrcBkwrd(FLOAT32 );
    //

    //Pre and Post Methods for Database parameters
    PASTATUS PreOpConn(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreModeAttr(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreMode(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostMode(UINT8 a_ucAccLvl);
    PASTATUS PreModePerm(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreNModeAttr(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreNMode(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostOp(UINT8 a_ucAccLvl);
    VOID     PostOpChar(UINT8 a_ucAccLvl);  
    PASTATUS PrePtExecSt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPtExecSt(UINT8 a_ucAccLvl);
    PASTATUS PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPntType(UINT8 a_ucAccLvl);
    PASTATUS PreOpIn1(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOpIn2(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOpIn3(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOpIn4(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOpOut1(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOpOut2(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOpOut3(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOpOut4(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreRedTag(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreFaultOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreOptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostFaultOpt(UINT8 a_ucAccLvl);
    PASTATUS PreFaultValue(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostOptDir(UINT8);

    inline PASTATUS PreCheckPoint(UINT8 *, UINT8) {
        SpAoSlotChkpntVersion = LATEST_SP_AO_SLTCHKPNT_VERSION;
        return PA_OK;
    }    
    //

    //clsTcSpAoSlot Class Varibles GetPtr methods
    inline VOID *GetOpConn(VOID)            {return &OpConn;} 
    inline VOID *GetFaultStatePtr(VOID)     {return &FaultState;} 
    inline VOID *GetLocalManPtr(VOID)       {return &LocalMan;}
    inline VOID *GetModeAttrPtr(VOID)       {return &ModeAttr;} 
    inline VOID *GetModePtr(VOID)           {return &Mode;} 
    inline VOID *GetModePermPtr(VOID)       {return &ModePerm;} 
    inline VOID *GetNModeAttrPtr(VOID)      {return &NModeAttr;} 
    inline VOID *GetNModePtr(VOID)          {return &NMode;} 
    VOID *GetOpPtr(VOID);
    inline VOID *GetOpCharPtr(VOID)         {return &OpChar;}
    inline VOID *GetOpFinalPtr(VOID)        {return &OpFinal;}
    inline VOID *GetOpIn0Ptr(VOID)          {return &OpIn0;}
    inline VOID *GetOpIn1Ptr(VOID)          {return &OpIn1;}
    inline VOID *GetOpIn2Ptr(VOID)          {return &OpIn2;}
    inline VOID *GetOpIn3Ptr(VOID)          {return &OpIn3;}
    inline VOID *GetOpIn4Ptr(VOID)          {return &OpIn4;}
    inline VOID *GetOpIn5Ptr(VOID)          {return &OpIn5;}
    inline VOID *GetOpOut0Ptr(VOID)         {return &OpOut0;}
    inline VOID *GetOpOut1Ptr(VOID)         {return &OpOut1;}
    inline VOID *GetOpOut2Ptr(VOID)         {return &OpOut2;}
    inline VOID *GetOpOut3Ptr(VOID)         {return &OpOut3;}
    inline VOID *GetOpOut4Ptr(VOID)         {return &OpOut4;}
    inline VOID *GetOpOut5Ptr(VOID)         {return &OpOut5;}
    inline VOID *GetOptDirPtr(VOID)         {return &OptDir;} 
    inline VOID *GetRedTagPtr(VOID)         {return &RedTag;}
    inline VOID *GetStdbyManPtr(VOID)       {return &StdbyMan;}
    VOID *GetInitReqPtr(VOID);
    inline VOID *GetFaultOptPtr(VOID)       {return &FaultOpt;}
    inline VOID *GetFaultValuePtr(VOID)     {return &FaultValue;}   
    inline VOID *GetB0_LInvPtr(VOID)        {return &B0_LInv;}
    inline VOID *GetB1_LInvPtr(VOID)        {return &B1_LInv;}
    inline VOID *GetOpInternalPtr(VOID)     {return &OpInternl;}
    inline VOID *GetB0_LPtr(VOID)           {return &B0_L;}
    inline VOID *GetB1_LPtr(VOID)           {return &B1_L;}
    inline VOID *GetB0_OPtr(VOID)           {return &B0_O;}
    inline VOID *GetB1_OPtr(VOID)           {return &B1_O;}
    inline VOID *GetChrc_S0Ptr(VOID)        {return &Chrc_S0;}
    inline VOID *GetChrc_S1Ptr(VOID)        {return &Chrc_S1;}
    inline VOID *GetChrc_S2Ptr(VOID)        {return &Chrc_S2;}
    inline VOID *GetChrc_S3Ptr(VOID)        {return &Chrc_S3;}
    inline VOID *GetChrc_S4Ptr(VOID)        {return &Chrc_S4;}
    inline VOID *GetOTPT_UnusedPtr(VOID)    {return &OTPT_Unused;}
    inline VOID *GetB0_InvPtr(VOID)         {return &B0_Inv;}
    inline VOID *GetB1_InvPtr(VOID)         {return &B1_Inv;}
    inline VOID *GetOutputDACImgPtr(VOID)    {return &OutDACImg;}
    //

    //Static Varibles GetPtr methods
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams; }
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SpAoSlotChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    //

    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SpAoSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SpAoSlotChkpntVersion;}

    //Database Access Related Methods
    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    //

    clsTcSpAoSlot(const clsTcSpAoSlot&); // Safeguard against default copy constructor
    clsTcSpAoSlot& operator=(const clsTcSpAoSlot&); // and default assignment

public:
    clsTcSpAoSlot(UINT8); 
    ~clsTcSpAoSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,TCAOSERVOSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,TCAOSERVOSLOT_HPP,__LINE__); }

    //Database Access Related Methods    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    //

    //Method to Initial member variables
    VOID InitSlotDatabase(BOOL bFullInit);
    VOID InactivateSlot(VOID);
    //
    
    //AO Channel Processing Helper methods
    VOID   CmptInitReq(VOID);
    VOID   UpdateOpFinal(FLOAT32);
    VOID   DriveOutput( DELAY_TYPE a_eDelayType = NormalOutput);
    VOID   BackInit(VOID);
    VOID   DriveDac(UINT16);
    BOOL   ComputeCalibrationConstants(FLOAT32,FLOAT32);
    VOID   SlotFaultHandler(TOG_FAILED);
    void   StoreInternalOp();
    BOOL   OpenLoopbackMux(UINT8 a_uiChanNum, BOOL bProcSF);
    BOOL   ReadComparatorOutput(VOID);
    UINT16 GetInternalReading();
    inline VOID SetOutDACImg(UINT16 a_uiVal) { OutDACImg = a_uiVal; }
    inline VOID SetOpFinal(FLOAT32 newOpFinal)  {OpFinal=newOpFinal;}
    inline BOOL GetOTPT_Unused(VOID){ return OTPT_Unused; }
    inline VOID CloseLoopbackMux(UINT8 ) {
        volatile AOCTRL1 AoCtrl1;    
        AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;

        AoCtrl1.bit.Ao_Rdbk_Mux_en=1;
        (* (P_AO_CTRL1_REG)).all=AoCtrl1.all;
    }
    AOLPBKSTS DoLoopbackTest(UINT16 a_uiDacCount );
    inline VOID  DecrSkipLpBkTst(VOID){ucSkipLpBkTst--;}
    inline UINT8 GetSkipLpBkTst(VOID){return ucSkipLpBkTst;}
    inline VOID  ResetSkipLpBkTst(UINT8 ucTemp){ucSkipLpBkTst =ucTemp;}
    //       

    //Get and Set Methods for the memeber variables
    inline FLOAT32 GetOpInternl(VOID)        { return OpInternl;  }
    inline VOID SetOpInternal(FLOAT32 a_fOp) { OpInternl = a_fOp; }    
    inline FAULTSTATE GetFaultState(VOID)    { return FaultState; }
    inline VOID ResetFaultState(VOID)        { FaultState = FAULTSTATE_NORMAL; }
    inline BOOL GetReadBackrequired(VOID){ return bReadBackrequired;}
    inline VOID SetReadBackrequired(BOOL bReadBksts){bReadBackrequired = bReadBksts; };
    inline VOID SetB0O(FLOAT32 a_fVal)   { B0_O    = a_fVal; }
    inline VOID SetB1O(FLOAT32 a_fVal)   { B1_O    = a_fVal; }
    inline VOID SetB0L(FLOAT32 a_fVal)   { B0_L    = a_fVal;}
    inline VOID SetB1L(FLOAT32 a_fVal)   { B1_L    = a_fVal;}
    inline VOID SetB0Inv(FLOAT32 a_fVal) { B0_Inv  = a_fVal; }
    inline VOID SetB1Inv(FLOAT32 a_fVal) { B1_Inv  = a_fVal; }
    inline VOID SetB0LInv(FLOAT32 a_fVal){ B0_LInv = a_fVal;}
    inline VOID SetB1LInv(FLOAT32 a_fVal){ B1_LInv = a_fVal;}
    inline FLOAT32 GetB1L(VOID)   { return B1_L;}
    inline FLOAT32 GetB0L(VOID)   { return B0_L;}
    //

    //Helper Methods
    inline BOOL IsChnlConfig(VOID){ return (PntType != PNTTYPE_NOTCONFIGURED);}
    BOOL IsOpConnected()   { return (OpConn != 0); }
    //

    //Redundacny Dump Related Struct and Methods
    #pragma pack 2
    typedef struct strSpAoSyncRec
    {
        UINT16      Header;     // The first two bytes of dump record should always represent version. Do not change this. 
        UINT8       PntType;
        UINT8       PtExecSt;
        UINT8       FaultState;
        UINT8       FaultOpt;
        UINT8       Mode;
        UINT8       ModeAttr;
        UINT8       ModePerm;
        UINT8       NMode;
        UINT8       NModeAttr;
        UINT8       RedTag;
        UINT8       OptDir;
        UINT8       LocalMan;
        UINT8       OpChar;
        UINT8       StdbyMan;
        UINT8       InitReq;
        UINT8       ucSkipLpBkTst;
        FLOAT32     FaultValue;
        FLOAT32     OpLoLimitVal;
        FLOAT32     OpHiLimitVal;
        FLOAT32     OpIn0;
        FLOAT32     OpIn1;
        FLOAT32     OpIn2;
        FLOAT32     OpIn3;
        FLOAT32     OpIn4;
        FLOAT32     OpIn5;
        FLOAT32     OpOut0;
        FLOAT32     OpOut1;
        FLOAT32     OpOut2;
        FLOAT32     OpOut3;
        FLOAT32     OpOut4;
        FLOAT32     OpOut5;
        FLOAT32     Chrc_S0;
        FLOAT32     Chrc_S1;
        FLOAT32     Chrc_S2;
        FLOAT32     Chrc_S3;
        FLOAT32     Chrc_S4;
        FLOAT32     OpInternal;
        FLOAT32     Op;
        UINT8       bReadBackrequired;
        INT32      OpConn;
    } SYNCRECORD,*PSYNCRECORD;
    #pragma unpack
    inline UINT32 GetRedSlotSize(VOID) { return sizeof(SYNCRECORD); }
    PASTATUS GetDumpData(UINT8* const pDump,const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    inline UINT32 GetRedSlotDelta(VOID) {return 0;}        
    inline UINT8 *GetRedSlotPointer(VOID) {
        return NULL;
    }
    //
};

#ifndef MAX_DUMP_SIZE
#define MAX_DUMP_SIZE 240
#endif
_CompileAssert(sizeof(clsTcSpAoSlot::SYNCRECORD) <= MAX_DUMP_SIZE)

#endif  //__TCSPAOSLOT_HPP__
