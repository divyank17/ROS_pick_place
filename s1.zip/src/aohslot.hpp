/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohslot.hpp                                                 *
*    Description : Class clsAohSlot declaration.                               *
*******************************************************************************/
#ifndef __AOHSLOT_HPP__
#define __AOHSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "outslot.hpp"

#if !defined(IOMTYPE_UIO)
    #include "hartdb.hpp"
    #include "aohardware.hpp"
#endif

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define AOHSLOT_SIZE ((sizeof(clsAohSlot) + (sizeof(clsAohSlot) % 2)) / 2)
// IOL Parameter number definitions
#if !defined(IOMTYPE_UIO)
#define PARAMID_LOCALMAN     52
#define PARAMID_MODATTR      53
#define PARAMID_MODE         54
#define PARAMID_MODEPERM     56
#define PARAMID_NMODATTR     57
#define PARAMID_NMODE        58
#define PARAMID_OP           59
#define PARAMID_OPCHAR       60
#define PARAMID_OPIN0        62
#define PARAMID_OPIN1        63
#define PARAMID_OPIN2        64
#define PARAMID_OPIN3        65
#define PARAMID_OPIN4        66
#define PARAMID_OPOUT0       68
#define PARAMID_OPOUT1       69
#define PARAMID_OPOUT2       70
#define PARAMID_OPOUT3       71
#define PARAMID_OPOUT4       72
#define PARAMID_OPTDIR       74
#define PARAMID_PNTTYPE      76
#define PARAMID_PTEXECST     77
#define PARAMID_REDTAG       80
#define PARAMID_RINITREQ     81
#define PARAMID_STDBYMAN     84
#define PARAMID_INITREQ      88
#define PARAMID_FAULTOPT    125
#define PARAMID_FAULTVALUE  127
#define PARAMID_OPINTERNAL  238
#define PARAMID_CHRC_S0     246
#define PARAMID_CHRC_S1     247
#define PARAMID_CHRC_S2     248
#define PARAMID_CHRC_S3     249
#define PARAMID_CHRC_S4     250
#define PARAMIDOTPT_UNUSED  251

#if defined(IOPTYPE_AO16)
// PMIO AO16 Redesign non avail param id
#define PARAMID_FL_UNPWRD    51
#define PARAMID_MODEAPPL     55
#define PARAMID_OPREAL       59
#define PARAMID_OPIN5        67
#define PARAMID_OPOUT5       73
#define PARAMID_PNTFORM      75
#define PARAMID_RCSAOPT      78
#define PARAMID_CSCD_RQSTD   79
#define PARAMID_PTEXECSTLRS  245
#endif

#endif

const FLOAT32 EXTENDED_OP_LOLIMIT   = -25.0;
const FLOAT32 OP_LOLIMIT            = -6.9;
const FLOAT32 OP_HILIMIT            = 106.9;
#if !LOWCOST
const FLOAT32 EXTENDED_OP_HILIMIT   = 131.187;
#else // For LowCost Extended High Limit will be 125
const FLOAT32 EXTENDED_OP_HILIMIT   = 125.0;
#endif
const UINT8   AOHSLOT_SPARESIZE     = 16;
const UINT8   PASSCOUNTMAX          = 6;       // 200ms Delay
const UINT8   PASSCOUNTMIN          = 1;       // must be >= 1
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsAohSlot; // forward declaration
typedef struct tagAoSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsAohSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsAohSlot::* PostPtr)(UINT8);
    VOID *   (clsAohSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} AO_SLOTPARAMINFO;

typedef enum tagAoLpbkSts {
    AOLPBK_PASSED,
    AOLPBK_HITESTFAIL,
    AOLPBK_LOTESTFAIL
} AOLPBKSTS;

#if defined(IOPTYPE_AO16)
// PMIO AO16 Redesign non avail params typedefs
typedef enum tagFl_UnPwrd {
    FL_UNPWRD_HOLD = 0,
    FL_UNPWRD_UNPOWER = 1
} FL_UNPWRD;
typedef enum tagRCasOpt {
    NONE_RCASOPT = 0,
    SPC_RCASOPT = 1,
    DDC_RCASOPT = 2,
    RSP_RCASOPT = 3,
    DDCRSP_RCASOPT = 4
} RCASOPT;
#endif

/*******************************************************************************
*                                   clsAohSlot                                 *
*                                   ==========                                 *
*******************************************************************************/
class clsAohSlot : public clsOutSlot {
protected:
    UINT8 AohSlotSpare[AOHSLOT_SPARESIZE];
    clsHartCfgDb HartCfgDb; 

    BOOL        OpChar;
#if !defined(IOMTYPE_UIO)
    BOOL        OTPT_Unused;
#endif
    FLOAT32     OpIn0;
    FLOAT32     OpIn1;
    FLOAT32     OpIn2;
    FLOAT32     OpIn3;
    FLOAT32     OpIn4;
    FLOAT32     OpIn5;
    FLOAT32     OpOut0;
    FLOAT32     OpOut1;
    FLOAT32     OpOut2;
    FLOAT32     OpOut3;
    FLOAT32     OpOut4;
    FLOAT32     OpOut5;

    FLOAT32     Chrc_S0;
    FLOAT32     Chrc_S1;
    FLOAT32     Chrc_S2;
    FLOAT32     Chrc_S3;
    FLOAT32     Chrc_S4;

    FLOAT32     OpInternl;

    clsHartCfgDb7 HartCfgDb7; 
    // !!!*** AO_SLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the AO slot's redundant synch data area.
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedSlotSize() must be updated to
    // reference the new end member. This dump record begins in clsIoSlot.
    
    FLOAT32     B0_LInv;
    FLOAT32     B1_LInv;
    FLOAT32     B0_Inv;
    FLOAT32     B1_Inv;
   
    FLOAT32     B0_L;
    FLOAT32     B1_L;
    FLOAT32     B0_O;
    FLOAT32     B1_O;
    
    FLOAT32     OpFinal;
    UINT16      OutDACImg;
    UINT16      LoopBackDACImg;
    AOLPBKSTS   LoopBackStatus;

    UINT8       ucPassCount;
    UINT8       ucSkipLpBkTst;
    BOOL        bReadBackrequired;

    clsHartDevDb HartDevDb;

#if defined(IOMTYPE_UIO)
    UINT8       ucAoReadBackFailCount;
    UINT8       ucAoDacFailCount;
    
    // Don't sync OTPT_Unused.  UIO needs to prevent
    // read back diagnostics from running until the slot
    // can contribute current.
    BOOL        OTPT_Unused;
#endif

#if defined (IOPTYPE_AO16)
    // PMIO AO16 Redesign non avail params defs
    //FL_UNPWRD Fl_UnPwrd;
    UINT8     ModeAppl[4];
    RCASOPT   RCasOpt;
    BOOL      Cscd_Rqstd;
    BOOL      RInitReq;
    UINT8     SlotCfgd;
    static const UINT8 PmioDumpParamTbl[];
    static const UINT8 PmioHartDumpParamTbl[];
#endif

    static const UINT8 AosData[];
    static const UINT8 SecData[];
    static const UINT8 CheckPointVer1[];
    static const UINT8 CheckPointVer2[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const AO_SLOTPARAMINFO tblParamInfo[];
#if defined(IOMTYPE_UIO)
    static UINT8 AoSlotChkpntVersion;
#endif

    PASTATUS ClampWithWarning(VOID *,UINT8 );
    PASTATUS ChrcPntBnds(FLOAT32 *,FLOAT32,UINT8);
    FLOAT32  ChrcFrwrd(FLOAT32 );
    VOID     InitAohSlot(BOOL , BOOL);
    UINT16   ConvFloatValtoDACCntVal(FLOAT32,BOOL);
    FLOAT32  ConvOpDACCntValtoFloatVal(VOID);
    UINT16   GetInternalReading();

#if defined(IOMTYPE_UIO)
    PASTATUS PreInitPntType(UINT8 *writebuffer, UINT8);
#endif

    PASTATUS PrePntType(UINT8 *, UINT8);
    VOID     PostPntType(UINT8);

    PASTATUS PrePtExecSt(UINT8 *,UINT8);
    VOID     PostPtExecSt(UINT8);

    PASTATUS PreOp(UINT8 *,UINT8);
    
    VOID     PostOpChar(UINT8);

    PASTATUS PreMode(UINT8 *,UINT8);
    VOID     PostMode(UINT8);
    
    PASTATUS PreNMode(UINT8 *,UINT8);

    PASTATUS PreNModeAttr(UINT8 *,UINT8);
    VOID     PostNModeAttr(UINT8);
    
    PASTATUS PreModeAttr(UINT8 *,UINT8);

    PASTATUS PreModePerm(UINT8 *,UINT8);
    
    PASTATUS PreFaultState(UINT8 *, UINT8);
    VOID     PostFaultState(UINT8);
    
    PASTATUS PreFaultValue(UINT8 *, UINT8);
    
    PASTATUS PreFaultOpt(UINT8 *, UINT8);   
    VOID     PostFaultOpt(UINT8);

    PASTATUS PreRedTag(UINT8 *,UINT8);
    
    PASTATUS PreOpIn1(UINT8 *, UINT8); 
    PASTATUS PreOpIn2(UINT8 *, UINT8); 
    PASTATUS PreOpIn3(UINT8 *, UINT8); 
    PASTATUS PreOpIn4(UINT8 *, UINT8);

    PASTATUS PreOpOut1(UINT8 *, UINT8);
    PASTATUS PreOpOut2(UINT8 *, UINT8);
    PASTATUS PreOpOut3(UINT8 *, UINT8);
    PASTATUS PreOpOut4(UINT8 *, UINT8);

    VOID     PostOptDir(UINT8);

    PASTATUS PreCommand(UINT8 *,UINT8);
    VOID     PostCommand(UINT8);
    PASTATUS PreHEnable(UINT8 *,UINT8);
    PASTATUS PreHAlarmEnable(UINT8 *,UINT8);
    VOID     PostHAlarmEnable(UINT8);
    PASTATUS PreHScanCfg(UINT8 *,UINT8);
    VOID     PostHScanCfg(UINT8);
    PASTATUS PreHComThrs(UINT8 *,UINT8);
    PASTATUS PreHComHys(UINT8 *,UINT8);
    VOID     PostHDevIdCd(UINT8);
    PASTATUS PreHDvMfgCd(UINT8 *,UINT8);
    PASTATUS PreHDvTypCd(UINT8 *,UINT8);
    PASTATUS PreHDvMfgCd7(UINT8 *,UINT8);
    PASTATUS PreHDvTypCd7(UINT8 *,UINT8);
    PASTATUS PreHDvRevCd(UINT8 *,UINT8);
    PASTATUS PreHDdRevCd(UINT8 *,UINT8);

#if defined(IOMTYPE_UIO)
    // CFGRESTORE must only be written to the clsUioSlot, this pre-function ensures this is true
    PASTATUS PreCfgRestore(UINT8 *, UINT8) { return DO_PARAMETER_INVALID; }
#endif

    inline VOID *GetOpCharPtr(VOID)     { return &OpChar; }
    inline VOID *GetOpFinalPtr(VOID)    { return &OpFinal; }
    inline VOID *GetOpIn0Ptr(VOID)      { return &OpIn0; }
    inline VOID *GetOpIn1Ptr(VOID)      { return &OpIn1; }
    inline VOID *GetOpIn2Ptr(VOID)      { return &OpIn2; }
    inline VOID *GetOpIn3Ptr(VOID)      { return &OpIn3; }
    inline VOID *GetOpIn4Ptr(VOID)      { return &OpIn4; }
    inline VOID *GetOpIn5Ptr(VOID)      { return &OpIn5; }
    inline VOID *GetOpOut0Ptr(VOID)     { return &OpOut0; }
    inline VOID *GetOpOut1Ptr(VOID)     { return &OpOut1; }
    inline VOID *GetOpOut2Ptr(VOID)     { return &OpOut2; }
    inline VOID *GetOpOut3Ptr(VOID)     { return &OpOut3; }
    inline VOID *GetOpOut4Ptr(VOID)     { return &OpOut4; }
    inline VOID *GetOpOut5Ptr(VOID)     { return &OpOut5; }
    inline VOID *GetOpInternalPtr(VOID) { return &OpInternl; }
    inline VOID *GetOTPT_UnusedPtr(VOID){ return &OTPT_Unused; }
    inline VOID *GetAosDataPtr(VOID)    { return (VOID *)AosData; }
#if defined(IOMTYPE_UIO)    
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[AoSlotChkpntVersion-1].CheckPointPtr; }
#else
    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[SlotChkpntVersion-1].CheckPointPtr; }
#endif
    //Redundancy related param
    inline VOID *GetRedParamsPtr(VOID)  { return (VOID *)RedParams; }
    inline VOID *GetSecDataPtr(VOID)    { return (VOID *)SecData; }
    inline VOID *GetB0_LPtr(VOID)       { return &B0_L; }
    inline VOID *GetB1_LPtr(VOID)       { return &B1_L; }
    inline VOID *GetB0_OPtr(VOID)       { return &B0_O; }
    inline VOID *GetB1_OPtr(VOID)       { return &B1_O; }
    inline VOID *GetB0_LInvPtr(VOID)    { return &B0_LInv; }
    inline VOID *GetB1_LInvPtr(VOID)    { return &B1_LInv; }
    inline VOID *GetB0_InvPtr(VOID)     { return &B0_Inv;  }
    inline VOID *GetB1_InvPtr(VOID)     { return &B1_Inv;  }
    inline VOID *GetChrc_S0Ptr(VOID)    { return &Chrc_S0; }
    inline VOID *GetChrc_S1Ptr(VOID)    { return &Chrc_S1; }
    inline VOID *GetChrc_S2Ptr(VOID)    { return &Chrc_S2; }
    inline VOID *GetChrc_S3Ptr(VOID)    { return &Chrc_S3; }
    inline VOID *GetChrc_S4Ptr(VOID)    { return &Chrc_S4; }
    inline VOID *GetOutputDACImgptr(VOID) { return &OutDACImg; }
    
    inline VOID *GetCommandPtr(VOID)    { return &HartDevDb.Command; }
    inline VOID *GetHDevCdPtr(VOID)     { return (VOID *)HartCfgDb.HDevCd; }
    inline VOID *GetHAlarmEnablePtr(VOID) { return &HartCfgDb.HAlarmEnable; }
    inline VOID *GetHEnablePtr(VOID)    { return &HartCfgDb.HEnable; }
    inline VOID *GetHScanCfgPtr(VOID)   { return &HartCfgDb.HScanCfg; }
    inline VOID *GetHDynRatePtr(VOID)   { return &HartDevDb.HDynRate; }
    inline VOID *GetHDevRatePtr(VOID)   { return &HartDevDb.HDevRate; }
    inline VOID *GetHSlotDvcPtr(VOID)   { return HartCfgDb7.HSlotDvc7; }
    inline VOID *GetHSlotDvcPtr7(VOID)  { return &HartCfgDb7.HSlotDvc7[4];}
    inline VOID *GetHComThrsPtr(VOID)   { return &HartCfgDb.HComThrs; }
    inline VOID *GetHComHysPtr(VOID)    { return &HartCfgDb.HComHys; }
    inline VOID *GetHComStsPtr(VOID)    { return &HartDevDb.HComSts; }
    inline VOID *GetHNComErrPtr(VOID)   { return &HartDevDb.HNComErr; }
    inline VOID *GetHLComFailPtr(VOID)  { return &HartDevDb.HLComFail; }
    inline VOID *GetH7Cmd0Ptr(VOID)     { return &HartDevDb.HCmd0.ucBytes[HART6_CMD0_RESPONSE_SIZE]; }
    inline VOID *GetHCmd0Ptr(VOID)      { return &HartDevDb.HCmd0; }
    inline VOID *GetHCmd12Ptr(VOID)     { return &HartDevDb.HCmd12; }
    inline VOID *GetHCmd13Ptr(VOID)     { return &HartDevDb.HCmd13; }
    inline VOID *GetHCmd14Ptr(VOID)     { return &HartDevDb.HCmd14; }
    inline VOID *GetHCmd15Ptr(VOID)     { return &HartDevDb.HCmd15; }
    inline VOID *GetHCmd16Ptr(VOID)     { return &HartDevDb.HCmd16; }
    inline VOID *GetHLongTagPtr(VOID)   { return &HartDevDb.HLongTag; }
    inline VOID *GetHDynValPtr(VOID)    { return HartDevDb.HDynVal; }
    inline VOID *GetHDynStPtr(VOID)     { return HartDevDb.HDynSt; }
    inline VOID *GetHDynCcPtr(VOID)     { return HartDevDb.HDynCc; }
    inline VOID *GetHDynEuPtr(VOID)     { return HartDevDb.HDynEu; }
    inline VOID *GetHSlot0TSPtr(VOID)   { return &HartDevDb.HDevSlot0DTS;}
    inline VOID *GetHSlotValPtr(VOID)   { return HartDevDb.HSlotVal; }
    inline VOID *GetHSlotStPtr(VOID)    { return HartDevDb.HSlotSt; }
    inline VOID *GetHSlotCcPtr(VOID)    { return HartDevDb.HSlotCc; }
    inline VOID *GetHSlotEuPtr(VOID)    { return HartDevDb.HSlotEu; }
    inline VOID *GetHDevStPtr(VOID)     { return HartDevDb.HDevSt; }
    inline VOID *GetHCmd48Ptr(VOID)     { return &HartDevDb.HCmd48; }
    inline VOID *GetHCmdFailPtr(VOID)   { return &HartDevDb.HCmdFail; }
    inline VOID *GetHCmdRespPtr(VOID)   { return &HartDevDb.HCmdResp; }
    inline VOID *GetHDvMfgCdPtr(VOID)   { return &HartCfgDb.HDvMfgCd; }
    inline VOID *GetHDvMfgCd7Ptr(VOID)  { return HartCfgDb7.HDvMfgCd7;}
    inline VOID *GetHDevIdCdPtr(VOID)   { return HartCfgDb.HDevIdCd; }
    inline VOID *GetHDvTypCdPtr(VOID)   { return &HartCfgDb.HDvTypCd; }
    inline VOID *GetHDvTypCd7Ptr(VOID)  { return HartCfgDb7.HDvTypCd7; }
    inline VOID *GetHDvRevCdPtr(VOID)   { return &HartCfgDb.HDvRevCd; }
    inline VOID *GetHDdRevCdPtr(VOID)   { return &HartCfgDb.HDdRevCd; }
    inline VOID *GetHNtfyCfgPtr(VOID)   { return HartCfgDb.HNtfyCfg; }
    inline VOID *GetHDynDvcPtr(VOID)    { return HartDevDb.HDynDvc; }
    inline VOID *GetHartVersionPtr(VOID){ return &HartDevDb.m_ucHartVersion; }

    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }


#if defined (IOPTYPE_AO16)    
    // PMIO AO16 Redesign non avail params method defs and inlines.
    PASTATUS PreRCasOpt(UINT8 *, UINT8);
    PASTATUS PreCscd_Rqstd(UINT8 *, UINT8);

    VOID PostPntForm(UINT8);       
    VOID PostRCasOpt(UINT8);
    //VOID PostFl_UnPwrd(UINT8);
    
    inline VOID *GetModeApplPtr(VOID)   { return (VOID *)ModeAppl; }
    inline VOID *GetRCasOptPtr(VOID)    { return &RCasOpt;  }
    inline VOID *GetCscd_RqstdPtr(VOID) { return &Cscd_Rqstd; }
    inline VOID *GetRInitReqPtr(VOID)   { return &RInitReq; }
#endif

#if defined(IOMTYPE_UIO)
    inline PASTATUS PreCheckPoint(UINT8 *,UINT8) { 
      AoSlotChkpntVersion = LATEST_UIO_AO_SLTCHKPNT_VERSION;
      return PA_OK; 
    }
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &AoSlotChkpntVersion;}
#endif

    //For Returning the pointer to OP Scan record 
    VOID *GetInitReqPtr(VOID);
    VOID *GetStdbyManPtr(VOID);
    VOID *GetOpPtr(VOID);
 
#if !defined(IOPTYPE_AO16)
    // Accessing it as public method in PMIO AO16 Redesign 
    UINT8    *GetParamPtr(UINT8);
#endif

    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsAohSlot(const clsAohSlot&); // Safeguard against default copy constructor
    clsAohSlot& operator=(const clsAohSlot&); // and defualt assignement.

public:
    clsAohSlot(UINT8);
    ~clsAohSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AOHSLOT_HPP,__LINE__); }
     
    VOID *operator new(UINT32, UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AOHSLOT_HPP,__LINE__); } 

    DATATYPE    GetDataType(UINT8);
    ACCESSTYPE  GetAccessType(UINT8);
    UINT8       GetParamSize(UINT8);
    ACCESSLOCK  GetAccessLock(UINT8);
    BOOL        GetIsDbChecksumed(UINT8);
    PASTATUS    VerifyControlState(UINT8);

    VOID     InitSlot(BOOL );
    VOID  InactivateSlot(VOID);
    VOID  CmptInitReq(VOID);
    VOID  UpdateOpFinal(FLOAT32);
    VOID  SlotFaultHandler(TOG_FAILED);
    FLOAT32  ChrcBkwrd(FLOAT32 );
    VOID     PostHEnable(UINT8);

#if !defined(IOMTYPE_UIO)
    AOLPBKSTS DoLoopbackTest(UINT16 a_uiDacCount = FOUR_PRECENT_LOOPBACK_DACCOUNT);
    BOOL  ComputeCalibrationConstants(FLOAT32,FLOAT32);
#endif

    inline BOOL RegenChannelEvents(VOID) { return HartDevDb.ProcessHartEvents(TRUE); }

    VOID     PostOp(UINT8);

    inline UINT32 GetRedSlotDelta(VOID) {return 0;}

#if defined(IOPTYPE_AO16)
    inline VOID  *GetSlotCfgdPtr(VOID)        { return &SlotCfgd; }
    inline UINT32 GetRedSlotSize(VOID)        { return PMIO_SLOTDUMP_PARAMSIZE; }
    inline UINT32 GetRedHartSlotSize(VOID)    { return PMIO_HARTDUMP_PARAMSIZE; }
    inline UINT8 *GetRedSlotPointer(VOID)     { return (UINT8 *)PmioDumpParamTbl; }
    inline UINT8 *GetRedHartSlotPointer(VOID) { return (UINT8 *)PmioHartDumpParamTbl; }
#else
    inline UINT32 GetRedSlotSize(VOID) {
        return ((UINT32)((UINT8 *)&HartCfgDb7 - (UINT8 *)&PntType) + sizeof(HartCfgDb7));
    }
        
    inline UINT8 *GetRedSlotPointer(VOID) {
        return (UINT8 *)&PntType;
    }
#endif
    
    VOID     BackInit(VOID);
    inline FLOAT32 GetOpFinal(VOID) { return OpFinal; }
    inline BOOL GetOpChar(VOID) { return OpChar; }
    inline OPTDIR GetOptDir(VOID) { return OptDir; }
    inline VOID SetModeVal(MODE a_eNewMode) { Mode = a_eNewMode ;}

    inline FLOAT32 GetB0O(VOID)   { return B0_O;}
    inline FLOAT32 GetB1O(VOID)   { return B1_O;}
    inline FLOAT32 GetB0L(VOID)   { return B0_L;}
    inline FLOAT32 GetB1L(VOID)   { return B1_L;}
    inline FLOAT32 GetB0Inv(VOID) { return B0_Inv; }
    inline FLOAT32 GetB1Inv(VOID) { return B1_Inv; }
    inline FLOAT32 GetB0LInv(VOID){ return B0_LInv;}
    inline FLOAT32 GetB1LInv(VOID){ return B1_LInv;}

    inline BOOL GetOTPT_Unused(VOID){ return OTPT_Unused; }
    
#if defined(IOMTYPE_UIO)
    inline VOID SetOTPT_Unused(BOOL unused) {OTPT_Unused = unused; }
#endif

    inline VOID SetB0O(FLOAT32 a_fVal)   { B0_O    = a_fVal; }
    inline VOID SetB1O(FLOAT32 a_fVal)   { B1_O    = a_fVal; }
    inline VOID SetB0L(FLOAT32 a_fVal)   { B0_L    = a_fVal;}
    inline VOID SetB1L(FLOAT32 a_fVal)   { B1_L    = a_fVal;}
    inline VOID SetB0Inv(FLOAT32 a_fVal) { B0_Inv  = a_fVal; }
    inline VOID SetB1Inv(FLOAT32 a_fVal) { B1_Inv  = a_fVal; }
    inline VOID SetB0LInv(FLOAT32 a_fVal){ B0_LInv = a_fVal;}
    inline VOID SetB1LInv(FLOAT32 a_fVal){ B1_LInv = a_fVal;}

    inline FLOAT32 GetOpInternl(VOID) { return OpInternl; }
    inline VOID SetOpInternl(FLOAT32 a_fOp) { OpInternl = a_fOp; }
    inline UINT16 GetOutDACImg(VOID) { return OutDACImg; }
    inline UINT16 GetLoopBackDACImg(VOID) { return LoopBackDACImg; }
    inline AOLPBKSTS GetLoopBackStatus(VOID) { return LoopBackStatus; }

    inline VOID SetOutDACImg(UINT16 a_uiVal) { OutDACImg = a_uiVal; }

    inline VOID ResetFaultState(VOID) { FaultState = FAULTSTATE_NORMAL; }

    // HART stack interface functions
    inline UINT8 GetChannelNumber(VOID) { return ChanNum; }
    inline HCHANTYPE GetHartChanType(VOID) { return HartDevDb.m_HChanType; }
    inline UINT8 GetPollingAddress(VOID) { return HartDevDb.m_ucPollingAddress; }
    inline VOID SetPollingAddress(UINT8 a_ucAddr) { HartDevDb.m_ucPollingAddress = a_ucAddr; }
    inline HARTUNIQUEADDR GetUniqueAddress(VOID) { return HartDevDb.m_UniqueAddress; }
    inline UINT8 GetNoOfPreambleBytes(VOID) { return HartDevDb.m_ucReqdPreambles; }
    inline const UINT8 * GetXmtDataPtr(VOID) { return HartDevDb.m_ucpLastXmtPtr; }
#if defined(IOMTYPE_UIO)
    inline const UINT8 * GetPstXmtDataPtr(VOID) { return HartDevDb.m_ucpLastPstXmtPtr;}
#endif

    inline HSYNCSTATUS ReceptionComplete(HMSGSTATUS a_HartMsgSts) { 
        return HartDevDb.ReceptionComplete(a_HartMsgSts); 
    }

    inline VOID LogEvent(HEVENTTYPE a_HartEventType) { 
        return HartDevDb.LogEvent(a_HartEventType); 
    }

    inline UINT8 GetRetryCount(VOID) {
        UINT8 ucReturn = HART_MAX_RETRIES;
        if (FALSE == HartCfgDb.HEnable) {
            ucReturn = HART_AUTODISCOVERY_RETRYCOUNT;
        }
        return ucReturn;
    }

    clsClientBuffer& GetRcvBufObject(VOID);

    inline clsHartCfgDb& GetHartCfgDb(VOID) { return HartCfgDb; }
    inline clsHartDevDb& GetHartDevDb(VOID) { return HartDevDb; }

    inline BOOL GetReadBackrequired(VOID){ return bReadBackrequired;}
    inline VOID SetReadBackrequired(BOOL bReadBksts){ bReadBackrequired = bReadBksts ;}
    BOOL IsOutputNotViable(UINT8 ucParamId);
    inline BOOL GetHEnable(VOID) { return HartCfgDb.HEnable; }
    inline VOID SetHEnable(BOOL a_bEnable) {HartCfgDb.HEnable = a_bEnable;}
    
#if !defined(IOMTYPE_UIO)
    VOID Hart7Dump (VOID);
#endif
    inline VOID DecrSkipLpBkTst(VOID){ucSkipLpBkTst--;}
    inline UINT8 GetSkipLpBkTst(VOID){return ucSkipLpBkTst;}
    inline VOID ResetSkipLpBkTst(UINT8 ucTemp){ucSkipLpBkTst =ucTemp;}



#if defined(IOMTYPE_UIO)
    AOLPBKSTS DoReadBackTest(UINT16 a_uiAdcCount);
    virtual UINT8 GetSlotChkPntParamId(VOID);   
    virtual UINT8 GetLatestSlotChkPntVersion(VOID);
    virtual UINT8 GetPtExecStParamId(VOID);
    inline VOID ResetAoReadBackFailCount(VOID){ucAoReadBackFailCount = 0;}
    inline UINT8 GetAoReadBackFailCount(VOID){return ucAoReadBackFailCount;}
    inline VOID IncAoReadBackFailCount(VOID){ucAoReadBackFailCount++;}
    inline VOID ResetAoDacFailCount(VOID) {ucAoDacFailCount = 0;}
    inline UINT8 GetAoDacFailCount(VOID) {return ucAoDacFailCount;}
    inline VOID IncAoDacFailCount(VOID) {ucAoDacFailCount++;}
#endif

    VOID ResetLpBkPassCount(VOID);

#if defined(IOPTYPE_AO16)
    // PMIO AO16 Redesign inlines
    UINT8   *GetParamPtr(UINT8);    
    inline VOID *GetFl_UnPwrdPtr(VOID)            { return &FaultOpt; } //since GetFaultOptPtr() is inaccessible
    inline VOID *GetPmioDumpParamPtr(VOID)        { return (VOID *)PmioDumpParamTbl; }
    inline VOID *GetPmioHartDumpParamPtr(VOID)    { return (VOID *)PmioHartDumpParamTbl; }

    inline UINT8 IsCheckPointParam(UINT8 ucParamId)
    {
        UINT8 ucArrayIndex = 0;
        UINT8 ucChkPntIndex = 0;

        while (CheckPointVer2[ucArrayIndex])
        {
            if (CheckPointVer2[ucArrayIndex] == ucParamId)
                return (ucChkPntIndex + 1);
            else
                ucChkPntIndex += GetParamSize(CheckPointVer2[ucArrayIndex]);

            ucArrayIndex++;
        }

        return PA_NULL;
    }
#endif

};

#endif
