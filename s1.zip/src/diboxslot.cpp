/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : diboxslot.cpp                                               *
*    Description : Class clsclsDiBoxSlot definition.                           *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "tracelog.hpp"
#include "diboxslot.hpp"
#ifdef DEBUG
#include "debug.hpp"
#endif
/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/
extern clsIol Iol;
#ifdef IOMTYPE_DISOE
extern "C" BOOL _SolveState(STMCHINPTBUFF  * ptrSOEstate , BOOL  * bLogEventFlag);

#pragma section EVTLOG_SECTION
// The PVCLEvtRegLog has been allocated in specific section to enable flash operations.
// Flash operations need 4k of space from location 0xfffdc. To ensure that no 
// working data is ovewritten during flash operation, EVTLOG section was created 
// and only PVCLEvtRegLog has been allocated in this section. 
PVCLEVTRECORD       PVCLEvtRegLog[PVCLEVTREG_SIZE];
SOEISRBUFF          SOEISRBuffer[SOEISRBUFSIZE];
UINT8  SoeIsrBufAppPtr;
UINT8  SoeIsrBufRemPtr;
#pragma section

#endif
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_DIAGCTFL,
    SF_OPENWIRE,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_INPTFAIL
};

const UINT8 clsDiBoxSlot::PvStAll[] = {
    PARAMID_PVALL,
    PARAMID_BADPVALL,
    0 // Terminator
};

const UINT8 clsDiBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_FREQ6050,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
#ifdef IOMTYPE_DISOE
    PARAMID_DIMODE,
#endif
    0 // Terminator
};

#ifdef IOMTYPE_DISOE
const CHECKPOINT_VER_TABLE clsDiBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 5 }
};
#endif

#ifdef IOMTYPE_DI

#if !defined(IOPTYPE_DI)

const UINT8 clsDiBoxSlot::CheckPointVer2[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_FREQ6050,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    PARAMID_DIMODE,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsDiBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 4 },
    { CheckPointVer2, 5 }
};

#else

const UINT8 clsDiBoxSlot::CheckPointVer2[] = {
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,    
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsDiBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 4 },
    { CheckPointVer2, 2 }
};

const UINT8 clsDiBoxSlot::PvStAlm[] = {
    PARAMID_PVALL,
    PARAMID_BADPVALL,
    PARAMID_ALMALL,
    0 // Terminator
};

// PMIO HLAI BOX DUMP PARAM
const UINT8  clsDiBoxSlot::PmioDumpParamTbl[] = {
    PARAMID_MOD_STAT1,
    PARAMID_DBVALID,
    PARAMID_NROFDIS,
    PARAMID_PVALL,
    0 // Terminator        // size 1 8
};

#if defined(DIGTYPE_DI24)
const UINT8 clsBoxSlot::IopDesc[] = "DI 24V  ";
#else
const UINT8 clsBoxSlot::IopDesc[] = "DI w/COS";
#endif

#endif // #if !defined(IOPTYPE_DI)

#endif //#ifdef IOMTYPE_DI

UINT8 clsDiBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

const UINT8 clsDiBoxSlot::RedParams[] = {
    PARAMID_SFACTNTBL,
    PARAMID_DBVALID,
    PARAMID_IOLDEVTYPE,
    PARAMID_MODLTYPE,
#if !defined(IOPTYPE_DI)
    PARAMID_MAXSLOTS,
    PARAMID_DIMODE,
#else
    PARAMID_NROFDIS,
#endif
    0 // Terminator
};

volatile UINT8 *clsDiBoxSlot::pInputPorts[4] = { 
    &P_PB.PORT.BYTE, &P_PC.PORT.BYTE, &P_PD.PORT.BYTE, &P_PE.PORT.BYTE 
};

const BOXPARAMINFO clsDiBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      // 35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   // 37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          // 38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          // 39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          // 40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          // 41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          // 43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      // 44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    // 45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           // 47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       // 48 AppBuildNo
#if defined(IOPTYPE_DI)
    DT_BLIND, 22, AT_PSET, ALCK_VIEW, 0, 0, GetIomDtlPtr, FALSE,                    // 49 IOMDTL
    DT_BLIND, 10, AT_PSET, ALCK_VIEW, 0, 0, GetIolSupPtr, FALSE,                    // 50 IOL_SUP
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, 0, 0, GetPmBxSfBitsPtr, FALSE,               // 51 BxSfBits - for redesign PMIO DI
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 50
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       // 51 BoxSfBits
#endif
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        // 52 BoxSfLrs
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       // 53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          // 54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         // 55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              // 56 DpaExt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              // 57 DsaExt
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      // 58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      // 59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               // 60 BaExt
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                // 61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         // 62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        // 63 HwRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,TRUE,                        // 64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          // 65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            // 66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,PreModStat1,PostModStat1,GetModStat1Ptr,TRUE,    // 67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         // 68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,TRUE,                           // 69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              // 70 NthExt
#if defined(IOPTYPE_DI)
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetSuperCtrlPtr, FALSE,                 // 71 SUPER_CTRL        
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 71
#endif
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     // 72 SwRevCode
#if defined(IOPTYPE_DI)
    DT_UINT16, 2, AT_MBYTE, ALCK_IUSER, 0, 0, GetToknStallPtr, FALSE,               // 73 TOKN_STALL
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 73
#endif
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     // 74 TstFunct
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        // 75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          // 76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,PostRedData,GetRedDataPtr,FALSE,      // 77 RedData
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           // 78 DbValid
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,PostSfActionTbl,GetSfActionTblPtr,FALSE,      // 79 SfActionTbl
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 80
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 81
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,PreFreq6050,0,GetFreq6050Ptr,TRUE,                 // 82 Freq6050
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 99
#if defined(IOPTYPE_DI)
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNrOfDIsPtr,FALSE,                          // 100 NrOfDIs
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 100
#endif
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetPvAllPtr,FALSE,                            // 101 PvAll
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetPvChAppPtr,FALSE,                         // 102 PvChApp
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetPvChRemPtr,FALSE,                         // 103 PvChRem
    DT_BLIND,8,AT_PSET,ALCK_VIEW,0,0,GetPvStAllPtr,FALSE,                           // 104 PvStAll //PvAllWs
#if defined(IOPTYPE_DI)
    DT_BLIND,12,AT_PSET,ALCK_VIEW,0,0,GetPvStAlmPtr,FALSE,                          // 105 PvStAlm
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 105
#endif 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 106 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 109
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetBadPvAllPtr,FALSE,                         // 110 BadPvAll
#if defined(IOPTYPE_DI)
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetAlmAllPtr,FALSE,                           // 111 AlmAll
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 111
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 114
#if defined(IOPTYPE_DI)
    DT_STRG, 8, AT_MBYTE, ALCK_VIEW, 0, 0, GetIopDescPtr, FALSE,                    // 115  IopDesc
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 115
#endif
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                         // 116 MaxSlots
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 142
    DT_BLIND,5,AT_PSET,ALCK_VIEW,PreCheckPoint,0,GetCheckPointPtr,TRUE,             // 143 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 152
#ifdef IOMTYPE_UIO
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,PreHADCEnable,0,GetHADCEnablePtr,FALSE,             // 153 HADCEnable
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHADCStatusPtr,FALSE,                       // 154 HADCStatus
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 154
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 157
    DT_BLIND,66,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                        // 158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     // 160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostStatReset,GetStatResetPtr,FALSE,  // 161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       // 165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     // 166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      // 167 Tracelevel
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,PreDiMode,PostDiMode,GetDiModePtr,TRUE,             // 168 DiMode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 169
    DT_UINT8,1,AT_SBYTE,ALCK_OPER,PreCPLDRegData,PostCPLDRegData,GetCPLDRegDataPtr,FALSE,// 170 CPLDRegData
#ifdef IOMTYPE_DISOE
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetStMchOvrRunsPtr,FALSE,                    // 171 SOEHandler OverRuns
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetStMchMaxOvrRunTimePtr,FALSE,              // 172 SOEHandler max over time
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetStMchLstOvrRunTimePtr,FALSE,              // 173 SOEHandler last overrun time
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,0,PostResetOvrRunData,GetResetOvrRunData,FALSE,    // 174 Reset SOEHandler Overrun data
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 174
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 242
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 248
#if defined(IOPTYPE_DI)
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, 0, 0, GetBoxSfBitsPtr, FALSE,                // 249 BoxSfBits
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 249
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         // 255
};
/*******************************************************************************
*                           clsDiBoxSlot::clsDiBoxSlot                         *
*                           ==========================                         *
* PURPOSE:    Constructor                                                      *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsDiBoxSlot::clsDiBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType, MAXSLOTS) 
{
    UINT8 ProductCode = *((UINT8*)(MODULEINFO_START_ADDRESS + HW_PROD_CODE_OFFSET));
    // Initialize database parameters.
    PvChApp   = 0;
    PvChRem   = 0;
    Freq6050  = FREQ6050_SIXTYHZ;
    UINT8 ucCount;
    for (ucCount = 0; ucCount < 4; ucCount++)
    {
        PvAll[ucCount] = 0;
        BadPvAll[ucCount] = 0;
#if defined (IOPTYPE_DI)
        AlmAll[ucCount] = 0;        
        OneSecFlDI[ucCount] = 0;
#endif
        DiHvRawInputs[ucCount] = 0;
        ucDirectionBits[ucCount] = 0;
    }
    for (ucCount = 0; ucCount < MAXSLOTS; ucCount++ )
    {
        Sequence[ucCount] = 0;
        nDCdetect[ucCount] = 0;
        scAccumulator[ucCount] = 0;
#ifdef IOMTYPE_UIO
        HADCEnable[ucCount] = FALSE;
        HADCStatus[ucCount] = HART_DATA_UNKNOWN;
#endif
    }

    ProcessCycle = PROCESSCYCLE_INPUT;
    bDoOpenWireDiag = FALSE;
    m_uiCPLDDiagCounter = 0;
    ForcedInputDiagStatus.ui32Val = 0;
    HG_SNS = 0;
#ifdef IOMTYPE_DI
    HwInfo.ProductType = PRODTYPE_DI;
#elif defined(IOMTYPE_DISOE)
    HwInfo.ProductType = PRODTYPE_DISOE;
#endif
    RDBK_SEL = RDBK_BANK2; // Select bank for reading DI_IOTA bits
    switch (DI_IOTA){
        #ifdef IOMTYPE_DISOE
        case DISOE_IOTA_24V:
        case DISOE_IOTA_24V_IS:
            if(a_MdType == MODLTYPE_DISOE)
                HwInfo.ProductCode = PRODCODE_DISOE;
            else
                HwInfo.ProductCode = ProductCode;
            break;
        #elif IOMTYPE_DI
        case DI_IOTA_24V:
        case DI_IOTA_24V_IS:
            if(a_MdType == MODLTYPE_DIL) {
                if(ProductCode == PRODCODE_DI_24V_LC)
                    HwInfo.ProductCode = PRODCODE_DI_24V_LC;
                else
                    HwInfo.ProductCode = PRODCODE_DI_24V;
            }
            else
                HwInfo.ProductCode = PRODCODE_DI_24V_LC_S8;
            break;
        case DI_IOTA_110V:
            HwInfo.ProductCode = PRODCODE_DI_110V;
            break;
        case DI_IOTA_240V:
            HwInfo.ProductCode = PRODCODE_DI_240V;
            break;
        #endif
        default:
            HardFail(HF_BADPROGRAMJUMP,DIBOXSLOT_CPP,__LINE__);
    }

    // Following check is made to distinguish Series C and Series 8 hardware
    // before Serialization is done, it is required because windowed and non-windowed watchdog
    // is decided based on CPLD version, for Series C non-windowed watchdog is enabled for 
    // CPLD versions above 'E', but Series 8 non-windowed watchdog is present for
    // CPLD versions starting from 'A', this check is present in Scheduler.cpp and boxslot.cpp
    // for revisions from 'A' to 'E', where windowed watchdog is enabled, which causes Series 8
    // DI module to hardfail because of watchdog timeout.
    // Below check is only added if module type is Series C module type and product code is 
    // not in Series C range (condition occurs only if module is not serialized)

    // Open wire circuitry is used to distinguish between Series C DISOE and Series 8 DISOE hardwares.
    // For DISOE this check is applicable only if it is serialized to Verawang
    if(((MODLTYPE_DIL == a_MdType) && (ProductCode > PRODCODE_DI_24V_LC)) || 
        (MODLTYPE_DISOE_S8 == a_MdType)){
        UINT8 bHGSnsState = HG_SNS;
        UINT8 bNewState = 0;
        UINT8 bOldState = 0;
        // Change Readback select to 2 for reading Open wire status
        RDBK_SEL = RDBK_BANK2;
        bOldState = SNS_CHK;

        HG_SNS = !bHGSnsState;
        IdleWait(100);
        bNewState = SNS_CHK;

        if(MODLTYPE_DISOE_S8 == a_MdType) {
            // If Old and new states are same, then Open wire circuitry is absent
            // Change the product code as LOWCOST Series 8 DISOE
            if(bOldState == bNewState) 
                HwInfo.ProductCode = PRODCODE_DISOE_LC_S8;
            else
                HwInfo.ProductCode = PRODCODE_DISOE_S8;
        }
        else if(MODLTYPE_DIL == a_MdType) {
            // If Old and new states are same, then Open wire circuitry is absent
            // Change the product code as Series 8
            if(bOldState == bNewState)
                HwInfo.ProductCode = PRODCODE_DI_24V_LC;
            else
                HwInfo.ProductCode = PRODCODE_DI_24V;
        }
        // Change back HG_SNS state
        HG_SNS = bHGSnsState;
    }

    // Initialize DI HV timer only when module is DI HV
    if ( MODLTYPE_DIH == a_MdType)
    {
        TPU2_TCR   = 0x21; // Divide/4 clock, rising edge, clear TCNT on TGRA match.
        TPU2_TMDR  = 0xC0; // TP2 normal operation
        TPU2_TIER  = 0x01; // TGIEA interrupt enabled with TGRA match
        TPU2_TGRA  = 12480; //2080*6=12480, 2.08 msec interrupt.
        //Set DiHv interrupt priority IPRI_TICK, so that the STC interrupt 
        //handler and DiHv interrupt handler cannot interrupt each other
        IPRG_SCAN  = IPRI_TICK; 
        TPU2_CST  = 1; // Start the DI HV timer
     }//end of if module is DI HV
    
#ifdef IOMTYPE_DI
    DiMode                  = DIMODE_NORMAL;
    LatchTimeCnt            = LATCHTIMECONST;
#endif

// DISOE Point Processing FIFO 's related Declarations
#ifdef IOMTYPE_DISOE
    bTaskFifoInOverflow     = FALSE;
    bEventLost              = FALSE;
    // Initialization of  FIFOs
    UINT8 *PtrFIFO = (UINT8 *)TaskFIFO;
    for (UINT16 ucCount = 0; ucCount < (TASKFIFO_SIZE*sizeof(TASKFIFORECORD)); ucCount++){
        *PtrFIFO++ = 0;
    }
    PtrFIFO = (UINT8 *)PVCLEvtRegLog;
    for (UINT16 ucCount = 0; ucCount < (PVCLEVTREG_SIZE*sizeof(PVCLEVTRECORD)); ucCount++){
        *PtrFIFO++ = 0;
    }
    PtrFIFO = (UINT8 *)TimeSynchtbl;
    for (UINT8 ucCount = 0; ucCount < (TIMESYNCTBLSIZE*sizeof(TIMESYNCFIFO)); ucCount++){
        *PtrFIFO++ = 0;
    }
    // initialise the append and remove pointers of fifos used in SOE
    RegLogAppPtr            = 0;
    RegLogRemPtr            = 0;
    TaskFifoAppPtr          = 0; 
    TaskFifoRemPtr          = 0;
    TimeSyncTblAppPtr       = 0;
    TimeSyncTblRemPtr       = 0;
    RegTimeSyncTblAppPtr    = 0;
    FRC_Time.WORD.ClockHighWord  = 0;
    StMchOvrRuns            = 0;
    StMchMaxOvrRunTime      = 0;
    StMchLstOvrRunTime      = 0;
    ResetOvrRunData         = FALSE;
    UnSentPkt_Ptr           = 0;
    DiMode                  = DIMODE_SOE;
    bInitStMchInputBufFl    = TRUE;
    bOneSecFl               = FALSE;
    PVCLEvtRegInProgress    = FALSE;
    bUnSent_PVCL_Pkts       = FALSE;
    bLog_Frozen             = FALSE;
    bRegen_Expected         = FALSE;
    ucNoSyncCnt             = 0;
    ucReceiving_SyncCnt     = 0;
    SoeIsrBufRemPtr         = 0;
    SoeIsrBufAppPtr         = 0;
    LastTpu2Count           = 0;
    bLogEvent               = FALSE;
    ucContext               = CONTEXT_ZERO;
    ScanChanRtnSts          = RETURNSTATUS_INPROGRESS;
    bDoForcedInputDiag      = FALSE;
    bForcedInputDiagInProg  = FALSE;
    // Initialize the DISOE timer
#endif 
    TPU0_CST    = 0;    // make sure the counter is stopped
    TPU0_TCR    = 0x21; // Divide/4 clock, rising edge, clear TCNT on TGRA match.
    TPU0_TMDR   = 0xC0; // TPU0 normal mode operation
    TPU0_TIER   = 0x01; // TGIEA interrupt enabled with TGRA match
#ifdef IOMTYPE_DISOE
    TPU0_TGRA   = TPU0_1MSEC_CNT; // Default Count feed for 1 msec interrupt.
    IPRI_IOPROC = LVLPRI_SOE;     // Set SOE interrupt priority level
#else 
    TPU0_TGRA   = TPU0_5MSEC_CNT; // Default Count feed for 5 msec interrupt.
    IPRI_IOPROC = LVLPRI_TICK;    // Set SOE interrupt priority level
#endif 
#ifdef IOMTYPE_DISOE
    // Init Timers for Free Running timer.
    TPU2_CST    = 0;    // make sure the counter is stopped
    TPU2_TCR    = 0x02; // Divide/16 clock, rising edge, 
    TPU2_TMDR   = 0xC0; // TPU2 normal mode operation
    TPU2_CST    = 1;    // Start the Free Running Counter for SOE
#endif
}

/*******************************************************************************
*                          clsDiBoxSlot::GetDataType                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsDiBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsDiBoxSlot::GetAccessType                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsDiBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                          clsDiBoxSlot::GetParamSize                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsDiBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                          clsDiBoxSlot::GetParamPtr                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsDiBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                         clsDiBoxSlot::GetAccessLock                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsDiBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                    clsDiBoxSlot::GetIsDbChecksumed                           *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDiBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                        clsDiBoxSlot::VerifyControlState                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}
/*******************************************************************************
*                        clsDiBoxSlot::ExecutePreFunction                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsDiBoxSlot::ExecutePostFunction                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                           clsDiBoxSlot::PreFreq6050                          *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS  clsDiBoxSlot::PreFreq6050(UINT8 *a_Writebuffer, UINT8)
{   if (*a_Writebuffer > FREQ6050_FIFTYHZ)
    {
        return DO_PARAMETER_INVALID;
    }
    
    if ( GetModuleStatus()  != MODSTATUS_IDLE )
        return DO_STATE_MUST_BE_IDLE;
   
    return PA_OK;
} 
/*******************************************************************************
*                         clsDiBoxSlot::PreCheckPoint                         *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsDiBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    DiMode = DIMODE_NORMAL;
    Freq6050 = FREQ6050_SIXTYHZ;
    return PA_OK;
}
/*******************************************************************************
*                           clsDiBoxSlot::AppStcProcessing                     *
*                           =========================                          *
* PURPOSE:   This is a routine called by the AppStcProcessing.                 *
*            The DI 24V Module processing is done here.                        *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::AppStcProcessing(VOID)
{   
#ifdef DEBUG
    uiExecTime = TPU5_TCNT;
#endif

    // Process redundancy inputs, outputs and state here
    ManageRedIO();

    if (PROCESSCYCLE_INPUT == ProcessCycle) 
    {    // input processing cycle
         ProcessCycle = PROCESSCYCLE_DIAG;
         if(DIMODE_NORMAL == DiMode) 
         {
             for (UINT8 ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++) 
             {
                 SLOT(ucSltNm)->GetRawInput();
             }
         }
#ifdef IOMTYPE_DISOE
        // SOE mode related code
        else if(DIMODE_SOE == DiMode)
        {
            for (UINT8 ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++)
            {
                // check for manual mode Pv Change
                if((PVSOURCE_AUTO != SLOT(ucSltNm)->GetPvSource()) && (EVTOPT_SOE == SLOT(ucSltNm)->GetEvtOpt()))
                {
                    // if LastPv and NewPv is not matching post the PvChgEvt to PVCL
                    ONOFF CurPv = GetPv(ucSltNm);
                    if(CurPv != SLOT(ucSltNm)->GetLastPv())
                    {
                        SLOT(ucSltNm)->SetLastPv(CurPv);
                        // make the Pv Change packet and post it in PVCL
                        PVCLEVTRECORD PvchgPkt;
                        UINT16        SyncId;
                        UINT32        TimeStamp,CurrentTime;
                        if(TimeSyncTblAppPtr>0)
                        {
                            SyncId    = TimeSynchtbl[TimeSyncTblAppPtr-1].TimeSynchID;
                            TimeStamp = TimeSynchtbl[TimeSyncTblAppPtr-1].SynchTimeStamp;
                        }
                        else
                        {
                            SyncId    = TimeSynchtbl[TIMESYNCTBLSIZE-1].TimeSynchID;
                            TimeStamp = TimeSynchtbl[TIMESYNCTBLSIZE-1].SynchTimeStamp;
                        }
                        // Get present FRC time and calculate offset from SyncId.
                        set_imask_exr(LVLPRI_HIGHEST);
                        CurrentTime = GetFrcCount();
                        set_imask_exr(LVLPRI_TICK);
                        if(CurrentTime>=TimeStamp)
                        {
                            TimeStamp = CurrentTime - TimeStamp;
                        }
                        else
                        {
                            TimeStamp = (MAXUINT32-TimeStamp)+CurrentTime+1;
                        }
                        // Now the offset is in terms of 0.666usec, devide by 300 to make it
                        // interms of 200usec
                        TimeStamp = TimeStamp/300;
                        PvchgPkt.Qualifier = EVENTTYPE_PVCLNORMAL;
                        PvchgPkt.TimeStampFlag = TRUE;
                        PvchgPkt.EventPktType = EVENTPACKET_SOEPVC;
                        PvchgPkt.PVCL_PVCHANGEPKT.PVCHG_PV = CurPv;
                        PvchgPkt.PVCL_PVCHANGEPKT.PVCHGSOEslot = ucSltNm;
                        PvchgPkt.PVCL_PVCHANGEPKT.SyncIDHigh = (UINT8)(SyncId>>8);
                        PvchgPkt.PVCL_PVCHANGEPKT.SyncIDLow = (UINT8)(SyncId);
                        PvchgPkt.PVCL_PVCHANGEPKT.TimeStampHigh = (UINT8)(TimeStamp>>16);
                        PvchgPkt.PVCL_PVCHANGEPKT.TimeStampMid = (UINT8)(TimeStamp>>8);
                        PvchgPkt.PVCL_PVCHANGEPKT.TimeStampLow = (UINT8)(TimeStamp);
                        AddNrmPVCLEvent(&PvchgPkt);
                    }
                } // if MAN mode
                // process latch timer
                SLOT(ucSltNm)->ProcessLatchedTimer();
            }
            if(TRUE == bOneSecFl)
            {
                // Increment the NoSyncCmd count till 20sec. 
                if(ucNoSyncCnt<STCTWENTYSECCNT)
                {
                    ucNoSyncCnt++;
                    if ( (STCFOURSECCNT >= ucNoSyncCnt) && (TRUE == bLog_Frozen))
                    {
                        //If the PV Change Log is frozen, and the receiving syncs 
                        // counter is active, the receiving syncs counter is decremented.
                        // If it has timed out, and no regen is in progress, the PC Change 
                        // Log is unfrozen, and the regen expected flag is cleared.
                        if (ucReceiving_SyncCnt>0)
                        {
                            ucReceiving_SyncCnt --;
                        }
                        if ( (0==ucReceiving_SyncCnt) && (FALSE == PVCLEvtRegInProgress) )
                        {
                            bRegen_Expected = FALSE;
                            bLog_Frozen = FALSE;
                        }
                    }
                    if(STCFOURSECCNT == ucNoSyncCnt)
                    {
                        // Be ready for the regeneration
                        Prepare_For_Regen();
                    }
                    if (STCTENSECCNT == ucNoSyncCnt)
                    {
                        // clear the SyncId Table
                        TimeSyncTblAppPtr = 0;
                        TimeSyncTblRemPtr = 0;
                        TimeSynchtbl[TimeSyncTblAppPtr].TimeSynchID = 0;
                    }
                    if(STCTWENTYSECCNT == ucNoSyncCnt)
                    {
                        // remove all the events from the Regen log (PVCLEvtRegLog)
                        RegLogAppPtr      = 0;
                        RegLogRemPtr      = 0;
                        bRegen_Expected   = FALSE;
                        bLog_Frozen       = FALSE;
                        bUnSent_PVCL_Pkts = FALSE;
                    }
                }
                // Decrement PvChgDly count for all slots for every second
                for(UINT8 ucCount=1;ucCount<=MAXSLOTS;ucCount++)
                {
                    // process the PvChgDly
                    SLOT(ucCount)->ProcessPvChgDly();
                }
                bOneSecFl = FALSE;
            } // if OneSec flag Set
        } // only for DiMode is SOE
#endif
        bDoOpenWireDiag = FALSE;
        //This check is added to prevent setting of high sensitivity for OWD 
        //for DISOE IOM when it is in SOE and LowLatency Mode
        if ( DIMODE_NORMAL==DiMode){  
            if ((ModlType == MODLTYPE_DIL) || (ModlType == MODLTYPE_DISOE) ||
                (ModlType == MODLTYPE_DIL_S8) || (ModlType == MODLTYPE_DISOE_S8)) 
            {             
                UINT8 ucTemp = get_imask_exr();
                set_imask_exr(LVLPRI_HIGHEST);
                if (TPU5_TCNT < (3 * TPUCOUNT_IN_MILLISECOND)) 
                {
                    // This means, there is at least 7 msec left in the current
                    // 10 msec cycle and the open wire diagnostic can be carried
                    // out in the next cycle.
                    
                    // Save the sensitivity circuit status in normal mode for use
                    // in the diagnostic cycle
                    RDBK_SEL = RDBK_BANK2;
                    ucSns_Chk_Nrml = SNS_CHK;
                    
                    // Set the mode to high sensitivity for OWD in the next cycle
                    HG_SNS = SNS_OWD; 
                    // Open Wire is diagnostics is not enabled for Series 8 DI and DISOE IOM
                    if((HwInfo.ProductCode != PRODCODE_DISOE_LC_S8) && (HwInfo.ProductCode != PRODCODE_DI_24V_LC_S8)
                        &&(HwInfo.ProductCode != PRODCODE_DI_24V_LC))
                        bDoOpenWireDiag = TRUE;
                    else
                        bDoOpenWireDiag = FALSE;
                }   
                #ifdef DEBUG
                else TraceLog.AddToTrace(TRACEID_DIAGTASK,bcOpenWireDiagmiss);
                #endif
                set_imask_exr(ucTemp);
            }// end of ModlType == MODLTYPE_DIL
        }
        // Do the CPLD Register Diagnostic every 500ms
        if (m_uiCPLDDiagCounter >= (CPLD_DIAG_COUNT-1)) {
            CPLDReadBkRegDiag();
            m_uiCPLDDiagCounter = 0;
        }
        else {
            m_uiCPLDDiagCounter++;
        }
    }// end of input processing cycle
    else
    {    // This is diagnostic cycle
         ProcessCycle = PROCESSCYCLE_INPUT;
         if ((MODLTYPE_DIL == ModlType) || (ModlType == MODLTYPE_DISOE) || 
             (MODLTYPE_DIL_S8 == ModlType) || (ModlType == MODLTYPE_DISOE_S8)){
             // Run open wire diagnostics and forced 
             // input diagnostics only in 24V DI IOM and DISOE
#ifdef DEBUG
             if (TRUE == g_bStopDiTests) {
                 if (TRUE == bDoOpenWireDiag) {
                     HG_SNS = SNS_NORMAL; // Put back to normal sensitivity
                 }
             }
             else {
                 if ((TRUE == bDoOpenWireDiag)&&(DIMODE_NORMAL==DiMode)) {
                     OpenWireDiagStatus = OpenWireDiag();
                 }
                 ForcedInputDiag();
             }
#else
             if ((TRUE == bDoOpenWireDiag)&&(DIMODE_NORMAL==DiMode)) {
                 OpenWireDiag();
             }
             if(DIMODE_NORMAL == DiMode) {
                 ForcedInputDiag();
             }
             #ifdef IOMTYPE_DISOE
             else if(DIMODE_SOE == DiMode){
                 // For SOE mode FID is executed @20msec rate based on below flag status.
                 bDoForcedInputDiag = TRUE;
             }
             #endif
#endif
         }
         
         // Update PV and BadPv for all slots depending 
         // on the result of point processing and diagnotics.
         // Inhibit slot processing on backup module during db synchronization
         // Man and Sub PVs could otherwise be inappropriately updated from raw data
         if((DIMODE_NORMAL==DiMode && (Iol.AmPrimary() || REDSTATE_SYNCD == GetRedState())) || CheckForFactoryTestMode())
         {
            for (UINT8 ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++) 
            {
                SLOT(ucSltNm)->UpdateBadPv();
                SLOT(ucSltNm)->ProcessSlot();
            }
         }
         #ifdef IOMTYPE_DISOE
         // Process regular PvChgEvt
         if(DIMODE_SOE == DiMode)
         {
             ProcessTaskfifoPacket();
         }
         #endif
    }//end of diagnostic cycle 

#ifdef DEBUG
    UINT16 uiStopTime = TPU5_TCNT;

    if (uiStopTime > uiExecTime) uiExecTime = uiStopTime - uiExecTime;
    else uiExecTime = (TPUCOUNT_MAXVALUE - uiExecTime) + uiStopTime + 1;

    // Note that ProcessCycle is already changed for next cycle.
    if (PROCESSCYCLE_DIAG == ProcessCycle) {
        if (uiMaxIpTime < uiExecTime) uiMaxIpTime = uiExecTime;
    }
    else
    {
        if (uiMaxDiagTime < uiExecTime) uiMaxDiagTime = uiExecTime;
    }
#endif
}//end of AppStcProcessing
/******************************************************************************
*                  clsDiBoxSlot::DiHvInterruptHandler                         *
*                  ====================================                       *
* PURPOSE:                                                                    * 
*    TPU2 interrupt service routine.                                          *  
*    This ISR performs DI HV input sampling every 2.08 msec.                  *
*    It is suitable for use with 120VAC, 125VDC, and 240VAC inputs.           *
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*    The uP is guaranteed to see an energized state whenever the input        *
*    voltage is above ~90V with respect to its return.                        *
*    This algorithm assumes the AC inputs are half wave rectified.            *
*    An AC ON is declared only after two consecutive positive half cycles have*
*    been detected. Once ON , the loss of any single positive half cycle will *
*    not change the raw input to OFF. An AC OFF is declared only after no     *
*    positive half cycles have been detected for at least 1.5 half cycles of  *
*    time.                                                                    *
*    A DC ON is declared if the input has continuous current flow for more    *
*    than one half AC cycle. Note that a drop out of duration less than a     *
*    sample period occurring in between sample times will go undetected. A DC *
*    OFF is declared on the first and all subsequent samples having no current*
*    flow.                                                                    *
*                                                                             *
******************************************************************************/
VOID clsDiBoxSlot::DiHvInterruptHandler(VOID) 
{
    TPU2_TGFA = 0; // Acknowledge the compare match interrupt
    UINT8 ucBankNum,ucChanNum,ucCount,ucDCthreshold;
    INT8  scIncrementValue,scACthreshold;
    UINT8 ucRawInputs[NO_OF_BANKS];

    if (MODSTATUS_RUN == BOX->GetModuleStatus()) {
        // Read the input ports for this sample
        ucRawInputs[0] = P_PB.PORT.BYTE;
        ucRawInputs[1] = P_PC.PORT.BYTE;
        ucRawInputs[2] = P_PD.PORT.BYTE;
        ucRawInputs[3] = P_PE.PORT.BYTE;

        if (FREQ6050_FIFTYHZ == BOX->Freq6050) {
            scIncrementValue = CNT_ACDROPOUT50HZ; // sample counts for 50 Hz
            ucDCthreshold = CNT_DCDETECT50HZ;
        }
        else {
            scIncrementValue = CNT_ACDROPOUT60HZ; // sample counts for 60 Hz
            ucDCthreshold = CNT_DCDETECT60HZ;
        }

        scACthreshold = scIncrementValue + 1;

        // Do the input processing bankwise for all the channels
        for (ucBankNum=0,ucChanNum=0; ucBankNum < NO_OF_BANKS; ucBankNum++) {
            // Initialize the channel mask for this bank
            UINT8 ucBitMask  = 0x01;
            for (ucCount = 0; ucCount < INPUTS_PER_BANK; ucCount++,ucChanNum++) {
                if (!(ucRawInputs[ucBankNum] & ucBitMask)) { // current is flowing
                    if (!(BOX->ucDirectionBits[ucBankNum] & ucBitMask)) {
                        // if the direction bit for this channel is not set
                        // it is a rising edge - set the direction bit
                        BOX->scAccumulator[ucChanNum] += scIncrementValue;
                        BOX->ucDirectionBits[ucBankNum] |= ucBitMask;
                    }
                    if (BOX->scAccumulator[ucChanNum] >= scACthreshold) { // AC ON
                        BOX->scAccumulator[ucChanNum] = scACthreshold;
                        BOX->DiHvRawInputs[ucBankNum] |= ucBitMask;    // set PvRaw bit ON
                    }
                    else {
                        BOX->nDCdetect[ucChanNum]++;
                        if (BOX->nDCdetect[ucChanNum] >= ucDCthreshold) { // DC ON
                            BOX->nDCdetect[ucChanNum] = ucDCthreshold;                            
                            BOX->DiHvRawInputs[ucBankNum] |= ucBitMask;// set PvRaw bit ON
                        }
                    }
                }
                else {                                         // current is not flowing
                    if (BOX->nDCdetect[ucChanNum] == ucDCthreshold)
                        BOX->DiHvRawInputs[ucBankNum] &= ~ucBitMask;   // set PvRaw bit OFF
                    BOX->nDCdetect[ucChanNum] = 0;
                    BOX->scAccumulator[ucChanNum] -= 1;
                    BOX->ucDirectionBits[ucBankNum] &= ~ucBitMask; // clear direction bit
                    if (BOX->scAccumulator[ucChanNum] <= 0) {
                       BOX->scAccumulator[ucChanNum] = 0;
                       BOX->DiHvRawInputs[ucBankNum] &= ~ucBitMask;    // set PvRaw bit OFF
                    }
                }
                ucBitMask <<= 1;
            } // end of channel for loop
        } // end of bank for loop 
    } // end of ModuleStatus = RUN
}
/*******************************************************************************
*                          clsDiBoxSlot::ForcedInputDiag                       *
*                          =============================                       *
* PURPOSE:  This function test for all the comparitors by writing AA and       *
*           55 on each port by setting/resetting control signals.              *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Results are stored in a box param ForcedInputDiagStatus using which   *
*        soft fail is posted later in BoxHouseKeeping(Low priority task). Also *
*        BadPv is updated using these results in UpdateBadPv() as softfail     *
*        not be posted yet from BoxHouseKeeping.                               * 
*******************************************************************************/
VOID clsDiBoxSlot::ForcedInputDiag(VOID) 
{
    UINT8 ucCount,ucPattern = 0xAA;
    UINT32 ulMask;

    // A monte carlo analysis of the propogation time from changing the A5CNTL
    // lines until the value at the input ports settles has indicated that
    // the worst case time of 11.75 uS for DI and 6 uS for DISOE. A delay of
    // 15 us and 8 uS are implemented for DI and DISOE respectively. Also for DISOE,
    // interrupt mask is elevated to SOE level to blcok SOE ISR during the test.

#ifdef IOMTYPE_DISOE
    const UINT8 A5CNTL_DELAY = 8;
    if(DIMODE_SOE == DiMode){
        bForcedInputDiagInProg = TRUE;
    }
#else
#if defined (IOPTYPE_DI)
    const UINT8 A5CNTL_DELAY = 28;
#else
    const UINT8 A5CNTL_DELAY = 15;
#endif
#endif


    A5_CNTL = 2;
    IdleWait(A5CNTL_DELAY);

    // Check all ports for the right pattern. All bits DiagData
    // in bytes will be zero if all channels are fine.
    ForcedInputDiagStatus.ucBytes[0] = P_PE.PORT.BYTE ^ ucPattern;
    ForcedInputDiagStatus.ucBytes[1] = P_PD.PORT.BYTE ^ ucPattern;
    ForcedInputDiagStatus.ucBytes[2] = P_PC.PORT.BYTE ^ ucPattern;
    ForcedInputDiagStatus.ucBytes[3] = P_PB.PORT.BYTE ^ ucPattern;

    // Test for the other pattern.
    ucPattern = ~ucPattern;
    A5_CNTL = 1;
    IdleWait(A5CNTL_DELAY);

    ForcedInputDiagStatus.ucBytes[0] |= P_PE.PORT.BYTE ^ ucPattern;
    ForcedInputDiagStatus.ucBytes[1] |= P_PD.PORT.BYTE ^ ucPattern;
    ForcedInputDiagStatus.ucBytes[2] |= P_PC.PORT.BYTE ^ ucPattern;
    ForcedInputDiagStatus.ucBytes[3] |= P_PB.PORT.BYTE ^ ucPattern;

    // Release forced inputs.
    A5_CNTL = 0;
    IdleWait(A5CNTL_DELAY);
#ifdef IOMTYPE_DISOE
    bForcedInputDiagInProg = FALSE;
#endif

    // Below code will not get executed utill any of input channel is failed.
    if(ForcedInputDiagStatus.ui32Val > 0)
    {
        for (ucCount = 1,ulMask = 1; ucCount <= MAXSLOTS; ucCount++,ulMask <<= 1)
        {
            if ((GetModuleStatus() == MODSTATUS_RUN) &&
                (SLOT(ucCount)->GetPtExecSt() == PTEXECST_ACTIVE) &&
                (ForcedInputDiagStatus.ui32Val & ulMask))
            {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_INPTFAIL,TRUE,ucCount);
                SLOT(ucCount)->UpdateBadPv();
            }
            else 
            {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_INPTFAIL,FALSE,ucCount);
            }
        }
    }
}
/*******************************************************************************
*                          clsDiBoxSlot::OpenWireDiag                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT32 clsDiBoxSlot::OpenWireDiag(VOID)
{
    DATABYTES   DiagData;
    UINT8       ucCount, ucSnsChkMask;
    UINT32      ulMask;

    // If any channel is open, the corresponding bit will be set.
    DiagData.ucBytes[0] = P_PE.PORT.BYTE;
    DiagData.ucBytes[1] = P_PD.PORT.BYTE;
    DiagData.ucBytes[2] = P_PC.PORT.BYTE;
    DiagData.ucBytes[3] = P_PB.PORT.BYTE;
    
    //Read SNS_CHK bits
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    RDBK_SEL = RDBK_BANK2; // Select bank for reading SNS_CHK bits
    ucSns_Chk_OWD = SNS_CHK;
    UINT8 ucSnsChk = ucSns_Chk_Nrml | (ucSns_Chk_OWD ^ 0x0F);
    set_imask_exr(ucSaveExr);
    HG_SNS = SNS_NORMAL; // Put back to normal sensitivity
    
    // Check if the TPU5 count is getting changed as part of Dump. If yes
    // Skip this diagnostic cycle.
    if (GetStcSyncReset()) {
        bStcSyncRestart = FALSE;
        return 0;
    }

    for (ucCount = 0, ulMask = 1, ucSnsChkMask = SNS_CHKA; ucCount < MAXSLOTS; ucSnsChkMask >>= 1)
    {
        if (ucSnsChk & ucSnsChkMask) 
        {
            // This bank of inputs has a failed sensitivity circuit
            // so post SF and skip OWD
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,TRUE,0);
            ucCount += 8;
            ulMask <<= 8;
            // If it is stuck in high sensitivity mode
            // For every channel in this bank with OWD enabled mark the PV BAD!
            // This is done via ucSns_Chk_OWD in clsDiSlot::UpdateBadPv()
        }
        else
        {
            // Test hardware is operating correctly
            do 
            {
                ucCount++;
                if ((SLOT(ucCount)->GetOwdEnable() == TRUE) 
                    && (DiagData.ui32Val & ulMask)
                    && (SLOT(ucCount)->GetPtExecSt() == PTEXECST_ACTIVE) 
                    && (GetModuleStatus() == MODSTATUS_RUN))
                {
                    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,TRUE,ucCount);
                }
                else
                {
                   AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ucCount);
                }
                ulMask <<= 1;

            } while ((ucCount % 8) > 0);
        }
    }
    // If all 4 feedback signals were correct in both directions clear the SF
    if (ucSnsChk == 0) AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,FALSE,0);
    return DiagData.ui32Val;
}

VOID clsDiBoxSlot::AppColdInit(VOID) {
    if (MODSTATUS_RUN == ModStat1.Status) {
        ModStat1.Status = MODSTATUS_IDLE;
        AddModStatEvent(EVENTTYPE_NORMAL);
    }
    DbValid = DB_INVALID;
    ComputeCheckSum(); // Recompute BOX checksum
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        // Slot checksum is recomputed by InitSlotDatabase.
        SLOT(ucSlotNum)->InitSlotDatabase(TRUE);
    }
}

BOOL clsDiBoxSlot::AppFOProcess(VOID) {
    return FALSE;
}

VOID clsDiBoxSlot::AppPostSwap(VOID) {
}

VOID clsDiBoxSlot::AppPostSync(VOID) {
    for (UINT8 ucSltNm = 1; ucSltNm <= MAXSLOTS; ucSltNm++) {
        SLOT(ucSltNm)->UpdateBadPv();
#ifdef IOMTYPE_DISOE
        if(DIMODE_SOE == DiMode)
        // call the SOE specific post functions to ensure
        // proper values are updated after sync
        SLOT(ucSltNm)->CallPostDebounce();
        SLOT(ucSltNm)->CallPostPvChgDly();
#endif
    }
    PostDiMode(1);//Aurgument is used to be inline with func signature
    // Run the TPU0 timer to start the SOE ISR.
    if((DIMODE_NORMAL != DiMode)&&(MODSTATUS_RUN == ModStat1.Status))
    {
        TPU0_CST = 1;
    }
}
/*******************************************************************************
*                             clsDiBoxSlot::PreDiMode                          *
*                             =======================                          *
* PURPOSE: If the Module is in RUN state do not allow to change the DiMode     *
* ARGUMENTS:                                                                   *
*              a_Writebuffer-    Pointer to the buffer                         *
*              a_ucAccLvl   -   Access Level                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDiBoxSlot::PreDiMode(UINT8 *a_Writebuffer, UINT8)
{
    UINT8 ucModSts = BOX->GetModuleStatus();
    if (*a_Writebuffer > DIMODE_LOWLATNCY)
    {
        return DO_ILLEGAL_VALUE;
    }
    #ifdef IOMTYPE_DI
    if ((DIMODE_LOWLATNCY != *a_Writebuffer) && (DIMODE_NORMAL != *a_Writebuffer))
    {
        return DO_ILLEGAL_VALUE;
    }
    #endif
    if (MODSTATUS_RUN == ucModSts)
    {
        return DO_STATE_MUST_BE_IDLE;
    }
    return PA_OK;
}
/*******************************************************************************
*                             clsDiBoxSlot::PostDiMode                         *
*                             =======================                          *
* PURPOSE: Set the count for the TPU0 timer used for SOEInterruptHandler       *
*           Also clean the SOE related fifos when the DiMode SOE               *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::PostDiMode(UINT8 )
{
#ifndef IOMTYPE_DISOE
    if (BoxChkpntVersion < DIMODE_BOXCHKPNT_VERSION)
    {
        // If DiMode gets written make sure that the box checkpoint version is 
        // at least verison 2, which is the version at which DIMODE was added.
        BoxChkpntVersion = DIMODE_BOXCHKPNT_VERSION;
    }
#endif

    if(DIMODE_LOWLATNCY==DiMode)
    {
        // intialize the LatchTimerCnt for 1.5 sec
        // As channel processed every 5msec which is 4 times more than
        // STC cycle, the value is multiplied by 4
        LatchTimeCnt = LOWLATLATCHTIMECONST;
        //In DI24V, TPU0_TGRA and IPRI_IOPROC never change.

        #ifdef IOMTYPE_DISOE
        TPU0_TGRA   = TPU0_5MSEC_CNT;  // Count feed for 5 msec interrupt
        IPRI_IOPROC = LVLPRI_TICK;     // Set SOE interrupt priority level
        // also clear all the fifos, related to SOE mode as we should not post SOE events
        TaskFifoAppPtr    = 0;
        TaskFifoRemPtr    = 0;
        RegLogAppPtr      = 0;
        RegLogRemPtr      = 0;
        #endif

        // No openwire detection in this mode
        HG_SNS = SNS_NORMAL; // Ensure to put back normal sensitivity
        bDoOpenWireDiag = FALSE;
    }
    #ifdef IOMTYPE_DISOE
    else if (DIMODE_SOE==DiMode)
    {
        TPU0_TGRA   = TPU0_1MSEC_CNT; // Count feed for 1 msec interrupt.
        IPRI_IOPROC = LVLPRI_SOE;     // Set SOE interrupt priority level
        // intialize the LatchTimerCnt for 1.5 sec
        LatchTimeCnt = LATCHTIMECONST;

        // No openwire detection in this mode
        HG_SNS = SNS_NORMAL; // Ensure to put back normal sensitivity
        bDoOpenWireDiag = FALSE;
    }
    #endif
    else
    {
        // Stop the SOE ISR interrupt as it is no longer required for Normal Mode
        TPU0_CST = 0;
        // For DiMode equal to DIMODE_NORMAL
        LatchTimeCnt = LATCHTIMECONST;
    }
}
#ifdef IOMTYPE_DISOE
/*******************************************************************************
*                             clsDiBoxSlot::PostResetOvrRunData                *
*                             =======================                          *
* PURPOSE: To Reset the SOE ISR overrun data.                                  *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::PostResetOvrRunData(UINT8 )
{
    if(TRUE == ResetOvrRunData)
    {
        StMchOvrRuns        = 0;
        StMchMaxOvrRunTime  = 0;
        StMchLstOvrRunTime  = 0;
        ResetOvrRunData     = FALSE;
    }
    return;
}
/*******************************************************************************
*                             clsDiBoxSlot::SetStMchInputBufTarget             *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: Slot number and the Debounce value                                *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::SetStMchInputBufTarget(UINT8 SlotNum,UINT8 ucTarget)
{
    // As the StMchinPutBuf is zero based, channel num is one base, we decrement
    // the channel num by one
    StMchInputBuf[SlotNum-1].unTarget = ucTarget;
}
#endif
///////////////////////////////////////////////////////////////////////////////
//                       SOE Interrupt Handler                               //
///////////////////////////////////////////////////////////////////////////////
/*******************************************************************************
*                             clsDiBoxSlot::SOEInterruptHandler                *
*                             ===============================                  *
* PURPOSE: To scan the channels in SOE and LowLatency modes                    *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::SOEInterruptHandler(VOID)
{
    if(DIMODE_LOWLATNCY == BOX->DiMode)
    {
        //if DiMode is LOWLATNCY SOEInterruptHandler ISR will come at each 5msec
        TPU0_TGFA = 0;        // Acknowledge the compare match interrupt
        // Do 0xAA, 0x55 test to validate inputs channels.
        BOX->ForcedInputDiag();
        for ( UINT8 ChannelNm = 1; ChannelNm <= MAXSLOTS; ChannelNm++)
        {
             SLOT(ChannelNm)->GetRawInput();
             SLOT(ChannelNm)->UpdateBadPv();
             SLOT(ChannelNm)->ProcessSlot();
        }
        return;
    }
    #ifdef IOMTYPE_DISOE
    else
    {
        // Causion: Do not add/change below code as it is tightly coupled with IOLINK ISRs
        //          If you change it, it may lead to IOL errors.

        UINT32 FrcPresent;
        UINT8  FreeSpace;
        // Acknowledge the TPU0 interrupt
        TPU0_TGFA = 0;

        // If the IOL transmitter is active drop the interrupt mask level
        // to allow its ISR to run w/ exclusive priority and then continue
        if((TXREQ_n == IOLDRV_ON))
        {
            set_imask_exr(LVLPRI_IOLN);
        }
        // If a new IOL request has begun since entering this ISR let the IOL
        // Rcvr ISR execute first and defer the execution of this ISR until
        // the request is completely received
        else if (IOL_RDRF)
        {
            TPU0_CST  = 0;
            TPU0_TCNT = TPU0_990US_CNT;    // preset for an interrupt in 10 us
            TPU0_CST  = 1;
            return;
        }
        // Update the Free Running Counter and get its value
        FrcPresent = BOX->GetFrcCount();
        // Compute the free space in the SOE ISR buffer
        if(SoeIsrBufAppPtr<SoeIsrBufRemPtr)
        {
            FreeSpace = SoeIsrBufRemPtr-SoeIsrBufAppPtr;
        }
        else
        {
            FreeSpace = SOEISRBUFSIZE-(SoeIsrBufAppPtr-SoeIsrBufRemPtr);
        }

        // If there is free space, insert a new entry
        if(FreeSpace>1)
        {
            // store 32 channels Pv and the current time stamp
            SOEISRBuffer[SoeIsrBufAppPtr].TimeStamp = FrcPresent;
            SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[0] = ~(P_PB.PORT.BYTE);
            SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[1] = ~(P_PC.PORT.BYTE);
            SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[2] = ~(P_PD.PORT.BYTE);
            SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[3] = ~(P_PE.PORT.BYTE);
            SoeIsrBufAppPtr = SoeIsrBufAppPtr + 1;
            if(SoeIsrBufAppPtr>=SOEISRBUFSIZE)
            {
                SoeIsrBufAppPtr = 0;
            }
        }
        if((TRUE == BOX->bDoForcedInputDiag) && (TXREQ_n == IOLDRV_OFF))
        {
            BOX->bDoForcedInputDiag = FALSE;
            // Execute the Forced Input Diagnostics with lower priority
            // to allow link 
            set_imask_exr(LVLPRI_IOLN);
            // Do 0xAA, 0x55 test to validate input channels.
            BOX->ForcedInputDiag();
        }
    }
    #endif
}
#ifdef IOMTYPE_DISOE
/*******************************************************************************
*                             clsDiBoxSlot::GetSOESample                       *
*                             ==========================                       *
* PURPOSE: This Method is only for the DISOE module to get the channel data    *
*          and timestamp.                                                      *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::GetSOESample(VOID)
{
    // This function does same as SOEInterruptHandler for DiMode = SOE,
    // and this function will be called from iol when SOE interrupt is hogged.
    // So when IOM is in SOE mode (DiMode), either SOEInterruptHandler
    // or GetSOESample will be executed, but not both at same time.
    UINT32 FrcPresent;
    UINT8  FreeSpace;

    if(DIMODE_SOE != DiMode)
        return;
    // Update the Free Running Counter and get its value
    FrcPresent = BOX->GetFrcCount();
    // Acknowledge the TPU0 interrupt
    TPU0_TGFA = 0;
    // Compute the free space in the SOE ISR buffer
    if(SoeIsrBufAppPtr<SoeIsrBufRemPtr)
    {
        FreeSpace = SoeIsrBufRemPtr-SoeIsrBufAppPtr;
    }
    else
    {
        FreeSpace = SOEISRBUFSIZE-(SoeIsrBufAppPtr-SoeIsrBufRemPtr);
    }

    // If there is free space, insert a new entry
    if(FreeSpace>1)
    {
        // store 32 channels Pv and the current time stamp
        SOEISRBuffer[SoeIsrBufAppPtr].TimeStamp = FrcPresent;
        SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[0] = ~(P_PB.PORT.BYTE);
        SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[1] = ~(P_PC.PORT.BYTE);
        SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[2] = ~(P_PD.PORT.BYTE);
        SOEISRBuffer[SoeIsrBufAppPtr].ChnPv1_32[3] = ~(P_PE.PORT.BYTE);
        SoeIsrBufAppPtr = SoeIsrBufAppPtr + 1;
        if(SoeIsrBufAppPtr>=SOEISRBUFSIZE)
        {
            SoeIsrBufAppPtr = 0;
        }
    }
    return;
}
/*******************************************************************************
*                             clsDiBoxSlot::ScanChannel                        *
*                             ===============================                  *
* PURPOSE:This method shall initialize SOE State Machine Input buffer          *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::ScanChannel(VOID)
{
    UINT8 SOEChannelNum=1;
    // for the first time scan of ports after IOM loaded/Activated,
    // initialize the STMCHINPTBUFF
    for(UINT8 ucByteIndex=0;ucByteIndex<sizeof(UINT32);ucByteIndex++)
    {
        for(UINT8 ucBitIndex=0x01;ucBitIndex!=0;)
        {
            StMchInputBuf[SOEChannelNum-1].bNew = !((*pInputPorts[ucByteIndex]) & ucBitIndex);
            // Initialize the STMCHINPTBUFF with the new Pv value
            InitStMchInputBuf(SOEChannelNum-1);
            // update the PvAll with this new Pv value.
            // As StMchInPutBuf is zero based and channel number is one based,
            // Increment the channel number and call below functions.
            SLOT(SOEChannelNum)->SetRawInput(StMchInputBuf[SOEChannelNum-1].bNew);
            SLOT(SOEChannelNum)->ProcessSlot();
            ucBitIndex = ucBitIndex<<1;
            SOEChannelNum++;
        }
    }
    bInitStMchInputBufFl = FALSE;
    return;
}
/********************************************************************************
*           clsDiBoxSlot::ProcessForPvChgEvt                                    *
*           ================================                                    *
* Purpose: This method shall process PVs stored in SOEISRBuffer and post events *
*          in TaskFIFO                                                          *
********************************************************************************/
VOID clsDiBoxSlot::ProcessForPvChgEvt(VOID)
{
    // If IOM is Idle, no need to process the packets further.
    if(MODSTATUS_IDLE == ModStat1.Status)
    {
        // To ignore the first overrun calculation after IOM made RUN from IDLE
        BOX->SOEHandler_StartTime = 0;
        SoeIsrBufRemPtr = SoeIsrBufAppPtr;
        return;
    }
    // process the packets
    while(SoeIsrBufRemPtr != SoeIsrBufAppPtr)
    {
        UINT8 ChannelNum=1;
        UINT32 SOEHandler_EndTime = SOEISRBuffer[SoeIsrBufRemPtr].TimeStamp;
        for(UINT8 ucByteIndex=0;ucByteIndex<sizeof(UINT32);ucByteIndex++)
        {
            for(UINT8 ucBitIndex=0x01;ucBitIndex!=0;ucBitIndex <<= 1)
            {
                BOOL bLogEvent = FALSE;
                BOOL bStoreTime = FALSE;
                // do the PV change detection only for the Active channels
                if(PTEXECST_ACTIVE == SLOT(ChannelNum)->GetPtExecSt())
                {
                    StMchInputBuf[ChannelNum-1].bNew = 
                    (SOEISRBuffer[SoeIsrBufRemPtr].ChnPv1_32[ucByteIndex]) & ucBitIndex;
                    // call SOE state machine for Pv change detection and store time stamp
                    // if Pv change is detected.
                    bStoreTime = _SolveState(StMchInputBuf+(ChannelNum-1), &bLogEvent);
                    if(TRUE == bStoreTime)
                    {
                        StMchInputBuf[ChannelNum-1].EventTime = SOEHandler_EndTime;
                    }
                    // Make Pv change packet to TaskFIFO if detected by state machine. 
                    if((TRUE==bLogEvent)&&(FALSE==bEventLost))
                    {
                        // add the Packet to TaskFifo.
                        UINT8 FreeSpace=0;
                        // Mask it as TaskFifoRemPtr can be updated by STC anytime.
                        // Also STC is using TaskFifoAppPtr pointer.
                        set_imask_exr(LVLPRI_TICK);
                        if(TaskFifoAppPtr>=TaskFifoRemPtr)
                        {
                            FreeSpace=TASKFIFO_SIZE-(TaskFifoAppPtr-TaskFifoRemPtr);
                        }
                        else
                        {
                            FreeSpace = TaskFifoRemPtr-TaskFifoAppPtr;
                        }
                        if(FreeSpace>1)
                        {
                            // add the event to the TaskFIFO using task fifo append pointer
                            TaskFIFO[TaskFifoAppPtr].TaskFifoPacketType = TASKFIFO_RAWPKT;
                            TaskFIFO[TaskFifoAppPtr].stTaskFifoRawPkt.SOEslot = ChannelNum;
                            TaskFIFO[TaskFifoAppPtr].stTaskFifoRawPkt.CurrentState = 
                                StMchInputBuf[ChannelNum-1].bNew;
                            TaskFIFO[TaskFifoAppPtr].stTaskFifoRawPkt.EventTimeStamp = 
                                StMchInputBuf[ChannelNum-1].EventTime;
                            TaskFifoAppPtr++;
                            // reset the TaskFifoAppPtr
                            if(TaskFifoAppPtr>=TASKFIFO_SIZE) 
                            {
                                TaskFifoAppPtr=0;
                            }
                        }
                        else
                        {
                            // set the flag to post the lost event
                            bEventLost = TRUE;
                        }
                        set_imask_exr(LVLPRI_TASK);
                    }// log the event
                }// if point is active
                ChannelNum++;
            }// inner for loop 
        }// outer for loop
        // calculate the overurn of SOE ISR
        if(SOEHandler_StartTime > 0)
        {
            UINT32 NoClks = SOEHandler_EndTime - SOEHandler_StartTime;
            if(NoClks > SOEISROVERRNTIME)
            {
                if(NoClks > MAXUINT16) NoClks = MAXUINT16;
                StMchOvrRuns = StMchOvrRuns+1;
                StMchLstOvrRunTime = NoClks;
                if(StMchMaxOvrRunTime < StMchLstOvrRunTime)
                    StMchMaxOvrRunTime = StMchLstOvrRunTime;
            }
        }
        SOEHandler_StartTime = SOEHandler_EndTime;
        // Mask it with link as SoeIsrBufRemPtr is also used in GetSOESample
        // which can called by AppUrgent from iol ISR.
        set_imask_exr(LVLPRI_HIGHEST);
        SoeIsrBufRemPtr++;
        if(SoeIsrBufRemPtr>=SOEISRBUFSIZE)
        {
            SoeIsrBufRemPtr = 0;
        }
        set_imask_exr(LVLPRI_TASK);
    }
    return;
}
/********************************************************************************
*           clsDiBoxSlot::InitStMchInputBuf                                     *
*           ================================                                    *
* Purpose: This method initializes the STMCHINPTBUFF                            *
*                                                                               *
********************************************************************************/
VOID clsDiBoxSlot::InitStMchInputBuf(UINT8 unChannel)
{
    StMchInputBuf[unChannel].bOld = StMchInputBuf[unChannel].bNew;
    StMchInputBuf[unChannel].bLast = StMchInputBuf[unChannel].bNew;
    StMchInputBuf[unChannel].bInTransition = FALSE;
    StMchInputBuf[unChannel].unCount = 1;
    StMchInputBuf[unChannel].EventTime = 0;
}
/********************************************************************************
*           clsDiBoxSlot::InitSOEState                                          *
*           ================================                                    *
* Purpose: This method initializes the STMCHINPTBUFF with current state         *
*                                                                               *
********************************************************************************/
VOID clsDiBoxSlot::InitSOEState(UINT8 unChannel, BOOL bStateNow)
{
    StMchInputBuf[unChannel].bOld = bStateNow;
    StMchInputBuf[unChannel].bNew = bStateNow;
    StMchInputBuf[unChannel].bLast = bStateNow;
    StMchInputBuf[unChannel].bInTransition = FALSE;
    StMchInputBuf[unChannel].unCount = 1;
    StMchInputBuf[unChannel].EventTime = 0;
}
/*******************************************************************************
*                             clsDiBoxSlot::ProcessTaskfifoPacket              *
*                             ===================================              *
* PURPOSE: This routine is called to process a raw input or events lost packet *
*          from the Task FIFO.                                                 * 
* ARGUMENTS: Taskfifo Packet type as input to the method.                      *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::ProcessTaskfifoPacket()
{
    UINT8   SlotNum     = 0;
    BOOL    State       = 0;
    UINT8   ucEvtCnt    = MAX_EVENT_COUNT;//MAX_EVENT_COUNT=16
    UINT16  ComputedSyncId = 0;
    static  UINT16 LostEvtSyncId = 0;
    // process till the Tast fifo is empty or MAX_EVENT_COUNT no.of packets processed;
    while ((TaskFifoRemPtr != TaskFifoAppPtr)&&(ucEvtCnt>0))
    {
        switch(TaskFIFO[TaskFifoRemPtr].TaskFifoPacketType)
        {
        case TASKFIFO_STSPKT:
            break;
        case TASKFIFO_RAWPKT:
            SlotNum = TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.SOEslot;
            State = TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.CurrentState;
            SLOT(SlotNum)->SetRawInput(State);
            if((SLOT(SlotNum)->GetPtExecSt() == PTEXECST_ACTIVE) )
            {
                SLOT(SlotNum)->UpdateBadPv();
                //while slot is processed the ProcessPv is called to Handle the PV.
                // apply the input direction ans update the Pv
                SLOT(SlotNum)->ProcessSlot();
            }
            //post the Pv change event for this slot if 1) Event option is SOE 
            // 2) Pv source is auto 3) softfail is not present 
            if( (EVTOPT_SOE == SLOT(SlotNum)->GetEvtOpt()) &&
                    (PVSOURCE_AUTO == SLOT(SlotNum)->GetPvSource()) &&
                    (0==SLOT(SlotNum)->GetSlotSfBt()) )
            {
                // update the Pv value from the Computed PvAuto
                TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.CurrentState=
                        (BOOL)SLOT(SlotNum)->GetPvAuto();
                ComputedSyncId = CalcSyncID();
                if( 0 == SLOT(SlotNum)->GetPvChgDlyTimer() )
                {
                    BOX->PostToPVCL(EVENTPACKET_SOEPVC,ComputedSyncId);
                }
                else
                {
                    // if it is the first event after the PvChgDLy set, post this event
                    if(FALSE == SLOT(SlotNum)->GetbPvChgDlyEventSet())
                    {
                        BOX->PostToPVCL(EVENTPACKET_SOEPVC,ComputedSyncId);
                    }
                    SLOT(SlotNum)->StorePvChgDlyPacket(State,
                        TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.EventTimeStamp,ComputedSyncId);
                }
            }
            break;
        case TASKFIFO_LSTPKT:
            //post the Lost event for this slot if Event option is SOE
            BOX->PostToPVCL(EVENTPACKET_SOELOST,LostEvtSyncId);
            break;
        default:
            HardFail(HF_BADPROGRAMJUMP,DIBOXSLOT_CPP,__LINE__,
                     TaskFIFO[TaskFifoRemPtr].TaskFifoPacketType);
        }
        TaskFifoRemPtr++;
        if(TaskFifoRemPtr >= TASKFIFO_SIZE)
        {
            TaskFifoRemPtr = 0;
        }
        ucEvtCnt--;
    } // while all packets processed
    // Add the Lost Event in TaskFifo after all Raw Packets processed from TaskFifo
    if((TRUE==bEventLost)&&(TaskFifoRemPtr == TaskFifoAppPtr))
    {
        // Do not post SOELost event if all channels EVTOPT option is NONE.
        for(UINT8 ChanNum=1;ChanNum<=32;ChanNum++)
        {
            if(SLOT(ChanNum)->GetEvtOpt()) break;
            if(MAXSLOTS == ChanNum)
            {
                // Control has come till here indicates "All channels EVTOPT is NONE",
                // so return after resetting the flag.
                bEventLost = FALSE;
                return;
            }
        }
        TaskFIFO[TaskFifoAppPtr].TaskFifoPacketType = TASKFIFO_LSTPKT;
        // give the recent Raw Packet time for LostEvt, which indicates
        // that events lost from packet time to next packet posted in the TaskFIFO
        if(TaskFifoRemPtr>0)
        {
            TaskFIFO[TaskFifoAppPtr].stTaskFifoEvtLstPkt.EventTimeStamp = 
                TaskFIFO[TaskFifoRemPtr-1].stTaskFifoRawPkt.EventTimeStamp;
        }
        else
        {
            TaskFIFO[TaskFifoAppPtr].stTaskFifoEvtLstPkt.EventTimeStamp = 
                TaskFIFO[TASKFIFO_SIZE-1].stTaskFifoRawPkt.EventTimeStamp;
        }
        // increments and see for the boundary value.
        TaskFifoAppPtr++;
        if (TaskFifoAppPtr >= TASKFIFO_SIZE)//TASKFIFO_SIZE = 32 entries
        { // wrap around
            TaskFifoAppPtr = 0;
        }
        LostEvtSyncId = ComputedSyncId;
        bEventLost = FALSE;
    }
}
/*******************************************************************************
*                             clsDiBoxSlot::CalcSyncID                         *
*                             ========================                         *
* PURPOSE: This method is used to  calculate the SyncId and Time stamp for     *
*           Event present in the TaskFIFO                                      *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
*******************************************************************************/
/*
     set SyncTime = Latest sync ID Time
     set SyncID = Latest sync ID

     if SyncID is not 0 then

         Get_Current_Time ( CurrentTime )

         if SyncTime != EvtTime then

             if SyncTime > EvtTime then

                 if SyncTime <= CurrentTime or EvtTime >= CurrentTime then

                     move to preceding entry of TIMESYNC_TABLE

                 endif

             elseif EvtTime >= CurrentTime then

                 move to preceding entry of TIMESYNC_TABLE

             endif

         endif

     endif
*/
UINT16 clsDiBoxSlot::CalcSyncID(VOID)
{
    // Read the Latest SyncId and SyncTime from TimeSynchIdTbl
    UINT16  SyncId       = 0;
    UINT32  SyncTime     = 0;
    UINT32  EvtTime      = 0;
    UINT32  CurrentTime  = 0;
    BOOL    GoToPreSyncID= FALSE;
    // Take a copy of TimeSyncTblAppPtr
    UINT8   SyncTblLocalAppPtr = TimeSyncTblAppPtr;
    // Read the Latest SyncId and SyncTime from TimeSynchIdTbl
    if(SyncTblLocalAppPtr>0)
    {
        SyncId = TimeSynchtbl[SyncTblLocalAppPtr-1].TimeSynchID;
        SyncTime = TimeSynchtbl[SyncTblLocalAppPtr-1].SynchTimeStamp;
    }
    else
    {
        SyncId = TimeSynchtbl[TIMESYNCTBLSIZE-1].TimeSynchID;
        SyncTime = TimeSynchtbl[TIMESYNCTBLSIZE-1].SynchTimeStamp;
    }
    switch(TaskFIFO[TaskFifoRemPtr].TaskFifoPacketType)
    {
    case TASKFIFO_RAWPKT:
        EvtTime = TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.EventTimeStamp;
        break;
    case TASKFIFO_LSTPKT:
        EvtTime = TaskFIFO[TaskFifoRemPtr].stTaskFifoEvtLstPkt.EventTimeStamp;
        break;
    }
    // calculate the offset time from the syncId time
    if(0 != SyncId)
    {
        set_imask_exr(LVLPRI_HIGHEST);
        CurrentTime = GetFrcCount();
        set_imask_exr(LVLPRI_TICK);
        if(SyncTime != EvtTime)
        {
            if(SyncTime>EvtTime)
            {
                if((SyncTime<=CurrentTime) || (EvtTime>CurrentTime))
                {
                    GoToPreSyncID = TRUE;
                }
            }
            else if(EvtTime>CurrentTime)
            {
                GoToPreSyncID = TRUE;
            }
        }
        if(TRUE == GoToPreSyncID)
        {
            // take the previous SyncId
            if(SyncTblLocalAppPtr>1)
            {
                SyncId = TimeSynchtbl[SyncTblLocalAppPtr-2].TimeSynchID;
                SyncTime = TimeSynchtbl[SyncTblLocalAppPtr-2].SynchTimeStamp;
            }
            else if(1 == SyncTblLocalAppPtr)
            {
                SyncId = TimeSynchtbl[TIMESYNCTBLSIZE-1].TimeSynchID;
                SyncTime = TimeSynchtbl[TIMESYNCTBLSIZE-1].SynchTimeStamp;
            }
            else
            {
                SyncId = TimeSynchtbl[TIMESYNCTBLSIZE-2].TimeSynchID;
                SyncTime = TimeSynchtbl[TIMESYNCTBLSIZE-2].SynchTimeStamp;
            }
        }
    }
    // Now you go the SyncID and SyncTime. Calculate EvtTime offset.
    if(0 != SyncId)
    {
        EvtTime -= SyncTime;
    }
    else
    {
        EvtTime = 0;
    }
    // Assign the calculated event time offset to packet
    switch(TaskFIFO[TaskFifoRemPtr].TaskFifoPacketType)
    {
    case TASKFIFO_RAWPKT:
        TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.EventTimeStamp = EvtTime/EVTTIME_200uSEC_FACTOR;
        break;
    case TASKFIFO_LSTPKT:
        TaskFIFO[TaskFifoRemPtr].stTaskFifoEvtLstPkt.EventTimeStamp = EvtTime/EVTTIME_200uSEC_FACTOR;
        break;
    }
    return SyncId;
}
/*******************************************************************************
*                           clsDiBoxSlot::PostToPVCL                           *
*                           =============================                      *
* PURPOSE:     This routine is called to build and enter a packet              *
*              into the PV Change List and Regen Log                           *
* ARGUMENTS:   None                                                            *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDiBoxSlot::PostToPVCL(EVENTPACKET PvclEventPacketType,UINT16 SyncId)
{
    UINT16 FreeSpace = 0;
    BOOL IsPosted = TRUE;
    UINT32 TimeStamp = 0;
    // process the event to put in to PVCL and RegenLog.
    if(RegLogAppPtr>=RegLogRemPtr)
    {
        FreeSpace=PVCLEVTREG_SIZE-(RegLogAppPtr-RegLogRemPtr);
    }
    else
    {
        FreeSpace = RegLogRemPtr-RegLogAppPtr;
    }
    if(FreeSpace<=1)
    {
        // move the Remove Ptr so that new event will be stored
        RegLogRemPtr++;
        if(RegLogRemPtr>=PVCLEVTREG_SIZE)
        {
            RegLogRemPtr = 0;
        }
    }
    PVCLEvtRegLog[RegLogAppPtr].Qualifier = EVENTTYPE_PVCLNORMAL;
    PVCLEvtRegLog[RegLogAppPtr].TimeStampFlag = TRUE;
    if(EVENTPACKET_SOEPVC == PvclEventPacketType)
    {
        // build the PvChgPkt
        TimeStamp = TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.EventTimeStamp;
        PVCLEvtRegLog[RegLogAppPtr].EventPktType = EVENTPACKET_SOEPVC;
        PVCLEvtRegLog[RegLogAppPtr].PVCL_PVCHANGEPKT.PVCHG_PV = 
            TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.CurrentState;
        PVCLEvtRegLog[RegLogAppPtr].PVCL_PVCHANGEPKT.PVCHGSOEslot = 
            TaskFIFO[TaskFifoRemPtr].stTaskFifoRawPkt.SOEslot;
        PVCLEvtRegLog[RegLogAppPtr].PVCL_PVCHANGEPKT.SyncIDHigh = (UINT8)(SyncId>>8);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_PVCHANGEPKT.SyncIDLow = (UINT8)(SyncId);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_PVCHANGEPKT.TimeStampHigh = (UINT8)(TimeStamp>>16);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_PVCHANGEPKT.TimeStampMid = (UINT8)(TimeStamp>>8);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_PVCHANGEPKT.TimeStampLow = (UINT8)(TimeStamp);
        IsPosted = AddNrmPVCLEvent(&PVCLEvtRegLog[RegLogAppPtr]);
    }
    else
    {
        // build the Pv Lost packet
        TimeStamp = TaskFIFO[TaskFifoRemPtr].stTaskFifoEvtLstPkt.EventTimeStamp;
        PVCLEvtRegLog[RegLogAppPtr].EventPktType = EVENTPACKET_SOELOST;
        PVCLEvtRegLog[RegLogAppPtr].PVCL_EVTLOSTPKT.SOE_SyncIDHigh = (UINT8)(SyncId>>8);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_EVTLOSTPKT.SOE_SyncIDLow = (UINT8)(SyncId);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_EVTLOSTPKT.SynchTimeHigh = (UINT8)(TimeStamp>>16);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_EVTLOSTPKT.SynchTimeMid = (UINT8)(TimeStamp>>8);
        PVCLEvtRegLog[RegLogAppPtr].PVCL_EVTLOSTPKT.SynchTimeLow = (UINT8)(TimeStamp);
        IsPosted = AddNrmPVCLEvent(&PVCLEvtRegLog[RegLogAppPtr]);
    }
    // add the this packet also to pv change log used for regeneration
    if(FALSE == IsPosted)
    {
        // This Event will be retried by the EventManagerTask
        if (FALSE == bUnSent_PVCL_Pkts)
        {
            // make a note of the starting event which have not posted to PVCL.
            UnSentPkt_Ptr = RegLogAppPtr;
            bUnSent_PVCL_Pkts = TRUE;
        }
    }
    else
    {
        PVCLEvtRegLog[RegLogAppPtr].Qualifier = EVENTTYPE_PVCLRECOVERY;
    }
    RegLogAppPtr++;
    // check for pointer Boundary value;
    if(RegLogAppPtr>=PVCLEVTREG_SIZE)
    {
        RegLogAppPtr = 0;
    }
    return IsPosted;
}
/*******************************************************************************
*                             clsDiBoxSlot::PVCLEvtRegen                        *
* PURPOSE: regenerates the SOE Pv change events                                 *
* ARGUMENTS:                                                                    *
* RETURN: TRUE if all event are regened                                         *
* NOTES:                                                                        *
*******************************************************************************/
BOOL clsDiBoxSlot::PVCLEvtRegen(VOID)
{
    //do the regen context wise in order to give the chance to execute other tasks
    static  CONTEXT EvtRegContext = CONTEXT_ONE;
    static  UINT16  RemPtr = RegLogRemPtr;
    static  UINT16  AppPtr = RegLogAppPtr;
    UINT16  uCount = MAXEVNTPERCTX;
    //to prevent the EVM task from posting unsent pkts to PVCL 
    bUnSent_PVCL_Pkts = FALSE;
    switch(EvtRegContext)
    {
    case CONTEXT_ONE:
        // save the Regen log App and Rem ptrs to local variables
        AppPtr = RegLogAppPtr;
        RemPtr = RegLogRemPtr;
        // before regen, the Boundary packets has to be posted in PVCL
        UINT32 TimeStp; // used to store High and low bytes separately
        // start sending Boundary packets for all Sync IDs
        // Initially Append pointer will always be pointing to empty location,
        // so make it to point to the latest SyncID.
        RegTimeSyncTblAppPtr = RegTimeSyncTblAppPtr-1;
        while(TIMESYNCTBLSIZE > RegTimeSyncTblAppPtr)
        {
            PVCLEVTRECORD BoundryPkt;
            BoundryPkt.Qualifier = EVENTTYPE_PVCLRECOVERY;
            BoundryPkt.TimeStampFlag = TRUE;
            BoundryPkt.EventPktType = EVENTPACKET_IOLTSB;
            BoundryPkt.PVCL_BOUNDRYPKT.SOE_SyncIDHigh = 
                (UINT8)((RegTimeSynchtbl[RegTimeSyncTblAppPtr].TimeSynchID)>>8);
            BoundryPkt.PVCL_BOUNDRYPKT.SOE_SyncIDLow = 
                (UINT8)(RegTimeSynchtbl[RegTimeSyncTblAppPtr].TimeSynchID);
            TimeStp = RegTimeSynchtbl[RegTimeSyncTblAppPtr].SynchTimeStamp;
            BoundryPkt.PVCL_BOUNDRYPKT.SynchTimeHigh = (UINT8)(TimeStp>>16);
            BoundryPkt.PVCL_BOUNDRYPKT.SynchTimeMid = (UINT8)(TimeStp>>8);
            BoundryPkt.PVCL_BOUNDRYPKT.SynchTimeLow = (UINT8)(TimeStp);
            BOOL bSuccess = AddNrmPVCLEvent(&BoundryPkt);
            if (FALSE == bSuccess)
            {
                // if not added successfully due to PVCL overflow, try again
                return FALSE;
            }
            else
            {
                RegTimeSyncTblAppPtr--;
            }
            if(AppPtr == RemPtr)
            {
                // if there are no events for regeneration, then send only one Boundary
                // packet with latest sync ID
                return TRUE;
            }
        }
        EvtRegContext = CONTEXT_TWO;
        break;
    case CONTEXT_TWO:
        // post MAXEVNTPERCTX no.of events or till PVCLEvtRegLog is empty
        while( (RemPtr != AppPtr) && (0 != uCount) )
        {
            BOOL bSuccess = AddNrmPVCLEvent(&PVCLEvtRegLog[RemPtr]);
            if (FALSE == bSuccess)
            {
                // if not added successfully due to PVCL overflow, try again
                return FALSE;
            }
            RemPtr++;
            if(RemPtr>=PVCLEVTREG_SIZE)
            {
                RemPtr = 0;
            }
            uCount--;
        }
        // come again to post the remaining pkts from Regen log if still pkts left
        if((0 == uCount)&&(AppPtr != RemPtr))
        {
            return FALSE;
        }
        if(AppPtr == RemPtr)
        {
            // intialize the pointers for next regen
            EvtRegContext = CONTEXT_ONE;
            return TRUE;
        }
        break;
    default:
        HardFail(HF_BADPROGRAMJUMP,DIBOXSLOT_CPP,__LINE__,EvtRegContext);
    }
    return FALSE;
}
/*******************************************************************************
*                             clsDiBoxSlot::UpdateTimeSyncId                    *
*                             ===============================                   *
* PURPOSE:                                                                      *
* ARGUMENTS:                                                                    *
* RETURN:                                                                       *
* NOTES:                                                                        *
*******************************************************************************/
// Update syncId received from the IOLINK command .
VOID clsDiBoxSlot::UpdateTimeSyncId(UINT16 uiSynchId)
{
    if(TimeSyncTblRemPtr>TimeSyncTblAppPtr)
    {
        // move the TimeSyncTblRemPtr forward by one position so  that new Sync Id sits there
        TimeSyncTblRemPtr++;// Removing oldest sync id.
        if (TimeSyncTblRemPtr >= TIMESYNCTBLSIZE) 
        { // wrap around
            TimeSyncTblRemPtr = 0;
        }
    }
    TimeSynchtbl[TimeSyncTblAppPtr].TimeSynchID = uiSynchId;
    TimeSynchtbl[TimeSyncTblAppPtr].SynchTimeStamp = GetFrcCount();
    TimeSyncTblAppPtr++;
    if (TimeSyncTblAppPtr >= TIMESYNCTBLSIZE) 
    { // wrap around
        TimeSyncTblAppPtr = 0;
        //Removing oldest sync id.
        TimeSyncTblRemPtr++;
    }
}
/*******************************************************************************
*                             clsDiBoxSlot::Prepare_For_Regen                  *
*                             ===============================                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDiBoxSlot::Prepare_For_Regen(VOID)
{
    // If a regen is already in progress, this routine exits.  Otherwise, if
    // the PV Change Log is not frozen, it is frozen, and the receiving syncs counter
    // is set to the unfreeze constant of 20 seconds.  If a regen expected flag is not 
    // set, the Timesync Table is saved, and the regen expected flag is set.
    if (FALSE == PVCLEvtRegInProgress)
    {
        if (FALSE == bLog_Frozen)
        {
            bLog_Frozen = TRUE;
            ucReceiving_SyncCnt = STCTWENTYSECCNT;
            TraceLog.AddToTrace(TRACEID_GENERIC,bcLogFrozen);
        }
        if (FALSE == bRegen_Expected)
        {
            // copy the sync Id table.This routine is written here to avoid
            // a function call to CopySyncTbl from  STC ISR 
            UINT8 IdxPtr = TimeSyncTblRemPtr;
            // initialize the pointers
            RegTimeSyncTblAppPtr = 0;
            while(IdxPtr != TimeSyncTblAppPtr)
            {
                RegTimeSynchtbl[RegTimeSyncTblAppPtr].TimeSynchID = 
                    TimeSynchtbl[IdxPtr].TimeSynchID;
                RegTimeSynchtbl[RegTimeSyncTblAppPtr].SynchTimeStamp = 
                    TimeSynchtbl[IdxPtr].SynchTimeStamp;
                RegTimeSyncTblAppPtr++;
                IdxPtr++;
                if (IdxPtr >= TIMESYNCTBLSIZE) 
                { // wrap around
                    IdxPtr = 0;
                }
            }
            bRegen_Expected = TRUE;
        }
    }
    return;
}
/*******************************************************************************
*                             clsDiBoxSlot::CopySyncTbl                        *
*                             ===============================                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: This function is called before start of regen                         *
*******************************************************************************/
VOID clsDiBoxSlot::CopySyncTbl(VOID)
{
    // copy the sync id table in the order old->new
    UINT8 IdxPtr = TimeSyncTblRemPtr;
    // initialize the pointers
    RegTimeSyncTblAppPtr = 0;
    while(IdxPtr != TimeSyncTblAppPtr)
    {
        RegTimeSynchtbl[RegTimeSyncTblAppPtr].TimeSynchID = 
            TimeSynchtbl[IdxPtr].TimeSynchID;
        RegTimeSynchtbl[RegTimeSyncTblAppPtr].SynchTimeStamp = 
            TimeSynchtbl[IdxPtr].SynchTimeStamp;
        RegTimeSyncTblAppPtr++;
        IdxPtr++;
        if (IdxPtr >= TIMESYNCTBLSIZE) 
        { // wrap around
            IdxPtr = 0;
        }
    }
}
/*******************************************************************************
*                             clsDiBoxSlot::Restore_Unsent_Pkts                *
*                             ===============================                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsDiBoxSlot::Restore_Unsent_Pkts()
{
    // If the bUnSent_PVCL_Pkts flag is not set, this routine exits.
    // Otherwise, this function restores the packets to PVCL.The AddPVCLEvent( ) 
    // is called to add the packet to the PVCL.If the entry was not successful,
    // the ucSuspendTime is set to one-half second, to allow
    // the C300 Event Collector Task to read the PV Change Circular List, and the
    // loop is exited.  If the entry was successful, or if the packet was skipped,
    // the UnSentPkt_Ptr is updated to the next packet.  If eight packets have been
    // processed, or all packets in the PV Change Log have been processed, the loop
    // exits.  If only eight packets were processed, the ucSuspendTime is set to ten
    // milliseconds, to allow higher-priority tasks to run.If all unsent packets 
    // have been entered successfully, the bUnSent_PVCL_Pkts flag is set false.
    UINT8 ucSuspendTime = TWO_SEC_SUSPEND;
    if (TRUE == bUnSent_PVCL_Pkts)
    {
        UINT8 Pkt_Count = MAX_UNSENT;//MAX_UNSENT = 8
        while((UnSentPkt_Ptr != RegLogAppPtr) && (0 != Pkt_Count))
        {
            if(EVENTTYPE_PVCLNORMAL == PVCLEvtRegLog[UnSentPkt_Ptr].Qualifier)
            {
                BOOL bSuccess = AddNrmPVCLEvent(&PVCLEvtRegLog[UnSentPkt_Ptr]);
                if (FALSE == bSuccess)
                {
                    // if not added success fully due to PVCL overflow, try again
                    ucSuspendTime   = HALF_SEC_SUSPEND;
                    return ucSuspendTime;
                }
                else
                {
                    PVCLEvtRegLog[UnSentPkt_Ptr].Qualifier = EVENTTYPE_PVCLRECOVERY;
                }
            } // un sent packet
            UnSentPkt_Ptr++;
            //Checking for wrap of UnSentPkt_Ptr in RegenLog
            if(UnSentPkt_Ptr>=PVCLEVTREG_SIZE)
            {
                UnSentPkt_Ptr = 0;
            }
            Pkt_Count--;
        }
        if(0 == Pkt_Count)
        {
            //If there are still some more pkts left
            ucSuspendTime   = TEN_MS_SUSPEND;
        }
        if(UnSentPkt_Ptr == RegLogAppPtr)
        {
            bUnSent_PVCL_Pkts = FALSE;
        }
    }
    return ucSuspendTime;
}
/*******************************************************************************
*                             clsDiBoxSlot::Discard_Old_Pkts                   *
*                             ===============================                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsDiBoxSlot::Discard_Old_Pkts(UINT8 ucSuspendTime)
{
    // The PV Change Log is searched for packets with a sync ID which differ
    // from the discard sync ID by 11 or more (i.e. > 20 seconds old). The packets are 
    // deleted by updating the remove pointer.The loop exits when 1) the entire log   
    // has been searched, 2) twenty-four packets have been deleted,   
    // or 3) a packet is found that is not to be deleted.  If the loop exits
    // due to the twenty-four packet limitation, the SUSPEND_TIME is set to cause
    // a ten millisecond task delay,to allow any higher-priority tasks to run 
    UINT16 Discard_ptr = RegLogRemPtr;
    UINT16 LatestSyncID = 0;
    UINT16 PktSynID     = 0;
    UINT16 SyncDiff     = 0;
    if( (FALSE == bLog_Frozen) && (RegLogRemPtr != RegLogAppPtr) )
    {
        UINT8 Pkt_Count = MAX_DISCARD; //MAX_DISCARD = 24
        if(TimeSyncTblAppPtr>0)
        {
            LatestSyncID = TimeSynchtbl[TimeSyncTblAppPtr-1].TimeSynchID;
        }
        else
        {
            LatestSyncID = TimeSynchtbl[TIMESYNCTBLSIZE-1].TimeSynchID;
        }
        while( (Discard_ptr != RegLogAppPtr)&&(Pkt_Count!=0))
        {
            if(EVENTPACKET_SOEPVC == PVCLEvtRegLog[Discard_ptr].EventPktType)
            {
                PktSynID = (((UINT16)PVCLEvtRegLog[Discard_ptr].PVCL_PVCHANGEPKT.SyncIDHigh)<<8) |
                    ((UINT16)PVCLEvtRegLog[Discard_ptr].PVCL_PVCHANGEPKT.SyncIDLow);
            }
            else //LOST EVENT Packet type
            {
                PktSynID = (((UINT16)PVCLEvtRegLog[Discard_ptr].PVCL_EVTLOSTPKT.SOE_SyncIDHigh)<<8) |
                    ((UINT16)PVCLEvtRegLog[Discard_ptr].PVCL_EVTLOSTPKT.SOE_SyncIDLow);
            }
            // To check if the C300 controller synId is not wrapped around
            if (PktSynID <= LatestSyncID)
            {
                SyncDiff = LatestSyncID - PktSynID;
            }
            else
            {
                SyncDiff = (MAXUINT16-PktSynID) + LatestSyncID + 1;
            }
            if(SyncDiff <= SYNC_DIFFERENCE)
            {
                //If pkt is not older than 20sec ,do not discard
                // set the remove pointer to this location as from this onwards all
                // are not older than 20sec
                RegLogRemPtr = Discard_ptr;
                return ucSuspendTime;
            }
            else //packet is older than 20sec w.r.t to latest sync id.
            {
                Discard_ptr++;
                if(Discard_ptr>=PVCLEVTREG_SIZE)
                {
                    Discard_ptr = 0;
                }
            }
            Pkt_Count--;
        }// while
        if(0 == Pkt_Count) //Max pkts processed but there are pkts left to be processed
        {
            ucSuspendTime = TEN_MS_SUSPEND;
        }
        // update the RegLogRemPtr with the new location
        RegLogRemPtr = Discard_ptr;
    }
    return ucSuspendTime;
}
#endif
