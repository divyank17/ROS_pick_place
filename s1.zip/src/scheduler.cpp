/******************************************************************************
*                                                                             *
*                              COPYRIGHT (C) 2004                             *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                *
*                              ALL RIGHTS RESERVED                            *
*                                                                             *
*   This software is a copyrighted work and / or information protected as a   *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct*
*   from ownership of any medium in which the software is embodied. Copyright *
*   or trade secret notices included must be reproduced in any copies that are*
*   authorized by Honeywell Inc.                                              *
*                                                                             *
*   The information in this software is subject to change without notice and  *
*   should not be considered as a commitment by Honeywell Inc.                *
*                                                                             *
* ============================================================================*
*    File Name   : scheduler.cpp                                              *
*    Description : Definitions and constants of  scheduler                    *
******************************************************************************/
/******************************************************************************
*                               INCLUDE FILES                                 *
******************************************************************************/
#include "tracelog.hpp"
#include "debug.hpp"
#include "scheduler.hpp"
#include "boxslot.hpp"
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;
extern BOOL FactryModeWDTUTest;
extern BOOL HWRevCodeWriteInProgress;
extern UINT16 g_usWdtTestTimer[2];
#ifdef DEBUG
extern UINT8 g_ChangeWdtRefreshTime;
#endif

/*******************************************************************************
*                                EXTERNAL FUNCTIONS                            *
*******************************************************************************/
extern "C" BOOL _TestRAMCell(UINT32);
/******************************************************************************
*                 clsTaskScheduler::clsTaskScheduler                          *
*                 ==================================                          *
* PURPOSE:                                                                    * 
*    The constructor for Scheduler class                                      * 
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
clsTaskScheduler::clsTaskScheduler(VOID)
{
    // Initialize scheduler timer
    MSTPCR_TPU      = 0;
    TPU5_TCR        = 0x21; // Divide/4 clock, rising edge, clear TCNT on TGRA match.
    TPU5_TMDR       = 0xC0; // TPU5 normal mode operation
    TPU5_TIER       = 0x01; // TGIEA interrupt enabled with TGRA match
    TPU5_TGRA       = TPUCOUNT_MAXVALUE; // Seed TGRA for 10 msec interrupt.
    IPRI_TICK       = LVLPRI_TICK;       // Set STC interrupt priority level

    // Initialize data members
    m_ul10msCounter         = 0;
    m_ulLast10msCounter     = 0;
    m_ucWdtRefreshCounter   = 0;
    m_uiWdtDiagCounter      = 0;
    m_WdtDiagState          = WDTDIAG_RESET;
    m_bWdtEnabled           = FALSE;
    m_ucActiveTask          = 0;
    m_usTaskActivationBits  = 0;
    m_ucDelayedTaskCount    = 0;
    m_bOneSecondTimerFlag   = FALSE;
    m_ulCpuFreeTimeCounter  = 0;
    m_ucStatResetCounter    = 0;
    m_ucStcOverrunCount     = 0;
    // Customer (-MiRO) Issue(-CL Fail) Fix - Write request counter init
    m_usWriteReqCount       = 0;

    for (UINT8 ucTask=0 ; ucTask < TASKCOUNT; ucTask++)
    {
        // Initialize Periodic table
        m_PeriodicTable[ucTask].usDownCounter   = 0;
        m_PeriodicTable[ucTask].usPeriod        = 0;
        // Initialize Suspended table
        m_DelaySuspendTable[ucTask].usDownCounter   = 0;
        m_DelaySuspendTable[ucTask].TaskContext     = TASKCONTEXT_ZERO;
        // Initiaize task status to sleep state and ReRequest counter to zero
        m_TaskStatus[ucTask].TaskState          = TASKSTATE_ASLEEP;
        m_TaskStatus[ucTask].ucRequestCounter   = 0;
        // Initialize DMC table
        m_DmcTable[ucTask].usLifespan           = 0;
        m_DmcTable[ucTask].usCurrentLife        = 0;
    }

#ifdef DEBUG
    uiMaxStcLatency = 0;
#endif
}

/******************************************************************************
*                 clsTaskScheduler::InitPeriodicTask                          *
*                 ==================================                          *
* PURPOSE:                                                                    * 
*    The method initializes the periodic table structure                      * 
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID clsTaskScheduler::InitPeriodicTask(UINT8 a_ucTaskId, UINT16 a_usPeriod,
                                        UINT16 a_usLifeSpan)
{
    m_PeriodicTable[a_ucTaskId - 1].usPeriod      = a_usPeriod / SCHEDULER_PERIOD;
    m_PeriodicTable[a_ucTaskId - 1].usDownCounter = a_usPeriod / SCHEDULER_PERIOD;
    m_DmcTable[a_ucTaskId - 1].usLifespan         = a_usLifeSpan / SCHEDULER_PERIOD; 
    m_DmcTable[a_ucTaskId - 1].usCurrentLife      = a_usLifeSpan / SCHEDULER_PERIOD; 
}

/******************************************************************************
*                 clsTaskScheduler::RunTask                                   *
*                 =========================                                   *
* PURPOSE:                                                                    * 
*    Sets the Task activation bit based on the task number                    * 
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID clsTaskScheduler::RunTask(UINT8 a_ucTaskId)
{
    UINT16 usMask = (0x0001 << (a_ucTaskId - 1));
    // Protect the access of task activation bits from 
    // STC ISR since the access is not atomic and the 
    // same data is accessed in STC ISR.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    m_usTaskActivationBits |= usMask;

    // Customer (MiRO) Issue(CL Fail) Fix - counter increment if write requests arrives into the buffer
    if (TASKID_WRDBTASK == a_ucTaskId) {

        m_usWriteReqCount += 1;
    }

    set_imask_exr(ucSaveExr);
}

/******************************************************************************
*                     clsTaskScheduler::RefreshTaskDMC                        *
*                     ================================                        *
* PURPOSE:                                                                    * 
*    Method refreshing periodic Task's DMC cell                               * 
* ARGUMENTS:                                                                  * 
*   UINT8 a_ucTaskId : Task ID of the calling task.                           *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
******************************************************************************/
VOID clsTaskScheduler::RefreshTaskDmc(UINT8 a_ucTaskId) {
    m_DmcTable[a_ucTaskId - 1].usCurrentLife = 
                                         m_DmcTable[a_ucTaskId - 1].usLifespan;
}
/******************************************************************************
*                 clsTaskScheduler::ExecuteTaskScheduler                      *
*                 ======================================                      *
* PURPOSE:                                                                    * 
*    Main Task Scheduler Exeutive Method                                      * 
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID clsTaskScheduler::ExecuteTaskScheduler(VOID)
{
    UINT8   ucTask;
    UINT16  usTimeDifference,usMask = 0;
    UINT8   ucActiveTaskIndex = 0;

    BOX->AppInitialization();      // Call IOM specific initializion.
    TraceLog.AddToTrace(TRACEID_GENERIC,bcAppInitComplete);

    IRQ1_STATUS = DISABLE;         // Clear the IRQ1 status flag
    IRQ1_ENABLE = ENABLE;          // Enable IRQ1 (CPLD interrupt).

#if defined(IOMTYPE_UIO)
    // Set up IRQ3 for UART and SPI
    // NOTE: Currently, SPI cannot cause an interrupt.
    IRQ3_STATUS = DISABLE;
    IRQ3_ENABLE = ENABLE;
#endif

#if !defined(DEBUG)
    // Disable all interrupt to start STC and watchdog timer together
    // so that both timers remain in sync for the life of execution.
    set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts

#if (defined(IOMTYPE_SP) || defined(IOMTYPE_SVP))
    if (!(BOX->CheckForFactoryTestMode()))
    {// Don't enable watchdog if we are in Factory mode. otherwise this will cause 
     // board reset while test is going on
        EnableWatchdog();
    }
#else
        EnableWatchdog();
#endif

    TPU5_CST    = 1;               // Start the STC timer
    set_imask_exr(0);              // Enable all interrupts
    TraceLog.AddToTrace(TRACEID_GENERIC,bcWDTEnabled);
#else
    TPU5_CST = 1;                  // Start the STC timer
#endif
    TPU3_CST = 1;                  // Start the Status LED blink timer  

    // Hit WDT first time (optional). Next will be after 100 msec
    WDTRFS_n = 0;
    WDTRFS_n = 1;

#if defined(PMIO_DEBUG) && (0)
    ucDbgCnt = 0;
    ucDbgPnt = 0;
    uiDbgPnt1 = 0;
    uiDbgPnt2 = 0;
    ucDbgFlag = 0;
    
    xRamRead(0x5001, &ucDbgPnt, 1); uiDbgPnt1 = (UINT16)(ucDbgPnt);
	xRamRead(0x5002, &ucDbgPnt, 1); uiDbgPnt2 = (UINT16)(ucDbgPnt);

    //xRamRead(0x5002, &ucDbgPnt, 1); uiDbgPnt2 = (UINT16)(ucDbgPnt * uiDbgPnt1);
    //xRamRead(0x5003, &ucDbgPnt, 1); uiDbgPnt3 = (UINT16)(ucDbgPnt);
    //xRamRead(0x5004, &ucDbgPnt, 1); uiDbgPnt4 = (UINT16)(ucDbgPnt * uiDbgPnt3);
    //xRamRead(0x5005, &ucDbgPnt, 1); uiDbgPnt5 = (UINT16)(ucDbgPnt);
    //xRamRead(0x5006, &ucDbgPnt, 1); uiDbgPnt6 = (UINT16)(ucDbgPnt * uiDbgPnt5);
    //xRamRead(0x5007, &ucDbgPnt, 1); uiDbgPnt7 = (UINT16)(10 * ucDbgPnt);
    //xRamRead(0x5008, &ucDbgPnt, 1); uiDbgPnt8 = (UINT16)(10 * ucDbgPnt);

    xRamRead(0x5000, &ucDbgPnt, 1);
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nDP: %02x", ucDbgPnt));
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nDP1: %d\r\nDP2: %d", uiDbgPnt1, uiDbgPnt2));    
	//while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nDP3: %d DP4: %d", uiDbgPnt3, uiDbgPnt4));
	//while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nDP5: %d DP6: %d", uiDbgPnt5, uiDbgPnt6));
#endif

    Iol.Enable();                  // Start the IOL Interface
    TraceLog.AddToTrace(TRACEID_GENERIC,bcIOLEnable);

    BOX->DoAliveToIdleChange();    // Change module status to IDLE.
    TraceLog.AddToTrace(TRACEID_GENERIC,bcAliveToIdle);

#if !defined(IOPTYPE_SCIOM)    
    // modified for FCT testing (FACTORY TEST - TEST#1, SUBTEST#4)
    if (!(BOX->CheckForFactoryTestMode()))
    {
        // Retriving box slot checkpoint restoration from xRAM
        // this should be here, i.e., after module status changed to IDLE, 
        // cause: If the module restarted in RUN state, it may come up status PWR (STS: POWER ON) in module status native window
        // also not able to restore the database which will show INVLD ST error.
        BOX->PmioCheckPointRestore();
    }
    else
    {
        UINT8 ucFillByte = 0xFF;

        xRamWrite(xRAM_CHKPNT_ADRS, &ucFillByte, xRAM_CHKPNT_BLOCK);
	}
#endif

    while(TRUE) {
        if (m_ul10msCounter != m_ulLast10msCounter) {
            // Check if the Current Value of clock > last execution time
            if (m_ul10msCounter > m_ulLast10msCounter) {
                usTimeDifference = (UINT16)(m_ul10msCounter - 
                                            m_ulLast10msCounter);
            }
            else {
                // Check for Overflow and calculate accordingly 
                usTimeDifference = (UINT16)(MAXUINT32 - m_ulLast10msCounter +
                                                        m_ul10msCounter + 1);
            }

            static UINT16 susMaxTimeDifference = 1;
            static UINT16 susTimeDifferenceCount = 0;
            if ( usTimeDifference > 1 ) susTimeDifferenceCount++;
            // Log the time difference only if it is greater than previous maximum.
            if ( usTimeDifference > susMaxTimeDifference ) {
                susMaxTimeDifference = usTimeDifference;
                TraceLog.AddToTrace(TRACEID_GENERIC,bcSchedulerDelay,
                (UINT32)(((UINT32)susMaxTimeDifference << WORDSIZE) | susTimeDifferenceCount));
            }

            m_ulLast10msCounter = m_ul10msCounter;
        }

        // Block the timer ISR while processing task activation bits.
        set_imask_exr(LVLPRI_TICK); 

        // Process Task Activation Bits
        for (ucTask = 0; ucTask < TASKCOUNT; ucTask++) {
            usMask = 0x0001 << ucTask;
            // Protect the access of task activation bits from 
            // STC ISR since the access is not atomic and the 
            // same data is accessed in STC ISR.
            set_imask_exr(LVLPRI_TICK);
            if(m_usTaskActivationBits & usMask) {
                switch (m_TaskStatus[ucTask].TaskState) {
                    case TASKSTATE_ASLEEP:
                        m_TaskStatus[ucTask].TaskState = TASKSTATE_READYTORUN;
                        break;
                    case TASKSTATE_READYTORUN:
                    case TASKSTATE_WAITING:
                    case TASKSTATE_READYTORESUME:
                        m_TaskStatus[ucTask].ucRequestCounter++;
                        // If the task could not be scheduled even after
                        // MAX_TASKREQ_COUNT attempts, raise a softfail.
                        if(MAX_TASKREQ_COUNT == m_TaskStatus[ucTask].ucRequestCounter) {
                            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REQOFLOW,TRUE,0);
                        }
                        break;
                    // Customer(-MiRO) Issue(-CL Fail & EHPM Crash due to HLAI IOL Comm Error) fix
                    default:
                        m_DelaySuspendTable[ucTask].usDownCounter = 0;
                        m_DelaySuspendTable[ucTask].TaskContext   = TASKCONTEXT_ZERO;
                        m_TaskStatus[ucTask].TaskState            = TASKSTATE_READYTORUN;
                        m_TaskStatus[ucTask].ucRequestCounter     = 0;
                        break;
                } // end of switch
                
                // Customer (-MiRO) Issue (-CL Fail) fix - Counter decrement if write request has been addressed
                if (TASKID_WRDBTASK == (ucTask + 1)) // only write database task
                {
                    if (m_usWriteReqCount > 0)
                        m_usWriteReqCount -= 1;
                }
                // Reset Task activatioon bit
                m_usTaskActivationBits &= ~usMask;
            } // Task activation bit check
            set_imask_exr(LVLPRI_TASK);
        } // End of for loop
        
        // Find Ready Task with highest priority
        for (ucTask = 0; ucTask < TASKCOUNT; ucTask++) {
            if((TASKSTATE_READYTORUN == m_TaskStatus[ucTask].TaskState) ||
                (TASKSTATE_READYTORESUME == m_TaskStatus[ucTask].TaskState)) {
                m_ucActiveTask = ucTask + 1;  // Set task to be scheduled.
                break;
            } // Task state either in Ready to Run state or Ready to Resume state
        } // End of Find Ready Tasks for loop

        // Restore original priority after updating active task.
        set_imask_exr(LVLPRI_TASK); 

#ifdef DEBUG
        if (g_ucCpuFreeTestIndex > 0) { // Test for finding maximum value of
            // CPU free running counter is commanded. Do not schedule any tasks 
            // for the duration of this test.
            m_ucActiveTask = 0;
            if (CPUFREE_TESTCOUNT ==  g_ucCpuFreeTestIndex) { 
                // Test just starting - disable everything except scheduler and STC.
                #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
                if(FALSE == IsFpgaS2) // S3 FPGA
                {
                    P_INTC.IPRK.BIT.LOW  = 0;
                }
                else //if(TRUE = IsFpgaS2)
                #endif
                {
                    IPRI_IOL   = 0;
                }
                IPRI_GHO   = 0;
                IPRI_TICK  = LVLPRI_HIGHEST;
                set_imask_exr(LVLPRI_HIGHEST - 1);
            }
        }
#endif

        // Schedule the task if any
        if(m_ucActiveTask > 0) {
            ucActiveTaskIndex = m_ucActiveTask - 1;

            TASKRETURN TaskReturnValue;
            // If task is in Ready to Resume state set the task state of run state
            if(TASKSTATE_READYTORESUME == m_TaskStatus[ucActiveTaskIndex].TaskState) {
                m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_RUNNING;
                // Assign task execution function
                TaskReturnValue = m_TaskDefinitionTable[ucActiveTaskIndex].TaskFunctionPtr(
                                        m_DelaySuspendTable[ucActiveTaskIndex].TaskContext);
            }
            else { // Task is ready to Run State
                m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_RUNNING;
                // Assign task execution function
                TaskReturnValue = 
                    m_TaskDefinitionTable[ucActiveTaskIndex].TaskFunctionPtr(TASKCONTEXT_ZERO);
            }

            // Process the return value of the function
            if(TASKRETURNSTATE_SUSPEND == TaskReturnValue.TaskReturnState) {

                // Customer(-MiRO) Issue(-CL Fail & EHPM Crash due to HLAI IOL Comm Error) fix
                // Block the timer ISR while processing task activation bits.
                set_imask_exr(LVLPRI_TICK);

                // If the task return state was suspend,set the task state to wait state
                m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_WAITING;
                if (TPU5_TCNT >= TPUCOUNT_HALFVALUE) {  // Compensate for current TPU count value.
                    TaskReturnValue.ucSuspendTime++;
                }
                m_DelaySuspendTable[ucActiveTaskIndex].usDownCounter = TaskReturnValue.ucSuspendTime;
                m_DelaySuspendTable[ucActiveTaskIndex].TaskContext = TaskReturnValue.TaskContext;
                m_ucDelayedTaskCount++;

                // Customer(-MiRO) Issue(-CL Fail & EHPM Crash due to HLAI IOL Comm Error) fix
                // Block the timer ISR while processing task activation bits.
                set_imask_exr(LVLPRI_TASK);
            }
            else { // Check the ReRequest counter,if its zero set task state to sleep state
                if (0 == m_TaskStatus[ucActiveTaskIndex].ucRequestCounter) {
                    m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_ASLEEP;
                    // Return request overflow softfail if any.
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REQOFLOW,FALSE,0);
                }
                else {
                    // Decrement ReRequest counter & set task to ReadytoRun
                    m_TaskStatus[ucActiveTaskIndex].ucRequestCounter--;
                    m_TaskStatus[ucActiveTaskIndex].TaskState = TASKSTATE_READYTORUN;
                }
            }

            m_ucActiveTask = 0;

            // Check the stack top pattern for any overuse by the task just executed.
            if (STACKTESTPATTERN != (*(STACK_TOP))) {
               HardFail(HF_STACKOVERRURN,SCHEDULER_CPP,__LINE__);
            }
            else {
                // Post SF_STCKLIM if stack usage went above softfail limit level
                volatile UINT8 *ucpStack = (volatile UINT8 *)(STACK_TOP + 1);
                while (*ucpStack++ == 0xFF);
                if (((UINT32)ucpStack - (UINT32)STACK_TOP) < (UINT32)STACK_SFLIMIT) {
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_STCKLIM,TRUE,0);
                }
                else {
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_STCKLIM,FALSE,0);
                }
            }
        } // Active task > 0
#ifdef IOMTYPE_DISOE
        // process PVs and post state change events to TaskFIFO of diboxslot class.
        BOX->ProcessForPvChgEvt();
#endif


#ifdef IOMTYPE_SP
        BOX->ProcessIOChannels();
#endif
        if (FALSE == m_bOneSecondTimerFlag) {
            // Increment the free running counter.
            m_ulCpuFreeTimeCounter++;
        }
        else { // One second timer expired. Calculate the CPU free percentage.
#ifdef DEBUG
            if (g_ucCpuFreeTestIndex > 0) { // Record CPU free counter
                g_ucCpuFreeTestIndex--;
                g_ulCpuFreeTestCounts[g_ucCpuFreeTestIndex] = m_ulCpuFreeTimeCounter;
                if (0 == g_ucCpuFreeTestIndex) { // Test is complete now.
                    // Restore normal interrupt priorities.
                    IPRI_TICK = LVLPRI_TICK;
                    IPRI_GHO  = LVLPRI_GHO; 
                    #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
                    if(FALSE == IsFpgaS2) // S3 FPGA
                    {
                        P_INTC.IPRK.BIT.LOW  = LVLPRI_IOL;
                    }
                    else //if(TRUE = IsFpgaS2)
                    #endif
                    {
                        IPRI_IOL  = LVLPRI_IOL;
                    }
                    set_imask_exr(0);
                }
            }
#endif

            FLOAT32 fCpuFree = ((FLOAT32)m_ulCpuFreeTimeCounter * (FLOAT32)100.0) / 
                                (FLOAT32)MAX_CPUFREE_COUNT;
            m_bOneSecondTimerFlag  = FALSE;
            m_ulCpuFreeTimeCounter = 0;
            
            if (m_ucStatResetCounter > 0) {
                m_ucStatResetCounter--;
            }
            else {
                // At least 5 seconds passed after the last request
                // to reset CPU statistics. Update the box database.
#if (defined (IOMTYPE_SP) || defined(IOMTYPE_SVP))
                 
                 BOX->SetIolProcCpuFreeAvg(fCpuFree);
                 if (fCpuFree < BOX->GetIolProcCpuFreeMin()) 
                 {
                     BOX->SetIolProcCpuFreeMin(fCpuFree);
                 }
                 if (fCpuFree > BOX->GetIolProcCpuFreeMax()) 
                 {
                     BOX->SetIolProcCpuFreeMax(fCpuFree);
                 }
#else

                BOX->SetCpuFreeAvg(fCpuFree);
                if (fCpuFree < BOX->GetCpuFreeMin()) {
                    BOX->SetCpuFreeMin(fCpuFree);
                }
#endif
            }
        }                
    } // End of while loop 
} // clsTaskScheduler::ExecuteTaskScheduler

/******************************************************************************
*                  clsTaskScheduler::STCInterruptHandler                      *
*                  ====================================                       *
* PURPOSE:                                                                    * 
*    TPU(Timer Pulse Unit) interrupt service routine,uses channel 5           *  
*    in overflow mode                                                         * 
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID clsTaskScheduler::STCInterruptHandler(VOID) 
{
    TPU5_TGFA = 0; // Acknowledge the compare match interrupt

    #ifdef DEBUG
    UINT16 TpuCount = TPU5_TCNT;
    if (TaskScheduler.uiMaxStcLatency < TpuCount) {
        TaskScheduler.uiMaxStcLatency = TpuCount / TPUCOUNT_IN_MICROSECOND;
    }
    #endif

    // Check for any overRun of the STC.
    if (TPU5_TCNT > TPUCOUNT_STCOVERRUN) TaskScheduler.m_ucStcOverrunCount++;
    else if (TaskScheduler.m_ucStcOverrunCount > 0) TaskScheduler.m_ucStcOverrunCount--;

    if (MAX_STCOVERRUN_COUNT <= TaskScheduler.m_ucStcOverrunCount){ 
        TaskScheduler.m_ucStcOverrunCount = MAX_STCOVERRUN_COUNT;
        // Post STC overrun softfail event if redundancy syncing is not in progress
        if (BOX->GetRedState() <= REDSTATE_SYNCD) {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_STCOVRUN,TRUE,0);
        }
    }
    else { // Clear STC overrun soft fail.
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_STCOVRUN,FALSE,0);
    }    

    TaskScheduler.m_ul10msCounter++;
    BOX->SetTraceTime(); // Update Tracelog time counter.

#ifndef DEBUG
#if (!defined(IOMTYPE_SVP) && !defined(IOMTYPE_SP))
    #if !defined(IOMTYPE_UIO) // UIO refreshes watchdog every 10 msec
    if (TaskScheduler.m_ucWdtRefreshCounter > STCTICKS_60MILLISEC) {
    #endif
        // It is time to do a WDT refresh for modules that support non-windowed watchdog.
        // NOTE: WDT refresh period for module with non-windowed watchdog will be equal to 
        // (STCTICKS_60MILLISEC + 2) * SCHEDULER_PERIOD = (6 + 2) * 10 = 80 msec.
        // Check whether the module supports WDT diagnostics or not. This support got
        // implemented in RevF CPLD for DI, RevE CPLD for DO and RevC FPGA for analogs.
        // NOTE that RevP is the prototype version for digitals which should be excluded.
        #if (defined(IOMTYPE_DI))
        // If CPLD revision is greater than A, then check for product code, it should not be in Series C range
        // If CPLD revision is greater than or equal to A, then check for product code, it should be in Series 8 range
        if (((BOX->GetPld1RevLetter() > PD_REV_E) && (BOX->GetPld1RevLetter() != PD_REV_P) && 
            (BOX->GetProductCode() != PRODCODE_DI_24V_LC) && (PRODCODE_DI_24V_LC_S8 != BOX->GetProductCode())) || 
            ((BOX->GetPld1RevLetter() >= PD_REV_A) && ((BOX->GetProductCode() == PRODCODE_DI_24V_LC) || 
            (BOX->GetProductCode() == PRODCODE_DI_24V_LC_S8)))) {
        #elif (defined(IOMTYPE_DISOE))
        if ((BOX->GetPld1RevLetter() >= PD_REV_A)) {
        #elif (defined(IOMTYPE_DO))
        if ((BOX->GetPld1RevLetter() > PD_REV_D) && (BOX->GetPld1RevLetter() != PD_REV_P)) {
        #elif (defined IOMTYPE_SVP) || (defined IOMTYPE_SP)
        if (BOX->GetPld2RevLetter() == 0) {     //Disable WDT for now for SVP & SP
        #elif (LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
        if (TRUE) {   // LOWCOST supports regardless the version
        #elif (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        if ((FALSE==IsFpgaS2)||(BOX->GetPld2RevLetter() > PD_REV_B)) {
        #else // HEK other than AIH and AOH
        if (BOX->GetPld2RevLetter() > PD_REV_B) {
        #endif
            if (TaskScheduler.m_uiWdtDiagCounter > WDT_DIAGSTART_DIAGCOUNT) {
                // It is time to do a WDT diagnostic cycle
                TaskScheduler.m_ucWdtRefreshCounter++;
                switch (TaskScheduler.m_WdtDiagState) { // State of WDT diagnostic cycle
                    case WDTDIAG_RESET:     // Start it by signalling the ISR
                        TaskScheduler.m_WdtDiagState = WDTDIAG_RUNNING;
                        break;
                    case WDTDIAG_RUNNING:   // WDT interrupt has not happened yet
                        if (TaskScheduler.m_ucWdtRefreshCounter > STCTICKS_120MILLISEC) {
                            // The WDT warning interrupt HAS NOT happened in time.
                            #if (HEK && !defined(IOMTYPE_PI) && !defined(IOMTYPE_UIO))
                            BOOL bWdtIntAsserted = (FPGA_INTFL_WDTO) ? TRUE : FALSE;
                            #elif defined(IOMTYPE_UIO)
                            // Check IRQ1 status as well as the port register.
                            // IRQ1 status will clear once the interrupt
                            // handler has been entered.
                            BOOL bWdtIntAsserted = ((IRQ1_STATUS) || (WDTOPIRQ)) ? TRUE : FALSE;
                            #else
                            BOOL bWdtIntAsserted = (IRQ1_STATUS) ? TRUE : FALSE;
                            #endif

                            #if defined (IOMTYPE_UIO)
                            // If the WDT Impending interrupt is not asserted then the WDTCLR will not
                            // affect the WDT state. We must not try to do the clear and set WdtIntProcessed
                            // otherwise IRQ1 will not be able to process the interrupt correctly.
                            if (FALSE == BOX->GetWdtIntProcessed() && bWdtIntAsserted) {
                            #else
                            if (FALSE == BOX->GetWdtIntProcessed() ) {
                            #endif
                                // Stop the watchdog from expiring if IRQ1 has not processed 
                                // the interrupt yet. Note that the FPAG_INFL_WDTO may stay
                                // asserted longer up to 5 msec after the IRQ1 has processed it.
                                TaskScheduler.StopImpendingWatchdog();
                                // Mark that scheduler detected FPGA_INTFL_WDTO first and serviced it.
                                // This is required otherwise the Irq1InterruptHandler may hardfail
                                // because the WDTDIAG_STATE is not running.
                                BOX->SetWdtIntProcessed();
                            }
                        }
                        break;
                    default:
                        // The state machine is out of whack, so HF
                        HardFail(HF_BADPROGRAMJUMP,SCHEDULER_CPP,__LINE__);
                        break;
                }
            }
            else if (!FactryModeWDTUTest) { // Watchdog diagnostics is not
                // scheduled now. Kick the dog, reset the WDT counter,
                // and increment the WDT diag counter.
                WDTRFS_n = 0; 
                WDTRFS_n = 1;
                TaskScheduler.m_ucWdtRefreshCounter = 0;
                TaskScheduler.m_uiWdtDiagCounter++;
                // Arm IRQ1 processing for watchdog interrupt.
                BOX->ResetWdtIntProcessed();
            }
            else TaskScheduler.m_ucWdtRefreshCounter++;
        }
        else { // This module that does not support WDT diagnostics. It might  
            // also have a CPLD/FPGA version that implements windowed watchdog. 
            // In either case, treat it as a module that has windowed watchdog.
            // NOTE: WDT refresh period for modules with windowed watchdog will be equal to
            // (STCTICKS_100MILLISEC + 2) * SCHEDULER_PERIOD =  (10 + 2) * 10 = 120 msec.
            if (TaskScheduler.m_ucWdtRefreshCounter > STCTICKS_100MILLISEC) {
                WDTRFS_n = 0; 
                WDTRFS_n = 1;
                TaskScheduler.m_ucWdtRefreshCounter = 0;
            }
            else {
                TaskScheduler.m_ucWdtRefreshCounter++;
            }
        }
    #if !defined(IOMTYPE_UIO) // UIO refreshes watchdog every 10 msec
    }
    else { // Not time to do anything with the WDT
        TaskScheduler.m_ucWdtRefreshCounter++; 
    }
    #endif
#endif
#else // Debug code
    // This code is for Debug purpose to test the Watchdog functionality
    // for different refresh rates from 10 to 150 msec. Remove code in 
    // product firmware.    
    TaskScheduler.m_ucWdtRefreshCounter++;
    if(g_ChangeWdtRefreshTime == TaskScheduler.m_ucWdtRefreshCounter) {
        if(FALSE == g_bWdtTestInProgress) {
           WDTRFS_n = 0; 
           WDTRFS_n = 1;
           TaskScheduler.m_ucWdtRefreshCounter = 0;
        }
   }

#if !defined(IOPTYPE_SCIOM)
    // modified for FCT testing (WATCHDOG TEST - TEST#6)
    if ((TRUE == FactryModeWDTUTest)
    &&  (TaskScheduler.m_ucWdtRefreshCounter > STCTICKS_60MILLISEC))
    {        
        TaskScheduler.StopImpendingWatchdog();

        WDTRFS_n = 0;
        WDTRFS_n = 1;
        TaskScheduler.m_ucWdtRefreshCounter = 0;        
    }
#endif

#endif

#if defined(IOMTYPE_SVP) || defined(IOMTYPE_SP)
    TcIomDiagnostics();
#else
    // Perform test on external memory and address lines
    #if (HEK & !defined(IOMTYPE_PI))
    if ((_TestRAMCell(EXTRAM_QUICKTEST_LOC1) != TRUE) ||
        (_TestRAMCell(EXTRAM_QUICKTEST_LOC2) != TRUE) ||
        (_TestRAMCell(EXTRAM_QUICKTEST_LOC3) != TRUE)) {
        HardFail(HF_RAMCONTERROR,SCHEDULER_CPP,__LINE__);
    }
    #endif
    AddressDiagRoutine();
#endif

    // During calibration no other tasks are active. Don't hardfail if DMC expires.
    if (FALSE == BOX->GetCalibAllState()) {
        //During update of HW Rev Code and Hardware Serial Number 
        if ( FALSE == HWRevCodeWriteInProgress){
            UINT8 ucTask;
            UINT16 usMask;

            // Process Periodic Table
            for (ucTask = 0; ucTask < TASKCOUNT; ucTask++) {
                if (TaskScheduler.m_PeriodicTable[ucTask].usDownCounter > 0) {
                    TaskScheduler.m_PeriodicTable[ucTask].usDownCounter--;
                    if (0 == TaskScheduler.m_PeriodicTable[ucTask].usDownCounter) {
                        TaskScheduler.m_PeriodicTable[ucTask].usDownCounter = 
                            TaskScheduler.m_PeriodicTable[ucTask].usPeriod;
                        usMask = 0x0001 << ucTask;
                        TaskScheduler.m_usTaskActivationBits |= usMask;
                    }
                }
                // Customer (-MiRO) Issue(-CL Fail) Fix - Setting task activation bit again here (other than run task), if write requests are exists in the buffer 
                if (TASKID_WRDBTASK == (ucTask + 1)) {
                    usMask = 0x0001 << ucTask;
                    if ((TaskScheduler.m_usWriteReqCount > 0) && !(TaskScheduler.m_usTaskActivationBits & usMask)) {
                        TaskScheduler.m_usTaskActivationBits |= usMask;
                    }
                }
            }

            // Process Delay/Suspend Table if any delayed tasks exists
            if (0 != TaskScheduler.m_ucDelayedTaskCount) {
                for (ucTask = 0; ucTask < TASKCOUNT; ucTask++) {
                    // Check if the the task was in suspended state already
                    if ((TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter > 0) &&
                        (TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter < MAXUINT8)) {
                        TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter--;
                    }
                    // Customer(-MiRO) Issue(-CL Fail & EHPM Crash due to HLAI IOL Comm Error) fix
                    else if (TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter >= MAXUINT8) {
                        TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter &= 0x00FF;
                    }

                    if ((TASKSTATE_WAITING == TaskScheduler.m_TaskStatus[ucTask].TaskState) &&
                        (0 == TaskScheduler.m_DelaySuspendTable[ucTask].usDownCounter)) {
                        // if suspension time over,set task in ReadytoResume state
                        TaskScheduler.m_TaskStatus[ucTask].TaskState = TASKSTATE_READYTORESUME;
                        TaskScheduler.m_ucDelayedTaskCount--;
                    } 
                } 
            }

            // Monitor DMC for periodic tasks
            for (ucTask = 0; ucTask < TASKCOUNT; ucTask++)  {
                if (TaskScheduler.m_DmcTable[ucTask].usCurrentLife > 0) {
                    // If either CPU free max value find test or HART loopback 
                    // test is running, do not decrement DMC counter.
                    #if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
                    if (LOOPBACK_RUNNING == BOX->GetLpBkStat()) {
                        continue;
                    }
                    #endif
                    #ifdef DEBUG
                    if (g_ucCpuFreeTestIndex > 0) continue;
                    #endif
#if defined(IOPTYPE_SCIOM)
                    // disabled due to PAR# 1-93OP1Z9 (DO16 Forcing the DO channel via data change schematic makes IOP as NR) (note: HF17)
                    // disabled for redesign IOP due to HF17.
                    TaskScheduler.m_DmcTable[ucTask].usCurrentLife--;
                    if (TaskScheduler.m_DmcTable[ucTask].usCurrentLife == 0) {  
                        TraceLog.AddToTrace(TRACEID_GENERIC,bcDMCFail,(UINT32)ucTask);
                        HardFail(HF_DMCTIMEOUT,SCHEDULER_CPP,__LINE__);
                    }
#endif
                } 
            }
        }
    }

    // Process 1 second Timer
    if(0 == (TaskScheduler.m_ul10msCounter % SCHEDULER_TICKS_IN_SECOND)) { 
        // Set the one second indicator flag
        TaskScheduler.m_bOneSecondTimerFlag = TRUE;
#ifdef IOPTYPE_DI
        // also set the one second flag used for SOE applications in diboxslot
        BOX->SetOneSecFlagDI();
#endif
#ifdef IOMTYPE_DISOE
        // also set the one second flag used for SOE applications in diboxslot
        BOX->SetOneSecFl();
#endif
    }

    #ifdef DEBUG
    // If CPU free max value find test is running,
    // do not call applications specfic routine.
    if (g_ucCpuFreeTestIndex > 0) return;
    #endif

    BOX->AppStcProcessing();
}
/******************************************************************************
*                   clsTaskScheduler::StopImpendingWatchdog                   *
*                   =======================================                   *
*  This function is called from IRQ1 or STC interrupt to stop watchdog from   *
*  expiring. In all occassions except factory test mode, watchdog expiry is   *
*  prevented by asserting WDTODCLR_n line. If factory test is going on, WDT   *
*  expiration time is measured by measuring the time in a tight while loop.   *
******************************************************************************/
VOID clsTaskScheduler::StopImpendingWatchdog(VOID) {
    const UINT8  WDT_MEASURE_RESOLUTION = 50; // 50 micro second.
    const UINT16 WDT_EXTRA_WAIT_TIME = 20000; // 20 msec
    INT32 WdtTime  = 0;

    UINT8 ucSaveExr = get_imask_exr();
#if defined (IOMTYPE_UIO)
    set_imask_exr(LVLPRI_PDVC);
#elif defined (IOMTYPE_DISOE)
    set_imask_exr(LVLPRI_SOE);
#else
    set_imask_exr(LVLPRI_TICK);
#endif

    if (!FactryModeWDTUTest) {
        // If WDT diagnostics test is being done, 
        // refresh WDT and reset WdtDiag data members.
        // NOTE : WDTODCLR_n refreshes the watchdog automatically
        WDTODCLR_n = 0; 
        WDTODCLR_n = 1; 
        m_uiWdtDiagCounter = 0;
        m_WdtDiagState = WDTDIAG_RESET;
    }
    else  {
        // Make exclusive use of TPU1 for measuring time for the watchdog to expire.
        set_imask_exr(LVLPRI_HIGHEST);
        TPU1_TCNT = 0;     // Reset TPU1 counter.
        TPU1_CST  = 1;     // Start TPU1 counter.
        WdtTime = (INT32)(m_ucWdtRefreshCounter * SCHEDULER_PERIOD * MICROSECONDS_IN_MILLISECOND); 

        while (WdtTime <= (WDT_MAX_TIME_IN_MICROSEC + WDT_EXTRA_WAIT_TIME)) {
           while (TPU1_TCNT < (WDT_MEASURE_RESOLUTION * TPU1_TICKS_IN_MICROSECOND));
           TPU1_TCNT = 0;     // Reset TPU1 counter.
           TPU1_CST  = 1;     // Start TPU1 counter.
           WdtTime += WDT_MEASURE_RESOLUTION;
           BOX->SetTstFunctTime(WdtTime);
#if !defined(IOPTYPE_SCIOM)
           // modified for FCT testing (WATCHDOG TEST - TEST#6)
           if (TRUE == FactryModeWDTUTest)
           {
               FactryModeWDTUTest = FALSE;
               return;
           }
#endif
        }

        // If WDT expiry takes more than 150msec, 
        // write -1 to TstFunctTime param to report failure. 
        BOX->SetTstFunctTimeStsToFail();

        set_imask_exr(ucSaveExr);
        return; 
    } 

#ifdef DEBUG 
    // Record the TPU ticks & 10 msec timer from the last STC tick.
    g_usWdtTestTimer[1] = TPU5_TCNT;
    g_usWdtTestTimer[0] = m_ucWdtRefreshCounter * SCHEDULER_PERIOD;
    // Calculate the millisecond and microsecond time since last WDT refresh
    // in zeroth byte and first byte respectively of g_usWdtTestTimer.
    g_usWdtTestTimer[0] += (UINT16)(g_usWdtTestTimer[1] / TPUCOUNT_IN_MILLISECOND);
    g_usWdtTestTimer[1] = (UINT16)((g_usWdtTestTimer[1] % TPUCOUNT_IN_MILLISECOND) 
                                   / TPUCOUNT_IN_MICROSECOND);
    // Allow further refresh of the watchdog.
    g_bWdtTestInProgress  = FALSE;
#endif

    // Restart the WdtRefreshCounter to synchronize the refresh window.
    m_ucWdtRefreshCounter = 0;
    set_imask_exr(ucSaveExr);
}

