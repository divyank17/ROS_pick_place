/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcailvdtslot.cpp                                            *
*    Description : Class clsAiLvdtSlot definition.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "svpmain.h"

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define   NUM_CALIBREC_PER_CHANNEL      2
const FLOAT32 EX_VOL_MIN  = (FLOAT32)3.0;

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern SHRAMDATA ShramData;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsAiLvdtSlot::RedParams[] = {
    kSvpAiPnInptDir,
    kSvpAiPnLoCutoff,
    kSvpAiPnPntType,
    kSvpAiPnPtExecSt,
    kSvpAiPnPvChar,
    kSvpAiPnPvClamp,
    kSvpAiPnPvEUHi,
    kSvpAiPnPvEULo,
    kSvpAiPnPvExEUHi,
    kSvpAiPnPvExEULo,
    kSvpAiPnPvSrcOpt,
    kSvpAiPnPvSource,
    kSvpAiPnPvTv,
    kSvpAiPnPvTvP,
    kSvpAiPnSensrTyp,
    kSvpAiPnTf,
    kSvpAiPnOwdEnbl,
    kSvpAiPnExVol,
    kSvpAiPnTxWireSel,
    kSvpAiPnVdtMode,
    0 // Terminator
};

const AILVDTSLOTPARAMINFO clsAiLvdtSlot::tblParamInfo[] = { // Build paraminfo table
 //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
//  FILL 0 index to 50th index///////////////////////////////////////////////////////////////////////////////////////////
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPntTypePtr,TRUE,             // 51 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPtExecStPtr,TRUE,           // 52 PtExecSt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastPvPtr,FALSE,         // 53 LastPv
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetLoCutOffPtr,TRUE,         // 54 LoCutOff
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadPvFlPtr,FALSE,           // 55 BadPvFl
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,0,0,GetInptDirPtr,TRUE,         // 56 InptDir
    DT_FLOAT32,4,AT_BXREC,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPvPtr,FALSE,             // 57 Pv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoPtr,FALSE,         // 58 PvAuto
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoStPtr,FALSE,          // 59 PvAutoSt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvCalcPtr,FALSE,         // 60 PvCalc
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,0,0,GetPvCharPtr,TRUE,          // 61 PvChar
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,0,0,GetPvClampPtr,TRUE,         // 62 PvClamp
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetPvEUHiPtr,TRUE,      // 63 PvEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetPvEULoPtr,TRUE,      // 64 PvEULo
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetPvExEUHiPtr,TRUE,    // 65 PvExEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetPvExEULoPtr,TRUE,    // 66 PvExEULo
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvExHiFlPtr,FALSE,          // 67 PvExHiFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvExLoFlPtr,FALSE,          // 68 PvExLoFl
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvPPtr,FALSE,            // 69 PvP
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvRawPtr,FALSE,          // 70 PvRaw
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPvSourcePtr,TRUE,           // 71 PvSource
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetPvSrcOptPtr,TRUE,           // 72 PvSrcOpt
    DT_ENUM,1,AT_BXREC,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvStsPtr,FALSE,             // 73 PvSts
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPvTvPtr,TRUE,            // 74 PvTv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvTvPPtr,FALSE,          // 75 PvTvP
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,0,0,GetSensrTypPtr,TRUE,        // 76 SensrTyp
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetTfPtr,TRUE,              // 77 Tf
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetOwdEnablePtr,TRUE,           // 78 OwdEnable
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 79 
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetExVolPtr,TRUE,            // 80 ExVol - Excitation Voltage
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetTxWireSelPtr,TRUE,           // 81 TxWireSel - Transducer Wire Selection
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetVdtModePtr,TRUE,            // 82 VdtMode - VDT mode LVDT/RVDT
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 83 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 84 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 85 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 86 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 87 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 88 
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetCalibValPtr,FALSE,          // 89 CalibVal
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetValvePosCalibEnb,FALSE,     // 90 Valve Position Calibration Enable
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetValvePosCalibSts,FALSE,     // 91 Valve Position Calibration Status
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetExFbAVolRmsPtr,FALSE,    // 92 Excitation Feedback A Voltage RMS
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetExFbBVolRmsPtr,FALSE,    // 93 Excitation Feedback B Voltage RMS
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetExVolRmsPtr,FALSE,       // 94 Excitation Voltage RMs
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetActualAnglePtr,FALSE,    // 95 Actual Angle
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetApplyOffsetPtr,TRUE,        // 96 Apply Offset
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAngleOffsetPtr,FALSE,    // 97 Angle Offset
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 101
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 102
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 103
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 104
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 113
    DT_BLIND,44,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCheckPointPtr,FALSE,       // 114 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 116
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 123 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 124 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 125 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 126 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 127 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 128 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 129 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 130 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 131 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 132 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 133  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 141
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,// 142 SlotChkpntVersion
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 243
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 244 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 255

};

/*******************************************************************************
*                            clsAiLvdtSlot::clsAiLvdtSlot                      *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsAiLvdtSlot::clsAiLvdtSlot( UINT8 a_ucSltNm ) : clsInSlot(PNTTYPE_NOTCONFIGURED, a_ucSltNm) 
{    
    //Get the slot shared ram pointer into local variable
    UINT8 nSlotNum = a_ucSltNm - AI_LVDT_CHANNEL_START_INDEX;
    pAiShramSlotData = &ShramData.ShramSlotData.AiShramSlotData[nSlotNum];

    //Initialize the class member variables
    InitLvdtAiSlot(FALSE, TRUE);
}

/*******************************************************************************
*                           clsAiLvdtSlot::operator new                        *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAiLvdtSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return ucIomDbMemory + SVPBOXSLOT_SIZE +  
              ((a_ucSltNm-AI_LVDT_CHANNEL_1_NUMBER)* AILVDTSLOT_SIZE);
}

/*******************************************************************************
*                            clsAiLvdtSlot::GetDataType                        *
*                          ==========================                          *
* PURPOSE:    Returns the Data type of a requested parameter                   *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Data type                                                        *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsAiLvdtSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsAiLvdtSlot::GetAccessType                        *
*                          ==========================                          *
* PURPOSE:    Returns the access type of a requested parameter                 *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Access type                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsAiLvdtSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                            clsAiLvdtSlot::GetParamSize                       *
*                            ========================                          *
* PURPOSE:    Returns the Size of a requested parameter                        *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Size                                                             *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAiLvdtSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsAiLvdtSlot::GetParamPtr                        *
*                            =======================                           *
* PURPOSE:    Returns the Pointer to the GetParamPtr of a requested parameter  *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Pointer to the GetParamPtr function                              *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsAiLvdtSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                           clsAiLvdtSlot::GetAccessLock                       *
*                           =========================                          *
* PURPOSE:    Returns the access lock of a requested parameter                 *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Access Lock                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsAiLvdtSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                       clsAiLvdtSlot::GetIsDbChecksumed                       *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAiLvdtSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsAiLvdtSlot::VerifyControlState                    *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAiLvdtSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    UINT8 PntExecSts   = (PTEXECST)pAiShramSlotData->PtExecSt;
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PntExecSts) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PntExecSts) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PntExecSts) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    }

    return PA_OK;
}

/*******************************************************************************
*                         clsAiLvdtSlot::ExecutePreFunction                    *
*                         ==============================                       *
* PURPOSE:   Invokes the Prefunction of a request parameter                    *
* ARGUMENTS:                                                                   *
                a_ucParamNumber  - Parameter Number                            *
                a_Buffer         -   Pointer to the data                       *
*               a_ucAccessLevel  -   Access level of the parameter             *
* RETURN:                                                                      *
                PA_OK                                                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAiLvdtSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsAiLvdtSlot::ExecutePostFunction                   *
*                         ===============================                      *
* PURPOSE:   Invokes the Postfunction of a request parameter                   *
* ARGUMENTS:                                                                   *
                a_ucParamNumber  - Parameter Number                            *
*               a_ucAccessLevel  -   Access level of the parameter             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAiLvdtSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}

/*******************************************************************************
*                           clsAiLvdtSlot::InitSlotDatabase                    *
*                           ============================                       *
*  Initialize the entire channel database. Calls the Init function for each    *
*  class in the channel object hierarchy and recompute database checksum.      *
*******************************************************************************/ 
VOID clsAiLvdtSlot::InitSlotDatabase(BOOL bFullInit) {
    BOOL bObjCreate = FALSE; 
    
    //Initialize base class members
    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitInSlot(bFullInit, bObjCreate);
    InitLvdtAiSlot(bFullInit, bObjCreate); 
    
    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                            clsAiLvdtSlot::InitLvdtAiSlot                     *
*                          ==========================                          *
* PURPOSE:    Initilizes required AI and LVDT Params                           *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAiLvdtSlot::InitLvdtAiSlot(BOOL bFullInit, BOOL){
    LastPv              = NaN;
    PvCalc              = NaN;
    PvAuto              = NaN;
    PvAutoSt            = PVVALST_BAD;
    PvRaw               = NaN;
                        
    PvEUHi              = NaN;
    PvEULo              = NaN;
    PvExEUHi            = NaN;
    PvExEULo            = NaN;
    PvClamp             = PVCLAMP_NOCLAMP;
    LoCutOff            = NaN;
    Tf                  = (FLOAT32) 0.0;
                        
    PvTv                = NaN;
    PvTvP               = NaN;
    
    if (bFullInit) {
        Pv       = NaN;
        PvSts    = PVVALST_BAD;
        PvP      = NaN;
        BadPvFl  = TRUE;
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
    }

    ExVol         = NaN;
    Exc_RMS_Sum   = NaN;
    FdbkA_RMS_Sum = NaN;
    FdbkB_RMS_Sum = NaN;
    CalibVal         = CALIB_VALUE_NONE;
    ValvePosCalibEnb = FALSE;
    ValvePosCalibSts = VALVE_POS_CALIB_NOT_DONE;

    SensrTyp            = SENSRTYP_LVDT;
    InptDir             = INPTDIR_DIRECT;
    PvChar              = PVCHAR_LINEAR;
    ExVol               = EX_VOL_MIN ;
    TxWireSel           = THREE_WIRE_TX;
    VdtMode             = VDT_MODE_NORMAL;
}

/*******************************************************************************
*                    Get Methods for AI Channels Parameters                    *
*******************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////
//Getting the data from shared ram database into local copy and returns the pointers
//////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
//Overrided clsIoSlot Class Varibles GetPtr methods
//////////////////////////////////////////////////////////
VOID *clsAiLvdtSlot::GetPntTypePtr(VOID)         
{ 
    PntType = (PNTTYPE)pAiShramSlotData->PntType;

    return &PntType;
}

VOID *clsAiLvdtSlot::GetPtExecStPtr(VOID)        
{
    PtExecSt = (PTEXECST)pAiShramSlotData->PtExecSt;

    return &PtExecSt;        
}

///////////////////////////////////////////////////////////
//Overrided clsInSlot Class Varibles GetPtr methods
///////////////////////////////////////////////////////////
VOID *clsAiLvdtSlot::GetPvSourcePtr(VOID)        
{ 
    PvSource = (PVSOURCE)pAiShramSlotData->PvSource;

    return &PvSource;        
}

VOID *clsAiLvdtSlot::GetPvSrcOptPtr(VOID)        
{ 
    PvSrcOpt = (PVSRCOPT)pAiShramSlotData->PvSrcOpt;

    return &PvSrcOpt;        
}

VOID *clsAiLvdtSlot::GetOwdEnablePtr(VOID)       
{ 
    OwdEnable = (BOOL)pAiShramSlotData->OwdEnable;

    return &OwdEnable;       
}

///////////////////////////////////////////////////////////
//Member Varibles GetPtr methods
///////////////////////////////////////////////////////////
VOID *clsAiLvdtSlot::GetPvPtr(VOID) 
{ 
    Pv = (FLOAT32)pAiShramSlotData->Pv;

    return &Pv;
}

VOID *clsAiLvdtSlot::GetPvStsPtr(VOID) 
{ 
    PvSts = (PVVALST)pAiShramSlotData->PvSts;

    return &PvSts;
} 

VOID *clsAiLvdtSlot::GetLastPvPtr(VOID)          
{ 
    LastPv          = (FLOAT32)pAiShramSlotData->LastPv;
    
    return &LastPv;          
}

VOID *clsAiLvdtSlot::GetPvCalcPtr(VOID)          
{ 
    PvCalc          = (FLOAT32)pAiShramSlotData->PvCalc;

    return &PvCalc;          
}

VOID *clsAiLvdtSlot::GetPvAutoPtr(VOID)          
{ 
    PvAuto          = (FLOAT32)pAiShramSlotData->PvAuto;

    return &PvAuto;          
}

VOID *clsAiLvdtSlot::GetPvAutoStPtr(VOID)        
{ 
    PvAutoSt = (PVVALST)pAiShramSlotData->PvAutoSt;

    return &PvAutoSt;        
}

VOID *clsAiLvdtSlot::GetPvRawPtr(VOID)   
{
    PvRaw           = (FLOAT32)pAiShramSlotData->PvRaw;

    return &PvRaw;           
}

VOID *clsAiLvdtSlot::GetBadPvFlPtr(VOID)        
{
    BadPvFl = (BOOL)pAiShramSlotData->BadPvFl;

    return &BadPvFl;         
}

VOID *clsAiLvdtSlot::GetPvExHiFlPtr(VOID)        
{
    PvExHiFl = (BOOL)pAiShramSlotData->PvExHiFl;

    return &PvExHiFl;
}

VOID *clsAiLvdtSlot::GetPvExLoFlPtr(VOID)        
{
    PvExLoFl = (BOOL)pAiShramSlotData->PvExLoFl;

    return &PvExLoFl;        
}

VOID *clsAiLvdtSlot::GetSensrTypPtr(VOID)        
{ 
    SensrTyp        = (SENSRTYP)pAiShramSlotData->SensrTyp;

    return &SensrTyp;        
}

VOID *clsAiLvdtSlot::GetPvCharPtr(VOID)          
{
    PvChar = (PVCHAR)pAiShramSlotData->PvChar;

    return &PvChar;          
}

VOID *clsAiLvdtSlot::GetInptDirPtr(VOID)         
{
    InptDir = (INPTDIR)pAiShramSlotData->InptDir;

    return &InptDir;
}

VOID *clsAiLvdtSlot::GetPvEUHiPtr(VOID)          
{
    PvEUHi = (FLOAT32)pAiShramSlotData->PvEUHi;

    return &PvEUHi;          
}

VOID *clsAiLvdtSlot::GetPvEULoPtr(VOID)      
{ 
    PvEULo = (FLOAT32)pAiShramSlotData->PvEULo;

    return &PvEULo;          
}

VOID* clsAiLvdtSlot::GetPvExEUHiPtr(VOID)    
{
    PvExEUHi = (FLOAT32)pAiShramSlotData->PvExEUHi;

    return &PvExEUHi;
}

VOID *clsAiLvdtSlot::GetPvExEULoPtr(VOID)      
{ 
    PvExEULo = (FLOAT32)pAiShramSlotData->PvExEULo;

    return &PvExEULo;        
}

VOID *clsAiLvdtSlot::GetPvClampPtr(VOID)         
{ 
    PvClamp = (PVCLAMP)pAiShramSlotData->PvClamp;

    return &PvClamp;         
}

VOID *clsAiLvdtSlot::GetLoCutOffPtr(VOID)
{
    LoCutOff = (FLOAT32)pAiShramSlotData->LoCutOff;

    return &LoCutOff;        
}

VOID *clsAiLvdtSlot::GetTfPtr(VOID)
{ 
    Tf = (FLOAT32)pAiShramSlotData->Tf;

    return &Tf;              
}

VOID *clsAiLvdtSlot::GetPvPPtr(VOID)
{ 
    PvP = (FLOAT32)pAiShramSlotData->PvP;

    return &PvP;
}

VOID *clsAiLvdtSlot::GetPvTvPtr(VOID)
{ 
    PvTv = (FLOAT32)pAiShramSlotData->PvTv;

    return &PvTv;            
}

VOID *clsAiLvdtSlot::GetPvTvPPtr(VOID)           
{
    PvTvP = (FLOAT32)pAiShramSlotData->PvTvP;

    return &PvTvP;           
}

VOID *clsAiLvdtSlot::GetExVolPtr(VOID)           
{ 
    ExVol           = (FLOAT32)pAiShramSlotData->ExVol;
    
    return &ExVol;           
}

VOID *clsAiLvdtSlot::GetTxWireSelPtr(VOID)       
{ 
    TxWireSel = (TXWIRESEL)pAiShramSlotData->TxWireSel;

    return &TxWireSel;       
}

VOID *clsAiLvdtSlot::GetVdtModePtr(VOID)        
{ 
    VdtMode = (VDTMODE)pAiShramSlotData->VdtMode;

    return &VdtMode;         
}
  
VOID *clsAiLvdtSlot::GetCalibValPtr(VOID) 
{
    CalibVal = (CALIBVALUE)pAiShramSlotData->CalibVal;

    return &CalibVal;
}

VOID *clsAiLvdtSlot::GetExVolRmsPtr(VOID) 
{
    Exc_RMS_Sum = (FLOAT32)pAiShramSlotData->Exc_RMS_Sum;
 
    return &Exc_RMS_Sum;
}
VOID *clsAiLvdtSlot::GetExFbAVolRmsPtr(VOID) 
{
    FdbkA_RMS_Sum = (FLOAT32)pAiShramSlotData->FdbkA_RMS_Sum;
 
    return &FdbkA_RMS_Sum;
}
VOID *clsAiLvdtSlot::GetExFbBVolRmsPtr(VOID) 
{
    FdbkB_RMS_Sum = (FLOAT32)pAiShramSlotData->FdbkB_RMS_Sum;
 
    return &FdbkB_RMS_Sum;
}

VOID *clsAiLvdtSlot::GetValvePosCalibEnb(VOID) 
{
    ValvePosCalibEnb = (BOOL)pAiShramSlotData->ValvePosCalibEnb;

    return &ValvePosCalibEnb;
}

VOID *clsAiLvdtSlot::GetValvePosCalibSts(VOID) 
{
    ValvePosCalibSts = (VALVEPOSCALIBSTATUS)pAiShramSlotData->ValvePosCalibSts;

    return &ValvePosCalibSts;
}

VOID *clsAiLvdtSlot::GetActualAnglePtr(VOID) 
{
    ActualAngle = (FLOAT32)pAiShramSlotData->ActualAngle;

    return &ActualAngle;
}

VOID *clsAiLvdtSlot::GetApplyOffsetPtr(VOID) 
{
    ApplyOffset = (BOOL)pAiShramSlotData->ApplyOffset;

    return &ApplyOffset;
}

VOID *clsAiLvdtSlot::GetAngleOffsetPtr(VOID) 
{
    AngleOffset = (FLOAT32)pAiShramSlotData->AngleOffset;

    return &AngleOffset;
}


/*******************************************************************************
*                         clsAiLvdtSlot::GetDumpData                           *
*                         ===============================                      *
* PURPOSE:  This method will copy the redundancy dump data to buffer transmit  *
*           to the secondary IOM                                               *
* ARGUMENTS:                                                                   *
                                                                               *
*                                                                              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS  clsAiLvdtSlot::GetDumpData(UINT8* const pDump, const UINT8 MaxSize)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL && sizeof(strAiLvdtSlotDumpData) < MaxSize)
    {
        strAiLvdtSlotDumpData *pDumpData = (strAiLvdtSlotDumpData*)pDump;

        pDumpData->Version    = PACK2_AS_UI16(SVPAI_SYNC_VER_1,0);
        pDumpData->PntType    = (PNTTYPE)pAiShramSlotData->PntType;
        pDumpData->PtExecSt   = (PTEXECST)pAiShramSlotData->PtExecSt;
        pDumpData->PvSource   = (PVSOURCE)pAiShramSlotData->PvSource;
        pDumpData->PvSrcOpt   = (PVSRCOPT)pAiShramSlotData->PvSrcOpt;
        pDumpData->OwdEnable  = (BOOL)pAiShramSlotData->OwdEnable;
        pDumpData->PvEUHi     = (FLOAT32)pAiShramSlotData->PvEUHi;
        pDumpData->PvEULo     = (FLOAT32)pAiShramSlotData->PvEULo;
        pDumpData->PvExEUHi   = (FLOAT32)pAiShramSlotData->PvExEUHi;
        pDumpData->PvExEULo   = (FLOAT32)pAiShramSlotData->PvExEULo;
        pDumpData->LoCutOff   = (FLOAT32)pAiShramSlotData->LoCutOff;
        pDumpData->Tf         = (FLOAT32)pAiShramSlotData->Tf;
        pDumpData->ExVol      = (FLOAT32)pAiShramSlotData->ExVol;
        pDumpData->SensrTyp   = (SENSRTYP)pAiShramSlotData->SensrTyp;
        pDumpData->InptDir    = (INPTDIR)pAiShramSlotData->InptDir;
        pDumpData->PvChar     = (PVCHAR)pAiShramSlotData->PvChar;
        pDumpData->PvClamp    = (PVCLAMP)pAiShramSlotData->PvClamp;
        pDumpData->TxWireSel  = (TXWIRESEL)pAiShramSlotData->TxWireSel;
        pDumpData->VdtMode    = (VDTMODE)pAiShramSlotData->VdtMode;

        //Copy the Pv if Pvsource  is MAN and SUB
        if(PVSOURCE_AUTO != pDumpData->PvSource)
        {
          pDumpData->Pv       = (FLOAT32)pAiShramSlotData->Pv;
          pDumpData->PvSts    = (PVVALST)pAiShramSlotData->PvSts;
        }

        pDumpData->bValvePosCalibEnb = pAiShramSlotData->ValvePosCalibEnb;
        //Copy the LVDT Calib Data
        for(int i = 0;i<2;i++)
        {
            pDumpData->CalibData[i].LvdtRawLo           = pAiShramSlotData->CalibData[i].LvdtRawLo;
            pDumpData->CalibData[i].LvdtRawHi           = pAiShramSlotData->CalibData[i].LvdtRawHi;
            pDumpData->CalibData[i].Vxt_Fcal_Min        = pAiShramSlotData->CalibData[i].Vxt_Fcal_Min;
            pDumpData->CalibData[i].Vxt_Fcal_Max        = pAiShramSlotData->CalibData[i].Vxt_Fcal_Max;
            pDumpData->CalibData[i].FdbkA_Fcal_Min      = pAiShramSlotData->CalibData[i].FdbkA_Fcal_Min;
            pDumpData->CalibData[i].FdbkA_Fcal_Max      = pAiShramSlotData->CalibData[i].FdbkA_Fcal_Max;
            pDumpData->CalibData[i].FdbkB_Fcal_Min      = pAiShramSlotData->CalibData[i].FdbkB_Fcal_Min;
            pDumpData->CalibData[i].FdbkB_Fcal_Max      = pAiShramSlotData->CalibData[i].FdbkB_Fcal_Max;
            pDumpData->CalibData[i].ExctnFrequency      = pAiShramSlotData->CalibData[i].ExctnFrequency;
            pDumpData->CalibData[i].Bottom              = pAiShramSlotData->CalibData[i].Bottom;
            pDumpData->CalibData[i].LvdtCalibrationGood = pAiShramSlotData->CalibData[i].LvdtCalibrationGood;
        }        

        pDumpData->FiltOut    = (FLOAT32)pAiShramSlotData->FiltOut;
       
        pDumpData->ActualAngle   = (FLOAT32)pAiShramSlotData->ActualAngle;
        RetVal = PA_OK;
    }
    return RetVal;
}

/*******************************************************************************
*                         clsAiLvdtSlot::StoreDumpData                         *
*                         ===============================                      *
* PURPOSE:  This method will copy the redundancy dump data into local dump     *
*           structure in Primary IOM                                           *
*                                                                              *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS  clsAiLvdtSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL)
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SVPAI_SYNC_VER_1)
        {
            strAiLvdtSlotDumpData* pDumpData = (strAiLvdtSlotDumpData*)(pDump);

            pAiShramSlotData->PntType  = pDumpData->PntType;
            pAiShramSlotData->PtExecSt = pDumpData->PtExecSt;
            pAiShramSlotData->PvSource = pDumpData->PvSource;
            pAiShramSlotData->PvSrcOpt = pDumpData->PvSrcOpt;
            pAiShramSlotData->OwdEnable= pDumpData->OwdEnable;
            pAiShramSlotData->PvEUHi   = pDumpData->PvEUHi;
            pAiShramSlotData->PvEULo   = pDumpData->PvEULo;
            pAiShramSlotData->PvExEUHi = pDumpData->PvExEUHi;
            pAiShramSlotData->PvExEULo = pDumpData->PvExEULo;
            pAiShramSlotData->LoCutOff = pDumpData->LoCutOff;
            pAiShramSlotData->Tf       = pDumpData->Tf;
            pAiShramSlotData->ExVol    = pDumpData->ExVol;  
            pAiShramSlotData->SensrTyp = pDumpData->SensrTyp;
            pAiShramSlotData->InptDir  = pDumpData->InptDir;
            pAiShramSlotData->PvChar   = pDumpData->PvChar;
            pAiShramSlotData->PvClamp  = pDumpData->PvClamp;
            pAiShramSlotData->TxWireSel= pDumpData->TxWireSel;
            pAiShramSlotData->VdtMode  = pDumpData->VdtMode;

            //Copy the Pv if Pvsource  is MAN and SUB
            if(PVSOURCE_AUTO != pDumpData->PvSource)
            {
              pAiShramSlotData->Pv     = pDumpData->Pv;
            }

            pAiShramSlotData->ValvePosCalibEnb = pDumpData->bValvePosCalibEnb;
            //Store the LVDT Calib data
            for(int Index = 0; Index < NUM_CALIBREC_PER_CHANNEL; Index++)
            {
                pAiShramSlotData->CalibData[Index].LvdtRawLo           = pDumpData->CalibData[Index].LvdtRawLo;
                pAiShramSlotData->CalibData[Index].LvdtRawHi           = pDumpData->CalibData[Index].LvdtRawHi;
                pAiShramSlotData->CalibData[Index].Vxt_Fcal_Min        = pDumpData->CalibData[Index].Vxt_Fcal_Min;
                pAiShramSlotData->CalibData[Index].Vxt_Fcal_Max        = pDumpData->CalibData[Index].Vxt_Fcal_Max;
                pAiShramSlotData->CalibData[Index].FdbkA_Fcal_Min      = pDumpData->CalibData[Index].FdbkA_Fcal_Min;
                pAiShramSlotData->CalibData[Index].FdbkA_Fcal_Max      = pDumpData->CalibData[Index].FdbkA_Fcal_Max;
                pAiShramSlotData->CalibData[Index].FdbkB_Fcal_Min      = pDumpData->CalibData[Index].FdbkB_Fcal_Min;
                pAiShramSlotData->CalibData[Index].FdbkB_Fcal_Max      = pDumpData->CalibData[Index].FdbkB_Fcal_Max;
                pAiShramSlotData->CalibData[Index].ExctnFrequency      = pDumpData->CalibData[Index].ExctnFrequency;
                pAiShramSlotData->CalibData[Index].Bottom              = pDumpData->CalibData[Index].Bottom;
                pAiShramSlotData->CalibData[Index].LvdtCalibrationGood = pDumpData->CalibData[Index].LvdtCalibrationGood;
            }
            
            pAiShramSlotData->FiltOut  = pDumpData->FiltOut;
            
            pAiShramSlotData->ActualAngle       = pDumpData->ActualAngle;
            RetVal = PA_OK;
        }
    }
    return RetVal;
}

        
