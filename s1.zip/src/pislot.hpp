/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2010                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : pislot.hpp                                                  *
*    Description : Class clsPiSlot declaration.                                *
*******************************************************************************/
#ifndef __PISLOT_HPP__
#define __PISLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "scheduler.hpp"
#include "inslot.hpp"
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define PISLOT_SIZE ((sizeof(clsPiSlot) + (sizeof(clsPiSlot) % 2)) / 2)

// IOL Parameter number definitions
#define PARAMID_C1             64
#define PARAMID_C2             65
#define PARAMID_C3             66
#define PARAMID_EDGEDETECT     68
#define PARAMID_FREQPERIOD     69
#define PARAMID_INPUTSTREAM    70
#define PARAMID_PNTTYPE        74
#define PARAMID_PTEXECST       75
#define PARAMID_ENPULSEWIDTHREJ 76
#define PARAMID_PULSEINTYPE    77
#define PARAMID_PULSEMODE      78
#define PARAMID_TV64           80
#define PARAMID_SAFEOUTPUT     85
#define PARAMID_TIMEBASE       89
#define PARAMID_TV             90
#define PARAMID_VOLTAGE        93

#define FASTCUTOFF_CHN0 7
#define FASTCUTOFF_CHN1 8
#define PISLOT_SPARESIZE 8
#define NUM_IP 7

#define NOCOUNT 0
#define SECS_PER_MIN   60.0
#define MINS_PER_HOUR  60.0
#define CTR_TIMEBASE   10000000.0

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsPiSlot; // forward declaration
typedef struct tagSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsPiSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsPiSlot::* PostPtr)(UINT8);
    VOID *   (clsPiSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} SLOTPARAMINFO;

typedef enum tagStatus {
    STATUS_BAD       =0,
    STATUS_UNCERTN   =1,
    STATUS_NORMAL    =2,
    STATUS_MANUAL    =3
} STATUS;

typedef enum tagFaultState {
    FAULTSTATE_NORMAL   = 0,
    FAULTSTATE_FAULTED  = 1
}FAULTSTATE;

typedef enum tagVoltage {
    VOLTAGE_LOW   = 0,
    VOLTAGE_HIGH  = 1
} VOLTAGE;

typedef enum tagEdgeDet {
    FALLINGEDGE = 0,    
    RISINGEDGE  = 1    
} EDGEDETECT;

typedef enum tagFreqPeriod {
    FREQPERIOD_25MS     = 0,
    FREQPERIOD_50MS     = 1,
    FREQPERIOD_100MS    = 2,
    FREQPERIOD_200MS    = 3,
    FREQPERIOD_500MS    = 4,
    FREQPERIOD_1S       = 5,
    FREQPERIOD_2S       = 6
} FREQPERIOD;

typedef enum tagTimeBase {
    SECONDS   = 0,
    MINUTES   = 1,
    HOURS     = 2
} TIMEBASE;

typedef enum tagPulseMode{
    PERIOD     = 0,
    PULSE_HIGH = 1,
    PULSE_LOW  = 2
} PULSEMODE;

typedef enum tagInputStream {
    SINGLE_PULSE = 0,
    DUAL_PULSE   = 1
} INPUTSTREAM;

typedef enum tagPulseInType {
   PULSEINPUT          = 0,
   PULSEINPUT_FC       = 1
} PULSEINTYPE;

typedef enum tagSoCmdVal {
   SOCMD_OFF  = 0,
   SOCMD_ON   = 1,
   SOCMD_NONE = 2
} SOCMDVAL;

 /*******************************************************************************
*                                   clsPiSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsPiSlot : public clsInSlot {
private:
    UINT8        PiSlotSpare[PISLOT_SPARESIZE];    
    FLOAT32      ufC1;
    FLOAT32      ufC2;
    FLOAT32      ufC3;    
    EDGEDETECT   EdgeDetect;
    FREQPERIOD   FreqPeriod;
    INPUTSTREAM  InputStream;
    BOOL         EnPulseWidthRej; 
    PULSEINTYPE     InputType;
    PULSEMODE    PulseMode;         
    TIMEBASE     TimeBase;
    VOLTAGE      Voltage;         
    BOOL         SafeOutput;
    BOOL         Channel_Unused;
    UINT32       LastCount;
    UINT32       LastFRC;
    UINT32       RawCntPri0;
    FAULTSTATE   FaultState;
    SOCMDVAL     LastSoCmdVal;
    
    // !!!*** PI_SLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the PI slot's redundant synch data area.
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end or to the spare memory allocated. If new member is added to the
    // end, GetRedSlotSize() must be updated to reference the new end member. 
    // This dump record begins in clsIoSlot.

    BOOL         SoCmdOff;
    BOOL         SoCmdOn;    
    BOOL         ResetFl;
    BOOL         BadPvFl;
    FLOAT64      dTv64;
    UINT32       BadAvRaw;
    UINT32       RawCntBu0;

    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[];
    static const SLOTPARAMINFO tblParamInfo[256];

    PASTATUS PrePntType(UINT8 *a_writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPntType(UINT8 a_AccLvl);
    PASTATUS PrePtExecSt(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostPtExecSt(UINT8 a_AccLvl);     
    PASTATUS PreC1(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostC1(UINT8 a_ucAcclvl);
    PASTATUS PreC2(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostC2(UINT8 a_ucAccLvl);
    PASTATUS PreC3(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostC3(UINT8 a_ucAcclvl);
    PASTATUS PreEdgeDetect(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostEdgeDetect(UINT8 a_ucAcclvl);
    PASTATUS PreFreqPeriod(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostFreqPeriod(UINT8 a_ucAcclvl);
    PASTATUS PreEnPulseWidthRej(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostEnPulseWidthRej(UINT8 a_ucAcclvl);    
    PASTATUS PreInputStream(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostInputStream(UINT8 a_ucAcclvl);
    PASTATUS PrePulseInType(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostPulseInType(UINT8 a_ucAcclvl);
    PASTATUS PrePulseMode(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostPulseMode(UINT8 a_ucAcclvl);
    PASTATUS PreSafeOutput(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostSafeOutput(UINT8 a_ucAcclvl);
    PASTATUS PreSoCmdOff(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostSoCmdOff(UINT8 a_ucAcclvl);
    PASTATUS PreSoCmdOn(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostSoCmdOn(UINT8 a_ucAcclvl);
    PASTATUS PreTimeBase(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostTimeBase(UINT8 a_ucAcclvl);
    PASTATUS PreVoltage(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostVoltage(UINT8 a_ucAcclvl);
    PASTATUS PreResetFl(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostResetFl(UINT8 a_ucAcclvl);
    PASTATUS PreTv(UINT8 * a_Writebuffer,UINT8 a_ucAccLvl);
    VOID     PostTv(UINT8 a_ucAcclvl);    
    PASTATUS PreTv64(UINT8 * a_Writebuffer,UINT8 a_ucAccLvl);
    VOID     PostTv64(UINT8 a_ucAcclvl);    
    
    inline VOID *GetCheckPointPtr(VOID){ return (VOID *)CheckPointVerTable[SlotChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetRedParamsPtr(VOID) { return (VOID *)RedParams; }


    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
        
    VOID *GetPvPtr(VOID);
    VOID *GetPvStsPtr(VOID);    
    VOID *GetAvPtr(VOID);
    VOID *GetAvStsPtr(VOID);    
    VOID *GetAvRawPtr(VOID);
    VOID *GetAvRawStsPtr(VOID);    
    VOID *GetPlPtr(VOID);
    VOID *GetPlStsPtr(VOID);
    VOID *GetTvPtr(VOID);
    VOID *GetTvRawPtr(VOID);    
    VOID *GetTvProcPtr(VOID);
    VOID *GetSoPtr(VOID);    
    VOID *GetBadSoPtr(VOID);    
    
    inline VOID *GetBadAvRawPtr(VOID){return &BadAvRaw;}
    inline VOID *GetBadPvFlPtr(VOID){return &BadPvFl;}    
    inline VOID *GetC1Ptr(VOID){ return &ufC1;}
    inline VOID *GetC2Ptr(VOID){ return &ufC2;}
    inline VOID *GetC3Ptr(VOID){ return &ufC3;}    
    inline VOID *GetEdgeDetectPtr(VOID){ return &EdgeDetect;}
    inline VOID *GetFreqPeriodPtr(VOID){ return &FreqPeriod;}
    inline VOID *GetEnPulseWidthRejPtr(){return &EnPulseWidthRej;}    
    inline VOID *GetInputStreamPtr(VOID){return &InputStream;}
    inline VOID *GetPulseInTypePtr(VOID){return &InputType;}
    inline VOID *GetPulseModePtr(VOID){return &PulseMode;}    
    inline VOID *GetSafeOutputPtr(VOID){return &SafeOutput;}
    inline VOID *GetSoCmdOffPtr(VOID){return &SoCmdOff;}
    inline VOID *GetSoCmdOnPtr(VOID){return &SoCmdOn;}
    inline VOID *GetTimeBasePtr(VOID){return &TimeBase;}
    inline VOID *GetTv64Ptr(VOID){return &dTv64;}
    inline VOID *GetVoltagePtr(VOID){return &Voltage;}
    inline VOID *GetResetFlPtr(VOID){return &ResetFl;}

    VOID InitPiSlot(BOOL,BOOL);

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsPiSlot(const clsPiSlot&); // Safeguard against default copy constructor
    clsPiSlot& operator=(const clsPiSlot&); // and default assignment.

public: 
    clsPiSlot(UINT8);
    ~clsPiSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,PISLOT_HPP,__LINE__); }
    
    VOID *operator new(UINT32, UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,PISLOT_HPP,__LINE__); } 

    VOID InitSlotDatabase(BOOL);
    VOID InactivateSlot(VOID);
    VOID ProcessSlotIntegration(VOID);    
    VOID SlotFaultHandler(VOID);
   
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);

    inline FAULTSTATE GetFaultState(VOID){return FaultState;}
    inline VOID ResetFaultState(VOID){FaultState = FAULTSTATE_NORMAL;}
    inline FLOAT32 GetC1(VOID){return ufC1;}
    inline FLOAT32 GetC2(VOID){return ufC2;}
    inline FLOAT32 GetC3(VOID){return ufC3;}    
    inline EDGEDETECT GetEdgeDetect(VOID){return EdgeDetect;}
    inline FREQPERIOD GetFreqPeriod(VOID){return FreqPeriod;}
    inline INPUTSTREAM GetInputStream(VOID){return InputStream;}
    inline PULSEINTYPE GetPulseInType(VOID){return InputType;}
    inline BOOL GetPwReject(VOID){return EnPulseWidthRej;}
    inline PULSEMODE GetPulseMode(VOID){return PulseMode;}
    inline BOOL GetSafeOutput(VOID){return SafeOutput;}
    inline VOLTAGE GetVoltage(VOID){return Voltage;}
    inline UINT32 GetRawCntPri0(VOID){return RawCntPri0;}
    inline UINT32 GetRawCntBu0(VOID){return RawCntBu0;}
    inline UINT32 GetRedSlotDelta(VOID) {return 0;}
    inline UINT32 GetRedSlotSize(VOID) {
        return ((UINT32)((UINT8 *)&LastSoCmdVal - (UINT8 *)&PntType) + sizeof(LastSoCmdVal));                 
    }

    inline UINT8 *GetRedSlotPointer(VOID) {
        return (UINT8 *)&PntType;
    }

    inline VOID ClrCtrArchive(VOID) { LastCount = 0; }

    inline VOID StoreBadAvRaw(UINT32 a_ulAvRaw) {
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    //disable IOL interrupts
        BadAvRaw = a_ulAvRaw;
        set_imask_exr(ucSaveExr);         // re-enable IOL interrupts
    }
    
    inline VOID StoreRawCntPri0(UINT32 a_ulAvRaw) {
        RawCntPri0 = a_ulAvRaw;
    }

    inline VOID StoreRawCntBu0(UINT32 a_ulAvRaw) {
        RawCntBu0 = a_ulAvRaw;
    }

    inline VOID StoreTv64(FLOAT64 a_dTv) {
        dTv64 = a_dTv;
    }

    inline VOID UpdateBadPvFl(BOOL a_bFlag) { BadPvFl = a_bFlag; }
    inline SOCMDVAL GetLastSoCmdVal(VOID){return LastSoCmdVal;}
    inline VOID SetLastSoCmdVal(SOCMDVAL a_LastSoCmdVal){LastSoCmdVal = a_LastSoCmdVal;}
};

#endif
