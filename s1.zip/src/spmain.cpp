/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spmain.cpp                                                  *
*    Description : Speed Protection module application specific startup code.  *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN TCDiagnosticTask(TASKCONTEXT);
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif

/*******************************************************************************
*                               EXTERNAL DATA                                  *
*******************************************************************************/
extern SHRAMDATA ShramData;

/*******************************************************************************
*                            GLOBAL  FUNCTIONS                                 *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT);
TASKRETURN CalibrationTask(TASKCONTEXT);

/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
WRITEINPROGRESS  WriteInProgress;
#ifdef DEBUG
clsDebugPort     DebugPort;
#endif

// Global objects
clsTaskScheduler TaskScheduler;

//To Retain the tracelogs at Reset
#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section

#pragma section  INTERNALRAM_SECTION
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;
clsEeprom        Eeprom;
clsShramWriteMsgQueue ShramMsgQueue;
#pragma section 

//Instance for IOLINK and APPLICATION processor SCS Queues
clsIoLinkFifo IolinkScsFifo;
clsIoLinkFifo AppScsFifo;

// Pointers to database objects
clsIomSlot       *pDatabase[MAXSLOTS + 1];

// Database Memory
UINT16 ucIomDbMemory[SPBOXSLOT_SIZE+(AI_MAXSLOTS * TCSPAISLOT_SIZE)+\
                    (AO_MAXSLOTS*TCSPAOSLOT_SIZE)+(DI_MAXSLOTS*DISLOT_SIZE)+\
                    (SP_MAXSLOTS*SPSLOT_SIZE)+(DO_MAXSLOTS*TCDOSLOT_SIZE)+\
                    (VOTLOGIC_BLOCK*SPVOTLOGIC_SIZE)];

/// Address after ucIomDbMemory.Used in testparam support.
UINT16* gIomDbMemoryEndPtr = ((UINT16*)ucIomDbMemory + word_sizeof(ucIomDbMemory));

//Flag utilized to prevent the stcappprocessing from checking the state 
//of the redundancy switches when switch diagnostcis will be running
BOOL bSwitchDiagRunning = FALSE;
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//NOTE:
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                            WriteDatabaseTask
                                           ,LowPriorityTask
                                           ,CalibrationTask
                                           ,EventRecoveryTask
                                           ,TCDiagnosticTask
#ifdef DEBUG
                                           ,DebugTask
#endif
};

/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE  : Application specific startup code.                                *
* ARGUMENTS: NONE.                                                             *
* RETURN   : NONE.                                                             *
* NOTES    : This function is called by the PowerOn reset vector.              *
*******************************************************************************/
VOID main(VOID) 
{
    // Link app trace log.
    TraceLog.StoreAppTraceLogPtr(&ShramData.AppTraceLog);

    // Create box and slot database objects
    pDatabase[0] = new clsSpBoxSlot(MODLTYPE_SP);
    TraceLog.AddToTrace(TRACEID_GENERIC,bcAiIom,BOX->GetDPA());

    // Create object instances for AI 
    for (UINT8  ucSltNm=AI_CH_START;ucSltNm <= AI_CH_END;ucSltNm++)
    {
        pDatabase[ucSltNm] = new(ucSltNm) clsTcSpAiSlot(ucSltNm); 
    }

    // Create object instances for AO
    pDatabase[AO_CH_START] = new(AO_CH_START) clsTcSpAoSlot(AO_CH_START);

    // Create object instnaces for DI channels
    for (UINT8 ucSltNm = DI_CH_START;ucSltNm <= DI_CH_END;ucSltNm++)
    {
        pDatabase[ucSltNm] = new(ucSltNm) clsDiSlot(ucSltNm); 
    }
 
    // Create object instnaces for DO channels
    for (UINT8 ucSltNm = DO_CH_START;ucSltNm <= DO_CH_END;ucSltNm++) 
    {
        pDatabase[ucSltNm] = new(ucSltNm) clsDoSlot(ucSltNm); 
    }

    // Create object instnaces for SPEED channels
    for (UINT8 ucSltNm = SP_CH_START; ucSltNm <= SP_CH_END; ucSltNm++) 
    {
        pDatabase[ucSltNm ] = new(ucSltNm) clsSpSlot(ucSltNm);
    } 

    // Create object instnaces for Voting channel
    pDatabase[VOTLOGIC_BLOCK_START] = new(VOTLOGIC_BLOCK_START) clsVotLogicSlot(VOTLOGIC_BLOCK_START);

    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone); 

    // Initialize IOLINK and Application Processor SCS Queues
    IolinkScsFifo.clsIoLinkFifoInit((UINT32)(ShramData.ScsMem),SCS_BUFFER_SIZE);
    AppScsFifo.clsIoLinkFifoInit((UINT32)(ShramData.ScsMemApp),SCS_BUFFER_SIZE);

    // Initialize periodic tasks.
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
                                      DMCPERIOD_LPTASK);
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
                                        DMCPERIOD_DIAGTASK);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();

#ifdef DEBUG
    // Set the Debug Task to RUN State
    TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif
    
    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}

/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE  : LowPriorityTask Runs every 1 seconds,                             *
* ARGUMENTS: a_TaskContext - Task Context                                      *
* RETURN   : TASKRETURN - returns the task current status                      *
* NOTES    :                                                                   *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    const UINT8 SWTCH_DIAG_COUNT = 5;
    static UINT8 ucSwDiagCntr= 0;

    static TOG_FAILED LastTogFailed = NOTOG_FAILED;
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

    //check if the modules are settled 
    if(((OUTCTL_PARTNER == BOX->GetModStat3State())&&(!Iol.AmPrimary()))||
        ((OUTCTL_MINE == BOX->GetModStat3State())&&(Iol.AmPrimary())))
    {
        // Check for Communication failure and CEE Failure. If any one of these present, 
        // call FaultHandling function which sheds the output according to Mode and 
        // ModeAttr configuration.
        TOG_FAILED TogFailed = BOX->IsTogFailed();

        if (BOX->CheckForFactoryTestMode())
        {
            TogFailed = NOTOG_FAILED; //override the Togfailed status with NO TOG FAILED to avoid the mode shed due to TOG timeout
        }
        
        if (NOTOG_FAILED != TogFailed)
        {   
            if (COMTOG_FAILED == TogFailed)
            {
                if(LastTogFailed!=TogFailed)
                {
                    //Handle Communication TOG Failure for AO Channel
                    if(FAULTSTATE_NORMAL == AO_SLOT(AO_CH_START)->GetFaultState()) 
                    {
                        AO_SLOT(AO_CH_START)->SlotFaultHandler(TogFailed);
                    }

                    //Send SCS to Application Processor to Handle Communication TOG Failure for DO Channels
                    IolinkScsFifo.SendSCSCommand(SCS_COMTOG_FAILED);
                }
            }
            
            if (CTLTOG_FAILED == TogFailed)
            {
                if(LastTogFailed!=TogFailed)
                {
                   //Handle Control TOG Failure for AO Channel
                   if(FAULTSTATE_NORMAL == AO_SLOT(AO_CH_START)->GetFaultState()) 
                   {
                        AO_SLOT(AO_CH_START)->SlotFaultHandler(TogFailed);
                   }

                   //Send SCS to Application Processor to Handle Control TOG Failure for DO Channels
                   IolinkScsFifo.SendSCSCommand(SCS_CTLTOG_FAILED);
                }
            }
            
        }
        else if ((BOX->GetComTog() == TRUE) && (BOX->GetCtlTog() == TRUE)) 
        {
            if (FAULTSTATE_FAULTED == AO_SLOT(AO_CH_START)->GetFaultState()) 
            {
                AO_SLOT(AO_CH_START)->ResetFaultState();
                AO_SLOT(AO_CH_START)->BackInit();
            }
            //Send SCS to Application Processor to Handle both CTL and COMM TOG are Good for DO Channels
            IolinkScsFifo.SendSCSCommand(SCS_NOTOG_FAILED);
        }
        LastTogFailed = TogFailed;
        
    }

    //Perform the loopback test only if calibration was done 
    if(TRUE == BOX->IsAOCalibrationGood())
    { 
        static UINT8 nDelay = 10; //Startup delay, delay the diagnostics by 100 * 10 = 1000ms
        if(!--nDelay)
        {
            //Only if channel is configured, TestLoopbackCircuit is performed
            if(AO_SLOT(AO_CH_START)->IsChnlConfig())
            {
                // Check operation of loopback circuit.
                BOX->TestLoopbackCircuit();
            }
        
            //Run the switch diagnostics every 500msec
            if(0 == ucSwDiagCntr)
            {
                //Set the Diag run flag so that switch status will not be checked 
                //in stcprocessing routine
                bSwitchDiagRunning = TRUE;
                //Since the hardfail is the outcome of failure of this diagnostics 
                //ignore the return value
                if (!(BOX->CheckForFactoryTestMode())){ //do not execute in Factory Mode
                    SwitchDiagnostics();
                }
                ucSwDiagCntr = SWTCH_DIAG_COUNT;
                bSwitchDiagRunning = FALSE;
            }
            else 
            {
                ucSwDiagCntr--;
            }
        }
        
     }
    
    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}

/*******************************************************************************
*                                CalibrationTask                               *
*                                ===============                               *
* PURPOSE  : CalibrationTask Runs when calibration is performed                *
* ARGUMENTS: a_TaskContext - Task Context                                      *
* RETURN   : TASKRETURN - returns the task current status                      *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN CalibrationTask(TASKCONTEXT a_TaskContext)
{
#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                                      "\n\r\tStarting calibration...\n\r"));
#endif

    TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibStart,FACTCAL);

    IdleWait(MICROSECONDS_IN_MILLISECOND);

    if (FALSE == BOX->PerformModuleCalibration()) 
    { 
        // Calibration was aborted for failed.
        TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibAbort,MODULEINFO_WRITECOUNT);

#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                                          "\n\r\tCalibration aborted"));
#endif
    }

    TASKRETURN      TaskReturnValue;
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;

    return TaskReturnValue;
}
