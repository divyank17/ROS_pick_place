/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spslot.cpp                                                  *
*    Description : Class clsSpSlot definition.                                 *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern SHRAMDATA ShramData;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsSpSlot::RedParams[] = {
    kSpSpdPnPntType,
    kSpSpdPnPtExecSt,
    kSpSpdPnPvClamp,
    kSpSpdPnPvSrcOpt,
    kSpSpdPnPvSource,
    kSpSpdPnSensrType,
    kSpSpdPnTeethCnt,
    kSpSpdPnGearRatio,
    kSpSpdPnEdgDetect,
    kSpSpdPnPvhiAlm_Tp,
    kSpSpdPnPvHhAlm_Tp,
    kSpSpdPnRocPosHiAlm_Tp,
    kSpSpdPnRocPosHhAlm_Tp,
    kSpSpdPnCrSpeed,
    kSpSpdPnNmSpeed,
    kSpSpdPnFilterTime,
    kSpSpdPnPvHhAlm_Flwrst,
    kSpSpdPnRocPosHhAlm_Flwrst,
    kSpSpdMeasurementType,  
    kSpSpdOrdrerOfKFactor,  
    kSpSpdFirstOrderKFactor,
    kSpSpdMinFlowRate,      
    kSpSpdKMinFlowRate,     
    kSpSpdMaxFlowRate,      
    kSpSpdKMaxFlowRate,
    kSpSpdTimeUnit,
    0 // Terminator
};

const SLOTPARAMINFO clsSpSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,NoOfParams,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 0
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 1
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 2
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 3
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 4
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 5
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 6
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 7
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 8
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 9
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 45
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPv100Ptr,FALSE,                                // 46 Pv100
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPntTypePtr,TRUE,                                   // 51 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPtExecStPtr,TRUE,                                 // 52 PtExecSt
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 53
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 54
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastPvPtr,FALSE,                               // 55 LastPv
    DT_FLOAT32,4,AT_BXREC,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPvPtr,FALSE,                                    //56 Pv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetRocPvPtr,FALSE,                                // 57 RocPv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoPtr,FALSE,                               // 58 PvAuto
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoStPtr,FALSE,                                // 59 PvAutoSt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvCalcPtr,FALSE,                               // 60 PvCalc
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,0,0,GetPvClampPtr,TRUE,                               // 61 PvClamp
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 62
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 63
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 64
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 65
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 66
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 67
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvPPtr,FALSE,                                  // 68 PvP
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvRawPtr,FALSE,                                // 69 PvRaw
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPvSourcePtr,TRUE,                                 // 70 PvSource
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetPvSrcOptPtr,TRUE,                                 // 71 PvSrcOpt
    DT_ENUM,1,AT_BXREC,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvStsPtr,FALSE,                                   // 72 PvSts
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 73
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 74 
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetOwdEnablePtr,FALSE,                                // 75 OwdEnable
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetSpSensrTypePtr,TRUE,                               // 76 SpSensrType
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetGearRatioPtr,TRUE,                              // 77 GearRatio
    DT_UINT16,2,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetTeethCntPtr,TRUE,                                // 78 TeethCnt
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetEdgeDetectPtr,TRUE,                                // 79 EdgeDetect
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOwdFlPtr,FALSE,                                   // 80 OwdFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetMisgPulFlPtr,FALSE,                               // 81 MisgPulFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetDefmPulFlPtr,FALSE,                               // 82 DefmPulFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetExciFailFlPtr,FALSE,                              // 83 ExciFailFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetZeroSpdFlPtr,FALSE,                               // 84 ZeroSpdFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 86
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetPvHiAlmTPPtr,TRUE,                             // 87 PvHiAlmTP  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 92
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvHiAlmFLPtr,FALSE,                               // 93 PvHiAlmFL
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 94
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetPvHHAlmTPPtr,TRUE,                             // 95 PvHHAlmTP
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 100
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvHHAlmFLPtr,FALSE,                               // 101 PvHHAlmFL
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 102
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvHHAlmFlwrstPtr,FALSE,                           // 103 PvHHAlmFlwrst
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 104
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetRocPosHiAlmTPPtr,TRUE,                         // 105 RocPosHiAlmTP
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 110
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetRocPosHiAlmFLPtr,FALSE,                           // 111 RocPosHiAlmFL
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 112
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetRocPosHHAlmTPPtr,TRUE,                         // 113 RocPosHHAlmTP
    DT_BLIND,62,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCheckPointPtr,FALSE,                             // 114 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 115
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetRocPosHHAlmFLPtr,FALSE,                           // 116 RocPosHHAlmFL
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 117
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetRocPosAlmFlwrstPtr,FALSE,                         // 118 RocPosAlmFlwrst
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 121 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 122 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 126
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetFilterTimePtr,TRUE,                               // 127 FilterTime
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,                               // 128 SlotSfBt
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetCriticalSpdPtr,TRUE,                            // 129 CriticalSpd
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetNominalSpdPtr,TRUE,                             // 130 NominalSpd
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastROCNegLldrCrSpdPtr,FALSE,                  // 131 LastROCNegLldrCrSpd
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastROCPosHhdrNmSpdPtr,FALSE,                  // 132 LastROCPosHhdrNmSpd
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetMeasurementTypePtr,TRUE,                           // 133 MeasurementType
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetOrderOfKFactorPtr,TRUE,                            // 134 Order of KFactor
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetKFactorPtr,TRUE,                           // 135 K Factor
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetMinFlowRatePtr,TRUE,                       // 136 Min Flow Rate
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetKMinFlowRatePtr,TRUE,                      // 137 K Min Flow Rate
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetMaxFlowRatePtr,TRUE,                       // 138 Max Flow Rate
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetKMaxFlowRatePtr,TRUE,                      // 139 K Max Flow Rate
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,0,0,GetTimeUnitPtr,TRUE,                             // 140 Time Unit
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetResetPvPtr,FALSE,                                 // 141 ResetPv
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 142
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 155 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 156 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 157 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 158 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 159 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 160 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 161 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 162 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 163 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 173 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 174 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 195  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 199  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 207 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 208 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 213 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 214 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 234 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 235 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 236 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 237 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 238 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 239 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 240 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 241 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 242 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 243 
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,                      // 244 SlotChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 255
};

/*******************************************************************************
*                            clsSpSlot::clsSpSlot                              *
*                            ====================                              *
* PURPOSE   : Constructor of clsSpSlot Class. which initializes  class         *
*             members.                                                         *
* ARGUMENTS : a_ucSltNm - Slot Number                                          *
* RETURN    : NONE                                                             *
* NOTES:    :                                                                  *
*******************************************************************************/
clsSpSlot::clsSpSlot(UINT8 a_ucSltNm) : clsInSlot(PNTTYPE_NOTCONFIGURED, a_ucSltNm) 
{
    //Get the slot shared ram pointer into local variable
    UINT8 nSlotNum = a_ucSltNm - SP_CH_START;
    pSpeedShramSlotData = &ShramData.ShramSlotData.SpeedShramSlotData[nSlotNum];

    //Initialize the members variables
    InitSpSlot(TRUE, TRUE);
}

/*******************************************************************************
*                           clsSpSlot::operator new                            *
*                           =======================                            *
* PURPOSE  : Overrided new Operator to allocate memory to Slot                 *
* ARGUMENTS: a_ucSltNm - Slot Number                                           *
* RETURN   : returns slot memory pointer                                       *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::operator new(UINT32, UINT8 a_ucSltNm) { 

    return (ucIomDbMemory + SPBOXSLOT_SIZE + (AI_MAXSLOTS * TCSPAISLOT_SIZE)+ 
           (AO_MAXSLOTS * TCSPAOSLOT_SIZE)+ (DI_MAXSLOTS * DISLOT_SIZE) +
           ((DO_MAXSLOTS * TCDOSLOT_SIZE) + (a_ucSltNm-SP_CH_START)* SPSLOT_SIZE));//Note::

}

/*******************************************************************************
*                          clsSpSlot::GetDataType                              *
*                          ======================                              *
* PURPOSE  : This function returns data type of the parameter.                 *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : DataType of the parameter                                         *
* NOTES    :                                                                   *
*******************************************************************************/
DATATYPE clsSpSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsSpSlot::GetAccessType                            *
*                          ========================                            *
* PURPOSE  : This function returns accesstype of the parameter.                *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : AccessType of the parameter.                                      *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSTYPE clsSpSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                            clsSpSlot::GetParamSize                           *
*                            =======================                           *
* PURPOSE  : This function returns size of the parameter                       *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsSpSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsSpSlot::GetParamPtr                            *
*                            ======================                            *
* PURPOSE  : This function returns pointer of the parameter                    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 *clsSpSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))(); 
}

/*******************************************************************************
*                           clsSpSlot::GetAccessLock                           *
*                           =========================                          *
* PURPOSE  : This function returns Access Lock of the parameter.               *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Access Lock of the parameter number.                              *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSLOCK clsSpSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                       clsSpSlot::GetIsDbChecksumed                           *
*                       ============================                           *
* PURPOSE  : This function returns whether parameter.is checkpointed or not    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : BOOL - TRUE if parameter is checkpoint paramter, else FALSE       *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsSpSlot::VerifyControlState                        *
*                         ==============================                       *
* PURPOSE  : This function checks the contorl state assigned to the parameter  *
*            to actual present control state of the channel and IOM module     *
*            itself,before the actual write to the parameter.                  *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    : This function decides whether the write can be done or not to the *
*            paramerter under current channel or IOM state.                    *
*******************************************************************************/
PASTATUS clsSpSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    UINT8 PntExecSts   = (PTEXECST)pSpeedShramSlotData->PtExecSt;
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PntExecSts) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PntExecSts) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PntExecSts) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x911,tblParamInfo[a_ucParamNumber].ControlState);
        break;
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsDiSlot::ExecutePreFunction                        *
*                         =============================                        *
* PURPOSE  : This function invokes the pre-function for the given writable     *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber  - Parameter Number                               *
*            a_Buffer         - Pointer to the data                            *
*            a_ucAccessLevel  - Access level of the parameter                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsSpSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                       UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsSpSlot::ExecutePostFunction                       *
*                         ===============================                      *
* PURPOSE  : This function invokes the post-function for the given writable    *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber - Parameter Number                                *
*            a_ucAccessLevel - Access level of the parameter                   *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                    UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}

/*******************************************************************************
*                           clsSpSlot::InitSlotDatabase                        *
*                           ============================                       *
* PURPOSE  : Initialize the entire channel database. Calls the Init function   *
*            for each class in the channel object hierarchy and recompute      *
*            database checksum.                                                *
* ARGUMENTS: bFullInit - lag utilised when slots have to be reinitialized      *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpSlot::InitSlotDatabase(BOOL bFullInit) 
{
    BOOL bObjCreate = FALSE; 

    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitInSlot(bFullInit, bObjCreate);
    InitSpSlot(TRUE, TRUE);

    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                           clsSpSlot::InitSpSlot                              *
*                           =======================                            *
* PURPOSE  : Initialization function for clsSpSlot data members.               *
* ARGUMENTS: bFullInit   - Flag utilised when slots have to be reinitialized   *
*            bObjCreate  - Flag utilised when slots have to be reinitialized   *
* RETURN   : NONE                                                              *
* NOTES    : This function is called when slot parameters                      *
*            need to be reinitialized                                          *
*******************************************************************************/
VOID clsSpSlot::InitSpSlot(BOOL bFullInit, BOOL) 
{
    PvRaw     = NaN;
    PvCalc    = NaN;
    PvAuto    = NaN;
    PvAutoSt  = PVVALST_BAD;
    LastPv    = NaN;
    PvClamp   = PVCLAMP_NOCLAMP;

    if (bFullInit) {
        Pv       = NaN;
        PvSts    = PVVALST_BAD;
        RocPv    = 0.0;
        BadPvFl  = TRUE;
        PvP      = NaN;
        Pv100    = NaN;
    }

    SpSensrType = ACTIVE_SENSR;
    EdgeDetect  = RAISING;
    GearRatio   = 1;
    TeethCnt    = 60;
    FilterTime  = FT5MS;
    OwdFl       = FALSE;
    ExciFailFl  = FALSE;
    RevRotFl    = FALSE;
    ZeroSpdFl   = FALSE;
    MisgPulFl   = FALSE;
    DefmPulFl   = FALSE;

    CriticalSpd   = NaN;
    NominalSpd    = NaN;
    RocPosLm      = NaN;
    RocNegLm      = NaN;
    PvHiAlmTP     = NaN;
    PvHiAlmFL     = FALSE;
    PvHHAlmTP     = NaN;
    PvHHAlmFL     = FALSE;
    PvHHAlmFlwrst = FALSE;
    RocPosHiAlmTP = NaN;
    RocPosHiAlmFL = FALSE;
    RocPosHHAlmTP = NaN;
    RocPosHHAlmFL = FALSE;
    RocPosAlmFlwrst = FALSE;
    LastROCNegLldrCrSpd = NaN;
    LastROCPosHhdrNmSpd = NaN;
    ResetPv = FALSE;
}

/*******************************************************************************
*                    Get Methods for Speed Channels Parameters                 *
*******************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////
//Getting the data from shared ram database into local copy and returns the pointers
//////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
//Overrided clsIoSlot Class Varibles GetPtr methods
//////////////////////////////////////////////////////////
/*******************************************************************************
*                         clsSpSlot::GetPntTypePtr                             *
*                         ========================                             *
* PURPOSE  : This function returns PntType Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPntTypePtr(VOID)    
{
    PntType    = (PNTTYPE)pSpeedShramSlotData->PntType;

    return &PntType; 
}

/*******************************************************************************
*                         clsSpSlot::GetPtExecStPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns PtExecSt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPtExecStPtr(VOID)   
{ 
    PtExecSt   = (PTEXECST)pSpeedShramSlotData->PtExecSt;
    
    return &PtExecSt; 
}

///////////////////////////////////////////////////////////
//Overrided clsInSlot Class Varibles GetPtr methods
///////////////////////////////////////////////////////////
/*******************************************************************************
*                         clsSpSlot::GetPvSourcePtr                            *
*                         =========================                            *
* PURPOSE  : This function returns PvSource Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvSourcePtr(VOID)   
{ 
    PvSource   = (PVSOURCE)pSpeedShramSlotData->PvSource;
    
    return &PvSource; 
}

/*******************************************************************************
*                         clsSpSlot::GetPvSrcOptPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns PvSrcOpt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvSrcOptPtr(VOID)   
{ 
    PvSrcOpt   = (PVSRCOPT)pSpeedShramSlotData->PvSrcOpt;

    return &PvSrcOpt; 
}

/*******************************************************************************
*                         clsSpSlot::GetOwdEnablePtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns OwdEnable Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetOwdEnablePtr(VOID)  
{ 
    OwdEnable  = (BOOL)pSpeedShramSlotData->OwdEnable;

    return &OwdEnable; 
}

///////////////////////////////////////////////////////////
//Overrided clsSpSlot Class Varibles GetPtr methods
///////////////////////////////////////////////////////////
/*******************************************************************************
*                         clsSpSlot::GetPvPtr                                  *
*                         ===================                                  *
* PURPOSE  : This function returns PV Parameter Pointer                        *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvPtr(VOID)
{
    Pv = (FLOAT32)pSpeedShramSlotData->Pv;

    return &Pv;
}

/*******************************************************************************
*                         clsSpSlot::GetPv100Ptr                               *
*                         ======================                               *
* PURPOSE  : This function returns PV100 Parameter Pointer                     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPv100Ptr(VOID)
{
    Pv100 = (FLOAT32)pSpeedShramSlotData->Pv;

     //get the correspoinding Nominal Speed
    FLOAT32 NSpd  = (FLOAT32)pSpeedShramSlotData->NominalSpd;

    //If Nominal Speed is not equal zero then
    //Calculate PV using the formala PV (range from 0 to 100) = (Pv/NominalSpeed) * 100%
    if(NSpd != 0) {
        Pv100 = (Pv100/NSpd) * 100;
    }
    else { //If Zero, PV is NaN
        Pv100 = NaN;
    }

    return &Pv100;
}

/*******************************************************************************
*                         clsSpSlot::GetPvStsPtr                               *
*                         ======================                               *
* PURPOSE  : This function returns PvSts Parameter Pointer                     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvStsPtr(VOID)
{
    PvSts = (PVVALST)pSpeedShramSlotData->PvSts;

    return &PvSts;
}

/*******************************************************************************
*                         clsSpSlot::GetPvRawPtr                               *
*                         ======================                               *
* PURPOSE  : This function returns PvRaw Parameter Pointer                     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvRawPtr(VOID)    
{
    PvRaw = (FLOAT32)pSpeedShramSlotData->PvRaw;

    return &PvRaw;   
}

/*******************************************************************************
*                         clsSpSlot::GetPvCalcPtr                              *
*                         =======================                              *
* PURPOSE  : This function returns PvCalc Parameter Pointer                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvCalcPtr(VOID)   
{
    PvCalc = (FLOAT32)pSpeedShramSlotData->PvCalc;

    return &PvCalc;  
}

/*******************************************************************************
*                         clsSpSlot::GetPvAutoPtr                              *
*                         =======================                              *
* PURPOSE  : This function returns PvAuto Parameter Pointer                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvAutoPtr(VOID)   
{
    PvAuto = (FLOAT32)pSpeedShramSlotData->PvAuto;

    return &PvAuto;  
}

/*******************************************************************************
*                         clsSpSlot::GetPvAutoStPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns PvAutoSt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvAutoStPtr(VOID) 
{
    PvAutoSt = (PVVALST)pSpeedShramSlotData->PvAutoSt;

    return &PvAutoSt;
}

/*******************************************************************************
*                         clsSpSlot::GetLastPvPtr                              *
*                         =======================                              *
* PURPOSE  : This function returns LastPv Parameter Pointer                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetLastPvPtr(VOID)   
{
    LastPv = (FLOAT32)pSpeedShramSlotData->LastPv;

    return &LastPv;  
}

/*******************************************************************************
*                         clsSpSlot::GetRocPvPtr                               *
*                         ======================                               *
* PURPOSE  : This function returns RocPv Parameter Pointer                     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetRocPvPtr(VOID)    
{
    RocPv = (FLOAT32)pSpeedShramSlotData->RocPv;

    return &RocPv;
}

/*******************************************************************************
*                         clsSpSlot::GetPvPPtr                                 *
*                         ====================                                 *
* PURPOSE  : This function returns PvP Parameter Pointer                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvPPtr(VOID)      
{
    PvP = (FLOAT32)pSpeedShramSlotData->PvP;

    return &PvP;     
}

/*******************************************************************************
*                         clsSpSlot::GetPvClampPtr                             *
*                         ========================                             *
* PURPOSE  : This function returns PvClamp Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvClampPtr(VOID)  
{
    PvClamp = (PVCLAMP)pSpeedShramSlotData->PvClamp;

    return &PvClamp;
}

/*******************************************************************************
*                         clsSpSlot::GetSpSensrTypePtr                         *
*                         ============================                         *
* PURPOSE  : This function returns SensrType Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetSpSensrTypePtr(VOID)   
{
    SpSensrType = (SENSRTYPE)pSpeedShramSlotData->SensrType;

    return &SpSensrType;
}

/*******************************************************************************
*                         clsSpSlot::GetEdgeDetectPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns EdgeDetect Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetEdgeDetectPtr(VOID)    
{
    EdgeDetect = (EDGEDETECT)pSpeedShramSlotData->EdgeDetect;

    return &EdgeDetect;
}

/*******************************************************************************
*                         clsSpSlot::GetGearRatioPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns GearRatio Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetGearRatioPtr(VOID)     
{
    GearRatio = (FLOAT32)pSpeedShramSlotData->GearRatio;

    return &GearRatio;
}

/*******************************************************************************
*                         clsSpSlot::GetTeethCntPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns TeethCnt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetTeethCntPtr(VOID)      
{
    TeethCnt = (UINT16)pSpeedShramSlotData->TeethCount;

    return &TeethCnt;
}

/*******************************************************************************
*                         clsSpSlot::GetOwdFlPtr                               *
*                         ======================                               *
* PURPOSE  : This function returns OwdFl Parameter Pointer                     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetOwdFlPtr(VOID)         
{
    OwdFl = (BOOL)pSpeedShramSlotData->OwdFl;

    return &OwdFl;
}
 
/*******************************************************************************
*                         clsSpSlot::GetMisgPulFlPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns MisgPulFl Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetMisgPulFlPtr(VOID)     
{
    MisgPulFl = (BOOL)pSpeedShramSlotData->MisgPulFl;

    return &MisgPulFl;
}

/*******************************************************************************
*                         clsSpSlot::GetDefmPulFlPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns DefmPulFl Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetDefmPulFlPtr(VOID)     
{
    DefmPulFl = (BOOL)pSpeedShramSlotData->DefmPulFl;

    return &DefmPulFl;
}

/*******************************************************************************
*                         clsSpSlot::GetExciFailFlPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns ExciFailFl Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetExciFailFlPtr(VOID)    
{
    ExciFailFl = (BOOL)pSpeedShramSlotData->ExciFailFl;

    return &ExciFailFl;
}

/*******************************************************************************
*                         clsSpSlot::GetZeroSpdFlPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns ZeroSpdFl Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetZeroSpdFlPtr(VOID)     
{
    ZeroSpdFl = (BOOL)pSpeedShramSlotData->ZeroSpdFl;

    return &ZeroSpdFl;
}

/*******************************************************************************
*                         clsSpSlot::GetRocPosLmPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns RocPosLm Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetRocPosLmPtr(VOID)      
{
    RocPosLm = pSpeedShramSlotData->RocPosLm;
    
    return &RocPosLm;
}

/*******************************************************************************
*                         clsSpSlot::GetPvHiAlmTPPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns PvHiAlmTP Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvHiAlmTPPtr(VOID)      
{
    PvHiAlmTP = (FLOAT32)pSpeedShramSlotData->PvHiAlmTP;

    return &PvHiAlmTP;
}

/*******************************************************************************
*                         clsSpSlot::GetPvHiAlmFLPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns PvHiAlmFL Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvHiAlmFLPtr(VOID)      
{
    PvHiAlmFL = (BOOL)pSpeedShramSlotData->PvHiAlmFL;

    return &PvHiAlmFL;
}

/*******************************************************************************
*                         clsSpSlot::GetPvHHAlmTPPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns PvHHAlmTP Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvHHAlmTPPtr(VOID)      
{
    PvHHAlmTP = (FLOAT32)pSpeedShramSlotData->PvHHAlmTP;

    return &PvHHAlmTP;
}

/*******************************************************************************
*                         clsSpSlot::GetPvHHAlmFLPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns PvHHAlmFL Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvHHAlmFLPtr(VOID)      
{
    PvHHAlmFL = (BOOL)pSpeedShramSlotData->PvHHAlmFL;

    return &PvHHAlmFL;
}

/*******************************************************************************
*                         clsSpSlot::GetPvHHAlmFlwrstPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns PvHHAlmFlwrst Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetPvHHAlmFlwrstPtr(VOID)      
{
    PvHHAlmFlwrst = (BOOL)pSpeedShramSlotData->PvHHAlmFlwrst;

    return &PvHHAlmFlwrst;
}

/*******************************************************************************
*                         clsSpSlot::GetRocPosHiAlmTPPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns RocPosHiAlmTP Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetRocPosHiAlmTPPtr(VOID)      
{
    RocPosHiAlmTP = (FLOAT32)pSpeedShramSlotData->RocPosHiAlmTP;

    return &RocPosHiAlmTP;
}

/*******************************************************************************
*                         clsSpSlot::GetRocPosHiAlmFLPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns RocPosHiAlmFL Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetRocPosHiAlmFLPtr(VOID)      
{
    RocPosHiAlmFL = (BOOL)pSpeedShramSlotData->RocPosHiAlmFL;

    return &RocPosHiAlmFL;
}

/*******************************************************************************
*                         clsSpSlot::GetRocPosHHAlmTPPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns RocPosHHAlmTP Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetRocPosHHAlmTPPtr(VOID)      
{
    RocPosHHAlmTP = (FLOAT32)pSpeedShramSlotData->RocPosHHAlmTP;

    return &RocPosHHAlmTP;
}

/*******************************************************************************
*                         clsSpSlot::GetRocPosHHAlmFLPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns RocPosHHAlmFL Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetRocPosHHAlmFLPtr(VOID)      
{
    RocPosHHAlmFL = (BOOL)pSpeedShramSlotData->RocPosHHAlmFL;

    return &RocPosHHAlmFL;
}

/*******************************************************************************
*                         clsSpSlot::GetRocPosAlmFlwrstPtr                     *
*                         ================================                     *
* PURPOSE  : This function returns RocPosAlmFlwrst Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetRocPosAlmFlwrstPtr(VOID)      
{
    RocPosAlmFlwrst = (BOOL)pSpeedShramSlotData->RocPosHHAlmFlwrst;

    return &RocPosAlmFlwrst;
}

/*******************************************************************************
*                         clsSpSlot::GetLastROCNegLldrCrSpdPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns LastROCNegLldrCrSpd Parameter               *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetLastROCNegLldrCrSpdPtr(VOID)  
{ 
    LastROCNegLldrCrSpd   = (FLOAT32)pSpeedShramSlotData->LastROCNegLldrCrSpd;

    return &LastROCNegLldrCrSpd; 
}

/*******************************************************************************
*                         clsSpSlot::GetLastROCPosHhdrNmSpdPtr                 *
*                         ====================================                 *
* PURPOSE  : This function returns LastROCPosHhdrNmSpd Parameter Pointer       *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetLastROCPosHhdrNmSpdPtr(VOID)  
{ 
    LastROCPosHhdrNmSpd   = (FLOAT32)pSpeedShramSlotData->LastROCPosHhdrNmSpd;

    return &LastROCPosHhdrNmSpd; 
}

/*******************************************************************************
*                         clsSpSlot::GetCriticalSpdPtr                         *
*                         ============================                         *
* PURPOSE  : This function returns CriticalSpd Parameter Pointer               *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetCriticalSpdPtr(VOID)  
{ 
    CriticalSpd   = (FLOAT32)pSpeedShramSlotData->CriticalSpd;

    return &CriticalSpd; 
}

/*******************************************************************************
*                         clsSpSlot::GetNominalSpdPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns NominalSpd Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetNominalSpdPtr(VOID)  
{ 
    NominalSpd   = (FLOAT32)pSpeedShramSlotData->NominalSpd;

    return &NominalSpd; 
}

/*******************************************************************************
*                         clsSpSlot::GetFilterTimePtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns FilterTime Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetFilterTimePtr(VOID)      
{
    FilterTime = (FILTERTIME)pSpeedShramSlotData->FilterTime;

    return &FilterTime;
}

/*******************************************************************************
*                         clsSpSlot::GetMeasurementTypePtr                     *
*                         ================================                     *
* PURPOSE  : This function returns MeasurementType Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetMeasurementTypePtr(VOID)      
{
    MeasurementType = (MEASUREMENT_TYPE)pSpeedShramSlotData->MeasurementType;

    return &MeasurementType;
}

/*******************************************************************************
*                         clsSpSlot::GetOrderOfKFactorPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns Order Of KFactor Parameter Pointer          *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetOrderOfKFactorPtr(VOID)      
{
    Order_Of_KFactor = (ORDER_OF_KFACTOR)pSpeedShramSlotData->OrderOfKFactor;

    return &Order_Of_KFactor;
}

/*******************************************************************************
*                         clsSpSlot::GetKFactorPtr                             *
*                         ========================                             *
* PURPOSE  : This function returns KFactor Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetKFactorPtr(VOID)      
{
    KFactor = (FLOAT32)pSpeedShramSlotData->KFactor;

    return &KFactor;
}

/*******************************************************************************
*                         clsSpSlot::GetMinFlowRatePtr                         *
*                         ============================                         *
* PURPOSE  : This function returns Min Flow Rate Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetMinFlowRatePtr(VOID)      
{
    MinFlowRate = (FLOAT32)pSpeedShramSlotData->MinFlowRate;

    return &MinFlowRate;
}

/*******************************************************************************
*                         clsSpSlot::GetKMinFlowRatePtr                        *
*                         =============================                        *
* PURPOSE  : This function returns K Min Flow Rate Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetKMinFlowRatePtr(VOID)      
{
    KMinFlowRate = (FLOAT32)pSpeedShramSlotData->KMinFlowRate;

    return &KMinFlowRate;
}

/*******************************************************************************
*                         clsSpSlot::GetMaxFlowRatePtr                         *
*                         ============================                         *
* PURPOSE  : This function returns Max Flow Rate Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetMaxFlowRatePtr(VOID)      
{
    MaxFlowRate = (FLOAT32)pSpeedShramSlotData->MaxFlowRate;

    return &MaxFlowRate;
}

/*******************************************************************************
*                         clsSpSlot::GetKMaxFlowRatePtr                        *
*                         =============================                        *
* PURPOSE  : This function returns K Max Flow Rate Parameter Pointer           *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetKMaxFlowRatePtr(VOID)      
{
    KMaxFlowRate = (FLOAT32)pSpeedShramSlotData->KMaxFlowRate;

    return &KMaxFlowRate;
}

/*******************************************************************************
*                         clsSpSlot::GetTimeUnitPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns Time Unit Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetTimeUnitPtr(VOID)      
{
    TimeUnit = (TIME_UNIT)pSpeedShramSlotData->TimeUnit;

    return &TimeUnit;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetResetPvPtr                        *
*                         =============================                        *
* PURPOSE  : This function returns ResetPv Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpSlot::GetResetPvPtr(VOID)
{ 
    ResetPv = (BOOL) pSpeedShramSlotData->ResetPv;  
    return &ResetPv;
}


/*******************************************************************************
*                         clsSpSlot::GetDumpData                               *
*                         ======================                               *
* PURPOSE  : This method will copy the redundancy dump data to buffer transmit *
*            to the secondary IOM                                              *
* ARGUMENTS: pDump - Dump Pointer                                              *
*            MaxSize - Dump Size                                               *
* RETURN   : PA_OK -   If getdump is succesful                                 *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsSpSlot::GetDumpData(UINT8* const pDump,const UINT8 MaxSize)
{
    PASTATUS retVal = PA_NULL;
    if(pDump && IS_EVEN(pDump) && sizeof(SYNCRECORD) < MaxSize)
    {
        PSYNCRECORD pSyncRec    = (PSYNCRECORD)pDump;
        SPEEDSHRAMSLOTDATA* pSlotDB    = (SPEEDSHRAMSLOTDATA*)pSpeedShramSlotData;
        ///
        pSyncRec->Header        = PACK2_AS_UI16(SPEED_SYNC_VER_1,0);
        pSyncRec->PntType       = (UINT8)pSlotDB->PntType;
        pSyncRec->PtExecSt      = (UINT8)pSlotDB->PtExecSt;
        pSyncRec->PvSource      = (UINT8)pSlotDB->PvSource;
        pSyncRec->PvSrcOpt      = (UINT8)pSlotDB->PvSrcOpt;
        pSyncRec->OwdEnable     = (UINT8)pSlotDB->OwdEnable;
        pSyncRec->PvClamp       = (UINT8)pSlotDB->PvClamp;
        pSyncRec->SpSensrType   = (UINT8)pSlotDB->SensrType;
        pSyncRec->EdgeDetect    = (UINT8)pSlotDB->EdgeDetect;
        pSyncRec->PvHHAlmFlwrst   = (UINT8)pSlotDB->PvHHAlmFlwrst;
        pSyncRec->RocPosAlmFlwrst = (UINT8)pSlotDB->RocPosHHAlmFlwrst;
        pSyncRec->TeethCount    = (UINT16)pSlotDB->TeethCount;
        pSyncRec->LastPv        = pSlotDB->LastPv;
        pSyncRec->PvCalc        = pSlotDB->PvCalc;
        pSyncRec->GearRatio     = pSlotDB->GearRatio;

        pSyncRec->PvHiAlmTP     = pSlotDB->PvHiAlmTP;
        pSyncRec->PvHHAlmTP     = pSlotDB->PvHHAlmTP;
        pSyncRec->RocPosHiAlmTP = pSlotDB->RocPosHiAlmTP;
        pSyncRec->RocPosHHAlmTP = pSlotDB->RocPosHHAlmTP;
        pSyncRec->LastROCNegLldrCrSpd = pSlotDB->LastROCNegLldrCrSpd;
        pSyncRec->LastROCPosHhdrNmSpd = pSlotDB->LastROCPosHhdrNmSpd;

        pSyncRec->CriticalSpd   = pSlotDB->CriticalSpd;
        pSyncRec->NominalSpd    = pSlotDB->NominalSpd;
        pSyncRec->Pv              = pSlotDB->Pv;
        pSyncRec->PvSts           = pSlotDB->PvSts;

        pSyncRec->FilterTime    = pSlotDB->FilterTime;   
        
        pSyncRec->MeasurementType  = (UINT8)pSlotDB->MeasurementType;
        pSyncRec->Order_Of_KFactor = (UINT8)pSlotDB->OrderOfKFactor;
        pSyncRec->KFactor          = pSlotDB->KFactor;
        pSyncRec->MinFlowRate      = pSlotDB->MinFlowRate;
        pSyncRec->KMinFlowRate     = pSlotDB->KMinFlowRate;
        pSyncRec->MaxFlowRate      = pSlotDB->MaxFlowRate;
        pSyncRec->KMaxFlowRate     = pSlotDB->KMaxFlowRate;
        pSyncRec->TimeUnit         = (UINT8)pSlotDB->TimeUnit;
        ///
        retVal = PA_OK;
    }
    return retVal;
}

/*******************************************************************************
*                         clsSpSlot::StoreDumpData                             *
*                         ========================                             *
* PURPOSE  : This method will copy the redundancy dump data into local dump    *
*            structure in Primary IOM                                          *
* ARGUMENTS: pDump - Dump Pointer                                              *
* RETURN   : PA_OK -   If dump is succesful                                    *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS  clsSpSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS retVal = PA_NULL;
    ///
    if(pDump && IS_EVEN(pDump))
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SPEED_SYNC_VER_1)
        {
            PSYNCRECORD pSyncRec            = (PSYNCRECORD)pDump;
            SPEEDSHRAMSLOTDATA* pSlotDB     = (SPEEDSHRAMSLOTDATA*)pSpeedShramSlotData;         

            pSlotDB->PntType                = (UINT16)pSyncRec->PntType;
            pSlotDB->PtExecSt               = (UINT16)pSyncRec->PtExecSt;
            pSlotDB->PvSource               = (UINT16)pSyncRec->PvSource;
            pSlotDB->PvSrcOpt               = (UINT16)pSyncRec->PvSrcOpt;
            pSlotDB->OwdEnable              = (UINT16)pSyncRec->OwdEnable;
            pSlotDB->PvClamp                = (UINT16)pSyncRec->PvClamp;
            pSlotDB->SensrType              = (UINT16)pSyncRec->SpSensrType;
            pSlotDB->EdgeDetect             = (UINT16)pSyncRec->EdgeDetect;
            pSlotDB->PvHHAlmFlwrst          = (UINT16)pSyncRec->PvHHAlmFlwrst;
            pSlotDB->RocPosHHAlmFlwrst      = (UINT16)pSyncRec->RocPosAlmFlwrst;
            pSlotDB->TeethCount             = (UINT16)pSyncRec->TeethCount;

            pSlotDB->LastPv                 = pSyncRec->LastPv;
            pSlotDB->PvCalc                 = pSyncRec->PvCalc;
            pSlotDB->GearRatio              = pSyncRec->GearRatio;

            pSlotDB->PvHiAlmTP              = pSyncRec->PvHiAlmTP;
            pSlotDB->PvHHAlmTP              = pSyncRec->PvHHAlmTP;
            pSlotDB->RocPosHiAlmTP          = pSyncRec->RocPosHiAlmTP;
            pSlotDB->RocPosHHAlmTP          = pSyncRec->RocPosHHAlmTP;
            pSlotDB->LastROCNegLldrCrSpd    = pSyncRec->LastROCNegLldrCrSpd;
            pSlotDB->LastROCPosHhdrNmSpd    = pSyncRec->LastROCPosHhdrNmSpd;
            pSlotDB->CriticalSpd            = pSyncRec->CriticalSpd;
            pSlotDB->NominalSpd             = pSyncRec->NominalSpd;            

            //Sync Pv and PvSts in MAN and SUB Mode
            if(PVSOURCE_AUTO != (PVSOURCE)pSyncRec->PvSource)
            {
                pSlotDB->Pv                     = pSyncRec->Pv;
                pSlotDB->PvSts                  = pSyncRec->PvSts;
            }
            pSlotDB->FilterTime             = pSyncRec->FilterTime;

            pSlotDB->MeasurementType  = (UINT16)pSyncRec->MeasurementType;
            pSlotDB->OrderOfKFactor   = (UINT16)pSyncRec->Order_Of_KFactor;
            pSlotDB->KFactor          = pSyncRec->KFactor;
            pSlotDB->MinFlowRate      = pSyncRec->MinFlowRate;
            pSlotDB->KMinFlowRate     = pSyncRec->KMinFlowRate;
            pSlotDB->MaxFlowRate      = pSyncRec->MaxFlowRate;
            pSlotDB->KMaxFlowRate     = pSyncRec->KMaxFlowRate;
            pSlotDB->TimeUnit         = (UINT16)pSyncRec->TimeUnit;

            retVal = PA_OK;
        }
    }
 
    return retVal;
}