/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohardware.hpp                                              *
*    Description : Analog output hardware encapsulation.                       *
*******************************************************************************/
#ifndef __AOHARDWARE_HPP__
#define __AOHARDWARE_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8   DAC_RESOLUTION                = 12;    // 12 bit DAC
const UINT16  DAC_SETTLE_TIME               = 50;    // In units of micro sec.

const UINT16  MAXCURRENT_OUTPUT_DACCOUNT    = 0xFFF; // 25 mA
#if !LOWCOST
const UINT16  MINCURRENT_OUTPUT_DACCOUNT    = 0x080; // 0 mA
const UINT16  TWENTY_MA_H_OUTPUT_DACCOUNT   = 0xD1A;
const UINT16  TWENTY_MA_L_OUTPUT_DACCOUNT   = 0xCB4;
const UINT16  FOUR_MA_H_OUTPUT_DACCOUNT     = 0x32E;
const UINT16  FOUR_MA_L_OUTPUT_DACCOUNT     = 0x2C8;
const UINT16  MAX_FIVE_V_OUTPUT_DACCOUNT    = 0xCC6;
const UINT16  MIN_FIVE_V_OUTPUT_DACCOUNT    = 0xB97;
const UINT16  MAX_ONE_V_OUTPUT_DACCOUNT     = 0x33F;
const UINT16  MIN_ONE_V_OUTPUT_DACCOUNT     = 0x275;
const UINT16  MAX_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x82D;
const UINT16  MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x738;

const UINT16  FACCAL_OUTPUT_DACCOUNT        = 0x8F7;
const UINT16  MINHIZERO_LOOPBACK_DACCOUNT   = 0x070; // TBD
const UINT16  MAXHIZERO_LOOPBACK_DACCOUNT   = 0x090; // TBD 
const UINT16  MINCURRENT_LOOPBACK_DACCOUNT  = 0x0ED;
const UINT16  MAXCURRENT_LOOPBACK_DACCOUNT  = 0xF08;
#else // Lowcost AO
const UINT16  MINCURRENT_OUTPUT_DACCOUNT    = 0x000; // 0 mA
const UINT16  TWENTY_MA_H_OUTPUT_DACCOUNT   = 0xD87;
const UINT16  TWENTY_MA_L_OUTPUT_DACCOUNT   = 0xD21;
const UINT16  FOUR_MA_H_OUTPUT_DACCOUNT     = 0x2DC;
const UINT16  FOUR_MA_L_OUTPUT_DACCOUNT     = 0x277;
const UINT16  MAX_ONE_V_OUTPUT_DACCOUNT     = 0x3C1;               
const UINT16  MIN_ONE_V_OUTPUT_DACCOUNT     = 0x2F9;              
const UINT16  MAX_FIVE_V_OUTPUT_DACCOUNT    = 0xEB6;              
const UINT16  MIN_FIVE_V_OUTPUT_DACCOUNT    = 0xD8A;             
const UINT16  MAX_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x95D;
const UINT16  MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT = 0x863;

const UINT16  FACCAL_OUTPUT_DACCOUNT        = 0x8F7;
const UINT16  MINHIZERO_LOOPBACK_DACCOUNT   = 0x0B7; 
const UINT16  MAXHIZERO_LOOPBACK_DACCOUNT   = 0x097; 
const UINT16  MINCURRENT_LOOPBACK_DACCOUNT  = 0x0ED;  
const UINT16  MAXCURRENT_LOOPBACK_DACCOUNT  = 0xF08;
#endif

const UINT16  MAXIMUM_CURRENT_SWING         = 25; // In units of mA.

const UINT16  OUTPUT_DACCOUNT_PER_MILLIAMP  = (MAXCURRENT_OUTPUT_DACCOUNT - MINCURRENT_OUTPUT_DACCOUNT)
                                              / MAXIMUM_CURRENT_SWING;
const UINT16  FOUR_PRECENT_LOOPBACK_DACCOUNT= (MAXCURRENT_LOOPBACK_DACCOUNT - MINCURRENT_LOOPBACK_DACCOUNT) * 4 / 100;

const UINT8  MUX_ENABLE                     = 0x80;
const UINT8  OUTPUT_ADDRESS_READBACK_MASK   = 0x8F;
#if !LOWCOST
const UINT8  LOOPBACK_ADDRESS_READBACK_MASK = 0x9F;
#else
const UINT8  LOOPBACK_ADDRESS_READBACK_MASK = 0x3F;
#endif
const UINT8  MUX_READBACK_RETRYCOUNT        = 4;
const UINT8  MUX_CHANNELSEL_SETTLE_TIME     = 1;

const UINT16 DEFAULT_OUTPUT_CAPACITORCHARGE_TIME       = 300;          //300 us
const UINT16 CALIBRATION_EXTENDED_CAPACITORCHARGE_TIME = 10000;        //10  ms
const UINT16 CALIBRATION_MINIMUM_CAPACITORCHARGE_TIME  = 150;          //150 us
const UINT16 LOOPBACK_COMPARATORSETTLE_TIME            = 150;          //150 us

#if !LOWCOST
const UINT8 SNSCAL1 = 0x00;
const UINT8 SNSV1   = 0x01;
const UINT8 SNSV2   = 0x02;
const UINT8 SNSV3   = 0x03;
const UINT8 SNSV4   = 0x04;
const UINT8 HIZERO1 = 0x05;
const UINT8 SNSV5   = 0x06;
const UINT8 SNSV6   = 0x07;

const UINT8 FACCAL  = 0x08;
const UINT8 SNSV7   = 0x09;
const UINT8 CALCHK  = 0x0A;
const UINT8 HIZERO2 = 0x0B;
const UINT8 SNSCAL2 = 0x0C;
const UINT8 SNSV8   = 0x0D;
const UINT8 SNSV9   = 0x0E;
const UINT8 SNSV10  = 0x0F;

const UINT8 SNSV11  = 0x10;
const UINT8 SNSV12  = 0x11;
const UINT8 SNSCAL3 = 0x12;
const UINT8 SNSV13  = 0x13;
const UINT8 SNSV14  = 0x14;
const UINT8 SNSV15  = 0x15;
const UINT8 SNSV16  = 0x16;
const UINT8 HIZERO3 = 0x17;
#else // LowCost
const UINT8 SNSCAL1 = 0x30;
const UINT8 SNSV1   = 0x31;
const UINT8 SNSV2   = 0x32;
const UINT8 SNSV3   = 0x33;
const UINT8 SNSV4   = 0x34;
const UINT8 HIZERO1 = 0x35;
const UINT8 SNSV5   = 0x36;
const UINT8 SNSV6   = 0x37;

const UINT8 FACCAL  = 0x28;  // Present No Connection
const UINT8 SNSV7   = 0x29;
const UINT8 CALCHK  = 0x2A;
const UINT8 HIZERO2 = 0x2B;
const UINT8 SNSCAL2 = 0x2C;
const UINT8 SNSV8   = 0x2D;
const UINT8 SNSV9   = 0x2E;
const UINT8 SNSV10  = 0x2F;

const UINT8 SNSV11  = 0x18;
const UINT8 SNSV12  = 0x19;
const UINT8 SNSCAL3 = 0x1A;
const UINT8 SNSV13  = 0x1B;
const UINT8 SNSV14  = 0x1C;
const UINT8 SNSV15  = 0x1D;
const UINT8 SNSV16  = 0x1E;
const UINT8 HIZERO3 = 0x1F;
#endif

const UINT8 LOOPBACK_ADDRESS[] = {
    SNSV1,  //Address:: 0x01 - 1
    SNSV2,  //Address:: 0x02 - 2
    SNSV3,  //Address:: 0x03 - 3
    SNSV4,  //Address:: 0x04 - 4
    SNSV5,  //Address:: 0x06 - 5
    SNSV6,  //Address:: 0x07 - 6
    SNSV7,  //Address:: 0x09 - 7
    SNSV8,  //Address:: 0x0D - 8
    SNSV9,  //Address:: 0x0E - 9
    SNSV10, //Address:: 0x0F - 10
    SNSV11, //Address:: 0x10 - 11
    SNSV12, //Address:: 0x11 - 12
    SNSV13, //Address:: 0x13 - 13
    SNSV14, //Address:: 0x14 - 14
    SNSV15, //Address:: 0x15 - 15
    SNSV16, //Address:: 0x16 - 16
    HIZERO1,//Address:: 0x05 - 17
    HIZERO2,//Address:: 0x0B - 18
    HIZERO3,//Address:: 0x17 - 19
    SNSCAL1,//Address:: 0x00 - 20
    SNSCAL2,//Address:: 0x0C - 21
    SNSCAL3,//Address:: 0x12 - 22
    CALCHK, //Address:: 0x0A - 23
    FACCAL  //Address:: 0x08 - 24
};

//Array Index positions in the LOOPBACK_ADDRESS array
const UINT8 HIZERO1_OFFSET = 17;
const UINT8 HIZERO2_OFFSET = 18;
const UINT8 HIZERO3_OFFSET = 19;
const UINT8 SNSCAL1_OFFSET = 20;
const UINT8 SNSCAL2_OFFSET = 21;
const UINT8 SNSCAL3_OFFSET = 22;
const UINT8 CALCHK_OFFSET  = 23;
const UINT8 FACCAL_OFFSET  = 24;

#if LOWCOST
const UINT16 DAC_RR_RESET_ENABLE             = 0x0001;
const UINT16 DAC_RR_RESET_DISABLE            = 0x0000;
const UINT16 DAC_CR_CONFIGURATION            = 0x10F7;  // output enable, Output Range 0-24mA , Skew rate enable
const UINT16 DAC17_CR_CONFIGURATION          = 0x1007;  // output enable, Output Range 0-24mA 

const UINT8  READBACK_DAC_ADDR               = 0x10;   // Address of 17 DAC for read back purpose
const UINT8  MUX_SEL_SETTLE_TIME             = 1;    
const UINT8  COMPARATOR_SETTLE_TIME          = 100;     // us Delay before reading the comparator output
const UINT8  DESELECT_DAC_MASK               = 0x1F;
const UINT8  CLOSE_LOOPBACK_MUX              = 0x38;   // Closing the Loopback Mux
#endif

//Redundancy Related Constant Declarations
// Status of switches with Test switch in Normal state 

const UINT8 INH_ON_ON   = 0x00; //a and b on
const UINT8 INH_ON_OFF  = 0x04; //b sws on
const UINT8 INH_OFF_ON  = 0x1C; //a sws on
const UINT8 INH_OFF_OFF = 0x0C; //a and b off 

const UINT8 INH_OFF_ON_TST_ON   = 0x1C; //a sws on
const UINT8 INH_OFF_OFF_TST_ON  = 0x0C; //a sws on

#if !LOWCOST
const UINT8 DIS_ON_ON   = 0xE0;
const UINT8 DIS_OFF_ON  = 0x60;
#else
const UINT8 DIS_ON_ON   = 0xC0; // a and b on
const UINT8 DIS_OFF_ON  = 0x40; // b sws on
#endif 
const UINT8 DIS_ON_OFF  = 0x80; // a sws on 
const UINT8 DIS_OFF_OFF = 0x00; // a and b off

const UINT8 TST_ON        = 0x02;
const UINT8 TST_OFF       = 0x00;
const UINT8 TST_DISABLED  = 0x02; 
const UINT8 TST_ENABLED   = 0x00;
const UINT8 TSTn_DISABLED = 0;
const UINT8 TSTn_ENABLED  = 1;

const UINT16 READ_DELAY_TIME = 250;     //250us Read delay 
const UINT16 TST_READ_DELAY_TIME = 20;  //20us Read delay
const UINT16 DIS_READ_DELAY_TIME = 20; 
const UINT16 INH_READ_DELAY_TIME = 300; 

//Constants that can be moved to outslot    
const UINT8 SW_ON       = 0x1;
const UINT8 SW_OFF      = 0x0;

//wait time for primary to change role on a commanded swap
const UINT16 SWAP_RESPNSE_TIME_DELAY = 300;


const UINT8 DIS_SWA_SET  = 0x80;
const UINT8 DIS_SWB1_SET = 0x40;
const UINT8 DIS_SWB2_SET = 0x20;

const UINT8 TST_SET      = 0x02;

const UINT8 INH_SWA_SET    = 0x10;
const UINT8 INH_SWB1_SET   = 0x08;
const UINT8 INH_SWB2_SET   = 0x04;

/*******************************************************************************
*                             TYPES & ENUMERATIONS                             *
*******************************************************************************/
#if !LOWCOST
typedef union tagDacByte {
    UINT8 ucByte[2];
    struct {
        UINT16 Commmand : 3;
        UINT16 Count    : 12;
        UINT16 SubBit   : 1;
    } DAC;
} DACBYTE;

//DAC Commands 
typedef enum DAC_CMDS{
    NO_OPERATION                      = 0x0,
    LD_INPUT_REG                      = 0x1,
    LD_INPUT_AND_DAC_REG              = 0x2,
    UPDATE_DAC_REG_FROM_INPUT_REG     = 0x3,
    SHUTDOWN_DAC                      = 0x4,
    UPO_LOW                           = 0x5,
    UPO_HIGH                          = 0x6,
    MODE1                             = 0x7,
    MODE0                             = 0x7
}DAC_CMDS;
#else  // LowCost
typedef union tagDacCmd {
    UINT32 DacCmd;
    struct {
        UINT8  Wk;          // don't care
        UINT8  reg_address;
        UINT16 Data;
    } DAC;
} DACCMD;
// DAC Register addresses
typedef enum DAC_REG_ADDRS{
    NO_OPER                = 0x00,     // no operation
    DAC_REG_DR             = 0x01,     // data register
    DAC_REG_RB             = 0x02,     // read back register
    DAC_REG_CR             = 0x55,     // control register
    DAC_REG_RR             = 0x56      // reset register
}DAC_REG_ADDRS;
#endif

typedef enum DELAY_TYPE {
    NormalOutput                 = 0,
    CalibrationWithExtendedDelay = 1,
    CalibrationWithMinimumDelay  = 2
}DELAY_TYPE;

typedef enum SWITCH_TYPE{
    DIS_SWCH              = 0x0,
    TST_SWCH              = 0x1,
    INH_SWCH              = 0x2
}SWITCH_TYPE;

/*******************************************************************************
*                                 clsAoHardware                                *
*                                 =============                                *
*******************************************************************************/
#if !LOWCOST
#if defined(IOMTYPE_AOH) || defined(IOMTYPE_AO)
class clsAoHardware {
    DACBYTE DacByte;

    clsAoHardware(const clsAoHardware&); // Safeguard against default copy constructor.
    clsAoHardware& operator=(const clsAoHardware&); // Sefeguard against default assignment.

public:
    clsAoHardware(VOID);
    ~clsAoHardware(VOID) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__); }

    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__);  return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__); }

    VOID DriveDac(UINT16);
    VOID DriveOutput(UINT8 a_ucSlotNum, 
                     DELAY_TYPE a_eDelayType = NormalOutput);
    BOOL ReadComparatorOutput(VOID);
    BOOL OpenLoopbackMux(UINT8,BOOL);

    inline VOID CloseLoopbackMux(UINT8 a_ucChanNum) {
        INPSEL = a_ucChanNum & (~MUX_ENABLE); 
    }

    BOOL   TestSwitchDiagnostics(UINT8);
    BOOL   InhibitSwitchDiagnostics(UINT8);
    BOOL   DisableSwitchDiagnostics(UINT8);  
    
    UINT8  GetSwitchStatus(SWITCH_TYPE);  
    VOID   VerifySwitchState(SWITCH_TYPE,UINT8); 

};
#endif
#else   // LowCost
/*******************************************************************************
*                                 clsAoHardware                                *
*                                 =============                                *
*******************************************************************************/
#if defined(IOMTYPE_AOH)
class clsAoHardware {
private:
    DACCMD DacCmd;
    VOID toggle_dac_latch();
    VOID toggle_dac_clear();
    VOID write_dac_data(UINT8 , UINT16 );
    VOID dac_mux_select(int a_ucSlotNum);
    clsAoHardware(const clsAoHardware&); // Safeguard against default copy constructor.
    clsAoHardware& operator=(const clsAoHardware&); // Sefeguard against default assignment.

public:
    
    clsAoHardware(VOID);
    ~clsAoHardware(VOID) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__); }

    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__);  return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AOHARDWARE_HPP,__LINE__); }


    VOID DriveDac(UINT16,UINT8);
    VOID DriveOutput(UINT8 a_ucSlotNum,DELAY_TYPE a_eDelayType = NormalOutput);
    VOID DisableOutputDrive(UINT8);
    VOID EnableOutputDrive(UINT8);
    
    BOOL ReadComparatorOutput(VOID);  
    BOOL OpenLoopbackMux(UINT8,BOOL);

    inline VOID CloseLoopbackMux(UINT8 a_ucChanNum) {
        if (a_ucChanNum)
        INPSEL = CLOSE_LOOPBACK_MUX; 
    }

    inline VOID WriteStrobe() {
    WR_n = 0;  // Write Strobe ON
    WR_n = 1;  // Write Strobe OFF
    }
    
    BOOL   TestSwitchDiagnostics(UINT8);
    BOOL   InhibitSwitchDiagnostics(UINT8);
    BOOL   DisableSwitchDiagnostics(UINT8);  
    
    UINT8  GetSwitchStatus(SWITCH_TYPE);  
    VOID   VerifySwitchState(SWITCH_TYPE,UINT8);
};

#endif
#endif // LC end
#endif

