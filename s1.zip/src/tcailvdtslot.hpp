/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcailvdtchannel.hpp                                         *
*    Description : Class clsAiLvdtSlot definition.                             *
*******************************************************************************/
#ifndef __TCAILVDTCHANNEL_HPP__
#define __TCAILVDTCHANNEL_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define AILVDTSLOT_SIZE ((sizeof(clsAiLvdtSlot) + (sizeof(clsAiLvdtSlot) % 2)) / 2)

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SVPAI_SYNC_VER_1;

const UINT8 OPENWIRE_TOTAL_TESTCOUNT     = 5;
const UINT8 OPENWIRE_PVFALL_MAXCOUNT     = 5;

// Excitation signal related declarations
#define EXCITN_FREQ_LO_LIMIT    2800 // Hz
#define EXCITN_FREQ_HI_LIMIT    3200 // Hz
#define EXCITN_AMP_LO_LIMIT     3    // Vrms
#define EXCITN_AMP_HI_LIMIT     10   // Vrms 

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagPvClamp {
    PVCLAMP_NOCLAMP   =0,
    PVCLAMP_CLAMP     =1
} PVCLAMP;

typedef enum tagPvChar {
    PVCHAR_JTHERM   = 0,
    PVCHAR_KTHERM   = 1,
    PVCHAR_ETHERM   = 2,
    PVCHAR_TTHERM   = 3,
    PVCHAR_BTHERM   = 4,
    PVCHAR_STHERM   = 5,
    PVCHAR_RTHERM   = 6,
    PVCHAR_RPTHERM  = 7,
    PVCHAR_DINRTD   = 8,
    PVCHAR_JISRTD   = 9,
    PVCHAR_NICKLRTD = 10,
    PVCHAR_COPPRRTD = 11,
    PVCHAR_LINEAR   = 12,
    PVCHAR_SQRROOT  = 13,
    PVCHAR_NTHERM   = 14,
    PVCHAR_PT200RTD = 15,
    PVCHAR_PT500RTD = 16,
    PVCHAR_CU10RTD  = 17,
    PVCHAR_CU25RTD  = 18,
    PVCHAR_RHRAD    = 19,
    PVCHAR_W5W26TC  = 20,
    PVCHAR_W5W25TC  = 21,
    PVCHAR_NINIMOTC = 22,
    PVCHAR_RTDOHMS  = 23,
    PVCHAR_DEVRANGE = 26,
    PVCHAR_SYSRANGE = 27,
    PVCHAR_SYSRSQRT = 28
} PVCHAR;

typedef enum tagPvTemp {
    PVTEMP_DEG_C  = 0,      
    PVTEMP_DEG_F  = 1,
    PVTEMP_DEG_R  = 2,
    PVTEMP_DEG_K  = 3
} PVTEMP;

typedef enum tagSensrTyp {
    SENSRTYP_1to5_V     =0,
    SENSRTYP_0to5_V     =1,
    SENSRTYP_0to100_MV  =2,
    SENSRTYP_THERMCPL   =3,
    SENSRTYP_RTD        =4,
    SENSRTYP_P4TO2_V    =5,
    SENSRTYP_SLIDWIRE   =6,
    SENSRTYP_SLDWSRCE   =7,
    SENSRTYP_SPT_DP     =8,
    SENSRTYP_SPT_GP     =9,
    SENSRTYP_SPT_AP     =10,
    SENSRTYP_STT        =11,
    SENSRTYP_SFM        =12,
    SENSRTYP_SCM        =13,
    SENSRTYP_SGC        =14,
    SENSRTYP_SVP        =15,
    SENSRTYP_MTT        =16,
    SENSRTYP_STP        =17,
    SENSRTYP_SLV        =18,
    SENSRTYP_SDU        =19,
    SENSRTYP_GENERIC    =20,
    SENSRTYP_LVDT       =21,
    SENSRTYP_RVDT       =22,
    SENSRTYP_RESOLVER   =23
} SENSRTYP;

/*
    Transducer Wire Selection
*/
typedef enum tagTxWireSel{
    THREE_WIRE_TX = 0,
    FOUR_WIRE_TX =  1,
    FIVE_WIRE_TX =  2,
    SIX_WIRE_TX =   3
}TXWIRESEL;

/* 
    VDT Modes
*/
typedef enum tagVdtMode{
    VDT_MODE_NORMAL = 0,
    VDT_MODE_A_MINUS_B = 1,
    VDT_MODE_AB_DIVIDE_AB = 2,
    VDT_MODE_ARCTAB_A_BY_B = 3
}VDTMODE;

/* 
    Calibration Values
*/
typedef enum tagCalibVal{
   CALIB_VALUE_NONE=0,
   CALIB_VALUE_ZERO=1,
   CALIB_VALUE_HUNDRED=2
}CALIBVALUE;

typedef enum tagValvePosCalibStatus
{
    VALVE_POS_CALIB_NOT_DONE,
    VALVE_POS_CALIB_STEP1,
    VALVE_POS_CALIB_STEP2,
    VALVE_POS_CALIB_INPROGRESS,
    VALVE_POS_CALIB_COMPLETE,
    VALVE_POS_CALIB_FAILED
}VALVEPOSCALIBSTATUS;

/*
     Redundacy dump record structure
*/
struct strAiLvdtSlotDumpData 
{
    UINT16     Version;     // The first two bytes of dump record should always represent version. Do not change this. 
    PNTTYPE    PntType;
    PTEXECST   PtExecSt;
    PVSOURCE   PvSource;
    PVSRCOPT   PvSrcOpt;
    BOOL       OwdEnable;
    FLOAT32    PvEUHi;
    FLOAT32    PvEULo;
    FLOAT32    PvExEUHi;
    FLOAT32    PvExEULo;
    FLOAT32    LoCutOff;
    FLOAT32    Tf;
    FLOAT32    ExVol;
    SENSRTYP   SensrTyp;
    INPTDIR    InptDir;
    PVCHAR     PvChar;
    PVCLAMP    PvClamp;
    TXWIRESEL  TxWireSel;
    VDTMODE    VdtMode;
    CALIBVALUE CalibVal;
    FLOAT32    Pv; // Sync Pv also when PvSource is Manual
    PVVALST    PvSts;
    BOOL       bValvePosCalibEnb;
    LVDTCALIBDATA CalibData[2];     //Top and bottom calib data
    FLOAT32    FiltOut;
    FLOAT32    ActualAngle;
};

class clsAiLvdtSlot; // forward declaration
typedef struct tagAiLvdtSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsAiLvdtSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsAiLvdtSlot::* PostPtr)(UINT8);
    VOID *   (clsAiLvdtSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
}AILVDTSLOTPARAMINFO;

/*******************************************************************************
*                                   clsAiLvdtSlot                              *
*                                   ==========                                 *
*******************************************************************************/
class clsAiLvdtSlot : public clsInSlot {
protected:
    static const UINT8 RedParams[]; 
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const AILVDTSLOTPARAMINFO tblParamInfo[256];
    static UINT8 SvpAiSlotChkpntVersion;

    //Member Variables
    FLOAT32    Pv;
    FLOAT32    LastPv;
    FLOAT32    PvCalc;
    FLOAT32    PvAuto;
    FLOAT32    PvRaw;
    FLOAT32    PvEUHi;
    FLOAT32    PvEULo;
    FLOAT32    PvExEUHi;
    FLOAT32    PvExEULo;
    FLOAT32    LoCutOff;
    FLOAT32    Tf;
    FLOAT32    PvP;
    FLOAT32    PvTv;
    FLOAT32    PvTvP;
    FLOAT32    ExVol;
    FLOAT32    Exc_RMS_Sum;
    FLOAT32    FdbkA_RMS_Sum;
    FLOAT32    FdbkB_RMS_Sum;
    BOOL       BadPvFl;
    BOOL       PvExHiFl;
    BOOL       PvExLoFl;
    PVVALST    PvSts;
    PVVALST    PvAutoSt;
    SENSRTYP   SensrTyp;
    INPTDIR    InptDir;
    PVCHAR     PvChar;
    PVCLAMP    PvClamp;
    TXWIRESEL  TxWireSel;
    VDTMODE    VdtMode;
    CALIBVALUE CalibVal;
    BOOL       ValvePosCalibEnb;
    VALVEPOSCALIBSTATUS ValvePosCalibSts;
    FLOAT32    FiltOut;
    FLOAT32    ActualAngle;
    BOOL       ApplyOffset;
    FLOAT32    AngleOffset;

    AISHRAMSLOTDATA *pAiShramSlotData; //Shared ram slot data pointer

    VOID InitLvdtAiSlot(BOOL bFullInit, BOOL);

    //Overrided clsIoSlot Class Varibles GetPtr methods
    VOID *GetPntTypePtr(VOID);         
    VOID *GetPtExecStPtr(VOID);
    
    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SvpAiSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SvpAiSlotChkpntVersion;}
                                      
    //Overrided clsInSlot Class Varibles GetPtr methods
    VOID *GetPvSourcePtr(VOID);        
    VOID *GetPvSrcOptPtr(VOID);        
    VOID *GetOwdEnablePtr(VOID);      

    //Member Varibles GetPtr methods
    VOID *GetPvPtr(VOID);
    VOID *GetPvStsPtr(VOID);
    VOID *GetLastPvPtr(VOID);          
    VOID *GetPvCalcPtr(VOID);          
    VOID *GetPvAutoPtr(VOID);          
    VOID *GetPvAutoStPtr(VOID);        
    VOID *GetPvRawPtr(VOID);           
    VOID *GetBadPvFlPtr(VOID);         
    VOID *GetPvExHiFlPtr(VOID);        
    VOID *GetPvExLoFlPtr(VOID);        
    VOID *GetSensrTypPtr(VOID);        
    VOID *GetPvCharPtr(VOID);          
    VOID *GetInptDirPtr(VOID);         
    VOID *GetPvEUHiPtr(VOID);          
    VOID *GetPvEULoPtr(VOID);          
    VOID *GetPvExEUHiPtr(VOID);
    VOID *GetPvExEULoPtr(VOID);        
    VOID *GetPvClampPtr(VOID);         
    VOID *GetLoCutOffPtr(VOID);        
    VOID *GetTfPtr(VOID);              
    VOID *GetPvPPtr(VOID);            
    VOID *GetPvTvPtr(VOID);            
    VOID *GetPvTvPPtr(VOID);           
    VOID *GetExVolPtr(VOID);           
    VOID *GetTxWireSelPtr(VOID);       
    VOID *GetVdtModePtr(VOID);           
    VOID *GetCalibValPtr(VOID);
    VOID *GetExVolRmsPtr(VOID);
    VOID *GetExFbAVolRmsPtr(VOID);
    VOID *GetExFbBVolRmsPtr(VOID);
    VOID *GetValvePosCalibEnb(VOID);
    VOID *GetValvePosCalibSts(VOID);
    VOID *GetActualAnglePtr(VOID);
    VOID *GetApplyOffsetPtr(VOID);
    VOID *GetAngleOffsetPtr(VOID);

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    
    clsAiLvdtSlot(const clsAiLvdtSlot&); // Safeguard against default copy constructor
    clsAiLvdtSlot& operator=(const clsAiLvdtSlot&); // and default assignment    
public:
    clsAiLvdtSlot(UINT8);
    ~clsAiLvdtSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);

    VOID InitSlotDatabase(BOOL bFullInit);

    // redundancy dump related Fucntions
    PASTATUS  GetDumpData(UINT8* const pDump, const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    inline UINT32 GetRedSlotSize(VOID) {
        return (sizeof(strAiLvdtSlotDumpData));
    }

    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams; }
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SvpAiSlotChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    inline SENSRTYP GetSensorType() {return (SENSRTYP)pAiShramSlotData->SensrTyp;}
    inline BOOL GetValveCalibEnb()  {return (BOOL)pAiShramSlotData->ValvePosCalibEnb;}
};

#endif //__TCAILVDTCHANNEL_HPP__
