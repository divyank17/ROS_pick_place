/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : svpboxslot.hpp                                              *
*    Description : Class clsSvpBoxSlot declaration.                            *
*******************************************************************************/
#ifndef __SVPBOXSLOT_HPP__
#define __SVPBOXSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "svpversion.h"

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SVPIOM_SYNC_VER_1;

const UINT16 FIVE_VOLT_TOLERENCE_COUNT = 425;
const UINT8 SVP_SHARED_RAM_ACCESS_PERIOD = 5; // In units of msec.
// claculate the timer count for equivalent to 5 msec scheduling
const UINT16 TPU0_MAXCOUNT = (UINT16)(((SYSTEM_CLOCK_FREQUENCY / 64) / 
                          (MILLISECONDS_IN_SECOND / SVP_SHARED_RAM_ACCESS_PERIOD)));
#define SVPBOXSLOT_SIZE ((sizeof(clsSvpBoxSlot)+(sizeof(clsSvpBoxSlot)%2)) / 2)

const UINT16  BUPREQ_400MS_DELAY      =  80;   //5ms * 80  = 400ms
const UINT16  MANAGEREDIO_500MS_DELAY =  100;  //5ms * 100 = 500ms

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
#define PARAMID_PVALL             101
#define PARAMID_BADPVALL          84

#define PARAMID_SVP_MODSTAT1      67
#define PARAMID_SVP_MODSTAT2      68
#define PARAMID_SVP_DBVALID       78
#define PARAMID_SVP_CALIBALL      80
#define PARAMID_SVP_EXCITFREQ     177

#define PARAMID_SVP_PROC_SCAN_RECORD       176
#define PARAMID_SVP_BCKCLAC_SCAN_RECORD    175
#define PARAMID_SVP_BCKCLAC_PV_SCAN_RECORD 195

#define PARAMID_IOLPROCCPUFREEAVG 179
#define PARAMID_IOLPROCCPUFREEMAX 180
#define PARAMID_IOLPROCCPUFREEMIN 181
#define PARAMID_IOLPROCSTATRESET  182
#define PARAMID_APPPROCCPUFREEAVG 183
#define PARAMID_APPPROCCPUFREEMAX 184
#define PARAMID_APPPROCCPUFREEMIN 185
#define PARAMID_APPPROCSTATRESET  186
#define PARAMID_SVP_CALIBOPT      190
#define PARAMID_SVP_SERVODRIVEOPT 201


const UINT16 LATCHTIMECONST         = 75;
const UINT16 LOWLATLATCHTIMECONST   = 300;
const FLOAT32 OP_LOLIMIT            = -6.9;
const FLOAT32 OP_HILIMIT            = 106.9;
const UINT8 SW_ON       = 1;
const UINT8 SW_OFF      = 0;

const UINT8 PARTNERSLOTINFAIL_SIZE = 2;


const UINT16 TIMER_10SEC   = 1000;      //10 sec timer with resolution of 10ms (STC Processing)

class clsSvpBoxSlot; // forward declaration

VOID TcIomDiagnostics();

VOID TCStartupDiagnostics();

typedef struct tagBoxParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType; 
    ACCESSLOCK   AccessLock;
    PASTATUS (clsSvpBoxSlot::* PrePtr)(UINT8 *,UINT8);
    VOID     (clsSvpBoxSlot::* PostPtr)(UINT8);
    VOID *   (clsSvpBoxSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

typedef enum enmArw
{
    K_NORMAL_ARW = 0,
    K_HI_ARW  = 1,
    K_LOARW = 2,
    K_HI_LO_ARW = 3
}ENUMARW;

typedef union tagSlowScanChannelData{
    UINT8 Byte;
    struct BIT{
           UINT8 SvpRegCtl2ArwSts :4;
           UINT8 SvpRegCtl1ArwSts :4;
    }bit;
}ARWSTS;
typedef union tagInitReq{
    UINT8 Byte;
    struct BIT{
           UINT8 unused     :6;
           UINT8 Ch2InitReq :1;
           UINT8 Ch1InitReq :1;
    }bit;
}INITREQ;

typedef struct tagBackCalcScanRec {
   FLOAT32     AoOp[AO_MAXSLOTS];
   FLOAT32     InitVal[SVPREGCTL_MAXSLOTS];
   ARWSTS      ArwSts;   //0-3 1st Channel, 4-7 - 2nd channel
   INITREQ     SvpRegCtlInitReq;   //0 bit- 1st Channel, 1st bit - 2nd channel  (filled by SvpRegCtl InitReq)
   INITREQ     AoInitReq;//0 bit- 1st Channel, 2nd bit - 2nd channel(filled by AO InitReq) 
}BACKCALCSCANREC;

typedef union tagChannelData{
    UINT8 Byte;
    struct BIT{
           UINT8 unused     :4;
           UINT8 Di2BadPvFl :1;
           UINT8 Di1BadPvFl :1;
           UINT8 Di2Pv      :1;
           UINT8 Di1Pv      :1;
    }bit;
}CHANNELDATA;

typedef struct tagProcessScanRec{
    FLOAT32 AiPv[AI_MAXSLOTS];
    UINT8   LvdtSlotSf[AI_MAXSLOTS];
    UINT8   AiPvSts; //0-3 bits are for channel1 4-7 are for channel2
    CHANNELDATA   ChannelData;
}PROCESSSCANREC;

typedef struct tagBackupPvScanRec
{
    FLOAT32 AiPv[AI_MAXSLOTS];
}BACKUPPVSCANREC;

typedef enum svpChannelType{ 
  SVP_AI_CHAN01 = 1,
  SVP_AI_CHAN02 = 2,
  SVP_AO_CHAN01 = 3,
  SVP_AO_CHAN02 = 4,
  SVP_DI_CHAN01 = 5,
  SVP_DI_CHAN02 = 6,
  SVP_PID_CHAN01 = 7,
  SVP_PID_CHAN02 = 8
}SVPCHANTYPE;

//Calibration Channels Option
typedef enum tagCalibOpt
{ 
  CALIBOPT_NONE      = 0,
  CALIBOPT_AISTD     = 1,
  CALIBOPT_AOSTD     = 2,
  CALIBOPT_VDT       = 3,
  CALIBOPT_VDTEXCTN  = 4,
  CALIBOPT_VDTFB1A   = 5,
  CALIBOPT_VDTFB1B   = 6,
  CALIBOPT_VDTFB2A   = 7,
  CALIBOPT_VDTFB2B   = 8,
  CALIBOPT_SERVOOUT  = 9,
  CALIBOPT_SERVODIAG = 10

}CALIBOPT;

// Skoda Support: Servo Drive Option
typedef enum tagServoDriveOpt
{
    SINGLECOIL_DRIVE = 0,
    DUALCOIL_DRIVE = 1
}SERVODRIVEOPT;

/*******************************************************************************
*                                 clsSvpBoxSlot                                *
*                                 =============                                *
*******************************************************************************/
class clsSvpBoxSlot  : public clsBoxSlot{
protected:
    // Member variables
    static UINT8 SvpBoxChkpntVersion;

     //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetBoxChkpntVersionPtr(VOID) {return &SvpBoxChkpntVersion;}
    

private:
    UINT8       PpxChannel;

    //AO specific
    BOOL   CalibAll;
    BLIND  PartnerSlotInFail[PARTNERSLOTINFAIL_SIZE];
    BOOL   bDisOpInternlUpdte;
    UINT16 Dac50Percent;
    
    // DI Channel Specific
    UINT8      ucSns_Chk_OWD;
    DATABYTES  ForcedInputDiagStatus;
    FLOAT32 ExFreq;
    // !!!*** SVP_BOXSLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the AIH box slot's redundant synch data area
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedBoxSize() must be updated to
    // reference the new end member. This dump record begins in clsBoxSlot.
    UINT16     PvChApp;   // append index pointer
    UINT16     PvChRem;   // remove index pointer
    UINT8 CntBupreq;
    BOOL  bDisableFO;
    BOOL  bDisableFoOnOwd;
    SERVODRIVEOPT ServoDriveOpt;

    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const BOXPARAMINFO tblParamInfo[256];
    
    static const SOFTFAILTYPE AI_SlotSfMap[BYTESIZE];
    static const SOFTFAILTYPE LVDT_SlotSfMap[BYTESIZE];
    static const SOFTFAILTYPE AO_SlotSfMap[BYTESIZE];
    static const SOFTFAILTYPE DI_SlotSfMap[BYTESIZE];    
    
    UINT8         ucWdtRefreshCounter;
    UINT16        uiWdtDiagCounter;
    WDTDIAG_STATE WdtDiagState;
    
    VOID StopImpendingWatchdog(VOID);

    inline VOID *GetPvChAppPtr(VOID)    { return &PvChApp; }
    inline VOID *GetPvChRemPtr(VOID)    { return &PvChRem; }
    
    VOID     PostRedData(UINT8);

    // *************************SVP ************************************************
    VOID *GetBackCalcScanRecPtr(VOID);
    VOID *GetProcessScanRecPtr(VOID);
    VOID *GetBackUpPvScanRecPtr(VOID);
    // *************************SVP END ************************************************

    VOID *GetExFreqPtr(VOID);
    VOID *GetCalibAllPtr(VOID);
    VOID *GetCalibOptPtr(VOID);
    VOID *GetModStat1Ptr(VOID);
    VOID *GetModStat2Ptr(VOID);
    VOID *GetDbValidPtr(VOID);

    VOID *GetIolProcCpuFreeAvgPtr(VOID);
    VOID *GetIolProcCpuFreeMaxPtr(VOID);
    VOID *GetIolProcCpuFreeMinPtr(VOID);
    VOID *GetIolProcStatResetPtr(VOID);
    VOID *GetAppProcCpuFreeAvgPtr(VOID);
    VOID *GetAppProcCpuFreeMaxPtr(VOID);
    VOID *GetAppProcCpuFreeMinPtr(VOID);
    VOID *GetAppProcStatResetPtr(VOID);
    VOID *GetSvpTestParamPtr(VOID)      { return (VOID *)GetTestParamPtr(); }
    VOID *GetServoDriveOptPtr(VOID);

    VOID *GetCheckSumPtr(VOID);

    VOID PostIolProcStatReset(UINT8);
    
    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[SvpBoxChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetRedParamsPtr(VOID)  { return (VOID *)RedParams; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    SVPSHRAMBOXDATA *pSvpShramBoxData; //Shared ram box data pointer

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsSvpBoxSlot(const clsSvpBoxSlot&); // Safeguard against def copy constr.
    clsSvpBoxSlot& operator=(const clsSvpBoxSlot&); // and default assignment.
    inline VOID SetForPrimary(VOID);
    inline VOID SetOutCtl(UINT8 OutCtlState);
    inline UINT8 GetOutCtl(VOID);
    VOID ManageRedIO(VOID);
public:
    PROCESSSCANREC    ProcessScanRec;
    BACKCALCSCANREC   BackCalcScanRec;  // NOTE!! Check if required part of Dump record, then move above  // !!!*** SVP_BOXSLOT_DUMP_RECORD_END ***!!!
    BACKUPPVSCANREC   BackUpPvScanRec;
    FLOAT32      IolProcCpuFreeAvg;
    FLOAT32      IolProcCpuFreeMax;
    FLOAT32      IolProcCpuFreeMin;
    BOOL         IolProcStatReset;
    FLOAT32      AppProcCpuFreeAvg;
    FLOAT32      AppProcCpuFreeMax;
    FLOAT32      AppProcCpuFreeMin;
    BOOL         AppProcStatReset;
    CALIBOPT     CalibOpt;
    BOOL         MonitorSyncState;
    BOOL         bRebootIOMAfterDelay;
    UINT16       TimerForReboot;
    BOOL bIsBackUpStatusStable;
    inline VOID SetRedState(BLIND ucRedState) 
    {
        RedData[1] = ucRedState;
        pSvpShramBoxData->RedSyncState = ucRedState;
    }

    inline BOOL IsScanRecordParameter(UINT8 a_ucParamNumber)
    {
        BOOL bIsScanRecordParameter = FALSE;

        if((a_ucParamNumber == PARAMID_SVP_PROC_SCAN_RECORD) ||
           (a_ucParamNumber == PARAMID_SVP_BCKCLAC_PV_SCAN_RECORD) ||
           (a_ucParamNumber == PARAMID_SVP_BCKCLAC_SCAN_RECORD))
        {
            bIsScanRecordParameter = TRUE;
        }

        return bIsScanRecordParameter;
    }

    VOID ReportDSCSF();
    VOID CheckBackUpStatus(VOID);
    void FillScanRecord(UINT8 a_ucParamNumber, UINT8 *a_ReadBuffer);
    void FillProcessScanRecord(UINT8 *a_ReadBuffer);
    void FillBackCalcScanRecord(UINT8 *a_ReadBuffer);
    void FillBackUpPvScanRecord(UINT8 *a_ReadBuffer);

    inline FLOAT32 GetIolProcCpuFreeMax(VOID) { return IolProcCpuFreeMax; }
    inline FLOAT32 GetIolProcCpuFreeMin(VOID) { return IolProcCpuFreeMin; }
    inline FLOAT32 GetIolProcCpuFreeAvg(VOID) { return IolProcCpuFreeAvg; }
    inline VOID SetIolProcCpuFreeAvg(FLOAT32 a_fCpuFreeAvg) { IolProcCpuFreeAvg = a_fCpuFreeAvg; }
    inline VOID SetIolProcCpuFreeMax(FLOAT32 a_fCpuFreeMax) { IolProcCpuFreeMax = a_fCpuFreeMax; }
    inline VOID SetIolProcCpuFreeMin(FLOAT32 a_fCpuFreeMin) { IolProcCpuFreeMin = a_fCpuFreeMin; }
    VOID SetForSecondary(BOOL bAoCheck);

    clsSvpBoxSlot(MODLTYPE);
    ~clsSvpBoxSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,SVPBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32) { return ucIomDbMemory; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,SVPBOXSLOT_HPP,__LINE__); } 
    
    VOID AppInitialization(VOID);
    VOID AppStcProcessing(VOID);
    BOOL PerformModuleCalibration(VOID);
    BOOL GetCalibAllState(VOID);

    BOOL AddSoftfailEvent(EVENTTYPE, SOFTFAILTYPE, BOOL, UINT8);
    virtual VOID BoxHouseKeeping(VOID);
    virtual BOOL RegenSoftfails(VOID);

    static VOID RefreshWatchDog(VOID);      //Refresh Watchdog
    static VOID IRQ1InterruptHandler(VOID); //Watchdog prefire interrupt
    static VOID ShramReadInterruptHandler(VOID);
    static VOID IRQ4InterruptHandler(VOID); //Powersupply failure interrupt

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       AppColdInit(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);
    VOID AppPostDump(VOID);
    
    UINT8 CheckForFactoryTestMode(VOID);
    VOID SetFactoryTestMode(VOID);
    VOID GetTstTimeFromShram(VOID);
    BOOL IsCalibInProgress()
    {
        return FALSE;
    }

    //***************** DI specific ****************
    inline UINT32 GetForcedInputDiagStatus(VOID){ return ForcedInputDiagStatus.ui32Val;}
    inline UINT8 GetSnsChkOWD(VOID) { return ucSns_Chk_OWD; }
    //**********************************************

    UINT8 GetModuleStatus(VOID);
    VOID SetModuleStatus();
    UINT8  GetModStat3State(VOID);

    inline UINT32 GetRedBoxDelta(VOID) {return 0;}
    inline UINT32 GetRedBoxSize(VOID) {

        return (sizeof(strSvpBoxSlotDumpData));
//      return ((UINT32)((UINT8 *)&ProcessScanRec - (UINT8 *)&ModStat1) + 
//                        (sizeof(PROCESSSCANREC)));
    }
        
    inline UINT8 *GetRedBoxPointer(VOID) {
        return (UINT8 *)&ModStat1;
    }

    inline BOOL IsPrimaryChannelInFail(UINT8 a_ucChanNum) {
        UINT8 ucIdx = 0;
        if (a_ucChanNum > (MAXSLOTS/2)) {
            ucIdx = 1;
            a_ucChanNum -= MAXSLOTS/2;
        }
        UINT8 ucMsk = SLOTINFAIL_MASKINIT >> (a_ucChanNum - 1);
        return (PartnerSlotInFail[ucIdx] & ucMsk) ? TRUE : FALSE;
    }

    inline VOID EnableOutputs(VOID) {
        //TBD: HF_OUTPUTCONTROL if readback fails
        P_CPLDR02.B0 = 1;
        P_CPLDR02.B1 = 1;
    }

    inline VOID DisableOutputs(VOID) {
        //TBD: HF_OUTPUTCONTROL if readback fails
        P_CPLDR02.B0 = 0;
        P_CPLDR02.B1 = 0;
    }

    //Do nothing here for TC modules. This will be done when DSC processor is 
    //ready. It will send SCS to do that.
    inline VOID  DoAliveToIdleChange(VOID){}

#ifdef DEBUG
    UINT32 m_ulMaxPpxTime;
    UINT32 m_ulAvgPpxTime;
    UINT32 m_ulMinPpxTime;
    inline VOID SetCalibAll(BOOL a_bVal)   { CalibAll = a_bVal; }
#endif

    inline BOOL  GetbDisOpInternlUpdteSts(){return bDisOpInternlUpdte;}
    inline UINT16 GetDac50Percent(VOID){return Dac50Percent;}
    struct strSvpBoxSlotDumpData 
    {
        UINT16       Version;     // The first two bytes of dump record should always represent version. Do not change this. 
        FLOAT32      ExFreq;
        UINT16       Tpu5_Pri;
        UINT16       ModStat1;
        UINT16       ModStat2;
        UINT8        MaxSlots;
        BOOL         DbValid;
        FLOAT32 FieldCoilResistanceServo1;
        FLOAT32 FieldCoilResistanceServo2;
        UINT16       ServoDriveOpt;
    };

    PASTATUS  GetDumpData(UINT8* const pDump, const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    static VOID IRQ6InterruptHandler(VOID);
    VOID CheckFailOverCondition(VOID);
    BOOL SwitchInit(VOID);
    VOID ResetWdtRefreshCounter(VOID){ucWdtRefreshCounter=0;}
    VOID SendWdtTstCmdToAppProc(VOID);
    SERVODRIVEOPT GetServoDriveOpt(VOID);
};

#endif // SVPBOXSLOT_HPP
