/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcdislot.hpp                                                *
*    Description : Class clsDiSlot definition.                                 *
*******************************************************************************/
#ifndef __TCDISLOT_HPP__
#define __TCDISLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                                 CONTANTS                                     *
*******************************************************************************/
#define DISLOT_SIZE ((sizeof(clsDiSlot) + (sizeof(clsDiSlot) % 2)) / 2) 

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
#ifdef IOMTYPE_SP
    extern const UINT16 SPDI_SYNC_VER_1;    
#elif defined IOMTYPE_SVP
    extern const UINT16 SVPDI_SYNC_VER_1;    
#endif


/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
/* DI Type Options */
typedef enum tagDiType{
    DITYPE_STATUS   = 0,
    DITYPE_LATCHED  = 1
} DITYPE;
//

class clsDiSlot; // forward declaration

/* Slot Database Parameter Info */
typedef struct tagDiSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsDiSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsDiSlot::* PostPtr)(UINT8);
    VOID *   (clsDiSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} DISLOTPARAMINFO;
//

/*******************************************************************************
*                                   clsDiSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsDiSlot : public clsInSlot {
protected:
    //Member Varibales
    UINT16  LatchTimer;
    BOOL    DiPv;
    BOOL    BadPvFl;
    BOOL    LastDiPv;
    BOOL    DiPvRaw;
    INPTDIR InptDir;
    ONOFF   DiPvAuto;
    DITYPE  DiType;
#ifdef IOMTYPE_SP
    BOOL DiPvFlWrst;
#endif
    //

    //Shared ram slot data pointer
    DISHRAMSLOTDATA *pDiShramSlotData;  
    //

    //Static Member variables
    static const UINT8 RedParams[];
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const DISLOTPARAMINFO tblParamInfo[256];
#ifdef IOMTYPE_SP
    static UINT8 SpDiSlotChkpntVersion;
#elif defined IOMTYPE_SVP
    static UINT8 SvpDiSlotChkpntVersion;
#endif
    //

    //Method to Initial member variables
    VOID InitTcDiSlot(BOOL,BOOL);
    //

    //Overrided clsIoSlot Class Varibles GetPtr methods
    VOID *GetPntTypePtr(VOID);  
    VOID *GetPtExecStPtr(VOID);

    //Overriden clsIomSlot Class Varibles GetPtr methods
#ifdef IOMTYPE_SP
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SpDiSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SpDiSlotChkpntVersion;}
#elif defined IOMTYPE_SVP   
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SvpDiSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SvpDiSlotChkpntVersion;}
#endif
    //

    //Overrided clsInSlot Class Varibles GetPtr methods
    VOID *GetPvSourcePtr(VOID);
    VOID *GetPvSrcOptPtr(VOID);
    VOID *GetOwdEnablePtr(VOID);
    //

    //Member Varibles GetPtr methods
    VOID *GetLatchTimerPtr(VOID);
    VOID *GetDiPvPtr(VOID);
    VOID *GetBadPvFlPtr(VOID);   
    VOID *GetLastDiPvPtr(VOID);  
    VOID *GetDiPvRawPtr(VOID);   
    VOID *GetInptDirPtr(VOID);   
    VOID *GetDiPvAutoPtr(VOID);  
    VOID *GetDiTypePtr(VOID);   
#ifdef IOMTYPE_SP    
    VOID *GetDiPvFlWrstPtr(VOID);
#endif
    //

    //Static Varibles GetPtr methods
#ifdef IOMTYPE_SP
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SpDiSlotChkpntVersion-1].CheckPointPtr; }
#elif defined IOMTYPE_SVP
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SvpDiSlotChkpntVersion-1].CheckPointPtr; }
#endif
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    inline VOID *GetRedParamsPtr(VOID) { return (VOID *)RedParams; }
    //

    //Database Access Related Methods
    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    //

    clsDiSlot(const clsDiSlot&); // Safeguard against default copy constructor
    clsDiSlot& operator=(const clsDiSlot&); // and default assignment.
public: 
    clsDiSlot( UINT8 a_ucSltNm);
    ~clsDiSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,DISLOT_HPP,__LINE__); }
        
    VOID *operator new(UINT32, UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,DISLOT_HPP,__LINE__); } 

    //Database Access Related Methods    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    //

    //Method to Initial member variables
    VOID InitSlotDatabase(BOOL);
    //

    //Redundacny Dump Related Struct and Methods
    struct strDiSlotDumpData
    {
        UINT16 Header;      // The first two bytes of dump record should always represent version. Do not change this. 
        UINT16 PntType  ;
        UINT16 PtExecSt ; 
        UINT16 PvSource ;
        UINT16 PvSrcOpt ;
        UINT16 OwdEnable;
        UINT16 InptDir  ;
        UINT16 DiType   ;
        BOOL   Pv;
        BOOL   BadPvFl;
#ifdef IOMTYPE_SP
        BOOL DiPvFlWrst;
#endif
        BOOL   PvAuto;
        BOOL   PvRaw;
    }SYNCRECORD,*PSYNCRECORD;
    UINT32 GetRedSlotSize(VOID){return (sizeof(SYNCRECORD));}
    PASTATUS GetDumpData(UINT8* const pDump, const UINT8 MaxSize);
    PASTATUS StoreDumpData(UINT8* const pDump);
    //
};

#endif