/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohboxslot.hpp                                              *
*    Description : Class clsAohBoxSlot declaration.                            *
*******************************************************************************/
#ifndef __AOHBOXSLOT_HPP__
#define __AOHBOXSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "aohardware.hpp"
#include "aohslot.hpp"
#include "boxslot.hpp"
#if !LOWCOST
#include "aohversion.h"
#else
#include "aoversion.h"
#endif
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#define AOHBOXSLOT_SIZE ((sizeof(clsAohBoxSlot)+(sizeof(clsAohBoxSlot)%2)) / 2)

const FLOAT32 DEFAULT_OUTPUT_SLOPE      = ((FLOAT32)(MAXCURRENT_OUTPUT_DACCOUNT - MINCURRENT_OUTPUT_DACCOUNT))
                                          / (EXTENDED_OP_HILIMIT - EXTENDED_OP_LOLIMIT);
const FLOAT32 DEFAULT_OUTPUT_OFFSET     = MINCURRENT_OUTPUT_DACCOUNT - (EXTENDED_OP_LOLIMIT * DEFAULT_OUTPUT_SLOPE);
const FLOAT32 DEFAULT_LOOPBACK_SLOPE    = ((FLOAT32)(MAXCURRENT_LOOPBACK_DACCOUNT - MINCURRENT_LOOPBACK_DACCOUNT))
                                          / (EXTENDED_OP_HILIMIT - EXTENDED_OP_LOLIMIT);
const FLOAT32 DEFAULT_LOOPBACK_OFFSET   = MINCURRENT_LOOPBACK_DACCOUNT - (EXTENDED_OP_LOLIMIT * DEFAULT_LOOPBACK_SLOPE);
const FLOAT32 HART_AUTODETECT_OP        = 0.0;

const UINT8 SLOTSFBIT_OUTPUTFL = 0x80;
const UINT8 PARTNERSLOTINFAIL_SIZE = 2;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsAohBoxSlot; // forward declaration
typedef struct tagBoxParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    PASTATUS (clsAohBoxSlot::* PrePtr)(UINT8 *,UINT8);
    VOID     (clsAohBoxSlot::* PostPtr)(UINT8);
    VOID *   (clsAohBoxSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

typedef struct tagOpScanRec {
    FLOAT32 Op[MAXSLOTS];
    UINT16  InitReq;
    UINT16  StdbyMan;
} OPSCANREC;

//The definition of this struct should match the design of Flash segment 8 @ 0x7000
typedef struct tagCalibData {
    FLOAT32 CalibConstants[4 * MAXSLOTS];
    FLOAT32 FactorySlope;
    FLOAT32 FactoryOffset;
} AOCALIBDATA;


/*******************************************************************************
*                                 clsAohBoxSlot                                *
*                                 =============                                *
*******************************************************************************/
class clsAohBoxSlot : public clsBoxSlot {
private:
    BOOL    HAutoDet[MAXSLOTS];
    // Slot checkpoint is used to determine the partners HART7 compatibility.
    // Primary IOM will set this variable to Latest slot checkpoint version before
    // dump and reset to zero after sync.
    // Secondary IOM will initialise its HART7 variables based on the slot checkpoint version
    // set by the primary.
    UINT8   PartnersChkPntVer;
    // !!!*** AOH_BOXSLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the AOH box slot's redundant synch data area
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedBoxSize() must be updated to
    // reference the new end member. This dump record begins in clsBoxSlot.
    
    BOOL    CalibAll;
    BOOL    CalibrationGood;
    UINT8   NormalLpbkChannel;
    UINT8   RetryLpbkChannel;
    OPSCANREC OpScanRec;
    //Calibration Related variables
    UINT16  HiZero;
    UINT16  HiZeroHiHi;
    UINT16  TestCountHiHi;
    UINT16  TestCountHi;
    UINT16  TestCount;
    UINT16  TestCountLo;
    UINT16  TestCountLoLo;
    UINT16  Dac4Percent;
    UINT16  Dac50Percent;
    UINT16  DacOpenWireThreshold;
    UINT16  DacMinus6pt9;
    UINT16  Dac100Percent;
    UINT16  Dac4PercentofFullScale;
   
    BOOL bDisOpInternlUpdte;

    //Redundancy Related variables
    UINT8 ucCurrentSlotNum;
    BOOL  bDisableFO;
    BLIND PartnerSlotInFail[PARTNERSLOTINFAIL_SIZE];
   
    // HART members
    FLOAT32 HCuAvail;
    BLIND   HGChngFl[MAXSLOTS];
    UINT16  HGCfgChgCnt[MAXSLOTS]; //Config Change counter of all the channels.
    UINT8   HGDevSt[MAXSLOTS];     //Device status of all the channels.
    BOOL    HADCEnable[MAXSLOTS];
    UINT8   HADCStatus[MAXSLOTS];
    UINT8   AdcCycleCount[MAXSLOTS];
    FLOAT32 Op_Saved[MAXSLOTS];
    BOOL    HEnableSaved[MAXSLOTS];
    static const UINT8 CheckPointVer1[];
    static const UINT8 CheckPointVer2[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const BOXPARAMINFO tblParamInfo[256];
    AOCALIBDATA  CalibData;
    BOOL         FieldCalibOn;

#if defined(IOPTYPE_AO16)
    // PMIO AO16 Redesign non avail parameters definitions
    UINT8     SltCntr;
    FL_UNPWRD Fl_UnPwrd_Bx;
    BLIND     PmBxSfBits[SLOTINFAIL_SIZE];
    static const UINT8 PmioDumpParamTbl[];

    VOID PostFl_UnPwrd_Bx(UINT8);
#endif

    PASTATUS PreCalibAll(UINT8 *,UINT8);
    VOID     PostCalibAll(UINT8);
    PASTATUS PreHADCEnable(UINT8 *,UINT8);
    VOID     PostHADCEnable(UINT8);
    PASTATUS PreHAutoDet(UINT8 *,UINT8);
    VOID     PostHAutoDet(UINT8);
    PASTATUS PreCheckPoint(UINT8 *,UINT8);

    VOID LoadCalibrationData(VOID);
    BOOL FlashCalibrationData(VOID);

    BOOL   PerformFieldCalibration(VOID);
    BOOL   PerformFactoryCalibration(VOID);
    BOOL   CheckRefVoltage(UINT16);

    inline VOID *GetOpScanRecPtr(VOID)  { return &OpScanRec; }
    inline VOID *GetCalibAllPtr(VOID)   { return &CalibAll; }
    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[BoxChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetRedParamsPtr(VOID)  { return (VOID *)RedParams; }
    inline VOID *GetHAutoDetPtr(VOID)   { return (VOID *)HAutoDet; }
    inline VOID *GetHADCEnablePtr(VOID)   { return (VOID *)HADCEnable; }
    inline VOID *GetHADCStatusPtr(VOID)   { return (VOID *)HADCStatus; }
    inline VOID *GetHGCfgChgCntPtr(VOID){ return (VOID *)HGCfgChgCnt;}
    inline VOID *GetHGChngFlPtr(VOID)   { return (VOID *)HGChngFl; }
    inline VOID *GetHCuAvailPtr(VOID)   { return (VOID *)&HCuAvail; }
    inline VOID *GetHGDevStPtr(VOID)    { return (VOID *)HGDevSt;}

    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    friend VOID *clsAohSlot::GetOpPtr(VOID);
    friend VOID *clsAohSlot::GetInitReqPtr(VOID);
    friend VOID *clsAohSlot::GetStdbyManPtr(VOID);

#if !defined(IOPTYPE_AO16)
    // accessing it as public method in PMIO AO16 Redesign
    UINT8    *GetParamPtr(UINT8);
#endif

    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsAohBoxSlot(const clsAohBoxSlot&); // Safeguard against def copy constr.
    clsAohBoxSlot& operator=(const clsAohBoxSlot&); // and default assignment.

public:
    clsAohBoxSlot(MODLTYPE);
    ~clsAohBoxSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AOHBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32) { return ucIomDbMemory; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AOHBOXSLOT_HPP,__LINE__); }
    
    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       AppColdInit(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);

  
    VOID   TestLoopbackCircuit(VOID);
    VOID   AppStcProcessing(VOID); 
    VOID   AppInitialization(VOID);
    BOOL   PerformModuleCalibration(VOID);
    FLOAT32 DoSuccessiveApproximation(BOOL a_bPrint = FALSE);

#if defined(IOPTYPE_AO16)
    // for redesign PMIO AO16    
    inline UINT32 GetRedBoxDelta(VOID)   { return 0; }
    inline UINT32 GetRedBoxSize(VOID)    { return PMIO_BOXDUMP_PARAMSIZE; }
    inline UINT8 *GetRedBoxPointer(VOID) { return (UINT8 *)PmioDumpParamTbl; }
    // added to resolve, PAR# 1-7L6ZU89
    inline VOID *GetPmBxSfBitsPtr(VOID)
    { 
        UINT8 ucIndex;

        for (ucIndex = 0; ucIndex < 6; ucIndex++)
            PmBxSfBits[ucIndex] = BoxSfBits[ucIndex];

        for (ucIndex = 6; ucIndex < 12; ucIndex++)
            PmBxSfBits[ucIndex] = SlotSfBits[ucIndex-6];

        for (ucIndex = 12; ucIndex < 16; ucIndex++)
            PmBxSfBits[ucIndex] = MapSlotInFail[ucIndex - 12];

        return PmBxSfBits;
    }
#else
    inline UINT32 GetRedBoxDelta(VOID) {return (UINT32)((UINT8*)&PartnersChkPntVer - (UINT8*)&HAutoDet[MAXSLOTS-1]);}
    inline UINT32 GetRedBoxSize(VOID) {
        return ((UINT32)((UINT8 *)&PartnersChkPntVer - (UINT8 *)&ModStat1) + sizeof(PartnersChkPntVer));
    }
        
    inline UINT8 *GetRedBoxPointer(VOID) {
        return (UINT8 *)&ModStat1;
    }
#endif

    inline FLOAT32 GetOp(UINT8 a_ucChanNum) { 
        return OpScanRec.Op[a_ucChanNum - 1]; 
    }

    inline VOID SetOp(UINT8 a_ucChanNum, FLOAT32 a_fOp, BOOL a_bDrvOp = TRUE) {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        OpScanRec.Op[a_ucChanNum - 1] = a_fOp;
        set_imask_exr(uiMask);
        BOOL bDrvOp = a_bDrvOp; // To avoid constant in condition compiler warning.
        if (bDrvOp) {
#if !defined(IOPTYPE_AO16)
            // for redesign PMIO, disabled due to RED DATA mismatch
            SLOT(a_ucChanNum)->SetOpInternl(a_fOp);
#endif
            SLOT(a_ucChanNum)->UpdateOpFinal(a_fOp) ;
        }
    }
 
    inline BOOL GetInitReq(UINT8 a_ucChanNum) 
    {
        UINT16 uiBitIndex  = 0x8000 >> (a_ucChanNum - 1);
        return ((OpScanRec.InitReq & uiBitIndex) > 0) ? ON : OFF;
    }
    
    inline VOID SetInitReq(UINT8 a_ucChanNum,BOOL bInitReq)
    {
        UINT16 uiBitIndex  = 0x8000 >> (a_ucChanNum - 1);
        if (TRUE == bInitReq) OpScanRec.InitReq |= uiBitIndex;
        else OpScanRec.InitReq &= ~uiBitIndex;       
    }

    inline BOOL GetStdbyMan(UINT8 a_ucChanNum) 
    {
        UINT16 uiBitIndex  = 0x8000 >> (a_ucChanNum - 1);
        return ((OpScanRec.StdbyMan & uiBitIndex) > 0) ? ON : OFF;
    }
    
    inline VOID SetStdbyMan(UINT8 a_ucChanNum,BOOL bStdbyMan)
    {
        UINT16 uiBitIndex  = 0x8000 >> (a_ucChanNum - 1);
        if (TRUE == bStdbyMan) OpScanRec.StdbyMan |= uiBitIndex;
        else OpScanRec.StdbyMan &= ~uiBitIndex;       
    }

    inline VOID EnableOutputs(VOID) {
        //TBD: HF_OUTPUTCONTROL if readback fails
        DIS_SWB_n = 1;
        DIS_SWA_n = 1;
    }

    inline VOID DisableOutputs(VOID) {
        //TBD: HF_OUTPUTCONTROL if readback fails
        DIS_SWB_n = 0;
        DIS_SWA_n = 0;
    }

    inline BOOL IsPrimaryChannelInFail(UINT8 a_ucChanNum) {
        UINT8 ucIdx = 0;
        if (a_ucChanNum > (MAXSLOTS/2)) {
            ucIdx = 1;
            a_ucChanNum -= MAXSLOTS/2;
        }
        UINT8 ucMsk = SLOTINFAIL_MASKINIT >> (a_ucChanNum - 1);
        return (PartnerSlotInFail[ucIdx] & ucMsk) ? TRUE : FALSE;
    }

    inline VOID ClearPartnerSlotInFail(VOID) {
        PartnerSlotInFail[0] = 0;
        PartnerSlotInFail[1] = 0;
    }

    inline BOOL IsFieldCalib() {return FieldCalibOn;}
    inline BOOL GetCalibAllState(VOID)  { return CalibAll;}
    inline BOOL IsCalibrationGood(VOID)  { return CalibrationGood;}
    inline AOCALIBDATA *GetCalibDataPtr(VOID) { return &CalibData;}

    //Redundancy Related Diagnostic Declarations
    VOID   SetForPrimary(VOID);
    VOID   SetForSecondary(BOOL);

    VOID   RecSecondaryFailover();

    inline BOOL GetBackupStatus(VOID){
        return(BUPREQ_FB);
    } 
    inline UINT8  GetModStat3State (VOID) { return (UINT8)ModStat3.OutCtl; }
    
    VOID FailOvrRedState_Mgmt(VOID);
    inline UINT8 GetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        return (HGChngFl[a_ucSlot - 1] & a_ucBit);
    }

    inline VOID SetHGCfgChgCnt(UINT8 a_ucSlot,UINT16 a_ucCfgChgCnt) {
        HGCfgChgCnt[a_ucSlot - 1] = a_ucCfgChgCnt;
    }

    inline VOID SetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        HGChngFl[a_ucSlot - 1] |= a_ucBit;
    }

    inline VOID ResetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        HGChngFl[a_ucSlot - 1] &= ~a_ucBit;
    }

    inline VOID ToggleHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) {
        HGChngFl[a_ucSlot - 1] ^= a_ucBit;
    }

    inline VOID InitHGChngFl(UINT8 a_ucSlot) {
        HGChngFl[a_ucSlot - 1] = 0;
    }

    inline VOID InitHGCfgChgCnt(UINT8 a_ucSlot) {
        HGCfgChgCnt[a_ucSlot - 1] = 0;
    }
    inline VOID SetHGDevSt(UINT8 a_ucSlot,UINT8 a_ucSts) {
        HGDevSt[a_ucSlot - 1] = a_ucSts;
    }

    inline FLOAT32 GetHCuAvail(VOID) { return HCuAvail; }
    inline VOID SetHCuAvail(FLOAT32 a_fVal) { HCuAvail = a_fVal; }
    inline BOOL GetHAutoDet(UINT8 a_ucSlot) { return HAutoDet[a_ucSlot - 1]; }
    inline BOOL GetHADCEnable(UINT8 a_ucSlot) { return HADCEnable[a_ucSlot - 1]; }
    inline UINT8 GetHADCStatus(UINT8 a_ucSlot) { return HADCStatus[a_ucSlot - 1]; }
    inline VOID ResetHAutoDet(UINT8 a_ucSlot) { HAutoDet[a_ucSlot - 1] = FALSE; }
    inline VOID ResetHADCEnable(UINT8 a_ucSlot) { HADCEnable[a_ucSlot - 1] = FALSE; }
    inline VOID SetHADCStatus(UINT8 a_ucSlot, UINT8 a_ucStatus) { HADCStatus[a_ucSlot - 1] = a_ucStatus; }
    inline VOID DecAdcCycleCount(UINT8 a_ucSlot) {if (AdcCycleCount[a_ucSlot - 1] != 0) AdcCycleCount[a_ucSlot - 1] -= 1; }
    inline UINT8 GetAdcCycleCount(UINT8 a_ucSlot) {return AdcCycleCount[a_ucSlot - 1]; }
    inline VOID SetAdcCycleCount(UINT8 a_ucSlot, UINT8 a_ucCount) {AdcCycleCount[a_ucSlot - 1] = a_ucCount; }
    VOID CheckFailOverCondition(VOID);
    BOOL SwitchInit(VOID);
    VOID EnableOutputFailFO(VOID) { SfActionTbl[2] |= 0x80; }

    inline VOID ResetCurrentSlotNum(){ucCurrentSlotNum =1;}
    inline UINT16 GetDac50Percent(VOID){return Dac50Percent;}
#ifdef DEBUG
    inline VOID SetCalibAll(BOOL a_bVal) { CalibAll = a_bVal; }
#endif
    VOID       AppPreDump(VOID);
    VOID       AppPostDump(VOID);
    inline VOID       AppSyncver(VOID){ bDisOpInternlUpdte = FALSE;}
    inline BOOL       GetbDisOpInternlUpdteSts(){return bDisOpInternlUpdte;}

#if defined(IOPTYPE_AO16)
    // PMIO AO16 Redesign inline methods & defs
    UINT8 *GetParamPtr(UINT8);
    inline VOID *GetSltCntrPtr(VOID)       { return &SltCntr; }
    inline BOOL  GetFl_UnPwrd_Bx(VOID)     { return Fl_UnPwrd_Bx;  }
    inline VOID *GetFl_UnPwrd_BxPtr(VOID)  { return &Fl_UnPwrd_Bx; }
    inline VOID *GetPmioDumpParamPtr(VOID) { return (VOID *)PmioDumpParamTbl; }
    inline VOID *GetPmioHartDumpParamPtr(VOID)     { return (VOID *)NULL; }

    inline UINT8 IsCheckPointParam(UINT8 ucParamId) 
    {
        UINT8 ucArrayIndex = 0;
        UINT8 ucChkPntIndex = 0;

        while (CheckPointVer2[ucArrayIndex])
        {            
            if (CheckPointVer2[ucArrayIndex] == ucParamId)
                return (ucChkPntIndex + 1);
            else
                ucChkPntIndex += GetParamSize(CheckPointVer2[ucArrayIndex]);

            ucArrayIndex++;
        }

        return PA_NULL;
    }
#endif
};

#endif
