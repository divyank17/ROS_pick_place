/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : dislot.hpp                                                  *
*    Description : Class clsDiSlot declaration.                                *
*******************************************************************************/
#ifndef __DISLOT_HPP__
#define __DISLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "scheduler.hpp"
#include "inslot.hpp"
#include "ecl.hpp"
#if defined(IOMTYPE_UIO) 
#include "hartdb.hpp"
#endif
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define DISLOT_SIZE ((sizeof(clsDiSlot) + (sizeof(clsDiSlot) % 2)) / 2)


// LATCH TIME CONSTANTs are baased on the frequency of calls to ProcessSlot

#if defined(IOMTYPE_UIO) 
// UIO definitions for latch time are in uioboxslot.hpp
#else
// For 1.5 sec LatchTimer, in Normal Mode the value would be 1500/20=75 and
// IN LOW LAtency Mode it would be 1500/5=300
const UINT16 LATCHTIMECONST = 75;
const UINT16 LOWLATLATCHTIMECONST = 300;
#endif

const UINT8 DISLOT_SPARESIZE = 8;

#ifdef IOMTYPE_DISOE
const UINT8 DEFAULT_DEBOUNCE  = 10;
const UINT8 DEFAULT_PVCHGDLY  = 0;
const UINT8 MAXPVCHGDLY       = 60;
const UINT8 MAXDEBOUNCETIME   = 50;
#endif

// IOL Parameter number definitions (UIO definitions in dislot.cpp)
#ifndef IOMTYPE_UIO
#define PARAMID_DITYPE      60
#define PARAMID_INPTDIR     64
#define PARAMID_PNTTYPE     70
#define PARAMID_PTEXECST    71
#define PARAMID_PVSOURCE    78
#define PARAMID_PVSRCOPT    79
#endif

#ifdef IOMTYPE_DISOE
#define PARAMID_EVTOPT          62
#define PARAMID_DEBOUNCE        92
#define PARAMID_PVCHGDLY        93
// declare Delayed Pv change packet structure
typedef struct tagDelayedPvChgPktRecord{
    UINT8   SOEslot         :6;
    UINT8   CurrentState    :1;
    UINT8   LastReportedSt  :1;
    UINT32  EventTimeStamp  :24;
    UINT16  SyncID             ;
}PVCHGDLYPKT;
#endif


#if defined(IOPTYPE_DI)

#define STATE_LRS_MASK  0x01              //STATE LRS MASK
#define OFF_LRS_MASK    0x02              //OFF LRS MASK
#define ON_LRS_MASK     0x04              //ON LRS MASK

#define NOALARM         0
#define OFFNORMAL_ALM   1
#define CHNGOFSTATE_ALM 15


//Checkpoint parameters
#define PARAMID_PNTTYPE   70
#define PARAMID_PNTFORM   69
#define PARAMID_DITYPE    60
#define PARAMID_INPTDIR   64
#define PARAMID_PVSRCOPT  79
#define PARAMID_PVSOURCE  78
#define PARAMID_EVTOPT    62
#define PARAMID_ALMOPT    51
#define PARAMID_DLYTIME   61
#define PARAMID_CONTCUT   58
#define PARAMID_PVNORMAL  75
#define PARAMID_AVTV      54
#define PARAMID_COUNTDWN  59
#define PARAMID_RESETVAL  81

#define PARAMID_PTEXECST  71
#define    PARAMID_PTEXECST_LRS 247

#define    PARAMID_PVNORMFL    76
#define    PARAMID_LASTAV      98
#define    PARAMID_OFFNRMFL    65
#define    PARAMID_AVTVFL      56
#define    PARAMID_COMMAND     57
#define    PARAMID_RESETFL     80
#define    PARAMID_STARTFL     84
#define    PARAMID_STOPFL      86
#define    PARAMID_STATE       85
#define    PARAMID_OVERFLOW    68
#define    PARAMID_PV_PVFL     72
#define    PARAMID_LAST_PV     103
//#define    PARAMID_BADPVFL    89

#define PARAMID_HIGHAL      63
#define PARAMID_PVRAW       77
#define PARAMID_PVAUTO      73
#define PARAMID_AV          52
#define PARAMID_OLDAV       66

#endif

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsDiSlot; // forward declaration
typedef struct tagDiSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsDiSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsDiSlot::* PostPtr)(UINT8);
    VOID *   (clsDiSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} DI_SLOTPARAMINFO;

#if defined(IOMTYPE_UIO)
// Decalaration for Av,AvRaw Status
typedef enum tagStatus {
    STATUS_BAD       =0,
    STATUS_UNCERTN   =1,
    STATUS_NORMAL    =2,
    STATUS_MANUAL    =3
} STATUS;
#endif

typedef enum tagDiType{
    DITYPE_STATUS   = 0,
    DITYPE_LATCHED  = 1,
    DITYPE_ACCUM    = 2
} DITYPE;

#if defined(IOPTYPE_DI)

typedef enum tagAlmOpt{
  ALMOPT_NONE       = 0,          
  ALMOPT_OFFNORMAL  = 1,
  ALMOPT_CMDDIS     = 2,
  ALMOPT_CHNGOFST   = 3,
  ALMOPT_CHSTOFFN   = 4 
}ALMOPT;

typedef enum tagCommand{
  NONE       = 0,          
  START_COM  = 1,
  STOP_COM   = 2,
  RESET_COM  = 3
}COMMAND;

typedef enum tagHighAl {
    CLEAR_ALARM       = 0,
    OFFNORM_ALARM     = 1,
    CHGOFSTATE_ALARM  = 2
} ALMCODE;

typedef enum tagPvNormal{
  PVNORMAL_OFF  = 0,          
  PVNORMAL_ON  = 1
}PVNORMAL;

typedef enum tagState{
  STOPPED  = 0,          
  RUNNING  = 1
}STATE;

//typedef enum AlmDirCode{
//  ALMOFF = 0,   //ALARM GOING OFF
//  ALMON = 0x10  //ALARM GOING ON
//}ALMDIRCODE;

// added to fix the PAR# 1-GJ6MQXN, 1-GLD5D07
typedef union tagAlmInfo {
    UINT8 ucByte;
    struct {
        UINT8 unused1     : 1;
        UINT8 unused2     : 1;
        UINT8 unused3     : 1;
        UINT8 ucOffNormFl : 1; //OFFNORMAL Flag
        UINT8 unused4     : 1;
        UINT8 ucOnFl      : 1; //ON Flag
        UINT8 ucOffFl     : 1; //OFF Flag
        UINT8 ucStateFl   : 1; //STATE Flag
    } Bit;
} ALMINFO;

typedef union tagAlarmLrs {
    UINT8 ucByte;
    struct {
        UINT8 unused1       : 1;
        UINT8 unused2       : 1;
        UINT8 unused3       : 1;
        UINT8 ucOffNormLrs  : 1; //OFFNORMAL LRS MASK
        UINT8 unused4       : 1;
        UINT8 ucOnLrs       : 1; //ON LRS MASK
        UINT8 ucOffLrs      : 1; //OFF LRS MASK
        UINT8 ucStateLrs    : 1; //STATE LRS MASK
    } Bit;
} ALARMLRS;

#define ALMOFF  0     //ALARM GOING OFF
#define ALMON   0x10  //ALARM GOING ON


#endif

#if defined (IOMTYPE_DISOE) || defined(IOPTYPE_DI)
// Decalaration for Evnt option.Default = NONE =(0)
typedef enum tagEvtOpt{
    EVTOPT_NONE     = 0,
    EVTOPT_EIP      = 1,
    EVTOPT_EIPSOE   = 2,
    EVTOPT_SOE      = 3
}EVTOPT;
#endif
 /*******************************************************************************
*                                   clsDiSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsDiSlot : public clsInSlot {
private:
    UINT8   DiSlotSpare[DISLOT_SPARESIZE];
    DITYPE  DiType;
    INPTDIR InptDir;  
    BOOL    PvRaw;
    ONOFF   PvAuto;
    BOOL    LastPv;
#if defined(IOMTYPE_UIO)
    FLOAT32 ufC1;
    FLOAT32 ufC2;
    BOOL    TvProc;
#endif
    // !!!*** DI_SLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the DI slot's redundant synch data area.
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end or to the spare memory allocated. If new member is added to the
    // end, GetRedSlotSize() must be updated to reference the new end member. 
    // This dump record begins in clsIoSlot.
#ifdef IOMTYPE_DISOE
    EVTOPT      EvtOpt;
    UINT8       Debounce; // Default = 10msec.(0 - 50 msecs).
    UINT8       PvChgDly; // Default = 0 sec.(0 - 60 secs).
    // !!!*** DISOE_SLOT_DUMP_RECORD_END ***!!!
    UINT8   PvChgDlyTimer;      // pv change timer
    BOOL    bPvChgDlyEventSet;  // used to check whether the delayed PvChg pcket present
    PVCHGDLYPKT DelayedPvChgPkt;
#endif
    UINT16  LatchTimer;
    UINT16  CheckSum;
    BOOL    RawInput;
#if defined(IOMTYPE_UIO)
    BOOL    ResetFl;
#endif
    static const UINT8 CheckPointVer1[];
#if defined(IOPTYPE_DI)
    static const UINT8 CheckPointVer2[];
    static const UINT8 PmioDumpParamTbl[];
#endif
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[];
    static const DI_SLOTPARAMINFO tblParamInfo[256];
#if defined(IOMTYPE_UIO)
    static const UINT8 CheckPointVer2[];
    static UINT8 DiSlotChkpntVersion;
    static const UINT8 HEuRngExt[];
    clsHartCfgDb HartCfgDb;
    clsHartCfgDb7 HartCfgDb7;
    clsHartDevDb HartDevDb;
#endif

#if defined(IOMTYPE_UIO)
    PASTATUS PreInitPntType(UINT8 *writebuffer, UINT8);
#endif
    PASTATUS PrePntType(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostPntType(UINT8 AccLvl);
    PASTATUS PrePtExecSt(UINT8 *writebuffer,UINT8 AccLvl);
    VOID     PostPtExecSt(UINT8 AccLvl);
    PASTATUS PrePvSource(UINT8 *writebuffer,UINT8 AccLvl);
    VOID     PostPvSource(UINT8 AccLvl);
    PASTATUS PrePvSrcOpt(UINT8 *writebuffer,UINT8 AccLvl);
    VOID     PostPvSrcOpt(UINT8 AccLvl);
    PASTATUS PreDiType(UINT8 *writebuffer,UINT8 AccLvl);
    VOID     PostDiType(UINT8 AccLvl);
    PASTATUS PreInptDir(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostInptDir(UINT8 AccLvl);
    PASTATUS PrePv(UINT8 *writebuffer, UINT8 AccLvl);
    PASTATUS PreOwdEnable(UINT8 *,UINT8);
#if defined (IOPTYPE_DI)
    // added to fix the PAR# 1-GJ6MQXN, 1-GLD5D07
    VOID  CreatePtExecStEvt(EVENTTYPE a_EventType);
    
    VOID AlarmProcessorDI(VOID);
    VOID ProcessOffNormal(VOID);
    VOID ProcessChangeOfState(VOID);
    VOID PvclEntryRoutine(VOID);

    ALMOPT AlmOpt;
    //PASTATUS PreAlmOption(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostAlmOption(UINT8);
    inline VOID *GetAlmOptPtr(VOID)    { return &AlmOpt; }    

    INT16 Av;
    inline VOID *GetAvPtr(VOID)    { return &Av; }    

    INT16 AvTv;
    //PASTATUS PreAvTv(UINT8 *writebuffer, UINT8 AccLvl);
    inline VOID *GetAvTvPtr(VOID)    { return &AvTv; }    

    BOOL  AvTvFl;
    inline VOID *GetAvTvFlPtr(VOID)    { return &AvTvFl; }    

    COMMAND Command;
    PASTATUS PreCommand(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostCommand(UINT8);
    inline VOID *GetCommandPtr(VOID)    { return &Command; }   

    PASTATUS PreContCut(UINT8 *writebuffer, UINT8 AccLvl);

    BOOL        Countdown;
    //PASTATUS PreCountdown(UINT8 *writebuffer, UINT8 AccLvl);
    inline VOID *GetCountdownPtr(VOID)    { return &Countdown; }   
    
    INT16 DelayTime;
    PASTATUS PreDelayTime(UINT8 *writebuffer, UINT8 AccLvl);
    inline VOID *GetDelayTimePtr(VOID)    { return &DelayTime; }   

    EVTOPT      EvtOpt;
    PASTATUS PreEvtOpt(UINT8 *writebuffer, UINT8 AccLvl);
    //VOID     PostEvtOpt(UINT8);
    inline VOID *GetEvtOptPtr(VOID)    { return &EvtOpt; }   

    ALMCODE  HighAl;
    inline VOID *GetHighAlPtr(VOID)   { return &HighAl; }

    BOOL OffNrmfl;
    inline VOID *GetOffNrmflPtr(VOID)   { return &OffNrmfl; }

    INT16 OldAv;
    inline VOID *GetOldAvPtr(VOID)   { return &OldAv; }

    FLOAT32 OldAvr;
    inline VOID *GetOldAvrPtr(VOID)   { return &OldAvr; }

    BOOL OverFlow;
    inline VOID *GetOverFlowPtr(VOID)   { return &OverFlow; }

    //PASTATUS PrePntForm(UINT8 *writebuffer, UINT8 AccLvl);
    inline VOID *GetPntFormPtr(VOID)   { return &PntForm; }

    //VOID     PostPv(UINT8);
    
    PVNORMAL PvNormal;
    //PASTATUS PrePvNormal(UINT8 *writebuffer, UINT8 AccLvl);
    inline VOID *GetPvNormalPtr(VOID)    { return &PvNormal; } 

    BOOL PvNormFl;
    //PASTATUS PrePvNormFl(UINT8 *writebuffer, UINT8 AccLvl);
    inline VOID *GetPvNormFlPtr(VOID)    { return &PvNormFl; } 

    BOOL ResetFl;
    PASTATUS PreResetFl(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostResetFl(UINT8);
    inline VOID *GetResetFlPtr(VOID){return &ResetFl;}

    INT16 ResetVal;
    PASTATUS PreResetVal(UINT8 *writebuffer, UINT8 AccLvl);
    inline VOID *GetResetValPtr(VOID){return &ResetVal;}

    FLOAT32 ResetVlr;
    inline VOID *GetResetVlrPtr(VOID){return &ResetVlr;}

    BOOL StartFl;
    PASTATUS PreStartFl(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostStartFl(UINT8);
    inline VOID *GetStartFlPtr(VOID){return &StartFl;}

    STATE State;
    inline VOID *GetStatePtr(VOID){return &State;}

    BOOL StopFl;
    PASTATUS PreStopFl(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostStopFl(UINT8);
    inline VOID *GetStopFlPtr(VOID){return &StopFl;}

    INT16 LastAv;
    inline VOID *GetLastAvPtr(VOID){return &LastAv;}

    UINT16 DlyTimer;
    inline VOID *GetDlyTimerPtr(VOID){return &DlyTimer;}

    // added to fix the PAR# 1-GJ6MQXN, 1-GLD5D07
    ALMINFO AlmInfo;
    ALARMLRS AlarmLrs;
    inline VOID *GetAlarmLrsPtr(VOID){return &AlarmLrs;}

    UINT16  CosTimer;
    inline VOID *GetCosTimerPtr(VOID){return &CosTimer;}
#endif
    // Receiver Beware checks only for DISOE 
#ifdef IOMTYPE_DISOE
    PASTATUS PreEvtOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreDebounce(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID PostDebounce(UINT8 a_ucAccLvl);
    PASTATUS PrePvChgDly(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID PostPvChgDly(UINT8 a_ucAccLvl);
#endif
#if defined(IOMTYPE_UIO)
    // CFGRESTORE must only be written to the clsUioSlot, this pre-function ensures this is true
    PASTATUS PreCfgRestore(UINT8 *, UINT8) { return DO_PARAMETER_INVALID; }
    PASTATUS PreAv(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostAv(UINT8);
    PASTATUS PreTv(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostTv(UINT8);
    PASTATUS PreC1(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    PASTATUS PreC2(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    PASTATUS PreResetFl(UINT8 *a_writebuffer,UINT8 a_ucAccLvl);
    VOID     PostResetFl(UINT8 a_ucAcclvl);
#endif

    VOID InitDiSlot(BOOL,BOOL);
    VOID DoPvDefault(VOID);
 
    VOID *GetPvPtr(VOID);
    VOID *GetBadPvFlPtr(VOID);

#if defined(IOMTYPE_UIO)
    VOID *GetAvPtr(VOID);
    VOID *GetAvStsPtr(VOID);
    VOID *GetAvRawPtr(VOID);
    VOID *GetAvRawStsPtr(VOID);
    VOID *GetAvTvFlPtr(VOID);
    VOID *GetTvPtr(VOID);
    inline VOID *GetC1Ptr(VOID){ return &ufC1;}
    inline VOID *GetC2Ptr(VOID){ return &ufC2;}
    inline VOID *GetResetFlPtr(VOID){return &ResetFl;}
    inline VOID *GetTvProcPtr(VOID){return &TvProc;}
#endif

    inline VOID *GetDiTypePtr(VOID)    { return &DiType; }
    inline VOID *GetInptDirPtr(VOID)   { return &InptDir; }
    inline VOID *GetPvRawPtr(VOID)     { return &PvRaw; }
    inline VOID *GetPvAutoPtr(VOID)    { return &PvAuto; }
    inline VOID *GetLatchTimerPtr(VOID){ return &LatchTimer; }
    inline VOID *GetLastPvPtr(VOID)    { return &LastPv; }
#if defined(IOMTYPE_UIO)    
    inline VOID *GetCheckPointPtr(VOID){ return (VOID *)CheckPointVerTable[DiSlotChkpntVersion-1].CheckPointPtr; }
#else
    inline VOID *GetCheckPointPtr(VOID){ return (VOID *)CheckPointVerTable[SlotChkpntVersion-1].CheckPointPtr; }
#endif    
    inline VOID *GetRedParamsPtr(VOID) { return (VOID *)RedParams; }

#ifdef IOMTYPE_DISOE
    inline VOID *GetEvtOptPtr(VOID)       { return  &EvtOpt; }
    inline VOID *GetDebouncePtr(VOID)     { return  &Debounce; }
    inline VOID *GetPvChgDlyPtr(VOID)     { return  &PvChgDly; }
#endif

#if defined(IOMTYPE_UIO)
    inline PASTATUS PreCheckPoint(UINT8 *,UINT8) { 
      DiSlotChkpntVersion = LATEST_UIO_DI_SLTCHKPNT_VERSION;
      return PA_OK; 
    }
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &DiSlotChkpntVersion;}
#endif
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

#if !defined(IOPTYPE_DI)
    UINT8    *GetParamPtr(UINT8);
#endif

    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsDiSlot(const clsDiSlot&); // Safeguard against default copy constructor
    clsDiSlot& operator=(const clsDiSlot&); // and default assignment.

public: 
    clsDiSlot(UINT8);
    ~clsDiSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,DISLOT_HPP,__LINE__); }
    
    VOID *operator new(UINT32, UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,DISLOT_HPP,__LINE__); } 
   
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);

    VOID InitSlotDatabase(BOOL);
    VOID InactivateSlot(VOID);  
    VOID UpdateBadPv(VOID);
#if defined (IOMTYPE_UIO)
    inline BOOL GetRawInput(VOID){ return RawInput; }
    inline VOID SetRawInput(BOOL a_bPvraw){ RawInput = a_bPvraw; }
    virtual UINT8 GetSlotChkPntParamId(VOID);
    virtual UINT8 GetLatestSlotChkPntVersion(VOID);
    virtual UINT8 GetPtExecStParamId(VOID);
    inline DITYPE   GetDiType(VOID){ return DiType; }
    inline PVSOURCE GetPvSource(VOID){ return PvSource; }
    inline FLOAT32  GetC1(VOID){return ufC1;}
    inline FLOAT32  GetC2(VOID){return ufC2;}
    inline BOOL GetTvProc(VOID){return TvProc;}
    inline VOID SetTvProc(BOOL a_tvproc){TvProc = a_tvproc;}
    BOOL IsPulseAccumCapable(VOID) {
        return ((ChanNum >= PC_CHANNEL1 && ChanNum <= PC_CHANNEL4) && (DiType == DITYPE_ACCUM)) ? TRUE:FALSE;
    }
    inline VOID *GetHDevCdPtr(VOID)       { return (VOID *)HartCfgDb.HDevCd; }
    inline VOID *GetHDvRngExtPtr(VOID)    { return (VOID *)HartDevDb.HDvRngExt; }
    inline VOID *GetHEuRngExtPtr(VOID)    { return (VOID *)HEuRngExt; }
    inline VOID *GetHAlarmEnablePtr(VOID) { return &HartCfgDb.HAlarmEnable; }
    inline VOID *GetHEnablePtr(VOID)      { return &HartCfgDb.HEnable; }
    inline VOID *GetHScanCfgPtr(VOID)     { return &HartCfgDb.HScanCfg; }
    inline VOID *GetHDynRatePtr(VOID)     { return &HartDevDb.HDynRate; }
    inline VOID *GetHDevRatePtr(VOID)     { return &HartDevDb.HDevRate; }
    inline VOID *GetHSlotDvcPtr(VOID)     { return HartCfgDb7.HSlotDvc7; }
    inline VOID *GetHSlotDvcPtr7(VOID)    { return &HartCfgDb7.HSlotDvc7[4];}
    inline VOID *GetHComThrsPtr(VOID)     { return &HartCfgDb.HComThrs; }
    inline VOID *GetHComHysPtr(VOID)      { return &HartCfgDb.HComHys; }
    inline VOID *GetHComStsPtr(VOID)      { return &HartDevDb.HComSts; }
    inline VOID *GetHNComErrPtr(VOID)     { return &HartDevDb.HNComErr; }
    inline VOID *GetHLComFailPtr(VOID)    { return &HartDevDb.HLComFail; }
    inline VOID *GetHCmd0Ptr(VOID)        { return &HartDevDb.HCmd0; }
    inline VOID *GetH7Cmd0Ptr(VOID)       { return &HartDevDb.HCmd0.ucBytes[HART6_CMD0_RESPONSE_SIZE]; }
    inline VOID *GetHCmd12Ptr(VOID)       { return &HartDevDb.HCmd12; }
    inline VOID *GetHCmd13Ptr(VOID)       { return &HartDevDb.HCmd13; }
    inline VOID *GetHCmd14Ptr(VOID)       { return &HartDevDb.HCmd14; }
    inline VOID *GetHCmd15Ptr(VOID)       { return &HartDevDb.HCmd15; }
    inline VOID *GetHCmd16Ptr(VOID)       { return &HartDevDb.HCmd16; }
    inline VOID *GetHLongTagPtr(VOID)     { return &HartDevDb.HLongTag; }
    inline VOID *GetHDynValPtr(VOID)      { return HartDevDb.HDynVal; }
    inline VOID *GetHDynStPtr(VOID)       { return HartDevDb.HDynSt; }
    inline VOID *GetHDynCcPtr(VOID)       { return HartDevDb.HDynCc; }
    inline VOID *GetHDynEuPtr(VOID)       { return HartDevDb.HDynEu; }
    inline VOID *GetHSlot0TSPtr(VOID)     { return &HartDevDb.HDevSlot0DTS;}
    inline VOID *GetHSlotValPtr(VOID)     { return HartDevDb.HSlotVal; }
    inline VOID *GetHSlotStPtr(VOID)      { return HartDevDb.HSlotSt; }
    inline VOID *GetHSlotCcPtr(VOID)      { return HartDevDb.HSlotCc; }
    inline VOID *GetHSlotEuPtr(VOID)      { return HartDevDb.HSlotEu; }
    inline VOID *GetHDevStPtr(VOID)       { return HartDevDb.HDevSt; }
    inline VOID *GetHCmd48Ptr(VOID)       { return &HartDevDb.HCmd48; }
    inline VOID *GetHCmdFailPtr(VOID)     { return &HartDevDb.HCmdFail; }
    inline VOID *GetHCmdRespPtr(VOID)     { return &HartDevDb.HCmdResp; }
    inline VOID *GetHDvMfgCdPtr(VOID)     { return &HartCfgDb.HDvMfgCd; }
    inline VOID *GetHDvMfgCd7Ptr(VOID)    { return HartCfgDb7.HDvMfgCd7;}
    inline VOID *GetHDevIdCdPtr(VOID)     { return HartCfgDb.HDevIdCd; }
    inline VOID *GetHDvTypCdPtr(VOID)     { return &HartCfgDb.HDvTypCd; }
    inline VOID *GetHDvTypCd7Ptr(VOID)    { return HartCfgDb7.HDvTypCd7;}
    inline VOID *GetHDvRevCdPtr(VOID)     { return &HartCfgDb.HDvRevCd; }
    inline VOID *GetHDdRevCdPtr(VOID)     { return &HartCfgDb.HDdRevCd; }
    inline VOID *GetHNtfyCfgPtr(VOID)     { return HartCfgDb.HNtfyCfg; }
    inline VOID *GetHDynDvcPtr(VOID)      { return HartDevDb.HDynDvc; }
    inline VOID *GetHartVersionPtr(VOID)  { return &HartDevDb.m_ucHartVersion; }
#else
    VOID GetRawInput(VOID);
#endif // defined (IOMTYPE_UIO)
    VOID ProcessSlot(VOID);

#ifdef IOMTYPE_DISOE
    VOID InitializePvAuto();
    VOID ProcessPvChgDly(VOID);
    VOID ProcessLatchedTimer(VOID);
    VOID StorePvChgDlyPacket(BOOL PvState,UINT32 EvtTimeStmp,UINT16 SyncID);
    inline UINT8    GetDebounce(VOID){return Debounce;}
    inline EVTOPT   GetEvtOpt(VOID){ return  EvtOpt; }
    inline VOID     SetRawInput(BOOL a_bPvraw){ RawInput = a_bPvraw;}
    inline UINT8    GetPvChgDlyTimer(VOID){ return PvChgDlyTimer;}
    inline BOOL     GetbPvChgDlyEventSet(VOID){ return bPvChgDlyEventSet;}
    inline BOOL     GetLastPv(VOID){ return LastPv;}
    inline PVSOURCE GetPvSource(VOID){ return PvSource;}
    inline VOID     SetLastPv(BOOL CurPv){ LastPv = CurPv;}
    inline ONOFF    GetPvAuto(VOID){ return PvAuto;}
    inline VOID     CallPostDebounce(VOID){ PostDebounce(ChanNum);}
    inline VOID     CallPostPvChgDly(VOID){ PostPvChgDly(ChanNum);}
#endif
    inline BOOL     IsOwdSfSet(VOID)
    {
#if defined (IOMTYPE_UIO)
        UINT8 ucBitOffSet = 0x04;   // Open wire SF bit offset
#else
        UINT8 ucBitOffSet = 0x08;   // Open wire SF bit offset
#endif
        return (SlotSfBt&ucBitOffSet);
    }
#ifdef IOMTYPE_DISOE
    inline UINT32 GetRedSlotDelta(VOID) {return 0;}
    inline UINT32 GetRedSlotSize(VOID) {
        return ((UINT32)((UINT8 *)&PvChgDly - (UINT8 *)&PntType) + sizeof(PvChgDly));
    }
#elif defined (IOMTYPE_UIO)
    inline UINT32 GetRedSlotDelta(VOID) {
        return (sizeof(ufC1)+sizeof(ufC2)+sizeof(TvProc));
    }
    inline UINT32 GetRedSlotSize(VOID) {
        return ((UINT32)((UINT8 *)&TvProc - (UINT8 *)&PntType) + sizeof(TvProc));
    }
    
#elif defined (IOPTYPE_DI)    
    inline UINT32 GetRedSlotDelta(VOID) { return 0; }
    inline UINT32 GetRedSlotSize(VOID)    { return PMIO_SLOTDUMP_PARAMSIZE; }
#else    
    inline UINT32 GetRedSlotDelta(VOID) { return 0; }
    inline UINT32 GetRedSlotSize(VOID) {
        return ((UINT32)((UINT8 *)&LastPv - (UINT8 *)&PntType) + sizeof(LastPv));
    }
#endif

#if defined(IOPTYPE_DI)
    // for PAR#1-98BB9AN (DI24), PAR#1-987WTI3 (DI) fixing
    BOOL AlarmEvents(EVENTTYPE a_EventType);

    UINT8    *GetParamPtr(UINT8);
    inline VOID *GetPmioDumpParamPtr(VOID)  { return (VOID *)PmioDumpParamTbl; }
    inline UINT8 *GetRedSlotPointer(VOID) { return (UINT8 *)PmioDumpParamTbl; }
    //inline UINT8 *GetRedSlotPointer(VOID) { return (UINT8 *)&PntType; }
    inline UINT8 IsCheckPointParam(UINT8 ucParamId) 
      {
          UINT8 ucArrayIndex = 0;
          UINT8 ucChkPntIndex = 0;

          while (CheckPointVer2[ucArrayIndex])
          {            
              if (CheckPointVer2[ucArrayIndex] == ucParamId)
                  return (ucChkPntIndex + 1);
              else
                  ucChkPntIndex += GetParamSize(CheckPointVer2[ucArrayIndex]);

              ucArrayIndex++;
          }

          return PA_NULL;
      }
#else
    inline UINT8 *GetRedSlotPointer(VOID) {
        return (UINT8 *)&PntType;
    }

#endif
};

#endif
