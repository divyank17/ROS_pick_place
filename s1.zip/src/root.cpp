/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : root.cpp                                                    *
*    Description : Application startup code common to all IOMs.                *
*******************************************************************************/

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <_h_c_lib.h>
#include "boxslot.hpp"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern VOID main(VOID);
/*******************************************************************************
*                              FORWARD DECLARATIONS                            *
*******************************************************************************/
VOID AppResetISR(VOID);
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef VOID (* INTRPTROUTINE)(VOID); // Application EVT table function type.
typedef VOID (* DTCINTROUTINE)(VOID); // Application DTC table function type.
/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/
NANINIT  NaNInit;  // For initializing NaN value.
#if defined(IOMTYPE_PI)
DNANINIT DNaNInit; // For initializing double NaN value.
#endif
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#pragma stacksize STACK_SIZE // Instruct linker to create a stack section.
// This table is used by _INITSCT to initialize values of RAM resident 
// variables that has specific initial values - static and global variables. 
#pragma section $DSEC
static const struct {
    CHAR *cpROMStart; // Start address of the initialized data section in ROM.
    CHAR *cpROMEnd;   // End address of the initialized data section in ROM.
    CHAR *cpRAMStart; // Start address of the initialized data section in RAM.
} INITIALIZED_DATA_TABLE = {(CHAR *)__sectop("D"),
                            (CHAR *)__secend("D"),
                            (CHAR *)__sectop("R")};
#pragma section

// This table is used by _INITSCT to zero out the rest of the RAM,
// except the area defined by other sections like REBOOT and STACK.
#pragma section $BSEC
static const struct {
    CHAR *cpStart;   // Start address of non-initialized data section in RAM.
    CHAR *cpEnd;     // End address of non-initialized data section in RAM.
} UNINITIALIZED_DATA_TABLE = { (CHAR *)__sectop("B"),(CHAR *)__secend("B") };
#pragma section

// This table is used by the boot firmware to call the appropriate interrupt
// sub-routine. All interrupt sources are first serviced by the boot firmware.
#pragma section APPEVT_SECTION
const INTRPTROUTINE tblIntHandlers[] =  {   //  Initialize interrupt handlers 
    AppResetISR,                            //  vector 0 MCU reset 
    NULL,                                   //  vector 1 Reserved
    NULL,                                   //  vector 2 Reserved
    NULL,                                   //  vector 3 Reserved
    NULL,                                   //  vector 4 Reserved
    NULL,                                   //  vector 5 Trace
    NULL,                                   //  vector 6 Reserved
    clsBoxSlot::NMInterruptHandler,         //  vector 7 NMI
    NULL,                                   //  vector 8 User breakpoint trap
    NULL,                                   //  vector 9 User breakpoint trap
    NULL,                                   //  vector 10 User breakpoint trap
    NULL,                                   //  vector 11 User breakpoint trap
    NULL,                                   //  vector 12 Reserved
    NULL,                                   //  vector 13 Reserved
    NULL,                                   //  vector 14 Reserved
    NULL,                                   //  vector 15 Reserved
    clsIol::ISR_GHO,                        //  vector 16 External trap IRQ0
    #ifdef IOMTYPE_SVP
    clsSvpBoxSlot::IRQ1InterruptHandler,    //  vector 17 External trap IRQ1
    #elif(defined(IOMTYPE_SP))
    clsSpBoxSlot::IRQ1InterruptHandler,     //  vector 17 External trap IRQ1
    #else
    clsBoxSlot::IRQ1InterruptHandler,       //  vector 17 External trap IRQ1
    #endif
    NULL,                                   //  vector 18 External trap IRQ2
    #if (defined(IOMTYPE_DO))
    clsDoBoxSlot::IRQ3InterruptHandler,     //  vector 19 External trap IRQ3
    #elif defined(IOMTYPE_PI)
    clsPiBoxSlot::FpgaInterruptHandler,     //  vector 19 External trap IRQ3
    #elif defined(IOMTYPE_UIO)
    clsUioBoxSlot::IRQ3InterruptHandler,    //  vector 19 External trap IRQ3 (port pin 6.7, FPGA_IRQ)
    #else 
    NULL,                                   //  vector 19 External trap IRQ3
    #endif
    #ifdef IOMTYPE_SVP
    clsSvpBoxSlot::IRQ4InterruptHandler,    //  vector 20 External trap IRQ4
    #elif (defined(IOMTYPE_SP))
    clsSpBoxSlot::IRQ4InterruptHandler,     //  vector 20 External trap IRQ4
    #else
    NULL,                                   //  vector 20 External trap IRQ4
    #endif
    NULL,                                   //  vector 21 External trap IRQ5
    NULL,                                   //  vector 22 External trap IRQ6
    NULL,                                   //  vector 23 External trap IRQ7
    NULL,                                   //  vector 24 SWDTEND DTC
    NULL,                                   //  vector 25 WOVI 
    NULL,                                   //  vector 26 Reserved 
    NULL,                                   //  vector 27 Reserved
    NULL,                                   //  vector 28 ADI
    NULL,                                   //  vector 29 Reserved
    NULL,                                   //  vector 30 Reserved
    NULL,                                   //  vector 31 Reserved
    #ifdef IOMTYPE_AIH
    clsAihBoxSlot::PpxInterruptHandler,     //  vector 32 TGI0A TPU0
    #elif (defined(IOMTYPE_LLMUX))
    clsLLBoxSlot::PpxInterruptHandler,      //  vector 32 TGI0A TPU0
    #elif (defined(IOMTYPE_DISOE) || defined(IOMTYPE_DI))
    clsDiBoxSlot::SOEInterruptHandler,      //  vector 32 TGI0A TPU0
    #elif(defined(IOMTYPE_SVP))
    clsSvpBoxSlot::ShramReadInterruptHandler, //  vector 32 TGI0A TPU0
    #elif(defined(IOMTYPE_SP))
    clsSpBoxSlot::PpxInterruptHandler,      //  vector 32 TGI0A TPU0
    #else
    NULL,                                   //  vector 32 TGI0A TPU0
    #endif
    NULL,                                   //  vector 33 TGI0B TPU0
    NULL,                                   //  vector 34 TGI0C TPU0
    NULL,                                   //  vector 35 TGI0D TPU0
    NULL,                                   //  vector 36 TCI0V TPU0
    NULL,                                   //  vector 37 Reserved
    NULL,                                   //  vector 38 Reserved
    NULL,                                   //  vector 39 Reserved
    NULL,                                   //  vector 40 TGI1A TPU1
    NULL,                                   //  vector 41 TGI1B TPU1
    NULL,                                   //  vector 42 TCI1V TPU1
    NULL,                                   //  vector 43 TCI1U TPU1
    #ifdef IOMTYPE_DI
    clsDiBoxSlot::DiHvInterruptHandler,     //  vector 44 TGI2A TPU2
    #elif (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_UIO))
    clsHartModem::HartModemHeartbeat,
    #else
    NULL,                                   //  vector 44 TGI2A TPU2
    #endif
    NULL,                                   //  vector 45 TGI2B TPU2
    NULL,                                   //  vector 46 TCI2V TPU2
    NULL,                                   //  vector 47 TCI2U TPU2
    clsBoxSlot::BlinkLEDInterruptHandler,   //  vector 48 TGI3A TPU3
    NULL,                                   //  vector 49 TGI3B TPU3
    NULL,                                   //  vector 50 TGI3C TPU3
    NULL,                                   //  vector 51 TGI3D TPU3
    NULL,                                   //  vector 52 TCI3V TPU3
    NULL,                                   //  vector 53 Reserved
    NULL,                                   //  vector 54 Reserved
    NULL,                                   //  vector 55 Reserved
    NULL,                                   //  vector 56 TGI4A TPU4
    clsIol::ISR_SilenceTimer,               //  vector 57 TGI4B TPU4
    NULL,                                   //  vector 58 TCI4V TPU4
    NULL,                                   //  vector 59 TCI4U TPU4
    clsTaskScheduler::STCInterruptHandler,  //  vector 60 TGI5A TPU5
    NULL,                                   //  vector 61 TGI5B TPU5
    NULL,                                   //  vector 62 TCI5V TPU5
    NULL,                                   //  vector 63 TCI5U TPU5
    NULL,                                   //  vector 64 CMIA0 8Bit0
    NULL,                                   //  vector 65 CMIB0 8Bit0
    NULL,                                   //  vector 66 OVI0 8Bit0
    NULL,                                   //  vector 67 Reserved
    NULL,                                   //  vector 68 CMIA1 8Bit1
    NULL,                                   //  vector 69 CMIB1 8Bit1
    NULL,                                   //  vector 70 OVI1 8Bit1
    NULL,                                   //  vector 71 Reserved
    NULL,                                   //  vector 72 Reserved 
    NULL,                                   //  vector 73 Reserved 
    NULL,                                   //  vector 74 Reserved 
    NULL,                                   //  vector 75 Reserved 
    NULL,                                   //  vector 76 Reserved
    NULL,                                   //  vector 77 Reserved
    NULL,                                   //  vector 78 Reserved
    NULL,                                   //  vector 79 Reserved
    #if !(LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
    clsIol::ISR_Rcvr_Error,                 //  vector 80 ERI0 SCI0  
    clsIol::ISR_Rcvr,                       //  vector 81 RXI0 SCI0
    clsIol::ISR_Xmit,                       //  vector 82 TXI0 SCI0
    clsIol::ISR_XmitEnd,                    //  vector 83 TEI0 SCI0
    #else
    NULL,                                   //  vector 80 ERI0 SCI0  
    NULL,                                   //  vector 81 RXI0 SCI0
    NULL,                                   //  vector 82 TXI0 SCI0
    NULL,                                   //  vector 83 TEI0 SCI0   
    #endif
    NULL,                                   //  vector 84 ERI1 SCI1
    NULL,                                   //  vector 85 RXI1 SCI1
    #ifdef DEBUG
    clsDebugPort::SciOneTxiIsr,             //  vector 86 TXI1 SCI1
    clsDebugPort::SciOneTriIsr,             //  vector 87 TEI1 SCI1
    #else
    NULL,                                   //  vector 86 TXI1 SCI1
    NULL,                                   //  vector 87 TEI1 SCI1
    #endif
    #if (LOWCOST || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
    clsIol::ISR_Rcvr_Error,                 //  vector 88 ERI0 SCI2  
    clsIol::ISR_Rcvr,                       //  vector 89 RXI0 SCI2
    clsIol::ISR_Xmit,                       //  vector 90 TXI0 SCI2
    clsIol::ISR_XmitEnd                     //  vector 91 TEI0 SCI2
    #elif (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
    clsIol::ISR_SCI2_Rcvr_Error,            //  vector 88 ERI0 SCI2  
    clsIol::ISR_SCI2_Rcvr,                  //  vector 89 RXI0 SCI2
    clsIol::ISR_SCI2_Xmit,                  //  vector 90 TXI0 SCI2
    clsIol::ISR_SCI2_XmitEnd                //  vector 91 TEI0 SCI2
    #else
    NULL,                                   // vector 88 Reserved
    NULL,                                   // vector 89 Reserved 
    NULL,                                   // vector 90 Reserved
    NULL                                    // vector 91 Reserved
    #endif
};
#pragma section 

#pragma section HEADER_SECTION
// This section is located at 0x4F0 to 0x4FF by the makefile linker options 
// and is used by the ADDRC application to inject header and CRC information
// to the downloadable image. Location of this section has dependency with
// many componenets - BOOT and APP firmware (makefile, commonelectronics.h
// constants), ADDCRC tool and IOLIM block extension DLL. A dummy table is 
// defined here so that the section allocation appears in the map file.
const UINT32 tblImageHeader[4] = { 0x01234567,0x89ABCDEF,0x01234567,0x89ABCDEF };
#pragma section 

#if(HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
//need to be  updated based on CPLD - hard coded to false for now
BOOL IsFpgaS2;
VOID CheckCPLD(VOID);
#endif

/*******************************************************************************
*                                 HardwareInit                                 *
*                                 ============                                 *
* PURPOSE   : Initialize common hardware resources.                            *
* ARGUMENTS : None.                                                            *
* RETURN    : None.                                                            *
* NOTES     : Called from AppResetISR during application startup.              *
*******************************************************************************/
static VOID HardwareInit(VOID)
{
    set_imask_exr(LVLPRI_HIGHEST);      // Disable all interrupts

#if defined(IOMTYPE_PI)
    // modify CS2 to have 1 wait state in App code
    P_BSC.WCR.BIT.W2 = 1;
#elif defined(IOMTYPE_UIO)
    //set CS2 have 0 wait states in FPGA App mode.
    P_BSC.WCR.BIT.W2 = 0;
#endif

    // Check for reboot and set in the static boxslot member.
#if !AIAO
    RDBK_SEL = RDBK_BANK7;
#endif
    (RIP_n) ? clsBoxSlot::SetIomRebooted(FALSE)
            : clsBoxSlot::SetIomRebooted(TRUE);

#ifdef DEBUG
    // Do not clear the RIP latch if reboot test is going on.
    extern CHAR g_cRebootTestString[];
    if (strcmp(g_cRebootTestString,"reboot") == FALSE) {
#endif //DEBUG
        CLR_RIP_n = 0; // Clear RIP and DIP latches.
#if HEK
        SET_DIP   = 0; // HEK does not Clear DIP latches on CLR_RIP_n.
#endif
        CLR_RIP_n = 1; // Arm RIP latch again.
#ifdef DEBUG
    }
#endif //DEBUG

    // Initialize SCI1 for printing power-on-self-test results.
    MSTPCR_SCI1 = 0;  // Clear module stop bit for SCI1
    SCIC1_TE    = 0;  // Disable transmitter
    SCIC1_RE    = 0;  // Disable receiver
    SCIC1_CKE   = 0;  // Setup internal clock source for SCI1
    SCIC1_SMR   = 0;  // Async,8bit data,no parity,1 stop bit,no multi,use CLK
    SCIC1_BRR   = 19; // For 24 MHz crystal, 38.4 kbps
    
#if LOWCOST
#ifdef IOMTYPE_AIH
    // Initialize 8bit Timers. Use as a 16 bit Timer (TMR0 + TMR1)
    P_MSTPCR.BIT.TMR = 0;       //  Enable 8-Bit Timer (MSTP12 OFF)
    TMR_TCNT  = 0;              //  Timer Counter
    TMR0_TCR   = 0;             //  Timer Control Register
    TMR0_TCSR  = 0;             //  Timer Control/Status Register
    TMR0_TCORA = 0;             //  Timer Constant Register A
    TMR0_TCORB = 0;             //  Timer Constant Register B
    TMR1_TCR   = 0;             //  Timer Control Register
    TMR1_TCSR  = 0;             //  Timer Control/Status Register
    TMR1_TCORA = 0;             //  Timer Constant Register A
    TMR1_TCORB = 0;             //  Timer Constant Register B

    TMR0_TCR   = TMR_OVERFLOW;  //  TCNT0 counts at TCNT1 overflow
    TMR1_TCR   = TMR_PHI_8;     //  TCNT1 counts at PHI/8
#endif
#endif
}
#if !defined(IOMTYPE_SVP) && !defined(IOMTYPE_SP)
/*******************************************************************************
*                                  PrintStr                                    *
*                                  ========                                    *
* PURPOSE   : Print power-on-self-test results to the debug port.              *
* ARGUMENTS : Pointer to the string to be printed.                             *
* RETURN    : None.                                                            *
* NOTES     : This print results are used by factory test engineers.           *
*******************************************************************************/
#ifndef DEBUG
#if defined(PMIO_RLS)
VOID PrintStr(const CHAR *a_cstrPrint) 
#else
static VOID PrintStr(const CHAR *a_cstrPrint) 
#endif
{
    SCIC1_TE = ENABLE;  // enable SCI1 transmitter
    SCIC1_TEND = 0;

    while (*a_cstrPrint)
    {
        SCIC1_TDR = *a_cstrPrint++;
        SCIC1_TDRE = 0; //Clear the empty flag. 
        while (!SCIC1_TDRE);//Waiting till TDR is empty
    }
    
    while (!SCIC1_TEND);// wait till last char tx is completed.
    SCIC1_TE = DISABLE;  // disable SCI1 transmitter
}
#endif
/*******************************************************************************
*                             StartupDiagnostics                               *
*                             ==================                               *
* PURPOSE   : Power-on-self test diagnostics.                                  *
* ARGUMENTS : None.                                                            *
* RETURN    : None.                                                            *
* NOTES     : This routine is called from the AppResetISR at startup.          *
*             Initially, module number and DPA are pinned out in binary format.*
*             Diagnostics routines are then called and at end of each routine, *
*             Txxx number is printed out to indicate the test has passed.      *
*******************************************************************************/
static VOID StartupDiagnostics(VOID) 
{
#ifndef DEBUG
    UINT8 Mask = 0x80;
    
    #if !AIAO
    RDBK_SEL         = RDBK_MODNUM;
    #endif // !AIAO
#if defined(IOPTYPE_SCIOM)
    UINT8 ModlId    = MODNUM & MODNUMBITS;
#else
    UINT8 ModlId    = MODNUM;
#endif
  
    // Printing the module number
    PrintStr("\n\rMODULE NUMBER:");
    while(Mask) {
        if (Mask & ModlId) {
            PrintStr("1");
        }
        else {
            PrintStr("0");
        }
        Mask >>= 1;
    }

    // Printing the DPA
    #if !AIAO
    RDBK_SEL = RDBK_IOTA;
    #endif // !AIAO
#if defined(IOPTYPE_SCIOM)
    ModlId = ((BOTTOM) ? 255 : 256) - 2 * ModlId;
#else        
    PrintStr("\n\r              PFFFSSSS");
    PrintStr("\n\rP-PARITY");
    PrintStr("\n\rF-FILE");
    PrintStr("\n\rS-SLOT\n\r");
    ModlId = isOddParity(MODNUM >> 4) ? (0x80 | MODNUM) : 0;
#endif
    Mask = 0x80;
    PrintStr("\n\rDPA          :");
    while(Mask) {
        if (Mask & ModlId) {
            PrintStr("1");
        }
        else {
            PrintStr("0");
        }
        Mask >>= 1;
    }
#endif

    while(RETURNSTATUS_COMPLETE != CPUDiagRoutine());
#ifndef DEBUG
    PrintStr("\n\rT001");
#endif
    
    while (RETURNSTATUS_COMPLETE != RAMContentsDiagRoutine());
#ifndef DEBUG
    PrintStr("\n\rT002");
#endif
    
    while (RETURNSTATUS_COMPLETE != AddressDiagRoutine()); 
#ifndef DEBUG
    PrintStr("\n\rT003");
#endif
    
#ifndef DEBUG
    while (RETURNSTATUS_COMPLETE != FlashContentsDiagRoutine()); 
    PrintStr("\n\rT004");

    // Print T999 to mark self test complete
    PrintStr("\n\rT999");
#endif

    TraceLog.AddToTrace(TRACEID_GENERIC,bcStartupDiagDone);
}
#endif
/*******************************************************************************
*                                   AppResetISR                                *
*                                   ===========                                *
* PURPOSE   : Start application image.                                         *
* ARGUMENTS : None.                                                            *
* RETURN    : None.                                                            *
* NOTES     : 1) Reset interrupt is first serviced by the boot firmware.       *
*             2) Boot firmware invokes this function if the application        *
*                fimrare was found to be loaded and intact.                    *
*             3) This function is never supposed to return as the application  *
*                main function never returns.                                  *
*             4) Initializing the stack memory should not be moved out of this *
*                function. Stack initialization is done when the application   *
*                image is not using any stack.                                 *
*******************************************************************************/
VOID AppResetISR(VOID) 
{
    // Reference INITIALIZED_DATA_TABLE and UNINITIALIZED_DATA_TABLE so that 
    // these static constants will not be optimized by the compiler becuase of 
    // no reference. 
    if ((UNINITIALIZED_DATA_TABLE.cpStart == UNINITIALIZED_DATA_TABLE.cpEnd) ||
       (INITIALIZED_DATA_TABLE.cpROMStart == INITIALIZED_DATA_TABLE.cpROMEnd)){
        HardFail(HF_INVPROGRAMEXEC,ROOT_CPP,__LINE__);
    }

    // Reference tblIntHandlers and tblImageHeader so that these static 
    // constants will not be optimized by the compiler because of no reference.
    if ((tblIntHandlers[0] == NULL ) || (tblImageHeader[0] == 0)) {
        HardFail(HF_INVPROGRAMEXEC,ROOT_CPP,__LINE__);
    }

    HardwareInit();         

    _INITSCT();   // Initialize RAM data sections - defined in runtime library
    
    // _INITSCT() clears the "IsFpgaS2" flag during RAM data section init.
    #if(HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
    CheckCPLD();
    #endif
    
    _CALL_INIT(); // Call global object constructors - defined in runtime lib

    TraceLog.AddToTrace(TRACEID_GENERIC,bcAppStart);
    (BOX->GetIomRebooted()) ? TraceLog.AddToTrace(TRACEID_GENERIC,bcReboot)
                            : TraceLog.AddToTrace(TRACEID_GENERIC,bcPowerOn);
#if defined (IOMTYPE_SVP) || defined(IOMTYPE_SP)
    TCStartupDiagnostics();
#else
    StartupDiagnostics();
#endif
    
    // Fill stack memory with 0xFF for monitoring maximum stack usage.
    volatile UINT8 *ucpStack = (volatile UINT8 *)(STACK_TOP + 1);
    while (ucpStack <= (volatile UINT8 *)STACK_BOTTOM) *ucpStack++ = 0xFF;
    #ifdef IOMTYPE_DO
    // Move the state of the outputs to just below the stack high water point
    // The boxslot constructor will repair this location after it gets its info
    *(STACK_TOP + STACK_SFLIMIT/4) = *STACK_TOP;
    #endif // IOMTYPE_DO
    // Load the end of stack with the test pattern for checking stack overrun.
    (*(STACK_TOP)) = STACKTESTPATTERN;
    TraceLog.AddToTrace(TRACEID_GENERIC,bcStackInit);

    set_imask_exr(0); // Enable all interrupts
    NaNInit.ulDword = SIGNL_NAN; // Initialize NaN value
    #if defined(IOMTYPE_PI)
    DNaNInit.uqWord.ulDwordHi = SIGNL_DNAN_HI; // Initialize double NaN value
    DNaNInit.uqWord.ulDwordLo = SIGNL_DNAN_LO;
    #endif        

    main();  // Launch application.

    // Pass execution to TaskScheduler.
    TaskScheduler.ExecuteTaskScheduler();

    // Execution is never expected to reach here.
    HardFail(HF_INVPROGRAMEXEC,ROOT_CPP,__LINE__);
    _CALL_END(); 
}

#if(HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
VOID CheckCPLD(VOID)
{
    UINT16 uiCpldRev;
    
    // Configure PORT A lower nibble as output for Address bus 16 - 19
    P_PA.DDR = 0x0F;
    // Configure PORT B as output for Address bus  8 - 15
    P_PB.DDR = 0xFF;
    // Configure PORT C as output for Address bus  0 - 7
    P_PC.DDR = 0xFF;
    // Configure PORT G as output for CPLD chip select
    P_PG.DDR = 0x1F;
    // CPLD chip select
    P_PG.DR.BYTE = 0x1C;

    uiCpldRev = ((UINT16)((UINT16)CPLD_REVLETTER << 8) | CPLD_REVNUMBER);
    
    if(0xFFFF == uiCpldRev)
    {
        IsFpgaS2 = FALSE;
    }
    else
    {
        IsFpgaS2 = TRUE;
    }
}
#endif
