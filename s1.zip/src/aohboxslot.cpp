/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohboxslot.cpp                                              *
*    Description : Class clsclsAohBoxSlot definition.                          *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aohmain.h"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;
extern BOOL bSwitchDiagRunning;
// added this to fix PAR# 1-E35JRDA (OP drop time more than specified (20ms) during failover with OP Fail (during SEC comes from SFAIL/SYNCD to OK/SYNCD))
extern UINT16 uiFtaReturnTimeout;
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_OUTPUTFL,
    SF_HARTCHANFAIL,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN
};

const UINT8 clsAohBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_HAUTODETBLND,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};

#if !defined(IOPTYPE_AO16)
const UINT8 clsAohBoxSlot::CheckPointVer2[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_HAUTODETBLND,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};
const CHECKPOINT_VER_TABLE clsAohBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 19 },
    { CheckPointVer2, 19 }
};
#else
// PMIO AO16 Redesign param tables
const UINT8 clsAohBoxSlot::CheckPointVer2[] = {
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};
const CHECKPOINT_VER_TABLE clsAohBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 19 },
    { CheckPointVer2, 2 }
};

// PMIO AO16 BOX DUMP PARAM
const UINT8  clsAohBoxSlot::PmioDumpParamTbl[] = {
    PARAMID_MODSTAT1,
    PARAMID_DBVALID,
    PARAMID_FL_UNPWRD_BX,
    0 // Terminator
};

#if defined(HART_SUPPORT)
const UINT8 clsBoxSlot::IopDesc[] = "AO16H   ";
#else
const UINT8 clsBoxSlot::IopDesc[] = "AO 16   ";
#endif
#endif

UINT8 clsAohBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

const UINT8 clsAohBoxSlot::RedParams[] = {
    PARAMID_DBVALID,
    PARAMID_IOLDEVTYPE,
    PARAMID_MODLTYPE,
#if defined(IOPTYPE_AO16)  
    PARAMID_FL_UNPWRD_BX,
    PARAMID_SFACTNTBL,
#else
    PARAMID_HAUTODETBLND,
#endif    
    0 // Terminator
};

const BOXPARAMINFO clsAohBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 00
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 01
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 02
    DT_BLIND, 3, AT_PSET, ALCK_VIEW, 0, 0, GetModStatTypePtr, FALSE,                       // 03 ModStatType
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 04
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 05
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 06
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 07
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 08
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 09
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 10
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 11
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 12
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 13
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 14
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 15
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 16
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 17
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 18
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 19
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 20
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 21
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 22
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 23
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 24
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 25
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 26
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 27
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 28
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 29
    DT_BLIND, 16, AT_MBYTE, ALCK_IUSER, 0, 0, GetHAutoDetPtr, TRUE,                        // 30 HAUTODETBLND
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 31
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 32
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 33
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 34
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, 0, 0, GetSlotSfBitsPtr, FALSE,                      // 35 SlotSfBits
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 36
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, 0, 0, GetMapSlotInFailPtr, FALSE,                   // 37 MapSlotInFail
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetChnErrAPtr, FALSE,                          // 38 ChnErrA
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetChnErrBPtr, FALSE,                          // 39 ChnErrB
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetChnSilAPtr, FALSE,                          // 40 ChnSilA
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetChnSilBPtr, FALSE,                          // 41 ChnSilB
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 42
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, 0, 0, GetHwInfoPtr, FALSE,                          // 43 HwInfo
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetBootBuildNoPtr, FALSE,                      // 44 BootBuildNo
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetBootSwRevCodePtr, FALSE,                    // 45 BootSwRevCode
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 46
    DT_BLIND, 14, AT_PSET, ALCK_VIEW, 0, 0, GetSup300Ptr, FALSE,                           // 47 Sup300
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetAppBuildNoPtr, FALSE,                       // 48 AppBuildNo
#if defined(IOPTYPE_AO16)
    DT_BLIND, 22, AT_PSET, ALCK_VIEW, 0, 0, GetIomDtlPtr, FALSE,                           // 49 IOMDTL
    DT_BLIND, 10, AT_PSET, ALCK_VIEW, 0, 0, GetIolSupPtr, FALSE,                           // 50 IOL_SUP
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, 0, 0, GetPmBxSfBitsPtr, FALSE,                      // 51 BxSfBits - for redesign PMIO AO16 (added to resolve, PAR# 1-7L6ZU89)
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 49
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 50   
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, 0, 0, GetBoxSfBitsPtr, FALSE,                       // 51 BoxSfBits
#endif    
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, 0, 0, GetBoxSfLrsPtr, FALSE,                        // 52 BoxSfLrs
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetCircListStPtr, FALSE,                       // 53 CircListSt
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetCommErrPtr, FALSE,                          // 54 CommErr
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetCommStatPtr, FALSE,                         // 55 CommStat
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetDpaPtr, FALSE,                              // 56 Dpa
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetDsaPtr, FALSE,                              // 57 Dsa
    DT_UINT16, 2, AT_MBYTE, ALCK_VIEW, 0, 0, GetEvntAppPtrPtr, FALSE,                      // 58 EvntAppPtr
    DT_UINT16, 2, AT_MBYTE, ALCK_VIEW, 0, 0, GetEvntRemPtrPtr, FALSE,                      // 59 EvntRemPtr
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetBaPtr, FALSE,                               // 60 Ba
    DT_BLIND, 4, AT_MBYTE, ALCK_IUSER, PreSyncVer, 0, GetSyncVerPtr, FALSE,                // 61 SyncVer
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetFailCodePtr, FALSE,                         // 62 FailCode
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetHwRevCodePtr, FALSE,                        // 63 HwRevCode
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetIolDevTypePtr, TRUE,                        // 64 IolDevType
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetLastFailPtr, FALSE,                          // 65 LastFail
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetMesNoPtr, FALSE,                            // 66 MesNo
    DT_UINT8, 1, AT_SBYTE, ALCK_IUSER, PreModStat1, PostModStat1, GetModStat1Ptr, TRUE,    // 67 ModStat1
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetModStat2Ptr, FALSE,                         // 68 ModStat2
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetModlTypePtr, TRUE,                           // 69 ModlType
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetNthPtr, FALSE,                              // 70 Nth   
#if defined(IOPTYPE_AO16)
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetSuperCtrlPtr, FALSE,                        // 71 SUPER_CTRL        
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 71
#endif
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetAppSwRevCodePtr, FALSE,                     // 72 SwRevCode
#if defined(IOPTYPE_AO16)
    DT_UINT16, 2, AT_MBYTE, ALCK_IUSER, 0, 0, GetToknStallPtr, FALSE,                      // 73 TOKN_STALL
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 73
#endif
    DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, 0, 0, GetTstFunctTimePtr, FALSE,                     // 74 TstFunct
    DT_BLIND, 80, AT_PSET, ALCK_VIEW, 0, 0, GetSfInfo300Ptr, FALSE,                        // 75 SfInfo300
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetWithBiasPtr, FALSE,                          // 76 WithBias
    DT_BLIND, 2, AT_MBYTE, ALCK_IUSER, PreRedData, PostRedData, GetRedDataPtr, FALSE,      // 77 RedData
    DT_BOOL, 1, AT_SBYTE, ALCK_IUSER, 0, 0, GetDbValidPtr, TRUE,                           // 78 DbValid
    DT_BLIND, 32, AT_MBYTE, ALCK_IUSER, 0, PostSfActionTbl, GetSfActionTblPtr, FALSE,      // 79 SfActionTbl
    DT_BOOL, 1, AT_SBYTE, ALCK_EPB, PreCalibAll, PostCalibAll, GetCalibAllPtr, FALSE,      // 80 CalibAll
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 81
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 82
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 83
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 84
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 85
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 86
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 87
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 88
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 89
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 90
#if defined(IOPTYPE_AO16)
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, 0, PostFl_UnPwrd_Bx, GetFl_UnPwrd_BxPtr, TRUE,         // 91 FL_UNPWRD_BX
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 91
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 92
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 93
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 94
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 95
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 96
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 97
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 98
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 99
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 100
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 101
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 102
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 103
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 104
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 105
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 106
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 107
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 108
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 109
    DT_BOOL, 1, AT_SBYTE, ALCK_ENGR, PreHAutoDet, PostHAutoDet, GetHAutoDetPtr, TRUE,      // 110 HAutoDet
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 111
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 112
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetLpBkStatPtr, FALSE,                         // 113
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 114
#if defined(IOPTYPE_AO16)
    DT_STRG, 8, AT_MBYTE, ALCK_VIEW, 0, 0, GetIopDescPtr, FALSE,                           // 115 IOPDESC (for redesign PMIO)
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, 0, FALSE,                                     // 115
#endif
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetMaxSlotsPtr, FALSE,                         // 116 MaxSlots
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 117
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 118
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 119
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 120
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, 0, 0, GetHGCfgChgCntPtr, FALSE,                     // 121 HGCFGCHG
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, 0, 0, GetHGChngFlPtr, FALSE,                        // 122 HGChngFl
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 123
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, 0, 0, GetHCuAvailPtr, FALSE,                       // 124 HCuAvail
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 125
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 126
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 127
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 128
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 129
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 130
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 131
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 132
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 133
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 134
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, 0, 0, GetHGDevStPtr, FALSE,                         // 135 HGDevSt
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 136
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 137
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 138
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 139
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 140
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 141
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 142
    DT_BLIND, 19, AT_PSET, ALCK_VIEW, PreCheckPoint, 0, GetCheckPointPtr, TRUE,            // 143 CheckPoint
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 144
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 145
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 146
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 147
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 148
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 149
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 150
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 151
    DT_BLIND, 68, AT_MBYTE, ALCK_VIEW, 0, 0, GetOpScanRecPtr, FALSE,                       // 152 OpScanRec
    DT_BOOL, 1, AT_SBYTE, ALCK_PBD, PreHADCEnable, PostHADCEnable, GetHADCEnablePtr, FALSE,// 153 HADCEnable
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetHADCStatusPtr, FALSE,                       // 154 HADCStatus
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 155
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 156
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 157
    DT_BLIND, 34, AT_MBYTE, ALCK_VIEW, 0, 0, GetCheckSumPtr, FALSE,                        // 158 CheckSum
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, 0, 0, GetCpuFreeAvgPtr, FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, 0, 0, GetCpuFreeMinPtr, FALSE,                     // 160 CPUFreeMin
    DT_BOOL, 1, AT_SBYTE, ALCK_OPER, PreStatReset, PostStatReset, GetStatResetPtr, FALSE,  // 161 StatReset
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 162
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 163
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 164
    DT_BLIND, 100, AT_MBYTE, ALCK_VIEW, 0, 0, GetTracelogPtr, FALSE,                       // 165 TraceLog
    DT_BLIND, 5, AT_MBYTE, ALCK_VIEW, 0, 0, GetTraceLogInfoPtr, FALSE,                     // 166 TraceLogInfo
    DT_UINT16, 2, AT_MBYTE, ALCK_OPER, 0, 0, GetTracelevelPtr, FALSE,                      // 167 Tracelevel
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 168
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 169
    DT_UINT8, 1, AT_SBYTE, ALCK_OPER, PreCPLDRegData, PostCPLDRegData, GetCPLDRegDataPtr, FALSE,// 170 CPLDRegData
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 171
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 172
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 173
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 174
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 175
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 176
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 177
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 178
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 179
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 180
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 181
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 182
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 183
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 184
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 185
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 186
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 187
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 188
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 189
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 190
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 191
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 192
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 193
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 194
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 195
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 196
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 197
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 198
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 199
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 200
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 201
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 202
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 203
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 204
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 205
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 206
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 207
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 208
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 209
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 210
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 211
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 212
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 213
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 214
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 215
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 216
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 217
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 218
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 219
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 220
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 221
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 222
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 223
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 224
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 225
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 226
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 227
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 228
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 229
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 230
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 231
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 232
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 233
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 234
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 235
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 236
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 237
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 238
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 239
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 240
    DT_BOOL, 1, AT_SBYTE, ALCK_OPER, 0, 0, GetCtlTogPtr, FALSE,                            // 241 CtlTog
    DT_BOOL, 1, AT_SBYTE, ALCK_OPER, 0, 0, GetComTogPtr, FALSE,                            // 242 ComTog
    DT_UINT8, 1, AT_SBYTE, ALCK_IUSER, 0, 0, GetBoxChkpntVersionPtr, TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 244
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 245
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 246
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 247
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 248
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 249
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 250    
#if defined(IOPTYPE_AO16)
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, 0, 0, GetBoxSfBitsPtr, FALSE,                       // 251 BoxSfBits - for redesign PMIO AO16
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetSltCntrPtr, FALSE,                          // 252 SLT_CNTR
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 251
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 252
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 253
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE,                                        // 254
    DT_NONE, 0, AT_NONE, ALCK_VIEW, 0, 0, 0, FALSE                                         // 255
};
/*******************************************************************************
*                         clsAohBoxSlot::clsAohBoxSlot                         *
*                         ============================                         *
* PURPOSE:    Constructor of clsAohBoxSlot Class. Initializes clsAohBoxSlot    *
*             class members.                                                   *                                                                 
* ARGUMENTS:  a_MdType    -   Module type                                      *
* RETURN:     NONE                                                             *
* NOTES:      This constructor will internally invokes clsBoxSlot class        *
*             constructor.                                                     *
*******************************************************************************/
clsAohBoxSlot::clsAohBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType, MAXSLOTS) 
{
    CalibAll        = FALSE;
    CalibrationGood = FALSE;
    FieldCalibOn    = FALSE;
    NormalLpbkChannel = 1;
    RetryLpbkChannel  = 14;

#if defined(IOPTYPE_AO16)
    //PMIO AO16 Redesign non avail param initialization.
    Fl_UnPwrd_Bx = FL_UNPWRD_UNPOWER;
    SltCntr = 0;
    // PAR #1-E35JRCL & Flooding alarms
    LastSfCode = SF_UNKNOWN;
    SfCodeLrs = SF_UNKNOWN;
    ucOutputFailCounter = 0;
#endif

    for (UINT8 ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
        OpScanRec.Op[ucSlotNum] = OP_LOLIMIT;
        HAutoDet[ucSlotNum] = FALSE;
        HADCEnable[ucSlotNum] = FALSE;
        HADCStatus[ucSlotNum] = HART_DATA_UNKNOWN;
        HGChngFl[ucSlotNum] = 0;
    }
    OpScanRec.InitReq  = 0;
    OpScanRec.StdbyMan = 0;
    HCuAvail = 100.0;

    HwInfo.ProductType = PRODTYPE_AO;
    //HwInfo.ProductCode = PRODUCT_CODE;    // read from EEPROM. Currently the value is 0xffff

    switch(a_MdType) {
    case MODLTYPE_AOH:
        HwInfo.ProductCode = PRODCODE_AO_HART;
        break;
    case MODLTYPE_AO:
#if HEK
        HwInfo.ProductCode = PRODCODE_AO;
#else
        HwInfo.ProductCode = PRODCODE_AO_LC;
#endif
        break;
    case MODLTYPE_AO_S8:
#if LOWCOST
        HwInfo.ProductCode = PRODCODE_AO_LC_S8;
        break;
#endif
        // Series C Depop AO is not planned in Series 8,
        // Hard fail module if configuration is done
    case MODLTYPE_AOH_S8:
        // Series C HART AO is not planned in Series 8,
        // Hard fail module if configuration is done
    default:
        HardFail(HF_BADPROGRAMJUMP,AOHBOXSLOT_CPP,__LINE__);
    }

    //Both the Modules will come as secondary
    ModStat3.OutCtl = OUTCTL_PARTNER;
    ucCurrentSlotNum =1;
    bDisableFO= FALSE;

    PartnerSlotInFail[0] = 0;
    PartnerSlotInFail[1] = 0;

    bDisOpInternlUpdte = FALSE;
    PartnersChkPntVer = 0;
}

/*******************************************************************************
*                          clsAohBoxSlot::GetDataType                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsAohBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsAohBoxSlot::GetAccessType                        *
*                          ============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsAohBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                          clsAohBoxSlot::GetParamSize                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAohBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                          clsAohBoxSlot::GetParamPtr                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsAohBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();

}
/*******************************************************************************
*                         clsAohBoxSlot::GetAccessLock                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsAohBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                    clsAohBoxSlot::GetIsDbChecksumed                          *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAohBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                        clsAohBoxSlot::VerifyControlState                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}
/*******************************************************************************
*                        clsAohBoxSlot::ExecutePreFunction                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))(a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsAohBoxSlot::ExecutePostFunction                    *
*                        ==================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
    return;
}
/*******************************************************************************
*                         clsAohBoxSlot::  PreCalibAll                         *
*                         ============================                         *
* PURPOSE:  Pre Receiver-Beware function for CalibAll parameter. Checks for    *
*           Calibration present status.                                        *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesfull                     *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreCalibAll(UINT8 *,UINT8) {
    // TBD : When the CalibSTS is selcted as disabled, abort
    // Calibration of the module is permitted only when module is Idle
    if (ModStat1.Status == MODSTATUS_RUN)  return DO_STATE_MUST_BE_IDLE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostCalibAll                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::PostCalibAll(UINT8) {
    if (TRUE == CalibAll) {
        TaskScheduler.RunTask(TASKID_CALIBTASK);
    }
    return;
}
/*******************************************************************************
*                         clsAohBoxSlot::PreCheckPoint                         *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        HAutoDet[ucSlotNum] = FALSE;
    }
    return PA_OK;
}

#if defined(IOPTYPE_AO16)
// PMIO AO16 Redesign non available parameters beware functions
/*******************************************************************************
*                         clsAohBoxSlot::PostFl_UnPwrd_Bx                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::PostFl_UnPwrd_Bx(UINT8)
{
    for (UINT8 ucSlot = 1; ucSlot <= MAXSLOTS; ucSlot++) {
        *(FL_UNPWRD *)SLOT(ucSlot)->GetFl_UnPwrdPtr() = Fl_UnPwrd_Bx;
    }
}
#endif

/*******************************************************************************
*                       clsAohBoxSlot::LoadCalibrationData                     *
*                       ==================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::LoadCalibrationData(VOID)
{
	/* 
     * Disabling below part of code due to,
     * As of now calibration data stored in both FRAM & Flash memories, but the latest HW is replaced with battery backup SRAM,
	 * calibration data is going to maintain in FLASH memory, and after power on calib data copied into SRAM as is.
     */
#if !defined(IOPTYPE_AO16)
    // First check if the SPI EEPROM is present on the app board. If the SPI 
    // EEPROM is present then check  if the data is valid. If the data in SPI
    // is not VALID then check if the calibration data is present in FLASH. If
    // yes load the data or declare Invalid calibration data.
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        if (CALIBRATION_DONE == Eeprom.ReadByte(EE_CALIBRATION_MARK)) {
            // Check if Calibration data is good
            if (Eeprom.ValidateEepromChecksum()) {
                CalibrationGood = TRUE;

                //Load the data into RAM
                CalibData.FactorySlope  = Eeprom.ReadFloat(EE_CALIBRATION_SLOPE);
                CalibData.FactoryOffset = Eeprom.ReadFloat(EE_CALIBRATION_OFFSET);
                for (UINT16 ucCount = 0; ucCount < (4 * MAXSLOTS); ucCount++)
                    CalibData.CalibConstants[ucCount] = 
                       Eeprom.ReadFloat(EE_CHANNEL_OFFSET_PTR+(ucCount*sizeof(FLOAT32)));
                //Now load the constants into channel parameters
                UINT8 ucIndex = 0;
                FLOAT32 fB1_L = 0.0, fB0_L = 0.0, fB1_O = 0.0, fB0_O = 0.0;
                FLOAT32 fB1LInv = 0.0, fB1Inv = 0.0, fB0_OInv = 0.0, fB0_LInv = 0.0;
                FLOAT32 fSumB0LInv = 0.0, fSumB1LInv = 0.0, fAvgB0LInv = 0.0, fAvgB1LInv = 0.0;
                for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
                    ucIndex = (ucSlotNum - 1) << 2;
                    fB1_O = CalibData.CalibConstants[ucIndex++];
                    fB0_O = CalibData.CalibConstants[ucIndex++];
                    //The loopback constants were normalized while saving.
                    //De-Normalize them before restoring for use.
                    fB1_L = CalibData.CalibConstants[ucIndex++] * CalibData.FactorySlope;
                    fB0_L = CalibData.CalibConstants[ucIndex]   + CalibData.FactoryOffset;
                    fB1Inv  = 1 / fB1_O;
                    fB1LInv = 1 / fB1_L;
                    fB0_OInv = - fB0_O / fB1_O;
                    fB0_LInv = - fB0_L / fB1_L;
                    fSumB0LInv += fB0_LInv;
                    fSumB1LInv += fB1LInv;

                    SLOT(ucSlotNum)->SetB1O(fB1_O);
                    SLOT(ucSlotNum)->SetB0O(fB0_O);
                    SLOT(ucSlotNum)->SetB1Inv(fB1Inv);
                    SLOT(ucSlotNum)->SetB0Inv(fB0_OInv);
                    SLOT(ucSlotNum)->SetB1L(fB1_L);
                    SLOT(ucSlotNum)->SetB0L(fB0_L);
                    SLOT(ucSlotNum)->SetB1LInv(fB1LInv);
                    SLOT(ucSlotNum)->SetB0LInv(fB0_LInv);
                }
                fAvgB0LInv = fSumB0LInv/MAXSLOTS;
                fAvgB1LInv = fSumB1LInv/MAXSLOTS;
                HiZeroHiHi = (-21 - Eeprom.ReadFloat(EE_CALIBRATION_OFFSET)) / Eeprom.ReadFloat(EE_CALIBRATION_SLOPE);
                TestCount  = Eeprom.ReadFloat(EE_CALIB_TEST_COUNT);
                TestCountHi   =  TestCount * 1.02; // +2%
                TestCountHiHi =  TestCount * 1.04; // +4%
                TestCountLo   =  TestCount * 0.98; // -2%
                TestCountLoLo =  TestCount * 0.96; // -4%
                Dac4Percent   =  4  * fAvgB1LInv;
                Dac50Percent  =  50 * fAvgB1LInv + fAvgB0LInv;
                DacMinus6pt9  = -21 * fAvgB1LInv + fAvgB0LInv;
                DacOpenWireThreshold = -19 * fAvgB1LInv + fAvgB0LInv;
                //Full scale DAC value 
                Dac100Percent = (UINT16)fAvgB1LInv * 100.0 + fAvgB0LInv;
                Dac4PercentofFullScale =  (UINT16)(Dac100Percent * 4)/100;
           }
           return;
        }
    }
#endif
    if (CALIBRATION_MARK == CALIBRATION_DONE) { 
        // Calibration present in flash. There is no plan to implement
        // CRC on flash calibration as this is getting relocated to EEPROM.
        CalibrationGood = TRUE;

        //Load the data into RAM
        CalibData.FactorySlope  = CALIBRATION_SLOPE;
        CalibData.FactoryOffset = CALIBRATION_OFFSET;
        volatile FLOAT32 *pfChanZeroDrift = CHANNEL_OFFSET_PTR;
        for (UINT8 ucCount = 0; ucCount < (4 * MAXSLOTS); ucCount++)
            CalibData.CalibConstants[ucCount] = *pfChanZeroDrift++;
        //Now load the constants into channel parameters
        UINT8 ucIndex = 0;
        FLOAT32 fB1_L = 0.0, fB0_L = 0.0, fB1_O = 0.0, fB0_O = 0.0;
        FLOAT32 fB1LInv = 0.0, fB1Inv = 0.0, fB0_OInv = 0.0, fB0_LInv = 0.0;
        FLOAT32 fSumB0LInv = 0.0, fSumB1LInv = 0.0, fAvgB0LInv = 0.0, fAvgB1LInv = 0.0;
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
            ucIndex = (ucSlotNum - 1) << 2;
            fB1_O = CalibData.CalibConstants[ucIndex++];
            fB0_O = CalibData.CalibConstants[ucIndex++];
            //The loopback constants were normalized while saving.
            //De-Normalize them before restoring for use.
            fB1_L = CalibData.CalibConstants[ucIndex++] * CalibData.FactorySlope;
            fB0_L = CalibData.CalibConstants[ucIndex]   + CalibData.FactoryOffset;
            fB1Inv  = 1 / fB1_O;
            fB1LInv = 1 / fB1_L;
            fB0_OInv = - fB0_O / fB1_O;
            fB0_LInv = - fB0_L / fB1_L;
            fSumB0LInv += fB0_LInv;
            fSumB1LInv += fB1LInv;

            SLOT(ucSlotNum)->SetB1O(fB1_O);
            SLOT(ucSlotNum)->SetB0O(fB0_O);
            SLOT(ucSlotNum)->SetB1Inv(fB1Inv);
            SLOT(ucSlotNum)->SetB0Inv(fB0_OInv);
            SLOT(ucSlotNum)->SetB1L(fB1_L);
            SLOT(ucSlotNum)->SetB0L(fB0_L);
            SLOT(ucSlotNum)->SetB1LInv(fB1LInv);
            SLOT(ucSlotNum)->SetB0LInv(fB0_LInv);
        }
        fAvgB0LInv = fSumB0LInv/MAXSLOTS;
        fAvgB1LInv = fSumB1LInv/MAXSLOTS;
        HiZeroHiHi = (-21 - CALIBRATION_OFFSET) / CALIBRATION_SLOPE;
        TestCount  = CALIB_TEST_COUNT;
        TestCountHi   =  TestCount * 1.02; // +2%
        TestCountHiHi =  TestCount * 1.04; // +4%
        TestCountLo   =  TestCount * 0.98; // -2%
        TestCountLoLo =  TestCount * 0.96; // -4%
        Dac4Percent   =  4  * fAvgB1LInv;
        Dac50Percent  =  50 * fAvgB1LInv + fAvgB0LInv;
        DacMinus6pt9  = -21 * fAvgB1LInv + fAvgB0LInv;
        DacOpenWireThreshold = -19 * fAvgB1LInv + fAvgB0LInv;
        //Full scale DAC value 
        Dac100Percent = (UINT16)fAvgB1LInv * 100.0 + fAvgB0LInv;
        Dac4PercentofFullScale = (UINT16) (Dac100Percent * 4)/100;
    
       /*
        * below part of code works as is,
        * Since FRAM is replaced with battery backup SRAM, Calibration data retrives from the flash
        * and writes in the SRAM on every power on.
        */

        // Now copy the data in SPI EEPROM. We need this only 1 time. This is because
        // if the module is already calibrated and the data is in Flash.This will be
        // removed later as it is not required once the data is in SPI. If calibration
        // is attempted, it will be written to EPIEEPROM directly if present.

        // First check if the SPI EEPROM is present on the app board. If the SPI 
        // EEPROM is present then store the data in SPI EEPROM else use FLASH.
        // Read the status register. Bits 2 and 3 are write protect bits and
        // always 0 as we do not protect it. If we see any of these bits ON,then
        // it is safe to assume that SPI device is not present.
        if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
            // Reinit the pointer
            UINT8 *ucBufferPtr = (UINT8*)(MODULEINFO_START_ADDRESS);
            //Enable the writes EEPROM 
            Eeprom.EnableWrite();
            //Start writing calibration constants to SPI.
            for (UINT16 ucCount=0; ucCount < MAX_EEPROM_SIZE-6; ucCount++) {
                Eeprom.WriteByte(ucCount,*ucBufferPtr);
                ucBufferPtr++;
                Eeprom.CheckWriteInProgress();
            }
            Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS,0x5A);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS+1,0x5A);
            Eeprom.CheckWriteInProgress();

            UINT16 ModuleWriteCount;
            ModuleWriteCount = Eeprom.ReadUint16(EE_MODULEINFO_WRITECOUNT)+1;
            if (0==ModuleWriteCount) ModuleWriteCount = 1;
            Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
            // calculate and write the checksum
            UINT16 Chksum = Eeprom.ComputeEepromChecksum();
            Eeprom.WriteByte(EE_MODULEINFO_CHKSUM,(UINT8)Chksum);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_CHKSUM+1,(UINT8)(Chksum>>8));
            Eeprom.CheckWriteInProgress();
            //Disable the writes EEPROM 
            Eeprom.DisableWrite();
        }
    }
   
    if (FALSE == CalibrationGood) { // Calibration data is bad or not available.
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
        
        // Load default constants for diagnostic/debug purposes.
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
            SLOT(ucSlotNum)->SetB1Inv(DEFAULT_OUTPUT_SLOPE);
            SLOT(ucSlotNum)->SetB0Inv(DEFAULT_OUTPUT_OFFSET);
            SLOT(ucSlotNum)->SetB1LInv(DEFAULT_LOOPBACK_SLOPE);
            SLOT(ucSlotNum)->SetB0LInv(DEFAULT_LOOPBACK_OFFSET);
        }
    }
    else { // return ADOUTCAL softfail.
       AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,FALSE,0);
    }
}
/*******************************************************************************
*                        clsAohBoxSlot::AppInitialization                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::AppInitialization(VOID) {
    const UINT8 LOOPBACK_TEST_COUNT = 4; // CALCHK and three HIZEROs.
    const UINT8 STARTUP_TEST_SETTLE_TIME = 120;

    // Load calibration data from EEPROM section to box/slot database.
    LoadCalibrationData();
    
    if (BOX->IsCalibrationGood() == TRUE)
    {   //Perform the startup tests only if calibration was done 
        // Before the outputs are enabled, drive all outputs to maximum current and
        // minimum current and perform complete loopback tests. Individual channel
        // loopback is not done here as the channel configuration is not loaded yet.
        FLOAT32 fOp = OP_HILIMIT;
        BOOL bStartupTestComplete = FALSE;

        do
        {
            // Drive all outputs. NOTE that output switches are NOT enabled yet.
            // So the channel currents are flowing into the ground.
            for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) 
            {
                SetOp(ucSlotNum,fOp);
            }
        
            // Wait for the outputs to settle.
            for (UINT8 ucLoop = 0; ucLoop < STARTUP_TEST_SETTLE_TIME; ucLoop++) 
            {
                IdleWait(MICROSECONDS_IN_MILLISECOND); 
            }
        
            // Perform loopback tests on CALCHK, HIZERO0, HIZERO1 and HIZERO2.
            for (UINT8 ucLoop = 0; ucLoop < LOOPBACK_TEST_COUNT; ucLoop++) 
            {
                TestLoopbackCircuit();
            }

            if (fOp == OP_LOLIMIT) bStartupTestComplete = TRUE;
            else fOp = OP_LOLIMIT;

        } while (bStartupTestComplete == FALSE);
    }
    
    // Wait until the hardware is settled down;wait time abt 600msec
    for (UINT8 ucCount = 30; ucCount > 0; ucCount--) IdleWait(20000);
    while (!SwitchInit());

}
/*******************************************************************************
*                      clsAohBoxSlot::AppStcProcessing                         *
*                      ==============================                          *
* PURPOSE:      This routine performs the following activities                 *
*                1) Validates the DSA state of the Module                      *
*                2) Redundancy processing                                      *
*                3) Validation of the Redundancy switch states                 *
*                4) Channel Output Readback and Refresh Mechnism               * 
*                                                                              *
*                                                                              *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:   NONE                                                               *
* NOTES:                                                                       * 
*           The Readback test and Refresh mechnism is based on the following   *
*           Scheme:                                                            * 
*           In each interval of 10msec stc cycle ,the readback and refresh     *
*           mechnism will be conducted for 4 channels in a sequential fashion. * 
*           So it takes 4 cycles(40msec) to complete the Readback              *
*           and Refresh mechnism for all 16 channels.                          * 
*                                                                              *
*           NOTE:                                                              *
*           ====                                                               *
*           1)The channel Readback test will not be conducted for a channel    *
*             whose output was just written                                    *
*           2)The channel Readback test will not be conducted for 2 cycles for *
*             a channel if the differance b/w succesive outputs is greater     * 
*             then 50%                                                         *
*******************************************************************************/
VOID clsAohBoxSlot::AppStcProcessing(VOID) {
    
    #if(HEK && defined(IOMTYPE_AOH))
    if((FALSE == IsFpgaS2) && (0 == FPGA_INIT_n)) // only for S3 FPGA
    // Hardfail the module if FPGA CRC check fails
    HardFail(HF_FPGARDBKFAIL, AOHBOXSLOT_CPP, __LINE__);
    #endif
    
    // Perform loopback test for the scheduled channels 
    // and retry channels if calibration is not in progress. 
    if (FALSE == CalibAll){
        UINT8 ucCount,LpbkSts;

#if defined(IOPTYPE_AO16) 
        FtaStatus();        
        
        // added this condition to fix the following customer issue,
        // BW-46473 null SF 02627886 DEER 02656190 / PAR 1-E8WAJQR (AO_16 card does not warn/alarm on wrong FTA connected)
        if ((GetFtaPres() == TRUE) &&            // FTA Present
            (INHIN_ASSERTED == INHIN_FB_n) &&    // Partner has not released output control
            (Iol.AmPrimary()) &&                 // and, I am primary 
            (DbValid == DB_INVALID))             // and, invalid db (added to fix RTPN-1797 and, proper wrong FTA detection)
        {
            if((!CheckRedData(REDDATA_REDCFG)) ||                                    // if non red config, HARD FAIL
               (((SWBUREQ_ASSERT == SWBUREQ_n) || (GetPartnersBackupStatus())) &&    // if red config, Syncd & if requesting for partner backup or partner requesting me for backup
                (LastSfCode != SF_OUTPUTFL)))                                        // and, Last Sfail should not be OP Fail
            {
                HardFail(HF_OUTPUTCONTROL, AOHBOXSLOT_CPP, __LINE__);
            }
        }
#endif        
        ManageRedIO();

        //Validate the screw controls  
        if (CheckRedData(REDDATA_REDCFG) || (!ModStat3.OutCtl && Iol.AmPrimary())) {
            CheckFailOverCondition();
        }

        //Ensure redundancy switches on primary and secondary module are intact 
#if defined(IOPTYPE_AO16)
        //FTA should be present & not in Factory Mode
        if ((GetFtaPres() != FTA_MISSING) && !(BOX->CheckForFactoryTestMode())) {
#else
        if (!(BOX->CheckForFactoryTestMode())){ //do not execute in Factory Mode
#endif
            if((OUTCTL_MINE == ModStat3.OutCtl)&&(FALSE == bSwitchDiagRunning)){
                AoHardware.VerifySwitchState(DIS_SWCH,DIS_ON_ON);
                AoHardware.VerifySwitchState(INH_SWCH,INH_ON_ON);
                AoHardware.VerifySwitchState(TST_SWCH,TST_DISABLED);

                //verify the INHIN_FB_n line 
                if(INHIN_NEGATED != INHIN_FB_n){
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,TRUE,0);
                }
                else{
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
                }
            }
            else if((OUTCTL_PARTNER == ModStat3.OutCtl)&& 
                   (FALSE == bSwitchDiagRunning)){
                AoHardware.VerifySwitchState(DIS_SWCH,DIS_OFF_OFF);
                AoHardware.VerifySwitchState(INH_SWCH,INH_OFF_OFF);
                AoHardware.VerifySwitchState(TST_SWCH,TST_DISABLED);
            }
        }
#ifdef DEBUG 
        if (TRUE == g_bStopRefresh) return;
#endif
        if(ucCurrentSlotNum == 1)bDisableFO = FALSE;
        //Do the refresh and readback of 4 channels 
        for (ucCount = 1; ucCount <= 4; ucCount++) {
            LpbkSts = AOLPBK_PASSED;
            //Do a readback of the channel output only if module roles are stable
            if(((OUTCTL_PARTNER == ModStat3.OutCtl)&&(!Iol.AmPrimary()))||
                ((OUTCTL_MINE == ModStat3.OutCtl)&&(Iol.AmPrimary()))){
                //Do a readback of the channel output if the Point Execution state 
                //is active and Module is in Run state 
                if((SLOT(ucCurrentSlotNum)->GetPtExecSt() == PTEXECST_ACTIVE)
#if defined(IOPTYPE_AO16)
                    // added to resolve, PAR# 1-80IEM4K
                    && (GetFtaPres() != FTA_MISSING)
#endif
                    &&(MODSTATUS_RUN == ModStat1.Status)){  
                    if((SLOT(ucCurrentSlotNum)->GetOTPT_Unused() == FALSE)//Is channel is use and Op not just written
                        &&(TRUE == SLOT(ucCurrentSlotNum)->GetReadBackrequired())){
                        if(0 == SLOT(ucCurrentSlotNum)->GetSkipLpBkTst()){//Validate the OP % swing and perform reaback  
                            LpbkSts = SLOT(ucCurrentSlotNum)->DoLoopbackTest(Dac4PercentofFullScale);
                            if (AOLPBK_PASSED == LpbkSts) {
#if defined(IOPTYPE_AO16)                                
                                // 2. disabled this condition to resolve following PAR,
                                //    PAR# 1-E2KA8ZT (modules swapover/failover is not working during OP fail)
                                // 1. added this condition to resolve the following PAR,
                                //    PAR# 1-80IEM4K (SEC module sync status stucked in "Fo Complete" duirng OP fail)                                
                                //if (Iol.AmPrimary() ||
                                //   ((SLOT(ucCurrentSlotNum)->GetSlotSfLrs() == TRUE) && (GetPartnersBackupStatus() == DEASSERTED)))
#endif
                                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,ucCurrentSlotNum);
                            }
                            else {
                                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,TRUE,ucCurrentSlotNum);
                                bDisableFO = TRUE;
                            }
                        }
                        else{
                            if(SLOT(ucCurrentSlotNum)->GetSkipLpBkTst() > 0){
                                SLOT(ucCurrentSlotNum)->DecrSkipLpBkTst();
                            }
                            /**********************************************************************
                             Added statement bDisableFO = TRUE to fix the following PAR  
                             1-288ORM:AO IOM with channel softfail does not completes sync after
                                      iolink cables is connected back
                            **********************************************************************/  
                            bDisableFO = TRUE;
                        }
                    }
                    else{
                        //Only if the channel is in use set the readback flag
                        if(SLOT(ucCurrentSlotNum)->GetOTPT_Unused() == FALSE){
                            //Conduct readback test for this channel in next cycle 
                            SLOT(ucCurrentSlotNum)->SetReadBackrequired(TRUE);
                            if(0 != SLOT(ucCurrentSlotNum)->GetSkipLpBkTst()){
                                SLOT(ucCurrentSlotNum)->DecrSkipLpBkTst(); 
                            }

                            if(REDSTATE_SYNCD != GetRedState())
                            /**********************************************************************
                             Added statement bDisableFO = TRUE to fix the following PAR  
                             1-288ORM:AO IOM with channel softfail does not completes sync after
                                      iolink cables is connected back
                            **********************************************************************/  
                            bDisableFO = TRUE;
                        }
                    }
                }
                else{
                    if (AOLPBK_PASSED == LpbkSts) {
                        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,ucCurrentSlotNum);
                    }
                    else {
                        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,TRUE,ucCurrentSlotNum);
                        bDisableFO = TRUE;
                    }
                }
                SLOT(ucCurrentSlotNum)->CmptInitReq();
            }
            else{
                    bDisableFO = TRUE;
            }
#if !LOWCOST
            // Refresh the output channel.
            AoHardware.DriveOutput(ucCurrentSlotNum);
#endif
            //Increment the channel No
            ucCurrentSlotNum++;
        }
        //Reset the slot counter 
        if(ucCurrentSlotNum > MAXSLOTS){
        // for redesign PMIO, disabled due to sync fail happens
#if !defined(IOPTYPE_AO16)
            if ((bDisableFO == FALSE) && (Iol.AmPrimary())&&
                (REDSTATE_SYNCD == GetRedState())){
                   EnableOutputFailFO();
            }
#endif
            ucCurrentSlotNum = 1;
        }
    }//Calibartion Not in progress loop
}
/*******************************************************************************
*                      clsAohBoxSlot::TestLoopbackCircuit                      *
*                      ==================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::TestLoopbackCircuit(VOID) {
    static UINT8 ucHFcount = 0; 
    static UINT8 ucInput = CALCHK_OFFSET; 
    BOOL bMuxAddrFailed = FALSE;
    BOOL bSF_Active = FALSE; 
    BOOL bTestResult = TRUE;

    UINT8 ucSaveExr =get_imask_exr();
    set_imask_exr(LVLPRI_TICK);
    
    if(((OUTCTL_PARTNER == ModStat3.OutCtl)&&(!Iol.AmPrimary()))||
        ((OUTCTL_MINE == ModStat3.OutCtl)&&(Iol.AmPrimary()))){
        // Open the loopback test input.
        bMuxAddrFailed = AoHardware.OpenLoopbackMux(ucInput,FALSE);
        
        if (CALCHK_OFFSET == ucInput) {
            //Drive the Dac with the Test Voltage + 2% 
#if !LOWCOST
            AoHardware.DriveDac(TestCountHi);
#else
            AoHardware.DriveDac(TestCountHi,READBACK_DAC_ADDR);
#endif
            if(AoHardware.ReadComparatorOutput()) bTestResult = FALSE;
            if(FALSE == bTestResult) {
                //Drive the Dac with the Test Voltage - 2% 
#if !LOWCOST
                AoHardware.DriveDac(TestCountLo);
#else
                AoHardware.DriveDac(TestCountLo,READBACK_DAC_ADDR);
#endif
                if(!AoHardware.ReadComparatorOutput()) bTestResult = FALSE;
            }
            if (TRUE == bTestResult) { // Either +2% or -2% test failed
                if(Iol.AmPrimary()) { // Do HF tests (+/- 4%) only if primary module
                    //Drive the Dac with the Test Voltage + 4%
#if !LOWCOST
                    AoHardware.DriveDac(TestCountHiHi);
#else
                    AoHardware.DriveDac(TestCountHiHi,READBACK_DAC_ADDR);
#endif
                    if(AoHardware.ReadComparatorOutput()) bTestResult = FALSE;
                    if(TRUE == bTestResult) {
                        ucHFcount++;
                        if(ucHFcount >= 2) HardFail(HF_BD_OUTPUT_MUX,AOHBOXSLOT_CPP,__LINE__);
                    }
                    else {
                        //Drive the Dac with the Test Voltage - 4% 
#if !LOWCOST
                        AoHardware.DriveDac(TestCountLoLo);
#else
                        AoHardware.DriveDac(TestCountLoLo,READBACK_DAC_ADDR);
#endif
                        bTestResult = TRUE;
                        if(!AoHardware.ReadComparatorOutput()) bTestResult = FALSE;
                        if(TRUE == bTestResult) {
                            ucHFcount++;
                            if(ucHFcount >= 2) HardFail(HF_BD_OUTPUT_MUX,AOHBOXSLOT_CPP,__LINE__);
                        }
                        else ucHFcount = 0;
                    }
                }
                bSF_Active = TRUE;
            }
            else bSF_Active = FALSE;
        }
        else { // ucInput == HIZERO1_OFFSET or HIZERO2_OFFSET or HIZERO3_OFFSET
            if(Iol.AmPrimary()) { // Do HF test only if primary module
#if !LOWCOST
                AoHardware.DriveDac(HiZeroHiHi);
#else
                AoHardware.DriveDac(HiZeroHiHi,READBACK_DAC_ADDR);
#endif
                if (FALSE == AoHardware.ReadComparatorOutput()) ucHFcount++;
                else ucHFcount = 0;
                if(ucHFcount >= 2) HardFail(HF_BD_OUTPUT_MUX,AOHBOXSLOT_CPP,__LINE__);
            }
        }
        // Close the test input.
        AoHardware.CloseLoopbackMux(ucInput);

        set_imask_exr(ucSaveExr);
        // Change input for the next cycle.
        switch (ucInput) {
            case CALCHK_OFFSET:
                ucInput = HIZERO1_OFFSET;
                break;
            case HIZERO1_OFFSET:
                ucInput = HIZERO2_OFFSET;
                break;
            case HIZERO2_OFFSET:
                ucInput = HIZERO3_OFFSET;
                break;
            case HIZERO3_OFFSET:
                ucInput = CALCHK_OFFSET;
                break;
            default:
                HardFail(HF_BADPROGRAMJUMP,AOHBOXSLOT_CPP,__LINE__);
        }
    }
    else {
        ucHFcount = 0; 
        ucInput = CALCHK_OFFSET; 
    }
    if (bSF_Active == FALSE && bMuxAddrFailed == FALSE) BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,FALSE,0);
    else BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,TRUE,0);
}
/*******************************************************************************
*                       clsAohBoxSlot::FlashCalibrationData                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAohBoxSlot::FlashCalibrationData(VOID) {
    UINT8 *ucBufferPtr;
    UINT8 ucModuleInfoBlockTop[3 * FLASH_PROGRAM_BLOCK_SIZE];//Total of 16+256+10 bytes data
    
    /*
     * enabled the part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */

#if defined(IOPTYPE_AO16) //ndef DEBUG
    UINT8 ucModuleInfoBlockBottom[FLASH_PROGRAM_BLOCK_SIZE];
#endif

    // Initialize the buffers.
    for (UINT8 ucCount = 0; ucCount < FLASH_PROGRAM_BLOCK_SIZE; ucCount++) {
        ucModuleInfoBlockTop[ucCount]    = 0xFF;
        ucModuleInfoBlockTop[ucCount+FLASH_PROGRAM_BLOCK_SIZE]    = 0xFF;
        ucModuleInfoBlockTop[ucCount+FLASH_PROGRAM_BLOCK_SIZE*2]  = 0xFF;
        /*
         * enabled the part of code due to,
         * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
         */

#if defined(IOPTYPE_AO16) //ndef DEBUG
        ucModuleInfoBlockBottom[ucCount]  = 0xFF;
#endif
    }

    /*
     * Disabling below part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */

#if !defined(IOPTYPE_AO16)
    // First check if the SPI EEPROM is present on the app board. If the SPI 
    // EEPROM is present then store the data in SPI EEPROM else use FLASH.
    // Read the status register. Bits 2 and 3 are write protect bits and
    // always 0 as we do not protect it. If we see any of these bits ON,then
    // it is safe to assume that SPI device is not present.
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        // Fill the information at the top of the module info block.
        ucBufferPtr = ucModuleInfoBlockTop;
        for (UINT8 ucCount = 0; ucCount < (4 * MAXSLOTS); ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.CalibConstants[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
        *((FLOAT32 *)ucBufferPtr) = CalibData.FactorySlope;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.FactoryOffset;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = TestCount;//Test count

        // calculate Total number fo bytes to be copied to EEPROM
        UINT16 uCalDataBytes = (ucBufferPtr - ucModuleInfoBlockTop) + sizeof(FLOAT32);
        // Reinit the pointer
        ucBufferPtr = ucModuleInfoBlockTop;
        //Enable the writes EEPROM 
        Eeprom.EnableWrite();
        //Start writing calibration constants to EEPROM.
        for (UINT16 ucCount=0; ucCount < uCalDataBytes; ucCount++) {
            Eeprom.WriteByte(ucCount+EE_CHANNEL_OFFSET_PTR,*ucBufferPtr);
            ucBufferPtr++;
            Eeprom.CheckWriteInProgress();
        }
        // Write Calibration complete
        Eeprom.WriteByte(EE_CALIBRATION_MARK,CALIBRATION_DONE);
        Eeprom.CheckWriteInProgress();

        Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS,0x5A);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS+1,0x5A);
        Eeprom.CheckWriteInProgress();

        UINT16 ModuleWriteCount;
        ModuleWriteCount = Eeprom.ReadUint16(EE_MODULEINFO_WRITECOUNT)+1;
        if (0==ModuleWriteCount) ModuleWriteCount = 1;
        Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
        Eeprom.CheckWriteInProgress();
        // calculate and write the checksum
        UINT16 Chksum = Eeprom.ComputeEepromChecksum();
        Eeprom.WriteByte(EE_MODULEINFO_CHKSUM,(UINT8)Chksum);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_CHKSUM+1,(UINT8)(Chksum>>8));
        Eeprom.CheckWriteInProgress();
        //Disable the writes EEPROM 
        Eeprom.DisableWrite();

        return TRUE;
    }
	
//#ifndef DEBUG // Flash programming will not be supported by APP debug build.
	else 
#else
	{
#ifdef DEBUG
		while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalib data storing into FLASH, ")); 
#endif
        // Fill the information at the top of the module info block.
        ucBufferPtr = ucModuleInfoBlockTop;
        *((UINT16 *)ucBufferPtr) = VENDOR_ID;
        ucBufferPtr += sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = PRODUCT_TYPE;
        ucBufferPtr += sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = PRODUCT_CODE;
        ucBufferPtr += sizeof(UINT16);
        *((UINT32 *)ucBufferPtr) = SERIAL_NUMBER;
        ucBufferPtr += sizeof(UINT32);
        *((UINT8 *)ucBufferPtr) = HARDWARE_REVCODE;
        ucBufferPtr += sizeof(UINT8);

        ucBufferPtr += sizeof(UINT32); // Fill area.
        *((UINT8 *)ucBufferPtr) = CALIBRATION_DONE;
        ucBufferPtr += sizeof(UINT8);

        for (UINT8 ucCount = 0; ucCount < (4 * MAXSLOTS); ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.CalibConstants[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
        *((FLOAT32 *)ucBufferPtr) = CalibData.FactorySlope;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.FactoryOffset;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = TestCount;//Test count

        // Fill information at the bottom of module info block.
        ucBufferPtr = ucModuleInfoBlockBottom + FLASH_PROGRAM_BLOCK_SIZE - 1;
        *((UINT16 *)ucBufferPtr) = 0; // Replace this CRC value later.

        ucBufferPtr -= sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = MODULINFO_WRITE_COMPLETE;

        // Program number of times module info section is programmed.
        ucBufferPtr -= sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) =  MODULEINFO_WRITECOUNT + 1;
        if (0 == *((UINT16 *)ucBufferPtr)) {
            *((UINT16 *)ucBufferPtr) = 1;
        }

        if (EraseFlash(MODULE_INFO_FLASH_BLOCK)) {
            if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS,ucModuleInfoBlockTop)) {
                if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS + FLASH_PROGRAM_BLOCK_SIZE,
                    ucModuleInfoBlockTop + FLASH_PROGRAM_BLOCK_SIZE)) {
                    if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS + 2*FLASH_PROGRAM_BLOCK_SIZE,
                        ucModuleInfoBlockTop + 2*FLASH_PROGRAM_BLOCK_SIZE)) {
                        if (ProgramFlash((UINT8 *)(MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1),
                            ucModuleInfoBlockBottom)) {
#ifdef DEBUG
		                    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("done")); 
#endif
                            return TRUE;
                        }
                    }
                }
            }
        }
    }
//#endif // ifndef DEBUG
#endif

    return FALSE;
}
/*******************************************************************************
*                               PerformModuleCalibration                       *
*                               ========================                       *
* PURPOSE: This function is responsible for module calibration                 *
*                                                                              *
* ARGUMENTS: None.                                                             *
* RETURN: TRUE if successful, FALSE otherwise                                  *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsAohBoxSlot::PerformModuleCalibration(VOID)
{
    AssertBackup();

    BOOL bResult = FALSE;
    //Drive all channels to DAC 0 state.
    for(UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++)
        SetOp(ucSlotNum, EXTENDED_OP_LOLIMIT);
    //Verify HIZERO readings for all three references
    for (UINT8 ucChanNum = HIZERO3_OFFSET; ucChanNum <= HIZERO1_OFFSET; ucChanNum++) {
        AoHardware.OpenLoopbackMux(ucChanNum,TRUE);
        HiZero = (UINT16)DoSuccessiveApproximation();
        AoHardware.CloseLoopbackMux(ucChanNum);
        if((HiZero < MINHIZERO_LOOPBACK_DACCOUNT) || 
           (HiZero > MAXHIZERO_LOOPBACK_DACCOUNT)) {
            //Drive all channels to -6.9
            for (UINT8 ucChanNum = 1; ucChanNum <= MAXSLOTS; ucChanNum++) 
                SetOp(ucChanNum, OP_LOLIMIT);
            CalibAll = FALSE;
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
            return FALSE;
        }
        else {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
        }
    }

#if !LOWCOST
    //Test what Calibration to perform
    AoHardware.OpenLoopbackMux(FACCAL_OFFSET,TRUE);
    //Drive the DAC with pre-decided FACCAL value
    AoHardware.DriveDac(FACCAL_OUTPUT_DACCOUNT);
    //Check the comparator reading to call the appropriate routine
    FieldCalibOn = AoHardware.ReadComparatorOutput();
    //Done ! Close the channel
    AoHardware.CloseLoopbackMux(FACCAL_OFFSET);
#else // For Low Cost 
    if (FACTCAL == 0)
        FieldCalibOn = FALSE;
    else
        FieldCalibOn = TRUE;
#endif

    bResult = FieldCalibOn ? PerformFieldCalibration() : PerformFactoryCalibration();
    FieldCalibOn = FALSE;

    if(TRUE == bResult) {
        //All is well. Program the flash 
        if(FALSE == (bResult = FlashCalibrationData())) { }
        else {
            // Calibration successful
#ifdef DEBUG
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalibration successful"));
#endif
#if LOWCOST
            // Clear write message queue before rebooting IOM, as it is utilised for 
            // copying ProgramFlash and EraseFlash routines before flashing
            UINT16 usItr;
            UINT8* ucPtr = WriteMsgQueue.GetMsgBufferPtr();
            // Wait for a watchdog refresh to happen so that there is maximum time is
            // available to the flash uitility before the next watchdog refresh window.
            while (TaskScheduler.GetWdtRefreshCounter() != 0);

            for(usItr = 0;usItr < WRITEMSG_QUEUESIZE;usItr++) {
                ucPtr[usItr] = 0x00;
            }
#endif
            // Reboot the module so that the new 
            // calibration data gets loaded.
            RebootIom();

           /*         
            * Since FRAM is replaced with backup SRAM, calibration done must be stored in FLASH only.
            */
#if defined(IOPTYPE_AO16)            
            xRamWrite((xRAM_CHKPNT_ADRS + xRAM_CALIB_DONE), (UINT8 *)&TRUE, sizeof(UINT8));
#endif
        }
    }
    //Drive all channels to -6.9 now
    for (UINT8 ucChanNum = 1; ucChanNum <= MAXSLOTS; ucChanNum++) 
        SetOp(ucChanNum, OP_LOLIMIT);
    CalibAll = FALSE;
    return bResult;
}
/*******************************************************************************
*                               PerformFactoryCalibration                      *
*                               =========================                      *
* PURPOSE: This function is responsible for factory calibration                *
*                                                                              *
* ARGUMENTS: None.                                                             *
* RETURN: TRUE if successful, FALSE otherwise                                  *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAohBoxSlot::PerformFactoryCalibration(VOID) {
    BOOL    bResult = TRUE;
    // Switch off the status LED 
    LED_PINS = STATUSLED_OFF;

#if !LOWCOST
    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
#else
    if (WaitCalibSwitch() == FALSE) {
       return FALSE;   // calibration cancelled
    } // continue if TRUE
#endif
    
    // Select multipliexer input from MUX 1 calibration voltage - SNSCAL
    AoHardware.OpenLoopbackMux(SNSCAL1_OFFSET,TRUE);
    //Perform Limit check with the Max/Min value of 1V
    bResult = CheckRefVoltage(MAX_ONE_V_OUTPUT_DACCOUNT) & 
              CheckRefVoltage(MIN_ONE_V_OUTPUT_DACCOUNT);
    if(!bResult) {
        AoHardware.CloseLoopbackMux(SNSCAL1_OFFSET);
        return FALSE;
    }

    //Perform A to D Conversion of 1V value present on SNSCAL
    UINT16 us1vDacCount = (UINT16)DoSuccessiveApproximation();
    //We are done with the 1V calibration reference, Flash the status LED to 
    //indicate that the tech can now change the reference voltage to 5V.
    BlinkLed(1);
    // Wait till user press and release CALIBRATE switch on the IOTA.
#if !LOWCOST
    while (!CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
#else
    if (WaitCalibSwitch() == FALSE) {
       return FALSE;   // calibration cancelled
    } // continue if TRUE
#endif

    //Perform Limit check with the Max/Min value of 5V
    bResult = CheckRefVoltage(MAX_FIVE_V_OUTPUT_DACCOUNT) & 
              CheckRefVoltage(MIN_FIVE_V_OUTPUT_DACCOUNT);
    if(!bResult) {
        AoHardware.CloseLoopbackMux(SNSCAL1_OFFSET);
        return FALSE;
    }
    //Perform A to D Conversion of 5V value present on SNSCAL
    UINT16 us5vDacCount = (UINT16)DoSuccessiveApproximation();
    //Compute the loopback slope and offset with the above readings
    CalibData.FactorySlope = (FLOAT32)((100.0 - 0.0)/(us5vDacCount - us1vDacCount));
    //Compute the constant, c = y - mx
    CalibData.FactoryOffset = 0.0 - CalibData.FactorySlope * us1vDacCount;

    //Blink the LEDs
    BlinkLed(2);
    // Wait till user press and release CALIBRATE switch on the IOTA.
#if !LOWCOST
    while (!CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
#else
    if (WaitCalibSwitch() == FALSE) {
       return FALSE;   // calibration cancelled
    } // continue if TRUE
#endif
    BlinkLed(3);

    //Now perform the slot calibration procedure for each slot
    //Drive all channels to DAC 0 state.
    //LOWCOST: Disable Output Drive also.
    for(UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        SLOT(ucSlotNum)->SetOutDACImg(0);
        AoHardware.DriveOutput(ucSlotNum,CalibrationWithExtendedDelay);
#if LOWCOST
        AoHardware.DisableOutputDrive(ucSlotNum);
#endif

    }
    //For each channel calculate the constants. Done in reverse order. 
    //First all channels are charged for 100 msec. On and after 2nd,
    //previous channel is charged for 100 msec and all channels are 
    //refreshed for 150 micro sec.
    for(UINT8 ucSlotNum = MAXSLOTS; ucSlotNum >= 1; ucSlotNum--) {
        if(ucSlotNum < MAXSLOTS) {
            //Charge the next channel with 100 ms delay
            SLOT(ucSlotNum + 1)->SetOutDACImg(0);
            AoHardware.DriveOutput(ucSlotNum + 1,CalibrationWithExtendedDelay);
            //Rest of the channels can be charged for 150 us
            for(UINT8 ucSlotNum1 = 1; ucSlotNum1 <= MAXSLOTS; ucSlotNum1++) {
                SLOT(ucSlotNum1)->SetOutDACImg(0);
                AoHardware.DriveOutput(ucSlotNum1,CalibrationWithMinimumDelay);
#if LOWCOST
                AoHardware.DisableOutputDrive(ucSlotNum1);
#endif

            }
        }
#if LOWCOST 
        AoHardware.EnableOutputDrive(ucSlotNum);
#endif

        if(FALSE == (bResult = SLOT(ucSlotNum)->
                               ComputeCalibrationConstants(CalibData.FactorySlope,
                                                           CalibData.FactoryOffset)))
            break;
    }
    //Drive all channels to DAC 0 state.
    for(UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
#if LOWCOST 
        AoHardware.EnableOutputDrive(ucSlotNum);
#endif
        SLOT(ucSlotNum)->SetOutDACImg(0);
        AoHardware.DriveOutput(ucSlotNum,CalibrationWithMinimumDelay);
    }
    AoHardware.CloseLoopbackMux(SNSCAL1_OFFSET);
    //Perform Limit check with the Max/Min value of Test Voltage if everything is Ok
    //TBD Amit : Get the new DAC counts from H/W team and enable this test.

    AoHardware.OpenLoopbackMux(CALCHK_OFFSET,TRUE);  
    TestCount = ((clsAohBoxSlot *)pDatabase[0])->DoSuccessiveApproximation();
    if (TRUE == bResult) {
      bResult = CheckRefVoltage(MAX_TEST_VOLTAGE_OUTPUT_DACCOUNT) & 
                CheckRefVoltage(MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT);
    }
    AoHardware.CloseLoopbackMux(CALCHK_OFFSET);
    return bResult;
}
/*******************************************************************************
*                               PerformFieldCalibration                        *
*                               =======================                        *
* PURPOSE: This function is responsible for field calibration                  *
*                                                                              *
* ARGUMENTS: None.                                                             *
* RETURN: TRUE if successful, FALSE otherwise                                  *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAohBoxSlot::PerformFieldCalibration(VOID) {
    //Abort if factory calibration is not yet done
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EECKSMER,!CalibrationGood,0);
    if(!CalibrationGood) return FALSE;
    DisableOutputs();
    BOOL bResult = TRUE;
    //Switch off the status LED
    LED_PINS = STATUSLED_OFF;

    // Wait till user press and release CALIBRATE switch on the IOTA.
#if !LOWCOST
    while (!CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
#else
    if (WaitCalibSwitch() == FALSE) {
       return FALSE;   // calibration cancelled
    } // continue if TRUE
#endif

    // Select multipliexer input from MUX 1 calibration voltage - SNSCAL
    AoHardware.OpenLoopbackMux(SNSCAL1_OFFSET,TRUE);
    //Perform Limit check with the Max/Min value of 5V
    bResult = CheckRefVoltage(MAX_FIVE_V_OUTPUT_DACCOUNT) & 
              CheckRefVoltage(MIN_FIVE_V_OUTPUT_DACCOUNT);
    if(!bResult) {
        AoHardware.CloseLoopbackMux(SNSCAL1_OFFSET);
        EnableOutputs();
        return FALSE;
    }
    //Revise B1_L
    FLOAT32 fOldSlope = CalibData.FactorySlope;
    CalibData.FactorySlope = (100.0 - CalibData.FactoryOffset) / 
                             DoSuccessiveApproximation();
    //Close SNSCAL1
    AoHardware.CloseLoopbackMux(SNSCAL1_OFFSET);
    //Drive all channels to DAC 0 state.
    for(UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++)
        SetOp(ucSlotNum, EXTENDED_OP_LOLIMIT);
    //Blink the LEDs
    BlinkLed(2);

    for(UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        AoHardware.OpenLoopbackMux(ucSlotNum,TRUE);
        if(FALSE == (bResult = SLOT(ucSlotNum)->ComputeCalibrationConstants(
                                                (SLOT(ucSlotNum)->GetB1L() / 
                                                 fOldSlope * CalibData.FactorySlope),
                                                 SLOT(ucSlotNum)->GetB0L()))) {
            AoHardware.CloseLoopbackMux(ucSlotNum);
            break;
        }
        AoHardware.CloseLoopbackMux(ucSlotNum);
     }//for loop for all channels
    EnableOutputs();
    return bResult;
}
/*******************************************************************************
*                           DoSuccessiveApproximation                          *
*                           =========================                          *
* PURPOSE:                                                                     *
*   Does 10 successive approximation A/D conversions by writing to the         *
*   loopback DAC. Averages the 10 readings together by subtracting min and max *
*   values and then dividing the sum by 8                                      *  
*                                                                              *    
* ARGUMENTS: None.                                                             *
* RETURN: UINT16 Contains averaged digital value on exit.                      *
* NOTES:                                                                       *
*        Required set up is to select the multiplexer for desired input and    *
*        wait until the multiplexer and DAC have settled.                      *                                                          *
*******************************************************************************/
#ifdef DEBUG
FLOAT32 clsAohBoxSlot::DoSuccessiveApproximation(BOOL a_bPrint) {
#else
FLOAT32 clsAohBoxSlot::DoSuccessiveApproximation(BOOL) {
#endif
    const UINT8 ADC_ITERATIONS = 10;
    const UINT8 ADC_FINERESOLUTION_COUNT = 5;

    UINT16 usSelectedbit,usAdcDigVal;
    UINT32 ulSumAdcDigVals = 0;
    UINT16 usMaxCount = 0x0000;
    UINT16 usMinCount = MAXUINT16;
    
    for (UINT8 ucIterations = 0; ucIterations < ADC_ITERATIONS; ucIterations++) {
        usAdcDigVal   = 0;
        usSelectedbit = 0x0800;
        for(UINT8 ucCnt = 0;ucCnt < DAC_RESOLUTION; ucCnt++) {
            usAdcDigVal += usSelectedbit;
#if !LOWCOST
            AoHardware.DriveDac(usAdcDigVal);
#else
            AoHardware.DriveDac(usAdcDigVal,READBACK_DAC_ADDR);
            IdleWait(COMPARATOR_SETTLE_TIME);   // Wait before reading comparator output
#endif
            if(AoHardware.ReadComparatorOutput()) { //Is it more?
                usAdcDigVal -= usSelectedbit;//Reduce it
            }
            //divide bit selector by 2
            usSelectedbit >>= 1;
        }
        usAdcDigVal -= 2;
        for(UINT8 ucCnt = 0; ucCnt < ADC_FINERESOLUTION_COUNT; ucCnt++) {
#if !LOWCOST
            AoHardware.DriveDac(usAdcDigVal);
#else
            AoHardware.DriveDac(usAdcDigVal,READBACK_DAC_ADDR);
            IdleWait(COMPARATOR_SETTLE_TIME);   // Wait before reading comparator output
#endif
            if(AoHardware.ReadComparatorOutput()) {
                usAdcDigVal-- ;
                break;
            }
            else {
                usAdcDigVal++;
            }
        }
        if(usAdcDigVal > usMaxCount) usMaxCount = usAdcDigVal;
        if(usAdcDigVal < usMinCount) usMinCount = usAdcDigVal;
#ifdef DEBUG
        if (a_bPrint) while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                             "\n\r\t%d\t: 0x%x",(ucIterations + 1),usAdcDigVal));
#endif
        ulSumAdcDigVals += usAdcDigVal;
    }
    ulSumAdcDigVals -= (usMaxCount + usMinCount);
    //TBD : Subtract the HiZero value from the computed DAC count 
    //Average it by samples of 10 and return
#ifdef DEBUG
    g_usMaxLpbkCount = usMaxCount;
    g_usMinLpbkCount = usMinCount;
#endif
    // Maximum and minimum samples are discarded. Return average of 8 values.
    return (ulSumAdcDigVals / (FLOAT32)(ADC_ITERATIONS - 2));
}

/*******************************************************************************
*                               CheckRefVoltage                                *
*                               ===============                                *
* PURPOSE: Checks for the sample voltage to be within valid ranges             *
*                                                                              *
* ARGUMENTS: DAC count for sample voltage                                      *
* RETURN: TRUE if successful, FALSE otherwise                                  *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsAohBoxSlot::CheckRefVoltage(UINT16 usVoltageLimit) {
#if !LOWCOST
    AoHardware.DriveDac(usVoltageLimit);
#else
    AoHardware.DriveDac(usVoltageLimit,READBACK_DAC_ADDR);
    IdleWait(COMPARATOR_SETTLE_TIME);   // Wait before reading comparator output
#endif
    BOOL bChkRefVoltagests = AoHardware.ReadComparatorOutput();
    if( (MIN_ONE_V_OUTPUT_DACCOUNT        == usVoltageLimit) || 
        (MIN_FIVE_V_OUTPUT_DACCOUNT       == usVoltageLimit) ||
        (MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT == usVoltageLimit)) {
        bChkRefVoltagests = !bChkRefVoltagests; // Because the o/p should be low
    }
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,!bChkRefVoltagests,0);
    return bChkRefVoltagests;
}


/*******************************************************************************
*                        SetForPrimary                                         *
*                        =============                                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::SetForPrimary (VOID) {
    // set inhibit switches to prevent the other module from driving the outputs
    INH_SWA = SW_ON;
    INH_SWB = SW_ON;
    // set disable switches to allow outputs to be driven
    DIS_SWA_n = SW_ON;
    DIS_SWB_n = SW_ON;

    IdleWait(INH_READ_DELAY_TIME);

    // verify switch states
    AoHardware.VerifySwitchState(DIS_SWCH,DIS_ON_ON);
    AoHardware.VerifySwitchState(INH_SWCH,INH_ON_ON);
    ModStat3.OutCtl = OUTCTL_MINE;
}
/*******************************************************************************
*                        SetForSecondary                                       *
*                        ===============                                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::SetForSecondary (BOOL bDoCheck) {
    // Set disable switches to prevent outputs from being driven out
    DIS_SWA_n = SW_OFF;
    DIS_SWB_n = SW_OFF;
    // set inhibit switches to allow the other module to drive the outputs
    INH_SWA = SW_OFF;
    INH_SWB = SW_OFF;
    if (bDoCheck) { // verify switch states
        IdleWait(INH_READ_DELAY_TIME);
        AoHardware.VerifySwitchState(DIS_SWCH,DIS_OFF_OFF);
        AoHardware.VerifySwitchState(INH_SWCH,INH_OFF_OFF);
    }
    ModStat3.OutCtl = OUTCTL_PARTNER;
}
/*******************************************************************************
*                           clsAihBoxSlot::AppPostSync                         *
*                           ==========================                         *
*  AppPostSync is called from PostRedState for application specific actions    *
*  after a database dump.                                                      *
*  1) Drives the Op with value from opInternal in secondary module and resets  *
*     some of the counters needed in redundanct partner.                       *
*  2) Update number of 1-second channels in the case of secondary module.      *
*******************************************************************************/
VOID clsAohBoxSlot::AppPostSync(VOID) {
    ResetCurrentSlotNum();
    FLOAT32 fOpval=0;

    if(!Iol.AmPrimary()){ 
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++){
			// added below condition to fix 1-F1UPS9D (OP Value 0 instead of -6.9 during replacement of legacy with redesign module)
			if (BOX->GetOp(ucSlotNum) != OP_LOLIMIT) {
				fOpval = SLOT(ucSlotNum)->GetOpInternl();
				BOX->SetOp(ucSlotNum, fOpval);
			}
            //Skip the loopback check for 2 cycles
            SLOT(ucSlotNum)->ResetSkipLpBkTst(2);
        }
#if !LOWCOST
        // If this is secondary module, recompute and update the number of 
        // 1-second channels. If the number of 1-second channels exceeded the
        // maximum allowed due to a databse dump from old version IOM, raise
        // HART diagnostic underrun softfail.
        UINT8 uc1SecChans = 0;
        clsHartDevDb::SetNoOf1SecChannels(0);
        
        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
            if ((SLOT(ucChan)->GetPtExecSt() == PTEXECST_ACTIVE) &&
                ((HSCANCFG_1SECDEV == SLOT(ucChan)->GetHartCfgDb().HScanCfg) ||
                 (HSCANCFG_1SECDYN == SLOT(ucChan)->GetHartCfgDb().HScanCfg) ||
                 (HSCANCFG_2SECDEVDYN == SLOT(ucChan)->GetHartCfgDb().HScanCfg))) {
                uc1SecChans++;
            }
        }

        if (uc1SecChans > MAX_1SEC_CHANNELS) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_HDIAGTO,TRUE,0);
        }
        clsHartDevDb::SetNoOf1SecChannels(uc1SecChans);
#endif
        PartnersChkPntVer = 0;
    }
    else { //primary
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++)
        {
            //As the outputs were at the screws check then right away
            SLOT(ucSlotNum)->SetReadBackrequired(TRUE); 
            SLOT(ucSlotNum)->ResetSkipLpBkTst(0);
        }
        PartnersChkPntVer = 0;
    }
}
/*******************************************************************************
*                    AppColdInit                                               *
*                    ===========                                               *
* PURPOSE:  Initializes the database of each slots                             *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::AppColdInit(VOID) {
    if (MODSTATUS_RUN == ModStat1.Status) {
        ModStat1.Status = MODSTATUS_IDLE;
        AddModStatEvent(EVENTTYPE_NORMAL);
    }
    DbValid = DB_INVALID;
    ComputeCheckSum(); // Recompute BOX checksum
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        // Slot checksum is recomputed in InitSlot.
        SLOT(ucSlotNum)->InitSlot(TRUE);
    }
}
/*******************************************************************************
*                         clsAohBoxSlot::SwitchInit                            *
*                         =========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAohBoxSlot::SwitchInit (VOID) {
    //Allow one module to come up earlier than other module
    UINT8 ucDelay = (BOTTOM) ? 20000 : DIS_READ_DELAY_TIME;       // compute variable delay (us)

    if (INHIN_NEGATED == INHIN_FB_n){     // partner is not controlling screws
        if (BURIN_ASSERTED == GetPartnersBackupStatus()) {          // partner asserting BUPREQ
            if (INHIN_NEGATED == INHIN_FB_n){// partner still not have screws
                IdleWait(ucDelay);                         // wait for some delay time
                if (INHIN_NEGATED == INHIN_FB_n) { // partnr does not have screws
                    //Shut off the partner outputs from driving the outputs
                    INH_SWA = SW_ON;
                    INH_SWB = SW_ON;
                    IdleWait(ucDelay);   // wait for inhibit switches some delay time
                    if(INHIN_NEGATED == INHIN_FB_n)
                    {
                        SetForPrimary();              // assume role as primary
                        return TRUE;                  // exit finished
                    }
                    else{
                        INH_SWA = SW_OFF;        // relinquish control of screws
                        INH_SWB = SW_OFF;
                        IdleWait(ucDelay);          // wait for some delay time
                        return FALSE;                         // exit unfinished
                    }
                }
                else {                         // partner is controlling screws
                    SetForSecondary(TRUE);      // assume role as backup module
                    return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                               // exit unfinished
            }
        }// partner asserting BUPREQ
        else {
            IdleWait(ucDelay);                      // wait for some delay time
            if (INHIN_NEGATED == INHIN_FB_n) {    // partner does not have screws
                if (BURIN_ASSERTED == GetPartnersBackupStatus()) {  // partner asserting BUPREQ
                    return FALSE;                            // exit unfinished
                }
                else {                       // partner is not asserting BUPREQ
                        SetForPrimary(); 
                        return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                                // exit unfinished
            }
        }
    }
    else {                                 // partner is controlling the screws
        IdleWait (ucDelay);                         // wait for some delay time
        if (INHIN_NEGATED == INHIN_FB_n) {  // partner does not have screws
            return FALSE;                                    // exit unfinished
        }
        else {                             // partner is controlling the screws
            SetForSecondary(TRUE);              // assume role as backup module
            return TRUE;                                       // exit finished
        }
    }
}
/*******************************************************************************
*                     clsAohBoxSlot::CheckFailOverCondition                    *
*                     =====================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::CheckFailOverCondition(VOID) {
#if LOWCOST
    UINT8 ucSwitchStatus = SWITCH_STATUS_REGISTER;
    BOOL bTstSave = (ucSwitchStatus & TST);  // Save state of TST switch from CPLD Register
#else
    BOOL bTstSave = TST_n; // Save state of TST switch
#endif

    // added this block as per legacy FW (NEGATE_BKPREQ), to fix the following PAR,
    // PAR# 1-E2KA8ZT (modules swapover/failover is not working during OP fail)
    // added LastSfCode checking to fix OP drop time (>20ms) during swapover without any sfails.
#if defined(IOPTYPE_AO16)    
    
    if ((SWBUREQ_ASSERT == SWBUREQ_n) && (SF_OUTPUTFL == LastSfCode)) // requesting partner for backup (REDDATA_BURQST = 1)
    {
        if (GetPartnersBackupStatus() == ASSERTED) // partner requested for backup (BUPREQ_IN = 1)
        {
            ResetRedData(REDDATA_BURQST);
        }
        else
        {
            SetRedData(REDDATA_BURQST);
        }

        UINT8 ucSFailExists = 0;

        for (int i = 0; i < SFBYTES_SIZE; i++)
        {
            ucSFailExists |= (SfActionTbl[i] & BoxSfBits[i]);
        }

        if ((0 == ucSFailExists) && (0 == ucOutputFailCounter) && (GetRedState() != REDSTATE_IOL_TIMEOUT))
        {
            SetRedData(REDDATA_SFFOEN);
            NegateBackup();
        }
    }
    else
    {
        ResetRedData(REDDATA_BURQST);
    }

    // OPEN_WIRE_PRC (from legacy FW)
    if (Iol.AmPrimary())
    {
        LastSfCode = (SWBUREQ_ASSERT == SWBUREQ_n) ? SfCodeLrs : SF_UNKNOWN;
    }
    // secondary
    else if ((SWBUREQ_DEASSERT == SWBUREQ_n)           // i am not asserted for backup
         && (GetPartnersBackupStatus() == DEASSERTED)) // my partner not asserted for backup
    {
        LastSfCode = SF_UNKNOWN;
    }
#endif


    if (!(BOX->CheckForFactoryTestMode())) { 
        TST_n = TSTn_DISABLED;
    }
    if (ModStat3.OutCtl == OUTCTL_PARTNER) {  // I do not have ctl of the screws
        
#if defined(IOPTYPE_AO16) && !defined(HART_SUPPORT)
        // fix for the PAR# 1-ELMDMA4 (OP drop time > 20ms, during redundant modules failover) 
        // disabled to make OP drop time <= 20ms as per specs (as per legacy)
        // cause: Sometimes BUPREQ_IN not asserting morethan 20ms during FTA removal
//      if (BURIN_ASSERTED == BUPREQ_IN)        
        if (!REDUNT_n) // FTA present
#else
        if ((BURIN_ASSERTED == BUPREQ_IN) && (!REDUNT_n)) // partner asserting for backup and FTA present
#endif
        {     // my partner has asserted BUPREQ
            if (INHIN_NEGATED == INHIN_FB_n) { // and it has given up the screws
                IdleWait(50);
                if (INHIN_NEGATED == INHIN_FB_n) {// partner still does not have
                    if (BUREQ_NEGATED == SWBUREQ_n) { // and i have negated BURQ
                        SetForPrimary();

                        if (REDSTATE_FO_IN_PROG == GetRedState())
                            SetRedState(REDSTATE_FO_COMPLETE);
                    }
#if defined(IOPTYPE_AO16)
                    // 1. added this condition to fix the following PAR
                    //    PAR# 1-E35JRDA (OP drop time more than specified (20ms) during failover with OP Fail (during SEC comes from SFAIL/SYNCD to OK/SYNCD))
                    // 2. added FTA Return timeout condition to fix the above PAR, during SEC FTA just returned but in timeout, with PRI FTA already failed condition
                    else if ((LastSfCode == SF_OUTPUTFL)    // existing SF_OUTPUTFL
                         &&  (!REDUNT_n)                    // FTA present
                         &&  (uiFtaReturnTimeout > 0))        // FTA return but in timeout
                    {
                        SetForPrimary();

                        if (REDSTATE_FO_IN_PROG == GetRedState())
                            SetRedState(REDSTATE_FO_COMPLETE);
                    }
#endif
                }
            }
        }
        // added this block as per legacy FW (FLOV_CND), to fix the following PAR,
        // PAR# 1-E2KA8ZT (modules swapover/failover is not working during OP fail)
#if defined(IOPTYPE_AO16)
        if ((BURIN_ASSERTED == BUPREQ_IN)        // my partner asserted for backup
        &&  (SWBUREQ_DEASSERT == SWBUREQ_n)     // i am not asserting for backup
        &&  (GetRedState() == REDSTATE_SYNCD)    // sync state
        &&  (LastSfCode != SF_OUTPUTFL))        // no last output fail sfail
        {
            TST_n = TSTn_ENABLED;
            //Shut off the partner outputs from driving the outputs
            INH_SWA = SW_ON;
            INH_SWB = SW_ON;
            IdleWait(300);         // wait for inhibit switches some delay time
            TST_n = TSTn_DISABLED; // To read INHIN, Change Tst SWs to OFF.
            if ((GetFtaPres()) && (INHIN_NEGATED != INHIN_FB_n))
            {
                INH_SWA = SW_OFF;        // relinquish control of screws
                INH_SWB = SW_OFF;
            }

            if (INHIN_NEGATED == INHIN_FB_n) { // and it has given up the screws
                //IdleWait(50);
                if (INHIN_NEGATED == INHIN_FB_n) {// partner still does not have
                    // If at this point the expected FO sequence did not occur
                    // properly. So save the state of the BUREQ's & REDSTATE
                    // Then take control of the field terminations
                    SetForPrimary();
                    if (REDSTATE_FO_IN_PROG == GetRedState())
                        SetRedState(REDSTATE_FO_COMPLETE);
                }
            }
        }
        else
        {
            // Swap process is failure.
            //INH_SWA = SW_OFF;        // relinquish control of screws
            //INH_SWB = SW_OFF;
        }
#endif

        if (Iol.AmPrimary()) 
        {
#if defined(IOPTYPE_AO16)
            // added, when redesign module fails to swapover/failover from SEC to PRI with Legacy as partner
            // as per PMIO, PRI module should first takeover the output control than SEC.                        
            TST_n = TSTn_ENABLED;
            //Shut off the partner outputs from driving the outputs
            INH_SWA = SW_ON;
            INH_SWB = SW_ON;
            IdleWait(5000);        // wait for inhibit switches some delay time
            TST_n = TSTn_DISABLED; // To read INHIN, Change Tst SWs to OFF.
            if (INHIN_NEGATED != INHIN_FB_n)
            {
                INH_SWA = SW_OFF;        // relinquish control of screws
                INH_SWB = SW_OFF;
            }                
#endif
            if (INHIN_NEGATED == INHIN_FB_n) // and it has given up the screws
            { 
                //IdleWait(50);
                if (INHIN_NEGATED == INHIN_FB_n) // partner still does not have
                {
                    // If at this point the expected FO sequence did not occur
                    // properly. So save the state of the BUREQ's & REDSTATE
                    // Then take control of the field terminations
                    SetForPrimary();
                    if (REDSTATE_FO_IN_PROG == GetRedState())
                        SetRedState(REDSTATE_FO_COMPLETE);
                }
            }
        }
    }
    else if (!Iol.AmPrimary()) {                // I have control of the screws
                                                   // and have started failover
        if (BUREQ_ASSERTED == SWBUREQ_n) {          // If I am asserting BUPREQ
#if defined(IOPTYPE_AO16)
            // if FTA missing or my partner is not asserting BUPREQ
            if (!(GetFtaPres())||(BURIN_NEGATED == BUPREQ_IN)) {
#else
            if (BURIN_NEGATED == BUPREQ_IN) {          // and my partner is not
#endif
                SetForSecondary(TRUE);          // assume role of backup module
            }
        }
    }
    // added these conditions to fix the following PAR,
    // PAR# 1-E35JRDA (OP drop time more than specified (20ms) during failover with OP Fail
#if defined(IOPTYPE_AO16)
    // if i am primary, & outputs are in my control
    // At that instance of FTA removed, immediately drop the outputs & its DSA     
    else if ((REDUNT_n) && (LastSfCode == SF_OUTPUTFL))
    {
        Iol.DropDSA();
        BOX->SetDSA(0);
        SetForSecondary(TRUE);
    }
    // added this block as per legacy FW (FLOV_CND), to fix the following PAR,
    // PAR# 1-E2KA8ZT (modules swapover/failover is not working during OP fail)
    else if ((INHIN_NEGATED != INHIN_FB_n) 
         && (GetMyBackupStatus() == ASSERTED) 
         && (GetPartnersBackupStatus() == DEASSERTED))
    {
        Iol.DropDSA();
        BOX->SetDSA(0);
        SetForSecondary(TRUE);
    }
#endif

#if LOWCOST        // Restore state of TST switch into CPLD register
    TST_n = !bTstSave;
#else
    TST_n = bTstSave;                            // Restore state of TST switch
#endif
}
/*******************************************************************************
*                           clsAohBoxSlot::AppPostSwap                         *
*                           ==========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::AppPostSwap(VOID) {
    //Change the Module switch state to secondary state
    //This change will avoid the switches to be operated twice when the 
    //modules chnages the role.
    SetForSecondary(TRUE);
}

VOID clsAohBoxSlot::AppPreDump(VOID) { 
    if(Iol.AmPrimary())
        PartnersChkPntVer = LATEST_SLTCHKPNT_VERSION;
    else
        PartnersChkPntVer = 0;
}

VOID clsAohBoxSlot::AppPostDump(VOID) { 
    bDisOpInternlUpdte = TRUE;
	/*
    if(!Iol.AmPrimary()) {
        if(PartnersChkPntVer < LATEST_SLTCHKPNT_VERSION)
        {
            for(UINT8 ucItr = 1;ucItr <= MAXSLOTS;ucItr++) {
                SLOT(ucItr)->Hart7Dump();
            }
        }
    }*/
}

