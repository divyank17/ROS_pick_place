/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohardware.hpp                                              *
*    Description : Analog output hardware encapsulation.                       *
*******************************************************************************/
#ifndef __LLHARDWARE_HPP__
#define __LLHARDWARE_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
#include "scheduler.hpp"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8  SCIMSGSIZE = sizeof(UINT32);
/*******************************************************************************
*                                   DEFINES                                    *
*******************************************************************************/
typedef union tagSciMessage {
    struct {
        UINT32          : 1;
        UINT32 Const    : 1;
        UINT32          : 1;
        UINT32 FtaId    : 1;
        UINT32 Command  : 4;
        UINT32          : 4;
        UINT32 ChanNum  : 4;
        UINT32 OtdEn    : 1;
        UINT32 Data     : 7;
        UINT32 CheckSum : 8;
    };
    UINT32 LONG;
    UINT8  BYTE[SCIMSGSIZE];
} SCIMESSAGE;

typedef union tagSciResponse {
    struct {
        UINT32 PtDataFlag : 1;
        UINT32            : 1;
        UINT32 FtaType    : 1;
        UINT32 FtaId      : 1;
        UINT32 Status     : 4;
        UINT32 ErrorMap   : 16;
        UINT32 CheckSum   : 8;
    };
    UINT32 LONG;
    UINT8  BYTE[SCIMSGSIZE];
} SCIRESPONSE;

typedef union tagSciPtDataResponse {
    struct {
        UINT32          : 1;
        UINT32 Sign     : 1;
        UINT32 FtaType  : 1;
        UINT32 FtaId    : 1;
        UINT32 ChanNum  : 4;
        UINT32 PtData   : 16;
        UINT32 CheckSum : 8;
    };
    UINT32 LONG;
    UINT8  BYTE[SCIMSGSIZE];
} SCIPTDATARESPONSE;

typedef enum SCI_CMDS{
    REQ_INVALID        = 0x0,
    REQ_STATUS         = 0x1,
    REQ_SCANCOMPLETE   = 0x2,
    REQ_STARTSCAN      = 0x3,
    REQ_LOADCONFIGDATA = 0x4,
    REQ_FREQSEL        = 0x5,
    REQ_CALIBRATE      = 0x6,
    REQ_POINTDATA      = 0x7,
    REQ_ATEDATACMD     = 0x8,
    REQ_DECONFIGPOINT  = 0x9
}SCI_CMDS;

//Errors conditions in IOM after Rx/No Rx from FTA
typedef enum SCI_RXSTATUS{
    STATUS_ACK             = 0x0,
    STATUS_CALIBINPROGRESS = 0x1,
    STATUS_VREF_FAILURE    = 0x2,
    STATUS_SCANINPROGRESS  = 0x3,
    STATUS_NACK            = 0x4,
    STATUS_CALIBFAILURE    = 0x5,
    STATUS_BADCHECKSUM     = 0x6,
    STATUS_WRONGUNITID     = 0x7,
    STATUS_ACKNOCALIB      = 0x8,
    STATUS_TIMEOUT         = 0x9 //No response from FTA
}SCI_RXSTATUS;
/*******************************************************************************
*                                   clsLLMuxHardware                           *
*******************************************************************************/
class clsLLMuxHardware {
private:
    clsLLMuxHardware(const clsLLMuxHardware&);            // Safeguard against default copy constructor.
    clsLLMuxHardware& operator=(const clsLLMuxHardware&); // Sefeguard against default assignment.

    SCIRESPONSE  Response[NO_OF_FTA];
    SCI_CMDS     CommandHistory[NO_OF_FTA];
    BOOL         TimeoutFlag[NO_OF_FTA];
    UINT32       RequestTrace[NO_OF_FTA]; //TBD: Temporary for debugging
public:
    clsLLMuxHardware();
    ~clsLLMuxHardware(VOID)      { HardFail(HF_INVPROGRAMEXEC,LLHARDWARE_HPP,__LINE__); }
    VOID *operator new(UINT32)   { HardFail(HF_INVPROGRAMEXEC,LLHARDWARE_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,LLHARDWARE_HPP,__LINE__); }

    inline SCIRESPONSE  GetResponse(UINT8 Fta)     { return Response[Fta];       }
    inline SCI_CMDS     GetLastRequest(UINT8 Fta)  { return CommandHistory[Fta]; }
    inline BOOL         GetTimeoutFlag(UINT8 Fta)  { return TimeoutFlag[Fta];    }
    inline UINT32       GetRequestTrace(UINT8 Fta) { return RequestTrace[Fta];   }//TBD: Temporary for debugging

    inline VOID SetTimeoutFlag(UINT8 Fta,SCI_RXSTATUS Status) { TimeoutFlag[Fta] = Status;}

    VOID  Initialize(VOID);
    VOID  CreateAndSendRequest(UINT8,SCI_CMDS,UINT8=0);
    VOID  SendRequest(UINT8,UINT32);
    VOID  CopyRxFromFifo(UINT8);
    UINT8 ComputeChecksum(UINT32);
};

#endif

