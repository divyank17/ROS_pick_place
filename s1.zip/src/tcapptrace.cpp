/*******************************************************************************
*                                HTS Bangalore 2010.                           *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                           HONEYWELL PROCESS SOLUTIONS                        *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcapptrace.cpp                                                *
*    Description : Implements tracelog fifo in shared ram                      *
*******************************************************************************/

#include "tcapptrace.h"

#ifdef IOMTYPE_SVP
	#include "svpmain.h"
#endif

#ifdef IOMTYPE_SP
	#include "spmain.h"
#endif

/*******************************************************************************
*                            clsTraceLog::clsTraceLog                          *
*                            ========================                          *
*  Constructor. TraceLog Class Data members are initialize only when IOM is    *
*  power recycled. Trace memory is preserved so when it is restarted by        *
*  pressing reset button to recover from a hard failure.                       *
*******************************************************************************/
clsAppTraceLog::clsAppTraceLog(VOID)
{
    // Do nothing on H8S.
#ifdef DSC
    // Preserve tracelogs after an iom triggered hardfail.
    if (FALSE == IomRebooted())
    {
        // Initialize object only in case of power-on-restart.
        m_TraceLevel = 0;
        m_uAppIndex = 0;
        m_Flags = 0;

        for (UINT16 uCount = 0; uCount < TRACE_BUFFER_SIZE_WORDS; ++uCount) 
        {
            TraceRecordBuffer[uCount] = 0;
        }
        clsBoxSlot::ResetTraceLogTime();
    }
#endif
}
#ifdef DSC
///
/// Macro to write a Trace Record word by word.
/// cannot treat it as a struct on DSC side.
/// because of the even word alignment.
/// A note on endianness.
/// H8S uses big endian BYTE ordering.
/// DSC uses little endian WORD ordering.(DSC cannot access single bytes)
/// So four consecutive bytes having
/// 01,02,03,and 04 represent 32 bit integer 
/// 0x01020304 on H8S,
/// 0x03040102 on DSC and
/// 0x04030201 on x86
///
/// Note:((x << 2) + x) = 5 * x
#define _SetTraceRecord(_idx,_code16,_data32,_time32) {\
    UINT16* pDest = (TraceRecordBuffer+(((_idx)<<2) + _idx));/*_idx * 5*/\
    *pDest++ = (_code16);\
    *pDest++ = ((UINT16)(_data32>>16));\
    *pDest++ = ((UINT16)(_data32));\
    *pDest++ = ((UINT16)(_time32>>16));\
    *pDest   = ((UINT16)(_time32));\
}

/// copy trace record as 5 UINT16s.
#define _CopyTraceRecord(_dst_idx,_src_idx) {\
    UINT16* pSrc  = (TraceRecordBuffer+(((_src_idx)<<2) + _src_idx));\
    UINT16* pDest = (TraceRecordBuffer+(((_dst_idx)<<2) + _dst_idx));\
    *pDest++ = *pSrc++;\
    *pDest++ = *pSrc++;\
    *pDest++ = *pSrc++;\
    *pDest++ = *pSrc++;\
    *pDest   = *pSrc;\
}

/*******************************************************************************
*                            clsTraceLog::AddToTrace                           *
*                            =======================                           *
*  Adds traces to the tracelog table and updates the append index.             *
*******************************************************************************/
VOID clsAppTraceLog::AddToTrace( APPTRACEID a_TraceId,APPBreadCrumb crumb,UINT32 data)
{ 
    /// do not log anything when iol processor is copying stuff
    if(m_Flags & COPY_IN_PROGRESS)
        return;
    ///
    if ((TRACEID_GENERIC == a_TraceId) || (a_TraceId & m_TraceLevel))
    {   //
        _DISABLE_INTERRUPTS();
        //
        UINT16 uIndex = m_uAppIndex;   // Reserve index for this log
        // Check for wrap around and update current index. 
        // Do not allow to overwrite crash traces.
        m_uAppIndex = (LASTTRACEINDEX <= m_uAppIndex) ? 0 : (m_uAppIndex+1);
        //
        _ENABLE_INTERRUPTS();
        // Log the trace.
        UINT32 time = clsBoxSlot::GetTraceLogTime();
        _SetTraceRecord(uIndex,crumb,data,time);//macro
    }
}
/*******************************************************************************
*                          clsTraceLog::CopyCrashTraceBlock                    *
*                          ================================                    *
*  Copies the last 20 traces to crash block (records 80-100) which is an area  *
*  that will never be overwritten by the new traces. Called from HardFail.     *
*******************************************************************************/
VOID clsAppTraceLog::CopyCrashTraceBlock(VOID) 
{
    INT16 iSrcIndex = 0,iDstIndex = (CRASHBLKSTARTINDEX+CRASHBLOCKSIZE-1);//80+19

    iSrcIndex = m_uAppIndex-1;// m_uAppIndex is empty.
    for(INT16 iIndex = (CRASHBLOCKSIZE-1);iIndex>=0;--iIndex)
    {
        if(iSrcIndex < 0)
        {   /// roll over from 0 to 79
            iSrcIndex = LASTTRACEINDEX;
        }

        _CopyTraceRecord(iDstIndex,iSrcIndex);//macro

        --iDstIndex;
        --iSrcIndex;
    }
return;
}

/*******************************************************************************
*                          clsAppTraceLog::IomRebooted                         *
*                          ================================                    *
* Check a shared memory location updated by IOL bootimage based                *
* on value of RIP_n                                                            *
*******************************************************************************/
BOOL clsAppTraceLog::IomRebooted(VOID)
{
    return ((GetCommonSharedData(CMN_SHARE_IOM_REBOOTED_IDX))? TRUE : FALSE);
}

#endif //DSC

//
// Support for reading arbitrary mem locations using TESTPARAM.
//
extern SHRAMDATA ShramData;
extern UINT16* gIomDbMemoryEndPtr;
///
void InitTestParam(void)
{
    // fill test pattern
    for(UINT16 i = 0; i < TESTPARAM_BUFFER_SIZE; ++i)
        pSharedData->ArrTestParam[i] = 0;
    // Initialize
    MarkCopyComplete();
}
///
UINT16* GetTestParamPtr(void)
{
    return (UINT16*)((pSharedData)? pSharedData->ArrTestParam : NULL);
}
///
UINT32 GetTestParamUint32(const UINT16 param_idx)
{
    UINT32 retval = TESTPARAM_INVALID_VALUE32;// 0xFFFFFFFF
    //
    if(pSharedData && (param_idx < (TESTPARAM_BUFFER_SIZE/2)))
    {
        // Shared ram values are stored in H8S byte ordering
        #if defined (H8S)
            // Directly assign 
            retval = *(((UINT32*)(pSharedData->ArrTestParam)) + param_idx);
        #elif defined (DSC) 
            // swap words and assign.
            UINT32 tempval = *(((UINT32*)(pSharedData->ArrTestParam)) + param_idx);
            retval = ((tempval<<16)|(tempval>>16));
        #endif
    }
return retval;
}
///
void WriteTestParamUint32(const UINT16 param_idx, const UINT32 value)
{
    if(pSharedData && (param_idx < (TESTPARAM_BUFFER_SIZE/2)))
    {
        UINT32* dest_addr = ((UINT32*)(pSharedData->ArrTestParam)) + param_idx;
        // write in BE byte ordering which is what H8S uses.
        #if defined (H8S)
            // 0x01020304 is { 01,02,03,04 } on H8S .Directly assign 
            *dest_addr = value;
        #elif defined (DSC) 
            // 0x01020304 is { 03,04,01,02 } on DSC .Swap words and assign.
            *dest_addr = ((value<<16)|(value>>16));
        #endif
    }
}
///
void CopyToTestParam(volatile UINT16* psrc, UINT16 len)
{
    UINT16 didx,sidx=0;
    len += TESTPARAM_DATA_START_IDX;
    /// cannot write more than the buffer size.
    if(len > TESTPARAM_BUFFER_SIZE)
        len = TESTPARAM_BUFFER_SIZE;
    /// Fill data upto len words
    for( didx = TESTPARAM_DATA_START_IDX; didx < len; ++didx)
        pSharedData->ArrTestParam[didx] = psrc[sidx++];
    /// Fill rest with 0xFFFF.
    if(len < TESTPARAM_BUFFER_SIZE)
        for( didx = len; didx < TESTPARAM_BUFFER_SIZE; ++didx)
            pSharedData->ArrTestParam[didx] = 0xFFFF;
}
///
void MarkCopyComplete(void)
{   /// mark copy complete.
    pSharedData->ArrTestParam[TESTPARAM_RESP_IDX] = TESTPARAM_ACK_PATTERN;
}
///
BOOL IsReadRequested(void) 
{   /// check whether user requested a read.
    return (TESTPARAM_ACK_PATTERN != pSharedData->ArrTestParam[TESTPARAM_RESP_IDX])? TRUE:FALSE;
}
///
void ProcessTestParams(void)
{
    if(FALSE != IsReadRequested())
    {   // Validate input slotnum.
        // MAXSLOTS is defined separately for both IOL and APP image.
        UINT16  slotnum  = pSharedData->ArrTestParam[TESTPARAM_SLOTNUM_IDX] - TESTPARAM_MIN_SLOT_OFFSET;
        UINT16  blockidx = pSharedData->ArrTestParam[TESTPARAM_MEM_BLOCK_IDX];
        //
        UINT16* psrc = NULL;
        if(slotnum < (MAXSLOTS+1))
        {
            psrc = (((UINT16*)(pDatabase[slotnum])) + (TESTPARAM_DATA_LEN*blockidx));
            /**/
            if(gIomDbMemoryEndPtr > psrc)
            {
                // if last block copy only valid part
                // note: it is possible to specify some slot number and read another
                // slot's memory by specifying a big block idx.however this is 
                // not possible in case of last slot
                if((psrc + TESTPARAM_DATA_LEN) > gIomDbMemoryEndPtr)
                {
                    CopyToTestParam((volatile UINT16*)psrc, (gIomDbMemoryEndPtr - psrc));
                }
                else
                {
                    CopyToTestParam((volatile UINT16*)psrc, TESTPARAM_DATA_LEN);
                }
            }
            MarkCopyComplete();
        }
        else if(TESTPARAM_FPGA_SLOT == pSharedData->ArrTestParam[TESTPARAM_SLOTNUM_IDX])
        {   /// Note:It is possible to expose FPGA shared data as it is seen from 
            /// either H8S or DSC.
            UINT16* FpgaSharedRamStartAddr = ((UINT16*)&ShramData);
            UINT16* FpgaSharedRamEndAddr = FpgaSharedRamStartAddr+word_sizeof(ShramData);
            //
            if((TESTPARAM_DATA_LEN*blockidx) < word_sizeof(ShramData))
            {
                psrc = FpgaSharedRamStartAddr + TESTPARAM_DATA_LEN*blockidx;
                // if last block copy only valid part
                if((psrc + TESTPARAM_DATA_LEN) > FpgaSharedRamEndAddr)
                {
                    CopyToTestParam((volatile UINT16*)psrc, (FpgaSharedRamEndAddr-psrc));
                }
                else
                {
                    CopyToTestParam((volatile UINT16*)psrc, TESTPARAM_DATA_LEN);
                }
            }
            MarkCopyComplete();
        }
        else if(TESTPARAM_CPLD_SLOT == pSharedData->ArrTestParam[TESTPARAM_SLOTNUM_IDX])
        {   // TODO: read and expose CPLD register values here. 
            MarkCopyComplete();
        }
        // else the read request is for the other processor.
        // do nothing.
    }
}
///

