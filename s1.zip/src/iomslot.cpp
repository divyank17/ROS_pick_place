/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iomslot.cpp                                                 *
*    Description : Contain IOM database interface functions common to all IOMs.*
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "iomslot.hpp"
#include "boxslot.hpp"
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
extern clsHartPst *pHartPst[];

#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
extern bool bHartDataDump;
#endif

#endif
DATABYTES clsIomSlot::Data;
UINT8 clsIomSlot::ScratchPad;
UINT8 clsIomSlot::WriteIndex;
PASTATUS clsIomSlot::ucSaveChkpntPaStatus = PA_OK;

#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
    extern clsShramWriteMsgQueue ShramWriteMsgQueue;
    extern UINT8 ucShramWriteMsgNumber; //Shared Ram write message number
    #define LATEST_SLTCHKPNT_VERSION GetLatestSlotChkpntVersion() 
#endif

#ifdef IOMTYPE_UIO
    #define LATEST_SLTCHKPNT_VERSION  GetLatestSlotChkPntVersion()
    #define PARAMID_SLTCHKPNT GetSlotChkPntParamId()
    #define PARAMID_PTEXECST GetPtExecStParamId()
#endif
/*******************************************************************************
*                          clsIomSlot::ReadParamData                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsIomSlot::ReadParamData(UINT8 *a_ReadBuffer,UINT8 a_ucParamNumber) {
    UINT8 *pSource = GetParamPtr(a_ucParamNumber);
    // Copy parameter data from object memory to read buffer.
    // Check write-in-progress semaphore for non-atomic (multi-byte) data.
    switch (GetAccessType(a_ucParamNumber)) {
    case AT_SBYTE:
        *a_ReadBuffer = *pSource;
        break;
    case AT_MBYTE:
#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
        if(ChanNum == 0 && BOX->IsScanRecordParameter(a_ucParamNumber))
        {
            BOX->FillScanRecord(a_ucParamNumber, a_ReadBuffer);
        }
        else
        {
            if (pSource == WriteInProgress.pDatabase) {
                pSource = (UINT8 *)WriteInProgress.pWriteBuffer;
            }
            for (UINT8 ucSize = GetParamSize(a_ucParamNumber); ucSize > 0; ucSize--) {
                *a_ReadBuffer++ = *pSource++;
            }
        }
        break;
#else
        if (pSource == WriteInProgress.pDatabase) {
            pSource = (UINT8 *)WriteInProgress.pWriteBuffer;
        }
#if !defined(IOPTYPE_SCIOM)
        // for PMIO redesign, NAN = 0xFFFFFFFF;       
        if ((GetParamSize(a_ucParamNumber) == sizeof(FLOAT32)) && (isnan(*(FLOAT32 *)pSource))
#if defined(IOPTYPE_DI)
            && (GetDataType(a_ucParamNumber) != DT_BLIND)
#endif
           )
        {
            for (UINT8 ucSize = GetParamSize(a_ucParamNumber); ucSize > 0; ucSize--)
                *a_ReadBuffer++ = 0xFF;
        }
        else
#endif
        for (UINT8 ucSize = GetParamSize(a_ucParamNumber); ucSize > 0; ucSize--) {
            *a_ReadBuffer++ = *pSource++;
        }
        break;
#endif
    case AT_PSET:
        while (*pSource) {
            UINT8 ucParamSize = GetParamSize(*pSource);
            UINT8 *pParamPtr = GetParamPtr(*pSource);
            if (ucParamSize > 1) {
                if (pParamPtr == WriteInProgress.pDatabase) {
                    pParamPtr = (UINT8 *)WriteInProgress.pWriteBuffer;
                }
#if !defined(IOPTYPE_SCIOM)

                // for PMIO redesign, NAN = 0xFFFFFFFF;
                if ((ucParamSize == sizeof(FLOAT32)) && (isnan(*(FLOAT32 *)pParamPtr))
#if defined(IOPTYPE_DO) || defined(IOPTYPE_DI)
                // added DI type to fix PAR# 1-EQ6GPG3 (Cust Issue: BW-50245 03217198 SF 03217199 DEER 03937644)
                // If you power on first 10 channel then it will trigger ON all the other channel
                 && (GetDataType(a_ucParamNumber) != DT_BLIND)
#endif
                 )
                {
                    for (UINT8 ucSize = ucParamSize; ucSize > 0; ucSize--) 
                        *a_ReadBuffer++ = 0xFF;             
                }
                else
#endif
                for (UINT8 ucSize = ucParamSize; ucSize > 0; ucSize--) {
                    *a_ReadBuffer++ = *pParamPtr++;
                }
            }
            else
            {
#if defined(IOPTYPE_AO16)
                // added to resolve, PAR#1-7WEJENK (INIT is always true while driving channels)
                if ((*pSource == PARAMID_INITREQ) || (*pSource == PARAMID_STDBYMAN))
                {
                    UINT16 uiBitIndex = 0x8000 >> (ChanNum - 1);
                    UINT16 *puiParamPtr = (UINT16 *)pParamPtr;                    

                    *a_ReadBuffer++ = ((*puiParamPtr & uiBitIndex) > 0) ? ON : OFF;
                }
                else
#endif
                *a_ReadBuffer++ = *pParamPtr;
            }
            pSource++;
        }
        // 1-225OHN [SCIO] STC OVERRUN on Series C HART AO during Auto-Checkpoint Saves
        // This problem happens due to large record size of Checkpoint parameter. The Iolink
        // interrupts holds STC interrupts while transmitting the data back to controller.
        // This may happen for other modules also although not seen. 
        // Reset m_ucStcOverrunCount to 1 when checkpoint read is in progress.
        if ((0 != ChanNum) && (PARAMID_SLTCHKPNT == a_ucParamNumber)) {
            TaskScheduler.SetStcOverrunCounter(1);
        }
        break;
    case AT_BXPACK:
        {
            // In this case, slot data is kept in box as a bitmap and 
            // pSource will be pointing to the the box database member 
            // where this data is kept. 
#if defined (IOMTYPE_UIO)
            *a_ReadBuffer = GetBit(*(UINT32 *)pSource, ChanNum - 1);
#else
            UINT8 ucBitIndex  = 0x80 >> ((ChanNum - 1) & 0x07);
            UINT8 ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
    
            if (pSource[ucByteIndex] & ucBitIndex) *a_ReadBuffer = TRUE;
            else *a_ReadBuffer = FALSE;
#endif
        }
        break;
    case AT_BXREC:
        // In this case, slot data is kept in box as a blind record. No need to
        // check WriteInProgress for this read as the interrupts are disabled
        // while write is performed on BXREC type data.
        for (UINT8 ucSize = GetParamSize(a_ucParamNumber); ucSize > 0; ucSize--) {
            *a_ReadBuffer++ = *pSource++;
        }
        break;
    default:
        //Invalid program execution
        HardFail(HF_BADPROGRAMJUMP,IOMSLOT_CPP,__LINE__);
    }
}
/*******************************************************************************
*                          clsIomSlot::ReadParamData                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsIomSlot::ReadParamData(UINT8 *a_ReadBuffer,UINT8 a_ucParamNumber,UINT8 a_ucIndex) {
    UINT8 *pSource = GetParamPtr(a_ucParamNumber);
    UINT8 ucSize = GetParamSize(a_ucParamNumber);

    pSource += ucSize * (a_ucIndex - 1);                   // index is one-based
    // Copy parameter data from object memory to read buffer.
    // Check write-in-progress semaphore for non-atomic (multi-byte) data.
    switch (GetAccessType(a_ucParamNumber)) {
    case AT_SBYTE:
        *a_ReadBuffer = *pSource;
        break;
    case AT_MBYTE:
        if (pSource == WriteInProgress.pDatabase) {
            pSource = (UINT8 *)WriteInProgress.pWriteBuffer;
        }
        for (; ucSize > 0; ucSize--) {
            *a_ReadBuffer++ = *pSource++;
        }
        break;
    case AT_BITPACK:
        {
            a_ucIndex--; // Convert index to zero-base.
            // Find byte offset. Note that shifting 3
            // bits to right is same as dividing by 8.
            UINT8 ucByteIndex = a_ucIndex >> 3;
            // Make the bit mask. Note that masking out last 3
            // bits is same as taking reminder after dividing by 8.
            UINT8 ucBitMask  = 0x01 << (a_ucIndex & 0x07);
            UINT8 *pSource = GetParamPtr(a_ucParamNumber);            
            *a_ReadBuffer = (*(pSource + ucByteIndex) & ucBitMask) ? TRUE : FALSE;
        }
        break;
    default:
        //Invalid program execution
        HardFail(HF_BADPROGRAMJUMP,IOMSLOT_CPP,__LINE__);
        break;
    }
}
/*******************************************************************************
*                          clsIomSlot::WriteParamData                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsIomSlot::WriteParamData(UINT8 *a_WriteBuffer,
                                    UINT8 a_ucParamNumber,
                                    UINT8 a_ucAccessLevel,
                                    BOOL  a_bDoChkSm) {
    PASTATUS PaStatus     = PA_OK;
    UINT8 ucParamSize     = GetParamSize(a_ucParamNumber);
    ACCESSLOCK AccessLock = GetAccessLock(a_ucParamNumber);
    ACCESSTYPE AccessType = GetAccessType(a_ucParamNumber);
#if !defined (IOMTYPE_UIO)
    UINT8 ucBitIndex;
    UINT8 ucByteIndex;
#endif // !defined (IOMTYPE_UIO)
    UINT8 ucMask;
    UINT8 ucSavePtExecSt,ucSaveModStat1,ucSaveExr = get_imask_exr();
    UINT8 *pDestination;

#ifdef IOMTYPE_SVP
//For SVP Box Parameters, Except MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ,IOLPROCSTATRESET,CALIBALL and CALIBOPT parameters,
//Pre, Post checks and data storage is done in IOLINK Processor itself
if((0 == ChanNum) && (a_ucParamNumber != PARAMID_SVP_MODSTAT1  && 
                      a_ucParamNumber != PARAMID_SVP_MODSTAT2  && 
                      a_ucParamNumber != PARAMID_BOXCHKPNT     && 
                      a_ucParamNumber != PARAMID_SVP_DBVALID   && 
                      a_ucParamNumber != PARAMID_SVP_EXCITFREQ &&
                      a_ucParamNumber != PARAMID_SVP_CALIBALL  &&
                      a_ucParamNumber != PARAMID_SVP_CALIBOPT  &&
                      a_ucParamNumber != PARAMID_APPPROCSTATRESET &&
                      a_ucParamNumber != PARAMID_SVP_SERVODRIVEOPT))
{
#endif
#ifdef IOMTYPE_SP
//For SP Box Parameters, Except MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ and CALIBALL parameters and SP AI and AO channels
//Pre, Post checks and data storage is done in IOLINK Processor itself
if(((0 == ChanNum) && (a_ucParamNumber != PARAMID_SP_MODSTAT1      && 
                       a_ucParamNumber != PARAMID_SP_MODSTAT2      &&
                       a_ucParamNumber != PARAMID_BOXCHKPNT        &&
                       a_ucParamNumber != PARAMID_SP_DBVALID       &&
                       a_ucParamNumber != PARAMID_SP_CALIBALL      &&
                       a_ucParamNumber != PARAMID_SP_RESETTRIP     &&
                       a_ucParamNumber != PARAMID_SP_REVROTCHNLA   &&
                       a_ucParamNumber != PARAMID_SP_REVROTCHNLB   &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEAVGAPP &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEMAXAPP &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEMINAPP &&
                       a_ucParamNumber != PARAMID_SP_STATRESETAPP)) || (ChanNum >= 1 && ChanNum <= 9))
{
#endif
    if ((0== ChanNum) && (PARAMID_BOXCHKPNT == a_ucParamNumber)) {
        ucSaveChkpntPaStatus = PA_OK;

#if !defined(IOPTYPE_SCIOM)
        // No Checkpoint version in PMIO
        // If checkpoint being restored is later than the currently supported version, 
        // accept only the part that the current firmware supports.
        pDestination = (UINT8 *)GetCheckPointPtr(LATEST_BOXCHKPNT_VERSION);
        ucParamSize = GetCheckPointSize(LATEST_BOXCHKPNT_VERSION);
#else
        if (*a_WriteBuffer > LATEST_BOXCHKPNT_VERSION) {
            // If checkpoint being restored is later than the currently supported version, 
            // accept only the part that the current firmware supports.
            pDestination = (UINT8 *) GetCheckPointPtr(LATEST_BOXCHKPNT_VERSION);
            ucParamSize = GetCheckPointSize(LATEST_BOXCHKPNT_VERSION);
            ucSaveChkpntPaStatus = DO_SLOT_CHECKPOINT_PARTIALLY_RESTORED;
        }
        else {
            // Checkpoint being restored is same as the current version or older.
            // Choose appropriate checkpoint record and size. NOTE: First byte
            // of the write buffer contains checkpoint version.
            pDestination = (UINT8 *) GetCheckPointPtr(*a_WriteBuffer);
            ucParamSize = GetCheckPointSize(*a_WriteBuffer);
        }
        // Change the version being written to the latest version supported.
        //Controller always calculates the checkpoint checksum for the latest version.
        //But IO calculates the checkpoint checksum based on the checkpoint version.
        //To avoid checksum mismatch, IO checkpoint version is changed to the latest. 
        *a_WriteBuffer = LATEST_BOXCHKPNT_VERSION;
#endif
    }
    if ((0 != ChanNum) && (PARAMID_SLTCHKPNT == a_ucParamNumber)) {
        ucSaveChkpntPaStatus = PA_OK;

#if !defined(IOPTYPE_SCIOM)
        // No Checkpoint version in PMIO
        // If checkpoint restored is later than the currently supported version, 
        // accept only the part that the current firmware supports.
        pDestination = (UINT8 *)GetCheckPointPtr(LATEST_SLTCHKPNT_VERSION);
        ucParamSize = GetCheckPointSize(LATEST_SLTCHKPNT_VERSION);
#else

        if (*a_WriteBuffer > LATEST_SLTCHKPNT_VERSION) {
            // If checkpoint restored is later than the currently supported version, 
            // accept only the part that the current firmware supports.
            pDestination = (UINT8 *) GetCheckPointPtr(LATEST_SLTCHKPNT_VERSION);
            ucParamSize = GetCheckPointSize(LATEST_SLTCHKPNT_VERSION);
            ucSaveChkpntPaStatus = DO_SLOT_CHECKPOINT_PARTIALLY_RESTORED;
        }
        else {
            // Checkpoint being restored is same as the current version or older.
            // Choose appropriate checkpoint record and size. NOTE: First byte
            // of the write buffer contains checkpoint version.
            pDestination = (UINT8 *) GetCheckPointPtr(*a_WriteBuffer);
            ucParamSize = GetCheckPointSize(*a_WriteBuffer);
        }
        // Change the version being written to the latest version supported.
        //Controller always calculates the checkpoint checksum for the latest version.
        //But IO calculates the checkpoint checksum based on the checkpoint version.
        //To avoid checksum mismatch, IO checkpoint version is changed to the latest. 
        *a_WriteBuffer = LATEST_SLTCHKPNT_VERSION;
#endif
    }

#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    else if (PARAMID_HBRDP == a_ucParamNumber) {
        if (0 == ChanNum) return DO_INVALID_SLOT_INDEX;
        // Release the handle first
        BOX->HNDLStatusTable[ChanNum-1].Handle = BRDPSESSION_CLOSE;
        // Check if any requests are pending against this channel and mark 
        // them as released.
        UINT16 usTemp = 1;

#if defined (IOMTYPE_UIO)
        UINT16 uiModemNumber = 0;

        if(ChanNum > SLOTSPERMODEM)
        {
            uiModemNumber = 1;
        }

        clsHartPst **pHartPst = clsHartPst::PassThroughTable(uiModemNumber);
#endif

        for (UINT8 ucCount=0;ucCount < MAXBRDPMSGS;ucCount++) {
            if (pHartPst[ucCount]->m_ucSlotNumber == ChanNum) {
                pHartPst[ucCount]->m_ucSlotNumber   = INVALID_SLOTNUM;
                pHartPst[ucCount]->m_ucHandle       = INVALID_HANDLE;
                pHartPst[ucCount]->m_PstStatus      = HPSTSTATUS_DEAD;
                pHartPst[ucCount]->m_ucPstMsgTimeout= 0;
#if defined (IOMTYPE_UIO)
                BOX->BRDPResourceStatus[uiModemNumber] &= ~usTemp;
#else
                BOX->BRDPResourceStatus &= ~usTemp;
#endif
            }
            usTemp <<= 1;
        }
        return PaStatus;
    }
#endif
    else {
        pDestination = GetParamPtr(a_ucParamNumber);
    }
#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
}
#endif

    // Avoid access level and control state checks for parameter set parameter.
    // The individual members will be checked during the recursive call.
    if (AT_PSET != AccessType)  {
        if (AccessLock == ALCK_VIEW) {
            
            #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
                //For SVP and SP IOM or Channel parameters, 
                //set the Write status into Shared Ram message status buffer
                PaStatus = DO_READ_ONLY_PARAMETER;
                ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
            #endif
            
            return DO_READ_ONLY_PARAMETER;
        }
        if ((AccessLock & a_ucAccessLevel) == 0) {
            
            #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
                //For SVP and SP IOM or Channel parameters, 
                //set the Write status into Shared Ram message status buffer
                PaStatus = DO_ACCESS_LEVEL_INVALID;
                ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
            #endif
            
            return DO_ACCESS_LEVEL_INVALID;
        }
        
        PaStatus = VerifyControlState(a_ucParamNumber);
                
        if (PA_OK != PaStatus) {

            #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
                //For SVP and SP IOM or Channel parameters, 
                //set the Write status into Shared Ram message status buffer
                ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
            #endif
            
            return PaStatus;
        }

        // Copy data to the DATABYTES structure for aligning 
        // it in even boundary for use by pre functions.
        if (ucParamSize <= sizeof(DATABYTES)) {
            for (UINT8 ucSize = 0; ucSize < ucParamSize; ucSize++) {
                Data.ucBytes[ucSize] = *(a_WriteBuffer + ucSize);
            }
        }
    }

#ifdef IOMTYPE_SVP
//For SVP Box Parameters, Except MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ,IOLPROCSTATRESET,CALIBALL and CALIBOPT parameters,
//Pre, Post checks and data storage is done in IOLINK Processor itself
if((0 == ChanNum) && (a_ucParamNumber != PARAMID_SVP_MODSTAT1  &&
                      a_ucParamNumber != PARAMID_SVP_MODSTAT2  &&
                      a_ucParamNumber != PARAMID_BOXCHKPNT     && 
                      a_ucParamNumber != PARAMID_SVP_DBVALID   && 
                      a_ucParamNumber != PARAMID_SVP_EXCITFREQ &&
                      a_ucParamNumber != PARAMID_SVP_CALIBALL  &&
                      a_ucParamNumber != PARAMID_SVP_CALIBOPT  &&
                      a_ucParamNumber != PARAMID_APPPROCSTATRESET &&
                      a_ucParamNumber != PARAMID_SVP_SERVODRIVEOPT))
{
#endif
#ifdef IOMTYPE_SP
//For SP Box Parameters, Except MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ and CALIBALL parameters and SP AI and AO channels
//Pre, Post checks and data storage is done in IOLINK Processor itself
if(((0 == ChanNum) && (a_ucParamNumber != PARAMID_SP_MODSTAT1      && 
                       a_ucParamNumber != PARAMID_SP_MODSTAT2      && 
                       a_ucParamNumber != PARAMID_BOXCHKPNT        &&
                       a_ucParamNumber != PARAMID_SP_DBVALID       &&
                       a_ucParamNumber != PARAMID_SP_CALIBALL      &&
                       a_ucParamNumber != PARAMID_SP_RESETTRIP     &&
                       a_ucParamNumber != PARAMID_SP_REVROTCHNLA   &&
                       a_ucParamNumber != PARAMID_SP_REVROTCHNLB   &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEAVGAPP &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEMAXAPP &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEMINAPP &&
                       a_ucParamNumber != PARAMID_SP_STATRESETAPP)) || (ChanNum >=1 && ChanNum <=9))
{
#endif
    // Call pre receiver-beware checks.
    if (ucParamSize <= sizeof(DATABYTES)) {
        PaStatus = ExecutePreFunction(a_ucParamNumber,&Data.ucBytes[0],a_ucAccessLevel);
    }
    else {
        PaStatus = ExecutePreFunction(a_ucParamNumber,a_WriteBuffer,a_ucAccessLevel);
    }

    if (PA_REDDATA_BYPASS != PaStatus) {
        if (PaStatus > PA_OK) {
            #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
                //For SVP and SP IOM or Channel parameters, 
                //set the Write status into Shared Ram message status buffer
                ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
            #endif
            return PaStatus;
        }
        // All checks passed. Save current interrupt masks and set current masks
        // so that STC or point processing cannot come in between.
        set_imask_exr(LVLPRI_TICK); 
    
        // Copy data from write buffer to the object memory.
        // Set write-in-progress semaphore for non-atomic data.
        switch (AccessType) {
            case AT_SBYTE:
                *pDestination = Data.ucBytes[0];
                break;
            case AT_MBYTE:
                WriteInProgress.pWriteBuffer = &Data.ucBytes[0];
                WriteInProgress.pDatabase = pDestination;
                UINT8 *pSource;
                if (ucParamSize > 4) pSource = a_WriteBuffer;
                else pSource = (UINT8 *)&Data;
                for (UINT8 ucSize = 0; ucSize < ucParamSize; ucSize++) {
                    *pDestination++ = pSource[ucSize];
                }
                break;
            case AT_PSET:
                // Restore original interrupt mask for parameter set.
                // Interrupt mask will be updated again by the recursive call.
                set_imask_exr(ucSaveExr); 
                while (*pDestination) {
                    ucParamSize = GetParamSize(*pDestination);

                    if ((PARAMID_SLTCHKPNT == a_ucParamNumber) && (ChanNum > 0) && (PARAMID_PTEXECST == *pDestination)) {
                        // If this is checkpoint restore and the current parameter is
                        // point execution state, do not write it now. Save it in a local
                        // variable and write only at the end of checkpoint restore.
                        ucSavePtExecSt = *(UINT8 *)a_WriteBuffer;
                        PaStatus = PA_OK;
                    }
                    else if( (PARAMID_BOXCHKPNT == a_ucParamNumber) &&
                             (PARAMID_MODSTAT1 == *pDestination)      ) {
                        ucSaveModStat1 = *(UINT8 *)a_WriteBuffer;
                        PaStatus = PA_OK;
                    }
                    else {
                        // Recursively call the individual parameter write of the parameter set.
                        // Disable checksum computation during individual parameters write.
                        PaStatus = WriteParamData(a_WriteBuffer,*pDestination,a_ucAccessLevel,FALSE);
#if defined(PMIO_DEBUG) && (0)
                        // to print failed param and its response while writing param set.
                        if (PaStatus > PA_OK)
                        {                            
                            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nPARM:%03d -", *pDestination));
                            for (UINT8 ucIndex = 0; ucIndex < ucParamSize; ucIndex++)
                            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" %02x", a_WriteBuffer[ucIndex]));
                            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" - %02x", PaStatus));
                        }
#endif
                    }
                    if (PaStatus > PA_OK) {
                        // Parameter set write failed in between. Update the database checksum.
                        ComputeCheckSum();

                        if ((PARAMID_SLTCHKPNT == a_ucParamNumber) && (MAXSLOTS == ChanNum)) {
                            TraceLog.AddToTrace(TRACEID_GENERIC,bcDbRestoreFail);
                        }
                        #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
                            //For SVP and SP IOM or Channel parameters, 
                            //set the Write status into Shared Ram message status buffer
                            ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
                        #endif
                        return PaStatus;
                    }
                    a_WriteBuffer = a_WriteBuffer + ucParamSize;
                    pDestination++;
                }

                // Parameter set write complete. If this was a checkpoint
                // restore, write the saved point execution state.
                if (PARAMID_SLTCHKPNT == a_ucParamNumber) {
                    PaStatus = WriteParamData(&ucSavePtExecSt,PARAMID_PTEXECST,a_ucAccessLevel,FALSE);
                }
                // Parameter set write complete. If this was a checkpoint
                // restore, write the saved modstat.
                if (PARAMID_BOXCHKPNT == a_ucParamNumber) {
                    PaStatus = WriteParamData(&ucSaveModStat1,PARAMID_MODSTAT1,a_ucAccessLevel,FALSE);
                }

                if (((0 == ChanNum) && (PARAMID_BOXCHKPNT == a_ucParamNumber)) ||
                    ((0 != ChanNum) && (PARAMID_SLTCHKPNT == a_ucParamNumber))) {
                    PaStatus = ucSaveChkpntPaStatus;
                }
                #ifdef IOMTYPE_AIH
                if ((PARAMID_SLTCHKPNT == a_ucParamNumber) && (MAXSLOTS == ChanNum)) {
                    TraceLog.AddToTrace(TRACEID_GENERIC,bcDbRestoreDone);
                }
                #endif
                break;
            case AT_BXPACK:
                // In this case, slot data is kept in box as a bitmap and 
                // pDestination will be pointing to the the box database 
                // member where this data is kept. 
#if defined (IOMTYPE_UIO)
                if (Data.ucBytes[0] > 0) {
                    SetBit((UINT32 *)pDestination, ChanNum - 1);
                }
                else {
                    ClearBit((UINT32 *)pDestination, ChanNum - 1);
                }
#else
                ucBitIndex  = 0x80 >> ((ChanNum - 1) & 0x07);
                ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
                if (Data.ucBytes[0] > 0) pDestination[ucByteIndex] |= ucBitIndex;
                else pDestination[ucByteIndex] &= ~ucBitIndex;
#endif
                break;
            case AT_BXREC:
                // In this case, slot data is kept in box as a bind record.
                // Since read can be performed from slot as individual data
                // or from box as a blind record, WriteInProgress mechanism 
                // cannot be used here. Disable interrupts so that IOL read
                // will not occur during the write operation.
                ucMask = get_imask_exr();
                set_imask_exr(LVLPRI_HIGHEST);
                for (UINT8 ucSize = 0; ucSize < ucParamSize; ucSize++) {
                    *pDestination++ = Data.ucBytes[ucSize];
                }
                set_imask_exr(ucMask);
                break;
            default:
                set_imask_exr(ucSaveExr); // Restore original interrupt mask
                #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
                    //For SVP and SP IOM or Channel parameters, 
                    //set the Write status into Shared Ram message status buffer
                    PaStatus = DO_DATA_TYPE_ERROR;
                    ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
                #endif
                return DO_DATA_TYPE_ERROR;
        }
    }
    else PaStatus = PA_OK;

#if !defined(IOPTYPE_SCIOM) 
    if (PA_OK == PaStatus)
    {
        UINT8 ucIndex = PA_NULL;

        if ((ucIndex = IsCheckPointParam(a_ucParamNumber)) != PA_NULL)
        {	
            // In PMIO redesign, checkpoint param should be stored in the battery backup sram
            xRamWrite((xRAM_CHKPNT_ADRS + (xRAM_CHKPNT_BLOCK*ChanNum) + (ucIndex - 1)), 
                    (ucParamSize > sizeof(DATABYTES)) ? a_WriteBuffer : (UINT8 *)&Data, 
                                                                          ucParamSize);
        }
    }

#endif

#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
}
#endif


#ifdef IOMTYPE_SVP
//SVP Box MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ,IOLPROCSTATRESET, CALIBALL and CALIBOPT parameters and all the SVP Channels
//parameters write requests are updated to shared ram write message queue for which 
//Pre, Post checks and data storage is done in Application Processor.
if(((0 == ChanNum) && (a_ucParamNumber  == PARAMID_SVP_MODSTAT1   || 
                       a_ucParamNumber  == PARAMID_SVP_MODSTAT2   || 
                       a_ucParamNumber  == PARAMID_BOXCHKPNT      || 
                       a_ucParamNumber  == PARAMID_SVP_DBVALID    || 
                       a_ucParamNumber  == PARAMID_SVP_EXCITFREQ  ||
                       a_ucParamNumber  == PARAMID_SVP_CALIBALL   ||
                       a_ucParamNumber  == PARAMID_SVP_CALIBOPT   ||
                      a_ucParamNumber == PARAMID_APPPROCSTATRESET ||
                      a_ucParamNumber == PARAMID_SVP_SERVODRIVEOPT)) || (0 != ChanNum))
{
    //Update the write request into shared ram message write queue
    if (AT_PSET != AccessType)
    {
        PaStatus = ShramWriteMsgQueue.UpdateParameterToWriteShramQueue(a_ucParamNumber,ChanNum,ucParamSize,a_ucAccessLevel,&Data);
    }
    else
    {
        PaStatus = ShramWriteMsgQueue.UpdateChkPntDataToWriteShramQueue(a_ucParamNumber,ChanNum,ucParamSize,a_ucAccessLevel,a_WriteBuffer);
    }
}
#endif
#ifdef IOMTYPE_SP
//For SP Box Parameters, Except MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ and CALIBALL parameters and SP AI and AO channels
//Pre, Post checks and data storage is done in IOLINK Processor itself
if(((0 == ChanNum) && (a_ucParamNumber == PARAMID_SP_MODSTAT1       || 
                       a_ucParamNumber == PARAMID_SP_MODSTAT2       ||
                       a_ucParamNumber == PARAMID_BOXCHKPNT         ||
                       a_ucParamNumber == PARAMID_SP_DBVALID        ||
                       a_ucParamNumber == PARAMID_SP_CALIBALL       ||
                       a_ucParamNumber == PARAMID_SP_RESETTRIP      ||
                       a_ucParamNumber == PARAMID_SP_REVROTCHNLA    ||
                       a_ucParamNumber == PARAMID_SP_REVROTCHNLB    ||
                       a_ucParamNumber == PARAMID_SP_CPUFREEAVGAPP  ||
                       a_ucParamNumber == PARAMID_SP_CPUFREEMAXAPP  ||
                       a_ucParamNumber == PARAMID_SP_CPUFREEMINAPP  ||
                       a_ucParamNumber == PARAMID_SP_STATRESETAPP)) || (ChanNum > 9))
{
    //Update the write request into shared ram message write queue
    if (AT_PSET != AccessType)
    {
        //Update the write request into shared ram message write queue
        PaStatus = ShramWriteMsgQueue.UpdateParameterToWriteShramQueue(a_ucParamNumber,ChanNum,ucParamSize,a_ucAccessLevel,&Data);
    }
    else
    {
        PaStatus = ShramWriteMsgQueue.UpdateChkPntDataToWriteShramQueue(a_ucParamNumber,ChanNum,ucParamSize,a_ucAccessLevel,a_WriteBuffer);
    }
}
#endif

#ifdef IOMTYPE_SVP
//For SVP Box Parameters, Except MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ,IOLPROCSTATRESET,CALIBALL and CALIBOPT parameters,
//Pre, Post checks and data storage is done in IOLINK Processor itself
if( (0 == ChanNum) && (a_ucParamNumber  != PARAMID_SVP_MODSTAT1    &&
                       a_ucParamNumber  != PARAMID_SVP_MODSTAT2    && 
                       a_ucParamNumber  != PARAMID_BOXCHKPNT       && 
                       a_ucParamNumber  != PARAMID_SVP_DBVALID     && 
                       a_ucParamNumber  != PARAMID_SVP_EXCITFREQ   &&
                       a_ucParamNumber  != PARAMID_SVP_CALIBALL    &&
                       a_ucParamNumber  != PARAMID_SVP_CALIBOPT    &&
                       a_ucParamNumber != PARAMID_APPPROCSTATRESET &&
                       a_ucParamNumber != PARAMID_SVP_SERVODRIVEOPT) )
{
    ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
#endif
#ifdef IOMTYPE_SP
//For SP Box Parameters, Except MODSTAT1, MODSTAT2, DBVALID, EXCITFREQ and CALIBALL parameters and SP AI and AO channels
//Pre, Post checks and data storage is done in IOLINK Processor itself
if(((0 == ChanNum) && (a_ucParamNumber != PARAMID_SP_MODSTAT1      && 
                       a_ucParamNumber != PARAMID_SP_MODSTAT2      && 
                       a_ucParamNumber != PARAMID_BOXCHKPNT        &&
                       a_ucParamNumber != PARAMID_SP_DBVALID       &&
                       a_ucParamNumber != PARAMID_SP_CALIBALL      &&
                       a_ucParamNumber != PARAMID_SP_RESETTRIP     &&
                       a_ucParamNumber != PARAMID_SP_REVROTCHNLA   &&
                       a_ucParamNumber != PARAMID_SP_REVROTCHNLB   &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEAVGAPP &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEMAXAPP &&
                       a_ucParamNumber != PARAMID_SP_CPUFREEMINAPP &&
                       a_ucParamNumber != PARAMID_SP_STATRESETAPP)) || (ChanNum >=1 && ChanNum <=9))
{
    ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
#endif

    // Reset write-in-progress semaphore and call post function.
    WriteInProgress.pDatabase    = NULL;
    WriteInProgress.pWriteBuffer = NULL;
    ExecutePostFunction(a_ucParamNumber,a_ucAccessLevel);

#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
}
#endif

    set_imask_exr(ucSaveExr); // Restore original interrupt mask

    // Calculate and update database checksum for checksumed paramters. 
    if (a_bDoChkSm && (TRUE == GetIsDbChecksumed(a_ucParamNumber))) {
        
        ComputeCheckSum();

#if !defined(IOPTYPE_SCIOM)
        // In PMIO Redesign, computed checksum of a received param, should be stored in the battery backup SRAM
        xRamWrite((xRAM_CHKPNT_ADRS + xRAM_CHKPNT_CKSM + (ChanNum * xRAM_CHKSM_SIZE)),
                   (UINT8 *)((clsBoxSlot *)pDatabase[0])->GetPmioCheckSumPtr(ChanNum),
                                                                     xRAM_CHKSM_SIZE);
#endif
    }

    return PaStatus;
}
/*******************************************************************************
*                          clsIomSlot::WriteParamData                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsIomSlot::WriteParamData(UINT8 *a_WriteBuffer,
                                    UINT8 a_ucParamNumber,
                                    UINT8 a_ucAccessLevel,
                                    UINT8 a_ucIndex) {
    PASTATUS PaStatus     = PA_OK;
    UINT8 ucParamSize     = GetParamSize(a_ucParamNumber);
    ACCESSLOCK AccessLock = GetAccessLock(a_ucParamNumber);
    ACCESSTYPE AccessType = GetAccessType(a_ucParamNumber);
#if !defined(IOMTYPE_SVP) && !defined(IOMTYPE_SP)
    UINT8 *pDestination   = GetParamPtr(a_ucParamNumber);
#endif
    WriteIndex = a_ucIndex;

    if (AccessType != AT_SBYTE && AccessType != AT_MBYTE) 
    {
        #if defined (IOMTYPE_SVP) || defined(IOMTYPE_SP)
            //For SP IOM or Channel parameters, 
            //set the Write status into Shared Ram message status buffer
             PaStatus = DO_DATA_TYPE_ERROR;
            ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
        #endif

        return DO_DATA_TYPE_ERROR;
    }
    
    if (AccessLock == ALCK_VIEW)
    { 
        #if defined (IOMTYPE_SVP) || defined(IOMTYPE_SP)
            //For SP IOM or Channel parameters, 
            //set the Write status into Shared Ram message status buffer
             PaStatus = DO_READ_ONLY_PARAMETER;
            ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
        #endif

        return DO_READ_ONLY_PARAMETER;
    }
    
    if ((AccessLock & a_ucAccessLevel) == 0) 
    {
        #if defined (IOMTYPE_SVP) || defined(IOMTYPE_SP)
            //For SP IOM or Channel parameters, 
            //set the Write status into Shared Ram message status buffer
             PaStatus = DO_ACCESS_LEVEL_INVALID;
            ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
        #endif

        return DO_ACCESS_LEVEL_INVALID;
    }
    
    PaStatus = VerifyControlState(a_ucParamNumber);
    if (PA_OK != PaStatus) 
    {
        #if defined (IOMTYPE_SVP) || defined(IOMTYPE_SP)
            //For SP IOM or Channel parameters, 
            //set the Write status into Shared Ram message status buffer
            ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
        #endif
        return PaStatus;
    }

    // Copy data to the DATABYTES structure for aligning 
    // it in even boundary for use by pre functions.
    for (UINT8 ucSize = 0; ucSize < ucParamSize; ucSize++) {
        Data.ucBytes[ucSize] = *(a_WriteBuffer + ucSize);
    }
    
#if !defined(IOMTYPE_SVP) && !defined(IOMTYPE_SP)
    // Call pre receiver beware checks.
    PaStatus = ExecutePreFunction(a_ucParamNumber,&Data.ucBytes[0],a_ucAccessLevel);
    if (PaStatus > PA_OK) {
        return PaStatus;
    }

    // All checks passed. Save current interrupt masks and set current masks
    // so that STC or point processing cannot come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK); 
    
    pDestination += ucParamSize * (a_ucIndex - 1);
    // Copy data from write buffer to the object memory.
    // Set write-in-progress semaphore for non-atomic data.
    switch (AccessType) {
        case AT_SBYTE:
            *pDestination = Data.ucBytes[0];
            break;
        case AT_MBYTE:
            WriteInProgress.pWriteBuffer = &Data.ucBytes[0];
            WriteInProgress.pDatabase = pDestination;
            set_imask_exr(LVLPRI_IOLN);
            for (UINT8 ucSize = 0; ucSize < ucParamSize; ucSize++) {
                *pDestination++ = Data.ucBytes[ucSize];
            }
            break;
        default:
            set_imask_exr(ucSaveExr); // Restore original interrupt mask
            return DO_DATA_TYPE_ERROR;
    }

#if defined(HART_SUPPORT) && (defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16))
    if (PA_OK == PaStatus)
    {
        UINT8 ucIndex = PA_NULL;

        if ((ucIndex = IsCheckPointParam(a_ucParamNumber)) != PA_NULL)
        {
            // In PMIO redesign, checkpoint param should be stored in the battery backup sram
            xRamWrite((xRAM_CHKPNT_ADRS + (xRAM_CHKPNT_BLOCK*ChanNum) + (ucIndex - 1) + (ucParamSize * (a_ucIndex - 1))),
                                                      (ucParamSize > sizeof(DATABYTES)) ? a_WriteBuffer : (UINT8 *)&Data,
                                                                                                            ucParamSize);
        }
    }
#endif

    // Reset write-in-progress semaphore and call post function.
    WriteInProgress.pDatabase    = NULL;
    WriteInProgress.pWriteBuffer = NULL;
    ExecutePostFunction(a_ucParamNumber,a_ucAccessLevel);
    
    set_imask_exr(ucSaveExr); // Restore original interrupt mask

    if (TRUE == GetIsDbChecksumed(a_ucParamNumber)) {
		
		ComputeCheckSum();

#if defined(HART_SUPPORT) && (defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16))
        // In PMIO Redesign, computed checksum of a received param, should be stored in the battery backup SRAM
        xRamWrite((xRAM_CHKPNT_ADRS + xRAM_CHKPNT_CKSM + (ChanNum * xRAM_CHKSM_SIZE)),
                   (UINT8 *)((clsBoxSlot *)pDatabase[0])->GetPmioCheckSumPtr(ChanNum),
                                                                     xRAM_CHKSM_SIZE);	
#endif
    }
#endif
    
#if defined (IOMTYPE_SVP) || defined(IOMTYPE_SP)
    //Update the write request into shared ram message write queue
    PaStatus = ShramWriteMsgQueue.UpdateParameterToWriteShramQueue(a_ucParamNumber,ChanNum,ucParamSize,a_ucAccessLevel,&Data,a_ucIndex);
    
    ShramWriteMsgQueue.SetMsgStatus(ucShramWriteMsgNumber,PaStatus);
#endif

    return PaStatus;
}

/*******************************************************************************
*                          clsIomSlot::ComputeCheckSum                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsIomSlot::ComputeCheckSum() {
    UINT8 *ChkPntPtr;
    UINT16 ulChecksum = 0;

    if (0 == ChanNum) ChkPntPtr = GetParamPtr(PARAMID_BOXCHKPNT);
    else {
        ChkPntPtr = GetParamPtr(PARAMID_SLTCHKPNT);
    }

#if defined(IOMTYPE_UIO)
    // If GetParamPtr() returns 0, then PntType is not configured i.e UioSlot.
    // No need to calculate checksum. Set checksum value to Zero.
    if(ChkPntPtr == (UINT8 *)0)
    {
       ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, ulChecksum);
       return ;
    }

#endif

    while (*ChkPntPtr) {

		UINT8 ucParamSize = GetParamSize(*ChkPntPtr);
        UINT8 *pParamPtr = GetParamPtr(*ChkPntPtr);

#if 0//defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
		// for, PMIO redesign
        // NAN value in series C represented as 0x7FFFFFFF 
        //      where as in pmio represented as 0xFFFFFFFF
        if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)pParamPtr)
#if defined(IOPTYPE_AO16)
        // default value of CHRC_Sn = 0x7FFFFFFF in pmio
        && ((*ChkPntPtr < PARAMID_CHRC_S0) && (*ChkPntPtr > PARAMID_CHRC_S4))
#endif
        ) 
		{
			*pParamPtr = 0xFF;
		}
#endif

        if (ucParamSize > 1) {
            for (UINT8 ucSize = ucParamSize; ucSize > 0; ucSize--) {
                ulChecksum += *pParamPtr++;
            }
        }
        else {
            ulChecksum += *pParamPtr;
        }
        ChkPntPtr++;

#if defined(PMIO_DEBUG) && (0)
		if (ucDbgPnt == 0xA5) {
			ucDumpBuff[ucDbgCnt++] = (UINT8)(ulChecksum >> 8);
			ucDumpBuff[ucDbgCnt++] = (UINT8)(ulChecksum & 0x00FF);
		}
#endif
    }
    ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, ulChecksum);
}

/*******************************************************************************
*                          clsIomSlot::ComputeRedCheckSum                      *
*                          ==============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: SYNC VER                                                              *
*******************************************************************************/
UINT16 clsIomSlot::ComputeRedCheckSum() {
    UINT8   ucSize,*pData,*ParamPtr;
    UINT16  ulChecksum = 0;

    pData = (UINT8 *)GetRedParamsPtr();

#if defined(IOMTYPE_UIO)
    // If GetRedParamsPtr() returns 0, then PntType is not configured i.e UioSlot.
    // No need to calculate Redundant checksum. Return 0
    if(pData == (UINT8 *)0)
       return ulChecksum;
#endif

#if defined(IOPTYPE_SCIOM)

    while (*pData) {

        ParamPtr = (UINT8 *)GetParamPtr(*pData);

        for (ucSize = GetParamSize(*pData); ucSize > 0; ucSize--) {
            ulChecksum += *ParamPtr++;
        }
    }
#else

#if defined(PMIO_DEBUG) && (0)
    if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n\r\nSLOT-%02x", ChanNum));
#endif

    UINT8 ucParamSize;

    while (*pData) {

#if defined(PMIO_DEBUG) && (0)
        if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nID: %02x DATA: ", *pData));
#endif
        ParamPtr = (UINT8 *)GetParamPtr(*pData);

		ucParamSize = GetParamSize(*pData);

        for (ucSize = ucParamSize; ucSize > 0; ucSize--)
        {
#if defined(PMIO_DEBUG) && (0)
            if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
            {
                if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)ParamPtr)
#if defined(IOPTYPE_AO16)
                      // default value of CHRC_Sn = 0x7FFFFFFF in pmio
                      && ((*pData < PARAMID_CHRC_S0) && (*pData > PARAMID_CHRC_S4))
#endif
                    )
                     while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("FF "));
                else while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("%02x ", *ParamPtr));
            }            
#endif 
            // for, PMIO redesign
            // NAN value in series C represented as 0x7FFFFFFF 
            //      where as in pmio represented as 0xFFFFFFFF
            if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)ParamPtr)
#if defined(IOPTYPE_AO16)
                   // default value of CHRC_Sn = 0x7FFFFFFF in pmio
                   && ((*pData < PARAMID_CHRC_S0) && (*pData > PARAMID_CHRC_S4))
#endif
               )
                 ulChecksum ^= 0xFF;
            else ulChecksum ^= *ParamPtr;

            ParamPtr++;
        }

#if defined(PMIO_DEBUG) && (0)
        if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("CSM: 0x%08X", (UINT32)ulChecksum));
#endif
        pData++;
    }

#endif // defined(IOPTYPE_SCIOM)

    return ulChecksum;
}

#if !defined(IOPTYPE_SCIOM)
/*******************************************************************************
*                          clsIomSlot::PmioDumpParam                           *
*                          ==============================                      *
* PURPOSE:   Redundant data dump routine for PM IOP primary.                   *
* ARGUMENTS: Destination pointer & source pointer.                             *
* RETURN:    NONE                                                              *
* NOTES:     Since the red data & its order is diff in Redesign PM IOPs.       *
*******************************************************************************/
VOID clsIomSlot::PmioDumpParam(UINT8 *pucDest)
{    
    UINT8 *pParamId;// = (UINT8 *)GetPmioDumpParamPtr();
    UINT8 ucParamSize;
    UINT8 *pParam;

#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
    if(true == bHartDataDump) {
        pParamId = (UINT8 *)GetPmioHartDumpParamPtr();
    }
    else 
#endif
    {
        pParamId = (UINT8 *)GetPmioDumpParamPtr();
    }

    while(*pParamId)
    {

#if defined(IOPTYPE_DI)
		// added to fix the following issue,
		// when the legacy iop inserted as a partner to the redesign iop (primary), after removing the primary (redesign), the new primary (legacy)
        // is not showing alarm as expected, Because the PVFL param is not retaining properly during data dump, due to its type AT_BXPACK.
        UINT8 u8Temp = 0;
        if(*pParamId == PARAMID_PV_PVFL)
        {            
            ReadParamData(&u8Temp, *pParamId);
            pParam = &u8Temp;
        }
        else
#endif
        pParam = (UINT8 *)GetParamPtr(*pParamId);

		ucParamSize = GetParamSize(*pParamId);

#if defined(IOPTYPE_DO) && defined(DIGTYPE_DO32)
        // because, these parameters are having 3 byte size in PMIO DO32,
        if ((*pParamId == PARAMID_T_P_STRT) || (*pParamId == PARAMID_T_P_END)) pParam++;
#endif

        for (UINT8 ucSize = ucParamSize; ucSize > 0; ucSize--)
        {            
            // for, PMIO redesign
            // NAN value in series C represented as 0x7FFFFFFF 
            //      where as in pmio represented as 0xFFFFFFFF
            if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)pParam)
#if defined(IOPTYPE_AO16)
            // default value of CHRC_Sn = 0x7FFFFFFF in pmio
            && ((*pParamId < PARAMID_CHRC_S0) && (*pParamId > PARAMID_CHRC_S4))
#endif
                )
                 *pucDest++ = 0xFF;
            else *pucDest++ = *pParam;
            
            pParam++;
        }

        pParamId++;
    }
}
/*******************************************************************************
*                          clsIomSlot::PmioComputeChecksum                     *
*                          ==============================                      *
* PURPOSE:   Computing checksum for pmio checkpoint restore data in xRAM       *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:     Redesign PM IOPs only                                             *
*******************************************************************************/
UINT16 clsIomSlot::PmioComputeChecksum(VOID)
{
    UINT8 ucTempBuff[xRAM_CHKPNT_PRMXSZ];
    UINT8 *ucChkPntParm = (UINT8 *)GetCheckPointPtr(LATEST_SLTCHKPNT_VERSION);    
    UINT8 ucParamSize;
    UINT8 ucParamIndex = 0;
    UINT16 uiChkSum = 0;

#if defined(PMIO_DEBUG) && (0)
	if (ChanNum < 3)
		while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n\r\nSLOT-%02x", ChanNum));
#endif

    for (UINT8 ucParamCount = 0; *(ucChkPntParm + ucParamCount) != 0; ucParamCount++)
    {
#if defined(PMIO_DEBUG) && (0)
		if (ChanNum < 3)
			while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nID: %02x DATA: ", *(ucChkPntParm + ucParamCount)));
#endif
		ucParamSize = GetParamSize(*(ucChkPntParm + ucParamCount));

        xRamRead((xRAM_CHKPNT_ADRS + (xRAM_CHKPNT_BLOCK * ChanNum) + ucParamIndex), ucTempBuff, ucParamSize);

        ucParamIndex += ucParamSize;

        for (UINT8 ucIndex = 0; ucIndex < ucParamSize; ucIndex++) {

#if defined(PMIO_DEBUG) && (0)
			if (ChanNum < 3)
				while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("%02x ", ucTempBuff[ucIndex]));
#endif 

            uiChkSum += ucTempBuff[ucIndex];
        }

#if defined(PMIO_DEBUG) && (0)
		if (ChanNum < 3)
			while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("CSM: 0x%08X", (UINT32)uiChkSum));
#endif

    }

    return uiChkSum;
}
/*******************************************************************************
*                    clsIomSlot::CheckpointRestoreCondition                    *
*                    ======================================                    *
* PURPOSE:   Checking valid conditions to restore checkpoint data.             *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:     When checkpoint checksum mismatch / change in physical address /  *
*            Freshly programmed board / Freshly Calibrated, Default database   *
*            will be loaded into xRAM.                                         *
*            When Checksum Ok / Same physical address (Assume module in chasis *
*            & Power Off) / normal reboot / already calibrated module, then    *
*            Checkpoint database retrive from xRAM.                            *
*******************************************************************************/
PASTATUS clsIomSlot::CheckpointRestoreCondition(VOID)
{   
    UINT8 ucTemp[sizeof(UINT32)];
    PASTATUS ucReturnStatus = PA_OK;

    /* Checking for the checkpoint integrity */ 
       
    UINT16 uiCalcChkSum = PmioComputeChecksum();

    xRamRead((xRAM_CHKPNT_ADRS + xRAM_CHKPNT_CKSM + (xRAM_CHKSM_SIZE * ChanNum)), ucTemp, xRAM_CHKSM_SIZE);
    
    UINT16 uiReadChkSum = (UINT16)((UINT16)ucTemp[0] << 8 | ucTemp[1]);
    
    if (uiCalcChkSum != uiReadChkSum)
    {
#if defined(PMIO_DEBUG) && (1)        
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nSLOT-%02x RCSM-%04x CCSM-%04x", 
                                                                ChanNum, uiReadChkSum, uiCalcChkSum));
#endif
        ucReturnStatus = PA_NULL;
    }

    /* Checking for the module address change */

    xRamRead((xRAM_CHKPNT_ADRS + xRAM_LAST_DPA), ucTemp, sizeof(UINT8));

#if !AIAO
    // Save readback select registers
    UINT8 ucRdBkSel = RDBK_SEL;
    RDBK_SEL = RDBK_MODNUM;
#endif // !AIAO

    UINT8 ucDpa = isOddParity(MODNUM >> 4) ? (0x80 | MODNUM) : 0;

#if !AIAO            
    RDBK_SEL = ucRdBkSel; // Restore readback select register
#endif

    if (ucDpa != ucTemp[0])
    {
        if (ChanNum == 0)
        {
            xRamWrite((xRAM_CHKPNT_ADRS + xRAM_LAST_DPA), &ucDpa, sizeof(UINT8));
#if defined(PMIO_DEBUG) && (1)
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\rCURR DPA - %02x\r\nPREV DPA - %02x",
                                                                      ucDpa, ucTemp[0]));
#endif
        }

        ucReturnStatus = PA_NULL;
    }

    /* Checking for the fresh module (after fw download) */
    
    xRamRead((xRAM_CHKPNT_ADRS + xRAM_APP_CRC), ucTemp, sizeof(UINT32));

    UINT32 ulPrevAppCrc = (UINT32)((UINT32)ucTemp[0] << 24)|
                                  ((UINT32)ucTemp[1] << 16)|
                                  ((UINT32)ucTemp[2] <<  8)|ucTemp[3];

    if (*((UINT32 *)APP_CRC_ADDRESS) != ulPrevAppCrc)
    {
        if (ChanNum == 0)
        {
            xRamWrite((xRAM_CHKPNT_ADRS + xRAM_APP_CRC), (UINT8 *)((UINT32 *)APP_CRC_ADDRESS), sizeof(UINT32));

#if defined(PMIO_DEBUG) && (1)
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n APP CRC - 0x%08X\r\nPREV CRC - 0x%08X",                                                                                           
                                                                 *((UINT32 *)APP_CRC_ADDRESS), ulPrevAppCrc));
#endif
        }

        ucReturnStatus = PA_NULL;
    }

#if !defined(IOMTYPE_DO) && !defined(IOMTYPE_DI)
    /* Checking for calibration done recently */
    xRamRead((xRAM_CHKPNT_ADRS + xRAM_CALIB_DONE), ucTemp, sizeof(UINT8));

    if (ucTemp[0] != 0x00)
    {
        if (ChanNum == 0)
        {
            ucTemp[0] = 0x00;
            xRamWrite((xRAM_CHKPNT_ADRS + xRAM_CALIB_DONE), ucTemp, sizeof(UINT8));

#if defined(PMIO_DEBUG) && (1)
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n CALIBRATION DONE RECENTLY"));
#endif
        }
        ucReturnStatus = PA_NULL;
    }
#endif

    return ucReturnStatus;
}
/*******************************************************************************
*                          clsIomSlot::PmioCheckPointRestore                   *
*                          ==============================                      *
* PURPOSE:   Restoring ChkPnt data from xRAM into respective param's, to make  *
*            to make data retained in power off condition, like how in PM IOP  *
*            database with battery backup SRAM.                                *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:     Redesign PM IOPs only                                             *
*******************************************************************************/
VOID clsIomSlot::PmioCheckPointRestore(BOOL bForce)
{        
    UINT8 *ucChkPntParm = (UINT8 *)GetCheckPointPtr(LATEST_SLTCHKPNT_VERSION);
    UINT8 *ucActualParameter, ucParamSize, ucParamIndex = 0;
    
	// if the database is okay,
    if ((FALSE == bForce) && (CheckpointRestoreCondition() == PA_OK)) // added Force param checking, to store the checkpoint data in xRAM
    {        
        UINT8  ucTempBuff[xRAM_CHKPNT_PRMXSZ];

        for (UINT8 ucParamCount = 0; *(ucChkPntParm + ucParamCount) != 0; ucParamCount++)
        {
            ucParamSize = GetParamSize(*(ucChkPntParm + ucParamCount));

            ucActualParameter = (UINT8 *)GetParamPtr(*(ucChkPntParm + ucParamCount));

            xRamRead((xRAM_CHKPNT_ADRS + (xRAM_CHKPNT_BLOCK * ChanNum) + ucParamIndex), ucTempBuff, ucParamSize);

            if ((PARAMID_BOXCHKPNTVER == *(ucChkPntParm + ucParamCount)) ||
                ((PARAMID_MODSTAT1 == *(ucChkPntParm + ucParamCount)) &&
                (ucTempBuff[0] == MODSTATUS_ALIVE)))
            {
                // Module will be bricked in these conditions,
                // 1. Checkpoint version should not be overridden, always should be latest.
                // 2. module will be shutdown, if it moves IDLE to ALIVE (0x00 - value in xRAM)
                // note: this conditions may arise if xRAM contains 0x00.
            }
            else
            {
                // need to check its status.
                ExecutePreFunction(*(ucChkPntParm + ucParamCount), ucTempBuff, ALVL_VIEW);

                for (UINT8 ucIndex = 0; ucIndex < ucParamSize; ucIndex++) {
                    *(ucActualParameter + ucIndex) = ucTempBuff[ucIndex];
                }

                ExecutePostFunction(*(ucChkPntParm + ucParamCount), ALVL_VIEW);
            }

            ucParamIndex += ucParamSize;
        }        
    }
    else // if checksum is not matching or a fresh module or force to store the checkpoint data
    {
        UINT16 uiChkSum = 0;

        for (UINT8 ucParamCount = 0; *(ucChkPntParm + ucParamCount) != 0; ucParamCount++)
        {
            ucParamSize = GetParamSize(*(ucChkPntParm + ucParamCount));

            ucActualParameter = (UINT8 *)GetParamPtr(*(ucChkPntParm + ucParamCount));

            xRamWrite((xRAM_CHKPNT_ADRS + (xRAM_CHKPNT_BLOCK * ChanNum) + ucParamIndex), ucActualParameter, ucParamSize);

            ucParamIndex += ucParamSize;

            for (UINT8 ucIndex = 0; ucIndex < ucParamSize; ucIndex++) {
                uiChkSum += *(ucActualParameter + ucIndex);
            }
        }

        ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, uiChkSum);

        xRamWrite((xRAM_CHKPNT_ADRS + xRAM_CHKPNT_CKSM + (ChanNum*xRAM_CHKSM_SIZE)),
                 (UINT8 *)((clsBoxSlot *)pDatabase[0])->GetPmioCheckSumPtr(ChanNum),
                                                                   xRAM_CHKSM_SIZE);
    }    
}
#endif //#if !defined(IOPTYPE_SCIOM)

