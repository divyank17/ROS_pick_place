/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : shraminterface.cpp                                          *
*    Description : Utilities Class  definitions to do operation on Shared Ram  *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_SVP
#include "svpmain.h"
#endif // End of IOMTYPE_SVP

#ifdef IOMTYPE_SP
#include "spmain.h"
#endif // End of IOMTYPE_SP

/*******************************************************************************
*                                 GLOBAL VARIABLES                             *
*******************************************************************************/
//Slot Database decalared on Shared Ram Section
#pragma section FPGA_SHRAM
SHRAMDATA ShramData;
#pragma section 

//Data shared between all images.
strCommonSharedData* pBootData = &ShramData.BootData;

//Write message messsage, which will be store same number 
//which is sent from write database task message number
UINT8 ucShramWriteMsgNumber = 0;

//Write Message Queue Instance
clsShramWriteMsgQueue ShramWriteMsgQueue;

/*******************************************************************************
*           clsShramWriteMsgQueue::UpdateParameterToWriteShramQueue            *
*           =======================================================            *
* PURPOSE: Method to put parameter write request into shared ram write message *
*          queue which is processed by application processor                   *
* ARGUMENTS: uParamCode - Parameter Code                                       *
*            uSlotId - Slot Number                                             *
*            uDataSize - Parameter Data Size                                   *
*            uAccessLevel - Access Level                                       *
*            pParamData - Parameter Actual Data                                *
* RETURN:    PASTATUS - returns the PA_OK on Successfully adding Message into  *
*            into queue, otherwise respective error                            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsShramWriteMsgQueue::UpdateParameterToWriteShramQueue(UINT8 uParamCode, 
                                                                 UINT8 uSlotId, 
                                                                 UINT8 uDataSize,
                                                                 UINT8 uAccessLevel, 
                                                                 void* pParamData)
{
  UINT8  uDataSizeWords = 0;
  UINT16 *pShramMsg     = NULL;
  UINT16 uSlotParamCode = 0;
  UINT8  uMsgCount      = 0;
  
  //Insert channel slot number, Index parameter flag into Parameter code
  //15..14 - Parmeter Index Flag
  //13...8 - Slot Number
  //7..0   - Parameter Code
  uSlotParamCode = (uParamCode | (((UINT16)uSlotId) << 8));
  uDataSizeWords = uDataSize >> 1; 

  //Set the Write Message status to InProgress before Sending
  ShramData.ucShramWrtMsgStatus[ucShramWriteMsgNumber] = IOL_WM_IN_PROGRESS;

  //Checks for the Queue Overflow
  if(WillRcvBfrOverflow(uDataSizeWords + SHRAM_WRT_MSG_HEADER_SZ))
  {
    return (DO_USER_ALLOCATED_BUFFER_FULL);
  }
  else //Queue entry is avaliable
  {
    //Get the Free Message Pointer
    pShramMsg = GetRcvBufPtr();

    //Form the Parameter Write Message Packet
    pShramMsg[SHRAM_WRT_PARAM_CODE_INDEX]   = uSlotParamCode;
    pShramMsg[SHRAM_WRT_DATA_SIZE_INDEX]    = uDataSize;
    pShramMsg[SHRAM_WRT_MSG_NUMBER_INDEX]   = ucShramWriteMsgNumber;
    pShramMsg[SHRAM_WRT_ACCESS_LEVEL_INDEX] = uAccessLevel;

    //Fill the Data of morethan 1byte data into Parameter Write Message Packet
    for(uMsgCount = 0; uMsgCount < uDataSizeWords; uMsgCount++)
    {
      pShramMsg[SHRAM_WRT_MSG_HEADER_SZ+uMsgCount] = *(((UINT16*)(pParamData)) + uMsgCount); 
    }  

    //Fill the Data of 1byte data into Parameter Write Message Packet
    if(uDataSize & 1)
    {
      pShramMsg[SHRAM_WRT_MSG_HEADER_SZ+uMsgCount] = *(((UINT8*)(pParamData)) + uMsgCount);
      uDataSizeWords++;
    }

    //Fill the Message size into Parameter Write Message Packet
    pShramMsg[SHRAM_WRT_MSG_SIZE_INDEX] = (uDataSizeWords + SHRAM_WRT_MSG_HEADER_SZ);    
    
    //Add Message into Write Message Queue
    AddMessage(ucShramWriteMsgNumber, uDataSizeWords + SHRAM_WRT_MSG_HEADER_SZ);
    
    return PA_OK;
  }
}

/*******************************************************************************
*           clsShramWriteMsgQueue::UpdateParameterToWriteShramQueue            *
*           =======================================================            *
* PURPOSE: Method to put index parameter write request into shared ram write   *
*          message queue which is processed by application processor           *
* ARGUMENTS: uParamCode - Parameter Code                                       *
*            uSlotId - Slot Number                                             *
*            uDataSize - Parameter Data Size                                   *
*            uAccessLevel - Access Level                                       *
*            pParamData - Parameter Actual Data                                *
*            uIndex - Paramter array Index                                     *
* RETURN:    PASTATUS - returns the PA_OK on Successfully adding Message into  *
*            into queue, otherwise respective error                            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsShramWriteMsgQueue::UpdateParameterToWriteShramQueue(UINT8 uParamCode, 
                                                                 UINT8 uSlotId, 
                                                                 UINT8 uDataSize,
                                                                 UINT8 uAccessLevel, 
                                                                 void* pParamData, 
                                                                 UINT8 uIndex)
{
  UINT8  uDataSizeWords = 0;
  UINT16 *pShramMsg     = NULL;
  UINT16 uSlotParamCode = 0;
  UINT8  uMsgCount      = 0;
  
  //Insert channel slot number, Index parameter flag into Parameter code
  //15..14 - Parmeter Index Flag
  //13...8 - Slot Number
  //7..0   - Parameter Code
  uSlotParamCode = (uParamCode | (((UINT16)uSlotId) << 8) | (1 << 14));
  uDataSizeWords = uDataSize >> 1; 

  //Set the Write Message status to InProgress before Sending
  ShramData.ucShramWrtMsgStatus[ucShramWriteMsgNumber] = IOL_WM_IN_PROGRESS;

  //Checks for the Queue Overflow
  if(WillRcvBfrOverflow(uDataSizeWords + SHRAM_WRT_MSG_HEADER_SZ))
  {
    return (DO_USER_ALLOCATED_BUFFER_FULL);
  }
  else
  {
    //Get the Free Message Pointer
    pShramMsg = GetRcvBufPtr();

    //Form the Parameter Write Message Packet
    pShramMsg[SHRAM_WRT_PARAM_CODE_INDEX]   = uSlotParamCode;
    pShramMsg[SHRAM_WRT_DATA_SIZE_INDEX]    = uDataSize;
    pShramMsg[SHRAM_WRT_MSG_NUMBER_INDEX]   = ucShramWriteMsgNumber;
    pShramMsg[SHRAM_WRT_ACCESS_LEVEL_INDEX] = uAccessLevel;

    //Fill the Data of morethan 1byte data into Parameter Write Message Packet
    for(uMsgCount = 0; uMsgCount < uDataSizeWords; uMsgCount++)
    {
      pShramMsg[SHRAM_WRT_MSG_HEADER_SZ+uMsgCount] = *(((UINT16*)(pParamData)) + uMsgCount); 
    }  

    //Fill the Data of 1byte data into Parameter Write Message Packet
    if(uDataSize & 1)
    {
      pShramMsg[SHRAM_WRT_MSG_HEADER_SZ+uMsgCount] = *(((UINT8*)(pParamData)) + uMsgCount);
      uDataSizeWords++;
    }
    
    //Set the Parameter index at the end of the message
    pShramMsg[SHRAM_WRT_MSG_HEADER_SZ+uDataSizeWords] = uIndex;
    uDataSizeWords++;

    //Fill the Message size into Parameter Write Message Packet
    pShramMsg[SHRAM_WRT_MSG_SIZE_INDEX] = (uDataSizeWords + SHRAM_WRT_MSG_HEADER_SZ);    
    
    //Add Message into Write Message Queue
    AddMessage(ucShramWriteMsgNumber, uDataSizeWords + SHRAM_WRT_MSG_HEADER_SZ);
    
    return (PA_OK);
  }
}

/*******************************************************************************
*           clsShramWriteMsgQueue::UpdateParameterToWriteShramQueue            *
*           =======================================================            *
* PURPOSE: Method to put checkpoint parameter write request into shared ram    *
*          write message queue which is processed by application processor     *
* ARGUMENTS: uParamCode - Parameter Code                                       *
*            uSlotId - Slot Number                                             *
*            uDataSize - Parameter Data Size                                   *
*            uAccessLevel - Access Level                                       *
*            pParamData - Parameter Actual Data                                *
* RETURN:    PASTATUS - returns the PA_OK on Successfully adding Message into  *
*            into queue, otherwise respective error                            *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsShramWriteMsgQueue::UpdateChkPntDataToWriteShramQueue(UINT8 uParamCode, 
                                                                  UINT8 uSlotId, 
                                                                  UINT8 uDataSize,
                                                                  UINT8 uAccessLevel, 
                                                                  UINT8* pParamData)
{
  UINT16 *pShramMsg     = NULL;
  UINT16 uSlotParamCode = 0;
  UINT8  uMsgCount      = 0;
  
  //Insert channel slot number, Index parameter flag into Parameter code
  //15..14 - Parmeter Index Flag
  //13...8 - Slot Number
  //7..0   - Parameter Code
  uSlotParamCode = (uParamCode | (((UINT16)uSlotId) << 8));

  //Set the Write Message status to InProgress before Sending
  ShramData.ucShramWrtMsgStatus[ucShramWriteMsgNumber] = IOL_WM_IN_PROGRESS;

  //Checks for the Queue Overflow
  if(WillRcvBfrOverflow(uDataSize + SHRAM_WRT_MSG_HEADER_SZ))
  {
    return (DO_USER_ALLOCATED_BUFFER_FULL);
  }
  else
  {
    //Get the Free Message Pointer
    pShramMsg = GetRcvBufPtr();

    //Form the Parameter Write Message Packet
    pShramMsg[SHRAM_WRT_PARAM_CODE_INDEX]   = uSlotParamCode;
    pShramMsg[SHRAM_WRT_DATA_SIZE_INDEX]    = uDataSize * 2; // Sending Bytes as Words
    pShramMsg[SHRAM_WRT_MSG_NUMBER_INDEX]   = ucShramWriteMsgNumber;
    pShramMsg[SHRAM_WRT_ACCESS_LEVEL_INDEX] = uAccessLevel;

    //Fill the Data of morethan 1byte data into Parameter Write Message Packet
    for(uMsgCount = 0; uMsgCount < uDataSize; uMsgCount++)
    {
      UINT8 Data = *(pParamData + uMsgCount);
      pShramMsg[SHRAM_WRT_MSG_HEADER_SZ+uMsgCount] = (UINT16)Data;
    }  

    //Fill the Data of 1byte data into Parameter Write Message Packet
    pShramMsg[SHRAM_WRT_MSG_SIZE_INDEX] = (uDataSize + SHRAM_WRT_MSG_HEADER_SZ);    
    
    //Add Message into Write Message Queue
    AddMessage(ucShramWriteMsgNumber, uDataSize + SHRAM_WRT_MSG_HEADER_SZ);
    
    return (PA_OK);
  }
}

/*******************************************************************************
*                   clsShramWriteMsgQueue::AddMessage                          *
*                   =================================                          *
* PURPOSE: Method to add the message to the shram write message queue          *
* ARGUMENTS: a_ucMsgNumber - Message Number                                    *
*            a_ucMsgSize   - Messag Size                                       *
* RETURN: None                                                                 *
* NOTES: Use of local variable in this function to calculate the next append   *
*        pointer is deliberte.  This is done to ensure that Append pointer is  *
*        changed atomically otherwise Application processor, being faster, can *
*        pick junk message on roll over conditions.                            *
*        DO NOT ATTEMPT TO OPTIMIZE THIS FUNCTION!!!!!!!!!!                    *
*******************************************************************************/
VOID clsShramWriteMsgQueue::AddMessage(UINT8, 
                                       UINT8 a_ucMsgSize)
{
    UINT16 AppendPtr = ShramData.uwpShramWrtMsgAppend;
    AppendPtr += a_ucMsgSize;

    // Check whether the append pointer is in the wrap-around extension area.
    // If yes, account for the space used in wrap-around extension at the
    // beginning of the buffer and set append pointer to the next location.
    if (AppendPtr >= SHRAMMSG_QUEUESIZE)
    {
        AppendPtr -= SHRAMMSG_QUEUESIZE;
    }
    
    ShramData.uwpShramWrtMsgAppend = AppendPtr;
}

//-----------------------------------------------------------------------
// Documentation:
//    This is the routine for adding SCS commands to the SCS Fifo.
//    The SCS append-offset is not updated until after all bytes of the
//    SCS command have been appended to the FIFO to avoid premature
//    processing by the co-processor.
//
//    Returns TRUE if successful or FALSE in case the command does not
//    fit.
//
// Concurrency:   Sequential
//-----------------------------------------------------------------------
BOOL clsIoLinkFifo::StoreScsCommand( UINT16* command, UINT16 cmdSize )
{
  BOOL bstatus = FALSE;
  if ( GetNumFree() >= cmdSize )
  {
    UINT16 newAppendOffset = get_AppendOffset();

    for (UINT16 idx=0; (idx<cmdSize); idx++)
    {
      set_data (newAppendOffset, command[idx]);
      if (newAppendOffset == (get_FifoSize()-1))
      {
        newAppendOffset = BARREL_START_OFFSET;
      }
      else
      {
        newAppendOffset++;
      }
    }
    set_AppendOffset(newAppendOffset);
    bstatus= TRUE;
  }

  return (bstatus);
}

//-----------------------------------------------------------------------
// Documentation:
//    This is the routine for adding SCS commands to the SCS Fifo.
//    The SCS append-offset is not updated until after all bytes of the
//    SCS command have been appended to the FIFO to avoid premature
//    processing by the co-processor.
//
//    Returns TRUE if successful or FALSE in case the command does not
//    fit.
//
// Concurrency:   Sequential
//-----------------------------------------------------------------------
BOOL clsIoLinkFifo::SendSCSCommand( UINT16 command)
{
  BOOL bstatus = FALSE;
  if ( GetNumFree() >= 1 )
  {
    UINT16 newAppendOffset = get_AppendOffset();

    set_data (newAppendOffset, command);
    if (newAppendOffset == (get_FifoSize()-1))
    {
      newAppendOffset = BARREL_START_OFFSET;
    }
    else
    {
      newAppendOffset++;
    }
    set_AppendOffset(newAppendOffset);
    bstatus= TRUE;
  }

  return (bstatus);
}

//-----------------------------------------------------------------------
// Documentation:
//    This method will append the SCS in FIFO 
//
// Concurrency:   Sequential
//-----------------------------------------------------------------------
void  clsIoLinkFifo::set_AppendOffset(const UINT16 value)
{ 
    *h_addrAppend = value;
}

//-----------------------------------------------------------------------
// Documentation:
//    This is the generic routine to get the next available
//    entry off the FIFO.   A null pointer will be returned
//    in case of errors such as FIFO empty
//
// Concurrency:   Sequential
//-----------------------------------------------------------------------
UINT16 clsIoLinkFifo::GetNextEntry(void)
{
  UINT16 temp_index;
  UINT16 next_entry=0;
  if (!isempty ())
  {
    temp_index = get_RemoveOffset();
    if (get_RemoveOffset() == (get_FifoSize() - 1))
    {
      set_RemoveOffset(BARREL_START_OFFSET);
    }
    else
    {
      set_RemoveOffset(get_RemoveOffset()+1);
    }
    next_entry = get_data(temp_index);
  }

  return (next_entry);
}

VOID *operator new(UINT32){ return NULL; }
VOID operator delete(VOID *){ }

// cast operator.
// currently multi read.
// any algorithm can be employed without
// changing client code.
template <class T>
clsSharedData32<T>::operator T() const
{
    UINT32 temp1 = ivalue;
    if(temp1 != ivalue)
    {
        UINT8 retries = 0;
        do
        {
            temp1 = ivalue; //read again.
            if(temp1 == ivalue)
            {
                return *((T*)&temp1);//success.
            }

        }while(retries++ < kMaxRetries);
        /// read failed. must crash here.
        HardFail(HF_INVPROGRAMEXEC,SVPBOXSLOT_HPP,__LINE__);
    }
    return *((T*)&temp1);
}