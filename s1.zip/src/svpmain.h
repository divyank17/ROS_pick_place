/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : svpmain.h                                                   *
*    Description : common defines used by module                               *
*******************************************************************************/
#ifndef __SVPMAIN_H__
#define __SVPMAIN_H__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "tcparamcodes.h"
#include "commonelectronics.h"
#include "tracelog.hpp"
#include "iol.hpp"
#include "debug.hpp"
#include "scheduler.hpp"
#include "tcdiag.h"
#include "wrmsgque.hpp"
#include "svpversion.h"
#include "iomslot.hpp"
#include "ioslot.hpp"
#include "inslot.hpp"
#include "outslot.hpp"
#include "shram.h"
#include "tcaoservoslot.hpp"
#include "tcailvdtslot.hpp"
#include "tcdislot.hpp" 
#include "tcsvpregctlslot.hpp"
#include "svpboxslot.hpp"

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
TASKRETURN CalibrationTask(TASKCONTEXT);
#endif 
