/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : llmuxboxslot.hpp                                            *
*    Description : Class clsLLBoxSlot declaration.                             *
* ============================================================================ *
*    Design Details  :                                                         *
*    The design of LLMUX input processing task is done in a way to optimize    *
*    use of CPU processing power. Two routines are responsible for the same.   *
*                                                                              *
* 1. If FTA is present, schedules the regular scanning of points and collects  *
*    data, otherwise, processes change request responses.                      *
* 2. If FTA is absent, does a 1 second periodic scan to check the presence.    *
*    If FTA is present, this routine processes responses of configuration      *
*    change requests issued due to database changes or reload. All the config  *
*    change requests are added to the change request FIFO upon request and     *
*    the responses are processed in this routine                               *
*******************************************************************************/
#ifndef __LLMUXBOXSLOT_HPP__
#define __LLMUXBOXSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "boxslot.hpp"
#include "llhardware.hpp"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#define LLMUXBOXSLOT_SIZE ((sizeof(clsLLBoxSlot)+(sizeof(clsLLBoxSlot)%2)) / 2)
#define SF_FTAFAIL        0
#define SF_F_IDERR        1
#define SF_FCOM_FL        2
#define SF_FVREFFL        3
#define SF_FCAL_FL        4
#define SF_FNOTCAL        5
const UINT8 MAX_RETRIES = 3; //150 ms = 3 * 50ms(Periodicity of Ppx task)
const UINT8 MAX_SCHEDULE_TIMESLOT = 20;
const UINT8 LAST_PTDATA_TIMESLOT  = 18;
const UINT8 START_SCAN_TIMESLOT   =  0;
const UINT8 END_SCAN_TIMESLOT     = 21;
const UINT8 MAXSLOTS_PER_FTA      = (MAXSLOTS/NO_OF_FTA);
const UINT8 FIFO_SIZE             = 250;//Same as PMIO
const UINT8 LLMUX_PPX_PERIOD      = 50;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsLLBoxSlot;     // forward declaration
typedef struct tagBoxParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    PASTATUS (clsLLBoxSlot::* PrePtr)(UINT8 *,UINT8);
    VOID     (clsLLBoxSlot::* PostPtr)(UINT8);
    VOID*    (clsLLBoxSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

typedef struct tagPvScanRec {
    FLOAT32 Pv;
    PVVALST PvSts;
    UINT8   Sequence;
} PVSCANREC;
/*******************************************************************************
*                                 clsLLBoxSlot                                 *
*                                 =============                                *
*******************************************************************************/
class clsLLBoxSlot : public clsBoxSlot {
private:
    FREQ6050  Freq6050;
    PVSCANREC PvScanRec[HALFMAXSLOTS];//64 Channels distributed across 2 PV scan records
    PVSCANREC PvScanRec2[HALFMAXSLOTS];
    FTATYPE   FtaType[NO_OF_FTA];
    BOOL      CalibFta[NO_OF_FTA];
    BOOL      CalibInProgress[NO_OF_FTA];
    UINT8     FtaSoftFailTable[NO_OF_FTA];
    UINT8     ChangeReqFifo[NO_OF_FTA][FIFO_SIZE];
    //Class variables used in Ppx and Scheduling of Fta Scanning
    BOOL  PeriodicScanInProgress;   //TRUE when 1sec scan is is progress.
    UINT8 CurrentScanCycle[NO_OF_FTA];//Cycle count 1 to 20
    UINT8 CurrentSlot[NO_OF_FTA];   //Slot currently being scanned
    UINT8 FtaNoRespCount[NO_OF_FTA];//Counter of no responses from FTA
    BOOL  FtaPresent[NO_OF_FTA];    //TRUE if FTA is present
    BOOL  FtaUnitId[NO_OF_FTA];     //Unit Id
    BOOL  BadTxFlag[NO_OF_FTA];     //TRUE if bad Tx
    BOOL  DenyScanRetry[NO_OF_FTA]; //FALSE if scan retry should be attempted for FTA
    BOOL  SkipDummySlot[NO_OF_FTA]; //Needed in order to syncronize FTA scanning in case
                                    //one FTA has to perform a retry. In case of retries
                                    //dummy slot is not executed. This flag marks it.
    //Fifo handling related variables
    UINT8  ServicedReqOffset[NO_OF_FTA];
    UINT8  AppendOffset[NO_OF_FTA];
    UINT16 PointBuildTable[NO_OF_FTA];
    BOOL   ReconfigInProgress[NO_OF_FTA];
    
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const SOFTFAILTYPE FtaSoftFails[][NO_OF_FTA];
    static const BOXPARAMINFO tblParamInfo[256];

    PASTATUS PreModStat1(UINT8 *,UINT8);
    VOID     PostModStat1(UINT8);
    PASTATUS PreCalibFta(UINT8 *, UINT8);
    VOID     PostCalibFta(UINT8);
    PASTATUS PreFreq6050(UINT8 *, UINT8);
    VOID     PostFreq6050(UINT8);
    PASTATUS PreCheckPoint(UINT8 *,UINT8);

    inline VOID  *GetFreq6050Ptr(VOID)   { return &Freq6050;   }  
    inline VOID  *GetPvScanRecPtr(VOID)  { return PvScanRec;   } 
    inline VOID  *GetPvScanRec2Ptr(VOID) { return PvScanRec2;  } 
    inline VOID  *GetFtaTypePtr(VOID)    { return FtaType;     }  
    inline VOID  *GetCalibFtaPtr(VOID)   { return CalibFta;    }  
    inline VOID  *GetRedParamsPtr(VOID)  { return (VOID *)NULL;}//No redundancy
    inline VOID *GetCheckPointPtr(VOID)  { return (VOID *)CheckPointVerTable[BoxChkpntVersion-1].CheckPointPtr; }

    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    friend VOID *clsAixSlot::GetPvPtr(VOID);
    friend VOID *clsAixSlot::GetPvStsPtr(VOID);
    friend VOID clsAixSlot::InitAixSlot(BOOL bFullInit, BOOL bObjCreate);

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    VOID     ProcessResponse(UINT8);
    VOID     ProcessStatusResponse(UINT8);

    //Error handling routines
    VOID ProcessNormalResponse(UINT8);
    VOID ProcessBadChecksum(UINT8);
    VOID ProcessWrongFtaId(UINT8);
    VOID ProcessNoResponse(UINT8);
    //Ppx routines
    VOID ProcessOldPVAndRequestNewData(UINT8);
    VOID FinishScanAndProcessFifo(UINT8);
    VOID ProcChangeReqFifo(UINT8);
    VOID ProcessPreviousData(UINT8);
    VOID CollectData(UINT8);
    VOID SetSlotsBad(UINT8);
    VOID ReloadFtaPoints(UINT8);
    BOOL CheckResponseForErrors(UINT8);
    VOID SendChangeRequest(UINT8);
    VOID ReadFifo(UINT8);
    VOID FlushFifo(UINT8);

    clsLLBoxSlot(const clsLLBoxSlot&); // Safeguard against def copy constr.
    clsLLBoxSlot& operator=(const clsLLBoxSlot&); // and default assignment.

    inline VOID UpdateFtaSoftFailTable  (UINT8 FtaNum, UINT8 SoftFail, BOOL Activate) {
        TRUE == Activate ?
        FtaSoftFailTable[FtaNum] |=  (0x01 << (SoftFail - 1)):
        FtaSoftFailTable[FtaNum] &= ~(0x01 << (SoftFail - 1));
    }
    inline BOOL IsFtaInSoftFail(UINT8 FtaNum) {
        return (0 != FtaSoftFailTable[FtaNum]);
    }
    inline BOOL IsReconfigInProgress(UINT8 FtaNum) {
        return ReconfigInProgress[FtaNum];
    }
public:
    clsLLBoxSlot(MODLTYPE);
    ~clsLLBoxSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,LLMUXBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32) { return ucIomDbMemory; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,LLMUXBOXSLOT_HPP,__LINE__); } 

    inline UINT8 *GetRedBoxPointer(VOID) { return (UINT8 *)&ModStat1; }

    static VOID PpxInterruptHandler(VOID);

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       AppColdInit(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);
    VOID       AppInitialization(VOID);
    VOID       AppUrgentProcess(VOID);
    VOID       LLMuxIRQ1InterruptHandler(VOID);
    VOID       SubmitReqToFifo(UINT8,SCI_CMDS,UINT8=0);
    VOID       ScanFtaAndCollectPv(UINT8);
    VOID       DoFtaStatusCollection(UINT8);
    VOID       IssueSfToFta(UINT8,UINT8,BOOL);
    BOOL       AreAllFtaPresent();
    BOOL       AreAllScanCyclesComplete();
    BOOL       AreOnlyReconfigFtasPending();
    BOOL       IsAnyFtaReconfigTakingPlace();
    RETURNSTATUS  LLMuxUartLoopBackTest(VOID);
    UARTLPBKSTS FactoryTestRxProcessing(UINT8 sucRcvUart);

    inline FLOAT32 GetPv(UINT8 a_ucChanNum) { 
        return a_ucChanNum <= HALFMAXSLOTS ?
        PvScanRec[a_ucChanNum - 1].Pv :
        PvScanRec2[a_ucChanNum - HALFMAXSLOTS - 1].Pv;
    }
    inline FLOAT32 GetPvSts(UINT8 a_ucChanNum) { 
        return a_ucChanNum <= HALFMAXSLOTS ?
        PvScanRec[a_ucChanNum - 1].PvSts :
        PvScanRec2[a_ucChanNum - HALFMAXSLOTS - 1].PvSts;
    }
    inline VOID SetPv(UINT8 a_ucChanNum, FLOAT32 a_fPv) {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_IOLN);
        if(a_ucChanNum <= HALFMAXSLOTS)
            PvScanRec[a_ucChanNum - 1].Pv = a_fPv;
        else
            PvScanRec2[a_ucChanNum - HALFMAXSLOTS - 1].Pv = a_fPv;
        set_imask_exr(uiMask);
    }
    inline VOID SetPvSts(UINT8 a_ucChanNum, PVVALST a_PvSts) { 
        if(a_ucChanNum <= HALFMAXSLOTS) PvScanRec[a_ucChanNum - 1].PvSts = a_PvSts;
        else PvScanRec2[a_ucChanNum - HALFMAXSLOTS - 1].PvSts = a_PvSts;
        SLOT(a_ucChanNum)->UpdateBadPvFl(PVVALST_BAD == a_PvSts);
    }
    inline UINT32 GetRedBoxDelta(VOID)                { return 0;                 }
    inline UINT32 GetRedBoxSize(VOID)                 { return ((UINT32)0);       }
    inline UINT8  GetFtaType(UINT8 ucFtaNum)          { return FtaType[ucFtaNum]; }
    inline BOOL   GetCalibFta(UINT8 FtaNum)           { return CalibFta[FtaNum];  }
    inline UINT8  GetFreq6050()                       { return Freq6050;          }
    inline BOOL   GetFtaPresence(UINT8 a_FtaNum)      { return FtaPresent[a_FtaNum];}
    inline BOOL   GetFtaUnitId(UINT8 a_FtaNum)        { return FtaUnitId[a_FtaNum]; }
    inline UINT8  GetPresentScanCycle(UINT8 a_FtaNum) { return CurrentScanCycle[a_FtaNum];}
    inline UINT16 GetPointBuildStatus(UINT8 a_FtaNum) { return PointBuildTable[a_FtaNum];}

    inline VOID SetFreq6050(FREQ6050 a_Freq6050)                   { Freq6050 = a_Freq6050; }
    inline VOID SetPresentScanCycle(UINT8 a_FtaNum, UINT8 a_Cycle) { CurrentScanCycle[a_FtaNum] = a_Cycle;}
    inline VOID SetPointBuildStatus(UINT8 a_FtaNum, UINT16 Bitmap) { PointBuildTable[a_FtaNum] = Bitmap;}

    inline VOID UpdatePointBuildTable(UINT8 Slot, BOOL Activate) {
        TRUE == Activate ?
        PointBuildTable[(Slot-1)/MAXSLOTS_PER_FTA] |=  (0x01 << ((Slot-1)%MAXSLOTS_PER_FTA)):
        PointBuildTable[(Slot-1)/MAXSLOTS_PER_FTA] &= ~(0x01 << ((Slot-1)%MAXSLOTS_PER_FTA));
    }
    inline VOID IncrementSequence(UINT8 a_ucChanNum) {
        if(a_ucChanNum <= HALFMAXSLOTS)
            PvScanRec[a_ucChanNum - 1].Sequence++;
        else
            PvScanRec2[a_ucChanNum - HALFMAXSLOTS - 1].Sequence++;
    }
    inline BOOL IsFactoryMode(VOID) { return ModStat1.Factory; }

    inline VOID SetFtaUartLpbkSts(UINT8 UartNo,UARTLPBKSTS Sts){
        TstFunctTime = ((*(UINT32 *)GetTstFunctTimePtr())|
                        ((UINT32)Sts << (UartNo*BYTESIZE)));
    }

    inline VOID SetLLMUXUartRTS(UINT8 UartNo,BOOL State){
        if(State){
            IRQ1_ENABLE = DISABLE;//Disabling IRQ1 thus handler is not invoked and RTS is not reset.
            FTA_UART(UartNo).REQUEST_TO_SEND = 1;
        }
        else{
            IRQ1_ENABLE = ENABLE;
            FTA_UART(UartNo).REQUEST_TO_SEND = 0;
        }
   }
};
#endif // LLMUXBOXSLOT_HPP
