/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : doboxslot.hpp                                               *
*    Description : Class clsDoBoxSlot declaration.                             *
*******************************************************************************/
#ifndef __DOBOXSLOT_HPP__
#define __DOBOXSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "boxslot.hpp"
#include "doslot.hpp"
#include "doversion.h"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#define DOBOXSLOT_SIZE ((sizeof(clsDoBoxSlot) + (sizeof(clsDoBoxSlot) % 2)) / 2)

//PARAMETER NUMBER CONSTANTS
#define PARAMID_SOALL           92 
#define PARAMID_STSINITCPY      104
#define PARAMID_OUTRGALL        105

#if defined(DIGTYPE_DO32)
#define PARAMID_T_FLUID0_PRI    247
#define PARAMID_T_FLUID1_PRI    248
#endif

#if defined(DIGTYPE_DO16)
// added due to PAR# 1-90NDJUH (few channels were showing channel soft failure, wrongly)
// modified diagnostic count for 16 channels
#define MAXHSOCBANKS        2
#define LPBKDIAGCOUNT       1   // 30ms per bank, total 60ms for all channels
#else
#define MAXHSOCBANKS        4
#define LPBKDIAGCOUNT       3   // 30ms per bank, total 120ms for all channels
#endif

#define CHANNELSPERBANK     8

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsDoBoxSlot; // forward declaration
typedef struct tagBoxParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    PASTATUS (clsDoBoxSlot::* PrePtr)(UINT8 *, UINT8);
    VOID (clsDoBoxSlot::* PostPtr)(UINT8);
    VOID *   (clsDoBoxSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

// DO redundancy definitions
const UINT8 INH_ON_ON   = 0x00;
const UINT8 INH_ON_OFF  = 0x38;
const UINT8 INH_OFF_ON  = 0x08;
const UINT8 INH_OFF_OFF = 0x18;
const UINT8 INHIBIT_FAULTED  = 0x08;
const UINT8 INH_ON_OFF_FLTD  = 0x30;
const UINT8 INH_OFF_ON_FLTD  = 0x00;
const UINT8 INH_OFF_OFF_FLTD = 0x10;
const UINT8 SW_ON       = TRUE;
const UINT8 SW_OFF      = FALSE;
const UINT8 INH_SW_MASK = 0x38;
const UINT8 TST_SW_MASK = 0x02;
const UINT8 EN_SW_MASK  = 0x01;

const UINT8 COMPARELOOPBACK = 1;
const UINT8 COMPARELATCH    = 2;

/*******************************************************************************
*                                  clsDoBoxSlot                                *
*                                  ============                                *
*******************************************************************************/
class clsDoBoxSlot : public clsBoxSlot {
private:
    BLIND   FaultOutput[4];
    // !!!*** BOXSLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the box slot's redundant synch data area
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedBoxSize() must be updated to
    // reference the new end member. This dump record begins in clsBoxSlot.
#ifdef IOMTYPE_UIO
    BOOL    HADCEnable[MAXSLOTS];
    UINT8   HADCStatus[MAXSLOTS];
#endif

    BLIND   OutRgAll[4];
    BLIND   StsInitCpy[4];
    UINT8   HoldRegImage[4];
    UINT8   OutputBuffer1[4];
    UINT8   OutputBuffer2[4];
    BOOL    UpdateOutputBuffer;
    UINT8   IotaType;
    UINT8   DiagCycleCounter;
    UINT8   DiagBankCounter;
    UINT8   ucCurrentSlotNum;   // used for Anti-PingPong
    BOOL    bDisableFO;

    static const UINT8 SoAll[];
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const UINT8 aMirrorByte[];
    static const BOXPARAMINFO tblParamInfo[256];

// for PMIO DO16 redesign
#if defined(IOPTYPE_DO)
#if defined(DIGTYPE_DO32)
    UINT8     T_Fluid0_Pri;
    UINT8     T_Fluid1_Pri;
#endif
    BOOL      LpbkBd;
    UINT8     SltCntr;
    UINT16    OutRegImg;
    UINT16    FailRgImg;
    UINT8     PrmChngd;
    FL_UNPWRD Fl_UnPwrd_Bx;
    static const UINT8 PmioDumpParamTbl[]; 
    BLIND PmBxSfBits[SLOTINFAIL_SIZE];
#endif

#ifdef IOMTYPE_UIO
    PASTATUS PreHADCEnable(UINT8 *,UINT8);
    VOID     PostHADCEnable(UINT8);
    inline VOID *GetHADCEnablePtr(VOID)   { return (VOID *)HADCEnable; }
    inline VOID *GetHADCStatusPtr(VOID)   { return (VOID *)HADCStatus; }
#endif
    inline VOID *GetOutRgAllPtr(VOID)   {return OutRgAll;}
    inline VOID *GetStsInitCpyPtr(VOID) {return StsInitCpy;}
    inline VOID *GetSoAllPtr(VOID)      {return (VOID *)SoAll;}
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[BoxChkpntVersion-1].CheckPointPtr;}
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams;}

    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    friend VOID *clsDoSlot::GetInitReqPtr(VOID);
#if !defined(IOPTYPE_DO)
    UINT8    *GetParamPtr(UINT8);
#endif
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsDoBoxSlot(const clsDoBoxSlot&); // Safeguard against default copy constr.
    clsDoBoxSlot& operator=(const clsDoBoxSlot&); // and defualt assignement.

public:
    UINT8  OverCurrent[4];
    static volatile UINT8 *OutputPorts[];
    clsDoBoxSlot(MODLTYPE);
    ~clsDoBoxSlot(VOID) {HardFail(HF_INVPROGRAMEXEC,DOBOXSLOT_HPP,__LINE__);}

    VOID *operator new(UINT32) {return ucIomDbMemory;}
    VOID operator delete(VOID *) {HardFail(HF_INVPROGRAMEXEC,DOBOXSLOT_HPP,__LINE__);}

    static VOID IRQ3InterruptHandler(VOID);

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       AppColdInit(VOID);
    BOOL       AppFOProcess(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);   
    VOID        AppStcProcessing(VOID);
    PASTATUS    PreCheckPoint(UINT8 *, UINT8);

#if defined(IOPTYPE_DO)
    VOID  PostFl_UnPwrd_Bx(UINT8);
#if defined(DIGTYPE_DO32)
    BOOL  SwitchInit(VOID);
    VOID  SetTestSwitch(BOOL);
    VOID  TestSwitchCheck(BOOL);
    BOOL  InhibitSwitchCheck(UINT8);
    VOID  InhibitSwitchDiagnostics(VOID);
    VOID  EnableSwitchCheck(BOOL);
    VOID  EnableSwitchDiagnostics(VOID);
    UINT8 InhibitSwitchStatus();
#endif //#if defined(DIGTYPE_DO32)

    inline VOID *GetPmBxSfBitsPtr(VOID)
    {
        UINT8 ucIndex;

        for (ucIndex = 0; ucIndex < 6; ucIndex++)
            PmBxSfBits[ucIndex] = BoxSfBits[ucIndex];

        for (ucIndex = 6; ucIndex < 12; ucIndex++)
            PmBxSfBits[ucIndex] = SlotSfBits[ucIndex - 6];

        for (ucIndex = 12; ucIndex < 16; ucIndex++)
            PmBxSfBits[ucIndex] = MapSlotInFail[ucIndex - 12];

        return PmBxSfBits;
    }

    inline UINT32 GetRedBoxSize(VOID)    { return PMIO_BOXDUMP_PARAMSIZE; }
    inline UINT8 *GetRedBoxPointer(VOID) { return (UINT8 *)PmioDumpParamTbl; }

#else
    
    inline UINT32 GetRedBoxSize(VOID) {
        return ((UINT32)((UINT8 *)&FaultOutput - (UINT8 *)&ModStat1) + sizeof(FaultOutput));
    }
        
    inline UINT8 *GetRedBoxPointer(VOID) {
        return (UINT8 *)&ModStat1;
    }

#endif

    inline UINT32 GetRedBoxDelta(VOID) { return 0; }

    inline BOOL GetUpdateOutputBuffer(VOID) {return UpdateOutputBuffer;}

    inline VOID SetInitReq(UINT8 a_ucChanNum,BOOL a_bInitReq) {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        (a_bInitReq) ? (StsInitCpy[ucByteIndex] |= ucBitIndex)
                     : (StsInitCpy[ucByteIndex] &= ~ucBitIndex);
    }
  
    inline UINT32 GetAllFaultOutputs(VOID) {return *(UINT32 *)FaultOutput;}

    inline VOID SetFaultOutput(UINT8 a_ucChanNum,BOOL a_bFaultOutput) {
        UINT8 ucBitIndex  = 0x01 << ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        (a_bFaultOutput) ? (FaultOutput[ucByteIndex] |= ucBitIndex)
                         : (FaultOutput[ucByteIndex] &= ~ucBitIndex);
    }

     VOID UpdateOutputBuffer2(UINT8 a_ucChanNum,BOOL a_bOutput) {
        UINT8 ucBitIndex  = 0x01 << ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        (a_bOutput) ? (OutputBuffer2[ucByteIndex] |= ucBitIndex)
                    : (OutputBuffer2[ucByteIndex] &= ~ucBitIndex);
#if defined(IOPTYPE_DO)
        // fix for PAR # DO32 Pulse period feature not working as expected
        if (TRUE == SLOT(a_ucChanNum)->GetPulseInProgState())
#else
      if((SLOT(a_ucChanNum)->GetDOType() == DOTYPE_ONPULSE) || 
          (SLOT(a_ucChanNum)->GetDOType() == DOTYPE_OFFPULSE))
#endif
         SLOT(a_ucChanNum)->SetSO(a_bOutput);
    }

    inline VOID SetOverCurrent(UINT8 a_ucChanNum,BOOL a_bOutput) {
        UINT8 ucBitIndex  = 0x01 << ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        (a_bOutput) ? (OverCurrent[ucByteIndex] |= ucBitIndex)
                    : (OverCurrent[ucByteIndex] &= ~ucBitIndex);
    }

    inline BOOL GetOverCurrent(UINT8 a_ucChanNum) {
        UINT8 ucBitIndex  = 0x01 << ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        return ((OverCurrent[ucByteIndex] & ucBitIndex) > 0) ? TRUE : FALSE;
    }
    inline VOID SetOutputBuffer1(UINT32 ulValue) {*(UINT32 *)OutputBuffer1 = ulValue;}
    inline UINT32 GetOutputBuffer1(VOID) {return *(UINT32 *)OutputBuffer1;}
    inline UINT32 GetOutputBuffer2(VOID) {return *(UINT32 *)OutputBuffer2;}
    inline BOOL IsExtBdSFActive(VOID) {return (BoxSfBits[23] & 0x02);}
    inline BOOL IsOutputFlActive(VOID) {return (BoxSfBits[2] & 0x80);}
    VOID LoopbackDiagnostics(UINT8);
    VOID SetForPrimary(VOID);
    VOID SetForSecondary(BOOL);
    VOID EnableOutputFailFO(VOID) { SfActionTbl[2] |= 0x80; }
    VOID CheckFailOverCondition(VOID);

#ifdef IOMTYPE_UIO
    inline BOOL GetHADCEnable(UINT8 a_ucSlot) { return HADCEnable[a_ucSlot - 1]; }
    inline UINT8 GetHADCStatus(UINT8 a_ucSlot) { return HADCStatus[a_ucSlot - 1]; }
    inline VOID ResetHADCEnable(UINT8 a_ucSlot) { HADCEnable[a_ucSlot - 1] = FALSE; }
    inline VOID SetHADCStatus(UINT8 a_ucSlot, UINT8 a_ucStatus) { HADCStatus[a_ucSlot - 1] = a_ucStatus; }
#endif

#ifdef DEBUG
    // Debug statistics for AppStc execution time.
    UINT16 uiExecTime,uiMaxStcTime;
#endif

// for PMIO DO16 redesign
#if defined(IOPTYPE_DO)

#if defined(DIGTYPE_DO16)
    UINT16 uiEnableOutputLatch;
    VOID   OutputLatch(BOOL bOutputLatch, BOOL bLatchType);
#endif
    
    UINT8 *GetParamPtr(UINT8);

#if defined(DIGTYPE_DO32)
    inline VOID *GetT_Fluid0_PriPtr(VOID)   { return &T_Fluid0_Pri; }
    inline VOID *GetT_Fluid1_PriPtr(VOID)   { return &T_Fluid1_Pri; }
#endif
    inline VOID *GetLpbkBdPtr(VOID)         { return &LpbkBd;  }
    inline VOID *GetOutRegImgPtr(VOID)      { return &OutRegImg; }
    inline VOID *GetFailRgImgPtr(VOID)      { return &FailRgImg; }
    inline VOID *GetPrmChngdPtr(VOID)       { return &PrmChngd; }
    inline VOID *GetSltCntrPtr(VOID)        { return &SltCntr; }
    inline BOOL  GetFl_UnPwrd_Bx(VOID)      { return Fl_UnPwrd_Bx; }
    inline VOID *GetFl_UnPwrd_BxPtr(VOID)   { return &Fl_UnPwrd_Bx; }
    inline VOID *GetPmioDumpParamPtr(VOID)  { return (VOID *)PmioDumpParamTbl; }
    inline UINT8 IsCheckPointParam(UINT8 ucParamId)
    {
        UINT8 ucArrayIndex = 0;
        UINT8 ucChkPntIndex = 0;

        while (CheckPointVer1[ucArrayIndex])
        {
            if (CheckPointVer1[ucArrayIndex] == ucParamId)
                return (ucChkPntIndex + 1);
            else
                ucChkPntIndex += GetParamSize(CheckPointVer1[ucArrayIndex]);

            ucArrayIndex++;
        }

        return PA_NULL;
    }
#endif
};

#endif 
