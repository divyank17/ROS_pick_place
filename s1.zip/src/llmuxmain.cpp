/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : llmuxmain.cpp                                                 *
*    Description : LLMUX module application specific startup code. *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "llmuxmain.h"
#include "iol.hpp"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN DiagnosticTask(TASKCONTEXT);
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
WRITEINPROGRESS  WriteInProgress;
#ifdef DEBUG
clsDebugPort     DebugPort;
#endif

// Global objects
#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section
clsTaskScheduler TaskScheduler;

#pragma section  INTERNALRAM_SECTION
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;
clsLLMuxHardware LLMuxHardware;
#pragma section 

// Pointers to database objects
clsIomSlot       *pDatabase[MAXSLOTS + 1];
// Database Memory
UINT16 ucIomDbMemory[LLMUXBOXSLOT_SIZE + (MAXSLOTS * LLMUXSLOT_SIZE)];

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//NOTE:
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                            WriteDatabaseTask
                                           ,LowPriorityTask
                                           ,EventRecoveryTask
                                           ,DiagnosticTask
#ifdef DEBUG
                                           ,DebugTask
#endif
};

/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
*    Application specific startup code.                                        *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function is called by the PowerOn reset vector.                      *
*******************************************************************************/
VOID main(VOID) {
    UINT8 ProductCode = *((UINT8*)(MODULEINFO_START_ADDRESS + HW_PROD_CODE_OFFSET));
    // Create box and slot database objects
    if(ProductCode == PRODCODE_LLMUX_S8)
        pDatabase[0] = new clsLLBoxSlot(MODLTYPE_LLMUX_S8);
    else
        pDatabase[0] = new clsLLBoxSlot(MODLTYPE_LLMUX);
    TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxIom,BOX->GetDPA());
    for (UINT8 ucSltNm = 0; ucSltNm < MAXSLOTS; ucSltNm++) {
        pDatabase[ucSltNm + 1] = new(ucSltNm) clsLLSlot(ucSltNm + 1);
    }
    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();
    
    // Initialize all periodic tasks
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
                                        DMCPERIOD_LPTASK);
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
                                        DMCPERIOD_DIAGTASK);

#ifdef DEBUG
    // Set the Debug Task to RUN State
    TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif

    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}
/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
* Runs Task every 1 seconds,can view LowPriorityTask over Debug terminal       *
* to identify the task                                                         *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();
    // Call FtaPowerFailMonitorRoutine to find out if the Power supply
    // has degraded beyond the acceptable limits. Issues SF if power
    // supply dips below 19V.
    FtaPowerMonitorRoutine();
    TASKRETURN TaskReturnValue(TASKRETURNSTATE_TERMINATE,a_TaskContext,0);
    return TaskReturnValue;
}
