/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : scheduler.hpp                                               *
*    Description : Declarations and constants for scheduler.                   *
*******************************************************************************/
#ifndef __SCHEDULER_HPP__
#define __SCHEDULER_HPP__
/******************************************************************************
*                               INCLUDE FILES                                 *
******************************************************************************/
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "commonelectronics.h"
/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
const UINT16 SCHEDULER_PERIOD  = 10; // In units of msec
// TGRA value for 10 msec interrupt with system clock divide by 4 configuration.
const UINT16 TPUCOUNT_MAXVALUE = (UINT16)((SYSTEM_CLOCK_FREQUENCY / 4) /
                                 (MILLISECONDS_IN_SECOND / SCHEDULER_PERIOD));
const UINT16 TPUCOUNT_HALFVALUE = TPUCOUNT_MAXVALUE / 2;
const UINT16 TPUCOUNT_IN_MILLISECOND = TPUCOUNT_MAXVALUE / SCHEDULER_PERIOD;
const UINT16 TPUCOUNT_IN_MICROSECOND = TPUCOUNT_IN_MILLISECOND / MICROSECONDS_IN_MILLISECOND;
#if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE) || defined(IOMTYPE_LLMUX) || defined(IOMTYPE_UIO))
const UINT16 TPUCOUNT_STCOVERRUN = 5 * TPUCOUNT_IN_MILLISECOND;
#else
const UINT16 TPUCOUNT_STCOVERRUN = 3 * TPUCOUNT_IN_MILLISECOND / 2;
#endif

// Number of scheduler ticks to count 1 second. 
const UINT8 SCHEDULER_TICKS_IN_SECOND = MILLISECONDS_IN_SECOND / SCHEDULER_PERIOD;

const UINT32 WDT_MAX_TIME_IN_MICROSEC = 150000; 
const UINT8  WDT_MAX_TIME_IN_STCTICKS = 15; 
const UINT8  STCTICKS_60MILLISEC  = 6;
const UINT8  STCTICKS_100MILLISEC = 10;
const UINT8  STCTICKS_120MILLISEC = 12;

#if defined(IOMTYPE_UIO)
// The diag counter m_uiWdtDiagCounter is incremented by one every time WDT
// refresh is done. With 10 msec refresh, it takes 6000 diag counts for running
// watchdog diagnostics once every minute. 60000/10 = 6000.
// Subtract 1 because the comparison is done as greater than DiagCount
const UINT16 WDT_DIAGSTART_DIAGCOUNT  = 5999;
#else
// The diag counter m_uiWdtDiagCounter is incremented by one every time WDT
// refresh is done. With 80 msec refresh, it takes 750 diag counts for running
// watchdog diagnostics once every minute. 60000/80 = 750.
const UINT16 WDT_DIAGSTART_DIAGCOUNT  = 749; 
#endif

// TPU channel 5 delay counter for STCOVRUN softfail.
const UINT8 MAX_STCOVERRUN_COUNT = 5;

// Maximum request count for posting request overflow softfail
const UINT8 MAX_TASKREQ_COUNT = 7;

// Maximum value of CPU free running counter. This value is experimentally 
// calculated using the PrintStat debug rountine. This value should be redefined
// if there are changes made to STCInterruptHandler or ExecuteTaskScheduler.
#if HEK
#ifdef IOMTYPE_UIO
    const UINT32 MAX_CPUFREE_COUNT = 52372;
#elif defined IOMTYPE_SP
    const UINT32 MAX_CPUFREE_COUNT = 29989;
#else
    const UINT32 MAX_CPUFREE_COUNT = 68500;
#endif
#else
    const UINT32 MAX_CPUFREE_COUNT = 93000; 
#endif

// Time in seconds for which CPU statistic update is suspended
// after the "Reset Statistics" button is pressed by the user.
const UINT8 STAT_RESET_TIME = 5;


#ifdef IOMTYPE_AIH
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_CALIBTASK    = 0x03;
    const UINT8 TASKID_EVRCTASK     = 0x04;
    const UINT8 TASKID_HARTTASK     = 0x05;
    const UINT8 TASKID_DIAGTASK     = 0x06;
    #ifdef DEBUG
    const UINT8 TASKID_DEBUGTASK    = 0x07;
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks units of milliseconds
    const UINT16 TASKPERIOD_LPTASK      = 100;
    const UINT16 TASKPERIOD_HARTTASK    = 250;
    const UINT16 TASKPERIOD_DIAGTASK    = 250;  
    // DMC period for all periodic tasks in units of milliseconds
    const UINT16 DMCPERIOD_LPTASK      = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_HARTTASK    = TASKPERIOD_HARTTASK * 2;  
    const UINT16 DMCPERIOD_DIAGTASK    = TASKPERIOD_DIAGTASK * 2;  
#endif
#if defined(IOMTYPE_SVP) || defined(IOMTYPE_SP)
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_CALIBTASK    = 0x03; 
    const UINT8 TASKID_EVRCTASK     = 0x04;  
    const UINT8 TASKID_DIAGTASK     = 0x05;  
    #ifdef DEBUG
    const UINT8 TASKID_DEBUGTASK    = 0x06;
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks units of milliseconds
    const UINT16 TASKPERIOD_LPTASK      = 100;
    const UINT16 TASKPERIOD_DIAGTASK    = 250;  
    // DMC period for all periodic tasks in units of milliseconds
    const UINT16 DMCPERIOD_LPTASK      = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_DIAGTASK    = TASKPERIOD_DIAGTASK * 2;  
#endif
#ifdef IOMTYPE_AOH
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_CALIBTASK    = 0x03;
    const UINT8 TASKID_EVRCTASK     = 0x04;
    const UINT8 TASKID_HARTTASK     = 0x05;
    const UINT8 TASKID_DIAGTASK     = 0x06;
    #ifdef DEBUG
    const UINT8 TASKID_DEBUGTASK    = 0x07;
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks in units of milliseconds
    const UINT16 TASKPERIOD_LPTASK      = 100;
    const UINT16 TASKPERIOD_HARTTASK    = 250;
    const UINT16 TASKPERIOD_DIAGTASK    = 250;
    // DMC period for all periodic tasks in units of milliseconds
    const UINT16 DMCPERIOD_LPTASK      = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_HARTTASK    = TASKPERIOD_HARTTASK * 2;  
    const UINT16 DMCPERIOD_DIAGTASK    = TASKPERIOD_DIAGTASK * 2;  
#endif

#if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_EVRCTASK     = 0x03;
    const UINT8 TASKID_DIAGTASK     = 0x04;
    #ifdef IOMTYPE_DISOE
    const UINT8 TASKID_EVMTASK      = 0x05;
    #endif
    #ifdef DEBUG
    #ifdef IOMTYPE_DISOE
    const UINT8 TASKID_DEBUGTASK    = 0x06;
    #else
    const UINT8 TASKID_DEBUGTASK    = 0x05;
    #endif // DISOE
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else // DEBUG
    #ifdef IOMTYPE_DISOE
    const UINT8 TASKCOUNT = TASKID_EVMTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif // DISOE
    #endif // DI or DISOE
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks units of milliseconds
    const UINT16 TASKPERIOD_LPTASK      = 100;
    const UINT16 TASKPERIOD_DIAGTASK    = 250;
    // DMC period for all periodic tasks in units of milliseconds
    const UINT16 DMCPERIOD_LPTASK      = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_DIAGTASK    = TASKPERIOD_DIAGTASK * 2;
#endif
#ifdef IOMTYPE_DO
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_EVRCTASK     = 0x03;
    const UINT8 TASKID_DIAGTASK     = 0x04;
    #ifdef DEBUG
    const UINT8 TASKID_DEBUGTASK    = 0x05;
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks in units of milliseconds
    const UINT16 TASKPERIOD_LPTASK      = 100;  
    const UINT16 TASKPERIOD_DIAGTASK    = 250;  
    // DMC period for all periodic tasks in units of milliseconds
    const UINT16 DMCPERIOD_LPTASK      = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_DIAGTASK    = TASKPERIOD_DIAGTASK * 2;  
#endif
#ifdef IOMTYPE_LLMUX
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_EVRCTASK     = 0x03;
    const UINT8 TASKID_DIAGTASK     = 0x04;
    #ifdef DEBUG
    const UINT8 TASKID_DEBUGTASK    = 0x05;
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks in units of milliseconds
    const UINT16 TASKPERIOD_LPTASK   = 100;  
    const UINT16 TASKPERIOD_DIAGTASK = 250;  
    // DMC period for all periodic tasks in tens of milliseconds
    const UINT16 DMCPERIOD_LPTASK   = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_DIAGTASK = TASKPERIOD_DIAGTASK * 2;  
#endif
#ifdef IOMTYPE_PI
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_EVRCTASK     = 0x03;
    const UINT8 TASKID_DIAGTASK     = 0x04;
    #ifdef DEBUG
    const UINT8 TASKID_DEBUGTASK    = 0x05;
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks in units of milliseconds
    const UINT16 TASKPERIOD_LPTASK   = 100;  
    const UINT16 TASKPERIOD_DIAGTASK = 250;  
    // DMC period for all periodic tasks in tens of milliseconds
    const UINT16 DMCPERIOD_LPTASK   = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_DIAGTASK = TASKPERIOD_DIAGTASK * 2;  
#endif
#ifdef IOMTYPE_UIO
    // Task IDs (in the order of priority)
    const UINT8 TASKID_WRDBTASK     = 0x01;
    const UINT8 TASKID_LPTASK       = 0x02;
    const UINT8 TASKID_EVRCTASK     = 0x03;
    const UINT8 TASKID_HARTTASK     = 0x04;    
    const UINT8 TASKID_DIAGTASK     = 0x05;
    #ifdef DEBUG
    const UINT8 TASKID_DEBUGTASK    = 0x06;
    const UINT8 TASKCOUNT = TASKID_DEBUGTASK;
    #else
    const UINT8 TASKCOUNT = TASKID_DIAGTASK; 
    #endif
    const UINT8 TASKID_INVALID      = 0xFF;
    // Task Period for Periodic tasks in units of milliseconds
    const UINT16 TASKPERIOD_LPTASK   = 100;  
    const UINT16 TASKPERIOD_HARTTASK = 250;
    const UINT16 TASKPERIOD_DIAGTASK = 250;  
    // DMC period for all periodic tasks in tens of milliseconds
    const UINT16 DMCPERIOD_LPTASK   = TASKPERIOD_LPTASK * 3;
    const UINT16 DMCPERIOD_HARTTASK = TASKPERIOD_HARTTASK * 2;    
    const UINT16 DMCPERIOD_DIAGTASK = TASKPERIOD_DIAGTASK * 2;  
#endif

/*******************************************************************************
*                               TYPES & ENUMERATIONS                           * 
*******************************************************************************/
typedef enum tagTaskReturnState {
    TASKRETURNSTATE_TERMINATE = 0,
    TASKRETURNSTATE_SUSPEND   = 1
} TASKRETURNSTATE;

typedef enum tagTaskContext {
    TASKCONTEXT_ZERO  = 0,
    TASKCONTEXT_ONE   = 1,
    TASKCONTEXT_TWO   = 2,
    TASKCONTEXT_THREE = 3,
    TASKCONTEXT_FOUR  = 4,
    TASKCONTEXT_FIVE  = 5,
    TASKCONTEXT_SIX   = 6,
    TASKCONTEXT_SEVEN = 7
} TASKCONTEXT;

//Executive Error Codes definitions 
typedef enum tagExecErrorCode
{
 EXEC_STC_OVERRUN        = 0x0008, //STC overrun 
 EXEC_WDT_NOTREFRESHED   = 0x0004, //Diagnostic not run error 
 EXEC_REREQ_OVERRUN      = 0x0002, //ReRequest overun error
 EXEC_RRNW_OVERRUN       = 0x0001 //Resume Request of Non waiting Task 
}EXECERRORCODE;

typedef enum tagTaskState {
    TASKSTATE_ASLEEP        = 0x00,
    TASKSTATE_RUNNING       = 0x01,
    TASKSTATE_READYTORUN    = 0x02,
    TASKSTATE_WAITING       = 0x04,
    TASKSTATE_READYTORESUME = 0x08
} TASKSTATE;

typedef enum tagWdtDiagState {
    WDTDIAG_RESET   = 0,
    WDTDIAG_RUNNING = 1
} WDTDIAG_STATE;

typedef struct tagTaskReturn 
{
    TASKRETURNSTATE  TaskReturnState;
    TASKCONTEXT      TaskContext;
    UINT8            ucReserved;
    UINT8            ucSuspendTime;
    tagTaskReturn() {}
    tagTaskReturn(TASKRETURNSTATE trs,TASKCONTEXT tc,UINT8 st) :
        TaskReturnState(trs),TaskContext(tc),ucSuspendTime(st) {}
} TASKRETURN;

//Task definition table 
typedef struct tagTaskDefinitionTable 
{
    TASKRETURN (*TaskFunctionPtr)(TASKCONTEXT);
} TASKDEFINITIONTABLE;

//Periodic task table
typedef struct tagPeriodicTable 
{
    UINT16 usDownCounter;//timeout period of the periodic task
    UINT16 usPeriod;//time out period for reloading the downcounter
} PERIODICTABLE;

//Task Delay/Suspend Table
typedef struct tagDelaySuspendTable {
    UINT16 usDownCounter;//suspend time of the task
    TASKCONTEXT  TaskContext;//task context
} DELAYSUSPENDTABLE;

//Task status table
typedef struct tagTaskStatus {
    TASKSTATE TaskState;//State of the task
    UINT8 ucRequestCounter;//ReRequest counter for the task
}TASKSTATUS;

typedef struct tagDmcTable {
    UINT16  usLifespan;     // DMC lifespan in clock ticks
    UINT16  usCurrentLife;  // Current lifespan in clock ticks
} DMCTABLE;
/*******************************************************************************
*                                 clsTaskScheduler                             * 
*                                 ================                             *
*******************************************************************************/
class clsTaskScheduler {
private:
    UINT32  m_ul10msCounter; // 10 msec clock counter
    UINT32  m_ulLast10msCounter; // Scheduler's Last execution time
    UINT8   m_ucWdtRefreshCounter;
    UINT16  m_uiWdtDiagCounter;
    WDTDIAG_STATE m_WdtDiagState;
    BOOL    m_bWdtEnabled;
    UINT8   m_ucActiveTask; // Active task number
    UINT16  m_usTaskActivationBits; 
    UINT8   m_ucDelayedTaskCount;
    BOOL    m_bOneSecondTimerFlag; 
    UINT32  m_ulCpuFreeTimeCounter;
    UINT8   m_ucStatResetCounter;
    UINT8   m_ucStcOverrunCount;
    // Customer (MiRO) Issue(CL Fail) Fix - To count no of write requests tobe processed in the buffer
    UINT16  m_usWriteReqCount;

    static const TASKDEFINITIONTABLE m_TaskDefinitionTable[TASKCOUNT];
    PERIODICTABLE       m_PeriodicTable[TASKCOUNT];
    DELAYSUSPENDTABLE   m_DelaySuspendTable[TASKCOUNT];
    TASKSTATUS          m_TaskStatus[TASKCOUNT];
    DMCTABLE            m_DmcTable[TASKCOUNT];

    clsTaskScheduler(const clsTaskScheduler&); // Safeguard against def copy constr.
    clsTaskScheduler& operator=(const clsTaskScheduler&); // and default assignment.

public:
    clsTaskScheduler(VOID);
    ~clsTaskScheduler(VOID) { HardFail(HF_INVPROGRAMEXEC,SCHEDULER_HPP,__LINE__); }

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,SCHEDULER_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) {  HardFail(HF_INVPROGRAMEXEC,SCHEDULER_HPP,__LINE__); };

    static VOID STCInterruptHandler(VOID);

    inline UINT32 Get10msecCounter(VOID) { return m_ul10msCounter; }
    inline VOID SetStcOverrunCounter(UINT8 a_ucCount) { m_ucStcOverrunCount=a_ucCount; }
    inline VOID EnableWatchdog(VOID) {
        if (FALSE == m_bWdtEnabled) {
            WDT_EN_n = 0;
            m_bWdtEnabled = TRUE;
            m_ucWdtRefreshCounter = 0;
            m_uiWdtDiagCounter = 0;
        }
    }

    inline UINT8 GetWdtRefreshCounter(VOID) { return m_ucWdtRefreshCounter; }
    inline VOID StatReset(VOID) { m_ucStatResetCounter = STAT_RESET_TIME; }

    inline WDTDIAG_STATE GetWdtDiagState(VOID) { return m_WdtDiagState;}

    VOID InitPeriodicTask(UINT8,UINT16,UINT16);
    VOID RunTask(UINT8); 
    VOID RefreshTaskDmc(UINT8);
    VOID ExecuteTaskScheduler(VOID); //Main scheduler executive function
    VOID StopImpendingWatchdog(VOID);

#ifdef DEBUG
    UINT16 uiMaxStcLatency;
#endif
    
};

/*******************************************************************************
*                                 clsStopwatch                                 *
*                                 ============                                 *
*******************************************************************************/
class clsStopwatch {
    private:

        enum { kDefaultRunningAvgConst = 20 };

        // coarse timebase records
        UINT32 start10ms;
        UINT32 stop10ms;

        // fine timebase records
        UINT16 startTpu;
        UINT16 stopTpu;

        // statistics
        FLOAT32 minTime;
        FLOAT32 maxTime;
        FLOAT32 avgTime;
        FLOAT32 lastTime;

        // running average constant
        FLOAT32 runAvgConst;

        inline VOID CalculateTime(VOID) {
            // calculate TPU counts
            lastTime = (TPUCOUNT_MAXVALUE * (stop10ms - start10ms)) + stopTpu - startTpu;

            // scale lastTime from TPU counts to milliseconds
            lastTime /= (FLOAT32)TPUCOUNT_IN_MILLISECOND;
        }

        // calculate stopwatch statistics
        inline VOID UpdateStats(VOID) {
            // running average
            if (isnan(avgTime)) {
                avgTime = lastTime;
            }
            else {
                avgTime += (lastTime - avgTime) / runAvgConst;
            }

            // minimum
            if ((lastTime < minTime) || isnan(minTime)) {
                minTime = lastTime;
            }

            // maximum
            if ((lastTime > maxTime) || isnan(maxTime)) {
                maxTime = lastTime;
            }
        }

    public:

        // constructor
        clsStopwatch(VOID) {
            Reset();
            runAvgConst = (FLOAT32)kDefaultRunningAvgConst;
        }

        // statistics accessors
        inline FLOAT32 GetMinTime(VOID) { return minTime; }
        inline FLOAT32 GetMaxTime(VOID) { return maxTime; }
        inline FLOAT32 GetAvgTime(VOID) { return avgTime; }
        inline FLOAT32 GetLastTime(VOID) { return lastTime; }

        inline VOID SetRunningAvgConst(FLOAT32 k) { runAvgConst = k; }

        // Start control
        inline VOID Start(VOID) {
            startTpu = TPU5_TCNT;
            start10ms = TaskScheduler.Get10msecCounter();
        }

        // Stop control
        inline VOID Stop(VOID) {
            stopTpu = TPU5_TCNT;
            stop10ms = TaskScheduler.Get10msecCounter();

            CalculateTime();
            UpdateStats();
        }

        // Reset stopwatch
        inline VOID Reset(VOID) {
            start10ms = 0;
            stop10ms = 0;
            startTpu = 0;
            stopTpu = 0;

            minTime = NaN;
            maxTime = NaN;
            avgTime = NaN;
            lastTime = NaN;
        }
};

#endif
