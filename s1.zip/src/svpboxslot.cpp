/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : svpboxslot.cpp                                              *
*    Description : Class clsclsSvpBoxSlot definition.                          *
*******************************************************************************/

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "svpmain.h"

/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);

extern SHRAMDATA ShramData;
extern clsIoLinkFifo AppScsFifo;
extern volatile BOOL ExitFromCalibTask;
extern clsIoLinkFifo IolinkScsFifo;
extern BOOL bSwitchDiagRunning;

extern UINT16 *uHandeShakeState;
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;
extern VOID VerifySwitchState (SWITCH_TYPE,UINT8);
extern VOID PrintStr(const CHAR *a_cstrPrint);

typedef union tagMODSTAT1DSC {
    struct {
            UINT8 Status :2;
            UINT8 Factory:1;
            UINT8 Unused :4;
            UINT8 BuSyncd:1;
            };
        UINT8 BYTE;
    }MODSTAT1_DSC;
MODSTAT1_DSC ModStat1_Dsc;

struct SFEVENTBITS
{
    UINT16 Cmd      : 1;        //Command to indicate this is Soft Fail event
    UINT16 EvtType  : 1;        //Event Type 
    UINT16 SfDir    : 1;        //Direction 1: Event 0: RTN
    UINT16 SlotNum  : 5;        //Slot number
    UINT16 SfType   : 8;        //Soft Failure type
};

union SFEVENT{
   UINT16              all;
   struct SFEVENTBITS   bit;
};

struct HFEVENTBITS
{
    UINT16 Reserved : 1;        // This bit is not used in hard fail. it is used in Soft Fail. 
                                // It should be Low for Hardfail.
    UINT16 HfCmd    : 1;        // Command to indicate this is Hard Fail event
    UINT16 Reserved2: 6;        // Unused
    UINT16 HfType   : 8;        // Hard Failure type
};

union HFEVENT{
   UINT16              all;
   struct HFEVENTBITS  bit;
};

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN
};

const SOFTFAILTYPE clsSvpBoxSlot::AI_SlotSfMap[BYTESIZE] = {
    SF_VREFFAIL,
    SF_OPENWIRE,
    SF_BADRJVAL,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN
};

const SOFTFAILTYPE clsSvpBoxSlot::LVDT_SlotSfMap[BYTESIZE] = {
    SF_CHNOTFLDCALIB,
    SF_EXCTVOLTFAIL,
    SF_EXCTFREQDRIFT,
    SF_FDBKAVOLTFAIL,
    SF_FDBKBVOLTFAIL,
    SF_VDTCOREFALLOUT,
    SF_UNSTABLEINPUT,
    SF_FDBKINPUTFAIL,
};

const SOFTFAILTYPE clsSvpBoxSlot::AO_SlotSfMap[BYTESIZE] = {
    SF_OUTPUTFL,
    SF_OPENWIRE,
    SF_DOVRCRNT,
    SF_VREFFAIL,
    SF_CURRENT_DRV_FAIL,
    SF_CHNOTFLDCALIB,
    SF_UNKNOWN,
    SF_UNKNOWN
};

const SOFTFAILTYPE clsSvpBoxSlot::DI_SlotSfMap[BYTESIZE] = {
    SF_DIAGCTFL,
    SF_OPENWIRE,
    SF_INPTFAIL,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
};

#define PARAMID_EXCITFREQ   177


const UINT8 clsSvpBoxSlot::RedParams[] = {
    kSiomPnDBVALID,
    kSiomPnIOLDevTy,
    kSiomPnModlType,
    kSiomSvpPnExcitFreq,
    kSiomSvpPnServoDriveOption,
    0 // Terminator
};

const BOXPARAMINFO clsSvpBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       // 03 ModStatType
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 30 HAUTODETBLND
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      // 35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   // 37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          // 38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          // 39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          // 40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          // 41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          // 43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      // 44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    // 45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           // 47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       // 48 AppBuildNo
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 50
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       // 51 BoxSfBits 
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        // 52 BoxSfLrs 
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       // 53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          // 54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         // 55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              // 56 Dpa
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              // 57 Dsa
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      // 58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      // 59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               // 60 Ba
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                // 61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         // 62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        // 63 HwRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,FALSE,                       // 64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          // 65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            // 66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,PostModStat1,GetModStat1Ptr,TRUE,              // 67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         // 68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,FALSE,                          // 69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              // 70 Nth
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetSuprCtrlPtr,FALSE,                         // 71 SuprCtrl
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     // 72 SwRevCode
    DT_UINT16,2,AT_MBYTE,ALCK_IUSER,0,0,GetToknStllPtr,FALSE,                       // 73 ToknStll
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     // 74 TstFunct
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        // 75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          // 76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,PostRedData,GetRedDataPtr,FALSE,      // 77 RedData
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           // 78 DbValid
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,PostSfActionTbl,GetSfActionTblPtr,FALSE,      // 79 SfActionTbl
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,0,0,GetCalibAllPtr,FALSE,                           // 80 CalibAll
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 81 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 82
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 83
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE,                                      // 84 BadPvAll
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 91  
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 100
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,0,FALSE,                                      // 101 PvAll
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetPvChAppPtr,FALSE,                         // 102 PvChApp
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetPvChRemPtr,FALSE,                         // 103 PvChRem
    DT_BLIND,8,AT_PSET,ALCK_VIEW,0,0,0,FALSE,                                       // 104 // for DI
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 110 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 111 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 112
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetLpBkStatPtr,FALSE,                         // 113 LpBkStat
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 114
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 115
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                          // 116 MaxSlots
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 122 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 124 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 132
    DT_INT32,4,AT_MBYTE,ALCK_IUSER,0,0,GetSvpTestParamPtr,FALSE,                    // 133 TESTPARAM[32]
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 142
    DT_BLIND,8,AT_PSET,ALCK_VIEW,0,0,GetCheckPointPtr,FALSE,                        // 143 CheckPoint 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 157
    DT_BLIND,18,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                        // 158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     // 160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,0,PostStatReset,GetStatResetPtr,FALSE,             // 161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       // 165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     // 166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      // 167 TraceLevel
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 169
    DT_UINT8,1,AT_SBYTE,ALCK_OPER,0,PostCPLDRegData,GetCPLDRegDataPtr,FALSE,        // 170 CPLDRegData
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 174
    DT_BLIND,20,AT_MBYTE,ALCK_VIEW,0,0,GetBackCalcScanRecPtr,FALSE,                 // 175 BackCalcScanRec 
    DT_BLIND,13,AT_MBYTE,ALCK_VIEW,0,0,GetProcessScanRecPtr,FALSE,                  // 176 ProcessScanRec
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,0,0,GetExFreqPtr,TRUE,                           // 177 LVDT excitn freq
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 178
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetIolProcCpuFreeAvgPtr,FALSE,              // 179 IolProcCPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetIolProcCpuFreeMaxPtr,FALSE,              // 180 IolProcCPUFreeMax
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetIolProcCpuFreeMinPtr,FALSE,              // 181 IolProcCPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostIolProcStatReset,GetIolProcStatResetPtr,FALSE,  // 182 IolProcStatReset
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetAppProcCpuFreeAvgPtr,FALSE,              // 183 AppProcCPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetAppProcCpuFreeMaxPtr,FALSE,              // 184 AppProcCPUFreeMax
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetAppProcCpuFreeMinPtr,FALSE,              // 185 AppProcCPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,0,0,GetAppProcStatResetPtr,FALSE,                  // 186 AppProcStatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 189
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,0,0,GetCalibOptPtr,FALSE,                          // 190 CalibOpt
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 194
    DT_BLIND,9,AT_MBYTE,ALCK_VIEW,0,0,GetBackUpPvScanRecPtr,FALSE,                  // 195 BackupPvScanRec
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,0,0,GetServoDriveOptPtr,FALSE,                      // 201 ServoDriveOpt
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 237
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetCtlTogPtr,FALSE,                            // 238 CtlTog
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetComTogPtr,FALSE,                            // 239 ComTog
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 242
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         // 255
};

/*******************************************************************************
*                          clsSvpBoxSlot::clsSvpBoxSlot                        *
*                          ============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsSvpBoxSlot::clsSvpBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType,MAXSLOTS){

   // Initialize data members.
    PpxChannel  = 1; // Start with channel 1.
    UINT8 ucSlot =0;
    PvChApp   = 0;
    PvChRem   = 0;        
     
    HwInfo.ProductCode = PRODCODE_SVP;
    HwInfo.ProductType = PRODTYPE_SVP;

   // Setup TPU0 timer for accessing shared ram for every 5 msec.
    TPU0_TCR    = 0x23; // Divide/64 clock, rising edge, clear TCNT on TGRA match.
    TPU0_TMDR   = 0xC0; // TPU0 normal mode operation
    TPU0_TIER   = 0x01; // TGIEA interrupt enabled with TGRA match
    TPU0_TGRA   = TPU0_MAXCOUNT; // interrupt every 5 msec. 
    IPRI_IOPROC = LVLPRI_IOPROC; // Set interrupt priority level

    OWD_ENB = 0; // Disable open wire detection circuitry at startup
    //Initialize Scan Record
    for (ucSlot = 0; ucSlot < AI_MAXSLOTS; ucSlot++) 
    {
        ProcessScanRec.AiPv[ucSlot] = NaN;
        ProcessScanRec.LvdtSlotSf[ucSlot]=(UINT8)0;
    }

    // for channel 1 and channel 2
    ProcessScanRec.AiPvSts = (PVVALST_NORMAL | PVVALST_NORMAL << 4);
  

    // for Channel Data
    ProcessScanRec.ChannelData.Byte =(UINT8)0;

    // Initialize Backcalc scan record.
    for(ucSlot=AO_SERVO_CHANNEL_1_NUMBER;ucSlot<=AO_SERVO_CHANNEL_2_NUMBER;ucSlot++)
    {
        BackCalcScanRec.AoOp[ucSlot-AO_SERVO_CHANNEL_1_NUMBER] = OP_LOLIMIT;
    }     //Get the box shared ram pointer into local variable
    BackCalcScanRec.AoInitReq.Byte = (UINT8)0;
    BackCalcScanRec.SvpRegCtlInitReq.Byte = (UINT8)0;
    BackCalcScanRec.InitVal[0] = (FLOAT32)0;
    BackCalcScanRec.InitVal[1] = (FLOAT32)0;
    BackCalcScanRec.ArwSts.bit.SvpRegCtl1ArwSts = K_NORMAL_ARW;
    BackCalcScanRec.ArwSts.bit.SvpRegCtl2ArwSts = K_NORMAL_ARW;

    pSvpShramBoxData = &ShramData.ShramSlotData.SvpShramBoxData;

    //Reset statistics data
    IolProcCpuFreeAvg  = 0.0;
    IolProcCpuFreeMax  = 0.0;
    IolProcCpuFreeMin  = 100.0;
    IolProcStatReset   = OFF;

    AppProcCpuFreeAvg  = 0.0;
    AppProcCpuFreeMax  = 0.0;
    AppProcCpuFreeMin  = 100.0;
    AppProcStatReset   = OFF;
#ifdef DEBUG
    m_ulMaxPpxTime  = 0;
    m_ulAvgPpxTime  = 0;
    m_ulMinPpxTime  = MAXUINT32;
#endif
    //Both modules will come up as secondary
    SetOutCtl(OUTCTL_PARTNER);

    INH_SWA = 0;
    INH_SWB = 0;
    TST_n = 0;
    AO_SERVO_OVRD = SW_ON;
    AO_SERVO_EN  =SW_ON;
    
    ucWdtRefreshCounter   = 0;
    uiWdtDiagCounter      = 0;
    WdtDiagState          = WDTDIAG_RESET;

    IPRI_POWERFAIL = LVLPRI_PDVC;
    IRQ4_SENSECTL  = IRQ_SC_RISING;
   
    IRQ4_STATUS = DISABLE;         // Clear the IRQ4 status flag
    IRQ4_ENABLE = ENABLE;          // Enable IRQ4 (CPLD interrupt).

    UINT16 uFPGARev  = FPGA_REV;
    HwInfo.Pld2RevLetter = ((uFPGARev & 0xFF00) >> 8) & HWINFO_REVLETTER_MASK;
    HwInfo.Pld2RevNumber = uFPGARev & 0x00FF;
    // Update CPLD version to Shared RAM. This is used to make SVP compatible for both 
    // Pass 1.5 and Pass 2
    pSvpShramBoxData->CPLDVersion = CPLD_REVNUMBER;

    //Update the IOM position in IOTA. This is used on LVDT Position Calibration
    pSvpShramBoxData->Bottom = BOTTOM;

    MonitorSyncState = FALSE;
    TimerForReboot = TIMER_10SEC;
    bRebootIOMAfterDelay = FALSE;

    //By default, BUPREQ stability delay to set 400, 
    //stability is checked only once the DB gets valid
    CntBupreq = BUPREQ_400MS_DELAY;
    bDisableFO = FALSE;
    bDisableFoOnOwd = FALSE;

    // Initialize CPLD interrupt settings on IRQ1.
    IPRI_PDVC     = LVLPRI_TICK;       // Set CPLD interrupt priority level
    bIsBackUpStatusStable = FALSE;
}

/*******************************************************************************
*                          clsSvpBoxSlot::GetDataType                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsSvpBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsSvpBoxSlot::GetAccessType                        *
*                          ============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsSvpBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                          clsSvpBoxSlot::GetParamSize                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsSvpBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                          clsSvpBoxSlot::GetParamPtr                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsSvpBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetAccessLock                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsSvpBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                    clsSvpBoxSlot::GetIsDbChecksumed                          *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsSvpBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                        clsSvpBoxSlot::VerifyControlState                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsSvpBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}

/*******************************************************************************
*                        clsSvpBoxSlot::ExecutePreFunction                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsSvpBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                        clsSvpBoxSlot::ExecutePostFunction                    *
*                        ==================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
    return;
}

/*******************************************************************************
*                           clsBoxSlot::PostRedData                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::PostRedData(UINT8) {
    switch (Data.ucBytes[2]) {
        case 0:         // If the new RedData is zero then RedState was changed
            PostRedState();                     // Process it
            break;
        case RDBIT_CLR + REDDATA_BURQST_BITNUM:// If RedData.BuRqst was cleared
            SWBUREQ_n = 1;                      // Deassert Backup Request line
            break;
        case RDBIT_SET + REDDATA_BURQST_BITNUM:    // If RedData.BuRqst was set
            SWBUREQ_n = 0;                        // Assert Backup Request line
            break;
        case RDBIT_CLR + REDDATA_REDCFG_BITNUM:// If RedData.RedCfg was cleared
            SetRedState(REDSTATE_NOT_SYNCD);
            break;
    }

    pSvpShramBoxData->RedSyncState = GetRedState();
}

/*******************************************************************************
*                        clsSvpBoxSlot::AppInitialization                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::AppInitialization(VOID)  {
     TPU0_CST = 1; // Start timer for shared ram read
    // Wait until the hardware is settled down wait time abt 4sec and to read the 
    // EEPROM calibration data on App processor ( this is arround 170 bytes to read
     //from EEPROM.
    // Change this for loop from to give sufficient
    // time to get the caib data from EEPROM in App Processor 
    for (UINT16 ucCount = 30; ucCount > 0; ucCount--) IdleWait(20000);
    while (!SwitchInit());
} 
/*******************************************************************************
*                         clsSvpBoxSlot::AppStcProcessing                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::AppStcProcessing(VOID)
{   
    //Check the 5v Power supply to App board
    UINT16 AppBrdStatus=*(UINT8*)0x81030;

    AppBrdStatus &= 0x1;

    if(AppBrdStatus)
    {
        //Shutdown the app board
        (P_CPLDR0C).CPLDRDREG &= 0x8;
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_5V_SUPPLY_FAIL,TRUE,0);
    }
    else
    {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_5V_SUPPLY_FAIL,FALSE,0);
    }
    if(TRUE == bRebootIOMAfterDelay)
    {
        TimerForReboot--;

        if(0 == TimerForReboot)
            RebootIom();
    }
    
}

void clsSvpBoxSlot::FillScanRecord(UINT8 a_ucParamNumber, UINT8 *a_ReadBuffer)
{
    switch(a_ucParamNumber)
    {
        case PARAMID_SVP_PROC_SCAN_RECORD: FillProcessScanRecord(a_ReadBuffer);
            break;
        case PARAMID_SVP_BCKCLAC_SCAN_RECORD: FillBackCalcScanRecord(a_ReadBuffer);
            break;
        case PARAMID_SVP_BCKCLAC_PV_SCAN_RECORD: FillBackUpPvScanRecord(a_ReadBuffer);
            break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,bcUnexpectedExcution,a_ucParamNumber);
            break;
    }
}

void clsSvpBoxSlot::FillBackUpPvScanRecord(UINT8 *a_ReadBuffer)
{
    //Backcalc Scan Records Channels
    BACKUPPVSCANREC *pBackUpPvScanRec = (BACKUPPVSCANREC*)(a_ReadBuffer+1);
    
    //AI Channels Data
    for (UINT8 ucSlot = 0; ucSlot < AI_MAXSLOTS; ucSlot++) 
    {
        pBackUpPvScanRec->AiPv[ucSlot] = (FLOAT32)ShramData.ShramSlotData.AiShramSlotData[ucSlot].Pv;
    }
}

void clsSvpBoxSlot::FillProcessScanRecord(UINT8 *a_ReadBuffer)
{
    PROCESSSCANREC  *pProcessScanRec = (PROCESSSCANREC*)(a_ReadBuffer+1);

    //AI Channels Data
    for (UINT8 ucSlot = 0; ucSlot < AI_MAXSLOTS; ucSlot++) 
    {
          pProcessScanRec->AiPv[ucSlot] = (FLOAT32)ShramData.ShramSlotData.AiShramSlotData[ucSlot].Pv;

          SENSRTYP SensType = AILVDT_SLOT(ucSlot+1)->GetSensorType();
             if(SensType == SENSRTYP_LVDT || SensType == SENSRTYP_RVDT || SensType == SENSRTYP_RESOLVER)
             {
                //AI Channels softfail Data
                pProcessScanRec->LvdtSlotSf[ucSlot] = (UINT8)SLOT(ucSlot+1)->GetSlotSfBt();
             }
             else
             {
                 pProcessScanRec->LvdtSlotSf[ucSlot] = (UINT8)0;
             }
    }

    //AI Channels Data
    for (UINT8 ucSlot = 0; ucSlot < AI_MAXSLOTS; ucSlot++) 
    {
          UINT8 temp_AiPvSts=0;
          if(ucSlot == 0)
          {
              UINT8 PvStsVal = (ShramData.ShramSlotData.AiShramSlotData[ucSlot].PvSts & 0x0F);
              temp_AiPvSts   = (pProcessScanRec->AiPvSts & 0xF0);
              temp_AiPvSts  |= PvStsVal;
              pProcessScanRec->AiPvSts = temp_AiPvSts;
          }
          else if(ucSlot == 1)
          {
              UINT8 PvStsVal = (ShramData.ShramSlotData.AiShramSlotData[ucSlot].PvSts & 0x0F);
              temp_AiPvSts   =(pProcessScanRec->AiPvSts & 0x0F);
              temp_AiPvSts  |= (PvStsVal << 4); 
              pProcessScanRec->AiPvSts = temp_AiPvSts;
          }
    }

    //Channel Data
    pProcessScanRec->ChannelData.bit.Di1Pv     = (BOOL)ShramData.ShramSlotData.DiShramSlotData[0].Pv;
    pProcessScanRec->ChannelData.bit.Di2Pv     = (BOOL)ShramData.ShramSlotData.DiShramSlotData[1].Pv;
    pProcessScanRec->ChannelData.bit.Di1BadPvFl= (BOOL)ShramData.ShramSlotData.DiShramSlotData[0].BadPvFl;
    pProcessScanRec->ChannelData.bit.Di2BadPvFl= (BOOL)ShramData.ShramSlotData.DiShramSlotData[1].BadPvFl;
    
    
}

void clsSvpBoxSlot::FillBackCalcScanRecord(UINT8 *a_ReadBuffer)
{
    //Backcalc Scan Records Channels
    BACKCALCSCANREC *pBackCalcScanRec = (BACKCALCSCANREC*)(a_ReadBuffer+1);
    
    for (UINT8 ucSlot = 0; ucSlot < SVPREGCTL_MAXSLOTS; ucSlot++)
    {
        pBackCalcScanRec->InitVal[ucSlot] = (FLOAT32)ShramData.ShramSlotData.RegCtlShramSlotData[ucSlot].SecInitVal;
    }
    pBackCalcScanRec->ArwSts.bit.SvpRegCtl1ArwSts  = (ENUMARW)ShramData.ShramSlotData.RegCtlShramSlotData[0].SecArwSts;
    pBackCalcScanRec->ArwSts.bit.SvpRegCtl2ArwSts  = (ENUMARW)ShramData.ShramSlotData.RegCtlShramSlotData[1].SecArwSts;
    pBackCalcScanRec->SvpRegCtlInitReq.bit.Ch1InitReq  = (BOOL)ShramData.ShramSlotData.RegCtlShramSlotData[0].InitReq;
    pBackCalcScanRec->SvpRegCtlInitReq.bit.Ch2InitReq  = (BOOL)ShramData.ShramSlotData.RegCtlShramSlotData[1].InitReq;
    //AO Channels
    for(UINT8 ucSlot = 0;ucSlot < AO_MAXSLOTS;ucSlot++)
    {
        pBackCalcScanRec->AoOp[ucSlot] = (FLOAT32)ShramData.ShramSlotData.AoShramSlotData[ucSlot].Op;
    }

    //AO Channel Initreqs
    pBackCalcScanRec->AoInitReq.bit.Ch1InitReq = (BOOL)ShramData.ShramSlotData.AoShramSlotData[0].InitReq;
    pBackCalcScanRec->AoInitReq.bit.Ch2InitReq = (BOOL)ShramData.ShramSlotData.AoShramSlotData[1].InitReq;


}

/*******************************************************************************
*                         clsSvpBoxSlot::GetProcessScanRecPtr                  *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetProcessScanRecPtr(VOID) 
{
    return &ProcessScanRec;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetBackCalcScanRecPtr                 *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetBackCalcScanRecPtr(VOID)
{
    return &BackCalcScanRec;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetBackUpPvScanRecPtr                 *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetBackUpPvScanRecPtr(VOID)
{
    return &BackUpPvScanRec;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetExFreqPtr                          *
*                         ===========================                          *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           ExFreeq parameter                                                  *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the ExFreq parameter                                    *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetExFreqPtr(VOID)
{
    ExFreq = (FLOAT32)pSvpShramBoxData->ExFreq;

    return &ExFreq;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetIolProcCpuFreeAvgPtr               *
*                         ===========================                          *
* PURPOSE:  Get the data pointer for IolProcCpuFreeAvg parameter               *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the IolProcCpuFreeAvg parameter                         *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetIolProcCpuFreeAvgPtr(VOID)
{
    return &IolProcCpuFreeAvg;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetIolProcCpuFreeMaxPtr               *
*                         ===========================                          *
* PURPOSE:  Get the data pointer for IolProcCpuFreeMax parameter               *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the IolProcCpuFreeMax parameter                         *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetIolProcCpuFreeMaxPtr(VOID)
{
    return &IolProcCpuFreeMax;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetIolProcCpuFreeMinPtr               *
*                         ===========================                          *
* PURPOSE:  Get the data pointer for IolProcCpuFreeMin parameter               *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the IolProcCpuFreeMin parameter                         *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetIolProcCpuFreeMinPtr(VOID)
{
    return &IolProcCpuFreeMin;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetCheckSumPtr                        *
*                         ===========================                          *
* PURPOSE:  Get the check sum data from shared ram and returns data pointer for*
*           CheckSum parameter                                                 *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the CheckSum parameter                                  *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetCheckSumPtr(VOID)
{
    for(int iSlot=0;iSlot<MAXSLOTS + 1;iSlot++)
    {
        CheckSum[iSlot] = pSvpShramBoxData->CheckSum[iSlot];
    }

    return &CheckSum;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetTstTimeFromShram                   *
*                         ===========================                          *
* PURPOSE:  Get the Tst Time data from shared ram and set local TstFunctTime   *
* ARGUMENTS: NONE                                                              *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::GetTstTimeFromShram(VOID)
{
    INT32 Temp_cnt = (INT32)pSvpShramBoxData->TstFunctTime;
    SetTstFunctTime(Temp_cnt);
}
/*******************************************************************************
*                           clsSpBoxSlot::PostIolProcStatReset                 *
*                           ========================                           *
* PURPOSE:   Post Receiver-Beware function for StatReset parameter             *
* ARGUMENTS: UINT8                                                             *
* RETURN:    VOID                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::PostIolProcStatReset(UINT8) {
    //Reset the  Statistics calculated for the Module
    //as operator has set the option to reset all stats calculated
    if(IolProcStatReset)
    {        
        IolProcCpuFreeAvg = 0.0;//Reset the CPUFreeAverage Parameter 
        //Reset the CPUFreeMin Parameter
        IolProcCpuFreeMin = 100.0;//In the beginning the module is approx 100 % free.
        IolProcCpuFreeMax = 0.0;
        //Reset the  ResetStat Flag to start recalculation  
        TaskScheduler.StatReset();
        IolProcStatReset = OFF;
    } 
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetAppProcCpuFreeAvgPtr               *
*                         ===========================                          *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           AppProcCpuFreeAvg parameter                                        *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the AppProcCpuFreeAvg parameter                         *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetAppProcCpuFreeAvgPtr(VOID)
{
    AppProcCpuFreeAvg = (FLOAT32)pSvpShramBoxData->AppProcCpuFreeAvg;

    return &AppProcCpuFreeAvg;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetIolProcStatResetPtr                *
*                         ===========================                          *
* PURPOSE:  Get the data pointer IolProcStatReset                              *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the IolProcStatReset parameter                          *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetIolProcStatResetPtr(VOID)
{
    return &IolProcStatReset;

}
/*******************************************************************************
*                         clsSvpBoxSlot::GetAppProcCpuFreeMaxPtr               *
*                         ===========================                          *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           AppProcCpuFreeMax parameter                                        *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the AppProcCpuFreeMax parameter                         *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetAppProcCpuFreeMaxPtr(VOID)
{
    AppProcCpuFreeMax = (FLOAT32)pSvpShramBoxData->AppProcCpuFreeMax;

    return &AppProcCpuFreeMax;
}
/*******************************************************************************
*                         clsSvpBoxSlot::GetAppProcCpuFreeMinPtr               *
*                         ===========================                          *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           AppProcCpuFreeMin parameter                                        *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the AppProcCpuFreeMin parameter                         *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetAppProcCpuFreeMinPtr(VOID)
{
    AppProcCpuFreeMin = (FLOAT32)pSvpShramBoxData->AppProcCpuFreeMin;

    return &AppProcCpuFreeMin;
}


/*******************************************************************************
*                         clsSvpBoxSlot::GetAppProcStatResetPtr                *
*                         ===========================                          *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           AppProcStatReset parameter                                         *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the AppProcStatReset parameter                          *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetAppProcStatResetPtr(VOID)
{
    AppProcStatReset = (FLOAT32)pSvpShramBoxData->AppProcStatReset;

    return &AppProcStatReset;

}

/*******************************************************************************
*                         clsSvpBoxSlot::GetServoDriveOptPtr                   *
*                         ===============================                      *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           ServoDriveOpt parameter                                            *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the ServoDriveOpt parameter                             *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetServoDriveOptPtr(VOID)
{
    ServoDriveOpt = (SERVODRIVEOPT)pSvpShramBoxData->ServoDriveOpt;

    return &ServoDriveOpt;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetServoDriveOpt                      *
*                         ===============================                      *
* PURPOSE:  Get ServoDriveOpt parameter from shared ram                        *
* ARGUMENTS: NONE                                                              *
* RETURN:    ServoDriveOpt parameter                                           *
* NOTES:                                                                       *
*******************************************************************************/
SERVODRIVEOPT clsSvpBoxSlot::GetServoDriveOpt(VOID)
{
    ServoDriveOpt = (SERVODRIVEOPT)pSvpShramBoxData->ServoDriveOpt;

    return ServoDriveOpt;
}
/*******************************************************************************
*                         clsSvpBoxSlot::GetCalibAllPtr                        *
*                         ===============================                      *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           CalibAll parameter                                                 *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the CalibAll parameter                                  *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetCalibAllPtr(VOID)
{
    CalibAll = (BOOL)pSvpShramBoxData->CalibAll;

    return &CalibAll;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetCalibOptPtr                        *
*                         ===============================                      *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           CalibOpt parameter                                                 *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the CalibOpt parameter                                  *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetCalibOptPtr(VOID)
{
    CalibOpt = (CALIBOPT)pSvpShramBoxData->CalibOpt;

    return &CalibOpt;
}
/*******************************************************************************
*                         clsSvpBoxSlot::GetCalibAllState                      *
*                         ===============================                      *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           CalibAll parameter                                                 *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the CalibAll parameter                                  *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsSvpBoxSlot::GetCalibAllState(VOID)
{
    CalibAll = (BOOL)pSvpShramBoxData->CalibAll;

    return CalibAll;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetModStat1Ptr                        *
*                         ===============================                      *
* PURPOSE:  Get the data from shared ram and returns data pointer for          *
*           ModStat1 parameter                                                 *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the ModStat1 parameter                                  *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetModStat1Ptr(VOID)
{
    ModStat1.Status  = (UINT8)pSvpShramBoxData->ModStat1 & 0x03;
    ModStat1.Factory = (UINT8)((pSvpShramBoxData->ModStat1 & 0x04)>>2); 
    ModStat1.Unused  = (UINT8)((pSvpShramBoxData->ModStat1 & 0x78)>>3);
    ModStat1.BuSyncd = (UINT8)((pSvpShramBoxData->ModStat1 & 0x80)>>7);

    return &ModStat1;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetModStat2Ptr                        *
*                         ===============================                      *
* PURPOSE:  Get the ModStat2 parameter                                         *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the ModStat2 parameter                                  *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetModStat2Ptr(VOID)
{
    return &ModStat2;
}
/*******************************************************************************
*                         clsSvpBoxSlot::GetModStat3                           *
*                         ============================                         *
* PURPOSE:  Get the shared ram data pointer for ModStat3 parameter             *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the ModStat3 parameter                                  *
* NOTES:                                                                       *
*******************************************************************************/
UINT8  clsSvpBoxSlot::GetModStat3State(VOID)
{
    return ((UINT8)pSvpShramBoxData->ModStat3);
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetDbValidPtr                         *
*                         ===============================                      *
* PURPOSE:  Get the shared ram data pointer for DbValid parameter              *
* ARGUMENTS: NONE                                                              *
* RETURN:   Pointer to the DbValid parameter                                   *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpBoxSlot::GetDbValidPtr(VOID)
{
    DbValid = (BOOL)pSvpShramBoxData->DbValid;
    return &DbValid;
}

/*******************************************************************************
*                         clsSvpBoxSlot::GetModuleStatus                       *
*                         ===============================                      *
* PURPOSE:  Get the shared ram data for ModStat1 parameter                     *
* ARGUMENTS: NONE                                                              *
* RETURN:   ModStat1 parameter                                                 *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsSvpBoxSlot::GetModuleStatus(VOID)
{
    ModStat1.Status  = (UINT8)pSvpShramBoxData->ModStat1 & 0x03;
    ModStat1.Factory = (UINT8)((pSvpShramBoxData->ModStat1 & 0x04)>>2); 
    ModStat1.Unused  = (UINT8)((pSvpShramBoxData->ModStat1 & 0x78)>>3);
    ModStat1.BuSyncd = (UINT8)((pSvpShramBoxData->ModStat1 & 0x80)>>7);

    return ModStat1.Status;
}

/*******************************************************************************
*                         clsSvpBoxSlot::SetModuleStatus                       *
*                         ===============================                      *
* PURPOSE:  set the shared ram data for ModStat1 parameter                     *
* ARGUMENTS: NONE                                                              *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::SetModuleStatus(VOID)
{
    ModStat1.Status  = (UINT8)pSvpShramBoxData->ModStat1 & 0x03;
    ModStat1.Factory = (UINT8)((pSvpShramBoxData->ModStat1 & 0x04)>>2); 
    ModStat1.Unused  = (UINT8)((pSvpShramBoxData->ModStat1 & 0x78)>>3);
    ModStat1.BuSyncd = (UINT8)((pSvpShramBoxData->ModStat1 & 0x80)>>7);
}

/*******************************************************************************
*                          clsSvpBoxSlot::BoxHouseKeeping                      *
*                          ===========================                         *
* PURPOSE:  This method will do the House keeping activity                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::BoxHouseKeeping(VOID)
{
    // Save current interrupt masks and set current masks
    // so that STC or point processing cannot come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK); 

    UINT8 ucCount,ucIndex = 0,ucCompositeByte = 0,ucMask = SLOTINFAIL_MASKINIT; 
    UINT8 ucByteOffset,ucBitOffset;

    UINT8 ucSfActByteOffset,ucSfActBitOffset=0x01;
    UINT8 SfCount = 0;

    BLIND AISlotSfBits [SFBYTES_SIZE];
    BLIND AOSlotSfBits [SFBYTES_SIZE];
    BLIND DISlotSfBits [SFBYTES_SIZE];
    BLIND LVDTSlotSfBits[SFBYTES_SIZE];        

    for (ucCount = 0; ucCount < SFBYTES_SIZE; ucCount++) {
        AISlotSfBits[ucCount]  = 0;
        AOSlotSfBits[ucCount]  = 0;
        DISlotSfBits[ucCount]  = 0;
        LVDTSlotSfBits[ucCount] = 0;
    }
    // Update MapSlotInFail parameter
    for (ucCount = 1; ucCount <= MaxSlots; ucCount++) {
        if ((ucByteOffset = SLOT(ucCount)->GetSlotSfBt()) > 0) {
            MapSlotInFail[ucIndex] |= ucMask;
        }
        else {
            MapSlotInFail[ucIndex] &= ~ucMask;
        }
        ucMask >>= 1;
        if (0 == ucMask) {
            ucMask = SLOTINFAIL_MASKINIT;
            ucIndex++;
        }

        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr); 
        set_imask_exr(LVLPRI_TICK); 
    }

    // Update AI SlotSfBits from individual SlotSfBt.
    ucCompositeByte = 0;
    for (UINT8 ucChan = AI_LVDT_CHANNEL_1_NUMBER; ucChan <= AI_LVDT_CHANNEL_2_NUMBER; ucChan++)
    {
        SENSRTYP SensType;
        SensType = AILVDT_SLOT(ucChan)->GetSensorType();
        if(SensType == SENSRTYP_LVDT || SensType == SENSRTYP_RVDT || SensType == SENSRTYP_RESOLVER)
            continue;   //Skip if the channel type is LVDT

        UINT8 SltSfByte = SLOT(ucChan)->GetSlotSfBt();
        ucCompositeByte |= SltSfByte; 
        

        //Call AddSoftFailEvent again here to assert/Deassert back-up request
        UINT8 Mask=0x1;
        for (ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
        {           
            ucSfActBitOffset=0x01;

            UINT8 a_SoftfailType = AI_SlotSfMap[ucCount];
            ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
            ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);
                        
            if(SltSfByte & Mask)
            {
                if(SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset) 
                {
                    SfCount++;
                }
            }
        }
    }
    
    ucMask = 0x01;
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++)
    {
        if (SF_UNKNOWN != AI_SlotSfMap[ucCount])
        {
            ucByteOffset = AI_SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = AI_SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;
            if (ucCompositeByte & ucMask)
                AISlotSfBits[ucByteOffset] |= ucBoxSfMask;
            else 
                AISlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
        }
        ucMask <<= 1;
        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr); 
        set_imask_exr(LVLPRI_TICK);
    }
        
    
    // Update LVDT SlotSfBits from individual SlotSfBt.
    ucCompositeByte = 0;
    for (UINT8 ucChan = AI_LVDT_CHANNEL_1_NUMBER; ucChan <= AI_LVDT_CHANNEL_2_NUMBER; ucChan++)
    {    
        SENSRTYP SensType;
        SensType = AILVDT_SLOT(ucChan)->GetSensorType();
        if(!(SensType == SENSRTYP_LVDT || SensType == SENSRTYP_RVDT || SensType == SENSRTYP_RESOLVER))
            continue;   //Skip if the channel type is AI

        UINT8 SltSfByte = SLOT(ucChan)->GetSlotSfBt();
        ucCompositeByte |= SltSfByte; 

        //Call AddSoftFailEvent again here to assert/Deassert back-up request
        UINT8 Mask=0x1;
        for (ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
        {
            ucSfActBitOffset=0x01;

            UINT8 a_SoftfailType = LVDT_SlotSfMap[ucCount];
            ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
            ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);
            
            if(SltSfByte & Mask)
            {
                if(SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset) 
                {
                    SfCount++;
                }
            }
        }
    }
    
    ucMask = 0x01;  
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++)
    {
        if (SF_UNKNOWN != LVDT_SlotSfMap[ucCount])
        {
            ucByteOffset = LVDT_SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = LVDT_SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;
            if (ucCompositeByte & ucMask)
                LVDTSlotSfBits[ucByteOffset] |= ucBoxSfMask;
            else 
                LVDTSlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
        }
        ucMask <<= 1;
        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr); 
        set_imask_exr(LVLPRI_TICK);
    }
        
    
    // Update AO SlotSfBits from individual SlotSfBt.
    ucCompositeByte = 0;
    for (UINT8 ucChan = AO_SERVO_CHANNEL_1_NUMBER; ucChan <= AO_SERVO_CHANNEL_2_NUMBER; ucChan++)
    {
        UINT8 SltSfByte = SLOT(ucChan)->GetSlotSfBt();
        ucCompositeByte |= SltSfByte; 

        //Call AddSoftFailEvent again here to assert/Deassert back-up request
        UINT8 Mask=0x1;
        for (ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
        {            
            ucSfActBitOffset=0x01;

            UINT8 a_SoftfailType = AO_SlotSfMap[ucCount];
            ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
            ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);
            
            if(SltSfByte & Mask)
            {
                BOOL bIsEntryInActionTbl = SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset;
                if(a_SoftfailType == SF_OUTPUTFL)
                {
                    if(bDisableFO)
                    {
                        bIsEntryInActionTbl = FALSE;
                    }
                    else
                    {
                        bIsEntryInActionTbl = TRUE;
                    }
                }

                if(DUALCOIL_DRIVE == GetServoDriveOpt())
                {// Dual Coil Drive enabled
                    if(a_SoftfailType == SF_OPENWIRE)
                    {// SF is open wire
                        if(bDisableFoOnOwd)
                        {// FailOver is Disabled , so make Action Table entry to False
                            bIsEntryInActionTbl = FALSE;
                        }
                        else
                        {// FailOver is Enabled.
                            bIsEntryInActionTbl = TRUE;
                        }
                    }
                }


                if(bIsEntryInActionTbl)
                {
                    SfCount++;
                }
            }
        }
    }
        
    ucMask = 0x01;
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++)
    {
        if (SF_UNKNOWN != AO_SlotSfMap[ucCount])
        {
            ucByteOffset = AO_SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = AO_SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;
            if (ucCompositeByte & ucMask)
                AOSlotSfBits[ucByteOffset] |= ucBoxSfMask;
            else
                AOSlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
        }
        ucMask <<= 1;
        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr); 
        set_imask_exr(LVLPRI_TICK);
    }
        
    ucCompositeByte = 0;
    for (UINT8 ucChan = DI_CHANNEL_1; ucChan <= DI_CHANNEL_2; ucChan++)
    {
        UINT8 SltSfByte = SLOT(ucChan)->GetSlotSfBt();
        ucCompositeByte |= SltSfByte; 

        //Call AddSoftFailEvent again here to assert/Deassert back-up request
        UINT8 Mask=0x1;
        for (ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
        {
            ucSfActBitOffset=0x01;

            UINT8 a_SoftfailType = DI_SlotSfMap[ucCount];
            ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
            ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);
            
            if(SltSfByte & Mask)
            {
                if(SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset) 
                {
                    SfCount++;
                }
            }
        }
    }

    ucMask = 0x01;
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++)
    {
        if (SF_UNKNOWN != DI_SlotSfMap[ucCount])
        {
            ucByteOffset = DI_SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = DI_SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;
            if (ucCompositeByte & ucMask)
                DISlotSfBits[ucByteOffset] |= ucBoxSfMask;
            else
                DISlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
        }
        ucMask <<= 1;
        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr); 
        set_imask_exr(LVLPRI_TICK);
    }
    
    WriteTestParamUint32(29,SfCount);

    if(0 == SfCount)
    {
        if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) 
        {
            if ((GetCalibAllState() != TRUE) && (!BOX->CheckForFactoryTestMode()))
            {
                DeAssertBackup();
            }
        }
    }

    for(UINT8 Indx=0 ; Indx<SFBYTES_SIZE; Indx++)
        SlotSfBits[Indx] = (AISlotSfBits[Indx] | LVDTSlotSfBits[Indx]| AOSlotSfBits[Indx] | DISlotSfBits[Indx]);
    
    
    // Count down SlotSfThrottleCount in all slots.
    for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {
        SLOT(ucCount)->CountDownSlotSfThrottle();
    }
    
    // Rereport ModStat event if required
    if (ModStat1Lrs > 0) {
        AddModStatEvent(EVENTTYPE_NORMAL);
    }

    // Alow STC to run to avoid STC overruns.
    set_imask_exr(ucSaveExr); 
    set_imask_exr(LVLPRI_TICK); 

    // Restore original interrupt mask and return.
    set_imask_exr(ucSaveExr); 
}

/*******************************************************************************
*                           clsBoxSlot::RegenSoftfails                         *
*                           ==========================                         *
* PURPOSE:    Regenerate all the Soft fails                                    *
* ARGUMENTS:  NONE                                                             *
* RETURN:     Status of Soft Fail Recovery                                     *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsSvpBoxSlot::RegenSoftfails(VOID) {
    static UINT8 ucByteCount = 0,ucBitCount = 0,ucMask = 0x01;
    // Iterate for 32 BoxSfBytes and each SlotSfByte. 
    while (ucByteCount <= (SFBYTES_SIZE + MaxSlots)) {
        UINT8 ucSfByte,ucSlotNum;
        if (ucByteCount < SFBYTES_SIZE) { //get box softfail byte
            ucSlotNum = 0;
            ucSfByte = BoxSfBits[ucByteCount];
        }
        else { //get slot soft fail byte
            if (SFBYTES_SIZE == ucByteCount) { 
                // Return FALSE so that event recovery task will suspend before 
                // recovering slot softfails. Increment ucByteCount before 
                // returning so that this function will continue with slot soft
                // fail recovery when scheduler resumes event recovery task.
                ucByteCount++;
                return FALSE;
            }
            ucSlotNum = ucByteCount - SFBYTES_SIZE;
            ucSfByte = SLOT(ucSlotNum)->GetSlotSfBt();
        }
        if (ucSfByte > 0) { // any soft fails exists
            while (ucBitCount < BYTESIZE) { 
                if (ucSfByte & ucMask) { // Regenerate softfail event
                    SOFTFAILTYPE SoftfailType;
                    if (ucByteCount < SFBYTES_SIZE) { // box softfail
                        SoftfailType = (SOFTFAILTYPE)
                                       ((ucByteCount * BYTESIZE) + ucBitCount);
                    }
                    else 
                    { 
                        SOFTFAILTYPE* pSlotSfMap;
                        SENSRTYP SensType;
                        switch(ucSlotNum)
                        {
                            case AI_LVDT_CHANNEL_1_NUMBER:
                            case AI_LVDT_CHANNEL_2_NUMBER:
                                SensType = AILVDT_SLOT(ucSlotNum)->GetSensorType();
                                if(SensType == SENSRTYP_LVDT || SensType == SENSRTYP_RVDT || SensType == SENSRTYP_RESOLVER)
                                    pSlotSfMap = (SOFTFAILTYPE*)LVDT_SlotSfMap;
                                else
                                    pSlotSfMap = (SOFTFAILTYPE*)AI_SlotSfMap;
                                SoftfailType = (SOFTFAILTYPE)pSlotSfMap[ucBitCount];
                                break;
                            case AO_SERVO_CHANNEL_1_NUMBER: 
                            case AO_SERVO_CHANNEL_2_NUMBER:
                                SoftfailType = (SOFTFAILTYPE)AO_SlotSfMap[ucBitCount];
                                break;
                            case DI_CHANNEL_1:              
                            case DI_CHANNEL_2:              
                                SoftfailType = (SOFTFAILTYPE)DI_SlotSfMap[ucBitCount];
                                break;
                            default:
                                SoftfailType = (SOFTFAILTYPE)SlotSfMap[ucBitCount];
                                break;
                        }
                    }

                    if (FALSE == AddSoftfailEvent(EVENTTYPE_RECOVERY,SoftfailType,
                                                  TRUE,ucSlotNum)) 
                    {
                        // Return FALSE so that task will suspend.
                        return FALSE; 
                    }
                }
                ucMask <<= 1;
                ucBitCount++;
            }
        }
        // Reinitialize ucMask and ucBitCount for next regeneration.
        ucMask = 0x01;
        ucBitCount = 0;
        ucByteCount++;
    }
    // Reinitialize ucByteCount for next regeneration.
    ucByteCount = 0;
    return TRUE; // Mark end of the softfail recovery.
}

/*******************************************************************************
*                     clsSvpBoxSlot::SetFactoryTestMode                        *
*                     =====================================                    *
* PURPOSE:  //This function sets the IOM in Factory Mode when the REDUNT_n and *
*           BOTTOM signals have appropiate states.The signal states chosen     *
*           enusures that the IOMs are not put to Factory Mode inadverently.   *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::SetFactoryTestMode(VOID)
{
    //REDUNT_n = 0 and BOTTOM = 1 sets the IOM in Factory Test Mode.
    if(!(REDUNT_n) &&  //Should be Low
      (BOTTOM)         //Should be High
    )
    {
        while(!(*uHandeShakeState == APP_CREATE_DB_DONE))
        {
            IdleWait(1);
        }
        PrintStr("\n\rAPP_CREATE_DB_DONE");

        IolinkScsFifo.SendSCSCommand(SCS_ENTER_FACTTEST_MODE);

        //Wait till App Processor to enter Factory mode and set the 
        // Shared Ram ModeStat data to Factory mode enables.
        while(!BOX->CheckForFactoryTestMode())
        {
           IdleWait(10000);
        }
        PrintStr("\n\rMODULE IN FACTORY MODE");
    }//Set Factory mode bit//IOM is in Factory Test Mode
    else
    {
        // Tell App Proc to not in Factory mode.
        IolinkScsFifo.SendSCSCommand(SCS_NOT_FACTTEST_MODE);
        PrintStr("\n\rMODULE NOT IN FACTORY MODE");
    }
}
/*******************************************************************************
*                     clsSvpBoxSlot::SendWdtTstCmdToAppProc                    *
*                     =====================================                    *
* PURPOSE:  This method is to send the SC command to App Processor to start the*
*           App Processor Watchdog Test                                        *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::SendWdtTstCmdToAppProc(VOID)
{
    // Send SCS command to Appprocessor to start WDT test
    IolinkScsFifo.SendSCSCommand(SCS_START_APP_WDT_TST);
}


/*******************************************************************************
*                     clsSvpBoxSlot::CheckForFactoryTestMode                   *
*                     =====================================                    *
* PURPOSE:  This method will return the staus of the Factory bit               *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsSvpBoxSlot::CheckForFactoryTestMode(VOID)
{
    ModStat1.Factory = (UINT8)((pSvpShramBoxData->ModStat1 & 0x04)>>2); 
    return ModStat1.Factory;
}

/*******************************************************************************
*                         clsSvpBoxSlot::AddSoftfailEvent                      *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsSvpBoxSlot::AddSoftfailEvent(EVENTTYPE a_EventType,
                                     SOFTFAILTYPE a_SoftfailType,  
                                     BOOL a_bDirection, UINT8 a_ucSltNm)
{
    EVENTRECORD SoftfailEvent;
    // Initialize event record.
    SoftfailEvent.Overflow      = FALSE;
    SoftfailEvent.ContactCutout = FALSE;
    SoftfailEvent.Qualifier     = a_EventType; 
    SoftfailEvent.EventPacket   = EVENTPACKET_SYSTEM;
    SoftfailEvent.SystemEvent.ChannelNumber = a_ucSltNm;
    SoftfailEvent.SystemEvent.EventSubType  = a_SoftfailType;
 
    UINT8 ucSfByte,ucLrsByte,ucByteOffset,ucBitOffset=0x01;
    UINT8 ucSfActByteOffset,ucSfActBitOffset=0x01;

    // Generate ByteOffset and BitOffsets for SfActionTable search
    ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
    ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);

    // Set SfByte and LrsByte according to the slot number and softail type.
    if (0 == a_ucSltNm) {
        ucByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
        ucBitOffset <<= (a_SoftfailType % BYTESIZE);
        ucSfByte  = BoxSfBits[ucByteOffset];
        ucLrsByte = BoxSfLrs[ucByteOffset];
    }
    else
    {
        SOFTFAILTYPE* pSlotSfMap;
        SENSRTYP SensType;
        switch(a_ucSltNm)
        {
            case AI_LVDT_CHANNEL_1_NUMBER:
            case AI_LVDT_CHANNEL_2_NUMBER:
                SensType = AILVDT_SLOT(a_ucSltNm)->GetSensorType();
                if(SensType == SENSRTYP_LVDT || SensType == SENSRTYP_RVDT || SensType == SENSRTYP_RESOLVER)
                    pSlotSfMap = (SOFTFAILTYPE*)LVDT_SlotSfMap;
                else
                pSlotSfMap = (SOFTFAILTYPE*)AI_SlotSfMap;
                break;
            case AO_SERVO_CHANNEL_1_NUMBER: 
            case AO_SERVO_CHANNEL_2_NUMBER:
                pSlotSfMap = (SOFTFAILTYPE*)AO_SlotSfMap;
                break;
            case DI_CHANNEL_1:              
            case DI_CHANNEL_2:              
                pSlotSfMap = (SOFTFAILTYPE*)DI_SlotSfMap;
                break;
            default:
                pSlotSfMap = (SOFTFAILTYPE*)SlotSfMap;
                break;
        }
        for (ucByteOffset = 0; ucByteOffset < BYTESIZE; ucByteOffset++)
        {
            if (pSlotSfMap[ucByteOffset] == a_SoftfailType)
                break;
            ucBitOffset <<= 1;
        }
        
        if (BYTESIZE == ucByteOffset)
        {
            return FALSE;
        }

        ucSfByte  = SLOT(a_ucSltNm)->GetSlotSfBt();
        ucLrsByte = SLOT(a_ucSltNm)->GetSlotSfLrs();
    }
        
    
    if (TRUE == a_bDirection) {
        SoftfailEvent.CurrentState = EVENTSTATE_ALARM;
        if (EVENTTYPE_NORMAL == a_EventType) {
            BOOL bIsEntryInActionTbl = SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset;
            
            if(a_SoftfailType == SF_OUTPUTFL)
            {
                if(bDisableFO)
                    bIsEntryInActionTbl = FALSE;
                else
                    bIsEntryInActionTbl = TRUE;
            }
            
            if(DUALCOIL_DRIVE == GetServoDriveOpt())
            {
                if((a_ucSltNm == AO_SERVO_CHANNEL_1_NUMBER) || (a_ucSltNm == AO_SERVO_CHANNEL_2_NUMBER))
                {// Either of the AO Channel
                    if(a_SoftfailType == SF_OPENWIRE)
                    {// Soft Fail type is Open wire
                        if(bDisableFoOnOwd)
                        {// FailOver is Disabled
                            bIsEntryInActionTbl = FALSE;
                        }
                        else
                        {// Failover is enabled.
                            bIsEntryInActionTbl = TRUE;
                        }
                    }
                }
            }

            //Initiate a SoftFail Failover if enabled and appropriate
            if (REDSTATE_SYNCD == GetRedState() &&                  // if modules syncd
                bIsEntryInActionTbl)// + FO for this SF
            {
                if(FALSE == AILVDT_SLOT(AI_LVDT_CHANNEL_1_NUMBER)->GetValveCalibEnb() &&
                   FALSE == AILVDT_SLOT(AI_LVDT_CHANNEL_2_NUMBER)->GetValveCalibEnb()
                  )
                {
                    if (!GetPartnersBackupStatus() && Iol.AmPrimary())
                    {
                        if(bIsBackUpStatusStable)
                        {
                            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x888,3);
                            Iol.DropDSA();
                            BOX->SetDSA(0);
                        }
                    }
                    AssertBackup();
                    ResetRedData(REDDATA_SFFOEN);
                }
            }
        }
    }
    else SoftfailEvent.CurrentState = EVENTSTATE_RETURN;

    UINT8 ucSaveExr = get_imask_exr();
    if (EVENTTYPE_NORMAL == a_EventType) {
        // Elevate the priority of executing thread to STC level
        // when SfBits and Sfcounter in database are updated.
        set_imask_exr(LVLPRI_TICK);
        
        
        if ((ucSfByte & ucBitOffset) && (FALSE == a_bDirection)) {
            // SfByte bit is set and the softfail is returning
            ucSfByte &= ~ucBitOffset; // reset SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter > 0) BoxSfCounter--;
            }
            else {
                if (SlotSfCounter > 0) SlotSfCounter--;
            }
        }
        else if ((!(ucSfByte & ucBitOffset)) && (TRUE == a_bDirection)) {
            // SfByte bit is not set and the softfail is being reported
            ucSfByte |= ucBitOffset; // set SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter < MAXUINT8) BoxSfCounter++;
            }
            else {
                if (SlotSfCounter < MAXUINT8) SlotSfCounter++;
            }
        }

        WriteTestParamUint32(30,BoxSfCounter);
        WriteTestParamUint32(31,SlotSfCounter);

        // Update SfByte in the box/slot database.
        if (0 == a_ucSltNm) {
            BoxSfBits[ucByteOffset] = ucSfByte;
        }
        else {
            SLOT(a_ucSltNm)->SetSlotSfBt(ucSfByte);
        }

        // Database update complete.
        // Restore original interrupt priority.
        set_imask_exr(ucSaveExr);
    }

    if ((0 == BoxSfCounter) && (0 == SlotSfCounter)) {
        SoftfailEvent.SystemEvent.SoftfailStatus = FALSE;
        pNrmEcl->ResetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = FALSE;
        SetRedData(REDDATA_SFFOEN);
        if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) {
            if ((GetCalibAllState() != TRUE) && (!BOX->CheckForFactoryTestMode())) {
                    DeAssertBackup();
            }
        }
    }
    else {
        SoftfailEvent.SystemEvent.SoftfailStatus = TRUE;
        pNrmEcl->SetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = TRUE;
    }
    if (MODSTATUS_FAIL != GetModuleStatus()) {
        // Add softfail event to the normal event circular list if this is 
        // event recovery OR if SfByte and LrsByte are not matching.
        if ((EVENTTYPE_RECOVERY == a_EventType) ||
            (ucLrsByte ^ ucSfByte) & ucBitOffset) {
            if (EVENTTYPE_RECOVERY == a_EventType) {
                if (pNrmEcl->IsRoomForRegen() == FALSE) {
                    return FALSE;
                }
            }

            if (TRUE == pNrmEcl->AddEvent(&SoftfailEvent)) {
                if (EVENTTYPE_NORMAL == a_EventType) {
                    // Update LRS byte only for normal events. 
                    if (TRUE == a_bDirection) {
                        ucLrsByte |= ucBitOffset;
                    }
                    else {
                        ucLrsByte &= ~ucBitOffset;
                    }
                }

                // Elevate the priority of executing thread to
                // STC level when LRS byte in database is updated.
                set_imask_exr(LVLPRI_TICK);
                if (0 == a_ucSltNm) {
                    BoxSfLrs[ucByteOffset] = ucLrsByte;
                }
                else {
                    SLOT(a_ucSltNm)->SetSlotSfLrs(ucLrsByte);
                }
                // Database update complete.
                // Restore original interrupt priority.
                set_imask_exr(ucSaveExr);

                return TRUE;
            }
            else { // AddEvent failed
                return FALSE;
            }
        }
    }

    // Execution reaches here only if 
    // there is nothing to report.
    return TRUE;
}

/*******************************************************************************
*                           clsSvpBoxSlot::ReportDSCSF                         *
*                           ==========================                         *
*  Call AddSoftFailEvent again here to assert/Deassert back-up request         *
*  for DSC resident  channels                                                  *
*                                                                              * 
*******************************************************************************/
VOID clsSvpBoxSlot::ReportDSCSF()
{
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++)
    {
        UINT8 SltSfByte = SLOT(ucSlotNum)->GetSlotSfBt();
        
        //Call AddSoftFailEvent again here to assert/Deassert back-up request
        UINT8 Mask=0x1;
        for (UINT8 ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
        {
            SOFTFAILTYPE SoftfailType;
            switch(ucSlotNum)
            {
                case AI_LVDT_CHANNEL_1_NUMBER:
                case AI_LVDT_CHANNEL_2_NUMBER:
                {
                    SENSRTYP SensType = AILVDT_SLOT(ucSlotNum)->GetSensorType();
                    if(SensType == SENSRTYP_LVDT || SensType == SENSRTYP_RVDT || SensType == SENSRTYP_RESOLVER)
                        SoftfailType = (SOFTFAILTYPE)LVDT_SlotSfMap[ucCount];
                    else
                        SoftfailType = (SOFTFAILTYPE)AI_SlotSfMap[ucCount];
                }
                break;
                case AO_SERVO_CHANNEL_1_NUMBER: 
                case AO_SERVO_CHANNEL_2_NUMBER:
                    SoftfailType = (SOFTFAILTYPE)AO_SlotSfMap[ucCount];
                    break;
                case DI_CHANNEL_1:              
                case DI_CHANNEL_2:              
                    SoftfailType = (SOFTFAILTYPE)DI_SlotSfMap[ucCount];
                    break;
                default:
                    SoftfailType = (SOFTFAILTYPE)SlotSfMap[ucCount];
                    break;
            }

            if(SF_UNKNOWN != SoftfailType)
            {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SoftfailType,SltSfByte & Mask,ucSlotNum);
            }
        }
    }
}

/*******************************************************************************
*                       clsSvpBoxSlot::ShramReadInterruptHandler               *
*                       ==================================                     *
* PURPOSE: Interrupt handler to read data from shared ram                      *
* ARGUMENTS: NONE                                                              *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::ShramReadInterruptHandler(VOID)  {

    TPU0_TGFA = 0; // Acknowledge the compare match interrupt

#ifndef _DEBUG
    //Service WatchDog
    RefreshWatchDog();
#endif

    //Check Backup Module backup request status
    BOX->CheckBackUpStatus();

    //Call AddSoftFailEvent again here to assert/Deassert back-up request for DSC resident
    //channels
    BOX->ReportDSCSF();

    // Bypass the Redundancy checks while doing calibration.
    if(FALSE==BOX->GetCalibAllState())
    {   
        BOX->ManageRedIO(); // Process redundancy inputs and state

        if(BOX->CheckRedData(REDDATA_REDCFG) || (!BOX->GetOutCtl() && Iol.AmPrimary()))
        {
            BOX->CheckFailOverCondition();
        }

        //Ensure redundancy switches on primary and secondary module are intact 
        if (!(BOX->CheckForFactoryTestMode()))//do not execute in Factory Mode
        { 
            if((OUTCTL_MINE == BOX->GetOutCtl())&&(FALSE == bSwitchDiagRunning))
            {
                VerifySwitchState(DIS_SWCH,DIS_ON_ON);
                VerifySwitchState(INH_SWCH,INH_ON_ON);
                VerifySwitchState(TST_SWCH,TST_DISABLED);
                //verify the INHIN_FB_n line 
                if(INHIN_NEGATED != INHIN_FB_n)
                {
                    //Check the Out Control state before rasing softfail
                    if((OUTCTL_MINE == BOX->GetOutCtl())&&(FALSE == bSwitchDiagRunning))
                    {
                        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x922,0);
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,TRUE,0);
                    }
                    else
                    {
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
                    }
                }
                else
                {
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
                }
            }
            else if((OUTCTL_PARTNER == BOX->GetOutCtl())&& 
                   (FALSE == bSwitchDiagRunning)){
                VerifySwitchState(DIS_SWCH,DIS_OFF_OFF);
                VerifySwitchState(INH_SWCH,INH_OFF_OFF);
                VerifySwitchState(TST_SWCH,TST_DISABLED);
            }
        }
    }

    volatile UINT16 ReadVal = 0;
    ReadVal = AppScsFifo.GetNextEntry();
    
    while(ReadVal != 0)
    {
        if( ReadVal < 0x8000)
        {
            if(ReadVal<0x4000)
            {// SCS Normal commands
              switch(ReadVal)
              {
                case SCS_COMMAND_MOD_STATUS:
                {
                      BOX->SetModuleStatus();
                      BOX->AddModStatEvent(EVENTTYPE_NORMAL);
                }
                break;
                case SCS_SHUTDOWN_IOM:
                    // Update the FailCode and shutdown IOM.
                    FailCode = HF_IOMUSERRESET;
                    ShutdownIom();
                    break;
                case SCS_CALIB_ENABLE:
                        //check for module calibration CMD.
                        TaskScheduler.RunTask(TASKID_CALIBTASK);
                        ExitFromCalibTask = FALSE;
                        break;
                case SCS_CALIB_DISABLE:
                        ExitFromCalibTask=TRUE;
                        break;
                case SCS_LED_BLINK_ONE:
                        BOX->BlinkLed(1);
                        break;
                case SCS_LED_BLINK_TWO:
                        BOX->BlinkLed(2);
                        break;
                case SCS_LED_BLINK_THREE:
                        BOX->BlinkLed(3);
                        break;
                case SCS_LED_BLINK_FOUR:
                        BOX->BlinkLed(4);
                        break;
                case SCS_DISABLE_OUTPUTS:
                        BOX->DisableOutputs();
                        break;
                case SCS_ENABLE_OUTPUTS:
                        BOX->EnableOutputs();
                        break;
                case SCS_LED_BLINK_OFF:
                        //Switch off the status LED
                        LED_PINS = STATUSLED_OFF;
                        break;
                case SCS_REBOOT_IOM:
                        //Reboot IOM.
                        RebootIom();
                        break;
                case SCS_MONITOR_SYNC:
                        //This SCS is sent by App processor which is secondary during Valve Position Calibration.
                        //When this IOM becomes Primary and Sync State changes to SYNCHED then it will Reboot
                        BOX->MonitorSyncState = TRUE;
                        break;
                case SCS_COMMAND_TST_TIME:
                        BOX->GetTstTimeFromShram();
                        break;
                case SCS_DROP_SYNC:
                    {
                        if ((Iol.AmPrimary()) && (REDSTATE_SYNCD == BOX->GetRedState())) 
                        {
                            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x925,0);
                            BOX->DropSync();
                        }
                    }
                    break;
                default:
                    TraceLog.AddToTrace(TRACEID_GENERIC,bcUnexpectedExcution,ReadVal);
                break;
              }
            }
            else
            {
                //Hard Fail Entry
                HFEVENT EvtData;
                EvtData.all = ReadVal;
                UINT8 Mask = 0x80;
                if(EvtData.bit.HfType>=HF_FIRSTUNUSEDENUM)
                PrintStr("\r\n Hard Fail Not in list");

                PrintStr("\r\nAPPHF");
                while(Mask)
                {
                    if (Mask & (UINT8)EvtData.bit.HfType)
                    {
                        PrintStr("1");
                    }
                    else
                    {
                        PrintStr("0");
                    }
                    Mask >>= 1;
                };
                PrintStr("\r\n");
                // Disable the Servo Master Control when module Hard Fails
                    AO_SERVO_EN  =SW_OFF;
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHardFail1,EvtData.bit.HfType);
                HardFail((HARDFAILTYPE)EvtData.bit.HfType,SVPBOXSLOT_CPP,__LINE__);
             }
         } 
         else
         {
            //Soft Fail Entry
            SFEVENT EvtData;
            EvtData.all = ReadVal;

            BOX->AddSoftfailEvent((EVENTTYPE)EvtData.bit.EvtType, (SOFTFAILTYPE)EvtData.bit.SfType,EvtData.bit.SfDir,EvtData.bit.SlotNum);
            if((SOFTFAILTYPE)EvtData.bit.SfType == SF_OUTPUTFL)
            {
                if(EvtData.bit.SfDir == TRUE)
                {
                    BOX->bDisableFO = TRUE;
                }
                else
                {
                    BOX->bDisableFO = FALSE;
                }
            }

            if(DUALCOIL_DRIVE == BOX->GetServoDriveOpt())
            {// If Dual COil Drive:
                // As Secodnary diagnostics are disable in Dual Coil Drive(Servo Y Connection at field); to avoid the pin pong issue by the 
                // Field Open wire , there are allowing only one switchover. and the setting "bDisableFoOnOwd" flag to TRUE to block the further
                // switchover to avoid ping-pong issue
                if(EvtData.bit.SlotNum == AO_SERVO_CHANNEL_1_NUMBER || EvtData.bit.SlotNum == AO_SERVO_CHANNEL_2_NUMBER)
                {// Either of the AO Slot
                    if((SOFTFAILTYPE)EvtData.bit.SfType == SF_OPENWIRE)
                    {// if the SF is Openwire
                        if(EvtData.bit.SfDir == TRUE)
                        {// Disable further Switchovers
                            BOX->bDisableFoOnOwd = TRUE;
                        }
                        else 
                        {
                             BOOL bSFFlag = FALSE;
                             for (UINT8 ucChan = AO_SERVO_CHANNEL_1_NUMBER; ucChan <= AO_SERVO_CHANNEL_2_NUMBER; ucChan++)
                             {
                                UINT8 SltSfByte = SLOT(ucChan)->GetSlotSfBt();

                                UINT8 Mask=0x1;
                                for (UINT8 ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
                                {                       
                                    if(SltSfByte & Mask)
                                    {
                                        bSFFlag = TRUE;
                                        break;
                                    }
                                }

                                if(bSFFlag)
                                {
                                    break;
                                }
                             }
                             if(FALSE == bSFFlag)
                             {
                                BOX->bDisableFoOnOwd = FALSE;
                             }
                        }
                    }
                }
            }
         }

         ReadVal = AppScsFifo.GetNextEntry();
    }

    APPBoardPowerDiagRoutine();

    //Check INIT_B from FPGA
    if(0==FPGA_INIT_n)
    {
        HardFail(HF_FPGARDBKFAIL,SVPBOXSLOT_CPP,__LINE__);
    }
}

/*******************************************************************************
*                           clsSvpBoxSlot::ManageRedIO                         *
*                           =======================                            *
* PURPOSE: Handle the redundancy IO signals                                    *
* ARGUMENTS: NONE                                                              *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::ManageRedIO(VOID) {
    ModStat2.BuReqIn = GetPartnersBackupStatus();

    if(!Iol.AmPrimary() && GetRedState() == REDSTATE_SYNCD) {
        if (ModStat2.BuReqIn && !GetMyBackupStatus()) {
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x956,0);
            SetRedState(REDSTATE_FO_COMPLETE);
        }
    }

    switch(Iol.AddressChange()) {
        case ADDCHG_NONE:
            break;
        case ADDCHG_NEW:
            if(Iol.AmPrimary())DeAssertBackup();
            SetRedState(REDSTATE_NOT_SYNCD);
            break;
        case ADDCHG_DROPPED:
            if(REDSTATE_IOL_TIMEOUT != GetRedState()) DropSync();
            break;
    }
}

/*******************************************************************************
*                         clsAohBoxSlot::SwitchInit                            *
*                         =========================                            *
* PURPOSE:    Initialize the Redundancy switches appropriately                 *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           Status of Switch Initialization                                    *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsSvpBoxSlot::SwitchInit (VOID) {
    //Allow one module to come up earlier than other module
    UINT8 ucDelay = (BOTTOM) ? 20000 : 20;       // compute variable delay (us)

    if (INHIN_NEGATED == INHIN_FB_n){     // partner is not controlling screws
        if (BURIN_ASSERTED == GetPartnersBackupStatus()) {          // partner asserting BUPREQ
            if (INHIN_NEGATED == INHIN_FB_n){// partner still not have screws
                IdleWait(ucDelay);                         // wait for some delay time
                if (INHIN_NEGATED == INHIN_FB_n) { // partnr does not have screws
                    //Shut off the partner outputs from driving the outputs
                    INH_SWA = SW_ON;
                    INH_SWB = SW_ON;
                    IdleWait(ucDelay);   // wait for inhibit switches some delay time

                    if(INHIN_NEGATED == INHIN_FB_n)
                    {
                        SetForPrimary();              // assume role as primary
                        return TRUE;                  // exit finished
                    }
                    else{
                        INH_SWA = SW_OFF;        // relinquish control of screws
                        INH_SWB = SW_OFF;
                        IdleWait(ucDelay);          // wait for some delay time
                        return FALSE;                         // exit unfinished
                    }
                }
                else {                         // partner is controlling screws
                    SetForSecondary(TRUE);      // assume role as backup module
                    return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                               // exit unfinished
            }
        }// partner asserting BUPREQ
        else {
            IdleWait(ucDelay);                      // wait for some delay time
            if (INHIN_NEGATED == INHIN_FB_n) {    // partner does not have screws
                if (BURIN_ASSERTED == GetPartnersBackupStatus()) {  // partner asserting BUPREQ
                    return FALSE;                            // exit unfinished
                }
                else {                       // partner is not asserting BUPREQ
                        SetForPrimary(); 
                        return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                                // exit unfinished
            }
        }
    }
    else {                                 // partner is controlling the screws
        IdleWait (ucDelay);                         // wait for some delay time
        if (INHIN_NEGATED == INHIN_FB_n) {  // partner does not have screws
            return FALSE;                                    // exit unfinished
        }
        else {                             // partner is controlling the screws
            SetForSecondary(TRUE);              // assume role as backup module
            return TRUE;                                       // exit finished
        }
    }
}

/*******************************************************************************
*                     clsSvpBoxSlot::CheckFailOverCondition                    *
*                     =====================================                    *
* PURPOSE: This method will check for the failover conditions                  *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpBoxSlot::CheckFailOverCondition(VOID) {

    BOOL bTstSave = TST_n; // Save state of TST switch

    if (!(BOX->CheckForFactoryTestMode())){ 
        TST_n = TSTn_DISABLED;
    }

    if (GetOutCtl() == OUTCTL_PARTNER)            // I do not have ctl of the screws
    {  
        if (BURIN_ASSERTED == BUPREQ_IN)          // my partner has asserted BUPREQ
        {     
            if (INHIN_NEGATED == INHIN_FB_n)      // and partner has given up the screws
            { 
                IdleWait(50);                     //Wait fro 50 us
                if (INHIN_NEGATED == INHIN_FB_n)  // partner still does not have screws
                {
                    if (BUREQ_NEGATED == SWBUREQ_n)// and i have negated BURQ
                    { 
                        SetForPrimary();           // assume role of primary module
                        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x911,0);
                        if (REDSTATE_FO_IN_PROG == GetRedState())
                        {
                            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x954,0);
                            SetRedState(REDSTATE_FO_COMPLETE);
                        }
                    }
                }
            }
        }

        if (Iol.AmPrimary()) {
            if (INHIN_NEGATED == INHIN_FB_n) { // and it has given up the screws
                IdleWait(50);
                if (INHIN_NEGATED == INHIN_FB_n) {// partner still does not have
                    // If at this point the expected FO sequence did not occur
                    // properly. So save the state of the BUREQ's & REDSTATE
                    // Then take control of the field terminations
                    SetForPrimary();
                    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x912,0);
                    if (REDSTATE_FO_IN_PROG == GetRedState())
                    {
                       TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x955,0);
                       SetRedState(REDSTATE_FO_COMPLETE);
                    }
                }
            }
        }
    }
    else if (!Iol.AmPrimary())   // I have control of the screws
    {
        if (BUREQ_ASSERTED == SWBUREQ_n)  // If I am asserting BUPREQ
        {
            if (BURIN_NEGATED == BUPREQ_IN)// and my partner is not
            {
                SetForSecondary(TRUE);         // assume role of backup module
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x913,0);
            }
        }
    }

    if (GetOutCtl() == OUTCTL_MINE)            
    {
        if (REDSTATE_FO_IN_PROG == GetRedState())
        {
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x959,0);
            SetRedState(REDSTATE_FO_COMPLETE);
        }
    }

    TST_n = bTstSave;                            // Restore state of TST switch
}

//This method checks the stability of BUPREQ signal
VOID clsSvpBoxSlot::CheckBackUpStatus(VOID)
{
    //BUPREQ stability is checked only once the DB gets valid
    //On the Primary module wait for 300ms for backup request to stabilized on secondary
    //this done to denounce the backup request gitter that happens on the secondary when secondary is
    //powered on. This is done to avoid spurious switchover
    if (BURIN_NEGATED == BUPREQ_IN)// and my partner is not
    {
        if(CntBupreq <= BUPREQ_400MS_DELAY)
        {
            bIsBackUpStatusStable = FALSE;
            CntBupreq++;
        }
    }
    else
    {
        bIsBackUpStatusStable = FALSE;
        CntBupreq = 0;
    }

    if(CntBupreq >= BUPREQ_400MS_DELAY)
    {
       bIsBackUpStatusStable = TRUE;
    }
}
VOID clsSvpBoxSlot::SetForPrimary(VOID) 
{
    // set inhibit switches to prevent the other module from driving the outputs
    INH_SWA = SW_ON;
    INH_SWB = SW_ON;
    
    //make sure the Override bit is OFF for Primary
    AO_SERVO_OVRD = SW_OFF;

    // set disable switches to allow outputs to be driven
    DIS_SWA_n = SW_ON;
    DIS_SWB_n = SW_ON;

    IdleWait(INH_READ_DELAY_TIME);
 
    // verify switch states
    VerifySwitchState(DIS_SWCH,DIS_ON_ON);
    VerifySwitchState(INH_SWCH,INH_ON_ON);

    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x909,0);
 
    SetOutCtl(OUTCTL_MINE);
}

VOID clsSvpBoxSlot::SetForSecondary(BOOL bDoCheck) 
{
    // set disable switches to allow outputs to be blocked
    DIS_SWA_n = SW_OFF;
    DIS_SWB_n = SW_OFF;

    // set inhibit switches to allow the other module to drive the outputs
    INH_SWA = SW_OFF;
    INH_SWB = SW_OFF;

    //make sure the Override bit is OFF for Primary
    AO_SERVO_OVRD = SW_ON;

    if (bDoCheck) { // verify switch states
        IdleWait(INH_READ_DELAY_TIME);
        VerifySwitchState(DIS_SWCH,DIS_OFF_OFF);
        VerifySwitchState(INH_SWCH,INH_OFF_OFF);
    }
 
    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x910,1);

    SetOutCtl(OUTCTL_PARTNER);
}

VOID clsSvpBoxSlot::SetOutCtl(UINT8 OutCtlState)
{
    pSvpShramBoxData->ModStat3 = OutCtlState;
}

UINT8 clsSvpBoxSlot::GetOutCtl(VOID)
{
    return(pSvpShramBoxData->ModStat3);
}


VOID clsSvpBoxSlot::AppColdInit(VOID) {
    // Send a SCS to Application Processor, to perform AppColdInit operation
    IolinkScsFifo.SendSCSCommand(SCS_APP_COLD_INIT);
}

VOID clsSvpBoxSlot::AppPostSwap(VOID) {
    //Change the Module switch state to secondary state
    //This change will avoid the switches to be operated twice when the 
    //modules chnages the role.
    SetForSecondary(TRUE);
    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x915,0);
}

/*******************************************************************************
*                           clsSvpBoxSlot::AppPostSync                         *
*                           ==========================                         *
*  AppPostSync is called from PostRedState for application specific actions    *
*  after a database dump.                                                      *
*******************************************************************************/
VOID clsSvpBoxSlot::AppPostSync(VOID)
{
    //If App processor has asked to monitor SYNCSTATE then Reboot the module when Primary and SYNCSTATE is synched
    //This is done by IOM in LVDT Calibration mode by original(when VALVECALIBENB was set to true) Secondary IOM which 
    //is primary now and the original Primary is backup now and in sync
    if(Iol.AmPrimary() && TRUE == MonitorSyncState)
    {
        bRebootIOMAfterDelay = TRUE;
    }
}

PASTATUS  clsSvpBoxSlot::GetDumpData(UINT8* pDump, const UINT8 MaxSize)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL && sizeof(strSvpBoxSlotDumpData) < MaxSize)
    {
        strSvpBoxSlotDumpData *pDumpData = (strSvpBoxSlotDumpData*)pDump;

        pDumpData->Version  = PACK2_AS_UI16(SVPIOM_SYNC_VER_1,0);
        pDumpData->ExFreq = pSvpShramBoxData->ExFreq;
        pDumpData->Tpu5_Pri = Tpu5_Pri;
        pDumpData->ModStat1 = pSvpShramBoxData->ModStat1 ;
        pDumpData->ModStat2 = pSvpShramBoxData->ModStat2 ;
        pDumpData->MaxSlots = MaxSlots;
        pDumpData->DbValid = pSvpShramBoxData->DbValid;		
        pDumpData->FieldCoilResistanceServo1 = pSvpShramBoxData->FieldCoilResistanceServo1;
        pDumpData->FieldCoilResistanceServo2 = pSvpShramBoxData->FieldCoilResistanceServo2;        
		pDumpData->ServoDriveOpt = pSvpShramBoxData->ServoDriveOpt;

        RetVal = PA_OK; 
    }
    return RetVal;
}

PASTATUS  clsSvpBoxSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL)
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SVPIOM_SYNC_VER_1)
        {
            strSvpBoxSlotDumpData* pDumpData = (strSvpBoxSlotDumpData*)(pDump);

			pSvpShramBoxData->ExFreq = pDumpData->ExFreq;            
			Tpu5_Pri = pDumpData->Tpu5_Pri;
			pSvpShramBoxData->ModStat1 = pDumpData->ModStat1;
			MaxSlots = pDumpData->MaxSlots;
			pSvpShramBoxData->DbValid = pDumpData->DbValid;            
            pSvpShramBoxData->FieldCoilResistanceServo1 = pDumpData->FieldCoilResistanceServo1;
            pSvpShramBoxData->FieldCoilResistanceServo2 = pDumpData->FieldCoilResistanceServo2;
            pSvpShramBoxData->ServoDriveOpt = pDumpData->ServoDriveOpt;

            RetVal = PA_OK;
        }        
    }
    return RetVal;
}

VOID clsSvpBoxSlot::IRQ6InterruptHandler(VOID)
{
//    IRQ6_STATUS = DISABLE;
    return;
}

VOID clsSvpBoxSlot::AppPostDump(VOID)
{
    if(Iol.AmPrimary() == FALSE)
    {
        IolinkScsFifo.SendSCSCommand(SCS_IOL_DUMPCOMPLETE);
    }
}

