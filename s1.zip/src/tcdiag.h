/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcdiag.h                                                    *
*    Description : Decalartion of common diagnostics related data              *
*******************************************************************************/
#ifndef __DIAG_H__
#define __DIAG_H__
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef RETURNSTATUS (* DIAGROUTINE)(VOID);

/* IOLINK and Application Processor Hand Shake State Options */
enum HAND_SHAKE_STATES{
    IOLINK_START_UP_DIAG_DONE = 0x0,
    APP_START_UP_DIAG_DONE    = 0x1,
    APP_CREATE_DB_DONE        = 0x2
};
//

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8  RAM_DIAG_CHUNK_SIZE    = 0x20;
const UINT8  ROM_DIAG_CHUNK_SIZE    = 0x40; 
const UINT16 ADDR_DIAG_PATTERN1     = 0x5555;
const UINT16 ADDR_DIAG_PATTERN2     = 0xAAAA;
const UINT16 DATA_DIAG_PATTERN1     = 0x0000;
const UINT16 DATA_DIAG_PATTERN2     = 0x1111;
const UINT8  EEPROM_DIAG_CHUNK_SIZE = 0x08;
const UINT32 EXTRAM_QUICKTEST_LOC1  = EXTERNAL_RAM_START_ADDRESS;
const UINT32 EXTRAM_QUICKTEST_LOC2  = 0x00210000;
const UINT32 EXTRAM_QUICKTEST_LOC3  = 0x0021FFFC;
const UINT8  ADDR_DIAG_COUNT        = 14; 

#ifdef IOMTYPE_SVP
    #define BOXCLASS    clsSvpBoxSlot
#elif  IOMTYPE_SP 
    #define BOXCLASS    clsSpBoxSlot    
#endif  

#define  DIAG_XREADY_VAL        0x1234

#ifdef IOMTYPE_SVP
    // For WD Factory Test
    #ifdef H8S
        const UINT8 WD_REFRESH_PERIOD = 5; // in msec
    #else
        const FLOAT32 WD_REFRESH_PERIOD = 2.5; // in msec
        const UINT32 MICROSECONDS_IN_MILLISECOND = 1000;
    #endif
    const UINT16 TC_WDT_MAX_TIME_IN_MICROSEC=15000;
#else //IOMTYPE_SP
    // For WD Factory Test
    #ifdef H8S
        const FLOAT32 WD_REFRESH_PERIOD = 5; // in msec
        const UINT16 TC_WDT_MAX_TIME_IN_MICROSEC=25000;
    #else
        const FLOAT32 WD_REFRESH_PERIOD = 2.5; // in msec
        const UINT16 TC_WDT_MAX_TIME_IN_MICROSEC=15000;
        const UINT32 MICROSECONDS_IN_MILLISECOND = 1000;
    #endif
#endif

#ifdef H8S

//Redundancy Related Constant Declarations
// Status of switches with Test switch in Normal state 
const UINT8 INH_ON_ON   = 0x00; //a and b on
const UINT8 INH_ON_OFF  = 0x04; //b sws on
const UINT8 INH_OFF_ON  = 0x02; //a sws on
const UINT8 INH_OFF_OFF = 0x06; //a and b off 

const UINT8 INH_OFF_ON_TST_ON   = 0x0E; //a sws on
const UINT8 INH_OFF_OFF_TST_ON  = 0x06; //a sws on

const UINT8 DIS_ON_ON   = 0x70;
const UINT8 DIS_ON_OFF  = 0x10;
const UINT8 DIS_OFF_ON  = 0x60;
const UINT8 DIS_OFF_OFF = 0x00;

const UINT8 TST_ON        = 0x02;
const UINT8 TST_OFF       = 0x00;
const UINT8 TST_DISABLED  = 0x80;
const UINT8 TST_ENABLED   = 0x00;
const UINT8 TSTn_DISABLED = 0;
const UINT8 TSTn_ENABLED  = 1;

const UINT16 READ_DELAY_TIME     = 250; //250us Read delay 
const UINT16 TST_READ_DELAY_TIME = 20;  //20us Read delay
const UINT16 DIS_READ_DELAY_TIME = 20; 
const UINT16 INH_READ_DELAY_TIME = 300; 

const UINT8 DIS_SWA_SET  = 0x10;
const UINT8 DIS_SWB1_SET = 0x20;
const UINT8 DIS_SWB2_SET = 0x40;

const UINT8 TST_SET      = 0x80;

const UINT8 INH_SWA_SET    = 0x08;
const UINT8 INH_SWB1_SET   = 0x02;
const UINT8 INH_SWB2_SET   = 0x04;

typedef enum SWITCH_TYPE{
    DIS_SWCH              = 0x0,
    TST_SWCH              = 0x1,
    INH_SWCH              = 0x2
}SWITCH_TYPE;

#define WIGGLE_TEST_RETRY       3
#define RED_HW_RETRY            3
    
#ifdef IOMTYPE_SP
    #define CPLD_VERSION  0x81
#endif
#ifdef IOMTYPE_SVP
    #define CPLD_VERSION  0x01
#endif

#define APP_BOARD_POWER_HARD_FAILURE_RETRY   3
#define VERIFY_SWITCH_HARD_FAILURE_RETRY     3

#ifdef IOMTYPE_SVP
#define IOTA_TYPE       IOTA_TYPE_SVP
#define APP_BOARD_TYPE  APP_BOARD_TYPE_SVP
#endif

#ifdef IOMTYPE_SP
#define IOTA_TYPE       IOTA_TYPE_SP
#define APP_BOARD_TYPE  APP_BOARD_TYPE_SP
#endif

#ifdef  IOMTYPE_SVP
    #define WDT_PREFIRE_TIMEOUT         3     //5ms * 3 = 15msec
    // The diag counter m_uiWdtDiagCounter is incremented by one every time WDT
    // refresh is done. With 5 msec refresh, it takes 12000 diag counts for running
    // watchdog diagnostics once every minute. 60000/5 = 12000. 
    #define TC_WDT_DIAGSTART_DIAGCOUNT   12000
#elif   IOMTYPE_SP 
    // The diag counter m_uiWdtDiagCounter is incremented by one every time WDT
    // refresh is done. With 2.5 msec refresh, it takes 24000 diag counts for running
    // watchdog diagnostics once every minute. 60000/5 = 12000. 
    #define TC_WDT_DIAGSTART_DIAGCOUNT  12000
    #define WDT_PREFIRE_TIMEOUT         7     //5ms * 7 = 35msec
#endif  

#ifdef  IOMTYPE_SP
#define OPEN_WIRE_RETRY_CYCLES  3
#endif

#define TC_XREADY_TEST_REG    0x81044

#define HAND_SHAKE_ADDRESS    (0x85FFE)
#define DATA_BUS_DIAG_ADDR    0x80200 

volatile UINT16* const ADDR_DIAG_TBL[ADDR_DIAG_COUNT] = {
    (UINT16*)0x88002,
    (UINT16*)0x88004,
    (UINT16*)0x88008,
    (UINT16*)0x88010,
    (UINT16*)0x88020,
    (UINT16*)0x88040,
    (UINT16*)0x88080,
    (UINT16*)0x88100,
    (UINT16*)0x88200,
    (UINT16*)0x88400,
    (UINT16*)0x88800,
    (UINT16*)0x89000,
    (UINT16*)0x8A000,
    (UINT16*)0x8C000
};

volatile UINT16 const ADDR_DIAG_VAL_TBL[ADDR_DIAG_COUNT] = {
    (UINT16)0x8002,
    (UINT16)0x8004,
    (UINT16)0x8008,
    (UINT16)0x8010,
    (UINT16)0x8020,
    (UINT16)0x8040,
    (UINT16)0x8080,
    (UINT16)0x8100,
    (UINT16)0x8200,
    (UINT16)0x8400,
    (UINT16)0x8800,
    (UINT16)0x9000,
    (UINT16)0xA000,
    (UINT16)0xC000
};


const UINT16 CRC_LOOKUP_TBL[] = {
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
    0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
    0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
    0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
    0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
    0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
    0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
    0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
    0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
    0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
    0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
    0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
    0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
    0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
    0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
    0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
    0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
    0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
    0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
    0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
    0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
    0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
    0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
    0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
    0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
    0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
    0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
    0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
    0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
    0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
    0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
    0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0
};

#else

#define IRQ1_STATUS PieCtrlRegs.PIEIFR12.bit.INTx3

#define WDT_PREFIRE_TIMEOUT          8     //2.5ms * 8 = 20msec

// The diag counter m_uiWdtDiagCounter is incremented by one every time WDT
// refresh is done. With 2.5 msec refresh, it takes 24000 diag counts for running
// watchdog diagnostics once every minute. 60000/2.5 = 24000. 
#define TC_WDT_DIAGSTART_DIAGCOUNT   24000

#ifdef  IOMTYPE_SVP
#define OPEN_WIRE_RETRY_CYCLES  3
#endif

#define TC_XREADY_TEST_REG    0x2008E9

#define HAND_SHAKE_ADDRESS    (0x2028FF)
#define DATA_BUS_DIAG_ADDR    0x200200

volatile UINT16* const ADDR_DIAG_TBL[ADDR_DIAG_COUNT] = {
    (UINT16*)0x208002,
    (UINT16*)0x208004,
    (UINT16*)0x208008,
    (UINT16*)0x208010,
    (UINT16*)0x208020,
    (UINT16*)0x208040,
    (UINT16*)0x208080,
    (UINT16*)0x208100,
    (UINT16*)0x208200,
    (UINT16*)0x208400,
    (UINT16*)0x208800,
    (UINT16*)0x209000,
    (UINT16*)0x20A000,
    (UINT16*)0x20C000
};

volatile UINT16 const ADDR_DIAG_VAL_TBL[ADDR_DIAG_COUNT] = {
    (UINT16)0x8002,
    (UINT16)0x8004,
    (UINT16)0x8008,
    (UINT16)0x8010,
    (UINT16)0x8020,
    (UINT16)0x8040,
    (UINT16)0x8080,
    (UINT16)0x8100,
    (UINT16)0x8200,
    (UINT16)0x8400,
    (UINT16)0x8800,
    (UINT16)0x9000,
    (UINT16)0xA000,
    (UINT16)0xC000
};
extern BOOL FactryModeWDTUTest;
#endif

/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
TASKRETURN SVPDiagnosticTask(TASKCONTEXT); 

#ifdef DSC
VOID IdleWait(UINT16 a_uidlewait);
#endif

VOID EnableWatchdog(VOID);
VOID RefreshWDT(VOID);
VOID ClearWDT(VOID);
VOID XReadyDiag(VOID);
BOOL TestRAMCell(UINT32 uTestLocation);
VOID TCStartupDiagnostics();
VOID DoPostDiagnostics();
VOID TcIomDiagnostics();

#ifdef H8S
VOID PrintStr(const CHAR *a_cstrPrint);
VOID PrintVal(FLOAT32 flNumber);
#endif

// Various common diagnostic routines
RETURNSTATUS CPUDiagRoutine(VOID);
RETURNSTATUS RAMContentsDiagRoutine(VOID);
RETURNSTATUS EXTRAMContentsDiagRoutine(VOID);
RETURNSTATUS FlashContentsDiagRoutine(VOID);
RETURNSTATUS AddressDiagRoutine(VOID);
RETURNSTATUS DataDiagRoutine(VOID);
RETURNSTATUS DPADiagRoutine(VOID);
RETURNSTATUS APPIOTADiagRoutine(VOID);
RETURNSTATUS APPBoardPowerDiagRoutine(VOID);
RETURNSTATUS WiggleDiagRoutine(VOID);
RETURNSTATUS CPLDVersionDiagRoutine(VOID);
RETURNSTATUS SwitchDiagnostics(VOID);

#if defined(IOMTYPE_SP)
RETURNSTATUS EepromCountDiagnostics(VOID);
RETURNSTATUS EepromWrFlagDiagnostics(VOID);
RETURNSTATUS EepromChksmDiagnostics(VOID);
#endif

#define FPGA_CTRL_REG_KEY       0xB
#define FPGA_KEY_POS            10

class clsFPGACtrlReg
{
    private:
        volatile UINT16* PtrToCtrlReg;
        UINT16  FPGAKey;
        clsFPGACtrlReg(){}; 
         
    public:
        clsFPGACtrlReg(volatile UINT16* ptr)
        {
            PtrToCtrlReg = ptr;
            FPGAKey = FPGA_CTRL_REG_KEY << FPGA_KEY_POS;     //Key is written in Upper 6 bits
        }
        
        clsFPGACtrlReg(volatile UINT16* ptr, UINT16 Key)
        {
            PtrToCtrlReg = ptr;
            FPGAKey = Key<<FPGA_KEY_POS;
        }
        
        clsFPGACtrlReg& operator = (const UINT16& val)
        {
            if(val & 0xFF00)
            {
                //Invalid. Put a trace log
#ifdef H8S
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x90A,(UINT32)PtrToCtrlReg);
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x90A,val);
#else
                TraceLog.AddToTrace(TRACEID_GENERIC,bcCtrlRegViolation,(UINT32)PtrToCtrlReg);
                TraceLog.AddToTrace(TRACEID_GENERIC,bcCtrlRegViolation,(UINT32)val);
#endif
            }
            else
            {
                *PtrToCtrlReg = val | FPGAKey;
            }
            
            return *this;
        }
        
        operator UINT16()
        {
            return ( (*PtrToCtrlReg)  & 0x00FF );
        }
};

#if  (defined(IOMTYPE_SVP) && defined(DSC)) || (defined(IOMTYPE_SP) && defined(H8S))
// Constants used for SPI EEPROM
// INSTRUCTION SET
const UINT16 SS_EEPROM            = 0x0000;
const UINT16 SS_DESELECT          = 0x0001;
const UINT16 RXD_CMD              = 0x0003;
const UINT16 TXD_CMD              = 0x0002;
const UINT16 WR_ENABLE_CMD        = 0x0006;
const UINT16 RESET_WR_ENABLE_CMD  = 0x0004;
const UINT16 RD_STATUS_REG_CMD    = 0x0005;
const UINT16 WR_STATUS_REG_CMD    = 0x0001;
const UINT16 SET_SS_REQ_BIT          = 0x0008;
const UINT16 RD_RDY_BIT              = 0x0004;
const UINT8 EE_CKSUM_ADD               = 0xFE;

#define EEPROM_ADDR_RANGE_START     (0x0000)
#define EEPROM_ADDR_RANGE_END       (0x01FF)
#define EEPROM_CHKSM_ADDR_END       (0x01FE)
#define MAX_EEPROM_SIZE             512
#define EEPROM_PAGE_SIZE            16
#define EEPROM_LOW_PAGE             256

const UINT8 MAX_WRITE_ADDITIONAL_WAIT = 5;  //Additional wait time for write in msec
const UINT8 SPI_EEPROM_WIP = 0x01;
const UINT16 EEPROM_WRITE_WAIT = 5000;  //Typical EEPROM byte write time.

/*******************************************************************************
*                                  clsEeprom                                   *
*                                  =========                                   *
*******************************************************************************/
class clsEeprom {
public:
    clsEeprom(VOID) {
        // Initialize FPGA Interrrupt registers (IE, GE)
        EEPROM_SPI.CTRL = SS_DESELECT;   // Deassert both slave selects.
    }
    ~clsEeprom(VOID) { HardFail(HF_INVPROGRAMEXEC,SPBOXSLOT_HPP,__LINE__); }

    VOID *operator new (UINT32)  { return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,SPBOXSLOT_HPP,__LINE__); }

    VOID    EnableWrite(VOID);
    VOID    DisableWrite(VOID);
    UINT8   ReadStatusRegister(VOID);
    VOID    CheckWriteInProgress(VOID);
    UINT8   ReadByte(UINT8,UINT8);
    UINT16  ReadUint16(UINT8,UINT8);
    UINT32  ReadUint32(UINT8,UINT8);
    FLOAT32 ReadFloat(UINT8,UINT8);
    FLOAT64 ReadFloat64(UINT8,UINT8);
    VOID    WriteByte(UINT8,UINT8,UINT8);
    VOID    WritePage(UINT16,UINT8 *);
    UINT16  ComputeEepromChecksum(VOID);
    BOOL    ValidateEepromChecksum(VOID);
};

#endif      //#if  (defined(IOMTYPE_SVP) && defined(DSC)) || (defined(IOMTYPE_SP) && defined(H8S))

#endif      //#ifndef __DIAG_H__
