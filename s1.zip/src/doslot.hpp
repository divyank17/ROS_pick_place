/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : doslot.hpp                                                  *
*    Description : Class clsDoSlot declaration.                                *
*******************************************************************************/
#ifndef __DOSLOT_HPP__
#define __DOSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "outslot.hpp"
#if defined(IOPTYPE_DO)
#include "ecl.hpp"
#endif
#if defined(IOMTYPE_UIO) 
#include "hartdb.hpp"
#endif
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define DOSLOT_SIZE ((sizeof(clsDoSlot) + (sizeof(clsDoSlot) % 2)) / 2)

const FLOAT32 OP_MAXVALUE      = 100.0;
const FLOAT32 OP_MINVALUE      = 0.0;
const FLOAT32 PULSE_MAXVALUE   = 60.0;
const FLOAT32 PULSE_MINVALUE   = 0.0;
const FLOAT32 MAX_PERIOD       = 120.0;
const FLOAT32 MIN_PERIOD       = 1.0;

//PARAMETER NUMBER CONTANTS
#if !defined(IOMTYPE_UIO) //UIO definitions in doslot.cpp
#define PARAMID_DOTYPE      51
#define PARAMID_OP          54
#define PARAMID_PERIOD      55
#define PARAMID_PNTTYPE     57
#define PARAMID_PTEXECST    58
#define PARAMID_INITREQ     59
#define PARAMID_SLOTSFBT    62
#define PARAMID_SO          63
#define PARAMID_STDBYMAN    64
#define PARAMID_AOSDATA     65
#define PARAMID_OPTDIR      67
#define PARAMID_ONPULSE     68
#define PARAMID_OFFPULSE    69
#define PARAMID_PWMINITR    71
#define PARAMID_MODE        72
#define PARAMID_NMODE       73
#define PARAMID_MODEPERM    74
#define PARAMID_MODEATTR    75
#define PARAMID_NMODEATTR   76
#define PARAMID_REDTAG      77
#define PARAMID_FAULTOPT    125
#define PARAMID_FAULTVALUE  127
#define PARAMID_FAULTSTATE  128
#define PARAMID_LOCALMAN    242

#if defined(IOPTYPE_DO)
#define PARAMID_FL_UNPWRD   52
#define PARAMID_PNTFORM     56
#define PARAMID_LATCHED     241
#define PARAMID_ACTV_NRL_SO 243
#define PARAMID_PTEXECSTLRS 245

#if defined(DIGTYPE_DO32)
#define PARAMID_PRD_TM      246
#define PARAMID_PWM_PLS_TM  247
#define PARAMID_STRT_NXT    248
#define PARAMID_T_P_STRT    249
#define PARAMID_T_P_END     250
#endif //#if defined(DIGTYPE_DO32)

#endif //#if defined(IOPTYPE_DO)

#endif

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagDoType {
    DOTYPE_STATUS   = 0,
    DOTYPE_PWM      = 1,
    DOTYPE_ONPULSE  = 2,
    DOTYPE_OFFPULSE = 3
}DOTYPE;

#if defined(IOMTYPE_UIO)
// Enumeration for NUMOFCHNLSGANGED parameter
typedef enum
{
  NUMOFCHNLSGANGED_TWO   = 2,
  NUMOFCHNLSGANGED_THREE = 3,
  NUMOFCHNLSGANGED_FOUR  = 4
} NUMOFCHNLSGANGED;
#endif

class clsDoSlot; // forward declaration
typedef struct tagDoSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS     (clsDoSlot::* PrePtr)(UINT8 *, UINT8);
    VOID         (clsDoSlot::* PostPtr)(UINT8);
    VOID *       (clsDoSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} DO_SLOTPARAMINFO;

#if defined(IOPTYPE_DO)
typedef enum tagFl_UnPwrd {
    FL_UNPWRD_HOLD = 0,
    FL_UNPWRD_UNPOWER = 1
} FL_UNPWRD;
#endif

/*******************************************************************************
*                                   clsDoSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsDoSlot : public clsOutSlot {
private:
    DOTYPE  DOType;
    BLIND   StartNext;
    UINT16  PRDTime;
    UINT16  PWMPulseTime;
    FLOAT32 OffPulse;
    FLOAT32 OnPulse;
    FLOAT32 Op;
    BOOL    SO;
    FLOAT32 Period;
    UINT32  TPStart;
    UINT32  TPEnd;
    UINT8   PulseInProgress;
#if defined(IOMTYPE_UIO)
    BOOL    OwdEnable;
    BOOL    EnblGangedOutputs;             
    UINT8   NumOfChnlsGanged;
#endif
    // !!!*** DO_SLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the DO slot's redundant synch data area.
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end or to the spare memory allocated. If new members are addeed 
    // to the end, GetRedSlotSize() must be updated to reference the new end member. 
    // This dump record begins in clsIoSlot.
    BOOL    StdbyMan;
    BOOL    PWMInitR;

    // for PMIO DO32 & DO16 redesign
#if defined(IOPTYPE_DO)
  //FL_UNPWRD   Fl_UnPwrd;
    BOOL        Latched;
    BOOL        ActvNrmlSo;
    static const UINT8 PmioDumpParamTbl[];
#endif
       
    static const UINT8 AosData[];
    static const UINT8 CheckPointVer1[];
#if defined(IOMTYPE_UIO)
    static const UINT8 CheckPointVer2[];
#endif
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[];
    static const DO_SLOTPARAMINFO tblParamInfo[256];
#if defined(IOMTYPE_UIO)
    static UINT8 DoSlotChkpntVersion;
    static const UINT8 HEuRngExt[];
    clsHartCfgDb HartCfgDb;
    clsHartCfgDb7 HartCfgDb7;
    clsHartDevDb HartDevDb;
#endif

    inline VOID *GetDOTypePtr(VOID)         {return &DOType;}
    inline VOID *GetPeriodPtr(VOID)         {return &Period;}
    inline VOID *GetOnPulsePtr(VOID)        {return &OnPulse;}
    inline VOID *GetOffPulsePtr(VOID)       {return &OffPulse;}
    inline VOID *GetOpPtr(VOID)             {return &Op;}
    inline VOID *GetSOPtr(VOID)             {return &SO;}
    inline VOID *GetPRDTimePtr(VOID)        {return &PRDTime;}
    inline VOID *GetPWMPulseTimePtr(VOID)   {return &PWMPulseTime;}
    inline VOID *GetStartNextPtr(VOID)      {return &StartNext;}
    inline VOID *GetTPStartPtr(VOID)        {return &TPStart;}
    inline VOID *GetTPEndPtr(VOID)          {return &TPEnd;}
    inline VOID *GetPWMInitRPtr(VOID)       {return &PWMInitR;}
    inline VOID *GetStdbyManPtr(VOID)       {return &StdbyMan;}
#if defined(IOMTYPE_UIO)
    inline VOID *GetCheckPointPtr(VOID)     {return (VOID *)CheckPointVerTable[DoSlotChkpntVersion-1].CheckPointPtr;}
#else
    inline VOID *GetCheckPointPtr(VOID)     {return (VOID *)CheckPointVerTable[SlotChkpntVersion-1].CheckPointPtr;}
#endif
    inline VOID *GetRedParamsPtr(VOID)      {return (VOID *)RedParams;}
    inline VOID *GetAosDataPtr(VOID)        {return (VOID *)AosData;}

#if defined(IOMTYPE_UIO)
    // CFGRESTORE must only be written to the clsUioSlot, this pre-function ensures this is true
    PASTATUS PreCfgRestore(UINT8 *, UINT8) { return DO_PARAMETER_INVALID; }
    
    inline PASTATUS PreCheckPoint(UINT8 *,UINT8) 
    {
        DoSlotChkpntVersion = LATEST_UIO_DO_SLTCHKPNT_VERSION;
        return PA_OK; 
    }
    
    PASTATUS PreInitPntType(UINT8 *writebuffer, UINT8);
    
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &DoSlotChkpntVersion;}
    inline VOID *GetOwdEnablePtr(VOID)  { return &OwdEnable; }
    inline VOID *GetEnblGangedOutputsPtr( VOID)  { return &EnblGangedOutputs; }
    inline VOID *GetNumOfChnlsGangedPtr(VOID)  { return &NumOfChnlsGanged; }
    inline VOID *GetHDevCdPtr(VOID)     { return (VOID *)HartCfgDb.HDevCd; }
    inline VOID *GetHAlarmEnablePtr(VOID) { return &HartCfgDb.HAlarmEnable; }
    inline VOID *GetHEnablePtr(VOID)    { return &HartCfgDb.HEnable; }
    inline VOID *GetHScanCfgPtr(VOID)   { return &HartCfgDb.HScanCfg; }
    inline VOID *GetHDynRatePtr(VOID)   { return &HartDevDb.HDynRate; }
    inline VOID *GetHDevRatePtr(VOID)   { return &HartDevDb.HDevRate; }
    inline VOID *GetHSlotDvcPtr(VOID)   { return HartCfgDb7.HSlotDvc7; }
    inline VOID *GetHSlotDvcPtr7(VOID)  { return &HartCfgDb7.HSlotDvc7[4];}
    inline VOID *GetHComThrsPtr(VOID)   { return &HartCfgDb.HComThrs; }
    inline VOID *GetHComHysPtr(VOID)    { return &HartCfgDb.HComHys; }
    inline VOID *GetHComStsPtr(VOID)    { return &HartDevDb.HComSts; }
    inline VOID *GetHNComErrPtr(VOID)   { return &HartDevDb.HNComErr; }
    inline VOID *GetHLComFailPtr(VOID)  { return &HartDevDb.HLComFail; }
    inline VOID *GetH7Cmd0Ptr(VOID)     { return &HartDevDb.HCmd0.ucBytes[HART6_CMD0_RESPONSE_SIZE]; }
    inline VOID *GetHCmd0Ptr(VOID)      { return &HartDevDb.HCmd0; }
    inline VOID *GetHCmd12Ptr(VOID)     { return &HartDevDb.HCmd12; }
    inline VOID *GetHCmd13Ptr(VOID)     { return &HartDevDb.HCmd13; }
    inline VOID *GetHCmd14Ptr(VOID)     { return &HartDevDb.HCmd14; }
    inline VOID *GetHCmd15Ptr(VOID)     { return &HartDevDb.HCmd15; }
    inline VOID *GetHCmd16Ptr(VOID)     { return &HartDevDb.HCmd16; }
    inline VOID *GetHLongTagPtr(VOID)   { return &HartDevDb.HLongTag; }
    inline VOID *GetHDynValPtr(VOID)    { return HartDevDb.HDynVal; }
    inline VOID *GetHDynStPtr(VOID)     { return HartDevDb.HDynSt; }
    inline VOID *GetHDynCcPtr(VOID)     { return HartDevDb.HDynCc; }
    inline VOID *GetHDynEuPtr(VOID)     { return HartDevDb.HDynEu; }
    inline VOID *GetHSlot0TSPtr(VOID)   { return &HartDevDb.HDevSlot0DTS;}
    inline VOID *GetHSlotValPtr(VOID)   { return HartDevDb.HSlotVal; }
    inline VOID *GetHSlotStPtr(VOID)    { return HartDevDb.HSlotSt; }
    inline VOID *GetHSlotCcPtr(VOID)    { return HartDevDb.HSlotCc; }
    inline VOID *GetHSlotEuPtr(VOID)    { return HartDevDb.HSlotEu; }
    inline VOID *GetHDevStPtr(VOID)     { return HartDevDb.HDevSt; }
    inline VOID *GetHCmd48Ptr(VOID)     { return &HartDevDb.HCmd48; }
    inline VOID *GetHCmdFailPtr(VOID)   { return &HartDevDb.HCmdFail; }
    inline VOID *GetHCmdRespPtr(VOID)   { return &HartDevDb.HCmdResp; }
    inline VOID *GetHDvMfgCdPtr(VOID)   { return &HartCfgDb.HDvMfgCd; }
    inline VOID *GetHDvMfgCd7Ptr(VOID)  { return HartCfgDb7.HDvMfgCd7;}
    inline VOID *GetHDevIdCdPtr(VOID)   { return HartCfgDb.HDevIdCd; }
    inline VOID *GetHDvTypCdPtr(VOID)   { return &HartCfgDb.HDvTypCd; }
    inline VOID *GetHDvTypCd7Ptr(VOID)  { return HartCfgDb7.HDvTypCd7; }
    inline VOID *GetHDvRevCdPtr(VOID)   { return &HartCfgDb.HDvRevCd; }
    inline VOID *GetHDdRevCdPtr(VOID)   { return &HartCfgDb.HDdRevCd; }
    inline VOID *GetHNtfyCfgPtr(VOID)   { return HartCfgDb.HNtfyCfg; }
    inline VOID *GetHDynDvcPtr(VOID)    { return HartDevDb.HDynDvc; }
    inline VOID *GetHartVersionPtr(VOID){ return &HartDevDb.m_ucHartVersion; }
#endif
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    VOID *GetInitReqPtr(VOID);

    VOID InitDoSlot(BOOL bFullInit, BOOL bObjCreate);
    VOID StartPulse(BOOL, FLOAT32);
    VOID CalcPwmOnTime(FLOAT32);

    //pre and post function declarations
    PASTATUS PreDOType(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostDOType(UINT8 AccLvl);
    PASTATUS PreFaultOpt(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostFaultOpt(UINT8);
    PASTATUS PreFaultValue(UINT8 *writebuffer, UINT8 AccLvl);
    PASTATUS PreMode(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostMode(UINT8);
    PASTATUS PreModeAttr(UINT8 *writebuffer, UINT8 AccLvl);
    PASTATUS PreModePerm(UINT8 *writebuffer, UINT8 AccLvl);
    PASTATUS PreNMode(UINT8 *writebuffer, UINT8 AccLvl);
    PASTATUS PreNModeAttr(UINT8 *writebuffer, UINT8 AccLvl);
    PASTATUS PreRedTag(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostRedTag(UINT8);
    PASTATUS PreOp(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostOp(UINT8 AccLvl);
    PASTATUS PrePeriod(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostPeriod(UINT8 AccLvl);
    PASTATUS PrePntType(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostPntType(UINT8 AccLvl);
    PASTATUS PrePtExecSt(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostPtExecSt(UINT8 AccLvl);
    PASTATUS PreSO(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostSO(UINT8 AccLvl);
    PASTATUS PreOptDir(UINT8 *writebuffer, UINT8 AccLvl);
    PASTATUS PreOnPulse(UINT8 *writebuffer, UINT8 AccLvl);
    VOID     PostOnPulse(UINT8 AccLvl);
    PASTATUS PreOffPulse(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostOffPulse(UINT8 AccLvl);
#if defined(IOMTYPE_UIO)
    VOID     PostOwd(UINT8);
    PASTATUS PreNumOfChnlsGanged(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostNumOfChnlsGanged(UINT8);
#endif

#if defined(IOPTYPE_DO)
    VOID PostPntForm(UINT8);    
#endif
    
    PASTATUS ClampWithWarning(UINT8 *,UINT8,DOTYPE);
#if !defined(IOPTYPE_DO)
    UINT8    *GetParamPtr(UINT8);
#endif
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsDoSlot(const clsDoSlot&); // Safeguard against default copy constructor
    clsDoSlot& operator=(const clsDoSlot&); // and defualt assignement.

public:
    clsDoSlot(UINT8);
    ~clsDoSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,DOSLOT_HPP,__LINE__); }
    //static volatile UINT8 *OutputPorts[];
    VOID *operator new(UINT32, UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,DOSLOT_HPP,__LINE__); } 

    DATATYPE GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8 GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL GetIsDbChecksumed(UINT8);
    PASTATUS VerifyControlState(UINT8);

    VOID ProcessDoSlot(VOID);
    VOID CmptInitReq(VOID);
    VOID InactivateSlot(VOID);
    VOID SlotFaultHandler(TOG_FAILED);

    VOID InitSlotDatabase(BOOL);
    
    VOID DriveToQuiescentState(VOID);
    VOID OverCurrentAction(VOID);
    VOID BackInit(VOID);

    inline UINT32 GetRedSlotDelta(VOID) {
#if defined(IOMTYPE_UIO)
        // NumOfChnlsGanged,EnblGangedOutputs are added to support DO ganging functionality.
        // supporting these two parameters for iom redundancy in UIO, we are returning 
        // the size of the two parameter here for iom synchronization during Migration.
        return (sizeof(NumOfChnlsGanged) + sizeof(EnblGangedOutputs));
#else
        return 0;
#endif
    }

#if defined(IOPTYPE_DO)
    inline VOID InitTPStartEnd(VOID)      { TPStart = TPEnd = 0; } //instead of relative clock implementation (T_FLUIDx..)
    inline UINT32 GetRedSlotSize(VOID)    { return PMIO_SLOTDUMP_PARAMSIZE; }
    inline UINT8 *GetRedSlotPointer(VOID) { return (UINT8 *)PmioDumpParamTbl; }
    inline UINT8 GetPulseInProgState(VOID) { return PulseInProgress; }
#else

    inline UINT32 GetRedSlotSize(VOID) {
#if defined(IOMTYPE_UIO)
        return ((UINT32)((UINT8 *)&NumOfChnlsGanged - (UINT8 *)&PntType) + sizeof(NumOfChnlsGanged));
#else
        return ((UINT32)((UINT8 *)&PulseInProgress - (UINT8 *)&PntType) + sizeof(PulseInProgress));
#endif
    }
        
    inline UINT8 *GetRedSlotPointer(VOID) {
        return (UINT8 *)&PntType;
    }
#endif
    inline BOOL GetSO(VOID) {
        return SO;
    }
    inline VOID SetSO(BOOL a_bSo) {
        SO = a_bSo;
    }
    inline DOTYPE  GetDOType(VOID) {
        return DOType;
    }
    inline BLIND  GetStartNext(VOID) {
        return StartNext;
    }
    inline UINT16  GetPWMPulseTime(VOID) {
        return PWMPulseTime;
    }
    
    inline VOID  SetPWMPulseTime(UINT16 a_uiValue) {
        PWMPulseTime = a_uiValue;
    }
    
    BOOL IsOutputNotViable(UINT8 ucParamId);
    
#if defined(IOMTYPE_UIO)
    inline BOOL GetOwdEnable(VOID) { return OwdEnable;}  
    virtual UINT8 GetSlotChkPntParamId(VOID);   
    virtual UINT8 GetLatestSlotChkPntVersion(VOID);
    virtual UINT8 GetPtExecStParamId(VOID);
    inline BOOL GetEnblGangedOutputs(VOID) { return EnblGangedOutputs;}
    inline UINT8 GetNumOfChnlsGanged(VOID) { return NumOfChnlsGanged;}
    VOID ConfigureAdjacentChannels(UINT8 a_ucChanStart); // Configures h/w interface, Do channel mask and Enable/Disable the DAC for Adjacent channels 
    VOID DeleteAdjacentChannels(UINT8 a_ucChanStart); // Initializes h/w interface, Do channel mask and Disable the DAC for Adjacent channels 
    VOID ClearOverCurrentSfForAdjChnls(VOID); // clears the over currnet softfail for do ganging adjacent channels if it is already set.
#endif

#ifdef DEBUG
    friend RETURNSTATUS TestHoldOut(VOID);
#endif

    // for PMIO DO32 & DO16 redesign
#if defined(IOPTYPE_DO)
  
    UINT8 *GetParamPtr(UINT8);
    VOID  PostFl_UnPwrd(UINT8);
    VOID  CreatePtExecStEvt(EVENTTYPE a_EventType);

    inline VOID *GetActvNrmlSoPtr(VOID)              { return &ActvNrmlSo; }
    inline VOID *GetLatchedPtr(VOID)                 { return &Latched; }
  //inline VOID *GetFl_UnPwrdPtr(VOID)               { return &Fl_UnPwrd; }
    inline VOID *GetFl_UnPwrdPtr(VOID)                 { return &FaultOpt; } //since GetFaultOptPtr() is inaccessible
    inline VOID *GetPmioDumpParamPtr(VOID)           { return (VOID *)PmioDumpParamTbl; }

    inline UINT8 IsCheckPointParam(UINT8 ucParamId)
    {
        UINT8 ucArrayIndex = 0;
        UINT8 ucChkPntIndex = 0;

        while (CheckPointVer1[ucArrayIndex])
        {
            if (CheckPointVer1[ucArrayIndex] == ucParamId)
                return (ucChkPntIndex + 1);
            else
                ucChkPntIndex += GetParamSize(CheckPointVer1[ucArrayIndex]);

            ucArrayIndex++;
        }

        return PA_NULL;
    }
#endif
};

#endif
