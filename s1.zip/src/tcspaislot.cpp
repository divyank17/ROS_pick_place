/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcspaislot.cpp                                              *
*    Description : Class clsTcSpAiSlot definition.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8  clsTcSpAiSlot::CheckPointVer1[] = {
    kSpAiPnChkPntVer,
    kSpAiPnPntType,
    kSpAiPnSensrTyp,
    kSpAiPnPvChar,
    kSpAiPnInptDir,
    kSpAiPnPvExEUHi,
    kSpAiPnPvEUHi,
    kSpAiPnPvEULo,
    kSpAiPnPvExEULo,
    kSpAiPnPvClamp,
    kSpAiPnLoCutOff,
    kSpAiPnTf,
    kSpAiPnPvTv,
    kSpAiPnPvSrcOpt,
    kSpAiPnPvSource,
    kSpAiPnOwdEnable,
    kSpAiPnPtExecSt,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsTcSpAiSlot::CheckPointVerTable[] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsTcSpAiSlot::SpAiSlotChkpntVersion = LATEST_SP_AI_SLTCHKPNT_VERSION;

const UINT8 clsTcSpAiSlot::RedParams[] = {
    kSpAiPnInptDir,
    kSpAiPnLoCutOff,
    kSpAiPnPntType,
    kSpAiPnPtExecSt,
    kSpAiPnPvChar,
    kSpAiPnPvClamp,
    kSpAiPnPvEUHi,
    kSpAiPnPvEULo,
    kSpAiPnPvExEUHi,
    kSpAiPnPvExEULo,
    kSpAiPnPvSrcOpt,
    kSpAiPnPvSource,
    kSpAiPnPvTv,
    kSpAiPnPvTvP,
    kSpAiPnSensrTyp,
    kSpAiPnTf,
    0 // Terminator
};

const SPAISLOTPARAMINFO clsTcSpAiSlot::tblParamInfo[] = { // Build paraminfo table
 //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
//  FILL 0 index to 50th index///////////////////////////////////////////////////////////////////////////////////////////
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePntType,PostPntType,GetPntTypePtr,TRUE,                // 51 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PrePtExecSt,PostPtExecSt,GetPtExecStPtr,TRUE,            // 52 PtExecSt
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadPvFlPtr,FALSE,                                 // 53 BadPvFl
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,PreInptDir,0,GetInptDirPtr,TRUE,                      // 54 InptDir
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastPvPtr,FALSE,                               // 55 LastPv
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreLoCutOff,0,GetLoCutOffPtr,TRUE,                     // 56 LoCutOff
    DT_FLOAT32,4,AT_BXREC,ALCK_OPER,CONTROLSTATE_NONE,PrePv,PostPv,GetPvPtr,FALSE,                           // 57 Pv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoPtr,FALSE,                               // 58 PvAuto
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoStPtr,FALSE,                                // 59 PvAutoSt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvCalcPtr,FALSE,                               // 60 PvCalc
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,PrePvChar,0,GetPvCharPtr,TRUE,                        // 61 PvChar
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,0,0,GetPvClampPtr,TRUE,                               // 62 PvClamp
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,PrePvEUHi,PostPvEUHi,GetPvEUHiPtr,TRUE,           // 63 PvEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,PrePvEULo,PostPvEULo,GetPvEULoPtr,TRUE,           // 64 PvEULo
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,PrePvExEUHi,PostPvExEUHi,GetPvExEUHiPtr,TRUE,     // 65 PvExEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,PrePvExEULo,PostPvExEULo,GetPvExEULoPtr,TRUE,     // 66 PvExEULo
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvExHiFlPtr,FALSE,                                // 67 PvExHiFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvExLoFlPtr,FALSE,                                // 68 PvExLoFl
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvPPtr,FALSE,                                  // 69 PvP
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvRawPtr,FALSE,                                // 70 PvRaw
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePvSource,PostPvSource,GetPvSourcePtr,TRUE,            // 71 PvSource
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,PostPvSrcOpt,GetPvSrcOptPtr,TRUE,                      // 72 PvSrcOpt
    DT_ENUM,1,AT_BXREC,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvStsPtr,FALSE,                                   // 73 PvSts
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePvTv,PostPvTv,GetPvTvPtr,TRUE,                     // 74 PvTv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvTvPPtr,FALSE,                                // 75 PvTvP
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,PreSensrTyp,PostSensrTyp,GetSensrTypPtr,TRUE,         // 76 SensrTyp
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PreTf,PostTf,GetTfPtr,TRUE,                           // 77 Tf
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreOwdEnable,0,GetOwdEnablePtr,TRUE,                      // 78 OwdEnable 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 79
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 80
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,                               // 81 SlotSfBt 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 82
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 101
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 102
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 103
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 104
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 113
    DT_BLIND,38,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,FALSE,                  // 114 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 116
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 132 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 133  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 142
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 243
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,// 244 SlotChkpntVersion
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 255

};

/*******************************************************************************
*                            clsTcSpAiSlot::clsTcSpAiSlot                      *
*                            ============================                      *
* PURPOSE   : Constructor of clsTcSpAiSlot Class. which initializes  class     *
*             members.                                                         *
* ARGUMENTS : a_ucSltNm - Slot Number                                          *
* RETURN    : NONE                                                             *
* NOTES:    :                                                                  *
*******************************************************************************/
clsTcSpAiSlot::clsTcSpAiSlot( UINT8 a_ucSltNm ) : clsInSlot(PNTTYPE_NOTCONFIGURED, a_ucSltNm) {
        InitSpAiSlot(FALSE, TRUE);
}

/*******************************************************************************
*                           clsTcSpAiSlot::operator new                        *
*                           ===========================                        *
* PURPOSE  : Overrided new Operator to allocate memory to Slot                 *
* ARGUMENTS: a_ucSltNm - Slot Number                                           *
* RETURN   : returns slot memory pointer                                       *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsTcSpAiSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return ucIomDbMemory + SPBOXSLOT_SIZE +  
              ((a_ucSltNm-AI_CH_START)* TCSPAISLOT_SIZE);
}

/*******************************************************************************
*                          clsTcSpAiSlot::GetDataType                          *
*                          ==========================                          *
* PURPOSE  : This function returns data type of the parameter.                 *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : DataType of the parameter                                         *
* NOTES    :                                                                   *
*******************************************************************************/
DATATYPE clsTcSpAiSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsTcSpAiSlot::GetAccessType                        *
*                          ============================                        *
* PURPOSE  : This function returns accesstype of the parameter.                *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : AccessType of the parameter.                                      *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSTYPE clsTcSpAiSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                            clsTcSpAiSlot::GetParamSize                       *
*                            ===========================                       *
* PURPOSE  : This function returns size of the parameter                       *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsTcSpAiSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsTcSpAiSlot::GetParamPtr                        *
*                            ==========================                        *
* PURPOSE  : This function returns Pointer of the parameter                    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 *clsTcSpAiSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                           clsTcSpAiSlot::GetAccessLock                       *
*                           ============================                       *
* PURPOSE  : This function returns Access Lock of the parameter.               *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Access Lock of the parameter number.                              *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSLOCK clsTcSpAiSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                       clsTcSpAiSlot::GetIsDbChecksumed                       *
*                       ================================                       *
* PURPOSE  : This function returns whether parameter.is checkpointed or not    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : BOOL - TRUE if parameter is checkpoint paramter, else FALSE       *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsTcSpAiSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsTcSpAiSlot::VerifyControlState                    *
*                         =================================                    *
* PURPOSE  : This function checks the contorl state assigned to the parameter  *
*            to actual present control state of the channel and IOM module     *
*            itself,before the actual write to the parameter.                  *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    : This function decides whether the write can be done or not to the *
*            paramerter under current channel or IOM state.                    *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x921,tblParamInfo[a_ucParamNumber].ControlState);
        break;
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsTcSpAiSlot::ExecutePreFunction                    *
*                         =================================                    *
* PURPOSE  : This function invokes the pre-function for the given writable     *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber  - Parameter Number                               *
*            a_Buffer         - Pointer to the data                            *
*            a_ucAccessLevel  - Access level of the parameter                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsTcSpAiSlot::ExecutePostFunction                   *
*                         ==================================                   *
* PURPOSE  : This function invokes the post-function for the given writable    *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber - Parameter Number                                *
*            a_ucAccessLevel - Access level of the parameter                   *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsTcSpAiSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}

/*******************************************************************************
*                           clsTcSpAiSlot::InitSlotDatabase                    *
*                           ============================                       *
* PURPOSE  : Initialize the entire channel database. Calls the Init function   *
*            for each class in the channel object hierarchy and recompute      *
*            database checksum.                                                *
* ARGUMENTS: bFullInit - lag utilised when slots have to be reinitialized      *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/ 
VOID clsTcSpAiSlot::InitSlotDatabase(BOOL bFullInit) {
    BOOL bObjCreate = FALSE; 
    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitInSlot(bFullInit, bObjCreate);
    InitSpAiSlot(bFullInit, bObjCreate); 
    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                            clsTcSpAiSlot::InitSpAiSlot                       *
*                            ===========================                       *
* PURPOSE  : Initialization function for clsTcSpAiSlot data members.           *
* ARGUMENTS: bFullInit   - Flag utilised when slots have to be reinitialized   *
*            bObjCreate  - Flag utilised when slots have to be reinitialized   *
* RETURN   : NONE                                                              *
* NOTES    : This function is called when slot parameters                      *
*            need to be reinitialized                                          *
*******************************************************************************/
VOID clsTcSpAiSlot::InitSpAiSlot(BOOL bFullInit, BOOL){
    PvRaw     = NaN;
    PvCalc    = NaN;
    FiltOut   = NaN;
    PvAuto    = NaN;
    PvAutoSt  = PVVALST_BAD;
    LastPv    = NaN;

    PvEUHi    = NaN;
    PvEULo    = NaN;
    PvExEUHi  = NaN;
    PvExEULo  = NaN;
    PvClamp   = PVCLAMP_NOCLAMP;
    LoCutOff  = NaN;
    Tf        = (FLOAT32) 0.0;
    Kf        = (FLOAT32) 1.0;
    PvTv      = NaN;
    PvTvP     = NaN;

    EUSpan    = NaN;
    EUSpanDivHundred = NaN;
    HundredDivEUSpan = NaN;

    if (bFullInit) {
        PvP      = NaN;
        BadPvFl  = TRUE;
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
        BOX->SetPv(ChanNum,NaN);
        BOX->SetPvSts(ChanNum,(UINT32)PVVALST_BAD);
    }

    InptDir  = INPTDIR_DIRECT;
    PvChar   = PVCHAR_LINEAR;
    PvRawHI  = NaN;
    PvRawLO  = NaN;
    PvTemp   = PVTEMP_DEG_C;
    SensrTyp = SENSRTYP_1to5_V;
    ADRawHi  = NaN;
    ADRawLo  = NaN;
    HundredDivRawSpan = NaN;
    InputBelowDeadband = FALSE;
    OpenWireTestCount = 0;
    OpenWirePvFallCount = 0;
    bAiChnOpenSF = FALSE;

    OpenwireCnt = 0;
}

/*******************************************************************************
*                             clsTcSpAiSlot::GetPvPtr                          *
*                             ====================                             *
* PURPOSE  : This function returns PV Parameter Pointer                        *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsTcSpAiSlot::GetPvPtr(VOID) { 
     return &(BOX->SpInputScanRec.AiPv[ChanNum - AI_CH_START]);
}

/*******************************************************************************
*                            clsTcSpAiSlot::GetPvStsPtr                        *
*                            =======================                           *
* PURPOSE  : This function returns PvSts Parameter Pointer                     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsTcSpAiSlot::GetPvStsPtr(VOID) { 

    static UINT32  RetVal = BOX->GetAiPvSts(ChanNum);
    return &RetVal;
} 

/*******************************************************************************
*                            clsTcSpAiSlot::PrePv                              *
*                            ====================                              *
* PURPOSE:  Pre Receiver-Beware function for Pv parameter.                     *
*           This method checks for range of the data that can be written to    *
*           PV parameter, access level check, module status check, point       *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the Pv parameter               *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    // Get IOM state.
    UINT8 MdSts = BOX->GetModuleStatus();  

    // Get new value of PV in a local variable.
    FLOAT32 ufNewVal = *(FLOAT32 *)a_Writebuffer;

    if (PvSrcOpt == PVSRCOPT_ONLYAUTO) 
    {
        return DO_READ_ONLY_PARAMETER;
    }

    if (PvSource == PVSOURCE_AUTO)
    {
        return DO_PVSOURCE_INVALID;
    }

    //Access lock = engr OR supr OR oper OR pbd
    if ((PvSource == PVSOURCE_SUB) && (a_ucAccLvl & ALCK_ONPROC_PBD))
    {
        return DO_PVSOURCE_INVALID;
    }

    //Access lock = prog OR cc OR umcc OR iuser
    if ((PvSource == PVSOURCE_MANUAL) && (a_ucAccLvl & ALCK_PROG_UMCC_CC_IUSER))
    {
        return DO_PVSOURCE_INVALID;
    }

    if (isnan(ufNewVal)) {
        return PA_OK;
    }

    if (PvSource == PVSOURCE_MANUAL) {
        if (ufNewVal > PvExEUHi)
        {
            return DO_LIMIT_OR_RANGE_EXCEEDED;
        }

        if (ufNewVal < PvExEULo)
        {
            return DO_LIMIT_OR_RANGE_EXCEEDED;
        }

        return PA_OK;
    }
    else if (PvSource == PVSOURCE_SUB) 
    {
        if (MdSts == MODSTATUS_IDLE)
        {
            return DO_STATE_MUST_BE_RUN;
        }

        if (PtExecSt == PTEXECST_INACTIVE)
        {
            return DO_PTEXECST_OR_MODLSTAT_INCONSISTENT;
        }

        if (ufNewVal > PvExEUHi) 
        {
            ufNewVal = PvExEUHi;
            *(FLOAT32*) a_Writebuffer = ufNewVal;
            return DO_VALUE_CLAMPED_ERROR;
        }
        if (ufNewVal < PvExEULo) 
        {
            ufNewVal = PvExEULo;
            *(FLOAT32*) a_Writebuffer = ufNewVal;
            return DO_VALUE_CLAMPED_ERROR;
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsTcSpAiSlot::PostPv                              *
*                           =====================                              *
* PURPOSE:  Post Receiver-Beware function for PV parameter.                    *
*           (1) Sets the PV Extended Range flags if PV exceeds the extended    *
*               range values.                                                  *
*           (2) Updates PvSts, EU Span, and PVP.                               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:NONE                                                                  *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPv(UINT8) {
    FLOAT32 fCurPv = BOX->GetPv(ChanNum);

    if (isnan(fCurPv)) 
    {
        PvP = NaN;

        BOX->SetPvSts(ChanNum,(UINT32)PVVALST_BAD); //Note::
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
    }
    else 
    {
        if (fCurPv == PvExEULo)
        {
            PvExLoFl = TRUE;
        }
        else 
        {
            PvExLoFl = FALSE;
        }

        if (fCurPv == PvExEUHi)
        {
            PvExHiFl = TRUE;
        }
        else
        {
            PvExHiFl = FALSE;
        }

        if (PVSOURCE_MANUAL == PvSource) {
            BOX->SetPvSts(ChanNum,(UINT32)PVVALST_MANUAL); //Note::
        }
        else {
            BOX->SetPvSts(ChanNum,(UINT32)PVVALST_UNCERTN); //Note::
        }

        // Update EUSpan and PvP.
        if (isnan(PvEUHi) || isnan(PvEULo)) {
            EUSpan = NaN;
            EUSpanDivHundred = NaN;
            HundredDivEUSpan = NaN;
            PvP = NaN;
        }
        else {
            EUSpan = PvEUHi - PvEULo;
            EUSpanDivHundred = EUSpan / (FLOAT32)100.0;
            HundredDivEUSpan = (FLOAT32)100.0 / EUSpan;
            PvP = (fCurPv - PvEULo) * HundredDivEUSpan;
        }
    }

}

/*******************************************************************************
*                          clsTcSpAiSlot::PrePvEUHi                            *
*                          ========================                            *
* PURPOSE:  Pre Receiver-Beware function for PvEUHi parameter.                 *
*           This method checks for range of the data that can be written to    *
*           PvEUHi parameter, access level check, module status check, point   *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PvEUHi parameter           *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvEUHi(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    if (!RealCompare(NewVal, PvEUHi)) {
        if (isnan(NewVal)) {
            return DO_ILLEGAL_VALUE;
        }

        if (!isnan(PvEULo)){
            if (NewVal < PvEULo){
                return DO_LIMIT_OR_RANGE_CROSSOVER;
            }

            if (NewVal < (PvEULo + (FLOAT32) 0.001)){
                return DO_ENGR_UNIT_SPAN_TOO_SMALL;
            }
        }

        if ((!isnan(PvExEUHi)) && (NewVal > PvExEUHi)){
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }

        if ((!isnan(LoCutOff)) && (NewVal < LoCutOff)){
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }
    return PA_OK;
}

/*******************************************************************************
*                           clsTcSpAiSlot::PostPvEUHi                          *
*                           =========================                          *
* PURPOSE:  Post Receiver-Beware function for PvEUHi parameter.                *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPvEUHi(UINT8) {
    // Force result of floating point operation to QNaN, if any of 
    // the operands is NaN. Otherwise it will result in SNaN.
    if (isnan(PvEUHi) || isnan(PvEULo)) {
        EUSpan = NaN;
        EUSpanDivHundred = NaN;
        HundredDivEUSpan = NaN;
    }
    else {
        EUSpan = PvEUHi - PvEULo;
        EUSpanDivHundred = EUSpan / (FLOAT32)100.0;
        HundredDivEUSpan = (FLOAT32)100.0 / EUSpan;
    }
}

/*******************************************************************************
*                          clsTcSpAiSlot::PrePvEULo                            *
*                          ========================                            *
* PURPOSE:  Pre Receiver-Beware function for PvEULo parameter.                 *
*           This method checks for range of the data that can be written to    *
*           PvEULo parameter, access level check, module status check, point   *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PvEULo parameter           *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvEULo(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    if ( !RealCompare(NewVal, PvEULo) ) {
        if (isnan(NewVal)){ 
            return DO_ILLEGAL_VALUE;
        }

        if ( !isnan(PvEUHi) ) {
            if (NewVal > PvEUHi){
                return DO_LIMIT_OR_RANGE_CROSSOVER;
            }

            if (NewVal > (PvEUHi - (FLOAT32)0.001)){
                return DO_ENGR_UNIT_SPAN_TOO_SMALL;
            }
        }

        if ( (!isnan(PvExEULo)) && (NewVal < PvExEULo) ){
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }

        if ( (!isnan(LoCutOff)) && (NewVal > LoCutOff) ){
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }
    return PA_OK;
}

/*******************************************************************************
*                           clsTcSpAiSlot::PostPvEULo                          *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for PvEUHi parameter.                *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:NONE                                                                  *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPvEULo(UINT8) {
    // Force result of floating point operation to QNaN, if any of 
    // the operands is NaN. Otherwise it will result in SNaN.
    if (isnan(PvEUHi) || isnan(PvEULo)) {
        EUSpan = NaN;
        EUSpanDivHundred = NaN;
        HundredDivEUSpan = NaN;
    }
    else {
        EUSpan = PvEUHi - PvEULo;
        EUSpanDivHundred = EUSpan / (FLOAT32)100.0;
        HundredDivEUSpan = (FLOAT32)100.0 / EUSpan;
    }
}

/*******************************************************************************
*                              clsTcSpAiSlot::PrePvTv                          *
*                              ======================                          *
* PURPOSE:  Pre Receiver-Beware function for PvTv parameter.                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the Tf parameter               *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvTv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) 
{
    FLOAT32 NewVal = *(FLOAT32 *)a_Writebuffer;

    if (! RealCompare(NewVal,PvTv)) { 
        if (isnan(PvExEUHi) || isnan(PvExEULo)){
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
        if (!isnan(NewVal)) {
            if (a_ucAccLvl & ALCK_ONPROC_PBD) { //OPER or SUPR or ENGR or PBD
                if ((NewVal > PvExEUHi) || (NewVal < PvExEULo)){
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
                }
            }
            else { //PROG or CC or UMCC or IUSER
                if (NewVal < PvExEULo) {
                    *(FLOAT32 *)a_Writebuffer = PvExEULo;
                    return DO_VALUE_CLAMPED_ERROR;
                }
                if (NewVal > PvExEUHi) {
                    *(FLOAT32 *)a_Writebuffer = PvExEUHi;
                    return DO_VALUE_CLAMPED_ERROR;
                }
            } //access level
        } //PvTv is NaN
    }
    return PA_OK;
}
/*******************************************************************************
*                              clsTcSpAiSlot::PostPvTv                         *
*                              =======================                         *
* PURPOSE:  Post Receiver-Beware function for PvTv parameter.                  *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Parameter Access level                         *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPvTv(UINT8) 
{
    //Force result of any floating point operation to QNaN, if any of the 
    //operands is NaN. Otherwise it will result in SNaN.
    if (isnan(PvTv) || isnan(PvEULo) || isnan(EUSpan)) 
    {
        PvTvP = NaN;
    }
    else {
        PvTvP = (PvTv - PvEULo) * HundredDivEUSpan;
    }
}

/*******************************************************************************
*                          clsTcSpAiSlot::PreTf                                *
*                          ====================                                *
* PURPOSE:  Pre Receiver-Beware function for Tf parameter.                     *
*           This method checks for range of the data that can be written to    *
*           Tf parameter.                                                      *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the Tf parameter               *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PreTf(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32*) a_Writebuffer;


    if ((NewVal < 0.0) || (NewVal > (FLOAT32)SECONDS_IN_MINUTE)) {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    if (isnan(NewVal) || (NewVal < (FLOAT32) 0.00001)) {
        *(FLOAT32*) a_Writebuffer = (FLOAT32) 0.0;
    }
    
    return PA_OK;
}

/*******************************************************************************
*                            clsTcSpAiSlot::PostTf                             *
*                            =====================                             *
* PURPOSE:  Post Receiver-Beware function for PvTf parameter.                  *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Parameter Access level                         *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostTf(UINT8) {
    // PPX period is defined in units of milli seconds. Convert to seconds.
    FLOAT32 Ts = (FLOAT32)SP_AI_PPX_PERIOD / (FLOAT32)MILLISECONDS_IN_SECOND;
    Kf = Ts / (Ts + (Tf * (FLOAT32)SECONDS_IN_MINUTE));

}
/*******************************************************************************
*                          clsTcSpAiSlot::PrePvSource                          *
*                          ==========================                          *
* PURPOSE:   Pre Receiver-Beware function for PvSource parameter.              *
*            Validates some pre conditions before the new PvSource value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvSource parameter         *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvSource(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PVSOURCE NewVal = *(PVSOURCE *) a_Writebuffer;
    if ((a_ucAccLvl != ALVL_IUSER) || (NewVal != PvSource)) {
        if (PVSRCOPT_ONLYAUTO == PvSrcOpt) {
            return DO_PARAMETER_INVALID;
        }
    }
    return PA_OK;

}
/*******************************************************************************
*                            clsTcSpAiSlot::PostPvSource                       *
*                            ===========================                       *
* PURPOSE:  Post Receiver-Beware function for PvSource parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PvSource parameter         *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPvSource(UINT8) {
    UINT8 ucModSts = BOX->GetModuleStatus();

    if (PvSource != PVSOURCE_MANUAL) 
    {
        if ((PTEXECST_INACTIVE == PtExecSt) || (MODSTATUS_IDLE == ucModSts))
        {
            BOX->SetPv(ChanNum,NaN);
            BOX->SetPvSts(ChanNum,(UINT32)PVVALST_BAD);
            PvP       = NaN;
            PvExHiFl  = FALSE;
            PvExLoFl  = FALSE;
        }
        else if (PVSOURCE_SUB == PvSource) 
        {
            if ((PVVALST_NORMAL == BOX->GetAiPvSts(ChanNum)) ||
                (PVVALST_MANUAL == BOX->GetAiPvSts(ChanNum))) 
            {
                BOX->SetPvSts(ChanNum,(UINT32)PVVALST_UNCERTN);
            }
        }
    }
    else if (PVVALST_BAD != BOX->GetAiPvSts(ChanNum)) 
    {
        BOX->SetPvSts(ChanNum,(UINT32)PVVALST_MANUAL);
    }
}
/*******************************************************************************
*                          clsTcSpAiSlot::PreLoCutOff                          *
*                          ==========================                          *
* PURPOSE:  Pre Receiver-Beware function for LoCutOff parameter.               *
*           This method checks for a valid data range, access level, and valid *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the LoCutOff parameter         *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PreLoCutOff(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    FLOAT32 NewVal = *(FLOAT32*) a_Writebuffer;

    if (!RealCompare(NewVal, LoCutOff)) 
    {
        if ((PvChar != PVCHAR_LINEAR) && (PvChar != PVCHAR_SQRROOT) &&
            (PvChar != PVCHAR_DEVRANGE) && (PvChar != PVCHAR_SYSRANGE) && 
            (PvChar != PVCHAR_SYSRSQRT)) 
        {
            return DO_PARAMETER_INVALID;
        }

        if ( !isnan(NewVal) ) 
        {
            if ((NewVal < (FLOAT32)0.0) && (a_ucAccLvl != ALVL_IUSER))
            {
                return DO_LIMIT_OR_RANGE_EXCEEDED;
            }
            else 
            {
                if ((!isnan(PvEUHi)) && (NewVal > PvEUHi))
                {
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
                }
                if ((!isnan(PvEULo)) && (NewVal < PvEULo))
                {
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
                }
            }
        }
    }
    return PA_OK;
}

/*******************************************************************************
*                            clsTcSpAiSlot::PrePntType                         *
*                            =========================                         *
* PURPOSE:  Pre Receiver-Beware function for PntType parameter.                *
*           This method checks for range of the data that can be written to    *
*           PntType parameter, access level check, module status check, point  *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PNTTYPE NewVal = *(PNTTYPE *) a_Writebuffer;

    ScratchPad = PntType; // Save old point type for post function.
    UINT8 MdSts = BOX->GetModuleStatus();
    if ((a_ucAccLvl == ALVL_IUSER) && (MdSts != MODSTATUS_IDLE)) 
    {
        return DO_STATE_MUST_BE_IDLE;
    }

    if ((MdSts != MODSTATUS_IDLE) && (PtExecSt != PTEXECST_INACTIVE)) 
    {
        return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
    }

    if ((NewVal != PNTTYPE_SP) &&
        (NewVal != PNTTYPE_NOTCONFIGURED))
    {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}

/*******************************************************************************
*                            clsTcSpAiSlot::PostPntType                        *
*                            ==========================                        *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
*           (1) Checks for valid range and access level.                       *
*           (2) Calls Point-Build initialization.                              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPntType(UINT8 a_ucAccLvl) {

    if ((PNTTYPE_NOTCONFIGURED == PntType) ||
        (PvSource != PVSOURCE_MANUAL) || (ALVL_IUSER == a_ucAccLvl)) 
    {
        InitSlotDatabase(TRUE);
    }
    else {
        // Call Point-Build initialization.
        InitSlotDatabase(FALSE);
    }
}

/*******************************************************************************
*                            clsTcSpAiSlot::PrePtExecSt                        *
*                            ==========================                        *
* PURPOSE:   Pre Receiver-Beware function for PtExecSt parameter.              *
*            Validates some pre conditions before the new PtExecSt parameter   *
*            can be written to database.                                       *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PtExecSt parameter         *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePtExecSt(UINT8 *a_Writebuffer, UINT8) {
    if (TRUE == BOX->GetCalibAllState()) 
    {
        return DO_CALIB_IN_PROGRESS;
    }

    if (*(PTEXECST *)a_Writebuffer == PTEXECST_ACTIVE) 
    {
        if ((isnan(PvExEUHi)) || (isnan(PvExEULo)) ||
            (isnan(PvEUHi)) || (isnan(PvEULo))) {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
    }

    return PA_OK;
}

/*******************************************************************************
*                            clsTcSpAiSlot::PostPtExecSt                       *
*                            ===========================                       *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPtExecSt(UINT8) {
    if (PtExecSt == PTEXECST_INACTIVE) {
        InactivateSlot();
    }
}

/*******************************************************************************
*                            clsTcSpAiSlot::PrePvChar                          *
*                            ========================                          *
* PURPOSE:   Pre Receiver-Beware function for PvChar parameter.                *
*            Validates some pre conditions before the new PvChar parameter     *
*            can be written to database.                                       *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvChar parameter           *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvChar(UINT8 *, UINT8) {
    // Check if calibration is enabled.
    if (TRUE == BOX->GetCalibAllState()) {
        return DO_CALIB_IN_PROGRESS;
    }
    return PA_OK;

}

/*******************************************************************************
*                          clsTcSpAiSlot::PrePvExEUHi                          *
*                          ==========================                          *
* PURPOSE:   Pre Receiver-Beware function for PvExEUHi parameter.              *
*            Validates some pre conditions before the new PvExEUHi value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvExEUHi parameter         *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvExEUHi(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32 *) a_Writebuffer;

    if (!RealCompare(NewVal,PvExEUHi)) {
        if (isnan(NewVal)) 
        {
            return DO_ILLEGAL_VALUE;
        }

        if ((!isnan(PvEUHi)) && (NewVal < PvEUHi)) {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }

        if ((!isnan(PvTv)) && (NewVal < PvTv)) {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }

    }
    return PA_OK;
}

/*******************************************************************************
*                          clsTcSpAiSlot::PostPvExEUHi                         *
*                          ===========================                         *
* PURPOSE:  Post Receiver-Beware function for PvExEUHi parameter.              *
*           Check current PV value and set PvExHiFl if necessary.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PvExEUHi parameter         *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPvExEUHi(UINT8) {
    FLOAT32 fCurPv = BOX->GetPv(ChanNum);

    if (!isnan(fCurPv)) {
        if (fCurPv >= PvExEUHi) {
            PvExHiFl = TRUE;
            BOX->SetPv(ChanNum,PvExEUHi);
        }
        else {
            PvExHiFl = FALSE;
        }
    }
}
/*******************************************************************************
*                          clsTcSpAiSlot::PrePvExEULo                          *
*                          ==========================                          *
* PURPOSE:   Pre Receiver-Beware function for PvExEULo parameter.              *
*            Validates some pre conditions before the new PvExEULo value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvExEULo parameter         *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvExEULo(UINT8 *a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32 *) a_Writebuffer;

    if (! RealCompare(NewVal,PvExEULo)) {
        if (isnan(NewVal)) {
            return DO_ILLEGAL_VALUE;
        }

        if ((!isnan(PvEULo)) && (NewVal > PvEULo)) {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }

        if ((!isnan(PvTv)) && (NewVal > PvTv)) {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                          clsTcSpAiSlot::PostPvExEULo                         *
*                          ===========================                         *
* PURPOSE:  Post Receiver-Beware function for PvExEULo parameter.              *
*           Check current PV value and set PvExLoFl if necessary.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PvExEULo parameter         *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPvExEULo(UINT8) {
    FLOAT32 fCurPv = BOX->GetPv(ChanNum);

    if (!isnan(fCurPv)) {
        if (fCurPv <= PvExEULo) {
            PvExLoFl = TRUE;
            BOX->SetPv(ChanNum,PvExEULo);
        }
        else {
            PvExLoFl = FALSE;
        }
    }
}

/*******************************************************************************
*                          clsTcSpAiSlot::PrePvRawHI                           *
*                          =========================                           *
* PURPOSE:   Pre Receiver-Beware function for PvRawHI parameter.               *
*            Validates some pre conditions before the new PvRawHI value can    *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvRawHI parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvRawHI(UINT8 *, UINT8 a_ucAccLvl) {

    if (a_ucAccLvl != ALVL_IUSER) {
        return DO_READ_ONLY_PARAMETER;
    }

    return PA_OK;
}
/*******************************************************************************
*                          clsTcSpAiSlot::PrePvRawLO                           *
*                          =========================                           *
* PURPOSE:   Pre Receiver-Beware function for PvRawLO parameter.               *
*            Validates some pre conditions before the new PvRawLO value can    *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvRawLO parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvRawLO(UINT8 *, UINT8 a_ucAccLvl) {

    if (a_ucAccLvl != ALVL_IUSER) {
        return DO_READ_ONLY_PARAMETER;
    }

    return PA_OK;
}

/*******************************************************************************
*                            clsTcSpAiSlot::PostPvSrcOpt                       *
*                            ===========================                       *
* PURPOSE:  Post Receiver-Beware function for PvSrcOpt parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostPvSrcOpt(UINT8) {
 if (PvSrcOpt == PVSRCOPT_ONLYAUTO) 
 {
        PvSource = PVSOURCE_AUTO;
        UINT8 ucModSts = BOX->GetModuleStatus();
        if ((PtExecSt == PTEXECST_INACTIVE) || (ucModSts == MODSTATUS_IDLE)) 
        {
             BOX->SetPv(ChanNum,NaN);//Note::  
             BOX->SetPvSts(ChanNum,(UINT32)PVVALST_BAD); //Note::
            PvP       = NaN;
            PvExHiFl  = FALSE;
            PvExLoFl  = FALSE;
        }
    }
}
/*******************************************************************************
*                          clsTcSpAiSlot::PrePvTemp                            *
*                          ========================                            *
* PURPOSE:   Pre Receiver-Beware function for PvTemp parameter.                *
*            Validates some pre conditions before the new PvTemp value can     *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PvTemp parameter           *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PrePvTemp(UINT8 *, UINT8 a_ucAccLvl) {
    //since this parameter is not applicable to LINEAR and SQRROOT PvChar,
    //it is not applicable to HLAI VIOPs. 
    if (a_ucAccLvl != ALVL_IUSER)
    {
        return DO_PARAMETER_INVALID;
    }
    return PA_OK;  
}

/*******************************************************************************
*                          clsTcSpAiSlot::PreSensrTyp                          *
*                          ==========================                          *
* PURPOSE:   Pre Receiver-Beware function for SensrTyp parameter.              *
*            Validates some pre conditions before the new PvTemp value can     *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the SensrTyp parameter         *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PreSensrTyp(UINT8 *a_Writebuffer, UINT8) {
   // Check if calibration is enabled.
    if (BOX->GetCalibAllState()) {
        return DO_CALIB_IN_PROGRESS;
    }
    SENSRTYP NewVal = *(SENSRTYP *) a_Writebuffer;

    if((NewVal != SENSRTYP_0to5_V) && (NewVal != SENSRTYP_1to5_V) && 
       (NewVal != SENSRTYP_P4TO2_V))
    {
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;

}

/*******************************************************************************
*                            clsTcSpAiSlot::PostSensrTyp                       *
*                            ===========================                       *
* PURPOSE:  Post Receiver-Beware function for SensrTyp parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the SensrTyp parameter         *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::PostSensrTyp(UINT8) {
    PvChar = PVCHAR_LINEAR;

    if (SensrTyp == SENSRTYP_P4TO2_V) {
        ADRawLo = (FLOAT32) 0.4;
        ADRawHi = (FLOAT32) 2.0;
    }
    else {
        if (SensrTyp == SENSRTYP_1to5_V)
        {
            ADRawLo = (FLOAT32) 1.0;
        }
        else
        {
            ADRawLo = (FLOAT32) 0.0;
        }

        ADRawHi = (FLOAT32) 5.0;
    }
    
    if ((SensrTyp == SENSRTYP_0to5_V) || (SensrTyp == SENSRTYP_P4TO2_V)) 
    {
        OwdEnable = FALSE;
    }

    HundredDivRawSpan = (FLOAT32)100.0 / (ADRawHi - ADRawLo);

}

/*******************************************************************************
*                          clsTcSpAiSlot::PreOwdEnable                         *
*                          ===========================                         *
* PURPOSE:   Pre Receiver-Beware function for SensrTyp parameter.              *
*            Validates some pre conditions before the new OwdEnable value can  *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the OwdEnable parameter        *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PreOwdEnable(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
   BOOL NewVal = *(BOOL *)a_Writebuffer;

    if ((ALVL_IUSER == a_ucAccLvl) && (NewVal == OwdEnable))
    {
        return PA_OK;
    }

    if (((SensrTyp == SENSRTYP_0to5_V) || (SensrTyp == SENSRTYP_P4TO2_V))
        && (TRUE == NewVal)) {
            return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    if(bAiChnOpenSF==TRUE)// if already Owd is detected clear that
    {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
        bAiChnOpenSF = FALSE;
    }

    return PA_OK;
}

/*******************************************************************************
*                          clsTcSpAiSlot::PreInptDir                           *
*                          =========================                           *
* PURPOSE:  Pre Receiver-Beware function for InptDir parameter.                *
*           This method checks for range of the data, access level, and valid  *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the InptDir parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::PreInptDir(UINT8 *, UINT8 ) {

    if ((PvChar != PVCHAR_LINEAR) && (PvChar != PVCHAR_SQRROOT) &&
        (PvChar != PVCHAR_DEVRANGE) && (PvChar != PVCHAR_SYSRANGE) && 
        (PvChar != PVCHAR_SYSRSQRT)) 
    {
        return DO_PARAMETER_INVALID;
    }
    return PA_OK;
}

/*******************************************************************************
*                             clsTcSpAiSlot::UpdateBadPv                       *
*                             ==========================                       *
* PURPOSE:                                                                     *
*     This routine is called from various locations in the receiver beware code*
*     or the point processor to compute the current value of -BadPvFl-, and to *
*     update the data base with the result.                                    * 
* ARGUMENTS:  None                                                             *
* RETURN:     None                                                             *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::UpdateBadPv() 
{
    UINT8 ucModSts = BOX->GetModuleStatus();
    BOOL  nBadFlag = TRUE;// PV bad          
    
    if (PvSource == PVSOURCE_MANUAL) 
    {
        nBadFlag = FALSE;//  PV OK
    }
    else if ((ucModSts == MODSTATUS_RUN) && (PtExecSt == PTEXECST_ACTIVE)) 
    { 
        // BadPv updation should be done based on results of
        // ForcedInputDiag (FID) along with Slot soft fail bits as the 
        // FID softfail is posted at lower speed in BoxHouseKeeping.
        UINT32 ulBitMask = 0x0001;
        ulBitMask = ulBitMask<<(ChanNum-1);
        if((PvSource == PVSOURCE_AUTO) && (0 == SlotSfBt) && 
                (!(ulBitMask & BOX->GetForcedInputDiagStatus())))  
        {                                                           
            if (!GetOwdEnable()) {
                nBadFlag = FALSE;//  PV OK
            }
        }
        
        if (PvSource != PVSOURCE_AUTO) 
        {
            nBadFlag = FALSE;//  PV OK
        }
    }
    BadPvFl = nBadFlag;
}

/*******************************************************************************
*                          clsTcSpAiSlot::InactivateSlot                       *
*                          =============================                       *
* PURPOSE: This funcitions is invoked when channel is inactive, which          *
*          initialize process data to default value                            *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::InactivateSlot(VOID) 
{
    PvAuto   = NaN;
    PvAutoSt = PVVALST_BAD;
    PvCalc   = NaN;
    PvRaw    = NaN;
    LastPv   = NaN;
    FiltOut  = NaN;
    BadPvFl  = FALSE;
    if (PvSource != PVSOURCE_MANUAL) 
    {
        BOX->SetPv(ChanNum,NaN);  //Note::
        BOX->SetPvSts(ChanNum,(UINT32)PVVALST_BAD); //Note:: 
        PvP   = NaN;
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
    }
}

/*******************************************************************************
*                           clsTcSpAiSlot::ProcessSlot                         *
*                           ==========================                         *
* PURPOSE:   This function calculates PV depending on RawData                  *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::ProcessSlot(FLOAT32 a_fRawData) 
{
    volatile FLOAT32 fNewPvRaw, fNewPvCalc, fNewFiltOut, fNewPvAuto;

    // Inhibit slot processing on backup module during db synchronization
    // Man and Sub PVs could otherwise be inappropriately updated from raw data
    if (!Iol.AmPrimary() && REDSTATE_SYNCD != BOX->GetRedState()) {
        return;
    }

    if (isnan(a_fRawData)) {
        fNewPvRaw = NaN;
    }
    else {
        fNewPvRaw = (a_fRawData - ADRawLo) * HundredDivRawSpan;
    }

    // Pv Characterization
    if ((isnan(fNewPvRaw)) || (PTEXECST_INACTIVE == PtExecSt)) {
        fNewPvCalc = NaN;
    }
    else { 
        switch(PvChar) {
        case PVCHAR_LINEAR :
        case PVCHAR_SYSRANGE:
        case PVCHAR_DEVRANGE:
            if (InptDir == INPTDIR_DIRECT) {
                fNewPvCalc = (fNewPvRaw * EUSpanDivHundred) + PvEULo;
            }
            else {
                fNewPvCalc = PvEUHi - (fNewPvRaw * EUSpanDivHundred);
            }
            break;
        case PVCHAR_SQRROOT:
        case PVCHAR_SYSRSQRT:
            if (InptDir == INPTDIR_DIRECT) {
                if (fNewPvRaw >= 0) {
                    fNewPvCalc = (FLOAT32)(sqrt(fNewPvRaw/(FLOAT32)100.0) * EUSpan ) + PvEULo;
                }
                else {
                    fNewPvCalc = (FLOAT32)(-sqrt(-(fNewPvRaw)/(FLOAT32)100.0) * EUSpan ) + PvEULo;
                }
            }
            else {
                if (fNewPvRaw >= 0) {
                    fNewPvCalc = PvEUHi - (FLOAT32)(sqrt(fNewPvRaw/(FLOAT32)100.0) * EUSpan );
                }
                else {
                    fNewPvCalc = PvEUHi + (FLOAT32)(sqrt(-(fNewPvRaw)/(FLOAT32)100.0) * EUSpan );
                }
            }
            break;
        default:
            fNewPvCalc = NaN;
            break;
        }
    } //end of characterization

    // Pv range checking and filtering
    BOOL bHiFlag = FALSE, bLoFlag = FALSE;
    PVVALST NewPvAutoSt = PvAutoSt;
    if (isnan(fNewPvCalc)) {
        fNewFiltOut = NaN;
        fNewPvAuto  = NaN;
        NewPvAutoSt = PVVALST_BAD;
    }
    else { // New PvCalc is not NaN
        // Do Pv filtering first.
        fNewFiltOut = NaN;
        if (isnan(FiltOut)) {
            fNewFiltOut = fNewPvCalc;
        }
        else {
            fNewFiltOut = FiltOut + Kf * (fNewPvCalc - FiltOut);
        }

        // Do range check and clamping.
        fNewPvAuto = NaN;
        if (PvClamp) {
            if (fNewFiltOut > PvExEUHi) {
                fNewFiltOut = NaN;
                NewPvAutoSt = PVVALST_UNCERTN;
                fNewPvAuto  = PvExEUHi;
                bHiFlag     = TRUE;
            }
            else {
                if (fNewFiltOut < PvExEULo) {
                    fNewFiltOut = NaN;
                    NewPvAutoSt = PVVALST_UNCERTN;
                    fNewPvAuto  = PvExEULo;
                    bLoFlag     = TRUE;
                }   
                else {
                    NewPvAutoSt = PVVALST_NORMAL;
                    fNewPvAuto  = fNewFiltOut;
                }
            }
        } 
        else { // No clamp configured
            if (fNewPvCalc > PvExEUHi) {
                fNewFiltOut = NaN;
                NewPvAutoSt = PVVALST_BAD;
                fNewPvAuto  = NaN;
                bHiFlag     = TRUE;
            }
            else {
                if (fNewPvCalc < PvExEULo) {
                    fNewFiltOut = NaN;
                    NewPvAutoSt = PVVALST_BAD;
                    fNewPvAuto  = NaN;
                    bLoFlag     = TRUE;
                }
                else {
                    NewPvAutoSt = PVVALST_NORMAL;
                    fNewPvAuto  = fNewFiltOut;
                }
            }
        } //end of range checking and clamping.

        // Apply LoCutOff if configured.
        if ((!isnan(LoCutOff)) && (!isnan(fNewPvAuto)) && (fNewPvAuto < LoCutOff)) {
            fNewPvAuto = PvEULo;
        }

    } //end of range checking and filtering

    // if there is no failure: as part of the diagnostics needs to be covered
    // Update PV database with new values
    PvRaw = fNewPvRaw;
    PvCalc = fNewPvCalc;
    PvAuto  = fNewPvAuto;
    FiltOut = fNewFiltOut;
    PvAutoSt = NewPvAutoSt;

     // Do Pv source selection
    FLOAT32 fPv;
    if (PvSource == PVSOURCE_AUTO) {
        fPv = PvAuto;
        BOX->SetPv(ChanNum,fPv); 
        BOX->SetPvSts(ChanNum,(UINT32)PvAutoSt);

        if (PVVALST_BAD != PvAutoSt) {
            LastPv = fPv;
        }

        PvExHiFl = bHiFlag;
        PvExLoFl = bLoFlag;
    }
    else { // if PvSource is Man or Sub
        fPv = BOX->GetPv(ChanNum);  
        if (!isnan(fPv)) {
            LastPv = fPv;
        }

    } //end of Pv source selection

    //Normalize Pv
    PvP = (fPv - PvEULo) * HundredDivEUSpan;
}

/*******************************************************************************
*                             clsTcSpAiSlot::AIDataFetch                       *
*                             ==========================                       *
* PURPOSE:    This function fetches the AI PVRAW data from screws              *
* ARGUMENTS:                                                                   *
*              NONE                                                            *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::AiDataFetch(VOID)
{
    volatile UINT16 uiRawData = 0;
    volatile FLOAT32 fRawData = NaN; 


    if (MODSTATUS_IDLE == BOX->GetModuleStatus()) {
        ProcessSlot(NaN);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
        bAiChnOpenSF = FALSE;
    }

    else
    {
        uiRawData = SpAdc.GetRawData(ChanNum);    // Fetch raw data for this channel.

        StoreRawAdcCount(uiRawData); // Store raw count in channel.

        DIAGSTATUS DiagStatus = DoAiOpenWireDiag(uiRawData);
        switch(DiagStatus)
        {
            case DIAG_OK:
            {         
                // Threshold values based on the Board Type. Applied to 1-5V and P4-2V configuration.
                // The NaN Threshold corresponds to -24% (1-5V) or -22.5% (P4-2V).
                UINT16 uiNanEnterThreshold;   // set NaN if RawData is below this value (40 mV)
                UINT16 uiNanExitThreshold;    // Exit from NaN if RawData is above this value (50 mV)

                uiNanEnterThreshold = INPUT_NAN_COUNT;    // =589
                uiNanExitThreshold = uiNanEnterThreshold + INPUT_DEADBAND_BIAS;
                UINT16 uiZeroRef = 0;

                 // convert counts to 0.0 to 5.0 value, or to NaN
                if (uiRawData > uiNanEnterThreshold) { // RawData is greater than NaN threshold.
                    if (TRUE == WasInputBelowDeadband()) {
                        // Input was below deadband in previous cycle. Continue raw value
                        // calculation, only if it had risen above deadband in this cycle.
                        // This allows a hysteris to set in once input goes below NaN threshold.

                        if (uiRawData > uiNanExitThreshold) {
                            SetInputBelowDeadband(FALSE);
                             //Multiply with the hardware multiplication
                             fRawData=(FLOAT32)uiRawData;
                             fRawData -= (FLOAT32)(uiZeroRef);
                        }
                    }
                    else { // Input was above NaN threshold in previous cycle.
                        //Multiply with the hardware multiplication
                        fRawData=(FLOAT32)uiRawData;
                        fRawData -= (FLOAT32)(uiZeroRef);   
                    }
                }
                else if (SENSRTYP_0to5_V == GetSensorType()) {
                    SetInputBelowDeadband(FALSE);
                    fRawData=(FLOAT32)uiRawData;
                    fRawData -= (FLOAT32)(uiZeroRef);   
                }
                else { // Input is below NaN threshold and sensor type is not 0to5V.
                    fRawData = NaN;
                    SetInputBelowDeadband(TRUE);
                }
                // All checks passed. Use calibration data 
                // to convert ADC counts into raw data.
                if (!isnan(fRawData))
                {
                    SPMCALIBDATA CalibData=BOX->GetCalibData();
                    fRawData *= CalibData.AICalibrationSlope;
                    fRawData += CalibData.AICalibrationOffset;
                }
                ProcessSlot(fRawData);
            }
            break;
            case DIAG_FAIL:
            {
                // there is a open wire detection on Ai
                ProcessSlot(NaN);
            }
            break;
            case DIAG_UNCERN:
            {
                //Do Nothing, Keep the old pv
            }
            break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x922,DiagStatus);
                break;
        }
    }
}

/*******************************************************************************
*                             clsTcSpAiSlot::AIDataFetch                       *
*                             ==========================                       *
* PURPOSE:Performs AIDATA fetch in 3 steps:                                    *
* Step 1: select the required MUX selection and pass it to getrawdataphase1(); *
* Step 2: getrawdataphase2()                                                   *
* Step 3: Get the ADC count for the channel and                                *
* ARGUMENTS: Takes an additional argument Event to distinguish the steps.      *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAiSlot::AiDataFetch(enmChanProcEvent Event)
{
    volatile UINT16 uiRawData = 0;
    volatile FLOAT32 fRawData = NaN; 
    switch (Event)
    {
        case EVENT_DIAGFPGA_RESP_OK:
        if (MODSTATUS_IDLE == BOX->GetModuleStatus()) {
            ProcessSlot(NaN);
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
            bAiChnOpenSF = FALSE;
        }
        else
        {
            SpAdc.GetRawDataPhase1(ChanNum);    // Fetch raw data for this channel.
        }
        break;

        case EVENT_CHAN_MUX_TOUT:
            SpAdc.GetRawDataPhase2();    
        break;

        case EVENT_CHANFPGA_RESP_OK:
        {
            uiRawData  = SpAdc.GetRawDataPhase3();   

            StoreRawAdcCount(uiRawData); // Store raw count in channel.
            DIAGSTATUS DiagStatus = DoAiOpenWireDiag(uiRawData);
            switch(DiagStatus)
            {
                case DIAG_OK:
                {
                    // Threshold values based on the Board Type. Applied to 1-5V and P4-2V configuration.
                    // The NaN Threshold corresponds to -24% (1-5V) or -22.5% (P4-2V).
                    UINT16 uiNanEnterThreshold;   // set NaN if RawData is below this value (40 mV)
                    UINT16 uiNanExitThreshold;    // Exit from NaN if RawData is above this value (50 mV)

                    uiNanEnterThreshold = INPUT_NAN_COUNT;    // =589
                    uiNanExitThreshold = uiNanEnterThreshold + INPUT_DEADBAND_BIAS;
                    UINT16 uiZeroRef = 0;

                     // convert counts to 0.0 to 5.0 value, or to NaN
                    if (uiRawData > uiNanEnterThreshold) { // RawData is greater than NaN threshold.
                        if (TRUE == WasInputBelowDeadband()) {
                            // Input was below deadband in previous cycle. Continue raw value
                            // calculation, only if it had risen above deadband in this cycle.
                            // This allows a hysteris to set in once input goes below NaN threshold.

                            if (uiRawData > uiNanExitThreshold) {
                                SetInputBelowDeadband(FALSE);
                                 //Multiply with the hardware multiplication
                                 fRawData=(FLOAT32)uiRawData;
                                 fRawData -= (FLOAT32)(uiZeroRef);
                            }
                        }
                        else { // Input was above NaN threshold in previous cycle.
                            //Multiply with the hardware multiplication
                            fRawData=(FLOAT32)uiRawData;
                            fRawData -= (FLOAT32)(uiZeroRef);   
                        }
                    }
                    else if (SENSRTYP_0to5_V == GetSensorType()) {
                        SetInputBelowDeadband(FALSE);
                        fRawData=(FLOAT32)uiRawData;
                        fRawData -= (FLOAT32)(uiZeroRef);   
                    }
                    else { // Input is below NaN threshold and sensor type is not 0to5V.
                        fRawData = NaN;
                        SetInputBelowDeadband(TRUE);
                    }
                    // All checks passed. Use calibration data 
                    // to convert ADC counts into raw data.
                    if (!isnan(fRawData))
                    {
                        SPMCALIBDATA CalibData=BOX->GetCalibData();
                        fRawData *= CalibData.AICalibrationSlope;
                        fRawData += CalibData.AICalibrationOffset;
                    }
    
 
                    ProcessSlot(fRawData);
                }
                break;
                case DIAG_FAIL:
                {
                    // there is a open wire detection on Ai
                    ProcessSlot(NaN);
                }
                break;
                case DIAG_UNCERN:
                {
                    //Do Nothing, Keep the old pv
                }
                break;
            }
        }
        break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x923,Event);
            break;
    }
}

/*******************************************************************************
*                             clsTcSpAiSlot::GetDumpData                       *
*                             ==========================                       *
* PURPOSE  : This method will copy the redundancy dump data to buffer transmit *
*            to the secondary IOM                                              *
* ARGUMENTS: pDump - Dump Pointer                                              *
*            MaxSize - Dump Size                                               *
* RETURN   : PA_OK -   If getdump is succesful                                 *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsTcSpAiSlot::GetDumpData(UINT8* const pDump,const UINT8 MaxSize)
{
    PASTATUS retVal = PA_NULL;
    if(pDump && IS_EVEN(pDump) && sizeof(SYNCRECORD) < MaxSize)
    {
        PSYNCRECORD pSyncRec    = (PSYNCRECORD)pDump;
        /// AI slot implementation is completely on Iolink processor.
        pSyncRec->Header            = PACK2_AS_UI16(SPAI_SYNC_VER_1,0);
        pSyncRec->PntType           = (UINT8)PntType;
        pSyncRec->PtExecSt          = (UINT8)PtExecSt;
        pSyncRec->ContCut           = (UINT8)ContCut;
        pSyncRec->PvSource          = (UINT8)PvSource;
        pSyncRec->PvSrcOpt          = (UINT8)PvSrcOpt;
        pSyncRec->OwdEnable         = (UINT8)OwdEnable;
        pSyncRec->PvChar            = (UINT8)PvChar;
        pSyncRec->SensrTyp          = (UINT8)SensrTyp;
        pSyncRec->PvClamp           = (UINT8)PvClamp;
        pSyncRec->PvTemp            = (UINT8)PvTemp;
        pSyncRec->PvCalc            = PvCalc;
        pSyncRec->FiltOut           = FiltOut;
        pSyncRec->ADRawHi           = ADRawHi;
        pSyncRec->ADRawLo           = ADRawLo;
        pSyncRec->PvRawHI           = PvRawHI;
        pSyncRec->PvRawLO           = PvRawLO;
        pSyncRec->PvEUHi            = PvEUHi;
        pSyncRec->PvEULo            = PvEULo;
        pSyncRec->PvExEUHi          = PvExEUHi;
        pSyncRec->PvExEULo          = PvExEULo;
        pSyncRec->LoCutOff          = LoCutOff;
        pSyncRec->Tf                = Tf;
        pSyncRec->Kf                = Kf;
        pSyncRec->PvTv              = PvTv;
        pSyncRec->PvTvP             = PvTvP;
        pSyncRec->EUSpan            = EUSpan;
        pSyncRec->EUSpanDivHundred  = EUSpanDivHundred;
        pSyncRec->HundredDivEUSpan  = HundredDivEUSpan;
        pSyncRec->HundredDivRawSpan = HundredDivRawSpan;
        pSyncRec->InptDir           = (UINT8)InptDir;
        pSyncRec->Pv                = BOX->SpInputScanRec.AiPv[ChanNum - AI_CH_START];
        pSyncRec->PvSts             = BOX->GetAiPvSts(ChanNum);
        ///
        retVal = PA_OK;
    }

    return retVal;
}

/*******************************************************************************
*                             clsTcSpAiSlot::StoreDumpData                     *
*                             ============================                     *
* PURPOSE  : This method will copy the redundancy dump data into local dump    *
*            structure in Primary IOM                                          *
* ARGUMENTS: pDump - Dump Pointer                                              *
* RETURN   : PA_OK -   If dump is succesful                                    *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS  clsTcSpAiSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS retVal = PA_NULL;
    ///
    if(pDump && IS_EVEN(pDump))
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SPAI_SYNC_VER_1)
        {
            PSYNCRECORD pSyncRec    = (PSYNCRECORD)pDump;        

            PntType             = (PNTTYPE)pSyncRec->PntType;
            PtExecSt            = (PTEXECST)pSyncRec->PtExecSt;
            ContCut             = (BOOL)pSyncRec->ContCut;
            PvSource            = (PVSOURCE)pSyncRec->PvSource;
            PvSrcOpt            = (PVSRCOPT)pSyncRec->PvSrcOpt;
            OwdEnable           = (BOOL)pSyncRec->OwdEnable;
            PvChar              = (PVCHAR)pSyncRec->PvChar;
            SensrTyp            = (SENSRTYP)pSyncRec->SensrTyp;
            PvClamp             = (PVCLAMP)pSyncRec->PvClamp;
            PvTemp              = (PVTEMP)pSyncRec->PvTemp;
            PvCalc              = pSyncRec->PvCalc;
            FiltOut             = pSyncRec->FiltOut;
            ADRawHi             = pSyncRec->ADRawHi;
            ADRawLo             = pSyncRec->ADRawLo;
            PvRawHI             = pSyncRec->PvRawHI;
            PvRawLO             = pSyncRec->PvRawLO;
            PvEUHi              = pSyncRec->PvEUHi;
            PvEULo              = pSyncRec->PvEULo;
            PvExEUHi            = pSyncRec->PvExEUHi;
            PvExEULo            = pSyncRec->PvExEULo;
            LoCutOff            = pSyncRec->LoCutOff;
            Tf                  = pSyncRec->Tf;
            Kf                  = pSyncRec->Kf;
            PvTv                = pSyncRec->PvTv;
            PvTvP               = pSyncRec->PvTvP;
            EUSpan              = pSyncRec->EUSpan;
            EUSpanDivHundred    = pSyncRec->EUSpanDivHundred;
            HundredDivEUSpan    = pSyncRec->HundredDivEUSpan;
            HundredDivRawSpan   = pSyncRec->HundredDivRawSpan;
            InptDir             = (INPTDIR)pSyncRec->InptDir;
        
            if(PvSource != PVSOURCE_AUTO)
            {
                BOX->SetPv(ChanNum,pSyncRec->Pv);
                BOX->SetPvSts(ChanNum,(UINT32)pSyncRec->PvSts);
            }
        
            retVal = PA_OK;
        }
    }

    return retVal;
}

/*******************************************************************************
*                                  ToggleBit                                   *
*                                  =========                                   *
* PURPOSE:   This funetion will toggle the bit in the a_uiword location,       *
* ARGUMENTS: a_uiword-> pointer to the data to toggle the bit                  *
*            a_uiposition-> position of the bit to be set                      *
* RETURN:  Data of the parameter                                               *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 ToggleBit(UINT16 a_uidata, UINT16 a_uiposition)
{
    if(TRUE==GetBitValue(a_uidata,a_uiposition))
    {
        ClearBit(&a_uidata,a_uiposition);
    }
    else
    {
        SetBit(&a_uidata,a_uiposition);
    }
    return(a_uidata);
}

/*******************************************************************************
*                                  GetBitValue                                 *
*                                  ===========                                 *
* PURPOSE:   This funetion will get the bit value in the a_uiword location,    *
* ARGUMENTS: a_uiword-> pointer to the data to set the bit                     *
*            a_uiposition-> position of the bit                                *
* RETURN: returns bit value                                                    *
* NOTES:                                                                       *
*******************************************************************************/
BOOL GetBitValue(UINT16 a_uiword,UINT16 a_uiposition)
{
   a_uiword&=(0x0001<<a_uiposition);
   if(0!=a_uiword)
   {
        return TRUE;
   }
   else
   {
        return FALSE;
   }
}
/*******************************************************************************
*                                  ClearBit                                    *
*                                  ========                                    *
* PURPOSE:   This funetion will clear the bit in the a_uiword location,        *
* ARGUMENTS: a_uiword-> pointer to the data to clear the bit                   *
*            a_uiposition-> position of the bit to be clear                    *
* RETURN:  None                                                                *
* NOTES:                                                                       *
*******************************************************************************/
VOID ClearBit(UINT16 *a_uiword,UINT16 a_uiposition)
{
    (*a_uiword)&=(~(0x0001<<a_uiposition));
}

/*******************************************************************************
*                                  SetBit                                      *
*                                  ======                                      *
* PURPOSE:   This funetion will set the bit in the a_uiword location,          *
* ARGUMENTS: a_uiword-> pointer to the data to set the bit                     *
*            a_uiposition-> position of the bit to be set                      *
* RETURN:  None                                                                *
* NOTES:                                                                       *
*******************************************************************************/
VOID SetBit(UINT16 *a_uiword,UINT16 a_uiposition)
{
    (*a_uiword)|=(0x0001<<a_uiposition);
}
