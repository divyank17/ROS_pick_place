/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcspaoslot.cpp                                              *
*    Description : Class clsTcSpAoSlot definition.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8  clsTcSpAoSlot::CheckPointVer1[] = {
    kSpAoPnChkPntVer,
    kSpAoPnPntType,  
    kSpAoPnOptDir,
    kSpAoPnOpChar,
    kSpAoPnOpIn1,
    kSpAoPnOpOut1,
    kSpAoPnOpIn2,
    kSpAoPnOpOut2,
    kSpAoPnOpIn3,
    kSpAoPnOpOut3,
    kSpAoPnOpIn4,
    kSpAoPnOpOut4,
    kSpAoPnModePerm,
    kSpAoPnNMode,
    kSpAoPnNModeAttr,
    kSpAoPnMode,
    kSpAoPnModeAttr,
    kSpAoPnFaultOpt,
    kSpAoPnFaultValue,
    kSpAoPnRedTag,
    kSpAoPnOpConn,
    kSpAoPnPtExecSt,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsTcSpAoSlot::CheckPointVerTable[] = {
    { CheckPointVer1, sizeof(CheckPointVer1) }
};

UINT8 clsTcSpAoSlot::SpAoSlotChkpntVersion = LATEST_SP_AO_SLTCHKPNT_VERSION;

const UINT8 clsTcSpAoSlot::RedParams[] = {
    kSpAoPnFaultValue,
    kSpAoPnFaultOpt,
    kSpAoPnRedTag,
    kSpAoPnPntType,
    kSpAoPnPtExecSt,
    kSpAoPnOptDir, 
    kSpAoPnOpIn0, 
    kSpAoPnOpIn1, 
    kSpAoPnOpIn2, 
    kSpAoPnOpIn3, 
    kSpAoPnOpIn4, 
    kSpAoPnOpOut0,
    kSpAoPnOpOut1,
    kSpAoPnOpOut2,
    kSpAoPnOpOut3,
    kSpAoPnOpOut4,
    kSpAoPnCHRC_S0,
    kSpAoPnCHRC_S1,
    kSpAoPnCHRC_S2,
    kSpAoPnCHRC_S3,
    kSpAoPnCHRC_S4,
    kSpAoPnOpChar,
    kSpAoPnNMode,
    kSpAoPnNModeAttr,
    kSpAoPnModePerm,
    kSpAoPnMode,
    kSpAoPnModeAttr,
    kSpAoPnOpConn,
    0 // Terminator
};

const SPAOSLOTPARAMINFO  clsTcSpAoSlot::tblParamInfo[] = { // Build paraminfo table
 //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed
//  FILL 0 index to 50th index///////////////////////////////////////////////////////////////////////////////////////////
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePntType,PostPntType,GetPntTypePtr,TRUE,     // 51 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PrePtExecSt,PostPtExecSt,GetPtExecStPtr,TRUE, // 52 PtExecSt
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLocalManPtr,FALSE,                     // 53 LocalMan 
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreModeAttr,0,GetModeAttrPtr,TRUE,            // 54 ModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreMode,PostMode,GetModePtr,TRUE,             // 55 Mode
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreModePerm,0,GetModePermPtr,TRUE,             // 56 ModePerm
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreNModeAttr,0,GetNModeAttrPtr,TRUE,          // 57 NModeArre
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreNMode,0,GetNModePtr,TRUE,                  // 58 NMode
    DT_FLOAT32,4,AT_BXREC,ALCK_OPER,CONTROLSTATE_ACTIVEANDRUN,PreOp,PostOp,GetOpPtr,FALSE,       // 59 Op
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,PostOpChar,GetOpCharPtr,TRUE,                // 60 OpChar
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpFinalPtr,FALSE,                   // 61 OpFinal
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpIn0Ptr,FALSE,                 // 62 OpIn0
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpIn1,0,GetOpIn1Ptr,TRUE,           // 63 OpIn1
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpIn2,0,GetOpIn2Ptr,TRUE,           // 64 OpIn2
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpIn3,0,GetOpIn3Ptr,TRUE,           // 65 OpIn3
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpIn4,0,GetOpIn4Ptr,TRUE,           // 66  OpIn4
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpIn5Ptr,FALSE,                 // 67 OpIn5
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpOut0Ptr,FALSE,                // 68 OpOut0
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpOut1,0,GetOpOut1Ptr,TRUE,         // 69 OpOut1
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpOut2,0,GetOpOut2Ptr,TRUE,         // 70 OpOut2
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpOut3,0,GetOpOut3Ptr,TRUE,         // 71 OpOut3
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,PreOpOut4,0,GetOpOut4Ptr,TRUE,         // 72 OpOut4
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpOut5Ptr,FALSE,                // 73 OpOut5
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,PreOptDir,PostOptDir,GetOptDirPtr,TRUE,    // 74 OptDir
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreRedTag,0,GetRedTagPtr,TRUE,                // 75 RedTag
    DT_BOOL,1,AT_BXPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetStdbyManPtr,FALSE,                    // 76 StdbyMan
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                   // 77
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                   // 78
    DT_BOOL,1,AT_BXPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetInitReqPtr,FALSE,                     // 79 InitReq
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreFaultOpt,PostFaultOpt,GetFaultOptPtr,TRUE,  // 80 FaultOpt
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreFaultValue,0,GetFaultValuePtr,TRUE,      // 81 FaultValue
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetFaultStatePtr,FALSE,                   // 82 FaultState
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_LInvPtr,FALSE,                   // 83 B0_LInv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_LInvPtr,FALSE,                   // 84 B1_LInv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpInternalPtr,FALSE,                // 85 OpInternal
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_LPtr,FALSE,                      // 86 B0_L
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_LPtr,FALSE,                      // 87 B1_L
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_OPtr,FALSE,                      // 88 B0_O
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_OPtr,FALSE,                      // 89 B1_O
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOutputDACImgPtr,FALSE,               // 90 OutDACImg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S0Ptr,FALSE,                   // 91 Chrc_S0
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S1Ptr,FALSE,                   // 92 Chrc_S1
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S2Ptr,FALSE,                   // 93 Chrc_S2 
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S3Ptr,FALSE,                   // 94 Chrc_S3
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S4Ptr,FALSE,                   // 95 Chrc_S4
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOTPT_UnusedPtr,FALSE,                  // 96 OTPT_Unused
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_InvPtr,FALSE,                    // 97 B0_Inv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_InvPtr,FALSE,                    // 98 B1_Inv
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                   // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                   // 100
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetOpConn,TRUE,                           // 101 OPCONNECTION
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                   // 102
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,                    // 103 SlotSfBt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfLrsPtr,FALSE,                   // 104 SlotSfLrs
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 113
    DT_BLIND,52,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,FALSE, // 114 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 116
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 142
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 150 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 243
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,// 244 SlotChkpntVersion
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 255
};

/*******************************************************************************
*                            clsTcSpAoSlot::clsTcSpAoSlot                      *
*                            ============================                      *
* PURPOSE   : Constructor of clsTcSpAoSlot Class. which initializes  class     *
*             members.                                                         *
* ARGUMENTS : a_ucSltNm - Slot Number                                          *
* RETURN    : NONE                                                             *
* NOTES:    :                                                                  *
*******************************************************************************/
clsTcSpAoSlot::clsTcSpAoSlot( UINT8 a_ucSltNm ) : clsOutSlot(PNTTYPE_NOTCONFIGURED, a_ucSltNm) {
    InitAoSlot(FALSE,TRUE);
}

/*******************************************************************************
*                           clsTcSpAoSlot::operator new                        *
*                           ===========================                        *
* PURPOSE  : Overrided new Operator to allocate memory to Slot                 *
* ARGUMENTS: a_ucSltNm - Slot Number                                           *
* RETURN   : returns slot memory pointer                                       *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsTcSpAoSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return (ucIomDbMemory + SPBOXSLOT_SIZE + (AI_MAXSLOTS * TCSPAISLOT_SIZE)+ 
              ((a_ucSltNm-AO_CH_START)* TCSPAOSLOT_SIZE));
}

/*******************************************************************************
*                            clsTcSpAoSlot::GetDataType                        *
*                            ==========================                        *
* PURPOSE  : This function returns data type of the parameter.                 *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : DataType of the parameter                                         *
* NOTES    :                                                                   *
*******************************************************************************/
DATATYPE clsTcSpAoSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsTcSpAoSlot::GetAccessType                        *
*                          ============================                        *
* PURPOSE  : This function returns accesstype of the parameter.                *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : AccessType of the parameter.                                      *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSTYPE clsTcSpAoSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                            clsTcSpAoSlot::GetParamSize                       *
*                            ===========================                       *
* PURPOSE  : This function returns size of the parameter                       *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsTcSpAoSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsTcSpAoSlot::GetParamPtr                        *
*                            ==========================                        *
* PURPOSE  : This function returns Pointer of the parameter                    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 *clsTcSpAoSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                           clsTcSpAoSlot::GetAccessLock                       *
*                           ============================                       *
* PURPOSE  : This function returns Access Lock of the parameter.               *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Access Lock of the parameter number.                              *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSLOCK clsTcSpAoSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                       clsTcSpAoSlot::GetIsDbChecksumed                       *
*                       ================================                       *
* PURPOSE  : This function returns whether parameter.is checkpointed or not    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : BOOL - TRUE if parameter is checkpoint paramter, else FALSE       *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsTcSpAoSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsTcSpAoSlot::VerifyControlState                    *
*                         =================================                    *
* PURPOSE  : This function checks the contorl state assigned to the parameter  *
*            to actual present control state of the channel and IOM module     *
*            itself,before the actual write to the parameter.                  *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    : This function decides whether the write can be done or not to the *
*            paramerter under current channel or IOM state.                    *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x924,tblParamInfo[a_ucParamNumber].ControlState);
        break;
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsTcSpAoSlot::ExecutePreFunction                    *
*                         =================================                    *
* PURPOSE  : This function invokes the pre-function for the given writable     *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber  - Parameter Number                               *
*            a_Buffer         - Pointer to the data                            *
*            a_ucAccessLevel  - Access level of the parameter                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) 
    {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsTcSpAoSlot::ExecutePostFunction                   *
*                         ==================================                   *
* PURPOSE  : This function invokes the post-function for the given writable    *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber - Parameter Number                                *
*            a_ucAccessLevel - Access level of the parameter                   *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsTcSpAoSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) 
{
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) 
    {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                           clsTcSpAoSlot::InitSlotDatabase                    *
*                           ===============================                    *
* PURPOSE  : Initialize the entire channel database. Calls the Init function   *
*            for each class in the channel object hierarchy and recompute      *
*            database checksum.                                                *
* ARGUMENTS: bFullInit - lag utilised when slots have to be reinitialized      *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsTcSpAoSlot::InitSlotDatabase(BOOL bFullInit) {
    BOOL bObjCreate = FALSE; 
    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitOutSlot(PntType, bFullInit, bObjCreate);
    InitAoSlot(bFullInit, bObjCreate);
    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                           clsTcSpAoSlot::InitTcAoSlot                        *
*                           ===========================                        *
* PURPOSE  : Initialization function for clsTcSpAoSlot data members.           *
* ARGUMENTS: bFullInit   - Flag utilised when slots have to be reinitialized   *
*            bObjCreate  - Flag utilised when slots have to be reinitialized   *
* RETURN   : NONE                                                              *
* NOTES    : This function is called when slot parameters                      *
*            need to be reinitialized                                          *
*******************************************************************************/
VOID clsTcSpAoSlot::InitAoSlot(BOOL bFullInit, BOOL bObjCreate) {
    // AO slot intialization
    OpConn      =  0;
    OpChar      =  FALSE;
    OpIn0       =  OP_LOLIMIT;
    OpIn1       =  NaN;
    OpIn2       =  NaN;
    OpIn3       =  NaN;
    OpIn4       =  NaN;
    OpIn5       =  OP_HILIMIT;
    OpOut0      =  OP_LOLIMIT;
    OpOut1      =  NaN;
    OpOut2      =  NaN;
    OpOut3      =  NaN;
    OpOut4      =  NaN;
    OpOut5      =  OP_HILIMIT;
    Mode        =  MODE_CASCADE;
    AoInitReq   = 0; 

    //variable created to skip the readback cycle
    ucSkipLpBkTst = 0;
    bReadBackrequired = TRUE;
    OTPT_Unused =  TRUE;
    bOpenLoopbackMuxSF=FALSE;

    if (TRUE == bObjCreate) {

        B0_L      =  NaN;
        B1_L      =  NaN;
        B0_O      =  NaN;
        B1_O      =  NaN;

         //In the linear equation 
        // y = mx+c //y = intercept ;m = slope ;c=offset constant 
        //To update these constants at the initialization
        //from the calibration constants 
        B0_Inv= (FLOAT32)(-10);
        B1_Inv= (FLOAT32)0.2;

        B1_LInv = DEFAULT_LOOPBACK_SLOPE;
        B1_Inv  = DEFAULT_OUTPUT_SLOPE;
        B0_Inv  = DEFAULT_OUTPUT_OFFSET;

        OutDACImg = 0;
        DacData.DAC.Commmand = LD_INPUT_AND_DAC_REG;
        DacData.DAC.SubBit   = 0;
        DacData.DAC.Count    = 0;
        LoopBackDACImg = 0;
        LoopBackStatus = AOLPBK_PASSED;
        ucPassCount = PASSCOUNTMIN;

        Chrc_S0   =  NaN;
        Chrc_S1   =  NaN;
        Chrc_S2   =  NaN;
        Chrc_S3   =  NaN;
        Chrc_S4   =  NaN;
        OpFinal   =  OP_LOLIMIT;
        OpInternl =  OP_LOLIMIT;        
    }
    
    OpLoLimitVal =  OP_LOLIMIT;
    OpHiLimitVal =  OP_HILIMIT;    
    
    if (TRUE == bFullInit) {
        BOOL bInitReq = TRUE;
        BOX->SetOp(ChanNum, OP_LOLIMIT);
        BOX->SetInitReq(ChanNum,bInitReq);
    }

}

/*******************************************************************************
*                            clsTcSpAoSlot::PrePntType                         *
*                            =========================                         *
* PURPOSE: Pre Receiver-Beware function for PntType parameter.                 *
*          Validates some pre conditions before the new PntType parameter      *
*          can be written to database.                                         *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesfull                     *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    ScratchPad = PntType; // Save old point type for post function.
    UINT8 MdSts = BOX->GetModuleStatus();

    if ((a_ucAccLvl == ALVL_IUSER) && (MdSts != MODSTATUS_IDLE)) {
        return DO_STATE_MUST_BE_IDLE;
    }

    if ((MdSts != MODSTATUS_IDLE) && (PtExecSt != PTEXECST_INACTIVE)) {
        return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
    }

    if (RedTag == REDTAG_ON) {
        return DO_POINT_IS_RED_TAGGED;
    }

    if (PNTTYPE_SP != *(PNTTYPE *)a_Writebuffer) {
        if (PNTTYPE_NOTCONFIGURED != *(PNTTYPE *)a_Writebuffer) {
            return DO_ILLEGAL_VALUE;
        }
    }
    else {
        if (a_ucAccLvl != ALVL_IUSER) {
            OTPT_Unused = FALSE; 
        }
    }

    return PA_OK;
}

/*******************************************************************************
*                            clsTcSpAoSlot::PostPntType                        *
*                            ==========================                        *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
*           Initializes the slot parameters                    .               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:                                                                      *
*           PA_OK           -   If routine executes successfully               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::PostPntType(UINT8) {

    if (PNTTYPE_NOTCONFIGURED == PntType) {
        InitSlotDatabase(TRUE);
    }
    else { 
        // Call Point-Build initialization.
        InitSlotDatabase(FALSE);
    }
}

/*******************************************************************************
*                          clsTcSpAoSlot::PrePtExecSt                          *
*                          ==========================                          *
* PURPOSE:  Pre Receiver-Beware function for OptType parameter.                *
*           This method checks for range of the data, access level, and valid  *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the OptType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PrePtExecSt(UINT8 *a_Writebuffer, UINT8) 
{
    const UINT8 CHRC_PARM_COUNT = 5;
    UINT8 ucIndex = 0;
    PASTATUS status = PA_OK;
    FLOAT32 *pChrcParm = NULL;

    if (*(PTEXECST *)a_Writebuffer > PTEXECST_ACTIVE) {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    //If the point execution state is active and output characterization is enabled 
    //validate the input and output characterization point
    if ((*(PTEXECST *)a_Writebuffer == PTEXECST_ACTIVE) && (TRUE == OpChar)) {
        pChrcParm = &(this->OpIn1);
        for (ucIndex=1;ucIndex < CHRC_PARM_COUNT;ucIndex++) {
            if (isnan(*pChrcParm++)) {
                status = DO_CONFIGURATION_MISMATCH_ERROR;
            }
        }
         
        pChrcParm = &(this->OpOut1);
        for (ucIndex=1;ucIndex < CHRC_PARM_COUNT;ucIndex++) {
            if (isnan(*pChrcParm++)) {
                status = DO_CONFIGURATION_MISMATCH_ERROR;
            }
        }
    }
    if (status != PA_OK) {
        return status;
    }

    return PA_OK;
}

/*******************************************************************************
*                            clsTcSpAoSlot::PostPtExecSt                       *
*                            ===========================                       *
* PURPOSE:  Post Receiver-Beware function for PtExecSt parameter.              *
* ARGUMENTS                                                                    *
*           a_ucAccLvl      -   Access level for check                         *
*:                                                                             *
* RETURN:                                                                      *
*           PA_OK           -   On Successful execution                        *
* NOTES:                                                                       *
*           Need to Add additional functionality later                         *
*******************************************************************************/
VOID clsTcSpAoSlot::PostPtExecSt(UINT8) {

    UINT8 MdSts = BOX->GetModuleStatus();
    //Perform back initialization 
    if ((PtExecSt == PTEXECST_ACTIVE) && (MdSts == MODSTATUS_RUN))
    {
        if (TRUE == OpChar)
        {
            //compute characterization slopes
            Chrc_S0 = (OpOut1 - OpOut0) / (OpIn1 - OpIn0);
            Chrc_S1 = (OpOut2 - OpOut1) / (OpIn2 - OpIn1);
            Chrc_S2 = (OpOut3 - OpOut2) / (OpIn3 - OpIn2);
            Chrc_S3 = (OpOut4 - OpOut3) / (OpIn4 - OpIn3);
            Chrc_S4 = (OpOut5 - OpOut4) / (OpIn5 - OpIn4);
        }
        /*
        Steps to Perform:
        ----------------
        1. Get the DAC Count value stored in the Database parameter 
        2. Convert the DAC Count to Float Value 
        3. Check if the Converted Float value needs zero clamping and clamp the 
         Op_Final value to -6.9
        */
        //Populate the database with output values after reading across channels
        BackInit();
    }
    CmptInitReq();

}

/*******************************************************************************
*                               clsTcSpAoSlot::PreMode                         *
*                               ======================                         *
* PURPOSE:    Pre Receiver-Beware function for Mode parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of Mode                                *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK           -   On successful execution                       *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreMode(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    BOOL ReqstdNrml = FALSE;

    if ((a_ucAccLvl == ALVL_OPER) && (ModePerm != MODEPERM_PERMIT)) {
        return DO_CHANGE_NOT_PERMITTED_BY_OPERATOR;
    }

    if (REDTAG_ON == RedTag) {
        return DO_POINT_IS_RED_TAGGED;
    }

    if ((a_ucAccLvl == ALVL_PROG) && (ModeAttr != MODEATTR_PROGRAM)) {
        //Program changing the value
        return DO_INVALID_MODE_ATTRIBUTE;
    }

    if ((MODE_MANUAL  != (*(MODE *)a_Writebuffer)) &&
        (MODE_CASCADE != (*(MODE *)a_Writebuffer)) &&
        (MODE_NORMAL  != (*(MODE *)a_Writebuffer)))
    {
      return DO_ILLEGAL_VALUE;
    }

    if (((*(MODE *)a_Writebuffer) == MODE_NORMAL) && (NMode == MODE_NONE)) {
        return DO_NORMAL_MODE_IS_NOT_CONFIGURED;
    }

    if ((*(MODE *)a_Writebuffer) == MODE_NORMAL) {
        ReqstdNrml = TRUE;
        *(MODE *)a_Writebuffer = (MODE)NMode;
    }

    if (ReqstdNrml && (NModeAttr != MODEATTR_NONE))
    {
        ModeAttr = (MODEATTR)NModeAttr;
    }
    else if (a_ucAccLvl & ALCK_ONPROC) {
        ModeAttr = MODEATTR_OPERATOR;
    }

    return PA_OK;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PostMode                        *
*                               =======================                        *
* PURPOSE:    Post Receiver-Beware function for Mode parameter.                *
* ARGUMENTS:                                                                   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK           -   On successful execution                       *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::PostMode(UINT8) {
    CmptInitReq();
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreModePerm                     *
*                               ==========================                     *
* PURPOSE:    Pre Receiver-Beware function for ModePerm parameter.             *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the ModePerm                        *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreModePerm(UINT8 * a_Writebuffer, UINT8) {
    MODEPERM NewVal = *(MODEPERM *)a_Writebuffer;

    if (NewVal > MODEPERM_PERMIT) {
       return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    return PA_OK;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreNMode                        *
*                               =======================                        *
* PURPOSE:    Pre Receiver-Beware function for NMode parameter.                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the NMode parameter                 *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreNMode(UINT8 * a_Writebuffer, UINT8) {
   MODE NewVal = *(MODE *)a_Writebuffer;

   if (NewVal > MODE_CASCADE) {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
   }

   if (MODE_NONE == NewVal) {
       NModeAttr = MODEATTR_NONE;
   }

   return PA_OK;

}

/*******************************************************************************
*                               clsTcSpAoSlot::PreNModAttr                     *
*                               ==========================                     *
* PURPOSE:   Pre Receiver-Beware function for NModeAttr parameter.             *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the NModeAttr                       *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreNModeAttr(UINT8 * a_Writebuffer, UINT8) {
    MODEATTR NewVal = *(MODEATTR *)a_Writebuffer;

    if (NewVal > MODEATTR_NORMAL) {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    if (NewVal == MODEATTR_NORMAL) {
        return DO_ILLEGAL_VALUE;
    }

    if ((NMode == MODE_NONE) && (NewVal != NModeAttr)) {
        return DO_NORMAL_MODE_IS_NOT_CONFIGURED;
    }

    return PA_OK;

}

/*******************************************************************************
*                               clsTcSpAoSlot::PreModeAttr                     *
*                               ==========================                     *
* PURPOSE:    Pre Receiver-Beware function for ModeAttr parameter.             *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the ModeAttr                        *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreModeAttr(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    MODEATTR NewVal = *(MODEATTR *)a_Writebuffer;

    if (REDTAG_ON == RedTag) {
        return DO_POINT_IS_RED_TAGGED;
    }

    if ((a_ucAccLvl == ALVL_OPER) && (ModePerm != MODEPERM_PERMIT)) {
        return DO_CHANGE_NOT_PERMITTED_BY_OPERATOR;
    }

    if (NewVal == MODEATTR_NONE) {
        return DO_ILLEGAL_VALUE;
    }

    if ((NewVal < MODEATTR_OPERATOR) || (NewVal > MODEATTR_NORMAL)) {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    if (NewVal == MODEATTR_NORMAL) {
        if (NModeAttr == MODEATTR_NONE) {
            return DO_NORMAL_ATTRIBUTE_NOT_CONFIGURED;
        }
        else {
            *(MODEATTR *)a_Writebuffer = (MODEATTR)NModeAttr;
        }
    }
    else 
    {
        if ((a_ucAccLvl == ALVL_PROG) && (NModeAttr != MODEATTR_NONE)) {
            NModeAttr = NewVal;
        }
    }

    return PA_OK;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreRedTag                       *
*                               ========================                       *
* PURPOSE:   Pre Receiver-Beware function for RedTag parameter                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the RedTag                          *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -  On successful execution                          *
* NOTES:                                                                       *
* Currently not used,in case FULL Point Support is added in future include     *
* this routine after additions to FULL point mode handling                     *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreRedTag(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
   REDTAG NewVal = *(REDTAG *) a_Writebuffer;
   if (ALVL_IUSER == a_ucAccLvl) {
        return PA_OK;
   }

    if (NewVal == REDTAG_ON) {
        if (a_ucAccLvl & ALCK_ONPROC) {
            if (MODE_MANUAL != Mode) {
                return DO_MODE_MUST_BE_MANUAL;
            }
            if (MODEATTR_OPERATOR != ModeAttr) {
                return DO_INVALID_MODE_ATTRIBUTE;
            }
        }
        else if ((ALVL_UMCC == a_ucAccLvl) || (ALVL_CC == a_ucAccLvl))
        {
            if (MODE_CASCADE != Mode) {
                return DO_INVALID_MODE;
            }
        }
        else {
            return DO_ACCESS_LEVEL_INVALID;
        }
    }
    if ((NewVal < REDTAG_OFF) 
        || (NewVal > REDTAG_ON)) {
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;

}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOp                           *
*                               ====================                           *
* PURPOSE: Pre Receiver-Beware function for Op parameter.                      *
*          Validates some pre conditions before the new Op parameter           *
*          is written to database.                                             *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           status          -  Returns PA_OK On Successful execution           *
* NOTES:                                                                       *
*           Need to Add some additional functionality later                    *
*                                                                              *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOp(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) {
    PASTATUS status = PA_OK;
    UINT8 ucRange_status = WITHIN_RANGE;
    FLOAT32  OpVal = *(FLOAT32 *) a_Writebuffer;
    
    //Check if any slot failure bit is active
    if((SlotSfBt!=0) && (!((Mode==MODE_MANUAL)&&(ModeAttr==MODEATTR_OPERATOR)))) {
        status = DO_INITIALIZATION_ERROR;
        return status;
    }
    if (isnan(OpVal)) {
        status = DO_ILLEGAL_VALUE;
    }

    //Apply range check 
    if (OpVal > OP_HILIMIT) {
        ucRange_status = OVER_RANGE;
    }
    else if (OpVal < OP_LOLIMIT) {
        ucRange_status = UNDER_RANGE;
    }

    if(a_ucAccLvl & ALCK_ONPROC_IUSER) {
        if (ucRange_status != WITHIN_RANGE) {
            status = DO_ILLEGAL_VALUE;
        }
    }

    if ((Iol.AmPrimary() == FALSE) && (BOX->GetRedState() >= REDSTATE_SYNCD)) { 
        // if the module is secondary and synced with the primary
        if ((MODE_CASCADE != Mode) && (BOX->IsPrimaryChannelInFail(ChanNum) == TRUE)) {   
            // Reject the write if mode is not cascade and primary channel in softfail
            TraceLog.AddToTrace(TRACEID_GENERIC,bcPriChanInFail,ChanNum); 
            return DO_INITIALIZATION_ERROR;
        }
    }

    if (RedTag) 
    {
        status = DO_POINT_IS_RED_TAGGED;   
    }
    else { 
        if (LocalMan)
        {
            status = DO_INITIALIZATION_ERROR;
        }
        else {
            switch (Mode) {
                case MODE_MANUAL:
                    switch (ModeAttr) {
                        case MODEATTR_OPERATOR:
                            //if ENGR or SUPERV or OPER (HumanLock)
                            if (a_ucAccLvl & ALCK_ONPROC) {
                                if(ucRange_status != WITHIN_RANGE)
                                    status = DO_LIMIT_OR_RANGE_EXCEEDED;
                            }
                            else if (ALVL_IUSER == a_ucAccLvl) {
                                status = ClampWithWarning(a_Writebuffer, ucRange_status);
                            }
                            else { 
                                status = DO_ACCESS_LEVEL_INVALID;
                            }
                            break;
                        case MODEATTR_PROGRAM:
                            if (ALVL_PROG == a_ucAccLvl) {
                                status = ClampWithWarning(a_Writebuffer, ucRange_status);
                            }
                            else {
                                status = DO_ACCESS_LEVEL_INVALID;
                            }
                            break;
                        default:
                            status = DO_INVALID_MODE_ATTRIBUTE;
                        }
                    break;
                case MODE_CASCADE:
                    if ((ALVL_UMCC != a_ucAccLvl) && (ALVL_CC != a_ucAccLvl)) {
                            status = DO_ACCESS_LEVEL_INVALID;
                    }
                    else {
                        status = ClampWithWarning(a_Writebuffer, ucRange_status);
                    }
                    break;
                default:
                    status = DO_INVALID_MODE;
             }
        }//Else loop =>LocalMan not set
    }//Else loop =>Point is not Red Tagged
    return status;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PostOp                          *
*                               =====================                          *
* PURPOSE:  Post Receiver-Beware function for Op parameter.                    *
*           Process the Op Parameter and updates the Final Output              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   On successful execution                        *
* NOTES:                                                                       *
*           To Add additional functionality                                    *
*******************************************************************************/
VOID clsTcSpAoSlot::PostOp(UINT8) {
    FLOAT32 OpVal = BOX->GetOp();  
    //The Current output channel is in use so can run some diagnostics
    OTPT_Unused = FALSE;
    //Save OP_REAL to OP_INTERNAL to compute SYNC_VER.The OPInternal parameter
    //will not be updated for period b/w dump complete and sync complete 
    if(FALSE == BOX->GetbDisOpInternlUpdteSts()) 
    {
        OpInternl = OpVal;
    }
    UpdateOpFinal(OpVal);
    
    BOX->SpOutPutScanRec.AoOp = OpVal;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PostOpChar                      *
*                               =========================                      *
* PURPOSE:    Post Receiver-Beware function for Opchar parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   On successful execution                        *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::PostOpChar(UINT8) {
//If characterization is not enabled,assign initial values to characterization
// points
    if (FALSE  == OpChar) {
        OpIn0 = OP_LOLIMIT;
        OpIn1 = NaN;
        OpIn2 = NaN;
        OpIn3 = NaN;
        OpIn4 = NaN;
        OpIn5 = OP_HILIMIT;
        OpOut0   = OP_LOLIMIT;
        OpOut1   = NaN;
        OpOut2   = NaN;
        OpOut3   = NaN;
        OpOut4   = NaN;
        OpOut5   = OP_HILIMIT;
    }
}

/*******************************************************************************
*                               clsTcSpAoSlot::ChrcFrwrd                       *
*                               ========================                       *
* PURPOSE: This function returns the characterized value of Op based           *
*          on the characterization table                                       *
* ARGUMENTS:                                                                   *
*              OpVal - Output value read across the  channel                   *
* RETURN:                                                                      *
*             Returns a float value                                            *
* NOTES:                                                                       *
*          This function is called from postOp method.                         *
*******************************************************************************/
FLOAT32 clsTcSpAoSlot::ChrcFrwrd(FLOAT32 OpVal) {
    FLOAT32 OpIn, OpOut, Slope;
    if (OpVal == OpIn0) {
        return OpOut0;
    }

    if (OpVal <= OpIn1) {
        OpIn  = OpIn0;
        OpOut = OpOut0;
        Slope = Chrc_S0;
    }
    else if (OpVal <= OpIn2) {
        OpIn  = OpIn1;
        OpOut = OpOut1;
        Slope = Chrc_S1;
    }
    else if (OpVal <= OpIn3) {
        OpIn  = OpIn2;
        OpOut = OpOut2;
        Slope = Chrc_S2;
    }
    else if (OpVal <= OpIn4) {
        OpIn  = OpIn3;
        OpOut = OpOut3;
        Slope = Chrc_S3;
    }
    else if (OpVal <= OpIn5) {
        OpIn  = OpIn4;
        OpOut = OpOut4;
        Slope = Chrc_S4;
    }
    return (OpVal - OpIn) * Slope + OpOut;
}

/*******************************************************************************
*                               clsTcSpAoSlot::ChrcPntBnds                     *
*                               ==========================                     *
* PURPOSE: Checks the values of the charcterization points to be within range  *
                                                                               *
* ARGUMENTS:                                                                   *
*             *ufDataPtr    -  Current value of the characterization point     *
*             NewVal        -  New value of the characterization point         *
*             a_ucAccLvl    -  Access level for check                          *
* RETURN:                                                                      *
*           PA_OK           -   On successful execution                        *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::ChrcPntBnds(FLOAT32 *ufDataPtr, FLOAT32 NewVal, UINT8 a_ucAccLvl) {
    if(ufDataPtr == NULL) return DO_ILLEGAL_VALUE;
    FLOAT32 OldVal = *ufDataPtr;
    if ((a_ucAccLvl == ALVL_IUSER) && RealCompare(NewVal,OldVal)) {
        return PA_OK;
    }
    else {
        if (FALSE == OpChar) {
            return DO_PARAMETER_INVALID;
        }

        if (isnan(NewVal))  {
            return DO_ILLEGAL_VALUE;
        }

        if ((NewVal < OpLoLimitVal) || (NewVal > OpHiLimitVal)) {
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
        ufDataPtr--;
        if ((! isnan(*ufDataPtr)) && (NewVal < *ufDataPtr)) {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }

        ufDataPtr++; ufDataPtr++;
        if ((! isnan(*ufDataPtr)) && (NewVal > *ufDataPtr)) {
            return DO_CONFIGURATION_MISMATCH_ERROR;
        }
    }
    return PA_OK;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpIn1                        *
*                               =======================                        *
* PURPOSE:   Pre Receiver-Beware function for OpIn1 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn1    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
             Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpIn1(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;

    PASTATUS status = ChrcPntBnds(&OpIn1, NewVal, a_ucAccLvl);   

    return status;

}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpIn2                        *
*                               =======================                        *
* PURPOSE:   Pre Receiver-Beware function for OpIn2 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn2    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpIn2(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    PASTATUS status = ChrcPntBnds(&OpIn2, NewVal, a_ucAccLvl);

    return status;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpIn3                        *
*                               =======================                        *
* PURPOSE:   Pre Receiver-Beware function for OpIn3 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn3    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpIn3(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    
    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    PASTATUS status =  ChrcPntBnds(&OpIn3, NewVal, a_ucAccLvl);

    return status;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpIn4                        *
*                               =======================                        *
* PURPOSE:   Pre Receiver-Beware function for OpIn4 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn4    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpIn4(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    PASTATUS status =  ChrcPntBnds(&OpIn4, NewVal, a_ucAccLvl);

    return status;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpOut1                       *
*                               ========================                       *
* PURPOSE:    Pre Receiver-Beware function for OpOut1 parameter.               *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut1   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpOut1(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    PASTATUS status = ChrcPntBnds(&OpOut1, NewVal, a_ucAccLvl);
    return status;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpOut2                       *
*                               ========================                       *
* PURPOSE:   Pre Receiver-Beware function for OpOut2 parameter.                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut2   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpOut2(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    PASTATUS status =  ChrcPntBnds(&OpOut2, NewVal, a_ucAccLvl);
    return status;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpOut3                       *
*                               ========================                       *
* PURPOSE:    Pre Receiver-Beware function for OpOut3 parameter.               *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut3   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpOut3(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    PASTATUS status = ChrcPntBnds(&OpOut3, NewVal, a_ucAccLvl);
    return status;
}

/*******************************************************************************
*                               clsTcSpAoSlot::PreOpOut4                       *
*                               ========================                       *
* PURPOSE:   Pre Receiver-Beware function for OpOut4 parameter.                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut4   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOpOut4(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    FLOAT32 NewVal = *(FLOAT32*)a_Writebuffer;
    PASTATUS status = ChrcPntBnds(&OpOut4, NewVal, a_ucAccLvl);
    return status;
}

/*******************************************************************************
*                           clsTcSpAoSlot::PreOptDir                           *
*                           ========================                           *
* PURPOSE:  Pre Receiver-Beware function for OPTDIR parameter.                 *
*           This method checks for range of the data that can be written to    *
*           OptDir parameter.                                                  *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the FaultState parameter       *
* RETURN:                                                                      *
*           PA_OK           -   If check is successfull                        *
* NOTES:    This method enables to write either DIRECT or REVERSE values only  * 
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreOptDir(UINT8 *a_Writebuffer, UINT8)
{
    OPTDIR eOptDir =  (*(OPTDIR *)a_Writebuffer);

    //Validate the fault option set by the user 
    if (eOptDir != OPTDIR_DIRECT && eOptDir != OPTDIR_REVERSE ) {
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;

}

/*******************************************************************************
*                          clsTcSpAoSlot::PostFaultOpt                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::PostOptDir(UINT8) {   
}

/*******************************************************************************
*                           clsTcSpAoSlot::PreFaultOpt                         *
*                           ==========================                         *
* PURPOSE:  Pre Receiver-Beware function for FaultOpt parameter.               *
*           This method checks for range of the data that can be written to    *
*           FaultOpt parameter.                                                *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the FaultState parameter       *
* RETURN:                                                                      *
*           PA_OK           -   If check is successfull                        *
* NOTES:    This method enables to write either HOLD,UNPOWER,FAULTVALUE        * 
*           values only                                                        *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreFaultOpt(UINT8 *a_Writebuffer, UINT8) {
    FAULTOPT eFaultOpt =  (*(FAULTOPT *)a_Writebuffer);

    //Validate the fault option set by the user 
    if ((eFaultOpt != FAULTOPT_HOLD) &&
        (eFaultOpt != FAULTOPT_UNPOWERED) &&
        (eFaultOpt != FAULTOPT_FAULTVALUE)) {
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;
}

/*******************************************************************************
*                          clsTcSpAoSlot::PostFaultOpt                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::PostFaultOpt(UINT8) {
    if (FAULTOPT_FAULTVALUE != FaultOpt) {
        FaultValue = OP_LOLIMIT;
    }
}

/*******************************************************************************
*                        clsTcSpAoSlot::PreFaultValue                          *
*                        ============================                          *
* PURPOSE:  Pre Receiver-Beware function for FaultOpt parameter.               *
*           This method checks for range of the data that can be written to    *
*           FaultOpt parameter.                                                *
*                                                                              *
* ARGUMENTS:a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the FaultValue parameter       *
* RETURN:   PA_OK           -   If check is successfull                        *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::PreFaultValue(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {

   // Get the value of FaultValue in local variable
    FLOAT32 NewVal = *(FLOAT32 *)a_Writebuffer;
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(FLOAT32 *)a_Writebuffer) == FaultValue)) {
        return PA_OK;
    }

    if (FAULTOPT_FAULTVALUE != FaultOpt) {
        return DO_PARAMETER_INVALID;
    }
 
    if (isnan(NewVal)) {
        return DO_ILLEGAL_VALUE;
    }

    if ((NewVal > OpHiLimitVal) || (NewVal < OpLoLimitVal)) {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }
 
    return PA_OK;

}

/*******************************************************************************
*                               clsTcSpAoSlot::BackInit                        *
*                               =======================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::BackInit()
{
    FLOAT32 fBackInitOp;

    if (OutDACImg <= MINCURRENT_OUTPUT_DACCOUNT) {
        fBackInitOp = OP_LOLIMIT;
    }
    else {
        fBackInitOp = ((FLOAT32)OutDACImg - B0_Inv) / B1_Inv;
    }
    
    if (fBackInitOp <= OP_LOLIMIT) {
        OpFinal = OP_LOLIMIT;
    }
    else if (fBackInitOp >= OP_HILIMIT) {
        OpFinal = OP_HILIMIT;
    }
    else {
        OpFinal = fBackInitOp;
    }

    if (TRUE == OpChar) { 
        fBackInitOp = ChrcBkwrd(fBackInitOp);
    }

    if (OPTDIR_REVERSE == OptDir) {
        fBackInitOp = ((FLOAT32) 100.0) - fBackInitOp;
    }
    
    BOX->SetOp(ChanNum,fBackInitOp,FALSE);

}

/*******************************************************************************
*                               clsTcSpAoSlot::ChrcBkwrd                       *
*                               ========================                       *
* PURPOSE:   This function returns the original value of Op based on the       *
*             characterization table from the output value                     *
* ARGUMENTS:                                                                   *
*              OpVal - Output value read across the  channel                   *
* RETURN:                                                                      *
*             Returns a float value                                            *
* NOTES                                                                        *
*              This function is used by BackInit to calculate original         *
*              uncharacterized Op from the output value read across IOM channel*
*******************************************************************************/
FLOAT32 clsTcSpAoSlot::ChrcBkwrd(FLOAT32 OpVal) {
    FLOAT32 OpIn, OpOut, Slope;
    if (OpVal == OpOut0) {
        return OpIn0;
    }

    if (OpVal <= OpOut1) {
        OpIn  = OpIn0;
        OpOut = OpOut0;
        Slope = Chrc_S0;
    }
    else if (OpVal <= OpOut2) {
        OpIn  = OpIn1;
        OpOut = OpOut1;
        Slope = Chrc_S1;
    }
    else if (OpVal <= OpOut3) {
        OpIn  = OpIn2;
        OpOut = OpOut2;
        Slope = Chrc_S2;
    }
    else if (OpVal <= OpOut4) {
        OpIn  = OpIn3;
        OpOut = OpOut3;
        Slope = Chrc_S3;
    }
    else if (OpVal <= OpOut5) {
        OpIn  = OpIn4;
        OpOut = OpOut4;
        Slope = Chrc_S4;
    }
    return (OpVal - OpOut) / Slope + OpIn;
}

/*******************************************************************************
*                          clsTcSpAoSlot::InactivateSlot                       *
*                          =============================                       *
* PURPOSE: This funcitions is invoked when channel is inactive, which          *
*          initialize process data to default value                            *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::InactivateSlot(VOID) 
{
    PostPtExecSt(0);
}

/*******************************************************************************
*                          clsTcSpAoSlot::StoreInternalOp                      *
*                          ==============================                      *
* PURPOSE: This funcitions is invoked when AO channel is connected to internal *
*          channel. Get the value from internal channel and drives to field    *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::StoreInternalOp()
{
    UINT32 OpConnection = (UINT32)OpConn;

    UINT8 SlotNo   = OpConnection & 0x00FF;
    UINT8 ParamNum = (OpConnection & 0xFF00) >> 8;
    
    //for AI Channel, Speed Channel PV and Voting Block VOTPV1 and VOTPV2
    //calculate the PV's values map to range of 0 to 100%
    if(SlotNo >= AI_CH_START && SlotNo <= AI_CH_END)
    {
        //If AI Channel PV, then get the pv value using PVP parameter which is map to range of 0 to 100%
        if(ParamNum == kSpAiPnPv) {
           ParamNum = kSpAiPnPvP;
        }
    }
    else if(SlotNo >= SP_CH_START && SlotNo <= SP_CH_END)
    {
        //If Speed Channel PV, then get the pv value using PV100 parameter which is map to range of 0 to 100%
        if(ParamNum == kSpSpdPnPv) {
            ParamNum = kSpSpdPnPv100;
        }
    }
    else if(SlotNo >= VOTLOGIC_BLOCK_START)
    {   
        //If Voting Block VOTPV1 and VOTPV2, then get the pv value using correspoinding VOTPV1100 and VOTPV2100 parameter 
        //which is map to range of 0 to 100%
        if(ParamNum == kSpSpdVotPnVotPv1) {
            ParamNum = kSpSpdVotPnVotPv1P;
        }
        else if(ParamNum == kSpSpdVotPnVotPv2) {
            ParamNum = kSpSpdVotPnVotPv2P;
        }
    }

    FLOAT32 OpVal = 0;
    UINT8 *a_ReadBuffer = (UINT8 *)&OpVal;
    UINT8 *pSource = SLOT(SlotNo)->GetParameterPtr(ParamNum);
    for (UINT8 ucSize = sizeof(FLOAT32); ucSize > 0; ucSize--) 
    {
       *a_ReadBuffer++ = *pSource++;
    }
    
    //AI PV, Speed PV and Voting Block PV is NaN
    //Clamp to OP low limit
    if(isnan(OpVal)) {
        OpVal = OP_LOLIMIT;
    }

    BOOL bInitReq = BOX->GetInitReq(ChanNum);  

    PASTATUS status = PreOp((UINT8*)&OpVal, ALVL_UMCC);
    if((status == PA_OK) && (bInitReq == FALSE))
    {
        FLOAT32 PrevOutDACImg = OutDACImg;
        UINT8  ucPrevSkipLpBkTst = ucSkipLpBkTst;

        BOX->SetOp(ChanNum,OpVal,FALSE);

        PostOp(ALVL_UMCC);

        // Compute loopback test time.
        FLOAT32 NewOutDACImg = (PrevOutDACImg > OutDACImg) ? (PrevOutDACImg - OutDACImg)
                                                           : (OutDACImg - PrevOutDACImg);

        if(NewOutDACImg < BOX->GetDac4PercentofFullScale() && ucPrevSkipLpBkTst == 0) {
            bReadBackrequired = TRUE;
        }
    }
}

/*******************************************************************************
*                               clsTcSpAoSlot::CmptInitReq                     *
*                               =======================                        *
* PURPOSE:   Computes the value of InitReq and RInitReq                        *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::CmptInitReq(VOID) {
    BOOL bInitReq = FALSE;
    bInitReq = ((PtExecSt == PTEXECST_INACTIVE) ||
                (BOX->GetModuleStatus() != MODSTATUS_RUN) || 
                (SlotSfBt) || 
                (MODE_CASCADE != Mode) ||
                (FAULTSTATE_FAULTED == FaultState));

    BOX->SetInitReq(ChanNum, bInitReq);  
}

/*******************************************************************************
*                               clsTcSpAoSlot::ClampWithWarning                *
*                               ===============================                *
* PURPOSE:   Checks the Range of the Output parameter to be within range and   *
*            clamps to the lower and upper limit if boundary is crossed        *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  Output value                                     *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::ClampWithWarning(VOID *a_Writebuffer,UINT8 ucRange_status) {
    switch (ucRange_status) {
    case UNDER_RANGE:
        *(FLOAT32 *) a_Writebuffer = OpLoLimitVal;
        return DO_VALUE_CLAMPED_ERROR;
    case OVER_RANGE:
        *(FLOAT32 *) a_Writebuffer =  OpHiLimitVal;
        return DO_VALUE_CLAMPED_ERROR;
    default:
        return PA_OK;
    }
}

/*******************************************************************************
*                             clsTcSpAoSlot::GetOpPtr                          *
*                             =======================                          *
* PURPOSE  : This function returns OP Parameter Pointer                        *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsTcSpAoSlot::GetOpPtr(VOID) { 
    return &(BOX->SpOutPutScanRec.AoOp);
}
/*******************************************************************************
*                             clsTcSpAoSlot::GetInitReqPtr                     *
*                             ============================                     *
* PURPOSE  : This function returns InitReq Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsTcSpAoSlot::GetInitReqPtr(VOID) { 
    //Value red from ScanRec
    AoInitReq = (BOX->SpOutPutScanRec.InitReq >> 4);
    return &AoInitReq;
}

/*******************************************************************************
*                        clsTcSpAoSlot::UpdateOpFinal                          *
*                        ============================                          *
* PURPOSE:  This method will calculate the OutDac value suing OP               *
* ARGUMENTS:a_fOp - Output Value                                               *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::UpdateOpFinal(FLOAT32 a_fOp) 
{

    if(FAULTSTATE_FAULTED != FaultState){
        if (OPTDIR_REVERSE == OptDir) { a_fOp = (FLOAT32)100.0 - a_fOp;
        }

        if (TRUE == OpChar) {
            a_fOp =  ChrcFrwrd(a_fOp);
        }
    }
    // Save the current OutDACImg for computing loopback test time.
    UINT16 uiLastOutDACImg = OutDACImg;

    if (a_fOp <= OP_LOLIMIT) {
        OpFinal = OP_LOLIMIT;
        OutDACImg = 0;
        LoopBackDACImg = 0;
    }
    else {
        OpFinal   = (a_fOp >= OP_HILIMIT) ? OP_HILIMIT : a_fOp;
        OutDACImg = (B1_Inv * OpFinal) + B0_Inv;
        LoopBackDACImg =  (B1_LInv * OpFinal) + B0_LInv;
    }
    // Compute loopback test time.
    uiLastOutDACImg = (uiLastOutDACImg > OutDACImg) ? (uiLastOutDACImg - OutDACImg)
                                                    : (OutDACImg - uiLastOutDACImg);
    //If the differance b/w subsequent op's was more 
    //than 50% skip donot readback for 2 cycles 
    if(uiLastOutDACImg > BOX->GetDac50Percent()){
        ucSkipLpBkTst = 3;
    }
    else {
        ucSkipLpBkTst = 0;
    }

    bReadBackrequired = FALSE;
//Output is not driven in updateopfinal. This is because, the aostc processing will wake up every 10 ms and update the same.
//Driving the output at this point will cause AO output to be driven from 3 places:
// (1) From aostcprocessing (runs from ISR)
// (2) From Writedatabase task (postop())
// (3) From LP task (During TOG failure)
//Removing it from here will prevent 2 and 3 and output gets driven only from one point (1)
//There is no provision of interrupt disable in driveoutput() which will cause reentrancy issues.
}

/*******************************************************************************
*                               clsTcSpAoSlot::DriveOutput                     *
*                               ==========================                     *
* PURPOSE: This function Drive Output to the field                             *
* ARGUMENTS:                                                                   *
*              a_eDelayType - Delay to drive Output                            *
* RETURN:                                                                      *
*             NONE                                                             *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::DriveOutput( DELAY_TYPE a_eDelayType)
{
    // First of all block execution of loopback test.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    AOCTRL1 AoCtrl1;
    AOCTRL3 AoCtrl3;

    clsFPGACtrlReg AoCtrl3Reg((volatile UINT16*)P_AO_CTRL3_REG);

    AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;
 
    AoCtrl1.bit.Ao_Dac_Clr=1;
    AoCtrl1.bit.Ao_Op_Mux_En=1;

    //(* (P_AO_CTRL1_REG)).all=AoCtrl1.all;
    clsFPGACtrlReg AoCtrlReg((volatile UINT16*)P_AO_CTRL1_REG);
    AoCtrlReg = AoCtrl1.all;

    //Load AO Data Register with DAC count
    (* (P_AO_CHAN_DATA_REG)) = OutDACImg; 
    
    //Trigger FPGA to write data to DAC
    AoCtrl3.all=(*(P_AO_CTRL3_REG)).all;
    AoCtrl3.bits.Ao_Req=1;
    //(*(P_AO_CTRL3_REG)).all = AppBrdCtrl.all;
    AoCtrl3Reg = AoCtrl3.all;

    //Wait for FPGA to Signal transmission to DAC over
    do
    {
        AoCtrl3.all=(*(P_AO_CTRL3_REG)).all;
    }
    while(!AoCtrl3.bits.Ao_Data_Rdy); 

    //Reset Request
    AoCtrl3.all=(*(P_AO_CTRL3_REG)).all;
    AoCtrl3.bits.Ao_Req=0;
    //(*(P_AO_CTRL3_REG)).all=AppBrdCtrl.all;
    AoCtrl3Reg = AoCtrl3.all;
    
    //Enable the MUX
    AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;
    AoCtrl1.bit.Ao_Op_Mux_En=0;

    //(*(P_AO_CTRL1_REG)).all=AoCtrl1.all;     //Enable the Mux
    AoCtrlReg = AoCtrl1.all;

    UINT16 usIteration = 1;
    UINT16 usCapChargeTime = DEFAULT_OUTPUT_CAPACITORCHARGE_TIME;
    switch (a_eDelayType) {
        case CalibrationWithExtendedDelay : //100 ms
            // Allow STC when waiting for extended delay so that watchdog refresh
            // will take place. There is no issue with the loopback as extended delay
            // is called only during calibration when the loopback is anyway disabled.
            set_imask_exr(LVLPRI_IOPROC);
            usIteration = 40; //40 times 2.5 ms. This mechanism avoids overflow of UINT16
            usCapChargeTime = CALIBRATION_EXTENDED_CAPACITORCHARGE_TIME/4;
            break;
        case CalibrationWithMinimumDelay:   //150 us
            usIteration = 1;
            usCapChargeTime = CALIBRATION_MINIMUM_CAPACITORCHARGE_TIME;
            break;
        default:
            //Do Nothing
            break;

    }

    do { 
        IdleWait(usCapChargeTime); 
        
        if(a_eDelayType == CalibrationWithExtendedDelay) {
            RefreshWDT(); 
        }

    } while(--usIteration);

    //Disable the MUX
    AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;
    AoCtrl1.bit.Ao_Op_Mux_En=1;
    //(*(P_AO_CTRL1_REG)).all=AoCtrl1.all;     //Disable the Mux
    AoCtrlReg = AoCtrl1.all;

    // Restore original interrupt mask.
    set_imask_exr(ucSaveExr);
}

/*******************************************************************************
*                             clsTcSpAoSlot::GetDumpData                       *
*                             ==========================                       *
* PURPOSE  : This method will copy the redundancy dump data to buffer transmit *
*            to the secondary IOM                                              *
* ARGUMENTS: pDump - Dump Pointer                                              *
*            MaxSize - Dump Size                                               *
* RETURN   : PA_OK -   If getdump is succesful                                 *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsTcSpAoSlot::GetDumpData(UINT8* const pDump,const UINT8 MaxSize)
{
    PASTATUS retVal = PA_NULL;
    if(pDump && IS_EVEN(pDump) && (sizeof(SYNCRECORD) < MaxSize))
    {
        PSYNCRECORD pSyncRec    = (PSYNCRECORD)pDump;
        ///
        pSyncRec->Header        = PACK2_AS_UI16(SPAO_SYNC_VER_1,0);
        pSyncRec->PntType       = (UINT8)PntType;
        pSyncRec->PtExecSt      = (UINT8)PtExecSt;
        pSyncRec->FaultState    = (UINT8)FaultState;
        pSyncRec->FaultOpt      = (UINT8)FaultOpt;
        pSyncRec->Mode          = (UINT8)Mode;
        pSyncRec->ModeAttr      = (UINT8)ModeAttr;
        pSyncRec->ModePerm      = (UINT8)ModePerm;
        pSyncRec->NMode         = (UINT8)NMode;
        pSyncRec->NModeAttr     = (UINT8)NModeAttr;
        pSyncRec->RedTag        = (UINT8)RedTag;
        pSyncRec->OptDir        = (UINT8)OptDir;
        pSyncRec->LocalMan      = (UINT8)LocalMan;
        pSyncRec->OpChar        = (UINT8)OpChar;
        pSyncRec->StdbyMan      = (UINT8)StdbyMan;
        pSyncRec->InitReq       = (UINT8)InitReq;
        pSyncRec->ucSkipLpBkTst = (UINT8)ucSkipLpBkTst;
        pSyncRec->FaultValue    = FaultValue;
        pSyncRec->OpLoLimitVal  = OpLoLimitVal;
        pSyncRec->OpHiLimitVal  = OpHiLimitVal;
        pSyncRec->OpIn0         = OpIn0;
        pSyncRec->OpIn1         = OpIn1;
        pSyncRec->OpIn2         = OpIn2;
        pSyncRec->OpIn3         = OpIn3;
        pSyncRec->OpIn4         = OpIn4;
        pSyncRec->OpIn5         = OpIn5;
        pSyncRec->OpOut0        = OpOut0;
        pSyncRec->OpOut1        = OpOut1;
        pSyncRec->OpOut2        = OpOut2;
        pSyncRec->OpOut3        = OpOut3;
        pSyncRec->OpOut4        = OpOut4;
        pSyncRec->OpOut5        = OpOut5;
        pSyncRec->Chrc_S0       = Chrc_S0;
        pSyncRec->Chrc_S1       = Chrc_S1;
        pSyncRec->Chrc_S2       = Chrc_S2;
        pSyncRec->Chrc_S3       = Chrc_S3;
        pSyncRec->Chrc_S4       = Chrc_S4;
        pSyncRec->OpInternal    = OpInternl;
        pSyncRec->Op            = BOX->GetOp();
        pSyncRec->bReadBackrequired = (UINT8)bReadBackrequired;
        pSyncRec->OpConn        = OpConn;
        ///
        retVal = PA_OK;
    }
return retVal;
}

/*******************************************************************************
*                             clsTcSpAiSlot::StoreDumpData                     *
*                             ============================                     *
* PURPOSE  : This method will copy the redundancy dump data into local dump    *
*            structure in Primary IOM                                          *
* ARGUMENTS: pDump - Dump Pointer                                              *
* RETURN   : PA_OK -   If dump is succesful                                    *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS  clsTcSpAoSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS retVal = PA_NULL;
    ///
    if(pDump && IS_EVEN(pDump))
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SPAO_SYNC_VER_1)
        {
            PSYNCRECORD pSyncRec    = (PSYNCRECORD)pDump;        

            PntType         = (PNTTYPE)pSyncRec->PntType;
            PtExecSt        = (PTEXECST)pSyncRec->PtExecSt;
            FaultState      = (FAULTSTATE)pSyncRec->FaultState;
            FaultOpt        = (FAULTOPT)pSyncRec->FaultOpt;
            Mode            = (MODE)pSyncRec->Mode;
            ModeAttr        = (MODEATTR)pSyncRec->ModeAttr;
            ModePerm        = (MODEPERM)pSyncRec->ModePerm;
            NMode           = (MODE)pSyncRec->NMode;
            NModeAttr       = (MODEATTR)pSyncRec->NModeAttr;
            RedTag          = (REDTAG)pSyncRec->RedTag;
            OptDir          = (OPTDIR)pSyncRec->OptDir;
            LocalMan        = (BOOL)pSyncRec->LocalMan;
            OpChar          = (BOOL)pSyncRec->OpChar;
            StdbyMan        = pSyncRec->StdbyMan;
            InitReq         = pSyncRec->InitReq;
            ucSkipLpBkTst   = pSyncRec->ucSkipLpBkTst;
            FaultValue      = pSyncRec->FaultValue;
            OpLoLimitVal    = pSyncRec->OpLoLimitVal;
            OpHiLimitVal    = pSyncRec->OpHiLimitVal;
            OpIn0           = pSyncRec->OpIn0;
            OpIn1           = pSyncRec->OpIn1;
            OpIn2           = pSyncRec->OpIn2;
            OpIn3           = pSyncRec->OpIn3;
            OpIn4           = pSyncRec->OpIn4;
            OpIn5           = pSyncRec->OpIn5;
            OpOut0          = pSyncRec->OpOut0;
            OpOut1          = pSyncRec->OpOut1;
            OpOut2          = pSyncRec->OpOut2;
            OpOut3          = pSyncRec->OpOut3;
            OpOut4          = pSyncRec->OpOut4;
            OpOut5          = pSyncRec->OpOut5;
            Chrc_S0         = pSyncRec->Chrc_S0;
            Chrc_S1         = pSyncRec->Chrc_S1;
            Chrc_S2         = pSyncRec->Chrc_S2;
            Chrc_S3         = pSyncRec->Chrc_S3;
            Chrc_S4         = pSyncRec->Chrc_S4;
            OpInternl       = pSyncRec->OpInternal;
        
            BOX->SetOp(ChanNum,pSyncRec->Op);
            OpFinal = pSyncRec->Op;        
 
            bReadBackrequired = (BOOL)pSyncRec->bReadBackrequired;

            OpConn          = pSyncRec->OpConn;

            if(PntType != PNTTYPE_NOTCONFIGURED)
            {
                //The Current output channel is in use so can run some diagnostics
                OTPT_Unused = FALSE;
            }

            //Skip the loopback check for 3 cycles 
            ucSkipLpBkTst = 3;  
    
            retVal = PA_OK;
        }
    }
return retVal;
}


/*******************************************************************************
*                               clsTcSpAoSlot::DoLoopbackTest                  *
*                               =============================                  *
* PURPOSE: This function performs loopback test                                *
* ARGUMENTS: a_uiDacCount - Dac Count                                          *
* RETURN: AOLPBKSTS - Loopback Status                                          *
* NOTES:                                                                       *
*******************************************************************************/
AOLPBKSTS clsTcSpAoSlot::DoLoopbackTest (UINT16 a_uiDacCount = FOUR_PRECENT_LOOPBACK_DACCOUNT)
{
    OpenLoopbackMux(SNSV1, TRUE);

    // If output is at zero current, both OutDACImg and LoopBackDACImg are zero.
    // There is a possibility that the +4% check may fail as (LoopBackDACImg + 
    // a_uiDacCount) may not enough to drive the comparator input to produce a 
    // high output. So preadd MINCURRENT_LOOPBACK_DACCOUNT.
    if (0 == LoopBackDACImg) {
        a_uiDacCount += MINCURRENT_LOOPBACK_DACCOUNT;
    }

    // Check and do +4% comparison.
    if ((LoopBackDACImg + a_uiDacCount) < MAXCURRENT_LOOPBACK_DACCOUNT)
    {
        DriveDac(  LoopBackDACImg + a_uiDacCount);
        
    
        if (FALSE == ReadComparatorOutput())
        {
            // Loopback test failed
            CloseLoopbackMux(SNSV1);
            ucPassCount = PASSCOUNTMAX;
            LoopBackStatus = AOLPBK_HITESTFAIL;
            return LoopBackStatus;
        }
    }

    // Check and do -4% comparison
    if (LoopBackDACImg > (MINCURRENT_LOOPBACK_DACCOUNT + a_uiDacCount))
    {
        DriveDac( LoopBackDACImg - a_uiDacCount);
    
        if (TRUE == ReadComparatorOutput())
        {
            // Loopback test failed
            CloseLoopbackMux(SNSV1);
            ucPassCount = PASSCOUNTMAX;
            LoopBackStatus = AOLPBK_LOTESTFAIL;
            return LoopBackStatus;
        }
    }
    // Both tests passed.
    CloseLoopbackMux(SNSV1);
    ucPassCount -= 1;
    if (ucPassCount == PASSCOUNTMIN-1) {
        ucPassCount = PASSCOUNTMIN;
        LoopBackStatus = AOLPBK_PASSED;
    }
    else {
        LoopBackStatus = AOLPBK_LOTESTFAIL;
    }

    
    return LoopBackStatus;
}

/*******************************************************************************
*                    clsTcSpAoSlot::OpenLoopbackMux                            *
*                    ==============================                            *
* PURPOSE:  This methods opens Mux for the corresponding channel               *
* ARGUMENTS: a_uiChanNum - Channel                                             *
* RETURN: BOOL - return TRUE on success                                        *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsTcSpAoSlot::OpenLoopbackMux(UINT8 a_uiChanNum , BOOL bProcSF)
{
    UINT16 ucChan = LOOPBACK_ADDRESS[a_uiChanNum];

    AOCTRL1 AoCtrl1;
    AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;

    AoCtrl1.bit.Ao_Rdbk_Mux_ctrl = ucChan;
    AoCtrl1.bit.Ao_Rdbk = 0;

    //(* (P_AO_CTRL1_REG)).all=AoCtrl1.all;
    clsFPGACtrlReg AoCtrlReg((volatile UINT16*)P_AO_CTRL1_REG);
    AoCtrlReg = AoCtrl1.all;

    IdleWait(MUX_CHANNELSEL_SETTLE_TIME); // Wait 1 micro second

    AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;
    AoCtrl1.bit.Ao_Rdbk_Mux_en=0;  // Enable or open MUX channel.
    //(* (P_AO_CTRL1_REG)).all=AoCtrl1.all;
    AoCtrlReg = AoCtrl1.all;

    UINT8 ucRetryCount;

    for (ucRetryCount = 0; ucRetryCount < MUX_READBACK_RETRYCOUNT; ucRetryCount++)
    {
        AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;

        if( AoCtrl1.bit.Ao_Rdbk_Mux_ctrl != ucChan)
        {
            AoCtrl1.bit.Ao_Rdbk_Mux_ctrl = ucChan; 
            //(* (P_AO_CTRL1_REG)).all=AoCtrl1.all;
            AoCtrlReg = AoCtrl1.all;
        }
        else {
            break;
        }
    }

    if (bProcSF && MUX_READBACK_RETRYCOUNT == ucRetryCount)
    {
        if (FALSE == bOpenLoopbackMuxSF) {
            bOpenLoopbackMuxSF = BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,TRUE,0);
        }
    }
    else
    {
        if(bOpenLoopbackMuxSF)
        {
            if (BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,FALSE,0)) {
                bOpenLoopbackMuxSF=FALSE;
            }
        }
    }
   
    IdleWait(LOOPBACK_COMPARATORSETTLE_TIME - DAC_SETTLE_TIME);
    
    return (MUX_READBACK_RETRYCOUNT == ucRetryCount);

}

/*******************************************************************************
*                               ReadComparatorOutput                           *
*                               ====================                           *
* PURPOSE: This method read the comparator output                              *
* ARGUMENTS: NONE.                                                             *
* RETURN: BOOL - return TRUE on success                                        *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsTcSpAoSlot::ReadComparatorOutput(VOID) {
    const UINT8 _MAX_READINGS_ = 3;
    UINT8 ucRdbk = 0;

    for (UINT8 ucCount = 0; ucCount < _MAX_READINGS_; ucCount++)
    {
        volatile AOCTRL1 AoCtrl1;
        AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;

        if (AoCtrl1.bit.Ao_Rdbk) {
            ucRdbk++; // If bit is set, increment the count
        }

        IdleWait(1); // Wait for 1 microsec
    }
    return (ucRdbk >= 2);

}



/*******************************************************************************
*                            ComputeCalibrationConstants                       *
*                            ===========================                       *
* PURPOSE: To compute the constants for calibration                            *
* ARGUMENTS: Slope and Offset values                                           *
* RETURN: TRUE is succseful, FALSE otherwise                                   *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsTcSpAoSlot::ComputeCalibrationConstants(FLOAT32 a_fB1Val, FLOAT32 a_fB0Val)
{
    clsSpBoxSlot *pBox = BOX;
    BOOL bFieldCalib    = pBox->IsFieldCalib();

    if(bFieldCalib) {
        if(a_fB0Val >= -21.0) {
          //Calibration Abort 
          pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
          return FALSE;
        }
    }
    //Drive 4mA Low DAC value and get the equivalent current
    OutDACImg = FOUR_MA_L_OUTPUT_DACCOUNT;
    DriveOutput(CalibrationWithExtendedDelay);
    volatile FLOAT32 Count4mA_L = pBox->DoSuccessiveApproximation(TRUE);
    volatile FLOAT32 Current4mA_L = a_fB1Val * Count4mA_L + a_fB0Val;
    //Drive 4mA High DAC value and get the equivalent current
    OutDACImg = FOUR_MA_H_OUTPUT_DACCOUNT;
    DriveOutput(CalibrationWithExtendedDelay);
    volatile FLOAT32 Count4mA_H = pBox->DoSuccessiveApproximation(TRUE);
    volatile FLOAT32 Current4mA_H = a_fB1Val  * Count4mA_H + a_fB0Val;
    //Compute the slope at 4mA by m = (y2-y1)/(x2-x1).
    volatile FLOAT32 Slope_4mA = NaN;
    if (Current4mA_H > Current4mA_L) {
        Slope_4mA = ((Current4mA_H - Current4mA_L) / 
            (FOUR_MA_H_OUTPUT_DACCOUNT - FOUR_MA_L_OUTPUT_DACCOUNT));
    }
    else {
        return FALSE;
    }
    //Compute the offset at 4mA by c = y1 - mx1
    volatile FLOAT32 Offset_4mA= Current4mA_L - Slope_4mA * FOUR_MA_L_OUTPUT_DACCOUNT;
    //TBD : Use a ceil() function to get the DAC Count
    volatile UINT16  CalcDacCount_4mA = (UINT16)((0 - Offset_4mA) / Slope_4mA);
    if(0 != (CalcDacCount_4mA & 0xF000)) {
       pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
       return FALSE;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,ChanNum);
    //Now get the approximated current value for 4mA
    OutDACImg = CalcDacCount_4mA;
    DriveOutput(CalibrationWithExtendedDelay);
    volatile FLOAT32 Current_4mA = a_fB1Val * pBox->DoSuccessiveApproximation(TRUE) + a_fB0Val;
    volatile UINT16 LpbkDacCount_4mA = 0;
    if(!bFieldCalib)  {//Only for factory
        //Get the internal loopback reading of 4mA we just drove
        LpbkDacCount_4mA = GetInternalReading();
    }

    //Repeat the above procedure for 20mA
    //Drive 20mA Low DAC value and get the equivalent current
    OutDACImg = TWENTY_MA_L_OUTPUT_DACCOUNT;
    DriveOutput(CalibrationWithExtendedDelay);
    volatile FLOAT32 Count20mA_L = pBox->DoSuccessiveApproximation(TRUE);
    volatile FLOAT32 Current20mA_L = a_fB1Val * Count20mA_L + a_fB0Val;
    //Drive 20mA High DAC value and get the equivalent current
    OutDACImg = TWENTY_MA_H_OUTPUT_DACCOUNT;
    DriveOutput(CalibrationWithExtendedDelay);
    volatile FLOAT32 Count20mA_H = pBox->DoSuccessiveApproximation(TRUE);
    volatile FLOAT32 Current20mA_H = a_fB1Val  * Count20mA_H + a_fB0Val;

    
    //Compute the slope at 20mA by m = (y2-y1)/(x2-x1).
    volatile FLOAT32 Slope_20mA = NaN;
    if (Current20mA_H > Current20mA_L) {
        Slope_20mA = ((Current20mA_H - Current20mA_L) / 
                      (TWENTY_MA_H_OUTPUT_DACCOUNT - TWENTY_MA_L_OUTPUT_DACCOUNT));
    }
    else {
        return FALSE;
    }
    //Compute the offset at 4mA by c = y1 - mx1
    volatile FLOAT32 Offset_20mA= Current20mA_L - Slope_20mA * TWENTY_MA_L_OUTPUT_DACCOUNT;
    //TBD : Use a ceil() function to get the DAC Count
    volatile UINT16  CalcDacCount_20mA = (UINT16)((100 - Offset_20mA) / Slope_20mA);
    if(0 != (CalcDacCount_20mA & 0xF000)) {
       pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
       //return FALSE;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,ChanNum);

    //Now get the approximated current value for 4mA
    OutDACImg = CalcDacCount_20mA;
    DriveOutput(CalibrationWithExtendedDelay);
    volatile FLOAT32 Current_20mA = a_fB1Val * pBox->DoSuccessiveApproximation(TRUE) + a_fB0Val;
    volatile UINT16 LpbkDacCount_20mA = 0;
    //Now get the internal loopback reading of 20mA we just drove
    if(!bFieldCalib) {//Only for factory 
        LpbkDacCount_20mA = GetInternalReading();
    }

    //Checking for open-wire. Ideally Current_20mA should be 100%. 
    //If it is less than 95 it is an open-wire
    if(Current_20mA <= 95.0) {
        //Calibration Abort 
        pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,TRUE,ChanNum);
        //return FALSE;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
    // Compute the external input calibration constants for this channel
    // Slope = (y2-y1)/(x2-x1),Offset = y1-mx1
    B1_O = (Current_20mA - Current_4mA) / 
           (CalcDacCount_20mA - CalcDacCount_4mA);
    B0_O = Current_4mA - (B1_O * CalcDacCount_4mA);
    // Compute the internal input calibration constants for this channel
    // Slope = (y2-y1)/(x2-x1),Offset = y1-mx1
    SPMCALIBDATA *pData = BOX->GetCalibDataPtr();
    volatile FLOAT32 fNormalizedB1 = 0;
    volatile FLOAT32 fNormalizedB0 = 0;
    if(bFieldCalib) {
        fNormalizedB1 = a_fB1Val / pData->AOFactorySlope;
        fNormalizedB0 = a_fB0Val - pData->AOFactoryOffset;
    }
    else {
        FLOAT32 fB1_I = (Current_20mA - Current_4mA) / 
                (LpbkDacCount_20mA - LpbkDacCount_4mA);
        FLOAT32 fB0_I = Current_4mA - (fB1_I * LpbkDacCount_4mA);
        if(fB0_I >= -21.0) {
          //Calibration Abort 
          pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
          return FALSE;
        }
        fNormalizedB1 = fB1_I / a_fB1Val;
        fNormalizedB0 = fB0_I - a_fB0Val;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,ChanNum);
    //Store the constants in the EEPROM image in RAM to burn in flash later
    UINT8 ucIndex = 0;
    pData->CalibConstants[ucIndex++] = B1_O;
    pData->CalibConstants[ucIndex++] = B0_O;
    pData->CalibConstants[ucIndex++] = fNormalizedB1;
    pData->CalibConstants[ucIndex]   = fNormalizedB0;

     // once the  flash writing is done remove this
   volatile FLOAT32 fB1_L,fB0_L,fB1Inv,fB0_OInv,fB0_LInv,fB1LInv;
    //The loopback constants were normalized while saving.
    //De-Normalize them before restoring for use.
    B1_L = fB1_L = fNormalizedB1 * pData->AOFactorySlope;
    B0_L = fB0_L = fNormalizedB0   + pData->AOFactoryOffset;
    B1_Inv = fB1Inv  = 1 / B1_O;
    B1_LInv = fB1LInv = 1 / fB1_L;
    B0_Inv = fB0_OInv = - B0_O / B1_O;
    B0_LInv = fB0_LInv = - fB0_L / fB1_L;

 
    return TRUE;
}

/*******************************************************************************
*                           clsTcSpAoSlot::DriveDac                            *
*                           =======================                            *
* PURPOSE: This method will Drive Dac                                          *
* ARGUMENTS: a_uiDacCount - Dac Count.                                         *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::DriveDac(UINT16 a_uiDacCount)
{
    AOCTRL1 AoCtrl1;
    AOCTRL3 AoCtrl3;
    clsFPGACtrlReg AoCtrlReg((volatile UINT16*)P_AO_CTRL1_REG);
    clsFPGACtrlReg AoCtrl3Reg((volatile UINT16*)P_AO_CTRL3_REG);

    AoCtrl1.all=(* (P_AO_CTRL1_REG)).all;
    
    AoCtrl1.bit.Ao_Dac_Clr=1;
    AoCtrl1.bit.Ao_Op_Mux_En=1;

    //(* (P_AO_CTRL1_REG)).all=AoCtrl1.all;
    AoCtrlReg = AoCtrl1.all;

    //Load AO Data Register with DAC count
    (* (P_AO_CHAN_DATA_REG)) = a_uiDacCount;

    //Trigger FPGA to write data to DAC
    AoCtrl3.all=(*(P_AO_CTRL3_REG)).all;
    AoCtrl3.bits.Ao_Req=1;
    //(*(P_AO_CTRL3_REG)).all = AppBrdCtrl.all;
    AoCtrl3Reg = AoCtrl3.all;

    //Wait for FPGA to Signal transmission to DAC over
    do
    {
        AoCtrl3.all=(*(P_AO_CTRL3_REG)).all;
    }
    while(!AoCtrl3.bits.Ao_Data_Rdy);

    AoCtrl3.all=(*(P_AO_CTRL3_REG)).all;
    AoCtrl3.bits.Ao_Req=0;
    //(*(P_AO_CTRL3_REG)).all=AppBrdCtrl.all;
    AoCtrl3Reg = AoCtrl3.all;

    IdleWait(DAC_SETTLE_TIME);

}

/*******************************************************************************
*                      clsTcSpAoSlot::SlotFaultHandler                         *
*                      ===============================                         *
* PURPOSE:   This function drives the output to configured FaultOpt values,    *
*            if the COM/CTL TOG fails.                                         *
* ARGUMENTS: a_TogFailed - Tog Failed Options                                  *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsTcSpAoSlot::SlotFaultHandler(TOG_FAILED a_TogFailed) {
    // If RedTag is ON for this channel do nothing...
    if (REDTAG_ON == RedTag) {
        return;
    }

    // Do not shed the output if only control tog failed
    // and the ouput is in manual-operator control.
    if ((CTLTOG_FAILED == a_TogFailed) && 
        (MODE_MANUAL == Mode) && (MODEATTR_OPERATOR == ModeAttr)) {
        return;
    }

    FaultState = FAULTSTATE_FAULTED; // Mark the slot as faulted.
    CmptInitReq();

    switch (FaultOpt) {
    case FAULTOPT_HOLD:
        break;
    case FAULTOPT_FAULTVALUE:
        BOX->SetOp(ChanNum,FaultValue);
        break;
    case FAULTOPT_UNPOWERED:
        BOX->SetOp(ChanNum,OP_LOLIMIT);
        break;
     default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x926,FaultOpt);
        break;
    }
}

/*******************************************************************************
*                              clsTcSpAoSlot::GetInternlReading                *
*                              ================================                *
* PURPOSE: To get the loopback value for the forward driven current for this   *
*          channel                                                             *
* ARGUMENTS: None.                                                             *
* RETURN: The DAC count corresponding to current                               *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
UINT16 clsTcSpAoSlot::GetInternalReading() {
    UINT16 DacCount = (UINT16)BOX->DoSuccessiveApproximation(TRUE);
 
    return DacCount;
}