/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohslot.cpp                                                 *
*    Description : Class clsAohSlot definition.                                *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "tracelog.hpp"
#ifdef IOMTYPE_UIO
    #include "uioboxslot.hpp"
    #include "uiofpga.hpp"
#else
    #include "aohmain.h"
#endif


/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#if defined(IOMTYPE_UIO)
#define PARAMID_LOCALMAN     52
#define PARAMID_MODATTR      53
#define PARAMID_MODE         54
#define PARAMID_MODEPERM     56
#define PARAMID_NMODATTR     57
#define PARAMID_NMODE        58
#define PARAMID_OP           59
#define PARAMID_OPCHAR       60
#define PARAMID_OPIN0        62
#define PARAMID_OPIN1        63
#define PARAMID_OPIN2        64
#define PARAMID_OPIN3        65
#define PARAMID_OPIN4        66
#define PARAMID_OPOUT0       68
#define PARAMID_OPOUT1       69
#define PARAMID_OPOUT2       70
#define PARAMID_OPOUT3       71
#define PARAMID_OPOUT4       72
#define PARAMID_OPTDIR       74
#define PARAMID_PNTTYPE      76
#define PARAMID_PTEXECST     77
#define PARAMID_REDTAG       80
#define PARAMID_RINITREQ     81
#define PARAMID_STDBYMAN     84
#define PARAMID_SLTCHKPNT    86
#define PARAMID_INITREQ      88
#define PARAMID_FAULTOPT    125
#define PARAMID_FAULTVALUE  127
#define PARAMID_OPINTERNAL  238
#define PARAMID_SLTCHKPNTVER 245
#define PARAMID_CHRC_S0     246
#define PARAMID_CHRC_S1     247
#define PARAMID_CHRC_S2     248
#define PARAMID_CHRC_S3     249
#define PARAMID_CHRC_S4     250
#define PARAMIDOTPT_UNUSED  251

// Slot checkpoint version
#define LATEST_SLTCHKPNT_VERSION LATEST_UIO_AO_SLTCHKPNT_VERSION

    // 0 mA DAC count
    const UINT16 MINCURRENT_OUTPUT_DACCOUNT = FPGA.MilliampsToDacCount(0.0);
#endif

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsAohSlot::AosData[] = {
    PARAMID_OP,
    PARAMID_INITREQ,
    PARAMID_STDBYMAN,
    PARAMID_LOCALMAN,
    0 // Terminator
};

const UINT8 clsAohSlot::SecData[] = {
    PARAMID_OP,
    PARAMID_RINITREQ,
#if defined(IOPTYPE_AO16)
    // added to resolve, PAR# 1-7KEO0U1 (INIT issue while driving OP through AM in MAN -C (Cascade mode))
    PARAMID_RCSAOPT,
    PARAMID_CSCD_RQSTD,
#endif
    0 // Terminator
};

const UINT8  clsAohSlot::CheckPointVer1[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_HENABLE,
    PARAMID_HALARMENABLE,
    PARAMID_OPCHAR,
    PARAMID_OPIN1,
    PARAMID_OPOUT1,
    PARAMID_OPIN2,
    PARAMID_OPOUT2,
    PARAMID_OPIN3,
    PARAMID_OPOUT3,
    PARAMID_OPIN4,
    PARAMID_OPOUT4,
    PARAMID_OPTDIR,
    PARAMID_MODEPERM,
    PARAMID_NMODE,
    PARAMID_NMODATTR,
    PARAMID_MODATTR,
    PARAMID_MODE,
    PARAMID_FAULTOPT,
    PARAMID_FAULTVALUE,
    PARAMID_REDTAG,
    PARAMID_HNTFYCFG,
    PARAMID_HDVMFGCD,
    PARAMID_HDVTYPCD,
    PARAMID_HDVREVCD,
    PARAMID_HDEVIDCD,
    PARAMID_HDDREVCD,
    PARAMID_HSCANCFG,
    PARAMID_HCOMTHRS,
    PARAMID_HCOMHYS,
    PARAMID_HSLOTDVCBLND,
    PARAMID_PTEXECST,
    0 // Terminator
};
#if !defined(IOPTYPE_AO16)
const UINT8  clsAohSlot::CheckPointVer2[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_HENABLE,
    PARAMID_HALARMENABLE,
    PARAMID_OPCHAR,
    PARAMID_OPIN1,
    PARAMID_OPOUT1,
    PARAMID_OPIN2,
    PARAMID_OPOUT2,
    PARAMID_OPIN3,
    PARAMID_OPOUT3,
    PARAMID_OPIN4,
    PARAMID_OPOUT4,
    PARAMID_OPTDIR,
    PARAMID_MODEPERM,
    PARAMID_NMODE,
    PARAMID_NMODATTR,
    PARAMID_MODATTR,
    PARAMID_MODE,
    PARAMID_FAULTOPT,
    PARAMID_FAULTVALUE,
    PARAMID_REDTAG,
    PARAMID_HNTFYCFG,
    PARAMID_HDVMFGCD,
    PARAMID_HDVTYPCD,
    PARAMID_HDVREVCD,
    PARAMID_HDEVIDCD,
    PARAMID_HDDREVCD,
    PARAMID_HSCANCFG,
    PARAMID_HCOMTHRS,
    PARAMID_HCOMHYS,
    PARAMID_HSLOTDVCBLND,
    PARAMID_PTEXECST,
    PARAMID_HDVMFGCD7,
    PARAMID_HDVTYPCD7,
    PARAMID_HSLOTDVCBLND7,
    0 // Terminator
};
const CHECKPOINT_VER_TABLE clsAohSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 116 },
    { CheckPointVer2, 124 }
};
#else
// PMIO AO16 Redesign param tables
const UINT8  clsAohSlot::CheckPointVer2[] = {
    PARAMID_PNTTYPE,
    PARAMID_PNTFORM,
    PARAMID_OPCHAR,
    PARAMID_OPIN1,
    PARAMID_OPOUT1,
    PARAMID_OPIN2,
    PARAMID_OPOUT2,
    PARAMID_OPIN3,
    PARAMID_OPOUT3,
    PARAMID_OPIN4,
    PARAMID_OPOUT4,
    PARAMID_OPTDIR,
    PARAMID_RCSAOPT,
    PARAMID_MODEPERM,
    PARAMID_NMODE,
    PARAMID_NMODATTR,
    PARAMID_MODATTR,
    PARAMID_FL_UNPWRD,
    PARAMID_REDTAG,
    PARAMID_PTEXECST,
#if 0//defined(HART_SUPPORT)
    PARAMID_HENABLE,        //1
    PARAMID_HALARMENABLE,   //1
    PARAMID_HNTFYCFG,       //50
    PARAMID_HDVMFGCD7,      //2
    PARAMID_HDVMFGCD,       //1
    PARAMID_HDVTYPCD7,      //2
    PARAMID_HDVTYPCD,       //1
    PARAMID_HDVREVCD,       //1
    PARAMID_HDEVIDCD,       //3
    PARAMID_HDDREVCD,       //1
    PARAMID_HSCANCFG,       //1
    PARAMID_HCOMTHRS,       //2
    PARAMID_HCOMHYS,        //2
  //PARAMID_H7SLDVC,
	PARAMID_HSLOTDVCBLND,   //4
	PARAMID_HSLOTDVCBLND7,  //4 - 76 bytes
#endif
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsAohSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 116 },
    { CheckPointVer2, 44 }
};

// PMIO HLAI SLOT DUMP PARAM
const UINT8 clsAohSlot::PmioDumpParamTbl[] = {
    PARAMID_PTEXECST,
    PARAMID_PTEXECSTLRS,
    PARAMID_PNTFORM,
    PARAMID_PNTTYPE,
    PARAMID_OPTDIR,
    PARAMID_MODE,
    PARAMID_MODATTR,
    PARAMID_NMODE,
    PARAMID_NMODATTR,
    PARAMID_CSCD_RQSTD,
    PARAMID_FL_UNPWRD,
    PARAMID_OPCHAR,
    PARAMID_OPIN0,
    PARAMID_OPOUT0,
    PARAMID_CHRC_S0,
    PARAMID_OPIN1,
    PARAMID_OPOUT1,
    PARAMID_CHRC_S1,
    PARAMID_OPIN2,
    PARAMID_OPOUT2,
    PARAMID_CHRC_S2,
    PARAMID_OPIN3,
    PARAMID_OPOUT3,
    PARAMID_CHRC_S3,
    PARAMID_OPIN4,
    PARAMID_OPOUT4,
    PARAMID_CHRC_S4,
    PARAMID_OPIN5,
    PARAMID_OPOUT5,
    PARAMID_LOCALMAN,
    PARAMID_STDBYMAN,
    PARAMID_MODEAPPL,
    PARAMID_MODEPERM,
    PARAMID_RCSAOPT,
    PARAMIDOTPT_UNUSED,
    PARAMID_REDTAG,
    PARAMID_OPREAL,
    PARAMID_OPINTERNAL,
    0 // Terminator
};

// PMIO HART SLOT DUMP PARAM
const UINT8  clsAohSlot::PmioHartDumpParamTbl[] = {
    PARAMID_HENABLE,
    PARAMID_HSCANCFG,
    PARAMID_HDYNRATE,
    PARAMID_HDEVRATE,
  //PARAMID_HSLOTDVC,
    PARAMID_HSLOTDVCBLND,
    PARAMID_HCOMTHRS,
    PARAMID_HCOMHYS,
    PARAMID_HDVMFGCD,
    PARAMID_HDEVIDCD,
    PARAMID_HDVTYPCD,
    PARAMID_HDVREVCD,
    PARAMID_HALARMENABLE,
    PARAMID_HNTFYCFG,
    PARAMID_SLOTCFGD,
  //PARAMID_H7SLDVC,
	PARAMID_HSLOTDVCBLND,
	PARAMID_HSLOTDVCBLND7,
    PARAMID_HDVMFGCD7,
    PARAMID_HDVTYPCD7,
    0 // Terminator
};
#endif // PMIO Redeisgn AO16 param tables

#if defined(IOMTYPE_UIO)
UINT8 clsAohSlot::AoSlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
#else
UINT8 clsAohSlot::SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
#endif

#if defined(IOPTYPE_AO16)
const UINT8 clsAohSlot::RedParams[] = {
    PARAMID_PTEXECST,
  //PARAMID_PTEXECSTLRS,
    PARAMID_PNTFORM,
    PARAMID_PNTTYPE,
    PARAMID_OPTDIR,
    PARAMID_MODE,
    PARAMID_MODATTR,
    PARAMID_NMODE,
    PARAMID_NMODATTR,
    PARAMID_CSCD_RQSTD,
    PARAMID_FL_UNPWRD,
    PARAMID_OPCHAR,
    PARAMID_OPIN0,
    PARAMID_OPOUT0,
    PARAMID_CHRC_S0,
    PARAMID_OPIN1,
    PARAMID_OPOUT1,
    PARAMID_CHRC_S1,
    PARAMID_OPIN2,
    PARAMID_OPOUT2,
    PARAMID_CHRC_S2,
    PARAMID_OPIN3,
    PARAMID_OPOUT3,
    PARAMID_CHRC_S3,
    PARAMID_OPIN4,
    PARAMID_OPOUT4,
    PARAMID_CHRC_S4,
    PARAMID_OPIN5,
    PARAMID_OPOUT5,
    PARAMID_LOCALMAN,
    PARAMID_STDBYMAN,
    PARAMID_MODEAPPL,
    PARAMID_MODEPERM,
    PARAMID_RCSAOPT,
    PARAMIDOTPT_UNUSED,
    PARAMID_REDTAG,  
    PARAMID_OPINTERNAL,
#if defined(HART_SUPPORT)
    PARAMID_HDVMFGCD7,
    PARAMID_HDVTYPCD7,
    PARAMID_HALARMENABLE,
    PARAMID_HENABLE,
    PARAMID_HSCANCFG,
    PARAMID_HDYNRATE,
    PARAMID_HDEVRATE,
  //PARAMID_H7SLDVC,
	PARAMID_HSLOTDVCBLND,
	PARAMID_HSLOTDVCBLND7,
    PARAMID_HCOMTHRS,
    PARAMID_HCOMHYS,
    PARAMID_HDEVIDCD,
    PARAMID_HDVREVCD,
    PARAMID_HNTFYCFG,
#endif
    0 // Terminator
};
#else
const UINT8 clsAohSlot::RedParams[] = {
    PARAMID_OPINTERNAL, 

    // Don't sync OTPT_Unused in UIO.  UIO needs to prevent
    // read back diagnostics from running until the slot
    // can contribute current.    
#if !defined(IOMTYPE_UIO)
    PARAMIDOTPT_UNUSED,
#endif

    PARAMID_FAULTVALUE,
    PARAMID_FAULTOPT,
    PARAMID_STDBYMAN,
    PARAMID_REDTAG,
    PARAMID_PNTTYPE,
    PARAMID_PTEXECST,
    PARAMID_OPTDIR, 
    PARAMID_OPIN0, 
    PARAMID_OPIN1, 
    PARAMID_OPIN2, 
    PARAMID_OPIN3, 
    PARAMID_OPIN4, 
    PARAMID_OPOUT0,
    PARAMID_OPOUT1,
    PARAMID_OPOUT2,
    PARAMID_OPOUT3,
    PARAMID_OPOUT4,
    PARAMID_CHRC_S0,
    PARAMID_CHRC_S1,
    PARAMID_CHRC_S2,
    PARAMID_CHRC_S3,
    PARAMID_CHRC_S4,
    PARAMID_OPCHAR,
    PARAMID_NMODE,
    PARAMID_NMODATTR,
    PARAMID_MODEPERM,
    PARAMID_MODE,
    PARAMID_MODATTR,
    PARAMID_LOCALMAN,
    0 // Terminator
};
#endif

const AO_SLOTPARAMINFO clsAohSlot::tblParamInfo[256] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 00
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 01
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 02
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 03
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 04
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 05
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 06
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 07
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 08
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 09
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 10
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 11
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 12
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 13
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 14
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 15
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 16
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 17
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 18
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 19
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 20
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 21
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 22
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 23
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 24
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 25
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 26
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 27
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 28
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 29
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 30
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 31
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 32
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 33
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 34
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 35
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 36
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 37
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 38
#if defined(IOPTYPE_AO16)
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetSlotCfgdPtr, FALSE,                        // 39 SLOTCFGD    
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                        // 39
#endif
    DT_BLIND, 4, AT_MBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, GetHSlotDvcPtr, TRUE,                       // 40 HSLOTDVCBLND
    DT_BLIND, 4, AT_MBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, GetHSlotDvcPtr7, TRUE,                      // 41 HSLOTDVCBLND7
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 42
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 43
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 44
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 45
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 46
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 47
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 48
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 49
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 50
#if defined(IOPTYPE_AO16)
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreFaultOpt, PostFaultOpt, GetFaultOptPtr, TRUE,    // 51 FaultOpt (PAR #1-DVN1QBM fix - FaultOpt param is using instead of Fl_UnPwrd param in legacy).
    //DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, 0, PostFl_UnPwrd, GetFl_UnPwrdPtr, TRUE,          // 51 Fl_UnPwrd
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 51
#endif
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetLocalManPtr, TRUE,                         // 52 LocalMan
    DT_ENUM, 1, AT_SBYTE, ALCK_OPER, CONTROLSTATE_NONE, PreModeAttr, 0, GetModeAttrPtr, TRUE,               // 53 ModeAttr
    DT_ENUM, 1, AT_SBYTE, ALCK_OPER, CONTROLSTATE_NONE, PreMode, PostMode, GetModePtr, TRUE,                // 54 Mode 
#if defined(IOPTYPE_AO16)
    DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetModeApplPtr, TRUE,                        // 55 ModeAppl
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 55
#endif
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_NONE, PreModePerm, 0, GetModePermPtr, TRUE,                // 56 ModePerm
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreNModeAttr, 0, GetNModeAttrPtr, TRUE,             // 57 NModeAttr 
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreNMode, 0, GetNModePtr, TRUE,                     // 58 NMode
    DT_FLOAT32, 4, AT_BXREC, ALCK_OPER, CONTROLSTATE_ACTIVEANDRUN, PreOp, PostOp, GetOpPtr, FALSE,          // 59 Op
    DT_BOOL, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, 0, PostOpChar, GetOpCharPtr, TRUE,                   // 60 Opchar
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetOpFinalPtr, FALSE,                      // 61 OpFinal
#if !defined(IOPTYPE_AO16)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVE, 0, 0, GetOpIn0Ptr, TRUE,                     // 62 OpIn0
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpIn1, 0, GetOpIn1Ptr, TRUE,              // 63 OpIn1
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpIn2, 0, GetOpIn2Ptr, TRUE,              // 64 OpIn2
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpIn3, 0, GetOpIn3Ptr, TRUE,              // 65 OpIn3
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpIn4, 0, GetOpIn4Ptr, TRUE,              // 66 OpIn4
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVE, 0, 0, GetOpIn5Ptr, TRUE,                     // 67 OpIn5
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVE, 0, 0, GetOpOut0Ptr, TRUE,                    // 68 OpOut0
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpOut1, 0, GetOpOut1Ptr, TRUE,            // 69 OpOut1
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpOut2, 0, GetOpOut2Ptr, TRUE,            // 70 OpOut2
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpOut3, 0, GetOpOut3Ptr, TRUE,            // 71 OpOut3
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVE, PreOpOut4, 0, GetOpOut4Ptr, TRUE,            // 72 OpOut4
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVE, 0, 0, GetOpOut5Ptr, TRUE,                    // 73 OpOut5
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, 0, PostOptDir, GetOptDirPtr, TRUE,               // 74 OptDir
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 75
#else
    //for PMIO AO16 redeisgn
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVEORIDLE, 0, 0, GetOpIn0Ptr, TRUE,               // 62 OpIn0
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpIn1, 0, GetOpIn1Ptr, TRUE,        // 63 OpIn1
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpIn2, 0, GetOpIn2Ptr, TRUE,        // 64 OpIn2
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpIn3, 0, GetOpIn3Ptr, TRUE,        // 65 OpIn3
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpIn4, 0, GetOpIn4Ptr, TRUE,        // 66 OpIn4
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVEORIDLE, 0, 0, GetOpIn5Ptr, TRUE,               // 67 OpIn5
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVEORIDLE, 0, 0, GetOpOut0Ptr, TRUE,              // 68 OpOut0
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpOut1, 0, GetOpOut1Ptr, TRUE,      // 69 OpOut1
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpOut2, 0, GetOpOut2Ptr, TRUE,      // 70 OpOut2
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpOut3, 0, GetOpOut3Ptr, TRUE,      // 71 OpOut3
    DT_FLOAT32, 4, AT_MBYTE, ALCK_SUPR, CONTROLSTATE_INACTIVEORIDLE, PreOpOut4, 0, GetOpOut4Ptr, TRUE,      // 72 OpOut4
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_INACTIVEORIDLE, 0, 0, GetOpOut5Ptr, TRUE,              // 73 OpOut5
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVEORIDLE, 0, PostOptDir, GetOptDirPtr, TRUE,         // 74 OptDir
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_NONE, 0, PostPntForm, GetPntFormPtr, TRUE,                 // 75 PNTFORM    
#endif
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, PrePntType, PostPntType, GetPntTypePtr, TRUE,        // 76 PntType
    DT_ENUM, 1, AT_SBYTE, ALCK_SUPR, CONTROLSTATE_NONE, PrePtExecSt, PostPtExecSt, GetPtExecStPtr, TRUE,    // 77 PtExecSt
#if defined(IOPTYPE_AO16)
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreRCasOpt, PostRCasOpt, GetRCasOptPtr, TRUE,       // 78 RCasOpt
    DT_ENUM, 1, AT_SBYTE, ALCK_PROG, CONTROLSTATE_NONE, PreCscd_Rqstd, 0, GetCscd_RqstdPtr, TRUE,           // 79 Cscd_Rqstd
    DT_ENUM, 1, AT_SBYTE, ALCK_SUPR, CONTROLSTATE_NONE, PreRedTag, 0, GetRedTagPtr, TRUE,                   // 80 RedTag    
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetRInitReqPtr, FALSE,                        // 81 RINITREQ
#else
    DT_NONE, 0, AT_NONE,  ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                     // 78
    DT_NONE, 0, AT_NONE,  ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                     // 79
    DT_BOOL, 1, AT_SBYTE, ALCK_SUPR, CONTROLSTATE_NONE, PreRedTag, 0, GetRedTagPtr, TRUE,                   // 80 RedTag    
    DT_NONE, 0, AT_NONE,  ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                     // 81 
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 82
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetSlotSfBtPtr, FALSE,                       // 83 SlotSfBt
#if defined(IOMTYPE_UIO)
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetStdbyManPtr, TRUE,                         // 84 StdbyMan
#else
    DT_BOOL, 1, AT_BXPACK, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetStdbyManPtr, TRUE,                        // 84 StdbyMan
#endif
    DT_BLIND, 7, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetAosDataPtr, FALSE,                         // 85 Aosdata
#if defined(IOPTYPE_AO16)
    DT_BLIND, 44, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, PreCheckPoint, 0, GetCheckPointPtr, TRUE,          // 86 checkpoint
    DT_BLIND, 7, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetSecDataPtr, FALSE,                         // 87 SecData // added to resolve, PAR# 1-7KEO0U1 (INIT issue while driving OP through AM in MAN -C (Cascade mode))
#else
    DT_BLIND, 124, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, PreCheckPoint, 0, GetCheckPointPtr, TRUE,         // 86 checkpoint
    DT_BLIND, 5, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetSecDataPtr, FALSE,                         // 87 SecData
#endif    
    DT_BOOL, 1, AT_BXPACK, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetInitReqPtr, FALSE,                        // 88 InitReq
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 89
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 90
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 91
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 92
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 93
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 94
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 95
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 96
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 97
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 98
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 99
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 100
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 101
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 102
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 103
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 104
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 105
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 106
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 107
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 108
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 109
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 110
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 111
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 112
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 113
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 114
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 115
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 116
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 117
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 118
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 119
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 120
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 121
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 122
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 123
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 124
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_NONE, PreFaultOpt, PostFaultOpt, GetFaultOptPtr, TRUE,     // 125 FaultOpt
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 126
    DT_FLOAT32, 4, AT_MBYTE, ALCK_EPB, CONTROLSTATE_NONE, PreFaultValue, 0, GetFaultValuePtr, TRUE,         // 127 FaultValue
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetFaultStatePtr, FALSE,                      // 128 FaultState
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 129
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 130
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 131
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 132
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 133
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 134
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 135
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 136
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 137
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 138
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 139
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 140
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 141
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 142
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 143
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 144
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreCommand, PostCommand, GetCommandPtr, FALSE,      // 145 Command
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 146
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 147
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 148
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 149
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 150
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 151
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 152
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 153
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 154
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 155
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 156
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 157
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 158
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 159
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 160
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 161
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 162
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 163
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 164
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 165
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 166
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 167
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 168
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 169
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 170
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 171
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 172
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 173
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 174
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 175
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 176
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 177
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 178
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 179
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 180
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 181
    DT_BLIND, 32, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHLongTagPtr, FALSE,                      // 182 HLongTag
    DT_BLIND, 5, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetH7Cmd0Ptr, FALSE,                         // 183 H7Cmd0
    DT_UINT16, 2, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreHDvMfgCd7, 0, GetHDvMfgCd7Ptr, TRUE,            // 184 HDvMfgCd7
    DT_UINT16, 2, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreHDvTypCd7, 0, GetHDvTypCd7Ptr, TRUE,            // 185 HDvTypCd7
#if defined(HART_SUPPORT)
	DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHSlot0TSPtr, FALSE,                       // 186 HSlot0TS
#else
	DT_UINT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHSlot0TSPtr, FALSE,                      // 186 HSlot0TS
#endif
    DT_BLIND, 7, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDevCdPtr, FALSE,                          // 187 HDevCd
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 188
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 189
    DT_BOOL, 1, AT_SBYTE, ALCK_OPER, CONTROLSTATE_NONE, PreHAlarmEnable, PostHAlarmEnable, GetHAlarmEnablePtr, TRUE, // 190 HAlarmEnable
    DT_BOOL, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, PreHEnable, PostHEnable, GetHEnablePtr, TRUE,    // 191 HEnable
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, PreHScanCfg, PostHScanCfg, GetHScanCfgPtr, TRUE, // 192 HScanCfg
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDynRatePtr, FALSE,                       // 193 HDynRate
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDevRatePtr, FALSE,                       // 194 HDevRate
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, 0, 0, GetHSlotDvcPtr, TRUE,                            // 195 HSlotDvc7[8]
    DT_UINT16, 2, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreHComThrs, 0, GetHComThrsPtr, TRUE,             // 196 HComThrs
    DT_UINT16, 2, AT_MBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreHComHys, 0, GetHComHysPtr, TRUE,               // 197 HComHys
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHComStsPtr, FALSE,                         // 198 HComSts
    DT_UINT16, 2, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHNComErrPtr, FALSE,                      // 199 HNComErr
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 200
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 201
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 202
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 203
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHLComFailPtr, FALSE,                       // 204 HLComFail
    DT_BLIND, 17, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd0Ptr, FALSE,                         // 205 HCmd0
    DT_BLIND, 24, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd12Ptr, FALSE,                        // 206 HCmd12
    DT_BLIND, 21, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd13Ptr, FALSE,                        // 207 HCmd13
    DT_BLIND, 16, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd14Ptr, FALSE,                        // 208 HCmd14
    DT_BLIND, 18, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd15Ptr, FALSE,                        // 209 HCmd15
    DT_BLIND, 3, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd16Ptr, FALSE,                         // 210 HCmd16
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDynValPtr, FALSE,                      // 211 HDynVal[4]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDynStPtr, FALSE,                          // 212 HDynSt[4]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDynCcPtr, FALSE,                          // 213 HDynCc[4]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDynEuPtr, FALSE,                          // 214 HDynEu[4]
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHSlotValPtr, FALSE,                     // 215 HSlotVal[8]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHSlotStPtr, FALSE,                         // 216 HSlotSt[8]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHSlotCcPtr, FALSE,                         // 217 HSlotCc[8]
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHSlotEuPtr, FALSE,                         // 218 HSlotEu[8]
    DT_BLIND, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDevStPtr, FALSE,                         // 219 HDevSt[4]
    DT_BLIND, 25, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd48Ptr, FALSE,                        // 220 HCmd48
    DT_BOOL, 1, AT_BITPACK, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmd48Ptr, FALSE,                        // 221 HCmd48BT
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmdFailPtr, FALSE,                        // 222 HCmdFail
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHCmdRespPtr, FALSE,                       // 223 HCmdResp
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreHDvMfgCd, 0, GetHDvMfgCdPtr, TRUE,                // 224 HDvMfgCd
    DT_BLIND, 3, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, 0, PostHDevIdCd, GetHDevIdCdPtr, TRUE,              // 225 HDevIdCd
    DT_UINT8, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreHDvTypCd, 0, GetHDvTypCdPtr, TRUE,               // 226 HDvTypCd
    DT_UINT8, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreHDvRevCd, 0, GetHDvRevCdPtr, TRUE,               // 227 HDvRevCd
    DT_UINT8, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreHDdRevCd, 0, GetHDdRevCdPtr, TRUE,               // 228 HDdRevCd
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 229
    DT_BLIND, 50, AT_MBYTE, ALCK_PBD, CONTROLSTATE_NONE, 0, 0, GetHNtfyCfgPtr, TRUE,                        // 230 HNtfyCfg
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 231
    DT_UINT8, 1, AT_SBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                   // 232 HBrdp
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHDynDvcPtr, FALSE,                         // 233 HDynDvc
    DT_ENUM, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetHartVersionPtr, FALSE,                     // 234 HartVersion
#if defined(IOMTYPE_UIO)
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_NONE, PreInitPntType, 0, GetPntTypePtr, FALSE,             // 235 InitPntType
#else
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 235
#endif
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB0_LInvPtr, TRUE,                       // 236 B0_LInv
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB1_LInvPtr, TRUE,                       // 237 B1_LInv
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetOpInternalPtr, FALSE,                   // 238 OpInternal
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetSlotSfLrsPtr, FALSE,                      // 239 SlotSfLrs
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB0_LPtr, TRUE,                          // 240 B0_L
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB1_LPtr, TRUE,                          // 241 B1_L
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB0_OPtr, TRUE,                          // 242 B1_O
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB1_OPtr, TRUE,                          // 243 B1_O
    DT_UINT16, 2, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetOutputDACImgptr, FALSE,                  // 244 OutDACImg 
#if defined(IOPTYPE_AO16)
    // New parameter created which was not existing in PMIO, using to match Legacy Dump Data.
    DT_ENUM, 1, AT_SBYTE, ALCK_SUPR, CONTROLSTATE_NONE, 0, 0, GetPtExecStLrsPtr, FALSE,                     // 245  PTEXECST_LRS
#else
    DT_UINT8, 1, AT_SBYTE, ALCK_IUSER, CONTROLSTATE_NONE, 0, 0, GetSlotChkpntVersionPtr, TRUE,              // 245 SlotChekpointVerNum
#endif    
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetChrc_S0Ptr, FALSE,                      // 246 Chrc_S0
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetChrc_S1Ptr, FALSE,                      // 247 Chrc_S1
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetChrc_S2Ptr, FALSE,                      // 248 Chrc_S2
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetChrc_S3Ptr, FALSE,                      // 249 Chrc_S3
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetChrc_S4Ptr, FALSE,                      // 250 Chrc_S4
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetOTPT_UnusedPtr, TRUE,                      // 251 OTPT_Unused
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB0_InvPtr, TRUE,                        // 252 B0_Inv
    DT_FLOAT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetB1_InvPtr, TRUE,                        // 253 B1_Inv
#if defined(IOMTYPE_UIO)
    DT_BLIND, 124, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, PreCfgRestore, 0, GetCheckPointPtr, TRUE,         // 254 CfgRestore
#else    
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                      // 254
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE                                       // 255
};

/*******************************************************************************
*                            clsAohSlot::operator new                          *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: a_ucSltNm = 0-relative slot number                                *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAohSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
#if defined(IOMTYPE_UIO)
    return (EXTRAM_SLOT_ADDR(a_ucSltNm + 1));
#else
    return (ucIomDbMemory + AOHBOXSLOT_SIZE + (a_ucSltNm * AOHSLOT_SIZE));
#endif
}
/*******************************************************************************
*                            clsAohSlot::clsAohSlot                            *
*                            ======================                            *
* PURPOSE: Constructor of clsAohSlot Class. This calls InitAohSlot which       *
*          initializes clsAohSlot class members.                               *
* ARGUMENTS:                                                                   *
*           a_ucSltNm    -   Slot number                                       *
* RETURN:   NONE                                                               *
* NOTES:    This constructor will internally invokes clsOutSlot class          *
*           constructor.                                                       *
*******************************************************************************/
clsAohSlot::clsAohSlot(UINT8 a_ucSltNm) : HartDevDb(a_ucSltNm,&HartCfgDb,&HartCfgDb7),
    clsOutSlot(PNTTYPE_NOTCONFIGURED,a_ucSltNm) {
    // Do not call full initilization during object construction as
    // the hardare is not setup yet to drive the outputs. Driving the outputs
    // to zero mA is done using the AppInitiazation function.
    InitAohSlot(FALSE,TRUE);
    for (UINT8 ucCount = 0; ucCount < AOHSLOT_SPARESIZE; ucCount++) {
        AohSlotSpare[ucCount] = 0;
    }
}
/*******************************************************************************
*                           clsAohSlot::InitAohSlot                            *
*                           =======================                            *
* PURPOSE: InitAohSlot function which initializes clsAohSlot class members.    *
* ARGUMENTS:                                                                   *
*            bFullInit   - Flag utilised when slots have to be reinitialised   *
*            bObjCreate  - Flag utilised when slots have to be reinitialised   *
* RETURN:    NONE                                                              *
* NOTES:   This function is called when slot parameters                        *
*          need to be reinitialised                                            *
*******************************************************************************/
VOID clsAohSlot::InitAohSlot(BOOL bFullInit, BOOL bObjCreate) {
    OpChar      =  FALSE;
    OpIn0       =  OP_LOLIMIT;
    OpIn1       =  NaN;
    OpIn2       =  NaN;
    OpIn3       =  NaN;
    OpIn4       =  NaN;
    OpIn5       =  OP_HILIMIT;
    OpOut0      =  OP_LOLIMIT;
    OpOut1      =  NaN;
    OpOut2      =  NaN;
    OpOut3      =  NaN;
    OpOut4      =  NaN;
    OpOut5      =  OP_HILIMIT;
    Mode        =  MODE_CASCADE;
    //variable created to skip the readback cycle
    ucSkipLpBkTst = 0;
    bReadBackrequired = TRUE;
    OTPT_Unused =  TRUE;
#if defined(IOMTYPE_UIO)
    ucAoReadBackFailCount = 0;
    ucAoDacFailCount      = 0;
#endif

#if defined (IOPTYPE_AO16)
    // PMIO AO16 non avail param init.
    //Fl_UnPwrd = (FL_UNPWRD)BOX->GetFl_UnPwrd_Bx();
    ModeAppl[0] = FALSE;
    ModeAppl[1] = FALSE;
    ModeAppl[2] = FALSE;
    ModeAppl[3] = FALSE;
    RCasOpt = NONE_RCASOPT;
    Cscd_Rqstd = FALSE;
    RInitReq = TRUE;
    Mode = MODE_NONE; //commented op values not getting update in experion
    PntType = PNTTYPE_ANALOGOUTPUT;
#endif

    if (TRUE == bObjCreate) {
#if !defined (IOMTYPE_UIO)
        B0_L      =  NaN;
        B1_L      =  NaN;
        B0_O      =  NaN;
        B1_O      =  NaN;
#else
        // UIO uses an adjustable reference voltage for calibration rather than a 
        // compensated DAC transfer function, therefore there exists a fixed relationship 
        // between DAC count and OpFinal. That fixed relationship is implemented here.

        //---------------------------------------------------------------------
        // B0_O and B1_O set the relationship between OpFinal and DAC counts
        //      such that OpFinal = (B1_O * DAC) + B0_O

        // B1_O is the slope relating % OpFinal and DAC count
        B1_O = 100.0 / (FPGA.MilliampsToDacCount(20.0) - FPGA.MilliampsToDacCount(4.0));

        // B0_O is OpFinal that correlates with 0x0000 DAC count
        B0_O = -(FPGA.MilliampsToDacCount(4.0) * B1_O);

        //---------------------------------------------------------------------
        // B0_L and B1_L set the relationship between OpFinal and ADC counts
        //      such that OpFinal = (B1_L * ADC) + B0_L.  This is used to 
        //      calculate the expected ADC count for the AO readback diagnostic

        // B1_L is the slope relating % OpFinal and ADC count
        B1_L = 100.0 / (FPGA.MilliampsToAdcCount(20.0) - FPGA.MilliampsToAdcCount(4.0));

        // B0_L is OpFinal that correlates with 0x0000 ADC count
        B0_L = -(FPGA.MilliampsToAdcCount(4.0) * B1_L);
#endif

        //In the linear equation 
        // y = mx+c //y = intercept ;m = slope ;c=offset constant 
        //To update these constants at the initialization
        //from the calibration constants 
        B0_Inv    = -B0_O /B1_O; //output offset compensation
        B1_Inv    = 1/B1_O;//slope offset compensation
        B0_LInv   = -B0_L /B1_L; //loopback offset compensation
        B1_LInv   = 1/B1_L; //loopback slope compensation

        OutDACImg = 0;
        LoopBackDACImg = 0;
        LoopBackStatus = AOLPBK_PASSED;
        ucPassCount = PASSCOUNTMIN;

#if defined(IOPTYPE_AO16)
        Chrc_S0   =  0;
        Chrc_S1   =  0;
        Chrc_S2   =  0;
        Chrc_S3   =  0;
        Chrc_S4   =  0;
        OpInternl =  0;
#else
        Chrc_S0   =  NaN;
        Chrc_S1   =  NaN;
        Chrc_S2   =  NaN;
        Chrc_S3   =  NaN;
        Chrc_S4   =  NaN;
        OpInternl = OP_LOLIMIT;
#endif

        OpFinal   =  OP_LOLIMIT;        
    }

    if (TRUE == bFullInit) {
        BOOL bInitReq = TRUE, bStdByMan = FALSE;
        BOX->SetOp(ChanNum,OP_LOLIMIT);
        BOX->SetInitReq(ChanNum,bInitReq);
        BOX->SetStdbyMan(ChanNum,bStdByMan);
        // this has been moved here, to fix RTPN-1845 & ETNC-16382
#if defined(IOPTYPE_AO16)
	    // fix for PAR# 1-E0EXNH5 & 1-DX7HNEJ
	    OpInternl = OP_LOLIMIT;
	    OpFinal = OP_LOLIMIT;
        // ETNC-16568 fix - reinit with slot0 value during point delete
        FaultOpt = *(FAULTOPT *)BOX->GetFl_UnPwrd_BxPtr();
#endif
    }       
}
/*******************************************************************************
*                            clsAohSlot::GetDataType                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsAohSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsAohSlot::GetAccessType                           *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsAohSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                            clsAohSlot::GetParamSize                          *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAohSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                            clsAohSlot::GetParamPtr                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsAohSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                           clsAohSlot::GetAccessLock                          *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsAohSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                             clsAohSlot::GetOpPtr                             *
*                             ====================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAohSlot::GetOpPtr(VOID) { 
#ifdef IOMTYPE_UIO
    return &(BOX->PvScanRec.ScanRec[ChanNum - 1].AOH.Op);
#else
    return &(BOX->OpScanRec.Op[ChanNum - 1]);
#endif
}

/*******************************************************************************
*                             clsAohSlot::GetInitReqPtr                        *
*                             =========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAohSlot::GetInitReqPtr(VOID) { 
#ifdef IOMTYPE_UIO
    return &(BOX->PvScanRec.initRequest);
#else
    return &(BOX->OpScanRec.InitReq);
#endif
}

/*******************************************************************************
*                             clsAohSlot::GetStdbyManPtr                       *
*                             ==========================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAohSlot::GetStdbyManPtr(VOID) { 
#ifdef IOMTYPE_UIO
    return &(BOX->PvScanRec.ScanRec[ChanNum - 1].AOH.StdByMan);
#else
    return &(BOX->OpScanRec.StdbyMan);
#endif
}

/*******************************************************************************
*                       clsAohSlot::GetIsDbChecksumed                          *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAohSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                         clsAohSlot::VerifyControlState                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
#if defined(IOPTYPE_AO16) && !defined(HART_SUPPORT)        
            return DO_PTEXECST_OR_MODLSTAT_INCONSISTENT;
#else
            return DO_STATE_MUST_BE_RUN;
#endif
        }
        break;
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsAohSlot::ExecutePreFunction                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsAohSlot::ExecutePostFunction                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                            clsAohSlot::PrePntType                            *
*                            ======================                            *
* PURPOSE: Pre Receiver-Beware function for PntType parameter.                 *
*          Validates some pre conditions before the new PntType parameter      *
*          can be written to database.                                         *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesfull                     *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    ScratchPad = PntType; // Save old point type for post function.
    UINT8 MdSts = BOX->GetModuleStatus();

    if ((a_ucAccLvl == ALVL_IUSER) && (MdSts != MODSTATUS_IDLE)) {
        return DO_STATE_MUST_BE_IDLE;
    }

    if ((MdSts != MODSTATUS_IDLE) && (PtExecSt != PTEXECST_INACTIVE)) {
#if defined(IOPTYPE_AO16)
        // PMIO AO16 Redesign check condition
        if ((PNTFORM_FULL == PntForm) || (PNTTYPE_ANALOGOUTPUT != *(PNTTYPE *)a_Writebuffer))
#endif
        return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
    }

#if !defined(IOPTYPE_AO16)
    if (RedTag == REDTAG_ON) {
        return DO_POINT_IS_RED_TAGGED;
    }
#endif

    if (PNTTYPE_ANALOGOUTPUT != *(PNTTYPE *)a_Writebuffer) {
        if (PNTTYPE_NOTCONFIGURED != *(PNTTYPE *)a_Writebuffer) {
            return DO_ILLEGAL_VALUE;
        }
    }
    else {
        if (a_ucAccLvl != ALVL_IUSER) {
            OTPT_Unused = FALSE; 
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAohSlot::PostPntType                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
*           Initializes the slot parameters                    .               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:                                                                      *
*           PA_OK           -   If routine executes successfully               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostPntType(UINT8) {
    if (PNTTYPE_NOTCONFIGURED == PntType) {
        InitSlot(TRUE);

        // if channel got deleted, initialize HART datadatabase
        AbortHartConnection(ChanNum);
        HartDevDb.InitDevDb(TRUE);
        HartCfgDb.InitCfgDb();
        HartCfgDb7.InitCfgDb();
        BOX->InitHGChngFl(ChanNum);
        
#if defined(IOMTYPE_UIO)
        BOX->InitHGCfgChgCnt(ChanNum);
#endif

        HartDevDb.m_bAtLeastOneTry = FALSE;
        
        // if IOM is primary, rebuild scan table and 
        // schedule next scan after 30 seconds.
        UINT8 ucDsa = BOX->GetDSA();
        if ((ucDsa > 0) && (ucDsa <= MAXDSA)) {
            HartDevDb.BuildScanTable();
            HartDevDb.m_sScanCounter = TICKS_IN_30_SEC;
        }
        
#if defined(IOMTYPE_UIO)
        //--------------------------------------------
        // Delete the configured slot
        //--------------------------------------------          
        UIO_SLOT(ChanNum)->DeleteConfiguredSlot();
#endif
    BOX->ResetHADCEnable(ChanNum);
    }
    else {
        InitSlot(FALSE);

        if (TRUE == BOX->GetHAutoDet(ChanNum)) {
            BOX->ResetHAutoDet(ChanNum);
            BOX->SetOp(ChanNum,OP_LOLIMIT);
        }
    }
}
/*******************************************************************************
*                            clsAohSlot::PrePtExecSt                           *
*                            =======================                           *
* PURPOSE:   Pre Receiver-Beware function for PtExecSt parameter.              *
*            Validates some pre conditions before the new PtExecSt parameter   *
*            can be written to database.                                       *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           status          -   Return PA_OK if pre check is succesfull        *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PrePtExecSt(UINT8 *a_Writebuffer,UINT8) {
    const UINT8 CHRC_PARM_COUNT = 5;
    UINT8 ucIndex = 0;
    PASTATUS status = PA_OK;
    FLOAT32 *pChrcParm = NULL;
     
    ScratchPad = PtExecSt; // Save current execution state for post function.

    if (*(PTEXECST *)a_Writebuffer > PTEXECST_ACTIVE)
        return DO_LIMIT_OR_RANGE_EXCEEDED;

#if !defined(IOMTYPE_UIO)
    if ((*(PTEXECST *)a_Writebuffer == PTEXECST_ACTIVE) && (BOX->GetHADCEnable(ChanNum)))
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
#endif

    //If the point execution state is active and output characterization is enabled 
    //validate the input and output characterization point
    if ((*(PTEXECST *)a_Writebuffer == PTEXECST_ACTIVE) && (TRUE == OpChar)) {
        pChrcParm = &(this->OpIn1);
        for (ucIndex=1;ucIndex < CHRC_PARM_COUNT;ucIndex++) {
            if (isnan(*pChrcParm++)) status = DO_CONFIGURATION_MISMATCH_ERROR;
        }
         
        pChrcParm = &(this->OpOut1);
        for (ucIndex=1;ucIndex < CHRC_PARM_COUNT;ucIndex++) {
            if (isnan(*pChrcParm++)) status = DO_CONFIGURATION_MISMATCH_ERROR;
        }
    }

    if (status != PA_OK) return status;

    // For HART enabled channels, make sure that only two channels with 
    // dedicated modems will be activated at a time. This change was brought
    // in while adding HART modem diagnostic for fixing the PAR 1-2EDL2L.
    //
    // NOTE: UIO does not support 1-second channels
#if !defined(IOMTYPE_UIO)
    if ((TRUE == HartCfgDb.HEnable) && 
        ((HSCANCFG_1SECDEV == HartCfgDb.HScanCfg) ||
         (HSCANCFG_1SECDYN == HartCfgDb.HScanCfg) ||
         (HSCANCFG_2SECDEVDYN == HartCfgDb.HScanCfg))) {
        if ((PTEXECST_INACTIVE == PtExecSt) &&
            (PTEXECST_ACTIVE == *(PTEXECST *)a_Writebuffer)) {
            // channel is getting activated
            if (clsHartDevDb::GetNoOf1SecChannels() >= MAX_1SEC_CHANNELS) {
                return DO_MAX_CONNECTIONS_EXCEEDED;
            }
            clsHartDevDb::Increment1SecChannels();
        }
        else if ((PTEXECST_ACTIVE == PtExecSt) &&
                 (PTEXECST_INACTIVE == *(PTEXECST *)a_Writebuffer)) {
            // channel is getting inactivated
            clsHartDevDb::Decrement1SecChannels();
        }
    }
#endif
    return PA_OK;
}
/*******************************************************************************
*                            clsAohSlot::PostPtExecSt                          *
*                            ========================                          *
* PURPOSE:  Post Receiver-Beware function for PtExecSt parameter.              *
* ARGUMENTS                                                                    *
*           a_ucAccLvl      -   Access level for check                         *
*:                                                                             *
* RETURN:                                                                      *
*           PA_OK           -   On Successful execution                        *
* NOTES:                                                                       *
*           Need to Add additional functionality later                         *
*******************************************************************************/
VOID clsAohSlot::PostPtExecSt(UINT8) {
    UINT8 MdSts = BOX->GetModuleStatus();

    //Perform back initialization 
    if ((PtExecSt == PTEXECST_ACTIVE) && (MdSts == MODSTATUS_RUN)) {
        if (TRUE == OpChar) {
            //compute characterization slopes
            Chrc_S0 = (OpOut1 - OpOut0) / (OpIn1 - OpIn0);
            Chrc_S1 = (OpOut2 - OpOut1) / (OpIn2 - OpIn1);
            Chrc_S2 = (OpOut3 - OpOut2) / (OpIn3 - OpIn2);
            Chrc_S3 = (OpOut4 - OpOut3) / (OpIn4 - OpIn3);
            Chrc_S4 = (OpOut5 - OpOut4) / (OpIn5 - OpIn4);
        }
        /*
        Steps to Perform:
        ----------------
        1. Get the DAC Count value stored in the Database parameter 
        2. Convert the DAC Count to Float Value 
        3. Check if the Converted Float value needs zero clamping and clamp the 
         Op_Final value to -6.9
        */
        //Populate the database with output values after reading across channels
        BackInit();
    }

    CmptInitReq();

    if ((PTEXECST)ScratchPad != PtExecSt) { // point execution state changed
        HartDevDb.ControlStateChange();
        ResetLpBkPassCount();
    }
}
/*******************************************************************************
*                               clsAohSlot::PreOp                              *
*                               =================                              *
* PURPOSE: Pre Receiver-Beware function for Op parameter.                      *
*          Validates some pre conditions before the new Op parameter           *
*          is written to database.                                             *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           status          -  Returns PA_OK On Successful execution           *
* NOTES:                                                                       *
*           Need to Add some additional functionality later                    *
*                                                                              *
*******************************************************************************/
PASTATUS clsAohSlot::PreOp(UINT8 *a_Writebuffer,UINT8 a_ucAccLvl) {
    PASTATUS status = PA_OK;
    UINT8 ucRange_status = WITHIN_RANGE;
    BOOL bStdbyMan = BOX->GetStdbyMan(ChanNum); 
    FLOAT32  OpVal = *(FLOAT32 *) a_Writebuffer;

#if defined(IOPTYPE_AO16)  
    // for redesign PMIO, if FTA missing or Slot fails with no standbyman
    if ((BOX->GetFtaPres() == FALSE) || ((SlotSfBt != 0) && (!bStdbyMan)))
        return DO_INITIALIZATION_ERROR;  

#else
    // For UIO, soft failure check will done at end of this function.
    // This behavoiur is different from SC AOH or AO.
#if !defined(IOMTYPE_UIO)
    //Check if any slot failure bit is active
    if((SlotSfBt!=0) && (!bStdbyMan) && (!((Mode==MODE_MANUAL)&&(ModeAttr==MODEATTR_OPERATOR)))) {
        status = DO_INITIALIZATION_ERROR;
        return status;
    }
#endif

#endif //#if defined(IOPTYPE_AO16)

    if (isnan(OpVal))
#if defined(IOPTYPE_AO16) && !defined(HART_SUPPORT)
        return DO_ILLEGAL_VALUE;
#else
        status = DO_ILLEGAL_VALUE;
#endif
    //Apply range check 
    if (OpVal > OP_HILIMIT)
        ucRange_status = OVER_RANGE;
    else if (OpVal < OP_LOLIMIT)
        ucRange_status = UNDER_RANGE;

#if defined(IOPTYPE_AO16)
    // for redesign PMIO AO16
    // (StandbyMan OR (CtlDead AND COMP_PNTFORM))
    if ((bStdbyMan) || (!(BOX->GetCtlWasAlive()) && (PNTFORM_COMPONENT == PntForm)))  
#endif

    if(a_ucAccLvl & ALCK_ONPROC_IUSER) {
        if (ucRange_status != WITHIN_RANGE)
            status = DO_ILLEGAL_VALUE;
    }

    if ((Iol.AmPrimary() == FALSE) && (BOX->GetRedState() >= REDSTATE_SYNCD)) {
        // if the module is secondary and synced with the primary
        if ((MODE_CASCADE != Mode) && (BOX->IsPrimaryChannelInFail(ChanNum) == TRUE)) {
            // Reject the write if mode is not cascade and primary channel in softfail
            TraceLog.AddToTrace(TRACEID_GENERIC,bcPriChanInFail,ChanNum);
            return DO_INITIALIZATION_ERROR;
        }
    }

    if (RedTag) 
        status = DO_POINT_IS_RED_TAGGED;
    else { 
        if (LocalMan)
            status = DO_INITIALIZATION_ERROR;
        else {
            switch (Mode) {
                case MODE_MANUAL:
                    switch (ModeAttr) {
                        case MODEATTR_OPERATOR:
                            //if ENGR or SUPERV or OPER (HumanLock)
                            if (a_ucAccLvl & ALCK_ONPROC) {
                                if(ucRange_status != WITHIN_RANGE)
                                    status = DO_LIMIT_OR_RANGE_EXCEEDED;
                            }
                            else if (ALVL_IUSER == a_ucAccLvl)
                                status = ClampWithWarning(a_Writebuffer, ucRange_status);
                            else { 
#if defined(IOPTYPE_AO16) && !defined(HART_SUPPORT)
                                // to fix the sync issue (leg & new module write response diff) when a point has been written by CM_Reg in MAN mode with wrong ACCLVL
                                status = DO_INVALID_MODE_ATTRIBUTE;
#else
                                status = DO_ACCESS_LEVEL_INVALID;
#endif
                            }
                            break;
                        case MODEATTR_PROGRAM:
                            if (ALVL_PROG == a_ucAccLvl) {
                                status = ClampWithWarning(a_Writebuffer, ucRange_status);
                            }
                            else 
                                status = DO_ACCESS_LEVEL_INVALID;
                            break;
                        default:
                            status = DO_INVALID_MODE_ATTRIBUTE;
                        }
                    break;
                case MODE_CASCADE:
#if !defined(IOPTYPE_AO16)
                    if (FALSE == bStdbyMan) {
                            if ((ALVL_UMCC != a_ucAccLvl) && (ALVL_CC != a_ucAccLvl))
                                status = DO_ACCESS_LEVEL_INVALID;
                            else {
                                status = ClampWithWarning(a_Writebuffer, ucRange_status);
                            }
                        }
                    break;
#else
                    // disabled due to op values not updating in experion
                    // for redesign PMIO AO16
                    if (((TRUE == bStdbyMan) && (ALCK_ONPROC & a_ucAccLvl))
                     ||((FALSE == bStdbyMan) && (ALVL_CC != a_ucAccLvl) && (ALVL_UMCC != a_ucAccLvl)))
                    {
                        status = DO_INVALID_MODE;
                    }
                    else
                    {
                        status = ClampWithWarning(a_Writebuffer, ucRange_status);
                    }
                    break;
                case MODE_NONE:
                    status = (ALVL_UMCC != a_ucAccLvl) ? DO_CONFIGURATION_MISMATCH_ERROR :
                                                       ClampWithWarning(a_Writebuffer, ucRange_status);                    
                    break;
#endif
                default:
                    status = DO_INVALID_MODE;
             }
        }//Else loop =>LocalMan not set
    }//Else loop =>Point is not Red Tagged


#if defined(IOMTYPE_UIO)
    //Check if any slot failure bit is active
    if((SlotSfBt!=0) && (!bStdbyMan) && (!((Mode==MODE_MANUAL)&&(ModeAttr==MODEATTR_OPERATOR)))) 
    {
        // In case of UIO, update OP value to the database(but not to the screws) even
        // soft failure exists on the slot before returning error. This is to avoid sync
        // ver checksum mismatch if only secondary module has soft failure.
        BOX->SetOp(ChanNum, OpVal, FALSE);

        //Save OP_REAL to OP_INTERNAL to compute SYNC_VER.The OPInternal parameter
        //will not be updated for period b/w dump complete and sync complete 
        if(FALSE == BOX->GetbDisOpInternlUpdteSts())
        {
            OpInternl = OpVal;
        }

        status = DO_INITIALIZATION_ERROR;
    }
#endif

    return status;
}
/*******************************************************************************
*                               clsAohSlot::PostOp                             *
*                               ==================                             *
* PURPOSE:  Post Receiver-Beware function for Op parameter.                    *
*           Process the Op Parameter and updates the Final Output              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   On successful execution                        *
* NOTES:                                                                       *
*           To Add additional functionality                                    *
*******************************************************************************/
VOID clsAohSlot::PostOp(UINT8) {
    FLOAT32 OpVal = BOX->GetOp(ChanNum);
    
#if !defined(IOMTYPE_UIO)
    //The Current output channel is in use so can run some diagnostics    
    OTPT_Unused = FALSE;
#endif

    //Save OP_REAL to OP_INTERNAL to compute SYNC_VER.The OPInternal parameter
    //will not be updated for period b/w dump complete and sync complete 
    if(FALSE == BOX->GetbDisOpInternlUpdteSts()){
        OpInternl = OpVal;
    }
    UpdateOpFinal(OpVal);
    if ((HART_AUTODETECT_OP > OpVal) || (TRUE != HartCfgDb.HEnable))
        BOX->SetHADCStatus(ChanNum,HART_DATA_UNKNOWN);
    else if ((HART_DATA_UNKNOWN == BOX->GetHADCStatus(ChanNum)) && (TRUE == HartCfgDb.HEnable))
        BOX->SetHADCStatus(ChanNum,HART_DATA_PENDING);

#if defined(IOMTYPE_UIO)
    MODSTAT3 modStat3;
    modStat3.BYTE = BOX->GetModStat3();
    
    // Don't mark the output as used until roles are stable and the 
    // OP has been written.
    if (((OUTCTL_PARTNER == modStat3.OutCtl) && (!Iol.AmPrimary())) || 
        ((OUTCTL_MINE == modStat3.OutCtl) && (Iol.AmPrimary())))
    {
        OTPT_Unused = FALSE;
    }
#endif

}
/*******************************************************************************
*                               clsAohSlot::postOpChar                         *
*                               ======================                         *
* PURPOSE:    Post Receiver-Beware function for Opchar parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   On successful execution                        *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostOpChar(UINT8) {
//If characterization is not enabled,assign initial values to characterization
// points
    if (FALSE  == OpChar) {
        OpIn0 = OP_LOLIMIT;
        OpIn1 = NaN;
        OpIn2 = NaN;
        OpIn3 = NaN;
        OpIn4 = NaN;
        OpIn5 = OP_HILIMIT;
        OpOut0   = OP_LOLIMIT;
        OpOut1   = NaN;
        OpOut2   = NaN;
        OpOut3   = NaN;
        OpOut4   = NaN;
        OpOut5   = OP_HILIMIT;
    }
}
/*******************************************************************************
*                               clsAohSlot::ChrcBkwrd                          *
*                               =====================                          *
* PURPOSE:   This function returns the original value of Op based on the       *
*             characterization table from the output value                     *
* ARGUMENTS:                                                                   *
*              OpVal - Output value read across the  channel                   *
* RETURN:                                                                      *
*             Returns a float value                                            *
* NOTES                                                                        *
*              This function is used by BackInit to calculate original         *
*              uncharacterized Op from the output value read across IOM channel*
*******************************************************************************/
FLOAT32 clsAohSlot::ChrcBkwrd(FLOAT32 OpVal) {
    FLOAT32 OpIn, OpOut, Slope;
    if (OpVal == OpOut0) 
        return OpIn0;

    if (OpVal <= OpOut1) {
        OpIn  = OpIn0;
        OpOut = OpOut0;
        Slope = Chrc_S0;
    }
    else if (OpVal <= OpOut2) {
        OpIn  = OpIn1;
        OpOut = OpOut1;
        Slope = Chrc_S1;
    }
    else if (OpVal <= OpOut3) {
        OpIn  = OpIn2;
        OpOut = OpOut2;
        Slope = Chrc_S2;
    }
    else if (OpVal <= OpOut4) {
        OpIn  = OpIn3;
        OpOut = OpOut3;
        Slope = Chrc_S3;
    }
    else if (OpVal <= OpOut5) {
        OpIn  = OpIn4;
        OpOut = OpOut4;
        Slope = Chrc_S4;
    }
    return (OpVal - OpOut) / Slope + OpIn;
}
/*******************************************************************************
*                               clsAohSlot::ChrcFrwrd                          *
*                               =====================                          *
* PURPOSE: This function returns the characterized value of Op based           *
*          on the characterization table                                       *
* ARGUMENTS:                                                                   *
*              OpVal - Output value read across the  channel                   *
* RETURN:                                                                      *
*             Returns a float value                                            *
* NOTES:                                                                       *
*          This function is called from postOp method.                         *
*******************************************************************************/
FLOAT32 clsAohSlot::ChrcFrwrd(FLOAT32 OpVal) {
    FLOAT32 OpIn, OpOut, Slope;
    if (OpVal == OpIn0) 
        return OpOut0;

    if (OpVal <= OpIn1) {
        OpIn  = OpIn0;
        OpOut = OpOut0;
        Slope = Chrc_S0;
    }
    else if (OpVal <= OpIn2) {
        OpIn  = OpIn1;
        OpOut = OpOut1;
        Slope = Chrc_S1;
    }
    else if (OpVal <= OpIn3) {
        OpIn  = OpIn2;
        OpOut = OpOut2;
        Slope = Chrc_S2;
    }
    else if (OpVal <= OpIn4) {
        OpIn  = OpIn3;
        OpOut = OpOut3;
        Slope = Chrc_S3;
    }
    else if (OpVal <= OpIn5) {
        OpIn  = OpIn4;
        OpOut = OpOut4;
        Slope = Chrc_S4;
    }
    return (OpVal - OpIn) * Slope + OpOut;
}
/*******************************************************************************
*                               clsAohSlot::ChrcPntBnds                        *
*                               =======================                        *
* PURPOSE: Checks the values of the charcterization points to be within range  *
                                                                               *
* ARGUMENTS:                                                                   *
*             *ufDataPtr    -  Current value of the characterization point     *
*             NewVal        -  New value of the characterization point         *
*             a_ucAccLvl    -  Access level for check                          *
* RETURN:                                                                      *
*           PA_OK           -   On successful execution                        *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::ChrcPntBnds(FLOAT32 *ufDataPtr, FLOAT32 NewVal, UINT8 a_ucAccLvl) {
    if(ufDataPtr == NULL) return DO_ILLEGAL_VALUE;
    FLOAT32 OldVal = *ufDataPtr;
    if ((a_ucAccLvl == ALVL_IUSER) && RealCompare(NewVal,OldVal))
        return PA_OK;
    else {
        if (FALSE == OpChar) return DO_PARAMETER_INVALID;
        if (isnan(NewVal))  return DO_ILLEGAL_VALUE;
        if ((NewVal < OP_LOLIMIT) || (NewVal > OP_HILIMIT))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        ufDataPtr--;
        if ((! isnan(*ufDataPtr)) && (NewVal < *ufDataPtr))
            return DO_CONFIGURATION_MISMATCH_ERROR;

        ufDataPtr++; ufDataPtr++;
        if ((! isnan(*ufDataPtr)) && (NewVal > *ufDataPtr))
            return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    return PA_OK;
}
/*******************************************************************************
*                               clsAohSlot::preOpIn1                           *
*                               ====================                           *
* PURPOSE:   Pre Receiver-Beware function for OpIn1 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn1    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
             Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpIn1(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpIn1, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::preOpIn2                           *
*                               ====================                           *
* PURPOSE:   Pre Receiver-Beware function for OpIn2 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn2    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpIn2(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpIn2, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::preOpIn3                           *
*                               ====================                           *
* PURPOSE:   Pre Receiver-Beware function for OpIn3 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn3    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpIn3(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpIn3, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::preOpIn4                           *
*                               ====================                           *
* PURPOSE:   Pre Receiver-Beware function for OpIn4 parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpIn4    *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpIn4(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpIn4, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::preOpOut1                          *
*                               =====================                          *
* PURPOSE:    Pre Receiver-Beware function for OpOut1 parameter.               *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut1   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpOut1(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpOut1, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::preOpOut2                          *
*                               =====================                          *
* PURPOSE:   Pre Receiver-Beware function for OpOut2 parameter.                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut2   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpOut2(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpOut2, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::preOpOut3                          *
*                               =====================                          *
* PURPOSE:    Pre Receiver-Beware function for OpOut3 parameter.               *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut3   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpOut3(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpOut3, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::preOpOut4                          *
*                               =====================                          *
* PURPOSE:   Pre Receiver-Beware function for OpOut4 parameter.                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the characterization point OpOut4   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            Returns the status returned from the routine ChrcPntBnds          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreOpOut4(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    return ChrcPntBnds(&OpOut4, *(FLOAT32*)a_Writebuffer, a_ucAccLvl);
}
/*******************************************************************************
*                               clsAohSlot::PostOptDir                         *
*                               ======================                         *
* PURPOSE:    Post Receiver-Beware function for OptDir parameter.              *
* ARGUMENTS:                                                                   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK           -   On successful execution                       *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostOptDir(UINT8) {
    BackInit();
}
/*******************************************************************************
*                               clsAohSlot::PreMode                            *
*                               ===================                            *
* PURPOSE:    Pre Receiver-Beware function for Mode parameter.                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of Mode                                *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK           -   On successful execution                       *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreMode(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    BOOL ReqstdNrml = FALSE;

#if defined(IOPTYPE_AO16)
    // PMIO AO16 Redesign check condition
    if (PNTFORM_COMPONENT == PntForm)
    {
        if ((*(MODE *)a_Writebuffer != Mode) || (ALVL_IUSER != a_ucAccLvl))
            return DO_PARAMETER_INVALID;
        //else, it is a checkpoint write so accept with no further checks.
    }
    else {
        // Full Point Form Configuration
#endif
        if ((a_ucAccLvl == ALVL_OPER) && (ModePerm != MODEPERM_PERMIT))
            return DO_CHANGE_NOT_PERMITTED_BY_OPERATOR;

        if (REDTAG_ON == RedTag)
            return DO_POINT_IS_RED_TAGGED;

        if ((a_ucAccLvl == ALVL_PROG) && (ModeAttr != MODEATTR_PROGRAM)) {
            //Program changing the value
            return DO_INVALID_MODE_ATTRIBUTE;
        }        

#if defined(IOPTYPE_AO16)
        // PMIO AO16 Redesign check condition
        if ((MODE_AUTO    == (*(MODE *)a_Writebuffer))
         || (MODE_BCAS    == (*(MODE *)a_Writebuffer))
         || (MODE_NONE    == (*(MODE *)a_Writebuffer))
         || (MODE_CASCADE == (*(MODE *)a_Writebuffer) && (NONE_RCASOPT == RCasOpt)))            
#else
        if ((MODE_MANUAL  != (*(MODE *)a_Writebuffer)) &&
            (MODE_CASCADE != (*(MODE *)a_Writebuffer)) &&
            (MODE_NORMAL  != (*(MODE *)a_Writebuffer)))
#endif
        return DO_ILLEGAL_VALUE;

        if (((*(MODE *)a_Writebuffer) == MODE_NORMAL) && (NMode == MODE_NONE))
            return DO_NORMAL_MODE_IS_NOT_CONFIGURED;

        if ((*(MODE *)a_Writebuffer) == MODE_NORMAL) {
            ReqstdNrml = TRUE;
            *(MODE *)a_Writebuffer = (MODE)NMode;
        }

#if defined(IOPTYPE_AO16)
        // added as like in PMIO firmware

        Cscd_Rqstd = FALSE;

        if ((MODE_NONE != NMode) && ((MODE)NMode != *(MODE *)a_Writebuffer) && (a_ucAccLvl == ALVL_PROG))
            NMode = *(MODE *)a_Writebuffer;
        
        // if new value is cascade mode & acc level is not continous control, flag a cascad requested, & force no change in current mode.        
        if ((MODE_CASCADE == *(MODE *)a_Writebuffer) && (a_ucAccLvl != ALVL_CC))
        {
            Cscd_Rqstd = TRUE;
            *(MODE *)a_Writebuffer = Mode;
        }
#endif
        if (ReqstdNrml && (NModeAttr != MODEATTR_NONE))
            ModeAttr = (MODEATTR)NModeAttr;
        else if (a_ucAccLvl & ALCK_ONPROC)
            ModeAttr = MODEATTR_OPERATOR;

#if defined(IOPTYPE_AO16)
        // Full Point Form Configuration end bracket
    }
#endif

    return PA_OK;
}
/*******************************************************************************
*                               clsAohSlot::PostMode                           *
*                               ====================                           *
* PURPOSE:    Post Receiver-Beware function for Mode parameter.                *
* ARGUMENTS:                                                                   *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK           -   On successful execution                       *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostMode(UINT8) {
    CmptInitReq();
}
/*******************************************************************************
*                               clsAohSlot::PreNMode                           *
*                               ====================                           *
* PURPOSE:    Pre Receiver-Beware function for NMode parameter.                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the NMode parameter                 *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/

#if !defined(IOPTYPE_AO16)
PASTATUS clsAohSlot::PreNMode(UINT8 * a_Writebuffer, UINT8) {
#else
// PMIO AO16 Redesign beware func
PASTATUS clsAohSlot::PreNMode(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    if (PNTFORM_COMPONENT == PntForm)
    {
        if (((MODE)NMode != *(MODE *)a_Writebuffer) || (a_ucAccLvl != ALVL_IUSER))
            return DO_PARAMETER_INVALID;
        //else, write is part of checkpoint restore, let it pass.
    }
    else {
        // Full point form configuration,
        if ((MODE_CASCADE == *(MODE *)a_Writebuffer) && (NONE_RCASOPT == RCasOpt))
            return DO_ILLEGAL_VALUE; 
#endif

        if ((*(MODE *)a_Writebuffer) > MODE_CASCADE)
#if !defined(IOPTYPE_AO16)
            return DO_LIMIT_OR_RANGE_EXCEEDED;
#else
            // for nMode = AUTO / BCAS / NORMAL,
            return DO_ILLEGAL_VALUE;
#endif

        if (MODE_NONE == (*(MODE *)a_Writebuffer))
            NModeAttr = MODEATTR_NONE;

#if defined(IOPTYPE_AO16)
        // Full point config, end bracket
    }
#endif

    return PA_OK;
}
/*******************************************************************************
*                               clsAohSlot::PreNModAttr                        *
*                               =======================                        *
* PURPOSE:   Pre Receiver-Beware function for NModeAttr parameter.             *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the NModeAttr                       *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
#if !defined(IOPTYPE_AO16)
PASTATUS clsAohSlot::PreNModeAttr(UINT8 * a_Writebuffer, UINT8) {

    if ((*(MODEATTR *)a_Writebuffer) > MODEATTR_NORMAL)
        return DO_LIMIT_OR_RANGE_EXCEEDED;

#else
// PMIO AO16 Redesign beware func
PASTATUS clsAohSlot::PreNModeAttr(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    if (PNTFORM_COMPONENT == PntForm)
    {
        if ((*(MODE *)a_Writebuffer != NModeAttr) || (ALVL_IUSER != a_ucAccLvl))
            return DO_PARAMETER_INVALID;
        //else, it is a checkpoint write so accept with no further checks.
    }
    else {
        // full point form configuration,
#endif        
        if ((*(MODEATTR *)a_Writebuffer) == MODEATTR_NORMAL)
            return DO_ILLEGAL_VALUE;

        if ((MODE_NONE == NMode) && (NModeAttr != (*(MODEATTR *)a_Writebuffer)))
            return DO_NORMAL_MODE_IS_NOT_CONFIGURED;

#if defined(IOPTYPE_AO16)
        // full point config, end bracket
    }
#endif

    return PA_OK;
}
/*******************************************************************************
*                          clsAohSlot::PostNModeAttr                            *
*                          ========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostNModeAttr(UINT8) {
    if(MODEATTR_NORMAL == NModeAttr) {
        ModeAttr = (MODEATTR) NModeAttr;
        Mode = (MODE) NMode;
    }
}
/*******************************************************************************
*                               clsAohSlot::PreModePerm                        *
*                               =======================                        *
* PURPOSE:    Pre Receiver-Beware function for ModePerm parameter.             *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the ModePerm                        *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
#if !defined(IOPTYPE_AO16)
PASTATUS clsAohSlot::PreModePerm(UINT8 * a_Writebuffer, UINT8) {

    if ((*(MODEPERM *)a_Writebuffer) > MODEPERM_PERMIT)
        return DO_LIMIT_OR_RANGE_EXCEEDED;
#else
// PMIO AO16 Redesign beware func.
PASTATUS clsAohSlot::PreModePerm(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {

    if (PNTFORM_COMPONENT == PntForm)
    {
        if ((*(MODE *)a_Writebuffer != ModePerm) || (ALVL_IUSER != a_ucAccLvl))
            return DO_PARAMETER_INVALID;
        //else, it is a checkpoint write so accept with no further checks.
    }

#endif

    return PA_OK;
}
/*******************************************************************************
*                               clsAohSlot::preModAttr                         *
*                               =======================                        *
* PURPOSE:    Pre Receiver-Beware function for ModeAttr parameter.             *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the ModeAttr                        *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreModeAttr(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
#if defined(IOPTYPE_AO16)
    if (PNTFORM_COMPONENT == PntForm)
    {
        if ((*(MODE *)a_Writebuffer != ModeAttr) || (ALVL_IUSER != a_ucAccLvl))
            return DO_PARAMETER_INVALID;
        //else, it is a checkpoint write so accept with no further checks.
    }
    else {
        // Full Point Form Configuration
#endif

        if (REDTAG_ON == RedTag)
            return DO_POINT_IS_RED_TAGGED;

        if ((a_ucAccLvl == ALVL_OPER) && (ModePerm != MODEPERM_PERMIT))
            return DO_CHANGE_NOT_PERMITTED_BY_OPERATOR;

        if ((*(MODEATTR *)a_Writebuffer) == MODEATTR_NONE)
            return DO_ILLEGAL_VALUE;

#if !defined(IOPTYPE_AO16)
        if (((*(MODEATTR *)a_Writebuffer) < MODEATTR_OPERATOR) ||
            ((*(MODEATTR *)a_Writebuffer) > MODEATTR_NORMAL))
            return DO_LIMIT_OR_RANGE_EXCEEDED;
#endif

        if ((*(MODEATTR *)a_Writebuffer) == MODEATTR_NORMAL) {
            if (NModeAttr == MODEATTR_NONE)
                return DO_NORMAL_ATTRIBUTE_NOT_CONFIGURED;
            else
                (*(MODEATTR *)a_Writebuffer) = (MODEATTR)NModeAttr;
        }
        else {
            if ((a_ucAccLvl == ALVL_PROG) && (NModeAttr != MODEATTR_NONE))
                NModeAttr = (*(MODEATTR *)a_Writebuffer);
        }
#if defined(IOPTYPE_AO16)
        // full point config, end bracket
    }
#endif

    return PA_OK;
}
/*******************************************************************************
*                        clsAohSlot::PreFaultValue                             *
*                        ========================                              *
* PURPOSE:  Pre Receiver-Beware function for FaultOpt parameter.               *
*           This method checks for range of the data that can be written to    *
*           FaultOpt parameter.                                                *
*                                                                              *
* ARGUMENTS:a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the FaultValue parameter       *
* RETURN:   PA_OK           -   If check is successfull                        *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreFaultValue(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    // Get the value of FaultValue in local variable
    FLOAT32 ufFaultVal = *(FLOAT32 *)a_Writebuffer;
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(FLOAT32 *)a_Writebuffer) == FaultValue))
        return PA_OK;

    if (FAULTOPT_FAULTVALUE != FaultOpt) {
        return DO_PARAMETER_INVALID;
    }
 
    if (isnan(ufFaultVal))
        return DO_ILLEGAL_VALUE;
/*
    if (!(a_ucAccLvl & ALCK_PBD)) {
        return DO_ACCESS_LEVEL_INVALID;
    }
    else {
*/
    if ((ufFaultVal > OP_HILIMIT) || (ufFaultVal < OP_LOLIMIT))
        return DO_LIMIT_OR_RANGE_EXCEEDED;
 
//    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAohSlot::PreFaultOpt                            *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for FaultOpt parameter.               *
*           This method checks for range of the data that can be written to    *
*           FaultOpt parameter.                                                *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the FaultState parameter       *
* RETURN:                                                                      *
*           PA_OK           -   If check is successfull                        *
* NOTES:    This method enables to write either HOLD,UNPOWER,FAULTVALUE        * 
*           values only                                                        *
*******************************************************************************/
PASTATUS clsAohSlot::PreFaultOpt(UINT8 *a_Writebuffer, UINT8) {
    FAULTOPT eFaultOpt =  (*(FAULTOPT *)a_Writebuffer);

    //Validate the fault option set by the user 
    if ((eFaultOpt != FAULTOPT_HOLD) &&
        (eFaultOpt != FAULTOPT_UNPOWERED) &&
        (eFaultOpt != FAULTOPT_FAULTVALUE))
        return DO_ILLEGAL_VALUE;

    return PA_OK;
}
/*******************************************************************************
*                          clsAohSlot::PostFaultOpt                            *
*                          ========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostFaultOpt(UINT8) {
    if (FAULTOPT_FAULTVALUE != FaultOpt) {
        FaultValue = OP_LOLIMIT;
    }
    // PAR #1-DVN1QBM fix - FaultOpt param is using instead of Fl_UnPwrd param in legacy.
    *(FL_UNPWRD *)BOX->GetFl_UnPwrd_BxPtr() = (FL_UNPWRD) FaultOpt;
}
/*******************************************************************************
*                               clsAohSlot::PreRedTag                          *
*                               =======================                        *
* PURPOSE:   Pre Receiver-Beware function for RedTag parameter                 *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the RedTag                          *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -  On successful execution                          *
* NOTES:                                                                       *
* Currently not used,in case FULL Point Support is added in future include     *
* this routine after additions to FULL point mode handling                     *
*******************************************************************************/
PASTATUS clsAohSlot::PreRedTag(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
#if defined(IOPTYPE_AO16)
    if (PNTFORM_COMPONENT == PntForm)
    {
        if ((RedTag != *(REDTAG *)a_Writebuffer) || (ALVL_IUSER != a_ucAccLvl))
            return DO_PARAMETER_INVALID;
        //else, Write is part of a checkpoint restore so allow it.
    }    
    else {
        // Full point form configuration,  
        if (!(a_ucAccLvl & ALCK_ENG_SUP_IUSER))
            return DO_ACCESS_LEVEL_INVALID;

        if (REDTAG_ON == (*(REDTAG *)a_Writebuffer)) {

            if (MODE_MANUAL != Mode)
                return DO_MODE_MUST_BE_MANUAL;

            if (MODEATTR_OPERATOR != ModeAttr)
                return DO_INVALID_MODE_ATTRIBUTE;
            else
                Cscd_Rqstd = FALSE;
        }             
    }

#else
        if (ALVL_IUSER == a_ucAccLvl)
        return PA_OK;

        if ((*(REDTAG *)a_Writebuffer) == REDTAG_ON) {
#if !defined(IOMTYPE_UIO)
            if (BOX->GetHADCEnable(ChanNum))
                return DO_PRIOR_FUNCTION_NOT_COMPLETE;
#endif
            if (a_ucAccLvl & ALCK_ONPROC) {
                if (MODE_MANUAL != Mode)
                    return DO_MODE_MUST_BE_MANUAL;
                if (MODEATTR_OPERATOR != ModeAttr)
                    return DO_INVALID_MODE_ATTRIBUTE;
            }
            else if ((ALVL_UMCC == a_ucAccLvl) || (ALVL_CC == a_ucAccLvl))
            {
                if (MODE_CASCADE != Mode)
                    return DO_INVALID_MODE;
            }
            else
                return DO_ACCESS_LEVEL_INVALID;
        }
        if (((*(REDTAG *)a_Writebuffer) < REDTAG_OFF)
         || ((*(REDTAG *)a_Writebuffer) > REDTAG_ON))
            return DO_ILLEGAL_VALUE;

        Cscd_Rqstd = FALSE;        
#endif

    return PA_OK;
}

#if defined(IOPTYPE_AO16)
// PMIO AO16 Redesign non available parameters beware functions
/*******************************************************************************
*                               clsAohSlot::PostFl_UnPwrd                      *
*                               =======================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
// PAR #1-DVN1QBM fix - FaultOpt param is using instead of Fl_UnPwrd param in legacy.
//VOID clsAohSlot::PostFl_UnPwrd(UINT8)
//{
//    *(FL_UNPWRD *)BOX->GetFl_UnPwrd_BxPtr() = Fl_UnPwrd;
//}
/*******************************************************************************
*                               clsAohSlot::PostPntForm                        *
*                               =======================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostPntForm(UINT8)
{
    if (PNTFORM_FULL == PntForm)
    {
        Mode = MODE_MANUAL;
        ModeAttr = MODEATTR_OPERATOR;
        ModeAppl[0] = TRUE; // manual mode applicable because full point form.
        ModeAppl[1] = FALSE;
        ModeAppl[2] = FALSE;
        ModeAppl[3] = FALSE;
    }
}
/*******************************************************************************
*                               clsAohSlot::PreRCasOpt                         *
*                               =======================                        *
* PURPOSE:   Pre Receiver-Beware function for RCasOpt parameter                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the RedTag                          *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -  On successful execution                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreRCasOpt(UINT8 * a_Writebuffer, UINT8 a_ucAccLvl) {
    
    if (PNTFORM_COMPONENT == PntForm)
    {        
        // ALVL_ENGR comparison added to resolve, PAR# 1-7KEO0U1
        if ((*(RCASOPT *)a_Writebuffer != RCasOpt) || ((ALVL_IUSER != a_ucAccLvl) && (ALVL_ENGR != a_ucAccLvl)))
        {
            return DO_PARAMETER_INVALID;
        }
    }
    // full point form,
    else if ((SPC_RCASOPT == *(RCASOPT *)a_Writebuffer) ||
             (RSP_RCASOPT == *(RCASOPT *)a_Writebuffer) ||
          (DDCRSP_RCASOPT == *(RCASOPT *)a_Writebuffer))
    {
        return DO_ILLEGAL_VALUE;
    }
    else if (MODE_MANUAL != Mode)
    {
        return DO_MODE_MUST_BE_MANUAL;
    }
   
    return PA_OK;
}
/*******************************************************************************
*                               clsAohSlot::PostRCasOpt                        *
*                               =======================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::PostRCasOpt(UINT8)
{
    if (NONE_RCASOPT == RCasOpt)
    {
        Cscd_Rqstd = FALSE;
        ModeAppl[3] = FALSE; // cascade mode false

        if (MODE_CASCADE == NMode)
        NMode = MODE_MANUAL;        
    }
    else
    {
        ModeAppl[3] = TRUE; // cascade mode true
    }

    ModeAppl[0] = TRUE; // manual mode applicable because full point form.
    ModeAppl[1] = FALSE;
    ModeAppl[2] = FALSE;
}
/*******************************************************************************
*                               clsAohSlot::PreCscd_Rqstd                      *
*                               =========================                      *
* PURPOSE:   Pre Receiver-Beware function for RCasOpt parameter                *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  New value of the RedTag                          *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -  On successful execution                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreCscd_Rqstd(UINT8 *, UINT8) {
    if ((PNTFORM_COMPONENT == PntForm) || (DDC_RCASOPT != RCasOpt))
        return DO_PARAMETER_INVALID;
    return PA_OK;
}

#endif //#if defined(IOPTYPE_AO16)

/*******************************************************************************
*                               clsAohSlot::InitSlot                           *
*                               ====================                           *
*  Initialize the entire channel database. Calls the Init function for each    *
*  class in the channel object hierarchy and recompute database checksum.      *
*******************************************************************************/
VOID clsAohSlot::InitSlot(BOOL bBldInit) {
    BOOL bObjCreate = FALSE; 

#if !defined(IOMTYPE_UIO)
    if (TRUE == bBldInit) {
        // If this is a active 1-second HART channel, decrement the static
        // 1-second channel counter as InitIoSlot will be inactivating the
        // channel without calling PostPtExecSt(). This step is required to 
        // cover the scenario where the C300 and IOM database got out-of-sync. 
        // Two examples are:
        // IOMSTATE is IDLE, there is a one 1-second channel in ACTIVE state.
        // 1) IOL communication is lost and then channel configurtion is force 
        //    deleted from C300. Subsequently IOL communication is restord and
        //    channel is reloaded.
        // 2) C300 is rebooted in NODB state (after a ntsetup or failure) and
        //    channel configuration is reloaded.
        if ((TRUE == HartCfgDb.HEnable) && 
            (PTEXECST_ACTIVE == PtExecSt) &&
            ((HSCANCFG_1SECDEV == HartCfgDb.HScanCfg) ||
             (HSCANCFG_1SECDYN == HartCfgDb.HScanCfg) ||
             (HSCANCFG_2SECDEVDYN == HartCfgDb.HScanCfg))) {
            clsHartDevDb::Decrement1SecChannels();
        }

    }
#endif
    clsIoSlot::InitIoSlot(PntType, bBldInit, bObjCreate);
    clsOutSlot::InitOutSlot(PntType, bBldInit, bObjCreate);
    InitAohSlot(bBldInit, bObjCreate);
    ComputeCheckSum(); // Recompute SLOT checksum
}
/*******************************************************************************
*                            clsAohSlot::InactivateSlot                        *
*                            ==========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::InactivateSlot(VOID) {
    PostPtExecSt(0);
}
/*******************************************************************************
*                               clsAohSlot::CmptInitReq                        *
*                               =======================                        *
* PURPOSE:                                                                     *
*            Computes the value of InitReq and RInitReq                        *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::CmptInitReq(VOID) {
    BOOL bInitReq = FALSE;

    bInitReq = ((PtExecSt == PTEXECST_INACTIVE) ||
                (BOX->GetModuleStatus() != MODSTATUS_RUN) || 
                (SlotSfBt)|| (BOX->GetStdbyMan(ChanNum)) ||
#if defined(IOPTYPE_AO16)
                // for redesign PMIO, check for NONE_MODE & FTA Presence also
                (MODE_NONE != Mode)  ||
                !(BOX->GetFtaPres()) ||
#else
                (MODE_CASCADE != Mode) ||
#endif
                (FAULTSTATE_FAULTED == FaultState));

    BOX->SetInitReq(ChanNum, bInitReq);

#if defined(IOPTYPE_AO16)
    // for redesign PMIO, Update RInitReq with CAS_MODE checking as like in Series C
    RInitReq = ((PtExecSt == PTEXECST_INACTIVE) ||
                (BOX->GetModuleStatus() != MODSTATUS_RUN) ||        
                (BOX->GetStdbyMan(ChanNum)) ||
                (BOX->GetFtaPres() != TRUE) ||
                (SlotSfBt) ||
                (MODE_CASCADE != Mode) ||
                (FAULTSTATE_FAULTED == FaultState));
#endif
}
/*******************************************************************************
*                               clsAohSlot::ClampWithWarning                   *
*                               ============================                   *
* PURPOSE:   Checks the Range of the Output parameter to be within range and   *
*            clamps to the lower and upper limit if boundary is crossed        *
* ARGUMENTS:                                                                   *
*            *a_Writebuffer-  Output value                                     *
*            a_ucAccLvl    -  Access level for check                           *
* RETURN:                                                                      *
*            PA_OK         -   On successful execution                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::ClampWithWarning(VOID *a_Writebuffer,UINT8 ucRange_status) {
    switch (ucRange_status) {
    case UNDER_RANGE:
        *(FLOAT32 *) a_Writebuffer = OP_LOLIMIT;
        return DO_VALUE_CLAMPED_ERROR;
    case OVER_RANGE:
        *(FLOAT32 *) a_Writebuffer =  OP_HILIMIT;
        return DO_VALUE_CLAMPED_ERROR;
    default:
        return PA_OK;
    }
}
/*******************************************************************************
*                               clsAohSlot::BackInit                           *
*                               ====================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::BackInit() {
    FLOAT32 fBackInitOp;

    if (OutDACImg <= MINCURRENT_OUTPUT_DACCOUNT) {
        fBackInitOp = OP_LOLIMIT;
    }
    else {
        fBackInitOp = ((FLOAT32)OutDACImg - B0_Inv) / B1_Inv;
    }
    
    if (fBackInitOp <= OP_LOLIMIT) OpFinal = OP_LOLIMIT;
    else if (fBackInitOp >= OP_HILIMIT) OpFinal = OP_HILIMIT;
    else OpFinal = fBackInitOp;

    if (TRUE == OpChar) { 
        fBackInitOp = ChrcBkwrd(fBackInitOp);
    }

    if (OPTDIR_REVERSE == OptDir) {
        fBackInitOp = ((FLOAT32) 100.0) - fBackInitOp;
    }
    
    BOX->SetOp(ChanNum,fBackInitOp,TRUE);
}
/*******************************************************************************
*                      clsAohSlot::SlotFaultHandler                            *
*                      ============================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::SlotFaultHandler(TOG_FAILED a_TogFailed) {
    // If RedTag is ON for this channel do nothing...
    if (REDTAG_ON == RedTag) {
        return;
    }

    // Do not shed the output if only control tog failed
    // and the ouput is in manual-operator control.
    if ((CTLTOG_FAILED == a_TogFailed) && 
        (MODE_MANUAL == Mode) && (MODEATTR_OPERATOR == ModeAttr)) {
        return;
    }

    FaultState = FAULTSTATE_FAULTED; // Mark the slot as faulted.
    CmptInitReq();

#if defined(IOMTYPE_UIO)
    // primary and secondary modules share the output screws. When
    // the secondary enters the faulted state, its outputs must go
    // unpowered to avoid disrupting the primary's the control
    if (!Iol.AmPrimary()) {
        // secondary
        BOX->SetOp(ChanNum, OP_LOLIMIT);
    }
    else
#endif
    {
        switch (FaultOpt) {
        case FAULTOPT_HOLD:
            break;
        case FAULTOPT_FAULTVALUE:
            BOX->SetOp(ChanNum,FaultValue);
            break;
        case FAULTOPT_UNPOWERED:
            BOX->SetOp(ChanNum,OP_LOLIMIT);
            break;
         default:
            break;
        }
    }
}
/*******************************************************************************
*                        clsAohSlot::UpdateOpFinal                             *
*                        =========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohSlot::UpdateOpFinal(FLOAT32 a_fOp) 
{
    if(FAULTSTATE_FAULTED != FaultState){
        if (OPTDIR_REVERSE == OptDir) a_fOp = (FLOAT32)100.0 - a_fOp;
        if (TRUE == OpChar) a_fOp =  ChrcFrwrd(a_fOp);
    }
    // Save the current OutDACImg for computing loopback test time.
    UINT16 uiLastOutDACImg = OutDACImg;

    if (a_fOp <= OP_LOLIMIT) {
        OpFinal = OP_LOLIMIT;
        OutDACImg = 0;
        LoopBackDACImg = 0;

#if LOWCOST
    // For low cost AO, even if we drive zero count some offset current
    // will flow.To avoid this, disable the output drive of DAC. 
        AoHardware.DisableOutputDrive(ChanNum);
#endif
    }
    else {
        OpFinal   = (a_fOp >= OP_HILIMIT) ? OP_HILIMIT : a_fOp;

#if LOWCOST
    // If the prevoius output DAC count is zero, 
    // enable the output drive of the DAC.         
       if(OutDACImg == 0)
       AoHardware.EnableOutputDrive(ChanNum);            
#endif
        OutDACImg = (B1_Inv * OpFinal) + B0_Inv;
        LoopBackDACImg =  (B1_LInv * OpFinal) + B0_LInv;
    }

    // Compute loopback test time.
    uiLastOutDACImg = (uiLastOutDACImg > OutDACImg) ? (uiLastOutDACImg - OutDACImg)
                                                    : (OutDACImg - uiLastOutDACImg);
                                                    
    //If the differance b/w subsequent op's was more 
    //than 50% skip donot readback for 2 cycles 
    if(uiLastOutDACImg > BOX->GetDac50Percent()){
        ucSkipLpBkTst = 2;
    }
    else
        ucSkipLpBkTst = 0;

    bReadBackrequired = FALSE;
#if defined(IOMTYPE_UIO)
    FPGA.WriteAnalogOutput(ChanNum, OutDACImg);
#else
    AoHardware.DriveOutput(ChanNum);
#endif
}

#if !defined(IOMTYPE_UIO)
/*******************************************************************************
*                        clsAohSlot::DoLoopbackTest                            *
*                        ==========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
AOLPBKSTS clsAohSlot::DoLoopbackTest(UINT16 a_uiDacCount) {
    AoHardware.OpenLoopbackMux(ChanNum,TRUE);
    // If output is at zero current, both OutDACImg and LoopBackDACImg are zero.
    // There is a possibility that the +4% check may fail as (LoopBackDACImg + 
    // a_uiDacCount) may not enough to drive the comparator input to produce a 
    // high output. So preadd MINCURRENT_LOOPBACK_DACCOUNT.
    if (0 == LoopBackDACImg) a_uiDacCount += MINCURRENT_LOOPBACK_DACCOUNT;

    // Check and do +4% comparison.
    if ((LoopBackDACImg + a_uiDacCount) < MAXCURRENT_LOOPBACK_DACCOUNT) {
#if !LOWCOST
        AoHardware.DriveDac(LoopBackDACImg + a_uiDacCount);
#else
        AoHardware.DriveDac((LoopBackDACImg + a_uiDacCount),READBACK_DAC_ADDR);
        IdleWait(COMPARATOR_SETTLE_TIME); // Wait before reading comparator output
#endif
        if (FALSE == AoHardware.ReadComparatorOutput()) { // Loopback test failed
            AoHardware.CloseLoopbackMux(ChanNum);
            ucPassCount = PASSCOUNTMAX;
            LoopBackStatus = AOLPBK_HITESTFAIL;
            return LoopBackStatus;
        }
    }

    // Check and do -4% comparison
    if (LoopBackDACImg > (MINCURRENT_LOOPBACK_DACCOUNT + a_uiDacCount)) {
#if !LOWCOST
        AoHardware.DriveDac(LoopBackDACImg - a_uiDacCount);
#else
        AoHardware.DriveDac((LoopBackDACImg - a_uiDacCount),READBACK_DAC_ADDR);
        IdleWait(COMPARATOR_SETTLE_TIME); // Wait before reading comparator output
#endif
        if (TRUE == AoHardware.ReadComparatorOutput()) { // Loopback test failed
            AoHardware.CloseLoopbackMux(ChanNum);
            ucPassCount = PASSCOUNTMAX;
            LoopBackStatus = AOLPBK_LOTESTFAIL;
            return LoopBackStatus;
        }
    }
    // Both tests passed.
    AoHardware.CloseLoopbackMux(ChanNum);
    ucPassCount -= 1;
    if (ucPassCount == PASSCOUNTMIN-1) {
        ucPassCount = PASSCOUNTMIN;
        LoopBackStatus = AOLPBK_PASSED;
    }
    else LoopBackStatus = AOLPBK_LOTESTFAIL;
    return LoopBackStatus;
}
/*******************************************************************************
*                            ComputeCalibrationConstants                       *
*                            ===========================                       *
* PURPOSE: To compute the constants for calibration                            *
*                                                                              *
* ARGUMENTS: Slope and Offset values                                           *
* RETURN: TRUE is succseful, FALSE otherwise                                   *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsAohSlot::ComputeCalibrationConstants(FLOAT32 a_fB1Val, FLOAT32 a_fB0Val)
{
    clsAohBoxSlot *pBox = BOX;
    BOOL bFieldCalib    = pBox->IsFieldCalib();

    if(bFieldCalib) {
        if(a_fB0Val >= -21.0) {
          //Calibration Abort 
          pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
          return FALSE;
        }
    }
    //Drive 4mA Low DAC value and get the equivalent current
    OutDACImg = FOUR_MA_L_OUTPUT_DACCOUNT;
    AoHardware.DriveOutput(ChanNum,CalibrationWithExtendedDelay);
    FLOAT32 Count4mA_L = pBox->DoSuccessiveApproximation();
    FLOAT32 Current4mA_L = a_fB1Val * Count4mA_L + a_fB0Val;
    //Drive 4mA High DAC value and get the equivalent current
    OutDACImg = FOUR_MA_H_OUTPUT_DACCOUNT;
    AoHardware.DriveOutput(ChanNum,CalibrationWithExtendedDelay);
    FLOAT32 Count4mA_H = pBox->DoSuccessiveApproximation();
    FLOAT32 Current4mA_H = a_fB1Val  * Count4mA_H + a_fB0Val;
    //Compute the slope at 4mA by m = (y2-y1)/(x2-x1).
    FLOAT32 Slope_4mA = NaN;
    if (Current4mA_H > Current4mA_L) {
        Slope_4mA = ((Current4mA_H - Current4mA_L) / 
            (FOUR_MA_H_OUTPUT_DACCOUNT - FOUR_MA_L_OUTPUT_DACCOUNT));
    }
    else {
        return FALSE;
    }
    //Compute the offset at 4mA by c = y1 - mx1
    FLOAT32 Offset_4mA= Current4mA_L - Slope_4mA * FOUR_MA_L_OUTPUT_DACCOUNT;
    //TBD : Use a ceil() function to get the DAC Count
    UINT16  CalcDacCount_4mA = (UINT16)((0 - Offset_4mA) / Slope_4mA);
    if(0 != (CalcDacCount_4mA & 0xF000)) {
       pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
       return FALSE;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,ChanNum);
    //Now get the approximated current value for 4mA
    OutDACImg = CalcDacCount_4mA;
    AoHardware.DriveOutput(ChanNum,CalibrationWithExtendedDelay);
    FLOAT32 Current_4mA = a_fB1Val * pBox->DoSuccessiveApproximation() + a_fB0Val;
    UINT16 LpbkDacCount_4mA = 0;
    if(!bFieldCalib) //Only for factory
        //Get the internal loopback reading of 4mA we just drove
        LpbkDacCount_4mA = GetInternalReading();
    //Repeat the above procedure for 20mA
    //Drive 20mA Low DAC value and get the equivalent current
    OutDACImg = TWENTY_MA_L_OUTPUT_DACCOUNT;
    AoHardware.DriveOutput(ChanNum,CalibrationWithExtendedDelay);
    FLOAT32 Count20mA_L = pBox->DoSuccessiveApproximation();
    FLOAT32 Current20mA_L = a_fB1Val * Count20mA_L + a_fB0Val;
    //Drive 20mA High DAC value and get the equivalent current
    OutDACImg = TWENTY_MA_H_OUTPUT_DACCOUNT;
    AoHardware.DriveOutput(ChanNum,CalibrationWithExtendedDelay);
    FLOAT32 Count20mA_H = pBox->DoSuccessiveApproximation();
    FLOAT32 Current20mA_H = a_fB1Val  * Count20mA_H + a_fB0Val;
    //Compute the slope at 20mA by m = (y2-y1)/(x2-x1).
    FLOAT32 Slope_20mA = NaN;
    if (Current20mA_H > Current20mA_L) {
        Slope_20mA = ((Current20mA_H - Current20mA_L) / 
                      (TWENTY_MA_H_OUTPUT_DACCOUNT - TWENTY_MA_L_OUTPUT_DACCOUNT));
    }
    else {
        return FALSE;
    }
    //Compute the offset at 4mA by c = y1 - mx1
    FLOAT32 Offset_20mA= Current20mA_L - Slope_20mA * TWENTY_MA_L_OUTPUT_DACCOUNT;
    //TBD : Use a ceil() function to get the DAC Count
    UINT16  CalcDacCount_20mA = (UINT16)((100 - Offset_20mA) / Slope_20mA);
    if(0 != (CalcDacCount_20mA & 0xF000)) {
       pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
       //return FALSE;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,ChanNum);

    //Now get the approximated current value for 4mA
    OutDACImg = CalcDacCount_20mA;
    AoHardware.DriveOutput(ChanNum,CalibrationWithExtendedDelay);
    FLOAT32 Current_20mA = a_fB1Val * pBox->DoSuccessiveApproximation() + a_fB0Val;
    UINT16 LpbkDacCount_20mA = 0;
    //Now get the internal loopback reading of 20mA we just drove
    if(!bFieldCalib) //Only for factory
        LpbkDacCount_20mA = GetInternalReading();
    //Checking for open-wire. Ideally Current_20mA should be 100%. 
    //If it is less than 95 it is an open-wire
    if(Current_20mA <= 95.0) {
        //Calibration Abort 
        pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,TRUE,ChanNum);
        //return FALSE;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
    // Compute the external input calibration constants for this channel
    // Slope = (y2-y1)/(x2-x1),Offset = y1-mx1
    B1_O = (Current_20mA - Current_4mA) / 
           (CalcDacCount_20mA - CalcDacCount_4mA);
    B0_O = Current_4mA - (B1_O * CalcDacCount_4mA);
    // Compute the internal input calibration constants for this channel
    // Slope = (y2-y1)/(x2-x1),Offset = y1-mx1
    AOCALIBDATA *pData = BOX->GetCalibDataPtr();
    FLOAT32 fNormalizedB1 = 0;
    FLOAT32 fNormalizedB0 = 0;
    if(bFieldCalib) {
        fNormalizedB1 = a_fB1Val / pData->FactorySlope;
        fNormalizedB0 = a_fB0Val - pData->FactoryOffset;
    }
    else {
        FLOAT32 fB1_I = (Current_20mA - Current_4mA) / 
                (LpbkDacCount_20mA - LpbkDacCount_4mA);
        FLOAT32 fB0_I = Current_4mA - (fB1_I * LpbkDacCount_4mA);
        if(fB0_I >= -21.0) {
          //Calibration Abort 
          pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,ChanNum);
          return FALSE;
        }
        fNormalizedB1 = fB1_I / a_fB1Val;
        fNormalizedB0 = fB0_I - a_fB0Val;
    }
    pBox->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,ChanNum);
    //Store the constants in the EEPROM image in RAM to burn in flash later
    UINT8 ucIndex = (ChanNum - 1) << 2;
    pData->CalibConstants[ucIndex++] = B1_O;
    pData->CalibConstants[ucIndex++] = B0_O;
    pData->CalibConstants[ucIndex++] = fNormalizedB1;
    pData->CalibConstants[ucIndex]   = fNormalizedB0;
    return TRUE;
}
/*******************************************************************************
*                              GetInternlReading                               *
*                              =================                               *
* PURPOSE: To get the loopback value for the forward driven current for this   *
*          channel                                                             *
* ARGUMENTS: None.                                                             *
* RETURN: The DAC count corresponding to current                               *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
UINT16 clsAohSlot::GetInternalReading() {
    //Close the already open loopback channel
    AoHardware.CloseLoopbackMux(SNSCAL1_OFFSET);
    AoHardware.OpenLoopbackMux(ChanNum,TRUE);
    UINT16 DacCount = (UINT16)BOX->DoSuccessiveApproximation();
    AoHardware.CloseLoopbackMux(ChanNum);
    AoHardware.OpenLoopbackMux(SNSCAL1_OFFSET,TRUE); 
    return DacCount;
}
/***************************************************************************************
*                           clsAihSlot::Hart7Dump                                      *
*                           ==========================                                 *
* When primary does not support HART 7 and secondary support HART 7                    *
* and IO is swapped, then HART 7 parameters will have inconsistent values.             *
* This function is used for initialising the HART 7 parameters after dump is completed.* 
***************************************************************************************/
VOID clsAohSlot::Hart7Dump (VOID) {
    HartCfgDb7.HDvTypCd7[1] = HartCfgDb.HDvTypCd;
    for(UINT8 ucItr=0;ucItr < HART6_MAXVAR_COUNT;ucItr++) {
        HartCfgDb7.HSlotDvc7[ucItr] = HartCfgDb.HSlotDvc[ucItr];
    }

    //Initialize HSLOTDVC[4..7] values to invalid parameter code(None)

    for(UINT8 ucItr=HART6_MAXVAR_COUNT;ucItr < HART_MAXVAR_COUNT;ucItr++) {
      HartCfgDb7.HSlotDvc7[ucItr] = HART_INVALID_PARAMETER_CODE;
    }
    HartCfgDb7.HDvMfgCd7[1] = HartCfgDb.HDvMfgCd;
}

#endif // !defined(IOMTYPE_UIO)

#if defined(IOMTYPE_UIO)

/*******************************************************************************
*                          clsAohSlot::DoReadBackTest                          *
*                              =================                               *
* PURPOSE:   Compares the ADC readback of the AO channel against the expected  *
*            ADC count to verify the AO does not have an output fail.          *
* ARGUMENTS: a_uiAdcCount - ADC count from the hardware                        *
* RETURN:    AOLPBK_PASSED - readback is within expected range                 *
*            AOLPBK_HITESTFAIL - readback is out of range (high)               *
*            AOLPBK_LOTESTFAIL - readback is out of range (low)                *
* NOTES:                                                                       *
*******************************************************************************/
AOLPBKSTS clsAohSlot::DoReadBackTest(UINT16 a_uiAdcCount)
{
    // Test for +/-4% of full scale range (0xFFFF)
    // +/-4% tolerence is defined by HW team 

    // 25mA over a scale of FFFF ADCcounts ==> 0.38uA/ADCcount
    // +/-4.0% tolerance ==> 1mA ==> 2631 counts ==>0xA47
    const UINT16 kReadbackTolerance = 0xA47;

    // check if the readback is too high
    if ((a_uiAdcCount > (LoopBackDACImg + kReadbackTolerance)) && (LoopBackDACImg != 0))
    {    
        LoopBackStatus = AOLPBK_HITESTFAIL;
    }

    // if not too high, check for too low
    else if ((a_uiAdcCount < (LoopBackDACImg - kReadbackTolerance)) && (LoopBackDACImg != 0))
    {
        LoopBackStatus = AOLPBK_LOTESTFAIL;
    }

    else
    {
        LoopBackStatus = AOLPBK_PASSED;
    }

    return LoopBackStatus;
}

/*******************************************************************************
*                         clsAihSlot::GetSlotChkPntParamId                     *
*                           ==============================                     *
* PURPOSE:                                                                     *
*   Checks to see if the given parameter code is for the checkpoint /          *
*   configuration restore parameter.                                           *
* ARGUMENTS:                                                                   *
*   a_ucParamNumber - Parameter code to check                                  *
* RETURN:                                                                      *
*   TRUE if the given parameter code is for checkpoint / configuration restore *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsAohSlot::GetSlotChkPntParamId(VOID)
{
    return PARAMID_SLTCHKPNT;
}

/*******************************************************************************
*                          clsAihSlot::GetPtExecStParamId                      *
*                           =============================                      *
* PURPOSE:                                                                     *
*   Returns the parameter code for the point execution state parameter.        *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   Parameter code for the point execution state parameter                     *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsAohSlot::GetPtExecStParamId(VOID)
{
    return PARAMID_PTEXECST;
}

/*******************************************************************************
*                      clsAihSlot::GetLatestSlotChkPntVersion                  *
*                       =====================================                  *
* PURPOSE:                                                                     *
*   Returns the latest slot checkpoint version number                          *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   Latest slot checkpoint version number                                      *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsAohSlot::GetLatestSlotChkPntVersion(VOID)
{
    return LATEST_SLTCHKPNT_VERSION;
}


/*******************************************************************************
*                          clsAohSlot::PreInitPntType                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
*   This methods checks to see if the InitPntType parameter can be written     *
*   to the slot.                                                               *
* ARGUMENTS:                                                                   *
*   a_WriteBuffer - Pointer to data for the InitPntType parameter              *
*   a_ucAccLvl    - Access level of the InitPntType parameter.                 *
* RETURN:                                                                      *
*   Returns PA_OK if the parameter can be written.                             *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
PASTATUS clsAohSlot::PreInitPntType(UINT8 *a_Writebuffer, UINT8)
{
    // Value of the parameter being written
    PNTTYPE valueBeingWritten = *(PNTTYPE *)a_Writebuffer;

    // Return Value (assume failure)
    PASTATUS rtnValue = DO_ILLEGAL_VALUE;
    
    // If the value being written is PNTTYPE_ANALOGOUTPUT,
    // allow the store to occur.
    if (valueBeingWritten == PNTTYPE_ANALOGOUTPUT) 
    {
        rtnValue = PA_OK;
    }

    return rtnValue;
}

#endif

BOOL clsAohSlot::IsOutputNotViable(UINT8 ucParamId) 
{
    // Return TRUE only for OP param write in MAN mode with Operator
    // attribute and if there is any softfail on slot.
    if (ucParamId != PARAMID_OP) return FALSE;
    if ((SlotSfBt != 0) && (!((Mode == MODE_MANUAL) && (ModeAttr == MODEATTR_OPERATOR)))) return TRUE;
    return FALSE;
}


/*******************************************************************************
*                              ResetLpBkPassCount                              *
*                              ==================                              *
* PURPOSE: Reset loopback pass count to PASSCOUNTMIN, so that loop back        *
           diagnostics is restarted when PTEXECST is changed from INACTIVE     *
           to ACTIVE or module status is changed from IDLE to RUN.             *
*                                                                              *
* ARGUMENTS: None.                                                             *
* RETURN: None                                                                 *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
VOID clsAohSlot::ResetLpBkPassCount(VOID) {
    UINT8 MdSts = BOX->GetModuleStatus();

    if((PtExecSt == PTEXECST_ACTIVE) && (MdSts == MODSTATUS_RUN))
    {
        ucPassCount = PASSCOUNTMIN;
    }
}

