
/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihboxslot.cpp                                              *
*    Description : Class clsclsAihBoxSlot definition.                          *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aihmain.h"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsAdc Adc;
extern clsIol Iol;
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_VREFFAIL,
#if !LOWCOST
    SF_ADOUTUDF,
    SF_OPENWIRE,
#else
    SF_ADC_SUPPLY_FAIL,
    SF_ADC_REG_WR_FAIL,
#endif
    SF_BADRJVAL,
    SF_HARTCHANFAIL,
    SF_ADCINCOMPLETE,
    SF_ADC_OVERFLOW,
    SF_UNKNOWN
};

const UINT8 clsAihBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};

#if !defined(IOPTYPE_HLAI)
const UINT8 clsAihBoxSlot::CheckPointVer2[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};
const CHECKPOINT_VER_TABLE clsAihBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 3 },
    { CheckPointVer2, 3 }
};
#else
// PMIO HLAI Redesign
const UINT8 clsAihBoxSlot::CheckPointVer2[] = {    
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsAihBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 3 },
    { CheckPointVer2, 2 }
};

// PMIO HLAI dump param order (since pmio param order is diff from series c)
const UINT8  clsAihBoxSlot::PmioDumpParamTbl[] = {
    PARAMID_MODSTAT1,
    PARAMID_DBVALID,
    PARAMID_PVSCAN,
    0 // Terminator
};

#if defined(HART_SUPPORT)
const UINT8 clsBoxSlot::IopDesc[] = "HLAIH   ";
#else
const UINT8 clsBoxSlot::IopDesc[] = "HLAI    ";
#endif

#endif

UINT8 clsAihBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

const UINT8 clsAihBoxSlot::RedParams[] = {
    PARAMID_IOLDEVTYPE,
    PARAMID_MODLTYPE,
    PARAMID_DBVALID,
    PARAMID_SFACTNTBL,
#if !defined(IOPTYPE_HLAI)
    PARAMID_MAXSLOTS,
#endif
    0 // Terminator
};

const BOXPARAMINFO clsAihBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       // 03 ModStatType
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      // 35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   // 37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          // 38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          // 39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          // 40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          // 41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          // 43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      // 44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    // 45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           // 47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       // 48 AppBuildNo
#if defined(IOPTYPE_HLAI)
    DT_BLIND, 22, AT_PSET, ALCK_VIEW, 0, 0, GetIomDtlPtr, FALSE,                    // 49 IOMDTL
    DT_BLIND, 10, AT_PSET, ALCK_VIEW, 0, 0, GetIolSupPtr, FALSE,                    // 50 IOL_SUP
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 50   
#endif
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       // 51 BoxSfBits 
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        // 52 BoxSfLrs 
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       // 53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          // 54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         // 55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              // 56 Dpa
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              // 57 Dsa
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      // 58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      // 59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               // 60 Ba
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                // 61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         // 62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        // 63 HwRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,TRUE,                        // 64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          // 65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            // 66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,PreModStat1,PostModStat1,GetModStat1Ptr,TRUE,    // 67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         // 68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,TRUE,                           // 69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              // 70 Nth
#if defined(IOPTYPE_HLAI)
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetSuperCtrlPtr, FALSE,                 // 71 SUPER_CTRL        
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 71
#endif
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     // 72 SwRevCode
#if defined(IOPTYPE_HLAI)
    DT_UINT16, 2, AT_MBYTE, ALCK_IUSER, 0, 0, GetToknStallPtr, FALSE,               // 73 TOKN_STALL
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 73
#endif
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     // 74 TstFunct
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        // 75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          // 76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,PostRedData,GetRedDataPtr,FALSE,      // 77 RedData
#if defined(HART_SUPPORT)
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,PostDbValid,GetDbValidPtr,TRUE,                 // 78 DbValid
#else
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           // 78 DbValid
#endif
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,PostSfActionTbl,GetSfActionTblPtr,FALSE,      // 79 SfActionTbl
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,PreCalibAll,PostCalibAll,GetCalibAllPtr,FALSE,      // 80 CalibAll
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 81
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 82
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 101
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 102
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 103
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 104
    DT_BLIND,96,AT_MBYTE,ALCK_VIEW,0,0,GetPvScanRecPtr,FALSE,                       // 105 PvScanRec
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 112
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetLpBkStatPtr,FALSE,                         // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 114
#if defined(IOPTYPE_HLAI)
    DT_STRG, 8, AT_MBYTE, ALCK_VIEW, 0, 0, GetIopDescPtr, FALSE,                    // 115 IOPDESC (for redesign PMIO)
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 115
#endif
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                         // 116 MaxSlots
#if defined(IOPTYPE_HLAI)
    DT_FLOAT32, 4, AT_MBYTE, ALCK_EPB, 0, 0, GetBxLimit1Ptr, FALSE,                 // 117 BX_LIMIT_1
    DT_FLOAT32, 4, AT_MBYTE, ALCK_EPB, 0, 0, GetBxLimit2Ptr, FALSE,                 // 118 BX_LIMIT_2
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 118
#endif    
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 120
#if defined(IOPTYPE_HLAI)
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 121 // no parm for non HART HLAI
#else
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetHGCfgChgCntPtr,FALSE,                     // 121 HGCFGCHG
#endif
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHGChngFlPtr,FALSE,                        // 122 HGChngFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 123
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetHCuAvailPtr,FALSE,                       // 124 HCuAvail
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 134
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHGDevStPtr,FALSE,                         // 135 HGDevSt
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 142
    DT_BLIND,3,AT_PSET,ALCK_VIEW,PreCheckPoint,0,GetCheckPointPtr,TRUE,             // 143 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 152
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,PreHADCEnable,PostHADCEnable,GetHADCEnablePtr,FALSE,// 153 HADCEnable
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHADCStatusPtr,FALSE,                       // 154 HADCStatus
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 156
#if defined(IOPTYPE_HLAI)
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, 0, 0, GetPvsGoodPtr, FALSE,                    // 157 PVSGOOD
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 157
#endif
    DT_BLIND,34,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                        // 158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     // 160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostStatReset,GetStatResetPtr,FALSE,  // 161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       // 165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     // 166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      // 167 TraceLevel
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 169
    DT_UINT8,1,AT_SBYTE,ALCK_OPER,PreCPLDRegData,PostCPLDRegData,GetCPLDRegDataPtr,FALSE,// 170 CPLDRegData
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 242
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         // 255
};

/*******************************************************************************
*                          clsAihBoxSlot::clsAihBoxSlot                        *
*                          ============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsAihBoxSlot::clsAihBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType,MAXSLOTS){
    // Initialize data members.
    PpxChannel  = 1; // Start with channel 1.
    for (UINT8 ucSlot = 0; ucSlot < MAXSLOTS; ucSlot++) {
        PvScanRec[ucSlot].Pv        = 0.0;
        PvScanRec[ucSlot].PvSts     = PVVALST_BAD;
        PvScanRec[ucSlot].Sequence  = 0;
    }

    CalibAll        = FALSE;
    CalibrationGood = FALSE;
    BoardType       = BOARDTYPE_UNKNOWN;
    CalibData.f5VRefHiLimit      = NaN;
    CalibData.f5VRefLoLimit      = NaN;
#if !LOWCOST
    CalibData.fCalibrationSlope  = NaN;
    CalibData.fCalibrationOffset = NaN;
    for (UINT8 ucSlot = 0; ucSlot < MAXSLOTS; ucSlot++) {
        CalibData.fChannelZeroDrift[ucSlot] = NaN;
        HADCEnable[ucSlot] = FALSE;
        HADCStatus[ucSlot] = HART_DATA_PENDING;
        AdcCycleCount[ucSlot] = 0;
        HGChngFl[ucSlot] = 0;
#if defined(IOPTYPE_HLAI)
        SlwSrcBuff[ucSlot] = NaN;        
#endif
    }
#else   // LOWCOST
    CalibData.spare1  = NaN;
    CalibData.spare2 = NaN;
    for (UINT8 ucSlot = 0; ucSlot < MAXSLOTS; ucSlot++) {
        CalibData.fCalibrationSlope[ucSlot] = NaN;
        CalibData.fCalibrationOffset[ucSlot] = NaN;
        HADCStatus[ucSlot] = HART_DATA_NOT_AVAILABLE;
        HGChngFl[ucSlot] = 0;
    }

    // If EEPROM is not mounted, Load the default constants. 
    CalibrationGood = TRUE;
    CalibData.f5VRefHiLimit = LCOST_FIVE_VOLT_HILIMIT;  
    CalibData.f5VRefLoLimit = LCOST_FIVE_VOLT_LOLIMIT;  
    for (UINT8 ucSlotNum=0; ucSlotNum<MAXSLOTS; ucSlotNum++) {
        CalibData.fCalibrationSlope[ucSlotNum]  = 1.0/(FLOAT32)LCOST_ONE_VOLT_COUNT;  // divide by 12288 = 0xf000 / 5(V)
        CalibData.fCalibrationOffset[ucSlotNum] = 0.0;
    }

#endif
    HCuAvail = 100.0;
    OwdCktGood = TRUE;

#if defined(IOPTYPE_HLAI)
    BxLimit1 = NaN;
    BxLimit2 = NaN;
    PvsGood = FALSE;
    bSlwFirstPass = TRUE;
#endif

    HwInfo.ProductType = PRODTYPE_AI;
    switch(a_MdType) {
    case MODLTYPE_AIH:
        HwInfo.ProductCode = PRODCODE_AI_HART;
        break;
    case MODLTYPE_AI:
#if HEK
        HwInfo.ProductCode = PRODCODE_AI_HL;
#else
        HwInfo.ProductCode = PRODCODE_AI_HL_LC;
        BoardType = BOARDTYPE_LOWCOST;
#endif
        break;
    case MODLTYPE_AI_S8:
#if LOWCOST
        HwInfo.ProductCode = PRODCODE_AI_HL_LC_S8;
        BoardType = BOARDTYPE_LOWCOST;
        break;
#endif
        // Series C Depop AI is not planned in Series 8,
        // Hard fail module if configuration is done
    case MODLTYPE_AIH_S8:
        // Series C HART AI is not planned in Series 8,
        // Hard fail module if configuration is done
    default:
        HardFail(HF_BADPROGRAMJUMP,AIHBOXSLOT_CPP,__LINE__);
    }

    // Setup TPU0 as point processing timer for every 50 msec.
    TPU0_TCR    = 0x23; // Divide/64 clock, rising edge, clear TCNT on TGRA match.
    TPU0_TMDR   = 0xC0; // TPU0 normal mode operation
    TPU0_TIER   = 0x01; // TGIEA interrupt enabled with TGRA match
    TPU0_TGRA   = TPU0_MAXCOUNT; // interrupt every (50/16) = 3.125 msec. 
    IPRI_IOPROC = LVLPRI_IOPROC; // Set PPX interrupt priority level

    OWD_ENB = 0; // Disable open wire detection circuitry at startup

#ifdef DEBUG
    m_ulMaxPpxTime  = 0;
    m_ulAvgPpxTime  = 0;
    m_ulMinPpxTime  = MAXUINT32;
#endif
    PartnersChkPntVer = 0;
}
/*******************************************************************************
*                          clsAihBoxSlot::GetDataType                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsAihBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsAihBoxSlot::GetAccessType                        *
*                          ============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsAihBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                          clsAihBoxSlot::GetParamSize                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAihBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                          clsAihBoxSlot::GetParamPtr                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsAihBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                         clsAihBoxSlot::GetAccessLock                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsAihBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                    clsAihBoxSlot::GetIsDbChecksumed                          *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                        clsAihBoxSlot::VerifyControlState                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}
/*******************************************************************************
*                        clsAihBoxSlot::ExecutePreFunction                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsAihBoxSlot::ExecutePostFunction                    *
*                        ==================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
    return;
}
/*******************************************************************************
*                         clsAihBoxSlot::  PreCalibAll                         *
*                         ============================                         *
* PURPOSE:  Pre Receiver-Beware function for CalibAll parameter. Checks for    *
*           Calibration present status.                                        *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesfull                     *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::PreCalibAll(UINT8 *,UINT8) {
    // Calibration is only permitted when the module state is Idle.
    if(ModStat1.Status == MODSTATUS_RUN) {
        return DO_STATE_MUST_BE_IDLE;
    }

    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostCalibAll                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::PostCalibAll(UINT8) {
    TaskScheduler.RunTask(TASKID_CALIBTASK);
}

/*******************************************************************************
*                         clsAihBoxSlot::PreCheckPoint                         *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsAihBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    return PA_OK;
}
/*******************************************************************************
*                        clsAihBoxSlot::AppInitialization                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::AppInitialization(VOID)  {
    LoadCalibrationData();
#if !LOWCOST
    // Detect whether pass one or pass two board. It takes a while for the zero
    // reference to settle after a cold powerup. Repeat the detection until a
    // the zero reference settle to a difference of 10 counts over 10 samples.
    const UINT8 REF0_SAMPLES_OR_DIFF = 10;
    const UINT8 REF0_TRIALS = 50;
    UINT8 ucTrials = REF0_TRIALS;
    clsOlympicAverage ZeroAvg;
    while (BOARDTYPE_UNKNOWN == BoardType) {
        UINT16 uiZero = REF0_SAMPLES_OR_DIFF;
        ZeroAvg.Initialize();
        while (uiZero--) {
            ZeroAvg.AddSample(Adc.GetRawData(IN_REF0));
        }
        if ((ZeroAvg.GetHiSample() - ZeroAvg.GetLoSample()) < REF0_SAMPLES_OR_DIFF) {
            // Zero reference settled to a difference of 10 counts.
            uiZero = ZeroAvg.GetResult();

            if ((uiZero > PASS1_ZERO_REF_LOLIMIT) && (uiZero < PASS1_ZERO_REF_HILIMIT)) {
                BoardType = BOARDTYPE_PASSONE;
            }
            else if ((uiZero > PASS2_ZERO_REF_LOLIMIT) && (uiZero < PASS2_ZERO_REF_HILIMIT)) {
                BoardType = BOARDTYPE_PASSTWO;
            }
        }
        
        // Exit the while loop with a softfail if reference type cannot be found in 50 trials.
        if (0 == --ucTrials) {
            BoardType = BOARDTYPE_PASSTWO;
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
        }
    }
#endif

    TPU0_CST = 1; // Start AIH point processing timer
} 
/*******************************************************************************
*                         clsAihBoxSlot::AppStcProcessing                      *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::AppStcProcessing(VOID)
{   
    #if(HEK && defined(IOMTYPE_AIH))
    if((FALSE == IsFpgaS2) && (0 == FPGA_INIT_n)) // only for S3 FPGA
    // Hardfail the module if FPGA CRC check fails
    HardFail(HF_FPGARDBKFAIL, AIHBOXSLOT_CPP, __LINE__);
    #endif
    
    ManageRedIO(); // Process redundancy inputs and state
}
/*******************************************************************************
*                       clsAihBoxSlot::LoadCalibrationData                     *
*                       ==================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::LoadCalibrationData(VOID) {
    UINT8 ucSlotNum;

	/* 
     * Disabling below part of code due to,
     * As of now calibration data stored in both FRAM & Flash memories, but the latest HW is replaced with battery backup SRAM,
	 * calibration data is going to maintain in FLASH memory, and after power on calib data copied into SRAM as is.
     */
#if !defined(IOPTYPE_HLAI)
    // First check if the SPI EEPROM is present on the app board. If the SPI 
    // EEPROM is present then check  if the data is valid. If the data in SPI
    // is not VALID then check if the calibration data is present in FLASH. If
    // yes load the data or declare Invalid calibration data.
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        if (CALIBRATION_DONE == Eeprom.ReadByte(EE_CALIBRATION_MARK)) {
            // Check if Calibration data is good
            if (Eeprom.ValidateEepromChecksum()) {
                CalibrationGood = TRUE;
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,FALSE,0);

                CalibData.f5VRefHiLimit = Eeprom.ReadFloat(EE_CALIBRATION_5VREF_HILIMIT);
                CalibData.f5VRefLoLimit = Eeprom.ReadFloat(EE_CALIBRATION_5VREF_LOLIMIT);
#if !LOWCOST    // one SLOPE/OFFSET. Zero drift for each channel
                CalibData.fCalibrationSlope  = Eeprom.ReadFloat(EE_CALIBRATION_SLOPE);
                CalibData.fCalibrationOffset = Eeprom.ReadFloat(EE_CALIBRATION_OFFSET);

#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r- EEPROM CALIB DATA -"));                
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r5VHL-%f 5VLL-%f SLOPE-%f OFSET-%f",
                    CalibData.f5VRefHiLimit,
                    CalibData.f5VRefLoLimit,
                    CalibData.fCalibrationSlope,
                    CalibData.fCalibrationOffset));                
#endif
#endif                
                for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
                    CalibData.fChannelZeroDrift[ucSlotNum] = 
                        Eeprom.ReadFloat(EE_CHANNEL_ZERODRIFT_PTR+(ucSlotNum*sizeof(FLOAT32)));
#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.                    
                    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\rChnl0Drift[%02x]-%f",
                        ucSlotNum, CalibData.fChannelZeroDrift[ucSlotNum]));
#endif
#endif
                }
#else   // LOWCOST, SLOPE and OFFSET for each channel
                for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
                    CalibData.fCalibrationSlope[ucSlotNum] = 
                        Eeprom.ReadFloat(EE_CHANNEL_SLOPE_PTR+(ucSlotNum*sizeof(FLOAT32)));
                    CalibData.fCalibrationOffset[ucSlotNum] = 
                        Eeprom.ReadFloat(EE_CHANNEL_OFFSET_PTR+(ucSlotNum*sizeof(FLOAT32)));
                }
#endif
                return;
            }
        }
    }
#endif

    if (CALIBRATION_MARK == CALIBRATION_DONE) { 
        // Calibration present in flash. There is no plan to implement
        // CRC on flash calibration as this is getting relocated to EEPROM.
        CalibrationGood = TRUE;                
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,FALSE,0);

        CalibData.f5VRefHiLimit = CALIBRATION_5VREF_HILIMIT;
        CalibData.f5VRefLoLimit = CALIBRATION_5VREF_LOLIMIT;
#if !LOWCOST
        CalibData.fCalibrationSlope  = CALIBRATION_SLOPE;
        CalibData.fCalibrationOffset = CALIBRATION_OFFSET;

#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r- FLASH CALIB DATA -"));
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r5VHL-%f 5VLL-%f SLOPE-%f OFSET-%f",
            CalibData.f5VRefHiLimit,
            CalibData.f5VRefLoLimit,
            CalibData.fCalibrationSlope,
            CalibData.fCalibrationOffset));
#endif
#endif

        volatile FLOAT32 *pfChanZeroDrift = CHANNEL_ZERODRIFT_PTR;
        for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
            CalibData.fChannelZeroDrift[ucSlotNum] = *pfChanZeroDrift++;

#if(0) && !defined(IOPTYPE_SCIOM)
#ifdef DEBUG            // to print each param and its response while writing param set.                    
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\rChnl0Drift[%02x]-%f",
                ucSlotNum, CalibData.fChannelZeroDrift[ucSlotNum]));
#endif
#endif
        }
#else   // LOWCOST
        volatile FLOAT32 *pfChanZeroDrift = CHANNEL_ZERODRIFT_PTR;
        for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
            CalibData.fCalibrationSlope[ucSlotNum] = *pfChanZeroDrift++;
        }
        for (ucSlotNum = 0; ucSlotNum < MAXSLOTS; ucSlotNum++) {
            CalibData.fCalibrationOffset[ucSlotNum] = *pfChanZeroDrift++;
        }
#endif
        TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibLoad);
		
       /*
        * below part of code works as is,
        * Since FRAM is replaced with battery backup SRAM, Calibration data retrives from the flash
        * and writes in the SRAM on every power on.
        */
		
        // Now copy the data in SPI EEPROM. We need this only 1 time. This is because
        // if the module is already calibrated and the data is in Flash.This will be
        // removed later as it is not required once the data is in SPI. If calibration
        // is attempted, it will be written to EPIEEPROM directly if present.

        // First check if the SPI EEPROM is present on the app board. If the SPI 
        // EEPROM is present then store the data in SPI EEPROM else use FLASH.
        // Read the status register. Bits 2 and 3 are write protect bits and
        // always 0 as we do not protect it. If we see any of these bits ON,then
        // it is safe to assume that SPI device is not present.
        if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
            // Reinit the pointer
            UINT8 *ucBufferPtr = (UINT8*)(MODULEINFO_START_ADDRESS);
            //Enable the writes EEPROM 
            Eeprom.EnableWrite();
            //Start writing calibration constants to SPI.
            for (UINT16 ucCount=0; ucCount < MAX_EEPROM_SIZE-6; ucCount++) {
                Eeprom.WriteByte(ucCount,*ucBufferPtr);
                ucBufferPtr++;
                Eeprom.CheckWriteInProgress();
            }
            Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS,0x5A);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS+1,0x5A);
            Eeprom.CheckWriteInProgress();

            UINT16 ModuleWriteCount;
            ModuleWriteCount = Eeprom.ReadUint16(EE_MODULEINFO_WRITECOUNT)+1;
            if (0==ModuleWriteCount) ModuleWriteCount = 1;
            Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
            // calculate and write the checksum
            UINT16 Chksum = Eeprom.ComputeEepromChecksum();
            Eeprom.WriteByte(EE_MODULEINFO_CHKSUM,(UINT8)Chksum);
            Eeprom.CheckWriteInProgress();
            Eeprom.WriteByte(EE_MODULEINFO_CHKSUM+1,(UINT8)(Chksum>>8));
            Eeprom.CheckWriteInProgress();
            //Disable the writes EEPROM 
            Eeprom.DisableWrite();

            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x107);
        }
    }
}
/*******************************************************************************
*                       clsAihBoxSlot::FlashCalibrationData                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihBoxSlot::FlashCalibrationData(VOID) {
    UINT8 *ucBufferPtr;
    UINT16 uiCount;
    UINT8 ucModuleInfoBlockTop[MAX_EEPROM_SIZE];       // for EEPROM and FLASH(top)
    // note: In case of EEPROM, the Top buffer does not include the first 16 byte 
    // of EEPROM which is the manufacture data.
    /*
     * enabled the part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */
#if defined(IOPTYPE_HLAI) //#ifndef DEBUG
    UINT8 ucModuleInfoBlockBottom[FLASH_PROGRAM_BLOCK_SIZE];    // for FLASH(bottom)
#endif

    // Initialize the buffers.
    for (uiCount = 0; uiCount < MAX_EEPROM_SIZE; uiCount++) {
        ucModuleInfoBlockTop[uiCount]    = 0xFF;
    }
    /*
     * enabled the part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */
#if defined(IOPTYPE_HLAI) //#ifndef DEBUG
    for (uiCount = 0; uiCount < FLASH_PROGRAM_BLOCK_SIZE; uiCount++) {
        ucModuleInfoBlockBottom[uiCount]  = 0xFF;
    }
#endif
    
    /*
     * Disabling below part of code due to,
     * Since FRAM is replaced with battery bacukup SRAM, calibration data must be maintaining in FLASH memory
     */
#if !defined(IOPTYPE_HLAI)
    // First check if the SPI EEPROM is present on the app board. If the SPI 
    // EEPROM is present then store the data in SPI EEPROM else use FLASH.
    // Read the status register. Bits 2 and 3 are write protect bits and
    // always 0 as we do not protect it. If we see any of these bits ON,then
    // it is safe to assume that SPI device is not present.
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        // Fill the information at the top of the module info block.
        ucBufferPtr = ucModuleInfoBlockTop;
        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefHiLimit;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefLoLimit;
        ucBufferPtr += sizeof(FLOAT32);
#if !LOWCOST
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset;
        ucBufferPtr += sizeof(FLOAT32);

        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fChannelZeroDrift[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#else   // LOWCOST
        ucBufferPtr += sizeof(FLOAT32);    // skip spare1
        ucBufferPtr += sizeof(FLOAT32);    // skip spare2

        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#endif

        // calculate Total number fo bytes to be copied to EEPROM
        UINT16 uCalDataBytes = ucBufferPtr - ucModuleInfoBlockTop;
        // Reinit the pointer
        ucBufferPtr = ucModuleInfoBlockTop;
        //Enable the writes EEPROM 
        Eeprom.EnableWrite();
        //Start writing calibration constants to EEPROM.

        for (UINT16 ucCount=0; ucCount < uCalDataBytes; ucCount++) {
            Eeprom.WriteByte(ucCount+EE_CALIBRATION_5VREF_HILIMIT,*ucBufferPtr);
            ucBufferPtr++;
            Eeprom.CheckWriteInProgress();
        }

        // Write Calibration complete
        Eeprom.WriteByte(EE_CALIBRATION_MARK,CALIBRATION_DONE);
        Eeprom.CheckWriteInProgress();

        Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS,0x5A);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_WRITE_FLAGS+1,0x5A);
        Eeprom.CheckWriteInProgress();

        UINT16 ModuleWriteCount;
        ModuleWriteCount = Eeprom.ReadUint16(EE_MODULEINFO_WRITECOUNT)+1;
        if (0==ModuleWriteCount) ModuleWriteCount = 1;
        Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
        Eeprom.CheckWriteInProgress();
        // calculate and write the checksum
        UINT16 Chksum = Eeprom.ComputeEepromChecksum();
        Eeprom.WriteByte(EE_MODULEINFO_CHKSUM,(UINT8)Chksum);
        Eeprom.CheckWriteInProgress();
        Eeprom.WriteByte(EE_MODULEINFO_CHKSUM+1,(UINT8)(Chksum>>8));
        Eeprom.CheckWriteInProgress();
        //Disable the writes EEPROM 
        Eeprom.DisableWrite();

        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x108,(UINT32)Eeprom.ReadByte(EE_MODULEINFO_WRITECOUNT));
        return TRUE;
    }

    // *************************************************************
    //    EEPROM does not exist. Write to FLASH. Write 2 sectors
    // *************************************************************
    // note: Question for LLMUX since 4 byte x 64 chan = 256.
//#ifndef DEBUG // Flash programming will not be supported by APP debug build.
    else 
#else
	{
#ifdef DEBUG
	while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalib data storing into FLASH, ")); 
#endif
        // Fill the information at the top of the module info block.
        ucBufferPtr = ucModuleInfoBlockTop;
        *((UINT16 *)ucBufferPtr) = VENDOR_ID;
        ucBufferPtr += sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = PRODUCT_TYPE;
        ucBufferPtr += sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = PRODUCT_CODE;
        ucBufferPtr += sizeof(UINT16);
        *((UINT32 *)ucBufferPtr) = SERIAL_NUMBER;
        ucBufferPtr += sizeof(UINT32);
        *((UINT8 *)ucBufferPtr) = HARDWARE_REVCODE;
        ucBufferPtr += sizeof(UINT8);

         ucBufferPtr += sizeof(UINT32); // Fill area.
        *((UINT8 *)ucBufferPtr) = CALIBRATION_DONE;
        ucBufferPtr += sizeof(UINT8);

        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefHiLimit;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefLoLimit;
        ucBufferPtr += sizeof(FLOAT32);
#if !LOWCOST
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope;
        ucBufferPtr += sizeof(FLOAT32);
        *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset;
        ucBufferPtr += sizeof(FLOAT32);

        for (UINT8 ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fChannelZeroDrift[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#else   // LOWCOST
        ucBufferPtr += sizeof(FLOAT32);    // skip spare1
        ucBufferPtr += sizeof(FLOAT32);    // skip spare2

        UINT8 ucCount;
        for (ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationSlope[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
        for (ucCount = 0; ucCount < MAXSLOTS; ucCount++) {
            *((FLOAT32 *)ucBufferPtr) = CalibData.fCalibrationOffset[ucCount];
            ucBufferPtr += sizeof(FLOAT32);
        }
#endif

        // Fill information at the bottom of module info block.
        ucBufferPtr = ucModuleInfoBlockBottom + FLASH_PROGRAM_BLOCK_SIZE - 1;
        *((UINT16 *)ucBufferPtr) = 0; // Replace this CRC value later.

        ucBufferPtr -= sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) = MODULINFO_WRITE_COMPLETE;
    
        // Program number of times module info section is programmed.
        ucBufferPtr -= sizeof(UINT16);
        *((UINT16 *)ucBufferPtr) =  MODULEINFO_WRITECOUNT + 1;
        if (0 == *((UINT16 *)ucBufferPtr)) {
            *((UINT16 *)ucBufferPtr) = 1;
        }

        if (EraseFlash(MODULE_INFO_FLASH_BLOCK)) {
            if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS,
                ucModuleInfoBlockTop)) {
                if (ProgramFlash((UINT8 *)(MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1),
                    ucModuleInfoBlockBottom)) {
#ifdef DEBUG
	while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("done")); 
#endif
                    return TRUE;
                }
            }
        }
    }
//#endif // ifndef DEBUG
#endif

    return FALSE;
}
#if !LOWCOST
/*******************************************************************************
*                       clsAihBoxSlot::ValidateCheckVoltage                    *
*                       ===================================                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAihBoxSlot::ValidateCheckVoltage(UINT8 a_ucSlotNum,UINT16 a_uiZeroRef) {
    UINT16 uiRefInput = 0;
    switch (a_ucSlotNum) {
    case IN_CHAN01:
    case IN_CHAN02:
    case IN_CHAN03:
        uiRefInput = IN_CKVT1;
        break;
    case IN_CHAN04:
    case IN_CHAN05:
    case IN_CHAN06:
        uiRefInput = IN_CKVT2;
        break;
    case IN_CHAN07:
    case IN_CHAN08:
    case IN_CHAN09:
        uiRefInput = IN_CKVT3;
        break;
    case IN_CHAN10:
    case IN_CHAN11:
    case IN_CHAN12:
        uiRefInput = IN_CKVT41;
        break;
    case IN_CHAN13:
    case IN_CHAN14:
        uiRefInput = IN_CKVT52;
        break;
    case IN_CHAN15:
    case IN_CHAN16:
        uiRefInput = IN_CKVT5;
        break;
    }

    FLOAT32 fRefInput = ((FLOAT32)(Adc.GetRawData(uiRefInput) - a_uiZeroRef)
                         * CalibData.fCalibrationSlope) + CalibData.fCalibrationOffset;
    uiRefInput -= (MAXSLOTS + 1); // Compute index to REFVOLTAGE_LIMITS array.
    if ((fRefInput > REFVOLTAGE_LIMITS[uiRefInput].fHiLimit) || 
        (fRefInput < REFVOLTAGE_LIMITS[uiRefInput].fLoLimit)) {
        return FALSE;
    }
    return TRUE;
}
#endif
/*******************************************************************************
*                         clsAihBoxSlot::DoIdleDiagnostics                     *
*                         ================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::DoIdleDiagnostics(VOID) {
#if !LOWCOST
    // Validate zero reference.
    UINT16 uiZeroRefCount = Adc.GetRawData(IN_REF0);
    if (BOARDTYPE_PASSONE == BoardType) {
        if ((uiZeroRefCount < PASS1_ZERO_REF_LOLIMIT) || 
            (uiZeroRefCount > PASS1_ZERO_REF_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
            return;
        }
    }
    else { // Pass2 board
        if ((uiZeroRefCount < PASS2_ZERO_REF_LOLIMIT) || 
            (uiZeroRefCount > PASS2_ZERO_REF_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
            return;
        }
    }
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);

    // Validate 5V reference.
    UINT16 uiRefInput = Adc.GetRawData(IN_CKVT5) - uiZeroRefCount;
    if (BOARDTYPE_PASSONE == BoardType) {
        if ((uiRefInput < PASS1_FIVE_VOLT_LOLIMIT) || 
            (uiRefInput > PASS1_FIVE_VOLT_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,TRUE,0);
            return;
        }
    }
    else { // Pass2 board
        if ((uiRefInput < PASS2_FIVE_VOLT_LOLIMIT) || 
            (uiRefInput > PASS2_FIVE_VOLT_HILIMIT)) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,TRUE,0);
            return;
        }
    }
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,FALSE,0);

    // Test 5V reference against limits for stored in flash.
    if (((FLOAT32)uiRefInput > CalibData.f5VRefHiLimit) || 
        ((FLOAT32)uiRefInput < CalibData.f5VRefLoLimit)) {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
        return;
    }

    // Test against +/- 4% limits of the reference voltage
    // corresponding to the current PPX channel.
    if (FALSE == ValidateCheckVoltage(PpxChannel,uiZeroRefCount)) {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
        return;
    }
#else   // LOWCOST
    UINT32 ulRawData[ADC_INT_CHANNELS+1]; //ADC Internel Readings(OFFSET,VCC,TEMP,GAIN,REF)
    UINT8 ucChan;     

    for( ucChan=0;ucChan<(ADC_INT_CHANNELS+1);ucChan++){
       ulRawData[ucChan] = 0;
    }
        
    Adc.GetRawData(TRUE, ulRawData,FALSE);    //Read internel Readings 

    // ADC OFFSET Check
    ulRawData[IN_LC_OFFSET] = (ulRawData[IN_LC_OFFSET] & ADC_INT_DATA_MASK);  
    // If OFFSET is negative, perform 2's compliment.  
    if(ulRawData[IN_LC_OFFSET] & ADC_OFFSET_MASK)
    ulRawData[IN_LC_OFFSET] = ((~ulRawData[IN_LC_OFFSET]) & ADC_INT_DATA_MASK) + 1;
       
    if (ulRawData[IN_LC_OFFSET] > LCOST_ZERO_REF_HILIMIT) {
       // Post softfail for zero reference test failure.
       BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
    }
    else { // Zero reference test passed. Return softfail if any.
       BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
    }
    
    // 5V VCC Check
    ulRawData[IN_LC_VCC] = (ulRawData[IN_LC_VCC] & ADC_INT_DATA_MASK);
    if ((ulRawData[IN_LC_VCC] < LCOST_VCC_LOLIMIT) || 
       (ulRawData[IN_LC_VCC] > LCOST_VCC_HILIMIT)) {
       BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,TRUE,0);
    }
    else {
       BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,FALSE,0);
    }
    
    // 5V precise reference Check
    ulRawData[IN_LC_REF] = (ulRawData[IN_LC_REF] & ADC_INT_DATA_MASK);
    if ((ulRawData[IN_LC_REF] < LCOST_FIVE_VOLT_LOLIMIT) || 
       (ulRawData[IN_LC_REF] > LCOST_FIVE_VOLT_HILIMIT)) {
       BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,TRUE,0);
    }
    else {
       BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,FALSE,0);
    }
#endif
}

/*******************************************************************************
*                       clsAihBoxSlot::PpxInterruptHandler                     *
*                       ==================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
VOID clsAihBoxSlot::PpxInterruptHandler(VOID)  {
    TPU0_TGFA = 0; // Acknowledge the compare match interrupt

#ifdef DEBUG
    // Initilize the variable for measuring performance.
    UINT16 uiPpxStart = TPU5_TCNT;
    UINT32 ulPpxStart = TaskScheduler.Get10msecCounter();
#endif    

#if !LOWCOST
    UINT16 uiZeroRef = 0;
#endif
        
    if (FALSE == BOX->CalibrationGood) { // Calibration data is bad or not available.
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
        SLOT(BOX->PpxChannel)->ProcessSlot(NaN);
    }
#if defined(IOPTYPE_HLAI)
    else if (FALSE == BOX->GetFtaPres()) { //  FTA missing,

        SLOT(BOX->PpxChannel)->ProcessSlot(NaN);
    }    
#endif
    else if (MODSTATUS_IDLE == BOX->ModStat1.Status) {
        // Return open wire softfail if any, since module is now idle.
        SLOT(BOX->PpxChannel)->DisableOpenWireCheck();
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,BOX->PpxChannel);
        // If module is IDLE, return any diagnostic circuit failure. It was found
        // during testing that an extremely chattering input may misfire this box softfail
        // and IDLEing the module is the only way this softfail can be cleared. If this is 
        // in fact a module h/w problem, softfail will be reposted when module is RUN again.
        BOX->SetOwdCktGood();
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,FALSE,0);
        // previously softfail SF_BADRJVAL was returned here,
        // but now it is removed as part of PAR 1-ATOTCQ fix.
        if (FALSE == BOX->CalibAll) {
            BOX->DoIdleDiagnostics();

            /*
             * Fix for not to generate badpvfl alarms for all channels in module Idle state.
             */
#if !defined(IOPTYPE_HLAI)
            if (PTEXECST_ACTIVE == SLOT(BOX->PpxChannel)->GetPtExecSt()) {
                SLOT(BOX->PpxChannel)->ProcessSlot(NaN);
            }
#endif
        }
    }
    else if (MODSTATUS_RUN == BOX->ModStat1.Status) {
#if !LOWCOST    // Check ZeroRef each time
        // Open wire testing enabled in the previous cycle for this channel.
        // Re-evaluate the conditions and disable if required.
        if ((BOX->IsOwdCktGood() != TRUE) ||
            (SLOT(BOX->PpxChannel)->GetOwdEnable() == FALSE) || 
            (SLOT(BOX->PpxChannel)->GetPtExecSt() != PTEXECST_ACTIVE)) {
            SLOT(BOX->PpxChannel)->DisableOpenWireCheck();
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,BOX->PpxChannel);
        }

        uiZeroRef = Adc.GetRawData(IN_REF0); // Convert zero reference.
        // Do the zero reference test based on the board type.
        if (BOARDTYPE_PASSONE == BOX->BoardType) {
            if ((uiZeroRef < PASS1_ZERO_REF_LOLIMIT) || 
                (uiZeroRef > PASS1_ZERO_REF_HILIMIT)) {
                // Post softfail for zero reference test failure.
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
            }
            else { // Zero reference test passed. Return softfail if any.
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
            }
        }
        else { // Pass2 board
            if ((uiZeroRef < PASS2_ZERO_REF_LOLIMIT) || 
                (uiZeroRef > PASS2_ZERO_REF_HILIMIT)) {
                // Post softfail for zero reference test failure.
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
            }
            else { // Zero reference test passed. Return softfail if any.
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
            }
        }
#endif

        
#if !LOWCOST

        UINT16 uiRawData = 0;
        FLOAT32 fRawData = NaN; 
        
        uiRawData = Adc.GetRawData(BOX->PpxChannel); // Convert raw data for this channel.
        SLOT(BOX->PpxChannel)->StoreRawAdcCount(uiRawData); // Store raw count in channel.

        // Check the common mode voltage warning bit.
        if (0 == OVERVT_n) {
            SLOT(BOX->PpxChannel)->DisableOpenWireCheck();
            // Fix for PAR:1-ATOTCQ 
            // posting of soft fail is removed ,as currently we dont have 
            // soft fail code present for Common mode voltage out of range.
            // Instead of that we are supposed to set Pv to NAN and Pvstatus to BAD,
            // but that is happening  in process slot function.
        }
        else
        {
            SLOT(BOX->PpxChannel)->CheckOpenWire(); // First open wire check            

            // Convert and test the check voltage corresponding to this channel.
            // This test ensures that the analog mux is switching correctly.
            if (FALSE == BOX->ValidateCheckVoltage(BOX->PpxChannel,uiZeroRef)) {

#if defined(IOPTYPE_HLAI)               
                /*
                 * Fix for customer par (badpvfl observing momentarily at the time of reconstituting or configuring a point.)
                 * Root Cause: At the same time access of ADC during point process & xRAM during writing config data,
                 * which is due to both the devices are accessing through FPGA register address (0x4000B0)
                 * Resolution: if xRAM accessed during slot process, skip the current process/loop.
                 */
				if (ucXRamTimeout) {
                    return;
                }
#endif
                // Check voltage test failed for this channel. Post softfail.
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
            }
            else { // Check voltage validated.

#if !defined(IOPTYPE_SCIOM)
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_ADOUTCAL, FALSE, 0);
#endif
                // Connnect ADC back to the input channel. This is done now so
                // that there is enough time for the MUX to settle before the 
                // VerifyOwdCkt is called at the end of PPX. Since MUX is settled,
                // VerifyOwdCkt can take the ADC sample without additional wait.
                Adc.Connect(BOX->PpxChannel); 

                if ((0 == uiRawData) || (MAXIMUM_ADCOUNT == uiRawData)) {
                    // ADC count check failed. Post ADOUTUDF softfail.
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTUDF,FALSE,BOX->PpxChannel);
                }
                else { // ADC count is good. Clear ADOUTUDF softfail if any.
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTUDF,FALSE,BOX->PpxChannel);
                    SLOT(BOX->PpxChannel)->CheckOpenWire(); // Second open wire check

                    // Threshold values based on the Board Type. Applied to 1-5V and P4-2V configuration.
                    // The NaN Threshold corresponds to -24% (1-5V) or -22.5% (P4-2V).
                    UINT16 uiNanEnterThreshold;   // set NaN if RawData is below this value (40 mV)
                    UINT16 uiNanExitThreshold;    // Exit from NaN if RawData is above this value (50 mV)
                    if (BOARDTYPE_PASSTWO == BOX->BoardType) {
                      uiNanEnterThreshold = PASS2_INPUT_NAN_COUNT;    // =589
                      uiNanExitThreshold = uiNanEnterThreshold + PASS2_INPUT_DEADBAND_BIAS;
                    }
                    else { // BOARDTYPE_PASSONE
                      uiNanEnterThreshold = PASS1_INPUT_NAN_COUNT;    // =1307
                      uiNanExitThreshold = uiNanEnterThreshold + PASS1_INPUT_DEADBAND_BIAS;
                    }

                    // convert counts to 0.0 to 5.0 value, or to NaN
                    if (uiRawData > uiNanEnterThreshold) { // RawData is greater than NaN threshold.
                        if (TRUE == SLOT(BOX->PpxChannel)->WasInputBelowDeadband()) {
                            // Input was below deadband in previous cycle. Continue raw value
                            // calculation, only if it had risen above deadband in this cycle.
                            // This allows a hysteris to set in once input goes below NaN threshold.

                            if (uiRawData > uiNanExitThreshold) {
                                SLOT(BOX->PpxChannel)->SetInputBelowDeadband(FALSE);
                                fRawData = (FLOAT32)uiRawData;
                                fRawData -= (FLOAT32)(uiZeroRef + BOX->CalibData.fChannelZeroDrift[BOX->PpxChannel - 1]);
                            }
                        }
                        else { // Input was above NaN threshold in previous cycle.
                            fRawData = (FLOAT32)uiRawData; 
                            fRawData -= (FLOAT32)(uiZeroRef + BOX->CalibData.fChannelZeroDrift[BOX->PpxChannel - 1]);   
                        }
                    }
#if defined(IOPTYPE_HLAI)
                    else if ((SENSRTYP_0to5_V   == SLOT(BOX->PpxChannel)->GetSensorType()) ||
                             (SENSRTYP_SLIDWIRE == SLOT(BOX->PpxChannel)->GetSensorType())) {
#else
                    else if (SENSRTYP_0to5_V == SLOT(BOX->PpxChannel)->GetSensorType()) {
#endif
                        SLOT(BOX->PpxChannel)->SetInputBelowDeadband(FALSE);
                        fRawData = (FLOAT32)uiRawData;
                        fRawData -= (FLOAT32)(uiZeroRef + BOX->CalibData.fChannelZeroDrift[BOX->PpxChannel - 1]);   
                    }
                    else { // Input is below NaN threshold and sensor type is not 0to5V.
                        fRawData = NaN;
                        SLOT(BOX->PpxChannel)->SetInputBelowDeadband(TRUE);
                    }

                    // All checks passed. Use calibration data 
                    // to convert ADC counts into raw data.
                    if (!isnan(fRawData)) {
                        fRawData *= BOX->CalibData.fCalibrationSlope;
                        fRawData += BOX->CalibData.fCalibrationOffset;

#if defined(IOPTYPE_HLAI)
                        // work around to make pvraw high, when SLIDWIRE not connected.
                        if ((uiRawData <= uiNanEnterThreshold) &&                            
                            (SENSRTYP_SLIDWIRE == SLOT(BOX->PpxChannel)->GetSensorType()))
                        {
                            fRawData  = BOX->SlwSrcBuff[SLOT(BOX->PpxChannel)->GetSlwSrcId()-1];
                            fRawData += SLOT(BOX->PpxChannel)->GetADRawLo();
                            fRawData /= SLOT(BOX->PpxChannel)->GetHundredDivRawSpan();
                        }
#endif
                    }
                    SLOT(BOX->PpxChannel)->CheckOpenWire(); // Third open wire check
                } // else part of validate check voltage
            } // else part of common mode voltage check
        } // else if MODSTATUS_RUN

#if defined(IOPTYPE_HLAI)
        // Storing Slidewire power source into buffer
        // BOX->SlwSrcBuff[BOX->PpxChannel - 1] = fRawData;

        // Slidewire first pass clear to get slidewire pwr src from buffer
        if (MAXSLOTS == BOX->PpxChannel) BOX->bSlwFirstPass = FALSE;

        // If not slidewire sensor or not slidewire first pass
        if ((FALSE == BOX->bSlwFirstPass) || 
            (SENSRTYP_SLIDWIRE != SLOT(BOX->PpxChannel)->GetSensorType()))
#endif

        SLOT(BOX->PpxChannel)->ProcessSlot(fRawData); // Do slot processing.
    }

    // Setup to do point PPX in the next channel in the next cycle.
    BOX->PpxChannel = (MAXSLOTS == BOX->PpxChannel) ? 1 : BOX->PpxChannel + 1;

    if ((BOX->IsOwdCktGood() == TRUE) &&
        (BOX->GetModuleStatus() == MODSTATUS_RUN) &&
        (SLOT(BOX->PpxChannel)->GetOwdEnable() == TRUE) &&
        (SLOT(BOX->PpxChannel)->GetPtExecSt() == PTEXECST_ACTIVE)) {
        // Connect open wire MUX to the next channel so that HART filter  
        // capacitors will be stabilized before actual open wire detection 
        // start in the next cycle. Decision to carry on with open wire 
        // detection or not will be taken at the beginning of next cycle.
        SLOT(BOX->PpxChannel)->EnableOpenWireCheck();
    }

#if defined(IOPTYPE_HLAI)
    // Timeout for SPI after imm.. used by xRAM
    if (ucXRamTimeout) ucXRamTimeout--;
#endif

#else  // Low Cost

     UINT32 ulRawData[MAXSLOTS];
     FLOAT32 fRawData;
     UINT8 ucStatusByte,ucChan,ucChanId;
   
     // Check ADC Internel Readings first(OFFSET,VCC,REF) first.     
     for( ucChan=0;ucChan<MAXSLOTS;ucChan++){
          ulRawData[ucChan] = 0;
     }
        
     Adc.GetRawData(TRUE, ulRawData,FALSE);    //Read internel Readings 

     // ADC OFFSET Check
     ulRawData[IN_LC_OFFSET] = (ulRawData[IN_LC_OFFSET] & ADC_INT_DATA_MASK);  

     //If OFFSET is negative,perform 2's complement.
     if(ulRawData[IN_LC_OFFSET] & ADC_OFFSET_MASK)
     ulRawData[IN_LC_OFFSET] = ((~ulRawData[IN_LC_OFFSET]) & ADC_INT_DATA_MASK) + 1;
     
     if (ulRawData[IN_LC_OFFSET] > LCOST_ZERO_REF_HILIMIT) {
        // Post softfail for zero reference test failure.
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
     }
     else { // Zero reference test passed. Return softfail if any.
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
     }
    
     // 5V VCC Check
     ulRawData[IN_LC_VCC] = (ulRawData[IN_LC_VCC] & ADC_INT_DATA_MASK);
     if ((ulRawData[IN_LC_VCC] < LCOST_VCC_LOLIMIT) || 
        (ulRawData[IN_LC_VCC] > LCOST_VCC_HILIMIT)) {
         BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,TRUE,0);
     }
     else {
         BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,FALSE,0);
     }
    
     // 5V precise reference Check
     ulRawData[IN_LC_REF] = (ulRawData[IN_LC_REF] & ADC_INT_DATA_MASK);
     if ((ulRawData[IN_LC_REF] < LCOST_FIVE_VOLT_LOLIMIT) || 
         (ulRawData[IN_LC_REF] > LCOST_FIVE_VOLT_HILIMIT)) {
         BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,TRUE,0);
     }     
     else {
         BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VREFFAIL,FALSE,0);
     }  
           

     // Now Read the channel Data 
     for ( ucChan =0; ucChan < MAXSLOTS; ucChan++){ 
           ulRawData[ucChan] = 0;
     }
       
     Adc.GetRawData(FALSE, ulRawData,FALSE);        // Convert raw data for all 16 channels. 
     
     for (ucChan = 1;ucChan <= MAXSLOTS; ucChan++ )
     {
         fRawData = NaN;
         ucStatusByte = (UINT8)(ulRawData[ucChan-1] >> 24); // Read Status byte        
         ucChanId = (ucStatusByte & LC_STS_CHID);         

         if(ulRawData[ucChan-1] == ADC_CONV_INCOMPLETE){
            fRawData = NaN;
            // ADC channel conversion failed. Post ADCINCOMPLETE softfail.
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADCINCOMPLETE,TRUE,ucChan);
         }
         else if (((ucStatusByte & LC_STS_OVF_SUPPLY) != 0) && ((ucChanId - IN_LC_CHAN0) != (ucChan-1) )) // OVF,SUPPLY ON or Invalid channel. Bad Data
         {
            fRawData = NaN;
            switch(ucStatusByte & LC_STS_OVF_SUPPLY){
                case LC_STS_SUPPLY:
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_OVERFLOW,FALSE,ucChan);
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,TRUE,0);
                    break;
                case LC_STS_OVERFLOW:
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_OVERFLOW,TRUE,ucChan);
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,FALSE,0);
                    break;
                case LC_STS_OVF_SUPPLY:
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_OVERFLOW,TRUE,ucChan);
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,TRUE,0);
                    break;
            }
         }
         else {
            // ADC count is good. Clear SUPPLY_OVF_FAIL,ADCINCOMPLETE softfail if any.
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_OVERFLOW,FALSE,ucChan);
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADC_SUPPLY_FAIL,FALSE,0);
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADCINCOMPLETE,FALSE,ucChan);
            
            ulRawData[ucChan-1] = (ulRawData[ucChan-1] & ADC_CHAN_DATA_MASK);   
            SLOT(ucChan)->StoreRawAdcCount(ulRawData[ucChan-1]); // Store raw count in channel.

            UINT32 ulNanEnterThreshold;   // set NaN if RawData is below this value 
            UINT32 ulNanExitThreshold;    // Exit from NaN if RawData is above this value 

            ulNanEnterThreshold = LCOST_INPUT_NAN_COUNT;    
            ulNanExitThreshold = ulNanEnterThreshold + LCOST_INPUT_DEADBAND_BIAS;

            // convert counts to 0.0 to 5.0 value, or to NaN
            if (ulRawData[ucChan-1] > ulNanEnterThreshold) {               // RawData is greater than NaN threshold.
               if (TRUE == SLOT(ucChan)->WasInputBelowDeadband()) {
                  // Input was below deadband in previous cycle. Continue raw value
                  // calculation, only if it had risen above deadband in this cycle.
                  // This allows a hysteris to set in once input goes below NaN threshold.
                  if (ulRawData[ucChan-1] > ulNanExitThreshold) {
                     SLOT(ucChan)->SetInputBelowDeadband(FALSE);
                     fRawData = (FLOAT32)ulRawData[ucChan-1];
                  }                    
               }
               else {   // Input was above NaN threshold in previous cycle.
                    fRawData = (FLOAT32)ulRawData[ucChan-1];             
               }
            }
            else { 
                 fRawData = NaN;
                 SLOT(ucChan)->SetInputBelowDeadband(TRUE);
            }

            // All checks passed. Use calibration data 
            // to convert ADC counts into raw data.
            if (!isnan(fRawData)) {
               fRawData *= BOX->CalibData.fCalibrationSlope[ucChan-1];
               fRawData += BOX->CalibData.fCalibrationOffset[ucChan-1];
            }
         } // endif
         SLOT(ucChan)->ProcessSlot(fRawData); // Do slot processing.     
     }// end of for loop    
}// end of Module State= Run         
#endif

#ifdef DEBUG
    // Calculate PPX performance.
    UINT16 uiPpxEnd = TPU5_TCNT;
    UINT32 ulPpxEnd = TaskScheduler.Get10msecCounter();
    UINT32 ulPpxTime = 0;
    // First check whether scheduler 10 msec counter has incremented more than once
    // or not. Increment of one count will be covered by the difference of TPUCOUNT.
    // Update ulPpxTime only if the difference is more than one count.
    if (ulPpxEnd > (ulPpxStart + 1)) {
        ulPpxTime = (ulPpxEnd - (ulPpxStart + 1)) * TPUCOUNT_MAXVALUE;
    }

    // Now account for the difference of TPUCOUNT.
    if (uiPpxEnd > uiPpxStart) ulPpxTime += (uiPpxEnd - uiPpxStart);
    else ulPpxTime += (MAXUINT16 - uiPpxStart + 1 + uiPpxEnd);

    // Convert count value to micro seconds.
    ulPpxTime /= TPUCOUNT_IN_MICROSECOND;

    // Update minimum, maximum and average values.
    if (ulPpxTime > BOX->m_ulMaxPpxTime) {
        BOX->m_ulMaxPpxTime = ulPpxTime;
    }
    if (ulPpxTime < BOX->m_ulMinPpxTime) {
        BOX->m_ulMinPpxTime = ulPpxTime;
    }
    if (0 == BOX->m_ulAvgPpxTime) { // This is the first reading
        BOX->m_ulAvgPpxTime = ulPpxTime;
    }
    else {
        BOX->m_ulAvgPpxTime = (BOX->m_ulAvgPpxTime + ulPpxTime) / 2;
    }
#endif
}
/*******************************************************************************
*                               PerformModuleCalibration                       *
*                               ========================                       *
* PURPOSE: This function is responsible for module calibration                 *
* ARGUMENTS: None.                                                             *
* RETURN: TRUE if successful, FALSE otherwise                                  *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsAihBoxSlot::PerformModuleCalibration(VOID)
{
    UINT8  ucCount;
    FLOAT32 fOneVolt,fFiveVolt;
    clsOlympicAverage CalInputAverage,ZeroRefAverage;
    
#if !LOWCOST
    const UINT8 TOTAL_SAMPLES = 34;
    UINT16 uiCount;    
    FLOAT32 fZeroRef;

    AssertBackup();

    if (0 == FACTCAL) { // If factory calibration is being performed
#ifdef DEBUG
        if (BOARDTYPE_PASSONE == BoardType) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Pass 1 board"));
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Pass 2 board"));
        }
#endif
        // Wait till user press and release CALIBRATE switch on the IOTA.
        while (!CALIBRATE) { // Process any pending writes while waiting
            WriteDatabaseTask(TASKCONTEXT_ZERO); 
            // Abort calibration if cancel request was done
            if (FALSE == CalibAll) return FALSE;
        }
        while (CALIBRATE) { // Process any pending writes while waiting
            WriteDatabaseTask(TASKCONTEXT_ZERO); 
            // Abort calibration if cancel request was done
            if (FALSE == CalibAll) return FALSE;
        }
        BlinkLed(1);

        // Start with averaging 1V at calib inputs.
        for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {
            uiCount = Adc.GetRawData(IN_CALIB,CALIBRATION_MUX_SETTLE_TIME);
            CalInputAverage.AddSample(uiCount);
            uiCount = Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
            ZeroRefAverage.AddSample(uiCount);
        }

        fZeroRef = ZeroRefAverage.GetResult();
        fOneVolt = CalInputAverage.GetResult() - fZeroRef;

#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f",
                                          ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(),
                                          fZeroRef));
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t1V Hi = %d Lo = %d Avg = %f+%f\n",
                                          CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                          fOneVolt,fZeroRef));
#endif
        uiCount = (UINT16) fOneVolt;
        if (BOARDTYPE_PASSONE == BoardType) {
            if ((uiCount < PASS1_ONE_VOLT_LOLIMIT) || 
                (uiCount > PASS1_ONE_VOLT_HILIMIT)) {
                // Post bad calibration reference softfail.
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
                CalibAll = FALSE; 
                return FALSE; // Abort calibration.
            }
        }
        else { // Pass2 board
            if ((uiCount < PASS2_ONE_VOLT_LOLIMIT) || 
                (uiCount > PASS2_ONE_VOLT_HILIMIT)) {
                // Post bad calibration reference softfail.
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
                CalibAll = FALSE; 
                return FALSE; // Abort calibration.
            }
        }
    } 
    else { // Field calibration. Ensure that factory calibration data is present.
        if (CalibrationGood != TRUE) {
#ifdef DEBUG
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tDo factory calibration first"));
#endif
            CalibAll = FALSE; 
            return FALSE; // Abort calibration.
        }
#ifdef DEBUG
        if (BOARDTYPE_PASSONE == BoardType) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tField calibration..Pass 1 board"));
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tField calibration..Pass 2 board"));
        }
#endif
    }
    
    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    BlinkLed(2);

    // Average 5V at calib inputs for both factory and field calibration.
    ZeroRefAverage.Initialize();
    CalInputAverage.Initialize(); 
    for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {
        uiCount = Adc.GetRawData(IN_CALIB,CALIBRATION_MUX_SETTLE_TIME);
        CalInputAverage.AddSample(uiCount);
        uiCount = Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
        ZeroRefAverage.AddSample(uiCount);
    }
    
    fZeroRef = ZeroRefAverage.GetResult();
    fFiveVolt = CalInputAverage.GetResult() - fZeroRef;

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f",
                                      ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(),
                                      fZeroRef));
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t5V Hi = %d Lo = %d Avg = %f+%f\n",
                                      CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                      fFiveVolt,fZeroRef));
#endif
    uiCount = (UINT16) fFiveVolt;
    if (BOARDTYPE_PASSONE == BoardType) {
        if ((uiCount < PASS1_FIVE_VOLT_LOLIMIT) || 
            (uiCount > PASS1_FIVE_VOLT_HILIMIT)) {
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE; 
            return FALSE; // Abort calibration.
        }
    }
    else { // Pass2 board
        if ((uiCount < PASS2_FIVE_VOLT_LOLIMIT) || 
            (uiCount > PASS2_FIVE_VOLT_HILIMIT)) {
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE; 
            return FALSE; // Abort calibration.
        }
    }
    // Clear bad calibration reference softfail if any.
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,0);

    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    while (CALIBRATE) { // Process any pending writes while waiting
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) return FALSE;
    }
    BlinkLed(3);

    if (0 == FACTCAL) { // if factory calibration
        CalibData.fCalibrationSlope = 4.0 / (fFiveVolt - fOneVolt);
        CalibData.fCalibrationOffset =  1.0 - (CalibData.fCalibrationSlope * fOneVolt);
    }
    else { // if field calibration
        CalibData.fCalibrationSlope = (5.0 - CalibData.fCalibrationOffset) / fFiveVolt;
    }

    // Validate reference voltages.
    for (ucCount = 1; ucCount <= NO_OF_REF_VOLTAGES; ucCount++) {
        FLOAT32 fRefInput = (FLOAT32)Adc.GetRawData(MAXSLOTS + ucCount,CALIBRATION_MUX_SETTLE_TIME);
        fZeroRef = (FLOAT32)Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
        fRefInput -= fZeroRef;
        if (NO_OF_REF_VOLTAGES == ucCount) {
            // Save 5V reference limits for storing in flash.
            CalibData.f5VRefHiLimit = fRefInput + (FLOAT32) FIVE_VOLT_TOLERENCE_COUNT;
            CalibData.f5VRefLoLimit = fRefInput - (FLOAT32) FIVE_VOLT_TOLERENCE_COUNT;
        }
        fRefInput = (fRefInput * CalibData.fCalibrationSlope) + CalibData.fCalibrationOffset;
#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCHKVT%d : %f ZeroCount : %f",
                                          ucCount,(fRefInput * 1000),fZeroRef));
#endif
        if ((fRefInput > REFVOLTAGE_LIMITS[ucCount - 1].fHiLimit) || 
            (fRefInput < REFVOLTAGE_LIMITS[ucCount - 1].fLoLimit)) {
#ifdef DEBUG
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCHKVT test failed"));
#endif
            CalibAll = FALSE;
            return FALSE;
        }
    }

    if (0 == FACTCAL) { // if factory calibration
        // Find individual channel zero drift offsets.
        for (UINT8 ucSlot = 1; ucSlot <= MAXSLOTS; ucSlot++) {
            ZeroRefAverage.Initialize();
            CalInputAverage.Initialize();
            for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {
                uiCount = Adc.GetRawData(ucSlot,CALIBRATION_MUX_SETTLE_TIME);
                CalInputAverage.AddSample(uiCount);
                uiCount = Adc.GetRawData(IN_REF0,CALIBRATION_MUX_SETTLE_TIME);
                ZeroRefAverage.AddSample(uiCount);
            }
            fZeroRef = ZeroRefAverage.GetResult();
            CalibData.fChannelZeroDrift[ucSlot - 1] = CalInputAverage.GetResult() - fZeroRef;
#ifdef DEBUG
            if (ucSlot & 0x01) {
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r"));
            }
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\tChan%d zero drift %f",ucSlot,
                                                                    CalibData.fChannelZeroDrift[ucSlot - 1]));
#endif
        }
    }
#else // Lowcost

    const UINT8 TOTAL_SAMPLES = 34;
    UINT32 ulCount,ulRawCount[MAXSLOTS];
    UINT16 SAMPLE_WAIT = 5000;       // 5 msec IdleWait after GetRawData()

    UINT8   ucSlot,ucSeq,ucEnd;
    FLOAT32 fOneVoltArray[MAXSLOTS];
    FLOAT32 fFiveVoltArray[MAXSLOTS];

    for(ucSlot=0;ucSlot<MAXSLOTS;ucSlot++){
    fOneVoltArray[ucSlot]  = NaN;
    fFiveVoltArray[ucSlot] = NaN;
    ulRawCount[ucSlot] = 0;
    }

    AssertBackup();

#ifdef DEBUG
        if (BOARDTYPE_LOWCOST == BoardType) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Low Cost Board"));
        }
#endif

    ucEnd = MAXSLOTS; // 1 to 16 chanels. 

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tApply 0.8V input to all 16 Channels and touch calib pad"));
#endif

    // Wait till user press and release CALIBRATE switch on the IOTA.
    if(WaitCalibSwitch()==FALSE){
        return FALSE;
    } 

    // Average 0.8V at input channel(16 Channels) for factory calibration.
    for(ucSeq = 1;ucSeq<=ucEnd;ucSeq++){   
        CalInputAverage.Initialize();
        for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {
        Adc.GetRawData(FALSE,ulRawCount,TRUE);
        ulCount = (ulRawCount[ucSeq-1] & ADC_CHAN_DATA_MASK);
        CalInputAverage.AddSample(ulCount);
        IdleWait(SAMPLE_WAIT);
        }
        fOneVolt = CalInputAverage.GetResult();

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t0.8V Hi = 0x%08X Lo = 0x%08X Avg = %f\n",
                                      CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                      fOneVolt));
#endif
        ulCount = (UINT32) fOneVolt;
        if ((ulCount < LCOST_0_8_VOLT_LOLIMIT) ||
            (ulCount > LCOST_0_8_VOLT_HILIMIT)){
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0); 
            CalibAll = FALSE; 
            return FALSE; // Abort calibration.
        }   
        fOneVoltArray[ucSeq-1] = fOneVolt;
        for(ucSlot=0;ucSlot<MAXSLOTS;ucSlot++){ 
           ulRawCount[ucSlot] = 0;
        }
    }

    ucEnd = MAXSLOTS; // 1 to 16 chanels. now for 4V
    BlinkLed(1);     

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tNow Apply 4V input to all 16 Channels and touch calib pad"));
#endif

    // Wait till user press and release CALIBRATE switch on the IOTA.
    if(WaitCalibSwitch()==FALSE){
      return FALSE;
     }

    // Average 4V at input channel(16 Channels) for factory calibration.
    for(ucSeq = 1;ucSeq<=ucEnd;ucSeq++){  
        CalInputAverage.Initialize();
        for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) {
        Adc.GetRawData(FALSE,ulRawCount,TRUE);
        ulCount = (ulRawCount[ucSeq-1] & ADC_CHAN_DATA_MASK);
        CalInputAverage.AddSample(ulCount);
        IdleWait(SAMPLE_WAIT);
        }
        fFiveVolt = CalInputAverage.GetResult();

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t4V Hi = 0x%08X Lo = 0x%08X Avg = %f\n",
                                      CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                      fFiveVolt));
#endif
        ulCount = (UINT32) fFiveVolt;
        if ((ulCount < LCOST_FOUR_VOLT_LOLIMIT) ||
            (ulCount > LCOST_FOUR_VOLT_HILIMIT)){
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE; 
            return FALSE; // Abort calibration.
        }  

        fFiveVoltArray[ucSeq-1] = fFiveVolt;
        for(ucSlot=0;ucSlot<MAXSLOTS;ucSlot++){
           ulRawCount[ucSlot] = 0;
        }
    }
    // Clear bad calibration reference softfail if any.
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,0);

    BlinkLed(2);

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tTouch calib pad module will reboot"));
#endif
    // Wait till user press and release CALIBRATE switch on the IOTA.
       if(WaitCalibSwitch() == FALSE){
          return FALSE; // Abort calibration
       }
    BlinkLed(3);

    // Calculating the slope and offset for each channel.
    for (ucSlot = 0; ucSlot < MAXSLOTS ; ucSlot++)
    {
           CalibData.fCalibrationSlope[ucSlot]  = (4.0 - 0.8) / (fFiveVoltArray[ucSlot] - fOneVoltArray[ucSlot]);
           CalibData.fCalibrationOffset[ucSlot] = 0.8 - (CalibData.fCalibrationSlope[ucSlot] * fOneVoltArray[ucSlot]);
     }   
     
#endif
    if (FlashCalibrationData()) {
        // Calibrtion is successful.
        TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibDone,MODULEINFO_WRITECOUNT);

#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalibration successful"));
#endif
#if LOWCOST
        // Clear write message queue before rebooting IOM, as it is utilised for 
        // copying ProgramFlash and EraseFlash routines before flashing
        UINT16 usItr;
        UINT8* ucPtr = WriteMsgQueue.GetMsgBufferPtr();
        // Wait for a watchdog refresh to happen so that there is maximum time is
        // available to the flash uitility before the next watchdog refresh window.
        while (TaskScheduler.GetWdtRefreshCounter() != 0);

        for(usItr = 0;usItr < WRITEMSG_QUEUESIZE;usItr++) {
            ucPtr[usItr] = 0x00;
        }
#endif
        // Reboot the module so that the new 
        // calibration data gets loaded.
        RebootIom();

        /*         
         * Since FRAM is replaced with backup SRAM, calibration done must be stored in FLASH only.
         */
#if defined(IOPTYPE_HLAI)
        xRamWrite((xRAM_CHKPNT_ADRS + xRAM_CALIB_DONE), (UINT8 *)&TRUE, sizeof(UINT8));
#endif
    }

    CalibAll = FALSE;
    return FALSE;
}


/*******************************************************************************
*                           clsAihBoxSlot::AppColdInit                         *
*                           ==========================                         *
*                                                                              *
*******************************************************************************/
VOID clsAihBoxSlot::AppColdInit(VOID) {
    if (MODSTATUS_RUN == ModStat1.Status) {
        ModStat1.Status = MODSTATUS_IDLE;
        AddModStatEvent(EVENTTYPE_NORMAL);
    }
    DbValid = DB_INVALID;
    ComputeCheckSum(); // Recompute BOX checksum
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        // Slot checksum is recomputed by InitSlotDatabase.
        SLOT(ucSlotNum)->InitSlotDatabase(TRUE);
    }
}

VOID clsAihBoxSlot::AppPostSwap(VOID) {
}

/*******************************************************************************
*                           clsAihBoxSlot::AppPostSync                         *
*                           ==========================                         *
*  AppPostSync is called from PostRedState for application specific actions    *
*  after a database dump.                                                      *
*******************************************************************************/
VOID clsAihBoxSlot::AppPostSync(VOID) {
    if (!Iol.AmPrimary()) {
        // If this is secondary module, recompute and update the number of 
        // 1-second channels. If the number of 1-second channels exceeded the
        // maximum allowed due to a databse dump from old version IOM, raise
        // HART diagnostic underrun softfail.
        UINT8 uc1SecChans = 0;
        clsHartDevDb::SetNoOf1SecChannels(0);
        
        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
            if ((SLOT(ucChan)->GetPtExecSt() == PTEXECST_ACTIVE) &&
                ((HSCANCFG_1SECDEV == SLOT(ucChan)->GetHartCfgDb().HScanCfg) ||
                 (HSCANCFG_1SECDYN == SLOT(ucChan)->GetHartCfgDb().HScanCfg) ||
                 (HSCANCFG_2SECDEVDYN == SLOT(ucChan)->GetHartCfgDb().HScanCfg))) {
                uc1SecChans++;
            }
        }

        if (uc1SecChans > MAX_1SEC_CHANNELS) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_HDIAGTO,TRUE,0);
        }
        clsHartDevDb::SetNoOf1SecChannels(uc1SecChans);
        PartnersChkPntVer = 0;
    }
    else {  // Primary Module
        PartnersChkPntVer = 0;
    }
}

VOID clsAihBoxSlot::AppPreDump(VOID) { 
    if(Iol.AmPrimary())
        PartnersChkPntVer = LATEST_SLTCHKPNT_VERSION;
    else
        PartnersChkPntVer = 0;
}

VOID clsAihBoxSlot::AppPostDump(VOID) { 
	/*
    if(!Iol.AmPrimary()) {
        if(PartnersChkPntVer < LATEST_SLTCHKPNT_VERSION)
        {
            for(UINT8 ucItr = 1;ucItr <= MAXSLOTS;ucItr++) {
                SLOT(ucItr)->Hart7Dump();
            }
        }
    }*/
}
