/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : doversion.h                                                 *
*    Description : Digital Output firmware version declaration.                *
*******************************************************************************/
#ifndef DOVERSION_H
#define DOVERSION_H
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#ifdef DEVELOPER_BUILD_OVERRIDE
    const UINT8 VERSION_NUMBER  = VERSION;
    const UINT8 REVISION_NUMBER = REVISION;
    const UINT8 BUILD_NUMBER    = BUILD;
    // donot remove below comment lines, if removed version number will be error
    //const UINT8 DO32_VER_NUMBER = VERSION;
    //const UINT8 DO32_REV_NUMBER = REVISION;
    //const UINT8 DO32_BLD_NUMBER = BUILD;
#else
    #if defined(DIGTYPE_DO32)
        /*
         * REV 4.3.0 - Initial release of redesign DO32 IOP
         * REV 4.4.0 - Fix for DO32 PAR # (ON / OFF PULSE NOT DRIVING)
         * REV 4.5.0 - Fix for DO32 PAR # 1-DYV60ED & 1-DYV60ES (ON / PULSE not considering respective pulse period)
         * REV 4.6.0 - Fix for DO32 PAR # 1-E1F06W3 (PWM Pulse not retaining during IOP Failover)
         * REV 4.7.0 - Fix for DO32 PAR # 1-E6TVROZ (flooding OK EVENT ALARM from the secondary module during FO_COMPLETE)
         */
        const UINT8 DO32_VER_NUMBER = 4;
        const UINT8 DO32_REV_NUMBER = 7;
        const UINT8 DO32_BLD_NUMBER = 0;
    #elif defined(DIGTYPE_DO16)
        /*
         * REV 4.3.0 - Initial release of redesign DO16 IOP
         * REV 4.4.0 - Customer(-MiRO) Issue(-CL Fail) Fix + Field upgrade feature in boot code
         * REV 4.5.0 - to fix PAR# 1-EMPNLXD (channel OP does not take failure option value when both IOLink is removed)
         * REV 4.6.0 - to fix PAR# 1-EWTQH7B (On pulse & Off pulse functionality is not working in do16)
         */
        const UINT8 VERSION_NUMBER  = 4;
        const UINT8 REVISION_NUMBER = 6;
        const UINT8 BUILD_NUMBER    = 0;
    #endif
#endif

#endif
