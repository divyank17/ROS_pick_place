/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uioboxslot.hpp                                              *
*    Description : Class clsUioBoxSlot declaration.                            *
*******************************************************************************/
#ifndef __UIOBOXSLOT_HPP__
#define __UIOBOXSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "boxslot.hpp"
#include "uioslot.hpp"
#include "uioversion.h"
#include "uiofpga.hpp"
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/

const UINT16  MACROCYCLE_PERIOD        = 50;    // Repeat processing algorithm every 50 msec
const UINT16  AI_PROCESS_SLOT_PERIOD   = 50;    // AIs should be processed once every 50 msec. This definition is for aihslot functions (Tf).
const UINT16  DI_PROCESS_SLOT_PERIOD   = 10;    // DIs should be processed once every 10 msec. This definition is for dislot functions (LATCHTIME).

const UINT16 CALIB_CHECK_PERIOD        = 10000; // Calibration should be checked every 10 seconds
const UINT16 PIN_DIAG_PERIOD           = 1000;  // Pin diagnostic runs every 1 second
const UINT16 AO_READBACK_PERIOD        = 20;    // AO Readback runs every 20 msec (AF: Try to do 2 times per 50 msec cycle)
const UINT16 DO_LINE_MONITORING_PERIOD = 1000;  // DO line monitoring runs once per second

const UINT16 CALIB_CHECK_CYCLECOUNT        = CALIB_CHECK_PERIOD / SCHEDULER_PERIOD;
const UINT16 PIN_DIAG_CYCLECOUNT           = PIN_DIAG_PERIOD    / SCHEDULER_PERIOD;
const UINT16 AO_READBACK_CYCLECOUNT        = AO_READBACK_PERIOD  / SCHEDULER_PERIOD;
const UINT16 DO_LINE_MONITORING_CYCLECOUNT = DO_LINE_MONITORING_PERIOD / SCHEDULER_PERIOD;
const UINT16 MACROCYCLE_CYCLECOUNT         = MACROCYCLE_PERIOD  / SCHEDULER_PERIOD;

const UINT16 MAX_SUCCESSIVE_CALIBRATIONS = 6;
const UINT16 AI_SLOTS_PER_CYCLE = 7;

// Constants related to INHIN signal
const UINT8  INH_IN_ASSERTED = 1;
const UINT8  INH_IN_NEGATED  = 0;

// DI LatchTimer is calculated based on the number of executions of ProcesSlot
// For 1.5 sec LatchTimer the value is 1500 msec / 10 msec (period of processslot execution) = 150 cycles
const UINT16 LATCHTIMECONST = 1500 / DI_PROCESS_SLOT_PERIOD;

// Constants related to HART
const FLOAT32 HART_UNCONFIGURED_OP      = 131.25;
const FLOAT32 HART_AUTODETECT_OP        = 12.5;
const FLOAT32 HART_AUTODETECT_CURRENT   = 6.0;
const FLOAT32 HART_ZERO_CURRENT         = 0.0;

// UIOBOXSLOT_SIZE is 1/2 of the class size in bytes.
// This is so because database memory is allocated as an array of UINT16.
#define UIOBOXSLOT_SIZE ((sizeof(clsUioBoxSlot) + (sizeof(clsUioBoxSlot) % 2)) / 2)

#define kMaxTempAlarmLimit  (70)
#define kMinTempAlarmLimit  (-40)

#define kNumOfDiPulseCountingChannels 0x04

// definitions and constants to support clsDiSlot
typedef enum tagDiMode
{
    DIMODE_NORMAL    = 0,
    DIMODE_SOE       = 1,
    DIMODE_LOWLATNCY = 2
} DIMODE;

// temperature monitoring
const UINT16 kTempMonitoringPeriod = 10000; // msec
const UINT16 kTempAlarmThrottleCount = 6; // multiple of kTempMonitoringPeriod

// Max skip count to declare AO readback diagnostics fail
const UINT8 kMaxAoReadBackFailCount   = 2;

// Max skip count to declare AO DAC Full diagnostic fail
const UINT8 kMaxAoDacFullDiagFailCount = 2;

// Factory test support for hart testing
typedef union {
    struct {
        UINT8 NumOfChannels;    // DATA0 - represents no of channels to test
        UINT8 StartChannelNum;  // DATA1 - represents starting channel number
        UINT8 DATA2;            // not used. future purpose
        UINT8 DATA3;            // not used. future purpose
    };
    UINT8 DATA[4];
}HARTTESTDATA;

typedef enum tagHartConfData {
    ONECHANNEL       = 0,
    TWOCHANNEL       = 1,
    FOURCHANNEL      = 2,
    EIGHTCHANNEL     = 3,
    SIXTEENCHANNEL   = 4,
    THIRTYTWOCHANNEL = 5,
    INVALIDVALUE     = 6
}HARTCONFDATA;

#define _CompileAssert(_expr) typedef int __dummy[(_expr)];

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsUioBoxSlot; // forward declaration
typedef struct tagBoxParamInfo
{
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    PASTATUS (clsUioBoxSlot::* PrePtr)(UINT8 *,UINT8);
    VOID     (clsUioBoxSlot::* PostPtr)(UINT8);
    VOID *   (clsUioBoxSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

// to avoid padding of structures
#pragma pack 1

// analog input PvScanRec component
typedef struct tagAihPvScanRec
{
    FLOAT32 Pv;
    PVVALST PvSts;
} AIHPVSCANREC;

// analog output PvScanRec component
typedef struct tagAohPvScanRec
{
    FLOAT32 Op;
    BOOL StdByMan;
} AOHPVSCANREC;

// digital input PvScanRec component
typedef struct tagDiPvScanRec
{
    ONOFF PvFl;
    BOOL BadPvFl;
} DIPVSCANREC;

// digital input Pulse counting scan record structure
typedef struct tagDiPcPvScanRec
{
    FLOAT32    Av;
    STATUS     AvSts;
    UINT32     AvRaw;
    STATUS     AvRawSts;
    FLOAT32    Tv;
    BOOL       AvTvFl;
    UINT16     ResetCount;
} DIPCSCANREC;

// digital output PWM PvScanRec component
typedef struct tagDoPvScanRec
{
    FLOAT32 Op;
    BOOL StdByMan;
} DOPVSCANREC;

// Size of a channel's scan data, in bytes
#define CHAN_SCANRECSIZE (sizeof(AIHPVSCANREC))

// the UIO PvScanRec structure
typedef struct tagPvScanRec
{
    // Point type information for each channel
    PNTTYPE pntType[MAXSLOTS];
    
    // Init request flags for output channels
    UINT32  initRequest;     
    
    // SO values for DO channels
    UINT32  doSoAll;  
    
    union
    {
        AIHPVSCANREC    AIH;
        AOHPVSCANREC    AOH;
        DIPVSCANREC     DI;
        DOPVSCANREC     DO;
        UINT8           RawData[CHAN_SCANRECSIZE];
    } ScanRec[MAXSLOTS];
} PVSCANREC;

// the UIO PcScanRec structure
typedef struct tagPcScanRec
{
    struct
    {
        DIPCSCANREC DIPC;
    }ScanRec[kNumOfDiPulseCountingChannels];
}PCSCANREC;

// PV scan record size, in bytes
#define PVSCANRECSIZE (sizeof(PVSCANREC))

// PV scan record2 size, in bytes
#define PCSCANRECSIZE (sizeof(PCSCANREC))

#pragma unpack 

// integer-based running average for maintaining calibration
struct strRefVoltRunningAverage
{
    static const int Samples = 32;
    UINT32 accum;

    void reset(UINT16 value)
    {
        accum = Samples * value;
    }

    void update(UINT16 value)
    {
        accum = accum - average() + value;
    }

    UINT16 average(void)
    {
        UINT16 avg = accum / Samples;

        if (accum % Samples >= Samples / 2)
        {
            avg++;
        }

        return avg;
    }
};

/*******************************************************************************
*                                 clsUioBoxSlot                                *
*                                ===============                               *
*******************************************************************************/
class clsUioBoxSlot : public clsBoxSlot
{
private:
    PVSCANREC   PvScanRec;
    DIMODE  DiMode;
    INT16   TempHiLm;
    INT16   TempLoLm;
    BOOL    AvTvFlSync[kNumOfDiPulseCountingChannels];
    FLOAT32 TvSync[kNumOfDiPulseCountingChannels];

    // !!!*** BOXSLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the box slot's redundant synch data area
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedBoxSize() must be updated to
    // reference the new end member. This dump record begins in clsBoxSlot.

    PCSCANREC   PcScanRec;
    FLOAT32 TempCur;
    FLOAT32 TempMax;
    FLOAT32 TempMin;

    // Cycle tracking counters and flags    
    UINT16 CycleCounter;
    UINT16 CalibrationCheckCounter;
    UINT16 DoPinDiagnosticCounter;
    UINT16 DoLineMonitoringDiagnosticCounter;
    UINT8  ucCurrentSlotNum;
    BOOL   bSampleAllChannels;
    BOOL   bCheckCalibration;
    BOOL   bExecuteAoReadbackDiagnostic;
    BOOL   bExecuteDoPinDiagnostic;
    BOOL   bExecuteDoLineMonitoringDiagnostic;
    BOOL   bExecuteAoDacFullLoadDiagnostic;

    // Flag used to indicate the module needs to be cold-initialized
    // (occurs when the module's DSA gets cleared)
    BOOL   bScheduleAppColdInit;

    // Flag used to indicate that the AO DAC Full Load
    // diagnostic should be scheduled.
    //
    // NOTE:  Made this flag volatile since it can be
    //        modified by IOLINK interrupts.
    volatile BOOL bScheduleAoDacFullLoadDiagnostic;

    // This variable holds the channel number set by iolink 
    // time sync cmd to schedule AO DAC Full load diagnostic.
    UINT8 ucIolChannelToExecuteAoDacFullDiagnostic;

    // This variable holds the value of ucIolChannelToExecuteAoDacFullDiagnostic
    // parameter and set before AO DAC Full load diagnostic executed every cycle.
    // This parameter is used to avoid race condition because of the channel number
    // is changing by iolink interrupts.
    UINT8 ucChannelToExecuteAoDacFullDiagnostic;
    
    // Diagnostic counters and flags
    BOOL   bRefVoltagesGood;
    BOOL   bCalibrationGood;
    strRefVoltRunningAverage Avg4v096[eMaxNumIoBoards];

    // Digital Input mask to allow for converting only DIs
    UINT32 DiChannelMask;

    // Analog Output mask to allow for converting only AOs    
    UINT32 AoChannelMask;
    
    // Digital Output mask used to indicate configured DO channels
    UINT32 DoChannelMask;
    
    // State of DO channels used for diagnostics
    UINT32 DoDiagChannelState;
     
    //********************************************************
    // AI Data Members
    //********************************************************
    UINT32 AiDisableOpenWireFO_Mask;
    
    //********************************************************
    // DI Data Members
    //********************************************************
    UINT16 LatchTimeCnt; // Count value corresponding to DiMode   
    UINT32 DiDisableOpenWireFO_Mask;
    
    //********************************************************
    // AO Data Members
    //********************************************************
    BOOL   bDisOpInternlUpdte; // Flag to indicate OpInternal to update or not    
    UINT32 AoDisableOutputFailFO_Mask;
    UINT32 AoDisableDacFullFailFO_Mask;

    //********************************************************
    // DO Data Members
    //********************************************************
    UINT32 DoOutputBuffer1;
    UINT32 DoOutputBuffer2;
    UINT32 DoOverCurrent;
    UINT32 DoDisableOutputFailFO_Mask;
    UINT32 DoDisableOpenWireFO_Mask;

    //********************************************************
    // Data members related to HART
    //********************************************************
    FLOAT32 HCuAvail[HARTMODEM_COUNT];
    BLIND   HGChngFl[MAXSLOTS];
    UINT16  HGCfgChgCnt[MAXSLOTS]; //Config Change counter of all the channels.
    UINT8   HGDevSt[MAXSLOTS];     //Device status of all the channels.  
    BOOL    HADCEnable[MAXSLOTS];
    UINT8   HADCStatus[MAXSLOTS];
    UINT8   AdcCycleCount[MAXSLOTS];
    FLOAT32 Op_Saved[MAXSLOTS];
    BOOL    HEnableSaved[MAXSLOTS];

    //********************************************************
    // Temperature alarm throttling
    //********************************************************
    UINT16 HiTempAlarmThrottleCount;
    UINT16 LoTempAlarmThrottleCount;

    //********************************************************
    //Data memebrs related to factory support
    //********************************************************
    HARTTESTDATA HartTestData;    // hart test configuration data. 
    UINT8        ucCurrentChannel; // Current channel to test
    UINT8        ucNextChannel;   // Next channel to test

    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const BOXPARAMINFO tblParamInfo[256];

    // Parameter access pre/post functions
    PASTATUS PreCheckPoint(UINT8 *,UINT8);
    PASTATUS PreTempHiLm(UINT8 *,UINT8);
    PASTATUS PreTempLoLm(UINT8 *,UINT8);
    VOID PostTempLm(UINT8);
    VOID PostStatReset(UINT8);
    PASTATUS PreDiMode(UINT8 *a_Writebuffer , UINT8 a_ucAccLvl);
    PASTATUS PreSetConfData(UINT8 *,UINT8);
    VOID PostSetConfData(UINT8);
    PASTATUS PreHADCEnable(UINT8 *,UINT8);
    VOID     PostHADCEnable(UINT8);

    // Parameter pointer access functions
    inline VOID *GetPvScanRecPtr(VOID){return &PvScanRec;}
    inline VOID *GetPcScanRecPtr(VOID){return &PcScanRec;}
    inline VOID *GetTempCurPtr(VOID){return &TempCur;}
    inline VOID *GetTempMaxPtr(VOID){return &TempMax;}
    inline VOID *GetTempMinPtr(VOID){return &TempMin;}
    inline VOID *GetTempHiLmPtr(VOID){return &TempHiLm;}
    inline VOID *GetTempLoLmPtr(VOID){return &TempLoLm;}
    inline VOID *GetHGCfgChgCntPtr(VOID){ return (VOID *)HGCfgChgCnt; }
    inline VOID *GetHGChngFlPtr(VOID)   { return (VOID *)HGChngFl; }
    inline VOID *GetHADCEnablePtr(VOID)   { return (VOID *)HADCEnable; }
    inline VOID *GetHADCStatusPtr(VOID)   { return (VOID *)HADCStatus; }
    inline VOID *GetHCuAvailBoard1Ptr(VOID)  { return (VOID *)&HCuAvail[0]; }
    inline VOID *GetHCuAvailBoard2Ptr(VOID)  { return (VOID *)&HCuAvail[1]; }
    inline VOID *GetHGDevStPtr(VOID)    { return (VOID *)HGDevSt;}

    inline VOID *GetDiModePtr(VOID){return &DiMode;}
    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[BoxChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams;}
    inline VOID *GetSetConfPtr(VOID) { return &HartTestData; }

    // Allow AI Slot to access the scan record for parameter access
    friend VOID *clsAixSlot::GetPvPtr(VOID);
    friend VOID *clsAixSlot::GetPvStsPtr(VOID);
    friend VOID clsAixSlot::InitAixSlot(BOOL bFullInit, BOOL bObjCreate);

    // Allow DI Slot to access the scan record for parameter access
    friend VOID *clsDiSlot::GetPvPtr(VOID);
    friend VOID *clsDiSlot::GetBadPvFlPtr(VOID);
    friend VOID *clsDiSlot::GetAvPtr(VOID);
    friend VOID *clsDiSlot::GetAvStsPtr(VOID);
    friend VOID *clsDiSlot::GetAvRawPtr(VOID);
    friend VOID *clsDiSlot::GetAvRawStsPtr(VOID);
    friend VOID *clsDiSlot::GetAvTvFlPtr(VOID);
    friend VOID *clsDiSlot::GetTvPtr(VOID);

    // Allow DO Slot to access the scan record for parameter access
    friend VOID *clsDoSlot::GetInitReqPtr(VOID);
    
    // Allow AO Slot to access the scan record for parameter access
    friend VOID *clsAohSlot::GetOpPtr(VOID);
    friend VOID *clsAohSlot::GetInitReqPtr(VOID);
    friend VOID *clsAohSlot::GetStdbyManPtr(VOID);

    // Generic IOM parameter access functions
    UINT8 *  GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsUioBoxSlot(const clsUioBoxSlot&); // Safeguard against default copy constr.
    clsUioBoxSlot& operator=(const clsUioBoxSlot&); // and default assignment.
    
    //********************************************************
    // Diagnostic Functions
    //********************************************************
    VOID ExecuteDoLineMonitoringDiagnostic(VOID);
    VOID ExecuteAoReadbackDiagnostic(VOID);
    VOID ExecuteDoPinDiagnostic(VOID);
    VOID ExecuteAoDacFullLoadDiagnostic(VOID);

    // AppStcProcessing functions for Box Slot Processing
    VOID CommandConversions(VOID);
    VOID MonitorCalibrationAndReferenceVoltages(VOID);
    VOID MaintainCounters(VOID);
    VOID SetBadPVs(VOID);

public:
    clsUioBoxSlot(MODLTYPE);
    ~clsUioBoxSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,UIOBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32) { return ucIomDbMemory; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,UIOBOXSLOT_HPP,__LINE__); } 

    static VOID IRQ3InterruptHandler(VOID);

    VOID AppInitialization(VOID);
    VOID AppStcProcessing(VOID);

    // redundancy related functions    
    VOID CheckFailOverCondition(VOID);
    BOOL SwitchInit(VOID);    
    VOID SetForPrimary(VOID);
    VOID SetForSecondary(BOOL bDoCheck = FALSE);

    // factory suppurt
    RETURNSTATUS HartLoopBackTest(VOID);
    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       AppColdInit(VOID);
    BOOL       AppFOProcess(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);
    VOID       AppPreDump(VOID);
    VOID       AppPostDump(VOID);

    // Channel type specific box slot processing functions
    VOID  DigitalInputProcessing(VOID);
    VOID  DigitalOutputProcessing(VOID);
    VOID  AnalogInputProcessing(VOID);
    VOID  ProcessUioDiPulseCountChannel(UINT8 ucSltNm);   // Do point processing for pulse counting channel

    // Temperature Monitoring methods
    VOID MonitorTemperature(BOOL bThrottleRtn = TRUE);
    inline VOID DecrementTempAlarmThrottleCounts(VOID)
    {
        if (HiTempAlarmThrottleCount) { HiTempAlarmThrottleCount--; }
        if (LoTempAlarmThrottleCount) { LoTempAlarmThrottleCount--; }
    }
    inline UINT16 GetTemperatureMonitoringPeriod(VOID) { return kTempMonitoringPeriod; }

    inline UINT32 GetRedBoxDelta(VOID)   { return (sizeof(TvSync)+sizeof(AvTvFlSync)); }
    inline UINT32 GetRedBoxSize(VOID)    { return ((UINT32)((UINT8 *)&TvSync - (UINT8 *)&ModStat1) + sizeof(TvSync)); }
    inline UINT8 *GetRedBoxPointer(VOID) { return (UINT8 *)&ModStat1; }

    PASTATUS PostUioBoxSlotDump(VOID);

    VOID InitializeChannelData(UINT8 a_ucChanNum, PNTTYPE pntType);

    inline SOFTFAILTYPE GetSlotSfMapEntry(UINT8 idx) { return SlotSfMap[idx]; }

    // InitPntType accessor functions
    PNTTYPE GetInitPntType(UINT8 a_ucChanNum);
    PNTTYPE * GetInitPntTypePtr(UINT8 a_ucChanNum);
    
    virtual UINT8 GetSlotChkPntParamId(VOID) {return NULL;}
    virtual UINT8 GetPtExecStParamId(VOID) {return NULL;}
    virtual UINT8 GetLatestSlotChkPntVersion(VOID) {return NULL;}   
    
    //********************************************************
    // Common AO/DO Functions
    //********************************************************
    inline VOID SetInitReq(UINT8 a_ucChanNum,BOOL a_bInitReq)
    {
        if (a_bInitReq)
        {
            SetBit(&PvScanRec.initRequest, a_ucChanNum - 1);
        }
        else
        {
            ClearBit(&PvScanRec.initRequest, a_ucChanNum - 1);
        }
    }

    inline BOOL GetInitReq(UINT8 a_ucChanNum)
    {
        return GetBit(PvScanRec.initRequest, a_ucChanNum - 1);
    }

    //********************************************************
    // DI Functions
    //********************************************************
    inline ONOFF GetDiPv(UINT8 a_ucChanNum) 
    {
        return (PvScanRec.ScanRec[a_ucChanNum-1].DI.PvFl);
    }
    
    inline VOID SetPv(UINT8 a_ucChanNum, ONOFF a_Pv)
    {
        PvScanRec.ScanRec[a_ucChanNum-1].DI.PvFl = a_Pv;
    }

    inline VOID SetBadPvFl(UINT8 a_ucChanNum, BOOL a_BadPvFl)
    {
        PvScanRec.ScanRec[a_ucChanNum-1].DI.BadPvFl = a_BadPvFl;
    }

    inline VOID InitializeDiPcScanRec(UINT8 a_ucChanNum){
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.Av          = NaN;
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvSts       = STATUS_BAD;
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvRaw       = 0;
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvRawSts    = STATUS_BAD;
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvTvFl      = FALSE;
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.Tv          = NaN;
        TvSync[a_ucChanNum-PC_CHANNEL1]                             = NaN;
        AvTvFlSync[a_ucChanNum-PC_CHANNEL1]                         = FALSE;

        // Initialize the ResetCount.  The TOP (A) and BOTTOM (B) modules use different sets of
        // numbers for the ResetCount.  The TOP (A) uses even numbers while the BOTTOM (B) module
        // uses odd numbers.
        // On swap/switchover/failover, the AVRAW will reset 0, causing a bump (this is by design,
        // UIO does not sync the pulse count).  The even/odd scheme for ResetCount will ensure a
        // downstream PITOTALIZER block will see a change in the ResetCount on a switchover, which
        // allows the PITOTALIZER to gracefully handle the reset of AVRAW to 0.
        if (!(BOTTOM))
        {
            // The TOP module (A) uses even numbers exclusively for ResetCount
            PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.ResetCount = 0;
        }
        else
        {
            // The BOTTOM module (B) uses odd numbers exclusively for ResetCount
            PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.ResetCount = 1;
        }
    }

    inline FLOAT32 GetAv(UINT8 a_ucChanNum) { 
        return PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.Av;
    }
    
    inline STATUS GetAvSts(UINT8 a_ucChanNum) { 
        return PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvSts;
    }

    inline UINT32 GetAvRaw(UINT8 a_ucChanNum) { 
        return PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvRaw;
    }

    inline STATUS GetAvRawSts(UINT8 a_ucChanNum) { 
        return PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvRawSts;
    }

    inline FLOAT32 GetTv(UINT8 a_ucChanNum) { 
        return PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.Tv;
    }

    inline BOOL GetAvTvFl(UINT8 a_ucChanNum) { 
        return PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvTvFl;
    }
    inline VOID IncrementResetCount(UINT8 a_ucChanNum) {
        UINT16 count = PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.ResetCount;

        // On UIO, the ResetCount is incremented by 2.  The TOP (A) module exclusively uses even-
        // numbered reset counts while the BOTTOM (B) module exclusively uses odd-numbered reset
        // counts.  This number system is initiated in InitializeDiPcScanRec and maintained here by
        // incrementing by 2.  See comments in InitializeDiPcScanRec for more details.
        count += 2;
        if (0xFFFF == count) {
            // must not use 0xFFFF, this has special init purpose for the PITOTALIZER block
            count += 2;
        }

        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.ResetCount = count;
    }

    inline VOID StoreAv(UINT8 a_ucChanNum,FLOAT32 a_fAv) {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    // disable IOL interrupts
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.Av = a_fAv;
        set_imask_exr(uiMask);         // re-enable IOL interrupts
    }

    inline VOID StoreTv(UINT8 a_ucChanNum,FLOAT32 a_fTv) {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    // disable IOL interrupts
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.Tv = a_fTv;
        set_imask_exr(uiMask);         // re-enable IOL interrupts
    }

    inline VOID StoreTvForSync(UINT8 a_ucChanNum,FLOAT32 a_fTv) {
        TvSync[a_ucChanNum-PC_CHANNEL1] = a_fTv;
    }

    inline VOID StoreAvSts(UINT8 a_ucChanNum, STATUS a_AvSts) { 
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvSts = a_AvSts;
    }   
    
    inline VOID StoreAvRaw(UINT8 a_ucChanNum,UINT32 a_ulAvRaw) {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);    //disable IOL interrupts
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvRaw= a_ulAvRaw;
        set_imask_exr(uiMask);         // re-enable IOL interrupts
    }

    inline VOID StoreAvRawSts(UINT8 a_ucChanNum, STATUS a_AvRawSts) { 
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvRawSts = a_AvRawSts;
    }

    inline VOID StoreAvTvFl(UINT8 a_ucChanNum, BOOL a_AvTvFl) { 
        PcScanRec.ScanRec[a_ucChanNum-PC_CHANNEL1].DIPC.AvTvFl = a_AvTvFl;
        AvTvFlSync[a_ucChanNum-PC_CHANNEL1] = a_AvTvFl;
    }

    VOID SyncTvProcessing(VOID){
        UINT8 ucTvSyncCount;
        for(ucTvSyncCount=0;ucTvSyncCount<kNumOfDiPulseCountingChannels;ucTvSyncCount++)
        {
            PcScanRec.ScanRec[ucTvSyncCount].DIPC.Tv = TvSync[ucTvSyncCount];
            PcScanRec.ScanRec[ucTvSyncCount].DIPC.AvTvFl  = AvTvFlSync[ucTvSyncCount];
        }
    }

    inline UINT16 GetLatchTimeCnt(VOID){ return LatchTimeCnt;}    

    // The following functions are needed for interoperability with the DI existing slot.  Stub out functionality.
    inline DIMODE GetDiMode(VOID)   { return DiMode; }  // only DIMODE_NORMAL is supported on the UIO
    inline UINT8  GetModlType(VOID) { return MODLTYPE_DIL; }   // DI slot on UIO should behave like DI slot on DI-24
    inline UINT32 GetForcedInputDiagStatus(VOID){ return 0; } // No forced diagnostics on UIO.  All zeros means no failures.

    //********************************************************
    // AI Functions
    //********************************************************
    inline FLOAT32 GetPv(UINT8 a_ucChanNum) { return PvScanRec.ScanRec[a_ucChanNum - 1].AIH.Pv; }
    inline PVVALST GetPvSts(UINT8 a_ucChanNum) { return PvScanRec.ScanRec[a_ucChanNum - 1].AIH.PvSts; }

    inline VOID SetPv(UINT8 a_ucChanNum, FLOAT32 a_fPv)
    {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        PvScanRec.ScanRec[a_ucChanNum - 1].AIH.Pv = a_fPv;
        set_imask_exr(uiMask);
    }

    inline VOID SetPvSts(UINT8 a_ucChanNum, PVVALST a_PvSts)
    {
        PvScanRec.ScanRec[a_ucChanNum - 1].AIH.PvSts = a_PvSts;
        AIH_SLOT(a_ucChanNum)->UpdateBadPvFl(PVVALST_BAD == a_PvSts);
    }
 
    inline UINT8 GetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) { return (HGChngFl[a_ucSlot - 1] & a_ucBit); }
    inline VOID SetHGCfgChgCnt(UINT8 a_ucSlot,UINT16 a_ucCfgChgCnt) { HGCfgChgCnt[a_ucSlot - 1] = a_ucCfgChgCnt; }
    inline VOID SetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) { HGChngFl[a_ucSlot - 1] |= a_ucBit; }
    inline VOID ResetHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) { HGChngFl[a_ucSlot - 1] &= ~a_ucBit; }
    inline VOID ToggleHGChngFlBit(UINT8 a_ucSlot,UINT8 a_ucBit) { HGChngFl[a_ucSlot - 1] ^= a_ucBit; }
    inline VOID InitHGCfgChgCnt(UINT8 a_ucSlot) { HGCfgChgCnt[a_ucSlot - 1] = 0; }
    inline VOID InitHGChngFl(UINT8 a_ucSlot) { HGChngFl[a_ucSlot - 1] = 0; }
    inline VOID SetHGDevSt(UINT8 a_ucSlot,UINT8 a_ucSts) { HGDevSt[a_ucSlot - 1] = a_ucSts; }
    inline FLOAT32 GetHCuAvail(UINT8 modem) { return HCuAvail[modem]; }
    inline VOID SetHCuAvail(FLOAT32 a_fVal, UINT8 modem) { HCuAvail[modem] = a_fVal; }

    // The following functions are needed for interoperability with the existing AI slot.  Stub out functionality.
    inline BOOL GetCalibAllState(VOID) { return FALSE; }  // Calibration not commanded on UIO.
    inline BOOL IsOwdCktGood(VOID) { return TRUE; }  // No open wire detection circuit to diagnose.
    
    //********************************************************
    // DO Functions
    //********************************************************

    VOID UpdateOutputBuffer2(UINT8 a_ucChanNum,BOOL a_bOutput);

    inline VOID SetDoOp(UINT8 a_ucChanNum, FLOAT32 newOp)
    {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        PvScanRec.ScanRec[a_ucChanNum - 1].DO.Op = newOp;
        set_imask_exr(uiMask);
    }

    inline BOOL GetOverCurrent(UINT8 a_ucChanNum)
    {
        return GetBit(DoOverCurrent, a_ucChanNum - 1);
    }

    inline VOID SetOverCurrent(UINT8 a_ucChanNum, BOOL a_bOutput) 
    {
        if (a_bOutput)
        {
            SetBit(&DoOverCurrent, a_ucChanNum - 1);
        }
        else
        {
            ClearBit(&DoOverCurrent, a_ucChanNum - 1);
        }
    }

    inline VOID EnableOutputFailFO(VOID) { SetSfActionBit(SF_OUTPUTFL); }
    inline VOID EnableOpenWireFO(VOID) { SetSfActionBit(SF_OPENWIRE); }
    inline VOID SetDOMask(UINT8 a_ucChanNum)   { SetBit(&DoChannelMask, a_ucChanNum - 1); }     // Set Do channel mask
    inline VOID ClearDOMask(UINT8 a_ucChanNum) { ClearBit(&DoChannelMask, a_ucChanNum - 1); }   // Clear Do channel mask

    //********************************************************
    // AO Functions
    //********************************************************
    
    inline void ScheduleAoDacFullLoadDiagnostic(UINT8 ucChanNum) 
    { 
       bScheduleAoDacFullLoadDiagnostic = TRUE; 
       ucIolChannelToExecuteAoDacFullDiagnostic = ucChanNum;
    }
    
    inline FLOAT32 GetOp(UINT8 a_ucChanNum) { return PvScanRec.ScanRec[a_ucChanNum - 1].AOH.Op; }

    inline VOID SetOp(UINT8 a_ucChanNum, FLOAT32 a_fOp, BOOL a_bDrvOp = TRUE)
    {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        PvScanRec.ScanRec[a_ucChanNum - 1].AOH.Op = a_fOp; 
        set_imask_exr(uiMask);
        BOOL bDrvOp = a_bDrvOp; // To avoid constant in condition compiler warning.
        if (bDrvOp)
        {
            AOH_SLOT(a_ucChanNum)->SetOpInternl(a_fOp);
            AOH_SLOT(a_ucChanNum)->UpdateOpFinal(a_fOp) ;
        }
    }
 
    inline BOOL   GetStdbyMan(UINT8 a_ucChanNum) { return (PvScanRec.ScanRec[a_ucChanNum - 1].AOH.StdByMan); }
    inline VOID   SetStdbyMan(UINT8 a_ucChanNum,BOOL bStdbyMan) { PvScanRec.ScanRec[a_ucChanNum - 1].AOH.StdByMan = bStdbyMan; }
    inline VOID   AppSyncver(VOID){ bDisOpInternlUpdte = FALSE;}
    inline BOOL   GetbDisOpInternlUpdteSts() { return bDisOpInternlUpdte; }

    inline UINT16 GetDac50Percent(VOID){return 0xFFFF;} // <JRF ToDo> stub, verify that "> 50%" check is not needed
    inline BOOL GetHAutoDet(UINT8) { return FALSE; }
    inline VOID ResetHAutoDet(UINT8) {}

    inline BOOL IsPrimaryChannelInFail(UINT8) { return FALSE; } // stub, "PartnerSlotInFail" was never actually implemented on SerC AO

    inline VOID SetLastChannel(VOID) { ucCurrentChannel = ucNextChannel; } // factory support
    
    //********************************************************
    // HART Functions
    //********************************************************

    inline FLOAT32 GetOpSaved(UINT8 a_ucSlot) { return Op_Saved[a_ucSlot - 1]; }
    inline VOID SetOpSaved(UINT8 a_ucSlot, FLOAT32 fValue) { Op_Saved[a_ucSlot - 1] = fValue; }
    inline BOOL GetHADCEnable(UINT8 a_ucSlot) { return HADCEnable[a_ucSlot - 1]; }
    inline UINT8 GetHADCStatus(UINT8 a_ucSlot) { return HADCStatus[a_ucSlot - 1]; }
    inline VOID ResetHADCEnable(UINT8 a_ucSlot) { HADCEnable[a_ucSlot - 1] = FALSE; }
    inline VOID SetHADCStatus(UINT8 a_ucSlot, UINT8 a_ucStatus) { HADCStatus[a_ucSlot - 1] = a_ucStatus; }
    inline VOID DecAdcCycleCount(UINT8 a_ucSlot) {if (AdcCycleCount[a_ucSlot - 1] != 0) AdcCycleCount[a_ucSlot - 1] -= 1; }
    inline UINT8 GetAdcCycleCount(UINT8 a_ucSlot) {return AdcCycleCount[a_ucSlot - 1]; }
    inline VOID SetAdcCycleCount(UINT8 a_ucSlot, UINT8 a_ucCount) {AdcCycleCount[a_ucSlot - 1] = a_ucCount; }

    inline BOOL IsDumpInProgress(VOID)
    {
        return (GetRedState() >= REDSTATE_DUMP_START);
    }

    inline VOID ScheduleAppColdInit(VOID)
    {
        bScheduleAppColdInit = TRUE;
    }
};

#endif
