/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : domain.h                                                    *
*    Description : common defines used by module                               *
*******************************************************************************/
#ifndef __DOMAIN_H__
#define __DOMAIN_H__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "commonelectronics.h"
#include "tracelog.hpp"
#include "scheduler.hpp"
#include "debug.hpp"
#include "diag.h"
#include "wrmsgque.hpp"
#include "doversion.h"
#include "doboxslot.hpp"
#include "doslot.hpp"

#endif 
