/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uiomain.cpp                                                 *
*    Description : Universal I/O module application specific startup code.     *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "uiomain.h"
#include "iol.hpp"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN HartTask(TASKCONTEXT);
extern TASKRETURN DiagnosticTask(TASKCONTEXT);

#ifdef DEBUG
    extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
WRITEINPROGRESS  WriteInProgress;
#ifdef DEBUG
    clsDebugPort DebugPort;
#endif

//To Retain the tracelogs at Reset
#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section

#pragma section INTERNALRAM_SECTION
clsTaskScheduler TaskScheduler;
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;
clsUioFpga       FPGA;
#pragma section

// Pointers to database objects
clsIomSlot *pDatabase[MAXSLOTS + 1];

// Database Memory
UINT16 ucIomDbMemory[UIOBOXSLOT_SIZE + (MAXSLOTS * UIOSLOT_SIZE)];

// RAM reserved for configured slots
#pragma section EXTERNALRAM_SECTION
    UINT16 ucConfiguredSlotDbMemory[MAXSLOTS * CONFIGUREDSLOT_SIZE];
#pragma section

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//NOTE:
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                            WriteDatabaseTask
                                           ,LowPriorityTask
                                           ,EventRecoveryTask
                                           ,HartTask
                                           ,DiagnosticTask
#ifdef DEBUG
                                           ,DebugTask
#endif
};

/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
*    Application specific startup code.                                        *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function is called by the PowerOn reset vector.                      *
*******************************************************************************/
VOID main(VOID) 
{
    // Create box database object
    pDatabase[0] = new clsUioBoxSlot(MODLTYPE_UIO);
    TraceLog.AddToTrace(TRACEID_GENERIC,bcUioIom,BOX->GetDPA());

    // Create slot database objects
    for (UINT8 ucSltNm = 0; ucSltNm < MAXSLOTS; ucSltNm++) {
        pDatabase[ucSltNm + 1] = new(ucSltNm) clsUioSlot(ucSltNm + 1);
    }
    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();

    CheckAndInitHart();

    // Initialize all periodic tasks
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
                                        DMCPERIOD_LPTASK);
    TaskScheduler.InitPeriodicTask(TASKID_HARTTASK,TASKPERIOD_HARTTASK,
                                        DMCPERIOD_HARTTASK);
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
                                        DMCPERIOD_DIAGTASK);

#ifdef DEBUG
   // Set the Debug Task to RUN State
    TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif

    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}
/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE:                                                                     *
*    Demo purpose task code.                                                   *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
* Runs Task every 100 msec, can view LowPriorityTask over Debug terminal       *
* to identify the task                                                         *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    // start exec counter at 1 to delay the first temperature reading to give the
    // digital thermometer enough time for the first temperature conversion
    static UINT16 lptTaskExecCount = 1;

    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

    // HartLoopback test for factory support
    if(TRUE == HartLoopBkTestInProgress)
    {
        HartLoopBkTestInProgress = (RETURNSTATUS_INPROGRESS == BOX->HartLoopBackTest());
    }

    // Check for Communication failure and CEE Failure. If any one of 
    // these present, call FaultHandling function which sheds output
    // based on the Mode and ModeAttr configuration.
    TOG_FAILED TogFailed = BOX->IsTogFailed();
    if (NOTOG_FAILED != TogFailed) 
    {
        // tell partner about TOG fail condition
        TOGFAILED_OUT = 1;

        for (UINT8 ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) 
        {
            switch (BOX->GetInitPntType(ucChannel))
            {
                case PNTTYPE_ANALOGOUTPUT:                    
                case PNTTYPE_DIGITALOUTPUT:
                
                    if(FAULTSTATE_NORMAL == OUT_SLOT(ucChannel)->GetFaultState()) 
                    {
                        OUT_SLOT(ucChannel)->SlotFaultHandler(TogFailed);
                    }
                    
                    break;
                    
                default:
                    break;
            }
        }
    }
    else if ((BOX->GetComTog() == TRUE) && (BOX->GetCtlTog() == TRUE)) 
    { 
        // If both CTL and COMM TOG is present
        for (UINT8 ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) 
        {
            switch (BOX->GetInitPntType(ucChannel))
            {
                case PNTTYPE_ANALOGOUTPUT:                     
                case PNTTYPE_DIGITALOUTPUT:
                
                    if(FAULTSTATE_FAULTED == OUT_SLOT(ucChannel)->GetFaultState()) 
                    {
                        OUT_SLOT(ucChannel)->ResetFaultState();
                    }
                    
                    break;
                 
                default:
                    break;
            }
        }

        // tell partner about TOG healthy condition
        TOGFAILED_OUT = 0;
    }

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();
    
    // Process BRDP Handle and Message Timeout every second.
    if (BOX->BRDPOneSecCounter >= 10) {
        BOX->BRDPOneSecCounter = 0;
        BOX->ProcessBrdpTimeout();
    }
    else
        BOX->BRDPOneSecCounter++;

    // periodically monitor the temperature
    if (0 == (lptTaskExecCount % (BOX->GetTemperatureMonitoringPeriod() / TASKPERIOD_LPTASK)))
    {
        BOX->DecrementTempAlarmThrottleCounts();
        BOX->MonitorTemperature();
    }

    // increment the task execution counter
    lptTaskExecCount++;

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}

