/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : turbineelectronics.h                                        *
*    Description : Declaration of turbine controller specific constants      . *
*******************************************************************************/
#ifndef __TURBINEELECTRONICS_H__
#define __TURBINEELECTRONICS_H__
/*******************************************************************************
*                             TYPES & ENUMERATIONS                             *
*******************************************************************************/

//AI ( Standard AI) Control Registerf
struct AICTRLBITS {          // bits description
    UINT16  reserved2:8;    // 0 - 9
    UINT16  Ai_Data_rd:1;    // 10        Ai data Ready
    UINT16  Overt_Ai:1;      // 11        Overt Ai
    UINT16  Mux_ctrl:2;      // 12 - 13   mux ctrl  0
    UINT16  Ai_Req_bit:1;    // 14   Ai Req Bit
    UINT16  Mux_en:3;        // 15   mux enable 0
};

union AICTRL {
   UINT16              all;
   struct AICTRLBITS   bit;
};

//AO ( Standard AO) Control Registers
struct AOCTRL1BITS {            //  bits  description
    UINT16  reserved1   :8;     //  0 - 5
    UINT16  Ao_Rdbk_Mux_en:1;   //  8 AO readback Mux Enable: Actieve LOW, Default HIGH
    UINT16  Ao_Rdbk_Mux_ctrl:3; //  9 - 11 AO readback Mux control, Default HIGH
    UINT16  Ao_Op_Mux_En:1;     //  12   AO mux control bits, Default HIGH
    UINT16  Ao_Op_Mux :1;       //  13  AO Mux Channel
    UINT16  Ao_Rdbk   :1;       //  14   Status bit - read back AO --- TBD
    UINT16  Ao_Dac_Clr:1;       //  15   AO DAC clear bit: Active LOW,Defaul LOW --- TBD
};

union AOCTRL1 {
   UINT16               all;
   struct AOCTRL1BITS   bit;
};

struct AOCTRL2BITS {                // bits  description
    UINT16  reserved    :8;         // 0 - 7
    UINT16  Inhin_Fb_n  :1;         // 8
    UINT16  Inhst1_Fb2  :1;         // 9
    UINT16  Inhst1_Fb1  :1;         // 10
    UINT16  Inhst2_Fb   :1;         // 11
    UINT16  Disa_Fb2_n  :1;         // 12     reserved
    UINT16  Disa_Fb1_n  :1;         // 13
    UINT16  Disa_Fb_n   :1;         // 14
    UINT16  Test        :1;         // 15     test bit
};

union AOCTRL2 {
   UINT16               all;
   struct AOCTRL2BITS   bit;
};


struct AOCTRL3BITS
{
    UINT16  Key         :8;     //  8-15 Key
    UINT16  Ao_Req      :1;     //  7 AO Request bit
    UINT16  Ao_Data_Rdy :1;     //  6 AO Data Ready
    UINT16  Resvd       :6;     //  5-0  Reserved
};

union AOCTRL3
{
    UINT16 all;
    struct AOCTRL3BITS bits;
};

struct APPBRDCTRBITS
{
    UINT16  Key         :8;     //  8-15 Key
    UINT16  Reserved    :5;     //  3-7  Reserved
    UINT16  EEPROMWRPR  :1;     //  2    EEPROM Write Protect
    UINT16  MastClr     :1;     //  1    Master clear
    UINT16  PWRMON      :1;     //  0    Power Monitor
};

union APPBRDCTRLREG
{
    UINT16 all;
    struct APPBRDCTRBITS bit;
};

union FpgaCtlReg {
    struct {
        unsigned int    Key:8;
        unsigned int    B7:1;
        unsigned int    B6:1;
        unsigned int    B5:1;
        unsigned int    B4:1;
        unsigned int    B3:1;
        unsigned int    B2:1;
        unsigned int    B1:1;
        unsigned int    B0:1;
    };
    UINT16 FPGAREG;
};
struct st_tpu {                                         /* struct TPU   */
              union {                                   /* TSTR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk  :2;        /*              */
                           unsigned char CST5:1;        /*    CST5      */
                           unsigned char CST4:1;        /*    CST4      */
                           unsigned char CST3:1;        /*    CST3      */
                           unsigned char CST2:1;        /*    CST2      */
                           unsigned char CST1:1;        /*    CST1      */
                           unsigned char CST0:1;        /*    CST0      */
                           }      BIT;                  /*              */
                    }           TSTR;                   /*              */
              union {                                   /* TSYR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk   :2;       /*              */
                           unsigned char SYNC5:1;       /*    SYNC5     */
                           unsigned char SYNC4:1;       /*    SYNC4     */
                           unsigned char SYNC3:1;       /*    SYNC3     */
                           unsigned char SYNC2:1;       /*    SYNC2     */
                           unsigned char SYNC1:1;       /*    SYNC1     */
                           unsigned char SYNC0:1;       /*    SYNC0     */
                           }      BIT;                  /*              */
                    }           TSYR;                   /*              */
};                                                      /*              */
struct st_tpu0 {                                        /* struct TPU0  */
               union {                                  /* TCR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char CCLR:3;       /*    CCLR      */
                            unsigned char CKEG:2;       /*    CKEG      */
                            unsigned char TPSC:3;       /*    TPSC      */
                            }      BIT;                 /*              */
                     }          TCR;                    /*              */
               union {                                  /* TMDR         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk :2;        /*              */
                            unsigned char BFB:1;        /*    BFB       */
                            unsigned char BFA:1;        /*    BFA       */
                            unsigned char MD :4;        /*    MD        */
                            }      BIT;                 /*              */
                     }          TMDR;                   /*              */
               union {                                  /* TIOR         */
                     unsigned int WORD;                 /*  Word Access */
                     struct {                           /*  Byte Access */
                            unsigned char H;            /*    TIORH     */
                            unsigned char L;            /*    TIORL     */
                            }     BYTE;                 /*              */
                     struct {                           /*  Bit  Access */
                            unsigned char IOB:4;        /*    IOB       */
                            unsigned char IOA:4;        /*    IOA       */
                            unsigned char IOD:4;        /*    IOD       */
                            unsigned char IOC:4;        /*    IOC       */
                            }     BIT;                  /*              */
                     }          TIOR;                   /*              */
               union {                                  /* TIER         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char TTGE :1;      /*    TTGE      */
                            unsigned char      :2;      /*              */
                            unsigned char TCIEV:1;      /*    TCIEV     */
                            unsigned char TGIED:1;      /*    TGIED     */
                            unsigned char TGIEC:1;      /*    TGIEC     */
                            unsigned char TGIEB:1;      /*    TGIEB     */
                            unsigned char TGIEA:1;      /*    TGIEA     */
                            }      BIT;                 /*              */
                     }          TIER;                   /*              */
               union {                                  /* TSR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :3;       /*              */
                            unsigned char TCFV:1;       /*    TCFV      */
                            unsigned char TGFD:1;       /*    TGFD      */
                            unsigned char TGFC:1;       /*    TGFC      */
                            unsigned char TGFB:1;       /*    TGFB      */
                            unsigned char TGFA:1;       /*    TGFA      */
                            }      BIT;                 /*              */
                     }          TSR;                    /*              */
               unsigned int     TCNT;                   /* TCNT         */
               unsigned int     TGRA;                   /* TGRA         */
               unsigned int     TGRB;                   /* TGRB         */
               unsigned int     TGRC;                   /* TGRC         */
               unsigned int     TGRD;                   /* TGRD         */
};                                                      /*              */
struct st_tpu1 {                                        /* struct TPU1  */
               union {                                  /* TCR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char CCLR:2;       /*    CCLR      */
                            unsigned char CKEG:2;       /*    CKEG      */
                            unsigned char TPSC:3;       /*    TPSC      */
                            }      BIT;                 /*              */
                     }          TCR;                    /*              */
               union {                                  /* TMDR         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk:4;         /*              */
                            unsigned char MD:4;         /*    MD        */
                            }      BIT;                 /*              */
                     }          TMDR;                   /*              */
               union {                                  /* TIOR         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char IOB:4;        /*    IOB       */
                            unsigned char IOA:4;        /*    IOA       */
                            }      BIT;                 /*              */
                     }          TIOR;                   /*              */
               char             wk;                     /*              */
               union {                                  /* TIER         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char TTGE :1;      /*    TTGE      */
                            unsigned char      :1;      /*              */
                            unsigned char TCIEU:1;      /*    TCIEU     */
                            unsigned char TCIEV:1;      /*    TCIEV     */
                            unsigned char      :2;      /*              */
                            unsigned char TGIEB:1;      /*    TGIEB     */
                            unsigned char TGIEA:1;      /*    TGIEA     */
                            }      BIT;                 /*              */
                     }          TIER;                   /*              */
               union {                                  /* TSR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char TCFD:1;       /*    TCFD      */
                            unsigned char     :1;       /*              */
                            unsigned char TCFU:1;       /*    TCFU      */
                            unsigned char TCFV:1;       /*    TCFV      */
                            unsigned char     :2;       /*              */
                            unsigned char TGFB:1;       /*    TGFB      */
                            unsigned char TGFA:1;       /*    TGFA      */
                            }      BIT;                 /*              */
                     }          TSR;                    /*              */
               unsigned int     TCNT;                   /* TCNT         */
               unsigned int     TGRA;                   /* TGRA         */
               unsigned int     TGRB;                   /* TGRB         */
};                                                      /*              */


struct st_p1 {                                          /* struct P1    */
             unsigned char      DDR;                    /* P1DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P1PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P1DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
};                                                      /*              */
struct st_p3 {                                          /* struct P3    */
             unsigned char      DDR;                    /* P3DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P3PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:2;           /*    Bit 7,6   */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P3DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:2;           /*    Bit 7,6   */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
             char               wk3[19];                /*              */
             union {                                    /* P3ODR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:2;           /*    Bit 7,6   */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            ODR;                    /*              */
};                                                      /*              */
struct st_p4 {                                          /* struct P4    */
             union {                                    /* P4PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
};                                                      /*              */
struct st_p5 {                                          /* struct P5    */
             unsigned char      DDR;                    /* P5DDR        */
             char               wk1[159];               /*              */
             union {                                    /* P5PORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:4;           /*    Bit 7-4   */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* P5DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:4;           /*    Bit 7-4   */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
};                                                      /*              */
struct st_pa {                                          /* struct PA    */
             unsigned char      DDR;                    /* PADDR        */
             char               wk1[159];               /*              */
             union {                                    /* PAPORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* PADR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
             char               wk3[6];                 /*              */
             union {                                    /* PAPCR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PCR;                    /*              */
             char               wk4[6];                 /*              */
             union {                                    /* PAODR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            ODR;                    /*              */
};                                                      /*              */
struct st_pb {                                          /* struct PB    */
             unsigned char      DDR;                    /* PBDDR        */
             char               wk1[159];               /*              */
             union {                                    /* PBPORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* PBDR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
             char               wk3[6];                 /*              */
             union {                                    /* PBPCR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char B7:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PCR;                    /*              */
};                                                      /*              */
struct st_pg {                                          /* struct PG    */
             unsigned char      DDR;                    /* PGDDR        */
             char               wk1[159];               /*              */
             union {                                    /* PGPORT       */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:3;           /*    Bit 7,6,5 */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            PORT;                   /*              */
             char               wk2[15];                /*              */
             union {                                    /* PGDR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:3;           /*    Bit 7,6,5 */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
};                                                      /*              */
struct st_intc {                                        /* struct INTC  */
               union {                                  /* IPRA         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    IRQ0      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    IRQ1      */
                            }      BIT;                 /*              */
                     }          IPRA;                   /*              */
               union {                                  /* IPRB         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    IRQ2,3    */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    IRQ4,5    */
                            }      BIT;                 /*              */
                     }          IPRB;                   /*              */
               union {                                  /* IPRC         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    IRQ6,IRQ7 */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    DTC       */
                            }      BIT;                 /*              */
                     }          IPRC;                   /*              */
               union {                                  /* IPRD         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    WDT       */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    RFSHC     */
                            }      BIT;                 /*              */
                     }          IPRD;                   /*              */
               union {                                  /* IPRE         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :5;       /*              */
                            unsigned char LOW :3;       /*    A/D       */
                            }      BIT;                 /*              */
                     }          IPRE;                   /*              */
               union {                                  /* IPRF         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TPU0      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TPU1      */
                            }      BIT;                 /*              */
                     }          IPRF;                   /*              */
               union {                                  /* IPRG         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TPU2      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TPU3      */
                            }      BIT;                 /*              */
                     }          IPRG;                   /*              */
               union {                                  /* IPRH         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TPU4      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TPU5      */
                            }      BIT;                 /*              */
                     }          IPRH;                   /*              */
               union {                                  /* IPRI         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    TMR0      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    TMR1      */
                            }      BIT;                 /*              */
                     }          IPRI;                   /*              */
               union {                                  /* IPRJ         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    DMAC      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    SCI0      */
                            }      BIT;                 /*              */
                     }          IPRJ;                   /*              */
               union {                                  /* IPRK         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :1;       /*              */
                            unsigned char HIGH:3;       /*    SCI1      */
                            unsigned char     :1;       /*              */
                            unsigned char LOW :3;       /*    SCI2      */
                            }      BIT;                 /*              */
                     }          IPRK;                   /*              */
               char             wk[93];                 /*              */
               union {                                  /* ISCR         */
                     unsigned int WORD;                 /*  Word Access */
                     struct {                           /*  Byte Access */
                            unsigned char H;            /*    ISCRH     */
                            unsigned char L;            /*    ISCRL     */
                            }     BYTE;                 /*              */
                     struct {                           /*  Bit  Access */
                            unsigned char IRQ7SC:2;     /*    IRQ7SC    */
                            unsigned char IRQ6SC:2;     /*    IRQ6SC    */
                            unsigned char IRQ5SC:2;     /*    IRQ5SC    */
                            unsigned char IRQ4SC:2;     /*    IRQ4SC    */
                            unsigned char IRQ3SC:2;     /*    IRQ3SC    */
                            unsigned char IRQ2SC:2;     /*    IRQ2SC    */
                            unsigned char IRQ1SC:2;     /*    IRQ1SC    */
                            unsigned char IRQ0SC:2;     /*    IRQ0SC    */
                            }     BIT;                  /*              */
                     }          ISCR;                   /*              */
               union {                                  /* IER          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char IRQ7E:1;      /*    IRQ7E     */
                            unsigned char IRQ6E:1;      /*    IRQ6E     */
                            unsigned char IRQ5E:1;      /*    IRQ5E     */
                            unsigned char IRQ4E:1;      /*    IRQ4E     */
                            unsigned char IRQ3E:1;      /*    IRQ3E     */
                            unsigned char IRQ2E:1;      /*    IRQ2E     */
                            unsigned char IRQ1E:1;      /*    IRQ1E     */
                            unsigned char IRQ0E:1;      /*    IRQ0E     */
                            }      BIT;                 /*              */
                     }          IER;                    /*              */
               union {                                  /* ISR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char IRQ7F:1;      /*    IRQ7F     */
                            unsigned char IRQ6F:1;      /*    IRQ6F     */
                            unsigned char IRQ5F:1;      /*    IRQ5F     */
                            unsigned char IRQ4F:1;      /*    IRQ4F     */
                            unsigned char IRQ3F:1;      /*    IRQ3F     */
                            unsigned char IRQ2F:1;      /*    IRQ2F     */
                            unsigned char IRQ1F:1;      /*    IRQ1F     */
                            unsigned char IRQ0F:1;      /*    IRQ0F     */
                            }      BIT;                 /*              */
                     }          ISR;                    /*              */
};                                                      /*              */
struct st_bsc {                                         /* struct BSC   */
              union {                                   /* ABWCR        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    Bit 7     */
                           unsigned char B6:1;          /*    Bit 6     */
                           unsigned char B5:1;          /*    Bit 5     */
                           unsigned char B4:1;          /*    Bit 4     */
                           unsigned char B3:1;          /*    Bit 3     */
                           unsigned char B2:1;          /*    Bit 2     */
                           unsigned char B1:1;          /*    Bit 1     */
                           unsigned char B0:1;          /*    Bit 0     */
                           }      BIT;                  /*              */
                    }           ABWCR;                  /*              */
              union {                                   /* ASTCR        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    Bit 7     */
                           unsigned char B6:1;          /*    Bit 6     */
                           unsigned char B5:1;          /*    Bit 5     */
                           unsigned char B4:1;          /*    Bit 4     */
                           unsigned char B3:1;          /*    Bit 3     */
                           unsigned char B2:1;          /*    Bit 2     */
                           unsigned char B1:1;          /*    Bit 1     */
                           unsigned char B0:1;          /*    Bit 0     */
                           }      BIT;                  /*              */
                    }           ASTCR;                  /*              */
              union {                                   /* WCR          */
                    unsigned int WORD;                  /*  Word Access */
                    struct {                            /*  Byte Access */
                           unsigned char H;             /*    WCRH      */
                           unsigned char L;             /*    WCRL      */
                           }     BYTE;                  /*              */
                    struct {                            /*  Bit  Access */
                           unsigned char W7:2;          /*    W7        */
                           unsigned char W6:2;          /*    W6        */
                           unsigned char W5:2;          /*    W5        */
                           unsigned char W4:2;          /*    W4        */
                           unsigned char W3:2;          /*    W3        */
                           unsigned char W2:2;          /*    W2        */
                           unsigned char W1:2;          /*    W1        */
                           unsigned char W0:2;          /*    W0        */
                           }     BIT;                   /*              */
                    }           WCR;                    /*              */
              union {                                   /* BCR          */
                    unsigned int WORD;                  /*  Word Access */
                    struct {                            /*  Byte Access */
                           unsigned char H;             /*    BCRH      */
                           unsigned char L;             /*    BCRL      */
                           }     BYTE;                  /*              */
                    struct {                            /*  Bit  Access */
                           unsigned char ICIS1 :1;      /*    ICIS1     */
                           unsigned char ICIS0 :1;      /*    ICIS0     */
                           unsigned char BRSTRM:1;      /*    BRSTRM    */
                           unsigned char BRSTS1:1;      /*    BRSTS1    */
                           unsigned char BRSTS0:1;      /*    BRSTS0    */
                           unsigned char RMTS  :3;      /*    RMTS      */
                           unsigned char BRLE  :1;      /*    BRLE      */
                           unsigned char BREQOE:1;      /*    BREQOE    */
                           unsigned char EAE   :1;      /*    EAE       */
                           unsigned char       :1;      /*              */
                           unsigned char DDS   :1;      /*    DDS       */
                           unsigned char       :1;      /*              */
                           unsigned char WDBE  :1;      /*    WDBE      */
                           unsigned char WAITE :1;      /*    WAITE     */
                           }     BIT;                   /*              */
                    }           BCR;                    /*              */
              union {                                   /* MCR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char TPC :1;        /*    TPC       */
                           unsigned char BE  :1;        /*    BE        */
                           unsigned char RCDM:1;        /*    RCDM      */
                           unsigned char     :1;        /*              */
                           unsigned char MXC :2;        /*    MXC       */
                           unsigned char RLW :2;        /*    RLW       */
                           }      BIT;                  /*              */
                    }           MCR;                    /*              */
              union {                                   /* DRAMCR       */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char RFSHE:1;       /*    RFCHE     */
                           unsigned char RCW  :1;       /*    RCW       */
                           unsigned char RMODE:1;       /*    RMODE     */
                           unsigned char CMF  :1;       /*    CMF       */
                           unsigned char CMIE :1;       /*    CMIE      */
                           unsigned char CKS  :3;       /*    CKS       */
                           }      BIT;                  /*              */
                    }           DRAMCR;                 /*              */
              unsigned char     RTCNT;                  /* RTCNT        */
              unsigned char     RTCOR;                  /* RTCOR        */
              char              wk1[107];               /*              */
              union {                                   /* PFCR1        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk  :4;        /*              */
                           unsigned char A23E:1;        /*    A23E      */
                           unsigned char A22E:1;        /*    A22E      */
                           unsigned char A21E:1;        /*    A21E      */
                           unsigned char A20E:1;        /*    A20E      */
                           }      BIT;                  /*              */
                    }           PFCR1;                  /*              */
              char              wk2[102];               /*              */
              union {                                   /* PFCR2        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char WAITPS :1;     /*    WAITPS    */
                           unsigned char BREQOPS:1;     /*    BREQOPS   */
                           unsigned char CS167E :1;     /*    CS167E    */
                           unsigned char CS25E  :1;     /*    CS25E     */
                           unsigned char ASOD   :1;     /*    ASOD      */
                           }      BIT;                  /*              */
                    }           PFCR2;                  /*              */
};                                                      /*              */
struct st_sam0a {                                       /* struct DMAC0A*/
                void           *MAR;                    /* MAR          */
                unsigned int    IOAR;                   /* IOAR         */
                unsigned int    ETCR;                   /* ETCR         */
                char            wk2[26];                /*              */
                union {                                 /* DMACR        */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char DTSZ :1;     /*    DTSZ      */
                             unsigned char DTID :1;     /*    DTID      */
                             unsigned char RPE  :1;     /*    RPE       */
                             unsigned char DTDIR:1;     /*    DTDIR     */
                             unsigned char DTF  :4;     /*    DTF       */
                             }      BIT;                /*              */
                      }         DMACR;                  /*              */
                char            wk3[3];                 /*              */
                union {                                 /* DMABCR       */
                      unsigned int WORD;                /*  Word Access */
                      struct {                          /*  Byte Access */
                             unsigned char H;           /*    DMABCRH   */
                             unsigned char L;           /*    DMABCRL   */
                             }     BYTE;                /*              */
                      struct {                          /*  Bit  Access */
                             unsigned char wk  :1;      /*              */
                             unsigned char FAE :1;      /*    FAE       */
                             unsigned char     :1;      /*              */
                             unsigned char SAE :1;      /*    SAE       */
                             unsigned char     :3;      /*              */
                             unsigned char DTA :1;      /*    DTA       */
                             unsigned char     :3;      /*              */
                             unsigned char DTE :1;      /*    DTE       */
                             unsigned char     :3;      /*              */
                             unsigned char DTIE:1;      /*    DTIE      */
                             }     BIT;                 /*              */
                      }         DMABCR;                 /*              */
};                                                      /*              */
struct st_sam0b {                                       /* struct DMAC0B*/
                void           *MAR;                    /* MAR          */
                unsigned int    IOAR;                   /* IOAR         */
                unsigned int    ETCR;                   /* ETCR         */
                char            wk2[19];                /*              */
                union {                                 /* DMACR        */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char DTSZ :1;     /*    DTSZ      */
                             unsigned char DTID :1;     /*    DTID      */
                             unsigned char RPE  :1;     /*    RPE       */
                             unsigned char DTDIR:1;     /*    DTDIR     */
                             unsigned char DTF  :4;     /*    DTF       */
                             }      BIT;                /*              */
                      }         DMACR;                  /*              */
                char            wk3[2];                 /*              */
                union {                                 /* DMABCR       */
                      unsigned int WORD;                /*  Word Access */
                      struct {                          /*  Byte Access */
                             unsigned char H;           /*    DMABCRH   */
                             unsigned char L;           /*    DMABCRL   */
                             }     BYTE;                /*              */
                      struct {                          /*  Bit  Access */
                             unsigned char wk  :1;      /*              */
                             unsigned char FAE :1;      /*    FAE       */
                             unsigned char     :1;      /*              */
                             unsigned char SAE :1;      /*    SAE       */
                             unsigned char     :2;      /*              */
                             unsigned char DTA :1;      /*    DTA       */
                             unsigned char     :0;      /*              */
                             unsigned char     :2;      /*              */
                             unsigned char DTE :1;      /*    DTE       */
                             unsigned char     :3;      /*              */
                             unsigned char DTIE:1;      /*    DTIE      */
                             }     BIT;                 /*              */
                      }         DMABCR;                 /*              */
};                                                      /*              */
struct st_sam1a {                                       /* struct DMAC1A*/
                void           *MAR;                    /* MAR          */
                unsigned int    IOAR;                   /* IOAR         */
                unsigned int    ETCR;                   /* ETCR         */
                char            wk2[12];                /*              */
                union {                                 /* DMACR        */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char DTSZ :1;     /*    DTSZ      */
                             unsigned char DTID :1;     /*    DTID      */
                             unsigned char RPE  :1;     /*    RPE       */
                             unsigned char DTDIR:1;     /*    DTDIR     */
                             unsigned char DTF  :4;     /*    DTF       */
                             }      BIT;                /*              */
                      }         DMACR;                  /*              */
                char            wk3;                    /*              */
                union {                                 /* DMABCR       */
                      unsigned int WORD;                /*  Word Access */
                      struct {                          /*  Byte Access */
                             unsigned char H;           /*    DMABCRH   */
                             unsigned char L;           /*    DMABCRL   */
                             }     BYTE;                /*              */
                      struct {                          /*  Bit  Access */
                             unsigned char FAE :1;      /*    FAE       */
                             unsigned char     :1;      /*              */
                             unsigned char SAE :1;      /*    SAE       */
                             unsigned char     :2;      /*              */
                             unsigned char DTA :1;      /*    DTA       */
                             unsigned char     :0;      /*              */
                             unsigned char     :1;      /*              */
                             unsigned char DTE :1;      /*    DTE       */
                             unsigned char     :3;      /*              */
                             unsigned char DTIE:1;      /*    DTIE      */
                             }     BIT;                 /*              */
                      }         DMABCR;                 /*              */
};                                                      /*              */
struct st_sam1b {                                       /* struct DMAC1B*/
                void           *MAR;                    /* MAR          */
                unsigned int    IOAR;                   /* IOAR         */
                unsigned int    ETCR;                   /* ETCR         */
                char            wk2[5];                 /*              */
                union {                                 /* DMACR        */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char DTSZ :1;     /*    DTSZ      */
                             unsigned char DTID :1;     /*    DTID      */
                             unsigned char RPE  :1;     /*    RPE       */
                             unsigned char DTDIR:1;     /*    DTDIR     */
                             unsigned char DTF  :4;     /*    DTF       */
                             }      BIT;                /*              */
                      }         DMACR;                  /*              */
                union {                                 /* DMABCR       */
                      unsigned int WORD;                /*  Word Access */
                      struct {                          /*  Byte Access */
                             unsigned char H;           /*    DMABCRH   */
                             unsigned char L;           /*    DMABCRL   */
                             }     BYTE;                /*              */
                      struct {                          /*  Bit  Access */
                             unsigned char FAE :1;      /*    FAE       */
                             unsigned char     :1;      /*              */
                             unsigned char SAE :1;      /*    SAE       */
                             unsigned char     :1;      /*              */
                             unsigned char DTA :1;      /*    DTA       */
                             unsigned char     :0;      /*              */
                             unsigned char DTE :1;      /*    DTE       */
                             unsigned char     :3;      /*              */
                             unsigned char DTIE:1;      /*    DTIE      */
                             }     BIT;                 /*              */
                      }         DMABCR;                 /*              */
};                                                      /*              */
struct st_fam0 {                                        /* struct DMAC0 */
               void            *MARA;                   /* MARA         */
               char             wk1[2];                 /*              */
               unsigned int     ETCRA;                  /* ETCRA        */
               void            *MARB;                   /* MARB         */
               char             wk2[2];                 /*              */
               unsigned int     ETCRB;                  /* ETCRB        */
               char             wk3[18];                /*              */
               union {                                  /* DMACR        */
                     unsigned int WORD;                 /*  Word Access */
                     struct {                           /*  Byte Access */
                            unsigned char A;            /*    DMACRA    */
                            unsigned char B;            /*    DMACRB    */
                            }     BYTE;                 /*              */
                     struct {                           /*  Bit  Access */
                            unsigned char DTSZ  :1;     /*    DTSZ      */
                            unsigned char SAID  :1;     /*    SAID      */
                            unsigned char SAIDE :1;     /*    SAIDE     */
                            unsigned char BLKDIR:1;     /*    BLKDIR    */
                            unsigned char BLKE  :1;     /*    BLKE      */
                            unsigned char       :0;     /*              */
                            unsigned char       :1;     /*              */
                            unsigned char DAID  :1;     /*    DAID      */
                            unsigned char DAIDE :1;     /*    DAIDE     */
                            unsigned char       :1;     /*              */
                            unsigned char DTF   :4;     /*    DTF       */
                            }     BIT;                  /*              */
                     }          DMACR;                  /*              */
               char             wk4[2];                 /*              */
               union {                                  /* DMABCR       */
                     unsigned int WORD;                 /*  Word Access */
                     struct {                           /*  Byte Access */
                            unsigned char H;            /*    DMABCRH   */
                            unsigned char L;            /*    DMABCRL   */
                            }     BYTE;                 /*              */
                     struct {                           /*  Bit  Access */
                            unsigned char wk   :1;      /*              */
                            unsigned char FAE  :1;      /*    FAE       */
                            unsigned char      :4;      /*              */
                            unsigned char DTA  :1;      /*    DTA       */
                            unsigned char      :0;      /*              */
                            unsigned char      :2;      /*              */
                            unsigned char DTME :1;      /*    DTME      */
                            unsigned char DTE  :1;      /*    DTE       */
                            unsigned char      :2;      /*              */
                            unsigned char DTIEB:1;      /*    DTIEB     */
                            unsigned char DTIEA:1;      /*    DTIEA     */
                            }     BIT;                  /*              */
                     }          DMABCR;                 /*              */
};                                                      /*              */
struct st_fam1 {                                        /* struct DMAC1 */
               void            *MARA;                   /* MARA         */
               char             wk1[2];                 /*              */
               unsigned int     ETCRA;                  /* ETCRA        */
               void            *MARB;                   /* MARB         */
               char             wk2[2];                 /*              */
               unsigned int     ETCRB;                  /* ETCRB        */
               char             wk3[4];                 /*              */
               union {                                  /* DMACR        */
                     unsigned int WORD;                 /*  Word Access */
                     struct {                           /*  Byte Access */
                            unsigned char A;            /*    DMACRA    */
                            unsigned char B;            /*    DMACRB    */
                            }     BYTE;                 /*              */
                     struct {                           /*  Bit  Access */
                            unsigned char DTSZ  :1;     /*    DTSZ      */
                            unsigned char SAID  :1;     /*    SAID      */
                            unsigned char SAIDE :1;     /*    SAIDE     */
                            unsigned char BLKDIR:1;     /*    BLKDIR    */
                            unsigned char BLKE  :1;     /*    BLKE      */
                            unsigned char       :0;     /*              */
                            unsigned char       :1;     /*              */
                            unsigned char DAID  :1;     /*    DAID      */
                            unsigned char DAIDE :1;     /*    DAIDE     */
                            unsigned char       :1;     /*              */
                            unsigned char DTF   :4;     /*    DTF       */
                            }     BIT;                  /*              */
                     }         DMACR;                   /*              */
               union {                                  /* DMABCR       */
                     unsigned int WORD;                 /*  Word Access */
                     struct {                           /*  Byte Access */
                            unsigned char H;            /*    DMABCRH   */
                            unsigned char L;            /*    DMABCRL   */
                            }     BYTE;                 /*              */
                     struct {                           /*  Bit  Access */
                            unsigned char FAE  :1;      /*    FAE       */
                            unsigned char      :3;      /*              */
                            unsigned char DTA  :1;      /*    DTA       */
                            unsigned char      :0;      /*              */
                            unsigned char DTME :1;      /*    DTME      */
                            unsigned char DTE  :1;      /*    DTE       */
                            unsigned char      :2;      /*              */
                            unsigned char DTIEB:1;      /*    DTIEB     */
                            unsigned char DTIEA:1;      /*    DTIEA     */
                            }     BIT;                  /*              */
                     }          DMABCR;                 /*              */
};                                                      /*              */
struct st_dmac {                                        /* struct DMAC  */
               union {                                  /* DMAWER       */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :4;       /*              */
                            unsigned char WE1B:1;       /*    WE1B      */
                            unsigned char WE1A:1;       /*    WE1A      */
                            unsigned char WE0B:1;       /*    WE0B      */
                            unsigned char WE0A:1;       /*    WE0A      */
                            }      BIT;                 /*              */
                     }          DMAWER;                 /*              */
               union {                                  /* DMATCR       */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char wk  :2;       /*              */
                            unsigned char TEE1:1;       /*    TEE1      */
                            unsigned char TEE0:1;       /*    TEE0      */
                            }      BIT;                 /*              */
                     }          DMATCR;                 /*              */
};                                                      /*              */
struct st_dtc {                                         /* struct DTC   */
              union {                                   /* EA           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    IRQ0      */
                           unsigned char B6:1;          /*    IRQ1      */
                           unsigned char B5:1;          /*    IRQ2      */
                           unsigned char B4:1;          /*    IRQ3      */
                           unsigned char B3:1;          /*    IRQ4      */
                           unsigned char B2:1;          /*    IRQ5      */
                           unsigned char B1:1;          /*    IRQ6      */
                           unsigned char B0:1;          /*    IRQ7      */
                           }      BIT;                  /*              */
                    }           EA;                     /*              */
              union {                                   /* EB           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk:1;          /*              */
                           unsigned char B6:1;          /*    ADI       */
                           unsigned char B5:1;          /*    TGI0A     */
                           unsigned char B4:1;          /*    TGI0B     */
                           unsigned char B3:1;          /*    TGI0C     */
                           unsigned char B2:1;          /*    TGI0D     */
                           unsigned char B1:1;          /*    TGI1A     */
                           unsigned char B0:1;          /*    TGI1B     */
                           }      BIT;                  /*              */
                    }           EB;                     /*              */
              union {                                   /* EC           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    TGI2A     */
                           unsigned char B6:1;          /*    TGI2B     */
                           unsigned char B5:1;          /*    TGI3A     */
                           unsigned char B4:1;          /*    TGI3B     */
                           unsigned char B3:1;          /*    TGI3C     */
                           unsigned char B2:1;          /*    TGI3D     */
                           unsigned char B1:1;          /*    TGI4A     */
                           unsigned char B0:1;          /*    TGI4B     */
                           }      BIT;                  /*              */
                    }           EC;                     /*              */
              union {                                   /* ED           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk:2;          /*              */
                           unsigned char B5:1;          /*    TGI5A     */
                           unsigned char B4:1;          /*    TGI5B     */
                           unsigned char B3:1;          /*    CMI0A     */
                           unsigned char B2:1;          /*    CMI0B     */
                           unsigned char B1:1;          /*    CMI1A     */
                           unsigned char B0:1;          /*    CMI1B     */
                           }      BIT;                  /*              */
                    }           ED;                     /*              */
              union {                                   /* EE           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk:4;          /*              */
                           unsigned char B3:1;          /*    RXI0      */
                           unsigned char B2:1;          /*    TXI0      */
                           unsigned char B1:1;          /*    RXI1      */
                           unsigned char B0:1;          /*    TXI1      */
                           }      BIT;                  /*              */
                    }           EE;                     /*              */
              union {                                   /* EF           */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    RXI2      */
                           unsigned char B6:1;          /*    TXI2      */
                           }      BIT;                  /*              */
                    }           EF;                     /*              */
              char              wk;                     /*              */
              union {                                   /* VECR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char SWDTE:1;       /*    SWDTE     */
                           unsigned char DTVEC:7;       /*    DTVEC     */
                           }      BIT;                  /*              */
                    }           VECR;                   /*              */
};                                                      /*              */
union un_sbycr {                                        /* union SBYCR  */
               unsigned char BYTE;                      /*  Byte Access */
               struct {                                 /*  Bit  Access */
                      unsigned char SSBY  :1;           /*    SSBY      */
                      unsigned char STS   :3;           /*    STS       */
                      unsigned char OPE   :1;           /*    OPE       */
                      unsigned char       :2;           /*              */
                      unsigned char IRQ37S:1;           /*    IRQ37S    */
                      }      BIT;                       /*              */
};                                                      /*              */
union un_syscr {                                        /* union SYSCR  */
               unsigned char BYTE;                      /*  Byte Access */
               struct {                                 /*  Bit  Access */
                      unsigned char wk    :2;           /*              */
                      unsigned char INTM  :2;           /*    INTM      */
                      unsigned char NMIEG :1;           /*    NMIEG     */
                      unsigned char LWROD :1;           /*    LWROD     */
                      unsigned char IRQPAS:1;           /*    IRQPAS    */
                      unsigned char RAME  :1;           /*    RAME      */
                      }      BIT;                       /*              */
};                                                      /*              */
union un_sckcr {                                        /* union SCKCR  */
               unsigned char BYTE;                      /*  Byte Access */
               struct {                                 /*  Bit  Access */
                      unsigned char PSTOP:1;            /*    PSTOP     */
                      unsigned char      :1;            /*              */
                      unsigned char DIV  :1;            /*    DIV       */
                      unsigned char      :2;            /*              */
                      unsigned char SCK  :3;            /*    SCK       */
                      }      BIT;                       /*              */
};                                                      /*              */
union un_mdcr {                                         /* union MDCR   */
              unsigned char BYTE;                       /*  Byte Access */
              struct {                                  /*  Bit  Access */
                     unsigned char wk :5;               /*              */
                     unsigned char MDS:3;               /*    MDS       */
                     }      BIT;                        /*              */
};                                                      /*              */
union un_mstpcr {                 /********************************************/
    UINT16 WORD;                  /*        Module Stop Control Register      */
    struct {                      /*                                          */
        UINT8 H;                  /*   MSTPCRH                                */
        UINT8 L;                  /*   MSTPCRL                                */
    } BYTE;                       /*                                          */
    struct {                      /*                                          */
        UINT8     :1;             /*                                          */
        UINT8 DTC :1;             /*   Data Transfer Controller               */
        UINT8 TPU :1;             /*   16 Bit Timer Pulse Unit                */
        UINT8 TMR :1;             /*   8 bit Timers                           */
        UINT8     :1;             /*                                          */
        UINT8 DAC :1;             /*   Digital to Analog Converter            */
        UINT8 ADC :1;             /*   Analog to Digital Converter            */
        UINT8     :1;             /*                                          */
        UINT8 SCI2:1;             /*   Serial Commn. Interface Channel 2      */
        UINT8 SCI1:1;             /*   Serial Commn. Interface Channel 1      */
        UINT8 SCI0:1;             /*   Serial Commn. Interface Channel 0      */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
        UINT8     :1;             /*                                          */
    } BIT;                        /*                                          */
};
union un_syscr2 {                                       /* union SYSCR2 */
                unsigned char BYTE;                     /*  Byte Access */
                struct {                                /*  Bit  Access */
                       unsigned char wk   :4;           /*              */
                       unsigned char FLSHE:1;           /*    FLSHE     */
                       }      BIT;                      /*              */
};                                                      /*              */
struct st_ppg {                                         /* struct PPG   */
              union {                                   /* PCR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char G3CMS:2;       /*    G3CMS     */
                           unsigned char G2CMS:2;       /*    G2CMS     */
                           unsigned char G1CMS:2;       /*    G1CMS     */
                           unsigned char G0CMS:2;       /*    G0CMS     */
                           }      BIT;                  /*              */
                    }           PCR;                    /*              */
              union {                                   /* PMR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char G3INV:1;       /*    G3INV     */
                           unsigned char G2INV:1;       /*    G2INV     */
                           unsigned char G1INV:1;       /*    G1INV     */
                           unsigned char G0INV:1;       /*    G0INV     */
                           unsigned char G3NOV:1;       /*    G3NOV     */
                           unsigned char G2NOV:1;       /*    G2NOV     */
                           unsigned char G1NOV:1;       /*    G1NOV     */
                           unsigned char G0NOV:1;       /*    G0NOV     */
                           }      BIT;                  /*              */
                    }           PMR;                    /*              */
              union {                                   /* NDER         */
                    unsigned int WORD;                  /*  Word Access */
                    struct {                            /*  Bit  Access */
                           unsigned char H;             /*    NDERH     */
                           unsigned char L;             /*    NDERL     */
                           }     BYTE;                  /*              */
                    struct {                            /*  Bit  Access */
                           unsigned char B15:1;         /*    NDER15    */
                           unsigned char B14:1;         /*    NDER14    */
                           unsigned char B13:1;         /*    NDER13    */
                           unsigned char B12:1;         /*    NDER12    */
                           unsigned char B11:1;         /*    NDER11    */
                           unsigned char B10:1;         /*    NDER10    */
                           unsigned char B9 :1;         /*    NDER9     */
                           unsigned char B8 :1;         /*    NDER8     */
                           unsigned char B7 :1;         /*    NDER7     */
                           unsigned char B6 :1;         /*    NDER6     */
                           unsigned char B5 :1;         /*    NDER5     */
                           unsigned char B4 :1;         /*    NDER4     */
                           unsigned char B3 :1;         /*    NDER3     */
                           unsigned char B2 :1;         /*    NDER2     */
                           unsigned char B1 :1;         /*    NDER1     */
                           unsigned char B0 :1;         /*    NDER0     */
                           }      BIT;                  /*              */
                    }           NDER;                   /*              */
              union {                                   /* PODR         */
                    unsigned int WORD;                  /*  Word Access */
                    struct {                            /*  Bit  Access */
                           unsigned char H;             /*    PODRH     */
                           unsigned char L;             /*    PODRL     */
                           }     BYTE;                  /*              */
                    struct {                            /*  Bit  Access */
                           unsigned char B15:1;         /*    NDER15    */
                           unsigned char B14:1;         /*    NDER14    */
                           unsigned char B13:1;         /*    NDER13    */
                           unsigned char B12:1;         /*    NDER12    */
                           unsigned char B11:1;         /*    NDER11    */
                           unsigned char B10:1;         /*    NDER10    */
                           unsigned char B9 :1;         /*    NDER9     */
                           unsigned char B8 :1;         /*    NDER8     */
                           unsigned char B7 :1;         /*    NDER7     */
                           unsigned char B6 :1;         /*    NDER6     */
                           unsigned char B5 :1;         /*    NDER5     */
                           unsigned char B4 :1;         /*    NDER4     */
                           unsigned char B3 :1;         /*    NDER3     */
                           unsigned char B2 :1;         /*    NDER2     */
                           unsigned char B1 :1;         /*    NDER1     */
                           unsigned char B0 :1;         /*    NDER0     */
                           }     BIT;                   /*              */
                    }           PODR;                   /*              */
              union {                                   /* NDRH (H'4C)  */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B15:1;         /*    NDR15     */
                           unsigned char B14:1;         /*    NDR14     */
                           unsigned char B13:1;         /*    NDR13     */
                           unsigned char B12:1;         /*    NDR12     */
                           unsigned char B11:1;         /*    NDR11     */
                           unsigned char B10:1;         /*    NDR10     */
                           unsigned char B9 :1;         /*    NDR9      */
                           unsigned char B8 :1;         /*    NDR8      */
                           }      BIT;                  /*              */
                    }           NDRH1;                  /*              */
              union {                                   /* NDRL (H'4D)  */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char B7:1;          /*    NDR7      */
                           unsigned char B6:1;          /*    NDR6      */
                           unsigned char B5:1;          /*    NDR5      */
                           unsigned char B4:1;          /*    NDR4      */
                           unsigned char B3:1;          /*    NDR3      */
                           unsigned char B2:1;          /*    NDR2      */
                           unsigned char B1:1;          /*    NDR1      */
                           unsigned char B0:1;          /*    NDR0      */
                           }      BIT;                  /*              */
                    }           NDRL1;                  /*              */
              union {                                   /* NDRH (H'4E)  */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk :4;         /*              */
                           unsigned char B11:1;         /*    NDR11     */
                           unsigned char B10:1;         /*    NDR10     */
                           unsigned char B9 :1;         /*    NDR9      */
                           unsigned char B8 :1;         /*    NDR8      */
                           }      BIT;                  /*              */
                    }           NDRH2;                  /*              */
              union {                                   /* NDRL (H'4F)  */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk:4;          /*              */
                           unsigned char B3:1;          /*    NDR3      */
                           unsigned char B2:1;          /*    NDR2      */
                           unsigned char B1:1;          /*    NDR1      */
                           unsigned char B0:1;          /*    NDR0      */
                           }      BIT;                  /*              */
                    }           NDRL2;                  /*              */
};                                                      /*              */
struct st_sci {                                         /* struct SCI   */
              union {                                   /* SMR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char CA  :1;        /*    C/A       */
                           unsigned char CHR :1;        /*    CHR       */
                           unsigned char PE  :1;        /*    PE        */
                           unsigned char OE  :1;        /*    O/E       */
                           unsigned char STOP:1;        /*    STOP      */
                           unsigned char MP  :1;        /*    MP        */
                           unsigned char CKS :2;        /*    CKS       */
                           }      BIT;                  /*              */
                    }           SMR;                    /*              */
              unsigned char     BRR;                    /* BRR          */
              union {                                   /* SCR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char TIE :1;        /*    TIE       */
                           unsigned char RIE :1;        /*    RIE       */
                           unsigned char TE  :1;        /*    TE        */
                           unsigned char RE  :1;        /*    RE        */
                           unsigned char MPIE:1;        /*    MPIE      */
                           unsigned char TEIE:1;        /*    TEIE      */
                           unsigned char CKE :2;        /*    CKE       */
                           }      BIT;                  /*              */
                    }           SCR;                    /*              */
              unsigned char     TDR;                    /* TDR          */
              union {                                   /* SSR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char TDRE:1;        /*    TDRE      */
                           unsigned char RDRF:1;        /*    RDRF      */
                           unsigned char ORER:1;        /*    ORER      */
                           unsigned char FER :1;        /*    FER       */
                           unsigned char PER :1;        /*    PER       */
                           unsigned char TEND:1;        /*    TEND      */
                           unsigned char MPB :1;        /*    MPB       */
                           unsigned char MPBT:1;        /*    MPBT      */
                           }      BIT;                  /*              */
                    }           SSR;                    /*              */
              unsigned char     RDR;                    /* RDR          */
              union {                                   /* SCMR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk  :4;        /*              */
                           unsigned char SDIR:1;        /*    SDIR      */
                           unsigned char SINV:1;        /*    SINV      */
                           unsigned char     :1;        /*              */
                           unsigned char SMIF:1;        /*    SMIF      */
                           }      BIT;                  /*              */
                    }           SCMR;                   /*              */
              char              wk;                     /*              */
};                                                      /*              */
struct st_ici {                                         /* struct ICI   */
              union {                                   /* SMR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char GM :1;         /*    GM        */
                           unsigned char BLK:1;         /*    BLK       */
                           unsigned char PE :1;         /*    PE        */
                           unsigned char OE :1;         /*    O/E       */
                           unsigned char BCP:2;         /*    BCP       */
                           unsigned char CKS:2;         /*    CKS       */
                           }      BIT;                  /*              */
                    }           SMR;                    /*              */
              unsigned char     BRR;                    /* BRR          */
              union {                                   /* SCR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char TIE :1;        /*    TIE       */
                           unsigned char RIE :1;        /*    RIE       */
                           unsigned char TE  :1;        /*    TE        */
                           unsigned char RE  :1;        /*    RE        */
                           unsigned char MPIE:1;        /*    MPIE      */
                           unsigned char TEIE:1;        /*    TEIE      */
                           unsigned char CKE :2;        /*    CKE       */
                           }      BIT;                  /*              */
                    }           SCR;                    /*              */
              unsigned char     TDR;                    /* TDR          */
              union {                                   /* SSR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char TDRE:1;        /*    TDRE      */
                           unsigned char RDRF:1;        /*    RDRF      */
                           unsigned char ORER:1;        /*    ORER      */
                           unsigned char ERS :1;        /*    ERS       */
                           unsigned char PER :1;        /*    PER       */
                           unsigned char TEND:1;        /*    TEND      */
                           unsigned char MPB :1;        /*    MPB       */
                           unsigned char MPBT:1;        /*    MPBT      */
                           }      BIT;                  /*              */
                    }           SSR;                    /*              */
              unsigned char     RDR;                    /* RDR          */
              union {                                   /* SCMR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk  :4;        /*              */
                           unsigned char SDIR:1;        /*    SDIR      */
                           unsigned char SINV:1;        /*    SINV      */
                           unsigned char     :1;        /*              */
                           unsigned char SMIF:1;        /*    SMIF      */
                           }      BIT;                  /*              */
                    }           SCMR;                   /*              */
              char              wk;                     /*              */
};                                                      /*              */
struct st_ad {                                          /* struct A/D   */
             unsigned int       DRA;                    /* ADDRA        */
             unsigned int       DRB;                    /* ADDRB        */
             unsigned int       DRC;                    /* ADDRC        */
             unsigned int       DRD;                    /* ADDRD        */
             union {                                    /* ADCSR        */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char ADF :1;         /*    ADF       */
                          unsigned char ADIE:1;         /*    ADIE      */
                          unsigned char ADST:1;         /*    ADST      */
                          unsigned char SCAN:1;         /*    SCAN      */
                          unsigned char CKS :1;         /*    CKS       */
                          unsigned char CH  :3;         /*    CH        */
                          }      BIT;                   /*              */
                   }            CSR;                    /*              */
             union {                                    /* ADCR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char TRGS:2;         /*    TRGS      */
                          unsigned char     :1;         /*              */
                          unsigned char CKS :1;         /*    CKS       */
                          }      BIT;                   /*              */
                   }            CR;                     /*              */
};                                                      /*              */
struct st_da {                                          /* struct D/A   */
             unsigned char      DR0;                    /* DADR0        */
             unsigned char      DR1;                    /* DADR1        */
             union {                                    /* DACR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char DAOE1:1;        /*    DAOE1     */
                          unsigned char DAOE0:1;        /*    DAOE0     */
                          unsigned char DAE  :1;        /*    DAE       */
                          }      BIT;                   /*              */
                   }            CR;                     /*              */
};                                                      /*              */
struct st_tmr {                                         /* struct TMR   */
              union {                                   /* TCR0         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char CMIEB:1;       /*    CMIEB     */
                           unsigned char CMIEA:1;       /*    CMIEA     */
                           unsigned char OVIE :1;       /*    OVIE      */
                           unsigned char CCLR :2;       /*    CCLR      */
                           unsigned char CKS  :3;       /*    CKS       */
                           }      BIT;                  /*              */
                    }           TCR0;                   /*              */
              union {                                   /* TCR1         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char CMIEB:1;       /*    CMIEB     */
                           unsigned char CMIEA:1;       /*    CMIEA     */
                           unsigned char OVIE :1;       /*    OVIE      */
                           unsigned char CCLR :2;       /*    CCLR      */
                           unsigned char CKS  :3;       /*    CKS       */
                           }      BIT;                  /*              */
                    }           TCR1;                   /*              */
              union {                                   /* TCSR0        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char CMFB:1;        /*    CMFB      */
                           unsigned char CMFA:1;        /*    CMFA      */
                           unsigned char OVF :1;        /*    OVF       */
                           unsigned char ADTE:1;        /*    ADTE      */
                           unsigned char OS  :4;        /*    OS        */
                           }      BIT;                  /*              */
                    }           TCSR0;                  /*              */
              union {                                   /* TCSR1        */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char CMFB:1;        /*    CMFB      */
                           unsigned char CMFA:1;        /*    CMFA      */
                           unsigned char OVF :1;        /*    OVF       */
                           unsigned char     :1;        /*              */
                           unsigned char OS  :4;        /*    OS        */
                           }      BIT;                  /*              */
                    }           TCSR1;                  /*              */
              unsigned int      TCORA;                  /* TCORA        */
              unsigned int      TCORB;                  /* TCORB        */
              unsigned int      TCNT;                   /* TCNT         */
};                                                      /*              */
struct st_tmr0 {                                        /* struct TMR0  */
               union {                                  /* TCR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char CMIEB:1;      /*    CMIEB     */
                            unsigned char CMIEA:1;      /*    CMIEA     */
                            unsigned char OVIE :1;      /*    OVIE      */
                            unsigned char CCLR :2;      /*    CCLR      */
                            unsigned char CKS  :3;      /*    CKS       */
                            }      BIT;                 /*              */
                     }          TCR;                    /*              */
               char             wk1;                    /*              */
               union {                                  /* TCSR         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char CMFB:1;       /*    CMFB      */
                            unsigned char CMFA:1;       /*    CMFA      */
                            unsigned char OVF :1;       /*    OVF       */
                            unsigned char ADTE:1;       /*    ADTE      */
                            unsigned char OS  :4;       /*    OS        */
                            }      BIT;                 /*              */
                     }          TCSR;                   /*              */
               char             wk2;                    /*              */
               unsigned char    TCORA;                  /* TCORA        */
               char             wk3;                    /*              */
               unsigned char    TCORB;                  /* TCORB        */
               char             wk4;                    /*              */
               unsigned char    TCNT;                   /* TCNT         */
};                                                      /*              */
struct st_tmr1 {                                        /* struct TMR1  */
               union {                                  /* TCR          */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char CMIEB:1;      /*    CMIEB     */
                            unsigned char CMIEA:1;      /*    CMIEA     */
                            unsigned char OVIE :1;      /*    OVIE      */
                            unsigned char CCLR :2;      /*    CCLR      */
                            unsigned char CKS  :3;      /*    CKS       */
                            }      BIT;                 /*              */
                     }          TCR;                    /*              */
               char             wk1;                    /*              */
               union {                                  /* TCSR         */
                     unsigned char BYTE;                /*  Byte Access */
                     struct {                           /*  Bit  Access */
                            unsigned char CMFB:1;       /*    CMFB      */
                            unsigned char CMFA:1;       /*    CMFA      */
                            unsigned char OVF :1;       /*    OVF       */
                            unsigned char     :1;       /*              */
                            unsigned char OS  :4;       /*    OS        */
                            }      BIT;                 /*              */
                     }          TCSR;                   /*              */
               char             wk2;                    /*              */
               unsigned char    TCORA;                  /* TCORA        */
               char             wk3;                    /*              */
               unsigned char    TCORB;                  /* TCORB        */
               char             wk4;                    /*              */
               unsigned char    TCNT;                   /* TCNT         */
};                                                      /*              */
struct st_flash {                                       /* struct FLASH */
                union {                                 /* RAMER        */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char wk  :4;      /*              */
                             unsigned char RAMS:1;      /*    RAMS      */
                             unsigned char RAM2:1;      /*    RAM2      */
                             unsigned char RAM1:1;      /*    RAM1      */
                             unsigned char RAM0:1;      /*    RAM0      */
                             }      BIT;                /*              */
                      }         RAMER;                  /*              */
                char            wk[236];                /*              */
                union {                                 /* FLMCR1       */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char FWE:1;       /*    FWE       */
                             unsigned char SWE:1;       /*    SWE       */
                             unsigned char ESU:1;       /*    ESU       */
                             unsigned char PSU:1;       /*    PSU       */
                             unsigned char EV :1;       /*    EV        */
                             unsigned char PV :1;       /*    PV        */
                             unsigned char E  :1;       /*    E         */
                             unsigned char P  :1;       /*    P         */
                             }      BIT;                /*              */
                      }         FLMCR1;                 /*              */
                union {                                 /* FLMCR2       */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char FLER:1;      /*    FLER      */
                             }      BIT;                /*              */
                      }         FLMCR2;                 /*              */
                union {                                 /* EBR1         */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char EB7:1;       /*    EB7       */
                             unsigned char EB6:1;       /*    EB6       */
                             unsigned char EB5:1;       /*    EB5       */
                             unsigned char EB4:1;       /*    EB4       */
                             unsigned char EB3:1;       /*    EB3       */
                             unsigned char EB2:1;       /*    EB2       */
                             unsigned char EB1:1;       /*    EB1       */
                             unsigned char EB0:1;       /*    EB0       */
                             }      BIT;                /*              */
                      }         EBR1;                   /*              */
                union {                                 /* EBR2         */
                      unsigned char BYTE;               /*  Byte Access */
                      struct {                          /*  Bit  Access */
                             unsigned char wk  :4;      /*              */
                             unsigned char EB11:1;      /*    EB11      */
                             unsigned char EB10:1;      /*    EB10      */
                             unsigned char EB9 :1;      /*    EB9       */
                             unsigned char EB8 :1;      /*    EB8       */
                             }      BIT;                /*              */
                      }         EBR2;                   /*              */
};                                                      /*              */
#define P_TPU   (*(volatile struct st_tpu   *)0xFFFFC0) /* TPU   Address*/
#define P_TPU0  (*(volatile struct st_tpu0  *)0xFFFFD0) /* TPU0  Address*/
#define P_TPU1  (*(volatile struct st_tpu1  *)0xFFFFE0) /* TPU1  Address*/
#define P_TPU2  (*(volatile struct st_tpu1  *)0xFFFFF0) /* TPU2  Address*/
#define P_TPU3  (*(volatile struct st_tpu0  *)0xFFFE80) /* TPU3  Address*/
#define P_TPU4  (*(volatile struct st_tpu1  *)0xFFFE90) /* TPU4  Address*/
#define P_TPU5  (*(volatile struct st_tpu1  *)0xFFFEA0) /* TPU5  Address*/
#define P_P1    (*(volatile struct st_p1    *)0xFFFEB0) /* P1    Address*/
#define P_P2    (*(volatile struct st_p1    *)0xFFFEB1) /* P2    Address*/
#define P_P3    (*(volatile struct st_p3    *)0xFFFEB2) /* P3    Address*/
#define P_P4    (*(volatile struct st_p4    *)0xFFFF53) /* P4    Address*/
#define P_P5    (*(volatile struct st_p5    *)0xFFFEB4) /* P5    Address*/
#define P_P6    (*(volatile struct st_p1    *)0xFFFEB5) /* P6    Address*/
#define P_PA    (*(volatile struct st_pa    *)0xFFFEB9) /* PA    Address*/
#define P_PB    (*(volatile struct st_pb    *)0xFFFEBA) /* PB    Address*/
#define P_PC    (*(volatile struct st_pb    *)0xFFFEBB) /* PC    Address*/
#define P_PD    (*(volatile struct st_pb    *)0xFFFEBC) /* PD    Address*/
#define P_PE    (*(volatile struct st_pb    *)0xFFFEBD) /* PE    Address*/
#define P_PF    (*(volatile struct st_p1    *)0xFFFEBE) /* PF    Address*/
#define P_PG    (*(volatile struct st_pg    *)0xFFFEBF) /* PG    Address*/
#define P_INTC  (*(volatile struct st_intc  *)0xFFFEC4) /* INTC  Address*/
#define P_BSC   (*(volatile struct st_bsc   *)0xFFFED0) /* BSC   Address*/
#define P_DMAC0A (*(volatile struct st_sam0a *)0xFFFEE0) /* DMAC 0A Addr */
#define P_DMAC0B (*(volatile struct st_sam0b *)0xFFFEE8) /* DMAC 0B Addr */
#define P_DMAC1A (*(volatile struct st_sam1a *)0xFFFEF0) /* DMAC 1A Addr */
#define P_DMAC1B (*(volatile struct st_sam1b *)0xFFFEF8) /* DMAC 1B Addr */
#define P_DMAC0 (*(volatile struct st_fam0  *)0xFFFEE0) /* DMAC 0  Addr */
#define P_DMAC1 (*(volatile struct st_fam1  *)0xFFFEF0) /* DMAC 1  Addr */
#define P_DMAC  (*(volatile struct st_dmac  *)0xFFFF00) /* DMAC  Address*/
#define P_DTC   (*(volatile struct st_dtc   *)0xFFFF30) /* DTC   Address*/
#define P_SBYCR (*(volatile union  un_sbycr *)0xFFFF38) /* SBYCR Address*/
#define P_SYSCR (*(volatile union  un_syscr *)0xFFFF39) /* SYSCR Address*/
#define P_SCKCR (*(volatile union  un_sckcr *)0xFFFF3A) /* SCKCR Address*/
#define P_MDCR  (*(volatile union  un_mdcr  *)0xFFFF3B) /* MDCR  Address*/
#define P_MSTPCR (*(volatile union  un_mstpcr*)0xFFFF3C) /* MSTPCRAddress*/
#define P_SYSCR2 (*(volatile union  un_syscr2*)0xFFFF42) /* SYSCR2Address*/
#define P_PPG   (*(volatile struct st_ppg   *)0xFFFF46) /* PPG   Address*/
#define P_SCI0  (*(volatile struct st_sci   *)0xFFFF78) /* SCI0  Address*/
#define P_SCI1  (*(volatile struct st_sci   *)0xFFFF80) /* SCI1  Address*/
#define P_SCI2  (*(volatile struct st_sci   *)0xFFFF88) /* SCI2  Address*/
#define P_ICI0  (*(volatile struct st_ici   *)0xFFFF78) /* ICI0  Address*/
#define P_ICI1  (*(volatile struct st_ici   *)0xFFFF80) /* ICI1  Address*/
#define P_ICI2  (*(volatile struct st_ici   *)0xFFFF88) /* ICI2  Address*/
#define P_AD    (*(volatile struct st_ad    *)0xFFFF90) /* A/D   Address*/
#define P_DA    (*(volatile struct st_da    *)0xFFFFA4) /* D/A   Address*/
#define P_TMR   (*(volatile struct st_tmr   *)0xFFFFB0) /* TMR   Address*/
#define P_TMR0  (*(volatile struct st_tmr0  *)0xFFFFB0) /* TMR0  Address*/
#define P_TMR1  (*(volatile struct st_tmr1  *)0xFFFFB1) /* TMR1  Address*/
#define P_FLASH (*(volatile struct st_flash *)0xFFFEDB) /* FLASH Address*/
#define st_tpu3 st_tpu0                         /* Change Struct TPU3   */
#define st_tpu2 st_tpu1                         /* Change Struct TPU2   */
#define st_tpu4 st_tpu1                         /* Change Struct TPU4   */
#define st_tpu5 st_tpu1                         /* Change Struct TPU5   */
#define st_p2   st_p1                           /* Change Struct P2->P1 */
#define st_p6   st_p1                           /* Change Struct P6->P1 */
#define st_pf   st_p1                           /* Change Struct PF->P1 */
#define st_pc   st_pb                           /* Change Struct PC->PB */
#define st_pd   st_pb                           /* Change Struct PD->PB */
#define st_pe   st_pb                           /* Change Struct PE->PB */

#if H8S_2319C
// 2319c Flash Registers configuration

union un_fccs {                         /* Flash Code Control Select FCCS  IV = 0x80 ,Address = H'FFC4*/
    unsigned char BYTE ;                /* Byte access*/
    struct {                            /* Bit  access*/
        unsigned char      : 3;
        unsigned char FLER : 1;        /* FLER*/
        unsigned char      : 3;
        unsigned char SCO  : 1;        /* SCO*/
    }    BIT;
};

union un_fpcs {                         /* FPCS  IV = 0x00 ,Address = H'FFC5*/
    unsigned char BYTE ;                /* Byte access*/
    struct {                            /* Bit  access*/
        unsigned char      : 7;
        unsigned char PPVS : 1;        /* PPVS*/
    }    BIT;
};

union un_fecs {                         /* FECS  IV = 0x00 ,Address = H'FFC6*/
    unsigned char BYTE ;                /* Byte access*/
    struct {                            /* Bit  access*/
        unsigned char      : 7;
        unsigned char EPVB : 1;        /* EPVB*/
    }    BIT;
};

union un_ramer {                         /* RAMER  IV = 0x00 ,Address = H'FEDB*/
    unsigned char BYTE ;                /* Byte access*/
    struct {                            /* Bit  access*/
        unsigned char          : 4;
        unsigned char RAMS     : 1;
        unsigned char RAM2     : 1;
        unsigned char RAM1     : 1;
        unsigned char RAM0     : 1;
    }    BIT;
};
#endif

typedef enum tagStatusLed {
    STATUSLED_AMBER = 0,
    STATUSLED_RED   = 1,
    STATUSLED_GREEN = 2,
    STATUSLED_OFF   = 3
} STATUSLED;

// Define FWtypes
typedef enum tagFwType {
    FWTYPE_BOOT = 0,
    FWTYPE_APP  = 1,
    FWTYPE_FPGA    = 2,
    FWTYPE_DSCBOOT = 3,
    FWTYPE_DSCAPP  = 4
} FWTYPE;
/*******************************************************************************
*                            CONSTANT DECLARATIONS                             *
*******************************************************************************/
const UINT32 SYSTEM_CLOCK_FREQUENCY = 24000000; // 24 MHz
const UINT32 SECONDS_IN_MINUTE      = 60;
const UINT32 MILLISECONDS_IN_SECOND = 1000;
const UINT32 MICROSECONDS_IN_MILLISECOND = 1000;
const UINT32 MICROSECONDS_IN_SECOND = MICROSECONDS_IN_MILLISECOND * MILLISECONDS_IN_SECOND;

#define IOLPORT0 //Use SCI0 for IOLINK  
// Define memory addresses
#define FLASH_START_ADDRESS             (0x00000000)
#define FLASH_PROGRAM_BLOCK_SIZE        (128)


#define BOOT_FLASH_START_ADDRESS    (0x00020000)    // Address where boot firmware flashing starts
#define BOOT_HEADER_START_ADDRESS   (0x000204F0)    // Header start address
#define BOOT_HEADER_END_ADDRESS     (0x000204FF)    // Boot Header end address
#define BOOT_BYTECNT_ADDRESS        (0x000204F0)    // Boot Firmware size location
#define BOOT_CRC_ADDRESS            (0x000204F4)    // Boot 32Bit CRC location
#define BOOT_MODTYPE_ADDRESS        (0x000204F8)    // Boot Module type location
#define BOOT_FWTYPE_ADDRESS         (0x000204FA)    // Boot Firmware type location
#define APP_FLASH_START_ADDRESS     (0x00020000)    // APP Fimrware Start
#define APP_HEADER_START_ADDRESS    (0x000204F0)    // APP Header Start
#define APP_HEADER_END_ADDRESS      (0x000204FF)    // APP Header End
#define APP_BYTECNT_ADDRESS         (0x000204F0)    // APP FW ByteCount
#define APP_CRC_ADDRESS             (0x000204F4)    // APP FW 32Bit CRC
#define FPGA_FLASH_START_ADDRESS    (0x00020000)    // Address where fpga firmware flashing starts
#define FPGA_HEADER_START_ADDRESS   (0x00020000)    // Header start address
#define FPGA_HEADER_END_ADDRESS     (0x0002000F)    // Fpga Header end address
#define FPGA_BYTECNT_ADDRESS        (0x00020000)    // Fpga Firmware size location
#define FPGA_CRC_ADDRESS            (0x00020004)    // Fpga 32Bit CRC location
#define FPGA_MODTYPE_ADDRESS        (0x00020008)    // Fpga Module type location
#define FPGA_FWTYPE_ADDRESS         (0x0002000A)    // Fpga Firmware type location
#define FPGA_STARTS_HERE_IN_H8      (0x00008000)    // Actual location of Fpga in flash

#define INTERNAL_RAM_START_ADDRESS      (0x00FF7C00)    // 32K internal RAM
#define INTERNAL_RAM_END_ADDRESS        (0x00FFFBFF)

#define P1DR                            (0x00FFFF60)
#define PGDR                            (0x00FFFF6F)

#define FLASH_END_ADDRESS           (0x0005FFFF)    // 384K internal ROM
#define CPLD_START_ADDRESS          (0x00080000)
#define CPLD_END_ADDRESS            (0x00080009)
#define FPGA_START_ADDRESS          (0x00400000)//TBD
#define FPGA_END_ADDRESS            (0x004003FF)//TBD
#define SHRAM_BOOT_DIAG_ADDRESS     (0x85FFC)   //0x85FFC used for H8S boot sharedram diagnostic
#define SHRAM_END_ADDRESS           (0x85FDE)   //0x85FE0 and 0x85FFF  is reserved
#define SHRAM_START_ADDRESS         (0x82000)


#define EXTERNAL_RAM_START_ADDRESS  SHRAM_START_ADDRESS    // Shared external RAM
#define EXTERNAL_RAM_END_ADDRESS    SHRAM_END_ADDRESS

#define STACK_SIZE                  0x1000          // 4K bytes stack for HEK debug and release versions.
#define STACK_SFLIMIT               0x100           // 256 bytes stack guarded area

#define STACK_BOTTOM                    ((volatile UINT32 *)INTERNAL_RAM_END_ADDRESS)
#define STACK_TOP                       ((volatile UINT32 *)(INTERNAL_RAM_END_ADDRESS + 1 - STACK_SIZE))

// Module Info section definitions
#define MODULE_INFO_FLASH_BLOCK         (7)
#define MODULEINFO_START_ADDRESS        (0x00007000)
#define VENDOR_ID                       (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS)))
#define PRODUCT_TYPE                    (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 2)))
#define PRODUCT_CODE                    (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4)))
#define SERIAL_NUMBER                   (*((volatile UINT32  *)(MODULEINFO_START_ADDRESS + 6)))
#define HARDWARE_REVCODE                (*((volatile UINT8   *)(MODULEINFO_START_ADDRESS + 10)))
#define HARDWARE_REVNUMBER              (*((volatile UINT8   *)(MODULEINFO_START_ADDRESS + 11)))
#define CALIBRATION_MARK                (*((volatile UINT8   *)(MODULEINFO_START_ADDRESS + 15)))

#ifdef IOMTYPE_AIH
    #define CALIBRATION_5VREF_HILIMIT   (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 16)))
    #define CALIBRATION_5VREF_LOLIMIT   (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 20)))
    #define CALIBRATION_SLOPE           (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 24)))
    #define CALIBRATION_OFFSET          (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 28)))
    #define CHANNEL_ZERODRIFT_PTR         ((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 32))
#elif (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    #define CHANNEL_OFFSET_PTR            ((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 16))
    #define CALIBRATION_SLOPE           (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 272)))
    #define CALIBRATION_OFFSET          (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 276)))
    #define CALIB_TEST_COUNT            (*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 280)))
#elif(defined(IOMTYPE_SP))
    // following needs to be change when calibration is done
    #define CALIBRATION_5VREF_HILIMIT   5//(*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 16)))
    #define CALIBRATION_5VREF_LOLIMIT   1//(*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 20)))
    #define CALIBRATION_SLOPE           0.0000762951094834821//(*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 24)))
    #define CALIBRATION_OFFSET          0//(*((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 28)))
    #define CHANNEL_ZERODRIFT_PTR       0//  ((volatile FLOAT32 *)(MODULEINFO_START_ADDRESS + 32))

#endif

#define MODULEINFO_WRITECOUNT           (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4090)))
#define MODULEINFO_WRITE_FLAGS          (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4092)))
#define MODULEINFO_CHKSUM               (*((volatile UINT16  *)(MODULEINFO_START_ADDRESS + 4094)))
#define MODULEINFO_END_ADDRESS          (0x00007FFF)

// Programmable Device Information
const UINT8 PD_REV_A = 1;
const UINT8 PD_REV_B = PD_REV_A + 1;
const UINT8 PD_REV_C = PD_REV_B + 1;
const UINT8 PD_REV_D = PD_REV_C + 1;
const UINT8 PD_REV_E = PD_REV_D + 1;
const UINT8 PD_REV_F = PD_REV_E + 1;
const UINT8 PD_REV_G = PD_REV_F + 1;
const UINT8 PD_REV_H = PD_REV_G + 1;
const UINT8 PD_REV_I = PD_REV_H + 1;
const UINT8 PD_REV_J = PD_REV_I + 1;
const UINT8 PD_REV_K = PD_REV_J + 1;
const UINT8 PD_REV_L = PD_REV_K + 1;
const UINT8 PD_REV_M = PD_REV_L + 1;
const UINT8 PD_REV_N = PD_REV_M + 1;
const UINT8 PD_REV_O = PD_REV_N + 1;
const UINT8 PD_REV_P = PD_REV_O + 1;
const UINT8 PD_REV_Q = PD_REV_P + 1;
const UINT8 PD_REV_R = PD_REV_Q + 1;
const UINT8 PD_REV_S = PD_REV_R + 1;
const UINT8 PD_REV_T = PD_REV_S + 1;
const UINT8 PD_REV_U = PD_REV_T + 1;
const UINT8 PD_REV_V = PD_REV_U + 1;
const UINT8 PD_REV_W = PD_REV_V + 1;
const UINT8 PD_REV_X = PD_REV_W + 1;
const UINT8 PD_REV_Y = PD_REV_X + 1;
const UINT8 PD_REV_Z = PD_REV_Y + 1;

// Offsets in the SPI EEPROM for the calibration and HWINFO.
#if (HEK)
    const UINT8 EE_VENDOR_ID            = 0;
    const UINT8 EE_PRODUCT_TYPE         = 2;
    const UINT8 EE_PRODUCT_CODE         = 4;
    const UINT8 EE_SERIAL_NUMBER        = 6;
    const UINT8 EE_HARDWARE_REVCODE     = 10;
    const UINT8 EE_CALIBRATION_MARK     = 15;
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_SP))
    const UINT8 EE_CALIBRATION_5VREF_HILIMIT    = 16;
    const UINT8 EE_CALIBRATION_5VREF_LOLIMIT    = 20;
    const UINT8 EE_CALIBRATION_SLOPE            = 24;
    const UINT8 EE_CALIBRATION_OFFSET           = 28;
    const UINT8 EE_CHANNEL_ZERODRIFT_PTR        = 32;
  #elif (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    const UINT8 EE_CHANNEL_OFFSET_PTR           = 16;
    const UINT16 EE_CALIBRATION_SLOPE           = 272;
    const UINT16 EE_CALIBRATION_OFFSET          = 276;
    const UINT16 EE_CALIB_TEST_COUNT            = 280;
  #endif
    const UINT16 EE_MODULEINFO_WRITECOUNT       = 506;
    const UINT16 EE_MODULEINFO_WRITE_FLAGS      = 508;
    const UINT16 EE_MODULEINFO_CHKSUM           = 510;
#endif

#define ADDRESS_RANGE_END           (0x00FFFFFF)

// Stack pattern bytes to check against stack corruption
const UINT32 STACKTESTPATTERN         = 0xFF5AA5FF;
const UINT32 MAX_CALIBRATION_COUNT    = 200;
const UINT8  CALIBRATION_DONE         = 0xA5;

const UINT16 MODULINFO_WRITE_COMPLETE = 0x5A5A;
const UINT16 EEPROM_MAXWRCOUNT        = 10000;  //MAx 10,000 writes supported for EEPROM
const UINT8  HWINFO_REVLETTER_MASK    = 0x3F; // to mask out the first two unused bits.
const UINT8  FPGA_REVNUMBER_MASK    = 0x1F; // mask out B7:RIP_n, B6:DIP_n and B5:HFRESET (DO only).

// Default manufacturing info values - loaded if module info section is not programmed.
const UINT32 DEFAULT_SERIAL_NUMBER    = 1234567890;
const UINT16 HWINFO_VENDOR_ID         = 3;
const UINT16 DEFAULT_PRODUCT_CODE     = 1;
const UINT8  DEFAULT_REVNUMBER        = 255;
const UINT8  REVLETTER_A              = 1;
const UINT8  REVLETTER_ZZ             = 0x3A;

// Flash addresses where boot and application addresses are strored.

// Version Information triplet
#define VERSION_NUMBER_OFFSET       0x70
#define REVISION_NUMBER_OFFSET      0x71
#define BUILD_NUMBER_OFFSET         0x72

#define BOOT_VERSION_BLOCK          0x100   // Note: BLOCK should be 128 byte block boundary (0x80)
#define BOOT_VERSION_NUMBER_PTR     ((UINT8 *)(BOOT_VERSION_BLOCK + VERSION_NUMBER_OFFSET))  // 0x170
#define BOOT_REVISION_NUMBER_PTR    ((UINT8 *)(BOOT_VERSION_BLOCK + REVISION_NUMBER_OFFSET)) // 0x171
#define BOOT_BUILD_NUMBER_PTR       ((UINT8 *)(BOOT_VERSION_BLOCK + BUILD_NUMBER_OFFSET))    // 0x172

#define APP_VERSION_BLOCK           0x20100

#define APP_VERSION_NUMBER_PTR      ((UINT8 *)(APP_VERSION_BLOCK + VERSION_NUMBER_OFFSET))   // 0x20170
#define APP_REVISION_NUMBER_PTR     ((UINT8 *)(APP_VERSION_BLOCK + REVISION_NUMBER_OFFSET))  // 0x20171
#define APP_BUILD_NUMBER_PTR        ((UINT8 *)(APP_VERSION_BLOCK + BUILD_NUMBER_OFFSET))     // 0x20172


#if H8S_2319C //TBD Flash registers to be added
    // 2319c Flash registers Memory Map location
    #define P_FCCS  (*(volatile union un_fccs   *)0xFFFFC4) /* FCCS Address*/
    #define P_FPCS  (*(volatile union un_fpcs   *)0xFFFFC5) /* FPCS Address*/
    #define P_FECS  (*(volatile union un_fecs   *)0xFFFFC6) /* FECS Address*/
    #define P_RAMER (*(volatile union un_ramer  *)0xFFFEDB) /* RAMER Address*/
    #define P_FKEY  (*(volatile UINT8   *)0xFFFFC8) /* FKEY Address*/
    #define P_FMATS (*(volatile UINT8   *)0xFFFFC9) /* FMATS Address*/
    #define P_FTDAR (*(volatile UINT8   *)0xFFFFCA) /* FTDAR Address*/
#endif

// Module Stop Control Register
#define MSTPCR          P_MSTPCR.WORD        // Word Access to MSTP
#define MSTPCR_DTC      P_MSTPCR.BIT.DTC     // Data Transfer Controller
#define MSTPCR_TPU      P_MSTPCR.BIT.TPU     // 16 Bit Timer Pulse Unit
#define MSTPCR_TMR      P_MSTPCR.BIT.TMR     // 8 Bit Timers
#define MSTPCR_DAC      P_MSTPCR.BIT.DAC     // Digital to Analog Converter
#define MSTPCR_ADC      P_MSTPCR.BIT.ADC     // Analog to Digital Converter
#define MSTPCR_SCI1     P_MSTPCR.BIT.SCI1    // Serial Commn. Interface Channel 1
#define MSTPCR_SCI0     P_MSTPCR.BIT.SCI0    // Serial Commn. Interface Channel 0


const unsigned char MODULE_DISABLED = 1;
const unsigned char MODULE_ENABLED = 0;

// System Control Register
#define SYSCR           P_SYSCR.BYTE         // Byte Access to SYSCR
#define SYSCR_INTM      P_SYSCR.BIT.INTM     // Interrupt Control Mode
#define SYSCR_NMIEG     P_SYSCR.BIT.NMIEG    // NMI Edge Select
#define SYSCR_LWROD     P_SYSCR.BIT.LWROD    //
#define SYSCR_IRQPAS    P_SYSCR.BIT.IRQPAS   // IRQ Input Pin Select
#define SYSCR_RAME      P_SYSCR.BIT.RAME     // RAM Emulation
const unsigned char SYSCR_ICM2 = 2;
const unsigned char SYSCR_ICM0 = 0;

// Interrupt Control Register
#define INTC_IER        P_INTC.IER.BYTE
#define INTC_IPRA       P_INTC.IPRA.BYTE
#define INTC_IPRB       P_INTC.IPRB.BYTE
#define INTC_IPRC       P_INTC.IPRC.BYTE
#define INTC_IPRD       P_INTC.IPRD.BYTE
#define INTC_IPRE       P_INTC.IPRE.BYTE
#define INTC_IPRF       P_INTC.IPRF.BYTE
#define INTC_IPRG       P_INTC.IPRG.BYTE
#define INTC_IPRH       P_INTC.IPRH.BYTE
#define INTC_IPRI       P_INTC.IPRI.BYTE
#define INTC_IPRJ       P_INTC.IPRJ.BYTE
#define INTC_IPRK       P_INTC.IPRK.BYTE
#define INTC_ISCR       P_INTC.ISCR.WORD
#define INTC_ISR        P_INTC.ISR.BYTE

#define IPRG_SCAN       P_INTC.IPRG.BIT.HIGH
#define IPRG_HART       P_INTC.IPRG.BIT.HIGH // HART timer
#define IPRI_BLINK      P_INTC.IPRG.BIT.LOW  // TGI3A - LED Blink

#define IPRI_GHO        P_INTC.IPRA.BIT.HIGH // IRQ0 - Gap Has Occurred
#define IPRI_PDVC       P_INTC.IPRA.BIT.LOW  // IRQ1 - Programmable Device
#define IPRI_OVERCURNT  P_INTC.IPRB.BIT.HIGH // IRQ0 - Over-current Has Occurred
#define IPRI_HART       IPRI_PDVC            //   HEK: FPGA - HART UARTS
#define IPRI_WDTO       IPRI_HART            //   LEK: CPLD - WatchDog TimeOut
#define IPRI_DTC        P_INTC.IPRC.BIT.LOW  // SWDTEND - Data Transfer Controller
#define IPRI_GAPT       P_INTC.IPRH.BIT.HIGH // TGI4B - Gap/Silence Timer
#define IPRI_TICK       P_INTC.IPRH.BIT.LOW  // TGI5A - System Clock Tick
#define IPRI_IOPROC     P_INTC.IPRF.BIT.HIGH // TGI0A - I/O Processing
#define IPRI_DEBUG      P_INTC.IPRK.BIT.HIGH // SCI1 - Debug port
#define IPRI_POWERFAIL  P_INTC.IPRB.BIT.LOW // IRQ4 - Power failure

#ifdef IOLPORT0
#define IPRI_IOL        P_INTC.IPRJ.BIT.LOW  // ERI0, RXI0, TXI0, TEI0 - IOL Serial Port
#else
#define IPRI_IOL        P_INTC.IPRK.BIT.HIGH  // ERI0, RXI0, TXI0, TEI0 - IOL Serial Port
#endif

const unsigned char LVLPRI_HIGHEST      = 7;
const unsigned char LVLPRI_GHO          = LVLPRI_HIGHEST;
const unsigned char LVLPRI_IOL          = LVLPRI_HIGHEST;
const unsigned char LVLPRI_IOLN         = 6 ;

#ifdef IOMTYPE_DISOE
    const unsigned char LVLPRI_SOE      = 7;
    const unsigned char LVLPRI_TICK     = 4;
#else
    const unsigned char LVLPRI_TICK     = 5;
#endif

//Set priority level of BlinkLedInterruptHandler to be same as of
//STC interrupt handler.The STC interrupt handler can no longer
//interrupt BlinkLedInterruptHandler.
const unsigned char LVLPRI_LED          = LVLPRI_TICK;

const unsigned char LVLPRI_IOPROC       = 4;

#if (HEK)
  #ifdef IOMTYPE_AOH
    const unsigned char LVLPRI_EEPRDWR  = LVLPRI_TICK;
  #else
    const unsigned char LVLPRI_EEPRDWR  = LVLPRI_IOPROC;
  #endif
#endif

const unsigned char LVLPRI_PDVC         = 3;
const unsigned char LVLPRI_HART         = LVLPRI_PDVC;
const unsigned char LVLPRI_WDTO         = LVLPRI_HART;

const unsigned char LVLPRI_GAPT         = 2;
const unsigned char LVLPRI_DBUG         = 1;
const unsigned char LVLPRI_TASK         = 0;

// LED blink period in msec during softfail conditions.
const UINT16 STATUSLED_BLINK_PERIOD = 500;

// Serial Control Interface Channel 1
#define SCIC1_SMR       P_SCI1.SMR.BYTE      // Serial Mode Register 1
#define SCIC1_CA        P_SCI1.SMR.BIT.CA    //  Communication Mode
#define SCIC1_CHR       P_SCI1.SMR.BIT.CHR   //  Character Length
#define SCIC1_PE        P_SCI1.SMR.BIT.PE    //  Parity Enable
#define SCIC1_OE        P_SCI1.SMR.BIT.OE    //  Parity Mode
#define SCIC1_STOP      P_SCI1.SMR.BIT.STOP  //  Number of Stop Bits
#define SCIC1_MP        P_SCI1.SMR.BIT.MP    //  Multiprocessor Mode
#define SCIC1_CKS       P_SCI1.SMR.BIT.CKS   //  Clock Select 1 and 0
#define SCIC1_BRR       P_SCI1.BRR           // Bit Rate Register 1
#define SCIC1_SCR       P_SCI1.SCR.BYTE      // Serial Control Register 1
#define SCIC1_TIE       P_SCI1.SCR.BIT.TIE   //  Transmit Interrupt Enable
#define SCIC1_RIE       P_SCI1.SCR.BIT.RIE   //  Receive Interrupt Enable
#define SCIC1_TE        P_SCI1.SCR.BIT.TE    //  Transmitter Enable
#define SCIC1_RE        P_SCI1.SCR.BIT.RE    //  Receiver Enable
#define SCIC1_MPIE      P_SCI1.SCR.BIT.MPIE  //  Multiprocessor Interrupt Enable
#define SCIC1_TEIE      P_SCI1.SCR.BIT.TEIE  //  Transmit End Interrupt Enable
#define SCIC1_CKE       P_SCI1.SCR.BIT.CKE   //  Clock Enable
#define SCIC1_TDR       P_SCI1.TDR           //  Transmit Data Register
#define SCIC1_SSR       P_SCI1.SSR.BYTE      // Serial Status Register 1
#define SCIC1_TDRE      P_SCI1.SSR.BIT.TDRE  //  Transmit Data Register Empty
#define SCIC1_RDRF      P_SCI1.SSR.BIT.RDRF  //  Receive Data Register Empty
#define SCIC1_ORER      P_SCI1.SSR.BIT.ORER  //  Overrun Error
#define SCIC1_FER       P_SCI1.SSR.BIT.FER   //  Framing Error
#define SCIC1_PER       P_SCI1.SSR.BIT.PER   //  Parity Error
#define SCIC1_TEND      P_SCI1.SSR.BIT.TEND  //  Transmit End
#define SCIC1_MPB       P_SCI1.SSR.BIT.MPB   //  Multiprocessor Bit
#define SCIC1_MPBT      P_SCI1.SSR.BIT.MPBT  //  Multiprocessor Bit Transfer
#define SCIC1_RDR       P_SCI1.RDR           // Receive Data Register 1
#define SCIC1_SCMR      P_SCI1.SCMR.BYTE     // Smart Card Mode Register 1
#define SCIC1_SDIR      P_SCI1.SCMR.BIT.SDIR //  SC Data Transfer Direction
#define SCIC1_SINV      P_SCI1.SCMR.BIT.SINV //  SC Data Invert
#define SCIC1_SMIF      P_SCI1.SCMR.BIT.SMIF //  SC Interface Mode Select

// Timer Pulse Unit
#define TPUC            (*(volatile struct st_tpu *)0xFFFFC0)
#define TPU_TSTR        TPUC.TSTR.BYTE      //  Timer Start Register
#define TPU0_CST        TPUC.TSTR.BIT.CST0  //  Counter 0 Enable
#define TPU1_CST        TPUC.TSTR.BIT.CST1  //  Counter 1 Enable
#define TPU2_CST        TPUC.TSTR.BIT.CST2  //  Counter 2 Enable
#define TPU3_CST        TPUC.TSTR.BIT.CST3  //  Counter 3 Enable
#define TPU4_CST        TPUC.TSTR.BIT.CST4  //  Counter 4 Enable
#define TPU5_CST        TPUC.TSTR.BIT.CST5  //  Counter 5 Enable
#define TPU_TSYR        TPUC.TSYR.BYTE      //  Timer Synchro Register
#define TPU0_SYNC       TPUC.TSYR.BIT.SYNC0 //  Counter 0 Enable
#define TPU1_SYNC       TPUC.TSYR.BIT.SYNC1 //  Counter 1 Enable
#define TPU2_SYNC       TPUC.TSYR.BIT.SYNC2 //  Counter 2 Enable
#define TPU3_SYNC       TPUC.TSYR.BIT.SYNC3 //  Counter 3 Enable
#define TPU4_SYNC       TPUC.TSYR.BIT.SYNC4 //  Counter 4 Enable
#define TPU5_SYNC       TPUC.TSYR.BIT.SYNC5 //  Counter 5 Enable

// Timer Pulse Unit 0
#define TPU0            (*(volatile struct st_tpu0 *)0xFFFFD0)
#define TPU0_TCNT       TPU0.TCNT           //  Timer Counter Register
#define TPU0_TGRA       TPU0.TGRA           //  Timer General Register A
#define TPU0_TGRB       TPU0.TGRB           //  Timer General Register B
#define TPU0_TGRC       TPU0.TGRC           //  Timer General Register C
#define TPU0_TGRD       TPU0.TGRD           //  Timer General Register D
#define TPU0_TSR        TPU0.TSR.BYTE       //  Timer General Register B
#define TPU0_TCFV       TPU0.TSR.BIT.TCFV   //  Overflow Flag
#define TPU0_TGFA       TPU0.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU0_TGFB       TPU0.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU0_TGFC       TPU0.TSR.BIT.TGFC   //  Input Capture/Output Compare Flag C
#define TPU0_TGFD       TPU0.TSR.BIT.TGFD   //  Input Capture/Output Compare Flag D
#define TPU0_TIER       TPU0.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU0_TTGE       TPU0.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU0_TCIEV      TPU0.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU0_TGIEA      TPU0.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU0_TGIEB      TPU0.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU0_TGIEC      TPU0.TIER.BIT.TGIEC //  TGR Interrupt Enable C
#define TPU0_TGIED      TPU0.TIER.BIT.TGIED //  TGR Interrupt Enable D
#define TPU0_TIOR       TPU0.TIOR.WORD      //  Timer I/O Control Register
#define TPU0_IORH       TPU0.TIOR.BYTE.H    //  Timer I/O Control High Byte
#define TPU0_IORL       TPU0.TIOR.BYTE.L    //  Timer I/O Control Low Byte
#define TPU0_IOA        TPU0.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU0_IOB        TPU0.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU0_IOC        TPU0.TIOR.BIT.IOC   //  I/O Control for TGRC
#define TPU0_IOD        TPU0.TIOR.BIT.IOD   //  I/O Control for TGRD
#define TPU0_TMDR       TPU0.TMDR.BYTE      //  Timer Mode Register
#define TPU0_MD         TPU0.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU0_BFA        TPU0.TMDR.BIT.BFA   //  MBuffer Operation A
#define TPU0_BFB        TPU0.TMDR.BIT.BFB   //  Buffer Operation A
#define TPU0_TCR        TPU0.TCR.BYTE       //  Timer Control Register
#define TPU0_CCLR       TPU0.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU0_CKEG       TPU0.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU0_TPSC       TPU0.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 1
#define TPU1            (*(volatile struct st_tpu1 *)0xFFFFE0)
#define TPU1_TCNT       TPU1.TCNT           //  Timer Counter Register
#define TPU1_TGRA       TPU1.TGRA           //  Timer General Register A
#define TPU1_TGRB       TPU1.TGRB           //  Timer General Register B
#define TPU1_TSR        TPU1.TSR.BYTE       //  Timer General Register B
#define TPU1_TCFD       TPU1.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU1_TGFA       TPU1.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU1_TGFB       TPU1.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU1_TCFU       TPU1.TSR.BIT.TCFU   //  Underflow Flag
#define TPU1_TCFV       TPU1.TSR.BIT.TCFV   //  Overflow Flag
#define TPU1_TIER       TPU1.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU1_TTGE       TPU1.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU1_TCIEU      TPU1.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU1_TCIEV      TPU1.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU1_TGIEA      TPU1.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU1_TGIEB      TPU1.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU1_TIOR       TPU1.TIOR.BYTE      //  Timer I/O Control Register
#define TPU1_IOA        TPU1.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU1_IOB        TPU1.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU1_TMDR       TPU1.TMDR.BYTE      //  Timer Mode Register
#define TPU1_MD         TPU1.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU1_TCR        TPU1.TCR.BYTE       //  Timer Control Register
#define TPU1_CCLR       TPU1.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU1_CKEG       TPU1.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU1_TPSC       TPU1.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 2
#define TPU2            (*(volatile struct st_tpu1 *)0xFFFFF0)
#define TPU2_TCNT       TPU2.TCNT           //  Timer Counter Register
#define TPU2_TGRA       TPU2.TGRA           //  Timer General Register A
#define TPU2_TGRB       TPU2.TGRB           //  Timer General Register B
#define TPU2_TSR        TPU2.TSR.BYTE       //  Timer General Register B
#define TPU2_TCFD       TPU2.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU2_TGFA       TPU2.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU2_TGFB       TPU2.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU2_TCFU       TPU2.TSR.BIT.TCFU   //  Underflow Flag
#define TPU2_TCFV       TPU2.TSR.BIT.TCFV   //  Overflow Flag
#define TPU2_TIER       TPU2.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU2_TTGE       TPU2.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU2_TCIEU      TPU2.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU2_TCIEV      TPU2.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU2_TGIEA      TPU2.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU2_TGIEB      TPU2.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU2_TIOR       TPU2.TIOR.BYTE      //  Timer I/O Control Register
#define TPU2_IOA        TPU2.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU2_IOB        TPU2.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU2_TMDR       TPU2.TMDR.BYTE      //  Timer Mode Register
#define TPU2_MD         TPU2.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU2_TCR        TPU2.TCR.BYTE       //  Timer Control Register
#define TPU2_CCLR       TPU2.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU2_CKEG       TPU2.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU2_TPSC       TPU2.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 3
#define TPU3            (*(volatile struct st_tpu0 *)0xFFFE80)
#define TPU3_TCNT       TPU3.TCNT           //  Timer Counter Register
#define TPU3_TGRA       TPU3.TGRA           //  Timer General Register A
#define TPU3_TGRB       TPU3.TGRB           //  Timer General Register B
#define TPU3_TGRC       TPU3.TGRC           //  Timer General Register C
#define TPU3_TGRD       TPU3.TGRD           //  Timer General Register D
#define TPU3_TSR        TPU3.TSR.BYTE       //  Timer General Register B
#define TPU3_TCFV       TPU3.TSR.BIT.TCFV   //  Overflow Flag
#define TPU3_TGFA       TPU3.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU3_TGFB       TPU3.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU3_TGFC       TPU3.TSR.BIT.TGFC   //  Input Capture/Output Compare Flag C
#define TPU3_TGFD       TPU3.TSR.BIT.TGFD   //  Input Capture/Output Compare Flag D
#define TPU3_TIER       TPU3.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU3_TTGE       TPU3.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU3_TCIEV      TPU3.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU3_TGIEA      TPU3.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU3_TGIEB      TPU3.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU3_TGIEC      TPU3.TIER.BIT.TGIEC //  TGR Interrupt Enable C
#define TPU3_TGIED      TPU3.TIER.BIT.TGIED //  TGR Interrupt Enable D
#define TPU3_TIOR       TPU3.TIOR.WORD      //  Timer I/O Control Register
#define TPU3_IORH       TPU3.TIOR.BYTE.H    //  Timer I/O Control High Byte
#define TPU3_IORL       TPU3.TIOR.BYTE.L    //  Timer I/O Control Low Byte
#define TPU3_IOA        TPU3.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU3_IOB        TPU3.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU3_IOC        TPU3.TIOR.BIT.IOC   //  I/O Control for TGRC
#define TPU3_IOD        TPU3.TIOR.BIT.IOD   //  I/O Control for TGRD
#define TPU3_TMDR       TPU3.TMDR.BYTE      //  Timer Mode Register
#define TPU3_MD         TPU3.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU3_BFA        TPU3.TMDR.BIT.BFA   //  MBuffer Operation A
#define TPU3_BFB        TPU3.TMDR.BIT.BFB   //  Buffer Operation A
#define TPU3_TCR        TPU3.TCR.BYTE       //  Timer Control Register
#define TPU3_CCLR       TPU3.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU3_CKEG       TPU3.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU3_TPSC       TPU3.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 4
#define TPU4            (*(volatile struct st_tpu1 *)0xFFFE90)
#define TPU4_TCNT       TPU4.TCNT           //  Timer Counter Register
#define TPU4_TGRA       TPU4.TGRA           //  Timer General Register A
#define TPU4_TGRB       TPU4.TGRB           //  Timer General Register B
#define TPU4_TSR        TPU4.TSR.BYTE       //  Timer General Register B
#define TPU4_TCFD       TPU4.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU4_TGFA       TPU4.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU4_TGFB       TPU4.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU4_TCFU       TPU4.TSR.BIT.TCFU   //  Underflow Flag
#define TPU4_TCFV       TPU4.TSR.BIT.TCFV   //  Overflow Flag
#define TPU4_TIER       TPU4.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU4_TTGE       TPU4.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU4_TCIEU      TPU4.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU4_TCIEV      TPU4.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU4_TGIEA      TPU4.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU4_TGIEB      TPU4.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU4_TIOR       TPU4.TIOR.BYTE      //  Timer I/O Control Register
#define TPU4_IOA        TPU4.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU4_IOB        TPU4.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU4_TMDR       TPU4.TMDR.BYTE      //  Timer Mode Register
#define TPU4_MD         TPU4.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU4_TCR        TPU4.TCR.BYTE       //  Timer Control Register
#define TPU4_CCLR       TPU4.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU4_CKEG       TPU4.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU4_TPSC       TPU4.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0

// Timer Pulse Unit 5
#define TPU5            (*(volatile struct st_tpu1 *)0xFFFEA0)
#define TPU5_TCNT       TPU5.TCNT           //  Timer Counter Register
#define TPU5_TGRA       TPU5.TGRA           //  Timer General Register A
#define TPU5_TGRB       TPU5.TGRB           //  Timer General Register B
#define TPU5_TSR        TPU5.TSR.BYTE       //  Timer General Register B
#define TPU5_TCFD       TPU5.TSR.BIT.TCFD   //  Timer Control Direction Flag
#define TPU5_TGFA       TPU5.TSR.BIT.TGFA   //  Input Capture/Output Compare Flag A
#define TPU5_TGFB       TPU5.TSR.BIT.TGFB   //  Input Capture/Output Compare Flag B
#define TPU5_TCFU       TPU5.TSR.BIT.TCFU   //  Underflow Flag
#define TPU5_TCFV       TPU5.TSR.BIT.TCFV   //  Overflow Flag
#define TPU5_TIER       TPU5.TIER.BYTE      //  Timer Interrupt Enable Register
#define TPU5_TTGE       TPU5.TIER.BIT.TTGE  //  A/D Conversion Start Request Enable
#define TPU5_TCIEU      TPU5.TIER.BIT.TCIEU //  Underflow Interrupt Enable
#define TPU5_TCIEV      TPU5.TIER.BIT.TCIEV //  Overflow Interrupt Enable
#define TPU5_TGIEA      TPU5.TIER.BIT.TGIEA //  TGR Interrupt Enable A
#define TPU5_TGIEB      TPU5.TIER.BIT.TGIEB //  TGR Interrupt Enable B
#define TPU5_TIOR       TPU5.TIOR.BYTE      //  Timer I/O Control Register
#define TPU5_IOA        TPU5.TIOR.BIT.IOA   //  I/O Control for TGRA
#define TPU5_IOB        TPU5.TIOR.BIT.IOB   //  I/O Control for TGRB
#define TPU5_TMDR       TPU5.TMDR.BYTE      //  Timer Mode Register
#define TPU5_MD         TPU5.TMDR.BIT.MD    //  Mode Bits 3-0
#define TPU5_TCR        TPU5.TCR.BYTE       //  Timer Control Register
#define TPU5_CCLR       TPU5.TCR.BIT.CCLR   //  Counter Clear Bits 2-0
#define TPU5_CKEG       TPU5.TCR.BIT.CKEG   //  Clock Edge Bits 1-0
#define TPU5_TPSC       TPU5.TCR.BIT.TPSC   //  Timer Prescalar Bits 2-0


#define RCVSELA_n       P_P1.DR.BIT.B7
#define TXREQ_n         P_P1.DR.BIT.B6
#define JABRES_n        P_P1.DR.BIT.B5
#define WDTODCLR_n      P_P1.DR.BIT.B4
#define WDTRFS_n        P_P1.DR.BIT.B3
#define FPGA_DONE       P_P1.PORT.BIT.B2
#define DSC_H8S_GPIO0   P_P1.DR.BIT.B1
#define JTAG_TMS        P_P1.DR.BIT.B0

// General Purpose I/O - PORT 2.
#define CLRGHL_n        P_P2.DR.BIT.B7
#define JTAG_TDO        P_P2.DR.BIT.B6
#define SWBUREQ_n       P_P2.DR.BIT.B5
#define REBOOT_n        P_P2.DR.BIT.B4
#define WDT_EN_n        P_P2.DR.BIT.B3
#define FPGA_INIT_n     P_P2.PORT.BIT.B2
#define APP_IO_0        P_P2.DR.BIT.B1
#define APP_IO_1        P_P2.DR.BIT.B0


// General Purpose I/O - PORT 3.

#define P33_CCLK       P_P3.DR.BIT.B5
#define TRST_n         P_P3.DR.BIT.B4
#define DBG_RXD        P_P3.DR.BIT.B3
#define IOL_RXD          P_P3.DR.BIT.B2
#define DBG_TXD        P_P3.DR.BIT.B1
#define IOL_TXD          P_P3.DR.BIT.B0


// PORT 5 definitions.
#define TXD2            P_P5.DR.BIT.B0
#define RXD2            P_P5.DR.BIT.B1
#define H8S_GPIO_FPGA_0 P_P5.DR.BIT.B2
#define H8S_WAIT_n      P_P5.DR.BIT.B3


// PORT 6 definitions.
#define H8S_IRQ3       P_P6.DR.BIT.B7
#define H8S_IRQ2       P_P6.DR.BIT.B6
#define H8S_IRQ1       P_P6.DR.BIT.B5
#define H8S_IRQ0       P_P6.DR.BIT.B4
#define H8S_TDO        P_P6.DR.BIT.B3
#define H8S_TDI        P_P6.DR.BIT.B2
#define H8S_TCK        P_P6.DR.BIT.B1
#define JTAG_TCK       H8S_TCK //TBD. Tjsi si a dummy defn. Confirm later.
#define JTAG_TDI       H8S_TDI //TBD. Tjsi si a dummy defn. Confirm later.
#define FPGA_ERASE_n   H8S_TDI //Dumy!!!!!!!!!!!
#define GOODINPUT      H8S_TDI //Dumy!!!!!!!!!!!
#define H8S_TMS        P_P6.DR.BIT.B0

// General Purpose I/O - PORT A.
#define EN_SW               P_PA.DR.BIT.B0
#define H8S_DSC_INT1_n      P_PA.DR.BIT.B1
#define BOOT_CTRL_0         P_PA.DR.BIT.B2
#define BOOT_CTRL_1         P_PA.DR.BIT.B3
#define FPGA_PROG_B         P_PA.DR.BIT.B6

// General Purpose I/O - PORT B,C,D,E - no definitions.


// General Purpose I/O - PORT F.
#define PF0_CPLD_IO         P_PF.DR.BIT.B0
#define H8S_FPGA_DSCINT1_n  P_PF.DR.BIT.B1 
#define KERNEL_SEREEPROM_CS P_PF.DR.BIT.B2
#define LWR_n               P_PF.DR.BIT.B3
#define HWR_n               P_PF.DR.BIT.B4
#define RD_n                P_PF.DR.BIT.B5
#define AS_n                P_PF.DR.BIT.B6
#define PHI_CLK             P_PF.DR.BIT.B7

// General Purpose I/O - PORT G.
#define GPIO_FPGA_1    P_PG.DR.BIT.B0
#define GPIO_FPGA_2    P_PG.DR.BIT.B1
#define FPGA_H8S_DOUT  P_PG.DR.BIT.B2
#define CPLD_CS_n      P_PG.DR.BIT.B3
#define FPGA_CS_n      P_PG.DR.BIT.B4


#if HEK
    // CPLD Definitions
    union un_cpld_rd {
        struct {
            unsigned int    unusedhi:8;
            unsigned int    B7:1;
            unsigned int    B6:1;
            unsigned int    B5:1;
            unsigned int    B4:1;
            unsigned int    B3:1;
            unsigned int    B2:1;
            unsigned int    B1:1;
            unsigned int    B0:1;
        };
        UINT16 CPLDRDREG;
    };

    union un_cpld_rd_r08 {
        struct {
            unsigned int    unusedhi:8;
            unsigned int    B7:1;
            unsigned int    B6:1;
            unsigned int    B5:1;
            unsigned int    B3_4:2;
            unsigned int    B0_2:3;
        };
        UINT16 CPLDRDREG;
    };

    struct st_gpr{
        unsigned int    B7  :1;
        unsigned int    B6  :1;
        unsigned int    B5  :1;
        unsigned int    B4_3:2;
        unsigned int    B2  :1;
        unsigned int    B1  :1;
        unsigned int    B0  :1;
    };
    union un_gpr {
        struct {
            unsigned int    unusedhi:8;
            unsigned int    B7:1;
            unsigned int    B6:1;
            unsigned int    B5:1;
            unsigned int    B4_3:2;
            unsigned int    B2:1;
            unsigned int    B1:1;
            unsigned int    B0:1;
        };
        UINT16 CPLDRDREG;
    };
    union un_hmuxenbl {
        unsigned int ALL_FOUR;
        struct {
            unsigned int B15_4 : 12;
            unsigned int MUX1  : 1;
            unsigned int MUX2  : 1;
            unsigned int MUX3  : 1;
            unsigned int MUX4  : 1;
        };
    };
    #define MODNUM         (UINT8)(*(volatile  UINT16 *)0x200000)
    #define CPLD_REVLETTER (*(volatile UINT8 *)0x200003)
    #define CPLD_REVNUMBER (*(volatile UINT8 *)0x200005)
    #define P_GPR          (*(volatile un_gpr *)0x200006)//(*(volatile struct st_gpr *)0x200006)
    #define P_CPLDR02      (*(volatile  un_cpld_rd *)0x200008)
    #define P_CPLDR04      (*(volatile  un_cpld_rd *)0x20000A)
    #define P_CPLDR06      (*(volatile  un_cpld_rd *)0x20000C)
    #define P_CPLDR08      (*(volatile  un_cpld_rd *)0x20000E)
    #define P_CPLD_R08     (*(volatile  un_cpld_rd_r08 *)0x20000E)
    #define P_CPLDR0A      (*(volatile  un_cpld_rd *)0x200010)
    #define P_CPLDR0C      (*(volatile  un_cpld_rd *)0x200012)

       // FPGA definititons for AI and AO channels
    #define P_AI_CHAN_DATA_REG         (volatile UINT16 *)0x00081024
    #define P_AI_CTRL_REG              (volatile UINT16 *)0x00081026
    #define P_AO_CHAN_DATA_REG         (volatile UINT16  *)0x00081028
    #define P_AO_CTRL1_REG             (volatile AOCTRL1 *)0x0008102A
    #define P_AO_CTRL2_REG             (*(volatile FpgaCtlReg *)0x200014)
    #define P_AO_CTRL2_REG_U           (*(volatile UINT16 *)0x0008102C)
    #define P_AO_CTRL3_REG             (volatile AOCTRL3*)0x0008102E
    #define P_APP_BRD_CTRL_REGS        (volatile APPBRDCTRLREG*)0x00081030
    
     #define P_AO_CTRL2_REG_FPGA             (*(volatile FpgaCtlReg *)0x0008102C)

    //#define INHIN_FB_n P_AO_CTRL2_REG_FPGA.B7
    #define INHIN_FB_n P_AO_CTRL2_REG.B0 //P_AO_CTRL2_REG_U & 0x0080
    #define INHST1_FB1 P_AO_CTRL2_REG.B1
    #define INHST1_FB2 P_AO_CTRL2_REG.B2
    #define INHST1_FB  P_AO_CTRL2_REG.B3
    #define DISA_FB_n  P_AO_CTRL2_REG.B4
    #define DISB_FB1_n P_AO_CTRL2_REG.B5
    #define DISB_FB2_n P_AO_CTRL2_REG.B6
    #define TST_FB     P_AO_CTRL2_REG.B7
    #define TST_n      P_CPLDR02.B4


    #define CLR_RIP_n   P_GPR.B0
    #define RIP_n       P_CPLDR0C.B5
    #define SET_DIP     P_GPR.B1
    #define DIP_n       P_GPR.B1
    #define EEPROM_WP_n P_GPR.B2
    #define LED_PINS    P_GPR.B4_3


    #define AO_TST_SW_RB   P_CPLDR02.B7

    #ifdef IOMTYPE_SP
        #define DO_PWR_ENABLE   P_CPLDR02.B6
        #define DO_OUT_ENABLE   P_CPLDR02.B5
    #else
        #define AO_SERVO_OVRD  P_CPLDR02.B6
        #define AO_SERVO_EN    P_CPLDR02.B5
    #endif


    #define CPLD02SPARE    P_CPLDR02.B4
    #define INH_SWB        P_CPLDR02.B3
    #define INH_SWA        P_CPLDR02.B2
    #define DIS_SWB_n      P_CPLDR02.B1
    #define DIS_SWA_n      P_CPLDR02.B0

    //#define RESERVED     P_CPLDR04.B7

    #define REDUNT_n     P_CPLDR04.B6

    #define BOTTOM       P_CPLDR04.B5
    #define JABLOCK_n    P_CPLDR04.B4
    #define GHOXXX       P_CPLDR04.B3
    #define BUPREQ_IN    P_CPLDR04.B2
    #define BUPREQ_FB    P_CPLDR04.B1
    #define STBYMAN      P_CPLDR04.B0

//  #define RESERVED    P_CPLDR06.B7
    #define CALIBRATE   P_CPLDR06.B6
    #define DIAGFAIL_n  P_CPLDR06.B5
    #define SPI_FL_WP   P_CPLDR06.B4
    #define ADC_CLK     P_CPLDR06.B3
    #define OVERVT_n    P_CPLDR06.B2
    #define FACTCAL       P_CPLDR06.B1

    #define ANALOG_RDBK    P_CPLDR06.B0 //TBD calib here?

    
    #define BOOTCTRL1   P_CPLDR08.B7
    #define BOOTCTRL0   P_CPLDR08.B6
    #define APP_TYPE2   P_CPLDR08.B5
    #define APP_TYPE1   P_CPLDR08.B4
    #define APP_TYPE0   P_CPLDR08.B3
    #define IOTA_TYPE_2 P_CPLDR08.B2
    #define IOTA_TYPE_1 P_CPLDR08.B1
    #define IOTA_TYPE_0 P_CPLDR08.B0

    #define CPLD_APP_TYPE   P_CPLD_R08.B3_4
    #define CPLD_IOTA_TYPE  P_CPLD_R08.B0_2

    #define DO_TST_SW_RB   P_CPLDR0A.B7
    #define DO_TST_SW      P_CPLDR0A.B6
    #define DO_DIS_SW_RB   P_CPLDR0A.B5
    #define DO_DIS_SW      P_CPLDR0A.B4
    #define DO_INH_SW2_RB  P_CPLDR0A.B3
    #define DO_INH_SW1_RB  P_CPLDR0A.B2
    #define DO_INH_SW2     P_CPLDR0A.B1
    #define DO_INH_SW1     P_CPLDR0A.B0

    #define RST_APP_n      P_CPLDR0C.B2
    #define RST_DSC_n      P_CPLDR0C.B1
    #define RST_FPGA_n     P_CPLDR0C.B0

    // FPGA UART definitions
    struct st_fpga_uart{
        union {
            unsigned char RCVBUF_REGISTER;
            unsigned char XMTHOLD_REGISTER;
        };
        union {
            unsigned char INTR_ENBL_REGISTER;
            struct {
                unsigned char INTR_ENBL_B7_5        : 4;
                unsigned char MODEMSTS_INTR_ENBL    : 1;
                unsigned char RCVLINESTS_INTR_ENBL  : 1;
                unsigned char XMTREGEMPTY_INTR_ENBL : 1;
                unsigned char RCVDATAAVBL_INTR_ENBL : 1;
            };
        };
        union {
            unsigned char INTR_IDNT_REGISTER;
            struct {
                unsigned char READ_FIFO_ENBL : 2;
                unsigned char INTR_IDNT_B5_4 : 2;
                unsigned char INTR_ID        : 3;
                unsigned char INTR_PENDING   : 1;
            };
            struct {
                unsigned char INTRID_HINIBBLE   : 4;
                unsigned char HART_INTR_ID      : 4;
            };
            unsigned char FIFO_CTRL_REGISTER;
            struct {
                unsigned char RCV_FIFO_TRIG_LEVEL : 2;
                unsigned char FIFO_CTRL_B5_4      : 2;
                unsigned char DMA_MODE_SELECT     : 1;
                unsigned char XMT_FIFO_CLEAR      : 1;
                unsigned char RCV_FIFO_CLEAR      : 1;
                unsigned char FIFO_ENBL           : 1;
            };
        };
        union {
            unsigned char LINE_CTRL_REGISTER;
            struct {
                unsigned char DVSR_LATCH_ACCESS   : 1;
                unsigned char SET_BREAK           : 1;
                unsigned char STICK_PARITY_SELECT : 1;
                unsigned char EVEN_PARITY_SELECT  : 1;
                unsigned char PARITY_ENBL         : 1;
                unsigned char STOP_BITS_SELECT    : 1;
                unsigned char BITS_PER_CHAR       : 2;
            };
        };
        union {
            unsigned char MODEM_CTRL_REGISTER;
            struct {
                unsigned char MODEM_CTRL_B7_5 : 3;
                unsigned char LOOP_BACK_ENBL  : 1;
                unsigned char USER_OUTPUT2    : 1;
                unsigned char USER_OUTPUT1    : 1;
                unsigned char REQUEST_TO_SEND : 1;
                unsigned char DATA_TERM_READY : 1;
            };
        };
        union {
            unsigned char LINE_STS_REGISTER;
            struct {
                unsigned char RCV_FIFO_ERROR : 1;
                unsigned char XMT_COMPLETE   : 1;
                unsigned char XMTREG_EMPTY   : 1;
                unsigned char BREAK_INTR     : 1;
                unsigned char FRAMING_ERROR  : 1;
                unsigned char PARITY_ERROR   : 1;
                unsigned char OVERRUN_ERROR  : 1;
                unsigned char DATA_READY     : 1;
            };
        };
        union {
            unsigned char MODEM_STS_REGISTER;
            struct {
                unsigned char CARRIER_DETECT       : 1;
                unsigned char RING_INDICATER       : 1;
                unsigned char DATASET_READ         : 1;
                unsigned char CLEAR_TO_SEND        : 1;
                unsigned char DELTA_CARRIER_DETECT : 1;
                unsigned char TRAIL_EDGE_INDICATOR : 1;
                unsigned char DELTA_DATASET_READ   : 1;
                unsigned char DELTA_CLEAR_TO_SEND  : 1;
            };
        };
        unsigned char SCRATCH_PAD_REGISTER;
        unsigned char RESET;
    };
    struct st_fpga_uartlite{
        UINT8   RXD;
        UINT8   TXD;
        union {
            UINT8   SR;
            struct {
                UINT8 PARITY_ERROR  : 1;
                UINT8 FRAME_ERROR   : 1;
                UINT8 OVERUN_ERROR  : 1;
                UINT8 INTR_ENABLED  : 1;
                UINT8 TX_FIFO_FULL  : 1;
                UINT8 TX_FIFO_EMPTY : 1;
                UINT8 RX_FIFO_FULL  : 1;
                UINT8 RX_FIFO_DATA  : 1;
            };
        };
        union {
            UINT8   CR;
            struct {
                UINT8               : 3;
                UINT8 ENABLE_INTR   : 1;
                UINT8               : 2;
                UINT8 RESET_RX_FIFO : 1;
                UINT8 RESET_TX_FIFO : 1;
            };
        };
    };
    struct st_fpga_brg{
        UINT8 LOBYTE;
        UINT8 HIBYTE;
    };

#ifdef IOMTYPE_LLMUX
    const UINT8  NO_OF_FTA = 4;
    const UINT32 FTA_UART[NO_OF_FTA] = { 0x400000,
                                         0x400010,
                                         0x400020,
                                         0x400030
    };
    #define FTA_UART(n)            (*(volatile struct st_fpga_uart *)FTA_UART[n])
    #define FTA_BAUDRATE_REGISTER  (*(volatile struct st_fpga_brg *)0x400050)

    const UINT8 FTA_UART_8BITS_PER_CHAR      = 0x03;
    const UINT8 FTA_UART_LINE_STS_ERROR_BITS = 0x1E;
#else
    const UINT8  HARTMODEM_COUNT  = 4;
    const UINT32 HART_UART[HARTMODEM_COUNT] = { 0x400000,
                                                0x400010,
                                                0x400020,
                                                0x400030
    };
    const UINT8 HART_INTR_PENDING_MASK  = 0x01;
    const UINT8 HART_XMTINTR_ENABLE     = 0x02; // Enable XMT hold register empty interrupt
    const UINT8 HART_RCVINTR_ENABLE     = 0x09; // Enables RcvData and ModemStatus interrupts
    const UINT8 HART_RCVERROR_PRESENT   = 0x1E; // Break, framing, parity or overrun error.
    #define HART_UART(n)            (*(volatile struct st_fpga_uart *)HART_UART[n])
    #define HART_BAUDRATE_REGISTER  (*(volatile struct st_fpga_brg *)0x400050)
#endif

    #define UART_LITE   (*(volatile struct st_fpga_uartlite *)0x400040)
    // FPGA Interrupt Status Register definitions
    union un_fpga_bytebits {
        struct {
            UINT8   B7:1;
            UINT8   B6:1;
            UINT8   B5:1;
            UINT8   B4:1;
            UINT8   B3:1;
            UINT8   B2:1;
            UINT8   B1:1;
            UINT8   B0:1;
        };
        struct {
            UINT8 HiNibble   : 4;
            UINT8 INTFL_HART : 4;
        };
        UINT8 FPGABYTEREG;
    };
    #define FPGA_ISR    (*(volatile union un_fpga_bytebits *)0x400060)
    #define FPGA_INTFL_WDTO  0//FPGA_ISR.B6
    #define FPGA_INTFL_SPI   FPGA_ISR.B5
    #define FPGA_INTFL_UART4 FPGA_ISR.B4
    #define FPGA_INTFL_UART3 FPGA_ISR.B3
    #define FPGA_INTFL_UART2 FPGA_ISR.B2
    #define FPGA_INTFL_UART1 FPGA_ISR.B1
    #define FPGA_INTFL_UART0 FPGA_ISR.B0

    //Interrupt source mask
    const UINT8 FPGA_INTFL_WDTO_MASK    = 0x40;
    const UINT8 FPGA_INTFL_SPI_MASK     = 0x20;
    const UINT8 FPGA_INTFL_UART4_MASK   = 0x10;
    const UINT8 FPGA_INTFL_UART3_MASK   = 0x08;
    const UINT8 FPGA_INTFL_UART2_MASK   = 0x04;
    const UINT8 FPGA_INTFL_UART1_MASK   = 0x02;
    const UINT8 FPGA_INTFL_UART0_MASK   = 0x01;
    //UART Interrupt Ids
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
    const UINT8 INTR_ID_RXLINESTATUS = 0x06;
    const UINT8 INTR_ID_RXDATAAVLBLE = 0x04;
    const UINT8 INTR_ID_CHARTIMEOUT  = 0x0C;
    const UINT8 INTR_ID_TXHLDRGEMPTY = 0x02;
    const UINT8 INTR_ID_MODEMSTATUS  = 0x00;
#else
    const UINT8 INTR_ID_RXLINESTATUS = 0x03;
    const UINT8 INTR_ID_RXDATAAVLBLE = 0x02;
    const UINT8 INTR_ID_CHARTIMEOUT  = 0x06;
    const UINT8 INTR_ID_TXHLDRGEMPTY = 0x01;
    const UINT8 INTR_ID_MODEMSTATUS  = 0x00;
#endif
    //UART Lite Interrupt Ids
    const UINT8 UARTLITE_PAR_ERROR_MASK    = 0x80;
    const UINT8 UARTLITE_FRAME_ERROR_MASK  = 0x40;
    const UINT8 UARTLITE_OVERUN_ERROR_MASK = 0x20;
    const UINT8 UARTLITE_RCVERROR_MASK     = 0xE0;
    const UINT8 UARTLITE_INTR_ENABLED_MASK = 0x10;
    const UINT8 UARTLITE_TX_FIFO_FULL_MASK = 0x08;
    const UINT8 UARTLITE_TX_FIFO_EMPTY_MASK= 0x04;
    const UINT8 UARTLITE_RX_FIFO_FULL_MASK = 0x02;
    const UINT8 UARTLITE_RX_FIFO_VALID_DATA_MASK = 0x01;
    // FPGA Miscellaneous definitions
    #define FPGA_REVLETTER (*(volatile UINT8 *)0x81008)
    #define FPGA_REVNUMBER (*(volatile UINT8 *)0x81009)
    #define FPGA_REV       (*(volatile UINT16 *)0x81008)
    // FPGA Analog Input definitions
    struct st_fpga_wcr{
        unsigned char   Rsrvd:1;
        unsigned char   FILTOFF:1;
        unsigned char   UP:1;
        unsigned char   ENB:1;
        unsigned char   CSEL:4;
    };
    #define WIGLPVCR    (*(volatile struct st_fpga_wcr *)0x400080)
    // Open wire detection (OWD) feature is implemented using the
    // hardware originally meant for doing SIL wiggle tests on input.
    #define OWD_CSEL    WIGLPVCR.CSEL
    #define OWD_ENB     WIGLPVCR.ENB

    #define INPSEL      (*(volatile UINT8 *)0x4000A0)
    // FPGA Analog Output Control Register definitions
    #define OCWR        (*(volatile union un_fpga_bytebits *)0x400080)
    #define OUTSEL      (*(volatile UINT8 *)0x400090)
    #define UKEY        (*(volatile UINT8 *)0x400091)
    // FPGA SPI definitions
    
    #define ADC_SPI     (*(volatile struct st_fpga_spi *)0x4000B0)
        
    #define SPIRESET    (*(volatile UINT8 *)0x4000B1)
    // Slave select constants
    const UINT8 SS_ADCSPI   = 0xFE;
    const UINT8 SS_DACSPI   = 0xFE;

    // SPI FIFO interrupt definitions
    const UINT8 SPI_TX_FIFO_EMPTY_MASK= 0x04;
    const UINT8 SPI_RX_FIFO_EMPTY_MASK= 0x01;
    const UINT8 SPI_RX_FIFO_RESET_MASK= 0x40;

    struct st_fpga_spi{
        UINT16   WRPROTECT;
        UINT16   TXD_1;
        UINT16   TXD_2;
        UINT16   CTRL;
        UINT16   RXD;
    };
    #define EEPROM_SPI   (*(volatile struct st_fpga_spi *)0x81030)



#endif  // HEK

// DTC register definition
typedef struct tagDTC_PARM{
    union{
        unsigned char   BYTE;
        struct{
            unsigned char   SM:2;
            unsigned char   DM:2;
            unsigned char   MD_DTS:3;
            unsigned char   SZ:1;
        }BIT;
    }MRA;
    unsigned char   SAR_H;
    unsigned int    SAR_L;
    union{
        unsigned char   BYTE;
        struct{
            unsigned char   CHNE:1;
            unsigned char   DISEL:1;
            unsigned char   WK:6;
        }BIT;
    }MRB;
    unsigned char   DAR_H;
    unsigned int    DAR_L;
    unsigned int    CRA;
    unsigned int    CRB;
}DTC_PARM;

/* Location of DTC registers */
const unsigned long DTC_PARM_LOC = 0xFFFBC0;
#define P_DTCPARM  (*(volatile DTC_PARM   *)DTC_PARM_LOC)

// DTC registers
#define DTCIOL_SARH     P_DTCPARM.SAR_H
#define DTCIOL_SARL     P_DTCPARM.SAR_L
#define DTCIOL_DARH     P_DTCPARM.DAR_H
#define DTCIOL_DARL     P_DTCPARM.DAR_L
#define DTCIOL_CRA      P_DTCPARM.CRA
#define DTCIOL_CRB      P_DTCPARM.CRB
#define DTCIOL_DM       P_DTCPARM.MRA.BIT.DM
#define DTCIOL_MD_DTS   P_DTCPARM.MRA.BIT.MD_DTS
#define DTCIOL_SM       P_DTCPARM.MRA.BIT.SM
#define DTCIOL_SZ       P_DTCPARM.MRA.BIT.SZ
#define DTCIOL_CHNE     P_DTCPARM.MRB.BIT.CHNE
#define DTCIOL_DISEL    P_DTCPARM.MRB.BIT.DISEL

#ifdef IOLPORT1

#define IOL_SMR         P_SCI1.SMR.BYTE
#define IOL_BRR         P_SCI1.BRR
#define IOL_SCR         P_SCI1.SCR.BYTE
#define IOL_TDR         P_SCI1.TDR
#define IOL_SSR         P_SCI1.SSR.BYTE
#define IOL_RDR         P_SCI1.RDR
#define IOL_SCMR        P_SCI1.SCMR.BYTE
#define IOL_CA          P_SCI1.SMR.BIT.CA
#define IOL_CHR         P_SCI1.SMR.BIT.CHR
#define IOL_PE          P_SCI1.SMR.BIT.PE
#define IOL_OE          P_SCI1.SMR.BIT.OE
#define IOL_STOP        P_SCI1.SMR.BIT.STOP
#define IOL_MP          P_SCI1.SMR.BIT.MP
#define IOL_CKS         P_SCI1.SMR.BIT.CKS
#define IOL_TIE         P_SCI1.SCR.BIT.TIE
#define IOL_RIE         P_SCI1.SCR.BIT.RIE
#define IOL_TE          P_SCI1.SCR.BIT.TE
#define IOL_RE          P_SCI1.SCR.BIT.RE
#define IOL_MPIE        P_SCI1.SCR.BIT.MPIE
#define IOL_TEIE        P_SCI1.SCR.BIT.TEIE
#define IOL_CKE         P_SCI1.SCR.BIT.CKE
#define IOL_TDRE        P_SCI1.SSR.BIT.TDRE
#define IOL_RDRF        P_SCI1.SSR.BIT.RDRF
#define IOL_ORER        P_SCI1.SSR.BIT.ORER
#define IOL_FER         P_SCI1.SSR.BIT.FER
#define IOL_PER         P_SCI1.SSR.BIT.PER
#define IOL_TEND        P_SCI1.SSR.BIT.TEND
#define IOL_MPB         P_SCI1.SSR.BIT.MPB
#define IOL_MPBT        P_SCI1.SSR.BIT.MPBT
#define IOL_SDIR        P_SCI1.SCMR.BIT.SDIR
#define IOL_SINV        P_SCI1.SCMR.BIT.SINV
#define IOL_SMIF        P_SCI1.SCMR.BIT.SMIF
#define MSTPCR_I0L      P_MSTPCR.BIT.SCI1

#define IOL_VECTOR_ERI  84
#define IOL_VECTOR_RXI  85
#define IOL_VECTOR_TXI  86
#define IOL_VECTOR_TEI  87

#endif

#ifdef IOLPORT0

#define IOL_SMR         P_SCI0.SMR.BYTE
#define IOL_BRR         P_SCI0.BRR
#define IOL_SCR         P_SCI0.SCR.BYTE
#define IOL_TDR         P_SCI0.TDR
#define IOL_SSR         P_SCI0.SSR.BYTE
#define IOL_RDR         P_SCI0.RDR
#define IOL_SCMR        P_SCI0.SCMR.BYTE
#define IOL_CA          P_SCI0.SMR.BIT.CA
#define IOL_CHR         P_SCI0.SMR.BIT.CHR
#define IOL_PE          P_SCI0.SMR.BIT.PE
#define IOL_OE          P_SCI0.SMR.BIT.OE
#define IOL_STOP        P_SCI0.SMR.BIT.STOP
#define IOL_MP          P_SCI0.SMR.BIT.MP
#define IOL_CKS         P_SCI0.SMR.BIT.CKS
#define IOL_TIE         P_SCI0.SCR.BIT.TIE
#define IOL_RIE         P_SCI0.SCR.BIT.RIE
#define IOL_TE          P_SCI0.SCR.BIT.TE
#define IOL_RE          P_SCI0.SCR.BIT.RE
#define IOL_MPIE        P_SCI0.SCR.BIT.MPIE
#define IOL_TEIE        P_SCI0.SCR.BIT.TEIE
#define IOL_CKE         P_SCI0.SCR.BIT.CKE
#define IOL_TDRE        P_SCI0.SSR.BIT.TDRE
#define IOL_RDRF        P_SCI0.SSR.BIT.RDRF
#define IOL_ORER        P_SCI0.SSR.BIT.ORER
#define IOL_FER         P_SCI0.SSR.BIT.FER
#define IOL_PER         P_SCI0.SSR.BIT.PER
#define IOL_TEND        P_SCI0.SSR.BIT.TEND
#define IOL_MPB         P_SCI0.SSR.BIT.MPB
#define IOL_MPBT        P_SCI0.SSR.BIT.MPBT
#define IOL_SDIR        P_SCI0.SCMR.BIT.SDIR
#define IOL_SINV        P_SCI0.SCMR.BIT.SINV
#define IOL_SMIF        P_SCI0.SCMR.BIT.SMIF
#define MSTPCR_I0L      P_MSTPCR.BIT.SCI0

#define IOL_VECTOR_ERI  80
#define IOL_VECTOR_RXI  81
#define IOL_VECTOR_TXI  82
#define IOL_VECTOR_TEI  83

#endif

#define GHO_IRQ0E       P_INTC.IER.BIT.IRQ0E
#define GHO_IRQ0F       P_INTC.ISR.BIT.IRQ0F
#define GHO_IRQ0SC      P_INTC.ISCR.BIT.IRQ0SC
#define IOL_ALERT_RCVD  IOL_MPB
#define IOL_ALERT_XMIT  IOL_MPBT
const unsigned char GHO_DISABLED = 0;
const unsigned char GHO_ENABLED = 1;
const unsigned char GHO_RESET = 0;
const unsigned char GHO_SET = 1;
const unsigned char GHO_NOTINGAP = 0;
const unsigned char GHO_INGAP = 1;
const unsigned char IRQ_SC_LOW = 0;
const unsigned char IRQ_SC_FALLING = 1;
const unsigned char IRQ_SC_RISING = 2;
const unsigned char IRQ_SC_EDGES = 3;
const unsigned char IOL_RDRF_RESET = 0;
const unsigned char IOL_RDRF_SET = 1;
const unsigned char IOL_XMTR_ENABLED = 1;
const unsigned char IOL_XMTR_DISABLED = 0;
const unsigned char IOL_TDRE_RESET = 0;
const unsigned char IOL_TDRE_SET = 1;
const unsigned char IOL_ALERT_RESET = 0;
const unsigned char IOL_ALERT_SET = 1;
const unsigned char IOLDRV_ON = 0;
const unsigned char IOLDRV_OFF = 1;
const unsigned char JABLOCK_ASSERTED = 0;
const unsigned char JABLOCK_NEGATED = 1;

#define IRQ1_ENABLE     P_INTC.IER.BIT.IRQ1E
#define IRQ1_STATUS     P_INTC.ISR.BIT.IRQ1F
#define IRQ1_SENSECTL   P_INTC.ISCR.BIT.IRQ1SC


#define IRQ3_ENABLE     P_INTC.IER.BIT.IRQ3E
#define IRQ3_STATUS     P_INTC.ISR.BIT.IRQ3F
#define IRQ3_SENSECTL   P_INTC.ISCR.BIT.IRQ3SC

#define IRQ4_ENABLE     P_INTC.IER.BIT.IRQ4E
#define IRQ4_STATUS     P_INTC.ISR.BIT.IRQ4F
#define IRQ4_SENSECTL   P_INTC.ISCR.BIT.IRQ4SC

// IOTA definitions
const UINT8 ACTIVE = TRUE;
const UINT8 NOTACTIVE = FALSE;
const UINT8 UPPER = FALSE;
const UINT8 LOWER = TRUE;
const UINT8 RCVSEL_CHANNELA = FALSE;
const UINT8 RCVSEL_CHANNELB = TRUE;

//IOTA Types
#define IOTA_TYPE_NONE     0x7
#define IOTA_TYPE_SVP      0x1
#define IOTA_TYPE_SP       0x4

//Application Board Types
#define APP_BOARD_TYPE_NONE     0x3
#define APP_BOARD_TYPE_SVP      0x0
#define APP_BOARD_TYPE_SP       0x1

UINT16 ToggleBit(UINT16 a_uidata, UINT16 a_uiposition);
BOOL GetBitValue(UINT16 a_uiword,UINT16 a_uiposition);
VOID ClearBit(UINT16 *a_uiword,UINT16 a_uiposition);
VOID SetBit(UINT16 *a_uiword,UINT16 a_uiposition);

typedef enum tagChanProcEvent
{
    EVENT_NULL = 0,
    EVENT_NONE,
    EVENT_CHANPROCCYCLE,
    EVENT_DIAG_MUX_TOUT,
    EVENT_CHAN_MUX_TOUT,
    EVENT_DIAGFPGA_RESP_OK,
    EVENT_CHANFPGA_RESP_OK
}enmChanProcEvent;

#endif
