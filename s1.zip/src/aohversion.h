/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohversion.h                                                *
*    Description : HART Analog Output firmware version declaration.            *
*******************************************************************************/
#ifndef AOHVERSION_H
#define AOHVERSION_H
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#ifdef DEVELOPER_BUILD_OVERRIDE
    const UINT8 VERSION_NUMBER  = VERSION;
    const UINT8 REVISION_NUMBER = REVISION;
    const UINT8 BUILD_NUMBER    = BUILD;
	// donot remove below comment lines, if removed version number will be error
	//const UINT8 HART_VER_NUMBER = VERSION;
	//const UINT8 HART_REV_NUMBER = REVISION;
	//const UINT8 HART_BLD_NUMBER = BUILD;
#else
    #if defined(IOPTYPE_AO16)
        #if defined(HART_SUPPORT)
			/**
			 * FW VER 3.0.0 - Redesign AO16 Hart PM IOP (with SRAM replacement)
			 *		  3.0.4 - 
			 *        3.0.5 - SIT fixes for PARs 1-DUA7GMN, 1-DUP4FSG
			 *        3.1.0 - field upgrade feature
			 *		  3.1.1 - SIT PAR (1-DVN1QD5 1-DX7HNEJ 1-DVN1QBM) Fixes
			 *        3.2.0 - SIT PAR (1-E0EXNH5) Fix
			 *		  3.3.0 - SIT Reopened PAR (1-DVN1QD5) fix
			 *		  3.4.0 - SIT PAR (1-DYD1PEV) fix
			 *        3.5.0 - SIT PAR (1-E2KA8ZT 1-E2KVSJR) Fixes
			 *        3.6.0 - SIT PAR (reopned PARs(1-E2KA8ZT 1-E2KVSJR), 1-E35JRCL & OP drop time during double fault) fixes
			 *		  3.7.0 - SIT PAR (1-E35JRDA, 1-E45JKMH, 1-E45P053 & OP drop time during Swapover without OPFail SFail)
			 *		  3.8.0 - SIT Issue fix - OP drop time more (>20ms) during SEC comes from CfgMis to SFail.
			 *        3.9.0 - SIT PAR (1-E61KJNG - Module FO continuously if both FTA removal) Fix.
			 *        4.0.0 - Cust PAR (BW-46473 null SF 02627886 DEER 02656190) common PAR (AO16 does not warn/alarm on wrong FTA connected)
			 *		  4.1.0 - Fix for dual C300pm/ehpm failure due to param HSLOT0TS access in HART variables tab in experion. (modified eventhough not reproduciable in AO16H)
			 *        4.2.0 - Fix for param error during module restore with C300PM
			 *		  4.3.0 - Fix for NR during swapover from sec to pri (in hybrid comb) with OP Channel SFail existing.
			 *        4.4.0 - Fix for SEC(NEW) Syncfail with PRI(NEW) after reinsertion, with a single CHL cfgd & with C300v2.
			 *        4.5.0 - fix is not to reinit the H7SLDVC variables during postdump
			 *        4.6.0 - Fix for HSLOTVAL = NAN for centain HART devices through CMD9 (Ex: 2.	Samson Trovis 3763 Positioner)
			 *			    - Fix for HSLOTVAL = WRONG VAL for HART5 through CMD33
			 *        4.7.0 - EQUATE Customer issue [RTPN-1064] - AO16 Value drops for 2sec when EHPM is getting loaded even if FAULTOPT is set as HOLD
             *     04.08.00 - SIT PAR (RTPN-1797 - AO16 primary is going to HFAIL_25 during C300PM Ram Retention Restore (RRR) test).
             *     04.09.00 - UTT issues - 1. Wrong FTA is not detecting, if the FTA inserted after the module powered up.
             *                             2. Storing the dump data into the battery backed SRAM.
             *     04.10.00 - SIT PAR (RTPN-1845 - Multiple Channels will go to BADPV after IOP Swapover)
             *              - SIT PAR (ETNC-16382 - OP is going to (-6.9) after two swap primary following an IOP reload,
             *                                      if the channel is not connected to any upstream block) - root cause is same as RTPN-1845
             *     04.11.00 - SIT PAR (RTPN-1852 - BADPV from primary, when backup FTA removed improperly and reinserted again)
             *              - SIT PAR (ETNC-16568 - FailOpt not retaining the value after channel deletion and loading)
             */
            const UINT8 HART_VER_NUMBER = 4;
            const UINT8 HART_REV_NUMBER = 11;
            const UINT8 HART_BLD_NUMBER = 0;
		#else
			/**
                REV 2.0.0 - Intial release of redesign AO16 IOP
                REV 2.1.0 - Customer(-MiRO) Issue(-CL Fail) Fix + Field upgrade feature in boot code
                REV 2.2.0 - fixes for the following PARs
                            PAR# 1-ELMDMA4 - OP drop time > 20ms, during redundant modules failover 
                            PAR# 1-EM8LALF - Redundancy status of secondary IOP in FOComplete when SoftFail exists
                            PAR# 1-EL2VVIJ - Sync failure in IDL/BKP in HPM FULL Control
                                             obs 1 fix: Unimplemented param 'HGCFGCHG' accessing
                                             obs 2 fix: Returning wrong error code during OP write (from CM) in IDLE/BKP in HPM FULL Control
                                             obs 3 fix: Sync failure in OK/BKP, if CM tries to write OP in MAN mode config.    
                REV 2.3.0 - fix for the issue, Module going into NR during stable run
                REV 2.4.0 - fix for the SYNC fail in OK/BKP during OP write through CM_REG with invalid access level in MAN mode
                REV 2.5.0 - PAR# 1-DCHI0F0 - New HLAI, AO16 module went into ACTIVE state (OK / BACKUP) after new IOP configuration
							Major changes related to FRAM replaced with battery backup SRAM
				REV 2.6.2 - PAR# 1-F1UPS9D - OP Value 0 instead of -6.9 during replacement of legacy with redesign module
				REV 2.6.3 - MiRO Fault Insertion modifications
				REV 2.7.0 - EQUATE Customer issue [RTPN-1064] - AO16 Value drops for 2sec when EHPM is getting loaded even if FAULTOPT is set as HOLD
             REV 02.08.00 - SIT PAR (RTPN-1797 - AO16 primary is going to HFAIL_25 during C300PM Ram Retention Restore (RRR) test).
             REV 02.09.00 - UTT issues - 1. Wrong FTA is not detecting, if the FTA inserted after the module powered up.
                                         2. Storing the dump data into the battery backed SRAM.
             REV 02.10.00 - SIT PAR (RTPN-1845 - Multiple Channels will go to BADPV after IOP Swapover)
                          - SIT PAR (ETNC-16382 - OP is going to (-6.9) after two swap primary following an IOP reload,
                                                  if the channel is not connected to any upstream block) - root cause is same as RTPN-1845
             REV 02.11.00 - SIT PAR (RTPN-1852 - BADPV from primary, when backup FTA removed improperly and reinserted again)
                          - SIT PAR (ETNC-16568 - FailOpt not retaining the value after channel deletion and loading)
            */
            const UINT8 VERSION_NUMBER  = 2;
            const UINT8 REVISION_NUMBER = 11;
            const UINT8 BUILD_NUMBER    = 0;
        #endif    
    #endif
#endif

#endif
