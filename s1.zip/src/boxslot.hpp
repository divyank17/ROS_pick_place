/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : boxslot.hpp                                                 *
*    Description : Class clsBoxSlot declaration.                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "datatype.h"
#include "commonelectronics.h"
#include "global.h"
#include "ecl.hpp"
#include "iomslot.hpp"
#include "utils.h"
#include "tracelog.hpp"
#include "iol.hpp"

#ifndef __BOXSLOT_HPP__
#define __BOXSLOT_HPP__
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagIOLDevType {
    IOLDEVTYPE_SLAVE   = 0,
    IOLDEVTYPE_MASTER1 = 1,
    IOLDEVTYPE_MASTER2 = 2,
    IOLDEVTYPE_MASTER3 = 3
} IOLDEVTYPE;

typedef union tagRevCode {
    UINT8 ucByte;
    struct {
        UINT8 ucVersion  : 4;
        UINT8 ucRevision : 4;
    };
} REVCODE;

typedef struct tagHwInfo {
    UINT32 SerialNumber;
    UINT16 VendorID;
    UINT16 ProductType;
    UINT16 ProductCode;
    UINT8  HwRevLetter;
    UINT8  HwRevNumber;
    UINT8  Pld1RevLetter;
    UINT8  Pld1RevNumber;
    UINT8  Pld2RevLetter;
    UINT8  Pld2RevNumber;
} HWINFO;

typedef union tagMODSTAT1 {
    struct {
        UINT8 BuSyncd:1;
        UINT8 Unused :4;
        UINT8 Factory:1;
        UINT8 Status :2;
    };
    UINT8 BYTE;
}MODSTAT1;

typedef union tagMODSTAT2 {
    struct {
        UINT8 DbNotDeflt:1;
        UINT8 BuReqIn   :1;
        UINT8 StndbyMan :1;
        UINT8 FtaPres   :1;
        UINT8 HF        :1;
        UINT8 SF        :1;
        UINT8 CommErr   :1;
        UINT8 IotaPos   :1;
    };
    UINT8 BYTE;
}MODSTAT2;

typedef union tagMODSTAT3 {
    struct {
        UINT8 Unused  :6;
        UINT8 PairInSF:1;
        UINT8 OutCtl  :1;
    };
    UINT8 BYTE;
}MODSTAT3;

typedef struct tagCOMMSTAT {
    UINT8 Unused:3;
    UINT8 LEA   :1;
    UINT8 LEB   :1;
    UINT8 LSA   :1;
    UINT8 LSB   :1;
    UINT8 PRC   :1;
}COMMSTAT;

typedef struct tagTRACELOGDATA {
    UINT32 TracelogTime;
    UINT8  LatestIndex;
} TRACELOGDATA;

typedef struct tagREDDATA {
    UINT8    Unused:3;
    UINT8    WiggleSF:1;
    UINT8    WiggleStat:1;
    UINT8    SFFOEnable:1;
    UINT8    RedConfig:1;
    UINT8    BURequest:1;
    UINT8    RedState;
}REDDATA;

#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)|| defined(IOMTYPE_UIO))
typedef struct tagBrdpStsTable {
    UINT8  Handle;
    UINT8  SlotNum;
    UINT8  MsgStatus;
    UINT8  Timeout;
} BRDPSTSTABLE;

typedef struct tagHndlStsTable {
    UINT8  Handle;
    UINT8  Timeout;
} HNDLSTSTABLE;
#endif
#ifdef IOMTYPE_LLMUX
typedef enum tagUartLpBkSts{
    OK      = 0,
    NO_RESP = 1,
    BAD_CKSM= 2,
    WRONG_ID= 4
}UARTLPBKSTS;
#endif
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8 MODSTATUS_ALIVE      = 0;
const UINT8 MODSTATUS_IDLE       = 1;
const UINT8 MODSTATUS_RUN        = 2;
const UINT8 MODSTATUS_FAIL       = 3; 

const UINT8 MODSTATUS_IDLE_LRSBIT = 0x01;
const UINT8 MODSTATUS_RUN_LRSBIT  = 0x02;

const UINT8 MODSTATUS_NO_TRANS   = 0;
const UINT8 MODSTATUS_IDLE_IDLE  = 1;
const UINT8 MODSTATUS_IDLE_RUN   = 2;
const UINT8 MODSTATUS_RUN_IDLE   = 3;
const UINT8 MODSTATUS_RUN_RUN    = 4;

const UINT8 BUREQ_ASSERTED  = 0;
const UINT8 BUREQ_NEGATED   = 1;
const UINT8 BURFB_ASSERTED  = 1;
const UINT8 BURFB_NEGATED   = 0;
const UINT8 BURIN_ASSERTED  = 1;
const UINT8 BURIN_NEGATED   = 0;

const UINT8 PAIR_IN_SF      = 1;
const UINT8 PAIR_NO_SF      = 0;

const UINT8 OUTCTL_MINE     = 1;
const UINT8 OUTCTL_PARTNER  = 0;
const UINT8 INHIN_ASSERTED  = 0;
#if defined(IOPTYPE_DO) && defined(DIGTYPE_DO32)
const UINT8 INHIN_NEGATED   = 0;
#else
const UINT8 INHIN_NEGATED   = 1;
#endif

const UINT8 RDBIT_SET = 0x80;
const UINT8 RDBIT_CLR = 0x00;

const UINT8 REDDATA_SIZE = 2;
const UINT8 REDDATA_BITS = 0x1F;

const UINT8 REDDATA_BURQST = 1;
const UINT8 REDDATA_REDCFG = 2;
const UINT8 REDDATA_SFFOEN = 4;
const UINT8 REDDATA_WIGGLE = 8;
const UINT8 REDDATA_WIGLSF = 16;

const UINT8 REDDATA_BURQST_BITNUM = 1;
const UINT8 REDDATA_REDCFG_BITNUM = 2;
const UINT8 REDDATA_SFFOEN_BITNUM = 3;
const UINT8 REDDATA_WIGGLE_BITNUM = 4;
const UINT8 REDDATA_WIGLSF_BITNUM = 5;
const UINT8 REDDATA_RSRVD6_BITNUM = 6;
const UINT8 REDDATA_RSRVD7_BITNUM = 7;
const UINT8 REDDATA_RSRVD8_BITNUM = 8;

const UINT8 REDSTATE_NULL                = 0;
const UINT8 REDSTATE_NOT_SYNCD           = 1;
const UINT8 REDSTATE_DUMP_FAILED         = 2;
const UINT8 REDSTATE_FREEZE_NOT_ACCEPTED = 3;
const UINT8 REDSTATE_SYNC_FAILED         = 4;
const UINT8 REDSTATE_SPARE05             = 5;
const UINT8 REDSTATE_IOL_TIMEOUT         = 0x10;
const UINT8 REDSTATE_SYNCD               = 0x80;
const UINT8 REDSTATE_DUMP_COMPLETE       = 0x81;
const UINT8 REDSTATE_FREEZE_PERMITTED    = 0x82;
const UINT8 REDSTATE_FREEZE_ACCEPTED     = 0x83;
const UINT8 REDSTATE_FO_IN_PROG          = 0x84;
const UINT8 REDSTATE_FO_COMPLETE         = 0x85;
const UINT8 REDSTATE_SWAP_IN_PROG        = 0x86;
const UINT8 REDSTATE_SWAP_COMPLETE       = 0x87;
const UINT8 REDSTATE_FROZEN              = 0xA0;
const UINT8 REDSTATE_DUMP_START          = 0xA1;
const UINT8 REDSTATE_MAX                 = 0xCE;

const UINT8 SYNCVER_SIZE        =   4;
#if !defined(IOPTYPE_SCIOM)
// for redesign PMIO redundant Sync Versions

#if defined(HART_SUPPORT)
const UINT8 AI_SYNC_VERSION		=	2;
const UINT8 AO_SYNC_VERSION     =   2;
#else
const UINT8 AI_SYNC_VERSION		=	1;
const UINT8 AO_SYNC_VERSION     =   1;
#endif
const UINT8 DI_SYNC_VERSION     =   1;
const UINT8 DO_SYNC_VERSION     =   2;
#else
const UINT8 AI_SYNC_VERSION     =   2;
const UINT8 AO_SYNC_VERSION     =   2;
const UINT8 DI_SYNC_VERSION     =   2;
const UINT8 DO_SYNC_VERSION     =   1;
#endif

const UINT8 DISOE_SYNC_VERSION  =   1;
const UINT8 LL_SYNC_VERSION     =   1;
#if defined(IOMTYPE_SVP)
const UINT8 SVP_SYNC_VERSION    =   1;
#endif
#if defined(IOMTYPE_SP)
const UINT8 SP_SYNC_VERSION     =   1;
#endif
const UINT8 PI_SYNC_VERSION     =   1;
const UINT8 UIO_SYNC_VERSION    =   1;

const UINT8 DB_VALID    = 0;
const UINT8 DB_INVALID  = 1;

const UINT8 IOPDESC_SIZE    = 8;
const UINT8 SFBYTES_SIZE    = 32;
const UINT8 SLOTINFAIL_SIZE = 16;
const UINT8 TSTFUNCT_SIZE   = 4;

const UINT8 BOXSLOT_SPARESIZE = 16;

const UINT8 SLOTINFAIL_MASKINIT = 0x80;

#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH) || defined(IOMTYPE_DO) || defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP) || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
const UINT8  COMTOGBIT = 0x01;
const UINT8  CTLTOGBIT = 0x02;
#if (defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP))
    //TOG Timeout for SP and SVP module is 1 sec.
    // After SE inputs and after analyzing scenarios: for TC TOGTIMEOUT should be 1 sec
    const UINT16 TOGTIMEOUT  = 100;
#else
// This constant was changed from 4 secs to 10 secs for the following PAR fix. The 
// actuak fix should have been in supervsior. However were dropped as it would 
// affect C300 performance.
// 1-2LZHA1- On C300 switchover control sheds and Series C output IOM's shed to FAULTOPT.
const UINT16 TOGTIMEOUT  = 1000;
#endif
#endif

#if LOWCOST 
const UINT16 DEBOUNCEINTERVAL = 5000;  // Read IOTA every 5 msec
const UINT16 DEBOUNCELOOP     = 20;    // 20 times i.e. 100 msec
#endif

#if !defined(IOPTYPE_SCIOM)
// for redesign PMIO, MODNUM BITS are different (7 - PARITY; 6:4 - FILE; 3:0 - SLOT)
const UINT8  MODNUMBITS = 0x7F;
#else
const UINT8  MODNUMBITS = 0x3F;
#endif

const UINT8  RELAYBIT = 0x40;   // temporary use for Pass 1 relay IOTAs
const UINT8  IOLIDBIT = 0x80;

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_AI) || defined(IOMTYPE_AO)) || (defined(IOPTYPE_DO) && defined(DIGTYPE_DO16))
const UINT8 MAXSLOTS = 16;
#elif (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE) || defined(IOMTYPE_DO))
const UINT8 MAXSLOTS = 32;
#elif defined(IOMTYPE_LLMUX)
const UINT8 MAXSLOTS = 64;
const UINT8 HALFMAXSLOTS = (MAXSLOTS/2);

#elif defined (IOMTYPE_SVP)   // SVP Module
const UINT8 MAXSLOTS                    = 8;

const UINT8 AI_MAXSLOTS                   = 2;
const UINT8 AO_MAXSLOTS                   = 2;
const UINT8 DI_MAXSLOTS                   = 2;
const UINT8 SVPREGCTL_MAXSLOTS            = 2;

const UINT8 AI_LVDT_CHANNEL_1_NUMBER      = 1;
const UINT8 AI_LVDT_CHANNEL_2_NUMBER      = 2;
const UINT8 AI_LVDT_CHANNEL_START_INDEX   = 1;

const UINT8 AO_SERVO_CHANNEL_1_NUMBER     = 3;
const UINT8 AO_SERVO_CHANNEL_2_NUMBER     = 4;
#define AO_SERVO_CHANNEL_START_INDEX        3

const UINT8 DI_CHANNEL_1                  = 5;
const UINT8 DI_CHANNEL_2                  = 6;
const UINT8 DI_CHANNEL_START_INDEX        = 5;

const UINT8 SVPREGCTL_CHANNEL_1           = 7;
const UINT8 SVPREGCTL_CHANNEL_2           = 8;
const UINT8 SVPREGCTL_CHANNEL_START_INDEX = 7;

#endif

#ifdef IOMTYPE_SP

const UINT8 MAXSLOTS    = 26;
#define MAX_IOLINK_SLOTS   9
#define MAX_APP_SLOTS     17
#define APP_SLOT_START_INDEX   10

const UINT8 AI_MAXSLOTS = 8;
const UINT8 AI_CH_START = 1;
const UINT8 AI_CH_END   = 8;
const UINT8 AI_CHANNEL_START_INDEX  = 1;

const UINT8 AO_MAXSLOTS  = 1;
const UINT8 AO_CH_START  = 9;
const UINT8 AO_CH_END    = 9;
const UINT8 AO_CHANNEL_START_INDEX  = 9;

const UINT8 DI_MAXSLOTS  = 8;
const UINT8 DI_CH_START  = 10;
const UINT8 DI_CH_END    = 17;
const UINT8 DI_CHANNEL_START_INDEX  = 10;

const UINT8 DO_MAXSLOTS  = 4;
const UINT8 DO_CH_START  = 18;
const UINT8 DO_CH_END    = 21;
const UINT8 DO_CHANNEL_START_INDEX  = 18;

const UINT8 SP_MAXSLOTS  = 4;
const UINT8 SP_CH_START  = 22;
const UINT8 SP_CH_END    = 25;
const UINT8 SPD_CHANNEL_START_INDEX = 22;

const UINT8 VOTLOGIC_BLOCK       = 1;
const UINT8 VOTLOGIC_BLOCK_START = 26;
const UINT8 VOTLOGIC_BLOCK_CHANNEL_START_INDEX = 26;

#endif

#if defined(IOMTYPE_PI)
const UINT8 MAXSLOTS = 8; 
const UINT8 OUTPUT_SLOTS = 2;
#endif

#if defined(IOMTYPE_UIO)
const UINT8 MAXSLOTS = 32;
#endif

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
const UINT8 LPBKSTAT_RCVCHNLENDBIT = 6;
const UINT8 LPBKSTAT_CHNLENDBIT = 4; 
const UINT8 LPBKTST_MAX_RETRIES = 3;
#endif

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_UIO))
// HART BRDP related contants
const UINT16 ALLHNDLBUSY        = 0xFFFF;
#if defined(IOMTYPE_UIO)
    const UINT8  BRDP_HNDL_MSK       = 0xF8;     // SSSSSNNN  S-slot number
    const UINT16 MAXNOOFHANDLES      = 256;      // 8 handles per channel * 32 channels
    const UINT8  SLOTSPERMODEM       = 16;
#else
    const UINT8 BRDP_HNDL_MSK       = 0x78;     // XSSSSNNN  S-slot number
    const UINT8 MAXNOOFHANDLES      = 128;
#endif

const UINT8 MAXBRDPMSGS         = 16;       // Max 16 PassThrough Messages at any time. 

const UINT8 BRDPStsTableSize    = 4;
const UINT8 HNDLStsTableSize    = 2;
const UINT8 BRDP_HNDL_TIMEOUT   = 180; // Handle Timeout in seconds
const UINT8 INVALID_HANDLE      = 0xFF;
const UINT8 INVALID_SLOTNUM     = 0xFF;
const UINT8 INVALID_HANDLE_MASK = 0x80;
const UINT8 BRDPSESSION_OPEN    = 0x01;
const UINT8 BRDPSESSION_CLOSE   = 0x00;
const UINT8 HARTMSG_LEN_OFFSET  = 0x07;
const UINT8 DEFAULT_HART_MSG_LEN = 0x09;
const UINT8 BRDPFIELDCOUNT      = 0x04;  //Information characters in def index paramem write
//The HART message size is calculated as
// Delimiter(1) + UniqueAddr(5) + Cmd(1) + ByetCount(1) + Data(255 Max) + Checksum(1) = 264
#define HARTREQMSGSIZE    264
// Delimiter(1) + UniqueAddr(5) + Cmd(1) + ByetCount(1) + Data(255 Max) + Checksum(1) = 264
#define HARTRESMSGSIZE    264

// C300/IOLIM has 128 byte buffers. Normally HART passthrough commands are less than 128 bytes
// long. The requests/responses which are longer than 128 are sent as split req/responses 
// using multiple IOL messages. max length of the message would be 264 bytes. So it is splited 
// in 3 requests.
const UINT8  HART_SPLIT_PACKET_MASK = 0x03;
// D N S C SltNum ParamNo Handle Header and 2 checksum bytes = 10
// So total HART request data per split request is 128-10=118
const UINT8 HART_REQ_BYTES_PER_IOL_MSG    = 118;
// Maximum number of bytes that can be sent out with each IOL Message
// Note: C300/IOLIM has 100 bytes wide response buffers. That includes D N S C 
// and Checksum bytes from IOLINK message. 1 header byte for response is also required.
// it implies that maximum hart response bytes that can be sent out is 100-7=93 bytes.
const UINT8  HART_RESP_BYTES_PER_IOL_MSG  = 93;
const UINT8  HART_COMPLETE_RESPONSE     = 0;
const UINT8  HART_PARTIAL_RESPONSE      = 1;
// Split Request constants
const UINT8  BRDP_SPLIT_REQUEST     = 0x80;
const UINT8  BRDP_SPLIT_LAST_REQ    = 0xC0;

// Offset in InfoField Data in Deferred Index Write commmand
const UINT8  BRDP_SLOTNO_OFFSET     = 0;
const UINT8  BRDP_PARAMCODE_OFFSET  = 1;
const UINT8  BRDP_HANDLE_OFFSET     = 2;
const UINT8  BRDP_HEADER_OFFSET     = 3;
const UINT8  BRDP_MSGNO_OFFSET      = 4;
#endif

//PARAMETER NUMBER CONTANTS
#define PARAMID_SLOTSFBITS      35  // SlotSfBits
#define PARAMID_MAPSLOTINFAIL   37  // MapSlotInFail
#define PARAMID_CHNERRA         38  // ChnErrA
#define PARAMID_CHNERRB         39  // ChnErrB
#define PARAMID_CHNSILA         40  // ChnSilA
#define PARAMID_CHNSILB         41  // ChnSilB
#define PARAMID_FPGAREVCODE     42  // FPGA RevCode
#define PARAMID_CPLDREVCODE     43  // CPLD RevCode
#define PARAMID_SUP300          47  // Sup300
#if defined(IOPTYPE_AO16)
#define PARAMID_BOXSFBITS       251 // Box Soft Fails
#else
#define PARAMID_BOXSFBITS       51  // BoxSfBits
#endif
#define PARAMID_COMMERR         54  // CommErr
#define PARAMID_COMMSTAT        55  // CommStat
#define PARAMID_DPA             56  // Dpa
#define PARAMID_DSA             57  // Dsa
#define PARAMID_BA              60  // Ba
#define PARAMID_IOLDEVTYPE      64  // IolDevType
#if !defined(IOPTYPE_SCIOM)
// for redesign PMIO, non avail params
#define PARAMID_LASTFAIL        65  // LastFail
#define PARAMID_HWREVCODE       63  // HwRevCode
#define PARAMID_SWREVCODE       72  // SwRevCode
#if defined(IOPTYPE_HLAI)
#define PARAMID_PVSCAN         105  // PVSCANREC (PVSTALM)
#endif
#endif
#define PARAMID_MODSTAT1        67  // ModStat1
#define PARAMID_MODSTAT2        68  // ModStat2
#define PARAMID_MODLTYPE        69  // ModlType
#define PARAMID_NTH             70  // Nth
#define PARAMID_REDDATA         77  // RedData
#define PARAMID_DBVALID         78  // DbValid
#define PARAMID_SFACTNTBL       79  // SfActionTbl
#define PARAMID_FREQ6050        82  // FREQ6050
#if defined(IOPTYPE_AO16) || defined(IOPTYPE_DO)
#define PARAMID_FL_UNPWRD_BX    91  // Box Fault Unpowered
#endif
#define PARAMID_HAUTODET        110 // HAUTODET
#define PARAMID_MAXSLOTS        116 // MaxSlots
#define PARAMID_BOXCHKPNT       143 // CheckPoint
#define PARAMID_BRDP            151 // BRDP (BOX)
#define PARAMID_TEMPHILM        208 // TempHiLm
#define PARAMID_TEMPLOLM        209 // TempLoLm
#define PARAMID_HBRDP           232 // HBRDP (SLOT)
#define PARAMID_BOXCHKPNTVER    243 // BoxChekpointVerNum
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_LLMUX))
#define PARAMID_SLTCHKPNTVER    245 // SlotChekpointVerNum
#elif defined(IOMTYPE_UIO)
// SlotCheckpointVerNum is defined in the individual slot cpp files.
#else
#define PARAMID_SLTCHKPNTVER    244 // SlotChekpointVerNum
#endif
#if defined(IOPTYPE_DO) || defined(IOPTYPE_DI)
#define PARAMID_DO_BOXSFAIL     249 //BoxSfBits
#endif

// Constants used for SPI EEPROM
// INSTRUCTION SET
const UINT8 EEPROM_WREN   = 0x06;
const UINT8 EEPROM_WRDI   = 0x04;
const UINT8 EEPROM_RDSR   = 0x05;
const UINT8 EEPROM_WRSR   = 0x01;
const UINT8 EEPROM_RDLO   = 0x03;
const UINT8 EEPROM_RDHI   = 0x0B;
const UINT8 EEPROM_WRLO   = 0x02;
const UINT8 EEPROM_WRHI   = 0x0A;

#if !defined(IOPTYPE_SCIOM)

// PTEXECST LRS BITS
const UINT8 PTEXECST_OFF_LRSBIT = 0x01;
const UINT8 PTEXECST_ON_LRSBIT  = 0x02;
// PTEXECST ON/OFF SUB EVENTS
const UINT8 PTEXECST_OFF_SUBEVT = 0x84;
const UINT8 PTEXECST_ON_SUBEVT  = 0x85;

/*
for redesign PMIO, xRAM related constants
This is status register value for xRAM.
01000000 (default - 0x40)
||||||||_Bit0 - dont care (default 0)
|||||||__Bit1 - WEL (0 - write disable default)
||||||___Bit2 - BP0 (Block Protect bit0, default 0)
|||||____Bit3 - BP1 (Block Protect bit1, default 0) 
||||_____Bit4 - dont care (default 0)
|||______Bit5 - dont care (default 0)
||_______Bit6 - dont care (default 1)
|________Bit7 - WPEN (0 - Write protect disable default)
*/
#define xRAM_PRESENT          0x40                   // Default value of the xRAM status register (used for its presence)
#define xRAM_READ             0x03                   // xRAM read opcode
#define xRAM_WRITE            0x02                   // xRAM write opcode
#define xRAM_SPI              EEPROM_SPI             // xRAM SPI register structure (same as EEPROM)
#define SS_xRAM               SS_EEPROM              // xRAM Slave Select Byte (same as EEPROM)
#define DUMMYBYTE             0x00                   // Dummy byte
#define xRAM_WREN             EEPROM_WREN            // xRAM Write Enable (same as EEPROM)
#define xRAM_WRDI             EEPROM_WRDI            // xRAM Write Disable (same as EEPROM)
#define xRAM_WP_n             EEPROM_WP_n            // xRAM Write Protect pin (same as EEPROM)
#define xRAM_ADDR_START       0x00001000             // In xRAM, start address for required backup data (as like PMIO battery backed SRAM)
#define xRAM_SIZE             0x00020000             // xRAM total size (1 Mbit / 128KByte)
#define xRAM_ADDR_END         (xRAM_SIZE-1)          // xRAM last address
#define xRAM_CHKPNT_ADRS      xRAM_ADDR_START        // checkpoint parameters start address in xRAM
#if defined(HART_SUPPORT) && (defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16))
#define xRAM_CHKPNT_BLOCK     200                    // block size for checkpoint parameters in xRAM
#else
#define xRAM_CHKPNT_BLOCK     100                    // block size for checkpoint parameters in xRAM
#endif
#if defined(IOPTYPE_DO) || defined(IOPTYPE_DI)
#define xRAM_CALIB_DONE       (xRAM_CHKPNT_BLOCK-72) // 0x103C byte is to store recently calib done
#define xRAM_LAST_DPA         (xRAM_CHKPNT_BLOCK-71) // 0x103D byte is to store LAST DPA (work around for IDL mode when module remove from chasis)
#define xRAM_APP_CRC          (xRAM_CHKPNT_BLOCK-70) // From 0x103E - 0x1041 is to store APP CRC Checking
#define xRAM_CHKPNT_CKSM      (xRAM_CHKPNT_BLOCK-66) // Last 34 bytes of box checkpoint block reserved for checksum of box and slot checkpoints
#else
#define xRAM_CALIB_DONE       (xRAM_CHKPNT_BLOCK-40) // 0x103C byte is to store recently calib done
#define xRAM_LAST_DPA         (xRAM_CHKPNT_BLOCK-39) // 0x103D byte is to store LAST DPA (work around for IDL mode when module remove from chasis)
#define xRAM_APP_CRC          (xRAM_CHKPNT_BLOCK-38) // From 0x103E - 0x1041 is to store APP CRC Checking
#define xRAM_CHKPNT_CKSM      (xRAM_CHKPNT_BLOCK-34) // Last 34 bytes of box checkpoint block reserved for checksum of box and slot checkpoints
#endif
#if defined(HART_SUPPORT) && (defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16))
#define xRAM_CHKPNT_PRMXSZ    0x52                   // Maximum size (+2) of parameter in xRAM
#else
#define xRAM_CHKPNT_PRMXSZ    0x12                   // Maximum size (+2) of parameter in xRAM
#endif
#define xRAM_CHKSM_SIZE       0x02                   // Size of checksum for checkpoints in xRAM

const UINT8 EEPROM_PRESENT  = xRAM_PRESENT;

#if defined(IOPTYPE_HLAI)
extern UINT8 ucXRamTimeout;
#endif

#if defined(IOPTYPE_DI) || defined(IOPTYPE_DO) || defined(IOPTYPE_AO16)
const UINT8 SRAM_WRMR = 0x01;

extern VOID xRamInit(VOID);
#endif
extern VOID xRamWrite(UINT32 ulAddress, UINT8 *pucData, UINT16 uiCount);
extern VOID xRamRead(UINT32 ulAddress, UINT8 *pucData, UINT16 uiCount);

#else
// This is status register value for EEPROM. Bit0-1 should always be 0,
// Bit2-3 should always 0 and bit4-7 should be always 1. We do not write 
// protect EEPROM so it should always read bit2-3 as 0's.
const UINT8 EEPROM_PRESENT= 0xF0; 
#endif
const UINT8 EEPROM_STSMASK  = 0xFC; 
const UINT8 EEPROM_SELECT   = 0xFD;
const UINT8 EEPROM_DESELECT = 0x02;

/*******************************************************************************
*                                  clsBoxSlot                                  *
*                                  ==========                                  *
*   This class implements the attributes common to box database of all IOMs.   *
*******************************************************************************/
class clsBoxSlot : public clsIomSlot {
#if defined(IOMTYPE_SVP) || defined(IOMTYPE_SP)
protected:
#else
private:
#endif
    clsEcl       *pNrmEcl;
#if defined IOMTYPE_DISOE || defined IOPTYPE_DI
    clsEcl      *pPvChngEcl;
#endif

public:
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
    // BRDP database
    UINT8       BRDPOneSecCounter;
    // These 2 bytes keep the status of available resources for brdp.
    // Each bit corressponds one resource pool which contains 
    // 1 request buffer & 1 response buffer.
    UINT16      BRDPResourceStatus;
    // Handle, Status
    HNDLSTSTABLE    HNDLStatusTable[MAXBRDPMSGS];
    // Stores the message number (Buffer Number ) where the split message is copied.
    UINT8       SPLTRequestHndlTable[MAXNOOFHANDLES];
    // Stores the offset in case of split message responses.
    UINT8       SPLTResponseOffsetTable[MAXBRDPMSGS];
    // End BRDP database
#elif defined(IOMTYPE_UIO)
    // BRDP database
    UINT8       BRDPOneSecCounter;
    // These 4 bytes keep the status of available resources for brdp.
    // Each bit corressponds one resource pool which contains 1 request buffer & 1 response buffer.
    UINT16      BRDPResourceStatus[HARTMODEM_COUNT];
    // Handle, Status
    // A Handle is issued per slot. A client can open several sessions with a Handle plus three bits to identify the session.
    // The data in this table represents the overall status of the Handle.
    HNDLSTSTABLE    HNDLStatusTable[MAXSLOTS];

    // Stores the message number (Buffer Number ) where the split message is copied.
    // For UIO MAXNOOFHANDLES is 256 (Max Number of sessions per channel * Number of Channels per Modem * Number of Modems)
    UINT8       SPLTRequestHndlTable[MAXNOOFHANDLES];

    // Stores the offset in case of split message responses.
    UINT8       SPLTResponseOffsetTable[HARTMODEM_COUNT][MAXBRDPMSGS];
    // End BRDP database
#endif

protected:
    HWINFO       HwInfo;
    REVCODE      AppSwRevCode;
    REVCODE      BootSwRevCode;

    MODLTYPE     ModlType;
    UINT8        ModlNum;
    UINT8        IolId;
    UINT8        Dpa;
    UINT8        Dsa;
    UINT8        Ba;
    UINT8        Nth;
    IOLDEVTYPE   IolDevType;
    UINT8        ModStat1Lrs;
    MODSTAT2     ModStat2;
    
    MODSTAT3     ModStat3;
    UINT8        MesNo;
    UINT8        CommErr;
    COMMSTAT     CommStat;
    UINT8        ChnErrA;
    UINT8        ChnErrB;
    UINT8        ChnSilA;
    UINT8        ChnSilB;
    FLOAT32      CpuFreeMin; 
    FLOAT32      CpuFreeAvg; 
    BOOL         StatReset;
    UINT8        CPLDRegData;

#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH) || defined(IOMTYPE_DO) || defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP) || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
    BOOL         ComTog;
    BOOL         CtlTog;
    BOOL         ComAlive;
    BOOL         CtlAlive;
    BOOL         CtlWasAlive;
    UINT16       TmoutCntr;
    UINT32       LastTime;
#endif

    HARDFAILTYPE LastFail;
    UINT8        SuprCtrl;
    UINT16       ToknStll;
    UINT16       CheckSum[MAXSLOTS + 1]; // Checksum for warm start. 
    BLIND        BoxSfBits[SFBYTES_SIZE];
    BLIND        SlotSfBits[SFBYTES_SIZE];
    BLIND        MapSlotInFail[SLOTINFAIL_SIZE];
    BLIND        BoxSfLrs[SFBYTES_SIZE];
    UINT8        BoxSfCounter;
    UINT8        SlotSfCounter;
    BLIND        SfActionTbl[SFBYTES_SIZE];
    BOOL         WithBias;
    BLIND        SyncVer[SYNCVER_SIZE];
    BLIND        RedData[REDDATA_SIZE];
    TRACELOGDATA TraceLogInfo; 
    UINT16       Tpu5_Sec;
    UINT8        LedBlinkCounter;
    UINT8        LpBkStat;
    static INT32 TstFunctTime;
    BOOL         bStcSyncRestart;
    BOOL         bWdtIntProcessed;
    UINT8        ucDummy;
#if defined (IOMTYPE_UIO)
public:
    BOOL        bMultiplePSTPresent[HARTMODEM_COUNT];
    UINT8       ucB2BPSTCount[HARTMODEM_COUNT];
    UINT8       ucLeastScanRate[HARTMODEM_COUNT];
    UINT16      usChannelsWithPST[HARTMODEM_COUNT];

protected:
#endif

#if defined(IOPTYPE_AO16)
    // to fix flood alarms
    SOFTFAILTYPE    LastSfCode;
    SOFTFAILTYPE    SfCodeLrs;
    UINT8           ucOutputFailCounter;
#endif

    // !!!*** BOXSLOT_DUMP_RECORD_BEGIN ***!!!
    // This marks the beginning of the box slot's redundant synch data area.
    // No data members that are not to be synch'd can be declared below this
    // point. Any new data members to be added to this dump record must be
    // added at the end in cls<iomtype>BoxSlot or the spare memory allocated. 
    // If new member is added to the end class, cls<iomtype>BoxSlot::GetRedBoxSize() 
    // must be updated to reference the new end member. This dump record ends 
    // in cls<iomtype>BoxSlot.
    MODSTAT1     ModStat1;
    BOOL         DbValid;
    UINT8        MaxSlots;
    UINT16       Tpu5_Pri;
    UINT8        BoxSlotSpare[BOXSLOT_SPARESIZE];

    static HARDFAILTYPE FailCode;
    static BOOL IomRebooted;
    static UINT32 TracelogTimeCntr; //Tracelog timestamp    
    static const UINT8 Bits[];
    static const SOFTFAILTYPE SlotSfMap[BYTESIZE];
    static const UINT8 ModStatType[];
    static const UINT8 Sup300[];
    static const UINT8 SfInfo300[];

#if !defined(IOPTYPE_SCIOM)
    // for redesign PMIO, non avail params
    static const UINT8 IomDtl[];
    static const UINT8 IolSup[];
    static const UINT8 IopDesc[];
#endif

    clsBoxSlot(MODLTYPE,UINT8);
    virtual ~clsBoxSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,BOXSLOT_HPP,__LINE__); }

    PASTATUS PreModStat1(UINT8 *,UINT8);
    VOID PostModStat1(UINT8);
    PASTATUS PreSyncVer(UINT8 *,UINT8); 
    PASTATUS PreRedData(UINT8 *,UINT8);
    VOID PostRedData(UINT8);
    PASTATUS PreStatReset(UINT8 *,UINT8);
    VOID PostStatReset(UINT8);
    PASTATUS PreCPLDRegData(UINT8 *,UINT8);
    VOID PostCPLDRegData(UINT8);

    inline VOID SetSfActionBit(SOFTFAILTYPE a_SoftfailType) {
        // get the SF byte and bit mask
        UINT8 ucSfActByte = (UINT8)(a_SoftfailType / BYTESIZE);
        UINT8 ucSfActBitMask = (UINT8)1 << (a_SoftfailType % BYTESIZE);

        // set the bit
        SfActionTbl[ucSfActByte] |= ucSfActBitMask;
    };

    inline VOID ClearSfActionBit(SOFTFAILTYPE a_SoftfailType) {
        // get the SF byte and bit mask
        UINT8 ucSfActByte = (UINT8)(a_SoftfailType / BYTESIZE);
        UINT8 ucSfActBitMask = (UINT8)1 << (a_SoftfailType % BYTESIZE);

        // clear the bit
        SfActionTbl[ucSfActByte] &= ~(ucSfActBitMask);
    };

#if defined(IOPTYPE_HLAI) && defined(HART_SUPPORT)
	/*
	* Work around for HLAIH sync issue in hybrid combination.
	* Explanation: SyncVer mismatch between legacy (0x724) & Redesign (0x726) during the time of database download
	* once after data dump both the modules are syncing eachother syncver(0x726).
	* Root cause: SfActionTbl[9] is appearing with 0x02, instead of 0x00 during database configuration download.
	*/
	inline VOID PostDbValid(UINT8) {
		if (DbValid == 0) {
			SfActionTbl[9] |= 0x02;
		}
	}
#endif

    inline VOID PostSfActionTbl(UINT8) {
#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))        
        // for redesign PMIO, it disabled due to sync fail
#if !defined(IOPTYPE_AO16)
        //clear the sf action table bit for SF_OUTPUTFL
        SfActionTbl[2] &=0x7F;
#endif
#elif defined (IOMTYPE_UIO)
        // clear sf action table bits so these particular softfails do not cause failover
        ClearSfActionBit(SF_OUTPUTFL);
        ClearSfActionBit(SF_OPENWIRE);
        ClearSfActionBit(SF_DOVRCRNT);
        ClearSfActionBit(SF_TEMPHILM);
        ClearSfActionBit(SF_TEMPLOLM);
#elif(defined(IOMTYPE_DO) || defined(IOMTYPE_SVP) || defined (IOMTYPE_SP))

#if !defined(IOPTYPE_DO)
        //clear the sf action table bit for SF_OUTPUTFL and SF_DOVRCRNT
        SfActionTbl[2] &=0x7F; 
        SfActionTbl[22] &=0xEF;  
#endif

#elif defined(IOMTYPE_PI)
        //clear the sf action table bit for SF_FCO_DIAG_FAIL
        ClearSfActionBit(SF_FCO_DIAG_FAIL);
#endif
       TraceLog.AddToTrace(TRACEID_GENERIC,bcSfActionTable);
    }

    inline VOID *GetChnErrAPtr(VOID) { return &ChnErrA; }
    inline VOID *GetChnErrBPtr(VOID) { return &ChnErrB; }
    inline VOID *GetChnSilAPtr(VOID) { return &ChnSilA; }
    inline VOID *GetChnSilBPtr(VOID) { return &ChnSilB; }
#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH) || defined(IOMTYPE_DO) || defined (IOMTYPE_SVP) || defined(IOMTYPE_SP) || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
    inline VOID *GetCtlTogPtr(VOID)     {return &CtlTog;}
    inline VOID *GetComTogPtr(VOID)     {return &ComTog;}
#endif
    inline VOID *GetCheckSumPtr(VOID) { return CheckSum; }
    inline VOID *GetBoxSfBitsPtr(VOID) { return BoxSfBits; }
    inline VOID *GetBoxSfLrsPtr(VOID) { return BoxSfLrs; }
    inline VOID *GetSlotSfBitsPtr(VOID) { return SlotSfBits; }
    inline VOID *GetMapSlotInFailPtr(VOID) { return MapSlotInFail; }
    inline VOID *GetModStatTypePtr(VOID) { return (VOID *)ModStatType; }
    inline VOID *GetSup300Ptr(VOID) { return (VOID *)Sup300; }
    inline VOID *GetCircListStPtr(VOID) { return &pNrmEcl->CircListSt; }
    inline VOID *GetCommErrPtr(VOID) { return &CommErr; }
    inline VOID *GetCommStatPtr(VOID) { return &CommStat; }
    inline VOID *GetDpaPtr(VOID) { return &Dpa; }
    inline VOID *GetDsaPtr(VOID) { return &Dsa; }
    inline VOID *GetEvntAppPtrPtr(VOID) { return &pNrmEcl->EvntAppPtr; }
    inline VOID *GetEvntRemPtrPtr(VOID) { return &pNrmEcl->EvntRemPtr; }
    inline VOID *GetBaPtr(VOID) { return &Ba; }
    inline VOID *GetSyncVerPtr(VOID) { return SyncVer; }
    inline VOID *GetFailCodePtr(VOID) { return &FailCode; }
    inline VOID *GetHwInfoPtr(VOID) { return &HwInfo; }
    inline VOID *GetHwRevCodePtr(VOID) { return &HwInfo.HwRevLetter; }
    inline VOID *GetAppSwRevCodePtr(VOID) { return &AppSwRevCode; }
    inline VOID *GetBootSwRevCodePtr(VOID) { return &BootSwRevCode; }
    inline VOID *GetAppBuildNoPtr(VOID) { return APP_BUILD_NUMBER_PTR; }   // read from flash
    inline VOID *GetBootBuildNoPtr(VOID) { return BOOT_BUILD_NUMBER_PTR; } // read from flash
    inline VOID *GetIolDevTypePtr(VOID) { return &IolDevType; }
    inline VOID *GetLastFailPtr(VOID) { return &LastFail; }
    inline VOID *GetMesNoPtr(VOID) { return &MesNo; }
    inline VOID *GetModStat1Ptr(VOID) { return &ModStat1; }
#if defined(DIGTYPE_DO16)
    inline VOID *GetModStat2Ptr(VOID) { ModStat2.StndbyMan = STDBYMN_PIN; return &ModStat2; }
#else
    inline VOID *GetModStat2Ptr(VOID) { return &ModStat2; }
#endif
    inline VOID *GetModlTypePtr(VOID) { return &ModlType; }
    inline VOID *GetNthPtr(VOID) { return &Nth; }
    inline VOID *GetTstFunctTimePtr(VOID) { return &TstFunctTime; }
    inline VOID *GetSfInfo300Ptr(VOID) { return (VOID *)SfInfo300; }
    inline VOID *GetWithBiasPtr(VOID) { return &WithBias; }
    inline VOID *GetRedDataPtr(VOID) { return RedData; }
    inline VOID *GetDbValidPtr(VOID) { return &DbValid; }
    inline VOID *GetSfActionTblPtr(VOID) { return SfActionTbl; }
    inline VOID *GetMaxSlotsPtr(VOID) { return &MaxSlots; }
    inline VOID *GetSuprCtrlPtr(VOID) { return &SuprCtrl; }
    inline VOID *GetToknStllPtr(VOID) { return &ToknStll; }
    inline VOID *GetCpuFreeMinPtr(VOID) { return &CpuFreeMin; }
    inline VOID *GetCpuFreeAvgPtr(VOID) { return &CpuFreeAvg; }
    inline VOID *GetStatResetPtr(VOID) { return &StatReset; }
    inline VOID *GetLpBkStatPtr(VOID) { return &LpBkStat;}

#if !defined(IOPTYPE_SCIOM)
    // for redesign PMIO, non avail param
    inline VOID *GetIopDescPtr(VOID)   { return (VOID *)IopDesc; }
    inline VOID *GetIomDtlPtr(VOID)    { return (VOID *)IomDtl; }
    inline VOID *GetIolSupPtr(VOID)    { return (VOID *)IolSup; }
    inline VOID *GetSuperCtrlPtr(VOID) { return &SuprCtrl; }
    inline VOID *GetToknStallPtr(VOID) { return &ToknStll; }    
#endif

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,BOXSLOT_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,BOXSLOT_HPP,__LINE__); } 
    clsBoxSlot(const clsBoxSlot&); // Safeguard against default copy constructor
    clsBoxSlot& operator=(const clsBoxSlot&); // and defualt assignement.

public:
    static VOID BlinkLEDInterruptHandler(VOID);
    static VOID IRQ1InterruptHandler(VOID);
    static VOID NMInterruptHandler(VOID);

    BOOL AddModStatEvent(EVENTTYPE);
#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
    virtual BOOL AddSoftfailEvent(EVENTTYPE, SOFTFAILTYPE, BOOL, UINT8); 
#else
    BOOL AddSoftfailEvent(EVENTTYPE, SOFTFAILTYPE, BOOL, UINT8);
#endif
    BOOL AddBracketEvent(EVENTSUBTYPE);
#if defined IOMTYPE_DISOE || defined IOPTYPE_DI
    BOOL AddPVCLBracketEvent(EVENTSUBTYPE);
#endif
#ifdef IOMTYPE_SVP
    virtual BOOL RegenSoftfails(VOID);
    virtual VOID BoxHouseKeeping(VOID);
#elif defined(IOMTYPE_SP)
    virtual VOID BoxHouseKeeping(VOID);
    BOOL RegenSoftfails(VOID);
#else
    BOOL RegenSoftfails(VOID);
    VOID BoxHouseKeeping(VOID);
#endif

#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_DI)
    // for redesign PMIO, alarms
    BOOL AddAiAlarmEvent(ALARMEVENTRECORD *pAlarmEvent);
#endif
#if !defined(IOPTYPE_SCIOM)
    BOOL AddPtExecStEvent(EVENTRECORD *pPtExecStEvent);
#endif

#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    // BRDP related functions
    VOID    InitBRDPDatabase(VOID);
    VOID    ProcessBrdpTimeout(VOID);
#endif
    PASTATUS PreRedState(VOID);
    VOID PostRedState(VOID);
    VOID ManageRedIO(VOID);
    VOID DropSync(VOID);
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
    RETURNSTATUS HartLoopBackTest(VOID);
#endif
#if !defined(IOPTYPE_SCIOM) //#ifndef DEBUG
    BOOL FlashHWRevCode(VOID);
    VOID StoreDatabase(UINT8, BOOL);
#endif

#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH) || defined(IOMTYPE_DO)|| defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP) || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
    TOG_FAILED IsTogFailed(VOID);
#endif

    virtual VOID AppStcProcessing(VOID)  { return; }
    virtual VOID AppInitialization(VOID) { return; }

    inline MODLTYPE GetModuleType(VOID) { return ModlType; }
    inline UINT8 GetModuleId(VOID) { return (IolId + ModlNum); }
    inline UINT8 GetModlNum(VOID) { return ModlNum; }
    inline UINT8 GetDPA(VOID) { return Dpa; }
    inline UINT8 GetDSA(VOID) { return Dsa; }
    inline UINT8 GetBA(VOID) { return Ba; }
    inline VOID SetDSA(UINT8 a_ucDsa) {
        Dsa = a_ucDsa;
        Ba  = 0xFF;
    }
    inline VOID SetBA(UINT8 a_ucBa) {
        Ba  = a_ucBa;
        Dsa = 0;
    }
    inline UINT8 GetPRC(VOID) {
        UINT8 ucRetVal = 0;
        if (CommStat.PRC) ucRetVal = 1;
        return ucRetVal;
    }
    inline VOID SetPRC(VOID) {
        CommStat.PRC = TRUE;
        RCVSELA_n = RCVSEL_CHANNELB;
    }
    inline VOID ResetPRC(VOID) {
        CommStat.PRC = FALSE;
        RCVSELA_n = RCVSEL_CHANNELA;
    }
    inline UINT8 SwapPRC(VOID) {
        UINT8 ucReturn;
        if (CommStat.PRC) {
            CommStat.LSB = TRUE;
            if (ChnSilB < MAXUINT8) ChnSilB++;
            CommStat.PRC = FALSE;
            RCVSELA_n = RCVSEL_CHANNELA;
            ucReturn = 0;
        }
        else {
            CommStat.LSA = TRUE;
            if (ChnSilA < MAXUINT8) ChnSilA++;
            CommStat.PRC = TRUE;
            RCVSELA_n = RCVSEL_CHANNELB;
            ucReturn = 1;
        }
        return ucReturn;
    }
    inline BOOL  AreLinkErrorsSet(UINT8 ucChan) {
        BOOL bReturn = FALSE;
        if ((ucChan == 0) && (CommStat.LSA || CommStat.LEA)) bReturn = TRUE;
        if ((ucChan == 1) && (CommStat.LSB || CommStat.LEB)) bReturn = TRUE;
        return bReturn;
    }
    inline UINT16 GetSilenceCount() { return (ChnSilA + ChnSilB); }
    inline BOOL  IsSlotSfPresent(VOID) { return (0 < SlotSfCounter); }
    inline UINT8 GetBoxSfByte(UINT8 a_ucIndex) { return BoxSfBits[a_ucIndex]; }
    inline UINT8 GetSlotSfByte(UINT8 a_ucIndex) { return SlotSfBits[a_ucIndex]; }
    
    inline UINT8 GetModuleStatus(VOID) { return ModStat1.Status; }
    inline UINT8 CheckForFactoryTestMode(VOID) {return ModStat1.Factory;}
    inline VOID  DoAliveToIdleChange(VOID) {
        if (MODSTATUS_ALIVE == ModStat1.Status) {
            ModStat1.Status = MODSTATUS_IDLE; 
            AddModStatEvent(EVENTTYPE_NORMAL);
        }
    }
    inline UINT8 GetMaxSlots(VOID) { return MaxSlots; }
    inline UINT8 GetMesNo(VOID) { return MesNo; }
    inline VOID  SetMesNo(UINT8 a_ucMesNo) { MesNo = a_ucMesNo; }
    inline BOOL  IsRoomForRegen(VOID) { return pNrmEcl->IsRoomForRegen(); }
#if defined IOMTYPE_DISOE || defined IOPTYPE_DI
    inline BOOL  IsRoomForPVCLRegen(VOID) { return pPvChngEcl->IsRoomForPVCLRegen(); }
#endif

    inline BOOL  IsIolCorrect(UINT8 ucIolId) { return !(ucIolId ^ IolId); }

#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH) || defined(IOMTYPE_DO)|| defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP) || defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
    inline VOID UpdateTOG(UINT8 ucTog) {
        if(ucTog && COMTOGBIT) ComTog = TRUE;
        if(ucTog && CTLTOGBIT) CtlTog = TRUE;
    }

    inline BOOL GetComTog(VOID)      { return ComTog; }
    inline BOOL GetCtlTog(VOID)      { return CtlTog; }
    inline BOOL GetCtlWasAlive(VOID) { return CtlWasAlive; }
#endif

    inline VOID SetCommError(PASTATUS a_uiError) {
        CommErr = a_uiError;
        if (CommStat.PRC) {
            CommStat.LEB = TRUE;
            if (ChnErrB < MAXUINT8) ChnErrB++;
        }
        else {
            CommStat.LEA = TRUE;
            if (ChnErrA < MAXUINT8) ChnErrA++;
        }
        ModStat2.CommErr = TRUE;
    }
    inline VOID ResetCommErrs(VOID) {
        CommStat.LEA = CommStat.LEB = CommStat.LSA = CommStat.LSB = FALSE;
        CommErr = PA_OK;
        ChnErrA = ChnErrB = ChnSilA = ChnSilB = 0;
        ModStat2.CommErr = FALSE;
    }

#if !defined(IOPTYPE_SCIOM)
    // for pmio redesign modules, to access
    inline BOOL  GetFtaPres(VOID)  { return ModStat2.FtaPres; }    
    inline BOOL  GetIotaPos(VOID)  { return ModStat2.IotaPos; }
    inline UINT8 GetModStat1(VOID) { return ModStat1.BYTE; }

    inline VOID SetFtaPres(BOOL bState)  { ModStat2.FtaPres = bState; }        
    inline VOID SetIotaPos(BOOL bState)  { ModStat2.IotaPos = bState; }    

#if defined(IOPTYPE_AO16)
    inline UINT8 GetLastSfCode(VOID) { return LastSfCode; }
    inline UINT8 GetSfCodeLrs(VOID) { return SfCodeLrs; }
    inline UINT8 GetucOutputFailCounter(VOID) { return ucOutputFailCounter; }
#endif
#endif

    inline UINT8 GetNrmEclStatus(VOID) { return pNrmEcl->GetStatus(); }
    
    inline BOOL AddNrmEclEvent(EVENTRECORD *a_pEventRecord) 
    {
        return pNrmEcl->AddEvent(a_pEventRecord);
    }

    inline UINT16 CollectNrmEclInfo(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes)
    {
        return pNrmEcl->CollectEclInfo(a_pBuffer, a_uiMaxBytes);
    }

    inline VOID CollectNrmEclData(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes)
    {
        pNrmEcl->CollectEclData(a_pBuffer, a_uiMaxBytes);
    }

    inline VOID UpdateNrmEclRemPtr(UINT16 a_uiNewRemPtr)
    {
        pNrmEcl->UpdateRemPtr(a_uiNewRemPtr);
    }

    inline VOID SetCheckSum(UINT8 a_ucChanNum, UINT a_ulChecksumVal)
    {
        CheckSum[a_ucChanNum] = a_ulChecksumVal;
    }
#if !defined(IOPTYPE_SCIOM)
    // for redesign PMIO,  
    inline UINT16 *GetPmioCheckSumPtr(UINT8 a_ucChanNum) { return &CheckSum[a_ucChanNum]; }
#endif

    // Related to PVCL buffer Handling with IOLINK commands .
#if defined IOMTYPE_DISOE || defined IOPTYPE_DI

    inline UINT16 CollectNrmPVCLInfo(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes)
    {
        return pPvChngEcl->CollectPVCLInfo(a_pBuffer, a_uiMaxBytes);
    }
    inline VOID CollectNrmPVCLData(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes)
    {
        pPvChngEcl->CollectPVCLData(a_pBuffer, a_uiMaxBytes);
    }
    inline VOID UpdateNrmPVCLRemPtr(UINT16 a_uiNewRemPtr)
    {
        pPvChngEcl->UpdatePVCLRemPtr(a_uiNewRemPtr);
    }
    inline BOOL AddNrmPVCLEvent(PVCLEVTRECORD *PVCLEvtRecord)
    {
        return pPvChngEcl->AddPVCLEvent(PVCLEvtRecord);
    }
    inline UINT16 *GetPVCLAppPtr(VOID)
    {
        return &pPvChngEcl->PVCLAppPtr;
    }
    inline UINT16 *GetPVCLRemPtr(VOID)
    {
        return &pPvChngEcl->PVCLRemPtr;
    }
#endif

    inline VOID BlinkLed(UINT8 a_ucBlinkCount) { 
    // Twice of desired blinks should be assigned to 
    // counter because 2 means one OFF and one ON
      LedBlinkCounter = 2 * a_ucBlinkCount; 
    }
    BOOL WaitCalibSwitch(VOID);
    virtual BOOL GetCalibAllState(VOID) { return FALSE; }
    virtual VOID AppUrgentProcess(VOID) { return; }

    inline HARDFAILTYPE GetFailCode(VOID) { return FailCode; }
    inline VOID  SetFailCode(HARDFAILTYPE a_FailCode) { FailCode = a_FailCode; }

    inline FLOAT32 GetCpuFreeMin(VOID) { return CpuFreeMin; }
    inline VOID SetCpuFreeMin(FLOAT32 a_fCpuFreeMin) { CpuFreeMin = a_fCpuFreeMin; }
    inline VOID SetCpuFreeAvg(FLOAT32 a_fCpuFreeAvg) { CpuFreeAvg = a_fCpuFreeAvg; }

    static inline VOID SetIomRebooted(BOOL a_bVal) { IomRebooted = a_bVal; }
    static inline BOOL GetIomRebooted(VOID) { return IomRebooted; }
    static inline UINT32 GetTraceLogTime(VOID) { return TracelogTimeCntr; }
    static inline VOID ResetTraceLogTime(VOID) { TracelogTimeCntr = 0; }

    inline VOID *GetTraceLogInfoPtr(VOID) {
        TraceLogInfo.TracelogTime = TracelogTimeCntr;
        TraceLogInfo.LatestIndex  = TraceLog.GetLatestTraceIndex();
        return &TraceLogInfo;
    }
    inline VOID SetTraceTime(VOID) { TracelogTimeCntr++; }
    inline VOID *GetTracelogPtr(VOID) { return TraceLog.GetTracelog(); }
    inline VOID *GetTracelevelPtr(VOID) { return TraceLog.GetTracelevel(); }

    inline VOID MarkStcCounter(BOOL bPrimary) {
        if (bPrimary == TRUE) Tpu5_Pri = TPU5_TCNT;
        else Tpu5_Sec = TPU5_TCNT;
    }
    inline VOID SyncStcCounter(BOOL bPrimary) {
        if (bPrimary == FALSE) {
            bStcSyncRestart = TRUE;
            TPU5_TCNT = Tpu5_Pri + (TPU5_TCNT - Tpu5_Sec);
        }
        TPU3_TCNT = 0;
    }
    inline BOOL GetStcSyncReset(VOID) {return bStcSyncRestart;}

    inline BOOL GetWdtIntProcessed(VOID) { return bWdtIntProcessed; }
    inline VOID SetWdtIntProcessed(VOID) { bWdtIntProcessed = TRUE; }
    inline VOID ResetWdtIntProcessed(VOID) { bWdtIntProcessed = FALSE; }

    inline BOOL CheckRedData(UINT8 ucBit) {return (RedData[0] & ucBit);}
    inline UINT8 GetRedData(VOID) {return (UINT8)RedData[0];}
    inline UINT8 GetRedState(VOID) {return (UINT8)RedData[1];}
    inline VOID ResetRedData(UINT8 ucBit) {RedData[0] &= ~ucBit;}
    inline VOID SetRedData(UINT8 ucBit) {RedData[0] |= ucBit;}
#ifdef IOMTYPE_SP
    virtual 
#endif
    inline VOID SetRedState(BLIND ucRedState) {RedData[1] = ucRedState;}
    inline VOID UpdateRedData(UINT8 ucnewRedData) {
        register UINT8 ucBitnum = ucnewRedData & 0x7F;
        if (ucnewRedData & 0x80) SetRedData(Bits[ucBitnum]);
        else ResetRedData(Bits[ucBitnum]);
    }
    
    inline BOOL GetPartnersBackupStatus(VOID){
        #if !AIAO
        RDBK_SEL = RDBK_IOTA;          // Select proper bank for BUPREQ_IN
        #endif // !AIAO
        #if LOWCOST
            // For Low Cost AI Module, BUPREQ_IN H/W signal is inverted.
            // Instead of fixing in H/W, firmware will read and complement it.
            #if defined(IOMTYPE_AIH)
                return (!BUPREQ_IN);
            #else
                return (BUPREQ_IN);
            #endif
        #else
        return (BUPREQ_IN);
        #endif
    }
    
    inline BOOL GetMyBackupStatus(VOID) {
        return (CheckRedData(REDDATA_BURQST));
    }

    inline VOID AssertBackup(VOID) {
        SetRedData(REDDATA_BURQST);
        SWBUREQ_n = 0;
    }
    inline VOID DeAssertBackup(VOID) {
        ResetRedData(REDDATA_BURQST);
        SWBUREQ_n = 1;
    }

#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    inline VOID NegateBackup(VOID) {
        ResetRedData(REDDATA_BURQST);
        SWBUREQ_n = 1;
    }
#endif

    inline UINT8 GetModStat2(VOID) { return ModStat2.BYTE; }
    inline UINT8 GetModStat3(VOID) { return ModStat3.BYTE; }
    inline VOID  SetModStat3 (BOOL bStatus) { ModStat3.OutCtl = bStatus; }
    
    //This function sets the IOM in Factory Mode when the REDUNT_n and BOTTOM signals have
    //appropiate states.The signal states chosen enusures that the IOMs are not put to 
    //Factory Mode inadverently.
    inline VOID SetFactoryTestMode(){
        #if !AIAO
        RDBK_SEL = RDBK_IOTA;          // Select proper bank for to read the BOTTOM & REDUNT_n
        #endif // !AIAO
               
#if !defined(IOPTYPE_SCIOM)
        // as per legacy,   FTA_MISSING,              IOPB (SEC)      & SWITCHED=0(SWITCH=FALSE),sets the IOP in Factory Test mode.
        // as per redesign, REDUNT_n=1 (FTA missing), BOTTOM=0 (IOPB) & BUPREQ_IN=0(SWITCHED=0), sets the IOP in Factory Test Mode.
        if ((REDUNT_n)   // FTA missing status
#if defined(IOPTYPE_DI) || defined(IOPTYPE_DO)           
        && (BOTTOM)
#else //for HLAI & AO16
        && !(BOTTOM)     // IOPB
#endif
        && !(BUPREQ_IN)) // LOW
#else
        //REDUNT_n = 0 and BOTTOM = 1 sets the IOM in Factory Test Mode. 
        if(!(REDUNT_n) &&  //Should be Low
            (BOTTOM))      //Should be High
#endif        
        ModStat1.Factory =1; //IOM is in Factory Test Mode
    }

#ifdef DEBUG
    inline HWINFO *GetHardwareInfo(VOID) { return &HwInfo; }
#endif

    inline VOID SetTstFunctTime(INT32 Time){TstFunctTime = Time;}

    inline VOID SetTstFunctTimeStsToFail(VOID){TstFunctTime = -1;}

    inline VOID ResetTstFunctTime(VOID){TstFunctTime = 0;}

    inline VOID *GetCPLDRegDataPtr(VOID){return &CPLDRegData;}

    inline UINT8 GetPld1RevLetter(VOID) {return HwInfo.Pld1RevLetter;}

    inline UINT8 GetPld2RevLetter(VOID) {return HwInfo.Pld2RevLetter;}

    inline UINT16 GetProductCode(VOID) {return HwInfo.ProductCode;}

#ifdef DEBUG
    inline INT32 GetTstFunctTime(VOID){return TstFunctTime;}
#endif

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
    inline VOID SetLpBkStatXmtModem(UINT8 XmtModem){
        XmtModem <<= LPBKSTAT_RCVCHNLENDBIT;
        LpBkStat |= XmtModem;
    }

    inline VOID SetLpBkStatRcvModem(UINT8 RcvModem){
        RcvModem <<= LPBKSTAT_CHNLENDBIT;  
        LpBkStat |= RcvModem;
    }

    inline VOID SetLpBkStatChan(UINT8 Chan){LpBkStat |= Chan;}
#endif

#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_UIO))
    inline VOID SetLpBkStat(HARTLPBKSTAT Sts){LpBkStat = (UINT8)Sts;}
    inline HARTLPBKSTAT GetLpBkStat(VOID) { return (HARTLPBKSTAT)LpBkStat; }
#endif

#if defined (IOMTYPE_UIO)
    BOOL PassthroughInQueue(UINT8 modem);
    UINT8 ChannelsWithPassthrough(UINT8 modem);
    VOID SearchForPassthrough(UINT8 modem, BOOL bB2BCountUpdate = TRUE);
#endif

};
#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
/*******************************************************************************
*                                  clsEeprom                                   *
*                                  =========                                   *
*******************************************************************************/
class clsEeprom {
public:
    clsEeprom(VOID) {
#if LOWCOST
        EEP_CS = 1;
#else
        // Initialize FPGA Interrrupt registers (IE, GE)
        EEPROM_SPI.CRL = 0x86;          // Enable SPI system in master manual mode.
        EEPROM_SPI.CRH = 0x00;          // Enable master transaction.
        EEPROM_SPI.SSR = SS_DESELECT;   // Deassert both slave selects.
#endif
    }
    ~clsEeprom(VOID) { HardFail(HF_INVPROGRAMEXEC,BOXSLOT_HPP,__LINE__); }

    VOID *operator new (SIZE_T)  { return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,BOXSLOT_HPP,__LINE__); }

    VOID    EnableWrite(VOID);
    VOID    DisableWrite(VOID);
    UINT8   ReadStatusRegister(VOID);
    VOID    CheckWriteInProgress(VOID);
    UINT8   ReadByte(UINT16);
    UINT16  ReadUint16(UINT16);
    UINT32  ReadUint32(UINT16);
    FLOAT32 ReadFloat(UINT16);
    VOID    WriteByte(UINT16,UINT8);
    VOID    WritePage(UINT16,UINT8 *);
    UINT16  ComputeEepromChecksum(VOID);
    BOOL    ValidateEepromChecksum(VOID);
#if LOWCOST
    BOOL    SendCommand(UINT8 ucCmd);   // Send an Instruction
    UINT8   ReadResponse(VOID);         // Read Serial Data
    inline  VOID ChipSelect(VOID){EEP_CS = 0;}
    inline  VOID ChipDeselect(VOID){EEP_CS = 1;}
#endif

};  // clsEeprom
#endif
#endif //BOXSLOT_HPP
