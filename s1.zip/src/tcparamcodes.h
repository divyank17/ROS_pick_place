////////////////////////////////////////////////////////////////////////////////
//
//                          COPYRIGHT (C) 2010
//               HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS 
//                         ALL RIGHTS RESERVED
//
//    This software is a copyrighted work and/or information protected as a
//    trade secret.  Legal rights of Honeywell Inc. in this software is
//    distinct from ownership of any medium in which the software is embodied.
//    Copyright or trade secret notices included must be reproduced in any
//    copies authorized by Honeywell Inc.
//
//    The information in this software is subject to change without notice and
//    should not be considered as a commitment by Honeywell Industrial
//    Automation and Controls Division.
//
//    File Name  : tcparamcodes.h
//
//    Description: SP and SVP IOM common definitions.
//
////////////////////////////////////////////////////////////////////////////////
#ifndef TC_PARAMCODES_H
#define TC_PARAMCODES_H

#define kPnPtExecSt         52
#define kPnSlotChkPnt       114

////////////////////////////////////////////////////////////////////////////////
// Common Box Level Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmPmBoxVarId
{
  //{--------------------------------------------------}
  //{             Individual Parameters                }
  //{--------------------------------------------------}
  kSiomPnBX_SF_Bits     = 51,
  kSiomPnBX_SF_LRS      = 52,
  kSiomPnCirc_List_St   = 53,
  kSiomPnComm_Err       = 54,
  kSiomPnCommStat       = 55,
  kSiomPnDPA_EXT        = 56,
  kSiomPnDSA_EXT        = 57,
  kSiomPnEvnt_App_Ptr   = 58,
  kSiomPnEvnt_Rem_ptr   = 59,
  kSiomPnBA_EXT         = 60,
  kSiomPnSYNCVER        = 61,
  kSiomPnFailCode       = 62,
  kSiomPnHWRevCod       = 63,
  kSiomPnIOLDevTy       = 64,
  kSiomPnLastFail       = 65,
  kSiomPnMes_No         = 66,
  kSiomPnModStat1       = 67,
  kSiomPnModStat2       = 68,
  kSiomPnModlType       = 69,
  kSiomPnNTH_Ext        = 70,
  kSiomPnSuprCtrl       = 71,
  kSiomPnSWRevCod       = 72,
  kSiomPnToknStll       = 73,
  kSiomPnTstFunct       = 74,
  kSiomPnSF_INFO_300    = 75,
  // IOP DIAG DISPLAY
  kSiomPnWITHBIAS       = 76,
  kSiomPnREDDATA        = 77,
  kSiomPnDBVALID        = 78,
  kSiomPnSF_ACTION_TBL  = 79,

  //{--------------------------------------------------}
  //{  application slot zero parameters start here     }
  //{--------------------------------------------------}
  kSiomPnCalib1         = 80,
  kSiomPnCalib2         = 81,

  // kSiomPnCalib1 is known as either CALIBALL or CALIBFTA1 in the HPM parameter dictionary.
  // kSiomPnCalib2 is known as either CAIBRJ or CALIBFTA2 in the HPM parameter dictionary.

  kSiomPnFreq6050       = 82,
  kSiomPnLinePerd       = 83,
  kSiomPnOTDenBl        = 84,
  kSiomPnRJRaw          = 85,
  kSiomPnRjGrad         = 86,
  kSiomPnRjConst        = 87,
  kSiomPnTestChan       = 88,
  kSiomPnR_PriSt        = 89,
  kSiomPnR_SecSt        = 90,
  kSiomPnFAILOPT        = 91,
  kSiomPnSOALL          = 92,
  kSiomPnFTA1TYPE       = 93,
  kSiomPnFTA2TYPE       = 94,
  kSiomPnRJTEMP         = 95,
  kSiomPnR_PriSt_400    = 96,
  kSiomPnR_SecSt_400    = 97,
  kSiomPnAppl_Spr10     = 98,
  kSiomPnAppl_Spr11     = 99,
  kSiomPnNrOfDIs        = 100,
  kSiomPnPVAll          = 101,
  kSiomPnPVCH_App_Ptr   = 102,
  kSiomPnPVCH_Rem_Ptr   = 103,
  kSiomPnPVSTALL        = 104,
  kSiomPnPVSTALM        = 105,
  kSiomPnIOPSTR1        = 106,
  kSiomPnIOPSTR2        = 107,
  kSiomPnIOPSTR3        = 108,
  kSiomPnIOPSTR4        = 109,
  kSiomHARTPnHAUTODET   = 110,
  kSiomPnPvScanRec2     = 111,  // Series C LLMUX channels 33-64
  kSiomPnPLRevCode      = 112,
  kSiomPnLPBKSTAT       = 113,  // Loop back Status, not used in Experion
  kSiomHARTPnHLPRFAIL   = 114,  // HART Last Processor Fail code
  kSiomPnIOPDESC        = 115,
  kSiomPnMAXSLOTS       = 116,
  kSiomPnCURPIID        = 117,
  kSiomPnCURPINAM       = 118,
  kSiomPnAPPL1          = 119,
  kSiomPnAPPL2          = 120,
  //                    = 121,  is available
  kSiomHARTPnHGCHNG1    = 122,
  kSiomPnLSEQNUMR       = 123,
  kSiomHARTPnHCUAVAIL   = 124,
  kSiomPnPERSLOCK       = 125,
  kSiomPnPERSREV        = 126,
  kSiomPnPERSVER        = 127,
  kSiomPnUCNLDIOP       = 128,
  kSiomPnBLK_INFO       = 129,
  kSiomPnPN_INFO        = 130,
  kSiomPnPNAMIOPA       = 131,
  kSiomPnPNAMIOPB       = 132,
  kSiomPnTESTPARAM      = 133,  // Test parameter to support additional debugging information from SP-IOM and SVP-IOM
  kSiomPnIOPPIDAT       = 134,
  kSiomPnBXChkPnt       = 143,  // For Box Slot Checkpoint
  kSiomPnBRDP           = 151,
  kSiomPnOPSCANREC      = 152,
  kSiomPnChkPntChkSum   = 158,  // For Checkpoint Checksum
  kSiomPnCPUFreeAvg     = 159,
  kSiomPnCPUFreeMin     = 160,
  kSiomPnStatReset      = 161,
  kSiomPnIOMTracelog    = 165,  //Will be a Indexed Parameter for IOM Tracelogs
  kSiomPnIOMTraceInfo   = 166,
  kSiomPnIOMTraceFlag   = 167,
  kSiomPnDIMODE              = 168, // Sample rate for the DI_SOE IOM only
  kSiomPnSTMCHOVRRUNS        = 171, // SOE ISR Overruns, only in Series CIO DI_SOE module
  kSiomPnSTMCHMAXOVRRUNTIME  = 172, // SOE ISR Last Overrun Time, only in Series CIO DI_SOE module
  kSiomPnSTMCHLASTOVRRUNTIME = 173, // SOE ISR Max Overrun Time, only in Series CIO DI_SOE module
  kSiomPnRSTSTMCHOVRRUNDATA  = 174, // Reset the SOE ISR overun data to zero
  kSiomSvpPnBackCalc         = 175, // For BackCalc Scan request for SVP IO Module
  kSiomSvpPnProcessData      = 176, // For Process Data Scan request for SVP IO Module
  kSiomSvpPnExcitFreq        = 177, // Excitation frequecy for SVP Module
  kSiomSpPnInputProcessData  = 178, // For Input Process Data Scan request for SP IO Module
  kSiomPnIolProcCPUFreeAvg   = 179, // Iolink Processor Avgerage CPU Free parameter for SVP and SP Module
  kSiomPnIolProcCPUFreeMax   = 180, // Iolink Processor Maximum CPU Free parameter for SVP and SP Module
  kSiomPnIolProcCPUFreeMin   = 181, // Iolink Processor Minimum CPU Free parameter for SVP and SP Module 
  kSiomPnIolProcStatReset    = 182, // Iolink Processor Statistic Reset parameter for SVP and SP Module 
  kSiomPnAppProcCPUFreeAvg   = 183, // Application Processor Avgerage CPU Free parameter for SVP and SP Module
  kSiomPnAppProcCPUFreeMax   = 184, // Application Processor Maximum CPU Free parameter for SVP and SP Module
  kSiomPnAppProcCPUFreeMin   = 185, // Application Processor Minimum CPU Free parameter for SVP and SP Module 
  kSiomPnAppProcStatReset    = 186, // Application Processor Statistic Reset parameter for SVP and SP Module 
  kSiomSpPnOutputProcessData = 187, // For Output Process Data Scan request for SP IO Module
  kSiomSpPnRevRotChnlA       = 188, // Reverse rotation Channel A parameter for SP Module
  kSiomSpPnRevRotChnlB       = 189, // Reverse rotation Channel B parameter for SP Module
  kSiomSpPnCalibOpt          = 190, // Cabilation Option parameter for SVP and SP Module
  kSiomPnResetTrip           = 191, // Reset Trip parameter for SP Module
  kSiomPnLastTripReason      = 192, // Last Trip Reason parameter for SP Module
  kSiomPnLastTripTime        = 193, // Last Trip Time parameter for SP Module
  kSiomSpPnRevRotFl          = 194, // SP IOM Reverse Rotation Flag
  kSiomSvpPnBackUpPvScanRec  = 195, // PV from SVP-AI channels of Secondary SVP IOM
  kSiomConfigProverSignal    = 196, // Configured Prover Signal channel
  kSiomActualProverSignal    = 197, // Actual Prover Signal channel selected
  kSiomMaintainOnFault       = 198, // Upon a fault maintain or de-select the current Prover Signal channel.
  kSiomPimPvScanRec1         = 199, // PIM PV Scan record 1
  kSiomPimPvScanRec2         = 200, // PIM PV Scan record 2
  kSiomSvpPnServoDriveOption = 201,  // Servo Drive Option

  kSiomBoxChkPntVer          = 243  // Chect Version Number
};

////////////////////////////////////////////////////////////////////////////////
// SVP AI IOP Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSvpModuleAiVarId
{
  //Individual Parameters
  kSvpAiPnFiltOut             = 50, // 0-50 is not used any where (even in c300), So this param code is used for internal Parameter data updation between App processor and IOLINK Processor
  kSvpAiPnPntType             = 51,
  kSvpAiPnPtExecSt            = 52,
  kSvpAiPnLastPv              = 53,
  kSvpAiPnLoCutoff            = 54, 
  kSvpAiPnBadPvFl             = 55,
  kSvpAiPnInptDir             = 56,
  kSvpAiPnPv                  = 57,
  kSvpAiPnPvAuto              = 58,
  kSvpAiPnPvAutoSt            = 59,
  kSvpAiPnPvCalc              = 60, 
  kSvpAiPnPvChar              = 61,
  kSvpAiPnPvClamp             = 62,
  kSvpAiPnPvEUHi              = 63,
  kSvpAiPnPvEULo              = 64,
  kSvpAiPnPvExEUHi            = 65, 
  kSvpAiPnPvExEULo            = 66, 
  kSvpAiPnPvExHiFL            = 67,
  kSvpAiPnPvExLoFL            = 68, 
  kSvpAiPnPvP                 = 69,
  kSvpAiPnPvRaw               = 70, 
  kSvpAiPnPvSource            = 71,
  kSvpAiPnPvSrcOpt            = 72,
  kSvpAiPnPvSts               = 73, 
  kSvpAiPnPvTv                = 74,
  kSvpAiPnPvTvP               = 75, 
  kSvpAiPnSensrTyp            = 76,
  kSvpAiPnTf                  = 77,
  kSvpAiPnOwdEnbl             = 78,
  // Spare
  kSvpAiPnExVol               = 80, 
  kSvpAiPnTxWireSel           = 81,
  kSvpAiPnVdtMode             = 82,
  // Spare
  kSvpAiPnExcitnAmpFl         = 84,
  kSvpAiPnExcitnOwdFl         = 85,
  kSvpAiPnExcitnShtcktFl      = 86,
  kSvpAiPnExcitnFbOwdFl       = 87,
  kSvpAiPnExcitnFbShtcktFl    = 88,
  kSvpAiPnCalibVal            = 89,
  kSvpAiPnValCalibEnb         = 90,
  kSvpAiPnValCalibSts         = 91,
  kSvpAiPnEXECFBARMSVOL       = 92,
  kSvpAiPnEXECFBBRMSVOL       = 93,
  kSvpAiPnEXECRMSVOL          = 94,
  kSvpAiPnActualAngle         = 95,
  kSvpAiPnApplyOffset         = 96,
  kSvpAiPnAngleOffset         = 97,
  kSvpAiPnChkPnt              = 114,    

  kSvpAiPnChkPntVer           = 142
};

////////////////////////////////////////////////////////////////////////////////
// SVP AO IOP Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSvpModuleAoVarId
{
  //Individual Parameters
  kSvpAoPnPntType             = 51,
  kSvpAoPnPtExecSt            = 52,
  kSvpAoPnModeAttr            = 53,
  kSvpAoPnMode                = 54, 
  kSvpAoPnModePerm            = 55,
  kSvpAoPnNModeAttr           = 56,
  kSvpAoPnNMode               = 57,
  kSvpAoPnOp                  = 58,
  kSvpAoPnOpChar              = 59, 
  kSvpAoPnOpFinal             = 60,
  kSvpAoPnOpIn0               = 61, 
  kSvpAoPnOpIn1               = 62,
  kSvpAoPnOpIn2               = 63, 
  kSvpAoPnOpIn3               = 64,
  kSvpAoPnOpIn4               = 65,
  kSvpAoPnOpIn5               = 66,
  kSvpAoPnOpOut0              = 67, 
  kSvpAoPnOpOut1              = 68,
  kSvpAoPnOpOut2              = 69,
  kSvpAoPnOpOut3              = 70,
  kSvpAoPnOpOut4              = 71,
  kSvpAoPnOpOut5              = 72, 
  kSvpAoPnOptDir              = 73,
  kSvpAoPnRedTag              = 74, 
  kSvpAoPnSlotSfBt            = 75,
  kSvpAoPnStdByMan            = 76, 
  // Spare
  kSvpAoPnInitReq             = 78, 
  kSvpAoPnFaultOpt            = 79,
  kSvpAoPnFaultValue          = 80, 
  kSvpAoPnFaultState          = 81, 
  kSvpAoPnSlotSfLrs           = 82,
  kSvpAoPnB0_LInv             = 83,
  kSvpAoPnB1_LInv             = 84, 
  kSvpAoPnOpInternal          = 85,
  kSvpAoPnB0_L                = 86,
  kSvpAoPnB1_L                = 87,
  kSvpAoPnB0_O                = 88, 
  kSvpAoPnB1_O                = 89,
  kSvpAoPnOutDACImg           = 90,
  kSvpAoPnChrc_S0             = 92,
  kSvpAoPnChrc_S1             = 93,
  kSvpAoPnChrc_S2             = 94,
  kSvpAoPnChrc_S3             = 95,
  kSvpAoPnChrc_S4             = 96,
  kSvpAoPnOTPT_Unused         = 97, 
  kSvpAoPnB0_Inv              = 98,
  kSvpAoPnB1_Inv              = 99,
  kSvpAoPnOptType             = 100,    
  kSvpAoPnDitherFreq          = 101,    
  kSvpAoPnDitherAmpl          = 102,
  kSvpAoPnInLckFlOpt1         = 103,
  kSvpAoPnInLckFlOpt2         = 104,
  kSvpAoPnInSelPrcIntLck1     = 105,    
  kSvpAoPnInSelPrcIntLck2     = 106,    
  kSvpAoPnPrcSafeOp1          = 107,
  kSvpAoPnPrcSafeOp2          = 108,
  kSvpAoPnOpBiasCurrent       = 109,
  kSvpAoPnOpConn              = 110,
  kSvpAoPnOpAction            = 111,
  kSvpAoPnOpHiCurrent         = 112,
  kSvpAoPnOpLoCurrent         = 113,
  kSvpAoPnChkPnt              = 114,
  kSvpAoPnStrokEnb            = 115,
  kSvpAoPnInitVal             = 116,
  kSvpAoSecDiagEnb            = 117,
  kSvpAoSecDiagCurr           = 118,
  kSvpAoIntrLck1Sts           = 119,
  kSvpAoIntrLck2Sts           = 120,
  kSvpAoDitherWaveform        = 121,

  kSvpAoPnChkPntVer           = 142,
  kSvpAoPnCommFailFl          = 164
};

////////////////////////////////////////////////////////////////////////////////
// SVP & SP DI IOP Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSvpModuleDiVarId
{
  //Individual Parameters
  kDiPnPntType             = 51,
  kDiPnPtExecSt            = 52,
  kDiPnBadPvFl             = 53,
  kDiPnInptDir             = 54,
  kDiPnLastDiPv            = 55,
  kDiPnDiPv                = 56,
  kDiPnDiPvAuto            = 57,
  kDiPnDiPvRaw             = 58, 
  kDiPnPvSource            = 59,
  kDiPnPvSrcOpt            = 60, 
  kDiPnOwdEnbl             = 61,
  kDiPnDiType              = 62, 
  kDiPnDiPvFlWrst          = 63,
  kDiPnLatchTimer          = 64, 
  //Spare                  = 65,
  //Spare                  = 66,
  kDiPnSlotSfBt            = 67,
  kDiPnSlotSfLrs           = 68,
  kDiPnChkPnt              = 114,

#ifdef IOMTYPE_SVP
  kDiPnChkPntVer           = 142
#elif IOMTYPE_SP
  kDiPnChkPntVer           = 244
#endif
};

////////////////////////////////////////////////////////////////////////////////
// SVP Regulatory Control Block Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSvpModuleRegCtlVarId
{
  //Individual Parameters
  kSvpRegCtlPnPntType             = 51, 
  kSvpRegCtlPnPtExecSt            = 52, 
  kSvpRegCtlPnPvEUHi              = 53,
  kSvpRegCtlPnPvEULo              = 54,
  kSvpRegCtlPnModeAttr            = 55,
  kSvpRegCtlPnMode                = 56, 
  kSvpRegCtlPnModePerm            = 57,
  kSvpRegCtlPnNormModeAttr        = 58, 
  kSvpRegCtlPnNormMode            = 59,
  kSvpRegCtlPnOp                  = 60,
  kSvpRegCtlPnRedTag              = 61,
  // Spare
  kSvpRegCtlPnInitVal             = 64,
  kSvpRegCtlPnPrefPv              = 65,
  kSvpRegCtlPnCtlEqn              = 66, 
  kSvpRegCtlPnCtlActn             = 67, 
  kSvpRegCtlPnT1                  = 68, 
  kSvpRegCtlPnT1HiLm              = 69,     
  kSvpRegCtlPnT1LoLm              = 70,
  kSvpRegCtlPnT2                  = 71, 
  kSvpRegCtlPnT2HiLm              = 72, 
  kSvpRegCtlPnT2LoLm              = 73,
  kSvpRegCtlPnGainHiLm            = 74, 
  kSvpRegCtlPnGainLoLm            = 75,
  kSvpRegCtlPnGainOpt             = 76,
  kSvpRegCtlPnK                   = 77, 
  kSvpRegCtlPnEqnEUnitsOpt        = 78, 
  kSvpRegCtlPnSp                  = 79,
  kSvpRegCtlPnSpHiLm              = 80, 
  kSvpRegCtlPnSpLoLm              = 81,
  kSvpRegCtlPnTmOutMode           = 82,
  kSvpRegCtlPnTmOutTime           = 83,     
  kSvpRegCtlPnSpTol               = 84,  
  kSvpRegCtlPnPvTrakOpt           = 85, 
  kSvpRegCtlPnPvTrakOptAi         = 86,
  kSvpRegCtlPnOpHiLm              = 87, 
  kSvpRegCtlPnOpLoLm              = 88,
  kSvpRegCtlPnOpExHiLm            = 89, 
  kSvpRegCtlPnOpExLoLm            = 90,
  kSvpRegCtlPnOpMinChg            = 91,
  kSvpRegCtlPnCvEUHi              = 92,
  kSvpRegCtlPnCvEULo              = 93, 
  kSvpRegCtlPnOpBias_Fix          = 94,
  kSvpRegCtlPnSafeOp              = 95,
  kSvpRegCtlPnOpTol               = 96,
  kSvpRegCtlPnOutInd              = 97, 
  kSvpRegCtlPnBadCtlOpt           = 98, 
  kSvpRegCtlPnPv1                 = 99,
  kSvpRegCtlPnPv2                 = 100,    
  kSvpRegCtlPnPv1Conn             = 101,
  kSvpRegCtlPnPv2Conn             = 102,
  kSvpRegCtlPnBadCtlFl            = 103,
  kSvpRegCtlPnCv                  = 104,
  kSvpRegCtlPnInitMan             = 105,    
  kSvpRegCtlPnLastGoodPv          = 106,
  kSvpRegCtlPnOpBias              = 107,
  kSvpRegCtlPnOpEu                = 108,
  kSvpRegCtlPnOpHiFl              = 109,    
  kSvpRegCtlPnOpLoFl              = 110,
  kSvpRegCtlPnOpExHiFl            = 111,
  kSvpRegCtlPnOpExLoFl            = 112,    
  kSvpRegCtlPnSpHiFl              = 113,
  kSvpRegCtlPnChkPnt              = 114,  
  kSvpRegCtlPnCtlInit             = 115,    
  kSvpRegCtlPnCtlState            = 116,        
  kSvpRegCtlPnArwNet              = 117,
  kSvpRegCtlPnArwOp               = 118,            
  kSvpRegCtlPnSecInitVal          = 119,     
  kSvpRegCtlPnSecInitSts          = 120,
  kSvpRegCtlPnSecArwSts           = 121,    
  kSvpRegCtlPnPriInitVal          = 122,
  kSvpRegCtlPnPriInitSts          = 123,
  kSvpRegCtlPnPriArwSts           = 124,
  kSvpRegCtlPnBadPvFl             = 125,
  kSvpRegCtlPnPv                  = 126, 
  kSvpRegCtlPnOpBias_Rate         = 127,    
  kSvpRegCtlPnPvSts               = 128,
  kSvpRegCtlPnPv1Sts              = 129,
  kSvpRegCtlPnPv2Sts              = 130,    
  kSvpRegCtlPnTmOutFl             = 131,
  kSvpRegCtlPnSpLoFl              = 132,
  kSvpRegCtlPnInitReq             = 133,
  kSvpRegCtlPnPvSel               = 134,
  kSvpRegCtlPnOpBias_Float        = 135,
  kSvpRegCtlPnTimeoutCount        = 136,

  kSvpRegCtlPnChkPntVer           = 142
};


////////////////////////////////////////////////////////////////////////////////
// SP AI IOP Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSpModuleAiVarId
{ 
  //Individual Parameters 
  kSpAiPnPntType             = 51,
  kSpAiPnPtExecSt            = 52,
  kSpAiPnBadPvFl             = 53,
  kSpAiPnInptDir             = 54,
  kSpAiPnLastPv              = 55,
  kSpAiPnLoCutOff            = 56,
  kSpAiPnPv                  = 57,
  kSpAiPnPvAuto              = 58,
  kSpAiPnPvAutoSt            = 59,
  kSpAiPnPvCalc              = 60,
  kSpAiPnPvChar              = 61,
  kSpAiPnPvClamp             = 62,
  kSpAiPnPvEUHi              = 63,
  kSpAiPnPvEULo              = 64,
  kSpAiPnPvExEUHi            = 65,
  kSpAiPnPvExEULo            = 66,
  kSpAiPnPvExHiFl            = 67,
  kSpAiPnPvExLoFl            = 68,
  kSpAiPnPvP                 = 69,
  kSpAiPnPvRaw               = 70,
  kSpAiPnPvSource            = 71,
  kSpAiPnPvSrcOpt            = 72,
  kSpAiPnPvSts               = 73,
  kSpAiPnPvTv                = 74,
  kSpAiPnPvTvP               = 75,
  kSpAiPnSensrTyp            = 76,
  kSpAiPnTf                  = 77,
  kSpAiPnOwdEnable           = 78,
  //Spare                    = 79,
  //Spare                    = 80,
  kSpAiPnSlotSfBt            = 81,

  kSpAiPnChkPnt              = 114,
  kSpAiPnChkPntVer           = 244
};

////////////////////////////////////////////////////////////////////////////////
// SP AO IOP Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSpModuleAoVarId
{
  //Individual Parameters 
  kSpAoPnPntType             = 51,
  kSpAoPnPtExecSt            = 52,
  kSpAoPnLocalMan            = 53,
  kSpAoPnModeAttr            = 54,
  kSpAoPnMode                = 55,
  kSpAoPnModePerm            = 56,
  kSpAoPnNModeAttr           = 57,
  kSpAoPnNMode               = 58,
  kSpAoPnOp                  = 59,
  kSpAoPnOpChar              = 60,
  kSpAoPnOpFinal             = 61,
  kSpAoPnOpIn0               = 62,
  kSpAoPnOpIn1               = 63,
  kSpAoPnOpIn2               = 64,
  kSpAoPnOpIn3               = 65,
  kSpAoPnOpIn4               = 66,
  kSpAoPnOpIn5               = 67,
  kSpAoPnOpOut0              = 68,
  kSpAoPnOpOut1              = 69,
  kSpAoPnOpOut2              = 70,
  kSpAoPnOpOut3              = 71,
  kSpAoPnOpOut4              = 72,
  kSpAoPnOpOut5              = 73,
  kSpAoPnOptDir              = 74,
  kSpAoPnRedTag              = 75,
  kSpAoPnStdbyMan            = 76,
  kSpAoPnAosData             = 77,
  kSpAoPnSecData             = 78,
  kSpAoPnInitReq             = 79,
  kSpAoPnFaultOpt            = 80,
  kSpAoPnFaultValue          = 81,
  kSpAoPnFaultState          = 82,
  kSpAoPnB0_Linv             = 83,
  kSpAoPnB1_Linv             = 84,
  kSpAoPnOpIntrnal           = 85,
  kSpAoPnB0_L                = 86,
  kSpAoPnB1_L                = 87,
  kSpAoPnB0_O                = 88,
  kSpAoPnB1_O                = 89,
  kSpAoPnOutdacimg           = 90,
  kSpAoPnCHRC_S0             = 91,
  kSpAoPnCHRC_S1             = 92,
  kSpAoPnCHRC_S2             = 93,
  kSpAoPnCHRC_S3             = 94,
  kSpAoPnCHRC_S4             = 95,
  kSpAoPnOTPT_UNUSED         = 96,
  kSpAoPnB0_INV              = 97,
  kSpAoPnB1_INV              = 98,
  kSpAoPnInitVal             = 99,
  kSpAoPnCommFail            = 100,
  kSpAoPnOpConn              = 101,
  //Spare                    = 102,
  //Spare                    = 103,
  kSpAoPnSlotSfBt            = 104,
  kSpAoPnSlotSfLrs           = 105,

  kSpAoPnChkPnt              = 114,
  kSpAoPnChkPntVer           = 244
};

////////////////////////////////////////////////////////////////////////////////
// SP DI IOP Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSpModuleDiVarId
{
  kSpDiPnPntType             = 51,
  kSpDiPnPtExecSt            = 52,
  kSpDiPnBadPvFl             = 53,
  kSpDiPnInptDir             = 54,
  kSpDiPnLastPv              = 55,
  kSpDiPnPv                  = 56,
  kSpDiPnPvAuto              = 57,
  kSpDiPnPvRaw               = 58,
  kSpDiPnPvSource            = 59,
  kSpDiPnPvSrcOpt            = 60,
  kSpDiPnOwdEnable           = 61,
  kSpDiPnDiType              = 62,
  kSpDiPnDiPvFlWrst          = 63,
  kSpDiPnLatchTimer          = 64,
  //Spare                    = 65,
  //Spare                    = 66,
  kSpDiPnSlotSfBt            = 67,
  kSpDiPnSlotSfLrs           = 68,

  kSpDiPnChkPnt              = 114,
  kSpDiPnSChkPntVer          = 244
};

////////////////////////////////////////////////////////////////////////////////
// SP DO IOP Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSpModuleDoVarId
{
  //Individual Parameters 
  kSpDoPnPntType             = 51,
  kSpDoPnPtExecSt            = 52,
  kSpDoPnLocalMan            = 53,
  kSpDoPnModeAttr            = 54,
  kSpDoPnMode                = 55,
  kSpDoPnModePerm            = 56,
  kSpDoPnNModeAttr           = 57,
  kSpDoPnNMode               = 58,
  kSpDoPnOp                  = 59,
  kSpDoPnOptDir              = 60,
  kSpDoPnRedTag              = 61,
  kSpDoPnStdbyMan            = 62,
  kSpDoPnSecData             = 63,
  kSpDoPnInitReq             = 64,
  kSpDoPnFaultOpt            = 65,
  kSpDoPnFaultValue          = 66,
  kSpDoPnFaultState          = 67,
  kSpDoPnDoType              = 68,
  kSpDoPnPeriod              = 69,
  kSpDoPnSo                  = 70,
  kSpDoPnOnPulse             = 71,
  kSpDoPnOffPulse            = 72,
  kSpDoPnPwminitr            = 73,
  kSpDoPnPrdtime             = 74,
  kSpDoPnPwmpulsetime        = 75,
  kSpDoPnStartNext           = 76,
  kSpDoPnTpStart             = 77,
  kSpDoPnTpend               = 78,
  kSpDoPnSoInitVal           = 79,
  kSpDoPnSoReadFail          = 80,
  kSpDoPnOpInitVal           = 81,
  kSpDoPnCommFailFl          = 82,
  kSpDoPnReadyToGo           = 83,
  kSpDoPnI1Conn              = 84,
  kSpDoPnI2Conn              = 85,
  kSpDoPnI3Conn              = 86,
  kSpDoPnI4Conn              = 87,
  kSpDoPnI5Conn              = 88,
  kSpDoPnI6Conn              = 89,
  kSpDoPnI7Conn              = 90,
  kSpDoPnI8Conn              = 91,
  //Spare                    = 92,
  //Spare                    = 93,
  kSpDoPnSlotSfBt            = 94,
  kSpDoPnSlotSfLrs           = 95,
  kSpDoPnI1                  = 96,
  kSpDoPnI2                  = 97,
  kSpDoPnI3                  = 98,
  kSpDoPnI4                  = 99,
  kSpDoPnI5                  = 100,
  kSpDoPnI6                  = 101,
  kSpDoPnI7                  = 102,
  kSpDoPnI8                  = 103,
  kSpDoPnI1InptDir           = 104,
  kSpDoPnI2InptDir           = 105,
  kSpDoPnI3InptDir           = 106,
  kSpDoPnI4InptDir           = 107,
  kSpDoPnI5InptDir           = 108,
  kSpDoPnI6InptDir           = 109,
  kSpDoPnI7InptDir           = 110,
  kSpDoPnI8InptDir           = 111,
  kSpDoPnLastTripSrc         = 112,
  kSpDoPnLastTripTimeInfo    = 113,
  kSpDoPnI1Sts               = 115,
  kSpDoPnI2Sts               = 116,
  kSpDoPnI3Sts               = 117,
  kSpDoPnI4Sts               = 118,
  kSpDoPnI5Sts               = 119,
  kSpDoPnI6Sts               = 120,
  kSpDoPnI7Sts               = 121,
  kSpDoPnI8Sts               = 122,

  kSpDoPnChkPnt              = 114,
  kSpDoPnChkPntVer           = 244
};

////////////////////////////////////////////////////////////////////////////////
// SP Speed IOP Parameters
////////////////////////////////////////////////////////////////////////////////

enum enmCioSpModuleSpdVarId
{
  //Individual Parameters 
  kSpSpdPnPv100               = 46,
  kSpSpdPnPntType             = 51,
  kSpSpdPnPtExecSt            = 52,
  kSpSpdPnBadPvFl             = 53,
  kSpSpdPnInptDir             = 54,
  kSpSpdPnLastPv              = 55,
  kSpSpdPnPv                  = 56,
  kSpSpdPnRocPV               = 57,
  kSpSpdPnPvAuto              = 58,
  kSpSpdPnPvAutoSt            = 59,
  kSpSpdPnPvCalc              = 60,
  kSpSpdPnPvClamp             = 61,
  kSpSpdPnPvEUHi              = 62,
  kSpSpdPnPvEULo              = 63,
  kSpSpdPnPvExEUHi            = 64,
  kSpSpdPnPvExEULo            = 65,
  kSpSpdPnPvExHiFl            = 66,
  kSpSpdPnPvExLoFl            = 67,
  kSpSpdPnPvP                 = 68,
  kSpSpdPnPvRaw               = 69,
  kSpSpdPnPvSource            = 70,
  kSpSpdPnPvSrcOpt            = 71,
  kSpSpdPnPvSts               = 72,
  kSpSpdPnPvTv                = 73,
  kSpSpdPnPvTvP               = 74,
  kSpSpdPnOwdEnable           = 75,
  kSpSpdPnSensrType           = 76,
  kSpSpdPnGearRatio           = 77,
  kSpSpdPnTeethCnt            = 78,
  kSpSpdPnEdgDetect           = 79,
  kSpSpdPnOwdFl               = 80,
  kSpSpdPnMisgpulFl           = 81,
  kSpSpdPnDefmpulFl           = 82,
  kSpSpdPnExcitfailFl         = 83,
  kSpSpdPnZerospdFl           = 84,
  kSpSpdPnRevrotFl            = 85,
  kSpSpdPnAlmEnb              = 86,
  kSpSpdPnPvhiAlm_Tp          = 87,
  kSpSpdPnPvhiAlm_Pr          = 88,
  kSpSpdPnPvhiAlm_Sr          = 89,
  kSpSpdPnPvhiAlm_Db          = 90,
  kSpSpdPnPvhiAlm_Dbu         = 91,
  kSpSpdPnPvhiAlm_Tm          = 92,
  kSpSpdPnPvhiAlm_Fl          = 93,
  kSpSpdPnPvhiAlm_Invert_Fl   = 94,
  kSpSpdPnPvHhAlm_Tp          = 95,
  kSpSpdPnPvHhAlm_Pr          = 96,
  kSpSpdPnPvHhAlm_Sr          = 97,
  kSpSpdPnPvHhAlm_Db          = 98,
  kSpSpdPnPvHhAlm_Dbu         = 99,
  kSpSpdPnPvHhAlm_Tm          = 100,
  kSpSpdPnPvHhAlm_Fl          = 101,
  kSpSpdPnPvHhAlm_Inv_Fl      = 102,
  kSpSpdPnPvHhAlm_Flwrst      = 103,
  kSpSpdPnPvHhAlm_Inv_Flwrst  = 104,
  kSpSpdPnRocPosHiAlm_Tp      = 105,
  kSpSpdPnRocPosHiAlm_Pr      = 106,
  kSpSpdPnRocPosHiAlm_Sr      = 107,
  kSpSpdPnRocPosHiAlm_Db      = 108,
  kSpSpdPnRocPosHiAlm_Dbu     = 109,
  kSpSpdPnRocPosHiAlm_Tm      = 110,
  kSpSpdPnRocPosHiAlm_Fl      = 111,
  kSpSpdPnRocPosHiAlm_Inv_Fl  = 112,
  kSpSpdPnRocPosHhAlm_Tp          = 113,
  kSpSpdPnRocPosHhAlm_Pr          = 126,
  kSpSpdPnRocPosHhAlm_Sr          = 115,
  kSpSpdPnRocPosHhAlm_Fl          = 116,
  kSpSpdPnRocPosHhAlm_Inv_Fl      = 117,
  kSpSpdPnRocPosHhAlm_Flwrst      = 118,
  kSpSpdPnRocPosHhAlm_Inv_Flwrst  = 119,
  kSpSpdPnRocNegHiAlm_Tp          = 120,
  kSpSpdPnRocNegHiAlm_Pr          = 121,
  kSpSpdPnRocNegHiAlm_Sr          = 122,
  kSpSpdPnRocNegHiAlm_Fl          = 123,
  kSpSpdPnRocPosLm                = 124,
  kSpSpdPnRocNegLm                = 125,
  kSpSpdPnFilterTime              = 127,
  kSpSpdPnSlotSfBt                = 128,
  kSpSpdPnCrSpeed                 = 129,
  kSpSpdPnNmSpeed                 = 130,
  kSpSpdPnLastRocNegLlDrcrSpd     = 131,
  kSpSpdPnLastRocPosHhDrnmSpd     = 132,
  kSpSpdMeasurementType           = 133,
  kSpSpdOrdrerOfKFactor           = 134,
  kSpSpdFirstOrderKFactor         = 135,
  kSpSpdMinFlowRate               = 136,
  kSpSpdKMinFlowRate              = 137,
  kSpSpdMaxFlowRate               = 138,
  kSpSpdKMaxFlowRate              = 139,
  kSpSpdTimeUnit                  = 140,
  kSpSpdResetPv                   = 141,
  //Spare

  kSpSpdPnChkPnt                  = 114,
  kSpSpdPnChkPntVer               = 244
};

////////////////////////////////////////////////////////////////////////////////
// SP Speed Voting Block Parameters
////////////////////////////////////////////////////////////////////////////////
enum enmCioSpModuleSpdVoteVarId
{ 
  kSpSpdVotPnGrp1VotChnbBlind    = 30,
  kSpSpdVotPnGrp2VotChnbBlind    = 31,

  //Individual Parameters 
  kSpSpdVotPnVotPv1P             = 45,
  kSpSpdVotPnVotPv2P             = 46,

  kSpSpdVotPnPntType             = 51,
  kSpSpdVotPnPtExecSt            = 52,
  kSpSpdVotPnVotAlgGrp1          = 53,
  kSpSpdVotPnVotAlgGrp2          = 54,
  kSpSpdVotPnGrp1VotChnb         = 55,
  kSpSpdVotPnGrp2VotChnb         = 56,
  kSpSpdVotPnGrp1NMin            = 57,
  kSpSpdVotPnGRP2NMin            = 58,
  kSpSpdVotPnMedOpt1             = 59,
  kSpSpdVotPnMedOpt2             = 60,
  kSpSpdVotPnVotPv1OvrtStEnb     = 61,
  kSpSpdVotPnVotPv2OvrtStEnb     = 62,
  kSpSpdVotPnGrp1IgnFl           = 63,
  kSpSpdVotPnGrp2IgnFl           = 64,
  kSpSpdVotPnGrp1IgnoredFl       = 65,
  kSpSpdVotPnGrp2IgnoredFl       = 66,
  kSpSpdVotPnVotPv1Sts           = 67,
  kSpSpdVotPnVotPv2Sts           = 68,
  kSpSpdVotPnVotRoc1Sts          = 69,
  kSpSpdVotPnVotRoc2Sts          = 70,
  kSpSpdVotPnLastVotPv1          = 71,
  kSpSpdVotPnLastVotPv2          = 72,
  kSpSpdVotPnLastVotRoc1         = 73,
  kSpSpdVotPnLastVotRoc2         = 74,
  kSpSpdVotPnVotPv1              = 75,
  kSpSpdVotPnVotPv2              = 76,
  kSpSpdVotPnVotRoc1             = 77,
  kSpSpdVotPnVotRoc2             = 78,
  kSpSpdVotPnResetTRIP           = 79,
  kSpSpdVotPnVotPvMax            = 80,
  kSpSpdVotPnVotPvOnTrip         = 81,
  kSpSpdVotPnVotRocPosHhOnTrip   = 82,
  // Spare                       = 83,
  // Spare                       = 84,
  kSpSpdVotPnCriticalSpeed       = 85,
  kSpSpdVotPnNorminalSpeed       = 86,
  kSpSpdVotPnAlmEnb              = 87,
  kSpSpdVotPnVotPv1hiAlm_Tp          = 88,
  kSpSpdVotPnVotPv1hiAlm_Pr          = 89,
  kSpSpdVotPnVotPv1hiAlm_Sr          = 90,
  kSpSpdVotPnVotPv1hiAlm_Db          = 91,
  kSpSpdVotPnVotPv1hiAlm_Dbu         = 92,
  kSpSpdVotPnVotPv1hiAlm_Tm          = 93,
  kSpSpdVotPnVotPv1hiAlm_Fl          = 94,
  kSpSpdVotPnVotPv1hiAlm_Invert_Fl   = 95,
  kSpSpdVotPnVotPv2hiAlm_Tp          = 96,
  kSpSpdVotPnVotPv2hiAlm_Pr          = 97,
  kSpSpdVotPnVotPv2hiAlm_Sr          = 98,
  kSpSpdVotPnVotPv2hiAlm_Db          = 99,
  kSpSpdVotPnVotPv2hiAlm_Dbu         = 100,
  kSpSpdVotPnVotPv2hiAlm_Tm          = 101,
  kSpSpdVotPnVotPv2hiAlm_Fl          = 102,
  kSpSpdVotPnVotPv2hiAlm_Invert_Fl   = 103,
  kSpSpdVotPnVotPv1HhAlm_Tp          = 104,
  kSpSpdVotPnVotPv1HhAlm_Pr          = 105,
  kSpSpdVotPnVotPv1HhAlm_Sr          = 106,
  kSpSpdVotPnVotPv1HhAlm_Db          = 107,
  kSpSpdVotPnVotPv1HhAlm_Dbu         = 108,
  kSpSpdVotPnVotPv1HhAlm_Tm          = 109,
  kSpSpdVotPnVotPv1HhAlm_Fl          = 110,
  kSpSpdVotPnVotPv1HhAlm_Inv_Fl      = 111,
  kSpSpdVotPnVotPv1HhAlm_Flwrst      = 112,
  kSpSpdVotPnVotPv1HhAlm_Inv_Flwrst  = 113,
  kSpSpdVotPnVotPv2HhAlm_Tp          = 174,
  kSpSpdVotPnVotPv2HhAlm_Pr          = 115,
  kSpSpdVotPnVotPv2HhAlm_Sr          = 116,
  kSpSpdVotPnVotPv2HhAlm_Db          = 117,
  kSpSpdVotPnVotPv2HhAlm_Dbu         = 118,
  kSpSpdVotPnVotPv2HhAlm_Tm          = 119,
  kSpSpdVotPnVotPv2HhAlm_Fl          = 120,
  kSpSpdVotPnVotPv2HhAlm_Inv_Fl      = 121,
  kSpSpdVotPnVotPv2HhAlm_Flwrst      = 122,
  kSpSpdVotPnVotPv2HhAlm_Inv_Flwrst  = 123,
  kSpSpdVotPnVotRoc1PosHiAlm_Tp          = 124,
  kSpSpdVotPnVotRoc1PosHiAlm_Pr          = 125,
  kSpSpdVotPnVotRoc1PosHiAlm_Sr          = 126,
  kSpSpdVotPnVotRoc1PosHiAlm_Fl          = 127,
  kSpSpdVotPnVotRoc1PosHiAlm_Inv_Fl      = 128,
  kSpSpdVotPnVotRoc2PosHiAlm_Tp          = 129,
  kSpSpdVotPnVotRoc2PosHiAlm_Pr          = 130,
  kSpSpdVotPnVotRoc2PosHiAlm_Sr          = 131,
  kSpSpdVotPnVotRoc2PosHiAlm_Fl          = 132,
  kSpSpdVotPnVotRoc2PosHiAlm_Inv_Fl      = 133,
  kSpSpdVotPnVotRoc1PosHhAlm_Tp          = 134,
  kSpSpdVotPnVotRoc1PosHhAlm_Pr          = 135,
  kSpSpdVotPnVotRoc1PosHhAlm_Sr          = 136,
  kSpSpdVotPnVotRoc1PosHhAlm_Fl          = 137,
  kSpSpdVotPnVotRoc1PosHhAlm_Inv_Fl      = 138,
  kSpSpdVotPnVotRoc1PosHhAlm_Flwrst      = 139,
  kSpSpdVotPnVotRoc1PosHhAlm_Inv_Flwrst  = 140,
  kSpSpdVotPnVotRoc2PosHhAlm_Tp          = 141,
  kSpSpdVotPnVotRoc2PosHhAlm_Pr          = 142,
  kSpSpdVotPnVotRoc2PosHhAlm_Sr          = 143,
  kSpSpdVotPnVotRoc2PosHhAlm_Fl          = 144,
  kSpSpdVotPnVotRoc2PosHhAlm_Inv_Fl      = 145,
  kSpSpdVotPnVotRoc2PosHhAlm_Flwrst      = 146,
  kSpSpdVotPnVotRoc2PosHhAlm_Inv_Flwrst  = 147,
  kSpSpdVotPnVotRoc1NegHiAlm_Tp          = 148,
  kSpSpdVotPnVotRoc1NegHiAlm_Pr          = 149,
  kSpSpdVotPnVotRoc1NegHiAlm_Sr          = 150,
  kSpSpdVotPnVotRoc1NegHiAlm_Fl          = 151,
  kSpSpdVotPnVotRoc1NegHiAlm_Inv_Fl      = 152,
  kSpSpdVotPnVotRoc2NegHiAlm_Tp          = 153,
  kSpSpdVotPnVotRoc2NegHiAlm_Pr          = 154,
  kSpSpdVotPnVotRoc2NegHiAlm_Sr          = 155,
  kSpSpdVotPnVotRoc2NegHiAlm_Fl          = 156,
  kSpSpdVotPnVotRoc2NegHiAlm_Inv_Fl      = 157,
  kSpSpdVotPnVotRoc1PosAlm_Tp            = 158,
  kSpSpdVotPnVotRoc1PosAlm_Lm            = 159,
  kSpSpdVotPnVotRoc2PosAlm_Tp            = 160,
  kSpSpdVotPnVotRoc2PosAlm_Lm            = 161,
  kSpSpdVotPnVotRoc1NegAlm_Tp            = 162,
  kSpSpdVotPnVotRoc1NegAlm_Lm            = 163,
  kSpSpdVotPnVotRoc2NegAlm_Tp            = 164,
  kSpSpdVotPnVotRoc2NegAlm_Lm            = 165,
  kSpSpdVotPnPv1                         = 166,
  kSpSpdVotPnPv2                         = 167,
  kSpSpdVotPnPv3                         = 168,
  kSpSpdVotPnPv4                         = 169,
  kSpSpdVotPnPv1Conn                     = 170,
  kSpSpdVotPnPv2Conn                     = 171,
  kSpSpdVotPnPv3Conn                     = 172,
  kSpSpdVotPnPv4Conn                     = 173,

  kSpSpdVotPnChkPnt                      = 114,
  kSpSpdVotPnChkPntVer                   = 244
};

#endif //TC_PARAMCODES_H
