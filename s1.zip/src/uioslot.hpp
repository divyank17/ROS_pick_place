/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uioslot.hpp                                                 *
*    Description : Class clsUioSlot declaration.                               *
*******************************************************************************/
#ifndef __UIOSLOT_HPP__
#define __UIOSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "scheduler.hpp"
#include "inslot.hpp"

// header files for the configured slot classes
#include "dislot.hpp"
#include "aihslot.hpp"
#include "aohslot.hpp"
#include "doslot.hpp"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern UINT16 ucConfiguredSlotDbMemory[];

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
#define UIOSLOT_SIZE ((sizeof(clsUioSlot) + (sizeof(clsUioSlot) % sizeof(UINT16))) / sizeof(UINT16))

#define EXTERNAL_RAM_SIZE       ((UINT32)(EXTERNAL_RAM_END_ADDRESS - EXTERNAL_RAM_START_ADDRESS + 1) / sizeof(UINT16))
#define MAX_CONFIGUREDSLOT_SIZE ((UINT32)(EXTERNAL_RAM_SIZE / MAXSLOTS))
#define CONFIGUREDSLOT_SIZE     ((sizeof(clsAohSlot) + (sizeof(clsAohSlot) % sizeof(UINT16))) / sizeof(UINT16))
                                // compile asserts in clsUioSlot constructor confirm the AO slot is the largest 
                                // of the supported channel types

#define MAX_CHECKPOINT_SIZE ((UINT8)200)

// IOL Parameter number definitions
#define PARAMID_INITPNTTYPE    235
#define PARAMID_CFGRESTORE     254

#define UIOSLOT_SPARESIZE 32

/*******************************************************************************
*                            TYPES AND ENUMERATIONS                            *
*******************************************************************************/
class clsUioSlot; // forward declaration

/*******************************************************************************
*                                   clsUioSlot                                 *
*                                   =========                                  *
*******************************************************************************/
class clsUioSlot : public clsIoSlot {
private:
    UINT8        UioSlotSpare[UIOSLOT_SPARESIZE];

    // !!!*** UIO_SLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the UIO slot's redundant synch data area.
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end or to the spare memory allocated. If new member is added to the
    // end, GetRedSlotSize() must be updated to reference the new end member. 
    // This dump record begins in clsIoSlot.

    VOID * GetRedParamsPtr(VOID);
    VOID * GetCheckPointPtr(UINT8 a_ucVer);
    UINT8 GetCheckPointSize(UINT8 a_ucVer);

    VOID InitUioSlot(BOOL,BOOL);

    UINT8 *GetParamPtr(UINT8);

    // Stub the Pre/Post functions, they are not used on the clsUioSlot
    PASTATUS ExecutePreFunction(UINT8,UINT8 *, UINT8) {return PA_NULL;}
    VOID ExecutePostFunction(UINT8,UINT8) {return;}

    clsUioSlot(const clsUioSlot&); // Safeguard against default copy constructor
    clsUioSlot& operator=(const clsUioSlot&); // and default assignment.

public: 
    clsUioSlot(UINT8);
    ~clsUioSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,UIOSLOT_HPP,__LINE__); }
    
    VOID *operator new(UINT32, UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,UIOSLOT_HPP,__LINE__); } 

    VOID InitSlotDatabase(BOOL);
    VOID InactivateSlot(VOID);

    PTEXECST GetPtExecSt(VOID);
    PNTTYPE  GetPntType(VOID);

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    UINT8      GetSlotChkPntParamId(VOID) {return PARAMID_CFGRESTORE;}
    UINT8      GetPtExecStParamId(VOID);
    UINT8      GetLatestSlotChkPntVersion(VOID);

    PASTATUS CreateConfiguredSlot(PNTTYPE InitPntType);
    VOID DeleteConfiguredSlot(VOID);

    virtual PASTATUS WriteParamData(UINT8 *,UINT8,UINT8,BOOL a_bDoChkSm = TRUE);
    virtual PASTATUS WriteParamData(UINT8 *,UINT8,UINT8,UINT8);

    inline UINT32 GetRedSlotDelta(VOID) {return 0;}
    inline UINT32 GetRedSlotSize(VOID) {
        return ((UINT32)((UINT8 *)UioSlotSpare - (UINT8 *)&PntType) + (sizeof(UINT8) * UIOSLOT_SPARESIZE));
    }

    inline UINT8 *GetRedSlotPointer(VOID) {
        return (UINT8 *)&PntType;
    }
};

#endif // __UIOSLOT_HPP__
