////////////////////////////////////////////////////////////////////////////////
//                         CSysE, Fort Washington, PA.                        //
//                                                                            //
//                             COPYRIGHT (C) 2004                             //
//                HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                //
//                             ALL RIGHTS RESERVED                            //
//                                                                            //
// This software is a copyrighted work and / or information protected as a    //
// trade secret.  Legal rights of Honeywell Inc. in this software is distinct //
// from ownership of any medium in which the software is embodied. Copyright  //
// or trade secret notices included must be reproduced in any copies that are //
// authorized by Honeywell Inc.                                               //
//                                                                            //
// The information in this software is subject to change without notice and   //
// should not be considered as a commitment by Honeywell Inc.                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//   File Name   : adc.hpp                                                    //
//   Description : Analog to Digital Converter class definition file          //
////////////////////////////////////////////////////////////////////////////////
#ifndef __ADC_HPP__
#define __ADC_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "commonelectronics.h"
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef struct tagHiLoLimits {
    FLOAT32 fHiLimit;
    FLOAT32 fLoLimit;
} HILOLIMITS;
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#if !LOWCOST
const UINT8 IN_REF0   = 0;
const UINT8 IN_CHAN01 = 1;
const UINT8 IN_CHAN02 = 2;
const UINT8 IN_CHAN03 = 3;
const UINT8 IN_CHAN04 = 4;
const UINT8 IN_CHAN05 = 5;
const UINT8 IN_CHAN06 = 6;
const UINT8 IN_CHAN07 = 7;
const UINT8 IN_CHAN08 = 8;
const UINT8 IN_CHAN09 = 9;
const UINT8 IN_CHAN10 = 10;
const UINT8 IN_CHAN11 = 11;
const UINT8 IN_CHAN12 = 12;
const UINT8 IN_CHAN13 = 13;
const UINT8 IN_CHAN14 = 14;
const UINT8 IN_CHAN15 = 15;
const UINT8 IN_CHAN16 = 16;
const UINT8 IN_CKVT1  = 17;
const UINT8 IN_CKVT2  = 18;
const UINT8 IN_CKVT3  = 19;
const UINT8 IN_CKVT41 = 20;
const UINT8 IN_CKVT52 = 21;
const UINT8 IN_CKVT5  = 22;
const UINT8 IN_CALIB  = 23;
const UINT8 TOTALINPUTS  = IN_CALIB+1;
#endif

#if LOWCOST   // ADS1258 Chip Channel ID
const UINT8  IN_LC_CHAN0    = 8;    // Channel ID of Channel 0
const UINT8  OFFSET_CHANID  = 0x18; // Channel ID of Channel OFFSET
// ADC Internel Reading Indexes
const UINT8  IN_LC_OFFSET   = 0;    
const UINT8  IN_LC_VCC      = 2;
const UINT8  IN_LC_TEMP     = 3;
const UINT8  IN_LC_GAIN     = 4;
const UINT8  IN_LC_REF      = 5;

const UINT8  LC_STS_CHID         = 0x1f;       // Channel ID bits in the ADC Status Byte
const UINT8  LC_STS_OVF_SUPPLY   = 0x60;       // ADS1258 status byte - OverFlow and Supply bits
const UINT8  LC_STS_OVERFLOW     = 0x40;       // ADS1258 status byte - OverFlow bit
const UINT8  LC_STS_SUPPLY       = 0x20;       // ADS1258 status byte - Supply bit
const UINT8  ADC_CHAN_CONNECTED  = 0x0000;     // Channel connection succeed
const UINT8  ADC_DEV_ID          = 0x8B;       // ADC DEV Id
const UINT8  ADC_INT_CHANNELS    = 5;          // OFFSET,VCC,GAIN,TEMP,REF
const UINT8  ADC_CHANNELS        = 16;         // 16 channels
const UINT16 ADC_RST_DLY         = 2000;       // ADC Reset Delay - 2msec 
const UINT16 ADC_DRDY_TIMEOUT    = 6000;       // 2 msec,3MHz Clock
const UINT32 ADC_CONV_INCOMPLETE = 0xFE000000; // A/D Conversion not happened.
const UINT32 ADC_CHAN_DATA_MASK  = 0x00FFFFE0; // Mask for ADC Data and ENOB(effective no of bits) is 19 bits
const UINT32 ADC_INT_DATA_MASK   = 0x00FFFFFF; // ADC Internel Readings mask
const UINT32 ADC_OFFSET_MASK     = 0x00800000; // Mask to check offset is negative.

// ADC Configuration Register Address and Configuration Data
const UINT8 CONFIG0_WR_ADD = 0x60; 
const UINT8 CONFIG0_DATA   = 0x06; // CHOP,STATUS Byte Enabled
const UINT8 CONFIG1_WR_ADD = 0x61;
const UINT8 CONFIG1_DATA   = 0x70; // DLY(111), DRATE(00)
const UINT8 MUXDIF_WR_ADD  = 0x63;
const UINT8 MUXDIF_DATA    = 0x00;
const UINT8 MUXSG0_WR_ADD  = 0x64;
const UINT8 MUXSG0_DATA    = 0x00;
const UINT8 MUXSG1_WR_ADD  = 0x65;
const UINT8 MUXSG1_DATA    = 0x00;
const UINT8 SYSRED_WR_ADD  = 0x66;
const UINT8 SYSRED_DATA    = 0x00;

const UINT8 CONFIG0_RD_ADD = 0x40;
const UINT8 CONFIG1_RD_ADD = 0x41;
const UINT8 MUXDIF_RD_ADD  = 0x42;
const UINT8 MUXSG0_RD_ADD  = 0x44;
const UINT8 MUXSG1_RD_ADD  = 0x45;
const UINT8 SYSRED_RD_ADD  = 0x46;
const UINT8 ADCDEVID_RD_ADD= 0x49;

#endif

const UINT16 NORMAL_MUX_SETTLE_TIME      = 200;   // In units of microseconds.
const UINT16 CALIBRATION_MUX_SETTLE_TIME = 10000; // In units of microseconds.
const UINT16 MAXIMUM_ADCOUNT             = 0xFFFF;

#if !LOWCOST   // Pass1 and Pass2
// Reference constants for Pass 1 boards. Corresponds to the divider ratio of 0.95 before ADC.
// Zero Reference : Ranges from 55 to 75 mV. Zero reference average is 65 mV.
const UINT16 PASS1_ZERO_REF_HILIMIT = 933; // floor(75 * 0.95 * 65535 / 5000) = floor(933.87375)
const UINT16 PASS1_ZERO_REF_LOLIMIT = 685; // ceil(55 * 0.95 * 65535 / 5000) = ceil(684.84075)
// 1V calib input : Ideal count = (1000 + 65) * 0.95 * 65535 / 5000 = 13261.00725
const UINT16 PASS1_ONE_VOLT_HILIMIT = 14587; // floor(13261.00725 + 10%) = floor(14587.107975)
const UINT16 PASS1_ONE_VOLT_LOLIMIT = 11935; // ceil(13261.00725 - 10%) = ceil(11934.906525)
// 5V calib input : Ideal count = (5000 + 65) * 0.95 * 65535 / 5000 = 63067.60725
const UINT16 PASS1_FIVE_VOLT_HILIMIT = 65534; // Clamped at 0xFFFE as 63067.60725 + 10% = 69374.367975
const UINT16 PASS1_FIVE_VOLT_LOLIMIT = 56761; // ciel(63067.60725 - 10%) = ciel(56760.846525)
// NaN threshold (40 mV) : Count = (40 + 65) * 0.95 * 65535 / 5000 = 1307.42325
const UINT16 PASS1_INPUT_NAN_COUNT = 1307; // floor(1307.42325)
// Input deadbad bias (10 mV) : Count = (10) * 0.95 * 65535 / 5000 = 124.5165
const UINT16 PASS1_INPUT_DEADBAND_BIAS = 124; // floor(124.5165)

// Reference constants for Pass 2 boards. Corresponds to the divider ratio of 0.857 before ADC.
// Zero Reference : Ranges from 5 to 20 mV. Zero reference average is 12.5mV.
const UINT16 PASS2_ZERO_REF_HILIMIT = 224; // floor(20 * 0.857 * 65535 / 5000) = floor(224.65398)
const UINT16 PASS2_ZERO_REF_LOLIMIT = 57;  // ciel(5 * 0.857 * 65535 / 5000) = ciel(56.163495)
// 1V calib input : Ideal count = (1000 + 12.5) * 0.857 * 65535 / 5000 = 11373.1077375
const UINT16 PASS2_ONE_VOLT_HILIMIT = 12510; // floor(11373.1077375 + 10%) = floor(12510.41851125)
const UINT16 PASS2_ONE_VOLT_LOLIMIT = 10236; // ciel(11373.1077375 - 10%) = ciel(10235.79696375)
// 5V calib input : Ideal count = (5000 + 12.5) * 0.857 * 65535 / 5000 = 56303.9037375
const UINT16 PASS2_FIVE_VOLT_HILIMIT = 61934; // floor(56303.9037375 + 10%) = floor(61934.29411125)
const UINT16 PASS2_FIVE_VOLT_LOLIMIT = 50674; // ciel(56303.9037375 - 10%) = ciel(50673.51336375)
// NaN threshold (40 mV) : Count = (40 + 12.5) * 0.857 * 65535 / 5000 = 589.7166975
const UINT16 PASS2_INPUT_NAN_COUNT = 589; // floor(589.7166975)
// Input deadbad bias (10 mV) : Count = (10) * 0.857 * 65535 / 5000 = 112.32699
const UINT16 PASS2_INPUT_DEADBAND_BIAS = 112; // floor(112.32699)

const UINT8 NO_OF_REF_VOLTAGES = 6;
const HILOLIMITS REFVOLTAGE_LIMITS[NO_OF_REF_VOLTAGES] = {
    0.114912, 0.097888, // CHVT1  : (0.1064 + 8%), (0.1064 - 8%)
    0.289848, 0.267552, // CKVT2  : (0.2787 + 4%), (0.2787 - 4%)
    0.758680, 0.700320, // CKVT3  : (0.7295 + 4%), (0.7295 - 4%)
    1.875640, 1.731360, // CKVT41 : ((1.9099 - 0.1064) + 4%), ((1.9099 - 0.1064) - 4%)
    4.910152, 4.532448, // CKVT52 : ((5.0000 - 0.2787) + 4%), ((5.0000 - 0.2787) - 4%)
    5.200000, 4.800000  // CKVT5  : (5.0000 + 4%), (5.0000 - 4%)
};

#else   // LOWCOST
// LOWCOST RawData Unit
//  1 count is 0.63578 uV. 
const UINT32 LCOST_ONE_VOLT_COUNT = 0x180000;   // 5V count is 0x780000

// Reference constants for Low Cost boards. Corresponds to the divider ratio of 0.937 before ADC, i.e. 93.7% of UINT16 full range is 5V. 
// ADC Internal Readings(VCC,GAIN,VREF,OFFSET): Ideal 5V Count = 0x3C0000(24 bit)
// ADC External Readings(Channel Inputs 1-16 ): Ideal 5V Count = 0x780000(24 bit)
  
const UINT32 LCOST_ZERO_REF_HILIMIT = 200;  
const UINT32 LCOST_ZERO_REF_LOLIMIT = 0;   
// 0.8 V calib input: Ideal Count = 1258291 (0x133333) +/- 5%
const UINT32 LCOST_0_8_VOLT_HILIMIT = (1258291 + 62914);
const UINT32 LCOST_0_8_VOLT_LOLIMIT = (1258291 - 62914);
// 4V calib input : Ideal count = 6291456  (0x600000) +/- 5%
const UINT32 LCOST_FOUR_VOLT_HILIMIT = (6291456 + 314572); 
const UINT32 LCOST_FOUR_VOLT_LOLIMIT = (6291456 - 314572); 
// 5V Ref input : Ideal count = 3932160 (0x3C0000) +/- 5%
const UINT32 LCOST_FIVE_VOLT_HILIMIT = 3932160 + 196608;       
const UINT32 LCOST_FIVE_VOLT_LOLIMIT = 3932160 - 196608; 
// 5V Vcc input : Ideal count = 3932160 (0x3C0000) +/- 10%
const UINT32 LCOST_VCC_HILIMIT = 3932160 + 393216;       
const UINT32 LCOST_VCC_LOLIMIT = 3932160 - 393216; 
// NaN threshold (40 mV) : Count = .040 * (0x780000/0x05)
const UINT32 LCOST_INPUT_NAN_COUNT = 62914; //
// Input deadband bias (10 mV) : Count = .010 * (0x780000/0x05)
const UINT32 LCOST_INPUT_DEADBAND_BIAS = 15728; //

const UINT16 SPI_TIMEOUT = 780;   // 260 usec, 4096 SCLK, 3MHz timer
#endif


#if !LOWCOST
/*******************************************************************************
*                                    clsAdc                                    *
*                                    ======                                    *
*******************************************************************************/
class clsAdc {
    static const UINT8 aInputSelect[];

public:
    clsAdc(VOID) {
        // Initialize FPGA Interrrupt registers (IE, GE)
        ADC_SPI.CRL = 0x86; // Enable SPI system in master manual mode.
        ADC_SPI.CRH = 0x00; // Enable master transaction.
        ADC_SPI.SSR = 0xFF; // Deassert both slave selects.
    }
    ~clsAdc(VOID) { HardFail(HF_INVPROGRAMEXEC,ADC_HPP,__LINE__); }

    VOID *operator new (SIZE_T)  { return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,ADC_HPP,__LINE__); }

    inline VOID Connect(UINT8 a_ucMuxSel) { INPSEL = aInputSelect[a_ucMuxSel]; }

    UINT16 GetRawData(UINT8,UINT16 a_uiWaitTime = NORMAL_MUX_SETTLE_TIME);

};  // clsAdc

#else   // LOWCOST
/*******************************************************************************
*                                    clsAdc                                    *
*                                    ======                                    *
*******************************************************************************/
class clsAdc {

private:  // HW interface
    void disable_adc(void);
    void send_adc_reset(void);
    void toggle_adc_din(void);
    void toggle_adc_clk(void);
    void toggle_adc_start(void);
    void write_adc_byte(UINT8 adc_data);
    char read_adc_byte(void);
    void pulse_start(void);
    VOID ChipSelect(VOID){ADC_CS_OUT = 0;}
    VOID ChipDeselect(VOID){ADC_CS_OUT = 1;}
    VOID delay(VOID){ NOP;NOP;}
    VOID start_timer(void) {TMR_TCNT = 0;}
    UINT16 read_timer(void) {return TMR_TCNT;}
    
public:
    clsAdc(VOID);
    ~clsAdc(VOID) { HardFail(HF_INVPROGRAMEXEC,ADC_HPP,__LINE__); }

    VOID *operator new (SIZE_T)  { return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,ADC_HPP,__LINE__); }
    VOID GetRawData(BOOL a_bInternal, UINT32 * a_Array, BOOL bCalib);
    UINT16 Connect(BOOL a_bInternal);
#ifdef DEBUG
    UINT8 WriteRegData(UINT8,UINT8);
    UINT8 ReadRegData(UINT8);
#endif
};  // clsAdc
#endif  // LOWCOST

#endif
