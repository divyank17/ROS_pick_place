/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : llmuxslot.hpp                                                 *
*    Description : Class clsLLSlot declaration.                               *
*******************************************************************************/
#ifndef __LLMUXSLOT_HPP__
#define __LLMUXSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aixslot.hpp"
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define LLMUXSLOT_SIZE ((sizeof(clsLLSlot) + (sizeof(clsLLSlot) % 2)) / 2)

//PARAMETER NUMBER CONTANTS
#define PARAMID_PNTTYPE     60//1
#define PARAMID_SENSRTYP    99//1
#define PARAMID_PVCHAR      68//1
#define PARAMID_PVTEMP      96//1
#define PARAMID_TCRNGOPT   102//1 
#define PARAMID_PVRAWHI     87//4
#define PARAMID_PVRAWLO     88//4
#define PARAMID_INPTDIR     56//1
#define PARAMID_PVEUHI      70//4
#define PARAMID_PVEULO      71//4
#define PARAMID_PVEXEUHI    72//4
#define PARAMID_PVEXEULO    73//4
#define PARAMID_PVCLAMP     69//1
#define PARAMID_LOCUTOFF    58//4
#define PARAMID_PVSRCOPT    94//1
#define PARAMID_PVSOURCE    93//1
#define PARAMID_TF         103//4
#define PARAMID_PVTV        97//4
//#define PARAMID_OWDENABLE 143//1 
#define PARAMID_PTEXECST    61//1

//Array subscript for Default_extended_values.
#define TOTAL_SENSORTYPES       12//These many sensors supported
#define TOTAL_LIMIT_CONSTS       4//LOW LIMIT,HIGH LIMIT, EXT LOW ,EXT HIGH
#define TOTAL_COEFFS             5//5th order polynomial
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsLLSlot; // forward declaration
typedef struct tagSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsLLSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsLLSlot::* PostPtr)(UINT8);
    VOID *   (clsLLSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} SLOTPARAMINFO;

typedef enum tagInit_Type {
    WARM_INIT  = 0,		
    COLD_INIT  = 1,
    PTBD_INIT  = 2
} INIT_TYPE;
/*******************************************************************************
*                                   clsLLSlot                                 *
*                                   ==========                                 *
*******************************************************************************/
class clsLLSlot : public clsAixSlot {
private:

  // J-Type Thermo-Couple coefficient table
  static  const FLOAT32 J_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 J_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 J_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 J_COEFF_SET3[TOTAL_COEFFS];
  static  const FLOAT32 J_COEFF_SET4[TOTAL_COEFFS];
  static  const FLOAT32 J_COEFF_SET5[TOTAL_COEFFS];
  // K-Type Thermo-Couple coefficient table
  static  const FLOAT32 K_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 K_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 K_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 K_COEFF_SET3[TOTAL_COEFFS];
  static  const FLOAT32 K_COEFF_SET4[TOTAL_COEFFS];
  static  const FLOAT32 K_COEFF_SET5[TOTAL_COEFFS];
  // E-Type Thermo-Couple coefficient table
  static  const FLOAT32 E_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 E_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 E_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 E_COEFF_SET3[TOTAL_COEFFS];
  static  const FLOAT32 E_COEFF_SET4[TOTAL_COEFFS];

  // T-Type Thermo-Couple coefficient table
  static  const FLOAT32 T_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 T_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 T_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 T_COEFF_SET3[TOTAL_COEFFS];
  // B-Type Thermo-Couple coefficient table
  static  const FLOAT32 B_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 B_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 B_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 B_COEFF_SET3[TOTAL_COEFFS];
  static  const FLOAT32 B_COEFF_SET4[TOTAL_COEFFS];
  static  const FLOAT32 B_COEFF_SET5[TOTAL_COEFFS];
  // S-Type Thermo-Couple coefficient table
  static  const FLOAT32 S_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 S_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 S_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 S_COEFF_SET3[TOTAL_COEFFS];
  static  const FLOAT32 S_COEFF_SET4[TOTAL_COEFFS];
  // R-Type Thermo-Couple coefficient table
  static  const FLOAT32 R_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 R_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 R_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 R_COEFF_SET3[TOTAL_COEFFS];
  static  const FLOAT32 R_COEFF_SET4[TOTAL_COEFFS];
  // JR-Type Thermo-Couple coefficient table
  static  const FLOAT32 JR_COEFF_SET0[TOTAL_COEFFS];
  static  const FLOAT32 JR_COEFF_SET1[TOTAL_COEFFS];
  static  const FLOAT32 JR_COEFF_SET2[TOTAL_COEFFS];
  static  const FLOAT32 JR_COEFF_SET3[TOTAL_COEFFS];
  static  const FLOAT32 JR_COEFF_SET4[TOTAL_COEFFS];
  // PTDIN-Type RTD coefficient table
  static  const FLOAT32 PTDIN_SET0[TOTAL_COEFFS];   
  static  const FLOAT32 PTDIN_SET1[TOTAL_COEFFS];   
  static  const FLOAT32 PTDIN_SET2[TOTAL_COEFFS];   
  // PTJIS-Type RTD coefficient table
  static  const FLOAT32 PTJIS_SET0[TOTAL_COEFFS];   
  static  const FLOAT32 PTJIS_SET1[TOTAL_COEFFS];   
  static  const FLOAT32 PTJIS_SET2[TOTAL_COEFFS];   
  // NIRTD-Type RTD coefficient table
  static  const FLOAT32 NIRTD_SET0[TOTAL_COEFFS];   
  static  const FLOAT32 NIRTD_SET1[TOTAL_COEFFS];   
  // CURTD-Type RTD coefficient table
  static  const FLOAT32 CURTD_SET0[TOTAL_COEFFS];   

  // TABLE OF COEFFICEINT SET POINTERS
  static  const FLOAT32 *J_TYPE[];
  static  const FLOAT32 *K_TYPE[];
  static  const FLOAT32 *E_TYPE[];
  static  const FLOAT32 *T_TYPE[];
  static  const FLOAT32 *B_TYPE[];
  static  const FLOAT32 *S_TYPE[];
  static  const FLOAT32 *R_TYPE[];
  static  const FLOAT32 *JR_TYPE[];
  static  const FLOAT32 *PTDIN[];
  static  const FLOAT32 *PTJIS[];
  static  const FLOAT32 *NIRTD[];
  static  const FLOAT32 *CURTD[];
  
  //TABLE OF THERMOCOUPLE TYPE POINTERS
  static  const FLOAT32 **POLY_COEFF_SET[];

  //J TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 J_BP[];
  //K TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 K_BP[];
  //E TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 E_BP[];
  //T TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 T_BP[];
  //B TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 B_BP[];
  //S TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 S_BP[];
  //R TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 R_BP[];
  //JR TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 JR_BP[];
  //PTD TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 PTD_BP[];
  //PTJ TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 PTJ_BP[];
  //NI TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 NI_BP[];
  //CU TYPE T/C POLYNOMIAL TABLE BREAKPOINTS (IN uV)
  static  const FLOAT32 CU_BP[];

  // TABLE OF BREAKPOINT POINTERS
  static  const FLOAT32 *BP_POINTER_TAB[];

  // TABLE OF DEFAULT LIMITS .
  static  const FLOAT32 EXTENDED_LIMITS_TABLE[TOTAL_SENSORTYPES][TOTAL_LIMIT_CONSTS];
protected:
    INPTDIR  InptDir;
    PVCHAR   PvChar;
    FLOAT32  PvRawHI;
    FLOAT32  PvRawLO;
    PVTEMP   PvTemp;
    SENSRTYP SensrTyp;
    TCRNGOPT TcRngOpt;
    FLOAT32  PvRawInt;
    FREQ6050 Freq6050;
    FLOAT32  RawSpan;
    BOOL     InitFlg;

    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const SLOTPARAMINFO tblParamInfo[256];

    PASTATUS PreInptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl); 
    PASTATUS PreLoCutOff(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl); 
    PASTATUS PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPntType(UINT8 a_ucAccLvl);
    PASTATUS PrePtExecSt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPtExecSt(UINT8 a_ucAccLvl);
    PASTATUS PrePvChar(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvChar(UINT8 a_ucAccLvl);
    VOID     PostPvEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvExEUHi(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvExEULo(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEULo(UINT8 a_ucAccLvl);
    PASTATUS PrePvRawHI(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvRawHI(UINT8 a_ucAccLvl);
    PASTATUS PrePvRawLO(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvSrcOpt(UINT8 a_ucAccLvl);
    PASTATUS PrePvTemp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvTemp(UINT8);
    PASTATUS PreSensrTyp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostSensrTyp(UINT8 a_ucAccLvl);
    VOID     PostTf(UINT8 a_ucAccLvl);
    PASTATUS PreOwdEnable(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreTcRngOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreFreq6050(UINT8 *a_Writebuffer, UINT8 );
    VOID     PostFreq6050(UINT8);

    VOID    DefaultExtendedEULimits(UINT8);
    FLOAT32 ConvTempUnit(FLOAT32 rTemp);
    inline  UINT8   GetConfigType()     {return 0;} // TBD Amit : Not sure about impl details. 
                                                    // NULL in FIO
    inline VOID *GetInptDirPtr(VOID)    {return &InptDir; }
    inline VOID *GetPvCharPtr(VOID)     {return &PvChar;  }
    inline VOID *GetPvRawHIPtr(VOID)    {return &PvRawHI; }
    inline VOID *GetPvRawLOPtr(VOID)    {return &PvRawLO; }
    inline VOID *GetPvTempPtr(VOID)     {return &PvTemp;  }
    inline VOID *GetSensrTypPtr(VOID)   {return &SensrTyp;}
    inline VOID *GetTcRngOptPtr(VOID)   {return &TcRngOpt;}
    inline VOID *GetPvRawIntPtr(VOID)   {return &PvRawInt;}
    inline VOID *GetFreq6050Ptr(VOID)   {return &Freq6050;}
    inline VOID *GetRawSpanPtr(VOID)    {return &RawSpan; }
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SlotChkpntVersion-1].CheckPointPtr;}
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)NULL; }//No redundancy

    inline UINT8 GetCheckPointParamNumber(VOID) { return PARAMID_SLTCHKPNT; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsLLSlot(const clsLLSlot&); // Safeguard against default copy constructor
    clsLLSlot& operator=(const clsLLSlot&); // and default assignment

public:
    clsLLSlot(UINT8);
    ~clsLLSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,LLMUXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,LLMUXSLOT_HPP,__LINE__); }

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       InitSlot(INIT_TYPE);

    inline UINT32 GetRedSlotDelta(VOID) {return 0;}
    inline UINT32 GetRedSlotSize(VOID) {
        return ((UINT32)0);
    }
    inline UINT8 *GetRedSlotPointer(VOID) {
        return (UINT8 *)&PntType;
    }
    inline PVCHAR   GetPvChar()     { return PvChar;  }
    inline SENSRTYP GetSensrTyp()   { return SensrTyp;}
    inline UINT8    GetFreq6050()   { return Freq6050;}
    inline BOOL     GetInitFlg()    { return InitFlg; }
    inline FLOAT32  GetPvRawInt()   { return PvRawInt;}
    inline FLOAT32  GetPvTv(VOID)   { return PvTv;}
    inline VOID     SetPvRawInt(FLOAT32 a_PvRawInt)  { PvRawInt = a_PvRawInt;}
    inline VOID     SetFreq6050(FREQ6050 a_Freq6050) { Freq6050 = a_Freq6050;}
    inline VOID     SetInitFlg(BOOL a_Init)          { InitFlg = a_Init;     }

    VOID ProcessInput(VOID);
    VOID ProcessTCorRTDInput();
    VOID ProcessLinearInput();
    VOID RangeFilterSource(VOID);
    PASTATUS EULimitCheck(VOID);
    FLOAT32  EUConversion(FLOAT32* a_fCoeffOffSet);
    FLOAT32* GenPolyPtr(VOID);
};

#endif
