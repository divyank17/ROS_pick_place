/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcaoservoslot.hpp                                           *
*    Description : Class clsAoServoSlot declaration.                           *
*******************************************************************************/
#ifndef __AOSERVOSLOT_HPP__
#define __AOSERVOSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define AOSERVOSLOT_SIZE ((sizeof(clsAoServoSlot) + (sizeof(clsAoServoSlot) % 2)) / 2)

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SVPAO_SYNC_VER_1;
extern const UINT16 SVPAO_SYNC_VER_2;

const UINT8   PASSCOUNTMAX          = 6;       // 200ms Delay
const UINT8   PASSCOUNTMIN          = 1;       // must be >= 1

const UINT16  MINCURRENT_OUTPUT_DACCOUNT    = 0x080; // 0 mA

const  FLOAT32 FARENHEIT_CONV_OFFSET  =   32.0;
const  FLOAT32 FARENHEIT_CONV_NUM     =   9.0;
const  FLOAT32 FARENHEIT_CONV_DEN     =   5.0;
const  FLOAT32 RANKINE_CONV_OFFSET    =   491.69;
const  FLOAT32 RANKINE_CONV_NUM       =   9.0;
const  FLOAT32 RANKINE_CONV_DEN       =   5.0;
const  FLOAT32 KELVIN_CONV_OFFSET     =   273.0;

const UINT8 SLOT_SPARESIZE=16;

#define NUM_ONE             1
#define NUM_TWENTY          20
#define NUM_TWENTY_TWO      22

// Dither singal lo hi limits definitions
#define DITHER_FREQ_LO_LIMIT    25
#define DITHER_FREQ_HI_LIMIT    60

const FLOAT32 MIN_DITHER_PERCENT=0;
const FLOAT32 MAX_DITHER_PERCENT=10;

#define HUNDRED                 100
#define ZERO           (FLOAT32)0

/*
    AO output full range declarations
 */
const UINT16 FULL_RANGE_BP_10_MINUS_10_MA   = 20;
const UINT16 FULL_RANGE_BP_20_MINUS_20_MA   = 40;
const UINT16 FULL_RANGE_BP_40_MINUS_40_MA   = 80;
const UINT16 FULL_RANGE_BP_80_MINUS_80_MA   = 160;
const UINT16 FULL_RANGE_BP_160_MINUS_160_MA = 320;
const UINT16 FULL_RANGE_BP_320_MINUS_320_MA = 640;
const UINT16 FULL_RANGE_UP_ZERO_50_MA       = 50;
const UINT16 FULL_RANGE_UP_ZERO_300_MA      = 300;

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagSvpAoLpbkSts {
    SVP_AOLPBK_PASSED,
    SVP_AOLPBK_HITESTFAIL,
    SVP_AOLPBK_LOTESTFAIL
}SVPAOLPBKSTS;

/*
    AO output type enum declarations
 */
typedef enum tagAoOptType{
    BP_10_MINUS_10_MA   = 0,
    BP_20_MINUS_20_MA   = 1,
    BP_40_MINUS_40_MA   = 2,
    BP_80_MINUS_80_MA   = 3,
    BP_160_MINUS_160_MA = 4,
    BP_320_MINUS_320_MA = 5,
    UP_ZERO_50_MA       = 6,
    UP_ZERO_300_MA      = 7,
    UP_4_TO_20_MA       = 8,
    AO_SERVO_TYPE_NONE  = 9     //Not a valid enum. Used for Range Checks
}AOOPTTYPE;

typedef enum tagSvpFaultOption {
    SVPFAULTOPT_HOLD         = 0,
    SVPFAULTOPT_UNPOWERED    = 1,
    SVPFAULTOPT_FAULTVALUE   = 2,
    SVPFAULTOPT_USEBIASCURRNT= 3
}SVPFAULTOPT;

/*
    Emum Selection of input for Process interlock
*/
typedef enum tagPrcIntrLck{
    PRC_LCK_NONE =0,
    PRC_LCK_DI1PVFL =1,
    PRC_LCK_DI2PVFL =2
}PRCINTRLCK;

typedef enum tagPrcIntrLckFailOpt{
    PRC_INT_LCK_FAIL_NONE,
    PRC_INT_LCK_FAIL_PRCSAFEOP,
    PRC_INT_LCK_FAIL_HOLD
}PRCINTRLCKFAILOPT;

typedef enum enmopaction
{
    OP_FULL_VALUE  =0,
    OP_INCREMENTAL =1
}OPACTION;

typedef enum enmditherwaveform
{
    DITHER_WAVEFORM_SINE   = 2,
    DITHER_WAVEFORM_SQUARE = 3
}DITHER_WAVEFORM;

/*
     Redundacy dump record structure
*/
struct strAoServoSlotDumpData 
{
    UINT16      Version;    // The first two bytes of dump record should always represent version. Do not change this. 
    PNTTYPE     PntType;
    PTEXECST    PtExecSt;
    FAULTSTATE  FaultState;
    SVPFAULTOPT FaultOpt;
    FLOAT32     FaultValue;
    MODE        Mode;
    MODEATTR    ModeAttr;
    MODEPERM    ModePerm;
    MODE        NMode;
    MODEATTR    NModeAttr;
    REDTAG      RedTag;
    OPTDIR      OptDir;
    FLOAT32     OpIn0;
    FLOAT32     OpIn1;
    FLOAT32     OpIn2;
    FLOAT32     OpIn3;
    FLOAT32     OpIn4;
    FLOAT32     OpIn5;
    FLOAT32     OpOut0;
    FLOAT32     OpOut1;
    FLOAT32     OpOut2;
    FLOAT32     OpOut3;
    FLOAT32     OpOut4;
    FLOAT32     OpOut5;
    FLOAT32     PrcSafeOp1;
    FLOAT32     PrcSafeOp2;
    FLOAT32     OpBiasCurrent;
    FLOAT32     DitherFreq;
    FLOAT32     DitherAmpl;
    FLOAT32     OpHiCurrent;
    FLOAT32     OpLoCurrent;
    BOOL        OpChar;
    AOOPTTYPE   OptType;
    OPACTION     OpAction;
    PRCINTRLCKFAILOPT IntrLckFlOpt1;
    PRCINTRLCKFAILOPT IntrLckFlOpt2;
    PRCINTRLCK   PrcIntLck1;
    PRCINTRLCK   PrcIntLck2;
    INT32        SvpRegCtlOpConnection;
    FLOAT32     Chrc_S0;
    FLOAT32     Chrc_S1;
    FLOAT32     Chrc_S2;
    FLOAT32     Chrc_S3;
    FLOAT32     Chrc_S4;
    BOOL        OTPT_Unused;
    FLOAT32     Op;
    FLOAT32     SecDiagCurrent; 
    BOOL        SecDiagEnb;
    DITHER_WAVEFORM DitherWaveform;
};

class clsAoServoSlot; // forward declaration
typedef struct tagAoServoSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsAoServoSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsAoServoSlot::* PostPtr)(UINT8);
    VOID *   (clsAoServoSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} AOSERVOSLOTPARAMINFO;
/*******************************************************************************
*                                   clsAoServoSlot                             *
*                                   ==========                                 *
*******************************************************************************/
class clsAoServoSlot : public clsOutSlot {
protected:

    static const UINT8 CheckPointVer1[];
    static const UINT8 CheckPointVer2[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const AOSERVOSLOTPARAMINFO tblParamInfo[256];
    static const UINT8 HEuRngExt[];
    static UINT8 SvpAoSlotChkpntVersion;

    //Member Variables
    FLOAT32     Op;
    FLOAT32     OpFinal;
    FLOAT32     OpIn0;
    FLOAT32     OpIn1;
    FLOAT32     OpIn2;
    FLOAT32     OpIn3;
    FLOAT32     OpIn4;
    FLOAT32     OpIn5;
    FLOAT32     OpOut0;
    FLOAT32     OpOut1;
    FLOAT32     OpOut2;
    FLOAT32     OpOut3;
    FLOAT32     OpOut4;
    FLOAT32     OpOut5;
    FLOAT32     PrcSafeOp1;
    FLOAT32     PrcSafeOp2;
    FLOAT32     OpBiasCurrent;
    FLOAT32     DitherFreq;
    FLOAT32     DitherAmpl;
    FLOAT32     PrcSafeOP;
    BOOL        StdbyMan;
    BOOL        InitReq;
    BOOL        OpChar;
    AOOPTTYPE   OptType;
    SVPFAULTOPT SvpFaultOpt;
    PRCINTRLCKFAILOPT IntrLckFlOpt1;
    PRCINTRLCKFAILOPT IntrLckFlOpt2;
    PRCINTRLCK   PrcIntLck1;
    PRCINTRLCK   PrcIntLck2;
    BOOL         IntrLck1Sts;
    BOOL         IntrLck2Sts;
    INT32        SvpRegCtlOpConnection;
    OPACTION     OpAction;
    FLOAT32      OpHiCurrent;
    FLOAT32      OpLoCurrent;
    FLOAT32     DitherAmpMaxLm;
    FLOAT32     DitherAmpMinLm;
    FLOAT32     B0_LInv;
    FLOAT32     B1_LInv; 
    FLOAT32     OpInternal;
    FLOAT32     B0_L;
    FLOAT32     B1_L;
    FLOAT32     B0_O;
    FLOAT32     B1_O;
    FLOAT32     Chrc_S0;
    FLOAT32     Chrc_S1;
    FLOAT32     Chrc_S2;
    FLOAT32     Chrc_S3;
    FLOAT32     Chrc_S4;
    FLOAT32     B0_Inv;
    FLOAT32     B1_Inv;
    UINT16      OutputDACImg;
    UINT16      OutDACImg;
    UINT16      LoopBackDACImg;
    BOOL        OTPT_Unused;
    BOOL        SecDiagEnb;
    FLOAT32     SecDiagCurrent;
    DITHER_WAVEFORM DitherWaveform;

    AOSHRAMSLOTDATA *pAoShramSlotData; //Shared ram slot data pointer

    VOID InitTcAoSlot(BOOL , BOOL);    
    VOID InitServoAoSlot(VOID);

    //Overrided clsIoSlot Class Varibles GetPtr methods
    VOID *GetPntTypePtr(VOID);         
    VOID *GetPtExecStPtr(VOID);
    
    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SvpAoSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SvpAoSlotChkpntVersion;}

    //Overrided clsOutSlot Class Varibles GetPtr methods
    VOID *GetModeAttrPtr(VOID);  
    VOID *GetModePtr(VOID);      
    VOID *GetModePermPtr(VOID);  
    VOID *GetNModeAttrPtr(VOID);  
    VOID *GetNModePtr(VOID);         
    VOID *GetFaultOptPtr(VOID);  
    VOID *GetFaultValuePtr(VOID);
    VOID *GetOptDirPtr(VOID);    
    VOID *GetRedTagPtr(VOID);    

    //Member Varibles GetPtr methods
    VOID *GetOpPtr(VOID);
    VOID *GetOpCharPtr(VOID);    
    VOID *GetOpFinalPtr(VOID);   
    VOID *GetOpIn0Ptr(VOID);     
    VOID *GetOpIn1Ptr(VOID);     
    VOID *GetOpIn2Ptr(VOID);     
    VOID *GetOpIn3Ptr(VOID);     
    VOID *GetOpIn4Ptr(VOID);     
    VOID *GetOpIn5Ptr(VOID);     
    VOID *GetOpOut0Ptr(VOID);    
    VOID *GetOpOut1Ptr(VOID);    
    VOID *GetOpOut2Ptr(VOID);    
    VOID *GetOpOut3Ptr(VOID);    
    VOID *GetOpOut4Ptr(VOID);    
    VOID *GetOpOut5Ptr(VOID);    
    VOID *GetStdbyManPtr(VOID);  
    VOID *GetInitReqPtr(VOID);
    VOID *GetOptTypePtr(VOID);
    VOID *GetDitherFreqPtr(VOID); 
    VOID *GetDitherAmplPtr(VOID); 
    VOID *GetInLckFlOpt1Ptr(VOID);
    VOID *GetInLckFlOpt2Ptr(VOID);
    VOID *GetInSelPrcIntLck1Ptr(VOID);
    VOID *GetInSelPrcIntLck2Ptr(VOID);  
    VOID *GetPrcSafeOp1Ptr(VOID);    
    VOID *GetPrcSafeOp2Ptr(VOID);    
    VOID *GetOpBiasCurrentPtr(VOID);
    VOID *GetSvpRegCtlOpConnection(VOID);
    VOID *GetOpActionPtr(VOID);
    VOID *GetOpHiCurrentPtr(VOID);
    VOID *GetOpLoCurrentPtr(VOID);
    VOID *GetSecDiagEnbPtr(VOID);
    VOID *GetB0_LInvPtr(VOID);       
    VOID *GetB1_LInvPtr(VOID);       
    VOID *GetOpInternalPtr(VOID);    
    VOID *GetB0_LPtr(VOID);          
    VOID *GetB1_LPtr(VOID);          
    VOID *GetB0_OPtr(VOID);          
    VOID *GetB1_OPtr(VOID);          
    VOID *GetChrc_S0Ptr(VOID);       
    VOID *GetChrc_S1Ptr(VOID);       
    VOID *GetChrc_S2Ptr(VOID);      
    VOID *GetChrc_S3Ptr(VOID);       
    VOID *GetChrc_S4Ptr(VOID);       
    VOID *GetOTPT_UnusedPtr(VOID);   
    VOID *GetB0_InvPtr(VOID);        
    VOID *GetB1_InvPtr(VOID);        
    VOID *GetOutDACImgPtr(VOID);
    VOID *GetSecDiagCurrentPtr(VOID);
    VOID *GetIntrLck1StsPtr(VOID);
    VOID *GetIntrLck2StsPtr(VOID);
    VOID *GetDitherWaveformPtr(VOID);

    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    
    VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams; }
    VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SvpAoSlotChkpntVersion-1].CheckPointPtr; }
    VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }

    clsAoServoSlot(const clsAoServoSlot&); // Safeguard against default copy constructor
    clsAoServoSlot& operator=(const clsAoServoSlot&); // and default assignment
public:
    clsAoServoSlot(UINT8); 
    ~clsAoServoSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);

    VOID InitSlotDatabase(BOOL bFullInit);

    inline UINT32 GetRedSlotDelta(VOID) {return 0;}      
    inline UINT8 *GetRedSlotPointer(VOID) {
        return NULL;//(UINT8 *)&PntType;//NOTE::
    } 

    // redundancy dump related Fucntions
    PASTATUS  GetDumpData(UINT8* const pDump, const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    inline UINT32 GetRedSlotSize(VOID) {
        return (sizeof(strAoServoSlotDumpData));
    }
};

#endif
