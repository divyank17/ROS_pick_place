;*******************************************************************************
;                         CSysE, Fort Washington, PA.                          *
;                                                                              *
;                              COPYRIGHT (C) 2004                              *
;                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
;                              ALL RIGHTS RESERVED                             *
;                                                                              *
;   This software is a copyrighted work and / or information protected as a    *
;   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
;   from ownership of any medium in which the software is embodied. Copyright  *
;   or trade secret notices included must be reproduced in any copies that are *
;   authorized by Honeywell Inc.                                               *
;                                                                              *
;   The information in this software is subject to change without notice and   *
;   should not be considered as a commitment by Honeywell Inc.                 *
;                                                                              *
; ============================================================================ *
;   File Name   : asmutils.asm                                                 *
;   Description : Common assembly routines.                                    *
;*******************************************************************************
    .AIFDEF DEBUG
INCLUDE_FLASH_ROUTINES: .DEFINE "0"
    .AELSE
INCLUDE_FLASH_ROUTINES: .DEFINE "1"
    .AENDI
;*******************************************************************************
;                               EXPORTED SYMBOLS                               *
;*******************************************************************************
    .EXPORT __TestRAMCell
    .EXPORT __TestCPURegisters
    .AIF "INCLUDE_FLASH_ROUTINES" EQ "1"
    .EXPORT __EraseFlashBlock
    .EXPORT __ProgramFlash
    .AENDI
    .AIF "H8S_2319C" EQ "1"
    .EXPORT __SolveState
    .AENDI
    .AIF "LOWCOST" EQ "1"
    .EXPORT __DUMMYREG
    .AENDI
;*******************************************************************************
;                                   CONSTANTS                                  *
;*******************************************************************************
    .AIF "INCLUDE_FLASH_ROUTINES" EQ "1"
SYSTEM_CLOCK_FREQUENCY  .EQU 24000000
CYCLE_COUNT             .EQU 4000000
;
TCSR        .EQU    H'FFFFBC    ; WDT  TCSR WRITE A5
RSTCSR      .EQU    H'FFFFBE    ; RESET CONTROL REGISTER WRITE 5A
;*****  REGISTER  **************************************************************
RDBK_SEL3   .EQU    H'00FFFF6E  ; Port F Data Register
RDBK_SOECLK .EQU    H'00FFFF53  ; Port 4 PORT register to read from CPLD
RDBK_SEL    .EQU    H'00FFFF60  ; Port 1 Data register
FLMCR1      .EQU    H'FFFFC8    ; FLASH MEMORY CONTROL REGISTER 1
 FWE:       .EQU    7
 SWE:       .EQU    6
 ESU:       .EQU    5
 PSU:       .EQU    4
 EV:        .EQU    3
 PV:        .EQU    2
 E:         .EQU    1
 PR:        .EQU    0
FLMCR2      .EQU    H'FFFFC9    ; FLASH MEMORY CONTROL REGISTER 2
 FLER:      .EQU    7
EBR1        .EQU    H'FFFFCA    ; OBJECT BLOCK SELECTION 1
EBR2        .EQU    H'FFFFCB    ; OBJECT BLOCK SELECTION 2
SYSCR2      .EQU    H'FFFF42    ; SYSTEM CONTROL REGISTER 2
 FLSHE:     .EQU    3
BCRL        .EQU    H'FFFED5    ; BUS CONTROLLER REGISTER
 EAE:       .EQU    5
;*****  FLASH constant  ********************************************************
MAX_ET      .EQU    100     ; The number of times of the maximum erase
MAX_WT      .EQU    1000    ; The number of times of the maximum writing
OW_COUNT    .EQU    6       ; The number of times of additional writing
BLK_MAX     .EQU    14      ; The number of the maximum blocks
MAXBLK1     .EQU    8       ; EBR1 The number of the maximum blocks
MAXBLK2     .EQU    6       ; EBR2 The number of the maximum blocks
;****  Execution result definition  ********************************************
OK          .EQU    H'00        ; Normal end
NG          .EQU    H'01        ; Abnormal end1
WNG         .EQU    H'02        ; Abnormal end2
;
FWE_ERR     .EQU    H'D1        ; FWE reset error
FLER_ERR    .EQU    H'D2        ; FLER(Flash error)
;
BLK_ERR     .EQU    H'E1        ; Erase block No. error
ERS_ERR     .EQU    H'E2        ; Number-of-times error of the maximum erase
;
WAD_ERR     .EQU    H'F1        ; Write-in address error 
WAE_ERR     .EQU    H'F2        ; 128 byte boundary address error
;
WT_ST_END   .EQU    H'0005FF80  ; The last top address of 128 byte writing
;***** Delay timer constants for programming and erasing  **********************
SWES_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 1) + 1 
SWEC_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 100) + 1
ESUS_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 100) + 1
ESUC_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 10) + 1
ES_W        .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 10000)
EC_W        .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 10) + 1
EVS_W       .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 20) + 1
EVC_W       .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 4) + 1
DLCH_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 1) + 1
PSUS_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 50) + 1
PSUC_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 5) + 1
P10S_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 10)
P30S_W      .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 30)
P200S_W     .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 200)
PC_W        .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 5) + 1
PVS_W       .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 4) + 1
PVC_W       .EQU    (SYSTEM_CLOCK_FREQUENCY / CYCLE_COUNT * 2) + 1
    .AENDI
;*******************************************************************************
;                                 DATA SECTION                                 *
;*******************************************************************************
    .AIF "INCLUDE_FLASH_ROUTINES" EQ "1"
    .SECTION    B,DATA,ALIGN=2

    ; HEK and LOWCOST define in the same way. Define OR condition.
    .AIF "HEK" EQ "1"
AIAO     .EQU    1
    .AELIF "LOWCOST" EQ "1"
AIAO     .EQU    1
    .AELSE
AIAO     .EQU    0
    .AENDI

    .AIF "AIAO" EQ "1"
COUNT   .RES.B  2       ; W_COUNT,E_COUNT
VF_ST   .RES.B  4       ; VERIFY START ADDRESS 
VF_ED   .RES.B  4       ; VERIFY END ADDRESS
W_ADR   .RES.B  4       ; WRITE DATA AREA ADDRESS
R_BUF   .RES.B  128     ; RETRY WRITE DATA AREA
OW_BUF  .RES.B  128     ; OVER WRITE DATA ARIA
VF_RET  .RES.B  1       ; VERIFY CHECK
BLK_NO  .RES.B  1       ; ERASE BIT NUMBER
    .AELSE
; Digital Modules do not have adequate memory and thus the memory
; is relocated to REBOOT_SECTION.It is only during flashing HWREVCODE 
; and SERIAL_NO in Factory Mode, this memory will be utilizedd.
COUNT   .EQU    H'00FFF390  ;W_COUNT,E_COUNT
VF_ST   .EQU    H'00FFF392  ;VERIFY START ADDRESS 
VF_ED   .EQU    H'00FFF396  ;VERIFY END ADDRESS
W_ADR   .EQU    H'00FFF39A  ;WRITE DATA AREA ADDRESS
R_BUF   .EQU    H'00FFF39E  ;RETRY WRITE DATA AREA
OW_BUF  .EQU    H'00FFF41E  ;OVER WRITE DATA ARIA
VF_RET  .EQU    H'00FFF49E  ;VERIFY CHECK
BLK_NO  .EQU    H'00FFF49F  ;ERASE BIT NUMBER
    .AENDI
    .AENDI

    .AIF "LOWCOST" EQ "1"
    .SECTION    B,DATA,ALIGN=2
__DUMMYREG  .RES.B  16        ;Dummy Write Area for unused IO, bigger than st_fpga_spi
    .AENDI

;*******************************************************************************
;                                PROGRAM SECTION                               *
;*******************************************************************************
    .SECTION P,CODE,ALIGN=2
    .AIF "INCLUDE_FLASH_ROUTINES" EQ "1"

;*******************************************************************************
;                                 ___ProgramFlash                              *
;                                 =================                            *
; PURPOSE:                                                                     *
;    Erase a specified block in Flash ROM.                                     *
; ARGUMENTS:                                                                   *
;    ER0 - Address of Data Buffer to be written                                *
;    ER1 - Address where the Data to be written in Flash                       *
; RETURN:                                                                      *
;    R0L - 0 if write & verify is successful                                   *
; NOTES:                                                                       *
;******************************************************************************/
__ProgramFlash:
;disable all interrupts
    ORC     #07,EXR             ; Disable all interrupts.
    STM.L   (ER2-ER3),@-SP
    STM.L   (ER4-ER6),@-SP
;
    MOV.L   ER0,@W_ADR:32            ;Write-in data buffer address
;
    BSR     PFWECHECK               ;FWE,FLER BIT CHECK
    CMP.B   #OK,R0L
    BNE     fwr_rtn
;
    MOV.L   #WT_ST_END,ER4          ;Write-in end head address check
    CMP.L   ER1,ER4
    BCC     FWC_010
;
    MOV.B   #WAD_ERR,R0L            ;Write-in address error
    BRA     fwr_rtn
;
FWC_010:
    MOV.L   #H'0000007F,ER4         ;128 byte boundary check
    AND.L   ER1,ER4
    BEQ     FWC_020
;
    MOV.B   #WAE_ERR,R0L            ;128 byte boundary address error
    BRA     fwr_rtn
;
FWC_020:
    MOV.L   ER1,@VF_ST:32
    MOV.L   #128,ER4
    ADD.L   ER4,ER1
    MOV.L   ER1,@VF_ED:32
;--------------< FLASH writing >----------------------------------------
    MOV.W   #H'5A5F,R4              ;WDT Initial cofiguration
    MOV.W   R4,@RSTCSR
;
    MOV.W   #128,R4
    MOV.L   @W_ADR:32,ER5
    MOV.L   #R_BUF:32,ER6
    EEPMOV.W                        ;Write-in data -> R_BUF block transmission
;
    MOV.L   #FLMCR1,ER6
    BSR     PSWESET                 ;SWE bit set
;
    XOR.W   R4,R4                   ;Number-of-times counter clearance of writing
    MOV.W   R4,@COUNT:32
;======= Initila Verify ========================
    BSR     FWRITEVF                ;Initial program verification
    CMP.B   #OK,R0L
    BEQ     fwr_end                 ;The completion of initial verification
;
    CMP.B   #WNG,R0L
    BEQ     fwr_end                 ;A written in error
;
;======= Initial writing (There is additional writing) ======
fwrte10:
    MOV.L   #R_BUF:32,ER2            ;Re-write-in data
    MOV.L   #P30S_W,ER3            ;P pulse (30��S)
;
    BSR     FWRITE                  ;Program
    BSR     FWRITEVF                ;Program verification 
;
    MOV.B   R0L,@VF_RET:32
    MOV.L   #OW_BUF:32,ER2             ;Data write-in [ additional ]
    MOV.L   #P10S_W,ER3            ;P pulse�i10��S�j
;
    BSR     FWRITE                  ;An additional program
;
    MOV.B   @VF_RET:32,R0L
    CMP.B   #OK,R0L
    BEQ     fwr_end                 ;The completion of a program
;
    CMP.B   #WNG,R0L
    BEQ     fwr_end                 ;A written in error
;
    MOV.W   @COUNT:32,R0             ;Number-of-times counter of writing (@COUNT�{�P)
    INC.W   #1,R0
    MOV.W   R0,@COUNT:32
    CMP.W   #OW_COUNT,R0
    BNE     fwrte10                 ;Number-of-times judging (number of times of additional writing)
;
;====== Usually, it writes in (he has no additional writing) ======
fwrte20:
    MOV.L   #R_BUF:32,ER2              ;Re-write-in data
    MOV.L   #P200S_W,ER3           ;P pulse�i200��S�j
;
    BSR     FWRITE                  ;Program
    BSR     FWRITEVF                ;Program verification
    CMP.B   #OK,R0L
    BEQ     fwr_end                 ;The completion of a program
;
    CMP.B   #WNG,R0L
    BEQ     fwr_end                 ;A written in error
;
    MOV.W   @COUNT:32,R0            ;Number-of-times counter of writing (@COUNT�{�P)
    INC.W   #1,R0
    MOV.W   R0,@COUNT:32
    MOV.W   #MAX_WT,E0
    CMP.W   E0,R0
    BNE     fwrte20                 ;Number-of-times judging (number of times of the maximum writing) 
;
    MOV.B   #NG,R0L                 ;A write-in error 
;------- END ------------------------------
fwr_end:
    BSR     PSWECLEAR               ;SWE BIT CLEAR
;
fwr_rtn:
;    ANDC    #80,EXR                ; Enable all interrupts.
    BCLR.B  #FLSHE,@SYSCR2          ;FLASH DISABLE
    LDM.L   @SP+,(ER4-ER6)
    LDM.L   @SP+,(ER2-ER3)
    RTS
;*******************************************************************************
;                                 PFWECHECK                                    *
;                                 =========                                    *
; PURPOSE:                                                                     *
;    Checks the FWE, FLER bit in flash.                                        *
; ARGUMENTS:                                                                   *
;    NONE.                                                                     *
; RETURN:                                                                      *
;    R0L - 0 if test successful.                                               *
; NOTES:                                                                       *
;******************************************************************************/
PFWECHECK   .EQU    $
;----------------< FWE CHECK >----------------
    BCLR.B  #EAE,@BCRL              ;EXTERNAL ADDRESS ENABLE
    BSET.B  #FLSHE,@SYSCR2          ;FLASH ENABLE
    BTST.B  #FWE,@FLMCR1
    BNE     pfstt_010
;
    MOV.B   #FWE_ERR,R0L            ;FWE ERROR
    BRA     pfstt_end

pfstt_010:
    BTST.B  #FLER,@FLMCR2
    BEQ     pfstt_OK
;
    MOV.B   #FLER_ERR,R0L           ;FLER ERROR
    BRA     pfstt_end
;
pfstt_OK:
    MOV.B   #OK,R0L
;
pfstt_end:
    RTS
;
;*******************************************************************************
;                                 PSWESET                                      *
;                                 =======                                      *
; PURPOSE:                                                                     *
;    Sets SWE bit.                                                             *
; ARGUMENTS:                                                                   *
;    ER6 = Address of FLMCR register                                           *
; RETURN:                                                                      *
;    NONE.                                                                     *
; NOTES:                                                                       *
;******************************************************************************/
PSWESET     .EQU    $
    MOV.L   #SWES_W,ER1
    BSET.B  #SWE,@ER6               ;SWE bit set
pswes_lp:
    DEC.L   #1,ER1                  ;After [ SWE setup ] wait (more than 1��S)
    BNE     pswes_lp:16
;
    RTS
;
;*******************************************************************************
;                                 PSWECLEAR                                    *
;                                 =========                                    *
; PURPOSE:                                                                     *
;    Clears SWE bit.                                                           *
; ARGUMENTS:                                                                   *
;    ER6 = Address of FLMCR register                                           *
; RETURN:                                                                      *
;    NONE.                                                                     *
; NOTES:                                                                       *
;******************************************************************************/
PSWECLEAR   .EQU    $
    MOV.L   #SWEC_W,ER1
    BCLR.B  #SWE,@ER6               ;SWE bit clear
pswec_lp:
    DEC.L   #1,ER1                  ;After [ SWE release ] wait (more than 100��S) 
    BNE     pswec_lp:16
;
    RTS
;
;*******************************************************************************
;                                 FWRITEVF                                     *
;                                 ========                                     *
; PURPOSE:                                                                     *
;    Write-in Verification                                                     *
; ARGUMENTS:                                                                   *
;    ER6 = Address of FLMCR register                                           *
;    @W_ADR  = A write-in address                                              *
;    @R_BUF  = 128 bytes of re-write-in data                                   *
; RETURN:                                                                      *
;    R0L - 0 if test successful.                                               *
; NOTES:                                                                       *
;******************************************************************************/
FWRITEVF    .EQU    $
    MOV.W   #H'FFFF,R5              ;Dummy write data for an address latch
    MOV.L   #R_BUF:32,ER1              ;Re-write-in data buffer
    MOV.L   @W_ADR:32,ER2              ;Write-in data buffer address
    MOV.L   @VF_ST:32,ER4              ;A flash ROM write-in address
;===== Data buffer write-in         [ additional ] =====
    MOV.L   #OW_BUF:32,ER3             ;Data buffer write-in [ additional ]
;===============================================
;
    MOV.L   #PVS_W,ER0
    BSET.B  #PV,@ER6                ;PV bit setup
pvs_lp:
    DEC.L   #1,ER0                  ;After [ PV bit setup ] wait (more than 4��S)
    BNE     pvs_lp:16
;
FWVF10:
    MOV.L   #DLCH_W,ER0
    MOV.W   R5,@ER4                 ;Dummy write (latch) 
wdl_lp:
    DEC.L   #1,ER0                  ;Latch wait (more than 2��S)
    BNE     wdl_lp:16
;
    MOV.W   @ER4+,R0                ;Flash ROM data
;== Creation of data write-in [ additional ] ===
    MOV.W   @ER1,E0                 ;It writes in the first stage (it is used 6 times)
    OR.W    R0,E0                   ;@COUNT = 0,1,2,3,4,5 Effective data
    MOV.W   E0,@ER3                 ;@COUNT = 6�`999      Invalid data
    ADDS    #2,ER3
;===============================================
    NOT.W   R0
    MOV.W   @ER2,E0
    OR.W    R0,E0                   ;Reversal data OR write-in data
    MOV.W   E0,@ER1                 ;Re-write-in data setup
    ADDS    #2,ER1
    MOV.W   @ER2+,E0
    AND.W   E0,R0                   ;At the time of the read-out data 0 AND write-in data 1
    BNE     FWVF30                  ;To the error which cannot be written
;
    CMP.L   #(R_BUF+128):32,ER1
    BNE     FWVF10                  ;128 byte verification
;
    MOV.B   #NG,R0L                 ;NG Set
    MOV.L   #R_BUF:32,ER1              ;Re-write-in data head address
FWVF20:
    MOV.W   @ER1+,E0
    CMP.W   R5,E0                   ;Is it H'FF altogether 128 bytes of re-write-in data?
    BNE     FWVF40                  ;Judgment  If it is not H'FF, it is to a verification error
;
    CMP.L   #(R_BUF+128):32,ER1
    BNE     FWVF20
;
    MOV.B   #OK,R0L                 ;OK Set
    BRA     FWVF40
;
FWVF30:
    MOV.B   #WNG,R0L                ;WNG Set
;-------  FLASH ROM ERR  -----------------------
FWVF40:
    MOV.L   #PVC_W,ER4
    BCLR.B  #PV,@ER6                ;PV bit clearance
pvc_lp:
    DEC.L   #1,ER4                  ;After [ PV bit release ] weight (more than 2��S)
    BNE     pvc_lp:16
;
    RTS
;
;*******************************************************************************
;                                 FWRITE                                       *
;                                 ======                                       *
; PURPOSE:                                                                     *
;    Write-in Module                                                           *
; ARGUMENTS:                                                                   *
;    ER6 = Address of FLMCR register                                           *
;    @VF_ST  = A write-in address                                               *
;    ER2     = The head address of writing                                     *
;    ER3     = P bit set time( 10��S or 30��S or 200��S )                      *
; RETURN:                                                                      *
;    NONE                      .                                               *
; NOTES:                                                                       *
;******************************************************************************/
FWRITE      .EQU    $
    MOV.L   @VF_ST:32,ER1              ;A write-in address
;
    MOV.W   #128,E0
FWRT10:
    MOV.B   @ER2+,R0L               ;Re-write-in data (byte unit)
    MOV.B   R0L,@ER1                ;Dummy write (byte unit) 
    ADDS    #1,ER1
    DEC.W   #1,E0
    BNE     FWRT10                  ;128 bytes   Repetition 
;
    MOV.W   #H'A579,R0              ;SYSTEM CLOCK(1/64)
    MOV.W   R0,@TCSR                ;WDT setup
    MOV.L   #PSUS_W,ER4
    BSET.B  #PSU,@ER6               ;PSU bit set
psus_lp:
    DEC.L   #1,ER4                  ;After [ PSU bit setup ] wait (more than 50��S)
    BNE     psus_lp:16
;======= WRITE pulse ===========================
    MOV.L   ER3,ER4
    BSET.B  #PR,@ER6                 ;P bit set (writing) 
ps_lp:
    DEC.L   #1,ER4                  ;Write-in time�F10��S or 30��S or 200��S
    BNE     ps_lp:16
;===============================================
    BCLR.B  #PR,@ER6                 ;Clear in P bit
    MOV.L   #PC_W,ER4
pc_lp:
    DEC.L   #1,ER4                  ;After [ P bit release ] wait (5��S)
    BNE     pc_lp:16
;
    MOV.L   #PSUC_W,ER4
    BCLR.B  #PSU,@ER6               ;Clear in PSU bit
psuc_lp:
    DEC.L   #1,ER4                  ;After [ PSU bit release ] wait (more than 5��S)
    BNE     psuc_lp:16
;
    MOV.W   #H'A500,R0
    MOV.W   R0,@TCSR                ;WDT stop
    RTS
    .AENDI
;*******************************************************************************
;                                 __TestRamCell                                *
;                                 =============                                *
; PURPOSE:                                                                     *
;    Do RAM contents diagnostic in a 4 byte cell.                              *
; ARGUMENTS:                                                                   *
;    ER0 - 4 byte address of the location to be tested.                        *
; RETURN:                                                                      *
;    R0L - 1 if test is successful, 0 if failed.                               *
; NOTES:                                                                       *
;    The registers used in this function are saved on stack and restored while *
;    exiting from function. R0 and R1 need not be saved. Also Saves and        *
;    restores the contents of interrupt mask register.                         *
;    Disables all interrupts for the duration of the test.                     *
;******************************************************************************/
__TestRAMCell:
    STM.L   (ER2-ER3),@-SP          ; Save ER2 and ER3
    STC.B   EXR,R3L                 ; Store present interrupt mask
    ORC     #07,EXR                 ; Disable all interrupts.
    MOV.L   @ER0,ER2                ; Save contents at the test location.
    MOV.L   #H'55AA55AA,ER1         ; Test with first pattern
    MOV.L   ER1,@ER0
    MOV.L   @ER0,ER1
    CMP.L   #H'55AA55AA,ER1
    BNE     RAMTEST_FAIL
    MOV.L   #H'AA55AA55,ER1         ; Test with second pattern
    MOV.L   ER1,@ER0
    MOV.L   @ER0,ER1
    CMP.L   #H'AA55AA55,ER1
    BNE     RAMTEST_FAIL
    MOV.B   #1,R1L                  ; Test successful, prepare to return TRUE.
    BRA     RAMTEST_EXIT
RAMTEST_FAIL:
    MOV.B   #0,R1L                  ; Test failed, prepare to return FALSE.
RAMTEST_EXIT:
    MOV.L   ER2,@ER0
    MOV.B   R1L,R0L                 ; Return prepared return value.
    LDC.B   R3L,EXR                 ; Restore the original interrupt mask
    LDM.L   @SP+,(ER2-ER3)          ; Restore ER2 and ER3
    RTS



;*******************************************************************************
;                              __TestCPURegisters                              *
;                              ==================                              *
; PURPOSE:                                                                     *
;    Do read/write diagnostics on CPU internal registers.                      *
; ARGUMENTS:                                                                   *
;    None.                                                                     *
; RETURN:                                                                      *
;    R0L - 1 if test is successful, 0 if failed.                               *
; NOTES:                                                                       *
;    The registers used in this function are saved on stack and restored while *
;    exiting from function. R0 and R1 need not be saved. Also Saves and        *
;    restores the contents of interrupt mask register.                         *
;    Disables all interrupts for the duration of the test.                     *
;******************************************************************************/
__TestCPURegisters:
    STM.L   (ER2-ER3),@-SP          ; Save ER2 and ER3
    STM.L   (ER4-ER6),@-SP          ; Save ER4 to ER6
    STC.B   EXR,R1L                 ; Store present interrupt mask
    PUSH.L  ER1
    ORC     #07,EXR                 ; Disable all interrupts.
    MOV.L   #H'A5A5A5A5,ER0
    MOV.L   #H'A5A5A5A5,ER1
    CMP.L   ER0,ER1
    BNE     REGTEST_FAIL
    MOV.L   #H'5A5A5A5A,ER2
    MOV.L   #H'5A5A5A5A,ER3
    CMP.L   ER2,ER3
    BNE     REGTEST_FAIL
    XOR.L   ER2,ER0
    OR.L    ER2,ER1
    CMP.L   ER0,ER1
    BNE     REGTEST_FAIL
    NOT.L   ER2
    AND.L   ER2,ER3
    BNE     REGTEST_FAIL
    MOV.L   #H'A5A5A5A5,ER3
    MOV.L   #H'A5A5A5A5,ER4
    CMP.L   ER3,ER4
    BNE     REGTEST_FAIL
    MOV.L   #H'5A5A5A5A,ER5
    MOV.L   #H'5A5A5A5A,ER6
    CMP.L   ER5,ER6
    BNE     REGTEST_FAIL
    XOR.L   ER5,ER3
    OR.L    ER5,ER4
    CMP.L   ER3,ER4
    BNE     REGTEST_FAIL
    NOT.L   ER5
    AND.L   ER5,ER6
    BNE     REGTEST_FAIL
    MOV.B   #1,R0L                  ; Return 1 (TRUE)
    BRA     REGTEST_EXIT
REGTEST_FAIL:
    MOV.B   #0,R0L                  ; Return 0 (FALSE)
REGTEST_EXIT:
    POP.L   ER1
    LDM.L   @SP+,(ER4-ER6)          ; Restore ER4 to ER6
    LDM.L   @SP+,(ER2-ER3)          ; Restore ER2 and ER3
    LDC.B   R1L,EXR                 ; Restore the original interrupt mask
    RTS
;*******************************************************************************
;                                 __EraseFlashBlock                            *
;                                 =================                            *
; PURPOSE:                                                                     *
;    Erase a specified block in Flash ROM.                                     *
; ARGUMENTS:                                                                   *
;    R0L - block number to be erased.                                          *
; RETURN:                                                                      *
;    R0L - 0 if block erase is successful.                                     *
; NOTES:                                                                       *
;    ER6       = The relative address of FLMCR register                        *
;    ER5       = EBR register is an address absolutely                         *
;    @VF_ST    = The head address of the block to erase                        *
;    @VF_ED    = The end address of the block to erase                         *
;******************************************************************************/
    .AIF "INCLUDE_FLASH_ROUTINES" EQ "1"
__EraseFlashBlock:
;disable all interrupts
    ORC     #07,EXR             ; Disable all interrupts.
    STM.L   (ER4-ER6),@-SP
    MOV.B   R0L,@BLK_NO:32
;
    BSR     EFWECHECK           ;FWE,FLER BIT CHECK
    CMP.B   #OK,R0L
    BNE     blk_rtn
;
    MOV.B   @BLK_NO:32,R0L
    CMP.B   #BLK_MAX,R0L
    BCS     blk_010
    MOV.B   #BLK_ERR,R0L        ;Block No. error 
    BRA     blk_rtn
;
blk_010:
    CMP.B   #MAXBLK1,R0L
    BCC     blk_020
;
;-----------------------------------------------
    BSR     GET_TAD1        ; ER0 <- block table address
RB_ADR1:
    XOR.L   ER1,ER1
    MOV.B   @BLK_NO:32,R1L
    SHLL.L  #2,ER1
    ADD.L   ER1,ER0
;
    MOV.L   #FLMCR1,ER6         ;Address�iH'000000�`H'007FFF�jerase
    MOV.L   #EBR1,ER5
    BRA     blk_030
;
blk_020:
    BSR     GET_TAD2            ;ER0 <- block table address
RB_ADR2:
    XOR.L   ER1,ER1
    MOV.B   @BLK_NO:32,R1L
    SUB.L   #8,ER1
    SHLL.L  #2,ER1
    ADD.L   ER1,ER0
    MOV.L   #FLMCR1,ER6         ;Address�iH'008000�`H'05FFFF�jerase
    MOV.L   #EBR2,ER5
;
blk_030:
    MOV.L   @ER0+,ER4           ;The top address of the block to erase 
    MOV.L   @ER0,ER0            ;The end address of the block to erase
    MOV.L   ER4,@VF_ST:32
    MOV.L   ER0,@VF_ED:32
;
    BSR     ESWESET             ;SWE bit set
;
    MOV.W   #H'5A5F,R0          ;WDT Initial cofiguration
    MOV.W   R0,@RSTCSR
;-----------------------------------------------
    XOR.W   R0,R0               ;Number-of-times counter clearance of elimination 
    MOV.W   R0,@COUNT:32
;
;======= INITIAL VERIFY =======================
    BSR     FERASEVF            ;FERASEVF MODULE
    CMP.B   #OK,R0L
    BEQ     blk_end             ;The completion of initial verification
;
;======= ERASE VERIFY ======================
blk_040:
    BSR     FERASE              ;FERASE MODULE
    BSR     FERASEVF            ;FERASEVF MODULE
    CMP.B   #OK,R0L
    BEQ     blk_end             ;Erase completion
;
    MOV.W   @COUNT:32,R0         ;Clear in the counter of the number of times of erase (@COUNT�{�P)
    INC.W   #1,R0
    MOV.W   R0,@COUNT:32
    MOV.W   #MAX_ET,E0
    CMP.W   E0,R0
    BNE     blk_040             ;Number-of-times judging (number of times of the maximum erase)
;------- ABNORMAL END  ------------------------
    MOV.B   #ERS_ERR,R0L        ; The set of the number-of-times error of the maximum erase
;
blk_end:
    BSR     ESWECLEAR           ;SWE BIT CLEAR
;
blk_rtn:
    BCLR.B  #FLSHE,@SYSCR2      ;FLASH DISABLE
;    ANDC    #80,EXR             ; Enable all interrupts.
    LDM.L   @SP+,(ER4-ER6)
    RTS
;
GET_TAD1    .EQU    $
    MOV.L   @ER7,ER0
    MOV.L   #BLOCKADR1-RB_ADR1,ER1
    ADD.L   ER1,ER0
    RTS
;
GET_TAD2    .EQU    $
    MOV.L   @ER7,ER0
    MOV.L   #BLOCKADR2-RB_ADR2,ER1
    ADD.L   ER1,ER0
    RTS
;*******************************************************************************
;                                 EFWECHECK                                    *
;                                 =========                                    *
; PURPOSE:                                                                     *
;    Checks the FWE, FLER bit in flash.                                        *
; ARGUMENTS:                                                                   *
;    NONE.                                                                     *
; RETURN:                                                                      *
;    R0L - 0 if test successful.                                               *
; NOTES:                                                                       *
;******************************************************************************/
EFWECHECK   .EQU    $
    BCLR.B  #EAE,@BCRL              ;EXTERNAL ADDRESS ENABLE
    BSET.B  #FLSHE,@SYSCR2          ;FLASH ENABLE
    BTST.B  #FWE,@FLMCR1
    BNE     efstt_010
;
    MOV.B   #FWE_ERR,R0L            ;FWE ERROR
    BRA     efstt_end

efstt_010:
    BTST.B  #FLER,@FLMCR2
    BEQ     efstt_OK
;
    MOV.B   #FLER_ERR,R0L           ;FLER ERROR
    BRA     efstt_end
;
efstt_OK:
    MOV.B   #OK,R0L
;
efstt_end:
    RTS
;
;*******************************************************************************
;                                 ESWESET                                      *
;                                 =======                                      *
; PURPOSE:                                                                     *
;    Sets SWE bit.                                                             *
; ARGUMENTS:                                                                   *
;    ER6 = Address of FLMCR register                                           *
; RETURN:                                                                      *
;    NONE.                                                                     *
; NOTES:                                                                       *
;******************************************************************************/
ESWESET     .EQU  $
    MOV.L   #SWES_W,ER1
    BSET.B  #SWE,@ER6           ;SWE bit set
eswes_lp:
    DEC.L   #1,ER1              ;After [ SWE setup ] wait (more than 1uS)
    BNE     eswes_lp:16
;
    RTS
;
;*******************************************************************************
;                                 ESWECLEAR                                    *
;                                 =========                                    *
; PURPOSE:                                                                     *
;    Clears SWE bit.                                                           *
; ARGUMENTS:                                                                   *
;    ER6 = Address of FLMCR register                                           *
; RETURN:                                                                      *
;    NONE.                                                                     *
; NOTES:                                                                       *
;******************************************************************************/
ESWECLEAR   .EQU    $
    MOV.L   #SWEC_W,ER1
    BCLR.B  #SWE,@ER6           ;SWE bit clear
eswec_lp:
    DEC.L   #1,ER1              ;After [ SWE release ] wait (more than 100uS) 
    BNE     eswec_lp:16
;
    RTS
;
;*******************************************************************************
;                                 FERASEVF                                     *
;                                 ========                                     *
; PURPOSE:                                                                     *
;    Erase verification Module.                                                *
; ARGUMENTS:                                                                   *
;    ER6     = Address of FLMCR register                                       *
;    @VF_ST  = The top address to verify                                       *
;    @VF_ED  = The end address to verify                                       *
; RETURN:                                                                      *
;    R0L - 0 if successful.                                                    *
; NOTES:                                                                       *
;******************************************************************************/
FERASEVF    .EQU    $
    MOV.L   @VF_ST:32,ER1
    MOV.W   #H'FFFF,E0          ;erase check data
;
    MOV.L   #EVS_W,ER4
    BSET.B  #EV,@ER6            ;EV bit set
evs_lp:
    DEC.L   #1,ER4              ;After [ EV bit setup ] wait (more than 20��S)
    BNE     evs_lp:16
;
VRF_010:
    MOV.L   #DLCH_W,ER4
    MOV.W   E0,@ER1             ;A dummy write�iaddress�Elatch�j
edl_lp:
    DEC.L   #1,ER4              ;After [ latch ] wait�imore than 2��S�j
    BNE     edl_lp:16
;
    MOV.W   @ER1+,R0
    CMP.W   E0,R0               ;verify
    BEQ     VRF_020             ;It ends, when having not eliminated an object address (non JMP)
;
    MOV.B   #NG,R0L             ;NG set
    BRA     VRF_030
;
VRF_020:
    MOV.L   @VF_ED:32,ER4
    CMP.L   ER1,ER4             ;Are they all address ends?
    BNE     VRF_010             ;NO:JMP
    MOV.B   #OK,R0L             ;YES:OK set
;
VRF_030:
    MOV.L   #EVC_W,ER4
    BCLR.B  #EV,@ER6            ;Clear in EV bit
evc_lp:
    DEC.L   #1,ER4              ;After [ EV bit release ] weight�imore than 4��S�j
    BNE     evc_lp:16
;
    RTS
;*******************************************************************************
;                                 FERASE                                       *
;                                 ======                                       *
; PURPOSE:                                                                     *
;    Erase Module.                                                             *
; ARGUMENTS:                                                                   *
;    ER6    = Address of FLMCR register                                        *
;    ER5    = EBR register is an address absolutely                            *
;    @BLK_NO = The bit number of the block for erasing                         *
; RETURN:                                                                      *
;    NONE.                                                                     *
; NOTES:                                                                       *
;******************************************************************************/
FERASE    .EQU  $
    MOV.B   @BLK_NO:32,R0H
    BSET.B  R0H,@ER5            ;It sets to the bit EBR of the block for erase
    MOV.W   #H'A57F,R0          ;SYSTEM CLOCK(1/131072)
    MOV.W   R0,@TCSR            ;WDT setup
    MOV.L   #ESUS_W,ER4
    BSET.B  #ESU,@ER6           ;ESU bit set
esus_lp:
    DEC.L   #1,ER4              ;After [ ESU bit setup ] wait(more than 100��S)
    BNE     esus_lp:16
;
    MOV.L   #ES_W,ER4          ;10mS
;======= ERASE pulse ===========================
    BSET.B  #E,@ER6             ;E bit set
es_lp:
    DEC.L   #1,ER4              ;Erase time�F10mS
    BNE     es_lp:16
;===============================================
    BCLR.B  #E,@ER6             ;Clear in E bit
    MOV.L   #EC_W,ER4
ec_lp:
    DEC.L   #1,ER4              ;After [ E bit release ] wait(more than 10��S)
    BNE     ec_lp:16
;
    MOV.L   #ESUC_W,ER4
    BCLR.B  #ESU,@ER6           ;Clear in ESU bit
esuc_lp:
    DEC.L   #1,ER4              ;After [ ESU bit release ] wait(more than 10��S)
    BNE     esuc_lp:16
;
    MOV.W   #H'A500,R0
    MOV.W   R0,@TCSR            ;WDT stop
    MOV.B   @BLK_NO:32,R0H
    BCLR.B  R0H,@ER5            ;Clear in the block for erasing in EBR register
    RTS
;
    .AENDI
;*******************************************************************************
;                          FLASH ROM BLOCK ADDRESS TABLE                       *
;*******************************************************************************
    .AIF "INCLUDE_FLASH_ROUTINES" EQ "1"
BLOCKADR1    .EQU   $
    .DATA.L     H'00000000  ; EB0   4KBYTE
    .DATA.L     H'00001000  ; EB1   4KBYTE
    .DATA.L     H'00002000  ; EB2   4KBYTE
    .DATA.L     H'00003000  ; EB3   4KBYTE
    .DATA.L     H'00004000  ; EB4   4KBYTE
    .DATA.L     H'00005000  ; EB5   4KBYTE
    .DATA.L     H'00006000  ; EB6   4KBYTE
    .DATA.L     H'00007000  ; EB7   4KBYTE
    .DATA.L     H'00008000  ; END_ADRESS1
BLOCKADR2    .EQU   $
    .DATA.L     H'00008000  ; EB8  32KBYTE
    .DATA.L     H'00010000  ; EB9  64KBYTE
    .DATA.L     H'00020000  ; EB10 64KBYTE
    .DATA.L     H'00030000  ; EB11 64KBYTE
    .DATA.L     H'00040000  ; EB12 64KBYTE
    .DATA.L     H'00050000  ; EB13 64KBYTE
    .DATA.L     H'00060000  ; END_ADRESS2
    .DATA.L     H'00000000  ; DUMMY
    .DATA.L     H'00000000  ; DUMMY
_BLKE_END   .EQU    $
    .AENDI
;*******************************************************************************
; below routines are only for DI-SOE module
    .AIF "H8S_2319C" EQ "1"
;********************************************************************************
;                                 __SolveState                                  *
;                                 =============                                 *
; PURPOSE:                                                                      *
;    Debounce Algorithm which keeps track of Transitions occuring at Inputs     *
;    to Post an Event alongwith Timestamp by traversing through various states  *
; ARGUMENTS:                                                                    *
;    ER0 - 4 byte address of the STMCHINPTBUFF structure                        *
; RETURN:                                                                       *
;    ER1 - If the Transition has occured , sets the Flag to Log an Event        *
; NOTES:                                                                        *
;    The registers used in this function are saved on stack and restored while  *
;    exiting from function.ER2 and ER3 are used to hold the STMCHINPTBUFF struct*
;    elements .ER2 4 byte register holds Target,bTransition,bLast values        *
;    respectively and ER3 4 byte register holds Count,bNew,bOld values          *
;*******************************************************************************/

__SolveState:
    STM.L   (ER2-ER3),@-SP        ; Save ER2 and ER3 on stack.
    STM.L   (ER4-ER6),@-SP        ; Save ER4 to ER6 on stack.
    MOV.W   @ER0,R3               ; Move Target,Count Data to R3.
    INC.L   #2,ER0
    MOV.W   @ER0,R4               ; Move bTransition,bLast Data to R4.
    INC.L   #2,ER0
    MOV.W   @ER0,R5               ; Move bNew,bOld Data to R5
    MOV.B   #0,R6L                ; Reset the return value every time
    CMP.B   #1,R4H                ; Check whether Transition has occured.
    BNE     STATE_J               ; Branch to state J if not in Transition.
    CMP.B   R4L,R5H               ; Comparing Last and New value .
    BNE     STATE_K               ; Branch to state K if Last not equal to New value.
    INC     R3L                   ; Increment the count .
    CMP.B   R3H,R3L               ; Comparing the Target and Count values.
    BNE     STATE_D               ; Branch to state D if Target and Count values are not equal.
STATE_A:
    CMP.B   R5L,R5H               ; Compare Old and New value .
    BNE     STATE_H               ; Branch to state H if the Old and New value are not equal.
    BRA     STATE_I               ; Branch to state I and set Transition to FALSE and Count value to Zero.
STATE_C:
    MOV.B   #1,R4H                ; Set Transition to True .
    MOV.B   #1,R3L                ; Set Count to One
    MOV.B   #1,R6L                ; Return value for function caller
    CMP.B   #0,R3H                ; if Target(Debounce) is Zero, Pv Change Event to be Posted
    BEQ     STATE_A 
    CMP.B   #1,R3H                ; if Target(Debounce) is one, Pv Change Event to be Posted
    BEQ     STATE_A 
STATE_D:
    MOV.B   R5H,R4L               ; Set New to Last value
    MOV.W   R5,@ER0
    DEC.L   #2,ER0
    MOV.W   R4,@ER0
    DEC.L   #2,ER0
    MOV.W   R3,@ER0
    MOV.B   R6L,R0L
    LDM.L   @SP+,(ER4-ER6)        ; Restore from stack to ER4 to ER6
    LDM.L   @SP+,(ER2-ER3)        ; Restore from stack to ER2 and ER3
    RTS                           ; Return 
STATE_H:
    MOV.B   R4H,@ER1              ; Set the Flag to Post an Event and store Timestamp of event.
STATE_I:
    MOV.B   R5H,R5L               ; store Old from New value 
    MOV.B   #1,R3L                ; Set Count value to One
    MOV.B   #0,R4H                ; Set Transition to FALSE .
    BRA     STATE_D               ; Branch to state D 
STATE_J:
    CMP.B   R4L,R5H               ; Comparing Last and New value .
    BNE     STATE_C               ; Branch to state C .
    BRA     STATE_D               ; Branch to state D .
STATE_K:
    MOV.B   #1,R3L                ; Setting Count equal to One .
    BRA     STATE_D               ; Branch to state D
; end of DI-SOE modules specific routines
    .AENDI
;*******************************************************************************
  .END ; Must for marking end of file. Insert any code before this line
