/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohardware.cpp                                              *
*    Description : Analog output hardware encapsulation.                       *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aohardware.hpp"
#include "aohslot.hpp"
#include "aohboxslot.hpp"

#if !LOWCOST
/*******************************************************************************
*                        clsAoHardware::clsAoHardware                          *
*                        ============================                          *
* PURPOSE:                                                                     *
*    Sets the SPI interface and transfers the DAC Word                         *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
clsAoHardware::clsAoHardware(VOID)
{
    DacByte.DAC.Commmand = LD_INPUT_AND_DAC_REG;
    DacByte.DAC.SubBit   = 0;
    DacByte.DAC.Count    = 0;

    SPIRESET = 0x1;

    //Initialize the Global Interrupt Enable for SPI Interface access
    DAC_SPI.IGER = 0x80;
    //Initialize the Individual Interrupt Enable for SPI Interface access
    DAC_SPI.IER = 0x00;//no interrupts enabled 

    //Write into the SPI Control register:low byte
    // Bit No ------- Functionality     
    //--------------------------------------------   
    // 7: Manual SS Assertion Enable : "1"
    // 6:
    // 5:
    // 4:
    // 3:
    // 2:Master Setting             : "1"
    // 1:SPI System Enable          : "1"
    // 0:  
    DAC_SPI.CRL = 0x86;
    //Write into the SPI Control register:high byte
    // Bit No ------- Functionality     
    //--------------------------------------------   
    // 7: Master Transaction Inhibit : "0"
    // 6:
    // 5:
    // 4:
    // 3:
    // 2:
    // 1:
    // 0:  
    DAC_SPI.CRH = 0x00; 

    //Write into the SPI Slave Select register:
    // Bit No ------- Functionality     
    //--------------------------------------------   
    // 7: 
    // 6:
    // 5:
    // 4:
    // 3:
    // 2:
    // 1:
    // 0:Select slave CSEL0_n :    "1"
    DAC_SPI.SSR = 0xFF; 
}
/*******************************************************************************
*                           clsAoHardware::DriveDac                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::DriveDac(UINT16 a_uiDacCount) {
    DacByte.DAC.Count = a_uiDacCount; // Form DAC word
    DAC_SPI.SSR = 0x02; // Assert slave select.
    DAC_SPI.TXD = DacByte.ucByte[0]; // Transmit DAC byte 0
    DAC_SPI.TXD = DacByte.ucByte[1]; // Transmit DAC byte 1
    while (0x04 != (DAC_SPI.SR & 0x04)); // Wait for TX FIFO to be empty.
    DAC_SPI.SSR = 0xFF; // Deassert slave select.
    IdleWait(DAC_SETTLE_TIME);
}
/*******************************************************************************
*                         clsAoHardware::DriveOutput                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::DriveOutput(UINT8 a_ucSlotNum, DELAY_TYPE a_eDelayType)
{
    // First of all block execution of loopback test.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    UINT16 uiDacCount = ((clsAohSlot *)pDatabase[a_ucSlotNum])->GetOutDACImg();
    DriveDac(uiDacCount);

    // Open output mux channel.
    UINT8 ucChanAddr = a_ucSlotNum - 1;

    // Block all interrupts during MUX channel selection 
    // so that UKEY monoshot will not expire.
    // NOTE : It is important to keep ALL the interrupts disabled until
    // the MUX is enabled. Both address selection and enabling of the MUX
    // take place in one UKEY trigger. The channel settle time is only one 
    // micro second and this is not expected to affect IOL operation. It was
    // observed that if IOL interrupt was enabled for the one micro second 
    // duration for which we wait for MUX channel settling, the MUX enabling
    // could fail some times. This happens if the IOL interrupt took exact
    // amount of time as the UKEY pulse time (40 micro second) and when it 
    // returned the UKEY pulse was terminating. Even having a second UKEY
    // trigger will not solve the problem as the UKEY is not retriggerable.
    set_imask_exr(LVLPRI_HIGHEST);
    UKEY   = 1; // Trigger oneshot.
    OUTSEL = ucChanAddr; // Drive address lines D3 to D0.
    IdleWait(MUX_CHANNELSEL_SETTLE_TIME);
    ucChanAddr |= MUX_ENABLE;
    OUTSEL = ucChanAddr; // Enable or open MUX channel.
    set_imask_exr(LVLPRI_TICK);

    // Readback and test MUX channel selection.
    if ((OUTSEL & OUTPUT_ADDRESS_READBACK_MASK) != ucChanAddr) {
        HardFail(HF_BD_OUTPUT_MUX,AOHARDWARE_CPP,__LINE__);
    }

    UINT16 usIteration = 1;
    UINT16 usCapChargeTime = DEFAULT_OUTPUT_CAPACITORCHARGE_TIME;
    switch (a_eDelayType) {
        case CalibrationWithExtendedDelay : //100 ms
            // Allow STC when waiting for extended delay so that watchdog refresh
            // will take place. There is no issue with the loopback as extended delay
            // is called only during calibration when the loopback is anyway disabled.
            set_imask_exr(LVLPRI_IOPROC);
            usIteration = 10; //10 times 10 ms. This mechanism avoids overflow of UINT16
            usCapChargeTime = CALIBRATION_EXTENDED_CAPACITORCHARGE_TIME;
            break;
        case CalibrationWithMinimumDelay:   //150 us
            usIteration = 1;
            usCapChargeTime = CALIBRATION_MINIMUM_CAPACITORCHARGE_TIME;
            break;
    }

    do { IdleWait(usCapChargeTime); } while(--usIteration);

    ucChanAddr &= ~MUX_ENABLE;
    // Block all interrupts again for protecting UKEY trigger.
    set_imask_exr(LVLPRI_HIGHEST);
    UKEY   = 1; // Trigger oneshot.
    OUTSEL = ucChanAddr; // Disable or close mux channel.

    // Restore original interrupt mask.
    set_imask_exr(ucSaveExr);
}
#else  // LowCost
/*******************************************************************************
*                         clsAoHardware::clsAoHardware                         *
*                         ==========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
clsAoHardware::clsAoHardware(VOID)
{
    DacCmd.DAC.reg_address = 0;
    DacCmd.DAC.Data     = 0;
}
/*******************************************************************************
*                           clsAoHardware::DriveDac                            *
*                           =======================                            *
* PURPOSE: Drive the Data into the DAC and apply latch pulse.                  *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::DriveDac(UINT16 a_uiDacCount,UINT8 a_uiChanAddr) 
{
    // Selection of DAC for each channel to drive output
    dac_mux_select(a_uiChanAddr);
    write_dac_data(DAC_REG_DR,a_uiDacCount); // Write the data to DAC
    toggle_dac_latch(); //Apply latch pulse
    IdleWait(DAC_SETTLE_TIME); 
    dac_mux_select(DESELECT_DAC_MASK); // deselecting the DAC
}
/*******************************************************************************
*                         clsAoHardware::DriveOutput                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::DriveOutput(UINT8 a_ucSlotNum, DELAY_TYPE a_eDelayType)
{

    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    UINT16 uiDacCount = ((clsAohSlot *)pDatabase[a_ucSlotNum])->GetOutDACImg();
   
    UINT8 ucChanAddr = a_ucSlotNum-1;
    // Write the Data into the DAC
    DriveDac(uiDacCount,ucChanAddr);

    UINT16 usIteration = 1;
    UINT16 usCapChargeTime = DEFAULT_OUTPUT_CAPACITORCHARGE_TIME;
    switch (a_eDelayType) {
        case CalibrationWithExtendedDelay : //100 ms
            // Allow STC when waiting for extended delay so that watchdog refresh
            // will take place. There is no issue with the loopback as extended delay
            // is called only during calibration when the loopback is anyway disabled.
            set_imask_exr(LVLPRI_IOPROC);
            usIteration = 10; //10 times 10 ms. This mechanism avoids overflow of UINT16
            usCapChargeTime = CALIBRATION_EXTENDED_CAPACITORCHARGE_TIME;
            break;
        case CalibrationWithMinimumDelay:   //150 us
            usIteration = 1;
            usCapChargeTime = CALIBRATION_MINIMUM_CAPACITORCHARGE_TIME;
            break;
    }

    do { IdleWait(usCapChargeTime); } while(--usIteration);

    // Restore original interrupt mask.
    set_imask_exr(ucSaveExr);
}
/*******************************************************************************
*                      clsAoHardware::DisableOutputDrive                       *
*                      =================================                       *
* PURPOSE: Disabling the output Drive of individual DAC                        *
* ARGUMENTS: Channel Number                                                    *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::DisableOutputDrive(UINT8 a_ucSlotNum)
{
    OUTSEL = (a_ucSlotNum - 1);
    write_dac_data(DAC_REG_CR,0x0007);

    DAC_LATCH = 1;  // High
    NOP;
    NOP;
    NOP; 
    DAC_LATCH = 0;  // Low
}
/*******************************************************************************
*                      clsAoHardware::EnableOutputDrive                        *
*                      ================================                        *
* PURPOSE: Enabling the output Drive of individual DAC                         *
* ARGUMENTS: Channel Number                                                    *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
VOID clsAoHardware::EnableOutputDrive(UINT8 a_ucSlotNum)
{
    OUTSEL = (a_ucSlotNum - 1);
    write_dac_data(DAC_REG_CR,0x10F7);

    DAC_LATCH = 1;  // High
    NOP;
    NOP;
    NOP; 
    DAC_LATCH = 0;  // Low
}
/*******************************************************************************
*                           Private HW Access Routines                         *
*                                   ==========                                 *
* PURPOSE:                                                                     *
*******************************************************************************/
void clsAoHardware::toggle_dac_latch()
{
    DAC_LATCH = 1; // High
    NOP;
    NOP;
    DAC_LATCH = 0; // low
}

void clsAoHardware::toggle_dac_clear(void)
{
    DAC_CLEAR = 1; // High
    NOP;
    DAC_CLEAR = 0; // low
}

void clsAoHardware::write_dac_data(UINT8 add,UINT16 data)
{
    UINT8 temp;
    DACCMD dac_data,temp_data;

    dac_data.DAC.reg_address = add;

    if ( add == DAC_REG_DR )               // Do only for data register
    dac_data.DAC.Data = ( data << 4 );     // data is 12 bit. remaining 4 bits are don't care bits.
    else
    dac_data.DAC.Data = data;
    // DAC command is 24bit data.Bit 23-16 is register address 
    // and Bit 15-4 is data, remaining 3-0 bits are Don't care
    for( temp = 24; temp >0;temp--)
    {
        NOP;
        temp_data = dac_data;
        DAC_SCLK = 0; // Low
        SDO = 0x01 & (temp_data.DacCmd >> (temp - 1));
        NOP;        
        DAC_SCLK = 1; // High
    }
    DAC_SCLK = 0;     // Low
}

void clsAoHardware::dac_mux_select(int a_ucSlotNum)
{
     
       OUTSEL = a_ucSlotNum;
       NOP;
}


#endif
/*******************************************************************************
*                    clsAoHardware::OpenLoopbackMux                            *
*                    ==============================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*                                                                              *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::OpenLoopbackMux(UINT8 a_ucSlotNum, BOOL bProcSF) {
    UINT8 ucChan = LOOPBACK_ADDRESS[a_ucSlotNum - 1];
    INPSEL = ucChan; // Drive address lines 
    IdleWait(MUX_CHANNELSEL_SETTLE_TIME); // Wait 1 micro second
#if !LOWCOST
    ucChan |= MUX_ENABLE;
    INPSEL = ucChan; // Enable or open MUX channel.
#endif

    UINT8 ucRetryCount;
    for (ucRetryCount = 0; ucRetryCount < MUX_READBACK_RETRYCOUNT; ucRetryCount++) {
        if ((INPSEL & LOOPBACK_ADDRESS_READBACK_MASK) == ucChan ) break;
        INPSEL = ucChan; // Enable or open MUX channel.
    }
    if (bProcSF) {
        ((clsAohBoxSlot *)pDatabase[0])->AddSoftfailEvent(
        EVENTTYPE_NORMAL,SF_DIAGCTFL,(MUX_READBACK_RETRYCOUNT == ucRetryCount),0);
    }
    IdleWait(LOOPBACK_COMPARATORSETTLE_TIME - DAC_SETTLE_TIME);
    return (MUX_READBACK_RETRYCOUNT == ucRetryCount);
}
/*******************************************************************************
*                               ReadComparatorOutput                           *
*                               ====================                           *
* PURPOSE:                                                                     *
*                                                                              *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::ReadComparatorOutput(VOID) {
    const UINT8 _MAX_READINGS_ = 3;
    UINT8 ucRdbk = 0;
    for (UINT8 ucCount = 0; ucCount < _MAX_READINGS_; ucCount++) {
        if (ANALOG_RDBK) ucRdbk++; // If bit is set, increment the count
        IdleWait(1); // Wait for 1 microsec
    }
    return (ucRdbk >= 2);
}



#if !LOWCOST
/*******************************************************************************
*                     GetSwitchStatus                                          *
*                     ================                                         *
* PURPOSE:                                                                     *
*       Reads the CPLD switch register and returns the switch status           *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*          UINT8 value indicates switch status                                 *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAoHardware::GetSwitchStatus(SWITCH_TYPE eswtype) {
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_IOL);
    UINT8 ucTemp = 0x00,ucRetryCntr;
    for (ucRetryCntr=3; ucRetryCntr>0; ucRetryCntr--) {
        switch(eswtype){
        case DIS_SWCH:
            if(OP_DISA_FB_n)
                ucTemp = ucTemp | DIS_SWA_SET;
            if(OP_DISB_FB1_n)
                ucTemp = ucTemp | DIS_SWB1_SET;
            if(OP_DISB_FB2_n)
                ucTemp = ucTemp | DIS_SWB2_SET;
            break;
        case TST_SWCH:
            if(TST)
                ucTemp = ucTemp | TST_SET;
            break;
        case INH_SWCH:
            if(INHST2_FB)
                ucTemp = ucTemp | INH_SWA_SET;
            if(INHST1_FB1)
                ucTemp = ucTemp | INH_SWB1_SET;
            if(INHST1_FB2)
                ucTemp = ucTemp | INH_SWB2_SET;
            break;
        }
    }
    set_imask_exr(ucSaveExr);
    return ucTemp;
}
#else // Low Cost
/*******************************************************************************
*                     GetSwitchStatus                                          *
*                     ================                                         *
* PURPOSE:                                                                     *
*       Reads the CPLD switch register and returns the switch status           *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*          UINT8 value indicates switch status                                 *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAoHardware::GetSwitchStatus(SWITCH_TYPE eswtype) {
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_IOL);
    UINT8 ucTemp = 0x00,ucRetryCntr;
    for (ucRetryCntr=2; ucRetryCntr>0; ucRetryCntr--) {
    UINT8 ucSwitchStates = SWITCH_STATUS_REGISTER; // Read Switch states from CPLD
        switch(eswtype){
        case DIS_SWCH:
            if(ucSwitchStates & OP_DISA_FB_n)       
                ucTemp = ucTemp | DIS_SWA_SET;
            if(ucSwitchStates & OP_DISB_FB1_n)
                ucTemp = ucTemp | DIS_SWB1_SET;
            break;
        case TST_SWCH:
            if(ucSwitchStates & TST)
                ucTemp = ucTemp | TST_SET;
            break;
        case INH_SWCH:
            if(ucSwitchStates & INHST2_FB)
                ucTemp = ucTemp | INH_SWA_SET;
            if(ucSwitchStates & INHST1_FB1)
                ucTemp = ucTemp | INH_SWB1_SET;
            if(ucSwitchStates & INHST1_FB2)
                ucTemp = ucTemp | INH_SWB2_SET;
            break;
        }
    }
    set_imask_exr(ucSaveExr);
    return ucTemp;
}
#endif

/*******************************************************************************
*                     VerifySwitchState                                        *
*                     =================                                        *
* PURPOSE:                                                                     * 
*      Reads the current status of the switches,compares it with whats expected*
*      status,if a mismatch is found the state of the switch is modified with  *
*      expected switch state                                                   *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAoHardware::VerifySwitchState(SWITCH_TYPE eswtype,UINT8 a_ucSwitchState){
    UINT8 ucCountOuter,ucCountInner,ucFailure=0;
    for (ucCountOuter=3; ucCountOuter>0; ucCountOuter--) {
        switch(eswtype){
        case DIS_SWCH:
            ucFailure = 1;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
                if (a_ucSwitchState == GetSwitchStatus(DIS_SWCH)) {
                    return; 
                }
            }
            if (a_ucSwitchState == DIS_ON_ON) {
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_ON;
            }
            else if (a_ucSwitchState == DIS_ON_OFF) {
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_OFF;
            }
            else if (a_ucSwitchState == DIS_OFF_ON) {
                DIS_SWA_n = SW_OFF;
                DIS_SWB_n = SW_ON;
            }
            else if (a_ucSwitchState == DIS_OFF_OFF) {
                DIS_SWA_n = SW_OFF;
                DIS_SWB_n = SW_OFF;
            }
            IdleWait(DIS_READ_DELAY_TIME);
            break;
        case TST_SWCH:
            ucFailure = 2;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
                if (a_ucSwitchState == GetSwitchStatus(TST_SWCH)) {
                    return; 
                }
            }
            //Set the switch to desired state
            TST_n = (a_ucSwitchState == TST_DISABLED) ? TSTn_DISABLED : TSTn_ENABLED;
            IdleWait(TST_READ_DELAY_TIME);
            break;
            
        case INH_SWCH:
            ucFailure = 3;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
                if (a_ucSwitchState == GetSwitchStatus(INH_SWCH)) {
                    return;
                }
            }

            if (a_ucSwitchState == INH_ON_ON) {
                INH_SWB = SW_ON;
                INH_SWA = SW_ON;
            }
            else if (a_ucSwitchState == INH_ON_OFF) {
                INH_SWB = SW_ON; 
                INH_SWA = SW_OFF;
            }
            else if (a_ucSwitchState == INH_OFF_ON) {
                INH_SWB = SW_OFF;
                INH_SWA = SW_ON;
            }
            else if (a_ucSwitchState == INH_OFF_OFF) {
                INH_SWA = SW_OFF;
                INH_SWB = SW_OFF;
            }
            IdleWait(INH_READ_DELAY_TIME);
            break;
        }//switch loop
    }//Outer For loop 
#if defined(IOPTYPE_AO16)
    // 2. added redundant state condition checking to fix PAR,
    //    PAR# 1-DYD1PEV (NR/Satus led RED during removal & reinsertion of IOLink cable A & B of primary)
    // 1. added to resolve, PAR# 1-7LC52TF (NR /Status RED Led Issue)
    //    if FTA missing or Secondary & just got BackupRequest from PRI  
    if ((FtaStatus() != FTA_RETURN_AND_TOUT) ||
        // PAR# 1-DYD1PEV fix - (NR/Status RED Led during removal & reinsertion of IOLink cable A & B of Primary)
        (REDSTATE_IOL_TIMEOUT != BOX->GetRedState()) ||
       ((OUTCTL_PARTNER == BOX->GetModStat3()) && (BUPREQ_IN)))
    {
        return;
    }
#endif
    // If the check and overwrite fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL, AOHARDWARE_CPP, __LINE__, ucFailure);
}

/*******************************************************************************
*                             InhibitSwitchDiagnostics                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Inhibit Switch Diagnostics                                                *
* ARGUMENTS:                                                                   *
*    UINT8 ucSubContext                                                        *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    Only one output is changed per diagnostic state and then it is checked in *
*    in the next diagnostic state to confirm the change occurred.              *
*    N.B.: ONLY ONE INH_SW is allowed to be ON during any diagnostic state.    *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::InhibitSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bInhswDiagSts = TRUE;
    UINT8 ucSaveExr =get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State()) {
        bInhswDiagSts = FALSE;
        switch(ucSubContext){
            case CONTEXT_ZERO:
                INH_SWB = SW_ON;
                bInhswDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(INH_ON_OFF == GetSwitchStatus(INH_SWCH)) {
                    bInhswDiagSts = TRUE;
                    INH_SWB = SW_OFF;
                }
                break;
            case CONTEXT_TWO:
                if(INH_OFF_OFF == GetSwitchStatus(INH_SWCH)) {
                    bInhswDiagSts = TRUE;
                    TST_n = TSTn_ENABLED;
                }
                break;
            case CONTEXT_THREE:
                if(TST_ENABLED == GetSwitchStatus(TST_SWCH)) {
                    bInhswDiagSts = TRUE;
                    INH_SWA = SW_ON;
                }
                break;
            case CONTEXT_FOUR:
                if(INH_OFF_ON_TST_ON == GetSwitchStatus(INH_SWCH))    {
                    bInhswDiagSts = TRUE;
                    INH_SWA = SW_OFF; 
                }
                break;
            case CONTEXT_FIVE:
                if(INH_OFF_OFF_TST_ON == GetSwitchStatus(INH_SWCH)) {
                    bInhswDiagSts = TRUE;
                    TST_n = TSTn_DISABLED; 
                }
                break;
            case CONTEXT_SIX:
                if(TST_DISABLED == GetSwitchStatus(TST_SWCH))
                    bInhswDiagSts = TRUE;
                break;
        }
    }
    set_imask_exr(ucSaveExr);
    return bInhswDiagSts;
}


/*******************************************************************************
*                             TestSwitchDiagnostics                            *
*                             =====================                            *
* PURPOSE:                                                                     *
*    Test Switch Diagnostics                                                   *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    This control output is changed once per diagnostic state and then it is   *
*    checked in the next diagnostic state to confirm the change occurred.      *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::TestSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bTstswDiagSts = TRUE;
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State()) {
        bTstswDiagSts = FALSE;
        switch(ucSubContext) {
            case CONTEXT_ZERO:
                TST_n = TSTn_ENABLED;
                bTstswDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(TST_ENABLED == GetSwitchStatus(TST_SWCH)) {
                    bTstswDiagSts = TRUE;
                    TST_n = TSTn_DISABLED;
                }
                break;
            case CONTEXT_TWO:
                if(TST_DISABLED == GetSwitchStatus(TST_SWCH)) {
                    bTstswDiagSts = TRUE;
                }
                break;
        }
    }
    set_imask_exr(ucSaveExr);
    return bTstswDiagSts;
}


/*******************************************************************************
*                             DisableSwitchDiagnostics                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Disable Switch Diagnostics                                                *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    Only one output is changed per diagnostic state and then it is checked in *
*    in the next diagnostic state to confirm the change occurred.              *
*    N.B.: ONLY ONE DIS_SW is allowed to be ON during any diagnostic state.    *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL clsAoHardware::DisableSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bDisSwDiagSts = TRUE;
    UINT8 ucSaveExr =get_imask_exr();
    set_imask_exr(LVLPRI_IOL);
    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State()) {
        bDisSwDiagSts = FALSE;
        switch(ucSubContext) {
            case CONTEXT_ZERO:
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_OFF;
                bDisSwDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(DIS_ON_OFF == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_OFF;
                }
                break;
            case CONTEXT_TWO:
                if(DIS_OFF_OFF == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_ON;
                }    
                break;
            case CONTEXT_THREE:
                if(DIS_OFF_ON == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_OFF;
                }
                break;
            case CONTEXT_FOUR:
                if(DIS_OFF_OFF == GetSwitchStatus(DIS_SWCH)) {
                    bDisSwDiagSts = TRUE;  
                }
                break;
        }
    }
    set_imask_exr(ucSaveExr);
    return bDisSwDiagSts;
}





