/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihmain.cpp                                                 *
*    Description : Analog HART input module application specific startup code. *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aihmain.h"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN HartTask(TASKCONTEXT);
extern TASKRETURN DiagnosticTask(TASKCONTEXT);
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
extern BOOL HartLoopBkTestInProgress;
/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
WRITEINPROGRESS  WriteInProgress;
#ifdef DEBUG
clsDebugPort     DebugPort;
#endif

// Global objects
clsTaskScheduler TaskScheduler;

#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section

#pragma section  INTERNALRAM_SECTION
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;
clsAdc           Adc;
clsEeprom        Eeprom;
#pragma section 

// Pointers to database objects
clsIomSlot       *pDatabase[MAXSLOTS + 1];
// Database Memory
UINT16 ucIomDbMemory[AIHBOXSLOT_SIZE + (MAXSLOTS * AIHSLOT_SIZE)];

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
TASKRETURN CalibrationTask(TASKCONTEXT);
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//NOTE:
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                            WriteDatabaseTask
                                           ,LowPriorityTask
                                           ,CalibrationTask
                                           ,EventRecoveryTask
                                           ,HartTask
                                           ,DiagnosticTask
#ifdef DEBUG
                                           ,DebugTask
#endif
};

/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
*    Application specific startup code.                                        *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function is called by the PowerOn reset vector.                      *
*******************************************************************************/
VOID main(VOID) 
{
    BOOL bHart = FALSE;   // the Box is HART capable
#if LOWCOST
    UINT8 ProductCode = *((UINT8*)(MODULEINFO_START_ADDRESS + HW_PROD_CODE_OFFSET));
#endif
    // Create box and slot database objects
    if (isHartCapable()) {  // decide HART or Hartless based on the HW
        // AI-HART
        pDatabase[0] = new clsAihBoxSlot(MODLTYPE_AIH);
        TraceLog.AddToTrace(TRACEID_GENERIC,bcAihIom,BOX->GetDPA());
        bHart = TRUE;
    }
    else {
        // AI-HL
#if HEK     // No dynamic module type detection for Series C Depop AI
        pDatabase[0] = new clsAihBoxSlot(MODLTYPE_AI);
#else
        if((ProductCode >= PRODCODE_AI_HART_LC_S8) && (ProductCode <= PRODCODE_AI_HL_LC_S8)) {
            pDatabase[0] = new clsAihBoxSlot(MODLTYPE_AI_S8);
        }
        else {  // Series C is chosen for any other product code configurations
            pDatabase[0] = new clsAihBoxSlot(MODLTYPE_AI);
        }
#endif
        TraceLog.AddToTrace(TRACEID_GENERIC,bcAiIom,BOX->GetDPA());
    }
    // TODO: Kernel/App board combination mismatch

    for (UINT8 ucSltNm = 0; ucSltNm < MAXSLOTS; ucSltNm++) {
        pDatabase[ucSltNm + 1] = new(ucSltNm) clsAihSlot(ucSltNm + 1);
#if defined(IOPTYPE_HLAI)
        // Checkpoint param restoring from xRAM
        pDatabase[ucSltNm + 1]->PmioCheckPointRestore();
#endif
    }
    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();

    if (bHart == TRUE) {
        CheckAndInitHart();
    }
    else
    {
        ResetHart();    // just Reset for Hartless module
    }

    // Initialize periodic tasks.
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
                                        DMCPERIOD_LPTASK);
    if (bHart == TRUE) {
        TaskScheduler.InitPeriodicTask(TASKID_HARTTASK,TASKPERIOD_HARTTASK,
                                        DMCPERIOD_HARTTASK);
    }
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
                                        DMCPERIOD_DIAGTASK);


#ifdef DEBUG
    // Set the Debug Task to RUN State
    TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif

    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}
/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
* Runs Task every 1 seconds,can view LowPriorityTask over Debug terminal       *
* to identify the task                                                         *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

#if !LOWCOST
    if(TRUE == HartLoopBkTestInProgress){
        HartLoopBkTestInProgress = (RETURNSTATUS_INPROGRESS == BOX->HartLoopBackTest());
    }
#endif

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
    // Process BRDP Handle and Message Timeout every second.
    if (BOX->BRDPOneSecCounter >= 10) {
        BOX->BRDPOneSecCounter = 0;
        BOX->ProcessBrdpTimeout();
    }
    else
        BOX->BRDPOneSecCounter++;
#endif
    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
/*******************************************************************************
*                                CalibrationTask                               *
*                                ===============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN CalibrationTask(TASKCONTEXT a_TaskContext)
{
#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                                      "\n\r\tStarting calibration...\n\r"));
#endif

    TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibStart,FACTCAL);

    // Disable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
        SLOT(ucChan)->GetHartDevDb().InitDevDb(TRUE);
    }
    IdleWait(MICROSECONDS_IN_MILLISECOND);
    TPU2_CST = 0; // Stop HART modem heartbeat timer.

    if (FALSE == BOX->PerformModuleCalibration()) { 
        // Calibration was aborted for failed.
        TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibAbort,MODULEINFO_WRITECOUNT);

#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                                          "\n\r\tCalibration aborted"));
#endif
    }

    // Reneable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
        SLOT(ucChan)->GetHartDevDb().m_sScanCounter = TICKS_IN_16_SEC;
    }
    TPU2_CST = 1; // Restart HART modem heartbeat timer.

    TASKRETURN      TaskReturnValue;
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
