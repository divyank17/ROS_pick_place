/*
COPYRIGHT (C) 2015
Honeywell Measurex (Ireland) Limited

ALL RIGHTS RESERVED
This software is a copyrighted work and/or information protected as a trade
secret.  Legal rights of Honeywell Measurex (Ireland) Limited in this software
is distinct from ownership of any medium in which the software is embodied.
Copyright or trade secret notices included must be reproduced in any document.
*/

/**
    @file
    @brief defines the MODLTYPE, PRODTYPE and PRODCODE enumerations
*/

#if !defined (PRODUCTDEFS_H)
#define PRODUCTDEFS_H

/**
    @brief defines Series-C I/O module types

    These enumerators must align with the Experion database definitions located in
    /db/src/IOLIM/pm_ioptype.enm.xml
*/
typedef enum tagModlType {
    // PM IOP Module Types
#if !defined(IOPTYPE_SCIOM)
    MODLTYPE_AI         = 2,     // HLAI non HART
    MODLTYPE_DIL        = 3,     // DI w/COS or DI24
#if defined(DIGTYPE_DO16)
    MODLTYPE_DOB        = 4,     // DO16
#else
    MODLTYPE_DOB        = 25,    // DO32
#endif
    MODLTYPE_DISOE      = 16,    // DISOE
    MODLTYPE_AO         = 24,    // AO16 non HART 
    MODLTYPE_AIH        = 29,    // HLAI HART
    MODLTYPE_AOH        = 31,     // AO16 HART
#else
    MODLTYPE_AIH        = 51,
    MODLTYPE_AOH        = 53,
    MODLTYPE_DIL        = 55,
    MODLTYPE_DOB        = 56,
    MODLTYPE_DISOE      = 57,
    MODLTYPE_AI         = 58,    // without HART
    MODLTYPE_AO         = 59,    // without HART
#endif
    // Series C Module Types
    MODLTYPE_LLMUX      = 52,    
    MODLTYPE_DIH        = 54,
    MODLTYPE_SVP        = 60,
    MODLTYPE_SP         = 61,
    MODLTYPE_PI         = 62,
    MODLTYPE_UIO        = 63,
    MODLTYPE_AI_LLAI    = 64,
    MODLTYPE_SIMIOM     = 65,
    MODLTYPE_UIO_2      = 66,

    // Series 8 Modules Types
    MODLTYPE_AIH_S8     = 101,
    MODLTYPE_AOH_S8     = 102,
    MODLTYPE_DIL_S8     = 103,
    MODLTYPE_DOB_S8     = 104,
    MODLTYPE_AI_S8      = 105,    // without HART
    MODLTYPE_AO_S8      = 106,    // without HART
    MODLTYPE_LLMUX_S8   = 107,
    MODLTYPE_DIH_S8     = 108,
    MODLTYPE_DISOE_S8   = 109
} MODLTYPE;

/**
    @brief defines Series-C I/O product type codes

    These definitions must align with the Product Registry document located here:
    /cmn/doc/Product Registry.doc.

    In addition, these product types defined separately for some Experion tools.  Changes to this
    enumeration likely requires and update to 
    - 'enmProductType' enumeration in /ecs/tools/mtool/include/eCAT.h
    - 'PRODTYPE' enumeration in /blockext/PMIO/IOLINK/iolinkext.h
*/
typedef enum tagProdType {
    PRODTYPE_NONE       =   0,
    PRODTYPE_BOOT       =   1,
    PRODTYPE_FPGA       =   2,
    PRODTYPE_AI         = 773,
    PRODTYPE_LLMUX      = 774,
    PRODTYPE_AO         = 775,
    PRODTYPE_DI         = 776,
    PRODTYPE_DO         = 777, 
    PRODTYPE_DISOE      = 780,
    // Product type 781 is unused
    PRODTYPE_SVP        = 782,
    PRODTYPE_SP         = 783,
    PRODTYPE_PI         = 784,
    PRODTYPE_UIO        = 785,
    PRODTYPE_LOWCOST    = 0x2000   //optional Flag
} PRODTYPE;

/**
    @brief defines product codes for use with product type PRODTYPE_AI
*/
typedef enum tagProdCodeAI {
    PRODCODE_AI_HART        = 1,    ///< Series C AI HART, 4-HART Modems, 16 Channels
    PRODCODE_AI_HL          = 2,    ///< Series C AI, 16 Channels
    PRODCODE_AI_HL_LC       = 3,    ///< Series C LOWCOST AI, 16 Channels
    PRODCODE_AI_HART_LC     = 4,    ///< Series C LOWCOST AI HART, 1-HART Modem, 16 Channels
    PRODCODE_AI_HART_LC_S8  = 5,    ///< Series 8 LOWCOST AI HART, 1-HART Modem, 16 Channels
    PRODCODE_AI_HL_LC_S8    = 6     ///< Series 8 LOWCOST AI, 16 Channels
} PRODCODEAI;

/**
    @brief defines product codes for use with product type PRODTYPE_AO
*/
typedef enum tagProdCodeAO {
    PRODCODE_AO_HART        = 1,   ///< Series C AO HART, 4-HART Modems, 16 Channels
    PRODCODE_AO             = 2,   ///< Series C AO, 16 Channels
    PRODCODE_AO_LC          = 3,   ///< Series C LOWCOST AO, 16 Channels
    PRODCODE_AO_HART_LC     = 4,   ///< Series C LOWCOST AO HART, 1-HART Modem, 16 Channels
    PRODCODE_AO_HART_LC_S8  = 5,   ///< Series 8 LOWCOST AO HART, 1-HART Modem, 16 Channels
    PRODCODE_AO_LC_S8       = 6    ///< Series 8 LOWCOST AO, 16 Channels
} PRODCODEAO;

/**
    @brief defines product codes for use with product type PRODTYPE_DI
*/
typedef enum tagProdCodeDI {
    PRODCODE_DI_24V         = 1,    ///< Series C DI-24V
    PRODCODE_DI_110V        = 2,    ///< Series C DI-110V
    PRODCODE_DI_240V        = 3,    ///< Series C DI-240V
    PRODCODE_DI_24V_LC      = 4,    ///< Series C LOWCOST DI-24V
    PRODCODE_DI_24V_LC_S8   = 5     ///< Series 8 DI-24V
} PRODCODEDI;

/**
    @brief defines product codes for use with product type PRODTYPE_DISOE
*/
typedef enum tagProdCodeDISOE {
    PRODCODE_DISOE          = 1,    ///< Series C DISOE
    PRODCODE_DISOE_S8       = 2,    ///< Series 8 DISOE
    PRODCODE_DISOE_LC_S8    = 3     ///< Series 8 LOWCOST DISOE
} PRODCODEDISOE;

/**
    @brief defines product codes for use with product type PRODTYPE_DO
*/
typedef enum tagProdCodeDO {
    PRODCODE_DO_24VBUS      = 1,    ///< Series C DO-24V
    PRODCODE_DO_HV1         = 2,    ///< Seriec C DO-HV1
    PRODCODE_DO_HV2         = 3,    ///< Series C DO-HV2
    PRODCODE_DO_RELAY       = 4,    ///< Series C DO-Relay
    PRODCODE_DO_24VISO      = 5,    ///< Series C DO-24VISO
    PRODCODE_DO_24VBUS_LC   = 6,    ///< Series C LOWCOST DO-24V
    PRODCODE_DO_24VBUS_LC_S8 = 7    ///< Series 8 DO-24V
} PRODCODEDO;

/**
    @brief defines product codes for use with product type PRODTYPE_LLMUX
*/
typedef enum tagProdCodeLLMUX {
    PRODCODE_LLMUX          = 1,    ///< Series C LLMUX
    PRODCODE_LLMUX_S8       = 2     ///< Series 8 LLMUX
} PRODCODELLMUX;

/**
    @brief defines product codes for use with product type PRODTYPE_SVP
*/
typedef enum tagProdCodeSVP { 
    PRODCODE_SVP            = 1,
    PRODCODE_SVP_RSVD       = 2 //Reserved
} PRODCODESVP;

/**
    @brief defines product codes for use with product type PRODTYPE_SP
*/
typedef enum tagProdCodeSP { 
    PRODCODE_SP             = 1,
    PRODCODE_SP_RSVD        = 2 //Reserved
} PRODCODESP;

/**
    @brief defines product codes for use with product type PRODTYPE_PI
*/
typedef enum tagProdCodePI { 
    PRODCODE_PI             = 1
} PRODCODEPI;

/**
    @brief defines product codes for use with product type PRODTYPE_UIO
*/
typedef enum tagProdCodeUIO { 
    PRODCODE_UIO            = 1,
    PRODCODE_UIO_2          = 2
} PRODCODEUIO;

const unsigned short PRODTYPE_UNKNOWN = 0xFFFF;
const unsigned short PRODCODE_UNKNOWN = 0xFFFF;

#endif // PRODUCTDEFS_H
