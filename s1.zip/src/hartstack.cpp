/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hartstack.cpp                                               *
*    Description : HART protocol stack implementation.                         *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif
#ifdef IOMTYPE_AOH
#include "aohmain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif

/*******************************************************************************
*                                 RUNTIME ASSERT                               *
*******************************************************************************/
#define USE_RUNTIME_ASSERT (1) // 0: disable, 1: enable

#if USE_RUNTIME_ASSERT
  #define assert(x) ((x) ? (void)0 : HardFail(HF_INVPROGRAMEXEC, HARTSTACK_CPP, __LINE__))
#else
  #define assert(x) // do nothing, runtime assert is disabled
#endif

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;
extern UINT16 g_usModemObjectMemory[];
#if defined(IOMTYPE_UIO)
// Memory for HART queues
extern UINT16 g_usHartQueueObjectMemory[];
#endif
/*******************************************************************************
*                               STATIC VARIABLES                               *
*******************************************************************************/
UINT8  clsHartModem::m_ucHartMuxEnbl = 0x00;    // Disable all multiplexors.
UINT16 clsHartModem::m_usHartMuxAddr = 0xC840;  // Connect modems to each MUX
UINT8  clsHartModem::m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT;
UINT8  clsHartModem::m_ucFailedChannel = 0;
UINT32 clsHartModem::m_sulMDiagCount = 0;

#if defined(IOMTYPE_UIO)
/*******************************************************************************
*                          clsHartQueue::operator new                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
*   Allocate memory for a clsHartQueue object.                                 *
* ARGUMENTS:                                                                   *
*   a_ucModemNumber: The modem the queue is to be associated with              *
* RETURN:                                                                      *
*   Pointer to memory that will hold the queue object.                         *
* NOTES:                                                                       *
*   None                                                                       *
*******************************************************************************/
VOID *clsHartQueue::operator new(UINT32, UINT8 a_ucModemNumber)
{ 
    return (g_usHartQueueObjectMemory + (a_ucModemNumber * CLSHARTQUEUE_SIZE));
}
#endif

/*******************************************************************************
*                         clsHartQueue::clsHartQueue                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Constructor. Initializes the object.                                      *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    Not applicable.                                                           *
* PROCESS:                                                                     *
*    1. Clear the Q buffer and initialze the next free index to zero.          *
* NOTES:                                                                       *
*    1. Only one clsQ object is constructed by the HARTP startup code.         *
*******************************************************************************/
clsHartQueue::clsHartQueue(VOID) {
    for (UINT8 ucCount = 0; ucCount < HARTQUEUE_BUFFER_SIZE; ucCount++) {
        m_ucBuffer[ucCount] = 0;
    }
    m_ucNextIndex = 0;
}
/*******************************************************************************
*                          clsHartQueue::AddToQueue                            *
*                          ========================                            *
* PURPOSE:                                                                     *
*    Add an entry to the HART communication queue.                             *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if request is accepted; FALSE if rejected.                  *
* PROCESS:                                                                     *
*    1. Check whether there is room in the Q. Reject if the Q is full.         *
*    2. Check whether a previous request from the same client is still         *
*       pending in the Q. Reject if a match is found.                          *
*    3. Check whether a previous request from the same client is still         *
*       processed by a modem object. Reject if a match is found.               *
*    4. Add the client reference to the tail.                                  *
* NOTES:                                                                       *
*    1. This method is called from the global function InitHartConnection.     *
*    2. Modem objects periodically checks the stack queue and uses the client  *
*       reference and callback interface to carry out the HART transaction.    *
*******************************************************************************/
BOOL clsHartQueue::AddToQueue(UINT8 a_ucChan) {
    // Do not let HART modem and timer interrupts to come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HART);

    // Check whether Q is full already. Q full means that client is already
    // present in the Q as we allow only entry per client in the Q.
    if (m_ucNextIndex > HARTQUEUE_BUFFER_SIZE) {
        set_imask_exr(ucSaveExr); // Restore original interrupt masks
        return FALSE;
    }

    // If client is already in the queue, reject the request.
    for (UINT8 ucCount = 0; ucCount < m_ucNextIndex; ucCount++) {
        if (m_ucBuffer[ucCount] == a_ucChan)    {
            set_imask_exr(ucSaveExr); // Restore original interrupt masks
            return FALSE;
        }
    }

    // If client is already being processed by a modem, reject the request.
    for (UINT8 ucCount = 0; ucCount < HARTMODEM_COUNT; ucCount++) {
        // Do not check connected channel for modems in DIAG state. 
        // These have connected channel set to the modem being diagnosed.
        if ((pHartModem[ucCount]->GetModemState() != HMODEMSTATE_DIAG) &&
            (pHartModem[ucCount]->GetConnectedChannel() == a_ucChan)) {
            set_imask_exr(ucSaveExr); // Restore original interrupt masks
            return FALSE;
        }
    }

    // Otherwise, add the client to the tail.
    m_ucBuffer[m_ucNextIndex++] = a_ucChan;
    set_imask_exr(ucSaveExr); // Restore original interrupt masks
    return TRUE;
}
/*******************************************************************************
*                         clsHartQueue::RemoveFromQueue                        *
*                         =============================                        *
* PURPOSE:                                                                     *
*    Remove a client reference from the HART communication queue.              *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if the reference is found in the Q and removed;             *
*    FALSE if no match to the passed reference is found.                       *
* PROCESS:                                                                     *
*    1. Compare each queue member with the passed reference.                   *
*    2. If a match is found, delete the element by shifting all the members    *
*       right of it to one position left.                                      *
*    3. Clear the last queue position and update next free index.              *
* NOTES:                                                                       *
*    1. This method is called by AbortHartConnection.                          *
*******************************************************************************/
BOOL clsHartQueue::RemoveFromQueue(UINT8 a_ucChan) {
    // Do not let HART modem and timer interrupts to come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HART);

    for (UINT8 ucCount = 0; ucCount < m_ucNextIndex; ucCount++) {
        if (m_ucBuffer[ucCount] == a_ucChan)    { // a_pClient found in queue
            // Shift rest of the Q to one position left.
            for (; ucCount < m_ucNextIndex; ucCount++) {
                m_ucBuffer[ucCount] = m_ucBuffer[ucCount + 1]; 
            }

            // Clear the last Q position and update next index.
            m_ucBuffer[m_ucNextIndex--] = 0;

            // request to remove is successful
            set_imask_exr(ucSaveExr); // Restore original interrupt masks
            return TRUE;
        }
    }

    // Client not found in the queue.
    set_imask_exr(ucSaveExr); // Restore original interrupt masks
    return FALSE;
}
/*******************************************************************************
*                         clsHartQueue::ProcessQueue                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Serach the queue and service a pending HART transaction request.          *
* ARGUMENTS:                                                                   *
*    1. a_ucModem - modem number (0,1,2 or 3)                                  *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Return if queue is empty.                                              *
*    2. Call the Connect method of the modem object specified and pass the     *
*       client reference at the head of the Q.                                 *
*    3. Advance all the Q members to one position left.                        *
*    4. Clear the last Q position and update next free index.                  *
* NOTES:                                                                       *
*    1. This method is called by ILDE modem objects when processing modem      *
*       heartbeat interrupt.                                                   *
*******************************************************************************/
VOID clsHartQueue::ProcessQueue(UINT8 a_ucModem) {
    // If the queue is empty, don't do anything
    if (0 == m_ucNextIndex) return;
    
    // Connect to the first client in the queue
    if ((m_ucBuffer[0] > 0) && (m_ucBuffer[0] <= MAXSLOTS)) {
        pHartModem[a_ucModem]->Connect(m_ucBuffer[0]); 
    }

#if defined(IOMTYPE_UIO)
    // Make sure the HART address registers reflect what was written
    // when we connected to a channel.
    if (!FPGA.IsHartAddressRegisterValid(a_ucModem))
    {
        pHartModem[a_ucModem]->SetModemBad();
        return;
    }
#else
    // Do loopback diagnostics on HART MUX ENBL and ADDR 
    // lines immediately after connecting to the channel.
    if (pHartModem[a_ucModem]->HartMuxLoopbackTest() > 1) 
    {        
        pHartModem[a_ucModem]->SetModemBad();
        return;
    }
#endif

    // Push all Q members forward.
    for (UINT8 ucCount = 0; ucCount < m_ucNextIndex; ucCount++) {
        m_ucBuffer[ucCount] = m_ucBuffer[ucCount + 1];
    }

    // Clear the last queue position and update next index.
    m_ucBuffer[m_ucNextIndex--] = NULL;
}

#if defined(IOMTYPE_UIO)
BOOL clsHartQueue::IsModemQueueEmpty(VOID) {
    // Next index is used to check for modem queue empty
    if(m_ucNextIndex == 0)
        return TRUE;
    else
        return FALSE;
}
#endif

/*******************************************************************************
*                          clsHartModem::operator new                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsHartModem::operator new(UINT32, UINT8 a_ucModemNumber) { 
    return (g_usModemObjectMemory + (a_ucModemNumber * CLSHARTMODEM_SIZE));
}
/*******************************************************************************
*                         clsHartModem::clsHartModem                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Constructor. Initializes the object.                                      *
* ARGUMENTS:                                                                   *
*    1. a_ucModem - modem number - 0,1,2 or 3                                  *
* RETURN:                                                                      *
*    Not applicable.                                                           *
* PROCESS:                                                                     *
*    1. Initialize all members variables.                                      *
*    2. Clear the associated DUART FIFO and disable associated DUART channel   *
*       interrupts.                                                            *
* NOTES:                                                                       *
*    1. IOM startup code instantiates four objects of the clsHartModem class.  *
*******************************************************************************/
clsHartModem::clsHartModem(UINT8 a_ucModem) : m_ucModemNumber(a_ucModem) {
    m_ucModemTimer       = 0;
    m_ModemState         = HMODEMSTATE_IDLE;

    m_ucConnectedChannel = 0;
    m_cucpXmtBuffer      = NULL;
    m_ucPollingAddress   = 0;
    for (UINT8 ucCount = 0; ucCount < HART_LONGADDR_LENGTH; ucCount++) {
        m_UniqueAddress.ucBytes[ucCount] = 0;
    }
   
    m_ucXmtCommand       = 0;
    m_ucBytesInRequest   = 0;
    m_ucBytesInResponse  = 0;
    m_XmtRcvContext      = XMTRCVCONTEXT_UNKNOWN;
    m_RcvMsgType         = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus       = HMSGSTATUS_BAD;
    m_ucCheckSum         = 0;
    m_ucRemPreambles     = 0;
    m_ucRcvdDelimiter    = 0;
    m_ucRetryCount       = 0;
    m_bRequestDisconnect = FALSE;
    m_bBurstDeviceFound  = FALSE;
    m_ucModemDiagCount   = 0;
#if defined (IOMTYPE_UIO)
    m_bHartStackProc     = FALSE;
#endif

    // Initialize hardware. First reset modem and UART.
    HART_UART(m_ucModemNumber).RESET = 1; 

    // Modem control register - Disable RTS.
    HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;

    // Line control register
    // Configure UART for 8 bits per character, odd parity and one stop bit.
    HART_UART(m_ucModemNumber).BITS_PER_CHAR = HART_UART_8BITS_PER_CHAR;
    HART_UART(m_ucModemNumber).PARITY_ENBL = 1; // By default parity is disabled.
    if (HART_UART(m_ucModemNumber).LINE_CTRL_REGISTER != 0x0B) {
        HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
    }

    // FIFO control register - Enable both transmit and receive FIFOs 
    // and configure receive interrupt trigger level of 14 bytes.
    HART_UART(m_ucModemNumber).FIFO_ENBL = 1;
    HART_UART(m_ucModemNumber).RCV_FIFO_TRIG_LEVEL = 3;
    ClearTxRxFIFOs();
    if (HART_UART(m_ucModemNumber).FIFO_CTRL_REGISTER != 0xC1) {
        HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
    }
    
    // Interrupt enable register - disable all interrupts.
    HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = 0;
}
/*******************************************************************************
*                            clsHartModem::Connect                             *
*                            =====================                             *
* PURPOSE:                                                                     *
*    Connect the modem to the specified client.                                *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number to be connected.                             *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Initialize clsHartModem members with the new channel details.          *
*    2. Enable and switch the HART multiplexor to the specified channel.       *
* NOTES:                                                                       *
*    1. Connect method is called from ProcessQueue.                            *
*******************************************************************************/
VOID clsHartModem::Connect(UINT8 a_ucChan) {
    m_ucConnectedChannel = a_ucChan;
    
    // Set MSB to show that IOP is primary master
#if defined(IOMTYPE_UIO)

    // Since the AI and AO channels don't inherit from a common HART class,
    // switch on the channel type to pull out the information we need.
    PNTTYPE HartChanPntType = BOX->GetInitPntType(m_ucConnectedChannel);
    switch (HartChanPntType)
    {
        case PNTTYPE_ANALOGINPUT:

            m_ucPollingAddress = AIH_SLOT(m_ucConnectedChannel)->GetPollingAddress(); 
            
            m_ucPollingAddress = ((m_ucPollingAddress & 
                HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
                
            m_UniqueAddress = AIH_SLOT(m_ucConnectedChannel)->GetUniqueAddress();
            
            m_ucRetryCount = AIH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                        
            break;
            
        case PNTTYPE_ANALOGOUTPUT:

            m_ucPollingAddress = AOH_SLOT(m_ucConnectedChannel)->GetPollingAddress(); 
            
            m_ucPollingAddress = ((m_ucPollingAddress & 
                HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
                
            m_UniqueAddress = AOH_SLOT(m_ucConnectedChannel)->GetUniqueAddress();
            
            m_ucRetryCount = AOH_SLOT(m_ucConnectedChannel)->GetRetryCount();
            
            break;
            
        default:
            // We should never get here...
            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
            break;
    }

    FPGA.ConfigureHartAmplifierGain(m_ucConnectedChannel, HartChanPntType);
#else
    m_ucPollingAddress = SLOT(m_ucConnectedChannel)->GetPollingAddress(); 
    m_ucPollingAddress = ((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) 
                      | HART_MASTER_ADDR_MASK);
    m_UniqueAddress = SLOT(m_ucConnectedChannel)->GetUniqueAddress();
    
    m_ucRetryCount = SLOT(m_ucConnectedChannel)->GetRetryCount();
#endif

    m_UniqueAddress.ucBytes[0] = ((m_UniqueAddress.ucBytes[0] & 
                                   HART_MANUFACTURE_ID_MASK) 
                                   | HART_MASTER_ADDR_MASK);
    m_ucModemDiagCount = 0;
    ClearTxRxFIFOs();

    // Limit the number of retries to 3.
    if (m_ucRetryCount > HART_MAX_RETRIES) 
        m_ucRetryCount = HART_MAX_RETRIES;

    m_ModemRcvBuffer.Flush(); // Initialize the modem receive buffer.
    SwitchMux(m_ucConnectedChannel); // Swith multiplexor to the connected channel.

    // Set SYNCWAIT state and turn ON the receiver to monitor 
    // the HART circuit during link quiet time.
    SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
}
/*******************************************************************************
*                          clsHartModem::Disconnect                            *
*                          ========================                            *
* PURPOSE:                                                                     *
*    Disconnect the modem from the currently connected channel.                *
* ARGUMENTS:                                                                   *
*    bResetState (UIO only) - When set to FALSE, caller intends to search for  *
*                             FDM sessions.                                    *           
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Initialize clsHartModem members with default values and flush buffers. *
*    2. Disable the HART multiplexor associated with the modem and RTS.        *
* NOTES:                                                                       *
*    1. Disonnect is called from HartModemHeartbeat and HartModemInterrupt,    *
*       if client has requested to disconnect.                                 *
*    2. Disconnect need to be protected as private method to streamline the    *
*       state change activities. So clients requesting disconnect sets a bool  *
*       variable in the modem object rather than calling the disconnect method *
*       directly. Next invocation of HartModemInterrupt or HartModemHeartbeat  *
*       method will call the Disconnect method.                                *
*******************************************************************************/
#if defined(IOMTYPE_UIO)
VOID clsHartModem::Disconnect(BOOL bResetState)
#else
VOID clsHartModem::Disconnect(VOID) 
#endif
{    
#if !defined(IOMTYPE_UIO)
    // Disable the MUX
    UINT8 ucDsbl = (0x01 << m_ucModemNumber);
    m_ucHartMuxEnbl &= ~ucDsbl; 
    HART_MUXENBL.ALL_FOUR = m_ucHartMuxEnbl; 
#endif

    HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0; // Disable RTS
    HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = 0; // Disable all HART interrupts.

    ClearTxRxFIFOs();
    
#if defined(IOMTYPE_UIO)
    // Raise priority temporarily so we can safely update m_bHartStackProc.
    // NOTE: Not sure if this is needed, but VW did this.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);
#endif

    if (m_ModemState != HMODEMSTATE_BAD)  {
        // BAD state can only be cleared by a power cycle.
        m_ModemState = HMODEMSTATE_IDLE;  
    }
    
#if defined (IOMTYPE_UIO)
    if(bResetState == FALSE) 
    {
        // TRUE indicates, after this function execution, there is going to be 
        // search for PST from function which has called Disconnect function
        m_bHartStackProc = TRUE;
    }
    // Restore priority
    set_imask_exr(ucSaveExr);
#endif

    m_ucModemTimer       = 0;
    m_ucConnectedChannel = 0;
    m_cucpXmtBuffer      = NULL;
    m_ucModemDiagCount   = 0;
    
    m_ModemRcvBuffer.Flush();

    m_ucPollingAddress = 0;
    for (UINT8 ucCount = 0; ucCount < HART_LONGADDR_LENGTH; ucCount++) {
        m_UniqueAddress.ucBytes[ucCount] = 0;
    }
    
    m_ucXmtCommand      = HARTCOMMAND_INVALID;
    m_ucBytesInRequest  = 0;
    m_ucBytesInResponse = 0;
    m_XmtRcvContext     = XMTRCVCONTEXT_UNKNOWN;
    m_RcvMsgType        = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus      = HMSGSTATUS_BAD;
    m_ucCheckSum        = 0;
    m_ucRetryCount      = 0;
    m_ucRemPreambles    = 0;
    m_bRequestDisconnect= FALSE;
}
/*******************************************************************************
*                            clsHartModem::SwitchMux                           *
*                            =======================                           *
*******************************************************************************/
VOID clsHartModem::SwitchMux(UINT8 a_ucChan) {
    
#if defined(IOMTYPE_UIO)
    FPGA.SetHartAddress(a_ucChan);    
#else
    UINT16 usAddr = a_ucChan - 1;
    
    usAddr <<= (m_ucModemNumber * 4);
    
    switch (m_ucModemNumber) {
    case 0:
        m_usHartMuxAddr &= 0xFFF0;
        break;
    case 1:
        m_usHartMuxAddr &= 0xFF0F;
        break;
    case 2:
        m_usHartMuxAddr &= 0xF0FF;
        break;
    case 3:
        m_usHartMuxAddr &= 0x0FFF;
        break;
    default:
        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
    }        

    m_usHartMuxAddr |= usAddr;
    m_ucHartMuxEnbl |= (0x01 << m_ucModemNumber);

    HART_MUXADDR = m_usHartMuxAddr;
    IdleWait(1);
    HART_MUXENBL.ALL_FOUR = m_ucHartMuxEnbl;
#endif
}

#if !defined(IOMTYPE_UIO)
/*******************************************************************************
*                       clsHartModem::HartMuxLoopbackTest                      *
*                       =================================                      *
*******************************************************************************/
UINT8 clsHartModem::HartMuxLoopbackTest(VOID) 
{
    UINT8 ucRdbkFail = 0, ucMuxEnblMask = (0x01 << m_ucModemNumber);
    UINT16 usMuxAddrMask = (0x000F << (m_ucModemNumber * 4));

    // Do HART MUX ENBL and ADDR lines readback test with three retries.
    for (UINT8 ucTrial = 0; ucTrial < HART_MAX_RETRIES; ucTrial++)
    {
        if (((HART_MUXADDR & usMuxAddrMask) != (m_usHartMuxAddr & usMuxAddrMask)) ||
            ((HART_MUXENBL.ALL_FOUR & ucMuxEnblMask) != (m_ucHartMuxEnbl & ucMuxEnblMask)))
        {
            ucRdbkFail++;
        }
    }
    
    return ucRdbkFail;
}
#endif

/*******************************************************************************
*                          clsHartModem::DiagConnect                           *
*                          =========================                           *
*  Perform modem diagnostics by connecting to the same channel as the suspect  *
*  modem. In DIAG mode, the data member m_ucConnectedChannel is used to store  *
*  the modem number of the suspect modem. Suspect modem is reinstated back to  *
*  SYNCWAIT state so that it will retry transmission. DIAG modem will look for *
*  carrier detect when suspect modem is transmitting.                          *
*******************************************************************************/
VOID clsHartModem::DiagConnect(UINT8 a_ucSuspectModem) {

#if defined(IOMTYPE_UIO)
    // UIO cannot support diagnostic connections.
    HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
#endif
    m_ModemState = HMODEMSTATE_DIAG;
    m_ucConnectedChannel = a_ucSuspectModem;
    m_ucModemTimer = HART_SLAVE_TIME_OUT;
    m_ucRemPreambles = 0;
    SwitchMux(pHartModem[a_ucSuspectModem]->GetConnectedChannel());
    
    ClearTxRxFIFOs();
    m_ModemRcvBuffer.Flush(); // Initialize the modem receive buffer.
    if (HART_RCVINTR_ENABLE != HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER) {
        HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;
        HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_RCVINTR_ENABLE;
    }
    
    // Put the SUSPECT modem back into SYNCWAIT state.
    pHartModem[a_ucSuspectModem]->ReinstateModem();

    // Update the diagnostic count and log the trace if required.
    m_sulMDiagCount++;
    if ((m_sulMDiagCount % 100) == 0) {
        TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagCount,m_sulMDiagCount);
    }
}
/*******************************************************************************
*                       clsHartModem::ProcessDiagModem                         *
*                       ==============================                         *
*  This function will be called if any RCV interrupt is detected while modem   *
*  is DIAG state. Check for the presence of carrier and make sure that suspect *
*  modem is transmitting. If both conditions are met, simply disconnect modem  *
*  so that it will be relieved of dianostic duties. Any data received in DIAG  *
*  mode is discarded.                                                          *
*******************************************************************************/
VOID clsHartModem::ProcessDiagModem(VOID) {
    UINT8 ucRcvdByte;
    // First ready any data in the UART receive buffer.
    while (HART_UART(m_ucModemNumber).DATA_READY) {
        UINT8 ucLineStatus = HART_UART(m_ucModemNumber).LINE_STS_REGISTER;
        ucRcvdByte = HART_UART(m_ucModemNumber).RCVBUF_REGISTER;
        if ((HART_PREAMBLE_BYTE == ucRcvdByte) &&
            (!(ucLineStatus & HART_RCVERROR_PRESENT))) {
            // If a preamble byte is received without any reception 
            // (break, framing, parity or overrun) error, increment byte count.
            m_ucRemPreambles++;
        }
    }

    if (m_ucRemPreambles >= HART_MIN_PREAMBLES) 
    {
        // Modem circuit is working fine. Reset last failed channel and disconnect the DIAG modem. 
        if (pHartModem[m_ucConnectedChannel]->GetConnectedChannel() == m_ucFailedChannel)
        {
            m_ucFailedChannel = 0;
        }

        Disconnect();
    }
}
/*******************************************************************************
*                         clsHartModem::HartModemInterrupt                     *
*                         ================================                     *
* PURPOSE:                                                                     *
*    Service interrupts from the associated UART channel.                      *
* ARGUMENTS:                                                                   *
*    1. a_HartIntrType - interrupt type identified by the ISR.                 *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Exit if modem state is IDLE or BAD.                                    *
*    2. If the client has requested disconnect, process it and return.         *
*    3. Process according to the interrupt type.                               *
* NOTES:                                                                       *
*    1. This method is called from ProcessHartInterrupt.                       *
*******************************************************************************/
VOID clsHartModem::HartModemInterrupt(HINTRTYPE a_HartIntrType) {
    if ((HMODEMSTATE_BAD == m_ModemState) || (HMODEMSTATE_IDLE == m_ModemState)) {
        return;
    }

    if (TRUE == m_bRequestDisconnect) {
        Disconnect();
        return;
    }

    BOOL bRcvdGood = TRUE;
    UINT8 ucByteCount = 0, ucLineErrCount = 0;

    switch (a_HartIntrType) {
    case HINTRTYPE_XMTFIFOEMPTY:
        if (HMODEMSTATE_XMTING == m_ModemState) {
            // Whatever put into UART FIFO earlier is transmitted.  
            if (m_ucBytesInRequest == 0) {
                // If all bytes of the request are transmitted, change state to RCVING. 
                SetState(HMODEMSTATE_RCVING,HART_SLAVE_TIME_OUT);
            }
            else {
                // There are more bytes left in the request.
                // Transmit next frame.
                TransmitRequest();
            }
        }
        break;
    case HINTRTYPE_CARRIERDETECT:
        // This interrupt is used for the timing of slave timeout or modem diagnostics.
        if ((HMODEMSTATE_RCVING == m_ModemState) ||
            (HMODEMSTATE_RCVWAIT == m_ModemState) ||
            (HMODEMSTATE_SUSPECT == m_ModemState)) {
            m_ModemState = HMODEMSTATE_RCVING;
            // Detected the start of the response messsage. Set the modem 
            // timer to the time required to fill UART receive FIFO.
            if (m_ucModemTimer < UART_RCV_FIFO_SIZE) {
                m_ucModemTimer = UART_RCV_FIFO_SIZE;
            }
        }
        else if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
            m_ucModemTimer = UART_RCV_FIFO_SIZE;
        }
        break;
    case HINTRTYPE_RCVFIFOFULL:
    case HINTRTYPE_RCVFIFOTOUT:
    case HINTRTYPE_CARRIERDROP:
        if (HMODEMSTATE_DIAG == m_ModemState) {
            ProcessDiagModem();
            break;
        }
        else if (HMODEMSTATE_SUSPECT == m_ModemState) {
            m_ModemState = HMODEMSTATE_RCVING;
        }
        // Data is available in UART FIFO. Copy all data to the modem buffer.
        // Check the line status register for each data byte. The status of
        // reception is revealed by the UART when the data byte is on top of
        // the receive FIFO.
        while (HART_UART(m_ucModemNumber).DATA_READY) { // while data in DUART RCV FIFO
            UINT8 ucLineStatus = HART_UART(m_ucModemNumber).LINE_STS_REGISTER;
            // Copy data from UART RCV FIFO to modem object buffer.
            m_ModemRcvBuffer = HART_UART(m_ucModemNumber).RCVBUF_REGISTER;
            ucByteCount++;
            if (ucLineStatus & HART_RCVERROR_PRESENT) {
                // If any reception (break, framing, parity or overrun) error detected.
                if ((1 == ucByteCount) && (HART_MAX_BYTECOUNT == m_ucBytesInResponse)) {
                    // First byte of the frame may not be received correctly. Ignore the error
                    // and discard the received byte for error in the first byte of the frame.
                    m_ModemRcvBuffer.ThrowLastRcvd(); 
                }
                else if (ucByteCount < m_ucBytesInResponse) {
                    ucLineErrCount++; // increment the error count.
                    if (ucLineErrCount > 1) { // if more than one error present
                        bRcvdGood = FALSE; // declare the message reception as bad.
                    }
                }
                else { // All bytes are received. This is a dribble byte.
                    m_ModemRcvBuffer.ThrowLastRcvd(); // Ignore it.
                }
            }
        }

        // All bytes left in the RCV FIFO are now copied to modem object buffer.
        if ((ucByteCount <= MAX_DRIBBLE_BYTES) && (m_ucBytesInResponse > MAX_DRIBBLE_BYTES)) {
            // PMIO SIT found that two dribble byte can be in the FIFO when secondary
            // master is used with some type of devices. If only two bytes are 
            // there in the FIFO when more than two bytes are expected in the 
            // response, these are dribble bytes left in the FIFO from an earlier 
            // transaction. Igore these bytes.
            // NOTE: Communication failure will be reported, in case more than  
            // two dribble bytes happen to occur.
            while (ucByteCount > 0) {
                m_ModemRcvBuffer.ThrowLastRcvd();
                ucByteCount--;
            }
            return;
        }

        if (TRUE == bRcvdGood) { // If the reception was good
            ProcessResponse();
        }
        else {
            HandleReceiveError();
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,1);
    }
}
/*******************************************************************************
*                       clsHartModem::HartModemHeartbeat                       *
*                       ================================                       *
* PURPOSE:                                                                     *
*    Service the timer interrupt from TPU2 once every HART chracter time       *
*    (9.167 msec) interval.                                                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If modem state is BAD return immediately.                              *
*    2. If modem state is IDLE process the HART Q and return.                  *
*    3. If client has requested to disconnect, process it and return.          *
*    4. Decrement the modem timer and call ModemTimeout method if the timer    *
*       decrements to zero.                                                    *
* NOTES:                                                                       *
*    1. This method is invoked from the TPU2 of H8.                            *
*******************************************************************************/
VOID clsHartModem::HartModemHeartbeat(VOID) {
    static UINT8 stucProcessModem = 0;
    TPU2_TGFA = 0; // Acknowledge the compare match interrupt
    
    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++,stucProcessModem++) {
        if (stucProcessModem >= HARTMODEM_COUNT) stucProcessModem = 0;
 
        // If modem is BAD, make sure that softfail is posted and continue.
        if (pHartModem[stucProcessModem]->m_ModemState == HMODEMSTATE_BAD) {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,(SOFTFAILTYPE)(SF_HMODEM1+stucProcessModem),TRUE,0);
            continue;
        }
        
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,(SOFTFAILTYPE)(SF_HMODEM1+stucProcessModem),FALSE,0);
                
        // Diag underrun count should be reset in secondary in any case.
        if (Iol.AmPrimary() == FALSE) {
            m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT; 
        }
            
        // Post/return SF_HDIAGTO depending on the number of 1-second  
        // channels and the diag underrun count. If m_ucHDiagUnderRunCount  
        // has reached zero, this modem is waiting in SUSPECT state for  
        // 3 seconds and SF_HDIAGTO softfail should be posted.
        if ((0 == m_ucHDiagUnderRunCount) ||
            (clsHartDevDb::GetNoOf1SecChannels() > MAX_1SEC_CHANNELS)) { 
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_HDIAGTO,TRUE,0);
        }
        else {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_HDIAGTO,FALSE,0);
        }
        
        // If the IOM is not primary, stop all activities for this modem.
#if defined(IOMTYPE_UIO)
        if ((Iol.AmPrimary() == FALSE) && (TRUE != HartLoopBkTestInProgress)) {
#else
        if (Iol.AmPrimary() == FALSE) {
#endif
            pHartModem[stucProcessModem]->Disconnect();
            continue;
        }
        
        // If client request disconnect, do it and process the queue.
        if (TRUE == pHartModem[stucProcessModem]->m_bRequestDisconnect)  {
            pHartModem[stucProcessModem]->Disconnect();
        }
        
        // If modem is IDLE, first check whether any other modem needs diagnosis
        if (pHartModem[stucProcessModem]->m_ModemState == HMODEMSTATE_IDLE) {
            //---------------------------------------------
            // UIO cannot perform diagnostic connections 
            // and will not mark modems as suspect.
            //---------------------------------------------
#if !defined(IOMTYPE_UIO)
            for (UINT8 ucCheck = 0; ucCheck < HARTMODEM_COUNT; ucCheck++) {
                if (ucCheck != stucProcessModem) {
                    if (pHartModem[ucCheck]->GetModemState() == HMODEMSTATE_SUSPECT) {
                        // Perform diagnostics of the suspect modem.
                        pHartModem[stucProcessModem]->DiagConnect(ucCheck);
                        break; // Break from the inner for loop.
                    }
                }
            }
#endif

            if (pHartModem[stucProcessModem]->m_ModemState != HMODEMSTATE_DIAG) {
                // if no modem requires diagnosis, process the HART queue as usual.           
#if defined(IOMTYPE_UIO)
                // Each modem has its own queue                   
                pHartQueue[stucProcessModem]->ProcessQueue(stucProcessModem);
#else
                HartQueue.ProcessQueue(stucProcessModem);
#endif
            }

            continue; // Continue to process next modem.
        }
   
        // Execution reaches here if modem was not IDLE. Process modem timer.
        if (pHartModem[stucProcessModem]->m_ucModemTimer > 0) {
            pHartModem[stucProcessModem]->m_ucModemTimer--;
        }
        if (0 == pHartModem[stucProcessModem]->m_ucModemTimer) {
            pHartModem[stucProcessModem]->ModemTimeout();
        }
    }
}
/*******************************************************************************
*                           clsHartModem::SetState                             *
*                           ======================                             *
* PURPOSE:                                                                     *
*    Set modem object to transmit, receive and waiting-to-sync states.         *
* ARGUMENTS:                                                                   *
*    1. a_ModemState - HMODEMSTATE to be set.                                  *
*    2. a_ucModemTimer - modem timer value to be set.                          *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Set the specified members and initialize other object members with     *
*       default values.                                                        *
*    2. Re-initialize channel details if state is changed to SYNCWAIT.         *
*    3. Set the UART interrupts and drive the RTS line as per the new state.   *
* NOTES:                                                                       *
*    1. This method is called from a number of modem object methods - Connect, *
*       TransmitRequest, ProcessResponse, ActOnResponse and SetupRetry.        *
*******************************************************************************/
VOID clsHartModem::SetState(HMODEMSTATE a_ModemState,UINT8 a_ucModemTimer) {
    m_ucModemTimer      = a_ucModemTimer;
    m_XmtRcvContext     = XMTRCVCONTEXT_UNKNOWN;
    m_RcvMsgType        = HMSGTYPE_UNKNOWN;
    m_RcvMsgStatus      = HMSGSTATUS_BAD;
    m_ucCheckSum        = 0;
    m_ucBytesInResponse = HART_MAX_BYTECOUNT; 

    ClearTxRxFIFOs();
#if defined(IOMTYPE_UIO) 
    HCHANTYPE ChanType;
    
    // Since the AI and AO channels don't inherit from a common HART class,
    // switch on the channel type to pull out the information we need.
    switch (BOX->GetInitPntType(m_ucConnectedChannel))
    {
        case PNTTYPE_ANALOGINPUT:
        
            ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        case PNTTYPE_ANALOGOUTPUT:
        
            ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        default:
            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
            break;
    }  
#else
    HCHANTYPE ChanType = SLOT(m_ucConnectedChannel)->GetHartChanType();
#endif
    switch (a_ModemState) {
    case HMODEMSTATE_SUSPECT:
    case HMODEMSTATE_SYNCWAIT:
        if (HART_RCVINTR_ENABLE != HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER) {
#if defined(IOMTYPE_UIO)
            // Disable the transmitter so we can receive data
            FPGA.EnableHartTransmitter(m_ucConnectedChannel, FALSE);
#endif
            HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;
            HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_RCVINTR_ENABLE;
        }

#if !defined(IOMTYPE_UIO)
       // UIO has separate pointers for PST and Status updates
        m_cucpXmtBuffer = SLOT(m_ucConnectedChannel)->GetXmtDataPtr();
#endif
        if (HCHANTYPE_PASSTHROUGH == ChanType) {
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
            
                    m_cucpXmtBuffer = AIH_SLOT(m_ucConnectedChannel)->GetPstXmtDataPtr();
                    break;
                
                case PNTTYPE_ANALOGOUTPUT:
            
                    m_cucpXmtBuffer = AOH_SLOT(m_ucConnectedChannel)->GetPstXmtDataPtr();
                    break;
                
                default:
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
          }    
#endif
            m_ucXmtCommand = *(m_cucpXmtBuffer + HPST_COMMAND_OFFSET);
            m_ucBytesInRequest = HPST_MESSAGE_OVERHEAD + *(m_cucpXmtBuffer + HPST_BYTECOUNT_OFFSET); 
        }
        else if (HCHANTYPE_CHANNEL == ChanType) {
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
            
                    m_cucpXmtBuffer = AIH_SLOT(m_ucConnectedChannel)->GetXmtDataPtr();
                    break;
                
                case PNTTYPE_ANALOGOUTPUT:
            
                    m_cucpXmtBuffer = AOH_SLOT(m_ucConnectedChannel)->GetXmtDataPtr();
                    break;
                
                default:
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
          }    
#endif
            m_ucXmtCommand = *m_cucpXmtBuffer++;
            // Bytecount + 1 checkbyte + 1 pad character. Pad character is
            // required to make sure that check byte is fully transmitted
            // before the RTS line is disabled.
            m_ucBytesInRequest = *m_cucpXmtBuffer++ + CHECKPAD_BYTECOUNT; 
        }
        else {
            HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
        }

#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                m_ucPollingAddress = AIH_SLOT(m_ucConnectedChannel)->GetPollingAddress();
                m_ucPollingAddress = ((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
                m_UniqueAddress = AIH_SLOT(m_ucConnectedChannel)->GetUniqueAddress();
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                m_ucPollingAddress = AOH_SLOT(m_ucConnectedChannel)->GetPollingAddress();
                m_ucPollingAddress = ((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
                m_UniqueAddress = AOH_SLOT(m_ucConnectedChannel)->GetUniqueAddress();
                break;
                
            default:
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }    
        
#else
        m_ucPollingAddress = SLOT(m_ucConnectedChannel)->GetPollingAddress();
        m_ucPollingAddress = ((m_ucPollingAddress & HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
        m_UniqueAddress = SLOT(m_ucConnectedChannel)->GetUniqueAddress();
#endif
        m_UniqueAddress.ucBytes[0] = ((m_UniqueAddress.ucBytes[0] & 
                                       HART_MANUFACTURE_ID_MASK) | HART_MASTER_ADDR_MASK);
        m_ModemState = a_ModemState;
        break;
    case HMODEMSTATE_XMTING:
        // Note that Transmit Holding Register Empty (THRE) interrupt is not
        // enabled here. As the transmit FIFO is empty now, enabling this 
        // interrupt will cause a false triggering. THRE interrupt is enabled
        // in TransmitRequest method, only after transmit bytes are transfered to
        // the UART XMT FIFO. RTS is also asserted just before the trasmit start.
        m_ModemState = HMODEMSTATE_XMTING;
        break; 
    case HMODEMSTATE_RCVING:
        if (HART_RCVINTR_ENABLE != HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER) {
#if defined(IOMTYPE_UIO)
            // Disable the transmitter so we can receive data
            FPGA.EnableHartTransmitter(m_ucConnectedChannel, FALSE);
#endif
            HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;
            HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_RCVINTR_ENABLE;
        }
        m_ModemState = HMODEMSTATE_RCVING;
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,2);
    }
}
/*******************************************************************************
*                         clsHartModem::ModemTimeout                           *
*                         ==========================                           *
* PURPOSE:                                                                     *
*    Service modem timer expired condition.                                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If modem is idle or bad, return.                                       *
*    2. If waiting for sync, check the receive buffer. If any data is received *
*       call HartModemInterrupt with RCVFIFOTOUT to process the received bytes.*
*       Otherwise, the link quiet time has been validated and is ok to start   *
*       tranmsitting the request.                                              *
*    3. If in reception mode also, check the receive buffer. If any data is    *
*       received, call HartModemInterrupt with RCVFIFOTOUT to process the      *
*       received bytes. Otherwise, call SetupRetry to retry the request.       *
*    4. If in transmit mode, check the transmit FIFO to see any characters are *
*       left to transmit. If not, this trasmit interrupt was somehow missed    *
*       by the IRQ1 processing. Call HartModemInterrupt with XMTFIFOEMPTY.     *
* NOTES:                                                                       *
*    1. ModemTimeout is called from HartModemHeartbeat method when modem timer *
*       decrements to zero.                                                    *
*******************************************************************************/
VOID clsHartModem::ModemTimeout(VOID) {
    switch (m_ModemState) {
    case HMODEMSTATE_BAD:
    case HMODEMSTATE_IDLE:
        return;
    case HMODEMSTATE_SUSPECT:
        // This modem needs diagnosis. Do not allow it to timeout and change
        // state. It will be taken out SUSPECT state only when another modem
        // is available for diagnosis.
        m_ucModemTimer = HART_PRIMARY_QUIET_TIME;
        // It takes approximately 300 milli second for the timer to timeout.
        // m_ucHDiagUnderRunCount is decremented for each timeout. When it
        // decrements to zero, 3 seconds has elapsed with this modem in
        // SUSPECT state. This will result in posing of SF_HDIAGTO softfail.
        if (m_ucHDiagUnderRunCount > 0) {
            m_ucHDiagUnderRunCount--;
            if (1 == m_ucHDiagUnderRunCount) {
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagFailed,
                                    (0xAA00|m_ucModemNumber));
            }
        }
        break;
    case HMODEMSTATE_DIAG:
        {
#if defined(IOMTYPE_UIO)
             // UIO cannot support diagnostic connections.
             HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
#else
            UINT8 ucSuspectModem = m_ucConnectedChannel; // NOTE: SUSPECT modem is connected to DIAG modem.
            UINT8 ucSuspectChannel = pHartModem[ucSuspectModem]->GetConnectedChannel();

            UINT8 ucModemDiagCount = pHartModem[ucSuspectModem]->GetModemDiagCount();
            HMODEMSTATE SuspectModemState = pHartModem[ucSuspectModem]->GetModemState();

            if (SuspectModemState == HMODEMSTATE_IDLE)
            {
                // SUSPECT modem has aborted transmission due to a configuration change.
                // For example, channel delete. Abort diagnostics by disconnecting the DIAG modem.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagAbort);
                Disconnect();
            }
            else if ((SuspectModemState == HMODEMSTATE_SYNCWAIT) || (SuspectModemState == HMODEMSTATE_XMTING))
            {
                // SUSPECT modem is still waiting for transmission or doing the transmission. Reset
                // DIAG modem timer and wait for the SUSPECT modem to complete transmission of preambles.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagReset,
                                    (SuspectModemState << BYTESIZE) | pHartModem[ucSuspectModem]->GetModemTimer());
                m_ucModemTimer = HART_SLAVE_TIME_OUT; 
            }
            //---------------------------------------------
            // UIO cannot perform diagnostic connections 
            // and will not mark modems as suspect.
            //---------------------------------------------
            else if (ucModemDiagCount < HMODEMDIAG_MAXCOUNT)
            {
                // Retry diagnostics.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagRetry,
                    (((UINT32)m_ucRemPreambles << (WORDSIZE+BYTESIZE)) | ((UINT32)ucSuspectChannel << WORDSIZE) |
                     (SuspectModemState << BYTESIZE) | ucModemDiagCount)); 
                DiagConnect(ucSuspectModem);
            }
            else {
                // Send bad status back to the connected channel of the 
                // SUSPECT modem until the channel agrees to disconnect.
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHModemDiagFailed,
                    ((UINT32)ucSuspectModem << (WORDSIZE+BYTESIZE)) | ((UINT32)m_ucModemNumber << WORDSIZE) |
                    (ucSuspectChannel << BYTESIZE) | m_ucFailedChannel);

                while (HSYNCSTATUS_KEEP_SYNC == SLOT(ucSuspectChannel)->ReceptionComplete(HMSGSTATUS_BAD));

                if (ucSuspectChannel == m_ucFailedChannel)
                {
                    // If modem diagnostics failed on the same channel as the last one,
                    // problem is with the HART channel, not with the modem. Clear all
                    // modem failures and report HART channel failure.
                    if (Iol.AmPrimary()) SLOT(m_ucFailedChannel)->GetHartDevDb().SetHartChanFail();

                    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
                    {
                        pHartModem[ucModem]->ClearModemBad();
                    }

                    pHartModem[ucSuspectModem]->Disconnect();
                    Disconnect();
                }
                else
                {
                    // DIAG modem timed out means it waited for 28 character times and 
                    // did not see a carrier. Also the diagnostics was retried three times
                    // and all trails failed. That means there is a failure with either
                    // the DIAG modem itself or with the modem being diagnosed. Mark 
                    // both modems bad so that both will be taken out of scheduling.
                    // Set DIAG modem also bad as it cannot be determined whether 
                    // the SUSPECT modem or the DIAG modem has hardware problem.
                    // Note that DIAG modem is connected only to the physical channel,
                    // it is not connected to any channel object and does not need to
                    // call ReceptionComplete() unlike the SUSPECT modem.
                    if (Iol.AmPrimary()) 
                    {
                        m_ucFailedChannel = ucSuspectChannel;
                        pHartModem[ucSuspectModem]->SetModemBad();
                        SetModemBad();
                    }
                    else 
                    {
                        pHartModem[ucSuspectModem]->Disconnect();
                        Disconnect();
                    }
                }
            }
#endif
        }
        break;
    case HMODEMSTATE_SYNCWAIT:
        if (HART_UART(m_ucModemNumber).DATA_READY) {
            // There is data in UART RCV FIFO but not up to the RCV FIFO
            // interrupt trigger level. Treat this condition similar to RCV
            // FIFO timeout and call HartModemInterrupt.
            HartModemInterrupt(HINTRTYPE_RCVFIFOTOUT);
        }
        else {
            // HART master link quiet time has elapsed and the IOP is now
            // synchronized. Start transmission of the request.
            TransmitRequest();
        }
        break;
    case HMODEMSTATE_RCVWAIT:
    case HMODEMSTATE_RCVING:
        if (HART_UART(m_ucModemNumber).DATA_READY) {
            // There is data in DUART RCV FIFO but not up to the RCV FIFO
            // interrupt trigger level. Treat this condition similar to RCV
            // FIFO timeout and call HartModemInterrupt.
            HartModemInterrupt(HINTRTYPE_RCVFIFOTOUT);
        }
        else {
            // Timeout while waiting for reply. 
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
                
                    AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_NORESPONSE);        
                    break;
                    
                case PNTTYPE_ANALOGOUTPUT:
                
                    AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_NORESPONSE);
                    break;
                    
                default:
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
            } 
                
            // Setup a retry and don't mark the modem as suspect.
            // UIO cannot perform diagnostic connections.
            SetupRetry(HART_LINK_GRANT_TIME);
#else
            SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_NORESPONSE);
#endif
            // If this is the first retry after a complete loss of response,
            // and is not device discovery operation, mark modem as SUSPECT so that
            // modem diagnosis will be done with the transmission of the retry request.
            // For AO make sure that the loopback test is also successful.
            // For AI make sure HEnable is TRUE
#if defined(IOMTYPE_AIH)
            if ((Iol.AmPrimary()) && 
                (m_ucModemDiagCount == 0) &&
                (SLOT(m_ucConnectedChannel)->GetHartCfgDb().HEnable == TRUE)) {
#endif
            
#if defined(IOMTYPE_AOH)
            AOLPBKSTS LpbkSts = AOLPBK_PASSED;
            if ((BOX->GetModuleStatus() == MODSTATUS_RUN) &&
                (SLOT(m_ucConnectedChannel)->GetPtExecSt() == PTEXECST_ACTIVE)) {
                LpbkSts = SLOT(m_ucConnectedChannel)->GetLoopBackStatus();
            }
            else {
                set_imask_exr(LVLPRI_TICK);
                LpbkSts = SLOT(m_ucConnectedChannel)->DoLoopbackTest();
                set_imask_exr(LVLPRI_HART);
            }
            if ((Iol.AmPrimary()) && 
                (m_ucModemDiagCount == 0) && 
                (AOLPBK_PASSED == LpbkSts) && 
                (SLOT(m_ucConnectedChannel)->GetOpFinal() > OP_LOLIMIT)) {
#endif

#if !defined(IOMTYPE_UIO)
                // This modem requires diagnostics. Before changing the state
                // to SUSPECT, check how many modems are already in SUSPECT state.
                UINT8 ucSuspectModems = 0;
                for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
                {
                    if (pHartModem[ucModem]->GetModemState() == HMODEMSTATE_SUSPECT)
                    {
                        ucSuspectModems++;
                    }
                }

                // Make sure that at least one modem is available for diagnostics.
                if (ucSuspectModems < (HARTMODEM_COUNT - 1))
                {
                    m_ucRetryCount--;

                    SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);

                    SetState(HMODEMSTATE_SUSPECT,HART_PRIMARY_QUIET_TIME);
                }
                else
                {
                    // This is the only modem that not in SUSPECT state.
                    // Free this one so that it can do diagnostics.
                    // Also force channel to disconnect from this modem.

                    while (HSYNCSTATUS_KEEP_SYNC == 
                           SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD));

                    Disconnect();
                }
            }
            else {
                // This is not the first retry or this channel is not configued
                // for HART (auto detection is going on) or loopback test has failed.
                // Setup for retry as usual.
                SetupRetry(HART_LINK_GRANT_TIME);
            }
#endif
        }
        break;
    case HMODEMSTATE_XMTING:
        if (HART_UART(m_ucModemNumber).XMTREG_EMPTY) {
            // Transmit FIFO is empty; but the interrupt was missed.
            // Call HartModemInterrupt as if interrupt really triggered.
            HartModemInterrupt(HINTRTYPE_XMTFIFOEMPTY);
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,3);
    }
}
/*******************************************************************************
*                        clsHartModem::TransmitRequest                         *
*                        =============================                         *
* PURPOSE:                                                                     *
*    Transmit the request by transfering bytes to UART transmit FIFO.          *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If this is the first frame of transmission, set the state to XMTING.   *
*       If this is the last retry of a command zero poll, reset address to 0.  *
*    2. Check the client type and do the transmit context switching depending  *
*       on the bytes left to transmit and the space available in the UART XMT  *
*       FIFO.                                                                  *
*    3. Enable Transmit Holding Register Empty interrupt.                      *
* NOTES:                                                                       *
*    1. This method is called from ModemTimeout when link quiet time expires   *
*       without any activity in the link.                                      *
*    2. TransmitRequest is called from ActOnResponse method when ACK or BACK   *
*       frame to the secondary master is detected.                             *
*    3. TransmitRequest is called from HartModemInterrupt in response to XMT   *
*       Holding Register Empty interrupt for transmitting rest of the message. *
*******************************************************************************/
VOID clsHartModem::TransmitRequest(VOID) 
{
    UINT8 ucXmtByteCount = 0, ucAddrByteCount = 0;
    
#if defined(IOMTYPE_UIO)

    HCHANTYPE ChanType;
    
    // Enable the transmitter
    FPGA.EnableHartTransmitter(m_ucConnectedChannel, TRUE);
    
    // Since the AI and AO channels don't inherit from a common HART class,
    // switch on the channel type to pull out the information we need.
    switch (BOX->GetInitPntType(m_ucConnectedChannel))
    {
        case PNTTYPE_ANALOGINPUT:
        
            ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        case PNTTYPE_ANALOGOUTPUT:
        
            ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        default:
            // We should never get here...
            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
            break;
    }
#else
    HCHANTYPE ChanType = SLOT(m_ucConnectedChannel)->GetHartChanType();
#endif

    if (HMODEMSTATE_SYNCWAIT == m_ModemState) { 
        // If modem state is SYNCWAIT, it means that the link quiet time has
        // just elapsed and this is the first frame of a new request.
        if (HCHANTYPE_CHANNEL == ChanType) {
            if ((m_ucRetryCount == 0) && (HARTCOMMAND_ZERO == m_ucXmtCommand)) {
                // If transmit command is command zero, device discovery going 
                // on and this is the last retry. Change the polling address to 
                // 0 to speed up the overall device discovery time. Otherwise, 
                // if the device misses the first poll for address 0, it will 
                // have to wait until all 16 addresses are tried. With this 
                // scheme, IOP will poll for address 0 during the last retry 
                // of any other address. NOTE that this scheme assumes the
                // number of retries for command 0 is always greater than one.
                m_ucPollingAddress = HART_MASTER_ADDR_MASK;
            }
        }

        // This is the first frame. Change modem state to XMTING and
        // initialize the context to PREAMBLE. 
        SetState(HMODEMSTATE_XMTING,UART_XMT_FIFO_SIZE);
        ucXmtByteCount = 0; 
        m_XmtRcvContext = XMTRCVCONTEXT_PREAMBLE;
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                m_ucRemPreambles = AIH_SLOT(m_ucConnectedChannel)->GetNoOfPreambleBytes();
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                m_ucRemPreambles = AOH_SLOT(m_ucConnectedChannel)->GetNoOfPreambleBytes();
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }      
#else
        m_ucRemPreambles = SLOT(m_ucConnectedChannel)->GetNoOfPreambleBytes();
#endif
    }

    if (HCHANTYPE_PASSTHROUGH == ChanType) {
        if (ucXmtByteCount < UART_XMT_FIFO_SIZE) { 
            switch (m_XmtRcvContext) {
            case XMTRCVCONTEXT_PREAMBLE:
                while ((m_ucRemPreambles > 0) && (ucXmtByteCount < UART_XMT_FIFO_SIZE)) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
                    ucXmtByteCount++;
                    m_ucRemPreambles--;
                }
                if (ucXmtByteCount >= UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    if (m_ucRemPreambles == 0) { 
                        // all preambles sent
                        m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                    }
                    break;
                }
                // No break for this case. Let the execution fall through 
                // if transmit FIFO is not full.
            case XMTRCVCONTEXT_DATA:
                m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                while ((m_ucBytesInRequest > 0) && (ucXmtByteCount < UART_XMT_FIFO_SIZE)) {
                    // Transmit passthrough bytes.
                    if (m_ucBytesInRequest > 1) {
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = *m_cucpXmtBuffer++; 
                        ucXmtByteCount++;
                    }
                    else {
                        // Transmit the pad character. Pad character is 
                        // required to make sure that check byte is fully 
                        // transmitted before the RTS line is disabled.
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
                        ucXmtByteCount++;
                    }                    
                    m_ucBytesInRequest--;
                }
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,4);
            }
        }
    }
    else if (HCHANTYPE_CHANNEL == ChanType) {  // this is a request from a channel object
        if (ucXmtByteCount < UART_XMT_FIFO_SIZE) { 
            switch (m_XmtRcvContext) {
            case XMTRCVCONTEXT_PREAMBLE:
                while ((m_ucRemPreambles > 0) && (ucXmtByteCount < UART_XMT_FIFO_SIZE)) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
                    ucXmtByteCount++;
                    m_ucRemPreambles--;
                }
                if (ucXmtByteCount >= UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    if (m_ucRemPreambles == 0) {
                        // all preambles sent
                        m_XmtRcvContext = XMTRCVCONTEXT_DELIMITER;
                    }
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_DELIMITER:
                if (HARTCOMMAND_ZERO == m_ucXmtCommand) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_POLLING_DELIMITER; 
                    ucXmtByteCount++;
                    m_ucCheckSum = HART_POLLING_DELIMITER;
                }
                else {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_UNIQUE_DELIMITER; 
                    ucXmtByteCount++;
                    m_ucCheckSum = HART_UNIQUE_DELIMITER;
                }

                if (ucXmtByteCount >= UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_ADDRESS;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_ADDRESS:
                if (HARTCOMMAND_ZERO == m_ucXmtCommand) {
                    HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_ucPollingAddress; 
                    ucXmtByteCount++;
                    m_ucCheckSum ^= m_ucPollingAddress;
                }
                else {
                    if ((UART_XMT_FIFO_SIZE - ucXmtByteCount) >= HART_LONGADDR_LENGTH) { 
                        // Five FIFO bytes required for unique address. Stack 
                        // will not break unique address into two frames.
                        for (ucAddrByteCount = 0; ucAddrByteCount < HART_LONGADDR_LENGTH;) {
                            HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_UniqueAddress.ucBytes[ucAddrByteCount]; 
                            ucXmtByteCount++;
                            m_ucCheckSum ^= m_UniqueAddress.ucBytes[ucAddrByteCount++];
                        }
                    }
                    else { 
                        // XMT FIFO does not have enough space to completely 
                        // queue up unique address. Let the current bytes in
                        // the FIFO to get transmitted.
                        m_XmtRcvContext = XMTRCVCONTEXT_ADDRESS;
                        break;
                    }
                }
                if (ucXmtByteCount == UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_COMMAND;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_COMMAND:
                HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_ucXmtCommand; 
                ucXmtByteCount++;
                m_ucCheckSum ^= m_ucXmtCommand;
                if (ucXmtByteCount == UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_BYTECOUNT;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_BYTECOUNT:
                // m_ucBytesInRequest is set with Bytecount + 2 to account for
                // the checkbyte and the pad character by the SetState method.
                // For transmitting, use the actual byte count.
                HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = (m_ucBytesInRequest - CHECKPAD_BYTECOUNT); 
                ucXmtByteCount++;
                m_ucCheckSum ^= (m_ucBytesInRequest - CHECKPAD_BYTECOUNT);
                if (ucXmtByteCount == UART_XMT_FIFO_SIZE) { // XMT FIFO full
                    m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                    break;
                }
                // No break for this case. Let the execution fall through if 
                // FIFO is not full.
            case XMTRCVCONTEXT_DATA:
                while ((ucXmtByteCount < UART_XMT_FIFO_SIZE) && (m_ucBytesInRequest > 0)) {
                    if (m_ucBytesInRequest > CHECKPAD_BYTECOUNT) {
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = *m_cucpXmtBuffer; 
                        ucXmtByteCount++;
                        m_ucCheckSum ^= *m_cucpXmtBuffer++;
                    }
                    else if (m_ucBytesInRequest == CHECKPAD_BYTECOUNT) { 
                        // Data is over, now transmit the checkbyte
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = m_ucCheckSum; 
                        ucXmtByteCount++;
                    }
                    else  { 
                        // m_ucBytesInRequest is 1. Request is now complete, 
                        // transmit the pad character. Pad character is 
                        // required to make sure that check byte is fully 
                        // transmitted before the RTS line is disabled.
                        HART_UART(m_ucModemNumber).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE; 
                        ucXmtByteCount++;
                    }

                    m_ucBytesInRequest--;
                }
                m_XmtRcvContext = XMTRCVCONTEXT_DATA;
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,5);
            }
        } // if continuation frame
    } // if client type is CHANNEL
    else {
        HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
    }

    // Enable XMT holding register empty interrupt and assert RTS.
    HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 1;
    HART_UART(m_ucModemNumber).INTR_ENBL_REGISTER = HART_XMTINTR_ENABLE;

    // Set modem timer with time for FIFO with ucXmtByteCount bytes to become 
    // empty. Add an allowance two byte times.
    m_ucModemTimer = ucXmtByteCount + XMTINT_ALLOWANCE; 

}
/*******************************************************************************
*                        clsHartModem::ProcessResponse                         *
*                        =============================                         *
* PURPOSE:                                                                     *
*    Pre-process the received bytes.                                           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Decode the response and decide the course of action depending on the   *
*       modem state and the received message status.                           *
* NOTES:                                                                       *
*    1. This method is called from HartModemInterrupt when response is         *
*       received without any reception errors.                                 *
*******************************************************************************/
VOID clsHartModem::ProcessResponse(VOID) {
    switch (m_ModemState) {
    case HMODEMSTATE_SYNCWAIT:
        // Activity on the link while waiting for sync. 
        // Decode the message and try to get in sync.
        DecodeResponse();
        // DecodeResponse sets the response status in m_RcvMsgStatus.
        // m_ucBytesInResponse will be the number of bytes left to receive.
        if (HMSGSTATUS_GOOD == m_RcvMsgStatus) {              
            if (0 == m_ucBytesInResponse) {  
                // Message is completely received and the status is good
                ActOnResponse();
                return;
            } 
            else { // Message is good but not complete yet.
                if (m_ucBytesInResponse > UART_RCV_FIFO_SIZE) {
                    m_ucModemTimer = UART_RCV_FIFO_SIZE;
                }
                else {
                    m_ucModemTimer = m_ucBytesInResponse + RCVINT_ALLOWANCE;
                }
            }
        } 
        else { // Message status is not good
            // Flush modem receive buffer
            m_ModemRcvBuffer.Flush();

            // NOTE: The code below is to work around a probable FPGA UART issue
            // which is under investigation with Xilinx. Sometimes FPGA UARTs does
            // not get into break condition, instead keep filling the FIFO with zero
            // characters when the Rx line of the modem is at low state. The work
            // around is to reset and re-intialize the UART and modem.
            HART_UART(m_ucModemNumber).RESET = 1; 
            // Modem control register - Disable RTS.
            HART_UART(m_ucModemNumber).REQUEST_TO_SEND = 0;

            // Line control register
            // Configure UART for 8 bits per character, odd parity and one stop bit.
            HART_UART(m_ucModemNumber).BITS_PER_CHAR = HART_UART_8BITS_PER_CHAR;
            HART_UART(m_ucModemNumber).PARITY_ENBL = 1; // By default parity is disabled.
            if (HART_UART(m_ucModemNumber).LINE_CTRL_REGISTER != 0x0B) {
                HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
            }
            // FIFO control register - Enable both transmit and receive FIFOs 
            // and configure receive interrupt trigger level of 14 bytes.
            HART_UART(m_ucModemNumber).FIFO_ENBL = 1;
            HART_UART(m_ucModemNumber).RCV_FIFO_TRIG_LEVEL = 3;
            ClearTxRxFIFOs();

            if (HART_UART(m_ucModemNumber).FIFO_CTRL_REGISTER != 0xC1) {
                HardFail(HF_INVPROGRAMEXEC,HARTSTACK_CPP,__LINE__);
            }

            // Reset the timer to LINK QUIET time and keep waiting to get sync
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        break;
    case HMODEMSTATE_RCVING:
        DecodeResponse();
        // DecodeResponse sets the response status in m_RcvMsgStatus.
        // m_ucBytesInResponse will be the number of bytes left to receive.
        if (HMSGSTATUS_GOOD == m_RcvMsgStatus) {
            if (m_ucBytesInResponse == 0) {  
                // Message is completely received and the status is good
                ActOnResponse(); 
            }
            else { // Message is good but not complete yet.
                if (m_ucBytesInResponse > UART_RCV_FIFO_SIZE) {
                    m_ucModemTimer = UART_RCV_FIFO_SIZE;
                }
                else {
                    m_ucModemTimer = m_ucBytesInResponse + RCVINT_ALLOWANCE;
                }
            }
        } 
        else { // If message is not good because of some 
            // communication error, log event and retry.
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
                
                    if (HMSGSTATUS_DEVICEERROR == m_RcvMsgStatus) {
                        AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_DEVICEERROR);
                    }
                    else {
                        AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
                    }
                    break;
                    
                case PNTTYPE_ANALOGOUTPUT:
                
                    if (HMSGSTATUS_DEVICEERROR == m_RcvMsgStatus) {
                        AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_DEVICEERROR);
                    }
                    else {
                        AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
                    }
                    break;
                    
                default:
                    // We should never get here...
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
            } 
#else
            if (HMSGSTATUS_DEVICEERROR == m_RcvMsgStatus) {
                SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_DEVICEERROR);
            }
            else {
                SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
            }
#endif            
            SetupRetry(HART_PRIMARY_QUIET_TIME);            
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,6);
    }
}
/*******************************************************************************
*                         clsHartModem::DecodeResponse                         *
*                         ============================                         *
* PURPOSE:                                                                     *
*    Peform framing of the response message and return the response to client. *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. Check each byte in the modem receive FIFO and perform the framing of   *
*       the response as per HART data link layer specification.                *
*    2. Set message status and number of bytes left to receive in the modem    *
*       class memmbers m_RcvMsgStatus and m_ucBytesInResponse respectively.    *
*    3. Copy appropriate part of the response message to the client receive    *
*       buffer. For passthrough objects, entire response message except the    *
*       preamble bytes is copied. For channel objects only the message from    *
*       byte count field is copied.                                            *
* NOTES:                                                                       *
*    1. This method is called from ProcessResponse method.                     *
*******************************************************************************/
VOID clsHartModem::DecodeResponse(VOID) {
    UINT8 ucCount,ucRcvChar;

    if (HMSGSTATUS_BAD == m_RcvMsgStatus) {
        m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
    }

#if defined(IOMTYPE_UIO)
    HCHANTYPE ChanType;
    
    // Since the AI and AO channels don't inherit from a common HART class,
    // switch on the channel type to pull out the information we need.
    switch (BOX->GetInitPntType(m_ucConnectedChannel))
    {
        case PNTTYPE_ANALOGINPUT:
        
            ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        case PNTTYPE_ANALOGOUTPUT:
        
            ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
            break;
            
        default:
            // We should never get here...
            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
            break;
    }
#else
    HCHANTYPE ChanType = SLOT(m_ucConnectedChannel)->GetHartChanType();
#endif
    while (m_ModemRcvBuffer.GetLength() > 0) { 
        switch (m_XmtRcvContext) {
        case XMTRCVCONTEXT_UNKNOWN:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (ucRcvChar == HART_PREAMBLE_BYTE) {
                m_ucRemPreambles = HART_MIN_PREAMBLES - 1;
                m_RcvMsgStatus = HMSGSTATUS_GOOD;
                m_XmtRcvContext = XMTRCVCONTEXT_PREAMBLE;
            }
            else { // start preamble detection again
                m_ucRemPreambles = HART_MIN_PREAMBLES; 
                m_RcvMsgStatus = HMSGSTATUS_BAD;
            }
            break;
        case XMTRCVCONTEXT_PREAMBLE:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (ucRcvChar == HART_PREAMBLE_BYTE) {
                m_RcvMsgStatus = HMSGSTATUS_GOOD;
                m_ucRemPreambles--;
                if (m_ucRemPreambles == 0) {
                    m_XmtRcvContext = XMTRCVCONTEXT_DELIMITER;
                }
            }
            else { // start preamble detection again
                m_ucRemPreambles = HART_MIN_PREAMBLES;
                m_RcvMsgStatus = HMSGSTATUS_BAD;
                m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
            }
            break;
        case XMTRCVCONTEXT_DELIMITER:
            {
                BOOL bTestedGood = TRUE;
                m_ucRcvdDelimiter = 0;
                ucRcvChar = m_ModemRcvBuffer.PopChar();
                // Preambles may not be complete even now. Take these out.
                if (ucRcvChar != HART_PREAMBLE_BYTE) {
                    m_ucRcvdDelimiter = ucRcvChar;

                    // Decode number of expansion bytes to ucRcvChar 
                    ucRcvChar = ((m_ucRcvdDelimiter & HART_EXPANSION_BYTE_MASK) >> HART_EXPANSION_BYTE_SHIFTS); 
                    if (ucRcvChar > 0) {
                        // Expansion bytes should be zero.
                        bTestedGood = FALSE;
                    }

                    // Check physical layer type set the status to bad if any of 
                    // the bit is set. Asynchronous physical layer value is zero.
                    if (m_ucRcvdDelimiter & HART_PHYSICAL_LAYER_MASK) {
                        bTestedGood = FALSE;
                    }

                    // Decode frame type to ucRcvChar
                    ucRcvChar = m_ucRcvdDelimiter & HART_FRAME_TYPE_MASK;
                    if ((bTestedGood == TRUE) && ((ucRcvChar == HART_FRAME_TYPE_ACK) ||
                         (ucRcvChar == HART_FRAME_TYPE_STX) || (ucRcvChar == HART_FRAME_TYPE_BACK))) {
                        // A valid delimiter is received
                        m_ucCheckSum = m_ucRcvdDelimiter; // Checksum starts here
                        if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                            (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                            // Since the AI and AO channels don't inherit from a common HART class,
                            // switch on the channel type to pull out the information we need.
                            switch (BOX->GetInitPntType(m_ucConnectedChannel))
                            {
                                case PNTTYPE_ANALOGINPUT:
                                
                                    AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = m_ucRcvdDelimiter;
                                    break;
                                    
                                case PNTTYPE_ANALOGOUTPUT:
                                
                                    AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = m_ucRcvdDelimiter;
                                    break;
                                    
                                default:
                                    // We should never get here...
                                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                    break;
                            }
#else
                            SLOT(m_ucConnectedChannel)->GetRcvBufObject() = m_ucRcvdDelimiter;
#endif
                        }
                        m_XmtRcvContext = XMTRCVCONTEXT_ADDRESS;
                    }
                    else { // If not a valid delimiter,
                        //  start preamble detection again
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                        m_XmtRcvContext = XMTRCVCONTEXT_UNKNOWN;
                        m_ucRemPreambles = HART_MIN_PREAMBLES;
                    }
                }
            }
            break;        
        case XMTRCVCONTEXT_ADDRESS:
            {
                BOOL bToMe = TRUE;
                HARTUNIQUEADDR unique;
                UINT8 ucPolAddr;

                // Start of message is successfully detected now.
                // Set the message status to good and decode rest of the message.
                m_RcvMsgStatus = HMSGSTATUS_GOOD;
                m_bBurstDeviceFound = FALSE; 

                // Validate the address in the response.
                if (m_ucRcvdDelimiter & HART_ADDR_TYPE_MASK) { 
                    // This response has unique address. Check whether entire 
                    // address is received or not.
                    if (m_ModemRcvBuffer.GetLength() < HART_LONGADDR_LENGTH) {
                        // Wait until full address is there in modem receive buffer.
                        return;
                    }

                    for (ucCount = 0; ucCount < HART_LONGADDR_LENGTH; ucCount++) {
                        unique.ucBytes[ucCount] = m_ModemRcvBuffer.PopChar();
                        m_ucCheckSum ^= unique.ucBytes[ucCount];
                        if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                            (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                            // Since the AI and AO channels don't inherit from a common HART class,
                            // switch on the channel type to pull out the information we need.
                            switch (BOX->GetInitPntType(m_ucConnectedChannel))
                            {
                                case PNTTYPE_ANALOGINPUT:
                                
                                    AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = unique.ucBytes[ucCount];
                                    break;
                                    
                                case PNTTYPE_ANALOGOUTPUT:
                                
                                    AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = unique.ucBytes[ucCount];
                                    break;
                                    
                                default:
                                    // We should never get here...
                                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                    break;
                            }                           
#else
                            SLOT(m_ucConnectedChannel)->GetRcvBufObject() = unique.ucBytes[ucCount];
#endif
                        }

                        if (ucCount == 0) {
                            if (HMODEMSTATE_RCVING == m_ModemState) {
                                if ((m_UniqueAddress.ucBytes[ucCount] & HART_MANUFACTURE_ID_MASK) != 
                                    (unique.ucBytes[ucCount] & HART_MANUFACTURE_ID_MASK)) {
                                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                                }
                            }
                            if (!(unique.ucBytes[ucCount] & HART_MASTER_ADDR_MASK)) {
                                bToMe = FALSE;
                            }
                            if (unique.ucBytes[ucCount] & HART_BURST_MODE_MASK) {
                                m_bBurstDeviceFound = TRUE;
                            }
                        }
                        else if (HMODEMSTATE_RCVING == m_ModemState) {
                            if (m_UniqueAddress.ucBytes[ucCount] != unique.ucBytes[ucCount]) {
                                m_RcvMsgStatus = HMSGSTATUS_BAD;
                            }
                        }
                    }
                }
                else { // polling address in the response
                    ucPolAddr = m_ModemRcvBuffer.PopChar();
                    m_ucCheckSum ^= ucPolAddr;
                    if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                        (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                        // Since the AI and AO channels don't inherit from a common HART class,
                        // switch on the channel type to pull out the information we need.
                        switch (BOX->GetInitPntType(m_ucConnectedChannel))
                        {
                            case PNTTYPE_ANALOGINPUT:
                            
                                AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucPolAddr;
                                break;
                                
                            case PNTTYPE_ANALOGOUTPUT:
                            
                                AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucPolAddr;
                                break;
                                
                            default:
                                // We should never get here...
                                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                break;
                        }                     
#else
                        SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucPolAddr;
#endif
                    }
                    if (HMODEMSTATE_RCVING == m_ModemState) {
                        if ((ucPolAddr & HART_MANUFACTURE_ID_MASK) != 
                            (m_ucPollingAddress & HART_MANUFACTURE_ID_MASK)) {
                            m_RcvMsgStatus = HMSGSTATUS_BAD;
                        }
                    }
                    if (!(ucPolAddr & HART_MASTER_ADDR_MASK)) {
                        bToMe = FALSE;
                    }
                    if (ucPolAddr & HART_BURST_MODE_MASK) {
                        m_bBurstDeviceFound = TRUE;
                    }
                }

                // Determine the frame type.
                switch (m_ucRcvdDelimiter & HART_FRAME_TYPE_MASK) {
                case HART_FRAME_TYPE_BACK:
                    m_bBurstDeviceFound = TRUE;
                    if (TRUE == bToMe) {
                        m_RcvMsgType = HMSGTYPE_BACKTOME;
                    }
                    else {
                        m_RcvMsgType = HMSGTYPE_BACKTOHIM;
                    }
                    break;
                case HART_FRAME_TYPE_STX:
                    if (TRUE == bToMe) {
                        m_RcvMsgType = HMSGTYPE_STXFROMME;
                    }
                    else {
                        m_RcvMsgType = HMSGTYPE_STX;
                    }
                    break;
                case HART_FRAME_TYPE_ACK:
                    if (TRUE == bToMe) {
                        m_RcvMsgType = HMSGTYPE_ACKTOME;
                    }
                    else {
                        m_RcvMsgType = HMSGTYPE_ACKTOHIM;
                    }
                    break;
                default:
                    // Invalidate receive message status and return. 
                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                    return;
                }

                // If delimiter is all fine, decode command field.
                m_XmtRcvContext = XMTRCVCONTEXT_COMMAND;
            }
            break;
        case XMTRCVCONTEXT_COMMAND:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (HMODEMSTATE_RCVING == m_ModemState) {
                if (m_ucXmtCommand != ucRcvChar) {
                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                }
            }

            m_ucCheckSum ^= ucRcvChar;
            if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }                
#else
                SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
            }
            m_XmtRcvContext = XMTRCVCONTEXT_BYTECOUNT;
            break;
        case XMTRCVCONTEXT_BYTECOUNT:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            if (HMODEMSTATE_RCVING == m_ModemState) {
                if (ucRcvChar < HART_MIN_RESPONSE_BYTECOUNT) {
                    m_RcvMsgStatus = HMSGSTATUS_BAD;
                }
#if defined(IOMTYPE_UIO)
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }           
#else
                SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
            }
            m_ucBytesInResponse = ucRcvChar + 1; // +1 to account for check byte
            m_ucCheckSum ^= ucRcvChar;
            if (HMSGTYPE_STX == m_RcvMsgType) {
                m_XmtRcvContext = XMTRCVCONTEXT_DATA;
            }
            else {
                m_XmtRcvContext = XMTRCVCONTEXT_STATUS;
            }
            break;
        case XMTRCVCONTEXT_STATUS:
            ucRcvChar = m_ModemRcvBuffer.PopChar();
            m_ucBytesInResponse--;
            if (m_ucBytesInResponse == 0) {
                m_RcvMsgStatus = HMSGSTATUS_BAD;
                return;
            }
            if (HMODEMSTATE_RCVING == m_ModemState) {
#if defined(IOMTYPE_UIO)
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }
#else
                SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
                if (ucRcvChar & HART_COMMN_STATUS_BIT) {
                    m_RcvMsgStatus = HMSGSTATUS_DEVICEERROR;
                }
            }            
            m_ucCheckSum ^= ucRcvChar;
            m_XmtRcvContext = XMTRCVCONTEXT_DATA;
            break;
        case XMTRCVCONTEXT_DATA:
            // m_RcvMsgType is already set and message is decoded upto 
            // byte count field Pending message length m_ucBytesInResponse
            // is also set now If m_ucBytesInResponse == 1 then verify the 
            // checksum. 
            if (m_ucBytesInResponse > 0)  {
                if (m_ucBytesInResponse > 1) {
                    ucRcvChar = m_ModemRcvBuffer.PopChar();
                    m_ucBytesInResponse--;
                    if (HMODEMSTATE_RCVING == m_ModemState) {
#if defined(IOMTYPE_UIO)
                        // Since the AI and AO channels don't inherit from a common HART class,
                        // switch on the channel type to pull out the information we need.
                        switch (BOX->GetInitPntType(m_ucConnectedChannel))
                        {
                            case PNTTYPE_ANALOGINPUT:
                            
                                AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            case PNTTYPE_ANALOGOUTPUT:
                            
                                AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            default:
                                // We should never get here...
                                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                break;
                        }
#else
                        SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
                    }
                    m_ucCheckSum ^= ucRcvChar;
                }
                else {    // this is the checkbyte. verify checksum
                    ucRcvChar = m_ModemRcvBuffer.PopChar();
                    m_ucBytesInResponse--;
                    if ((HCHANTYPE_PASSTHROUGH == ChanType) &&
                        (HMODEMSTATE_RCVING == m_ModemState)) {
#if defined(IOMTYPE_UIO)
                        // Since the AI and AO channels don't inherit from a common HART class,
                        // switch on the channel type to pull out the information we need.
                        switch (BOX->GetInitPntType(m_ucConnectedChannel))
                        {
                            case PNTTYPE_ANALOGINPUT:
                            
                                AIH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            case PNTTYPE_ANALOGOUTPUT:
                            
                                AOH_SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
                                break;
                                
                            default:
                                // We should never get here...
                                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                                break;
                        }
#else
                        SLOT(m_ucConnectedChannel)->GetRcvBufObject() = ucRcvChar;
#endif
                    }
                    if ((ucRcvChar != m_ucCheckSum)) {
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                    }

                    // At this point a message is completely processed.
                    // Break the while loop and return.
                    return;
                }
            }
            break;   
        default: 
            TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,7);
        }
    }
}
/*******************************************************************************
*                         clsHartModem::ActOnResponse                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
*    Post process the response message.                                        *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If STX is received, it means secondary master is there. Set modem to   *
*       SYNCWAIT with link quiet time to wait for ACK from device.             *
*    2. If ACK is received for a request just send, pass it to the client. If  *
*       the state is SYNCWAIT, setup link grant time to allow secondary master *
*       to start it transmission.                                              *
*    3. If an ACK or BACK to secondary master is received, start trasmission   *
*       of the request immediately.                                            *
*    4. If the device was found to be in burst mode, schedule command 109 to   *
*       turn off the burst mode.                                               *
* NOTES:                                                                       *
*    1. This method is called from ProcessResponse method when a good message  *
*       is completely received.                                                *
*******************************************************************************/
VOID clsHartModem::ActOnResponse(VOID) {
// AF: Review this function.  A lot is done with HART PST
    switch (m_RcvMsgType) {
    case HMSGTYPE_STX:
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }
        
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
#endif
        if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        else { // HMODEMSTATE_RCVING
            m_RcvMsgStatus = HMSGSTATUS_BAD;
            SetupRetry(HART_PRIMARY_QUIET_TIME);
        }
        break;
    case HMSGTYPE_ACKTOME:
        if (TRUE == m_bBurstDeviceFound) {
#if defined(IOMTYPE_UIO)
            // Since the AI and AO channels don't inherit from a common HART class,
            // switch on the channel type to pull out the information we need.
            switch (BOX->GetInitPntType(m_ucConnectedChannel))
            {
                case PNTTYPE_ANALOGINPUT:
                
                    AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    break;
                    
                case PNTTYPE_ANALOGOUTPUT:
                
                    AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    break;
                    
                default:
                    // We should never get here...
                    HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                    break;
            }
#else
            SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
#endif
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        else {
            if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                SetState(HMODEMSTATE_SYNCWAIT,HART_LINK_GRANT_TIME);
            }
            else { // HMODEMSTATE_RCVING
                // Good response. Submit the response to the client.
                
#if defined(IOMTYPE_UIO)
                HCHANTYPE ChanType;
                
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                    
                        ChanType = AIH_SLOT(m_ucConnectedChannel)->GetHartChanType();
                        break;
                        
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        ChanType = AOH_SLOT(m_ucConnectedChannel)->GetHartChanType();
                        break;
                        
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }  
#endif

                if ((m_ucRetryCount == 0) && (HARTCOMMAND_ZERO == m_ucXmtCommand)) {
                    // If command zero was successful in the last retry, reset the 
                    // polling address in DevDb so that command 6 will be not be issued.
#if defined(IOMTYPE_UIO)    
                    // Since the AI and AO channels don't inherit from a common HART class,
                    // switch on the channel type to pull out the information we need.
                    switch (BOX->GetInitPntType(m_ucConnectedChannel))
                    {
                        case PNTTYPE_ANALOGINPUT:
                        
                            AIH_SLOT(m_ucConnectedChannel)->SetPollingAddress(0);
                            break;
                            
                        case PNTTYPE_ANALOGOUTPUT:
                        
                            AOH_SLOT(m_ucConnectedChannel)->SetPollingAddress(0);
                            break;
                            
                        default:
                            // We should never get here...
                            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                            break;
                    }                
#else
                    SLOT(m_ucConnectedChannel)->SetPollingAddress(0);
#endif
                }

#if defined(IOMTYPE_UIO)
                HSYNCSTATUS receptionComplete = HSYNCSTATUS_UNKNOWN;
                
                // Since the AI and AO channels don't inherit from a common HART class,
                // switch on the channel type to pull out the information we need.
                switch (BOX->GetInitPntType(m_ucConnectedChannel))
                {
                    case PNTTYPE_ANALOGINPUT:
                        receptionComplete = 
                            AIH_SLOT(m_ucConnectedChannel)->ReceptionComplete(m_RcvMsgStatus);
                        break;
                    case PNTTYPE_ANALOGOUTPUT:
                    
                        receptionComplete =
                            AOH_SLOT(m_ucConnectedChannel)->ReceptionComplete(m_RcvMsgStatus);
                        break;
                    default:
                        // We should never get here...
                        HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                        break;
                }  
                
                if (HSYNCSTATUS_KEEP_SYNC == receptionComplete) {
                    // If Client wants stack to continue with a back-to-back message. 
                    ClearTxRxFIFOs();
                    SetState(HMODEMSTATE_SYNCWAIT,HART_LINK_GRANT_TIME);

                    // Since the AI and AO channels don't inherit from a common HART class,
                    // switch on the channel type to pull out the information we need.
                    switch (BOX->GetInitPntType(m_ucConnectedChannel))
                    {
                        case PNTTYPE_ANALOGINPUT:
                             m_ucRetryCount = AIH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                            break;
                        case PNTTYPE_ANALOGOUTPUT:                        
                             m_ucRetryCount = AOH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                            break;
                        default:
                            // We should never get here...
                            HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                            break;
                    }
#else
                if (HSYNCSTATUS_KEEP_SYNC == SLOT(m_ucConnectedChannel)->ReceptionComplete(m_RcvMsgStatus)) {
                    // If Client wants stack to continue with a back-to-back message. 
                    ClearTxRxFIFOs();
                    SetState(HMODEMSTATE_SYNCWAIT,HART_LINK_GRANT_TIME);
                    m_ucRetryCount = SLOT(m_ucConnectedChannel)->GetRetryCount();
#endif
                    if (m_ucRetryCount > HART_MAX_RETRIES) {
                        m_ucRetryCount = HART_MAX_RETRIES;
                    }
                }
                else 
                {                    
#if defined(IOMTYPE_UIO)
                    // Client does not have any new request. 
                    // Disconnect and check for any pass through requests.
                    
                    // Save the priority
                    UINT8 ucSaveExr = get_imask_exr();
                    
                    Disconnect(FALSE);
                    
                    // Check for previous transaction type
                    // If it was DYN or DEV or C48, check for FDM sessions
                    if(HCHANTYPE_CHANNEL == ChanType) 
                    {
                        if(BOX->PassthroughInQueue(m_ucModemNumber) != FALSE) 
                        {
                            // Search for Pass through and set up pass through request if present
                            BOX->SearchForPassthrough(m_ucModemNumber);
                        }
                    }
                    else 
                    {   
                        // If Previous Channel type was PST
                        if(BOX->bMultiplePSTPresent[m_ucModemNumber] == TRUE) 
                        {
                            // Search for other PST, do not calculate for back to back pst's count
                            // while performing multiple pst's
                            BOX->SearchForPassthrough(m_ucModemNumber, FALSE);
                            if(!BOX->usChannelsWithPST[m_ucModemNumber]) 
                            {
                                BOX->bMultiplePSTPresent[m_ucModemNumber] = FALSE;
                                // Channels with pst is made one so that, multiple pst present will not be
                                // set for one FDM session
                                BOX->usChannelsWithPST[m_ucModemNumber] = (UINT16)1;
                            }
                        }
                        else
                        {
                            BOX->usChannelsWithPST[m_ucModemNumber] = (UINT16)1;
                        }
                    }
                    // PST can be scheduled from two places, one after any channel disconnect (in HartStack.cpp)
                    // other when modem is idle (in Hart.cpp), Hart task in Hart.cpp has priority (5) and
                    // ActOnResponse function in HartStack.cpp (3), immediately after disconnect function if
                    // Hart task gets executed, then Hart task tries to schedule PST (because modem is idle after disconnect) 
                    // and after its execution ActOnResponse function also to tries to schedule PST, 
                    // to prevent this case, m_bHartStackProc variable is used to avoid Hart task from scheduling PST,
                    // its value is made true in Disconnect function and made false after PST scheduling by ActOnResponse
                    
                    // Temporarily raise priority to update m_bHartStackProc
                    set_imask_exr(LVLPRI_TICK);
                    m_bHartStackProc = FALSE;
                    
                    // Restore priority
                    set_imask_exr(ucSaveExr);
#else
                    // Client does not have any new request.
                    Disconnect();
#endif
                }
            }
        }
        break;
        
    case HMSGTYPE_ACKTOHIM:
#if defined(IOMTYPE_UIO) 
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                if (TRUE == m_bBurstDeviceFound) {
                    AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
                }
                else {
                    if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                        TransmitRequest();
                    }
                    else {
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                        SetupRetry(HSYNC_MINIMUM_TIME);
                    }
                }
                    
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
                if (TRUE == m_bBurstDeviceFound) {
                    AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
                    SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
                }
                else {
                    if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                        TransmitRequest();
                    }
                    else {
                        m_RcvMsgStatus = HMSGSTATUS_BAD;
                        SetupRetry(HSYNC_MINIMUM_TIME);
                    }
                }
                
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_SECMASTER);
        if (TRUE == m_bBurstDeviceFound) {
            SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
            SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        }
        else {
            if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
                TransmitRequest();
            }
            else {
                m_RcvMsgStatus = HMSGSTATUS_BAD;
                SetupRetry(HSYNC_MINIMUM_TIME);
            }
        }
#endif
        break;
    case HMSGTYPE_BACKTOHIM:
        // BACK to SecMaster just finished. We have the token now.
        // Note that the LogEvent will setup command 109 as the 
        // next command for this channel to turn off the burst mode.
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
#endif
        if (HMODEMSTATE_SYNCWAIT == m_ModemState) {
            TransmitRequest();
        }
        else {
            SetState(HMODEMSTATE_SYNCWAIT,HSYNC_MINIMUM_TIME);
        }
        break; 
    case HMSGTYPE_BACKTOME:
        // A BACK message to me just finished. The token is now with 
        // the secondary master even if it is present or not. Remain 
        // in sync with link quiet timer. 
        // Note that the LogEvent will setup command 109 as the 
        // next command for this channel to turn off the burst mode.
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_BURSTMODE);
#endif
        SetState(HMODEMSTATE_SYNCWAIT,HART_PRIMARY_QUIET_TIME);
        break;
    case HMSGTYPE_STXFROMME:
        // STXFROMME is totally unexpected. This means another primary 
        // master in the network. Log error and disconnect.
        m_RcvMsgStatus = HMSGSTATUS_BAD;
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_PRIMASTER);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_PRIMASTER);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_PRIMASTER);
#endif
        SetupRetry(HART_PRIMARY_QUIET_TIME);
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,8);
    }                
}
/*******************************************************************************
*                          clsHartModem::SetupRetry                            *
*                          ========================                            *
* PURPOSE:                                                                     *
*    Prepare the modem object for retrying the request.                        *
* ARGUMENTS:                                                                   *
*    1. a_ucWaitTime - wait time in in HART char interval before request is    *
*                      transmitted.                                            *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If retry count is greater than zero, setup for retry.                  *
*    2. If retry count is zero, notify the client with failed status.          *
* NOTES:                                                                       *
*    1. This method is called from the following methods - HandleReceiveError, *
*       ModemTimeout, ProcessResponse and ActOnResponse.                       *
*******************************************************************************/
VOID clsHartModem::SetupRetry(UINT8 a_ucWaitTime) {
    // Invalidate current receive message.
    m_RcvMsgStatus = HMSGSTATUS_BAD;
    // Flush the modem buffer.
    m_ModemRcvBuffer.Flush();

    if (m_ucRetryCount > 0) {
        m_ucRetryCount--;
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);          
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);                 
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        } 
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_RETRY);
#endif
        SetState(HMODEMSTATE_SYNCWAIT,a_ucWaitTime);
#if defined(IOMTYPE_UIO)

        // Factory Test support
        // Check for factory test in progress flag. if it is set, change the state to warning
        if(TRUE == HartLoopBkTestInProgress) 
        {
            BOX->SetLpBkStat(LOOPBACK_WARNING);
        }
#endif
    }
    else { 
        // Submit the reply with BAD status to the client.
#if defined(IOMTYPE_UIO)
        HSYNCSTATUS hStatus = HSYNCSTATUS_UNKNOWN;
        UINT8 retryCount = 0;
        
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:

                hStatus = AIH_SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD); 
                retryCount = AIH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                break;

            case PNTTYPE_ANALOGOUTPUT:
            
                hStatus = AOH_SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD);
                retryCount = AOH_SLOT(m_ucConnectedChannel)->GetRetryCount();
                break;

            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }
        
        if (HSYNCSTATUS_KEEP_SYNC == hStatus) {
            ClearTxRxFIFOs();
            SetState(HMODEMSTATE_SYNCWAIT,a_ucWaitTime);
            // Re-initialize retry count
            m_ucRetryCount = retryCount;
            if (m_ucRetryCount > HART_MAX_RETRIES) {
                m_ucRetryCount = HART_MAX_RETRIES;
            }
        }
        else {
            Disconnect();
        }
#else
        if (HSYNCSTATUS_KEEP_SYNC == SLOT(m_ucConnectedChannel)->ReceptionComplete(HMSGSTATUS_BAD)) {
            ClearTxRxFIFOs();
            SetState(HMODEMSTATE_SYNCWAIT,a_ucWaitTime);
            // Re-initialize retry count
            m_ucRetryCount = SLOT(m_ucConnectedChannel)->GetRetryCount();
            if (m_ucRetryCount > HART_MAX_RETRIES) {
                m_ucRetryCount = HART_MAX_RETRIES;
            }
        }
        else {
            Disconnect();
        }
#endif        
    }
}
/*******************************************************************************
*                       clsHartModem::HandleReceiveError                       *
*                       ================================                       *
* PURPOSE:                                                                     *
*    Decide what to do when a receive error is reported by the UART.           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* PROCESS:                                                                     *
*    1. If modem state is idle or bad, return.                                 *
*    2. If modem state is SYNCWAIT, reset the link timer.                      *
*    3. If modem state is RCVING, setup for retry.                             *
* NOTES:                                                                       *
*    1. This method is called from ModemInterrupts.                            *
*******************************************************************************/
VOID clsHartModem::HandleReceiveError(VOID) {
    switch (m_ModemState) {
    case HMODEMSTATE_BAD:
    case HMODEMSTATE_IDLE:
        return;
    case HMODEMSTATE_SYNCWAIT:
        // Acitivity in the channel while waiting to get in sync.
        // Reset m_ucModemTimer to LINK QUIET TIME and continue to wait.
        m_ModemRcvBuffer.Flush();
        m_ucModemTimer = HART_PRIMARY_QUIET_TIME;
        break;
    case HMODEMSTATE_RCVWAIT:
    case HMODEMSTATE_RCVING:
        // RCVERROR while getting a reply. Setup for retry.
#if defined(IOMTYPE_UIO)
        // Since the AI and AO channels don't inherit from a common HART class,
        // switch on the channel type to pull out the information we need.
        switch (BOX->GetInitPntType(m_ucConnectedChannel))
        {
            case PNTTYPE_ANALOGINPUT:
            
                AIH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
                break;
                
            case PNTTYPE_ANALOGOUTPUT:
            
                AOH_SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);               
                break;
                
            default:
                // We should never get here...
                HardFail(HF_BADPROGRAMJUMP,HARTSTACK_CPP,__LINE__);
                break;
        }         
#else
        SLOT(m_ucConnectedChannel)->LogEvent(HEVENTTYPE_COMMERROR);
#endif
        SetupRetry(HART_PRIMARY_QUIET_TIME);
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,bcDebug,9);
    }
}

