/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2011                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : uioversion.h                                                *
*    Description : Universal I/O firmware version declaration.                 *
*******************************************************************************/
#ifndef UIOVERSION_H
#define UIOVERSION_H
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#ifdef DEVELOPER_BUILD_OVERRIDE
const UINT8 VERSION_NUMBER  = VERSION;
const UINT8 REVISION_NUMBER = REVISION;
const UINT8 BUILD_NUMBER    = BUILD;
#else
const UINT8 VERSION_NUMBER  = 5;
const UINT8 REVISION_NUMBER = 0;
const UINT8 BUILD_NUMBER    = 8;
#endif

#endif