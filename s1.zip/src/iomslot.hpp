/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iomslot.hpp                                                 *
*    Description : Abstract base class clsIomSlot declaration.                 *
*******************************************************************************/
#ifndef __IOMSLOT_HPP__
#define __IOMSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "utils.h"
#include "datatype.h"
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern UINT16 ucIomDbMemory[];

#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))
#define PARAMID_PTEXECST    57
typedef enum DELAY_TYPE {
    NormalOutput                 = 0,
    CalibrationWithExtendedDelay = 1,
    CalibrationWithMinimumDelay  = 2
}DELAY_TYPE;

typedef enum tagPvValSt {
    PVVALST_BAD       =0,
    PVVALST_UNCERTN   =1,
    PVVALST_NORMAL    =2,
    PVVALST_MANUAL    =3
} PVVALST;

typedef enum tagPvSource {
    PVSOURCE_SUB     = 0,
    PVSOURCE_MANUAL  = 1,
    PVSOURCE_AUTO    = 2,
    PVSOURCE_TRACK   = 3
} PVSOURCE;

typedef enum tagPvSrcOpt {
    PVSRCOPT_ONLYAUTO = 0,
    PVSRCOPT_ALL      = 1
} PVSRCOPT;
#endif

#if defined(IOMTYPE_SP)
typedef enum tagSensrTyp {
    SENSRTYP_1to5_V     =0,
    SENSRTYP_0to5_V     =1,
    SENSRTYP_0to100_MV  =2,
    SENSRTYP_THERMCPL   =3,
    SENSRTYP_RTD        =4,
    SENSRTYP_P4TO2_V    =5,
    SENSRTYP_SLIDWIRE   =6,
    SENSRTYP_SLDWSRCE   =7,
    SENSRTYP_SPT_DP     =8,
    SENSRTYP_SPT_GP     =9,
    SENSRTYP_SPT_AP     =10,
    SENSRTYP_STT        =11,
    SENSRTYP_SFM        =12,
    SENSRTYP_SCM        =13,
    SENSRTYP_SGC        =14,
    SENSRTYP_SVP        =15,
    SENSRTYP_MTT        =16,
    SENSRTYP_STP        =17,
    SENSRTYP_SLV        =18,
    SENSRTYP_SDU        =19,
    SENSRTYP_GENERIC    =20,
    SENSRTYP_LVDT       =21,
    SENSRTYP_RVDT       =22
} SENSRTYP;
#endif

#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
typedef enum tagPntType {
    PNTTYPE_NOTCONFIGURED = 0,
    PNTTYPE_ANALOGINPUT   = 1,
    PNTTYPE_ANALOGOUTPUT  = 2,
    PNTTYPE_DIGITALINPUT  = 4,
    PNTTYPE_DIGITALOUTPUT = 5,
//The enumerations between 5 and 32 are used up in the file /db/src/IOLIM/pm_pnttype.enm.xml
    PNTTYPE_SVP =          32,
    PNTTYPE_SP  =          33
} PNTTYPE;

typedef enum tagPtExecSt {
    PTEXECST_INACTIVE = 0,
    PTEXECST_ACTIVE   = 1
} PTEXECST;

typedef enum tagAoLpbkSts {
    AOLPBK_PASSED,
    AOLPBK_HITESTFAIL,
    AOLPBK_LOTESTFAIL
} AOLPBKSTS;

const UINT16 MAXCURRENT_LOOPBACK_DACCOUNT = 0xF08;
const UINT16 MINCURRENT_LOOPBACK_DACCOUNT = 0x0ED;
const UINT16  FOUR_PRECENT_LOOPBACK_DACCOUNT= (MAXCURRENT_LOOPBACK_DACCOUNT - MINCURRENT_LOOPBACK_DACCOUNT) * 4 / 100;


#endif

/*******************************************************************************
*                                  clsIomSlot                                  *
*                                  ==========                                  *
*******************************************************************************/
class clsIomSlot {
protected:
    const UINT8 ChanNum;
    static DATABYTES Data;
    static UINT8 ScratchPad;
    static UINT8 WriteIndex;
    static UINT8 BoxChkpntVersion;
    static UINT8 SlotChkpntVersion;
    static PASTATUS ucSaveChkpntPaStatus;

    clsIomSlot(UINT8 a_ucSltNm) : ChanNum(a_ucSltNm) { WriteIndex = 0; }
    virtual ~clsIomSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,IOMSLOT_HPP,__LINE__); }

    virtual UINT8 *GetParamPtr(UINT8) = 0;
    virtual PASTATUS ExecutePreFunction(UINT8,UINT8 *, UINT8) = 0;
    virtual VOID ExecutePostFunction(UINT8,UINT8) = 0;
    inline  UINT8 GetWriteIndex(VOID) { return WriteIndex; }

#if !defined(IOMTYPE_UIO)
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SlotChkpntVersion;}
#endif
    inline VOID *GetBoxChkpntVersionPtr(VOID) {return &BoxChkpntVersion;}  

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,IOMSLOT_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,IOMSLOT_HPP,__LINE__); } 
    clsIomSlot(const clsIomSlot&); // Safeguard against default copy constructor
    clsIomSlot& operator=(const clsIomSlot&); // and default assignment.

public:
#if defined (IOMTYPE_UIO)
    virtual VOID ReadParamData(UINT8 *,UINT8);
    virtual VOID ReadParamData(UINT8 *,UINT8,UINT8);
    virtual PASTATUS WriteParamData(UINT8 *,UINT8,UINT8,BOOL a_bDoChkSm = TRUE);
    virtual PASTATUS WriteParamData(UINT8 *,UINT8,UINT8,UINT8);    
#else
    VOID ReadParamData(UINT8 *,UINT8);
    VOID ReadParamData(UINT8 *,UINT8,UINT8);
    PASTATUS WriteParamData(UINT8 *,UINT8,UINT8,BOOL a_bDoChkSm = TRUE);
    PASTATUS WriteParamData(UINT8 *,UINT8,UINT8,UINT8);    
#endif

    virtual BOOL GetIsDbChecksumed(UINT8) = 0;
    virtual DATATYPE GetDataType(UINT8) = 0;
    virtual ACCESSTYPE GetAccessType(UINT8) = 0;
    virtual UINT8 GetParamSize(UINT8) = 0;
    virtual ACCESSLOCK GetAccessLock(UINT8) = 0;
    virtual PASTATUS VerifyControlState(UINT8) = 0;
    virtual VOID *GetRedParamsPtr(VOID) = 0;
    virtual VOID *GetCheckPointPtr(UINT8 a_ucVer) = 0;
    virtual UINT8 GetCheckPointSize(UINT8 a_ucVer) = 0;
    
#if (defined(IOMTYPE_SP) || defined(IOMTYPE_SVP) || defined(IOMTYPE_UIO))
    virtual BOOL IsSlotSfToBeThrottled(UINT8,BOOL){return NULL;}
    virtual VOID CountDownSlotSfThrottle(VOID){};
    virtual UINT8 GetSlotSfBt(VOID){return NULL;}
    virtual VOID  SetSlotSfBt(UINT8){}
    virtual VOID  SetSlotSfLrs(UINT8){};
    virtual UINT8 GetSlotSfLrs(VOID){return NULL;}
    virtual UINT32 GetRedSlotDelta(VOID){return NULL;}
    virtual UINT32 GetRedSlotSize(VOID){return NULL;}
    virtual UINT8 *GetRedSlotPointer(VOID){return NULL;}
#endif

#if (defined(IOMTYPE_SP)||defined(IOMTYPE_SVP))

    PNTTYPE     PntType;
    PTEXECST    PtExecSt;
    PVSOURCE    PvSource;
    PVSRCOPT    PvSrcOpt;

    virtual UINT8 GetLatestSlotChkpntVersion(VOID) { return NULL; }
    inline VOID *GetPntTypePtr(VOID)    { return &PntType; }
    inline VOID *GetPtExecStPtr(VOID)   { return &PtExecSt; }
    inline VOID *GetPvSourcePtr(VOID)   { return &PvSource; }
    inline VOID *GetPvSrcOptPtr(VOID)   { return &PvSrcOpt; }

    virtual VOID InactivateSlot(VOID){};
    virtual VOID InitSlotDatabase(BOOL){};
    virtual BOOL RegenChannelEvents(VOID) { return TRUE; }

    virtual PASTATUS  GetDumpData(UINT8* const, const UINT8){return PA_OK;}
    virtual PASTATUS  StoreDumpData(UINT8* const){return PA_OK;}    
#endif
#if defined(IOMTYPE_SP)
    virtual UINT8 *GetParameterPtr(UINT8 a_ucParamNumber){ return GetParamPtr(a_ucParamNumber); }
#endif

#if defined(IOMTYPE_SVP)
    virtual VOID UpdateBadPv(VOID){};
    virtual VOID SetOpFinal(FLOAT32){};
    virtual VOID UpdateBadPvFl(BOOL ){};
    virtual VOID UpdateAiParamsFromDSC(void * , UINT8 ){};
    virtual VOID UpdateSvpRegCtlParamsFromDSC(void *, UINT8){};
    virtual VOID SetDiLastPv(BOOL ) {};
    virtual VOID SetDiBadPvfl(BOOL ){};
    virtual VOID SetDiPvAuto(ONOFF ){};
    virtual VOID SetDiPvRaw(ONOFF ){};
    virtual VOID AiDataFetch(VOID){};
    virtual VOID *GetSlotSfBtPtr(VOID){return NULL;}
    virtual VOID *GetSlotSfLrsPtr(VOID){return NULL;}
#endif
    VOID ComputeCheckSum(VOID);
    UINT16 ComputeRedCheckSum(VOID);

#ifdef DEBUG
    friend RETURNSTATUS ReadDb(VOID);
    friend RETURNSTATUS WriteDb(VOID);
    friend RETURNSTATUS GetPgrp(VOID);
#endif

#if defined (IOMTYPE_UIO)
    // define the UIO slot as a friend class
    // this allows the UIO slot to access protected functions on the configured channel objects
    friend class clsUioSlot;

    // define virtual functions, which are overridden by the configured channel classes
    virtual VOID InactivateSlot(VOID){};
    virtual UINT8 GetSlotChkPntParamId(VOID) = 0;
    virtual UINT8 GetPtExecStParamId(VOID) = 0; 
    virtual UINT8 GetLatestSlotChkPntVersion(VOID) = 0;   
#endif

#if !defined(IOPTYPE_SCIOM)
    // for redesign PMIO
    virtual VOID *GetPmioDumpParamPtr(VOID) = 0;
#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
    virtual VOID *GetPmioHartDumpParamPtr(VOID) = 0;
#endif
    virtual UINT8 IsCheckPointParam(UINT8 ucParamId) = 0;
    
    PASTATUS CheckpointRestoreCondition(VOID);
    VOID PmioCheckPointRestore(BOOL bForce = FALSE); // added Force param, to store the checkpoint data in xRAM
    VOID PmioDumpParam(UINT8 *pucDest);
    UINT16 PmioComputeChecksum(VOID);
#endif
};

#endif
