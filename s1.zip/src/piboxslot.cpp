/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2010                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : piboxslot.cpp                                               *
*    Description : Class clsPiBoxSlot definition.                              *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "tracelog.hpp"
#include "piboxslot.hpp"
#ifdef DEBUG
#include "debug.hpp"
#endif

/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/
extern clsIol Iol;
#ifdef DEBUG
extern BOOL    g_bIPIntProcessed;
extern BOOL    g_bFreqValTst;
extern UINT8   g_ucSlotInTest;
#endif
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/

#define _CompileAssert(_expr) typedef int __dummy[(_expr)];

BOOL clsPiBoxSlot::bPrototype = FALSE;
BOOL clsPiBoxSlot::Osc_Test_In_Progress = FALSE;

const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_PSFAIL,
    SF_FCO_DIAG_FAIL,
    SF_INPTFAIL,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN,
    SF_UNKNOWN
};

const UINT8 clsPiBoxSlot::CheckPointVer1[] = {
    PARAMID_BOXCHKPNTVER,
    PARAMID_DBVALID,
    PARAMID_MODSTAT1,
    PARAMID_MAINTAINONFAULT,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsPiBoxSlot::CheckPointVerTable[LATEST_BOXCHKPNT_VERSION] = {
    { CheckPointVer1, 4 }
};


UINT8 clsPiBoxSlot::BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;

const UINT8 clsPiBoxSlot::RedParams[] = {
    PARAMID_DBVALID,
    PARAMID_IOLDEVTYPE,
    PARAMID_MODLTYPE,
    PARAMID_MAXSLOTS,
    0 // Terminator
};

const BOXPARAMINFO clsPiBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      // 35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   // 37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          // 38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          // 39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          // 40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          // 41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          // 43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      // 44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    // 45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           // 47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       // 48 AppBuildNo
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 50
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       // 51 BoxSfBits
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        // 52 BoxSfLrs
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       // 53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          // 54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         // 55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              // 56 Dpa
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              // 57 Dsa
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      // 58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      // 59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               // 60 Ba
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                // 61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         // 62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        // 63 HwRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,TRUE,                        // 64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          // 65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            // 66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,PreModStat1,PostModStat1,GetModStat1Ptr,TRUE,    // 67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         // 68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,TRUE,                           // 69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              // 70 NthExt
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 71
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     // 72 SwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 73
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     // 74 TstFunct
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        // 75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          // 76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,PostRedData,GetRedDataPtr,FALSE,      // 77 RedData
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           // 78 DbValid
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,PostSfActionTbl,GetSfActionTblPtr,FALSE,      // 79 SfActionTbl
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 80
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 81
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 82 Freq6050
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 101
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 102
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 103
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 104
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 105 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 106 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 114
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 115
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                         // 116 MaxSlots
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 142
    DT_BLIND,4,AT_PSET,ALCK_VIEW,PreCheckPoint,0,GetCheckPointPtr,TRUE,             // 143 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 157
    DT_BLIND,18,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                        // 158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     // 160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostStatReset,GetStatResetPtr,FALSE,  // 161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       // 165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     // 166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      // 167 Tracelevel
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 195
    DT_UINT8,1,AT_SBYTE,ALCK_OPER,PreConfProvSig,PostConfProvSig,GetConfProvSigPtr,TRUE, // 196 ConfigProvSig
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetActualProvSigPtr,FALSE,                    // 197 ActualProvSig
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,PreMaintOnFault,PostMaintOnFault,GetMaintOnFaultPtr,TRUE, // 198 MaintainOnFault
    DT_BLIND,176,AT_MBYTE,ALCK_VIEW,0,0,GetPvScanRec1Ptr,FALSE,                     // 199 PvScanRec1
    DT_BLIND,88,AT_MBYTE,ALCK_VIEW,0,0,GetPvScanRec2Ptr,FALSE,                      // 200 PvScanRec2
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 242
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         // 255
};
/*******************************************************************************
*                           clsPiBoxSlot::clsPiBoxSlot                         *
*                           ==========================                         *
* PURPOSE:    Constructor                                                      *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsPiBoxSlot::clsPiBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType, MAXSLOTS) 
{
    // ensure correct size of the PvScanRec structures
    _CompileAssert(sizeof(PvScanRec1) == 176); // size from tblParamInfo[199]
    _CompileAssert(sizeof(PvScanRec2) == 88);  // size from tblParamInfo[200]

    // Initialize database parameters.
    for (UINT8 ucChanNum = 1; ucChanNum <= MAXSLOTS; ucChanNum++) {
        InitializePvScanRec(ucChanNum);
    }   

    ucGoodChannels    = 0xFF;     // all channels are good on startup
    ucTickCounter     = 0x00;     // initialize the tick counter
    MaintainOnFault   = OFF;      // initialize MAINTAINONFAULT
    bDisableFO        = FALSE;    // Disable failover flag for FCO diagnostics

    SetProverSignal(TRUE);        // deselect all for prover signal
    SetForceSafe(FORCEDSAFE_OFF); // deassert FORCED SAFE control

    HwInfo.ProductType = PRODTYPE_PI;
    HwInfo.ProductCode = PRODCODE_PI;

    bPrototype = (HwInfo.HwRevLetter == 0) && (HwInfo.HwRevNumber == 0);

    // Configure IRQ3 for FPGA Interrupts
    IRQ3_SENSECTL = IRQ_SC_LOW; 
    IPRI_FPGA     = LVLPRI_TICK;
    IRQ3_STATUS   = DISABLE;
    IRQ3_ENABLE   = ENABLE;

    for (UINT8 ucCount = 75; ucCount > 0; ucCount--) IdleWait(20000);
    while (!SwitchInit());
}
/*******************************************************************************
*                          clsPiBoxSlot::GetDataType                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsPiBoxSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsPiBoxSlot::GetAccessType                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsPiBoxSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                          clsPiBoxSlot::GetParamSize                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsPiBoxSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                          clsPiBoxSlot::GetParamPtr                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsPiBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                         clsPiBoxSlot::GetAccessLock                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsPiBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                    clsPiBoxSlot::GetIsDbChecksumed                           *
*                    ===============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsPiBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                        clsPiBoxSlot::VerifyControlState                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiBoxSlot::VerifyControlState(UINT8) {
    return PA_OK;
}
/*******************************************************************************
*                        clsPiBoxSlot::ExecutePreFunction                      *
*                        ================================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                           UINT8 *a_Buffer,
                                           UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsPiBoxSlot::ExecutePostFunction                     *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                            UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
} 
/*******************************************************************************
*                         clsPiBoxSlot::PreCheckPoint                          *
*                         ============================                         *
*******************************************************************************/
PASTATUS clsPiBoxSlot::PreCheckPoint(UINT8 *,UINT8)
{
    DbValid = DB_INVALID;
    BoxChkpntVersion = LATEST_BOXCHKPNT_VERSION;
    return PA_OK;
}
/*******************************************************************************
*                        clsPiBoxSlot::PreConfProvSig                          *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiBoxSlot::PreConfProvSig(UINT8 *a_Writebuffer,UINT8)
{
   UINT8 ucNewVal = *(UINT8 *) a_Writebuffer;
   PASTATUS RetVal = PA_OK;

   switch(ucNewVal){
      case 0:
         break;
      case 1:
      case 3:
      case 5:
      case 7:
         if(SLOT(ucNewVal)->GetInputStream() != DUAL_PULSE)
             RetVal = DO_CONFIGURATION_MISMATCH_ERROR;
         break;
      default:
         RetVal = DO_ILLEGAL_VALUE;
         break;
   }
   return RetVal;
}
/*******************************************************************************
*                        clsPiBoxSlot::PostConfProvSig                         *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::PostConfProvSig(UINT8)
{
    SetProverSignal(FALSE);
}
/*******************************************************************************
*                        clsPiBoxSlot::PreMaintOnFault                         *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiBoxSlot::PreMaintOnFault(UINT8 *,UINT8)
{
   return PA_OK;
}
/*******************************************************************************
*                        clsPiBoxSlot::PostMaintOnFault                        *
*                        =================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::PostMaintOnFault(UINT8)
{
}
/*******************************************************************************
*                         clsPiBoxSlot::AppInitialization                      *
*                         ===============================                      *
* PURPOSE: Start up isolated power supplies one at a time                      *
*          Clear all FPGA counters and timers                                  *
* ARGUMENTS: None                                                              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::AppInitialization(VOID)
{

UINT8    i,j,k,ucCnt,ucEnable=0x00,ucStatusTest=0x01;
UINT16    uiTestWord;
UINT32    ulTestValue;

// HW team will use the debug image to test only kernel board(without App board connected).
// Without App board connected isolated power supply diagnostics will fail. To avoid this 
// below code is excluded for debug image.
#if !defined(DEBUG)

    // <POST T001>

    // Hardfail if all are not disabled and OFF
    if (PSCSR.FPGAWORDREG != 0xFF00) HardFail(HF_PSISOPUFAIL,PIBOXSLOT_CPP,__LINE__);
    // Enable one power supply at a time, waitng up to 300ms in between, and checking
    // status after each one is enabled
    for (ucCnt=0; ucCnt<MAXSLOTS; ucCnt++) {
        ucEnable <<= 1;                      // update enable byte to include next power supply
        ucEnable |= 0x01;      
        ISOCHNENB = ucEnable;                // enable next power supply
        // Wait up to 300ms for correct status, checking every 50ms
        i = 0;
        do {
            i++;
            IdleWait(20000); // wait 20ms
            IdleWait(20000); // wait 20ms
            IdleWait(10000); // wait 10ms
            if ((ISOCHNGOOD & ucStatusTest) == 0) i = 6;
        } while (i < 6);
        // Softfail if all are not enabled that should be after each one is turned on
        if ((ISOCHNGOOD & ucStatusTest) != 0) {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_PSFAIL,TRUE,ucCnt+1);
        }
        ucStatusTest <<= 1;                      // update test mask for next power supply
        IdleWait(1);
    }
#endif // !DEBUG

    UINT8 ucSaveExr = get_imask_exr();

    // <POST T002> Check FPGA IRQ

    set_imask_exr(LVLPRI_HIGHEST);         // disable all interrupts
    if (FPGA_IRQ == ASSERTED_n) HardFail(HF_FPGAIRQFAIL,PIBOXSLOT_CPP,__LINE__);
    IRQ_DIAG_CTRL = ASSERTED;
    if (FPGA_IRQ == DEASSERTED_n) HardFail(HF_FPGAIRQFAIL,PIBOXSLOT_CPP,__LINE__);
    IRQ_DIAG_CTRL = DEASSERTED;
    if (FPGA_IRQ == ASSERTED_n) HardFail(HF_FPGAIRQFAIL,PIBOXSLOT_CPP,__LINE__);
    set_imask_exr(ucSaveExr);              // Allow a pending interrupt to execute

    // <POST T005> Check Data Bus
    if (SCRATCHPADREG != DEFAULT_TEST_PATTERN) HardFail(HF_TCDATABUSERROR, PIBOXSLOT_CPP, __LINE__);
    uiTestWord = 0x0001;
    for (i=0; i<16; i++) {
        SCRATCHPADREG = uiTestWord;
        if (SCRATCHPADREG != uiTestWord) HardFail(HF_TCDATABUSERROR, PIBOXSLOT_CPP, __LINE__);
        uiTestWord <<= 1;
    }
    SCRATCHPADREG = DEFAULT_TEST_PATTERN;

    // <POST T006> Check Counters

    DCCR.FPGAWORDREG = 0x0400;
    // Clear all counters
    CCCR.FPGAWORDREG = 0xFFFF;
    CCCR.FPGAWORDREG = 0;
    // Hard fail if any counter did not clear
    for (i=0;i<MAXSLOTS;i++) {
        if (fpgaCOUNTER[i] != 0) HardFail(HF_COUNTERFAIL, PIBOXSLOT_CPP, __LINE__);
    }
    ulTestValue = 0x00010001;
    for (i=0;i<15;i++) {
        for (j=0;j<MAXSLOTS;j++) {
            fpgaCTR_UPDATE[j] = ulTestValue;       // Load counter(j) with test value
            COUNT_UPDATE_FLAGS = 0xFF;             // Set Update Valid Flags
            if (fpgaCOUNTER[j] != ulTestValue) HardFail(HF_COUNTERFAIL, PIBOXSLOT_CPP, __LINE__);
            DCCR.FPGAWORDREG = 0x0403;             // Increment all counters
            DCCR.FPGAWORDREG = 0x0400;
            IdleWait(2);                           // Wait 2 microsecs
            // Hard fail if any counter did not increment
            for (k=0;k<MAXSLOTS;k++) {
                if ((j==k) && (fpgaCOUNTER[k] != (ulTestValue + 65537))) HardFail(HF_COUNTERFAIL, PIBOXSLOT_CPP, __LINE__);
                //if ((j!=k) && (fpgaCOUNTER[k] != 65537)) HardFail(HF_COUNTERFAIL, PIBOXSLOT_CPP, __LINE__);
            }
            COUNT_UPDATE_FLAGS = 0x00;             // Clear Update Valid Flags
            uiTestWord = 0x0001;
            // Hard fail if any counter does not clear when commanded to
            for (k=0;k<MAXSLOTS;k++) {
                CCCR.FPGAWORDREG = uiTestWord;
                CCCR.FPGAWORDREG = 0;
                if (fpgaCOUNTER[k] != 0) HardFail(HF_COUNTERFAIL, PIBOXSLOT_CPP, __LINE__);
                uiTestWord <<= 1;
            }
        }
        ulTestValue = (ulTestValue << 1) + 0x00010001; // Update test value
    }
    DCCR.FPGAWORDREG = 0x0000;

    // Only execute the following two tests if this module does NOT have prototype boards
    if (!bPrototype) {

        // <POST T003> Check P4.6

        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);     // disable all interrupts
        FPGA_IRQCR      = 0x0040;    // enable BAD DECODE interrupts from FPGA
        DCCR.FPGAWORDREG = 0x2000; // Arm the address bus test
        // Post a failure if either the bad decode signal or the FPGA IRQ is asserted
        if (BAD_DECODE == ASSERTED || FPGA_IRQ == ASSERTED_n) AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,TRUE,0);
        i = INVALID_LOCATION;      // Read an invalid location
        // Post a failure if either the bad decode signal or the FPGA IRQ is not asserted
        if (BAD_DECODE == DEASSERTED || FPGA_IRQ == DEASSERTED_n) AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,TRUE,0);
        DCCR.FPGAWORDREG = 0x3000; // Clear the address bus test results
        DCCR.FPGAWORDREG = 0x2000; 
        IRQ3_STATUS = DISABLE;     // Clear the FPGA interrupt flag in the H8
        // The FPGA IRQ handler will be called if the FPGA IRQ is still asserted
        set_imask_exr(ucSaveExr);          // Allow a pending interrupt to execute

        // <POST T004> Check Address Bus

        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);     // disable all interrupts
        i = FPGA_REVLETTER;        // Read a valid locaton
        // The FPGA IRQ handler will be called if a bad decode occurs
        set_imask_exr(ucSaveExr);          // Restore interrupt level

        FPGA_IRQCR    = 0xFFC0;    // enable IP, Oscillator fail, and BAD DECODE interrupts from FPGA
        DCCR.FPGAWORDREG = 0xA000; // start the oscillator diagnostic in FPGA with address bus test armed
    }
    else {
        // Configure FPGA Interrupt Control Register and Diagnostic Counter Control Register
        FPGA_IRQCR    = 0xFF80;    // enable IP and Oscillator fail interrupts from FPGA
        DCCR.FPGAWORDREG = 0x8000; // start the oscillator diagnostic in FPGA
    }

    if(CheckForFactoryTestMode())
        SetForceSafe(FORCEDSAFE_OFF);

}

/*******************************************************************************
*                         clsPiBoxSlot::AppStcProcessing                       *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
VOID clsPiBoxSlot::AppStcProcessing(VOID) {   
    UINT8 i;
    UINT8 ucBitMask = 0x01;
    UINT8 ucSaveExr,ucSample;
    UINT32 ulValue,ulBadValue;
    FLOAT32 ufAv;

    // Decrement the tick counter
    // If it rolls over, set to preset value 
    ucTickCounter -= 1;
    if (ucTickCounter == 255) ucTickCounter = 99;
    
    // Hardfail the module if FPGA CRC check fails
    if(FPGA_INIT_n == 0) HardFail(HF_FPGARDBKFAIL, PIBOXSLOT_CPP, __LINE__);

    // For each channel, check
    // <T001> Status of Isolated Power Supplies and
    // <T002> Input Voltage Threshold setting (dependant on bPrototype)
    // These diagnostics are executed on the backup module only when synchronized

    if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) {
        for (i = 0, ucBitMask = 0x01; i < MAXSLOTS; i++, ucBitMask <<= 1) {
            if ((ISOCHNGOOD & ucBitMask) != 0) {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_PSFAIL,TRUE,i+1);
                ucGoodChannels &= ~ucBitMask; // mark this channel bad
            }
            else {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_PSFAIL,FALSE,i+1);
                ucGoodChannels |= ucBitMask;  // mark this channel good
            }
            // This diagnostic requires a rev A app board
            // It is not executed on prototype hardware
            if (!bPrototype) {
                ucSample = (UINT8)((ITTCR.FPGAWORDREG ^ HLVTSR.FPGAWORDREG) & 0x00FF);
                if ((ucSample & ucBitMask) != 0) {
                    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_INPTFAIL,TRUE,i+1);
                    ucGoodChannels &= ~ucBitMask; // mark this channel bad
                }
            }
        }
    }

    // <T003> Do SO Readback Diagnostic for Channels 7 and 8

    bDisableFO = FALSE;
    for(UINT8 ucChan = FASTCUTOFF_CHN0;ucChan <= FASTCUTOFF_CHN1; ucChan++) {
        if(SLOT(ucChan)->GetPulseInType() == PULSEINPUT_FC) {
            FCORDBKSTS bFcoDiagStatus = FCORDBK_PASSED;
            if((SLOT(ucChan)->GetPtExecSt() == PTEXECST_ACTIVE) &&
                (MODSTATUS_RUN == ModStat1.Status)) {
                 bFcoDiagStatus = FCODriverReadBackDiagnostic(ucChan);
            }
   
            // Post the softfailure if any is needed
            if(bFcoDiagStatus == FCORDBK_PASSED) {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FCO_DIAG_FAIL,FALSE,ucChan);
            }
            else {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FCO_DIAG_FAIL,TRUE,ucChan);
                bDisableFO = TRUE;
            }
        }
    }

    // Enable the failover only when the SO readback test is passed at least once
    // for fast cutoff channels 7 and 8.
    if ((REDSTATE_SYNCD == GetRedState()) && (Iol.AmPrimary()) && (bDisableFO == FALSE)) {
            EnableFCOFailFO();
    }

    // <T004p> Challenge the oscillator diagnostic once every second
    
    //if (ucTickCounter == 0) {
        // Set Osc_Test_In_Progress and Osc_diag_test
        //if (!bPrototype) DCCR.FPGAWORDREG = 0xE000;  
        //else DCCR.FPGAWORDREG = 0xC000;
        //Osc_Test_In_Progress = TRUE;
        //i = 255;
        //do {
            //if (Osc_Test_In_Progress == FALSE) continue;
            //i--;
        //} while (i > 0);
        //if (i == 0) AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OSCDIAG_FAIL,TRUE,0);
    //}

    // <T005> Check Data Bus

    if (SCRATCHPADREG != DEFAULT_TEST_PATTERN) HardFail(HF_TCDATABUSERROR, PIBOXSLOT_CPP, __LINE__);
    UINT16 uiTestWord = 0x0001;
    for (i=0; i<16; i++) {
        SCRATCHPADREG = uiTestWord;
        if (SCRATCHPADREG != uiTestWord) HardFail(HF_TCDATABUSERROR, PIBOXSLOT_CPP, __LINE__);
        uiTestWord <<= 1;
    }
    SCRATCHPADREG = DEFAULT_TEST_PATTERN;

    // Process redundancy inputs and state
    ManageRedIO();

    if (CheckRedData(REDDATA_REDCFG) || (!ModStat3.OutCtl && Iol.AmPrimary())) {
        CheckFailOverCondition();
    }

    // Inhibit Counter/Timer processing and FCO status update on backup module
    // during db synchronization
    if (!Iol.AmPrimary() && REDSTATE_SYNCD != BOX->GetRedState()) return;

    // Process AVs, AVRAWs, and PLs
    for (i = 0, ucBitMask = 0x01; i < MAXSLOTS; i++, ucBitMask <<= 1) {
        // If channel is good process it
        if ((ucGoodChannels & ucBitMask) != 0){
            ulBadValue = 0;
            if ((BOX->ModStat1.Status == MODSTATUS_RUN) &&
                (SLOT(i+1)->GetPtExecSt() == PTEXECST_ACTIVE)) {
                // Get AvRaw and BadAvRaw and store them
                ulValue = BOX->GetCounter(i+1);
                if (i < (MAXSLOTS - 1)) ulBadValue = BOX->GetCounter(i+2);
                StoreAvRaw(i+1, ulValue);
                StoreAvRawSts(i+1, STATUS_NORMAL);
            }
            else {
                StoreAvRaw(i+1, 0);
                StoreAvRawSts(i+1, STATUS_BAD);
            }
            if ((SLOT(i+1)->GetPtExecSt() == PTEXECST_ACTIVE) && (BOX->ModStat1.Status == MODSTATUS_RUN)){
                // Compute Av and store it
                ufAv = (SLOT(i+1)->GetC1() / (SLOT(i+1)->GetC2()) * (FLOAT32)ulValue);
                StoreAv(i+1, ufAv);
                StoreAvSts(i+1, STATUS_NORMAL);

                // Get PL, scale it, and store it if it is valid
                ulValue = BOX->GetTimer(i+1);
                StorePl(i+1, SLOT(i+1)->GetC3() * ((FLOAT32)ulValue/10.0));
                StorePlSts(i+1, STATUS_NORMAL);
            }
            else {
                StoreAv(i+1, NaN);
                StoreAvSts(i+1, STATUS_BAD);
                StorePl(i+1, NaN);
                StorePlSts(i+1, STATUS_BAD);
            }

            // If this channel is Dual Pulse, update BadAvRaw and skip next channel
            if(SLOT(i+1)->GetInputStream() == DUAL_PULSE) {
                SLOT(i+1)->StoreBadAvRaw(ulBadValue);
                ucBitMask <<= 1;
                i++;
            }
            else SLOT(i+1)->StoreBadAvRaw(0);
        }
        else {
            StoreAvRaw(i+1, 0);
            StoreAvRawSts(i+1, STATUS_BAD);
            ulBadValue = 0;
            StoreAv(i+1, NaN);
            StoreAvSts(i+1, STATUS_BAD);
            StorePl(i+1, NaN);
            StorePlSts(i+1, STATUS_BAD);
            if(SLOT(i+1)->GetInputStream() == DUAL_PULSE) {
                SLOT(i+1)->StoreBadAvRaw(0);
                ucBitMask <<= 1;
                i++;
            }
        }
    }

    // Collect and store prover status, SOs, and TvProcs
    switch(CHANNEL_SELECT){
        case 0:
            ucActualProvSig = 0;
            break;
        case 0x10:
            ucActualProvSig = 1;
            break;
        case 0x20:
            ucActualProvSig = 3;
            break;
        case 0x40:
            ucActualProvSig = 5;
            break;
        case 0x80:
            ucActualProvSig = 7;
            break;
    }
    
    StoreSo(FASTCUTOFF_CHN0, STATUSOUT0);
    StoreSo(FASTCUTOFF_CHN1, STATUSOUT1);
    StoreTvProc(FASTCUTOFF_CHN0, COMPARING0);
    StoreTvProc(FASTCUTOFF_CHN1, COMPARING1);
    if (SLOT(FASTCUTOFF_CHN0)->GetPtExecSt() == PTEXECST_ACTIVE) StoreBadSo(FASTCUTOFF_CHN0, OFF);
    else StoreBadSo(FASTCUTOFF_CHN0, ON);
    if (SLOT(FASTCUTOFF_CHN1)->GetPtExecSt() == PTEXECST_ACTIVE) StoreBadSo(FASTCUTOFF_CHN1, OFF);
    else StoreBadSo(FASTCUTOFF_CHN1, ON);

}
/*******************************************************************************
*                       clsPiBoxSlot::FpgaInterruptHandler                     *
*                       ==================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:            *
*                                                                              *
*******************************************************************************/
VOID clsPiBoxSlot::FpgaInterruptHandler(VOID)  {
    // <T004i> Process 10 MHz oscillator failure
    if (FPGA_INTFL_OSCFAIL) //{
        //if (OSC_FFAULT) {
            // Clear Osc_diag_test (terminates test and resets FPGA_INTFL_OSCFAIL)
            // Pulse Osc_test_clr (resets OSC_FFAULT)
		    //if (!bPrototype) {
		        //DCCR.FPGAWORDREG = 0xA800;
		        //DCCR.FPGAWORDREG = 0xA000;
		    //}
		    //else {
		        //DCCR.FPGAWORDREG = 0x8800;
		        //DCCR.FPGAWORDREG = 0x8000;
		    //}
            //Osc_Test_In_Progress = FALSE;
        //}
        /*else*/ HardFail (HF_OSCFAIL, PIBOXSLOT_CPP, __LINE__);

    // <T006> Process BAD DECODE interrupt
    if (FPGA_INTFL_BDECODE) HardFail(HF_RAMADDRERROR, PIBOXSLOT_CPP, __LINE__);
        
    // Process all pending IP interrupts
    UINT8 ucSlotsToProcess = FPGA_INTFL_IP;
    if (ucSlotsToProcess != 0){
        UINT8 ucSelect = 0x01;
        for (UINT8 n = 1; n <= MAXSLOTS; n++){
            if (ucSlotsToProcess & ucSelect) SLOT(n)->ProcessSlotIntegration();
            ucSelect <<= 1;
        }
    }
    IRQ3_STATUS = DISABLE; // Clear the interrupt flag

#ifdef DEBUG
   if(g_bFreqValTst){
      // Read Counter Values
      INT_COUNTER2[g_ucSlotInTest] = fpgaPV_COUNTER[g_ucSlotInTest];
      // Read FRC Vaalues
      INT_FRC2[g_ucSlotInTest]     = fpgaFRC[g_ucSlotInTest];
  
      g_bIPIntProcessed = TRUE;
   }
#endif

}
/*******************************************************************************
*                     clsPiBoxSlot::EnableSwitchDiagnostics                    *
*                     =====================================                    *
* PURPOSE:  This is a diganostics for EN_SW (Enable Switch).                   *
*           First check whether EN_SW is in ON state. Then check whether       *
*           EN_SW is in OFF state. Finally check whether the EN_SW is is in    *
*           ON state. This diagnostic routine is called when the module        *
*           is acting as the backup module                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::EnableSwitchDiagnostics(VOID){
    EnableSwitchCheck(SW_ON);
    EN_SW = SW_OFF;     // Push EN_SW to OFF state.
    EnableSwitchCheck(SW_OFF);
    EN_SW = SW_ON;     // Push EN_SW to ON state.
    EnableSwitchCheck(SW_ON);
}
/*******************************************************************************
*                     clsPiBoxSlot::EnableSwitchCheck                          *
*                     ===============================                          *
* PURPOSE:  This is a Enable Switch check used as a part of EN_SW diagnostics. *
*           This checks EN_SW switch state against the provided state of the   *
*           same switch. Try reading the EN_SW switch 2 times. If error exists *
*           after retries, then write the same value to the switch and try     *
*           reading the switch. If read fails after 2 times of retries, then   *
*           HardFail the module.                                               *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::EnableSwitchCheck(BOOL a_SwitchState){
    UINT8 ucCountOuter,ucCountInner;

    for (ucCountOuter=3; ucCountOuter>0; ucCountOuter--) {
        for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
            if (a_SwitchState == EN_SW) return;
            IdleWait(10);
        }
        // If read fails, force EN_SW to desired state
        EN_SW = a_SwitchState;
    }
    // If the check fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL,PIBOXSLOT_CPP,__LINE__);
}
/*******************************************************************************
*                    clsPiBoxSlot::InhibitSwitchDiagnostics                    *
*                    ======================================                    *
* PURPOSE:  This is a diagnostics routine to check the status of INH_SW1 and   *
*           INH_SW2 switches. This is used as a part of the switch diagnostic. *
*           If the module is acting as the primary, check whether the EN_SW is *
*           in ON state. then check TST_SW is in OFF state. then check both    *
*           the INH_SW1 and INH_SW2 are in ON state.                           *
*           If the module is acting as the backup module, then do the EN_SW    *
*           diagnostic then check that both INH_SW1 and INH_SW2 are in OFF     *
*           state. Next try checking correct functioning of INH_SW1 and        *
*           INH_SW2 switches. Make sure that when module is secondary, both    *
*           of these switches should not be ON at the same time.               *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::InhibitSwitchDiagnostics(VOID){
    BOOL    bInhFaulted = FALSE;
    // if module is primary, check EN_SW is ON, check TST_SW is OFF,
    // and check both the INH_SW switches are ON.
    if (OUTCTL_MINE == ModStat3.OutCtl) {
        // Check whether EN_SW is ON
        EnableSwitchCheck(SW_ON);
        // Check whether TST_SW is OFF
        TestSwitchCheck(SW_OFF);
        // Check whether INH_SW switches are ON
        InhibitSwitchCheck(INH_ON_ON);
    }// end of primary 
    else { // the module is secondary
        // Do EN_SW diagnostics.
        EnableSwitchDiagnostics();
        // Make sure both INH_SW switches are OFF
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_OFF);
        // Turn ON the TST_SW
        SetTestSwitch(SW_ON);
        // Change the INH_SW1 to ON and keep INH_SW2 at OFF.
        INH_SW1 = SW_ON;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_ON_OFF);

        // Change the INH_SW1 to OFF.
        INH_SW1 = SW_OFF;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_OFF);
        // Turn OFF the TST_SW
        SetTestSwitch(SW_OFF);
        IdleWait(150);
        // Change the INH_SW2 to ON and keep INH_SW1 at OFF.
        INH_SW2 = SW_ON;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_ON);
        
        // Change the INH_SW2 to OFF.
        INH_SW2 = SW_OFF;
        // Give delay if required shiva
        bInhFaulted |= InhibitSwitchCheck(INH_OFF_OFF);

        // If INHOUT_n is faulted post the SF
        if(bInhFaulted) BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,TRUE,0);
    }
}
/*******************************************************************************
*                      clsPiBoxSlot::InhibitSwitchCheck                        *
*                      ================================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsPiBoxSlot::InhibitSwitchCheck(UINT8 a_ucSwitchState) {
    UINT8 ucCountOuter,ucCountInner,ucFeedback;

    for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
        if (a_ucSwitchState == InhibitSwitchStatus()) return FALSE;
        IdleWait(10);
    }

    // If the verification fails, try two more times to
    // force the INH_SW1 and INH_SW2 to the desired states and verify it
    for (ucCountOuter=2; ucCountOuter>0; ucCountOuter--) {
        if (a_ucSwitchState == INH_ON_ON) {
            INH_SW1 = SW_ON;
            INH_SW2 = SW_ON;
        }
        else if (a_ucSwitchState == INH_ON_OFF) {
            INH_SW1 = SW_ON;
            INH_SW2 = SW_OFF;
        }
        else if (a_ucSwitchState == INH_OFF_ON) {
            INH_SW1 = SW_OFF;
            INH_SW2 = SW_ON;
        }
        else if (a_ucSwitchState == INH_OFF_OFF) {
            INH_SW1 = SW_OFF;
            INH_SW2 = SW_OFF;
        }

        IdleWait(150);

        for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
            ucFeedback = InhibitSwitchStatus();
            if (ucFeedback == a_ucSwitchState) return FALSE;
            IdleWait(10);
        }
    }

    // INHINX_n or INHOUT_n faulted
    if (ucFeedback ^ a_ucSwitchState == INHIBIT_FAULTED)
        // States for a backup module
        if (a_ucSwitchState != INH_ON_ON) return TRUE;

    // If all fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL,PIBOXSLOT_CPP,__LINE__,a_ucSwitchState,ucFeedback);
    return TRUE;
}
/*******************************************************************************
*                     clsPiBoxSlot::InhibitSwitchStatus                        *
*                     =================================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsPiBoxSlot::InhibitSwitchStatus(VOID) {
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    UINT8 ucTemp = 0x00;
        if (INHSWV1)
            ucTemp = ucTemp | 0x08;
        if (INHSWV3)
            ucTemp = ucTemp | 0x10;
        if (INHSWV2)
            ucTemp = ucTemp | 0x20;
    set_imask_exr(ucSaveExr);
    return ucTemp;
}
/*******************************************************************************
*                        clsPiBoxSlot::TestSwitchCheck                         *
*                        =============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::TestSwitchCheck(BOOL a_SwitchState) {
    UINT8 ucCountOuter,ucCountInner;

    for (ucCountOuter=3; ucCountOuter>0; ucCountOuter--) {
        for (ucCountInner=3; ucCountInner>0; ucCountInner--) {
            if (a_SwitchState == TST_SW) return;
            IdleWait(10);
        }
        // If read fails, force TST_SW to desired state
        TST_SW = a_SwitchState;
    }
    // If the check and force fails, hard fail the module
    HardFail(HF_OUTPUTCONTROL,PIBOXSLOT_CPP,__LINE__);
}
/*******************************************************************************
*                        clsPiBoxSlot::SetTestSwtich                           *
*                        ===========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::SetTestSwitch(BOOL a_State) {
    if (a_State == SW_ON) {
        TestSwitchCheck(SW_OFF);
        TST_SW = SW_ON;
        TestSwitchCheck(SW_ON);
    }
    else if (a_State == SW_OFF) {
        TestSwitchCheck(SW_ON);
        TST_SW = SW_OFF;
        TestSwitchCheck(SW_OFF);
    }
}
/*******************************************************************************
*                       clsPiBoxSlot::AppColdInit                              *
*                       =========================                              *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::AppColdInit(VOID) {
    if (MODSTATUS_RUN == ModStat1.Status) {
        ModStat1.Status = MODSTATUS_IDLE;
        AddModStatEvent(EVENTTYPE_NORMAL);
    }    
    DbValid = DB_INVALID;
    ComputeCheckSum(); // Recompute BOX checksum
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        // Slot checksum is recomputed by InitSlotDatabase.
        SLOT(ucSlotNum)->InitSlotDatabase(TRUE);
    }
}
/*******************************************************************************
*                        clsPiBoxSlot::AppFOProcess                            *
*                        ==========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsPiBoxSlot::AppFOProcess(VOID) {
    return FALSE;
}
/*******************************************************************************
*                        clsPiBoxSlot::AppPostSwap                             *
*                        =========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::AppPostSwap(VOID) {
    // Change the Module switch state to secondary state
    // This change will keep the switches from switching twice when the 
    // modules change roles
    SetForSecondary(TRUE);
}
/*******************************************************************************
*                        clsPiBoxSlot::AppPostSync                             *
*                        =========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::AppPostSync(VOID) {
}
/*******************************************************************************
*                        clsPiBoxSlot::SetForPrimary                           *
*                        ===========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::SetForPrimary (VOID) {
    TST_SW = SW_ON; 
    INH_SW1 = SW_ON;
    INH_SW2 = SW_ON;
    TST_SW = SW_OFF;
    IdleWait(150);
    InhibitSwitchCheck(INH_ON_ON);
    ModStat3.OutCtl = OUTCTL_MINE;
}
/*******************************************************************************
*                        clsPiBoxSlot::SetForSecondary                         *
*                        =============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::SetForSecondary (BOOL bDoCheck) {
    INH_SW1 = SW_OFF;
    INH_SW2 = SW_OFF;
    if (bDoCheck) { // verify switch states
        IdleWait(150);
        InhibitSwitchCheck(INH_OFF_OFF);
    }
    ModStat3.OutCtl = OUTCTL_PARTNER;
}
/*******************************************************************************
*                     clsPiBoxSlot::CheckFailOverCondition                     *
*                     ====================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::CheckFailOverCondition(VOID) {
    BOOL bTstSave = TST_SW;                          // Save state of TST switch
    //To allow factory to test this switch. 
    if(!(BOX->CheckForFactoryTestMode())){
        TST_SW = SW_OFF;
    }
    if (ModStat3.OutCtl == OUTCTL_PARTNER) {  // I do not have ctl of the screws
        if (BURIN_ASSERTED == BUPREQ_IN) {     // my partner has asserted BUPREQ
            if (INHIN_NEGATED == INHINX_n) {   // and it has given up the screws
                IdleWait(50);
                if (INHIN_NEGATED == INHINX_n) {  // partner still does not have
                    if (BUREQ_NEGATED == SWBUREQ_n) { // and i have negated BURQ
                        SetForPrimary();
                        if (REDSTATE_FO_IN_PROG == GetRedState())
                            SetRedState(REDSTATE_FO_COMPLETE);
                    }
                }
            }
        }
        if (Iol.AmPrimary()) {
            if (INHIN_NEGATED == INHINX_n) { // and it has given up the screws
                IdleWait(50);
                if (INHIN_NEGATED == INHINX_n) {// partner still does not have
                    // If at this point the expected FO sequence did not occur
                    // properly. So save the state of the BUREQ's & REDSTATE
                    // Then take control of the field terminations
                    TraceLog.AddToTrace(TRACEID_GENERIC,bcFailOver,
                       (UINT32)BUPREQ_IN << 24 | (UINT32)SWBUREQ_n << 16 |
                       (UINT32)GetRedData() << 8 | GetRedState());
                    SetForPrimary();
                    if (REDSTATE_FO_IN_PROG == GetRedState())
                       SetRedState(REDSTATE_FO_COMPLETE);
                }
            }
        }
    }
    else if (!Iol.AmPrimary()) {                // I have control of the screws
                                                   // and have started failover
        if (BUREQ_ASSERTED == SWBUREQ_n) {          // If I am asserting BUPREQ
            if (BURIN_NEGATED == BUPREQ_IN) {          // and my partner is not
                SetForSecondary(TRUE);          // assume role of backup module
            }
        }
    }
    TST_SW = bTstSave;                           // Restore state of TST switch
}
/*******************************************************************************
*                        clsPiBoxSlot::SetProverSignal                         *
*                        =============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiBoxSlot::SetProverSignal(BOOL a_bClearActual){
    CHANNEL_SELECT = 0x00;
    if (a_bClearActual) ucConfigProvSig = 0;
    
    switch(ucConfigProvSig){
       case 0:
          break;
       case 1:
          DPICR.B12 = 1;
          break;
       case 3:
          DPICR.B13 = 1;
          break;
       case 5:
          DPICR.B14 = 1;
          break;
       case 7:
          DPICR.B15 = 1;
          break;
    }
    usDPICR = DPICR.FPGAWORDREG; // Update FPGA Sync parameter
}
/*******************************************************************************
*                         clsPiBoxSlot::SwitchInit                             *
*                         ========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsPiBoxSlot::SwitchInit (VOID) {

    EN_SW = SW_ON;                                    // Push EN_SW to ON state
    EnableSwitchCheck(SW_ON);                             // Verify it happened
    UINT8 ucDelay = (BOTTOM) ? 20000 : 10;       // compute variable delay (us)
    if (INHIN_NEGATED == INHINX_n) {       // partner is not controlling screws
        if (BURIN_ASSERTED == BUPREQ_IN) {          // partner asserting BUPREQ
            if (INHIN_NEGATED == INHINX_n) {   // partner still not have screws
                IdleWait(ucDelay);                  // wait for some delay time
                if (INHIN_NEGATED == INHINX_n) { // partnr does not have screws
                    INH_SW1 = SW_ON;            // assume control of the screws
                    INH_SW2 = SW_ON;
                    IdleWait(ucDelay);              // wait for some delay time
                    if (INHIN_NEGATED == INHINX_n) { // partner not have screws
                        SetForPrimary();              // assume role as primary
                        return TRUE;                           // exit finished
                    }
                    else {
                        INH_SW1 = SW_OFF;        // relinquish control of screws
                        INH_SW2 = SW_OFF;
                        IdleWait(ucDelay);          // wait for some delay time
                        return FALSE;                         // exit unfinished
                    }
                }
                else {                         // partner is controlling screws
                    SetForSecondary(TRUE);      // assume role as backup module
                    return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                                 // exit unfinished
            }
        }
        else {
            IdleWait(ucDelay);                      // wait for some delay time
            if (INHIN_NEGATED == INHINX_n) {    // partner does not have screws
                if (BURIN_ASSERTED == BUPREQ_IN) {  // partner asserting BUPREQ
                    return FALSE;                            // exit unfinished
                }
                else {                       // partner is not asserting BUPREQ
                    SetForPrimary();
                    IdleWait(150);                    // wait for 150 microsecs
                    return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                                // exit unfinished
            }
        }
    }
    else {                                 // partner is controlling the screws
        IdleWait (ucDelay);                         // wait for some delay time
        if (INHIN_NEGATED == INHINX_n) {        // partner does not have screws
            return FALSE;                                    // exit unfinished
        }
        else {                             // partner is controlling the screws
            SetForSecondary(TRUE);              // assume role as backup module
            return TRUE;                                       // exit finished
        }
    }
}
/*******************************************************************************
*                       clsPiBoxSlot::SetIntPeriod                             *
*                       ==========================                             *
* PURPOSE: Updates the integration period register in the FPGA with the        *
*          desired integration period for a given channel.                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
VOID clsPiBoxSlot::SetIntPeriod(UINT8 ucChanNum, FREQPERIOD a_ucIntPeriod){
    UINT8 ucbitmask = 0x01 << (ucChanNum - 1); 

    // Clear the IP Valid flag for the channel before updating the 
    // new integration period value
    IP_VALID_FLAGS &= ~ucbitmask;

    if(ucChanNum == 1)
      INT_PER_CHN1 = (UINT) a_ucIntPeriod;
    if(ucChanNum == 2)     
      INT_PER_CHN2 = (UINT) a_ucIntPeriod;  
    if(ucChanNum == 3)     
      INT_PER_CHN3 = (UINT) a_ucIntPeriod;
    if(ucChanNum == 4)     
      INT_PER_CHN4 = (UINT) a_ucIntPeriod;
    if(ucChanNum == 5)     
      INT_PER_CHN5 = (UINT) a_ucIntPeriod;
    if(ucChanNum == 6)     
      INT_PER_CHN6 = (UINT) a_ucIntPeriod;
    if(ucChanNum == 7)     
      INT_PER_CHN7 = (UINT) a_ucIntPeriod;
    if(ucChanNum == 8)     
      INT_PER_CHN8 = (UINT) a_ucIntPeriod;

    // Set the IP Valid flag for the channel after updating the 
    // new integration period value 
    IP_VALID_FLAGS |= ucbitmask;

    // Update FPGA Sync parameters
    usIPR1 = IPR1.FPGAWORDREG;
    usIPR2 = IPR2.FPGAWORDREG;
}
/*******************************************************************************
*                       clsPiBoxSlot::FCODriverReadBackDiagnostics             *
*                       ==========================================             *
* PURPOSE: Check actual output is equal to either the safe output state or the *
*          last commanded state if it were so commanded.                       *
* ARGUMENTS: Channel Number (7 or 8)                                           *
* RETURN: FCORDBK_FAILED - Diagnostic failed                                   *
*         FCORDBK_PASSED - Diagnostic Passed                                   *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
    FCORDBKSTS clsPiBoxSlot::FCODriverReadBackDiagnostic(UINT8 ucChan) 
    {
        FCORDBKSTS bFcoRbSts    = FCORDBK_PASSED;
        BOOL       SafeOut      = GetSafeOut(ucChan);
        BOOL       TvProc       = GetTvProc(ucChan);
        BOOL       LastTvProc   = GetLastTvProc(ucChan);

        // If TvProc has just terminated do the following so that diagnostic
        // coverage is not disturbed for either module at any time
        if ((TvProc == OFF) && (LastTvProc == ON)) {
            SLOT(ucChan)->SetLastSoCmdVal(SOCMD_NONE);
            SetSo(ucChan,SafeOut);
        }

        SOCMDVAL   LastSoCmdVal = SLOT(ucChan)->GetLastSoCmdVal();
        BOOL       OutSet       = GetOutSet(ucChan);
        BOOL       So           = GetSo(ucChan);

        // If neither module has control of screws return without performing diagnostic
        if ((INHIN_ASSERTED == INHINX_n) || (ModStat3.OutCtl == OUTCTL_MINE)) {
        
            if (ModStat3.OutCtl == OUTCTL_MINE) {
                if((!TvProc && (LastSoCmdVal == SOCMD_NONE) && (So != SafeOut)) ||
                   (!TvProc && (LastSoCmdVal == SOCMD_OFF) && (So == ON)) ||
                   (!TvProc && (LastSoCmdVal == SOCMD_ON) && (So == OFF)) ||
                   (TvProc && (So == SafeOut))) bFcoRbSts = FCORDBK_FAILED;
            }
            else {
                if((!TvProc && (LastSoCmdVal == SOCMD_NONE) && (OutSet != SafeOut)) ||
                   (!TvProc && (LastSoCmdVal == SOCMD_OFF) && (OutSet == ON)) ||
                   (!TvProc && (LastSoCmdVal == SOCMD_ON) && (OutSet == OFF)) ||
                   (TvProc && (OutSet == SafeOut))) bFcoRbSts = FCORDBK_FAILED;
            }
        }

        SetLastTvProc(ucChan,TvProc);
        return bFcoRbSts;
    }

