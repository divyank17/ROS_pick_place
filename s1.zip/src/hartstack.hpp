/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hartstack.hpp                                               *
*    Description : HART protocol stack classes declaration.                    *
*******************************************************************************/
#ifndef __HARTSTACK_HPP__
#define __HARTSTACK_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "hart.h"
#include "utils.h"

#if defined(IOMTYPE_UIO)
#include "uiofpga.hpp"
#endif

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
// HMODEMSTATE represents the current state of the HART modem object.
typedef enum tagHModemState { 
    HMODEMSTATE_BAD,      // Failed diagnostics checks.
    HMODEMSTATE_IDLE,     // Free to be scheduled.
    HMODEMSTATE_SYNCWAIT, // Waiting for link quiet time.
    HMODEMSTATE_XMTING,   // Transmitting a request.
    HMODEMSTATE_RCVWAIT,  // Waiting for response.
    HMODEMSTATE_RCVING,   // Receiving a response.
    HMODEMSTATE_SUSPECT,  // Modem needs to be diagnosed.
    HMODEMSTATE_DIAG      // Modem being used as diag modem.
} HMODEMSTATE;

// HSYNCSTATUS represents channel objects intention to release 
// or continue to  use the currently connected modem. 
typedef enum tagHSyncStatus { 
    HSYNCSTATUS_UNKNOWN,   // Initialization value.
    HSYNCSTATUS_KEEP_SYNC, // Continue using the modem.
    HSYNCSTATUS_DROP_SYNC  // Relase the modem.
} HSYNCSTATUS;

// HINTRTYPE represents the interrupts from the HART UARTs.
typedef enum tagHIntrType { 
    HINTRTYPE_UNKNOWN,       // Initialization value.
    HINTRTYPE_RCVFIFOFULL,   // Receive FIFO full.
    HINTRTYPE_RCVFIFOTOUT,   // RCV FIFO has unread data.
    HINTRTYPE_XMTFIFOEMPTY,  // XMT holding register empty.
    HINTRTYPE_CARRIERDETECT, // Modem detected carrier.
    HINTRTYPE_CARRIERDROP    // Modem detected carrier drop.
} HINTRTYPE;

// HMSGTYPE represents the current response message type.
typedef enum tagHMsgType { 
    HMSGTYPE_UNKNOWN,   // Initialization value.
    HMSGTYPE_STX,       // Request from handheld to device.
    HMSGTYPE_ACKTOME,   // Response from device to IOP.
    HMSGTYPE_ACKTOHIM,  // Response from device to handheld.
    HMSGTYPE_BACKTOME,  // Burst message addressed to IOP.
    HMSGTYPE_BACKTOHIM, // Burst addressed to handheld.
    HMSGTYPE_STXFROMME  // Request from IOP to device.
} HMSGTYPE;

// HMSGSTATUS represents the status of current response message.
typedef enum tagHMsgStatus { 
    HMSGSTATUS_GOOD,       // Good response.
    HMSGSTATUS_BAD,        // Failed to decode response.
    HMSGSTATUS_DEVICEERROR // CommStatus bit set by the device.
} HMSGSTATUS;

// HEVENTTYPE is used to notify events detected by the modem to the client.
typedef enum tagHEventType { 
    HEVENTTYPE_UNKNOWN,     // Initialization value.
    HEVENTTYPE_COMMERROR,   // Communication error detected.
    HEVENTTYPE_NORESPONSE,  // No response from the device.
    HEVENTTYPE_DEVICEERROR, // Device has detected error.
    HEVENTTYPE_RCVRERROR,   // IOP receiver has an error.
    HEVENTTYPE_RETRY,       // IOP is retrying the request.
    HEVENTTYPE_TOTALTIMEOUT,// Total time allotted expired.
    HEVENTTYPE_SECMASTER,   // Detected a secondary master.
    HEVENTTYPE_BURSTMODE,   // Device is in burst mode.
    HEVENTTYPE_PRIMASTER    // Another primary master detected.
} HEVENTTYPE;

// CONTEXT is used to save the current transmit and receive context by the
// modem object, when the transmit or receive function is exited.
typedef enum tagXmtRcvContext { 
    XMTRCVCONTEXT_UNKNOWN,   // Initialization value.
    XMTRCVCONTEXT_PREAMBLE,  // Send or receive - preambles.
    XMTRCVCONTEXT_DELIMITER, // Send or receive - delimiter byte next.
    XMTRCVCONTEXT_ADDRESS,   // Send or receive - address bytes next.
    XMTRCVCONTEXT_COMMAND,   // Send or receive - command byte next.
    XMTRCVCONTEXT_BYTECOUNT, // Send or receive - byte count next.
    XMTRCVCONTEXT_STATUS,    // Receive only - status byte.
    XMTRCVCONTEXT_DATA       // Send or receive - data bytes.
} XMTRCVCONTEXT;
/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
// Size defined in UINT16 units so as that the object is aligned in even memory
// boundary. This is required to ensure the alignment of individual members.
#define CLSHARTMODEM_SIZE ((sizeof(clsHartModem)+(sizeof(clsHartModem)%2)) / 2)

#if defined(IOMTYPE_UIO)
#define CLSHARTQUEUE_SIZE ((sizeof(clsHartQueue)+(sizeof(clsHartQueue)%2)) / 2)
#endif

const UINT8 HARTQUEUE_BUFFER_SIZE   = 16; 
const UINT8 HARTMODEM_BUFFER_SIZE   = 32;
const UINT8 HSYNC_MINIMUM_TIME      = 1;
const UINT8 CHECKPAD_BYTECOUNT      = 2;
const UINT8 XMTINT_ALLOWANCE        = 1;
const UINT8 RCVINT_ALLOWANCE        = 2;
const UINT8 MAX_DRIBBLE_BYTES       = 2;
const UINT8 UART_XMT_FIFO_SIZE      = 16;
const UINT8 UART_RCV_FIFO_SIZE      = 16;

const UINT8 HMODEMDIAG_MAXCOUNT           = 3;
const UINT8 HMODEMDIAG_UNDERRUN_MAXCOUNT  = 10;
const UINT8 HART_LOOPBACK_SIZE            = 12;
const UINT8 HART_ENABLE_ALL_MUXES         = 0x000F;
const UINT8 HART_UART_8BITS_PER_CHAR      = 0x03;
const UINT8 HART_UART_LINE_STS_ERROR_BITS = 0x1E;
const UINT8 HART_LOOPBACK_PATTERN[HART_LOOPBACK_SIZE] = { 0xAA,0x55,0xA5,0x5A,
                                                          0xCC,0x33,0xC3,0x3C,
                                                          0xF0,0x0F,0x00,0xFF };
/*******************************************************************************
*                               clsClientBuffer                                *
*                               ===============                                *
*  This class automates buffer management activities for clients of HART stack *
*  like channel objects and for passthrough response. Modem objects use the    *
*  methods of clsClientBuffer to return the response data from the HART device.*
*  Memory required for the buffer should be allocated by the client and the    *
*  buffer pointer should be passed to the constructor by the calling function. *
*******************************************************************************/
class clsClientBuffer {
    const UINT16 m_BUFSIZE;   // Size of the buffer.
    UINT8 * m_ucpBuffer;      // Pointer to the buffer memory.
    UINT16  m_usIndex;        // Index showing next free location.
    
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); } 
    clsClientBuffer(clsClientBuffer&); // Safeguard against default copy constructor.
    clsClientBuffer& operator=(const clsClientBuffer&); // and default assignement.

public:
    clsClientBuffer(UINT16 a_usBufSize,UINT8 * a_ucpBuf) : m_BUFSIZE(a_usBufSize) { 
        m_ucpBuffer = a_ucpBuf;
        Flush();
    }
    ~clsClientBuffer() { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); }

    inline VOID Flush(VOID) {
        for (m_usIndex = 0; m_usIndex < m_BUFSIZE; m_usIndex++) {
            *(m_ucpBuffer + m_usIndex) = 0;
        }
        m_usIndex = 0;
    }

    inline UINT8 At(UINT16 a_usIndex) { 
        UINT8 ucReturn = 0;
        if (a_usIndex < m_BUFSIZE) {
            ucReturn = *(m_ucpBuffer + a_usIndex); 
        }
        return ucReturn;
    }

    inline UINT8 *AddrAt(UINT16 a_usIndex) { 
        UINT8 *ucpReturn = 0;
        if (a_usIndex < m_BUFSIZE) {
            ucpReturn = (m_ucpBuffer + a_usIndex); 
        }
        return ucpReturn; 
    }

    inline clsClientBuffer& operator=(const UINT8 a_ucData) {
        if (m_usIndex < m_BUFSIZE) {
            *(m_ucpBuffer + m_usIndex) = a_ucData;
            m_usIndex++;
        }
        return *this;
    }
};
/*******************************************************************************
*                                clsHartQueue                                  *
*                                ============                                  *
*  clsHartQueue implments a first-in-first-out queue for HART requests. Global *
*  HART stack interface function InitHartConnection uses this class to queue   *
*  the requests. clsHartQueue can hold 16 UINT8 variables corresponding to the *
*  sixteen channel objects. At any point of time, the queue will not have two  *
*  entries of the same channel object. AddToQueue method takes care of this.   *
*  Queue is periodically checked by all the idle modems. Whenever an entry is  *
*  found in the queue, the modem connects to the corresponding channel object  *
*  to carry out HART transaction.                                              *
*******************************************************************************/
class clsHartQueue {
    UINT8 m_ucNextIndex; // Next free index in the queue.
    UINT8 m_ucBuffer[HARTQUEUE_BUFFER_SIZE]; // Buffer for holding contents.
    
#if !defined(IOMTYPE_UIO)
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); return NULL; }
#endif
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); } 
    clsHartQueue(clsHartQueue&); // Safeguard against default copy constructor.
    clsHartQueue& operator=(const clsHartQueue&); // and default assignement

public:
    clsHartQueue(VOID);
    ~clsHartQueue(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); } 

    BOOL AddToQueue(UINT8);
    BOOL RemoveFromQueue(UINT8);
    VOID ProcessQueue(UINT8);
#if defined(IOMTYPE_UIO)
    VOID *operator new(UINT32,UINT8);
    BOOL IsModemQueueEmpty(VOID);
#endif
};
/*******************************************************************************
*                               clsModemBuffer                                 *
*                               ==============                                 *
*  This class defines a receive buffer class for modem objects that will       *
*  automate the buffer management activities using its member functions. Each  *
*  modem object will instantiate a clsModemBuffer object and data from UART    *
*  FIFO is directly copied to this object. Modem objects use this FIFO as a    *
*  work space to decode HART message. By using circular FIFO model, memory     *
*  usage is optimized to 32 bytes even though HART message can contain almost  *
*  upto 290 bytes. Size is fixed at 32 bytes - double the size of the 16 byte  *
*  UART FIFO.                                                                  *
*******************************************************************************/
class clsModemBuffer {
    UINT8   *m_ucpAppend;   // Append pointer used to add data to FIFO.
    UINT8   *m_ucpRemove;   // Remove pointer used to pop data from FIFO.
    UINT8   m_ucCount;      // Current size of the FIFO.

    UINT8   m_ucBuffer[HARTMODEM_BUFFER_SIZE];  // FIFO buffer.
    
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); } 
    clsModemBuffer(clsModemBuffer&); // Safeguard against default copy constructor.
    clsModemBuffer& operator=(const clsModemBuffer&); // and default assignement.

public:
    clsModemBuffer() { Flush(); }
    ~clsModemBuffer() { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); }

    inline unsigned short GetLength(void) { return m_ucCount; }

    inline void Flush(VOID) {
        m_ucpAppend = m_ucpRemove = m_ucBuffer;
        while (m_ucpAppend < (m_ucBuffer + HARTMODEM_BUFFER_SIZE)) {
            *m_ucpAppend++ = 0;
        }
        m_ucpAppend = m_ucpRemove;
        m_ucCount = 0;
    }

    inline UINT8 PopChar(VOID) {
        UINT8 ucChar = *m_ucpRemove;
        if (m_ucCount > 0) {
            *m_ucpRemove++ = 0;
            m_ucCount--;
            if (m_ucpRemove == (m_ucBuffer + HARTMODEM_BUFFER_SIZE)) {
                m_ucpRemove = m_ucBuffer;
            }
        }
        return ucChar;
    }

    inline VOID ThrowLastRcvd(VOID){
        if (m_ucCount > 0) {
            *m_ucpAppend = 0;
            m_ucCount--;
            if (m_ucpAppend == m_ucBuffer) {
                m_ucpAppend = m_ucBuffer + HARTMODEM_BUFFER_SIZE - 1;
            }
            else m_ucpAppend--;
        }
    }

    inline clsModemBuffer& operator=(const UINT8 a_cucData) {
        if (m_ucCount < HARTMODEM_BUFFER_SIZE) {
            *m_ucpAppend++ = a_cucData;
            m_ucCount++;
            if (m_ucpAppend == (m_ucBuffer + HARTMODEM_BUFFER_SIZE))
                m_ucpAppend = m_ucBuffer;
        }
        return *this;
    }
};
/*******************************************************************************
*                                 clsHartModem                                 *
*                                 ============                                 *
*  clsHartModem implements HART data link layer functions. This class abstract *
*  the behavior and controls the HART modem and the associated UART channel    *
*  abd analog multiplexor. IOM startup code instantiates four clsHartModem     *
*  objects and setup a periodic timer interrupt at HART char time intervals to *
*  these objects. This heartbeat is a key function of the modem object to time *
*  the HART protocol timers. Interrupts from the UART/modem are also serviced  *
*  by these objects. Modem objects does the actual transmission of the HART    *
*  request by connecting to the appropriate channel using the MUX and copying  *
*  the request bytes to UART transmit FIFO. When response becomes available,   *
*  modem object retrieve the response data from the UART receive FIFO, performs*
*  data link layer checks and then transfer data to the client.                *
*******************************************************************************/
class clsHartModem {
    static UINT8    m_ucHartMuxEnbl;        // HART multiplexor enable register.
    static UINT16   m_usHartMuxAddr;        // HART multiplexor address register.
    static UINT8    m_ucHDiagUnderRunCount; // Modem diagnostic underrun count.
    static UINT8    m_ucFailedChannel;      // Channel at which modem diagnostics failed.
    static UINT32   m_sulMDiagCount;

    const UINT8     m_ucModemNumber;        // Modem number 0 to 3.
    UINT8           m_ucModemTimer;         // Protocol timer
    HMODEMSTATE     m_ModemState;           // Modem xmting, rcving or idle.

    UINT8           m_ucConnectedChannel;   // Currently connected channel number.
    const UINT8     *m_cucpXmtBuffer;       // Pointer to trasmit buffer.
    clsModemBuffer  m_ModemRcvBuffer;       // Modem Receive buffer object.
    UINT8           m_ucPollingAddress;     // Polling address
    HARTUNIQUEADDR  m_UniqueAddress;        // Unique address

    UINT8           m_ucXmtCommand;         // Currently operating command.
    UINT8           m_ucBytesInRequest;     // number of bytes to be XMTd.
    UINT16          m_ucBytesInResponse;    // number of byte to be received.
    XMTRCVCONTEXT   m_XmtRcvContext;        // current transmit or receive context.
    HMSGTYPE        m_RcvMsgType;           // HART frame type of the received message.
    HMSGSTATUS      m_RcvMsgStatus;         // status of the current reception.
    UINT8           m_ucCheckSum;           // current transmit or receive checksum.
    UINT8           m_ucRemPreambles;       // number of preambles to be XMTd or RCVd.
    UINT8           m_ucRcvdDelimiter;      // currently received delimiter.
    UINT8           m_ucRetryCount;         // Left retry counts for this transaction.
    BOOL            m_bRequestDisconnect;   // Client is requesting disconnect.
    BOOL            m_bBurstDeviceFound;    // Current device is in burst mode.
    UINT8           m_ucModemDiagCount;     // Modem diagnostic count in this connection.
#if defined(IOMTYPE_UIO)
    BOOL            m_bHartStackProc;       // Flag to indicate hart stack is searching for PSTs
#endif

    VOID SetState(HMODEMSTATE,UINT8);
    
#if defined(IOMTYPE_UIO)
    VOID Disconnect(BOOL bResetState = TRUE);
#else
    VOID Connect(UINT8);
    VOID Disconnect(VOID);
#endif
    VOID DiagConnect(UINT8);
    VOID SwitchMux(UINT8);
    VOID ModemTimeout(VOID);
    VOID TransmitRequest(VOID);
    VOID ProcessResponse(VOID);
    VOID DecodeResponse(VOID);
    VOID ActOnResponse(VOID);
    VOID SetupRetry(UINT8);
    VOID HandleReceiveError(VOID);
    VOID ProcessDiagModem(VOID);

    clsHartModem(clsHartModem&); // Safeguard against default copy constructor.
    clsHartModem& operator=(const clsHartModem&); // and default assignement

public:
    clsHartModem(UINT8);
    ~clsHartModem(VOID) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); } 

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,HARTSTACK_HPP,__LINE__); }

    VOID HartModemInterrupt(HINTRTYPE);
    static VOID HartModemHeartbeat(VOID);

#if !defined(IOMTYPE_UIO)
    UINT8 HartMuxLoopbackTest(VOID);
#endif

#if defined(IOMTYPE_UIO)
    VOID Connect(UINT8);
    inline BOOL IsHartStackProc(VOID) { return m_bHartStackProc;}
#endif
    inline UINT8 GetModemNumber(VOID) { return m_ucModemNumber; }
    inline UINT8 GetConnectedChannel(VOID) { return m_ucConnectedChannel; }
    inline UINT8 GetFailedChannel(VOID) { return m_ucFailedChannel; }
    inline VOID  RequestDisconnect(VOID) { m_bRequestDisconnect = TRUE; }
    inline HMODEMSTATE GetModemState(VOID) { return m_ModemState; }
    inline UINT8 GetModemTimer(VOID) { return m_ucModemTimer; }
    inline UINT8 GetModemDiagCount(VOID) { return m_ucModemDiagCount; }
    inline VOID  ReinstateModem(VOID) { 
        m_ucModemDiagCount++;
        SetState(HMODEMSTATE_SYNCWAIT,HART_LINK_GRANT_TIME);
        m_ucHDiagUnderRunCount = HMODEMDIAG_UNDERRUN_MAXCOUNT;
    }
    
    inline VOID  SetModemBad(VOID) { 
        Disconnect();
        m_ModemState = HMODEMSTATE_BAD; 
    }

    inline VOID ClearModemBad(VOID) {
        m_ucFailedChannel = 0;
        if (m_ModemState == HMODEMSTATE_BAD) m_ModemState = HMODEMSTATE_IDLE;
    }

    inline VOID  ClearTxRxFIFOs(VOID) {
        HART_UART(m_ucModemNumber).XMT_FIFO_CLEAR = 1;
        HART_UART(m_ucModemNumber).RCV_FIFO_CLEAR = 1;
    }

    friend VOID clsHartQueue::ProcessQueue(UINT8);

#ifdef DEBUG
    friend extern RETURNSTATUS HartModemStatus(VOID);
#endif
};
/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
#if defined(IOMTYPE_UIO)
// Every modem has its own queue (One modem per I/O board)
extern clsHartQueue *pHartQueue[HARTMODEM_COUNT];
#else
extern clsHartQueue    HartQueue;
#endif
extern clsHartModem    *pHartModem[HARTMODEM_COUNT];
/*******************************************************************************
*                               GLOBAL FUNCTIONS                               *
*******************************************************************************/
extern VOID CheckAndInitHart(VOID);
extern BOOL isHartCapable(VOID);
extern VOID ProcessHartInterrupt(VOID);
extern BOOL InitHartConnection(UINT8);
extern VOID ResetHart(VOID); 
extern BOOL AbortHartConnection(UINT8);

#endif
