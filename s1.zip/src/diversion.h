/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : diversion.h                                                 *
*    Description : Digital Input firmware version declaration.                 *
*******************************************************************************/
#ifndef DIVERSION_H
#define DIVERSION_H
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#ifdef DEVELOPER_BUILD_OVERRIDE
const UINT8 VERSION_NUMBER  = VERSION;
const UINT8 REVISION_NUMBER = REVISION;
const UINT8 BUILD_NUMBER    = BUILD;
#else
    #if defined(DIGTYPE_DI)
        /*
         * REV 5.0.0 - Intial release of redesign DI IOP
         * REV 5.1.0 - Customer(-MiRO) Issue(-CL Fail) Fix + Field upgrade feature in boot code
         * REV 5.2.0 - fix for the issues - FO_COMPLETE during SEC FTA failure and flooding alarms
         *                                - unnecessary alarm events are generating during modules swap
         * REV 5.3.0 - fix for PAR# 1-EQ6GPG3 (customer issue - When 10th channel made on, all other channels also gettting ON by themselves)
         * REV 5.4.0 - fix for PAR# 1-GEB5TXN (Offnormal alarms not generating / showing in the station).
         * REV 5.5.0 - fix for the following issues
		 *             PAR# 1-GJ6MQXN (DI & DI-24 inactive alarm icon is not changing to grey when channel is inactivated).
         *             PAR# 1-GLD5D07 (OFF-Normal alarm icon shows gray color (inactive alarm) after removal primary IOP of DI-24)
		 *             PAR# 1-GJDDRTJ (COS Alarms reappearing in alarm summary with the new time stamp when reinserting the backup IOP).
		               PAR# 1-GFATMDB (DI-24V IOP OFFNORMAL alarm not reporting in overflow condition and unexpected behaviors may occur).
         */
        const UINT8 VERSION_NUMBER  = 5;
        const UINT8 REVISION_NUMBER = 5;
        const UINT8 BUILD_NUMBER    = 0;
    #elif defined(DIGTYPE_DI24)
        /*
         * REV 5.0.0 - Intial release of redesign DI24 IOP
         * REV 5.1.0 - Customer(-MiRO) Issue(-CL Fail) Fix + Field upgrade feature in boot code
         * REV 5.2.0 - fix for the issues - FO_COMPLETE during SEC FTA failure and flooding alarms
         *                                - unnecessary alarm events are generating during modules swap
         * REV 5.3.0 - fix for PAR# 1-EQ6GPG3 (customer issue - When 10th channel made on, all other channels also gettting ON by themselves)
         * REV 5.4.0 - fix for PAR# 1-GEB5TXN (Offnormal alarms not generating / showing in the station).
         * REV 5.5.0 - fix for the following issues
		 *             PAR# 1-GJ6MQXN (DI & DI-24 inactive alarm icon is not changing to grey when channel is inactivated).
         *             PAR# 1-GLD5D07 (OFF-Normal alarm icon shows gray color (inactive alarm) after removal primary IOP of DI-24)		 
		 *             PAR# 1-GJDDRTJ (COS Alarms reappearing in alarm summary with the new time stamp when reinserting the backup IOP).
         */
        const UINT8 VERSION_NUMBER  = 5;
        const UINT8 REVISION_NUMBER = 5;
        const UINT8 BUILD_NUMBER    = 0;
    #endif
#endif

#endif
