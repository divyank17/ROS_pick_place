/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : domain.cpp                                                  *
*    Description : Digital Output module application specific startup code.    *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "domain.h"
#include "iol.hpp"
#include "tracelog.hpp"

/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN DiagnosticTask(TASKCONTEXT);
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
WRITEINPROGRESS  WriteInProgress;
#ifdef DEBUG
clsDebugPort     DebugPort;
#endif

//To Retain the tracelogs at Reset
#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section

clsTaskScheduler TaskScheduler;
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;

// Pointers to database objects
clsIomSlot       *pDatabase[MAXSLOTS + 1];

// Database Memory
UINT16 ucIomDbMemory[DOBOXSLOT_SIZE + (MAXSLOTS * DOSLOT_SIZE)];
// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//NOTE:
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                           WriteDatabaseTask
                                           ,LowPriorityTask
                                           ,EventRecoveryTask
                                           ,DiagnosticTask
#ifdef DEBUG
                                           ,DebugTask
#endif
};

/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
*    Application specific startup code.                                        *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function is called by the PowerOn reset vector.                      *
*******************************************************************************/
VOID main(VOID) 
{
    // Create box and slot database objects
    pDatabase[0] = new clsDoBoxSlot(MODLTYPE_DOB);
    TraceLog.AddToTrace(TRACEID_GENERIC,bcDoIom,BOX->GetDPA());
    for (UINT8 ucSltNm = 0; ucSltNm < MAXSLOTS; ucSltNm++) {
        pDatabase[ucSltNm + 1] = new(ucSltNm) clsDoSlot(ucSltNm + 1);
#if defined(IOPTYPE_DO)
        // PMIO DO Redesign Checkpoint restoring from SRAM
        pDatabase[ucSltNm + 1]->PmioCheckPointRestore();
#endif
    }
    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();

    // for PMIO DIDO redesign
#if defined(IOPTYPE_DO)
    xRamInit(); //TBD
#endif
    
    // Initialize all periodic tasks
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
        DMCPERIOD_LPTASK);
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
        DMCPERIOD_DIAGTASK);

#ifdef DEBUG
    // Set the Debug Task to RUN State
    TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif

    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}
/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE:                                                                     *
*    Demo purpose task code.                                                   *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
* Runs Task every 1 seconds,can view LowPriorityTask over Debug terminal       *
* to identify the task                                                         *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
    TASKRETURN TaskReturnValue;

    // Check for Communication failure and CEE Failure. If any one of 
    // these present, call FaultHandling function which sheds output
    // based on the Mode and ModeAttr configuration.
    TOG_FAILED TogFailed = BOX->IsTogFailed();
    if (NOTOG_FAILED != TogFailed) {
        for (UINT8 ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) {
            if(FAULTSTATE_NORMAL == SLOT(ucChannel)->GetFaultState()) {
                SLOT(ucChannel)->SlotFaultHandler(TogFailed);
            }
        }
    }
    else if ((BOX->GetComTog() == TRUE) && (BOX->GetCtlTog() == TRUE)) { 
        // If both CTL and COMM TOG is present
        for (UINT8 ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) {
            if(FAULTSTATE_FAULTED == SLOT(ucChannel)->GetFaultState()) {
                SLOT(ucChannel)->ResetFaultState();
            }
        }
    }

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();
   
#if defined(DIGTYPE_DO32)
    // If configured as redundant pair, do INH_SW diagnostics.
    if (BOX->CheckRedData(REDDATA_REDCFG)) {
        BOX->InhibitSwitchDiagnostics();
    }
#endif

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
