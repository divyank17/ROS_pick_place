/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spslot.hpp                                                  *
*    Description : Class clsAihSlot declaration.                               *
*******************************************************************************/
#ifndef __SPSLOT_HPP__
#define __SPSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define SPSLOT_SIZE ((sizeof(clsSpSlot) + (sizeof(clsSpSlot) % 2)) / 2)

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SPEED_SYNC_VER_1;
//

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
/* Sensor Type */
typedef enum tagSensrType{
    ACTIVE_SENSR   = 0,
    PASSIVE_SENSR  = 1
} SENSRTYPE;
//

/* EdgeDetect */
typedef enum tagEdgeDetect{
    RAISING  = 0,
    FALLING  = 1
} EDGEDETECT;
//

/* Filter Time */
typedef enum tagFilterTime{
   FT2p5MS = 0,
   FT5MS = 1,
   FT7p5MS = 2,
   FT10MS = 3,
   FT20MS = 4
}FILTERTIME;
//

/* Measurement Type */
typedef enum tagMeasurementType{
   SPEED_MEASUREMENT = 0,
   FLOW_MEASUREMENT  = 1
}MEASUREMENT_TYPE;
//

/* Order Of K Factor */
typedef enum tagOrderOfKFactor{
   FIRST_ORDER = 0,
   SECOND_ORDER  = 1
}ORDER_OF_KFACTOR;
//

/* Time Unit */
typedef enum tagTimeUnit{
   PER_SECONDS = 0,
   PER_MINUTES = 1,
   PER_HOURS   = 2,
   PER_DAYS    = 3
}TIME_UNIT;
//

class clsSpSlot; // forward declaration

/* Slot Database Parameter Info */
typedef struct tagSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsSpSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsSpSlot::* PostPtr)(UINT8);
    VOID *   (clsSpSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} SLOTPARAMINFO;
//

/*******************************************************************************
*                                   clsSpSlot                                  *
*                                   =========                                  *
*******************************************************************************/
class clsSpSlot : public clsInSlot {
protected:

    //Member Variables
    FLOAT32    Pv;
    PVVALST    PvSts;
    FLOAT32    LastPv;
    FLOAT32    PvRaw;
    FLOAT32    PvAuto;
    PVVALST    PvAutoSt;
    FLOAT32    PvCalc;
    FLOAT32    RocPv;
    BOOL       BadPvFl;
    PVCLAMP    PvClamp;
    FLOAT32    PvP;
    SENSRTYPE  SpSensrType;
    EDGEDETECT EdgeDetect;
    FLOAT32    GearRatio;
    UINT16     TeethCnt;
    BOOL       OwdFl;
    BOOL       MisgPulFl;
    BOOL       DefmPulFl;
    BOOL       ExciFailFl;
    BOOL       ZeroSpdFl;
    BOOL       RevRotFl;
    BOOL       ChanAlmEnb;
    FILTERTIME FilterTime;
    FLOAT32    RocPosLm;
    FLOAT32    RocNegLm;
    FLOAT32    PvHiAlmTP;
    BOOL       PvHiAlmFL;  
    FLOAT32    PvHHAlmTP;
    BOOL       PvHHAlmFL;  
    BOOL       PvHHAlmFlwrst;  
    FLOAT32    RocPosHiAlmTP;
    BOOL       RocPosHiAlmFL;  
    FLOAT32    RocPosHHAlmTP;
    BOOL       RocPosHHAlmFL;  
    BOOL       RocPosAlmFlwrst;
    FLOAT32    LastROCNegLldrCrSpd;
    FLOAT32    LastROCPosHhdrNmSpd;
    FLOAT32    CriticalSpd;
    FLOAT32    NominalSpd;
    FLOAT32    Pv100;
    FLOAT32    KFactor;
    FLOAT32    MinFlowRate;
    FLOAT32    KMinFlowRate;
    FLOAT32    MaxFlowRate;
    FLOAT32    KMaxFlowRate;
    MEASUREMENT_TYPE MeasurementType;
    ORDER_OF_KFACTOR Order_Of_KFactor;
    TIME_UNIT  TimeUnit;
    BOOL       ResetPv;
    //

    //Shared ram slot data pointer
    SPEEDSHRAMSLOTDATA *pSpeedShramSlotData; 
    //

    //Static Member variables
    static const UINT8 CheckPointVer1[]; 
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const SLOTPARAMINFO tblParamInfo[256];
    static UINT8 SpSpeedSlotChkpntVersion;
    //

    //Method to Initial member variables
    VOID InitSpSlot(BOOL bFullInit, BOOL bObjCreate);
    //

    //Overrided clsIoSlot Class Varibles GetPtr methods
    VOID *GetPntTypePtr(VOID);  
    VOID *GetPtExecStPtr(VOID);
    //

    //Overrided clsInSlot Class Varibles GetPtr methods
    VOID *GetPvSourcePtr(VOID);
    VOID *GetPvSrcOptPtr(VOID);
    VOID *GetOwdEnablePtr(VOID);
    //

    //clsSpSlot Class Varibles GetPtr methods
    VOID *GetPvPtr(VOID);
    VOID *GetPvStsPtr(VOID);
    VOID *GetPvRawPtr(VOID);   
    VOID *GetPvCalcPtr(VOID);  
    VOID *GetPvAutoPtr(VOID);  
    VOID *GetPvAutoStPtr(VOID);
    VOID *GetLastPvPtr(VOID);  
    VOID *GetRocPvPtr(VOID);   
    VOID *GetPvPPtr(VOID);     
    VOID *GetPv100Ptr(VOID);
    VOID *GetPvClampPtr(VOID);  
    VOID *GetSpSensrTypePtr(VOID);
    VOID *GetEdgeDetectPtr(VOID); 
    VOID *GetGearRatioPtr(VOID);  
    VOID *GetTeethCntPtr(VOID);   
    VOID *GetOwdFlPtr(VOID);     
    VOID *GetMisgPulFlPtr(VOID); 
    VOID *GetDefmPulFlPtr(VOID); 
    VOID *GetExciFailFlPtr(VOID);
    VOID *GetZeroSpdFlPtr(VOID); 
    VOID *GetLastROCNegLldrCrSpdPtr(VOID);
    VOID *GetLastROCPosHhdrNmSpdPtr(VOID);
    VOID *GetCriticalSpdPtr(VOID);
    VOID *GetNominalSpdPtr(VOID);   
    VOID *GetRocPosLmPtr(VOID);
    VOID *GetPvHiAlmTPPtr(VOID);
    VOID *GetPvHiAlmFLPtr(VOID);
    VOID *GetPvHHAlmTPPtr(VOID);
    VOID *GetPvHHAlmFLPtr(VOID);
    VOID *GetPvHHAlmFlwrstPtr(VOID);
    VOID *GetRocPosHiAlmTPPtr(VOID);
    VOID *GetRocPosHiAlmFLPtr(VOID);
    VOID *GetRocPosHHAlmTPPtr(VOID);
    VOID *GetRocPosHHAlmFLPtr(VOID);
    VOID *GetRocPosAlmFlwrstPtr(VOID);
    VOID *GetFilterTimePtr(VOID);
    VOID *GetMeasurementTypePtr(VOID);
    VOID *GetOrderOfKFactorPtr(VOID);
    VOID *GetKFactorPtr(VOID);
    VOID *GetMinFlowRatePtr(VOID);
    VOID *GetKMinFlowRatePtr(VOID);
    VOID *GetMaxFlowRatePtr(VOID);
    VOID *GetKMaxFlowRatePtr(VOID);
    VOID *GetTimeUnitPtr(VOID);
    VOID *GetResetPvPtr(VOID);

    //Not Used in Current Build
    inline VOID *GetRocNegLmPtr(VOID)      {return &RocNegLm;  }
    inline VOID *GetChanAlmEnbPtr(VOID)    {return &ChanAlmEnb;}
    //

    //Static Varibles GetPtr methods
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SpSpeedSlotChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams; }
    //

    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SpSpeedSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SpSpeedSlotChkpntVersion;}

    //Database Access Related Methods
    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    //

    clsSpSlot(const clsSpSlot&);            // Safeguard against default copy constructor
    clsSpSlot& operator=(const clsSpSlot&); // and default assignment
public:
    clsSpSlot(UINT8);
    ~clsSpSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,AIHSLOT_HPP,__LINE__); }

    //Database Access Related Methods    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    virtual UINT8 *GetParameterPtr(UINT8 a_ucParamNumber){ return GetParamPtr(a_ucParamNumber); }
    //

    //Method to Initial member variables
    VOID InitSlotDatabase(BOOL bFullInit);
    //

    //Redundacny Dump Related Struct and Methods
    typedef struct strSpeedSyncRec
    {
        UINT16     Header;      // The first two bytes of dump record should always represent version. Do not change this. 
        UINT8      PntType;
        UINT8      PtExecSt;
        UINT8      ContCut;
        UINT8      PvSource;
        UINT8      PvSrcOpt;
        UINT8      OwdEnable;
        UINT8      PvClamp;
        UINT8      SpSensrType;
        UINT8      EdgeDetect;
        UINT8      ChanAlmEnb;
        UINT8      PvHHAlmFlwrst;  
        UINT8      RocPosAlmFlwrst;
        UINT16     TeethCount;
        FLOAT32    LastPv;
        FLOAT32    PvCalc;
        FLOAT32    PvEUHi;
        FLOAT32    PvEULo;
        FLOAT32    PvExEUHi;
        FLOAT32    PvExEULo;
        FLOAT32    GearRatio;
        FLOAT32    PvHiAlmTP;
        FLOAT32    PvHHAlmTP;
        FLOAT32    RocPosHiAlmTP;
        FLOAT32    RocPosHHAlmTP;
        FLOAT32    LastROCNegLldrCrSpd;
        FLOAT32    LastROCPosHhdrNmSpd;
        FLOAT32    CriticalSpd;
        FLOAT32    NominalSpd;
        FLOAT32    Pv;
        UINT8      PvSts;
        UINT8      FilterTime;
        UINT8      MeasurementType;
        UINT8      Order_Of_KFactor;
        FLOAT32    KFactor;
        FLOAT32    MinFlowRate;
        FLOAT32    KMinFlowRate;
        FLOAT32    MaxFlowRate;
        FLOAT32    KMaxFlowRate;
        UINT8      TimeUnit;
    } SYNCRECORD,*PSYNCRECORD;
    UINT32 GetRedSlotSize(VOID) { return sizeof(SYNCRECORD); }
    PASTATUS GetDumpData(UINT8* const pDump,const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    //
};

#endif
