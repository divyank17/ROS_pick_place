/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : llmuxslot.cpp                                                 *
*    Description : Class clsLLSlot definition.                                *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "llmuxmain.h"
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
//J TYPE T/C Segment Number: 1 from -7900.0000000000uV(-200.44C) to -5720.0000000000uV(-127.80C)
const FLOAT32 clsLLSlot::J_COEFF_SET0[] = { -6.43695661790666690E+002,
                                            -3.88231251386591420E-001,
                                            -9.75924384722758450E-005,
                                            -1.03669907783138520E-008,
                                            -4.22158808250626940E-013 };
//J TYPE T/C Segment Number: 2 from -5720.0000000000uV(-127.80C) to 1030.0000000000uV(20.21C)
const FLOAT32 clsLLSlot::J_COEFF_SET1[] = {  1.13535074806805220E-002,
                                             1.98598352260953950E-002,
                                            -2.61721179183327980E-007,
                                            -3.06144992424454780E-013,
                                            -5.28828335206980480E-015 };
//J TYPE T/C Segment Number: 3 from 1030.0000000000uV(20.21C) to 20460.0000000000uV(374.83C)
const FLOAT32 clsLLSlot::J_COEFF_SET2[] = {  1.65435622583975260E-001,
                                             1.96759697511699370E-002,
                                            -1.76641317022024960E-007,
                                             7.97751945739614400E-012,
                                            -1.27323294206093460E-016 };
//J TYPE T/C Segment Number: 4 from 20460.0000000000uV(374.83C) to 40710.0000000000uV(725.22C)
const FLOAT32 clsLLSlot::J_COEFF_SET3[] = {  6.83090142524482080E+001,
                                             8.74901516766694860E-003,
                                             4.88562274570928810E-007,
                                            -1.04417467043403530E-011,
                                             7.11754469159352980E-017 };
//J TYPE T/C Segment Number: 5 from 40710.0000000000uV(725.22C) to 54740.0000000000uV(946.45C)
const FLOAT32 clsLLSlot::J_COEFF_SET4[] = { -1.15442105601496540E+003,
                                             1.13043370512791310E-001,
                                            -2.81080770865706660E-006,
                                             3.52611825636707710E-011,
                                            -1.61312124534184950E-016 };
//J TYPE T/C Segment Number: 6 from 54740.0000000000uV(946.45C) to 69550.0000000000uV(1199.94C)
const FLOAT32 clsLLSlot::J_COEFF_SET5[] = {  1.93892600506231160E+003,
                                            -9.69580594534117930E-002,
                                             2.52643500996247030E-006,
                                            -2.49050466500328800E-011,
                                             9.24112882557700110E-017 };

//K TYPE T/C Segment Number: 1 from -5900.0000000000uV(-200.57C) to -4390.0000000000uV(-129.22C)
const FLOAT32 clsLLSlot::K_COEFF_SET0[] = { -8.92177560258824090E+002,
                                            -7.19454456424979960E-001,
                                            -2.34454102191807010E-004,
                                            -3.28113878679712870E-008,
                                            -1.75826689009500490E-012 };
//K TYPE T/C Segment Number: 2 from -4390.0000000000uV(-129.22C) to 120.0000000000uV(3.04C)
const FLOAT32 clsLLSlot::K_COEFF_SET1[] = { -1.10605455819896000E-002,
                                             2.52005090009401990E-002,
                                            -6.63408346560438360E-007,
                                            -4.74226046559569210E-011,
                                            -2.62950802592357400E-014 };
//K TYPE T/C Segment Number: 3 from 120.0000000000uV(3.04C) to 7390.0000000000uV(181.25c)
const FLOAT32 clsLLSlot::K_COEFF_SET2[] = { -5.76550468802076170E-002,
                                             2.55286020323433130E-002,
                                            -5.34264574962465480E-007,
                                             7.81551449901910080E-011,
                                            -3.24304720927834710E-015 };
//K TYPE T/C Segment Number: 4 from 7390.0000000000uV(181.25c) to 15950.0000000000uV(389.41C)
const FLOAT32 clsLLSlot::K_COEFF_SET3[] = { -9.59108054424247670E+000,
                                             2.59983971951745390E-002,
                                             5.40282439347601430E-008,
                                            -1.35032458534748660E-011,
                                             3.92382067977712910E-016 };
//K TYPE T/C Segment Number: 5 from 15950.0000000000uV(389.41C) to 43550.0000000000uV(1058.82C)
const FLOAT32 clsLLSlot::K_COEFF_SET4[] = { -2.18527558347884750E+001,
                                             2.90842841683011320E-002,
                                            -2.96559356087807350E-007,
                                             6.22507527924963840E-012,
                                            -3.82807841890674420E-017 };
//K TYPE T/C Segment Number: 6 from 43550.0000000000uV(1058.82C) to 54880.0000000000uV(1371.81C)
const FLOAT32 clsLLSlot::K_COEFF_SET5[] = { -6.98688653046794230E+002,
                                             8.03281455814631170E-002,
                                            -1.68725107654565850E-006,
                                             2.17688903150353730E-011,
                                            -9.41843570167859030E-017 };

//E TYPE T/C Segment Number: 1 from -8830.0000000000uV(-200.22C) to -6720.0000000000uV(-135.15C)
const FLOAT32 clsLLSlot::E_COEFF_SET0[] = { -6.32905404450387660E+002,
                                            -3.33078781071565410E-001,
                                            -7.32485751512888060E-005,
                                            -6.79677565323291140E-009,
                                            -2.42897784985820620E-013 };
//E TYPE T/C Segment Number: 2 from -6720.0000000000uV(-135.15C) to -930.0000000000uV(-16.09C)
const FLOAT32 clsLLSlot::E_COEFF_SET1[] = { -1.78326863258159050E-001,
                                             1.67086231449987310E-002,
                                            -4.72498635674809390E-007,
                                            -3.58954462457204780E-011,
                                            -5.99373678998937170E-015 };
//E TYPE T/C Segment Number: 3 from -930.0000000000uV(-16.09) to 20180.0000000000uV(288.99C)
const FLOAT32 clsLLSlot::E_COEFF_SET2[] = { -2.16591632083498740E-003,
                                             1.70539828070282760E-002,
                                            -2.31173315751847020E-007,
                                             6.33383940929738860E-012,
                                            -7.89039480362184520E-017 };
//E TYPE T/C Segment Number: 4 from 20180.0000000000uV(288.99C) to 66170.0000000000uV(866.09C)
const FLOAT32 clsLLSlot::E_COEFF_SET3[] = {  8.42065978977963430E+000,
                                             1.52966549190731140E-002,
                                            -9.02625402525974190E-008,
                                             1.14504170927725980E-012,
                                            -4.75018749551588610E-018 };
//E TYPE T/C Segment Number: 5 from 66170.0000000000uV(866.09C) to 76370.0000000000uV(999.96C)
const FLOAT32 clsLLSlot::E_COEFF_SET4[] = { -1.84650057042293540E+003,
                                             1.20900688392081180E-001,
                                            -2.33547943818221080E-006,
                                             2.22535279653548410E-011,
                                            -7.87103044811625910E-017 };

//T TYPE T/C Segment Number: 1 from -6010.0000000000uV(-230.3C) to -5130.0000000000uV(-173.09C)
const FLOAT32 clsLLSlot::T_COEFF_SET0[] = { -1.27825271430897190E+004,
                                            -9.47614727154809170E+000,
                                            -2.65296824726376710E-003,
                                            -3.29582058408168200E-007,
                                            -1.54217437370670380E-011 };
//T TYPE T/C Segment Number: 2 from -5130.0000000000uV(-173.09C) to -2020.0000000000uV(-55.98C)
const FLOAT32 clsLLSlot::T_COEFF_SET1[] = { -8.07250631377047870E+000,
                                             1.45403509353883260E-002,
                                            -6.63799488870291950E-006,
                                            -1.29856703787583990E-009,
                                            -1.31390471391359630E-013 };
//T TYPE T/C Segment Number: 3 from -2020.0000000000uV(-55.98C) to 4470.0000000000uV(104.08C)
const FLOAT32 clsLLSlot::T_COEFF_SET2[] = {  2.97945235157134410E-002,
                                             2.58784581480305740E-002,
                                            -7.63828576723525590E-007,
                                             6.00464354552880470E-011,
                                            -4.44093693067020570E-015 };
//T TYPE T/C Segment Number: 4 from 4470.0000000000uV(104.08C) to 20870.0000000000uV(399.97C)
const FLOAT32 clsLLSlot::T_COEFF_SET3[] = {  2.30508485673941710E+000,
                                             2.45917730058376710E-002,
                                            -4.60380874689007880E-007,
                                             1.27587285981034450E-011,
                                            -1.63727142853188040E-016 };

//B TYPE T/C Segment Number: 1 from 30.0000000000uV(96.36C) to 130.0000000000uV(173.97C)
const FLOAT32 clsLLSlot::B_COEFF_SET0[] = {  5.45992307696616310E+001,
                                             1.68883041955307120E+000,
                                            -1.16099358968468230E-002,
                                             6.21503496451529110E-005,
                                            -1.41899766883674080E-007 };
//B TYPE T/C Segment Number: 2 from 130.0000000000uV(173.97C) to 450.0000000000uV(306.28C)
const FLOAT32 clsLLSlot::B_COEFF_SET1[] = {  7.99574846073366960E+001,
                                             9.04907029411058830E-001,
                                            -1.69015057714431720E-003,
                                             2.47007692143254960E-006,
                                            -1.55452838415347220E-009 };
//B TYPE T/C Segment Number: 3 from 450.0000000000uV(306.28C) to 1280.0000000000uV(507.52C)
const FLOAT32 clsLLSlot::B_COEFF_SET2[] = {  1.22272105534472000E+002,
                                             5.24119163696616820E-001,
                                            -3.18531931589741370E-004,
                                             1.53952422784960910E-007,
                                            -3.22735006942212740E-011 };
//B TYPE T/C Segment Number: 4 from 1280.0000000000uV(507.52C) to 3160.0000000000uV(800.84C)
const FLOAT32 clsLLSlot::B_COEFF_SET3[] = {  1.83562969293202680E+002,
                                             3.30524994986902130E-001,
                                            -7.76646530157251460E-005,
                                             1.50708055917700800E-008,
                                            -1.27619191786428160E-012 };
//B TYPE T/C Segment Number: 5 from 3160.0000000000uV(800.84C) to 7290.0000000000uV(1248.03C)
const FLOAT32 clsLLSlot::B_COEFF_SET4[] = {  2.71778002132017430E+002,
                                             2.17475293508387620E-001,
                                            -2.05030289473182130E-005,
                                             1.65920150666076200E-009,
                                            -5.74936015826816990E-014 };
//B TYPE T/C Segment Number: 6 from 7290.0000000000uV(1248.03C) to 13820.0000000000uV(1819.98C)
const FLOAT32 clsLLSlot::B_COEFF_SET5[] = {  3.85274848390841900E+002,
                                             1.52322479588850760E-001,
                                            -6.06281555999801910E-006,
                                             2.01003972833264160E-010,
                                            -1.17933904374876600E-015 };

//S TYPE T/C Segment Number: 1 from 0.0000000000uV(0C) to 940.0000000000uV(138.7C)
const FLOAT32 clsLLSlot::S_COEFF_SET0[] = {  3.65414414686176800E-002,
                                             1.83617522223811250E-001,
                                            -6.63434467258597530E-005,
                                             4.19316470620177650E-008,
                                            -1.30257885085664480E-011 };
//S TYPE T/C Segment Number: 2 from 940.0000000000uV(138.7C) to 3480.0000000000uV(422.96C)
const FLOAT32 clsLLSlot::S_COEFF_SET1[] = {  8.01481593364703570E+000,
                                             1.53890667399949220E-001,
                                            -1.88726447711641790E-005,
                                             3.57440235732600070E-009,
                                            -2.91187879370899280E-013 };
//S TYPE T/C Segment Number: 3 from 3480.0000000000uV(422.96C) to 8900.0000000000uV(939.96C)
const FLOAT32 clsLLSlot::S_COEFF_SET2[] = {  4.29732545176711510E+001,
                                             1.15248107722635900E-001,
                                            -1.80394773302148860E-006,
                                             1.85749943033436530E-011,
                                             1.67431220779231400E-016 };
//S TYPE T/C Segment Number: 4 from 8900.0000000000uV(939.96C) to 17270.0000000000uV(1641.79C)
const FLOAT32 clsLLSlot::S_COEFF_SET3[] = { -1.64476230004524380E+001,
                                             1.35620622165937230E-001,
                                            -4.23938797180483730E-006,
                                             1.29509088355384420E-010,
                                            -9.73893187051826770E-016 };
//S TYPE T/C Segment Number: 5 from 17270.0000000000uV(1641.79C) to 17950.0000000000uV(1700.24C)
const FLOAT32 clsLLSlot::S_COEFF_SET4[] = { -6.81153434014709550E+003,
                                             1.28982712586512040E+000,
                                            -6.87717555781677640E-005,
                                             1.26919226361528260E-009,
                                             1.70867561718942700E-015 };

//R TYPE T/C Segment Number: 1 from 0.0000000000uV(0C) to 930.0000000000uV(136.37C)
const FLOAT32 clsLLSlot::R_COEFF_SET0[] = {  4.49054409037791260E-002,
                                             1.87210818100058430E-001,
                                            -7.64597479298262750E-005,
                                             5.02381168410082140E-008,
                                            -1.61634065089609490E-011 };
//R TYPE T/C Segment Number: 2 from 930.0000000000uV(136.37C) to 3500.0000000000uV(408.88C)
const FLOAT32 clsLLSlot::R_COEFF_SET1[] = {  8.97819621525579240E+000,
                                             1.53225848318800430E-001,
                                            -2.06818834751034600E-005,
                                             3.79494671165287610E-009,
                                            -3.05051011890756770E-013 };
//R TYPE T/C Segment Number: 3 from 3500.0000000000uV(408.88C) to 9740.0000000000uV(941.55C)
const FLOAT32 clsLLSlot::R_COEFF_SET2[] = {  4.50626330284994200E+001,
                                             1.13404895422409140E-001,
                                            -3.06072527556911900E-006,
                                             1.11672527872904500E-010,
                                            -2.32528171594228990E-015 };
//R TYPE T/C Segment Number: 4 from 9740.0000000000uV(941.55C) to 19520.0000000000uV(1648.56C)
const FLOAT32 clsLLSlot::R_COEFF_SET3[] = {  1.42737153828793030E+001,
                                             1.21462386274025090E-001,
                                            -3.61407979172566870E-006,
                                             1.02375444339413060E-010,
                                            -8.33885802514159460E-016 };
//R TYPE T/C Segment Number: 5 from 19520.0000000000uV(1648.56C) to 20230.0000000000uV(1700.62C)
const FLOAT32 clsLLSlot::R_COEFF_SET4[] = { -3.28830546466814670E+003,
                                             4.35583972867782610E-001,
                                            -3.63088542765380780E-007,
                                            -9.28384312509475540E-010,
                                             2.39534806708817900E-014 };

const FLOAT32 clsLLSlot::JR_COEFF_SET0[] ={  0.0768595,
                                             0.185029,
                                            -0.646992E-04,
                                             0.312839E-07,
                                            -0.672033E-11 };
//JAPAN R TYPE T/C  POLYNOMIAL COEFFICEINTS   200-400 oC
const FLOAT32 clsLLSlot::JR_COEFF_SET1[] ={ 11.9452,
                                             0.147953,
                                            -0.172254E-04,
                                             0.281948E-08,
                                            -0.204802E-12 };
//JAPAN R TYPE T/C   POLYNOMIAL COEFFICEINTS 400-1050 oC
const FLOAT32 clsLLSlot::JR_COEFF_SET2[] ={  4.5509556E+01,
                                             1.1284875E-01,
                                            -2.8603978E-06,
                                             8.5173702E-11,
                                            -1.1440038E-15 };
//JAPAN TYPE R T/C POLYNOMIAL COEFFICIENTS  1050 TO 1400 oC
const FLOAT32 clsLLSlot::JR_COEFF_SET3[] ={  7.33001,
                                             0.123987E+00,
                                            -0.393709E-05,
                                             0.120231E-09,
                                            -0.119247E-14 };
//JAPAN TYPE R T/C POLYNOMIAL COEFFICIENTS  1400 TO 1770 oC
const FLOAT32 clsLLSlot::JR_COEFF_SET4[] ={  3665.91,
                                            -0.694224,
                                             0.645961E-4,
                                            -0.242821E-8,
                                             0.343118E-13 };

//PT 100 OHM DIN RTD  POLYNOMIAL COEFFICEINTS  -200-0 oC
const FLOAT32 clsLLSlot::PTDIN_SET0[]   = { -241.773,
                                             0.220760E-02,
                                             0.301526E-08,
                                            -0.113419E-13,
                                             0.220445E-19 };

//PT 100 OHM DIN RTD  POLYNOMIAL COEFFICEINTS   0-300 oC
const FLOAT32 clsLLSlot::PTDIN_SET1[] =   { -246.121,
                                             0.236461E-02,
                                             0.982877E-09,
                                            -0.365307E-15,
                                             0.201745E-20 };

//PT 100 OHM DIN RTD  POLYNOMIAL COEFFICEINTS  300-850 oC
const FLOAT32 clsLLSlot::PTDIN_SET2[] =   { -241.813,
                                             0.229999E-02,
                                             0.132504E-08,
                                            -0.108666E-14,
                                             0.245641E-20 };

//PT 100 JIS POLYNOMIAL COEFFICIENTS  RANGE -200 TO 0 oC
const FLOAT32 clsLLSlot::PTJIS_SET0[] =   { -237.404,
                                             0.214186E-02,
                                             0.365448E-08,
                                            -0.172584E-13,
                                             0.392444E-19 };

//PT 100 JIS POLYNOMIAL COEFFICIENTS  RANGE 0 TO 300 oC
const FLOAT32 clsLLSlot::PTJIS_SET1[] =   { -241.641,
                                             0.231667E-02,
                                             0.102498E-08,
                                            -0.489978E-15,
                                             0.186215E-20 };

//PT 100 JIS POLYNOMIAL COEFFICIENTS  RANGE 300 TO 650 oC
const FLOAT32 clsLLSlot::PTJIS_SET2[] =   { -238.055,
                                             0.225328E-02,
                                             0.144704E-08,
                                            -0.174097E-14,
                                             0.326377E-20 };

//NI 120 OHM RTD  POLYNOMIAL COEFFICEINTS   -45 TO 110 oC
const FLOAT32 clsLLSlot::NIRTD_SET0[] =   { -188.416,
                                             0.155130E-02,
                                             0.225404E-08,
                                            -0.225913E-13,
                                             0.424983E-19 };

//NI 120 OHM RTD   POLYNOMIAL COEFFICEINTS   110-315 oC
const FLOAT32 clsLLSlot::NIRTD_SET1[] =   { -162.158,
                                             0.147965E-02,
                                            -0.556362E-09,
                                            -0.200283E-14,
                                             0.239475E-20 };

//CU 10 OHM  POLYNOMIAL COEFFICEINTS   -20 TO 250 oC
const FLOAT32 clsLLSlot::CURTD_SET0[] =   { -234.336,
                                             0.0259336,
                                            -0.402695E-14,
                                             0.203216E-18,
                                            -0.376112E-23 };

// TABLE OF COEFFICEINT SET POINTERS FOR J_TYPE
const FLOAT32 *clsLLSlot::J_TYPE[]    =   { J_COEFF_SET0,    //  -200 TO    0 DEGREES
                                            J_COEFF_SET1,    //     0 TO  400 DEGREES
                                            J_COEFF_SET2,    //   400 TO  760 DEGREES
                                            J_COEFF_SET3,    //   760 TO 1200 DEGREES
                                            J_COEFF_SET4,
                                            J_COEFF_SET5 };  

// TABLE OF COEFFICEINT SET POINTERS FOR K_TYPE
const FLOAT32 *clsLLSlot::K_TYPE[]    =   { K_COEFF_SET0,    //-200 TO -100  DEGREES
                                            K_COEFF_SET1,    //-100 TO    0  DEGREES
                                            K_COEFF_SET2,    //   0 TO  200  DEGREES
                                            K_COEFF_SET3,    // 200 TO  400  DEGREES
                                            K_COEFF_SET4,    // 400 TO 1370  DEGREES
                                            K_COEFF_SET5 };  

// TABLE OF COEFFICEINT SET POINTERS FOR E_TYPE
const FLOAT32 *clsLLSlot::E_TYPE[]    =   { E_COEFF_SET0,    //-200 TO -100  DEGREES
                                            E_COEFF_SET1,    //-100 TO    0  DEGREES
                                            E_COEFF_SET2,    //   0 TO  400  DEGREES
                                            E_COEFF_SET3,    // 400 TO 1000  DEGREES
                                            E_COEFF_SET4 };  

// TABLE OF COEFFICEINT SET POINTERS FOR T_TYPE
const FLOAT32 *clsLLSlot::T_TYPE[]    =   { T_COEFF_SET0,    //-230 TO -200  DEGREES
                                            T_COEFF_SET1,    //-200 TO -100  DEGREES
                                            T_COEFF_SET2,    //-100 TO    0  DEGREES
                                            T_COEFF_SET3 };  //   0 TO  400  DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR B_TYPE
const FLOAT32 *clsLLSlot::B_TYPE[]    =   { B_COEFF_SET0,    //100  TO 200   DEGREES
                                            B_COEFF_SET1,    //200  TO 400   DEGREES
                                            B_COEFF_SET2,    //400  TO 700   DEGREES
                                            B_COEFF_SET3,    //700  TO 1050  DEGREES
                                            B_COEFF_SET4,    //1050 TO 1650  DEGREES
                                            B_COEFF_SET5 };  //1650 TO 1820  DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR S_TYPE
const FLOAT32 *clsLLSlot::S_TYPE[]    =   { S_COEFF_SET0,    //   0 TO 200   DEGREES
                                            S_COEFF_SET1,    // 200 TO 400   DEGREES
                                            S_COEFF_SET2,    // 400 TO 1050  DEGREES
                                            S_COEFF_SET3,    //1050 TO 1400  DEGREES
                                            S_COEFF_SET4 };  //1400 TO 1700  DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR R_TYPE
const FLOAT32 *clsLLSlot::R_TYPE[]    =   { R_COEFF_SET0,    //   0 TO  200  DEGREES
                                            R_COEFF_SET1,    // 200 TO  400  DEGREES
                                            R_COEFF_SET2,    // 400 TO 1050  DEGREES
                                            R_COEFF_SET3,    //1050 TO 1400  DEGREES
                                            R_COEFF_SET4 };  //1400 TO 1700  DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR JR_TYPE
const FLOAT32 *clsLLSlot::JR_TYPE[]    =  { JR_COEFF_SET0,   //   0 TO 200   DEGREES
                                            JR_COEFF_SET1,   // 200 TO 400   DEGREES
                                            JR_COEFF_SET2,   // 400 TO 1050  DEGREES
                                            JR_COEFF_SET3,   //1050 TO 1400  DEGREES
                                            JR_COEFF_SET4 }; //1400 TO 1700  DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR PTDIN
const FLOAT32 *clsLLSlot::PTDIN[]    =    { PTDIN_SET0,      //-180 TO   0   DEGREES
                                            PTDIN_SET1,      //   0 TO 300   DEGREES
                                            PTDIN_SET2 };    // 300 TO 800   DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR PTJIS
const FLOAT32 *clsLLSlot::PTJIS[]    =    { PTJIS_SET0,      //-180 TO   0   DEGREES
                                            PTJIS_SET1,      //   0 TO 300   DEGREES
                                            PTJIS_SET2 };    // 300 TO 650   DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR NIRTD
const FLOAT32 *clsLLSlot::NIRTD[]    =    { NIRTD_SET0,      // -45 TO 110   DEGREES
                                            NIRTD_SET1 };    // 110 TO 315   DEGREES

// TABLE OF COEFFICEINT SET POINTERS FOR CURTD
const FLOAT32 *clsLLSlot::CURTD[]    =    { CURTD_SET0 };    // -20 TO 250   DEGREES


// TABLE OF THERMOCOUPLE TYPE POINTERS
const FLOAT32 **clsLLSlot::POLY_COEFF_SET[] = {
                                            J_TYPE,          //POINTER TO J COEFF SETS
                                            K_TYPE,          //POINTER TO K COEFF SETS
                                            E_TYPE,          //POINTER TO E COEFF SETS
                                            T_TYPE,          //POINTER TO T COEFF SETS
                                            B_TYPE,          //POINTER TO B COEFF SETS
                                            S_TYPE,          //POINTER TO S COEFF SETS
                                            R_TYPE,          //POINTER TO R COEFF SETS
                                            JR_TYPE,         //POINTER TO JR COEFF SETS
                                            PTDIN,           //POINTER TO PTDIN COEFF SETS
                                            PTJIS,           //POINTER TO PTJIS COEFF SETS
                                            NIRTD,           //POINTER TO NIRTD COEFF SETS
                                            CURTD };         //POINTER TO CURTD COEFF SETS

// J TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::J_BP[] = {     5.0,    //MAXIMUM OFFSET VALUE
                                    -7900.0,    // -200.44C
                                    -5720.0,    // -127.80C
                                     1030.0,    //   20.21C
                                    20460.0,    //  374.83C
                                    40710.0,    //  725.22C
                                    54740.0,    //  946.45C
                                    69550.0 };  // 1199.94C

// K TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::K_BP[] = {     5.0,    //MAXIMUM OFFSET VALUE
                                    -5900.0,    //-200.57C
                                    -4390.0,    //-129.22C
                                      120.0,    //   3.04C
                                     7390.0,    // 181.25C
                                    15950.0,    // 389.41C
                                    43550.0,    //1058.82C
                                    54880.0 };  //1371.81C

// E TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::E_BP[] = {     4.0,    //MAXIMUM OFFSET VALUE
                                    -8830.0,    //-200.22C
                                    -6720.0,    //-135.15C
                                     -930.0,    // -16.09C
                                    20180.0,    // 288.99C
                                    66170.0,    // 866.09C
                                    76370.0 };  // 999.96C

// T TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::T_BP[] = {     3.0,    //MAXIMUM OFFSET VALUE
                                    -6010.0,    //-230.03C
                                    -5130.0,    //-173.09C
                                    -2020.0,    // -55.98C
                                     4470.0,    // 104.08C
                                    20870.0 };  // 399.97C

// B TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::B_BP[] = {     5.0 ,   //MAXIMUM OFFSET VALUE
                                       30.0,    //  96.36C
                                      130.0,    // 173.97C
                                      450.0,    // 306.28C
                                     1280.0,    // 507.52C
                                     3160.0,    // 800.84C
                                     7290.0,    //1248.03C
                                    13820.0 };  //1819.98C

// S TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::S_BP[] = {     4.0,    //MAXIMUM OFFSET VALUE
                                        0.0,    //   0.0C
                                      940.0,    // 138.7C
                                     3480.0,    // 422.96C
                                     8900.0,    // 939.96C
                                    17270.0,    //1641.79C
                                    17950.0 };  //1700.24C

// R TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::R_BP[] = {     4.0,    //MAXIMUM OFFSET VALUE
                                        0.0,    //   0.0C
                                      930.0,    // 136.37C
                                     3500.0,    // 408.88C
                                     9740.0,    // 941.55C
                                    19520.0,    //1648.56C
                                    20230.0 };  //1700.62C

// JAPAN R TYPE T/C  POLYNOMIAL TABLE BREAKPOINTS (IN uV)
const FLOAT32 clsLLSlot::JR_BP[] = { 4.0 ,                   //MAXIMUM OFFSET VALUE
                                     0.0,                    //0oC    =  0.0
                                     1468.13,                //200oC  =  1468.13
                                     3407.19,                //400oC  =  3407.19
                                     11169.53,               //1050oC =  11169.53
                                     16034.71,               //1400oC =  16034.71
                                     21133.5 };              //1770oC =  21133.5

// PT 100 DIN  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHM)
const FLOAT32 clsLLSlot::PTD_BP[] ={ 2.0 ,                   //MAXIMUM OFFSET VALUE
                                     18490,                  //-200oC =  18490
                                     100000,                 //0oC    =  100000
                                     212020,                 //300oC  =  212020
                                     390260 };               //850oC  =  390260

// PT 100 JIS  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHM)
const FLOAT32 clsLLSlot::PTJ_BP[] ={ 2.0 ,                   //MAXIMUM OFFSET VALUE
                                     17140,                  //-200oC =  17140
                                     100000,                 //0oC    =  100000
                                     213930,                 //300oC  =  213930
                                     333450 };               //650oC  =  333450

// NI 120 OHM RTD  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHMS)
const FLOAT32 clsLLSlot::NI_BP[] = { 1.0 ,                   //MAXIMUM OFFSET VALUE
                                     89492,                  //-45oC  =  89492
                                     209850,                 //110oC  =  209850
                                     463135 };               //315oC  =  463135

// CU 10 OHM RTD  POLYNOMIAL COEFFICEINT BREAKPOINTS (IN mOHMS)
const FLOAT32 clsLLSlot::CU_BP[] = { 0.0 ,                   //MAXIMUM OFFSET VALUE
                                     8264.8,                 //-20oC  =  8264.8
                                     18676 };                //250oC  =  18676

const FLOAT32 *clsLLSlot::BP_POINTER_TAB[] = {
                                      J_BP,                  //POINT TO J T/C BP's
                                      K_BP,                  //POINT TO K T/C BP's
                                      E_BP,                  //POINT TO E T/C BP's
                                      T_BP,                  //POINT TO T T/C BP's
                                      B_BP,                  //POINT TO B T/C BP's
                                      S_BP,                  //POINT TO S T/C BP's
                                      R_BP,                  //POINT TO R T/C BP's
                                      JR_BP,                 //POINT TO JR T/C BP's
                                      PTD_BP,                //POINT TO PT DIN BP's
                                      PTJ_BP,                //POINT TO PT JIS BP's
                                      NI_BP,                 //POINT TO NI RTD BP's
                                      CU_BP };               //POINT TO CU RTD BP's

// Table for limits
const FLOAT32 clsLLSlot::EXTENDED_LIMITS_TABLE[TOTAL_SENSORTYPES][TOTAL_LIMIT_CONSTS] = { //TBD: Values subject to change
    {-100.0,  750.0, -200.0, 1200.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "J TYPE RANGE LIMITS"
    {   0.0, 1100.0, -200.0, 1370.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "K TYPE RANGE LIMITS"
    {-150.0,  500.0, -200.0, 1000.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "E TYPE RANGE LIMITS"
    {-200.0,  300.0, -230.0,  400.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "T TYPE RANGE LIMITS"
    { 600.0, 1650.0,  100.0, 1820.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "B TYPE RANGE LIMITS"
    { 550.0, 1500.0,    0.0, 1700.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "S TYPE RANGE LIMITS"
    { 550.0, 1500.0,    0.0, 1700.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "R TYPE RANGE LIMITS"
    { 550.0, 1500.0,    0.0, 1770.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "Japan R TYPE RANGE LIMITS"
    {-200.0,  850.0, -200.0,  850.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "PT Din TYPE RANGE LIMITS"
    {-200.0,  650.0, -200.0,  650.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "PT JIS TYPE RANGE LIMITS"
    { -45.0,  315.0,  -45.0,  315.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "NI RTD TYPE RANGE LIMITS"
    { -20.0,  250.0,  -20.0,  250.0},//oC LOW LIMIT,oC HIGH LIMIT, oC EXT LOW ,oC EXT HIGH "CU RTD TYPE RANGE LIMITS"
};

//check point struct for LLMUX channel
const UINT8  clsLLSlot::CheckPointVer1[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_SENSRTYP,
    PARAMID_PVCHAR,
    PARAMID_PVTEMP,
    PARAMID_TCRNGOPT,
    PARAMID_PVRAWHI,
    PARAMID_PVRAWLO,
    PARAMID_INPTDIR,
    PARAMID_PVEUHI,
    PARAMID_PVEULO,
    PARAMID_PVEXEUHI,
    PARAMID_PVEXEULO,
    PARAMID_PVCLAMP,
    PARAMID_LOCUTOFF,
    PARAMID_PVSRCOPT,
    PARAMID_PVSOURCE,
    PARAMID_TF,
    PARAMID_PVTV,
    PARAMID_OWDENABLE,
    PARAMID_PTEXECST,
    0 // Terminator
};

const CHECKPOINT_VER_TABLE clsLLSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 48 }
};

UINT8 clsLLSlot::SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;

const SLOTPARAMINFO clsLLSlot::tblParamInfo[] = { // Build paraminfo table

    //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //0
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //1
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //2
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //3
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //4
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //5
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //6
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //7
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //8
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //9
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //50
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //51                                      
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadPvFlPtr,FALSE,                             //52 BadPvFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //53
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //54
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //55
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,PreInptDir,0,GetInptDirPtr,TRUE,                  //56 InptDir
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastPvPtr,FALSE,                           //57 LastPv
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreLoCutOff,0,GetLoCutOffPtr,TRUE,                 //58 LoCutOff
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //59
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePntType,PostPntType,GetPntTypePtr,TRUE,            //60 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PrePtExecSt,PostPtExecSt,GetPtExecStPtr,TRUE,        //61 PtExecSt
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //62
    DT_FLOAT32,4,AT_BXREC,ALCK_OPER,CONTROLSTATE_NONE,PrePv,PostPv,GetPvPtr,TRUE,                       //63 Pv
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //64
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoPtr,FALSE,                           //65 PvAuto
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvAutoStPtr,FALSE,                            //66 PvAutoSt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvCalcPtr,FALSE,                           //67 PvCalc
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,PrePvChar,PostPvChar,GetPvCharPtr,TRUE,           //68 PvChar
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,0,0,GetPvClampPtr,TRUE,                           //69 PvClamp
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,PrePvEUHi,PostPvEUHi,GetPvEUHiPtr,TRUE,       //70 PvEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVE,PrePvEULo,PostPvEUHi,GetPvEULoPtr,TRUE,       //71 PvEULo : PostPvEULo is same as PostPvEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PrePvExEUHi,PostPvExEUHi,GetPvExEUHiPtr,TRUE,     //72 PvExEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PrePvExEULo,PostPvExEULo,GetPvExEULoPtr,TRUE,     //73 PvExEULo
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvExHiFlPtr,FALSE,                            //74 PvExHiFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvExLoFlPtr,FALSE,                            //75 PvExLoFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //76
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //77
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //78
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //79
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //80
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //81
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //82
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //83
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //84
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvPPtr,FALSE,                              //85 PvP
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvRawPtr,FALSE,                            //86 PvRaw
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,PrePvRawHI,PostPvRawHI,GetPvRawHIPtr,TRUE,     //87 PvRawHI
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,PrePvRawLO,PostPvRawHI,GetPvRawLOPtr,TRUE,     //88 PvRawLO : PostPvRawLo is same as PostPvRawHi
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //89
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //90
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //91
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //92
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePvSource,PostPvSource,GetPvSourcePtr,TRUE,        //93 PvSource
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,PostPvSrcOpt,GetPvSrcOptPtr,TRUE,                  //94 PvSrcOpt
    DT_ENUM,1,AT_BXREC,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvStsPtr,FALSE,                               //95 PvSts
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,PrePvTemp,PostPvTemp,GetPvTempPtr,TRUE,           //96 PvTemp
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PrePvTv,PostPvTv,GetPvTvPtr,TRUE,                 //97 PvTv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvTvPPtr,TRUE,                             //98 PvTvP
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,PreSensrTyp,PostSensrTyp,GetSensrTypPtr,TRUE,     //99 SensrTyp
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,                           //100 SlotSFBt
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //101 
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreTcRngOpt,PostPvChar,GetTcRngOptPtr,TRUE,           //102 TcRngOpt
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PreTf,PostTf,GetTfPtr,TRUE,                       //103 Tf
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //104
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //105
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //106 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //107 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //109
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //110
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //111
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //112
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //113
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //114
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //116
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //117
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //118
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetFiltOutPtr,FALSE,                          //119 FiltOut
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //121 
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfLrsPtr,FALSE,                          //122 SlotSFLRS
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //123
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvRawIntPtr,FALSE,                         //124 PvRawInt
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreFreq6050,PostFreq6050,GetFreq6050Ptr,TRUE,        //125 Freq6050
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //126
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //127
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //128
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //132
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //133
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //141
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //142
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,PreOwdEnable,0,GetOwdEnablePtr,TRUE,              //143 OwdEnable
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //149
    DT_BLIND,48,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,TRUE,              //150 Checkpoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //243
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //244
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,                  //245 SlotChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //246
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetEUSpanPtr,FALSE,                           //247 EUSpan
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetKfPtr,FALSE,                               //248 Kf
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetRawSpanPtr,FALSE,                          //249 RawSpan
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          //254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE                                           //255
};
/*******************************************************************************
*                           clsLLSlot::operator new                            *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsLLSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return (ucIomDbMemory + LLMUXBOXSLOT_SIZE + (a_ucSltNm * LLMUXSLOT_SIZE));
}
/*******************************************************************************
*                            clsLLSlot::clsLLSlot                              *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsLLSlot::clsLLSlot(UINT8 a_ucSltNm) : clsAixSlot(a_ucSltNm) {
    PvRawHI     = NaN;
    PvRawLO     = NaN;
    PvRawInt    = NaN;
    SensrTyp    = SENSRTYP_THERMCPL;
    TcRngOpt    = TCRNGOPT_NORM;
    InptDir     = INPTDIR_DIRECT;
    PntType     = PNTTYPE_ANALOGINPUT;
    RawSpan     = NaN;
    Freq6050    = FREQ6050_SIXTYHZ;
    PvTemp      = PVTEMP_DEG_C;
    PvChar      = PVCHAR_JTHERM;
    if(PVSOURCE_MANUAL != PvSource) {
        BOX->SetPv(ChanNum,NaN);
        BOX->SetPvSts(ChanNum,PVVALST_BAD);
    }
}
/*******************************************************************************
*                            clsLLSlot::GetDataType                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsLLSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsLLSlot::GetAccessType                            *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsLLSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                            clsLLSlot::GetParamSize                           *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsLLSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                            clsLLSlot::GetParamPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsLLSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                           clsLLSlot::GetAccessLock                           *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsLLSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                       clsLLSlot::GetIsDbChecksumed                           *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsLLSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                         clsLLSlot::VerifyControlState                        *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsLLSlot::ExecutePreFunction                        *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsLLSlot::ExecutePostFunction                       *
*                         ===============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                               clsLLSlot::InitSlot                            *
*                               ====================                           *
* PURPOSE:  Method which initializes the slot database parameters              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the parameter                  *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*           The function calls the Init function for each class in the slot    *
*           hierarchy.                                                         *
*******************************************************************************/
VOID clsLLSlot::InitSlot(INIT_TYPE eInit) {
    if(WARM_INIT == eInit) {
        PvAuto   = NaN;
        PvAutoSt = PVVALST_BAD;
        PvCalc   = NaN;
        PvRaw    = NaN;
        LastPv   = NaN;
        FiltOut  = NaN;
        BadPvFl  = FALSE;
        PvRawInt = NaN;
        if (PvSource != PVSOURCE_MANUAL) {
            BOX->SetPv(ChanNum,NaN);
            BOX->SetPvSts(ChanNum,PVVALST_BAD);
            PvP   = NaN;
            PvExHiFl = FALSE;
            PvExLoFl = FALSE;
        }
    }
    else {
        BadPvFl  = FALSE;
        if((PTBD_INIT == eInit) && (PVSOURCE_MANUAL == PvSource)) { }
        else {
            PvP      = NaN;
            PvSrcOpt = PVSRCOPT_ONLYAUTO;
            PvSource = PVSOURCE_AUTO;
            BOX->SetPv(ChanNum,NaN);
            BOX->SetPvSts(ChanNum,PVVALST_BAD);
        }
        InitAixSlot(FALSE,TRUE);
        PtExecSt  = PTEXECST_INACTIVE;
        PvClamp   = PVCLAMP_NOCLAMP;
        PvTemp    = PVTEMP_DEG_C;
        LoCutOff  = NaN;
        PvChar    = PVCHAR_JTHERM;
        PvRawInt  = NaN;
        TcRngOpt  = TCRNGOPT_NORM;
        InptDir   = INPTDIR_DIRECT;
        PntType   = PNTTYPE_ANALOGINPUT;
        SensrTyp  = SENSRTYP_THERMCPL;
        PvRawHI   = NaN;
        PvRawLO   = NaN;
        Freq6050  = FREQ6050_SIXTYHZ;
    }

    // Recompute SLOT checksum
    ComputeCheckSum();
}
/*******************************************************************************
*                               clsLLSlot::ConvTempUnit                        *
*                               =======================                        *
* PURPOSE:  Convert the temeperature value from degree celsius to the          *
            unit specified by PvTemp parameter                                 *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the parameter                  *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
FLOAT32 clsLLSlot::ConvTempUnit(FLOAT32 rTemp) {
    switch (PvTemp) {
    case PVTEMP_DEG_C:
        return rTemp;
    case PVTEMP_DEG_F:
        return (FARENHEIT_CONV_OFFSET + (rTemp * FARENHEIT_CONV_NUM / FARENHEIT_CONV_DEN));
    case PVTEMP_DEG_R:
        return (RANKINE_CONV_OFFSET + (rTemp * RANKINE_CONV_NUM / RANKINE_CONV_DEN));
    case PVTEMP_DEG_K:
        return (KELVIN_CONV_OFFSET + rTemp);
    default:
        return NaN;
    }
}
/*******************************************************************************
*                               clsLLSlot::DefaultExtendedEULimits             *
*                               =============================                  *
* PURPOSE:  Assigns default extended engineering units as per MTL specs        *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the parameter                  *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*           Assigns default extended engineering units as per MTL specs        *
*******************************************************************************/
VOID clsLLSlot::DefaultExtendedEULimits(UINT8 a_ucAccLvl) {
    //Point to correct column offset in the extended limits table
    UINT8 ucLoLimitOffset = (TCRNGOPT_EXTENDED == TcRngOpt) ? 2 : 0;
    UINT8 ucHiLimitOffset = (TCRNGOPT_EXTENDED == TcRngOpt) ? 3 : 1;
    //Assign default value to PvExEULo and call its post function
    PvExEULo = ConvTempUnit(EXTENDED_LIMITS_TABLE[PvChar][ucLoLimitOffset]);
    PostPvExEULo(a_ucAccLvl);
    //Assign default value to PvExEUHi and call its post function
    PvExEUHi = ConvTempUnit(EXTENDED_LIMITS_TABLE[PvChar][ucHiLimitOffset]);
    PostPvExEUHi(a_ucAccLvl);
}
/*******************************************************************************
*                          clsLLSlot::PreInptDir                               *
*                          ======================                              *
* PURPOSE:  Pre Receiver-Beware function for InptDir parameter.                *
*           This method checks for range of the data, access level, and valid  *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PreInptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if ((a_ucAccLvl != ALVL_IUSER) || (*(INPTDIR *) a_Writebuffer != InptDir))
        if (PvChar != PVCHAR_LINEAR) return DO_PARAMETER_INVALID;
    return PA_OK;
}
/*******************************************************************************
*                          clsLLSlot::PreLoCutOff                              *
*                          =======================                             *
* PURPOSE:  Pre Receiver-Beware function for LoCutOff parameter.               *
*           This method checks for a valid data range, access level, and valid *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the preLoCutOff parameter      *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PreLoCutOff(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    FLOAT32 NewVal = *(FLOAT32*) a_Writebuffer;

    if (!RealCompare(NewVal, LoCutOff)) {
        if (PvChar != PVCHAR_LINEAR)
            return DO_PARAMETER_INVALID;

        if ( !isnan(NewVal) ) {
            if ((NewVal < (FLOAT32)0.0) && (a_ucAccLvl != ALVL_IUSER))
                return DO_LIMIT_OR_RANGE_EXCEEDED;
            else {
                if ((!isnan(PvEUHi)) && (NewVal > PvEUHi))
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
                if ((!isnan(PvEULo)) && (NewVal < PvEULo))
                    return DO_LIMIT_OR_RANGE_EXCEEDED;
            }
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PrePntType                             *
*                            ======================                            *
* PURPOSE:  Pre Receiver-Beware function for PntType parameter.                *
*           This method checks for range of the data that can be written to    *
*           PntType parameter, access level check, module status check, point  *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    this->ScratchPad = *(UINT8 *) a_Writebuffer;

    UINT8 MdSts = BOX->GetModuleStatus();
    
    if(TRUE == BOX->GetCalibFta((ChanNum-1) / MAXSLOTS_PER_FTA)) {
        return DO_CALIB_IN_PROGRESS;
    }

    if ((a_ucAccLvl == ALVL_IUSER) && (MdSts != MODSTATUS_IDLE)) {
        return DO_STATE_MUST_BE_IDLE;
    }

    if ((MdSts != MODSTATUS_IDLE) && (PtExecSt != PTEXECST_INACTIVE)) {
        return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
    }

    if (((PNTTYPE)ScratchPad != PNTTYPE_ANALOGINPUT) &&
        ((PNTTYPE)ScratchPad != PNTTYPE_NOTCONFIGURED)) {
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PostPntType                            *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
*           (1) Checks for valid range and access level.                       *
*           (2) Calls Point-Build initialization.                              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesful  completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPntType(UINT8 a_ucAccLvl) {
    if (a_ucAccLvl == ALVL_IUSER) {
        InitSlot(COLD_INIT);
    }
    else {
        if(PNTTYPE_NOTCONFIGURED == (PNTTYPE)ScratchPad) {
            UINT8 FtaNum = (ChanNum-1) / MAXSLOTS_PER_FTA;
            //If the point is deleted, SFs for the same should also go.
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FTAMSMCH,FALSE,ChanNum);
            if(0 == BOX->GetPointBuildStatus(FtaNum)) {
                //All the points of this FTA are gone. Return from SF if any for this FTA
                for(UINT8 Sf = SF_FTAFAIL; Sf <= SF_FCAL_FL; Sf++)
                    BOX->IssueSfToFta(FtaNum, Sf, FALSE);
            }
            InitSlot(COLD_INIT);
        }
        else {
            InitSlot(PTBD_INIT);
        }
    }
}
/*******************************************************************************
*                            clsLLSlot::PrePtExecSt                            *
*                            =======================                           *
* PURPOSE:   Pre Receiver-Beware function for PtExecSt parameter.              *
*            Validates some pre conditions before the new PtExecSt parameter   *
*            can be written to database.                                       *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePtExecSt(UINT8 *a_Writebuffer, UINT8) {
    PTEXECST NewStatus = *(PTEXECST *)a_Writebuffer;
    PASTATUS RetVal = PA_OK;
    UINT8 ucExpectedFtaType = (SENSRTYP_RTD == SensrTyp) ? FTATYPE_RTD : FTATYPE_TC;
    if(TRUE == BOX->GetCalibFta((ChanNum-1) / MAXSLOTS_PER_FTA))
        return DO_CALIB_IN_PROGRESS;
    // Save in ScratchPad for use in post function.
    ScratchPad = PtExecSt;
    if(PtExecSt != NewStatus) {
        if (PTEXECST_ACTIVE == NewStatus) {
            if(FTATYPE_NULL != BOX->GetFtaType((ChanNum-1) / MAXSLOTS_PER_FTA)) {
                if(ucExpectedFtaType != BOX->GetFtaType((ChanNum-1) / MAXSLOTS_PER_FTA)) {
                    RetVal = DO_CONFIGURATION_MISMATCH_ERROR;
                }
                else {
                    RetVal = EULimitCheck();
                }
            }
            else {
                RetVal = EULimitCheck();
            }
        }
    }
    return RetVal;
}
/*******************************************************************************
*                            clsLLSlot::EULimitCheck                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::EULimitCheck(VOID) {
    if(isnan(PvExEULo) || isnan(PvExEUHi) || isnan(PvEUHi) || isnan(PvEULo))
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if(SENSRTYP_0to100_MV == SensrTyp)
        if(isnan(PvRawLO) || isnan(PvRawHI))
            return DO_CONFIGURATION_MISMATCH_ERROR;
    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PostPtExecSt                           *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPtExecSt(UINT8) {
    UINT8 FtaNum = (ChanNum-1) / MAXSLOTS_PER_FTA;
    if (PTEXECST_INACTIVE == PtExecSt) {
        InitSlot(WARM_INIT);
    }
    if(ScratchPad != PtExecSt) {
        BOX->UpdatePointBuildTable(ChanNum,PTEXECST_INACTIVE != PtExecSt);
        if(PTEXECST_INACTIVE == PtExecSt) {
            if(FTATYPE_NULL != BOX->GetFtaType(FtaNum))
                BOX->SubmitReqToFifo(FtaNum,REQ_DECONFIGPOINT,((ChanNum-1)%MAXSLOTS_PER_FTA)+1);
        }
        else {
            InitFlg = TRUE;
            if(FTATYPE_NULL != BOX->GetFtaType(FtaNum))
                BOX->SubmitReqToFifo(FtaNum,REQ_LOADCONFIGDATA,((ChanNum-1)%MAXSLOTS_PER_FTA)+1);
        }
    }
}
/*******************************************************************************
*                            clsLLSlot::PrePvChar                              *
*                            =====================                             *
* PURPOSE:   Pre Receiver-Beware function for PvChar parameter.                *
*            Validates some pre conditions before the new PvChar parameter     *
*            can be written to database.                                       *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePvChar(UINT8 *a_Writebuffer, UINT8) {
    PVCHAR NewVal = *(PVCHAR *) a_Writebuffer;
    if(TRUE == BOX->GetCalibFta((ChanNum-1) / MAXSLOTS_PER_FTA))
        return DO_CALIB_IN_PROGRESS;

    if((NewVal >= PVCHAR_JTHERM) && (NewVal <= PVCHAR_RPTHERM)) {
      if(SENSRTYP_THERMCPL != SensrTyp)
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    else if((NewVal >= PVCHAR_DINRTD) && (NewVal <= PVCHAR_COPPRRTD)) {
      if(SENSRTYP_RTD != SensrTyp)
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    else if(PVCHAR_LINEAR == NewVal) {
      if(SENSRTYP_0to100_MV != SensrTyp)
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    else {
      return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PostPvChar                             *
*                            ========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPvChar(UINT8 a_ucAccLvl) {
    if((SENSRTYP_RTD == SensrTyp) || (SENSRTYP_THERMCPL == SensrTyp)) {
        DefaultExtendedEULimits(a_ucAccLvl);
    }
}
/*******************************************************************************
*                            clsLLSlot::PostPvEUHi                             *
*                            =====================                             *
* PURPOSE:  Post Receiver-Beware function for PvEUHi parameter.                *
*           (1) TO DO                                                          *
*           (2) TO DO                                                          *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPvEUHi(UINT8) {
    // Force result of floating point operation to QNaN, if any of 
    // the operands is NaN. Otherwise it will result in SNaN.
    if (isnan(PvEUHi) || isnan(PvEULo)) {
        EUSpan = NaN;
        EUSpanDivHundred = NaN;
        HundredDivEUSpan = NaN;
    }
    else {
        EUSpan = PvEUHi - PvEULo;
        EUSpanDivHundred = EUSpan / (FLOAT32)100.0;
        HundredDivEUSpan = (FLOAT32)100.0 / EUSpan;
    }
}
/*******************************************************************************
*                          clsLLSlot::PrePvExEUHi                              *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvExEUHi parameter.              *
*            Validates some pre conditions before the new PvExEUHi value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePvExEUHi(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    FLOAT32 NewVal = *(FLOAT32 *) a_Writebuffer;
    if (!RealCompare(NewVal,PvExEUHi)) {
        if (((SensrTyp == SENSRTYP_THERMCPL) || (SensrTyp == SENSRTYP_RTD)) &&
            (a_ucAccLvl != ALVL_IUSER))
            return DO_READ_ONLY_PARAMETER;
        if ((SensrTyp == SENSRTYP_0to100_MV) && (a_ucAccLvl != ALVL_IUSER) && 
            (PTEXECST_INACTIVE != PtExecSt))
            return DO_POINT_MUST_BE_INACTIVE;
        if(isnan(NewVal))
            return DO_ILLEGAL_VALUE;
        if((!isnan(PvEUHi)) && (NewVal < PvEUHi))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        if((!isnan(PvTv)) && (NewVal < PvTv))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        if (!isnan(PvExEULo))
            NewVal = ((FLOAT32) 7.5) * fabs(NewVal - PvExEULo);
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsLLSlot::PostPvExEUHi                            *
*                           =======================                            *
* PURPOSE:  Post Receiver-Beware function for PvExEUHi parameter.              *
*           Check current PV value and set PvExHiFl if necessary.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PvExEUHi parameter         *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPvExEUHi(UINT8) {
    FLOAT32 fCurPv = BOX->GetPv(ChanNum);

    if (!isnan(fCurPv)) {
        if (fCurPv >= PvExEUHi) {
            PvExHiFl = TRUE;
            BOX->SetPv(ChanNum,PvExEUHi);
        }
        else
            PvExHiFl = FALSE;
    }
}
/*******************************************************************************
*                          clsLLSlot::PrePvExEULo                              *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvExEULo parameter.              *
*            Validates some pre conditions before the new PvExEULo value can   *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePvExEULo(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    FLOAT32 NewVal = *(FLOAT32 *) a_Writebuffer;
    if (!RealCompare(NewVal,PvExEULo)) {
        if (((SensrTyp == SENSRTYP_THERMCPL) || (SensrTyp == SENSRTYP_RTD)) &&
            (a_ucAccLvl != ALVL_IUSER))
            return DO_READ_ONLY_PARAMETER;
        if ((SensrTyp == SENSRTYP_0to100_MV) && (a_ucAccLvl != ALVL_IUSER) && 
            (PTEXECST_INACTIVE != PtExecSt))
            return DO_POINT_MUST_BE_INACTIVE;
        if(isnan(NewVal))
            return DO_ILLEGAL_VALUE;
        if((!isnan(PvEULo)) && (NewVal > PvEULo))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        if((!isnan(PvTv)) && (NewVal > PvTv))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsLLSlot::PostPvExEULo                            *
*                           =======================                            *
* PURPOSE:  Post Receiver-Beware function for PvExEULo parameter.              *
*           Check current PV value and set PvExLoFl if necessary.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PvExEULo parameter         *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPvExEULo(UINT8) {
    FLOAT32 fCurPv = BOX->GetPv(ChanNum);

    if (!isnan(fCurPv)) {
        if (fCurPv <= PvExEULo) {
            PvExLoFl = TRUE;
            BOX->SetPv(ChanNum,PvExEULo);
        }
        else
            PvExLoFl = FALSE;
    }
}
/*******************************************************************************
*                          clsLLSlot::PrePvRawHI                               *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvRawHI parameter.               *
*            Validates some pre conditions before the new PvRawHI value can    *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePvRawHI(UINT8* a_Writebuffer, UINT8) {
    FLOAT32 NewVal = *(FLOAT32 *) a_Writebuffer;
    if (!RealCompare(NewVal,PvRawHI)) {
        if(SENSRTYP_0to100_MV != SensrTyp)
            return DO_READ_ONLY_PARAMETER;
        else {
            if(isnan(NewVal))
                return DO_ILLEGAL_VALUE;
            if((!isnan(PvRawLO)) && (NewVal < PvRawLO))
                return DO_LIMIT_OR_RANGE_CROSSOVER;
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PostPvRawHI                            *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvRawHI parameter.               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesful  completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPvRawHI(UINT8) {
    RawSpan = (!isnan(PvRawHI) && !isnan(PvRawLO)) ? PvRawHI - PvRawLO : NaN;
}
/*******************************************************************************
*                          clsLLSlot::PrePvRawLO                               *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvRawLO parameter.               *
*            Validates some pre conditions before the new PvRawLO value can    *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePvRawLO(UINT8* a_Writebuffer, UINT8 ) {
    FLOAT32 NewVal = *(FLOAT32 *) a_Writebuffer;
    if (!RealCompare(NewVal,PvRawLO)) {
        if(SENSRTYP_0to100_MV != SensrTyp)
            return DO_READ_ONLY_PARAMETER;
        if(isnan(NewVal))
            return DO_ILLEGAL_VALUE;
        if((!isnan(PvRawHI)) && (NewVal > PvRawHI))
            return DO_LIMIT_OR_RANGE_CROSSOVER;
        if(NewVal < (FLOAT32)0.0 )
            return DO_LIMIT_OR_RANGE_EXCEEDED;
    }
    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PostPvSrcOpt                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvSrcOpt parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesful  completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPvSrcOpt(UINT8) {
    if (PvSrcOpt == PVSRCOPT_ONLYAUTO) {
        PvSource = PVSOURCE_AUTO;
        if ((PtExecSt == PTEXECST_INACTIVE) || 
            (MODSTATUS_IDLE == BOX->GetModuleStatus())) {
            BOX->SetPv(ChanNum,NaN);
            BOX->SetPvSts(ChanNum,PVVALST_BAD);
            PvP = NaN;
        }
    }
}
/*******************************************************************************
*                          clsLLSlot::PrePvTemp                                *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for PvTemp parameter.                *
*            Validates some pre conditions before the new PvTemp value can     *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PrePvTemp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PVTEMP NewVal = *(PVTEMP *)a_Writebuffer;
    if(TRUE == BOX->GetCalibFta((ChanNum-1) / MAXSLOTS_PER_FTA))
        return DO_CALIB_IN_PROGRESS;
    if((ALVL_IUSER != a_ucAccLvl) || (NewVal != PvTemp)) {
        return (PvChar < PVCHAR_LINEAR) ? PA_OK : DO_PARAMETER_INVALID;
    }
    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PostPvTemp                             *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for PvTemp parameter.                *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesful  completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostPvTemp(UINT8 a_ucAccLvl) {
    if(PvChar < PVCHAR_LINEAR) DefaultExtendedEULimits(a_ucAccLvl);
}
/*******************************************************************************
*                          clsLLSlot::PreSensrTyp                              *
*                          =======================                             *
* PURPOSE:   Pre Receiver-Beware function for SensrTyp parameter.              *
*            Validates some pre conditions before the new PvTemp value can     *
*            be written to database.                                           *
* ARGUMENTS:                                                                   *
*            a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*            PA_OK          -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PreSensrTyp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    SENSRTYP NewVal  = *(SENSRTYP *) a_Writebuffer;
    UINT8 NewFtaType = FTATYPE_NULL;
    if(TRUE == BOX->GetCalibFta((ChanNum-1) / MAXSLOTS_PER_FTA))
        return DO_CALIB_IN_PROGRESS;
    //TBD: Check !!
    if(((ALVL_IUSER == a_ucAccLvl) && (NewVal != SensrTyp)) || 
        (ALVL_IUSER != a_ucAccLvl)) {
        if((NewVal > SENSRTYP_RTD) || (NewVal < SENSRTYP_0to100_MV))
            return DO_ILLEGAL_VALUE;
        NewFtaType = (SENSRTYP_RTD == NewVal) ? FTATYPE_RTD : FTATYPE_TC;
        if(FTATYPE_NULL != BOX->GetFtaType((ChanNum-1) / MAXSLOTS_PER_FTA))
            if(NewFtaType != BOX->GetFtaType((ChanNum-1) / MAXSLOTS_PER_FTA))
                return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    return PA_OK;
}
/*******************************************************************************
*                            clsLLSlot::PostSensrTyp                           *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for SensrTyp parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PV parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesful  completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostSensrTyp(UINT8 a_ucAccLvl) {
    if(SENSRTYP_THERMCPL == SensrTyp ){
        PvChar = PVCHAR_JTHERM ;
        DefaultExtendedEULimits(a_ucAccLvl);
    }
    else if(SENSRTYP_RTD == SensrTyp ){
        PvChar = PVCHAR_DINRTD ;
        DefaultExtendedEULimits(a_ucAccLvl);
    }
    else PvChar = PVCHAR_LINEAR;
}
/*******************************************************************************
*                            clsLLSlot::PostTf                                 *
*                            =======================                           *
* PURPOSE:  Post Receiver-Beware function for Tf parameter.                    *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Parameter Access level                         *
* RETURN:                                                                      *
*           PA_OK           -   On succesful  completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::PostTf(UINT8) {
    FLOAT32 Ts = (FLOAT32) 1.0 ;//Sample time for LLMUX is 1 sec.
    Kf = Ts / (Ts + (Tf * (FLOAT32) 60.0));
}
/*******************************************************************************
*                          clsLLSlot::PreOwdEnable                             *
*                          =======================                             *
* PURPOSE:  Pre Receiver-Beware function for PiuOTDEn parameter.               *
*           This method checks for range of the data, access level, and valid  *
*           PvChar.                                                            *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PreOwdEnable(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if ((a_ucAccLvl != ALVL_IUSER) && (*(BOOL *)a_Writebuffer != OwdEnable)) {
        if (SENSRTYP_RTD == SensrTyp)
            return DO_PARAMETER_INVALID;
    }
    return PA_OK;
}
/*******************************************************************************
*                          clsLLSlot::PreTcRngOpt                              *
*                          ======================                              *
* PURPOSE:  Pre Receiver-Beware function for TcRngOpt parameter.               *
*           This method checks for range of the data, access level, and valid  *
*           TcRngOpt                                                           *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PreTcRngOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if(TRUE == BOX->GetCalibFta((ChanNum-1) / MAXSLOTS_PER_FTA))
        return DO_CALIB_IN_PROGRESS;
    if ((a_ucAccLvl != ALVL_IUSER) || (*(BOOL *)a_Writebuffer != TcRngOpt))
        if(SENSRTYP_THERMCPL != SensrTyp)
            return DO_PARAMETER_INVALID;
    return PA_OK;
}
/*******************************************************************************
*                          clsLLSlot::PreFreq6050                              *
*                          ======================                              *
* PURPOSE:  Pre Receiver-Beware function for Freq6050 parameter.               *
*           This method checks for range of the data, access level, and valid  *
*           Freq6050                                                           *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesful                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsLLSlot::PreFreq6050(UINT8 *a_Writebuffer, UINT8 ) {
    ScratchPad = (UINT8)Freq6050;
    if(*(FREQ6050*)a_Writebuffer != Freq6050){
        if(BOX->GetModuleStatus() != MODSTATUS_IDLE)
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
    }
    return PA_OK;
}
/*******************************************************************************
*                          clsLLSlot::PostFreq6050                             *
*                          =======================                             *
* PURPOSE:  Post Receiver-Beware function for Freq6050 parameter.              *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If pre check is succesful                      *
* NOTES:                                                                       *
*           .                                                                  *
*******************************************************************************/
VOID clsLLSlot::PostFreq6050(UINT8) {
  if(1 == ChanNum) BOX->SetFreq6050(Freq6050);
}
/*******************************************************************************
*                           clsLLSlot::ProcessInput                            *
*                           =======================                            *
* PURPOSE: Slot point processing                                               *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::ProcessInput(VOID) {
    if(PTEXECST_ACTIVE == PtExecSt) {
        // If (FTA type is null).OR.(sensortype matches fta type) then
        // return fta config mismatch slot soft failure to normal
        UINT8 ucFtaType = BOX->GetFtaType((ChanNum-1) / MAXSLOTS_PER_FTA);
        UINT8 ucExpectedFtaType = (SENSRTYP_RTD == SensrTyp) ? FTATYPE_RTD : FTATYPE_TC;
        if((FTATYPE_NULL == ucFtaType) || (ucExpectedFtaType == ucFtaType)) {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FTAMSMCH,FALSE,ChanNum);
        }
        if(MODSTATUS_RUN == BOX->GetModuleStatus()) {
            if(((PvChar >= PVCHAR_JTHERM) && (PvChar <= PVCHAR_RPTHERM)) || 
               ((PvChar >= PVCHAR_DINRTD) && (PvChar <= PVCHAR_COPPRRTD))) {
                ProcessTCorRTDInput();
            }
            else if(PVCHAR_LINEAR == PvChar) {
                ProcessLinearInput();
            }
            else {
              HardFail(HF_BADPROGRAMJUMP,LLMUXSLOT_CPP,__LINE__);
            }
            RangeFilterSource();
            PvP = (BOX->GetPv(ChanNum) - PvEULo) * HundredDivEUSpan;
        }
    }
    else {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FTAMSMCH,FALSE,ChanNum);
    }
}
/*******************************************************************************
*                           clsLLSlot::ProcessTCorRTDInput                     *
*                           ==============================                     *
* PURPOSE: Slot point processing                                               *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::ProcessTCorRTDInput(VOID)
{
  PvRaw  = PvRawInt;
  PvCalc = isnan(PvRaw) ? NaN : ConvTempUnit(EUConversion(GenPolyPtr()));
}
/*******************************************************************************
*                           clsLLSlot::ProcessLinearInput                      *
*                           =============================                      *
* PURPOSE: Slot point processing                                               *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::ProcessLinearInput(VOID) {
    if(isnan(PvRawInt)) {
        PvRaw  = NaN;
        PvCalc = NaN;
    }
    else {
        PvRaw = PvRawInt / 1000;
        INPTDIR_DIRECT == InptDir ?
        PvCalc = ((PvRaw - PvRawLO) / RawSpan * EUSpan) + PvEULo :
        PvCalc = PvEUHi - ((PvRaw - PvRawLO) / RawSpan * EUSpan);
    }
}
/*******************************************************************************
*                            clsLLSlot::GenPolyPtr                             *
*                            =====================                             *
* PURPOSE: Generates Polynomial Co-efficient Pointer                           *                                        *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/

FLOAT32* clsLLSlot::GenPolyPtr(VOID) {
    FLOAT32 *BpPtr = (FLOAT32 *)BP_POINTER_TAB[PvChar];
    FLOAT32 **PolyPtr;
    UINT8 ucMaxOffSet = *BpPtr;// Get the maximum number of breakpoints
    UINT8 ucCoeffOffSet = 0;
    BpPtr++;// Point to the start of break point
    if(PvRaw > *BpPtr) {//If PvRaw > Low Limit
        BOOL LoopCriterion = TRUE;
        do {
            BpPtr++;//point to next break point
            if(PvRaw < *BpPtr) LoopCriterion = FALSE;
            else {
                ++ucCoeffOffSet;
                if (ucCoeffOffSet > ucMaxOffSet) {//if PvRaw is greater than the last (END) break point
                    --ucCoeffOffSet;// decrement the Co-efficient count by one and exit.
                    LoopCriterion = FALSE;
                }
            }
        }while(TRUE == LoopCriterion);
    }
    // read a pointer to the correct set of polynomial co-efficient set
    // for the current slot characterisation
    PolyPtr = (FLOAT32 **)POLY_COEFF_SET[PvChar];
    // Addup Co-efficient count to polynomial pointer to get the correct pointer
    // to correct set of polynomial values set.
    return *(PolyPtr + ucCoeffOffSet);
}
/*******************************************************************************
*                           clsLLSlot::EUConversion                            *
*                           =======================                            *
* PURPOSE:   Forward Polynomial conversion                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
FLOAT32 clsLLSlot::EUConversion(FLOAT32* a_fCoeffOffSet) {
    FLOAT32 fIntmdtePv = *(a_fCoeffOffSet + 4);
    for(UINT8 ucIndex = 4; ucIndex > 0; ucIndex--) {
        fIntmdtePv = fIntmdtePv * PvRaw + *(a_fCoeffOffSet + ucIndex - 1);
    }
    return fIntmdtePv;
}
/*******************************************************************************
*                           clsLLSlot::RangeFilterSource                       *
*                           ============================                       *
* PURPOSE: This routine uses the upper and lower range limits to check the     *
value of PVCALC passed to the routine for any range errors. If the clamping    *
option is specified the PVCALC value is filtered before range checking,        *
otherwise the the filtering takes place after the range checks. If on entry    *
the value of PVCALC is Nan, then PVAUTO is set to Nan and the routine exited.  *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLSlot::RangeFilterSource(VOID) {
    BOOL bHiFlag = FALSE, bLoFlag = FALSE;
    if (isnan(PvCalc)) {
        PvAuto  = NaN;
        FiltOut = NaN;
        PvAutoSt = PVVALST_BAD;
    }
    else { // PvCalc is not NaN
        // Do Pv filtering first.
        FLOAT32 fNewFiltOut = NaN;
        if (isnan(FiltOut)) fNewFiltOut = PvCalc;
        else fNewFiltOut = FiltOut + Kf * (PvCalc - FiltOut);

        // Do range check and clamping.
        FLOAT32 fNewPvAuto = NaN;
        if (PVCLAMP_CLAMP == PvClamp) {
            if (fNewFiltOut > PvExEUHi) {
                FiltOut    = NaN;
                PvAutoSt   = PVVALST_UNCERTN;
                fNewPvAuto = PvExEUHi;
                bHiFlag    = TRUE;
            }
            else {
                if (fNewFiltOut < PvExEULo) {
                    FiltOut    = NaN;
                    PvAutoSt   = PVVALST_UNCERTN;
                    fNewPvAuto = PvExEULo;
                    bLoFlag    = TRUE;
                }   
                else {
                    FiltOut    = fNewFiltOut;
                    PvAutoSt   = PVVALST_NORMAL;
                    fNewPvAuto = FiltOut;
                }
            }
        } 
        else { // No clamp configured
            if (PvCalc > PvExEUHi) {
                FiltOut    = NaN;
                PvAutoSt   = PVVALST_BAD;
                fNewPvAuto = NaN;
                bHiFlag    = TRUE;
            }
            else {
                if (PvCalc < PvExEULo) {
                    FiltOut    = NaN;
                    PvAutoSt   = PVVALST_BAD;
                    fNewPvAuto = NaN;
                    bLoFlag    = TRUE;
                }
                else {
                    FiltOut    = fNewFiltOut;
                    PvAutoSt   = PVVALST_NORMAL;
                    fNewPvAuto = FiltOut;
                }
            }
        } //end of range checking and clamping.

        // Apply LoCutOff if configured.
        if ((!isnan(LoCutOff)) && (!isnan(fNewPvAuto)) && (fNewPvAuto < LoCutOff)) {
            PvAuto = PvEULo;
        }
        else {
            PvAuto = fNewPvAuto;
        }
    } //end of range checking and filtering
    // Do Pv source selection
    FLOAT32 fPv;
    if (PvSource == PVSOURCE_AUTO) {
        fPv = PvAuto;
        BOX->SetPv(ChanNum,fPv);
        BOX->SetPvSts(ChanNum,PvAutoSt);
        BOX->IncrementSequence(ChanNum);

        if (PVVALST_BAD != PvAutoSt) {
            LastPv = fPv;
        }

        PvExHiFl = bHiFlag;
        PvExLoFl = bLoFlag;
    }
    else { // if PvSource is Man or Sub
        fPv = BOX->GetPv(ChanNum);
        if (!isnan(fPv)) {
            LastPv = fPv;
        }
    } //end of Pv source selection
}
