/*******************************************************************************
*                                HTS Bangalore 2010.                           *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                           HONEYWELL PROCESS SOLUTIONS                        *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcapptrace.h                                                *
*    Description : Implements tracelog fifo in shared ram                      *
*******************************************************************************/

#ifndef _TCAPPTRACE_H_
#define _TCAPPTRACE_H_

#ifdef H8S

#include "tracelog.hpp"
typedef IOBreadCrumb    APPBreadCrumb;
typedef TRACEID         APPTRACEID;

#elif DSC

#include "globaldsc.h"

#ifndef TRUE
    #define TRUE  1
#endif
#ifndef FALSE
    #define FALSE 0
#endif

#define _DISABLE_INTERRUPTS() DisableInterrupts()
#define _ENABLE_INTERRUPTS()  EnableInterrupts()
//
const UINT16 NO_OF_TRACERECORDS = 100;
const UINT16 CRASHBLOCKSIZE     = 20;
const UINT16 CRASHBLKSTARTINDEX = NO_OF_TRACERECORDS - CRASHBLOCKSIZE;
const UINT16 LASTTRACEINDEX     = CRASHBLKSTARTINDEX - 1;
//
typedef struct tagTraceRecord {
  UINT16  code;   //breadcrumb number
  UINT32  data;   //context data
  UINT32  time;   //time of occurance,10msec counter value
} TRACERECORD;
// give appropriate names to trace ids
// trace id is just a mechanism to control the
// level of tracing and is not part of the trace log.
typedef enum tagAppTraceId 
{
    kTraceId0000 = 0x0000,
    kTraceId0001 = 0x0001,
    kTraceId0002 = 0x0002,
    kTraceId0004 = 0x0004,
    kTraceId0008 = 0x0008,
    kTraceId0010 = 0x0010,
    kTraceId0020 = 0x0020,
    kTraceId0040 = 0x0040,
    kTraceId0080 = 0x0080,
    kTraceId0100 = 0x0100,
    kTraceId0200 = 0x0200,
    kTraceId0400 = 0x0400,
    kTraceId0800 = 0x0800,
    kTraceId1000 = 0x1000,
    kTraceId2000 = 0x2000,
    kTraceId4000 = 0x4000,
    kTraceId8000 = 0x8000,
    TRACEID_GENERIC = 0xFFFF
}APPTRACEID;
//
typedef enum tagAppBreadCrumb {

#ifdef IOMTYPE_SVP
    bcStart                     = 0x0750,
    bcSvpRegCtlSp               = 0x0751,
    bcSvpRegCtlCv               = 0x0752,
    bcSvpRegCtlOp               = 0x0753,
    bcServoRdbkCurr             = 0x0754,
    bcServoDrvCurr              = 0x0755,
    bcServoDiffCurr             = 0x0756,
    bcLvdtExtRMS                = 0x0757,
    bcLvdtARMS                  = 0x0758,
    bcLvdtBRMS                  = 0x0759,
    bcChanNum                   = 0x075A,
    bcRunningMaxRbCurrentDrift  = 0x075B,
    bcMaxRbCurrentDrift         = 0x075C,
    bcICoil                     = 0x075D,
    bc5vRefInput                = 0x075E,
    bc5vRefInputMax             = 0x075F,
    bc5vRefInputMin             = 0x0760,
    bcCkvt                      = 0x0761,
    bcVCoil                     = 0x0762,
    // Ai Facotory calibraiton intermediate data.
    bcAiCalib1VRefRdVal         = 0x0763,
    bcAiCalib5VRefRdVal         = 0x0764,
    bcAiCalibZeroRefRdVal       = 0x0765,
    bcAiCalibSlopeVal           = 0x0766,
    bcAiCalibOffsetVal          = 0x0767,
    bcAiCalibRefVolChk          = 0x0768,
    bcAiCalib5vRefhiVolChk      = 0x0769,
    bcAiCalib5vRefloVolChk      = 0x076A,
    //Ao Factory Clibraiton Inteediate data.
    bcAoCalib1VInputRdVal       = 0x076B,
    bcAoCalib5VInputRdVal       = 0x076C,
    bcAoCalibSlopeVal           = 0x076D,
    bcAoCalibOffsetVal          = 0x076E,
    bcAoCalibTestVol            = 0x076F,
    bcHardFail1                 = 0x0770,
    //LVDT Valve Position Calibration Failure
    bcValvePosExctnFreq         = 0x0771,
    bcValvePosExctAmpl          = 0x0772,
    bcValvePosFdbkAAmpl         = 0x0773,
    bcValvePosFdbkBAmpl         = 0x0774,
    bcCoreFalloutSum            = 0x0775,
    bcLvdtEepromWrite           = 0x0776,
    bcLvdtAdLo                  = 0x0777,
    bcLvdtAdHi                  = 0x0778,
    bcCoreFalloutRTN            = 0x0779,
    bcLVDTCalibData             = 0x077A,
    bcLVDTCalibDataPos          = 0x077B,
    bcCtrlRegViolation          = 0x077C,
    bcCheckPntFailCode          = 0x077D,
    bcXreadyVal                 = 0x077E,
	//Unexpected exection of Switch case.
	bcUnexpectedExcution        = 0x077F,
    //
    // add new svp crumb codes here
    //
    bcEnd = 0x07FF
#endif

#ifdef IOMTYPE_SP
    bcStart                     = 0x0850,
    bcTimerTickAt150us          = 0x0852,
    bcSpeedTripValues           = 0x0853,
    bcUncertainPulseDiff        = 0x0854,
    bcHardFail1                 = 0x0854,
    bcCtrlRegViolation          = 0x077C,
    bcCheckPntFailCode          = 0x077D,
    bcXreadyVal                 = 0x077E,
    // add new sp crumb codes here
    //
    bcEnd = 0x08FF
#endif
}APPBreadCrumb;

#endif // DSC

const UINT16 COPY_IN_PROGRESS           = 0x0001;
const UINT16 TRACE_BUFFER_SIZE_WORDS    = NO_OF_TRACERECORDS * 10;
/*******************************************************************************
*                                  clsTraceLog                                 *
*                                  ===========                                 *
*******************************************************************************/
class clsAppTraceLog
{
    volatile UINT16 m_uAppIndex;  /// incremented by app processor only
    volatile UINT16 m_TraceLevel; /// can be modified by either processor.
    volatile UINT16 m_Flags;      /// used to inform app processor of iol processor activity
    UINT16   unused;              /// to align TraceRecord on even word boundary.
#ifdef H8S
    TRACERECORD TraceRecord[NO_OF_TRACERECORDS];
#elif DSC
    // DSC compiler cannot pack structures 
    // of size odd number of words.
    // So each TRACERECORD is 10 bytes on H8S 
    // side but 12 bytes on DSC
    UINT16 TraceRecordBuffer[TRACE_BUFFER_SIZE_WORDS];
#endif

    clsAppTraceLog(const clsAppTraceLog&); // Safeguard against def copy constr.
    clsAppTraceLog& operator=(const clsAppTraceLog&); // and default assignment.

public:
    clsAppTraceLog(VOID);
    ~clsAppTraceLog(VOID) { 
        //HardFail(HF_INVPROGRAMEXEC,TRACELOG_HPP,__LINE__); 
    }
    
    inline void SetFlags(UINT16 flags)   {  m_Flags |= flags;   }
    inline void ClearFlags(UINT16 flags) {  m_Flags &= ~flags;  }
    inline BOOL CheckFlags(UINT16 flags) {  return ((m_Flags & flags) == flags) ? TRUE:FALSE; }
    BOOL IomRebooted(VOID);

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { 
        //HardFail(HF_INVPROGRAMEXEC,TRACELOG_HPP,__LINE__);
        return NULL; 
    }
    VOID operator delete(VOID *) { 
        //HardFail(HF_INVPROGRAMEXEC,TRACELOG_HPP,__LINE__); 
    }

    VOID AddToTrace(APPTRACEID a_TraceId,APPBreadCrumb crumb, UINT32 data = 0);
    VOID CopyCrashTraceBlock(VOID);

#ifdef H8S
    inline VOID *GetTracelog(VOID) { return TraceRecord;}
    inline VOID *GetTracelevel(VOID) { return (VOID*)&m_TraceLevel; }
    inline UINT16 GetLatestTraceIndex(VOID) { return m_uAppIndex; }
#endif
    //
    VOID ToggleTrace(APPTRACEID a_TraceId)
    {
        if (m_TraceLevel & a_TraceId) 
        {
            m_TraceLevel &= ~a_TraceId;
        }
        else 
        {
            m_TraceLevel |= a_TraceId;
        }
    }
};

#endif //_TCAPPTRACE_H_
