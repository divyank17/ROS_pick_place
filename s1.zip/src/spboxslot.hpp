/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spboxslot.hpp                                               *
*    Description : Class clsSpBoxSlot declaration.                             *
*******************************************************************************/
#ifndef __SPBOXSLOT_HPP__
#define __SPBOXSLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spversion.h"

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#define SPBOXSLOT_SIZE ((sizeof(clsSpBoxSlot )+(sizeof(clsSpBoxSlot )%2)) / 2)

/*******************************************************************************/
// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SPIOM_SYNC_VER_1;

/// need to be removed after cleaning commmon code i.e. iomslot.cpp
#define PARAMID_SP_MODSTAT1       67
#define PARAMID_SP_MODSTAT2       68
#define PARAMID_SP_DBVALID        78
#define PARAMID_SP_CALIBALL       80
#define PARAMID_SP_CPUFREEAVGAPP  183
#define PARAMID_SP_CPUFREEMAXAPP  184
#define PARAMID_SP_CPUFREEMINAPP  185
#define PARAMID_SP_STATRESETAPP   186
#define PARAMID_SP_REVROTCHNLA    188
#define PARAMID_SP_REVROTCHNLB    189
#define PARAMID_SP_CALIBOPT       190
#define PARAMID_SP_RESETTRIP      191
//
const UINT8   MAX_TIMERS                = 4;
const UINT16  AI_CHAN_PROC_PERIOD       = 15000; // 1 tick is 0.666usec (1.5ticks per 1usec), so we need 10msec = 10000*1.5
const FLOAT32 TPU2_TICKS_IN_MICROSECOND = (FLOAT32)(SYSTEM_CLOCK_FREQUENCY/MICROSECONDS_IN_SECOND) / (FLOAT32)16;
const UINT16  MUX_SETTLE_DELAY          = 200;//200 us;
const UINT16  FPGA_RESP_DELAY           = 120;//120 us;

const UINT8   DEASSERT_SKIP_CYCLES      = 2; 
const UINT16  BUPREQ_400MS_DELAY        = 80;   //5ms * 80  = 400ms

const UINT16  FIVE_VOLT_TOLERENCE_COUNT = 425;
const UINT8   SP_AI_PPX_PERIOD          = 10; // In units of msec. 
const UINT8   SP_PPX_PERIOD             = 5; // In units of msec.

// PPX interrupt is configured for 5 msec 
const UINT16  TPU0_MAXCOUNT             = (UINT16)(((SYSTEM_CLOCK_FREQUENCY / 64) / 
                                                    (MILLISECONDS_IN_SECOND / SP_PPX_PERIOD)));

const UINT8   SW_ON                     = 0x1;
const UINT8   SW_OFF                    = 0x0;

// Following Constant used as a correction factor to the count when reading 5V Calib Input
// While reading 5V calib input (with successive approxiamtion),the value present at OPAmp input is more 
// than expected. So dividing with this constant as part of the after reading the input to get correct 
// count for 5V calib input
const FLOAT32 GAIN_COMP                 = 1.0027;

const UINT8 AI_CALIBRATION_DONE_ADD     = 88;
const UINT8 AI_CALIBRATION_DONE         = 0x55;

const UINT8 AO_CALIBRATION_DONE_ADD     = 132;
const UINT8 AO_CALIBRATION_DONE         = 0xAA;

const UINT8 SP_EE_MODULEINFO_WRITE_FLAGS = 0x91;
const UINT8 SP_EE_MODULEINFO_WRITECOUNT  = 0x93;

const FLOAT32 DEFAULT_OUTPUT_SLOPE      = ((FLOAT32)(MAXCURRENT_OUTPUT_DACCOUNT - MINCURRENT_OUTPUT_DACCOUNT))
                                                  / (EXTENDED_OP_HILIMIT - EXTENDED_OP_LOLIMIT);
const FLOAT32 DEFAULT_OUTPUT_OFFSET     = MINCURRENT_OUTPUT_DACCOUNT - (EXTENDED_OP_LOLIMIT * DEFAULT_OUTPUT_SLOPE);
const FLOAT32 DEFAULT_LOOPBACK_SLOPE    = ((FLOAT32)(MAXCURRENT_LOOPBACK_DACCOUNT - MINCURRENT_LOOPBACK_DACCOUNT))
                                                  / (EXTENDED_OP_HILIMIT - EXTENDED_OP_LOLIMIT);
const FLOAT32 DEFAULT_LOOPBACK_OFFSET   = MINCURRENT_LOOPBACK_DACCOUNT - (EXTENDED_OP_LOLIMIT * DEFAULT_LOOPBACK_SLOPE);

const UINT8 PARTNERSLOTINFAIL_SIZE = 2;
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
/* Hardfail Event Bits*/
struct HFEVENTBITS
{
    UINT16 Reserved : 1;        // This bit is not used in hard fail. it is used in Soft Fail. 
                                // It should be Low for Hardfail.
    UINT16 HfCmd    : 1;        // Command to indicate this is Hard Fail event
    UINT16 Reserved2: 6;        // Unused
    UINT16 HfType   : 8;        // Hard Failure type
};

/* Hardfail Event Bits*/
union HFEVENT{
   UINT16              all;
   struct HFEVENTBITS  bit;
};

/* Softfail Event Bits*/
struct SFEVENTBITS
{
    UINT16 Cmd      : 1;        //Command to indicate this is Soft Fail event
    UINT16 EvtType  : 1;        //Event Type 
    UINT16 SfDir    : 1;        //Direction 1: Event 0: RTN
    UINT16 SlotNum  : 5;        //Slot number
    UINT16 SfType   : 8;        //Soft Failure type
};

/* Softfail Event Bits*/
union SFEVENT{
   UINT16              all;
   struct SFEVENTBITS   bit;
};

/* Module Status Structure */
typedef union tagMODSTAT1DSC 
{
    struct {
            UINT8 Status :2;
            UINT8 Factory:1;
            UINT8 Unused :4;
            UINT8 BuSyncd:1;
            };
    UINT8 BYTE;
}MODSTAT1_DSC;

/* Calibaration Options */
typedef enum tagCalibOpt
{ 
    CALIBOPT_NONE      = 0,
    CALIBOPT_AI        = 1,
    CALIBOPT_AO        = 2,
    CALIBOPT_SP        = 3
}CALIBOPT;

/* FRC Structure */
typedef struct tagFRC {
    union {
        UINT32 frc_count;
        struct {
            UINT16 ClockHighWord;
            UINT16 Tpu2Count;
        }WORD;
    };
}FRC;

/* Timer States */
typedef enum tagTimerState 
{
    TIMER_FREE=0,
    TIMER_RUNNING
}enmTimerState;

/* Timer Structure */
typedef struct tagTimer
{
    UINT32 TimerCount;
    UINT32 ExpiryCount;
    enmTimerState TimerState;
    enmChanProcEvent PostEvent;
}strTimer;

/* AI Channel States */
typedef enum tagChanProcState
{
    STATE_NULL = 0,
    STATE_IDLE,
    STATE_WAITFORDIAGMUX,
    STATE_WAITFORCHANMUX,
    STATE_WAITFOR_DIAGFPGA_RESP,
    STATE_WAITFOR_CHANFPGA_RESP
}enmChanProcState ;

/* DI Channel PV */
typedef union tagDiChannelData{
    UINT8 Byte;
    struct BIT{
           UINT8 Di8Pv       :1;
           UINT8 Di7Pv       :1;
           UINT8 Di6Pv       :1;
           UINT8 Di5Pv       :1;
           UINT8 Di4Pv       :1;
           UINT8 Di3Pv       :1;
           UINT8 Di2Pv       :1;
           UINT8 Di1Pv       :1;
    }bit;
}DICHANNELDATA;

/* Zero PV Flag */
typedef union tagZeroPvData{
    UINT8 Byte;
    struct BIT{
           // Res5,Res6, Res7, Res8 are reserved bits, currently not being used 
           UINT8 Res8           :1;
           UINT8 Res7           :1;
           UINT8 Res6           :1;
           UINT8 Res5           :1;
           UINT8 ZeroPv4        :1;
           UINT8 ZeroPv3        :1;
           UINT8 ZeroPv2        :1;
           UINT8 ZeroPv1        :1;
    }bit;
}ZEROPVDATA;

/* Bad PV Flag */
typedef union tagDiBadPvFl{
    UINT8 Byte;
    struct BIT{
           UINT8 Di8PvFl       :1;
           UINT8 Di7PvFl       :1;
           UINT8 Di6PvFl       :1;
           UINT8 Di5PvFl       :1;
           UINT8 Di4PvFl       :1;
           UINT8 Di3PvFl       :1;
           UINT8 Di2PvFl       :1;
           UINT8 Di1PvFl       :1;
    }bit;
}DIBADPVFL;

/* Reverse Rotation & Trip Information */
typedef union tagRevRotTripInfo{
    UINT8 Byte;
    struct BIT{
           // Res6, Res7, Res8 are reserved bits, currently not being used 
           UINT8 Res8       :1;
           UINT8 Res7       :1;
           UINT8 Res6       :1;
           UINT8 RevRot     :1;
           UINT8 TripInfo4  :1;
           UINT8 TripInfo3  :1;
           UINT8 TripInfo2  :1;
           UINT8 TripInfo1  :1;
    }bit;
}REVROTTRIPINFO;

/* Input Channel Scan Record */
typedef struct tagSpInputProcessData
{
    FLOAT32 AiPv[AI_MAXSLOTS];
    FLOAT32 SpdPv[SP_MAXSLOTS];
    FLOAT32 VotPv1;
    FLOAT32 VotPv2;
    FLOAT32 VotRoc1;
    FLOAT32 VotRoc2;    
    UINT32  AiPvSts;
    UINT16  SpdPvSts;
    UINT8   VotPvSts;  // Bits 0-3 are for VOTPV1STS and bits 4-7 are for VOTPV2STS
    UINT8   VotRocSts; // Bits 0-3 are for VOTROC1STS and bits 4-7 are for VOTROC2STS
    REVROTTRIPINFO   RevRotFlLastTripTimeInfo;
    ZEROPVDATA ZeroPvFl;
    DICHANNELDATA DiPv;
    DIBADPVFL BadPvFl;
}SPINPUTSCANREC;

/* Output Channel Scan Record */
typedef struct tagSpOutputProcessData
{
    FLOAT32 AoOp;
    FLOAT32 DoOp[DO_MAXSLOTS];
    UINT8   DoInitReq;
    UINT8   DoSo;   
    UINT8   InitReq; // Bit 4 - InitReq of AO Chnl, 
                     // Bit 3 - PwmInitR of DO Chnl 1, 
                     // Bit 2 - PwmInitR of DO Chnl 2, 
                     // Bit 1 - PwmInitR of DO Chnl 3, 
                     // Bit 0 - PwmInitR of DO Chnl 4,   
    UINT8    StdbyManLocalMan; // Bit 0 -  StdByMan of DO Chnl 1, 
                               // Bit 1 -  StdByMan of DO Chnl 2, 
                               // Bit 2 -  StdByMan of DO Chnl 3, 
                               // Bit 3 -  StdByMan of DO Chnl 4,
                               // Bit 4 -  LocalMan of DO Chnl 1, 
                               // Bit 5 -  LocalMan of DO Chnl 2, 
                               // Bit 6 -  LocalMan of DO Chnl 3, 
                               // Bit 7 -  LocalMan of DO Chnl 4,              
}SPOUTPUTSCANREC;

/* Calibration Data */
typedef struct tagSpmCalibData {
    FLOAT32 f5VRefHiLimit;
    FLOAT32 f5VRefLoLimit;
    FLOAT32 AICalibrationSlope;
    FLOAT32 AICalibrationOffset;
    FLOAT32 AIChannelZeroDrift[AI_MAXSLOTS];
    FLOAT32 CalibConstants[4];
    FLOAT32 AOFactorySlope;
    FLOAT32 AOFactoryOffset;
} SPMCALIBDATA;

/* Reverse Rotation */
typedef enum tagRevRotChnlA{
    REVROTCHNL_ONE   = 1,
    REVROTCHNL_TWO   = 2,
    REVROTCHNL_THREE = 3,
    REVROTCHNL_FOUR  = 4
}REVROTCHNL;

/* Last Trip Reason Enumeration */
typedef enum tagLastTripReason{
    LASTTRIPREASON_NONE = 0,
    VOTPV=1,
    VOTROC=2
}LASTTRIPREASON;

/* Box Slot Database Structure */
class clsSpBoxSlot ; // forward declaration
typedef struct tagBoxParamInfo {
    DATATYPE   DataType;
    UINT8      Size;
    ACCESSTYPE AccessType;
    ACCESSLOCK AccessLock;
    PASTATUS   (clsSpBoxSlot ::* PrePtr)(UINT8 *,UINT8);
    VOID       (clsSpBoxSlot ::* PostPtr)(UINT8);
    VOID *     (clsSpBoxSlot ::* ParamPtr)(VOID);
    BOOL       IsDbChecksumed;
} BOXPARAMINFO;

/*******************************************************************************
*                                 clsSpBoxSlot                                 *
*                                 =============                                *
*******************************************************************************/
class clsSpBoxSlot : public clsBoxSlot {
protected:
    // Member variables
    static UINT8 SpBoxChkpntVersion;

     //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetBoxChkpntVersionPtr(VOID) {return &SpBoxChkpntVersion;}
    
private:
    //Database Member Variables
    BOOL       CalibAll;
    FLOAT32    IolProcCpuFreeAvg;
    FLOAT32    IolProcCpuFreeMax;
    FLOAT32    IolProcCpuFreeMin;
    BOOL       IolProcStatReset;
    FLOAT32    AppProcCpuFreeAvg;
    FLOAT32    AppProcCpuFreeMax;
    FLOAT32    AppProcCpuFreeMin;
    BOOL       AppProcStatReset;
    REVROTCHNL RevRotChnlA;
    REVROTCHNL RevRotChnlB;
    BOOL       ResetTrip;
    CALIBOPT   CalibOpt;
    BOOL       RevRotFl;
    LASTTRIPREASON LastTripReason;
    FLOAT32        LastTripTime;
    //
    
    //Diagnostic Related Variables
    DATABYTES  ForcedInputDiagStatus;
    BOOL       bDisOpInternlUpdte;
    //

    //Redundancy Related Member Variables
    UINT8 uDeAssertSkipCycles;
    BOOL  bDisableFO;
    BOOL  bIsBackUpStatusStable;
    BLIND PartnerSlotInFail[PARTNERSLOTINFAIL_SIZE];
    //

    //Calibration Related Variables
    SPMCALIBDATA CalibData;
    BOOL         AICalibrationGood;
    BOOL         AOCalibrationGood;
    UINT16       HiZero;
    UINT16       HiZeroHiHi;
    UINT16       TestCountHiHi;
    UINT16       TestCountHi;
    UINT16       TestCount;
    UINT16       TestCountLo;
    UINT16       TestCountLoLo;
    UINT16       Dac4Percent;
    UINT16       Dac50Percent;
    UINT16       DacOpenWireThreshold;
    UINT16       DacMinus6pt9;
    UINT16       Dac100Percent;
    UINT16       Dac4PercentofFullScale;
    BOOL         FieldCalibOn;
    UINT8        uiRefInput;
    UINT32       uiCkvtFailCnt;
    UINT8        CntBupreq;
    UINT8        ucDscSfChanNum;
    //

    //Shared ram instance for box data
    SPSHRAMBOXDATA *pSpShramBoxData; 
    //

    //Static arrays for Checkpoint, Redundancty and databse
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const BOXPARAMINFO tblParamInfo[256];
    //

    //WatchDog Related Variables
    UINT8         ucWdtRefreshCounter;
    UINT16        uiWdtDiagCounter;
    WDTDIAG_STATE WdtDiagState;
    //

    //TOG related variables
    BOOL    CtlTog;
    BOOL    ComTog;
    //

    //AI Channel Scanning Related Variables
    UINT8       PpxChannel;
    enmChanProcState ChanProcState;
    enmChanProcEvent ChanProcEvent;
    UINT32  AiChannelsProcStartTime;    // gives me start of 1st AI channel processing time
    //

    //Pre Methods for Database Variables
    PASTATUS PreCalibAll(UINT8 *,UINT8);
    PASTATUS PreCalibOpt(UINT8 *,UINT8);
    //

    //Post Methods for Database Variables
    VOID     PostCalibAll(UINT8);
    VOID     PostIolProcStatReset(UINT8);
    VOID     PostCalibOpt(UINT8);
    VOID     PostRedData(UINT8);
    //

    //Get Pointer Methods for Database Variables
    VOID        *GetModStat1Ptr(VOID);
    VOID        *GetModStat2Ptr(VOID);
    VOID        *GetDbValidPtr(VOID);
    VOID        *GetRevRotChnlAPtr(VOID);
    VOID        *GetRevRotChnlBPtr(VOID);
    VOID        *GetCalibAllPtr(VOID);
    inline VOID *GetIolProcCpuFreeAvgPtr(VOID) { return &IolProcCpuFreeAvg; }// IOLINK Processor
    inline VOID *GetIolProcCpuFreeMaxPtr(VOID) { return &IolProcCpuFreeMax; }// IOLINK Processor
    inline VOID *GetIolProcCpuFreeMinPtr(VOID) { return &IolProcCpuFreeMin; }// IOLINK Processor
    inline VOID *GetIolProcStatResetPtr(VOID)  { return &IolProcStatReset;  }// IOLINK Processor
    VOID        *GetAppProcCpuFreeAvgPtr(VOID);
    VOID        *GetAppProcCpuFreeMaxPtr(VOID);
    VOID        *GetAppProcCpuFreeMinPtr(VOID);
    inline VOID *GetAppProcStatResetPtr(VOID)  { return &pSpShramBoxData->StatReset;  }
    VOID        *GetSpTestParamPtr(VOID)          { return (VOID *)GetTestParamPtr(); }
    VOID        *GetResetTripPtr(VOID);
    VOID        *GetCalibOptPtr(VOID);
    VOID        *GetRevRotFlPtr(VOID);
    VOID        *GetLastTripReasonPtr(VOID);
    VOID        *GetLastTripTimePtr(VOID);
    VOID        *GetCheckSumPtr(VOID);    
    inline VOID *GetCtlTogPtr(VOID) {return &CtlTog;}
    inline VOID *GetComTogPtr(VOID) {return &ComTog;}
    //

    //Redundancy related variable Get Pointer Method
    inline VOID *GetRedParamsPtr(VOID)            { return (VOID *)RedParams; }
    inline VOID *GetCheckPointPtr(VOID)           { return (VOID *)CheckPointVerTable[SpBoxChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer)  { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    //

    //Input and Output Channgel Scan Record Get Pointer Method
    inline VOID *GetSpOutPutScanRecPtr(VOID) { return (VOID *)&SpOutPutScanRec; }
    inline VOID *GetSpInputScanRecPtr(VOID)  { return (VOID *)&SpInputScanRec;  }
    //

    //Diagnostic Related Methods
    VOID DoIdleDiagnostics();
    BOOL ValidateCheckVoltage (UINT8,UINT16);
    BOOL ValidateCheckVoltage(UINT8 a_ucSlotNum,UINT16,enmChanProcEvent Event);
    //

    //Database Access Related Methods
    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    //
    
    clsSpBoxSlot (const clsSpBoxSlot &);            // Safeguard against def copy constr.
    clsSpBoxSlot & operator=(const clsSpBoxSlot &); // and default assignment.        
public:
    clsSpBoxSlot (MODLTYPE);
    ~clsSpBoxSlot (VOID)         { HardFail(HF_INVPROGRAMEXEC,SPBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32)   { return ucIomDbMemory; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,SPBOXSLOT_HPP,__LINE__); } 

    //Input and Output Channel Scan Related Variables
    SPOUTPUTSCANREC SpOutPutScanRec;
    SPINPUTSCANREC SpInputScanRec;

    //Database Access Related Methods
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    //
    
    //Scan Record related methods
    void FillScanRecord(UINT8 a_ucParamNumber, UINT8 *a_ReadBuffer);
    void FillInputScanRecord(UINT8 *a_ReadBuffer);
    void FillOutputScanRecord(UINT8 *a_ReadBuffer);
    inline BOOL IsScanRecordParameter(UINT8 a_ucParamNumber)
    {
        BOOL bIsScanRecordParameter = FALSE;

        if((a_ucParamNumber == kSiomSpPnInputProcessData) ||
           (a_ucParamNumber == kSiomSpPnOutputProcessData))
        {
            bIsScanRecordParameter = TRUE;
        }

        return bIsScanRecordParameter;
    }
    //

    //Get and Set methods for Iolink Processor Statistics
    inline FLOAT32 GetIolProcCpuFreeMax(VOID) { return IolProcCpuFreeMax; }
    inline FLOAT32 GetIolProcCpuFreeMin(VOID) { return IolProcCpuFreeMin; }
    inline FLOAT32 GetIolProcCpuFreeAvg(VOID) { return IolProcCpuFreeAvg; }
    inline VOID SetIolProcCpuFreeAvg(FLOAT32 a_fCpuFreeAvg) { IolProcCpuFreeAvg = a_fCpuFreeAvg; }
    inline VOID SetIolProcCpuFreeMax(FLOAT32 a_fCpuFreeMax) { IolProcCpuFreeMax = a_fCpuFreeMax; }
    inline VOID SetIolProcCpuFreeMin(FLOAT32 a_fCpuFreeMin) { IolProcCpuFreeMin = a_fCpuFreeMin; }
    //

    //Redundancy Related Methods
    VOID  SetForPrimary(VOID);
    VOID  SetForSecondary(BOOL);
    VOID  CheckFailOverCondition(VOID);
    BOOL  SwitchInit(VOID);
    VOID  ManageRedIO(VOID);
    VOID  SetOutCtl(UINT8 OutCtlState);
    UINT8 GetOutCtl(VOID);
    VOID  AppColdInit(VOID);
    VOID  AppPostSwap(VOID);
    VOID  AppPostSync(VOID);
    VOID  AppPostDump(VOID);
    inline VOID  AppSyncver(VOID) { bDisOpInternlUpdte = FALSE;}
    VOID EnableOutputFailFO(VOID) { SfActionTbl[2] |= 0x80;    }
    VOID CheckBackUpStatus(VOID);
    virtual inline VOID SetRedState(BLIND ucRedState) {
        RedData[1] = ucRedState;
        pSpShramBoxData->RedSyncState = ucRedState;

        if(REDSTATE_SYNCD == GetRedState())
        {
            uDeAssertSkipCycles = DEASSERT_SKIP_CYCLES;
        }
    }
    inline VOID EnableOutputs(VOID) {
        DIS_SWB_n = 1;
        DIS_SWA_n = 1;
    }

    inline VOID DisableOutputs(VOID) {
        DIS_SWB_n = 0;
        DIS_SWA_n = 0;
    }
    inline UINT32 GetRedBoxDelta(VOID)   { return 0;                              }
    inline UINT32 GetRedBoxSize(VOID)    { return (sizeof(strSpBoxSlotDumpData)); }
    inline UINT8 *GetRedBoxPointer(VOID) { return (UINT8 *)&ModStat1;             }
    //

    //Interrupt Related Methods
    VOID AppStcProcessing(VOID);
    static VOID PpxInterruptHandler(VOID);
    static VOID IRQ1InterruptHandler(VOID); //Watchdog prefire interrupt
    static VOID IRQ4InterruptHandler(VOID); //Powersupply failure interrupt
    static VOID IRQ6InterruptHandler(VOID);
    //

    //Softfails Related Methods
    virtual VOID BoxHouseKeeping(VOID);
    BOOL    AddSoftfailEvent(EVENTTYPE, SOFTFAILTYPE, BOOL, UINT8);
    VOID    ReportDSCSF();
    //

    //Diagnostic Related Methods
    VOID TestLoopbackCircuit(VOID);
    inline UINT32 GetForcedInputDiagStatus(VOID){ return ForcedInputDiagStatus.ui32Val;}
    inline VOID  DoAliveToIdleChange(VOID){}
    inline BOOL IsPrimaryChannelInFail(UINT8 a_ucChanNum) {
        UINT8 ucIdx = 0;
        if (a_ucChanNum > (MAXSLOTS/2)) {
            ucIdx = 1;
            a_ucChanNum -= MAXSLOTS/2;
        }
        UINT8 ucMsk = SLOTINFAIL_MASKINIT >> (a_ucChanNum - 1);
        return (PartnerSlotInFail[ucIdx] & ucMsk) ? TRUE : FALSE;
    }
    inline VOID ClearPartnerSlotInFail(VOID) {
        PartnerSlotInFail[0] = 0;
        PartnerSlotInFail[1] = 0;
    }
    //

    //Calibaration Related Methods
    BOOL    PerformModuleCalibration(VOID);
    BOOL    SPFlashCalibrationData(CALIBOPT);
    VOID    SPLoadCalibrationData(VOID);
    BOOL    AOPerformModuleCalibration(VOID);
    BOOL    AOPerformFactoryCalibration(VOID);
    BOOL    AOPerformFieldCalibration(VOID);
    BOOL    PerformSpAiCalibration(VOID);
    FLOAT32 DoSuccessiveApproximation(BOOL);
    BOOL    CheckRefVoltage(UINT16);
    SPMCALIBDATA GetCalibData()             { return CalibData;               }
    BOOL    IsCalibInProgress()             { return BOX->GetCalibAllState(); }
    inline  BOOL IsAOCalibrationGood(VOID)  { return AOCalibrationGood;       }
    inline  UINT16 GetDac50Percent(VOID)    { return Dac50Percent;            }
    inline  UINT16 GetDac4PercentofFullScale(VOID){ return Dac4PercentofFullScale;}
    inline  SPMCALIBDATA *GetCalibDataPtr(VOID)   { return &CalibData;            }
    inline  BOOL IsFieldCalib()                   { return FieldCalibOn;          }
    //

    //Initialization Related Methods
    VOID AppInitialization(VOID);
    //

    //Get and Set methods for Members or Derived Variables
    UINT8 GetModuleStatus(VOID);
    VOID  SetModuleStatus();
    UINT8 GetModStat3State(VOID);
    inline BOOL GetCalibAllState(VOID);
    inline BOOL GetbDisOpInternlUpdteSts(){return bDisOpInternlUpdte;}
    //

    //WatchDog related Methods
    static VOID RefreshWatchDog(VOID);      //Refresh Watchdog
    VOID  StopImpendingWatchdog(VOID);
    VOID  ResetWdtRefreshCounter(VOID) { ucWdtRefreshCounter=0; }
    //

    //Factory Test Related Methods
    UINT8 CheckForFactoryTestMode(VOID);
    VOID  SetFactoryTestMode(VOID);
    VOID  SetTstTimeFromShram(VOID);
    VOID  SendWdtTstCmdToAppProc(VOID);
    //

    //AI Channel Processing Relate Methods
    VOID ProcessIOChannels(VOID);
    VOID DiagMuxTout(VOID);
    VOID DiagFpgaRespOk(VOID);
    VOID ChanMuxTout(VOID);
    VOID ChanFpgaRespOk(VOID);
    VOID ChanProcCycle(VOID);
    VOID SetChanProcState(enmChanProcState NewChanProcState);
    VOID ProcessChannel();

    //Redundacny Dump Related Struct and Methods
    struct strSpBoxSlotDumpData 
    {
        UINT16  Version;     // The first two bytes of dump record should always represent version. Do not change this. 
        UINT16  Tpu5_Pri;
        UINT16  ModStat1;
        UINT16  ModStat2;
        UINT16  RevRotChnlA;
        UINT16  RevRotChnlB;
        UINT8   MaxSlots;
        BOOL    DbValid;
        UINT16  RotationDirData;
    };
    PASTATUS  GetDumpData(UINT8* const pDump, const UINT8 MaxSize);
    PASTATUS  StoreDumpData(UINT8* const pDump);
    //

    //Get and Set Related methods for Process Data
    FLOAT32 GetPv(UINT8 a_ucChanNum);    
    UINT32  GetAiPvSts(UINT8 a_ucChanNum); 
    inline FLOAT32 GetOp() { return SpOutPutScanRec.AoOp; }
    BOOL GetInitReq(UINT8);
    VOID SetPv(UINT8 a_ucChanNum, FLOAT32 a_fPv);
    VOID SetPvSts(UINT8 a_ucChanNum, UINT32 a_PvSts);
    VOID SetSpPvSts(UINT8 a_ucChanNum, UINT16 a_PvSts);
    inline VOID SetOp(UINT8 a_ucChanNum, FLOAT32 a_fOp, BOOL a_bDrvOp = TRUE) 
    {
        UINT8 uiMask = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        SpOutPutScanRec.AoOp = a_fOp;
        set_imask_exr(uiMask);
        BOOL bDrvOp = a_bDrvOp; // To avoid constant in condition compiler warning.
        if (bDrvOp) 
        {
            AO_SLOT(a_ucChanNum)->SetOpInternal(a_fOp);
            AO_SLOT(a_ucChanNum)->UpdateOpFinal(a_fOp) ;
        }
    }
    VOID SetInitReq(UINT8 a_ucChanNum,BOOL bInitReq);
    //

#ifdef DEBUG
    UINT32 m_ulMaxPpxTime;
    UINT32 m_ulAvgPpxTime;
    UINT32 m_ulMinPpxTime;
    inline VOID SetCalibAll(BOOL a_bVal)   { CalibAll = a_bVal; }
#endif
};

/*******************************************************************************
*                                 clsSpAdc                                     *
*                                 ========                                     *
*******************************************************************************/
#define NORMAL_SP_MUX_SETTLE_TIME   (UINT16)200   // In units of microseconds.
class clsSpAdc {
    static const UINT8 aInputSelect[];
    static const UINT8 MuxSelEnable[];
public:
    clsSpAdc(VOID) {}
    ~clsSpAdc(VOID) {}
    
    VOID *operator new (UINT32)  { return NULL; }
    VOID operator delete(VOID *) {  }

    UINT16 GetRawData(UINT8 MuxSel,UINT16 a_uiWaitTime = NORMAL_SP_MUX_SETTLE_TIME);
    UINT16 SetMuxEnable(UINT16 ui_MuxReg,UINT8 ui_MuxEn);
    UINT16 SetMuxCtrl(UINT16 ui_MuxReg,UINT8 ui_MuxCtl);
    UINT16 SetAiReqbit(UINT16 ui_MuxReg,BOOL AiReqbit);
    VOID GetRawDataPhase1(UINT8 a_ucMuxSel);
    VOID GetRawDataPhase2(VOID);
    UINT16 GetRawDataPhase3(VOID);
};
extern clsSpAdc SpAdc;

/*******************************************************************************
*                                 clsTimer                                     *
*                                 ========                                     *
*******************************************************************************/
class clsTimer
{
public :
    FRC    FRC_Time;
    UINT16 LastTpu2Count;

    BOOL StartTimer(UINT16 Delay, enmChanProcEvent Event);
    enmChanProcEvent CheckTimerEvent();
    UINT32 GetFRC();
    UINT32 GetElapsedCount(UINT32 StartingCount);

    clsTimer();
    ~clsTimer (VOID) { HardFail(HF_INVPROGRAMEXEC,SPBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32)   { return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,SPBOXSLOT_HPP,__LINE__); } 
private :
    strTimer TimerArr[MAX_TIMERS];
    strTimer * FindFreeTimer();
};

#endif // SPBOXSLOT_HPP
