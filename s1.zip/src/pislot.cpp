/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2010                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : pislot.cpp                                                  *
*    Description : Class clsPiSlot definition.                                 *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "pislot.hpp"
#include "piboxslot.hpp"

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8  clsPiSlot::CheckPointVer1[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_EDGEDETECT,
    PARAMID_FREQPERIOD,
    PARAMID_C1,
    PARAMID_C2,
    PARAMID_C3,
    PARAMID_INPUTSTREAM,
    PARAMID_ENPULSEWIDTHREJ,
    PARAMID_PULSEINTYPE,
    PARAMID_PULSEMODE,
    PARAMID_SAFEOUTPUT,
    PARAMID_TIMEBASE,
    PARAMID_VOLTAGE,
    PARAMID_PTEXECST,
    0 // Terminator
};


const CHECKPOINT_VER_TABLE clsPiSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
    { CheckPointVer1, 24 }
};


UINT8 clsPiSlot::SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;

const UINT8 clsPiSlot::RedParams[] = {
    PARAMID_PNTTYPE,
    PARAMID_EDGEDETECT,
    PARAMID_FREQPERIOD,
    PARAMID_C1,
    PARAMID_C2,
    PARAMID_C3,
    PARAMID_INPUTSTREAM,
    PARAMID_ENPULSEWIDTHREJ,
    PARAMID_PULSEINTYPE,
    PARAMID_PULSEMODE,
    PARAMID_SAFEOUTPUT,
    PARAMID_TIMEBASE,
    PARAMID_VOLTAGE,
    PARAMID_PTEXECST,
    0 // Terminator
};

const SLOTPARAMINFO clsPiSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 50
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 51 
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvPtr,FALSE,                                   // 52 Av
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvRawPtr,FALSE,                                 // 53 AvRaw
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvRawStsPtr,FALSE,                                // 54 AvRawSts
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 55 
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAvStsPtr,FALSE,                                   // 56 AvSts
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 57 
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadAvRawPtr,FALSE,                              // 58 BadAvRaw 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 59  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 60   
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 61
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadPvFlPtr,FALSE,                                 // 62 BadPvFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadSoPtr,FALSE,                                   // 63 BadSo
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreC1,PostC1,GetC1Ptr,TRUE,                            // 64 C1
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreC2,PostC2,GetC2Ptr,TRUE,                            // 65 C2
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreC3,PostC3,GetC3Ptr,TRUE,                            // 66 C3
    DT_BLIND,24,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,TRUE,                  // 67 Checkpoint
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreEdgeDetect,PostEdgeDetect,GetEdgeDetectPtr,TRUE,       // 68 EdgeDetect
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreFreqPeriod,PostFreqPeriod,GetFreqPeriodPtr,TRUE,       // 69 FreqPeriod 
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreInputStream,PostInputStream,GetInputStreamPtr,TRUE,    // 70 InputStream    
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPlPtr,FALSE,                                   // 71 Pl
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPlStsPtr,FALSE,                                   // 72 PlSts
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 73 
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePntType,PostPntType,GetPntTypePtr,TRUE,                // 74 PnyType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PrePtExecSt,PostPtExecSt,GetPtExecStPtr,TRUE,            // 75 PtExecSt  
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreEnPulseWidthRej,PostEnPulseWidthRej,GetEnPulseWidthRejPtr,TRUE, // 76 EnPulseWidthRej
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePulseInType,PostPulseInType,GetPulseInTypePtr,TRUE,    // 77 PulseInType
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePulseMode,PostPulseMode,GetPulseModePtr,TRUE,          // 78 PulseMode
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvPtr,FALSE,                                   // 79 Pv  
    DT_FLOAT64,8,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreTv64,PostTv64,GetTv64Ptr,FALSE,                    // 80 Tv64 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 81  
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvStsPtr,FALSE,                                   // 82 PvSts
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 83  
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreResetFl,PostResetFl,GetResetFlPtr,FALSE,              // 84 ResetFl 
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreSafeOutput,PostSafeOutput,GetSafeOutputPtr,TRUE,       // 85 SafeOutput
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSoPtr,FALSE,                                      // 86 So 
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreSoCmdOff,PostSoCmdOff,GetSoCmdOffPtr,FALSE,           // 87 SoCmdOff
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreSoCmdOn,PostSoCmdOn,GetSoCmdOnPtr,FALSE,              // 88 SoCmdOn 
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreTimeBase,PostTimeBase,GetTimeBasePtr,TRUE,             // 89 TimeBase 
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreTv,PostTv,GetTvPtr,FALSE,                          // 90 Tv 
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetTvProcPtr,FALSE,                                  // 91 TvProc 
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetTvRawPtr,FALSE,                                 // 92 TvRaw 
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreVoltage,PostVoltage,GetVoltagePtr,TRUE,                // 93 Voltage 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 94  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 95 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 96 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 97 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 98 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 99 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 100 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 101  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 102 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 103 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 104  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 105 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 106 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 114
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 116 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 117 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 142
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 144 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 243
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,                      // 244 SlotChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 245 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                              // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE                                              // 255
};
/*******************************************************************************
*                            clsPiSlot::operator new                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return (ucIomDbMemory + PIBOXSLOT_SIZE + (a_ucSltNm * PISLOT_SIZE));
}
/*******************************************************************************
*                           clsPiSlot::clsPiSlot                               *
*                           ====================                               *
* PURPOSE: Constructor of clsPiSlot Class. This calls InitPiSlot() which       *
*          initializes clsPiSlot class members.                                *
* ARGUMENTS:                                                                   *
*           a_ucSltNm    -   Slot number                                       *
* RETURN:   NONE                                                               *
* NOTES:    This constructor will internally invokes clsInSlot class           *
*                   constructor.                                               *
*******************************************************************************/
clsPiSlot::clsPiSlot(UINT8 a_ucSltNm) : clsInSlot(PNTTYPE_NOTCONFIGURED,a_ucSltNm) {
    Channel_Unused = TRUE;
    InitPiSlot(TRUE, TRUE);
    for (UINT8 ucCount = 0; ucCount < PISLOT_SPARESIZE; ucCount++) {
        PiSlotSpare[ucCount] = 0;
    }
}
/*******************************************************************************
*                           clsPiSlot::InitPiSlot                              *
*                           =====================                              *
* PURPOSE: InitPiSlot function which initializes clsPiSlot class members.      *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::InitPiSlot(BOOL bFullInit, BOOL ) {  
    Voltage     = VOLTAGE_LOW;
    EdgeDetect  = RISINGEDGE;
    FreqPeriod  = FREQPERIOD_1S;
    TimeBase    = SECONDS;
    EnPulseWidthRej = OFF;
    InputType   = PULSEINPUT;
    ufC1        = (FLOAT32)1.0;
    ufC2        = (FLOAT32)1.0;
    ufC3        = (FLOAT32)1.0;
    PulseMode   = PULSE_HIGH;
    ResetFl     = OFF;
    SafeOutput  = OFF;
    SoCmdOn     = OFF;
    SoCmdOff    = OFF;
    BadAvRaw    = 0;
    LastCount   = 0;
    LastFRC     = 0;
    FaultState  = FAULTSTATE_NORMAL;

    // AV, AVRAW, and PL  must be init in the FPGA
    // if channel 7 or 8, TVPROC will be init by AVRAW init
    // if DUAL_PULSE partner AVRAW must also be init
    BOX->ClrCounterTimer(ChanNum);
    if (InputStream == DUAL_PULSE) BOX->ClrCounterTimer(ChanNum+1);
    BOX->StoreResetCount(ChanNum,0);
    // if channel 7 or 8, init SO, TV, and TVRAW
    // SO and TVRAW must be init in the FPGA
    // TV need only be init in IOM database
    // BADSO need not be init at all
    if(ChanNum >= FASTCUTOFF_CHN0){
        BOX->SetSafeOut(ChanNum,FALSE);
        BOX->SetSo(ChanNum,OFF);
        LastSoCmdVal = SOCMD_OFF;
        StoreTv64(DNaN);
        BOX->StoreTv(ChanNum, NaN);
        BOX->StoreTvSync(ChanNum, DNaN);
        BOX->SetTvRaw(ChanNum);
    }
    InputStream = SINGLE_PULSE;
}
/*******************************************************************************
*                            clsPiSlot::GetDataType                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsPiSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsPiSlot::GetAccessType                            *
*                          ========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsPiSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                            clsPiSlot::GetParamSize                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsPiSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                            clsPiSlot::GetParamPtr                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsPiSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                           clsPiSlot::GetAccessLock                           *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsPiSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                       clsPiSlot::GetIsDbChecksumed                           *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsPiSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                         clsPiSlot::VerifyControlState                        *
*                         =============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsPiSlot::ExecutePreFunction                        *
*                         =============================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsPiSlot::ExecutePostFunction                       *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) 
{
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}

/*******************************************************************************
*                           clsPiSlot::PrePntType                              *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for PntType parameter.                *
*                                                                              *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) 
{
    this->ScratchPad = *(UINT8 *)a_Writebuffer; // Save for use in post function.
    UINT8 ucModSts = BOX->GetModuleStatus();

    if (((PNTTYPE)ScratchPad != PNTTYPE_NOTCONFIGURED)
        && ((PNTTYPE)ScratchPad != PNTTYPE_PULSEINPUT)) {
        return DO_ILLEGAL_VALUE;
    }

    if ((ALVL_IUSER == a_ucAccLvl) && (MODSTATUS_IDLE != ucModSts)) {
        return DO_STATE_MUST_BE_IDLE;
    }

    switch (ChanNum) {
        case 1:
        case 3:
        case 5:
        case 7:
            break;
        default:
            if (SLOT(ChanNum-1)->InputStream == DUAL_PULSE) return DO_CONFIGURATION_MISMATCH_ERROR;
            break;
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsPiSlot::PostPntType                             *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES: FCO processing is unnecessary                                         *
*******************************************************************************/
VOID clsPiSlot::PostPntType(UINT8) 
{
    BOOL bSelected = FALSE;

    if (PNTTYPE_NOTCONFIGURED == PntType) {
        // Initialize the slot database
        InitSlotDatabase(TRUE);
        // Mark this channel as unused
        Channel_Unused = TRUE;
        // If channel 7 or 8, reset SAFEOUTPUT, SO, and TVRAW in the FPGA
        if (ChanNum >= FASTCUTOFF_CHN0) {
            BOX->SetSafeOut(ChanNum,FALSE);
            BOX->SetSo(ChanNum,OFF);
            LastSoCmdVal= SOCMD_OFF;
            StoreTv64(DNaN);
            BOX->StoreTv(ChanNum, NaN);
            BOX->StoreTvSync(ChanNum, DNaN);
            BOX->SetTvRaw(ChanNum);
        }
    }
    else
        // Initialize the slot database only
        InitSlotDatabase(FALSE);

    // If this channel and its partner is selected for the prover, clear it
    switch(ChanNum){
       case 1:
          bSelected = DPICR.B12;
          break;
       case 3:
          bSelected = DPICR.B13;
          break;
       case 5:
          bSelected = DPICR.B14;
          break;
       case 7:
          bSelected = DPICR.B15;
          break;
       default:
          break;
    }
    if (bSelected) BOX->SetProverSignal(TRUE);
}
/*******************************************************************************
*                           clsPiSlot::PrePtExecSt                             *
*                           ======================                             *
* PURPOSE:  Pre Receiver-Beware function for PtExecSt parameter.               *
*           This method checks for range of the data that can be written to    *
*           PtExecSt parameter and access level check.                         *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
* RETURN:                                                                      *
*           PA_OK           -   If post check is succesfull                    *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PrePtExecSt(UINT8 *a_Writebuffer,UINT8) 
{
    PTEXECST ucNewPtExecSt = (PTEXECST) *(UINT8 *)a_Writebuffer;
    
    if (ucNewPtExecSt > PTEXECST_ACTIVE) return DO_ILLEGAL_VALUE;
    
    // Detect state changes
    this->ScratchPad = PTEXECST_NO_TRANS;
    if (PTEXECST_INACTIVE == PtExecSt) {
        if (ucNewPtExecSt == PTEXECST_INACTIVE) this->ScratchPad  = PTEXECST_INACT_INACT;
        else if (ucNewPtExecSt == PTEXECST_ACTIVE) this->ScratchPad  = PTEXECST_INACT_ACT;
    }
    else if (PTEXECST_ACTIVE == PtExecSt) {
        if (ucNewPtExecSt == PTEXECST_INACTIVE) this->ScratchPad  = PTEXECST_ACT_INACT;
        else if (ucNewPtExecSt == PTEXECST_ACTIVE) this->ScratchPad  = PTEXECST_ACT_ACT;
    }

    return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostPtExecSt                          *
*                             =======================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::PostPtExecSt(UINT8) 
{
    if (PtExecSt == PTEXECST_INACTIVE) InactivateSlot();           
    else BOX->StoreBadSo(ChanNum,OFF);

    if (InputStream == DUAL_PULSE) {
        BOX->SetIntPeriod(ChanNum+1,FreqPeriod);
        BOX->SetPwReject(ChanNum+1,EnPulseWidthRej);
        BOX->SetPulseMode(ChanNum+1,PulseMode);
        BOX->SetVoltage(ChanNum+1,Voltage);
        BOX->SetEdgeDetect(ChanNum+1,EdgeDetect);
    }
    
    // If channel going to ACTIVE, clear the PL timer
    if (ScratchPad == PTEXECST_INACT_ACT) BOX->ClrTimer(ChanNum);
}
/*******************************************************************************
*                            clsPiSlot::GetPvStsPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetPvPtr(VOID) { 
    return &(BOX->PvScanRec1[ChanNum - 1].Pv);
}
/*******************************************************************************
*                            clsPiSlot::GetPvStsPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetPvStsPtr(VOID) { 
    return &(BOX->PvScanRec1[ChanNum - 1].PvSts);
}
/*******************************************************************************
*                             clsPiSlot::PreC1                                 *
*                             ================                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreC1(UINT8 *a_Writebuffer,UINT8) 
{
   FLOAT32 ufNewVal = *(FLOAT32*)a_Writebuffer;

   if(isnan(ufNewVal) || (ufNewVal == (FLOAT32)0))
      return DO_ILLEGAL_VALUE;
   
   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostC1                                *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::PostC1(UINT8) 
{

}
/*******************************************************************************
*                             clsPiSlot::PreC2                                 *
*                             ================                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreC2(UINT8 *a_Writebuffer,UINT8) 
{
    FLOAT32 ufNewVal = *(FLOAT32 *)a_Writebuffer;

    if(isnan(ufNewVal) || (ufNewVal == (FLOAT32)0))
       return DO_ILLEGAL_VALUE;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostC2                                *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::PostC2(UINT8) 
{

}
/*******************************************************************************
*                             clsPiSlot::PreC3                                 *
*                             ================                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreC3(UINT8 *a_Writebuffer,UINT8) 
{
    FLOAT32 ufNewVal = *(FLOAT32 *)a_Writebuffer;

    if(isnan(ufNewVal) || (ufNewVal == (FLOAT32)0))
       return DO_ILLEGAL_VALUE;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostC3                                *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::PostC3(UINT8) 
{

}
/*******************************************************************************
*                             clsPiSlot::PreEdgeDetect                         *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreEdgeDetect(UINT8 *a_Writebuffer,UINT8) 
{
    if (*(UINT8 *)a_Writebuffer > RISINGEDGE) 
    {
        return DO_ILLEGAL_VALUE;
    }
   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostEdgeDetect                        *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostEdgeDetect(UINT8) 
{
   // Update in the FPGA register
   BOX->SetEdgeDetect(ChanNum,EdgeDetect);
}
/*******************************************************************************
*                             clsPiSlot::PreFreqPeriod                         *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreFreqPeriod(UINT8 *a_Writebuffer,UINT8) 
{
    if (*(UINT8 *)a_Writebuffer > FREQPERIOD_2S) 
    {
        return DO_ILLEGAL_VALUE;
    }
   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostFreqPeriod                        *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostFreqPeriod(UINT8) 
{
    // Update in FPGA Register
    BOX->SetIntPeriod(ChanNum,FreqPeriod);
}
/*******************************************************************************
*                             clsPiSlot::PreInputStream                        *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: In order to be configured for dual pulse input it must be an odd      *
*        channel and the partner channel must not be configured.               *
*******************************************************************************/
PASTATUS clsPiSlot::PreInputStream(UINT8 *a_Writebuffer,UINT8) 
{
    INPUTSTREAM NewVal = *(INPUTSTREAM *)a_Writebuffer;

    if (NewVal > DUAL_PULSE) {
        return DO_ILLEGAL_VALUE;
    }

    if (NewVal == DUAL_PULSE) {
        switch (ChanNum) {
            case 1:
            case 3:
            case 5:
            case 7:
                if (SLOT(ChanNum+1)->Channel_Unused == FALSE)
                    return DO_CONFIGURATION_MISMATCH_ERROR;
                break;
            default:
                return DO_INVALID_SLOT_INDEX;
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostInputStream                       *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostInputStream(UINT8) 
{
    // Update in FPGA Register
    BOX->SetChannelType(ChanNum,InputStream);
    Channel_Unused = FALSE;
}
/*******************************************************************************
*                             clsPiSlot::PreInputDigFilter                     *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreEnPulseWidthRej(UINT8 *,UINT8) 
{
   if (PTEXECST_ACTIVE == PtExecSt)
       return DO_POINT_MUST_BE_INACTIVE;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostInputDigFilter                    *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostEnPulseWidthRej(UINT8) 
{
   // Update in FPGA Register
   BOX->SetPwReject(ChanNum,EnPulseWidthRej);
}
/*******************************************************************************
*                             clsPiSlot::PrePulseInType                        *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PrePulseInType(UINT8 *a_Writebuffer,UINT8) 
{
    PULSEINTYPE NewVal = *(PULSEINTYPE *)a_Writebuffer;
    if (NewVal > PULSEINPUT_FC) 
        return DO_ILLEGAL_VALUE;
    if ((NewVal == PULSEINPUT_FC) && (ChanNum < FASTCUTOFF_CHN0)) 
        return DO_FUNCTION_NOT_IMPLEMENTED;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostPulseInType                       *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: !ToDo!                                                                *
*******************************************************************************/
VOID clsPiSlot::PostPulseInType(UINT8) 
{
}
/*******************************************************************************
*                             clsPiSlot::PrePulseMode                          *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PrePulseMode(UINT8 *a_Writebuffer,UINT8) 
{
    if (*(UINT8 *)a_Writebuffer > PULSE_LOW) 
    {
        return DO_ILLEGAL_VALUE;
    }
   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostPulseMode                         *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTE1: Requires update of FPGA register                                      *
* NOTE2: Due to timing within the FPGA all writes to the PMCR must be word     *
*        writes - otherwise pulse mode config of FPGA will be incorrect.       *
*******************************************************************************/
VOID clsPiSlot::PostPulseMode(UINT8) 
{
    // Update in FPGA register
    BOX->SetPulseMode(ChanNum,PulseMode);
}
/*******************************************************************************
*                             clsPiSlot::PreResetFl                            *
*                             =====================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreResetFl(UINT8 *,UINT8) 
{
    // check for channel active, if inactive return an error
    if (PTEXECST_INACTIVE == PtExecSt){
        return DO_STATE_MUST_BE_RUN;
    }

    // check for valid AV, if NaN return an error
    if(isnan(BOX->GetAv(ChanNum))){
        return DO_POINT_IS_IN_BADCTL;
    }

    return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostResetFl                           *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:  !ToDo!                                                               *
*******************************************************************************/
VOID clsPiSlot::PostResetFl(UINT8) 
{
    if(ResetFl == ON){
        // Increment the reset count
        BOX->IncrementResetCount(ChanNum);
        // Reset PL timer
        // Reset FPGA AVRAW counter and its archive (must be atomic)
        UINT8 ucSaveExr = get_imask_exr();          // save current Int mask
        set_imask_exr(LVLPRI_TICK);         //disable STC and FPGA interrupts
        BOX->ClrCounterTimer(ChanNum);
        LastCount = 0;
        set_imask_exr(ucSaveExr);                   // restore Int mask
        // If dual pulse type, reset the counter and timer of partner channel
        if (InputStream == DUAL_PULSE) BOX->ClrCounterTimer(ChanNum+1);
        // Reset the flag
        ResetFl = OFF;
    }
}

/*******************************************************************************
*                             clsPiSlot::PreSafeOutput                         *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreSafeOutput(UINT8 *a_Writebuffer,UINT8) 
{  
    // check for valid channel number
    if(*(UINT8 *)a_Writebuffer == ON && ChanNum<FASTCUTOFF_CHN0){
       return DO_FUNCTION_NOT_IMPLEMENTED;
    }

   if( PtExecSt != PTEXECST_INACTIVE)
      return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
   
   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostSafeOutput                        *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostSafeOutput(UINT8) 
{
    if (ChanNum>=FASTCUTOFF_CHN0) {
        BOX->SetSafeOut(ChanNum,SafeOutput);
        LastSoCmdVal= SOCMD_NONE;
        BOX->SetSo(ChanNum,SafeOutput);
    }
}
/*******************************************************************************
*                             clsPiSlot::PreVoltage                            *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreVoltage(UINT8 *a_Writebuffer,UINT8) 
{
    if (*(UINT8 *)a_Writebuffer > VOLTAGE_HIGH) 
    {
        return DO_ILLEGAL_VALUE;
    }

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostVoltage                           *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostVoltage(UINT8) 
{
   // Update the FPGA register
   BOX->SetVoltage(ChanNum,Voltage);
   if (InputStream == DUAL_PULSE) BOX->SetVoltage(ChanNum+1,Voltage);
}
/*******************************************************************************
*                             clsPiSlot::PreSoCmdOff                           *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreSoCmdOff(UINT8 *a_Writebuffer,UINT8) 
{
    // check for valid channel number
    if(ChanNum<FASTCUTOFF_CHN0){
       return DO_FUNCTION_NOT_IMPLEMENTED;
    }

    // check for valid AV, if NaN return an error
    if(isnan(BOX->GetAv(ChanNum))){
       return DO_POINT_IS_IN_BADCTL;
    }

    // check for FCO configuration
    if (InputType != PULSEINPUT_FC) return DO_CONFIGURATION_MISMATCH_ERROR;

    if( SoCmdOff == *(UINT8 *)a_Writebuffer)
       return PA_OK;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostSoCmdOff                          *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostSoCmdOff(UINT8) 
{
   // Update the FPGA register
   if(SoCmdOff == ON)
   {
     BOX->SetSo(ChanNum,OFF);
     LastSoCmdVal = SOCMD_OFF;
   }
}
/*******************************************************************************
*                             clsPiSlot::PreSoCmdOn                            *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreSoCmdOn(UINT8 *a_Writebuffer,UINT8) 
{
    // check for valid channel number
    if(ChanNum<FASTCUTOFF_CHN0){
       return DO_FUNCTION_NOT_IMPLEMENTED;
    }

    // check for valid AV, if NaN return an error
    if(isnan(BOX->GetAv(ChanNum))){
       return DO_POINT_IS_IN_BADCTL;
    }

    // check for FCO configuration
    if (InputType != PULSEINPUT_FC) return DO_CONFIGURATION_MISMATCH_ERROR;

    if( SoCmdOn == *(UINT8 *)a_Writebuffer)
       return PA_OK;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostSoCmdOff                          *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostSoCmdOn(UINT8) 
{
   // Update the FPGA register
   if(SoCmdOn == ON)
   {
     BOX->SetSo(ChanNum,ON);
     LastSoCmdVal = SOCMD_ON;
   }
}
/*******************************************************************************
*                             clsPiSlot::PreTimeBase                           *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsPiSlot::PreTimeBase(UINT8 *a_Writebuffer,UINT8 ) 
{
    if (*(UINT8 *)a_Writebuffer > HOURS) 
    {
        return DO_ILLEGAL_VALUE;
    }    
   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostTimeBase                          *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::PostTimeBase (UINT8) 
{
}
/*******************************************************************************
*                             clsPiSlot::PreTv                                 *
*                             ==========                                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                         *
*******************************************************************************/
PASTATUS clsPiSlot::PreTv(UINT8 *a_Writebuffer,UINT8 ) 
{
   FLOAT32 ufNewVal = *(FLOAT32 *)a_Writebuffer;

   if(ChanNum < FASTCUTOFF_CHN0)
      return DO_FUNCTION_NOT_IMPLEMENTED;

   if(InputType != PULSEINPUT_FC)
      return DO_CONFIGURATION_MISMATCH_ERROR;

   if(isnan(BOX->GetAv(ChanNum)))
      return DO_POINT_IS_IN_BADCTL;

   if(isnan(ufNewVal))
      return DO_ILLEGAL_VALUE;

   if(ufNewVal <= 0.0)
      return DO_ILLEGAL_VALUE;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostTv                                *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostTv (UINT8 ) {
    // Update TV64
    // Update TV in boxslot dump record
    // Update TVRAW in FPGA register
    StoreTv64((FLOAT64)BOX->GetTv(ChanNum));
    BOX->StoreTvSync(ChanNum,(FLOAT64)BOX->GetTv(ChanNum));
    BOX->SetTvRaw(ChanNum);
}
/*******************************************************************************
*                             clsPiSlot::PreTv64                                 *
*                             ==========                                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                         *
*******************************************************************************/
PASTATUS clsPiSlot::PreTv64(UINT8 *a_Writebuffer,UINT8 ) 
{
   FLOAT64 dNewVal = *(FLOAT64 *)a_Writebuffer;

   if(ChanNum < FASTCUTOFF_CHN0)
      return DO_FUNCTION_NOT_IMPLEMENTED;

   if(InputType != PULSEINPUT_FC)
      return DO_CONFIGURATION_MISMATCH_ERROR;

   if(isnan(BOX->GetAv(ChanNum)))
      return DO_POINT_IS_IN_BADCTL;

   if(isnan(dNewVal))
      return DO_ILLEGAL_VALUE;

   if(dNewVal <= 0.0)
      return DO_ILLEGAL_VALUE;

   return PA_OK;
}
/*******************************************************************************
*                             clsPiSlot::PostTv64                                *
*                             =================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Requires update of FPGA register                                      *
*******************************************************************************/
VOID clsPiSlot::PostTv64 (UINT8 ) {
    // Update TV in PV scan record
    // Update TV in boxslot dump record
    // Update TVRAW in FPGA register
    BOX->StoreTv(ChanNum,(FLOAT32)dTv64);
    BOX->StoreTvSync(ChanNum,dTv64);
    BOX->SetTvRaw(ChanNum);
}
/*******************************************************************************
*                            clsPiSlot::GetTvPtr                               *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetTvPtr(VOID) { 
    return &(BOX->PvScanRec2[ChanNum - 1].Tv);
}
/*******************************************************************************
*                            clsPiSlot::GetAvPtr                               *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetAvPtr(VOID) { 
    return &(BOX->PvScanRec1[ChanNum - 1].Av);
}
/*******************************************************************************
*                            clsPiSlot::GetAvStsPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetAvStsPtr(VOID) { 
    return &(BOX->PvScanRec1[ChanNum - 1].AvSts);
}
/*******************************************************************************
*                            clsPiSlot::GetAvRawPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetAvRawPtr(VOID) { 
    return &(BOX->PvScanRec1[ChanNum - 1].AvRaw);
}
/*******************************************************************************
*                            clsPiSlot::GetAvRawStsPtr                         *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetAvRawStsPtr(VOID) { 
    return &(BOX->PvScanRec1[ChanNum - 1].AvRawSts);
}
/*******************************************************************************
*                            clsPiSlot::GetPlPtr                               *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetPlPtr(VOID) {
    return &(BOX->PvScanRec1[ChanNum - 1].Pl);
}
/*******************************************************************************
*                            clsPiSlot::GetPlStsPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetPlStsPtr(VOID) {
    return &(BOX->PvScanRec1[ChanNum - 1].PlSts);
}
/*******************************************************************************
*                            clsPiSlot::GetTvProcPtr                           *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetTvProcPtr(VOID) { 
    return &(BOX->PvScanRec2[ChanNum - 1].TvProc);
}
/*******************************************************************************
*                            clsPiSlot::GetSoPtr                               *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetSoPtr(VOID) { 
    return &(BOX->PvScanRec2[ChanNum - 1].So);
}
/*******************************************************************************
*                            clsPiSlot::GetTvRawPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetTvRawPtr(VOID) { 
    return &(BOX->PvScanRec2[ChanNum - 1].TvRaw);
}

/*******************************************************************************
*                            clsPiSlot::GetBadSoPtr                            *
*                            =======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsPiSlot::GetBadSoPtr(VOID) { 
    return &(BOX->PvScanRec2[ChanNum - 1].BadSo);
}
/*******************************************************************************
*                           clsPiSlot::InitSlotDatabase                        *
*                           ===========================                        *
* PURPOSE:  Utility function which initializes the slot depending on point     *
*           configuration.                                                     *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::InitSlotDatabase(BOOL bFullInit) 
{
    BOOL bObjCreate = FALSE;
    PNTTYPE PntType = PNTTYPE_PULSEINPUT;
    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitInSlot(bFullInit, bObjCreate);    
    InitPiSlot(bFullInit, bObjCreate);
    ComputeCheckSum(); // Recompute SLOT checksum
}
/*******************************************************************************
*                           clsPiSlot::InactivateSlot                          *
*                           ====================                               *
* PURPOSE:  InactivateSlot                                                     *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:   NONE                                                               *
* NOTES: !!!*** TO REVIEW ***!!!                                                                      *
*******************************************************************************/
VOID clsPiSlot::InactivateSlot(VOID) 
{      
}
/*******************************************************************************
*                           clsPiSlot::ProcessSlotIntegration                  *
*                           =================================                  *
* PURPOSE: Update PV on completion of the configured integration period        *
* ARGUMENTS: None                                                              *
* RETURN: None                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsPiSlot::ProcessSlotIntegration(VOID)
{
  UINT8 ucBitMask = 0x01 << (ChanNum-1);
  FLOAT32 ufNewPv;
  UINT32  ulNewAvRaw,ulNewFRC;

  // Get the counter values and reset the IP interrupt flag
  ulNewAvRaw = BOX->GetPvCounter(ChanNum);
  ulNewFRC = BOX->GetFRC(ChanNum);
  
  if ((PtExecSt == PTEXECST_INACTIVE) || (BOX->GetModuleStatus() == MODSTATUS_IDLE))
      ufNewPv = NaN;
  else {
      // Calculate Pv partial value
      switch(TimeBase){
          case SECONDS:
              ufNewPv = (ufC1/ufC2);
          break;       
          case MINUTES:
              ufNewPv = ((ufC1/ufC2)* SECS_PER_MIN);
          break;       
          case HOURS:
              ufNewPv = ((ufC1/ufC2)* MINS_PER_HOUR * SECS_PER_MIN);
          break;       
      }

      // Compute new PV
      ufNewPv = ufNewPv * (FLOAT32)(ulNewAvRaw-LastCount) * (CTR_TIMEBASE/(FLOAT32)(ulNewFRC-LastFRC));
  }

  // Update archived counter values
  LastCount = ulNewAvRaw;
  LastFRC = ulNewFRC;

  // Update PV and PvSts values
  // If there are hardware diag failures, set them to NaN and BAD
  if ((BOX->GetGoodChannels() & ucBitMask) == 0) ufNewPv = NaN;
  BOX->StorePv(ChanNum, ufNewPv);
  if(!isnan(ufNewPv))
      BOX->StorePvSts(ChanNum, STATUS_NORMAL);
  else
      BOX->StorePvSts(ChanNum, STATUS_BAD);
}
/*******************************************************************************
*                           clsPiSlot::SlotFaultHandler                        *
*                           =================================                  *
* PURPOSE: Handle Communications (TOG) Faults                                  *
* ARGUMENTS: None                                                              *
* RETURN: None                                                                 *
* NOTES: Call from Low Priority Task on TOG fault                              *
*******************************************************************************/
VOID clsPiSlot::SlotFaultHandler(VOID)
{
    if (!BOX->GetMainOnFault()) {
        if(ChanNum == FASTCUTOFF_CHN0) {
            if (!COMPARING0) {
                OUT_CTRL0 = 1;
                OUT_SET0 = SafeOutput;
                OUT_CTRL0 = 0;
            }
        }
        else if(ChanNum == FASTCUTOFF_CHN1) {
            if (!COMPARING1) {
                OUT_CTRL1= 1;
                OUT_SET1 = SafeOutput;
                OUT_CTRL1= 0;
            }
        }
    }
    FaultState = FAULTSTATE_FAULTED;
}


