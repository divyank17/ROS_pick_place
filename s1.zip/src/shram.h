/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : shram.h                                                     *
*    Description : Shared Ram Data Structure declaration common across  IOLINK *
*                  processor and Application Processor .                       *
*******************************************************************************/
#ifndef __SHRAMIF_HPP__
#define __SHRAMIF_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "tcapptrace.h"

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
//Shared Ram Write Message Queue Sizes Definiations
const UINT16 SHRAMMSG_QUEUESIZE  = 2480; //2.48KB
const UINT8  MAXSHRAM_MSGSIZE    = 192;
const UINT16 SHRAMMSG_BUFFERSIZE = SHRAMMSG_QUEUESIZE + MAXSHRAM_MSGSIZE;
//
/////////////////// Shared Ram Write Message Packet Format ///////////////////////
//---------------------------------------------------------------------------------------
//     0    |     1    |       2          |        3      |     4      |     5       |...
//---------------------------------------------------------------------------------------
//          |          |15..14|13...8|7..0|               |            |             |...
//---------------------------------------------------------------------------------------
//                     |      \------------------------------------------------------------------>{ 0...7   - Parameter Number       
//---------------------------------------------------------------------------------------           8...13  - Slot Number
//  MSG_NUM | MSG_SIZE |    PARAM_CODE    |  ACCESS_LEVEL |  DATA_SIZE |    DATA     |...           14..15  - Flag for Arrayed Parameter, 1 - Arrayed, 0 - Not Arrayed
//---------------------------------------------------------------------------------------         }

//Shared Ram Write Message Packet Indices Definiations
const UINT8  SHRAM_WRT_MSG_NUMBER_INDEX   = 0;
const UINT8  SHRAM_WRT_MSG_SIZE_INDEX     = 1;
const UINT8  SHRAM_WRT_PARAM_CODE_INDEX   = 2;
const UINT8  SHRAM_WRT_ACCESS_LEVEL_INDEX = 3;
const UINT8  SHRAM_WRT_DATA_SIZE_INDEX    = 4;
const UINT8  SHRAM_WRT_MSG_HEADER_SZ      = 5;

//Shared Ram Write Message Status Buffer Size
#define  SHRAM_WRT_STATUS_BUFFER_SIZE  256

//SCS Command Queue Definitions
#define BARREL_START_OFFSET 3
#define SCS_MEM_SIZE        256
#define SCS_BUFFER_SIZE     252

//SCS Command Types Definitions
#define SCS_COMMAND_MOD_STATUS   1
#define SCS_IOL_DUMPCOMPLETE     2
#define SCS_SHUTDOWN_IOM         3
#define SCS_CALIB_ENABLE         4
#define SCS_CALIB_DISABLE        5
#define SCS_LED_BLINK_ONE        6
#define SCS_LED_BLINK_TWO        7
#define SCS_LED_BLINK_THREE      8
#define SCS_LED_BLINK_FOUR       9
#define SCS_LED_BLINK_OFF        10
#define SCS_DISABLE_OUTPUTS      11
#define SCS_ENABLE_OUTPUTS       12
#define SCS_FACTCALIB_SET        13
#define SCS_FACTCALIB_CLEAR      14
#define SCS_REBOOT_IOM           15
#define SCS_COMTOG_FAILED        16
#define SCS_CTLTOG_FAILED        17
#define SCS_NOTOG_FAILED         18
#define SCS_COMMAND_MOD_STATUS_RUN_IDLE        19
#define SCS_COMMAND_MOD_STATUS_IDLE_RUN        20
#define SCS_MONITOR_SYNC          21
#define SCS_APP_COLD_INIT         22 
#define SCS_APP_POST_SYNC         23 
#define SCS_ENTER_FACTTEST_MODE   24 
#define SCS_NOT_FACTTEST_MODE     25 
#define SCS_START_APP_WDT_TST     26 
#define SCS_COMMAND_TST_TIME      27
#define SCS_DROP_SYNC             28

//Data Type Definitions
#define SZ_DT_UINT8   1
#define SZ_DT_BOOL    1
#define SZ_DT_UINT16  2
#define SZ_DT_INT16   2
#define SZ_DT_ENUM    1
#define SZ_DT_SDENUM  2
#define SZ_DT_INT32   4
#define SZ_DT_UINT32  4
#define SZ_DT_FLOAT32 4
#define SZ_DT_FLOAT64 8

//NOP to be used for triggering Edge triggered interrupt to APP processor
//to process either write parameter messages or SCS messages.
#define INTERRUPT_NOP   5

#ifdef H8S

/*******************************************************************************
* Helper macros to pack and unpack multiple parameters in single word or byte. *
* Used to minimize the size of sync record.                                    *
* Note: These definitions are not related to shram and have to be moved to a   *
* suitable header file later.                                                  *
********************************************************************************/
/// pack
#define PACK2_AS_UI8(_v2,_v1)                           (UINT8) ((((_v2)&0xF)<<4)|((_v1)&0xF))
#define PACK4_AS_UI8(_v4,_v3,_v2,_v1)                   (UINT8) ((((_v4)&3)<<6)|(((_v3)&3)<<4)|(((_v2)&3)<<2)|((_v1)&3))
#define PACK8_AS_UI8(_v8,_v7,_v6,_v5,_v4,_v3,_v2,_v1)   (UINT8) ((((_v8)&1)<<7)|(((_v7)&1)<<6)|(((_v6)&1)<<5)|(((_v5)&1)<<4)|(((_v4)&1)<<3)|(((_v3)&1)<<2)|(((_v2)&1)<<1)|((_v1)&1))
#define PACK2_AS_UI16(_v2,_v1)                          (UINT16)((((_v2)&0xFF)<<8)|((_v1)&0xFF))
#define PACK4_AS_UI16(_v4,_v3,_v2,_v1)                  (UINT16)((((_v4)&0xF)<<12)|(((_v3)&0xF)<<8)|(((_v2)&0xF)<<4)|((_v1)&0xF))
/// unpack
#define UNPACK_UI8_TO2(_v,_v1,_v2,_type) \
    (_v1) = (_type)((_v)&0xF);\
    (_v2) = (_type)(((_v)>>4)&0xF);
#define UNPACK_UI8_TO4(_v,_v1,_v2,_v3,_v4,_type) \
    (_v1) = (_type)(_v&3);\
    (_v2) = (_type)(((_v)>>2)&3);\
    (_v3) = (_type)(((_v)>>4)&3);\
    (_v4) = (_type)(((_v)>>6)&3); 
#define UNPACK_UI8_TO8(_v,_v1,_v2,_v3,_v4,_v5,_v6,_v7,_v8,_type) \
    (_v1) = (_type)((_v)&1);\
    (_v2) = (_type)(((_v)>>1)&1);\
    (_v3) = (_type)(((_v)>>2)&1);\
    (_v4) = (_type)(((_v)>>3)&1);\
    (_v5) = (_type)(((_v)>>4)&1);\
    (_v6) = (_type)(((_v)>>5)&1);\
    (_v7) = (_type)(((_v)>>6)&1);\
    (_v8) = (_type)(((_v)>>7)&1);
#define UNPACK_UI16_TO2(_v,_v1,_v2,_type) \
    (_v1) = (_type)((_v)&0xFF);\
    (_v2) = (_type)(((_v)>>8)&0xFF);
#define UNPACK_UI16_TO4(_v,_v1,_v2,_v3,_v4,_type) \
    (_v1) = (_type)((_v)&0xF);\
    (_v2) = (_type)(((_v)>>4)&0xF);\
    (_v3) = (_type)(((_v)>>8)&0xF);\
    (_v4) = (_type)(((_v)>>12)&0xF);
///
#define IS_EVEN(_p) (0==((UINT32)(_p)&1))
///
/// Macro to get compiler to do some size validations.
#define _CompileAssert(_expr) typedef int __dummy[(_expr)];

//
/////////////////////////////////////////////////////
/// A utility class to enforce that H8S code always
/// reads multi word data from shared ram using
/// the correct mechanism. (be it semaphore or
/// multi read). Just update cast operator below.
/////////////////////////////////////////////////////
VOID* operator new(UINT32);
VOID  operator delete(VOID*);
///
template <class T>
class clsSharedData32
{
private:
    enum  { kMaxRetries = 10 };
    union
    {
        volatile T      value;
        volatile UINT32 ivalue;
    };
    clsSharedData32<T>* operator&();
public:
    clsSharedData32<T>(){
    }
    ///
    ~clsSharedData32<T>(){ 
    }
    ///
    clsSharedData32<T>(const T& val) {
        this->value = val;
    }
    ///
    clsSharedData32<T>(const clsSharedData32<T>& val) {
        this->value = val;
    }
    ///
    clsSharedData32<T>& operator = (T& val)
    {
        this->value = val;
    return *this;
    }
    ///
    template <class Other>
    clsSharedData32<T>& operator = (const Other& val){
        this->value = (T)val;
    return *this;
    }
    ///assignment
    clsSharedData32<T>& operator = (const clsSharedData32<T>& right){
       this->value = right;
    return *this;
    }
    /// for code that needs to execute as fast as possible
    /// and does not require special read,explicit method
    /// getting raw address.
    T* GetAddress(void) { 
        return &(this->value);
    }    
    /// cast operator.
    /// currently multi read.
    /// any algorithm can be employed without
    /// changing client code.
    operator T() const;
};
///

//Override the Data Types
typedef clsSharedData32<FLOAT32> SD_FLOAT32;
typedef clsSharedData32<UINT32>  SD_UINT32;
typedef clsSharedData32<INT32>   SD_INT32;

#define TURN_H8S (UINT16)1

#endif //#ifdef H8S

#ifdef DSC

//Redundacy Switch State Definitions
const UINT16 OUTCTL_MINE     = 1;
const UINT16 OUTCTL_PARTNER  = 0;
const UINT16 INHIN_ASSERTED  = 0;
const UINT16 INHIN_NEGATED   = 1;

//
#define TraceLog    ShramData.AppTraceLog

//H8S Channel Offset for channel mapping from H8S to DSC
#define  CH_OFFSET     9 
#define  period1sec    100

//Override the Data Types
#define SD_INT32    INT32
#define SD_FLOAT32  FLOAT32

#ifdef IOMTYPE_SP //For SP update operational data every 5ms
    #define SHARRAM_SCHEDULE_PERIOD (FLOAT32)5 // In units of msec
#else  //For SVP update operational data every 10ms
    #define SHARRAM_SCHEDULE_PERIOD (FLOAT32)10 // In units of msec
#endif

#endif //#ifdef DSC

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
/*******************************************************************************
*                   SHARED RAM DATABASE - Important Note                       *
*******************************************************************************/
//In Each Shared ram Structure element, element should be arragned in assigned order of there size,
//or Size of all shared RAM structure should be even number multiple of UINT16
#ifdef IOMTYPE_SVP

//SVP Box Shram Database
typedef struct tagBoxShramSlotData {
    SD_FLOAT32 ExFreq;
    SD_FLOAT32 AppProcCpuFreeAvg;
    SD_FLOAT32 AppProcCpuFreeMax;
    SD_FLOAT32 AppProcCpuFreeMin;
    SD_INT32   TstFunctTime;
    SD_FLOAT32 FieldCoilResistanceServo1;
    SD_FLOAT32 FieldCoilResistanceServo2;
    UINT16     DbValid;
    UINT16     CalibAll;
    UINT16     ModStat1;
    UINT16     ModStat2;
    UINT16     ModStat3;
    UINT16     AppProcStatReset;
    UINT16     CalibOpt;
    UINT16     CheckSum[MAXSLOTS + 1];//MaxSlots is even number of channels
    UINT16     RedSyncState;
    UINT16     CPLDVersion;
    UINT16     Bottom;
    UINT16     ServoDriveOpt;
}SVPSHRAMBOXDATA;

typedef struct tagLvdtCalibData{
    INT16  LvdtRawLo;
    INT16  LvdtRawHi;
    UINT16 Vxt_Fcal_Min;
    UINT16 Vxt_Fcal_Max;
    UINT16 FdbkA_Fcal_Min;
    UINT16 FdbkA_Fcal_Max;
    UINT16 FdbkB_Fcal_Min;
    UINT16 FdbkB_Fcal_Max;
    UINT16 ExctnFrequency;
    UINT16 LvdtCalibrationGood; 
    UINT16 Bottom;               
    UINT16 Spare;               
}LVDTCALIBDATA;

//SVP AI Channel Shram Database
typedef struct tagAiShramSlotData {
    SD_FLOAT32 Pv;
    SD_FLOAT32 LastPv;
    SD_FLOAT32 PvCalc;
    SD_FLOAT32 PvAuto;
    SD_FLOAT32 PvRaw;
    SD_FLOAT32 PvEUHi;
    SD_FLOAT32 PvEULo;
    SD_FLOAT32 PvExEUHi;
    SD_FLOAT32 PvExEULo;
    SD_FLOAT32 LoCutOff;
    SD_FLOAT32 Tf;
    SD_FLOAT32 PvP;
    SD_FLOAT32 PvTv;
    SD_FLOAT32 PvTvP;
    SD_FLOAT32 ExVol;
    SD_FLOAT32 Exc_RMS_Sum;
    SD_FLOAT32 FdbkA_RMS_Sum;
    SD_FLOAT32 FdbkB_RMS_Sum;
    UINT16     PntType;
    UINT16     PtExecSt;
    UINT16     PvSource;
    UINT16     PvSrcOpt;
    UINT16     OwdEnable;
    UINT16     BadPvFl;
    UINT16     PvExHiFl;
    UINT16     PvExLoFl;
    UINT16     PvSts;
    UINT16     PvAutoSt;
    UINT16     SensrTyp;
    UINT16     InptDir;
    UINT16     PvChar;
    UINT16     PvClamp;
    UINT16     TxWireSel;
    UINT16     VdtMode;
    UINT16     CalibVal;
    UINT16     ValvePosCalibEnb;
    UINT16     ValvePosCalibSts;
    UINT16     ApplyOffset;
    LVDTCALIBDATA CalibData[2];
    SD_FLOAT32 FiltOut;
    SD_FLOAT32 ActualAngle;
    SD_FLOAT32 AngleOffset;
}AISHRAMSLOTDATA;

//SVP DI Channel Shared Ram Database
typedef struct tagDiShramSlotData {
    UINT16  PntType;
    UINT16  PtExecSt;
    UINT16  PvSource;
    UINT16  PvSrcOpt;
    UINT16  OwdEnable;
    UINT16  LatchTimer;
    UINT16  Pv;
    UINT16  BadPvFl;
    UINT16  LastDiPv;
    UINT16  DiPvRaw;
    UINT16  InptDir;
    UINT16  DiPvAuto;
    UINT16  DiType;
    UINT16  Spare;
}DISHRAMSLOTDATA;

//SVP AO Channel Shared Ram Database
typedef struct tagAoShramSlotData {
    SD_FLOAT32 Op;
    SD_FLOAT32 FaultValue;
    SD_FLOAT32 OpFinal;
    SD_FLOAT32 OpIn0;
    SD_FLOAT32 OpIn1;
    SD_FLOAT32 OpIn2;
    SD_FLOAT32 OpIn3;
    SD_FLOAT32 OpIn4;
    SD_FLOAT32 OpIn5;
    SD_FLOAT32 OpOut0;
    SD_FLOAT32 OpOut1;
    SD_FLOAT32 OpOut2;
    SD_FLOAT32 OpOut3;
    SD_FLOAT32 OpOut4;
    SD_FLOAT32 OpOut5;
    SD_FLOAT32 B0_LInv;
    SD_FLOAT32 B1_LInv;
    SD_FLOAT32 OpInternl;
    SD_FLOAT32 B0_L;
    SD_FLOAT32 B1_L;
    SD_FLOAT32 B0_O;
    SD_FLOAT32 B1_O;
    SD_FLOAT32 Chrc_S0;
    SD_FLOAT32 Chrc_S1;
    SD_FLOAT32 Chrc_S2;
    SD_FLOAT32 Chrc_S3;
    SD_FLOAT32 Chrc_S4;
    SD_FLOAT32 B0_Inv;
    SD_FLOAT32 B1_Inv;
    SD_FLOAT32 DitherFreq;
    SD_FLOAT32 DitherAmpl;
    SD_FLOAT32 PrcSafeOp1;
    SD_FLOAT32 PrcSafeOp2;
    SD_FLOAT32 OpBiasCurrent;
    SD_FLOAT32 OpHiCurrent;
    SD_FLOAT32 OpLoCurrent;
    SD_FLOAT32 SecDiagCurrent;
    SD_INT32   SvpRegCtlOpConnection;
    UINT16     OutDACImg;
    UINT16     PntType;
    UINT16     PtExecSt;
    UINT16     FaultOpt;
    UINT16     FaultState;
    UINT16     ModeAttr;
    UINT16     Mode;
    UINT16     ModePerm;
    UINT16     NModeAttr;
    UINT16     NMode;
    UINT16     RedTag;
    UINT16     OptDir;
    UINT16     OpChar;
    UINT16     StdbyMan;
    UINT16     OTPT_Unused;
    UINT16     IntrLckFlOpt1;
    UINT16     IntrLckFlOpt2;
    UINT16     OptType;
    UINT16     PrcIntLck1;
    UINT16     PrcIntLck2;
    UINT16     InitReq;
    UINT16     OpAction;
    UINT16     SecDiagEnb;
    UINT16     IntrLck1Sts;
    UINT16     IntrLck2Sts;
    UINT16     DitherWaveform;
}AOSHRAMSLOTDATA;

//SVP REGCTL Channel Shared Ram Database
typedef struct tagRegCtlShramSlotData {
    SD_FLOAT32 Pv;
    SD_FLOAT32 Pv1;
    SD_FLOAT32 Pv2;
    SD_FLOAT32 LastGoodPv;
    SD_FLOAT32 PvEUHi;
    SD_FLOAT32 PvEULo;
    SD_FLOAT32 T1;
    SD_FLOAT32 T1HiLm;
    SD_FLOAT32 T1LoLm;
    SD_FLOAT32 T2;
    SD_FLOAT32 T2HiLm;
    SD_FLOAT32 T2LoLm;
    SD_FLOAT32 GainHiLm;
    SD_FLOAT32 GainLoLm;
    SD_FLOAT32 K;
    SD_FLOAT32 Sp;
    SD_FLOAT32 SpHiLm;
    SD_FLOAT32 SpLoLm;
    SD_FLOAT32 SpTol;
    SD_FLOAT32 Op;
    SD_FLOAT32 OpHiLm;
    SD_FLOAT32 OpLoLm;
    SD_FLOAT32 OpExHiLm;
    SD_FLOAT32 OpExLoLm;
    SD_FLOAT32 OpMinChg;
    SD_FLOAT32 OpBiasFixed;
    SD_FLOAT32 OpBiasRate;
    SD_FLOAT32 OpBias;
    SD_FLOAT32 OpEu;
    SD_FLOAT32 SafeOp;
    SD_FLOAT32 OpTol;
    SD_FLOAT32 Cv;
    SD_FLOAT32 CvEuHi;
    SD_FLOAT32 CvEuLo;
    SD_FLOAT32 InitVal;
    SD_FLOAT32 SecInitVal;
    SD_FLOAT32 PriInitVal;
    SD_FLOAT32 OpBiasFloat;
    SD_INT32   Pv1Connection;
    SD_INT32   Pv2Connection;
    SD_INT32   TimeoutCount;
    UINT32     TmOutTime;
    UINT16     PntType;
    UINT16     PtExecSt;
    UINT16     Mode;
    UINT16     ModeAttr;
    UINT16     NMode;
    UINT16     NModeAttr;
    UINT16     ModePerm;
    UINT16     RedTag;
    UINT16     PrefPvSrc;
    UINT16     BadPvFl;
    UINT16     PvTrakOpt;
    UINT16     PvTrakOptAi;
    UINT16     OpHiFl;
    UINT16     OpLoFl;
    UINT16     OpExHiFl;
    UINT16     OpExLoFl;
    UINT16     SpHiFl;
    UINT16     SpLoFl;
    UINT16     CtlEqn;
    UINT16     CtlActn;
    UINT16     CtlState;    
    UINT16     CtlInit;
    UINT16     GainOpt;
    UINT16     EqnEuUnitsOpt;
    UINT16     BadCtlOpt;
    UINT16     BadCtlFl;
    UINT16     InitMan;
    UINT16     TmOutMode;
    UINT16     OutInd;
    UINT16     ArwNet;
    UINT16     ArwOp;
    UINT16     SecArwSts;
    UINT16     SecStatus;
    UINT16     PvSts;
    UINT16     Pv1Sts;
    UINT16     Pv2Sts;
    UINT16     PriArwSts;
    UINT16     PriStatus;
    UINT16     TimeoutFlag;
    UINT16     InitReq;
    UINT16     PvSel;
    UINT16     Spare;
}REGCTLSHRAMSLOTDATA;

//SVP AI, DI, AO and REGCTL Channels Shared Ram Database
typedef struct tagShramSlotData {
    SVPSHRAMBOXDATA     SvpShramBoxData;
    AISHRAMSLOTDATA     AiShramSlotData[AI_MAXSLOTS];
    DISHRAMSLOTDATA     DiShramSlotData[DI_MAXSLOTS];
    AOSHRAMSLOTDATA     AoShramSlotData[AO_MAXSLOTS];
    REGCTLSHRAMSLOTDATA RegCtlShramSlotData[SVPREGCTL_MAXSLOTS];
}SHRAMSLOTDATA;

#endif //#ifdef IOMTYPE_SVP

#ifdef IOMTYPE_SP

//SP  Box Channel Shram Database
typedef struct tagBoxShramSlotData {
    SD_FLOAT32 AppProcCpuFreeMin;
    SD_FLOAT32 AppProcCpuFreeMax; 
    SD_FLOAT32 AppProcCpuFreeAvg; 
    SD_FLOAT32 LastTripTime;
    SD_INT32   TstFunctTime;
    UINT16     DbValid;
    UINT16     ModStat1;
    UINT16     ModStat2;
    UINT16     ModStat3;
    UINT16     StatReset;
    UINT16     RevRotChnlA;
    UINT16     RevRotChnlB;
    UINT16     CalibAll;
    UINT16     ResetTrip;
    UINT16     CalibOpt;
    UINT16     LastTripReason;
    UINT16     RevRotFl;
    UINT16     CheckSum[MAX_APP_SLOTS + 1];//MaxDscSlots is Odd number of channels
    UINT16     RedSyncState;
    UINT16     RotationDirData;
}SPSHRAMBOXDATA;

//SP DI Channel Shared Ram Database
typedef struct tagDiShramSlotData {
    UINT16  PntType;
    UINT16  PtExecSt;
    UINT16  PvSource;
    UINT16  PvSrcOpt;
    UINT16  OwdEnable;
    UINT16  LatchTimer;
    UINT16  Pv;
    UINT16  BadPvFl;
    UINT16  LastDiPv;
    UINT16  DiPvRaw;
    UINT16  InptDir;
    UINT16  DiPvAuto;
    UINT16  DiType;
    UINT16  DiPvFlWrst;
}DISHRAMSLOTDATA;

//SP Speed Channel Shram Database
typedef struct tagSpeedShramSlotData {
    SD_FLOAT32 Pv;
    SD_FLOAT32 LastPv;
    SD_FLOAT32 PvCalc;
    SD_FLOAT32 PvAuto;
    SD_FLOAT32 PvRaw;
    SD_FLOAT32 RocPv;
    SD_FLOAT32 PvP;
    SD_FLOAT32 PvTv;
    SD_FLOAT32 PvTvP;
    SD_FLOAT32 GearRatio;
    SD_FLOAT32 RocPosLm;
    SD_FLOAT32 PvHiAlmTP;
    SD_FLOAT32 PvHHAlmTP;
    SD_FLOAT32 RocPosHiAlmTP;
    SD_FLOAT32 RocPosHHAlmTP;
    SD_FLOAT32 LastROCNegLldrCrSpd;
    SD_FLOAT32 LastROCPosHhdrNmSpd;
    SD_FLOAT32 CriticalSpd;
    SD_FLOAT32 NominalSpd;
    UINT16     PntType;
    UINT16     PtExecSt;
    UINT16     PvSts;
    UINT16     PvAutoSt;
    UINT16     BadPvFl;
    UINT16     PvClamp;
    UINT16     PvSource;
    UINT16     PvSrcOpt;
    UINT16     OwdEnable;
    UINT16     SensrType;
    UINT16     TeethCount;
    UINT16     EdgeDetect;
    UINT16     OwdFl;
    UINT16     MisgPulFl;
    UINT16     DefmPulFl;
    UINT16     ExciFailFl;
    UINT16     ZeroSpdFl;
    UINT16     PvHiAlmFL;  
    UINT16     PvHHAlmFL;  
    UINT16     PvHHAlmFlwrst;  
    UINT16     RocPosHiAlmFL;  
    UINT16     RocPosHHAlmFL;  
    UINT16     RocPosHHAlmFlwrst;
    UINT16     FilterTime;
    SD_FLOAT32 KFactor;
    SD_FLOAT32 MinFlowRate;
    SD_FLOAT32 KMinFlowRate;
    SD_FLOAT32 MaxFlowRate;
    SD_FLOAT32 KMaxFlowRate;
    UINT16     MeasurementType;
    UINT16     OrderOfKFactor;
    UINT16     TimeUnit;
    UINT16     ResetPv;
}SPEEDSHRAMSLOTDATA;

//SP DO Channel Shared Ram Database
typedef struct tagDoShramSlotData {
    SD_FLOAT32 OnPulse;
    SD_FLOAT32 FaultValue;
    UINT16     SO;
    UINT16     PntType;
    UINT16     PtExecSt;
    UINT16     FaultOpt;
    UINT16     FaultState;
    UINT16     LocalMan;
    UINT16     ModeAttr;
    UINT16     Mode;
    UINT16     ModePerm;
    UINT16     NModeAttr;
    UINT16     NMode;
    UINT16     RedTag;
    UINT16     SoInitVal;
    UINT16     SoReadFail;
    UINT16     StdbyMan;
    UINT16     InitReq;
    UINT16     DoType;
    UINT16     ReadyToGo;
    SD_INT32  IntLck1Src;
    SD_INT32  IntLck2Src;
    SD_INT32  IntLck3Src;
    SD_INT32  IntLck4Src;
    SD_INT32  IntLck5Src;
    SD_INT32  IntLck6Src;
    SD_INT32  IntLck7Src;
    SD_INT32  IntLck8Src;
    UINT16    IntLck1Dxn;
    UINT16    IntLck2Dxn;
    UINT16    IntLck3Dxn;
    UINT16    IntLck4Dxn;
    UINT16    IntLck5Dxn;
    UINT16    IntLck6Dxn;
    UINT16    IntLck7Dxn;
    UINT16    IntLck8Dxn;
    UINT16    IntLck1Status;
    UINT16    IntLck2Status;
    UINT16    IntLck3Status;
    UINT16    IntLck4Status;
    UINT16    IntLck5Status;
    UINT16    IntLck6Status;
    UINT16    IntLck7Status;
    UINT16    IntLck8Status;
    UINT16    LastTripSrc;
    UINT16    TripTimeInfo;
    UINT16    IntLck1;
    UINT16    IntLck2;
    UINT16    IntLck3;
    UINT16    IntLck4;
    UINT16    IntLck5;
    UINT16    IntLck6;
    UINT16    IntLck7;
    UINT16    IntLck8;
    UINT16    LastSO;
    UINT16    PulseInProgress;
    UINT32    TPEnd;
}DOSHRAMSLOTDATA;

//SP Voting Block Shared Ram Database
typedef struct tagVoteShramSlotData {
    SD_FLOAT32 Pv1;
    SD_FLOAT32 Pv2;
    SD_FLOAT32 Pv3;
    SD_FLOAT32 Pv4;
    SD_FLOAT32 VotPV1;
    SD_FLOAT32 VotPV2;
    SD_FLOAT32 VotROC1;
    SD_FLOAT32 VotROC2;
    SD_FLOAT32 LastVotPV1;
    SD_FLOAT32 LastVotPV2;
    SD_FLOAT32 LastVotROC1;
    SD_FLOAT32 LastVotROC2;
    SD_FLOAT32 VotPVMax;
    SD_FLOAT32 VotPVOnTrip;
    SD_FLOAT32 VotROCPosHhOnTrip;
    SD_FLOAT32 VotPv1HiAlmTp;
    SD_FLOAT32 VotPv2HiAlmTp;
    SD_FLOAT32 VotPv1HhAlmTp;
    SD_FLOAT32 VotPv2HhAlmTp;
    SD_FLOAT32 VotRoc1PosHiAlmTp;
    SD_FLOAT32 VotRoc2PosHiAlmTp;
    SD_FLOAT32 VotRoc1PosHhAlmTp;
    SD_FLOAT32 VotRoc2PosHhAlmTp;
    SD_FLOAT32 VotRoc1NegAlmTp;
    SD_FLOAT32 VotRoc2NegAlmTp;
    SD_FLOAT32 VotRoc1PosAlmTp;
    SD_FLOAT32 VotRoc2PosAlmTp;
    SD_INT32   Pv1Connect;
    SD_INT32   Pv2Connect;
    SD_INT32   Pv3Connect;
    SD_INT32   Pv4Connect;
    UINT16     PntType;
    UINT16     PtExecSt;
    UINT16     VotAlgGrp1;      
    UINT16     VotAlgGrp2;      
    UINT16     Grp1nMin;        
    UINT16     Grp2nMin;        
    UINT16     MedOpt1;         
    UINT16     MedOpt2;         
    UINT16     VotPV1OvrTstEnb;
    UINT16     VotPV2OvrTstEnb;
    UINT16     Grp1IgnFl;
    UINT16     Grp2IgnFl;
    UINT16     VotPV1Sts;
    UINT16     VotPV2Sts;
    UINT16     VotROC1Sts;
    UINT16     VotROC2Sts;  
    UINT16     Grp1IgnoredFl[4];
    UINT16     Grp2IgnoredFl[4];
    UINT16     Grp1VotChEnb[4]; 
    UINT16     Grp2VotChEnb[4]; 
    UINT16     VotPv1HiAlmFl;
    UINT16     VotPv2HiAlmFl;
    UINT16     VotPv1HhAlmFl;
    UINT16     VotPv1HhAlmFlWrst;
    UINT16     VotPv2HhAlmFl;
    UINT16     VotPv2HhAlmFlWrst;
    UINT16     VotRoc1PosHiAlmFl;
    UINT16     VotRoc2PosHiAlmFl;
    UINT16     VotRoc1PosHhAlmFl;
    UINT16     VotRoc2PosHhAlmFl;
    UINT16     VotRoc1PosHhAlmFlWrst;
    UINT16     VotRoc2PosHhAlmFlWrst;
    UINT16     VotRoc1NegAlmFl;
    UINT16     VotRoc2NegAlmFl;
    UINT16     VotRoc1PosAlmLmt;
    UINT16     VotRoc2PosAlmLmt;
    UINT16     VotRoc1NegAlmLmt;
    UINT16     VotRoc2NegAlmLmt;
}VOTESHRAMSLOTDATA;

//SP DI, DO, SPEED Channels and Voting block Shared Ram Database
typedef struct tagShramSlotData {
    SPSHRAMBOXDATA      SpShramBoxData;
    DISHRAMSLOTDATA     DiShramSlotData[DI_MAXSLOTS];
    SPEEDSHRAMSLOTDATA  SpeedShramSlotData[SP_MAXSLOTS];
    DOSHRAMSLOTDATA     DoShramSlotData[DO_MAXSLOTS];
    VOTESHRAMSLOTDATA   VoteShramSlotData;
}SHRAMSLOTDATA;

#endif // #ifdef IOMTYPE_SP

#include "sharedcommon.h"

//Shared Ram Database
typedef struct tagShramData {
    strCommonSharedData BootData;
    volatile UINT16     uwpShramWrtMsgRemove;                               // Remove Index
    volatile UINT16     uwpShramWrtMsgAppend;                               // Append Index
    UINT16              uwShramWrtMsgBuffer[SHRAMMSG_BUFFERSIZE];           // Write Message Data Buffer
    UINT16              ucShramWrtMsgStatus[SHRAM_WRT_STATUS_BUFFER_SIZE];  // Write Status Buffer
    SHRAMSLOTDATA       ShramSlotData;                                      // Shared Ram Channels Database
    volatile UINT16     ScsMem[SCS_MEM_SIZE];                               // iolink processor SCS queue instance
    volatile UINT16     ScsMemApp[SCS_MEM_SIZE];                            // application processor SCS queue instance
    clsAppTraceLog      AppTraceLog;                                        // application processor tracelog class instance
}SHRAMDATA;

//Instance of Shared Ram data
extern SHRAMDATA ShramData;
//
/*******************************************************************************
*                   clsShramWriteMsgQueue Class Declaration                    *
*                   =======================================                    *
*******************************************************************************/
class clsShramWriteMsgQueue {
protected:
    clsShramWriteMsgQueue(const clsShramWriteMsgQueue&); 
    clsShramWriteMsgQueue& operator=(const clsShramWriteMsgQueue&); 

public:
    clsShramWriteMsgQueue(VOID) {
        ShramData.uwpShramWrtMsgAppend = ShramData.uwpShramWrtMsgRemove = 0;
    }

    ~clsShramWriteMsgQueue(VOID) {}    

    VOID *operator new(UINT32)   { return NULL; }
    VOID operator delete(VOID *) {};

    inline UINT16 *GetRcvBufPtr(VOID)  { return (ShramData.uwpShramWrtMsgAppend + ShramData.uwShramWrtMsgBuffer); }
    inline UINT16 *GetNextMsgPtr(VOID) { return (ShramData.uwpShramWrtMsgRemove + ShramData.uwShramWrtMsgBuffer); }

    inline UINT8 GetMsgStatus(UINT8 a_ucMsgNum) { 
        return ShramData.ucShramWrtMsgStatus[a_ucMsgNum]; 
    }

    inline VOID SetMsgStatus(UINT8 a_ucMsgNum, UINT8 a_ucMsgStatus) {
        ShramData.ucShramWrtMsgStatus[a_ucMsgNum] = a_ucMsgStatus;
    }

    inline BOOL IsRcvBfrEmpty(VOID) {
        return (ShramData.uwpShramWrtMsgRemove == ShramData.uwpShramWrtMsgAppend) ? TRUE : FALSE;
    }

    inline BOOL WillRcvBfrOverflow(UINT8 a_ucMsgSize) {
        UINT16 usFreeSpace = 0;
        if (ShramData.uwpShramWrtMsgAppend >= ShramData.uwpShramWrtMsgRemove) {
            usFreeSpace = SHRAMMSG_QUEUESIZE - (ShramData.uwpShramWrtMsgAppend - ShramData.uwpShramWrtMsgRemove) - a_ucMsgSize;
        }
        else {
            usFreeSpace = (ShramData.uwpShramWrtMsgRemove - ShramData.uwpShramWrtMsgAppend) - a_ucMsgSize;
        }
        return (usFreeSpace < MAXSHRAM_MSGSIZE) ? TRUE : FALSE;
    }  

    inline UINT8 * GetMsgBufferPtr(VOID){ return (UINT8*)&ShramData.uwShramWrtMsgBuffer;}
#ifdef H8S
    VOID AddMessage(UINT8 a_ucMsgNumber, UINT8 a_ucMsgSize);

    PASTATUS UpdateParameterToWriteShramQueue(UINT8 ParamCode, UINT8 SlotId, UINT8 dataSize,UINT8 accesslevel, void* ParamData);
    PASTATUS UpdateParameterToWriteShramQueue(UINT8 ParamCode, UINT8 SlotId, UINT8 dataSize,UINT8 accesslevel, void* ParamData,UINT8 uIndex);
    PASTATUS UpdateChkPntDataToWriteShramQueue(UINT8 ParamCode, UINT8 SlotId, UINT8 dataSize,UINT8 accesslevel, UINT8* ParamData);
#else
    //Use of local variable in this function to calculate the next Remove pointer
    //is deliberate.  This is done to ensure that Remove pointer is changed atomically.
    //DO NOT ATTEMPT TO OPTIMIZE THIS FUNCTION!!!!!!!!!!
    inline VOID RemoveMessage(UINT16 a_ucMsgSize) {
        UINT16 RemovePtr = ShramData.uwpShramWrtMsgRemove;
        RemovePtr += a_ucMsgSize;
        if (RemovePtr >= SHRAMMSG_QUEUESIZE) {
            RemovePtr -= SHRAMMSG_QUEUESIZE;
        }
        ShramData.uwpShramWrtMsgRemove = RemovePtr;
    }

    BOOL ReadDataFromShram(UINT16* upMsgNumber,UINT16* upParamCode,UINT16* upAccessLevel, UINT16* upDataSize, VOID* pParamData,UINT16* upIndex);
    VOID UpdateShramDataToDatabase(UINT16 uMsgNumber, UINT16 uParamCode, UINT16 uAccessLevel, UINT16 uDataSize, VOID* pParamData,UINT16 uIndex);

    static VOID InitFpgaSharedRamIniterface(VOID);
    static VOID SharedRAMQueueProcessing(VOID);
    
    //Function to update the operational data to shared RAM for IOLINK processor
    static VOID UpdateSharedRAMData(VOID);
#endif //#ifdef H8S
};

/*******************************************************************************
*                   Io Link Fifo Class Declaration                             *
*                   ==============================                             *
*******************************************************************************/
class clsIoLinkFifo
{
  private:
    //-----------------------------------------------------------------------
    // Private Data Members
    //-----------------------------------------------------------------------
    volatile UINT16* h_addrFifoSize;
    volatile UINT16* h_addrAppend;         //Points to the next location to add
    volatile UINT16* h_addrRemove;         //Points to the next location to remove
    volatile UINT16* c_addrFifo;

  public:   // Public methods

    clsIoLinkFifo(void)  {};
    ~clsIoLinkFifo(void) {};
  
    //-----------------------------------------------------------------------
    // Documentation:
    //    This initializes the FIFO.
    //-----------------------------------------------------------------------
    void clsIoLinkFifoInit(UINT32 shram_offset, UINT16 size)
    {
      c_addrFifo = (UINT16*)shram_offset;
    
      h_addrFifoSize = c_addrFifo;

      h_addrAppend = c_addrFifo + 1;

      h_addrRemove = c_addrFifo + 2;

      set_FifoSize(size);
      set_AppendOffset(BARREL_START_OFFSET);
      set_RemoveOffset(BARREL_START_OFFSET);
    }

    //-----------------------------------------------------------------------
    // Documentation:
    //    Return the number of free slots in the FIFO.
    //-----------------------------------------------------------------------
    UINT16 GetNumFree(void)
    {
      UINT16 cFree;
      if ( get_AppendOffset() >= get_RemoveOffset() )
      {
        cFree = get_FifoSize() - BARREL_START_OFFSET - (get_AppendOffset() - get_RemoveOffset()) - 1;
      }
      else
      {
        cFree = get_RemoveOffset() - get_AppendOffset() - 1;
      }
      return cFree;
    }

    //-----------------------------------------------------------------------
    // Documentation:
    //    Return the number of entries in the FIFO.
    //-----------------------------------------------------------------------
    UINT16 GetNumEntries(void)
    {
      return ( get_FifoSize() - BARREL_START_OFFSET - GetNumFree() - 1 );
    }

    //-----------------------------------------------------------------------
    // Other Operations
    // Documentation:
    //    This is the generic routine for adding data to the
    //    FIFO.  A null pointer will be returned in case of
    //    error, i.e. fifo is full.
    //
    // Concurrency:   Sequential
    //-----------------------------------------------------------------------
    BOOL StoreNextEntry(UINT16 entry)
    {
      if (!isfull())
      {
        set_data (get_AppendOffset(), entry);
        if (get_AppendOffset() == (get_FifoSize()-1))
        {
          set_AppendOffset(BARREL_START_OFFSET);
        }
        else
        {
          set_AppendOffset(get_AppendOffset()+1);
        }
        return (TRUE);
      }
      else
      {
        return (FALSE);
      }
    }

    //-----------------------------------------------------------------------
    // Documentation:
    //    This is the routine for adding SCS commands to the SCS Fifo.
    //    The SCS append-offset is not updated until after all bytes of the
    //    SCS command have been appended to the FIFO to avoid premature
    //    processing by the co-processor.
    //
    //    Returns TRUE if successful or FALSE in case the command does not
    //    fit.
    //
    // Concurrency:   Sequential
    //-----------------------------------------------------------------------
    BOOL StoreScsCommand( UINT16* command, UINT16 cmdSize );
    BOOL SendSCSCommand( UINT16 command);

    //-----------------------------------------------------------------------
    // Documentation:
    //    This is the generic routine to get the next available
    //    entry off the FIFO.   A null pointer will be returned
    //    in case of errors such as FIFO empty
    //
    // Concurrency:   Sequential
    //-----------------------------------------------------------------------
    UINT16 GetNextEntry(void);

  private:    // Private methods
    //-----------------------------------------------------------------------
    // Is empty and is full function prototypes
    //-----------------------------------------------------------------------
    BOOL isfull (void) 
    {
      if (((get_AppendOffset() == (get_FifoSize()-1) ) && (get_RemoveOffset() == BARREL_START_OFFSET)) ||
          (get_AppendOffset() == get_RemoveOffset()-1))
      {
        return (TRUE);
      }
      else
      {
        return(FALSE);
      }
    }

    BOOL isempty (void) { return ((get_AppendOffset() == get_RemoveOffset()) ? 1 : 0); }

    //-----------------------------------------------------------------------
    // Get and Set Operations for Has Relationships
    //-----------------------------------------------------------------------
    UINT16 get_data(const UINT16 index)
    { 
      return *(c_addrFifo+index);
    }

    void  set_data(const UINT16 index, UINT16 const value)
    {
      *(c_addrFifo+index) = value;
    }

    //-----------------------------------------------------------------------
    // Documentation:
    //    This is the append offset into the FIFO array at which
    //    entities will add a pointer values.
    //-----------------------------------------------------------------------
    UINT16 get_AppendOffset(void) { return *(h_addrAppend); }
    void  set_AppendOffset(const UINT16 value);
    
    //-----------------------------------------------------------------------
    // Documentation:
    //    This is the offset into the FIFO where the next value
    //    can be retrieved.
    //-----------------------------------------------------------------------
    UINT16 get_RemoveOffset(void) { return *(h_addrRemove); }
    void  set_RemoveOffset(const UINT16 value) { *h_addrRemove = value; }
  
    //-----------------------------------------------------------------------
    // Documentation:
    //    This is the FIFO size.
    //-----------------------------------------------------------------------
    UINT16 get_FifoSize(void) { return *(h_addrFifoSize); }
    void  set_FifoSize(const UINT16 value) { *h_addrFifoSize = value; }

};

#ifdef DSC
/*******************************************************************************
*                    Semaphore helper functions                                *
*******************************************************************************/
//Capture semaphore ensures that interrupts are disabled so that 
//a multi word data being modified by the application processor is not interrupted in the middle.
//This ensures that there is no undue delay between the modification of 2 words of multiword data.
inline BOOL CaptureSemaphore(UINT16)
{
    DINT;
    return TRUE;
}
inline VOID ReleaseSemaphore(UINT16)
{
    EINT;
}
#endif //#ifdef DSC

#endif //__SHRAMIF_HPP__
