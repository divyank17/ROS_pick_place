/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : wrmsgque.hpp                                                *
*    Description : Write message queue object declaration.                     *
*******************************************************************************/
#ifndef __WRMSGQUE_HPP__
#define __WRMSGQUE_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "datatype.h"
#if defined(IOMTYPE_AIHBOOT) || defined(IOMTYPE_AOHBOOT) || \
defined(IOMTYPE_LLMUXBOOT) || defined(IOMTYPE_DIBOOT)    || \
defined(IOMTYPE_DISOEBOOT) || defined(IOMTYPE_DOBOOT)    || \
defined(IOMTYPE_SVPBOOT)   || defined(IOMTYPE_SPBOOT)    || \
defined(IOMTYPE_PIBOOT)    || defined(IOMTYPE_UIOBOOT)
#include "..\boot\boxslot.hpp"
#else
#include "boxslot.hpp"
#endif
/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
#if defined(IOMTYPE_AIHBOOT) || defined(IOMTYPE_AOHBOOT) || \
defined(IOMTYPE_LLMUXBOOT) || defined(IOMTYPE_DIBOOT)    || \
defined(IOMTYPE_DISOEBOOT) || defined(IOMTYPE_DOBOOT)    || \
defined(IOMTYPE_SVPBOOT)   || defined(IOMTYPE_SPBOOT)    || \
defined(IOMTYPE_PIBOOT)    || defined(IOMTYPE_UIOBOOT)
const UINT16 WRITEMSG_QUEUESIZE = 2048; // 2 kb
#else
#if AIAO
// Increased size of queue as it was causing buffer overflow during 
// checkpoint restore. (1-1JUF65 )
const UINT16 WRITEMSG_QUEUESIZE = 3072; // 3 kb
#else
const UINT16 WRITEMSG_QUEUESIZE = 2048; // 2 kb
#endif
#endif
const UINT16 WRITEMSG_BUFFERSIZE = WRITEMSG_QUEUESIZE + IOL_MAXRCV_MSGSIZE;
const UINT16 WRITESTS_ARRAYSIZE = 256;

#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
    #include "shram.h"
    extern clsShramWriteMsgQueue ShramWriteMsgQueue; //Shared Ram Write Message Queue
#endif
/*******************************************************************************
*                              clsWriteMessageQueue                            *
*                              ====================                            *
*******************************************************************************/
class clsWriteMsgQueue {
protected:
    UINT8 ucMsgBuffer[WRITEMSG_BUFFERSIZE];
    UINT8 ucMsgStatus[WRITESTS_ARRAYSIZE];
    UINT8 *ucpAppend;
    UINT8 *ucpRemove;

    clsWriteMsgQueue(const clsWriteMsgQueue&); 
    clsWriteMsgQueue& operator=(const clsWriteMsgQueue&); 

public:
    clsWriteMsgQueue(VOID) {
        ucpAppend = ucpRemove = ucMsgBuffer;
    }
    #if defined(IOMTYPE_AIHBOOT) || defined(IOMTYPE_AOHBOOT)   || \
    defined(IOMTYPE_LLMUXBOOT)   || defined(IOMTYPE_DIBOOT)    || \
    defined(IOMTYPE_DOBOOT)      || defined(IOMTYPE_DISOEBOOT) || \
    defined(IOMTYPE_SVPBOOT)     || defined(IOMTYPE_SPBOOT)    || \
    defined(IOMTYPE_PIBOOT)      || defined(IOMTYPE_UIOBOOT)
    ~clsWriteMsgQueue(VOID) { HardFail(HF_INVPROGRAMEXEC); }    
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC); };
    #else
    ~clsWriteMsgQueue(VOID) { HardFail(HF_INVPROGRAMEXEC,WRMSGQUE_HPP,__LINE__); }    
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,WRMSGQUE_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,WRMSGQUE_HPP,__LINE__); };
    #endif

    inline UINT8 *GetRcvBufPtr(VOID) { return ucpAppend; }
    inline UINT8 *GetNextMsgPtr(VOID) { return ucpRemove; }
    inline UINT8 GetMsgStatus(UINT8 a_ucMsgNum) { 
        return ucMsgStatus[a_ucMsgNum]; 
    }
    inline VOID SetMsgStatus(UINT8 a_ucMsgNum, UINT8 a_ucMsgStatus) {
        ucMsgStatus[a_ucMsgNum] = a_ucMsgStatus;
    }
    inline BOOL IsRcvBfrEmpty(VOID) {
        return (ucpRemove == ucpAppend) ? TRUE : FALSE;
    }
    inline BOOL WillRcvBfrOverflow(UINT8 a_ucMsgSize) {
        UINT16 usFreeSpace = 0;
        if (ucpAppend >= ucpRemove) {
            usFreeSpace = WRITEMSG_QUEUESIZE - (ucpAppend - ucpRemove) - a_ucMsgSize;
        }
        else {
            usFreeSpace = (ucpRemove - ucpAppend) - a_ucMsgSize;
        }
        return (usFreeSpace < IOL_MAXRCV_MSGSIZE) ? TRUE : FALSE;
    }
    inline VOID AddMessage(UINT8 a_ucMsgNumber, UINT8 a_ucMsgSize) {
        ucMsgStatus[a_ucMsgNumber] = IOL_WM_IN_PROGRESS;
        
        #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
            ShramWriteMsgQueue.SetMsgStatus(a_ucMsgNumber,IOL_WM_IN_PROGRESS);
        #endif
        
        ucpAppend += a_ucMsgSize;
        *ucpAppend++ = a_ucMsgNumber;
        // Check whether the append pointer is in the wrap-around extension area.
        // If yes, account for the space used in wrap-around extension at the
        // beginning of the buffer and set append pointer to the next location.
        if (ucpAppend > ucMsgBuffer + WRITEMSG_QUEUESIZE) {
            ucpAppend -= WRITEMSG_QUEUESIZE;
        }
    }
    inline VOID RemoveMessage(UINT8 a_ucMsgNumber, UINT8 a_ucMsgSize) {
        ucpRemove += a_ucMsgSize + 1;  // + 1 for message number
        if (ucpRemove > ucMsgBuffer + WRITEMSG_QUEUESIZE) {
            ucpRemove -= WRITEMSG_QUEUESIZE;
        }
        ((clsBoxSlot *)pDatabase[0])->SetMesNo(a_ucMsgNumber);
    }

    inline UINT8 * GetMsgBufferPtr(VOID){ return (UINT8*)&ucMsgBuffer;}
};

#endif
