/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcdoslot.cpp                                                *
*    Description : Class clsDoSlot definition.                                 *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern SHRAMDATA ShramData;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsDoSlot::RedParams[] = {
    kSpDoPnDoType,
    kSpDoPnPntType,
    kSpDoPnModePerm,
    kSpDoPnNMode,
    kSpDoPnNModeAttr,
    kSpDoPnModeAttr,
    kSpDoPnMode,
    kSpDoPnFaultOpt,
    kSpDoPnFaultValue,
    kSpDoPnRedTag,
    kSpDoPnOnPulse,
    kSpDoPnSo,
    kSpDoPnI1Conn,
    kSpDoPnI2Conn,
    kSpDoPnI3Conn,
    kSpDoPnI4Conn,
    kSpDoPnI5Conn,
    kSpDoPnI6Conn,
    kSpDoPnI7Conn,
    kSpDoPnI8Conn,
    kSpDoPnI1InptDir,
    kSpDoPnI2InptDir,
    kSpDoPnI3InptDir,
    kSpDoPnI4InptDir,
    kSpDoPnI5InptDir,
    kSpDoPnI6InptDir,
    kSpDoPnI7InptDir,
    kSpDoPnI8InptDir,
    kSpDoPnPtExecSt,
    0 // Terminator
};

const DOSLOTPARAMINFO clsDoSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,NoOfParams,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 0
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 1
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 2
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 3
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 4
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 5
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 6
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 7
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 8
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 9
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPntTypePtr,TRUE,                                       // 51 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPtExecStPtr,TRUE,                                     // 52 PtExecSt
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLocalManPtr,FALSE,                                    // 53 LocalMan
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetModeAttrPtr,TRUE,                                     // 54 ModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetModePtr,TRUE,                                         // 55 Mode
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetModePermPtr,TRUE,                                     // 56 ModePerm
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetNModeAttrPtr,TRUE,                                    // 57 NModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetNModePtr,TRUE,                                        // 58 NMode
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_ACTIVEANDRUN,0,0,GetOpPtr,FALSE,                               // 59 Op    
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,0,0,GetOptDirPtr,FALSE,                                   // 60 OptDir
    DT_BOOL,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetRedTagPtr,TRUE,                                       // 61 RedTag
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetStdbyManPtr,FALSE,                                    // 62 StdbyMan 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 63
    DT_BOOL,1,AT_BXPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetInitReqPtr,FALSE,                                    // 64 InitReq
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetFaultOptPtr,TRUE,                                      // 65 FaultOpt
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetFaultValuePtr,TRUE,                                 // 66 FaultValue
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetFaultStatePtr,FALSE,                                  // 67 FaultState
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVE,0,0,GetDOTypePtr,TRUE,                                    // 68 DOType
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetPeriodPtr,TRUE,                                    // 69 Period
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetSOPtr,FALSE,                                          // 70 SO
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetOnPulsePtr,FALSE,                                  // 71 OnPulse
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetOffPulsePtr,FALSE,                                 // 72 OffPulse
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPWMInitRPtr,FALSE,                                    // 73 PWMInitR
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPRDTimePtr,FALSE,                                   // 74 PRDTime
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPWMPulseTimePtr,FALSE,                              // 75 PWMPulseTime
    DT_BLIND,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetStartNextPtr,FALSE,                                  // 76 StartNext
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetTPStartPtr,FALSE,                                   // 77 TPStart
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetTPEndPtr,FALSE,                                     // 78 TPEnd
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSoInitValPtr,FALSE,                                   // 79 SoInitVal
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSoReadFailFlPtr,FALSE,                                // 80 SoReadFailFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 81 OpInitVal
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 82
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetReadyToGoPtr,FALSE,                                   // 83 ReadyToGo
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck1SrcPtr,TRUE,                                   // 84 IntLck1Src
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck2SrcPtr,TRUE,                                   // 85 IntLck2Src
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck3SrcPtr,TRUE,                                   // 86 IntLck3Src
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck4SrcPtr,TRUE,                                   // 87 IntLck4Src
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck5SrcPtr,TRUE,                                   // 88 IntLck5Src
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck6SrcPtr,TRUE,                                   // 89 IntLck6Src
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck7SrcPtr,TRUE,                                   // 90 IntLck7Src
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck8SrcPtr,TRUE,                                   // 91 IntLck8Src
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 93
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,                                   // 94 SlotSfBt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfLrsPtr,FALSE,                                  // 95 SlotSfLrs
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck1Ptr,FALSE,                                     // 96 IntLck1
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck2Ptr,FALSE,                                     // 97 IntLck2
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck3Ptr,FALSE,                                     // 98 IntLck3
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck4Ptr,FALSE,                                     // 99 IntLck4
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck5Ptr,FALSE,                                     // 100 IntLck5
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck6Ptr,FALSE,                                     // 101 IntLck6
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck7Ptr,FALSE,                                     // 102 IntLck7
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck8Ptr,FALSE,                                     // 103 IntLck8
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck1DxnPtr,TRUE,                                    // 104 IntLck1Dxn
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck2DxnPtr,TRUE,                                    // 105 IntLck2Dxn
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck3DxnPtr,TRUE,                                    // 106 IntLck3Dxn
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck4DxnPtr,TRUE,                                    // 107 IntLck4Dxn
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck5DxnPtr,TRUE,                                    // 108 IntLck5Dxn
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck6DxnPtr,TRUE,                                    // 109 IntLck6Dxn
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck7DxnPtr,TRUE,                                    // 110 IntLck7Dxn
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetIntLck8DxnPtr,TRUE,                                    // 111 IntLck8Dxn
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastTripSrcPtr,FALSE,                                 // 112 LastTripSrc
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 113
    DT_BLIND,59,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCheckPointPtr,FALSE,                                  // 114 CheckPoint
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck1StatusPtr,FALSE,                               // 115 IntLck1Status
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck2StatusPtr,FALSE,                               // 116 IntLck2Status
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck3StatusPtr,FALSE,                               // 117 IntLck3Status
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck4StatusPtr,FALSE,                               // 118 IntLck4Status
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck5StatusPtr,FALSE,                               // 119 IntLck5Status
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck6StatusPtr,FALSE,                               // 120 IntLck6Status
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck7StatusPtr,FALSE,                               // 121 IntLck7Status
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntLck8StatusPtr,FALSE,                               // 122 IntLck8Status
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 142
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 144 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 161  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 187 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 188 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 193 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 194 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 214 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 215 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 216 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 217 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 218 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 219 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 220 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 221 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 222 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 223 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 233 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 234 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 243
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,                          // 244 SlotChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 245    
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                                  // 255
};

/*******************************************************************************
*                            clsDoSlot::clsDoSlot                              *
*                            ====================                              *
* PURPOSE   : Constructor of clsDoSlot Class. which initializes  class         *
*             members.                                                         *
* ARGUMENTS : a_ucSltNm - Slot Number                                          *
* RETURN    : NONE                                                             *
* NOTES:    :                                                                  *
*******************************************************************************/
clsDoSlot::clsDoSlot(UINT8 a_ucSltNm) : clsOutSlot(PNTTYPE_NOTCONFIGURED, a_ucSltNm) {

    //Get the slot shared ram pointer into local variable
    UINT8 nSlotNum = a_ucSltNm - DO_CH_START;
    pDoShramSlotData = &ShramData.ShramSlotData.DoShramSlotData[nSlotNum];

    //Initialize the memeber varialbes
    InitDoSlot(TRUE, TRUE);
}

/*******************************************************************************
*                           clsDoSlot::operator new                            *
*                           =======================                            *
* PURPOSE  : Overrided new Operator to allocate memory to Slot                 *
* ARGUMENTS: a_ucSltNm - Slot Number                                           *
* RETURN   : returns slot memory pointer                                       *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return (ucIomDbMemory + SPBOXSLOT_SIZE + (AI_MAXSLOTS * TCSPAISLOT_SIZE)+ 
           (AO_MAXSLOTS * TCSPAOSLOT_SIZE)+ (DI_MAXSLOTS * DISLOT_SIZE) +
           ((a_ucSltNm-DO_CH_START)* TCDOSLOT_SIZE));
}

/*******************************************************************************
*                            clsDoSlot::GetDataType                            *
*                            ======================                            *
* PURPOSE  : This function returns data type of the parameter.                 *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : DataType of the parameter                                         *
* NOTES    :                                                                   *
*******************************************************************************/
DATATYPE clsDoSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsDoSlot::GetAccessType                            *
*                          ========================                            *
* PURPOSE  : This function returns accesstype of the parameter.                *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : AccessType of the parameter.                                      *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSTYPE clsDoSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                            clsDoSlot::GetParamSize                           *
*                            =======================                           *
* PURPOSE  : This function returns size of the parameter                       *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsDoSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsDoSlot::GetParamPtr                            *
*                            ======================                            *
* PURPOSE  : This function returns pointer of the parameter                    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 *clsDoSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                           clsDoSlot::GetAccessLock                           *
*                           ========================                           *
* PURPOSE  : This function returns Access Lock of the parameter.               *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Access Lock of the parameter number.                              *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSLOCK clsDoSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                       clsDoSlot::GetIsDbChecksumed                           *
*                       ============================                           *
* PURPOSE  : This function returns whether parameter.is checkpointed or not    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : BOOL - TRUE if parameter is checkpoint paramter, else FALSE       *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsDoSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsDoSlot::VerifyControlState                        *
*                         =============================                        *
* PURPOSE  : This function checks the contorl state assigned to the parameter  *
*            to actual present control state of the channel and IOM module     *
*            itself,before the actual write to the parameter.                  *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    : This function decides whether the write can be done or not to the *
*            paramerter under current channel or IOM state.                    *
*******************************************************************************/
PASTATUS clsDoSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    default:
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x920,tblParamInfo[a_ucParamNumber].ControlState);
        break;
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsDoSlot::ExecutePreFunction                        *
*                         =============================                        *
* PURPOSE  : This function invokes the pre-function for the given writable     *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber  - Parameter Number                               *
*            a_Buffer         - Pointer to the data                            *
*            a_ucAccessLevel  - Access level of the parameter                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsDoSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsDoSlot::ExecutePostFunction                       *
*                         ==============================                       *
* PURPOSE  : This function invokes the post-function for the given writable    *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber - Parameter Number                                *
*            a_ucAccessLevel - Access level of the parameter                   *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsDoSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}

/*******************************************************************************
*                           clsDoSlot::InitSlotDatabase                        *
*                           ===========================                        *
* PURPOSE  : Initialize the entire channel database. Calls the Init function   *
*            for each class in the channel object hierarchy and recompute      *
*            database checksum.                                                *
* ARGUMENTS: bFullInit - lag utilised when slots have to be reinitialized      *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsDoSlot::InitSlotDatabase(BOOL bFullInit) 
{
    BOOL bObjCreate = FALSE; 
    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitOutSlot(PNTTYPE_NOTCONFIGURED, TRUE, TRUE);
    InitDoSlot(TRUE, TRUE);

    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                           clsDoSlot::InitDoSlot                              *
*                           =====================                              *
* PURPOSE  : Initialization function for clsDoSlot data members.               *
* ARGUMENTS: bFullInit   - Flag utilised when slots have to be reinitialized   *
*            bObjCreate  - Flag utilised when slots have to be reinitialized   *
* RETURN   : NONE                                                              *
* NOTES    : This function is called when slot parameters                      *
*            need to be reinitialized                                          *
*******************************************************************************/
VOID clsDoSlot::InitDoSlot(BOOL bFullInit, BOOL bObjCreate) {
    
    if (bFullInit) {
        DOType         =  DOTYPE_STATUS;
        Period         =  10.0;
        OnPulse        =  NaN;
        OffPulse       =  NaN;
        Op             =  0.0;
        SO             =  FALSE;
        PWMInitR       =  TRUE;
        PRDTime        =  1000;
        PWMPulseTime   =  0;
        StdbyMan       =  FALSE;
        InitReq        =  TRUE;
    }

    if (bObjCreate) {
        StartNext      =  TRUE;
        TPStart        =  0;
        TPEnd          =  0;
    }
    
    IntLck1Src         = 0;
    IntLck2Src         = 0;
    IntLck3Src         = 0;
    IntLck4Src         = 0;
    IntLck5Src         = 0;
    IntLck6Src         = 0;
    IntLck7Src         = 0;
    IntLck8Src         = 0;

    IntLck1Dxn         = INTERLOCK_REVERS;
    IntLck2Dxn         = INTERLOCK_REVERS;
    IntLck3Dxn         = INTERLOCK_REVERS;
    IntLck4Dxn         = INTERLOCK_REVERS;
    IntLck5Dxn         = INTERLOCK_REVERS;
    IntLck6Dxn         = INTERLOCK_REVERS;
    IntLck7Dxn         = INTERLOCK_REVERS;
    IntLck8Dxn         = INTERLOCK_REVERS;

    IntLck1Status      = TRUE;
    IntLck2Status      = TRUE;
    IntLck3Status      = TRUE;
    IntLck4Status      = TRUE;
    IntLck5Status      = TRUE;
    IntLck6Status      = TRUE;
    IntLck7Status      = TRUE;
    IntLck8Status      = TRUE;

    IntLck1            = FALSE;
    IntLck2            = FALSE;
    IntLck3            = FALSE;
    IntLck4            = FALSE;
    IntLck5            = FALSE;
    IntLck6            = FALSE;
    IntLck7            = FALSE;
    IntLck8            = FALSE;

    LastTripSrc        = 0;
    ReadyToGo          = TRUE;
}

///////////////////////////////////////////////////////////
//Overrided clsIoSlot Class Varibles GetPtr methods
//////////////////////////////////////////////////////////
/*******************************************************************************
*                         clsDoSlot::GetPntTypePtr                             *
*                         ========================                             *
* PURPOSE  : This function returns PntType Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetPntTypePtr(VOID)    
{
    PntType    = (PNTTYPE)pDoShramSlotData->PntType;

    return &PntType; 
}

/*******************************************************************************
*                         clsDoSlot::GetPtExecStPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns PtExecSt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetPtExecStPtr(VOID)   
{ 
    PtExecSt   = (PTEXECST)pDoShramSlotData->PtExecSt;
    
    return &PtExecSt; 
}

/*******************************************************************************
*                         clsDoSlot::GetFaultStatePtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns FaultState Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetFaultStatePtr(VOID)     
{ 
    FaultState = (FAULTSTATE)pDoShramSlotData->FaultState;

    return &FaultState; 
}

/*******************************************************************************
*                         clsDoSlot::GetFaultOptPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns FaultOpt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetFaultOptPtr(VOID)       
{   
    FaultOpt = (FAULTOPT)pDoShramSlotData->FaultOpt;

    return &FaultOpt; 
}

/*******************************************************************************
*                         clsDoSlot::GetFaultValuePtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns FaultValue Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetFaultValuePtr(VOID)     
{ 
    FaultValue = pDoShramSlotData->FaultValue;

    return &FaultValue; 
}

/*******************************************************************************
*                         clsDoSlot::GetModePtr                                *
*                         =====================                                *
* PURPOSE  : This function returns Mode Parameter Pointer                      *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetModePtr(VOID)           
{ 
    Mode = (MODE)pDoShramSlotData->Mode;

    return &Mode;
}

/*******************************************************************************
*                         clsDoSlot::GetModeAttrPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns ModeAttr Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetModeAttrPtr(VOID)       
{ 
    ModeAttr = (MODEATTR)pDoShramSlotData->ModeAttr;

    return &ModeAttr; 
}

/*******************************************************************************
*                         clsDoSlot::GetModePermPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns ModePerm Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetModePermPtr(VOID)       
{ 
    ModePerm = (MODEPERM)pDoShramSlotData->ModePerm;

    return &ModePerm; 
}

/*******************************************************************************
*                         clsDoSlot::GetNModePtr                               *
*                         ======================                               *
* PURPOSE  : This function returns NMode Parameter Pointer                     *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetNModePtr(VOID)          
{
    NMode = (MODE)pDoShramSlotData->NMode;

    return &NMode; 
}

/*******************************************************************************
*                         clsDoSlot::GetNModeAttrPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns NModeAttr Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetNModeAttrPtr(VOID)      
{ 
    NModeAttr = (MODEATTR)pDoShramSlotData->NModeAttr;

    return &NModeAttr; 
}

/*******************************************************************************
*                         clsDoSlot::GetRedTagPtr                              *
*                         =======================                              *
* PURPOSE  : This function returns RedTag Parameter Pointer                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetRedTagPtr(VOID)         
{ 
    RedTag = (REDTAG)pDoShramSlotData->RedTag;

    return &RedTag; 
}

/*******************************************************************************
*                         clsDoSlot::GetSOPtr                                  *
*                         ===================                                  *
* PURPOSE  : This function returns SO Parameter Pointer                        *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetSOPtr(VOID)             
{
    SO = (BOOL)pDoShramSlotData->SO;

    return &SO;
}
         
/*******************************************************************************
*                         clsDoSlot::GetSoInitValPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns SoInitVal Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetSoInitValPtr(VOID)        
{
    SoInitVal = (BOOL)pDoShramSlotData->SoInitVal;

    return &SoInitVal;
}

/*******************************************************************************
*                         clsDoSlot::GetSoReadFailFlagPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns SoReadFailFlag Parameter Pointer            *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetSoReadFailFlPtr(VOID) 
{
    SoReadFailFlag = (BOOL)pDoShramSlotData->SoReadFail;

    return &SoReadFailFlag;
}

/*******************************************************************************
*                         clsDoSlot::GetOnPulsePtr                             *
*                         ========================                             *
* PURPOSE  : This function returns OnPulse Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetOnPulsePtr(VOID)        
{
    OnPulse = (FLOAT32)pDoShramSlotData->OnPulse;

    return &OnPulse;
}

/*******************************************************************************
*                         clsDoSlot::GetInitReqPtr                             *
*                         ========================                             *
* PURPOSE  : This function returns InitReq Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetInitReqPtr(VOID)
{
    InitReq = (BOOL)pDoShramSlotData->InitReq;

    return &InitReq;
}

/*******************************************************************************
*                         clsDoSlot::GetStdbyManPtr                            *
*                         =========================                            *
* PURPOSE  : This function returns StdbyMan Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetStdbyManPtr(VOID)
{
    StdbyMan = (BOOL)pDoShramSlotData->StdbyMan;

    return &StdbyMan;
}

/*******************************************************************************
*                         clsDoSlot::GetDOTypePtr                              *
*                         =======================                              *
* PURPOSE  : This function returns DOType Parameter Pointer                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetDOTypePtr(VOID)         
{
    DOType = (DOTYPE)pDoShramSlotData->DoType;

    return &DOType;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck1SrcPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck1Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck1SrcPtr(VOID)          
{
    IntLck1Src = (INT32)pDoShramSlotData->IntLck1Src;

    return &IntLck1Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck2SrcPtr                          *
*                         =========]]]===============                          *
* PURPOSE  : This function returns IntLck2Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck2SrcPtr(VOID)          
{
    IntLck2Src = (INT32)pDoShramSlotData->IntLck2Src;

    return &IntLck2Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck3SrcPtr                          *
*                         ======]]]==================                          *
* PURPOSE  : This function returns IntLck3Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck3SrcPtr(VOID)          
{
    IntLck3Src = (INT32)pDoShramSlotData->IntLck3Src;

    return &IntLck3Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck4SrcPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck4Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck4SrcPtr(VOID)          
{
    IntLck4Src = (INT32)pDoShramSlotData->IntLck4Src;

    return &IntLck4Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck5SrcPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck5Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck5SrcPtr(VOID)          
{
    IntLck5Src = (INT32)pDoShramSlotData->IntLck5Src;

    return &IntLck5Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck6SrcPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck6Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck6SrcPtr(VOID)          
{
    IntLck6Src = (INT32)pDoShramSlotData->IntLck6Src;

    return &IntLck6Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck7SrcPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck7Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck7SrcPtr(VOID)          
{
    IntLck7Src = (INT32)pDoShramSlotData->IntLck7Src;

    return &IntLck7Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck8SrcPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck8Src Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck8SrcPtr(VOID)          
{
    IntLck8Src = (INT32)pDoShramSlotData->IntLck8Src;

    return &IntLck8Src;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck1Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck1 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck1Ptr(VOID)          
{
    IntLck1 =  (BOOL)pDoShramSlotData->IntLck1;

    return &IntLck1;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck2Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck2 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck2Ptr(VOID)          
{
    IntLck2 =  (BOOL)pDoShramSlotData->IntLck2;

    return &IntLck2;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck3Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck3 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck3Ptr(VOID)          
{
    IntLck3 =  (BOOL)pDoShramSlotData->IntLck3;

    return &IntLck3;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck4Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck4 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck4Ptr(VOID)          
{
    IntLck4 =  (BOOL)pDoShramSlotData->IntLck4;

    return &IntLck4;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck5Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck5 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck5Ptr(VOID)          
{
    IntLck5 =  (BOOL)pDoShramSlotData->IntLck5;

    return &IntLck5;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck6Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck6 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck6Ptr(VOID)          
{
    IntLck6 =  (BOOL)pDoShramSlotData->IntLck6;

    return &IntLck6;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck7Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck7 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck7Ptr(VOID)          
{
    IntLck7 =  (BOOL)pDoShramSlotData->IntLck7;

    return &IntLck7;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck8Ptr                             *
*                         ========================                             *
* PURPOSE  : This function returns IntLck8 Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck8Ptr(VOID)          
{
    IntLck8 =  (BOOL)pDoShramSlotData->IntLck8;

    return &IntLck8;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck1StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck1Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck1StatusPtr(VOID)          
{
    IntLck1Status =  (BOOL)pDoShramSlotData->IntLck1Status;

    return &IntLck1Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck2StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck2Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck2StatusPtr(VOID)          
{
    IntLck2Status =  (BOOL)pDoShramSlotData->IntLck2Status;

    return &IntLck2Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck3StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck3Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck3StatusPtr(VOID)          
{
    IntLck3Status =  (BOOL)pDoShramSlotData->IntLck3Status;

    return &IntLck3Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck4StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck4Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck4StatusPtr(VOID)          
{
    IntLck4Status =  (BOOL)pDoShramSlotData->IntLck4Status;

    return &IntLck4Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck5StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck5Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck5StatusPtr(VOID)          
{
    IntLck5Status =  (BOOL)pDoShramSlotData->IntLck5Status;

    return &IntLck5Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck6StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck6Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck6StatusPtr(VOID)          
{
    IntLck6Status =  (BOOL)pDoShramSlotData->IntLck6Status;

    return &IntLck6Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck7StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck7Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck7StatusPtr(VOID)          
{
    IntLck7Status =  (BOOL)pDoShramSlotData->IntLck7Status;

    return &IntLck7Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck8StatusPtr                       *
*                         ==============================                       *
* PURPOSE  : This function returns IntLck8Status Parameter Pointer             *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck8StatusPtr(VOID)          
{
    IntLck8Status =  (BOOL)pDoShramSlotData->IntLck8Status;

    return &IntLck8Status;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck1DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck1Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck1DxnPtr(VOID)          
{
    IntLck1Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck1Dxn;

    return &IntLck1Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck2DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck2Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck2DxnPtr(VOID)          
{
    IntLck2Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck2Dxn;

    return &IntLck2Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck3DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck3Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck3DxnPtr(VOID)          
{
    IntLck3Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck3Dxn;

    return &IntLck3Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck4DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck4Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck4DxnPtr(VOID)          
{
    IntLck4Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck4Dxn;

    return &IntLck4Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck5DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck5Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck5DxnPtr(VOID)          
{
    IntLck5Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck5Dxn;

    return &IntLck5Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck6DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck6Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck6DxnPtr(VOID)          
{
    IntLck6Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck6Dxn;

    return &IntLck6Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck7DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck7Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck7DxnPtr(VOID)          
{
    IntLck7Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck7Dxn;

    return &IntLck7Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetIntLck8DxnPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns IntLck8Dxn Parameter Pointer                *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetIntLck8DxnPtr(VOID)          
{
    IntLck8Dxn = (INTLCKINPTDXN)pDoShramSlotData->IntLck8Dxn;

    return &IntLck8Dxn;
}

/*******************************************************************************
*                         clsDoSlot::GetReadyToGoPtr                           *
*                         ==========================                           *
* PURPOSE  : This function returns ReadyToGo Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetReadyToGoPtr(VOID)
{
    ReadyToGo =  (BOOL)pDoShramSlotData->ReadyToGo;

    return &ReadyToGo;
}

/*******************************************************************************
*                         clsDoSlot::GetLastTripSrcPtr                         *
*                         ============================                         *
* PURPOSE  : This function returns LastTripSrc Parameter Pointer               *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsDoSlot::GetLastTripSrcPtr(VOID)
{
    LastTripSrc =  (UINT8)pDoShramSlotData->LastTripSrc;

    return &LastTripSrc;
}

/*******************************************************************************
*                         clsDoSlot::GetDumpData                               *
*                         ======================                               *
* PURPOSE  : This method will copy the redundancy dump data to buffer transmit *
*            to the secondary IOM                                              *
* ARGUMENTS: pDump - Dump Pointer                                              *
*            MaxSize - Dump Size                                               *
* RETURN   : PA_OK -   If getdump is succesful                                 *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsDoSlot::GetDumpData(UINT8* const pDump,const UINT8 MaxSize)
{
    PASTATUS retVal = PA_NULL;
    if(pDump && IS_EVEN(pDump) && sizeof(SYNCRECORD) < MaxSize)
    {
        PSYNCRECORD pSyncRec        = (PSYNCRECORD)pDump;
        DOSHRAMSLOTDATA* pSlotDB    = (DOSHRAMSLOTDATA*)pDoShramSlotData;
        ///
        pSyncRec->Header        = PACK2_AS_UI16(SPDO_SYNC_VER_1,0);
        pSyncRec->PntType       = (UINT8)pSlotDB->PntType;
        pSyncRec->PtExecSt      = (UINT8)pSlotDB->PtExecSt;
        pSyncRec->FaultState    = (UINT8)pSlotDB->FaultState;
        pSyncRec->FaultOpt      = (UINT8)pSlotDB->FaultOpt;
        pSyncRec->Mode          = (UINT8)pSlotDB->Mode;
        pSyncRec->ModeAttr      = (UINT8)pSlotDB->ModeAttr;
        pSyncRec->ModePerm      = (UINT8)pSlotDB->ModePerm;
        pSyncRec->NMode         = (UINT8)pSlotDB->NMode;
        pSyncRec->NModeAttr     = (UINT8)pSlotDB->NModeAttr;
        pSyncRec->RedTag        = (UINT8)pSlotDB->RedTag;
        pSyncRec->LocalMan      = (UINT8)pSlotDB->LocalMan;
        pSyncRec->SoInitVal     = (UINT8)pSlotDB->SoInitVal;
        pSyncRec->SoReadFailFlag= (UINT8)pSlotDB->SoReadFail;
        pSyncRec->InitReq       = (UINT8)pSlotDB->InitReq;
        pSyncRec->DOType        = (UINT8)pSlotDB->DoType;
        pSyncRec->IntLck1Src  = (INT32)pSlotDB->IntLck1Src;
        pSyncRec->IntLck2Src  = (INT32)pSlotDB->IntLck2Src;
        pSyncRec->IntLck3Src  = (INT32)pSlotDB->IntLck3Src;
        pSyncRec->IntLck4Src  = (INT32)pSlotDB->IntLck4Src;
        pSyncRec->IntLck5Src  = (INT32)pSlotDB->IntLck5Src;
        pSyncRec->IntLck6Src  = (INT32)pSlotDB->IntLck6Src;
        pSyncRec->IntLck7Src  = (INT32)pSlotDB->IntLck7Src;
        pSyncRec->IntLck8Src  = (INT32)pSlotDB->IntLck8Src;
        pSyncRec->IntLck1Dxn  = (UINT8)pSlotDB->IntLck1Dxn;
        pSyncRec->IntLck2Dxn  = (UINT8)pSlotDB->IntLck2Dxn;
        pSyncRec->IntLck3Dxn  = (UINT8)pSlotDB->IntLck3Dxn;
        pSyncRec->IntLck4Dxn  = (UINT8)pSlotDB->IntLck4Dxn;
        pSyncRec->IntLck5Dxn  = (UINT8)pSlotDB->IntLck5Dxn;
        pSyncRec->IntLck6Dxn  = (UINT8)pSlotDB->IntLck6Dxn;
        pSyncRec->IntLck7Dxn  = (UINT8)pSlotDB->IntLck7Dxn;
        pSyncRec->IntLck8Dxn  = (UINT8)pSlotDB->IntLck8Dxn;

        pSyncRec->OnPulse       = pSlotDB->OnPulse;
        pSyncRec->FaultValue    = pSlotDB->FaultValue;
        pSyncRec->SO            = (UINT8)pSlotDB->SO;

        pSyncRec->TPEnd            = (UINT32)pSlotDB->TPEnd;
        pSyncRec->PulseInProgress  = (UINT16)pSlotDB->PulseInProgress;
        pSyncRec->LastTripSrc      = (UINT8)pSlotDB->LastTripSrc;

        retVal = PA_OK;
    }
    return retVal;
}

/*******************************************************************************
*                         clsDoSlot::StoreDumpData                             *
*                         ========================                             *
* PURPOSE  : This method will copy the redundancy dump data into local dump    *
*            structure in Primary IOM                                          *
* ARGUMENTS: pDump - Dump Pointer                                              *
* RETURN   : PA_OK -   If dump is succesful                                    *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS  clsDoSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS retVal = PA_NULL;
    ///
    if(pDump && IS_EVEN(pDump))
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SPDO_SYNC_VER_1)
        {
            PSYNCRECORD pSyncRec    = (PSYNCRECORD)pDump;
            DOSHRAMSLOTDATA* pSlotDB    = (DOSHRAMSLOTDATA*)pDoShramSlotData;        

            pSlotDB->PntType         =  pSyncRec->PntType;
            pSlotDB->PtExecSt        =  pSyncRec->PtExecSt;
            pSlotDB->FaultState      =  pSyncRec->FaultState;
            pSlotDB->FaultOpt        =  pSyncRec->FaultOpt;
            pSlotDB->Mode            =  pSyncRec->Mode;
            pSlotDB->ModeAttr        =  pSyncRec->ModeAttr;
            pSlotDB->ModePerm        =  pSyncRec->ModePerm;
            pSlotDB->NMode           =  pSyncRec->NMode;
            pSlotDB->NModeAttr       =  pSyncRec->NModeAttr;
            pSlotDB->RedTag          =  pSyncRec->RedTag;
            pSlotDB->LocalMan        =  pSyncRec->LocalMan;
            pSlotDB->SoInitVal       =  pSyncRec->SoInitVal;
            pSlotDB->SoReadFail      =  pSyncRec->SoReadFailFlag;
            pSlotDB->InitReq         =  pSyncRec->InitReq;
            pSlotDB->DoType          =  pSyncRec->DOType;
            pSlotDB->IntLck1Src      =  pSyncRec->IntLck1Src;
            pSlotDB->IntLck2Src      =  pSyncRec->IntLck2Src;
            pSlotDB->IntLck3Src      =  pSyncRec->IntLck3Src;
            pSlotDB->IntLck4Src      =  pSyncRec->IntLck4Src;
            pSlotDB->IntLck5Src      =  pSyncRec->IntLck5Src;
            pSlotDB->IntLck6Src      =  pSyncRec->IntLck6Src; 
            pSlotDB->IntLck7Src      =  pSyncRec->IntLck7Src;
            pSlotDB->IntLck8Src      =  pSyncRec->IntLck8Src;
            pSlotDB->IntLck1Dxn      = pSyncRec->IntLck1Dxn;
            pSlotDB->IntLck2Dxn      = pSyncRec->IntLck2Dxn;
            pSlotDB->IntLck3Dxn      = pSyncRec->IntLck3Dxn;
            pSlotDB->IntLck4Dxn      = pSyncRec->IntLck4Dxn;
            pSlotDB->IntLck5Dxn      = pSyncRec->IntLck5Dxn;
            pSlotDB->IntLck6Dxn      = pSyncRec->IntLck6Dxn;
            pSlotDB->IntLck7Dxn      = pSyncRec->IntLck7Dxn;
            pSlotDB->IntLck8Dxn      = pSyncRec->IntLck8Dxn;

            pSlotDB->OnPulse         = pSyncRec->OnPulse;
            pSlotDB->FaultValue      = pSyncRec->FaultValue;

            pSlotDB->PulseInProgress = pSyncRec->PulseInProgress;
            pSlotDB->TPEnd           = pSyncRec->TPEnd;

            pSlotDB->SO = (BOOL)pSyncRec->SO;            
            pSlotDB->LastTripSrc      = pSyncRec->LastTripSrc;            
        
            retVal = PA_OK;
        }
    }
    return retVal;
}