/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcspaislot.hpp                                              *
*    Description : Class clsTcSpAiSlot definition.                             *
*******************************************************************************/
#ifndef __TCSPAISLOT_HPP__
#define __TCSPAISLOT_HPP__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
/* Diagnostics Status Options */
typedef enum tagDiagStatus
{
    DIAG_OK = 0,
    DIAG_UNCERN = 1,
    DIAG_FAIL = 2
}DIAGSTATUS;
//

/* PV Clamp Options */
typedef enum tagPvClamp {
    PVCLAMP_NOCLAMP   =0,
    PVCLAMP_CLAMP     =1
} PVCLAMP;
//

/* PV Char Options */
typedef enum tagPvChar {
    PVCHAR_JTHERM   = 0,
    PVCHAR_KTHERM   = 1,
    PVCHAR_ETHERM   = 2,
    PVCHAR_TTHERM   = 3,
    PVCHAR_BTHERM   = 4,
    PVCHAR_STHERM   = 5,
    PVCHAR_RTHERM   = 6,
    PVCHAR_RPTHERM  = 7,
    PVCHAR_DINRTD   = 8,
    PVCHAR_JISRTD   = 9,
    PVCHAR_NICKLRTD = 10,
    PVCHAR_COPPRRTD = 11,
    PVCHAR_LINEAR   = 12,
    PVCHAR_SQRROOT  = 13,
    PVCHAR_NTHERM   = 14,
    PVCHAR_PT200RTD = 15,
    PVCHAR_PT500RTD = 16,
    PVCHAR_CU10RTD  = 17,
    PVCHAR_CU25RTD  = 18,
    PVCHAR_RHRAD    = 19,
    PVCHAR_W5W26TC  = 20,
    PVCHAR_W5W25TC  = 21,
    PVCHAR_NINIMOTC = 22,
    PVCHAR_RTDOHMS  = 23,
    PVCHAR_DEVRANGE = 26,
    PVCHAR_SYSRANGE = 27,
    PVCHAR_SYSRSQRT = 28
} PVCHAR;
//

/* PV Temp Options */
typedef enum tagPvTemp {
    PVTEMP_DEG_C  = 0,      
    PVTEMP_DEG_F  = 1,
    PVTEMP_DEG_R  = 2,
    PVTEMP_DEG_K  = 3
} PVTEMP;
//

/* AI High Low Limits Options */
typedef struct tagSpAiHiLoLimits {
    FLOAT32 fHiLimit;
    FLOAT32 fLoLimit;
} SPHILOLIMITS;
//

class clsTcSpAiSlot; // forward declaration

/* Slot Database Parameter Info */
typedef struct tagSpAiSlotParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    CONTROLSTATE ControlState;
    PASTATUS (clsTcSpAiSlot::* PrePtr)(UINT8 *, UINT8);
    VOID     (clsTcSpAiSlot::* PostPtr)(UINT8);
    VOID *   (clsTcSpAiSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} SPAISLOTPARAMINFO;

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
#define TCSPAISLOT_SIZE ((sizeof(clsTcSpAiSlot) + (sizeof(clsTcSpAiSlot) % 2)) / 2)

const UINT16  INPUT_NAN_COUNT           = 589; // floor(589.7166975)
const FLOAT32 HARDWARE_MULTIPLICATION   = 1.1666666666666666666666666666667;//7/6
const UINT8   OPENWIRE_TOTAL_TESTCOUNT  = 5;
const UINT8   OPENWIRE_PVFALL_MAXCOUNT  = 5;
const UINT16  PASS2_ONE_VOLT_HILIMIT    = 12510;

// Note:: All beloew values are taken from adc.hpp
// Reference constants for Pass 1 boards. Corresponds to the divider ratio of 0.95 before ADC.
// Zero Reference : Ranges from 55 to 75 mV. Zero reference average is 65 mV.
const UINT16 SP_PASS1_ZERO_REF_HILIMIT    = 933; // floor(75 * 0.95 * 65535 / 5000) = floor(933.87375)
const UINT16 SP_PASS1_ZERO_REF_LOLIMIT    = 685; // ceil(55 * 0.95 * 65535 / 5000) = ceil(684.84075)
// 1V calib input : Ideal count           = (1000 + 65) * 0.95 * 65535 / 5000 = 13261.00725
const UINT16 SP_PASS1_ONE_VOLT_HILIMIT    = 14587; // floor(13261.00725 + 10%) = floor(14587.107975)
const UINT16 SP_PASS1_ONE_VOLT_LOLIMIT    = 11935; // ceil(13261.00725 - 10%) = ceil(11934.906525)
// 5V calib input : Ideal count           = (5000 + 65) * 0.95 * 65535 / 5000 = 63067.60725
const UINT16 SP_PASS1_FIVE_VOLT_HILIMIT   = 65534; // Clamped at 0xFFFE as 63067.60725 + 10% = 69374.367975
const UINT16 SP_PASS1_FIVE_VOLT_LOLIMIT   = 56761; // ciel(63067.60725 - 10%) = ciel(56760.846525)
// NaN threshold (40 mV) : Count          = (40 + 65) * 0.95 * 65535 / 5000 = 1307.42325
const UINT16 SP_PASS1_INPUT_NAN_COUNT     = 1307; // floor(1307.42325)
// Input deadbad bias (10 mV) : Count     = (10) * 0.95 * 65535 / 5000 = 124.5165
const UINT16 SP_PASS1_INPUT_DEADBAND_BIAS = 124; // floor(124.5165)

// Reference constants for Pass 2 boards. Corresponds to the divider ratio of 0.857 before ADC.
// Zero Reference : Ranges from 5 to 20 mV. Zero reference average is 12.5mV.
const UINT16 SP_PASS2_ZERO_REF_HILIMIT    = 224; // floor(20 * 0.857 * 65535 / 5000) = floor(224.65398)
const UINT16 SP_PASS2_ZERO_REF_LOLIMIT    = 57;  // ciel(5 * 0.857 * 65535 / 5000) = ciel(56.163495)
// 1V calib input : Ideal count           = (1000 + 12.5) * 0.857 * 65535 / 5000 = 11373.1077375
const UINT16 SP_PASS1p5_ONE_VOLT_HILIMIT  = 12510; // floor(11373.1077375 + 10%) = floor(12510.41851125)
const UINT16 SP_PASS1p5_ONE_VOLT_LOLIMIT  = 10236; // ciel(11373.1077375 - 10%) = ciel(10235.79696375)
// 5V calib input : Ideal count           = (5000 + 12.5) * 0.857 * 65535 / 5000 = 56303.9037375
const UINT16 SP_PASS1p5_FIVE_VOLT_HILIMIT = 61934; // floor(56303.9037375 + 10%) = floor(61934.29411125)
const UINT16 SP_PASS1p5_FIVE_VOLT_LOLIMIT = 50674; // ciel(56303.9037375 - 10%) = ciel(50673.51336375)
// NaN threshold (40 mV) : Count = (40 + 12.5) * 0.857 * 65535 / 5000 = 589.7166975
const UINT16 SP_PASS1p5_INPUT_NAN_COUNT   = 589; // floor(589.7166975)
// Input deadbad bias (10 mV) : Count     = (10) * 0.857 * 65535 / 5000 = 112.32699
const UINT16 INPUT_DEADBAND_BIAS          = 112; // floor(112.32699)

const UINT8 SP_NO_OF_REF_VOLTAGES = 3;
const SPHILOLIMITS SP_REFVOLTAGE_LIMITS[SP_NO_OF_REF_VOLTAGES] = {
    0.115668, 0.097428, // CHVT1  : (0.1071 + 8%), (0.1059 - 8%)
    0.302184, 0.2553,   // CKVT2  : (0.2798 + 8%), (0.2775 - 8%)
    0.790236, 0.669116, // CKVT3  : (0.7317 + 8%), (0.7273 - 8%)
};

// Redundancy dump record structure version. Do not delete any existing version and structure. For changes in dump structure in
// subsequent releases:
// a) Define a new constant for version, and increment the value by 1.
// b) In StoreDumpData(), add the conditional clause for new dump record version.
extern const UINT16 SPAI_SYNC_VER_1;
/*******************************************************************************
*                                   clsTcSpAiSlot                              *
*                                   ==========                                 *
*******************************************************************************/
class clsTcSpAiSlot : public clsInSlot {
protected:
    //Member Variables
    INPTDIR     InptDir;
    FLOAT32     PvRaw;
    PVCHAR      PvChar;
    FLOAT32     PvCalc;
    FLOAT32     FiltOut;
    FLOAT32     PvAuto;
    PVVALST     PvAutoSt;
    FLOAT32     LastPv;
    FLOAT32     PvP;
    BOOL        BadPvFl;
    FLOAT32     ADRawHi;
    FLOAT32     ADRawLo;
    FLOAT32     HundredDivRawSpan;
    FLOAT32     PvRawHI;
    FLOAT32     PvRawLO;
    FLOAT32     PvEUHi;
    FLOAT32     PvEULo;
    FLOAT32     PvExEUHi;
    FLOAT32     PvExEULo;
    BOOL        PvExHiFl;
    BOOL        PvExLoFl;
    PVCLAMP     PvClamp;
    FLOAT32     LoCutOff;
    FLOAT32     Tf;
    FLOAT32     Kf;
    FLOAT32     PvTv;
    FLOAT32     PvTvP;
    SENSRTYP    SensrTyp;
    FLOAT32     EUSpan;
    FLOAT32     EUSpanDivHundred;
    FLOAT32     HundredDivEUSpan;
    PVTEMP      PvTemp;
    BOOL        bAiChnOpenSF;
    UINT8       OpenwireCnt;
    UINT16      RawAdcCount;
    BOOL        InputBelowDeadband;
    UINT8       OpenWireTestCount; 
    UINT8       OpenWirePvFallCount;
    //

    //Static Member variables
    static const UINT8 CheckPointVer1[];
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const SPAISLOTPARAMINFO tblParamInfo[256];
    static UINT8 SpAiSlotChkpntVersion;
    //

    //Method to Initial member variables
    VOID InitSpAiSlot(BOOL bFullInit, BOOL bObjCreate);
    //

    //Pre and Post Methods for Database parameters
    PASTATUS PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPntType(UINT8 a_ucAccLvl);
    PASTATUS PrePv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPv(UINT8 a_ucAccLvl);
    PASTATUS PrePvEUHi(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvEULo(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvEULo(UINT8 a_ucAccLvl);
    PASTATUS PreTf(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PrePvTv(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvTv(UINT8 a_ucAccLvl);
    PASTATUS PrePvSource(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvSource(UINT8 a_ucAccLvl);
    PASTATUS PreLoCutOff(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl); 
    PASTATUS PrePvChar(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PrePvExEUHi(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEUHi(UINT8 a_ucAccLvl);
    PASTATUS PrePvExEULo(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvExEULo(UINT8 a_ucAccLvl);
    PASTATUS PrePvRawHI(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PrePvRawLO(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvSrcOpt(UINT8 a_ucAccLvl);
    PASTATUS PrePvTemp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    PASTATUS PreSensrTyp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostSensrTyp(UINT8 a_ucAccLvl);
    PASTATUS PreInptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl);
    VOID     PostPvClamp(UINT8 a_ucAccLvl);
    VOID     PostTf(UINT8 a_ucAccLvl);
    PASTATUS PreOwdEnable(UINT8 *a_Writebuffer,UINT8);
    PASTATUS PrePtExecSt(UINT8 *a_Writebuffer,UINT8);
    VOID     PostPtExecSt(UINT8 a_ucAccLvl);

    inline PASTATUS PreCheckPoint(UINT8 *, UINT8) {
        SpAiSlotChkpntVersion = LATEST_SP_AI_SLTCHKPNT_VERSION;
        return PA_OK;
    }
    //

    //clsTcSpAiSlot Class Varibles GetPtr methods
    inline VOID *GetInptDirPtr(VOID)    {return &InptDir;}
    inline VOID *GetPvRawPtr(VOID)    {return &PvRaw;}
    inline VOID *GetPvCalcPtr(VOID)   {return &PvCalc;}
    inline VOID *GetPvCharPtr(VOID)   {return &PvChar;}
    inline VOID *GetFiltOutPtr(VOID)  {return &FiltOut;}
    inline VOID *GetPvAutoPtr(VOID)   {return &PvAuto;}
    inline VOID *GetPvAutoStPtr(VOID) {return &PvAutoSt;}
    inline VOID *GetLastPvPtr(VOID)   {return &LastPv;}
    inline VOID *GetPvPPtr(VOID)      {return &PvP;}
    inline VOID *GetBadPvFlPtr(VOID)  {return &BadPvFl;} 
    inline VOID *GetPvEUHiPtr(VOID)   {return &PvEUHi;}
    inline VOID *GetPvEULoPtr(VOID)   {return &PvEULo;}
    inline VOID *GetPvExEUHiPtr(VOID) {return &PvExEUHi;}
    inline VOID *GetPvExEULoPtr(VOID) {return &PvExEULo;}
    inline VOID *GetPvExHiFlPtr(VOID) {return &PvExHiFl;}
    inline VOID *GetPvExLoFlPtr(VOID) {return &PvExLoFl;}
    inline VOID *GetPvClampPtr(VOID)  {return &PvClamp;}
    inline VOID *GetLoCutOffPtr(VOID) {return &LoCutOff;}
    inline VOID *GetTfPtr(VOID)       {return &Tf;}
    inline VOID *GetKfPtr(VOID)       {return &Kf;}
    inline VOID *GetPvTvPtr(VOID)     {return &PvTv;}
    inline VOID *GetPvTvPPtr(VOID)    {return &PvTvP;}
    inline VOID *GetEUSpanPtr(VOID)   {return &EUSpan;}
    inline VOID *GetPvRawHIPtr(VOID)  {return &PvRawHI;}
    inline VOID *GetPvRawLOPtr(VOID)  {return &PvRawLO;}
    inline VOID *GetPvTempPtr(VOID)   {return &PvTemp;}
    inline VOID *GetSensrTypPtr(VOID) {return &SensrTyp;}
    inline VOID *GetADRawHiPtr(VOID)  {return &ADRawHi;}
    inline VOID *GetADRawLoPtr(VOID)  {return &ADRawLo;}
    VOID *GetPvPtr(VOID);
    VOID *GetPvStsPtr(VOID);
    //

    //Static Varibles GetPtr methods
    inline VOID *GetRedParamsPtr(VOID)  {return (VOID *)RedParams; }
    inline VOID *GetCheckPointPtr(VOID) {return (VOID *)CheckPointVerTable[SpAiSlotChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
    //

    //Overriden clsIomSlot Class Varibles GetPtr methods
    inline VOID *GetSlotChkpntVersionPtr(VOID) {return &SpAiSlotChkpntVersion;}
    inline UINT8 GetLatestSlotChkpntVersion(VOID) {return SpAiSlotChkpntVersion;}
    

    //Database Access Related Methods
    UINT8    *GetParamPtr(UINT8);
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);

    clsTcSpAiSlot(const clsTcSpAiSlot&); // Safeguard against default copy constructor
    clsTcSpAiSlot& operator=(const clsTcSpAiSlot&); // and default assignment
public:
    clsTcSpAiSlot(UINT8);
    ~clsTcSpAiSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,TCAILVDTSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32,UINT8);
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,TCAILVDTSLOT_HPP,__LINE__); }

    //Database Access Related Methods    
    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    inline UINT8 *GetParameterPtr(UINT8 a_ucParamNumber){ return GetParamPtr(a_ucParamNumber); }
    //

    //Method to Initial member variables
    VOID InitSlotDatabase(BOOL bFullInit);
    VOID InactivateSlot(VOID);
    //

    //AI Channel Processing Helper methods
    VOID ValidateOwdCkt(BOOL,FLOAT32);
    VOID ProcessSlot(FLOAT32);
    VOID AiDataFetch(VOID);
    VOID AiDataFetch(enmChanProcEvent Event);
    VOID UpdateBadPv(VOID);
    DIAGSTATUS DoAiOpenWireDiag(FLOAT32);
    inline VOID UpdateBadPvFl(BOOL a_bFlag) { BadPvFl = a_bFlag; }
    inline VOID InitPvDb(VOID) {
        PvRaw = NaN;
        PvCalc = NaN;
        PvAuto = NaN;
        FiltOut = NaN;
        PvAutoSt = PVVALST_BAD;
        PvExHiFl = FALSE;
        PvExLoFl = FALSE;
    }
    inline VOID StoreRawAdcCount(UINT16 a_uiData)  { RawAdcCount = a_uiData;      }
    inline BOOL WasInputBelowDeadband(VOID)        { return InputBelowDeadband;   }
    inline VOID SetInputBelowDeadband(BOOL a_bFlg) { InputBelowDeadband = a_bFlg; }
    inline VOID SetAiOpenWireSf(BOOL bOpenWireSf){  bAiChnOpenSF = bOpenWireSf;
                                                    OpenwireCnt = 0;}
    //

    //Get Methods for the memeber variables
    inline PVSOURCE GetPvSource(VOID)       { return PvSource;   }
    inline PVCHAR   GetPvChar(VOID)         { return PvChar;     }
    inline FLOAT32  GetPvEUHi(VOID)         { return PvEUHi;     }
    inline FLOAT32  GetPvEULo(VOID)         { return PvEULo;     }
    inline FLOAT32  GetPvExEUHi(VOID)       { return PvExEUHi;   }
    inline FLOAT32  GetPvExEULo(VOID)       { return PvExEULo;   }
    inline SENSRTYP GetSensorType(VOID)     { return SensrTyp;   }
    //

    //Redundacny Dump Related Struct and Methods
    #pragma pack 2
    typedef struct strSpAiSyncRecord
    {
        UINT16      Header;     // The first two bytes of dump record should always represent version. Do not change this. 
        UINT8       PntType;
        UINT8       PtExecSt;
        UINT8       ContCut;
        UINT8       PvSource;
        UINT8       PvSrcOpt;
        UINT8       OwdEnable;
        UINT8       PvChar;
        UINT8       SensrTyp;
        UINT8       PvClamp;
        UINT8       PvTemp;
        FLOAT32     PvCalc;
        FLOAT32     FiltOut;
        FLOAT32     ADRawHi;
        FLOAT32     ADRawLo;
        FLOAT32     PvRawHI;
        FLOAT32     PvRawLO;
        FLOAT32     PvEUHi;
        FLOAT32     PvEULo;
        FLOAT32     PvExEUHi;
        FLOAT32     PvExEULo;
        FLOAT32     LoCutOff;
        FLOAT32     Tf;
        FLOAT32     Kf;
        FLOAT32     PvTv;
        FLOAT32     PvTvP;
        FLOAT32     EUSpan;
        FLOAT32     EUSpanDivHundred;
        FLOAT32     HundredDivEUSpan;
        FLOAT32     HundredDivRawSpan;
        UINT8       InptDir;
        FLOAT32     Pv;
        UINT8       PvSts;
    }SYNCRECORD,*PSYNCRECORD;
    #pragma unpack
    UINT32      GetRedSlotSize(VOID) { return sizeof(SYNCRECORD); }
    PASTATUS    GetDumpData(UINT8* const pDump,const UINT8 MaxSize);
    PASTATUS    StoreDumpData(UINT8* const pDump);
    inline UINT32 GetRedSlotDelta(VOID) {return 0;}        
    inline UINT8 *GetRedSlotPointer(VOID) {
        return NULL;
    }
    //
};

#endif //__TCSPAISLOT_HPP__
