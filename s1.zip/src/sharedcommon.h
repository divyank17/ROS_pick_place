/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2010                              *
*                         HONEYWELL PROCESS SOLUTIONS                          *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : sharedcommon.h                                              *
*    Description : Declarations shared between 4 images,                       *
*                  IOL and DSC,boot and app                                    *
*******************************************************************************/
#ifndef __SHAREDCOMMON_H__
#define __SHAREDCOMMON_H__
//
#ifdef DSC
  #define TURN_DSC 0
  #define TURN_H8S 1
  const UINT32 MAX_SEMAPHORE_TIMEOUT = 1000;// Has to be tuned
#endif

// --------------------------------------------------------------------------------------------
// Support for taking online snapshot of internal memory in IOM in 
// blocks of 120 bytes.
// TESTPARAM can be used to read memory contents of any slot 
// either on H8S,DSC or FPGA memory. Here is how it works.
// TESTPARAM[0] has to be loaded with a slot number.
// By default slot number refers to contents of IOL processor ram.
// 100+slotnumber refers to APP processor ram.
// TESTPARAM[1] has to be loaded with the index of 120 byte block
// to be copied to TESTPARAM[2] to [31].
// For example,if TESTPARAM[0]= 101 (ArrTestParam[0] =101 and ArrTestParam[1]=0) and 
// TESTPARAM[1] is 1 (pSharedData->ArrTestParam[2] = 1 and pSharedData->ArrTestParam[3] = 0) 
// memory contents of bytes 120 to 239 of SLOT[1] on App processor side will be copied to
// TESTPARAM[2] to TESTPARAM[31] (pSharedData->ArrTestParam[4] to pSharedData->ArrTestParam[63]) 
// Both DSC and H8S will load the data word by word and set ArrTestParam[2] to 0x0001.
// This is to stop copying repeatedly. So user will see that the value written to TESTPARAM[0] 
// has suddenly changed to 65536 + user entered value.
//---------------------------------------------------------------------------------------------
#define TESTPARAM_BUFFER_SIZE             64
#define TESTPARAM_DATA_START_IDX           4
#define TESTPARAM_DATA_LEN           (TESTPARAM_BUFFER_SIZE - TESTPARAM_DATA_START_IDX)
// Note H8S is big endian byte ordering
// TESTPARAM is UINT32, so if TESTPARAM[0] = 0x01020304
// ArrtestParam[0] = 0x0102 and ArrtestParam[1] = 0x0304
// DSC uses little endina word ordering
// so it will see ArrTestParam[1] as 0x0304 which is correct.
// H8S will see ArrTestParam[1] as 0x0304 which is also correct.
#define TESTPARAM_SLOTNUM_IDX              1
#define TESTPARAM_RESP_IDX                 0
#define TESTPARAM_MEM_BLOCK_IDX            3
#define TESTPARAM_UNUSED_3                 2
//
#define TESTPARAM_H8S_SLOT_OFFSET          0
#define TESTPARAM_DSC_SLOT_OFFSET        100
#define TESTPARAM_FPGA_SLOT_H8S          200
#define TESTPARAM_CPLD_SLOT_H8S          300
#define TESTPARAM_FPGA_SLOT_DSC          400
#define TESTPARAM_CPLD_SLOT_DSC          500
#define TESTPARAM_ACK_PATTERN         0x0001
#define TESTPARAM_INVALID_VALUE32     0xFFFFFFFF
#define TESTPARAM_INVALID_VALUE16     0xFFFF
//
#if defined (DSC)
    #define word_sizeof(_arg)            sizeof((_arg))
    #define TESTPARAM_MIN_SLOT_OFFSET    TESTPARAM_DSC_SLOT_OFFSET
    #define TESTPARAM_FPGA_SLOT          TESTPARAM_FPGA_SLOT_DSC
    #define TESTPARAM_CPLD_SLOT          TESTPARAM_CPLD_SLOT_DSC
#elif defined(H8S)
    #define word_sizeof(_arg)            ((sizeof((_arg))+1)>>1)
    #define TESTPARAM_MIN_SLOT_OFFSET    TESTPARAM_H8S_SLOT_OFFSET
    #define TESTPARAM_FPGA_SLOT          TESTPARAM_FPGA_SLOT_H8S
    #define TESTPARAM_CPLD_SLOT          TESTPARAM_CPLD_SLOT_H8S
#endif
//
#define BOOT_SHARED_DATA_LENGTH    32
#define CMN_SHARE_IOM_REBOOTED_IDX 0
//
class clsShramProtect 
{
private:
  volatile UINT16 H8SEntry;
  volatile UINT16 DSCEntry;
  volatile UINT16 Turn;
  volatile UINT16 ReadDone;
public:
    clsShramProtect()
    {
        H8SEntry = FALSE;
        DSCEntry = FALSE;
        Turn = TURN_H8S;
        ReadDone = TRUE;
    }

#ifdef H8S

    BOOL CaptureSemaphore();


    void ReleaseSemaphore()
    {
        H8SEntry = FALSE;
    }

#elif DSC

    BOOL CaptureSemaphore()
    {
      UINT32 TimeOutCount = 0;
      DSCEntry = TRUE; //Set the lock
      Turn = TURN_H8S; // Grant entry to the other processor
      while(H8SEntry == TRUE && Turn == TURN_H8S)
      {
        if((TimeOutCount++) > MAX_SEMAPHORE_TIMEOUT)
        {
          return FALSE;
        }
      }
      return TRUE;
    }

    void ReleaseSemaphore()
    {
      DSCEntry = FALSE;
    }

#endif

    BOOL CheckReadStatus() 
    {
        return ReadDone;
    }

    void UpdateReadStatus(BOOL RdSts)
    {
        ReadDone = RdSts;
    }
};
//
struct strCommonSharedData
{
  clsShramProtect   ShramProtect;
  volatile UINT16   bDSCImageChecked;
  volatile UINT16   CmdStatus;  
  volatile UINT16   bAppImageValid;
  volatile UINT16   NewBootImgValidSts;
  volatile UINT16   bNewBootCopyComplete;
  volatile UINT16   StartNewBootCopy;
  volatile UINT16   BootVersionNum;
  volatile UINT16   BootRevisionNum;
  volatile UINT16   BootBuildNum;
  volatile UINT16   AppVersionNum;
  volatile UINT16   AppRevisionNum;
  volatile UINT16   AppBuildNum;
  volatile UINT16   HardFailCode;
  volatile UINT16   FlashEraseAck;
  volatile UINT16   FlashEraseCmdSent;
  volatile UINT16   Data[BOOT_SHARED_DATA_LENGTH-1];
  volatile UINT16   ArrTestParam[TESTPARAM_BUFFER_SIZE]; // 64 words. (datatype of TESTPARAM in db is UINT32) 

  // overload new and delete to prevent linker 
  // error trying to link malloc.
  VOID *operator new(UINT32) { return NULL; }
  VOID operator delete(VOID *) {};
};
//
#if defined (IOMTYPE_SVPBOOT) || defined (IOMTYPE_SPBOOT)
  ///
  extern strCommonSharedData SharedData;
  extern strCommonSharedData* pSharedData;
  ///
#elif defined (IOMTYPE_SVP) || defined (IOMTYPE_SP)
  ///
  extern strCommonSharedData* pBootData;
  #define pSharedData pBootData
  ///
#endif
//define strSharedData for old code to compile.
#define strSharedData strCommonSharedData
//
void   SetCommonSharedData(const UINT16 idx,const UINT16 value);
UINT16 GetCommonSharedData(const UINT16 idx);
//
void InitTestParam(void);
UINT16* GetTestParamPtr(void);
BOOL IsReadRequested(void);
void MarkCopyComplete(void);
void CopyToTestParam(volatile UINT16* psrc, UINT16 len);
void ProcessTestParams(void);
void WriteTestParamUint32(const UINT16 param_idx, const UINT32 value);
UINT32 GetTestParamUint32(const UINT16 param_idx);
//

#endif // __SHAREDCOMMON_H__
