/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2010                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                          Honeywell Measurex Ireland Ltd                      *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : pimain.h                                                    *
*    Description : common defines used by module                               *
*******************************************************************************/
#ifndef __PIMAIN_H__
#define __PIMAIN_H__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "commonelectronics.h"
#include "tracelog.hpp"
#ifdef DEBUG
  #include "debug.hpp"
#endif
#include "scheduler.hpp"
#include "diag.h"
#include "wrmsgque.hpp"
#include "piversion.h"
#include "piboxslot.hpp"
#include "pislot.hpp"

#endif