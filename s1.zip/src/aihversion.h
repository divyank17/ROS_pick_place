/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihversion.h                                                *
*    Description : Analog Input firmware version declaration.                  *
*******************************************************************************/
#ifndef AIHVERSION_H
#define AIHVERSION_H
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#ifdef DEVELOPER_BUILD_OVERRIDE
    const UINT8 VERSION_NUMBER  = VERSION;
    const UINT8 REVISION_NUMBER = REVISION;
    const UINT8 BUILD_NUMBER    = BUILD;
	// donot remove below comment lines, if removed version number will be error
	//const UINT8 HART_VER_NUMBER = VERSION;
	//const UINT8 HART_REV_NUMBER = REVISION;
	//const UINT8 HART_BLD_NUMBER = BUILD;
#else
	#if defined(IOPTYPE_HLAI)
		#if defined(HART_SUPPORT)
			/* Rev history
			 * FW VER 7.0.0 - Redesign HLAI PM IOP (with SRAM replacement)
			 * FW VER 7.0.4 - base ver
			 * FW VER 7.0.5 - fix for data retention in SRAM issue
			 * FW VER 7.0.6 - fix for hybrid modules sync
			 * FW VER 7.0.7 - fix for configmis with legacy as sec during FTA removal & reinsert
			 * FW VER 7.1.0 - field upgrade feature
			 * FW VER 7.2.0 - SIT PAR (1-DVVRRFR, 1-DVUK26N) Fixes
			 * FW VER 7.3.0 - SIT Reopened PAR (1-DVVRRFR) Fix
			 * FW VER 7.4.0 - With MiRO customer issue fix (1-E54X6FB: C300PM dual failure occurred in R520.2 B229 test bed in the presence of redesigned HART IOPs)
			 * FW VER 7.5.0 - fix for FTA Failover issue (PAR# 1-E6YYQAR) due to fix for AO16H fixes.
			 * FW VER 7.6.0 - Fix for dual C300pm/ehpm failure due to param HSLOT0TS access in HART variables tab in experion.
			 * FW VER 7.7.0 - Fix for param error during module restore with C300PM
			 * FW VER 7.8.0 - Modified param PARAMID_H7SLDVC access during the fix for the issue in AO16H (SEC(NEW) Syncfail with PRI(NEW) after reinsertion, with a single CHL cfgd & with C300v2).
			 * FW VER 7.9.0 - Fix is not to reinit the H7SLDVC variables during postdump
			 * FW VER 8.0.0 - Fix for HSLOTVAL = NAN for centain HART devices through CMD9 (Ex: 2.	Samson Trovis 3763 Positioner)
			 *			    - Fix for HSLOTVAL = WRONG VAL for HART5 through CMD33
			 */
			const UINT8 HART_VER_NUMBER = 8;
			const UINT8 HART_REV_NUMBER = 0;
			const UINT8 HART_BLD_NUMBER = 0;
		#else
            /*
             * Redesign HLAI PM IOP Rev history
             * FW VER 7.0.00 - 1st release
             * FW VER 8.0.00 - 2nd release with customer par fixes
             * FW VER 8.1.00 - 3rd release with customer par fixes
             * FW VER 8.2.00 - Fix for the issue CL/EHPM Fail due to HLAI (EHPM Crash due to HLAI IOL Comm Error)
             * FW VER 8.3.00 - Fix for the issue CL/EHPM Fail due to HLAI (calling write database task before returning with IOL_RCVBUFOV, to clear the Write requests.)
             * FW VER 8.3.10 - Fix for the issue CL/EHPM Fail due to HLAI (added protection from data race condition in scheduler)
             * FW VER 8.3.0  - Released with fix for issue CL/EHPM fail due to (HLAI) IOP
             * FW VER 8.3.11 - Dev Build for, Customer(-MiRO) Issue(-CL Fail) Work arounds
             * FW VER 8.4.1  - Dev Build for, Customer(-MiRO) Issue(-CL Fail) Fix + Field upgrade feature in boot code
             * FW VER 8.5.1  - PAR# 1-DCHI0F0 - New HLAI, AO16 module went into ACTIVE state (OK / BACKUP) after new IOP configuration
							   Major changes related to FRAM replaced with battery backup SRAM
             */
            const UINT8 VERSION_NUMBER  = 8;
            const UINT8 REVISION_NUMBER = 5;
            const UINT8 BUILD_NUMBER    = 1;
        #endif
    #endif
#endif

#endif
