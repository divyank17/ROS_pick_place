/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aohmain.cpp                                                 *
*    Description : HART Analog Output module application specific startup code.*
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aohmain.h"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN HartTask(TASKCONTEXT);
extern TASKRETURN DiagnosticTask(TASKCONTEXT);
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
extern UINT8 g_ucChan;
extern BOOL HartLoopBkTestInProgress;

/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
WRITEINPROGRESS  WriteInProgress;

#ifdef DEBUG
clsDebugPort     DebugPort;
#endif
#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section

clsTaskScheduler TaskScheduler;

#pragma section INTERNALRAM_SECTION
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;
clsAoHardware    AoHardware;
clsEeprom        Eeprom;
#pragma section

// Pointers to database objects
clsIomSlot       *pDatabase[MAXSLOTS + 1];

// Database Memory
UINT16 ucIomDbMemory[AOHBOXSLOT_SIZE + (MAXSLOTS * AOHSLOT_SIZE)];

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
TASKRETURN CalibrationTask(TASKCONTEXT);

extern RETURNSTATUS SwitchDiagnostics(VOID);
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//NOTE:
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                            WriteDatabaseTask
                                           ,LowPriorityTask
                                           ,CalibrationTask
                                           ,EventRecoveryTask
                                           ,HartTask
                                           ,DiagnosticTask
#ifdef DEBUG
                                           ,DebugTask
#endif
};

//Flag utilized to prevent the stcappprocessing from checking the state 
//of the redundancy switches when switch diagnostcis will be running
BOOL bSwitchDiagRunning = FALSE;

/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
*    Application specific startup code.                                        *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function is called by the PowerOn reset vector.                      *
*******************************************************************************/
VOID main(VOID) 
{
    BOOL bHart = FALSE;   // the Box is HART capable
#if LOWCOST
    UINT8 ProductCode = *((UINT8*)(MODULEINFO_START_ADDRESS + HW_PROD_CODE_OFFSET));
#endif
    // Create box and slot database objects
    if (isHartCapable()) {  // decide by the Loopback Test of the 4 HART modems
        pDatabase[0] = new clsAohBoxSlot(MODLTYPE_AOH);
        TraceLog.AddToTrace(TRACEID_GENERIC,bcAohIom,BOX->GetDPA());
        bHart = TRUE;
    }
    else
    {
#if HEK     // No Dynamic module detection for Series C Depop AO
        pDatabase[0] = new clsAohBoxSlot(MODLTYPE_AO);
#else
        if((ProductCode >= PRODCODE_AO_HART_LC_S8) && (ProductCode <= PRODCODE_AO_LC_S8)) {
            pDatabase[0] = new clsAohBoxSlot(MODLTYPE_AO_S8);
        }
        else {  // Series C is chosen for all other Product Codes
            pDatabase[0] = new clsAohBoxSlot(MODLTYPE_AO);
        }
#endif
        TraceLog.AddToTrace(TRACEID_GENERIC,bcAoIom,BOX->GetDPA());
    }
    // Note: Kernel/App board combination mismatch is not necessary because App board is common.

    for (UINT8 ucSltNm = 0; ucSltNm < MAXSLOTS; ucSltNm++) {
        pDatabase[ucSltNm + 1] = new(ucSltNm) clsAohSlot(ucSltNm + 1);
#if defined(IOPTYPE_AO16)
        // PMIO AO16 Redesign Chkpnt restoring from xRAM
        pDatabase[ucSltNm + 1]->PmioCheckPointRestore();
#endif
    }
    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();

    if (bHart == TRUE) {
        CheckAndInitHart();
    }
    else
    {
        ResetHart();    // just Reset for Hartless module
    }

    // Initialize periodic tasks.
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
                                        DMCPERIOD_LPTASK);
    if (bHart == TRUE) {
        TaskScheduler.InitPeriodicTask(TASKID_HARTTASK,TASKPERIOD_HARTTASK,
                                        DMCPERIOD_HARTTASK);
    }
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
                                        DMCPERIOD_DIAGTASK);

#ifdef DEBUG
    // Set the Debug Task to RUN State
    TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif

    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}
/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    const UINT8 SWTCH_DIAG_COUNT = 5;
    static UINT8 ucSwDiagCntr= 0;
    
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
    
#if !LOWCOST
    if(TRUE == HartLoopBkTestInProgress){
        HartLoopBkTestInProgress = (RETURNSTATUS_INPROGRESS == BOX->HartLoopBackTest());
    }
#endif

    //check if the modules are settled 
    if(((OUTCTL_PARTNER == BOX->GetModStat3State())&&(!Iol.AmPrimary()))||
        ((OUTCTL_MINE == BOX->GetModStat3State())&&(Iol.AmPrimary()))){
    
        // Check for Communication failure and CEE Failure. If any one of these present, 
        // call FaultHandling function which sheds the output according to Mode and 
        // ModeAttr configuration.Do not call Faulthandler when the HartLoopback test 
        // is initiated from Factory mode or Debug mode.
        TOG_FAILED TogFailed = BOX->IsTogFailed();

        if ((NOTOG_FAILED != TogFailed) && (FALSE == HartLoopBkTestInProgress)) {
            for (UINT8 ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) {
                if(FAULTSTATE_NORMAL == SLOT(ucChannel)->GetFaultState()) {
                    SLOT(ucChannel)->SlotFaultHandler(TogFailed);
                }
            }
        }
        else if ((BOX->GetComTog() == TRUE) && (BOX->GetCtlTog() == TRUE)) {
            // If both CTL and COMM TOG are present
            for (UINT8 ucChannel = 1; ucChannel <= MAXSLOTS; ucChannel++) {
                if (FAULTSTATE_FAULTED == SLOT(ucChannel)->GetFaultState()) {
                    SLOT(ucChannel)->ResetFaultState();
                    SLOT(ucChannel)->BackInit();
                }
            }
        }
    }
    //Perform the loopback test only if calibration was done 
    if(TRUE == BOX->IsCalibrationGood()){ 
        // Check operation of loopback circuit.
        BOX->TestLoopbackCircuit();
        //Run the switch diagnostics every 500msec
        if(0 == ucSwDiagCntr){
            //Set the Diag run flag so that switch status will not be checked 
            //in stcprocessing routine
            bSwitchDiagRunning = TRUE;
            //Since the hardfail is the outcome of failure of this diagnostics 
            //ignore the return value
            if (!(BOX->CheckForFactoryTestMode())){ //do not execute in Factory Mode
                SwitchDiagnostics();
            }
            ucSwDiagCntr = SWTCH_DIAG_COUNT;
            bSwitchDiagRunning = FALSE;
        }
        else {ucSwDiagCntr--;}
        
     }
    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.x
    BOX->BoxHouseKeeping();

#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
    // Process BRDP Handle and Message Timeout every second.
    if (BOX->BRDPOneSecCounter >= 10) {
        BOX->BRDPOneSecCounter = 0;
        BOX->ProcessBrdpTimeout();
    }
    else
        BOX->BRDPOneSecCounter++;
#endif
    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
/*******************************************************************************
*                                CalibrationTask                               *
*                                ===============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN CalibrationTask(TASKCONTEXT a_TaskContext)
{
#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                                      "\n\r\tStarting calibration...\n\r"));
#endif

    TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibStart,FACTCAL);

    // Disable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
        SLOT(ucChan)->GetHartDevDb().InitDevDb(TRUE);
    }
    IdleWait(MICROSECONDS_IN_MILLISECOND);
    TPU2_CST = 0; // Stop HART modem heartbeat timer.

    if (FALSE == BOX->PerformModuleCalibration()) { 
        // Calibration was aborted for failed.
        TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibAbort,MODULEINFO_WRITECOUNT);

#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                                          "\n\r\tCalibration aborted"));
#endif
    }

    // Reneable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
        SLOT(ucChan)->GetHartDevDb().m_sScanCounter = TICKS_IN_16_SEC;
    }
    TPU2_CST = 1; // Restart HART modem heartbeat timer.

    TASKRETURN      TaskReturnValue;
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
