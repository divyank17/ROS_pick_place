/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : ecl.cpp                                                     *
*    Description : Class clsEcl implementation.                                *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "ecl.hpp"
#include "tracelog.hpp"
/*******************************************************************************
*                                 clsEcl::clsEcl                               *
*                                 ==============                               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsEcl::clsEcl(const ECLTYPE a_EclType) : EclType(a_EclType) {
    CircListSt = ECLMODSTAT_ALIVE;
    EvntAppPtr = 0;
    EvntRemPtr = 0;
    if(ECLTYPE_NORMAL == a_EclType){
        EclInOverflow = FALSE;
        for (UINT16 uiCount = 0; uiCount < ECL_SIZE; uiCount++) {
        CircularList[uiCount] = 0;
        }
    }
#if defined IOMTYPE_DISOE || defined IOPTYPE_DI
    else{
        PVCLAppPtr = 0;
        PVCLRemPtr = 0;
        // set the Large Circular List(PVCL, which is more than 256  byets) 
        // bit. this will indicate to the C300 controller that this module has
        // large circular list, otherwise C300 doesn't allow the remove pointer
        // to be more than 256 in the Update remove pointer command
        SetStatus(ECLSTATUS_LARGE);
        //PVCL circular list initialization in case of DISOE IOM
        PVCHGCLInOverflow = FALSE;
        for (UINT16 uiCount = 0; uiCount < PVCHGCL_SIZE; uiCount++)
            PVCHGCircularList[uiCount] = 0;
    }
#endif
}
/*******************************************************************************
*                               clsEcl::GetEclSize                             *
*                               ==================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsEcl::GetEclSize(VOID) {
    if (EvntAppPtr > EvntRemPtr) { 
        return (EvntAppPtr - EvntRemPtr);
    }
    if (EvntRemPtr > EvntAppPtr) { // Only AppPtr wrapped around
        return (ECL_SIZE - (EvntRemPtr - EvntAppPtr));
    }
    return 0; // AppPtr = RemPtr
}
/*******************************************************************************
*                                clsEcl::AddEvent                              *
*                                ================                              *
*  Copy the event packet to the ECL object buffer. This function must not be   *
*  called from any context that runs higher than LVLPRI_TICK level.            *
*******************************************************************************/
BOOL clsEcl::AddEvent(const EVENTRECORD *a_pEventRecord) 
{
    // Place holder for an overflow event
    EVENTRECORD overflowEvent;
    
    // Get length of the event record
    UINT8 ucPacketSize = 0;
    if ((a_pEventRecord->EventPacket == EVENTPACKET_SYSTEM) ||
        (a_pEventRecord->EventPacket == EVENTPACKET_HART)   ||
        (a_pEventRecord->EventPacket == EVENTPACKET_32CHAN_HART))
    {
            ucPacketSize = EVENTPACKETSIZE_SYSTEM;
    }
    else
    {
        // Unsupported packet type.
        HardFail(HF_INVPROGRAMEXEC,ECL_CPP,__LINE__);
    }

    // Elevate the priority to STC interrupt level. This is to protect
    // ECL buffer integrity since AddEvent is called from multple places.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    // Check whether there is enough free space in the ECL. Always leave space
    // for OVERFLOW event + 1 byte. The additional 1 byte prevents append
    // pointer from catching up with remove pointer which represents empty ECL.
    UINT16 uiEclFreeSpace = ECL_SIZE - GetEclSize();
    if (uiEclFreeSpace >= (ucPacketSize + EVENTPACKETSIZE_OVERFLOW + 1)) 
    {
        EclInOverflow = FALSE; 
    }
    else 
    { 
        // there is not enough free space
        if (TRUE == EclInOverflow) 
        { 
            // ECL already in overflow. Overflow event was already reported.
            // Restore original interrupt priority mask and exit.
            set_imask_exr(ucSaveExr);
            return FALSE;
        }
        else 
        { 
            //-----------------------------------
            // Create an overflow event
            //-----------------------------------
            
            // Make a copy of the existing event...
            overflowEvent               = *a_pEventRecord;
            
            overflowEvent.Overflow      = TRUE;
            overflowEvent.ContactCutout = FALSE;
            overflowEvent.Qualifier     = EVENTTYPE_NORMAL;
            overflowEvent.CurrentState  = EVENTSTATE_ALARM;
            overflowEvent.EventPacket   = EVENTPACKET_OVERFLOW;
            
            ucPacketSize  = EVENTPACKETSIZE_OVERFLOW;
            EclInOverflow = TRUE;
        }
    }

    // Copy event to the ECL object buffer. Use a local copy of 
    // the EvntAppPtr and update the object member only after 
    // the entire event packet is copied. This way, C300 will be 
    // collecting only fully formed event packets.
    UINT16 uiAppPtr = EvntAppPtr;
    UINT8 *ucEventRecordBytes = NULL;
    
    if (EclInOverflow)
    {
        ucEventRecordBytes = (UINT8 *)&overflowEvent;
    }
    else
    {
        ucEventRecordBytes = (UINT8 *)a_pEventRecord;
    }

    for (UINT8 ucCount = 0; ucCount < ucPacketSize; ucCount++) 
    {
        CircularList[uiAppPtr] = *ucEventRecordBytes++;
        uiAppPtr++;
        if (uiAppPtr >= ECL_SIZE) 
        { 
            // wrap around
            uiAppPtr = 0;
        }
    }

    // Update EvntAppPtr in the ECL object.
    EvntAppPtr = uiAppPtr;

    // Set ECL status according to the ECL type
    SetStatus(ECLSTATUS_NORMAL);

    // Restore original interrupt priority mask.
    set_imask_exr(ucSaveExr);

    return EclInOverflow ? FALSE : TRUE;
}
/*******************************************************************************
*                             clsEcl::CollectEclInfo                           *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsEcl::CollectEclInfo(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes) {
    // Calculate the current ECL size.
    UINT16 uiEclSize = GetEclSize();
    
    // Check and adjust to the length that can be transmitted.
    if (uiEclSize < a_uiMaxBytes) {
        a_uiMaxBytes = uiEclSize;
    }

    // Copy remove pointer and the length of the ECL data to the IOL buffer.
    DATABYTES DataBytes;
    DataBytes.ui16Val[0] = EvntRemPtr;
    *a_pBuffer++ = DataBytes.ucBytes[0];
    *a_pBuffer++ = DataBytes.ucBytes[1];
    DataBytes.ui16Val[0] = uiEclSize;
    *a_pBuffer++ = DataBytes.ucBytes[0];
    *a_pBuffer++ = DataBytes.ucBytes[1];
    
    // Return number of bytes that can be copied.
    return a_uiMaxBytes;
}
/*******************************************************************************
*                             clsEcl::CollectEclData                           *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID  clsEcl::CollectEclData(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes) {
    UINT16 uiRemPtr = EvntRemPtr;
    for (UINT16 uiCount = 0; uiCount < a_uiMaxBytes; uiCount++) {
        *a_pBuffer++ = CircularList[uiRemPtr++];
        // Check for wrap around
        if (uiRemPtr >= ECL_SIZE)   {
            uiRemPtr = 0; 
        }
    }
}
/*******************************************************************************
*                              clsEcl::UpdateRemPtr                            *
*                              ====================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID  clsEcl::UpdateRemPtr(UINT16 a_uiNewRemPtr) {
    // Check for wrap around and update remove pointer
    if (a_uiNewRemPtr >= ECL_SIZE) {
        a_uiNewRemPtr -= ECL_SIZE;
    }
    EvntRemPtr = a_uiNewRemPtr;
    // Reset ECL status bit if the circular list is empty
    if (EvntRemPtr == EvntAppPtr) {
            ResetStatus(ECLSTATUS_NORMAL);
    }
}
/*******************************************************************************
*                             clsEcl::IsRommForRegen                           *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL  clsEcl::IsRoomForRegen(VOID) {
    // Compute current ECL size and return TRUE if ECL is more than half empty.
    UINT16 uiEclFreeSpace = ECL_SIZE - GetEclSize();
    return (uiEclFreeSpace >= (ECL_SIZE / 2)) ? TRUE : FALSE;
}

#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_DI)
BOOL clsEcl::AddAlarmEvent(ALARMEVENTRECORD *pAlarmEvent)
{
    // Elevate the priority to STC interrupt level. This is to protect
    // ECL buffer integrity since AddEvent is called from multple places.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    // Check whether there is enough free space in the ECL. Always leave space
    // for OVERFLOW event + 1 byte. The additional 1 byte prevents append
    // pointer from catching up with remove pointer which represents empty ECL.
    UINT16 uiEclFreeSpace = ECL_SIZE - GetEclSize();
    if (uiEclFreeSpace < (EVENTPACKETSIZE_ALARM + EVENTPACKETSIZE_OVERFLOW + 1)) 
    {
        // no more space in ECL
        return FALSE;
    }

    // Copy event to the ECL object buffer. Use a local copy of 
    // the EvntAppPtr and update the object member only after 
    // the entire event packet is copied. This way, C300 will be 
    // collecting only fully formed event packets.
    UINT16 uiAppPtr = EvntAppPtr;
    UINT8 *ucEventRecordBytes = (UINT8 *)pAlarmEvent;    

    for (UINT8 ucCount = 0; ucCount < EVENTPACKETSIZE_ALARM; ucCount++)
    {
        CircularList[uiAppPtr] = *ucEventRecordBytes++;  

        uiAppPtr++;
        if (uiAppPtr >= ECL_SIZE)
        {
            // wrap around
            uiAppPtr = 0;
        }
    }

    // Update EvntAppPtr in the ECL object.
    EvntAppPtr = uiAppPtr;

    // Set ECL status according to the ECL type
    SetStatus(ECLSTATUS_NORMAL);

    // Restore original interrupt priority mask.
    set_imask_exr(ucSaveExr);

    return TRUE;
}
#endif

#if defined IOMTYPE_DISOE || defined IOPTYPE_DI
/*******************************************************************************
*                             clsEcl::IsRoomForPVCLRegen                       *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL  clsEcl::IsRoomForPVCLRegen(VOID) {
    // Compute current PVCL size and return TRUE if PVCL is more than half empty.
    UINT16 uiEclFreeSpace = PVCHGCL_SIZE - GetPVCHGCLSize();
    return (uiEclFreeSpace >= (PVCHGCL_SIZE / 2)) ? TRUE : FALSE;
}
/*******************************************************************************
*                             clsEcl::CollectPVCLInfo                          *
*                             ======================                           *
* PURPOSE: To return the length of PVCL and Remove pointer                     *
* ARGUMENTS: Buffer to fill the data and maxbyets that IOL xmit_buffer can send*
* RETURN: No of data bytes which can be collected by the IOL                   *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsEcl::CollectPVCLInfo(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes) 
{
    // Calculate the current PVCL size.
    UINT16 uiPVCLSize = GetPVCHGCLSize();
    // Check and adjust to the length that can be transmitted.
    if (uiPVCLSize < a_uiMaxBytes) 
    {
        a_uiMaxBytes = uiPVCLSize;
    }
    // Copy remove pointer and the length of the PVCL data to the IOL buffer.
    DATABYTES DataBytes;
    DataBytes.ui16Val[0] = PVCLRemPtr;
    *a_pBuffer++ = DataBytes.ucBytes[0];
    *a_pBuffer++ = DataBytes.ucBytes[1];
    DataBytes.ui16Val[0] = uiPVCLSize;
    *a_pBuffer++ = DataBytes.ucBytes[0];
    *a_pBuffer++ = DataBytes.ucBytes[1];
    // Return number of bytes that can be copied.
    return a_uiMaxBytes;
}
/*******************************************************************************
*                             clsEcl::CollectPVCLData                          *
*                             ======================                           *
* PURPOSE:  To return the requested no of bytes in a_pBuffer                   *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID  clsEcl::CollectPVCLData(UINT8 *a_pBuffer, UINT16 a_uiMaxBytes) 
{
    UINT16 uiRemPtr = PVCLRemPtr;
    for (UINT16 uiCount = 0; uiCount < a_uiMaxBytes; uiCount++) 
    {
        *a_pBuffer++ = PVCHGCircularList[uiRemPtr++];
        // Check for wrap around
        if (uiRemPtr >= PVCHGCL_SIZE)  
        {
            uiRemPtr = 0; 
        }
    }
}
/*******************************************************************************
*                              clsEcl::UpdatePVCLRemPtr                        *
*                              ====================                            *
* PURPOSE:  Update the remove pointer of PVCL                                  *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID  clsEcl::UpdatePVCLRemPtr(UINT16 a_uiNewRemPtr) 
{
    // Check for wrap around and update remove pointer
    if (a_uiNewRemPtr >= PVCHGCL_SIZE) 
    {
        a_uiNewRemPtr -= PVCHGCL_SIZE;
    }
    PVCLRemPtr = a_uiNewRemPtr;
    // Reset PVCL status bit if the circular list is empty
    if (PVCLRemPtr == PVCLAppPtr) 
    {
        if (ECLTYPE_PVCHANGE == EclType) 
        {
            ResetStatus(ECLSTATUS_PVCHANGE);
        }
    }
}
/*******************************************************************************
*                             clsEcl::AddPVCHGEvent                            *
*                             ======================                           *
*  Add the PV change event to PVCL. This function must not be called from any  *
*  context that runs higher than LVLPRI_TICK level.                            *
*******************************************************************************/
BOOL clsEcl::AddPVCLEvent(PVCLEVTRECORD *a_pPVCLEventRecord)
{
    // Check whether there is enough free space in the PVCL. The additional 1 byte prevents 
    // append pointer from catching up with remove pointer which represents empty PVECL.
    UINT8 ucPacketSize = 0;
    switch (a_pPVCLEventRecord->EventPktType) 
    {
#if defined(IOPTYPE_DI)
      case EEENTPACKET_EIP: 
            ucPacketSize = EVENTPACKETSIZE_SOEPVC;
            break;
#endif
        case EVENTPACKET_SYSTEM:
            ucPacketSize = EVENTPACKETSIZE_SYSTEM;
            break;
        case EVENTPACKET_SOEPVC:
            ucPacketSize = EVENTPACKETSIZE_SOEPVCTS;
            break;
        case EVENTPACKET_IOLTSB:
            ucPacketSize = EVENTPACKETSIZE_IOLTSB;
            break;
        case EVENTPACKET_SOELOST:
            ucPacketSize = EVENTPACKETSIZE_SOELOST;
            break;
        default:
            HardFail(HF_BADPROGRAMJUMP,ECL_CPP,__LINE__);
    }

    // Mask it with TICK lavel, as there is a chance of EVM (Event Manager Task)
    // get interrupted by the STC during Unsent packets posting.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    // check for the free space
    UINT16 uiPVEclFreeSpace = PVCHGCL_SIZE - GetPVCHGCLSize();
    if (uiPVEclFreeSpace >= (ucPacketSize+1)) 
    {
        PVCHGCLInOverflow = FALSE; 
    }
    else 
    {
        PVCHGCLInOverflow = TRUE;
    }

    if (PVCHGCLInOverflow == FALSE)
    {
        // Copy event to the PVCL. Use a local copy of the PVCLAppPtr
        // and update the object member only after the entire event
        // packet is copied. This way, C300 will be collecting only 
        // fully formed event packets.
        UINT16 uiAppPtr = PVCLAppPtr;
        UINT8 *ucEventRecordBytes = (UINT8 *) a_pPVCLEventRecord;

        for (UINT8 ucCount = 0; ucCount < ucPacketSize; ucCount++) 
        {
            PVCHGCircularList[uiAppPtr] = *ucEventRecordBytes++;
            uiAppPtr++;
            if (uiAppPtr >= PVCHGCL_SIZE)
            { 
                // wrap around
                uiAppPtr = 0;
            }
        }

        // Update PVCLAppPtr in the ECL object.
        PVCLAppPtr = uiAppPtr;

        // Set PVCL status according to the PVCL type
        SetStatus(ECLSTATUS_PVCHANGE);
    }

    set_imask_exr(ucSaveExr);
    return (!PVCHGCLInOverflow);
}
/*******************************************************************************
*                             clsEcl::GetPVCHGCLSize                           *
*                             ======================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/

// This method returns the PVCHGCircularlist size.
UINT16 clsEcl::GetPVCHGCLSize(VOID)
{
    if (PVCLAppPtr > PVCLRemPtr)
    {
        return (PVCLAppPtr - PVCLRemPtr);
    }
    if (PVCLRemPtr > PVCLAppPtr) { // Only AppPtr wrapped around
        return (PVCHGCL_SIZE - (PVCLRemPtr - PVCLAppPtr));
    }
    return 0; // PVCLAppPtr = PVCLRemPtr
}
#endif  //IOMTYPE_DISOE

