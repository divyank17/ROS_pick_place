////////////////////////////////////////////////////////////////////////////////
//                         CSysE, Fort Washington, PA.                        //
//                                                                            //
//                             COPYRIGHT (C) 2004                             //
//                HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                //
//                             ALL RIGHTS RESERVED                            //
//                                                                            //
// This software is a copyrighted work and / or information protected as a    //
// trade secret.  Legal rights of Honeywell Inc. in this software is distinct //
// from ownership of any medium in which the software is embodied. Copyright  //
// or trade secret notices included must be reproduced in any copies that are //
// authorized by Honeywell Inc.                                               //
//                                                                            //
// The information in this software is subject to change without notice and   //
// should not be considered as a commitment by Honeywell Inc.                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//   File Name   : adc.cpp                                                    //
//   Description : Analog to Digital Converter object source file             //
////////////////////////////////////////////////////////////////////////////////
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "scheduler.hpp"
#include "adc.hpp"

#if !LOWCOST
/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
#ifdef DEBUG
    extern UINT8  g_ucSyncChannel;
    extern UINT16 g_usSyncTime;
    extern BOOL   g_bFirstState,g_bSecondState;
#endif

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsAdc::aInputSelect[] = { 
    0x93,   // REF0
    0x81,   // CHAN01
    0x82,   // CHAN02
    0x83,   // CHAN03
    0x84,   // CHAN04
    0x86,   // CHAN05
    0x87,   // CHAN06
    0x88,   // CHAN07
    0x89,   // CHAN08
    0x8B,   // CHAN09
    0x8C,   // CHAN10
    0x8D,   // CHAN11
    0x8E,   // CHAN12
    0x91,   // CHAN13
    0x92,   // CHAN14
    0x94,   // CHAN15
    0x96,   // CHAN16
    0x80,   // CKVT1
    0x85,   // CKVT2
    0x8A,   // CKVT3
    0x8F,   // CKVT41
    0x90,   // CKVT52
    0x95,   // CKVT5
    0x97    // CALIB
};
/*******************************************************************************
*                                   GetRawData                                 *
*                                   ==========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsAdc::GetRawData(UINT8 a_ucMuxSel,UINT16 a_uiWaitTime) {
    INPSEL = aInputSelect[a_ucMuxSel];  // Select proper channel.

    if (a_uiWaitTime > 0) IdleWait(a_uiWaitTime);  // Wait for input to settle.

#ifdef DEBUG
    if (a_ucMuxSel == g_ucSyncChannel) {
        // if sync test is running, wait for the ADC clock sync edge and sync time.
        while (ADC_CLK == g_bFirstState);
        while (ADC_CLK == g_bSecondState);
        IdleWait(g_usSyncTime);
    }
#endif

    ADC_SPI.SSR = 0xFE;     // Assert slave select to start conversion.
    ADC_SPI.TXD = 0;        // Write three bytes to SPI transmit register 
    ADC_SPI.TXD = 0;        // to create 24 DCLOCKs to ADC for input conversion.
    ADC_SPI.TXD = 0;        
    while ((ADC_SPI.SR & 0x04) != 0x04);           // Wait for TXDR to empty.
    ADC_SPI.SSR = 0xFF;                             // Deassert slave select.
    
    UINT32 ulData = 0;
    while ((ADC_SPI.SR & 0x01) == 0) {    // While receive FIFO is not empty
        ulData <<= BYTESIZE;                 // Shift MSB as LSB is received.
        ulData += ADC_SPI.RXD;                 // Get data from receive FIFO.
    }

    // ADC starts data transmission only at 6th clock cycle. So the received
    // data is left shifted by two bits in the UINT32 variable.  Right shift
    ulData >>= 2;                // by two bits to align the converted value.
    ulData &= 0x0000FFFF;                          // Mask out upper 16 bits.
    return (UINT16)ulData;
}




#else   // LOWCOST
/*******************************************************************************
*                                     clsAdc                                   *
*                                   ==========                                 *
* PURPOSE: Initialize                                                          *
*******************************************************************************/
clsAdc::clsAdc(VOID) {

    UINT8 ucAdcData;
    BOOL bSPITimeout; 
    // Initialize Registers
    disable_adc();
    send_adc_reset();
  
    IdleWait(ADC_RST_DLY);  // Delay after ADC Reset
    do{
        do{  
            bSPITimeout = FALSE;
            ChipSelect();
            write_adc_byte(ADCDEVID_RD_ADD);    
            ucAdcData = read_adc_byte();
            if(ADC_SPITO) bSPITimeout = TRUE;
            ChipDeselect();
            delay();
            delay();
        }while(bSPITimeout);
    }while(ucAdcData != ADC_DEV_ID);

    // Configure the ADC Registers and Read back the Register value and 
    // compare. If the Register write fails, do it again until it succeeds.  
    do{
        do{  
            bSPITimeout = FALSE;
            ChipSelect();
            write_adc_byte(CONFIG0_WR_ADD);     
            write_adc_byte(CONFIG0_DATA);  
            if(ADC_SPITO) bSPITimeout = TRUE;
            ChipDeselect();
            delay();
            delay();
        }while(bSPITimeout);  
 
        do{  
            bSPITimeout = FALSE;
            ChipSelect();
            write_adc_byte(CONFIG0_RD_ADD);//config0=60     
            ucAdcData = read_adc_byte();
            if(ADC_SPITO) bSPITimeout = TRUE;
            ChipDeselect();
            delay();
            delay();
        }while(bSPITimeout);       
    }while( ucAdcData != CONFIG0_DATA);
    
    do{
        do{  
            bSPITimeout = FALSE;
            ChipSelect();
            write_adc_byte(CONFIG1_WR_ADD);     
            write_adc_byte(CONFIG1_DATA);  
            if(ADC_SPITO) bSPITimeout = TRUE;
            ChipDeselect();
            delay();
            delay();
        }while(bSPITimeout);

        do{  
            bSPITimeout = FALSE;
            ChipSelect();
            write_adc_byte(CONFIG1_RD_ADD);     
            ucAdcData = read_adc_byte();
            if(ADC_SPITO) bSPITimeout = TRUE;
            ChipDeselect();
            delay();
            delay();       
        }while(bSPITimeout);       
    }while( ucAdcData != CONFIG1_DATA);

    // Configuration of Registers MUXSG0,MUXSG1 and SYSRED will do before reading
    // Internel or Externel channel data.
}
/*******************************************************************************
*                                   GetRawData                                 *
*                                   ==========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAdc::GetRawData(BOOL a_bInternal, UINT32 * a_Array, BOOL bCalib) {
    UINT32 ulADCdata = 0;
    UINT8 i,j,nChannels,ucStatusByte,ucChanId;
    BOOL bSPITimeout;
    UINT8 ucNoOfConv = 0;
    UINT8 ucSaveExr = get_imask_exr();    

    ADC_START = 0;
    // Read the 16 input channels or the ADC internal parameters based on a_bInternal
    if (a_bInternal) nChannels = ADC_INT_CHANNELS; 
    else {
         if (bCalib) nChannels = ADC_CHANNELS + 3; // During Calibration read channel 1,2 and 3 twice.
         else nChannels = ADC_CHANNELS;                       
    }
    while (ADC_CHAN_CONNECTED != Connect(a_bInternal));        
       
    // Read the data from SPI
    for(j = nChannels; j > 0; j--) {
        set_imask_exr(LVLPRI_HIGHEST);        
        ADC_START = 1;                         // Pulse start conversion
        IdleWait(1);
        ADC_START = 0;
        set_imask_exr(ucSaveExr);

        start_timer();
        while (ADC_DRDY == 1 && (ADC_DRDY_TIMEOUT > read_timer())); // Wait for DRDY
      
        if(ADC_DRDY == 0) {
            bSPITimeout = FALSE;
            ChipSelect();
            for(i = 32; i > 0; i--) {
                ulADCdata = ulADCdata << 1;
                if(ADC_DOUT == 1) ulADCdata |= 0x01;
                   ADC_SCLK = 1;    // SCLK
                   ADC_SCLK = 0;
            } // end of for loop 
            if(ADC_SPITO)
            {
                // SPI Timeout happened. Ignore the data and read all the channels again.
                j = (nChannels + 1);
                bSPITimeout = TRUE;
            }
            ChipDeselect();
           // If the SPI Timeout happened, ignore the channel data
           if(!bSPITimeout){
               ucStatusByte = (UINT8)(ulADCdata >> 24); // Read Status byte        
               ucChanId = (ucStatusByte & LC_STS_CHID);
               if(a_bInternal)
                  a_Array[ucChanId - OFFSET_CHANID] = ulADCdata;
               else
                  a_Array[ucChanId - IN_LC_CHAN0] = ulADCdata;
           }                
       }
       else a_Array[nChannels-j] = ADC_CONV_INCOMPLETE;        
   }
} // end 
/*******************************************************************************
*                                   Connect
*                                   =======
* PURPOSE:
* ARGUMENTS:
* RETURN:
* NOTES: 
*******************************************************************************/
UINT16 clsAdc::Connect(BOOL a_bInternal) {
    UINT8 ucCONFIG0 = 0;
    UINT8 ucCONFIG1 = CONFIG1_DATA;
    UINT8 ucMUXSG0 = 0;
    UINT8 ucMUXSG1 = 0;
    UINT8 ucSYSRED = 0;
    UINT8 ucAdcData = 0;
    BOOL bSPITimeout= FALSE;

    // Determine proper selects
    if (a_bInternal) {
        ucCONFIG0 = 0x02;
        ucMUXSG0 = 0;
        ucMUXSG1 = 0;
        ucSYSRED = 0x3D;  // OFFSET,VCC,REF
    }
    else {
        ucCONFIG0 = 0x06;
        ucMUXSG0 = 0xFF;
        ucMUXSG1 = 0xFF;
        ucSYSRED = 0x00;
    }

    // Write to the Registers
   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(CONFIG0_WR_ADD);//config0=60     
      write_adc_byte(ucCONFIG0);  //config0data=06 CHOP Mode Enabled
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(CONFIG0_RD_ADD);//config0=60     
      ucAdcData = read_adc_byte();
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);

    if( ucAdcData != ucCONFIG0) return (256 * ucCONFIG0 + ucAdcData);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(CONFIG1_WR_ADD);//config0=60     
      write_adc_byte(ucCONFIG1);  //config0data=06 CHOP Mode Enabled
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay(); 
   }while(bSPITimeout);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(CONFIG1_RD_ADD);     
      ucAdcData = read_adc_byte();
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);

    if( ucAdcData != ucCONFIG1) return (256 * ucCONFIG1 + ucAdcData);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(MUXSG0_WR_ADD);    
      write_adc_byte(ucMUXSG0);  
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(MUXSG0_RD_ADD);    
      ucAdcData = read_adc_byte();
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);

    if( ucAdcData != ucMUXSG0) return (256 * ucMUXSG0 + ucAdcData);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(MUXSG1_WR_ADD);    
      write_adc_byte(ucMUXSG1);  
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(MUXSG1_RD_ADD);    
      ucAdcData = read_adc_byte();
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);
   
    if( ucAdcData != ucMUXSG1) return (256 * ucMUXSG1 + ucAdcData);
    
   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(SYSRED_WR_ADD);    
      write_adc_byte(ucSYSRED);  
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);

   do{  
      bSPITimeout = FALSE;
      ChipSelect();
      write_adc_byte(SYSRED_RD_ADD);     
      ucAdcData = read_adc_byte();
      if(ADC_SPITO) bSPITimeout = TRUE;
      ChipDeselect();
      delay();
      delay();
   }while(bSPITimeout);
    
    if( ucAdcData != ucSYSRED) return (256 * ucSYSRED + ucAdcData);

    return 0;
} 
#ifdef DEBUG
/*******************************************************************************
*                                    ADCRegWrite                               *
*                                    ===========                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAdc::WriteRegData(UINT8 sucRegAdd,UINT8 sucRegData) {
     UINT8 ucAdcData=0;

     ChipSelect();
     write_adc_byte((sucRegAdd|0x60));//muxsg0add=64     
     write_adc_byte(sucRegData);//muxsg0data
     ChipDeselect();
     delay();
     delay();
     ChipSelect();
     write_adc_byte((sucRegAdd|0x40));   
     ucAdcData = read_adc_byte();
     ChipDeselect();
     delay();
     delay();
     return ucAdcData;
}
/*******************************************************************************
*                                    ADCRegRead                                *
*                                    ===========                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAdc::ReadRegData(UINT8 sucRegAdd) {
     UINT8 ucAdcData=0;

     ChipSelect();
     write_adc_byte((sucRegAdd|0x40));   
     ucAdcData = read_adc_byte();
     ChipDeselect();
     delay();
     delay();
     return ucAdcData;
}
#endif
/*******************************************************************************
*                           Private HW Access Routines                         *
*                                   ==========                                 *
* PURPOSE:                                                                     *
*******************************************************************************/
void clsAdc::disable_adc(void)
{
  ADC_DIN = 0;    //DIN
  ADC_START = 0;  //start
  ADC_CS_OUT = 1;     //cs
  ADC_SCLK = 0;   //clock
}

void clsAdc::send_adc_reset(void)
{
    BOOL bSPITimeout = FALSE;
    do{
       ChipSelect();
       write_adc_byte(0xc0);    
       if(ADC_SPITO) bSPITimeout = TRUE;
       ChipDeselect();
       delay();
       delay();
    }while(bSPITimeout);
} 

void clsAdc::toggle_adc_din(void)
{
   ADC_DIN = 1; //din high 
   NOP;
   ADC_DIN = 0; //din low
   NOP;
} 

void clsAdc::toggle_adc_clk(void)
{
   ADC_SCLK = 1;  //clk high 
   NOP;
   ADC_SCLK = 0;  //clk low
   NOP;
} 

void clsAdc::toggle_adc_start(void)
{
   ADC_START = 1;   //start high 
   NOP;
   ADC_START = 0;   //start low
   NOP;
} 

void clsAdc::write_adc_byte(UINT8 adc_data)
{
  int data_index;
  char adc_temp;

  for (data_index=7; data_index>=0; data_index--)
  {
    delay();
    ADC_SCLK = 0;
    delay();
    adc_temp=adc_data;
    ADC_DIN = 0x01 & (adc_temp>>data_index);     //SDI
    delay();
    ADC_SCLK = 1;
  }
  ADC_SCLK = 0;
}

char clsAdc::read_adc_byte(void)
{
  int data_index;
  char adc_data_read_byte=0x00;

  NOP;
  for (data_index=7; data_index>=0; data_index--)
  {
    adc_data_read_byte = adc_data_read_byte <<1;
    if(ADC_DOUT == 1)    // SDO
       adc_data_read_byte |= 0x01;

    ADC_SCLK = 1;    // SCLK
    NOP;
    ADC_SCLK = 0; 
    NOP;
  } 
  return adc_data_read_byte;
}

void clsAdc::pulse_start(void)
{
  ADC_START = 0;
  NOP;
  ADC_START = 1;       // START
  NOP;
  ADC_START = 0;
}

#endif
