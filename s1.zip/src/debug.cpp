/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : debug.cpp                                                   *
*    Description : Debug task and debug port.                                  *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif
#ifdef IOMTYPE_AOH
#include "aohmain.h"
#endif
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
#include "dimain.h"
#endif
#ifdef IOMTYPE_DO
#include "domain.h"
#endif
#ifdef IOMTYPE_LLMUX
#include "llmuxmain.h"
#endif
#ifdef IOMTYPE_PI
#include "pimain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;
extern UINT32 g_ulTestLocation;
extern BOOL HartLoopBkTestInProgress;
extern BOOL FactryModeWDTUTest;
const UINT8 WDTREFRESHCOUNT = 10;
/*******************************************************************************
*                             GLOBAL & STATIC DATA                             *
*******************************************************************************/
BOOL   g_bTppInProgress = FALSE;
BOOL   g_bStopDiagTask = FALSE;
UINT16 g_usDiagCount = 0;
UINT16 g_usWdtTestTimer[] = { 0,0 } ;
BOOL   g_bWdtTestInProgress; // WDT refresh disable - to test WDT
UINT8  g_ChangeWdtRefreshTime = WDTREFRESHCOUNT;
UINT8  g_ucCpuFreeTestIndex = 0;
UINT32 g_ulCpuFreeTestCounts[CPUFREE_TESTCOUNT];

CHAR   g_strDebugPrompt[SMALL_INPUT_BUFFER_SIZE];

#if (defined(IOMTYPE_AI) || defined(IOMTYPE_AIH))
    UINT8  g_ucSyncChannel = 0xFF;
    UINT16 g_usSyncTime    = 0;
    BOOL   g_bFirstState   = FALSE;
    BOOL   g_bSecondState  = TRUE;
#endif

#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
    BOOL g_bStopDiTests = FALSE;
#endif

#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    BOOL g_bStopRefresh = FALSE; 
    UINT16 g_usMaxLpbkCount = 0;
    UINT16 g_usMinLpbkCount = 0;
#endif

#if defined(IOMTYPE_LLMUX)
    BOOL   g_bStopFtaScan = FALSE;
#endif

#if defined(IOMTYPE_PI) 
    BOOL    g_bIPIntProcessed = FALSE;
    BOOL    g_bFreqValTst = FALSE;
    UINT8   g_ucSlotInTest = 0;
#endif

#pragma section REBOOT_SECTION
    CHAR g_cRebootTestString[SMALL_INPUT_BUFFER_SIZE];
#pragma section

static char s_cInputBuffer[SMALL_INPUT_BUFFER_SIZE];
static char s_cCommandBuffer[SMALL_INPUT_BUFFER_SIZE];
static CONTEXT sTestRebootContext = CONTEXT_ZERO;
/*******************************************************************************
*                          clsDebugPort::clsDebugPort                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
clsDebugPort::clsDebugPort(VOID) {
    // Initialize data members
    ucInputIndex  = 1;
    ucOutputIndex = 0;
    // Initialize serial port registers
    MSTPCR_SCI1 = 0;  // Clear module stop bit for SCI1
    SCIC1_TE    = 0;  // Disable transmitter
    SCIC1_RE    = 0;  // Disable receiver
    SCIC1_CKE   = 0;  // Setup internal clock source for SCI1
    SCIC1_SMR   = 0;  // Async,8bit data,no parity,1 stop bit,no multi,use CLK
    SCIC1_BRR   = 12; // For 24 MHz crystal, 57.6 kbps
    // Setup interrupt priorty level 1 for debug serial port interrupts.
    IPRI_DEBUG  = 1;
}
/*******************************************************************************
*                          clsDebugPort::SciOneTxiIsr                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDebugPort::SciOneTxiIsr(VOID) {
    if (NULLCHAR != DebugPort.OutputBuffer[DebugPort.ucInputIndex]) {
        SCIC1_TDR = DebugPort.OutputBuffer[DebugPort.ucInputIndex++];
        SCIC1_TDRE = 0; 
    }
    else {
        IdleWait(20000);   // 20 msec wait (Workaround)
        SCIC1_TIE  = DISABLE; // disable transmit data empty interrupt
        SCIC1_TEIE = ENABLE;  // enable transmit end interrupt
        DebugPort.ucInputIndex = 1;
    }
}
/*******************************************************************************
*                          clsDebugPort::SciOneTriIsr                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDebugPort::SciOneTriIsr(VOID) {
    SCIC1_TEND = 0; // acknowledge the interrupt
    SCIC1_TEIE = DISABLE;  // disable transmit end interrupt
    SCIC1_TE   = DISABLE;  // disable SCI1 transmitter
}
/*******************************************************************************
*                          clsDebugPort::PrintString                           *
*                          =========================                           *
* PURPOSE:                                                                     *
*    Print a string to the debug port.                                         *
* ARGUMENTS:                                                                   *
*    a_cstrPrint - pointer to the string to be printed.                        *
*    Variable argument list of substitute variables in the string.             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function delays the calling thread of execution until the entire     *
*    string is printed at 57.6kbpd.                                            *
*    This function is not re-entrant. Be careful when invoking from an ISR.    *
*******************************************************************************/
RETURNSTATUS clsDebugPort::PrintString(const CHAR *a_cstrPrint,...) {
    if (ENABLE == SCIC1_TE) { // previous print did not finish yet
        return RETURNSTATUS_INPROGRESS;
    }
    SCIC1_TE = ENABLE;  // enable SCI1 transmitter
    // Expand the string to printed by substituting arguments.
    CHAR *strMarker = (CHAR *)&a_cstrPrint + sizeof(a_cstrPrint);
    snprintf(OutputBuffer,a_cstrPrint,strMarker,OUTPUT_BUFFER_SIZE);
    // Send the first character. Rest of the string will be transmitted
    // at interrupt level by SciOneTxiIsr.
    if (NULLCHAR != OutputBuffer[0]) {
        SCIC1_TDR = OutputBuffer[0];
        SCIC1_TDRE = 0;
    }
    SCIC1_TIE = ENABLE; // enable transmit data empty interrupt
    IdleWait(1000);
    return RETURNSTATUS_COMPLETE;
}
/*******************************************************************************
*                           clsDebugPort::GetInput                             *
*                           ======================                             *
* PURPOSE:                                                                     *
*    Get string input from debug port.                                         *
* ARGUMENTS:                                                                   *
*    a_ucpBuf - Buffer where input to be received.                             *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if ENTER input is received or buffer is full.       *
*    RETURNSTATUS_INPROGRESS for any other input or if no input detected.      *
* NOTE:                                                                        *
*    This function is not re-entrant and should not be called from ISRs.       *
*    The calling function is supposed to keep calling this function until      *
*    RETURNSTATUS_COMPLETE is returned.                                        *
*    Received string is returned to the caller using the reference argument.   *
*******************************************************************************/
RETURNSTATUS clsDebugPort::GetInput(CHAR *a_ucpBuf,const UINT8 a_ucMaxLen) {
    CHAR cRcvdChar = NULLCHAR;
    if (SCIC1_RDRF) { // If a key is pressed at the debug terminal.
        cRcvdChar = SCIC1_RDR;
        SCIC1_RDRF = 0;
        if (SCIC1_ORER || SCIC1_FER || SCIC1_PER) {
            // Reception errors - ignore received char and clear error flags.
            SCIC1_ORER = 0;
            SCIC1_PER  = 0;
            SCIC1_FER  = 0;
        }
        else {
            if ('\b' == cRcvdChar) {
                // If backspace is received, send it back to the terminal to
                // erase the last char. But this will only move the cursor 
                // back by one charcter position. Send a blank and another 
                // backspace to erase the character to reposition the cursor.
                if (ucOutputIndex > 0) {
                    ucOutputIndex--;
                    while (RETURNSTATUS_COMPLETE != DebugPort.PrintString("\b \b")); 
                }
            }
                
            if (('\r' == cRcvdChar) || (a_ucMaxLen == (ucOutputIndex + 1))) { 
                // If ENTER key is pressed or the buffer is full, null terminate 
                // the buffer and return COMPLETE status to process the input.
                *(a_ucpBuf + ucOutputIndex) = NULLCHAR; 
                ucOutputIndex = 0;
                return RETURNSTATUS_COMPLETE; 
            }

            if (((cRcvdChar >= '0') && (cRcvdChar <= '9')) ||
                ((cRcvdChar >= 'a') && (cRcvdChar <= 'z')) ||
                ((cRcvdChar >= 'A') && (cRcvdChar <= 'Z')) ||
                (cRcvdChar == '-') || (cRcvdChar == '.')) {
                // If all checks passed, add character to the buffer, 
                // null terminate and echo back to the terminal display.
                *(a_ucpBuf + ucOutputIndex) = cRcvdChar;          
                *(a_ucpBuf + ucOutputIndex + 1) = NULLCHAR; 
                while (RETURNSTATUS_COMPLETE != 
                       DebugPort.PrintString(a_ucpBuf + ucOutputIndex));
                ucOutputIndex++;
            }
        }
    }
    return RETURNSTATUS_INPROGRESS;
}
/*******************************************************************************
*                                 AdvanceContext                               *
*                                 ==============                               *
* PURPOSE:                                                                     *
*    Print the magnificiant startup screen at the debug port.                  *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    Called by the application startup code and also as response to the debug  *
*    command "clear".                                                          *
*******************************************************************************/
static RETURNSTATUS AdvanceContext(const CONTEXT a_LASTCONTEXT,CONTEXT& a_Context,
                                   RETURNSTATUS a_RtnSts) {
    if (RETURNSTATUS_COMPLETE == a_RtnSts) {
        a_Context = (CONTEXT)((UINT8)a_Context + 1);
        if (a_Context > a_LASTCONTEXT) {
            a_Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
    }
    return RETURNSTATUS_INPROGRESS;
}
/*******************************************************************************
*                                 StartupScreen                                *
*                                 =============                                *
* PURPOSE:                                                                     *
*    Print the magnificiant startup screen at the debug port.                  *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    Called by the application startup code and also as response to the debug  *
*    command "clear".                                                          *
*******************************************************************************/
static RETURNSTATUS StartupScreen(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts;
    switch (Context) {
    case CONTEXT_ZERO:
    case CONTEXT_ONE:
        RtnSts = DebugPort.PrintString("\n\n\n\n\n\n\n\n\n\n\n\n\n\r");
        break;
    case CONTEXT_TWO:
    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t*----------------------------------*");
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|        PROCESS MANAGER IO        |");
        break;
    case CONTEXT_FOUR:
        #ifdef IOMTYPE_AIH
        #if !LOWCOST
#if defined(IOPTYPE_HLAI) && !defined(HART_SUPPORT)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|        HLAI   %5d.%03d.%03d      |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
#elif defined(IOPTYPE_HLAI) && defined(HART_SUPPORT)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|       HLAIH   %5d.%03d.%03d      |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
#endif
        #else
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t| Series C  AI  IOM  %5d.%03d.%03d |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
        #endif
        #endif
        #ifdef IOMTYPE_AOH
        #if !LOWCOST
#if defined(IOPTYPE_AO16) && !defined(HART_SUPPORT)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|       AO16   %5d.%03d.%03d       |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
#elif defined(IOPTYPE_AO16) && defined(HART_SUPPORT)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|       AO16H   %5d.%03d.%03d      |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
#endif
        #else
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t| Series C  AO  IOM  %5d.%03d.%03d |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
        #endif
        #endif
        #if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
#if defined(DIGTYPE_DI)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|        DI   %5d.%03d.%03d        |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
#elif defined(DIGTYPE_DI24)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|       DI24   %5d.%03d.%03d       |",
                    VERSION_NUMBER, REVISION_NUMBER, BUILD_NUMBER);
#endif

        #endif
        #ifdef IOMTYPE_DO
#if defined(DIGTYPE_DO16)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|       DO16   %5d.%03d.%03d       |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
#elif defined(DIGTYPE_DO32)
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t|       DO32   %5d.%03d.%03d       |",
                    VERSION_NUMBER, REVISION_NUMBER, BUILD_NUMBER);
#endif
        #endif
        #ifdef IOMTYPE_LLMUX
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t| Series C LLMUX IOM %5d.%03d.%03d |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
        #endif
        #ifdef IOMTYPE_PI
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t| Series C  PI IOM   %5d.%03d.%03d |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
        #endif
        #ifdef IOMTYPE_UIO
        RtnSts = DebugPort.PrintString(
                    "\n\r\t\t\t| Series C UIO IOM   %5d.%03d.%03d |",
                    VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
        #endif        
        break;
    }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
/*******************************************************************************
*                                  ChangeBkgd                                  *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ChangeBkgd(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tState:%d Count:%d",
            !g_bStopDiagTask,g_usDiagCount);
        break;
    case CONTEXT_ONE:
        if (FALSE == g_bStopDiagTask) {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTOP);
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTART);
        }
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_THREE:
        if ('y' == s_cInputBuffer[0]) {
            if (FALSE == g_bStopDiagTask) {
                g_bStopDiagTask = TRUE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STOPPED);
            }
            else {
                g_bStopDiagTask = FALSE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STARTED);
            }
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_UNCHANGED);
        }
        break;
    }

    return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
/*******************************************************************************
*                                    ReadDb                                    *
*                                    ======                                    *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
RETURNSTATUS ReadDb(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucSlotNumber,ucParamNumber,ucDataSize,ucDataType;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ucSlotNumber = (UINT8)atoi(s_cInputBuffer);
        if (ucSlotNumber > ((clsBoxSlot *)pDatabase[0])->GetMaxSlots()) {
            RtnSts = DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_FOUR;
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PARAMNUMBER);
        }
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        ucParamNumber = (UINT8)atoi(s_cInputBuffer);
        ucDataSize = pDatabase[ucSlotNumber]->GetParamSize(ucParamNumber);
        if (ucDataSize > sizeof(FLOAT32)) {
            ucDataSize = sizeof(FLOAT32);
        }
        ucDataType = pDatabase[ucSlotNumber]->GetDataType(ucParamNumber);
        switch (ucDataType) {
        case DT_UINT8:
        case DT_BOOL:
        case DT_ENUM:
        case DT_SDENUM:
            UINT8 ucParam;
            pDatabase[ucSlotNumber]->ReadParamData(&ucParam,ucParamNumber);
            RtnSts = DebugPort.PrintString(PRINTSTRING_PRINTPARAM,
                             ucParamNumber,ucDataType,ucDataSize,ucParam);
            break;
        case DT_UINT16:
            UINT16 uiParam;
            pDatabase[ucSlotNumber]->ReadParamData((UINT8 *)&uiParam,ucParamNumber);
            RtnSts = DebugPort.PrintString(PRINTSTRING_PRINTPARAM,
                             ucParamNumber,ucDataType,ucDataSize,uiParam);
            break;
        case DT_INT16:
            INT16 iParam;
            pDatabase[ucSlotNumber]->ReadParamData((UINT8 *)&iParam,ucParamNumber);
            RtnSts = DebugPort.PrintString(PRINTSTRING_PRINTPARAM,
                             ucParamNumber,ucDataType,ucDataSize,iParam);
            break;
        case DT_UINT32:
            UINT32 ulParam;
            pDatabase[ucSlotNumber]->ReadParamData((UINT8 *)&ulParam,ucParamNumber);
            RtnSts = DebugPort.PrintString(
                             "\n\r\tPrm:%d Typ:%d Size:%d Val:%u",
                             ucParamNumber,ucDataType,ucDataSize,ulParam);
            break;
        case DT_INT32:
            INT32 lParam;
            pDatabase[ucSlotNumber]->ReadParamData((UINT8 *)&lParam,ucParamNumber);
            RtnSts = DebugPort.PrintString(
                             "\n\r\tPrm:%d Typ:%d Size:%d Val:%l",
                             ucParamNumber,ucDataType,ucDataSize,lParam);
            break;
        case DT_FLOAT32:
            FLOAT32 fParam;
            pDatabase[ucSlotNumber]->ReadParamData((UINT8 *)&fParam,ucParamNumber);
            fParam *= 1000;
            RtnSts = DebugPort.PrintString(
                             "\n\r\tPrm:%d Typ:%d Size:%d Val:%f",
                             ucParamNumber,ucDataType,ucDataSize,fParam);
            break;
        case DT_BLIND:
            RtnSts = DebugPort.PrintString("\n\r\tBLND-mget 0x%X",
                             pDatabase[ucSlotNumber]->GetParamPtr(ucParamNumber));
            break;
        }
        break;
    }

    return AdvanceContext(CONTEXT_FOUR,Context,RtnSts);
}
/*******************************************************************************
*                                    WriteDb                                   *
*                                    =======                                   *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
RETURNSTATUS WriteDb(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static VOID *pParamPtr;
    static UINT8 ucParamNumber,ucSlotNumber,ucDataType,ucAccessType;
    static CONTEXT Context = CONTEXT_ZERO;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ucSlotNumber = (UINT8)atoi(s_cInputBuffer);
        if (ucSlotNumber > ((clsBoxSlot *)pDatabase[0])->GetMaxSlots()) {
            Context = CONTEXT_ZERO;
            return DebugPort.PrintString(PRINTSTRING_INVALID);
        }
        RtnSts = DebugPort.PrintString(PRINTSTRING_PARAMNUMBER);
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        ucParamNumber = (UINT8)atoi(s_cInputBuffer);
        ucDataType    = pDatabase[ucSlotNumber]->GetDataType(ucParamNumber);
        ucAccessType  = pDatabase[ucSlotNumber]->GetAccessType(ucParamNumber);
        if (DT_NONE == ucDataType) {
            Context = CONTEXT_ZERO;
            return DebugPort.PrintString(PRINTSTRING_INVALID);
        }
        pParamPtr = pDatabase[ucSlotNumber]->GetParamPtr(ucParamNumber);
        if (DT_BLIND == ucDataType) {
            Context = CONTEXT_ZERO;
            if (AT_PSET == ucAccessType) {
                return DebugPort.PrintString("\n\r\tPrmSet-write each param");
            }
            else {
                return DebugPort.PrintString("\n\r\tBLND-mset 0x%X",pParamPtr);
            }
        }
        RtnSts = DebugPort.PrintString("\n\r\tData:");
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_SIX:
        switch (ucDataType) {
        case DT_UINT8:
        case DT_BOOL:
        case DT_ENUM:
        case DT_SDENUM:
            if (AT_BXPACK == ucAccessType) {
                // In this case, slot data is kept in box as a bitmap and 
                // pDestination will be pointing to the the box database 
                // member where this data is kept. 
                UINT8 ucBitIndex  = 0x80 >> ((ucSlotNumber - 1) & 0x07);
                UINT8 ucByteIndex = ((ucSlotNumber - 1) >> 3) & 0x03;
            
                if ((UINT8)atoi(s_cInputBuffer) > 0) {
                    ((UINT8 *)pParamPtr)[ucByteIndex] |= ucBitIndex;
                }
                else ((UINT8 *)pParamPtr)[ucByteIndex] &= ~ucBitIndex;
            
            }
            else {
                *((UINT8 *)pParamPtr) = (UINT8)atoi(s_cInputBuffer);
                if (PARAMID_DSA == ucParamNumber) {
                    Iol.ucIolDSA = *((UINT8 *)pParamPtr);
                    Iol.ucIolBA = 0;
                }
            }
            break;
        case DT_UINT16:
            *((UINT16 *)pParamPtr) = (UINT16)atoi(s_cInputBuffer);
            break;
        case DT_INT16:
            *((INT16 *)pParamPtr) = atoi(s_cInputBuffer);
            break;
        case DT_UINT32:
            *((UINT32 *)pParamPtr) = (UINT32)atoi(s_cInputBuffer);
            break;
        case DT_INT32:
            *((INT32 *)pParamPtr) = (INT32)atoi(s_cInputBuffer);
            break;
        case DT_FLOAT32:
            *((FLOAT32 *)pParamPtr) = (FLOAT32)atof(s_cInputBuffer);
            break;
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_SIX,Context,RtnSts);
}
/*******************************************************************************
*                                  ReadMemory                                  *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ReadMemory(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucType,ucColumn,ucOutType;
    static UINT32 ulAddress,ulTestLocation;
    static UINT16 uiReadCount;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTTYPE);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ucType = (UINT8)atoi(s_cInputBuffer);
        if ((ucType < 1) || (ucType > 3)) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTADDR);
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        ulAddress = 0;
        ulAddress = atoh(s_cInputBuffer);
        if (ulAddress > ADDRESS_RANGE_END) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        else {
          RtnSts = DebugPort.PrintString(PRINTSTRING_HOWMANY);
        }
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_SIX:
        uiReadCount = 0;
        uiReadCount = atoi(s_cInputBuffer);
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_SEVEN:
           RtnSts = DebugPort.PrintString("\n\r\tPrint Once(0) or Continuous(1):");
            break;
    case CONTEXT_EIGHT:
           RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
           break; 
    case CONTEXT_NINE:
           ucOutType = (UINT8)atoi(s_cInputBuffer);
           if(!ucOutType)
                 Context = CONTEXT_ELEVEN;
           RtnSts = RETURNSTATUS_COMPLETE;
           break;
    case CONTEXT_TEN:
           ulTestLocation = ulAddress;
           RtnSts = DebugPort.PrintString(PRINTSTRING_XTOCANCEL);
           break;
    case CONTEXT_ELEVEN:
        if ((RETURNSTATUS_COMPLETE == DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE)) &&
            ('x' == s_cInputBuffer[0])) {
            ulTestLocation = 0;
            Context = CONTEXT_ONE;
            return RETURNSTATUS_COMPLETE;
        }
        else {
            if(1 == ucType){            
               DebugPort.PrintString("\rTestLoc:0x%X Data:0x%02x",ulTestLocation,*((UINT8 *)ulTestLocation));
               ulTestLocation+= sizeof(UINT8);
            }
            else if(2 == ucType){
                  DebugPort.PrintString("\rTestLoc:0x%X Data:0x%04x",ulTestLocation,*((UINT16 *)ulTestLocation));
                  ulTestLocation+= sizeof(UINT16);
            }
            else{
                  DebugPort.PrintString("\rTestLoc:0x%X Data:0x%08X",ulTestLocation,*((UINT32 *)ulTestLocation));
                  ulTestLocation+= sizeof(UINT32);
            }
            
            if(ulTestLocation > (ulAddress + uiReadCount))
                  ulTestLocation = ulAddress;
            RtnSts = RETURNSTATUS_INPROGRESS;
        }           
           break;
    case CONTEXT_TWELVE:
        if(uiReadCount > 0) {
            RtnSts = DebugPort.PrintString("\n\r 0x%08X\t",ulAddress);
            ucColumn = (3 == ucType) ? 4 : (BYTESIZE-1);
        }
        else {
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case CONTEXT_THIRTEEN:
        if (1 == ucType) {
            DebugPort.PrintString(" 0x%02x",*((UINT8 *)ulAddress));
            if ((uiReadCount > 0) && (ulAddress < ADDRESS_RANGE_END)) {
                ulAddress += sizeof(UINT8);
            }
        }
        else if (2 == ucType) {
            DebugPort.PrintString(" 0x%04x",*((UINT16 *)ulAddress));
            if ((uiReadCount > 0) &&
                (ulAddress < (ADDRESS_RANGE_END - sizeof(UINT16)))) {
                ulAddress += sizeof(UINT16);
            }
        }
        else if (3 == ucType) {
            DebugPort.PrintString(" 0x%08X",*((UINT32 *)ulAddress));
            if ((uiReadCount > 0) &&
                (ulAddress < (ADDRESS_RANGE_END - sizeof(UINT32)))) {
                ulAddress += sizeof(UINT32);
            }
        }
        if (uiReadCount > 0) {
            uiReadCount--;
            if (0 == uiReadCount) {
                RtnSts = RETURNSTATUS_COMPLETE;
            }
            else {
                if (ucColumn > 0) {
                    ucColumn--;
                }
                else {
                    Context = CONTEXT_TWELVE;
                }
                RtnSts = RETURNSTATUS_INPROGRESS;
            }
        }
        else {
          RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    }

    return AdvanceContext(CONTEXT_THIRTEEN,Context,RtnSts);
}
/*******************************************************************************
*                                  WriteMemory                                 *
*                                  ===========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS WriteMemory(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucType;
    static UINT32 ulAddress,ulData;
    static UINT8  ucWriteCount,ucMemType;
    switch (Context) {
    case CONTEXT_ZERO:
         RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTTYPE);
         break;
    case CONTEXT_ONE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_TWO:
         ucType = (UINT8)atoi(s_cInputBuffer);
         if ((ucType < 1) || (ucType > 3)) {
             DebugPort.PrintString(PRINTSTRING_INVALID);
             Context = CONTEXT_ZERO;
             return RETURNSTATUS_COMPLETE;
         }
         RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTADDR);
         break;
    case CONTEXT_THREE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_FOUR:
         ulAddress = 0;
         ulAddress = atoh(s_cInputBuffer);
         if (ulAddress <= FLASH_END_ADDRESS) {
             RtnSts = DebugPort.PrintString("\n\r\tFlashAddr!");
             Context = CONTEXT_ZERO;
             return RETURNSTATUS_COMPLETE;
         }
         else if (((ulAddress >= INTERNAL_RAM_START_ADDRESS) && 
                   (ulAddress <= ADDRESS_RANGE_END)) || 
                    ulAddress < ADDRESS_RANGE_END) {
           RtnSts = DebugPort.PrintString(PRINTSTRING_HOWMANY);
         }
         else {
             DebugPort.PrintString(PRINTSTRING_INVALID);
             Context = CONTEXT_ZERO;
             return RETURNSTATUS_COMPLETE;
         }
         break;
    case CONTEXT_FIVE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_SIX:
         ucWriteCount = 0;
         ucWriteCount = atoi(s_cInputBuffer);
         RtnSts = DebugPort.PrintString("\n\r\tMemory Fill(1) or Memory Write(0):");        
         break;
    case CONTEXT_SEVEN:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE); 
         break;
    case CONTEXT_EIGHT:
         ucMemType = 0;
         ucMemType = atoi(s_cInputBuffer);
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_NINE:
         if(ucMemType == 1){
            RtnSts = DebugPort.PrintString("\n\r\tEnter Data:0x "); 
            Context = CONTEXT_TEN;
         }
         else{ 
            RtnSts = DebugPort.PrintString("\n\r\tAddr 0x%08X Data ",ulAddress);
         }        
         break;
    case CONTEXT_TEN:
         if (1 == ucType) {
             RtnSts = DebugPort.PrintString("0x%02x-New:0x",*((UINT8 *)ulAddress));
         }
         else if (2 == ucType) {
             RtnSts = DebugPort.PrintString("0x%04x-New:0x",*((UINT16 *)ulAddress));
         }
         else if (3 == ucType) {
             RtnSts = DebugPort.PrintString("0x%08X-New:0x",*((UINT32 *)ulAddress));
         }
         break;
    case CONTEXT_ELEVEN:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_TWELVE:
         ulData = atoh(s_cInputBuffer);
         RtnSts = DebugPort.PrintString("\n\r");
         break;
    case CONTEXT_THIRTEEN:
         if (ucWriteCount > 0) {
             ucWriteCount--;
         }
         if (1 == ucType) {
             *((UINT8 *)ulAddress) = (UINT8)ulData;
             if (ulAddress < ADDRESS_RANGE_END) {
                 if(ucMemType == 0)
                 DebugPort.PrintString("\tRdbk:0x%02x",*((UINT8 *)ulAddress));
                 if (ucWriteCount > 0) {
                     ulAddress += sizeof(UINT8);
                 }
             }
         }
         else if (2 == ucType) {
             *((UINT16 *)ulAddress) = (UINT16)ulData;
             if (ulAddress < ADDRESS_RANGE_END) {
                 if(ucMemType == 0)
                 DebugPort.PrintString("\tRdbk:0x%04x",*((UINT16 *)ulAddress));
                 if (ucWriteCount > 0) {
                     ulAddress += sizeof(UINT16);
                 }
             }
         }
         else if (3 == ucType) {
             *((UINT32 *)ulAddress) = (UINT32)ulData;
             if (ulAddress < ADDRESS_RANGE_END) {
                 if(ucMemType == 0)
                 DebugPort.PrintString("\tRdbk:0x%08X",*((UINT32 *)ulAddress));
                 if (ucWriteCount > 0) {
                     ulAddress += sizeof(UINT32);
                 }
             }
         }
         if(ucWriteCount > 0) {
             RtnSts = RETURNSTATUS_INPROGRESS;
             if(ucMemType == 0)
                Context = CONTEXT_NINE;
             else
                Context = CONTEXT_THIRTEEN;
         }
         else {
             if(ucMemType == 1)
                RtnSts = DebugPort.PrintString("\r\tMemory Fill Completed");
             else
                RtnSts = RETURNSTATUS_COMPLETE;
         }
         break;
     }
 
     return AdvanceContext(CONTEXT_THIRTEEN,Context,RtnSts);
}
/*******************************************************************************
*                                 DisplayPorts                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS DisplayPorts(VOID) {
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
    UINT8 ucSaveExr;
#endif
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORT1\t:0x%02x (Write 0xFFFF60)",P_P1.PORT.BYTE);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.PrintString(
        "\n\r\t   B7.RCVSELA_n:%d   B6.TXREQ_n  :%d   B5.JABRES_n  :%d",
        RCVSELA_n,TXREQ_n,JABRES_n);
        break;
    case CONTEXT_TWO:
#if !AIAO
        RtnSts = DebugPort.PrintString(
        "\n\r\t   B4.WDTOCLR_n:%d   B3.WDTRFS_n :%d   B2-B0.RDBKSEL:%d",
        WDTODCLR_n,WDTRFS_n,RDBK_SEL);
#else
        #if (defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
        RtnSts = DebugPort.PrintString(
        "\n\r\t   B4.WDTOCLR_n:%d   B3.WDTRFS_n :%d   B2.PROGRAM_n :%d \n\r\t   B1.BD_TCK  :%d   B0.BD_TDI :%d",
        WDTODCLR_n,WDTRFS_n,FPGA_ERASE_n,JTAG_TCK,JTAG_TDO);
        #else
        RtnSts = DebugPort.PrintString("\n\r\t   B4.WDTOCLR_n:%d   B3.WDTRFS_n :%d",
        WDTODCLR_n,WDTRFS_n);
        #endif
#endif
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORT2\t:0x%02x (Write to 0xFFFF61)",P_P2.PORT.BYTE);
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.PrintString(
        "\n\r\t   B7.CLRGHL_n :%d   B6.DIAGFL_n :%d   B5.SWBUREQ_n :%d",
        CLRGHL_n,DIAGFAIL_n,SWBUREQ_n);
        break;
    case CONTEXT_FIVE:
        #if (defined(IOMTYPE_PI) || defined(UIO))
        RtnSts = DebugPort.PrintString(
        "\n\r\t   B4.REBOOT_n :%d   B3.WDT_EN_n :%d   B1.BD_TMS :%d",
        REBOOT_n,WDT_EN_n,JTAG_TMS);
        #else
        RtnSts = DebugPort.PrintString(
        "\n\r\t   B4.REBOOT_n :%d   B3.WDT_EN_n :%d   B2.CLR_RIP_n :%d",
        REBOOT_n,WDT_EN_n,CLR_RIP_n);
        #endif
        break;
    case CONTEXT_SIX: 
        RtnSts = DebugPort.PrintString(
                 "\n\r\tPORT3\t:0x%02x (Write to 0xFFFF62)",P_P3.PORT.BYTE);
        break;
#if !AIAO
    case CONTEXT_SEVEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTA\t:0x%02x (Write 0xFFFF69)",P_PA.PORT.BYTE);
        break;
    case CONTEXT_EIGHT:
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        ucSaveExr = get_imask_exr();   // Save current interrupt mask.
        set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts.
        HG_SNS = 0; // Make sure that port is read with normal sensitivity.
        ((clsDiBoxSlot *)pDatabase[0])->StopOpenWireDiag(); // stop any open wire test scheduled.
        IdleWait(8000); // Wait for 8 msec for sensitivity to be normal.
#endif
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTB\t:0x%02x (Write 0xFFFF6A)",P_PB.PORT.BYTE);
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        set_imask_exr(ucSaveExr);
#endif
        break;
    case CONTEXT_NINE:
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        ucSaveExr = get_imask_exr();   // Save current interrupt mask.
        set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts.
        HG_SNS = 0; // Make sure that port is read with normal sensitivity.
        ((clsDiBoxSlot *)pDatabase[0])->StopOpenWireDiag(); // stop any open wire test scheduled.
        IdleWait(8000); // Wait for 8 msec for sensitivity to be normal.
#endif
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTC\t:0x%02x (Write 0xFFFF6B)",P_PC.PORT.BYTE);
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        set_imask_exr(ucSaveExr);
#endif
        break;
    case CONTEXT_TEN:
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        ucSaveExr = get_imask_exr();   // Save current interrupt mask.
        set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts.
        HG_SNS = 0; // Make sure that port is read with normal sensitivity.
        ((clsDiBoxSlot *)pDatabase[0])->StopOpenWireDiag(); // stop any open wire test scheduled.
        IdleWait(8000); // Wait for 8 msec for sensitivity to be normal.
#endif
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTD\t:0x%02x (Write 0xFFFF6C)",P_PD.PORT.BYTE);
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        set_imask_exr(ucSaveExr);
#endif
        break;
    case CONTEXT_ELEVEN:
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        ucSaveExr = get_imask_exr();   // Save current interrupt mask.
        set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts.
        HG_SNS = 0; // Make sure that port is read with normal sensitivity.
        ((clsDiBoxSlot *)pDatabase[0])->StopOpenWireDiag(); // stop any open wire test scheduled.
        IdleWait(8000); // Wait for 8 msec for sensitivity to be normal.
#endif
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTE\t:0x%02x (Write 0xFFFF6D)",P_PE.PORT.BYTE);
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        set_imask_exr(ucSaveExr);
#endif
        break;
    case CONTEXT_TWELVE:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTF\t:0x%02x (Write 0xFFFF6E)",P_PF.PORT.BYTE);
        break;
    case CONTEXT_THIRTEEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTG\t:0x%02x (Write 0xFFFF6F)",P_PG.PORT.BYTE);
        break;
#if defined(DIGTYPE_DO16)
    case CONTEXT_FOURTEEN:
        RtnSts = DebugPort.PrintString(
            "\n\r\tPORT6\t:0x%02x (Write to 0xFFFF65)",P_P6.PORT.BYTE);
        break;
#endif
#else // AIAO
    case CONTEXT_SEVEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORT4\t:0x%02x (Read 0xFFFF63)",P_P4.PORT.BYTE);
        break;
    case CONTEXT_EIGHT:
        #if (defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
        RtnSts = DebugPort.PrintString(
        "\n\r\t   B2.BD_TDO :%d   B1.FPGA_DONE:%d   B0.INIT_n    :%d",
        JTAG_TDI,FPGA_DONE,FPGA_INIT_n);
        #else
            #if !LOWCOST        
            RtnSts = DebugPort.PrintString(
            "\n\r\t   B2.JTAG_TDI :%d   B1.FPGA_DONE:%d   B0.FPGA_INIT_n    :%d",
            JTAG_TDI,FPGA_DONE,FPGA_INIT_n);
            #else
            RtnSts = RETURNSTATUS_COMPLETE;
            #endif
        #endif
        break;
    case CONTEXT_NINE:
        #if (defined(IOMTYPE_PI) || LOWCOST || defined(IOMTYPE_UIO))
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORT5\t:0x%02x (Write 0xFFFF64)",P_P5.PORT.BYTE);
        #else
        RtnSts = RETURNSTATUS_COMPLETE;
        #endif        
        break;
    case CONTEXT_TEN:
        #if (defined(IOMTYPE_PI) || LOWCOST || defined(IOMTYPE_UIO))
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORT6\t:0x%02x (Write 0xFFFF65)",P_P6.PORT.BYTE);
        #else
        RtnSts = RETURNSTATUS_COMPLETE; 
        #endif        
        break;
    case CONTEXT_ELEVEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTA\t:0x%02x (Write 0xFFFF69)",P_PA.PORT.BYTE);
        break;
    case CONTEXT_TWELVE:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTB\t:0x%02x (Write 0xFFFF6A)",P_PB.PORT.BYTE);
        break;
    case CONTEXT_THIRTEEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTC\t:0x%02x (Write 0xFFFF6B)",P_PC.PORT.BYTE);
        break;
    case CONTEXT_FOURTEEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTD\t:0x%02x (Write 0xFFFF6C)",P_PD.PORT.BYTE);
        break;
    case CONTEXT_FIFTEEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTE\t:0x%02x (Write 0xFFFF6D)",P_PE.PORT.BYTE);
        break;
    case CONTEXT_SIXTEEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTF\t:0x%02x (Write 0xFFFF6E)",P_PF.PORT.BYTE);
        break;
    case CONTEXT_SEVENTEEN:
        RtnSts = DebugPort.PrintString(
        "\n\r\tPORTG\t:0x%02x (Write 0xFFFF6F)",P_PG.PORT.BYTE);
        break;
#endif  //AIAO
    }

#if AIAO
    return AdvanceContext(CONTEXT_SEVENTEEN,Context,RtnSts);
#else
#if defined(DIGTYPE_DO16)
    return AdvanceContext(CONTEXT_FOURTEEN,Context,RtnSts);
#else
    return AdvanceContext(CONTEXT_THIRTEEN,Context,RtnSts);
#endif
#endif
}
#if !AIAO
/*******************************************************************************
*                                 ReadBack                                     *
*                                 ========                                     *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ReadBack(VOID) {
    static UINT8   sucRdbk    = RSR1;
    static CONTEXT Context    = CONTEXT_ZERO;
    static CONTEXT SubContext = CONTEXT_ZERO;

    UINT8 ucSaveExr;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(
                 "\n\r\tRdbkStsReg:%d\t:0x%02x",
                 (sucRdbk + 1), GetReadbackRegister(sucRdbk));
        break;
    case CONTEXT_ONE:
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        RDBK_SEL = sucRdbk;
        switch (sucRdbk) {
        case RSR1:
            RtnSts = DebugPort.PrintString("\n\r\t\t\tMODNUM\t\t:%d",MODNUM);
            break;
        case RSR2:
            switch(SubContext) {
            case CONTEXT_ZERO:
                RtnSts = DebugPort.PrintString(
                       "\n\r\t\t\tB7.FTAPRS\t:%d\n\r\t\t\tB6.Spare",FTAPRS);
                break;
            case CONTEXT_ONE:
                RtnSts = DebugPort.PrintString(
                       "\n\r\t\t\tB5.BUPREQ_FB\t:%d\n\r\t\t\tB4.GHOXXX\t:%d",
                       BUPREQ_FB,GHOXXX);
                break;
            case CONTEXT_TWO:
                RtnSts = DebugPort.PrintString(
                       "\n\r\t\t\tB3.JABLOCK_n\t:%d\n\r\t\t\tB2.BUPREQ_IN\t:%d",
                       JABLOCK_n,BUPREQ_IN);
                break;
            case CONTEXT_THREE:
                RtnSts = DebugPort.PrintString(
                       "\n\r\t\t\tB1.BOTTOM\t:%d\n\r\t\t\tB0.REDUNT_n\t:%d",
                       BOTTOM,REDUNT_n);
                break;
            }

            if (RETURNSTATUS_COMPLETE == RtnSts) {
                SubContext = (CONTEXT)((UINT8)SubContext + 1);
                if (SubContext < CONTEXT_THREE) {
                    set_imask_exr(ucSaveExr);
                    return RETURNSTATUS_INPROGRESS;
                }
            }
            SubContext = CONTEXT_ZERO;
            break;            
        case RSR3:
        case RSR4:
        case RSR5:
        case RSR6:
        case RSR7:
        case RSR9:        
#if !defined(IOPTYPE_DO) && !defined(DIGTYPE_DO32)
        case RSR10:
#endif
        case RSR11:
        case RSR12:
        case RSR13:
        case RSR14:
        case RSR15:
        case RSR16:
            break;
        case RSR8:
            RtnSts = DebugPort.PrintString(
                   "\n\r\t\t\tB7.RIP_n\t:%d\n\r\t\t\tB6.DIP_n\t:%d",RIP_n,DIP_n);
            if (RETURNSTATUS_INPROGRESS == RtnSts) {
                set_imask_exr(ucSaveExr);
                return RETURNSTATUS_INPROGRESS;
            }
            break;
#if defined(IOPTYPE_DO) && defined(DIGTYPE_DO32)
        case RSR10:
            RDBK_STRB_n = 1;                              // Disable CPLD outputs
            RDBK_SEL3   = 1;                              // Select CPLD 2
            RDBK_STRB_n = 0;                              // Re-enable CPLD outputs
            RtnSts = DebugPort.PrintString("\n\r\t\t\tB2.INSWV3\t:%d\n\r\t\t\tB1.INSWV2\t:%d\n\r\t\t\tB0.INSWV1\t:%d", INHSWV3, INHSWV2, INHSWV1);
            RDBK_STRB_n = 1;                              // Disable CPLD outputs
            RDBK_SEL3   = 0;                              // Select CPLD 1
            RDBK_STRB_n = 0;                              // Re-enable CPLD outputs
            break;
#endif
        }

        SubContext = CONTEXT_ZERO;
        set_imask_exr(ucSaveExr);
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_TWO:      
        if (sucRdbk < RSR16) {
            sucRdbk++;
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_INPROGRESS;
        }
        RtnSts = RETURNSTATUS_COMPLETE;
    }

    if (RETURNSTATUS_COMPLETE == RtnSts) {
        Context = (CONTEXT)((UINT8)Context + 1);
        if (Context > CONTEXT_TWO) {
            sucRdbk = RSR1;
            Context = CONTEXT_ZERO; 
            SubContext = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
    }
    return RETURNSTATUS_INPROGRESS;
}
#endif // (!AIAO)
#if !(defined(IOMTYPE_DO) || defined(IOMTYPE_DISOE))
/*******************************************************************************
*                                 TestWatchdog                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS TestWatchdog(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT32  ulTimer = 0;
    UINT8 ucNewRefreshRate;
    RETURNSTATUS   RtnSts  = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        g_usWdtTestTimer[0] = g_usWdtTestTimer[1] = 0;
        // Setup timer for 200 msec timeout.
        ulTimer = TaskScheduler.Get10msecCounter() + 20;
        TaskScheduler.EnableWatchdog();
        RtnSts  = DebugPort.PrintString("\n\r\tTest WDT...");
        break;
    case CONTEXT_ONE:
        if (TaskScheduler.Get10msecCounter() > ulTimer) {
            // 200 msec passed after enabling WDT. Stop refreshing.
            g_bWdtTestInProgress = TRUE;
            // Setup timer for another 200 msec timeout.
            ulTimer = TaskScheduler.Get10msecCounter() + 20;
            RtnSts = DebugPort.PrintString("stopped refresh...");
        }        
        break;
    case CONTEXT_TWO:
        if (TaskScheduler.Get10msecCounter() > ulTimer) {
            // 200 msec passed after stopping WDT. 
            // WDTOD ISR would have executed by now.
            RtnSts = DebugPort.PrintString("\n\r\tWDTOD in %d.%d msec",
                     g_usWdtTestTimer[0],g_usWdtTestTimer[1]);
        }
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\n\r\tNewRefTime(1-15):");
        break;
    case CONTEXT_FOUR:
        ucNewRefreshRate = 0;
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FIVE:
        ucNewRefreshRate = atoi(s_cInputBuffer);
        if ((ucNewRefreshRate > 0) && (ucNewRefreshRate < 16)) {
            // Wait until the next watchdog tick 
            // and then change the refresh rate.
            while (TaskScheduler.GetWdtRefreshCounter() != 0);
            g_ChangeWdtRefreshTime = ucNewRefreshRate;
        }
        RtnSts = DebugPort.PrintString("\n\r\tWdtRef rate %d0 msec",g_ChangeWdtRefreshTime);
        break;
    }
    if (RETURNSTATUS_COMPLETE == RtnSts) {
        Context = (CONTEXT)((UINT8)Context + 1);
        if (Context > CONTEXT_FIVE) {
            Context = CONTEXT_ZERO; 
            ulTimer = 0;
            return RETURNSTATUS_COMPLETE;
        }
    }
    return RETURNSTATUS_INPROGRESS;
}
#endif

/*******************************************************************************
*                                 TestIolink                                   *
*                                 ==========                                   *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS TestIolink(VOID) {
    const UINT8 TEST_COUNT = 6;
    const UINT8 TEST_BYTES[TEST_COUNT] = { 0xA5,0x5A,0xF0,0x0F,0xFF,0x00 };
    static CONTEXT Context = CONTEXT_ZERO;
    UINT8 ucSaveExr;
    UINT16 usCount;
    RETURNSTATUS   RtnSts  = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        TPU4_CST = 0; // Stop IOL silence timer to stop swap during the test.
        RCVSELA_n = 0;    // Select channel A
        RtnSts = DebugPort.PrintString("\n\r\tTest ChnA...");
        break;
    case CONTEXT_ONE:
        ucSaveExr = get_imask_exr();   // Save current interrupt mask
        set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts
        #if((HEK) && (defined(IOMTYPE_AOH)||defined(IOMTYPE_AIH)))
        if(FALSE == IsFpgaS2) // for S3 FPGA
        {        
            P_SCI2.SCR.BIT.RE  = 1;      // Enable IOL SCI receiver
            P_SCI2.SCR.BIT.TE  = 1;      // Enable IOL SCI transmitter
            TXREQ_n = 0;                 // Enable IOL 485 circuit
            IdleWait(2);
            for (usCount = 0; usCount < TEST_COUNT; usCount++) {
                
                P_SCI2.TDR = TEST_BYTES[usCount];
                P_SCI2.SSR.BIT.TDRE  = 0;         // Transmit test character
                while (P_SCI2.SSR.BIT.TEND == 0); // Wait until charter get transmitted
                if (P_SCI2.SSR.BIT.ORER || P_SCI2.SSR.BIT.FER || P_SCI2.SSR.BIT.PER || (P_SCI2.RDR != TEST_BYTES[usCount])) {
                    // if any error occured or the loopback character does not match
                    // break the for loop so that usCount will be less than TEST_COUNT
                    break;
                }
                P_SCI2.SSR.BIT.RDRF = 0;  // Reset receive data full status
            }
            TXREQ_n = 1;                     // Disable IOL 485 circuit
            P_SCI2.SCR.BIT.TE  = 0;       // Disable IOL SCI transmitter
            P_SCI2.SCR.BIT.RE  = 0;       // Disable IOL SCI receiver
        }
        else //if(TRUE = IsFpgaS2)
        #endif
        {
            IOL_RE  = 1;      // Enable IOL SCI receiver
            IOL_TE  = 1;      // Enable IOL SCI transmitter
            TXREQ_n = 0;      // Enable IOL 485 circuit
            IdleWait(2);
            for (usCount = 0; usCount < TEST_COUNT; usCount++) {
                IOL_TDR = TEST_BYTES[usCount];
                IOL_TDRE  = 0; // Transmit test character
                while (IOL_TEND == 0); // Wait until charter get transmitted
                if (IOL_ORER || IOL_FER || IOL_PER|| (IOL_RDR != TEST_BYTES[usCount])) {
                    // if any error occured or the loopback character does not match
                    // break the for loop so that usCount will be less than TEST_COUNT
                    break;
                }
                IOL_RDRF = 0;  // Reset receive data full status
            }
            TXREQ_n = 1;       // Disable IOL 485 circuit
            IOL_TE  = 0;       // Disable IOL SCI transmitter
            IOL_RE  = 0;       // Disable IOL SCI receiver    
        }
        set_imask_exr(ucSaveExr);  // Restore interrupts
        if (usCount < TEST_COUNT) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_FAILED));
            TPU4_TGRB = CNTLNKSIL;
            TPU4_CST = 1; // Restart IOL silence timer
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }        
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_PASSED));
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_TWO:
        if (0 == RCVSELA_n) {
            RCVSELA_n = 1;  // Select channel B
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tTest ChnB..."));
            Context = CONTEXT_ZERO;
        }
        else {
            RCVSELA_n = 0;  // Reset channel selection to A
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tTest gap timer..."));
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_THREE:
        ucSaveExr = get_imask_exr();   // Save current interrupt mask
        set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts
        #if (!AIAO)
        RDBK_SEL =  RDBK_IOTA;  // Set readback register for reading GHOXXX
        #endif
        
        #if((HEK) && (defined(IOMTYPE_AOH)||defined(IOMTYPE_AIH)))
        if(FALSE == IsFpgaS2) // for S3 FPGA
        {    
            P_SCI2.SCR.BIT.TE = 1;               // Enable IOL SCI transmitter
            TXREQ_n  = 0;                       // Enable IOL 485 circuit
            IdleWait(2);        
            
            P_SCI2.TDR  = TEST_BYTES[0];
            P_SCI2.SSR.BIT.TDRE = 0;               // Transmit a test character            
            while (P_SCI2.SSR.BIT.TEND == 0);      // Wait until charter get transmitted
            
            usCount = TPU5_TCNT;
            while (GHOXXX == GHO_NOTINGAP);
            usCount = TPU5_TCNT - usCount;
            usCount /= TPUCOUNT_IN_MICROSECOND;    // 1 TPU count = 1/6 micro second
            
            // Checking GHOIRQ_n in S3 FPGA HW
            if(P_P6.PORT.BIT.B4 == 0) {
                
                TXREQ_n = 1;                    // Disable IOL 485 circuit
                P_SCI2.SCR.BIT.TE  = 0;         // Disable IOL SCI transmitter
                set_imask_exr(ucSaveExr);        // Restore interrupts
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                "approx %d microsec\n\r\tTest clear GHOIRQ...",usCount));
            }            
            else {
                
                TXREQ_n = 1;                    // Disable IOL 485 circuit
                P_SCI2.SCR.BIT.TE  = 0;         // Disable IOL SCI transmitter
                set_imask_exr(ucSaveExr);         // Restore interrupts
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                "%d micro sec..but no GHOIRQ",usCount));
                Context = CONTEXT_FOUR;            // skip next case statement
            }
        }
        else //if(TRUE = IsFpgaS2)
        #endif
        {                
            IOL_TE   = 1;           // Enable IOL SCI transmitter
            TXREQ_n  = 0;           // Enable IOL 485 circuit
            IdleWait(2);        
            IOL_TDR  = TEST_BYTES[0];
            IOL_TDRE = 0;           // Transmit a test character
            while (IOL_TEND == 0);  // Wait until charter get transmitted
            usCount = TPU5_TCNT;
            while (GHOXXX == GHO_NOTINGAP);
            usCount = TPU5_TCNT - usCount;
            usCount /= TPUCOUNT_IN_MICROSECOND;  // 1 TPU count = 1/6 micro second
        
            if (GHOIRQ_n == 0) {        
                TXREQ_n = 1;            // Disable IOL 485 circuit
                IOL_TE  = 0;            // Disable IOL SCI transmitter
                set_imask_exr(ucSaveExr); // Restore interrupts
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                "approx %d microsec\n\r\tTest clear GHOIRQ...",usCount));
            }
            else {
                TXREQ_n = 1;            // Disable IOL 485 circuit
                IOL_TE  = 0;            // Disable IOL SCI transmitter
                set_imask_exr(ucSaveExr); // Restore interrupts
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
                "%d micro sec..but no GHOIRQ",usCount));
                Context = CONTEXT_FOUR; // skip next case statement
            }
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_FOUR:
        CLRGHL_n = 0;
        CLRGHL_n = 1;
        #if(HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))        
        // Checking GHOIRQ_n on S3 FPGA HW
        if((FALSE == IsFpgaS2) && (P_P6.PORT.BIT.B4 == 0)) {
        
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_FAILED));            
        } // Checking GHOIRQ_n on S2 FPGA HW
        else if ((TRUE == IsFpgaS2) && (GHOIRQ_n == 0))
        #else
        if (GHOIRQ_n == 0) // Checking GHOIRQ_n on other than AIH and AOH modules
        #endif    
        {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_FAILED));
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_PASSED));
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString("\n\r\tTest jabber...");
        break;
    case CONTEXT_SIX:
        ucSaveExr = get_imask_exr();   // Save current interrupt mask
        set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts
        JABRES_n = 0;           // Reset jabber lock
        JABRES_n = 1;           // Arm jabber again
        #if (!AIAO)
        RDBK_SEL =  RDBK_IOTA;  // Set readback register for reading GHOXXX
        #endif
        #if((HEK) && (defined(IOMTYPE_AOH)||defined(IOMTYPE_AIH)))
        if(FALSE == IsFpgaS2)                     // for S3 FPGA
        {    
            P_SCI2.SCR.BIT.TE   = 1;               // Enable IOL SCI transmitter
            TXREQ_n  = 0;                       // Enable IOL 485 circuit
            IdleWait(2);        
            usCount = TPU5_TCNT;
            while (JABLOCK_n == 1) {
                P_SCI2.TDR  = TEST_BYTES[0];
                P_SCI2.SSR.BIT.TDRE = 0;        // Transmit a test character
                while (IOL_TEND == 0);          // Wait until charter get transmitted
            }
            usCount = TPU5_TCNT - usCount;
            usCount /= TPUCOUNT_IN_MICROSECOND; // 1 TPU count = 1/6 micro second
            TXREQ_n = 1;                        // Disable IOL 485 circuit
            P_SCI2.SCR.BIT.TE  = 0;                // Disable IOL SCI transmitter
        }
        else //if(TRUE = IsFpgaS2)
        #endif
        {
            IOL_TE   = 1;           // Enable IOL SCI transmitter
            TXREQ_n  = 0;           // Enable IOL 485 circuit
            IdleWait(2);        
            usCount = TPU5_TCNT;
            while (JABLOCK_n == 1) {
                IOL_TDR  = TEST_BYTES[0];
                IOL_TDRE = 0;           // Transmit a test character
                while (IOL_TEND == 0);  // Wait until charter get transmitted
            }
            usCount = TPU5_TCNT - usCount;
            usCount /= TPUCOUNT_IN_MICROSECOND; // 1 TPU count = 1/6 micro second
            TXREQ_n = 1;            // Disable IOL 485 circuit
            IOL_TE  = 0;            // Disable IOL SCI transmitter
        }        
        set_imask_exr(ucSaveExr);  // Restore interrupts
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("%d micro sec",usCount));
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_SEVEN:
        RtnSts = DebugPort.PrintString("\n\r\tTest jabber lock reset...");
        break;
    case CONTEXT_EIGHT:
        JABRES_n = 0;           // Reset jabber lock
        JABRES_n = 1;           // Arm jabber again
        #if (!AIAO)
        RDBK_SEL =  RDBK_IOTA;  // Set readback register for reading GHOXXX
        #endif
        if (JABLOCK_n == 0) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_FAILED));
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_PASSED));
        }
        TPU4_TGRB = CNTLNKSIL;
        TPU4_CST = 1;           // Restart IOL silence timer
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_EIGHT,Context,RtnSts);
}
/*******************************************************************************
*                                 TestReboot                                   *
*                                 ==========                                   *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS TestReboot(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (sTestRebootContext) {
    case CONTEXT_ZERO:
        strcpy(g_cRebootTestString,"reboot");
        SET_DIP  = 0;
        RebootIom();
        break;
    case CONTEXT_ONE:
        {
            #if !AIAO
            UINT8 ucSaveExr = get_imask_exr();   // Save current interrupt mask.
            set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts.
            RDBK_SEL = RDBK_BANK7;
            #endif
            if (0 == RIP_n) {
                RtnSts = DebugPort.PrintString("\n\r\tReboot test passed");
            }
            else{
                #if !AIAO
                set_imask_exr(ucSaveExr);
                #endif
                return DebugPort.PrintString(
                       "\n\r\tIOM rebooted but, RIP_n did not assert");
            }
            #if !AIAO
            set_imask_exr(ucSaveExr);
            #endif
        }
        break;
    }

    return AdvanceContext(CONTEXT_ONE,sTestRebootContext,RtnSts);
}
/*******************************************************************************
*                                  PrintStat                                   *
*                                  =========                                   *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS PrintStat(VOID) {
#if defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined (IOMTYPE_UIO)
    static UINT8 sucIndex;
#endif

#if defined (IOMTYPE_UIO)
    static FLOAT32 sfAccumulator;
    static UINT32 suMin;
    static UINT32 suMax;
#endif
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        {
            volatile UINT8 *ucpStack = (volatile UINT8 *)(STACK_TOP + 1);
            while (*ucpStack++ == 0xFF);
            UINT32 ulFree = (UINT32)ucpStack - (UINT32)STACK_TOP;
            RtnSts = DebugPort.PrintString("\n\r\tMin Free Stack:%l",ulFree);
            break;
        }
    case CONTEXT_ONE:
        RtnSts = DebugPort.PrintString("\n\r\tMax Stc Latency:%d",
                                       TaskScheduler.uiMaxStcLatency);
        break;
    case CONTEXT_TWO:
        RtnSts = RETURNSTATUS_COMPLETE;
#ifdef IOMTYPE_AIH
        RtnSts = DebugPort.PrintString(
                 "\n\r\tPPX Time Max:%u\n\r\t          Min:%u\n\r\t          Avg:%u",
                 (*(clsAihBoxSlot *)pDatabase[0]).m_ulMaxPpxTime,
                 (*(clsAihBoxSlot *)pDatabase[0]).m_ulMinPpxTime,
                 (*(clsAihBoxSlot *)pDatabase[0]).m_ulAvgPpxTime);
#endif
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        RtnSts = DebugPort.PrintString("\n\r\tMaxStc :I%d D%d",
                           (*(clsDiBoxSlot *)pDatabase[0]).uiMaxIpTime,
                           (*(clsDiBoxSlot *)pDatabase[0]).uiMaxDiagTime);
#endif
#ifdef IOMTYPE_DO
        RtnSts = DebugPort.PrintString("\n\r\tMaxStc :%d",
                           (*(clsDoBoxSlot *)pDatabase[0]).uiMaxStcTime);
#endif
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\n\r\tObjSize Box:%u\n\r\t        Slot:%u",
#ifdef IOMTYPE_AIH
                 sizeof(clsAihBoxSlot),sizeof(clsAihSlot));
        sucIndex = 1;
#endif
#ifdef IOMTYPE_AOH
                 sizeof(clsAohBoxSlot),sizeof(clsAohSlot));
        sucIndex = 1;
#endif
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
                 sizeof(clsDiBoxSlot),sizeof(clsDiSlot));
#endif
#ifdef IOMTYPE_DO
                 sizeof(clsDoBoxSlot),sizeof(clsDoSlot));
#endif
#ifdef IOMTYPE_LLMUX
                 sizeof(clsLLBoxSlot),sizeof(clsLLSlot));
#endif
#ifdef IOMTYPE_PI
                 sizeof(clsPiBoxSlot),sizeof(clsPiSlot));
#endif
#ifdef IOMTYPE_UIO
                 sizeof(clsUioBoxSlot),sizeof(clsUioSlot));
#endif

        break;
    case CONTEXT_FOUR:
        RtnSts = RETURNSTATUS_COMPLETE;
#if defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH)
        if (sucIndex <= MAXSLOTS) {
            if (RETURNSTATUS_COMPLETE == DebugPort.PrintString(
                                "\n\r\tDyn:%6u\tDev:%6u\tC48:%6u",
                                SLOT(sucIndex)->GetHartDevDb().m_ulDynGoodCount,
                                SLOT(sucIndex)->GetHartDevDb().m_ulDevGoodCount,
                                SLOT(sucIndex)->GetHartDevDb().m_ulC48GoodCount)) {
                sucIndex++;
            }
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else {
            RtnSts = RETURNSTATUS_COMPLETE;
        }
#endif
        break;

#if defined (IOMTYPE_UIO)

    case CONTEXT_FIVE:
        s_cInputBuffer[0] = NULL;
        RtnSts = DebugPort.PrintString("\n\n\r\tRun CPU free count test? (y/n) (n) :");
        break;

    case CONTEXT_SIX:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            DebugPort.CancelInput();
            if (('y' == s_cInputBuffer[0]) || ('Y' == s_cInputBuffer[0])) {
                sfAccumulator = 0.0;
                suMin = 0xFFFFFFFF;
                suMax = 0;

                g_ucCpuFreeTestIndex = CPUFREE_TESTCOUNT;
            }
            else {
                g_ucCpuFreeTestIndex = 0;
                Context = CONTEXT_EIGHT;
            }
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        else {
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        break;

    case CONTEXT_SEVEN:
        if (g_ucCpuFreeTestIndex > 0) {
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else {
            sucIndex = CPUFREE_TESTCOUNT;
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;

    case CONTEXT_EIGHT:
        if (sucIndex > 0) {
            RtnSts = DebugPort.PrintString("\n\r\t  %u", g_ulCpuFreeTestCounts[sucIndex]);
            if (RETURNSTATUS_COMPLETE == RtnSts) {
                sfAccumulator += g_ulCpuFreeTestCounts[sucIndex];
                if (g_ulCpuFreeTestCounts[sucIndex] < suMin) { suMin = g_ulCpuFreeTestCounts[sucIndex]; }
                if (g_ulCpuFreeTestCounts[sucIndex] > suMax) { suMax = g_ulCpuFreeTestCounts[sucIndex]; }

                sucIndex--;
            }
        }

        if (0 == sucIndex) {
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        else {
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        break;

    case CONTEXT_NINE:
        RtnSts = DebugPort.PrintString("\n\r\tMax: %u, Min: %u, Avg: %u", suMax, suMin, (UINT32)(sfAccumulator/CPUFREE_TESTCOUNT));
        break;
#endif

    }

#if defined (IOMTYPE_UIO)
    return AdvanceContext(CONTEXT_NINE,Context,RtnSts);
#else
    return AdvanceContext(CONTEXT_FOUR,Context,RtnSts);
#endif
}
#if !(defined(IOMTYPE_DO) || defined(IOMTYPE_DISOE))
/*******************************************************************************
*                                 BackUpRequest                                *
*                                 =============                                *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
 static RETURNSTATUS BackUpRequest(VOID) {
     static CONTEXT Context = CONTEXT_ZERO;
     RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
     static BOOL bResult = FALSE;
     static UINT8 ucSWBUPRQ_n;
     
     switch(Context){
     case CONTEXT_ZERO:
         bResult = FALSE;         
            ucSWBUPRQ_n = SWBUREQ_n;
         SWBUREQ_n   = 0;
         IdleWait(50);
         RtnSts  = DebugPort.PrintString("\n\r\t SWBUREQ_n     BUPREQ_FB(Exp)     BUPREQ_FB(Act)    BUPREQ_IN");        
         break;
     case CONTEXT_ONE:
         if(BUPREQ_FB != 1)
            bResult = TRUE;  
         RtnSts  = DebugPort.PrintString("\n\r\t     0              1                  %d                %d",BUPREQ_FB,BUPREQ_IN);        
         break;
     case CONTEXT_TWO:
         SWBUREQ_n  = 1;
         IdleWait(50); 
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
     case CONTEXT_THREE:
         if(BUPREQ_FB != 0)
            bResult = TRUE;     
         RtnSts  = DebugPort.PrintString("\n\r\t     1              0                  %d                %d",BUPREQ_FB,BUPREQ_IN);
         break;
     case CONTEXT_FOUR:
            SWBUREQ_n = ucSWBUPRQ_n;
         if(bResult)
            RtnSts = DebugPort.PrintString("\n\r\tTest Failed........");
         else
            RtnSts = DebugPort.PrintString("\n\r\tTest Passed........"); 
         break;
     }
 
     return AdvanceContext(CONTEXT_FOUR,Context,RtnSts);
}
/*******************************************************************************
*                                    TestDipSignal                             *
*                                    =============                             *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS TestDipSignal(VOID){
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static UINT8 ucDipValue;
    switch (sTestRebootContext) {
    case CONTEXT_ZERO:
         strcpy(g_cRebootTestString,"testdip");
         RtnSts = DebugPort.PrintString("\n\r\tEnter SET_DIP(0 or 1):");
         break;
    case CONTEXT_ONE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_TWO:
         ucDipValue = atoi(s_cInputBuffer);
         SET_DIP = ucDipValue;
         RebootIom();
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_THREE:
         {
           if (0 == DIP_n) {
               RtnSts = DebugPort.PrintString("\n\r\tDIP test passed");
           }
           else{
               return DebugPort.PrintString(
                    "\n\r\tIOM rebooted but, DIP_n did not assert");
           }
         }  
         break;
        }     
     return AdvanceContext(CONTEXT_THREE,sTestRebootContext,RtnSts);
}
#endif
#ifdef IOMTYPE_DO
/*******************************************************************************
*                                  TestHoldOut                                 *
*                                  ===========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
RETURNSTATUS TestHoldOut(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    UINT32 ulData = 0, ulMask = 1;
    RETURNSTATUS   RtnSts  = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts  = DebugPort.PrintString("\n\r\tOpBitmap 0x:");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ulData = atoh(s_cInputBuffer);
        for (UINT8 ucIndex = 1; ucIndex <= MAXSLOTS; ucIndex++) {
            // Drive output
            BOX->UpdateOutputBuffer2(ucIndex,(ulData & ulMask));
            SLOT(ucIndex)->PostSO(0);
            ulMask <<= 1;
        }
        RtnSts  = DebugPort.PrintString(
                  "\n\r\tCheck LEDs. Reset to continue...\n\r");
        TXREQ_n = IOLDRV_OFF;          // ensure RS-485 transmitter is disabled
        DIAGFAIL_n = 0; // Assert DIAGFAIL to kill the IOM.
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_TWO,Context,RtnSts);
}
#endif
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
/*******************************************************************************
*                                 TestDiInputs                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS TestDiInputs(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT32 sulStatus,sulMask;
    static UINT8 sucCount,sucTestCount;
    CHAR   cBuffer[LARGE_INPUT_BUFFER_SIZE];
    
    switch (Context) {
    case CONTEXT_ZERO:
        sulMask = 1;
        sucCount = 1;
        sucTestCount = 1;
        if (FALSE == g_bStopDiTests) { // if DI tests are running
            sulStatus = ((clsDiBoxSlot *)pDatabase[0])->GetForcedInputDiagStatus();
            RtnSts = DebugPort.PrintString("\n\r\tForced input diag...");
        }
        else {
            Context = CONTEXT_THREE;
            RtnSts = DebugPort.PrintString(PRINTSTRING_STOPPED);
        }
        break;
    case CONTEXT_ONE:
        (sulStatus & sulMask) ? strcpy(cBuffer,PRINTSTRING_FAILED)
                              : strcpy(cBuffer,PRINTSTRING_PASSED);
        RtnSts = (sucCount % 2) ? 
                 DebugPort.PrintString("\n\r\tChan:%02d:%s",sucCount,cBuffer) :
                 DebugPort.PrintString("\tChan:%02d:%s",sucCount,cBuffer);

        if (RETURNSTATUS_COMPLETE == RtnSts)
        {
            if (sucCount < MAXSLOTS)
            {
                sucCount++;
                sulMask <<= 1;
                RtnSts = RETURNSTATUS_INPROGRESS;
                break;
            }
        }
        break;
    case CONTEXT_TWO:
        if (1 == sucTestCount)
        {
            sucTestCount++;
            RtnSts = DebugPort.PrintString("\n\n\r\tPress any key to continue...");
        }
        else
        {
            Context = CONTEXT_THREE;
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case CONTEXT_THREE:
        s_cInputBuffer[0] = NULLCHAR;
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if ((RETURNSTATUS_COMPLETE == RtnSts) || (NULLCHAR != s_cInputBuffer[0]))
        {          
            sulMask = 1;
            sucCount = 1;
            sulStatus = ((clsDiBoxSlot *)pDatabase[0])->OpenWireDiagStatus;
            Context = CONTEXT_ZERO;
            RtnSts = DebugPort.PrintString("\n\n\r\tOpen wire diag...");
        }
        break;
    case CONTEXT_FOUR:
        if (FALSE == g_bStopDiTests) {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTOP);
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTART);
        }
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_SIX:
        if ('y' == s_cInputBuffer[0]) {
            if (FALSE == g_bStopDiTests) {
                g_bStopDiTests = TRUE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STOPPED);
            }
            else {
                g_bStopDiTests = FALSE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STARTED);
            }
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_UNCHANGED);
        }
        break;
    }

    return AdvanceContext(CONTEXT_SIX,Context,RtnSts);
}
#endif
#ifdef IOMTYPE_AIH
/*******************************************************************************
*                                 GetAnalogInputs                              *
*                                 ===============                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS GetAnalogInputs(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 sucChan;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    #if LOWCOST
    static UINT32 ulRawData[16];
    #else
    UINT32 ulA;
    #endif

    switch (Context) {
    case CONTEXT_ZERO:
        #if !LOWCOST
        sucChan = IN_REF0;
        ulA = Adc.GetRawData(sucChan++);
        RtnSts = DebugPort.PrintString("\n\r\tShorted Input : 0x%08X",ulA);
        #else
        sucChan = 1;
        Adc.GetRawData(FALSE,ulRawData,FALSE);
        RtnSts = RETURNSTATUS_COMPLETE;
        #endif
        break;
    case CONTEXT_ONE:
        #if !LOWCOST
        ulA = Adc.GetRawData(sucChan);
        if (sucChan & 0x01) {
            RtnSts = DebugPort.PrintString("\tChannel %2d   : 0x%08X",sucChan,ulA);
        }
        else {
            RtnSts = DebugPort.PrintString("\n\r\tChannel %2d    : 0x%08X",sucChan,ulA);
        }
        #else
        if (sucChan & 0x01) {
            RtnSts = DebugPort.PrintString("\n\r\tChannel %2d    : 0x%08X",sucChan,ulRawData[sucChan-1]);
        }
        else {
            RtnSts = DebugPort.PrintString("\tChannel %2d    : 0x%08X",sucChan,ulRawData[sucChan-1]);
        }
        #endif
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucChan++;
            if (sucChan <= MAXSLOTS) RtnSts = RETURNSTATUS_INPROGRESS;
        }
        break;
    case CONTEXT_TWO:
        #if !LOWCOST
        ulA = Adc.GetRawData(IN_CKVT1);
        RtnSts = DebugPort.PrintString("\tCKVT1        : 0x%08X",ulA);
        #else
        for(int i=0;i<MAXSLOTS;i++){
        ulRawData[i]=0;
        }
        Adc.GetRawData(TRUE,ulRawData,FALSE);
        RtnSts = RETURNSTATUS_COMPLETE;
        #endif
        break;
    case CONTEXT_THREE:
        #if !LOWCOST
        ulA = Adc.GetRawData(IN_CKVT2);
        RtnSts = DebugPort.PrintString("\n\r\tCKVT2         : 0x%08X",ulA);
        #else
        RtnSts = DebugPort.PrintString("\n\r\tOFFSET        : 0x%08X",ulRawData[0]);
        #endif
        break;
    case CONTEXT_FOUR:
        #if !LOWCOST
        ulA = Adc.GetRawData(IN_CKVT3);
        RtnSts = DebugPort.PrintString("\tCKVT3        : 0x%08X",ulA);
        #else
        RtnSts = DebugPort.PrintString("\tVCC          : 0x%08X",ulRawData[2]);      
        #endif
        break;
    case CONTEXT_FIVE:
        #if !LOWCOST
        ulA = Adc.GetRawData(IN_CKVT41);
        RtnSts = DebugPort.PrintString("\n\r\tCKVT41        : 0x%08X",ulA);
        #else
        RtnSts = DebugPort.PrintString("\n\r\tTEMP          : 0x%08X",ulRawData[3]);
        #endif
        break;
    case CONTEXT_SIX:
        #if !LOWCOST
        ulA = Adc.GetRawData(IN_CKVT52);
        RtnSts = DebugPort.PrintString("\tCKVT52       : 0x%08X",ulA);
        #else
        RtnSts = DebugPort.PrintString("\tGAIN         : 0x%08X",ulRawData[4]);
        #endif
        break;
    case CONTEXT_SEVEN:
        #if !LOWCOST
        ulA = Adc.GetRawData(IN_CKVT5);
        RtnSts = DebugPort.PrintString("\n\r\tCKVT5         : 0x%08X",ulA);
        #else
        RtnSts = DebugPort.PrintString("\n\r\tREF           : 0x%08X",ulRawData[5]);
        #endif
        break;
    case CONTEXT_EIGHT:
        #if !LOWCOST
        ulA = Adc.GetRawData(IN_CALIB);
        RtnSts = DebugPort.PrintString("\tCalibrate In : 0x%08X",ulA);
        #else
        RtnSts = RETURNSTATUS_COMPLETE;
        #endif
        break;
    }

    return AdvanceContext(CONTEXT_EIGHT,Context,RtnSts);
}
/*******************************************************************************
*                                 SpinAnalogInput                              *
*                                 ===============                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS SpinAnalogInput(VOID) {
    static UINT8 sucChannel;
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    #if LOWCOST
    UINT32 ulRawCount,ulStatusByte,ulRawData[16];
    INT32 lRawCount;
    UINT8  ucIndex;
    #endif

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucChannel = (UINT8) atoi(s_cInputBuffer);
        }
        break;
    case CONTEXT_TWO:

#if !LOWCOST
        RtnSts = DebugPort.PrintString("\n\r%d",Adc.GetRawData(sucChannel));
#else
        ucIndex = (sucChannel > 16) ? (sucChannel - 17) : (sucChannel - 1);
        Adc.GetRawData((sucChannel > 16), ulRawData,FALSE);
        ulStatusByte = (ulRawData[ucIndex]>>24);
        ulRawCount = ulRawData[ucIndex] & 0x00FFFFE0;
        if (ulRawCount & 0x00800000) ulRawCount += 0xFF000000;
        lRawCount = (INT32) ulRawCount;

        RtnSts = DebugPort.PrintString("\n\r 0x%08X\t%l\t0x%02X",lRawCount,lRawCount,ulStatusByte);
#endif
        break;
    case CONTEXT_THREE:
        s_cInputBuffer[0] = NULLCHAR;
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if ((RETURNSTATUS_COMPLETE != RtnSts) && (NULLCHAR == s_cInputBuffer[0])) {
            Context = CONTEXT_ONE;
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
#if !LOWCOST
/*******************************************************************************
*                                 SyncAnalogInput                              *
*                                 ===============                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS SyncAnalogInput(VOID) {
    UINT8  ucSaveExr;
    UINT16 uiRawData;
    static UINT8 sucChannel;
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        sucChannel = (UINT8) atoi(s_cInputBuffer);
        RtnSts = DebugPort.PrintString("\n\r\tSync Edge 0-Positive 1-Negative :");
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        if (1 == (UINT8) atoi(s_cInputBuffer)) { // Negative edge selected
            g_bFirstState  = 0;
            g_bSecondState = 1;
            RtnSts = DebugPort.PrintString("\n\r\tNegEdge...");
        }
        else {
            g_bFirstState  = 1;
            g_bSecondState = 0;
            RtnSts = DebugPort.PrintString("\n\r\tPosEdge...");
        }
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString("\n\r\tSync time in micro secs (max 20):");
        break;
    case CONTEXT_SIX:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_SEVEN:
        g_usSyncTime = (UINT16) atoi(s_cInputBuffer);
        if (g_usSyncTime > 20) g_usSyncTime = 20;
        g_ucSyncChannel = sucChannel;
        RtnSts = DebugPort.PrintString("\n\r\tSync chan %d time %d",g_ucSyncChannel,g_usSyncTime);
        break;
    case CONTEXT_EIGHT:
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        uiRawData = Adc.GetRawData(g_ucSyncChannel);
        set_imask_exr(ucSaveExr);
        RtnSts = DebugPort.PrintString("\n\r%d",uiRawData);
        break;
    case CONTEXT_NINE:
        s_cInputBuffer[0] = NULLCHAR;
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if ((RETURNSTATUS_COMPLETE != RtnSts) && (NULLCHAR == s_cInputBuffer[0])) {
            DebugPort.CancelInput();
            Context = CONTEXT_SEVEN;
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    }

    return AdvanceContext(CONTEXT_NINE,Context,RtnSts);
}
#endif
/*******************************************************************************
*                                    SpinPvRaw                                 *
*                                    =========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS SpinPvRaw(VOID) {
    static UINT8 sucChannel;
    static UINT16 suiSamples,suiCount,uiZeroCount;
    static CONTEXT Context = CONTEXT_ZERO;
    static FLOAT32 sfAccumulator,sfHiSample,sfLoSample;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    
    FLOAT32 fPvRaw;
    UINT8   ucSaveExr;

#if !LOWCOST
    UINT16  uiRawCount,uiZeroAdjRawCount;
#else
    static INT32  lAccumulator,lHiSample,lLoSample;
    UINT32 ulRawCount,ulStatusByte,ulRawData[16];
    INT32  lRawCount;
    UINT8  ucIndex;
#endif

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucChannel = (UINT8) atoi(s_cInputBuffer);
#if !LOWCOST
            if ((sucChannel < 1) || (sucChannel > MAXSLOTS)) {
#else
            if ((sucChannel < 1) || (sucChannel > 22)) {
#endif
                DebugPort.PrintString(PRINTSTRING_INVALID);
                Context = CONTEXT_ZERO;
                return RETURNSTATUS_COMPLETE;
            }
        }
        break;
    case CONTEXT_TWO:
        suiSamples = 0;
        RtnSts = DebugPort.PrintString(PRINTSTRING_HOWMANY);
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            suiSamples = (UINT16)atoi(s_cInputBuffer);
            suiCount = 0;
            sfHiSample = 0.0;
            sfLoSample = 10.0;
            sfAccumulator = 0.0;
#if LOWCOST
            lHiSample = 0;
            lLoSample = 7864320;
            lAccumulator = 0;
            uiZeroCount = 0;
            ulRawData[1]=0;
#endif
        }
        break;
    case CONTEXT_FOUR:
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_TICK);

        #if !LOWCOST

        uiRawCount = Adc.GetRawData(sucChannel);
        uiZeroCount = Adc.GetRawData(IN_REF0);
        uiZeroAdjRawCount = 0;
        if (uiRawCount > (uiZeroCount + ((clsAihBoxSlot *)pDatabase[0])->GetCalibData()->fChannelZeroDrift[sucChannel - 1])) {
            uiZeroAdjRawCount = uiRawCount - (uiZeroCount + ((clsAihBoxSlot *)pDatabase[0])->GetCalibData()->fChannelZeroDrift[sucChannel - 1]);
        }
        fPvRaw = (uiZeroAdjRawCount * ((clsAihBoxSlot *)pDatabase[0])->GetCalibData()->fCalibrationSlope)
                 + ((clsAihBoxSlot *)pDatabase[0])->GetCalibData()->fCalibrationOffset;

        #else   // LOWCOST

        ucIndex = (sucChannel > 16) ? (sucChannel - 17) : (sucChannel - 1);
        Adc.GetRawData((sucChannel > 16), ulRawData,FALSE);
        ulStatusByte = (ulRawData[ucIndex]>>24);
        ulRawCount = ulRawData[ucIndex] & 0x00FFFFE0;
        if (ulRawCount & 0x00800000) ulRawCount += 0xFF000000;
        lRawCount = (INT32) ulRawCount;
        
        if ((sucChannel >= 1) && (sucChannel <=16)){
        //fPvRaw = (FLOAT32)lRawCount/(FLOAT32)1572864; 
        fPvRaw = ((FLOAT32)lRawCount * ((clsAihBoxSlot *)pDatabase[0])->GetCalibData()->fCalibrationSlope[sucChannel - 1])
                 + ((clsAihBoxSlot *)pDatabase[0])->GetCalibData()->fCalibrationOffset[sucChannel - 1];
        }
        else if ((sucChannel == 19) || (sucChannel == 22))
        fPvRaw = (FLOAT32)lRawCount/(FLOAT32)786432;
        else if (sucChannel == 21)
        fPvRaw = (FLOAT32)lRawCount/(FLOAT32)7864320;
        else
        fPvRaw = (FLOAT32)lRawCount;       

        #endif
        set_imask_exr(ucSaveExr);

        sfAccumulator += fPvRaw;
        if (fPvRaw > sfHiSample) sfHiSample = fPvRaw;
        if (fPvRaw < sfLoSample) sfLoSample = fPvRaw;

        #if LOWCOST
        lAccumulator += lRawCount;
        if (lRawCount > lHiSample) lHiSample = lRawCount;
        if (lRawCount < lLoSample) lLoSample = lRawCount;
        #endif

        #if !LOWCOST
        fPvRaw *= (FLOAT32)1000000;
        RtnSts = DebugPort.PrintString("\n\r\t%d\t%d\t%d\t%f",uiRawCount,uiZeroCount,uiZeroAdjRawCount,fPvRaw);
        #else
        RtnSts = DebugPort.PrintString("\n\r\t%l\t%f\t0x%02X",lRawCount,fPvRaw * 1000000,ulStatusByte);
        #endif
        break;
    case CONTEXT_FIVE:
        if (suiSamples > 0) {
            suiCount++;
            if (suiCount < suiSamples) {
                Context = CONTEXT_THREE;
                RtnSts = RETURNSTATUS_COMPLETE;
            }
            else {
                sfHiSample *= (FLOAT32)1000000;
                sfLoSample *= (FLOAT32)1000000;
#if LOWCOST
                sfAccumulator = (sfAccumulator / (suiCount-uiZeroCount)) * (FLOAT32)1000000;
                lAccumulator = (lAccumulator / (suiCount-uiZeroCount));
                RtnSts = DebugPort.PrintString("\n\n\r\tHiCount: %l LowCount: %l AveCount: %l Samples: %d\n\r\tHiPvRaw: %f LowPvRaw: %f AvePvRaw: %f",
                         lHiSample,lLoSample,lAccumulator,(suiSamples - uiZeroCount),sfHiSample,sfLoSample,sfAccumulator);
#else
                sfAccumulator = (sfAccumulator / suiCount) * (FLOAT32)1000000;
                RtnSts = DebugPort.PrintString("\n\n\r\tHi : %f Lo : %f Ave : %f Samples : %d",
                         sfHiSample,sfLoSample,sfAccumulator,suiSamples);
#endif
            }
        }
        else {
            s_cInputBuffer[0] = NULLCHAR;
            RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
            if ((RETURNSTATUS_COMPLETE != RtnSts) && (NULLCHAR == s_cInputBuffer[0])) {
                Context = CONTEXT_THREE;
            }
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
#if LOWCOST
/*******************************************************************************
*                                    ADCRegWrite                               *
*                                    ===========                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS AdcRegWrite(VOID) {
    static UINT8 sucRegAdd,sucRegData,sucSamples,sucCount;
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    UINT8 ucRegData=0;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tEnter Register Address#:");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucRegAdd = (UINT8) atoi(s_cInputBuffer);
        }
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.PrintString("\n\r\tEnter Register Data#:");
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucRegData = (UINT8) atoi(s_cInputBuffer);
        }
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.PrintString("\n\r\tHow Many Writes to Test#:");
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucSamples = (UINT8) atoi(s_cInputBuffer);
            sucCount = 0;            
        }
        break;
    case CONTEXT_SIX:

        ucRegData = Adc.WriteRegData(sucRegAdd,sucRegData);
        
        if( sucRegData == ucRegData) 
        RtnSts = DebugPort.PrintString("\n\r\t ADC Register Write Success:0x%08X",((UINT16)sucRegData<<8 | ucRegData));
        else
        RtnSts = DebugPort.PrintString("\n\r\t ADC Register Write  Failed:0x%08X",((UINT16)sucRegData<<8 | ucRegData));        
        break;
    case CONTEXT_SEVEN:
        sucCount++;
        if (sucCount < sucSamples) {
            Context = CONTEXT_FIVE;
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        else
            RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }
    return AdvanceContext(CONTEXT_SEVEN,Context,RtnSts);
}
/*******************************************************************************
*                                    ADCRegRead                                *
*                                    ===========                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS AdcRegRead(VOID) {
    static UINT8 sucRegAdd,sucSamples,sucCount;
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    UINT8 ucRegData=0;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tEnter Register Address#:");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucRegAdd = (UINT8) atoi(s_cInputBuffer);
        }
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.PrintString("\n\r\tHow Many Times to read#:");
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (RETURNSTATUS_COMPLETE == RtnSts) {
            sucSamples = (UINT8) atoi(s_cInputBuffer);
            sucCount = 0;            
        }
        break;
    case CONTEXT_FOUR:

        ucRegData = Adc.ReadRegData(sucRegAdd);
        RtnSts = DebugPort.PrintString("\n\r\t ADC Register Read Data:0x%08X",ucRegData);        
        break;
    case CONTEXT_FIVE:
        sucCount++;
        if (sucCount < sucSamples) {
            Context = CONTEXT_THREE;
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        else
            RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }
    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
#endif
#endif
#ifdef IOMTYPE_AOH
/*******************************************************************************
*                                     DriveOp                                  *
*                                     =======                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS DriveOp(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8   sucSlotNo;
    static FLOAT32 sfOp;
    
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        sucSlotNo = (UINT8)atoi(s_cInputBuffer);
        if (sucSlotNo > MAXSLOTS) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = DebugPort.PrintString("\n\r\tOP :"); 
        break; 
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        sfOp = atof(s_cInputBuffer);
        if ((sfOp < EXTENDED_OP_LOLIMIT) || (sfOp > EXTENDED_OP_HILIMIT)) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = RETURNSTATUS_COMPLETE; 
        break;
    case CONTEXT_FIVE:
        if (sucSlotNo > 0) {
            ((clsAohBoxSlot *)pDatabase[0])->SetOp(sucSlotNo,sfOp);
        }
        else {
            for (sucSlotNo = 1; sucSlotNo <= MAXSLOTS; sucSlotNo++) {
                ((clsAohBoxSlot *)pDatabase[0])->SetOp(sucSlotNo,sfOp);
            }
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
/*******************************************************************************
*                                   DriveCount                                 *
*                                   ==========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS DriveCount(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8  sucSlotNo;
    static UINT16 suiDacCount;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        sucSlotNo = (UINT8)atoi(s_cInputBuffer);
        if (sucSlotNo > MAXSLOTS) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = DebugPort.PrintString("\n\r\tDAC Count : 0x"); 
        break; 
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        suiDacCount = (UINT16)atoh(s_cInputBuffer);
        if (suiDacCount > MAXCURRENT_OUTPUT_DACCOUNT) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        if (sucSlotNo > 0) {
            ((clsAohSlot *)pDatabase[sucSlotNo])->SetOutDACImg(suiDacCount);
            AoHardware.DriveOutput(sucSlotNo);
        }
        else {
            for (sucSlotNo = 1; sucSlotNo <= MAXSLOTS; sucSlotNo++) {
                ((clsAohSlot *)pDatabase[sucSlotNo])->SetOutDACImg(suiDacCount);
                AoHardware.DriveOutput(sucSlotNo);
            }
        }
        RtnSts = RETURNSTATUS_COMPLETE; 
        break;
    }

    return AdvanceContext(CONTEXT_FOUR,Context,RtnSts);
}
/*******************************************************************************
*                                ChangeRefresh                                 *
*                                =============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ChangeRefresh(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tState:%d",!g_bStopRefresh);
        break;
    case CONTEXT_ONE:
        if (FALSE == g_bStopRefresh) {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTOP);
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTART);
        }
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_THREE:
        if ('y' == s_cInputBuffer[0]) {
            if (FALSE == g_bStopRefresh) {
                g_bStopRefresh = TRUE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STOPPED);
            }
            else {
                g_bStopRefresh = FALSE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STARTED);
            }
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_UNCHANGED);
        }
        break;
    }

    return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
/*******************************************************************************
*                                  LoopbackTest                                *
*                                  ============                                *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS LoopbackTest(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8  sucSlotNo;
    static UINT16 suiDeltaDacCount;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        sucSlotNo = (UINT8)atoi(s_cInputBuffer);
        if (sucSlotNo > MAXSLOTS) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = DebugPort.PrintString(
        "\n\r\tOtptDacCnt:0x%x\n\r\tLpbkDacCnt:0x%x ",
        ((clsAohSlot *)pDatabase[sucSlotNo])->GetOutDACImg(),
        ((clsAohSlot *)pDatabase[sucSlotNo])->GetLoopBackDACImg()); 
        break; 
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\n\r\tDltaDacCnt:0x");
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FIVE: 
        {
            suiDeltaDacCount = (UINT16)atoh(s_cInputBuffer);
            UINT8 ucSaveExr = get_imask_exr();
            set_imask_exr(LVLPRI_TICK);
            suiDeltaDacCount = ((clsAohSlot *)pDatabase[sucSlotNo])->DoLoopbackTest(suiDeltaDacCount);
            if (AOLPBK_PASSED == suiDeltaDacCount) {
                RtnSts = DebugPort.PrintString(PRINTSTRING_PASSED);
            }
            else if (AOLPBK_HITESTFAIL == suiDeltaDacCount) {
                RtnSts = DebugPort.PrintString("\n\r\tULT failed");
            }
            else if (AOLPBK_LOTESTFAIL == suiDeltaDacCount) {
                RtnSts = DebugPort.PrintString("\n\r\tLLT failed");
            }
            set_imask_exr(ucSaveExr);
        }
        break;
    }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
/*******************************************************************************
*                                GetLoopbackDACCount                           *
*                                ===================                           *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS GetLoopbackDACCount(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8  sucSlotNo;
    static UINT16 LpBkCnt = 0;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        sucSlotNo = (UINT8)atoi(s_cInputBuffer);
        if ((sucSlotNo > sizeof(LOOPBACK_ADDRESS)) || ((sucSlotNo < 1))) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        AoHardware.OpenLoopbackMux(sucSlotNo,TRUE);
        LpBkCnt = ((clsAohBoxSlot *)pDatabase[0])->DoSuccessiveApproximation(TRUE);
        AoHardware.CloseLoopbackMux(sucSlotNo);
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\n\n\r\tMax:0x%x\tMin:0x%x\tAvg:0x%x",
                                        g_usMaxLpbkCount,g_usMinLpbkCount,LpBkCnt);
        break;
    }

    return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
/*******************************************************************************
*                                  RedunSwitchTest                             *
*                                  ===============                             *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS RedunSwitchTest(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    const UINT8  NO_OF_TESTS = 32;
    const UINT16 READ_DELAY_TIME = 250; //250us
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 bIsShortTest = TRUE;
#if !LOWCOST
    static UINT8 CPLDReadFloat[NO_OF_TESTS] = { 0x0F,0x8F,0x6F,0xEF,0x1F,0x9F,0x7F,0xFF,
                                                0x07,0x87,0x67,0xE7,0x03,0x83,0x63,0xE3,
                                                0x0D,0x8D,0x6D,0xED,0x1D,0x9D,0x7D,0xFD,
                                                0x05,0x85,0x65,0xE5,0x01,0x81,0x61,0xE1};
    static UINT8 CPLDReadShort[NO_OF_TESTS] = { 0x0E,0x8E,0x6E,0xEE,0x0E,0x8E,0x6E,0xEE,
                                                0x06,0x86,0x66,0xE6,0x06,0x86,0x66,0xE6,
                                                0x0D,0x8D,0x6D,0xED,0x1D,0x9D,0x7D,0xFD,
                                                0x05,0x85,0x65,0xE5,0x01,0x81,0x61,0xE1};
#else
    static UINT8 CPLDReadFloat[NO_OF_TESTS] = { 0x0F,0x8F,0x4F,0xCF,0x1F,0x9F,0x5F,0xDF,
                                                0x07,0x87,0x47,0xC7,0x03,0x83,0x43,0xC3,
                                                0x0D,0x8D,0x4D,0xCD,0x1D,0x9D,0x5D,0xDD,
                                                0x05,0x85,0x45,0xC5,0x01,0x81,0x41,0xC1};
    static UINT8 CPLDReadShort[NO_OF_TESTS] = { 0x0E,0x8E,0x4E,0xCE,0x0E,0x8E,0x4E,0xCE,
                                                0x06,0x86,0x46,0xC6,0x06,0x86,0x46,0xC6,
                                                0x0D,0x8D,0x4D,0xCD,0x1D,0x9D,0x5D,0xDD,
                                                0x05,0x85,0x45,0xC5,0x01,0x81,0x41,0xC1};
#endif
    static UINT8 Results[NO_OF_TESTS]       = { 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
                                                0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
                                                0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
                                                0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tFloat(0),Short(1):");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        {
            UINT8 ucResult     = 0;
            BOOL  bFailed      = FALSE;
            bIsShortTest = (UINT8)atoi(s_cInputBuffer);
            const UINT8 *pcExpResult = bIsShortTest ? CPLDReadShort : CPLDReadFloat;
            for (UINT8 ucIndex = 0; ucIndex < NO_OF_TESTS; ucIndex++) {
#if !LOWCOST  // TODO: LOWCOST does not have FPGA
                OCWR.FPGABYTEREG = ucIndex;
                IdleWait(READ_DELAY_TIME);
                ucResult = (UINT8)(P_CPLDR02.CPLDRDREG >> BYTESIZE);
#else
             DIS_SWA_n = ((ucIndex & 0x01)?1:0);
             DIS_SWB_n = ((ucIndex & 0x02)?1:0);
             INH_SWA   = ((ucIndex & 0x04)?1:0);
             INH_SWB   = ((ucIndex & 0x08)?1:0);
             TST_n     = ((ucIndex & 0x10)?1:0);
             IdleWait(READ_DELAY_TIME);

             UINT8 ucSwitchStates = SWITCH_STATUS_REGISTER; // Reading switch states from CPLD
             ucResult = 0;
             if(INHIN_FB_n)
                ucResult = ucResult | 0x01;
             if(ucSwitchStates & TST)
                ucResult = ucResult | TST_SET;
             if(ucSwitchStates & INHST1_FB2)
                ucResult = ucResult | INH_SWB2_SET;
             if(ucSwitchStates & INHST1_FB1)
                ucResult = ucResult | INH_SWB1_SET;
             if(ucSwitchStates & INHST2_FB)
                ucResult = ucResult | INH_SWA_SET;
             if(ucSwitchStates & OP_DISB_FB1_n)
                ucResult = ucResult | DIS_SWB1_SET;
             if(ucSwitchStates & OP_DISA_FB_n)
                ucResult = ucResult | DIS_SWA_SET;


#endif
                if(pcExpResult[ucIndex] != ucResult) {
                    Results[ucIndex] = ucResult;
                    bFailed = TRUE;
                }
            }
            if (bFailed) {
                RtnSts = DebugPort.PrintString(PRINTSTRING_FAILED);
            }
            else {
                DebugPort.PrintString(PRINTSTRING_PASSED);
                Context = CONTEXT_ZERO;
                return RETURNSTATUS_COMPLETE;
            }
        }
        break;
    case CONTEXT_THREE:
        {
            static UINT8 ucsIndex = 0;
            RtnSts = RETURNSTATUS_COMPLETE;
            if (0x00 != Results[ucsIndex]) {
                RtnSts = DebugPort.PrintString("\n\r\tWrote:0x%02x Exptd:0x%02x Read:0x%02x",
                                               ucsIndex, bIsShortTest ? CPLDReadShort[ucsIndex]: 
                                                                        CPLDReadFloat[ucsIndex],
                                               Results[ucsIndex]);
            }
            
            // Increment the index only if the PrintString is complete.
            if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == NO_OF_TESTS)) {
                // All the strings are printed now.
                RtnSts = RETURNSTATUS_COMPLETE;
                ucsIndex = 0;
            }
            else {
                RtnSts = RETURNSTATUS_INPROGRESS;
            }
        }
        break;
    }

    return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
#endif //AOH
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_UIO))
/*******************************************************************************
*                                 ToggleSwitch                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ToggleSwitch(VOID){
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucswitchsts;
    switch (Context) {
    case CONTEXT_ZERO:
#if defined(IOMTYPE_AOH)
         RtnSts = DebugPort.PrintString("\n\r\tDsbl(0) Enbl(1):");
#else
         RtnSts = DebugPort.PrintString("\n\r\tOptoFET'S Dsbl(0) Enbl(1):");
#endif
         break;
    case CONTEXT_ONE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_TWO:
         ucswitchsts = (UINT8)atoi(s_cInputBuffer);
         if (ucswitchsts > 1) {
             DebugPort.PrintString(PRINTSTRING_INVALID);
             Context = CONTEXT_ZERO;
             return RETURNSTATUS_COMPLETE;
         }
         if (ucswitchsts) {
#if defined(IOMTYPE_AOH)
             ((clsAohBoxSlot *)pDatabase[0])->EnableOutputs();                
#else
             FPGA.DriveOptoFETs(TRUE);
#endif
             RtnSts = DebugPort.PrintString("\n\r\tEnbld");
         }
         else {
#if defined(IOMTYPE_AOH)
             ((clsAohBoxSlot *)pDatabase[0])->DisableOutputs();                    
#else 
             FPGA.DriveOptoFETs(FALSE);
#endif
             RtnSts = DebugPort.PrintString("\n\r\tDsbld");
         }
         break;
    }

    return AdvanceContext(CONTEXT_TWO,Context,RtnSts);
}
/*******************************************************************************
*                                   WalkDacTest                                *
*                                   ===========                                *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS WalkDacTest(VOID) {
    UINT16 uiCount;
    UINT8 ucSaveExr;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;

    static CONTEXT Context = CONTEXT_ZERO;
    static BOOL   sbPingPong;
    static UINT8  sucSlotNo,sucDirection;
    static UINT16 suiStartCount,suiStopCount,suiRunCount,suiStepCount,suiDwellTime;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tSlt#(0 for all):");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        sucSlotNo = (UINT8)atoi(s_cInputBuffer);
        if (sucSlotNo > MAXSLOTS) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = DebugPort.PrintString("\n\r\tStrtDacCnt(0-4095):"); 
        break; 
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        suiStartCount = (UINT16)atoi(s_cInputBuffer);
        if (suiStartCount > 4095) suiStartCount = 4095;
        RtnSts = DebugPort.PrintString("\n\r\tStopDacCnt(0-4095):");
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_SIX:
        suiStopCount = (UINT16)atoi(s_cInputBuffer);
        if (suiStopCount > 4095) suiStopCount = 4095;
        RtnSts = DebugPort.PrintString("\n\r\tStepDacCnt(1-4095):");
        break;
    case CONTEXT_SEVEN:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_EIGHT:
        suiStepCount = (UINT16)atoi(s_cInputBuffer);
        if (suiStepCount < 1) suiStepCount = 1;
        else if (suiStepCount > 4095) suiStepCount = 4095;
        RtnSts = DebugPort.PrintString("\n\r\tDwellTime(10-10000msec):");
        break;
    case CONTEXT_NINE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TEN:
        suiDwellTime = (UINT16)atoi(s_cInputBuffer);
        if (suiDwellTime < 10) suiDwellTime = 5;
        else if (suiDwellTime > 10000) suiDwellTime = 5000;
        else suiDwellTime /= 2;
        if (suiStartCount > suiStopCount) {
            sucDirection = 0;
            RtnSts = DebugPort.PrintString("\n\n\r\tWalkDn...");
        }
        else {
            sucDirection = 1;
            RtnSts = DebugPort.PrintString("\n\n\r\tWalkUp...");
        }
        suiRunCount = suiStartCount;
        break;
    case CONTEXT_ELEVEN:
        RtnSts = DebugPort.PrintString("\n\r\tStart:%d Stop:%d Step:%d Dwell:%d+%dmsec",
                 suiRunCount,suiStopCount,suiStepCount,suiDwellTime,suiDwellTime);
        break;
    case CONTEXT_TWELVE:
        sbPingPong = FALSE;
        s_cInputBuffer[0] = NULLCHAR;
        RtnSts = DebugPort.PrintString(
        "\n\n\r\tENTER to 1 test; 'p' to ping-pong..anykey stops\n\n\r");
        break;
    case CONTEXT_THIRTEEN:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        if (NULLCHAR != s_cInputBuffer[0]) {
            if ('p' == s_cInputBuffer[0]) {
                sbPingPong = TRUE; 
                s_cInputBuffer[0] = 1;
            }
            if (1 != s_cInputBuffer[0]) Context = CONTEXT_SIXTEEN;
            DebugPort.CancelInput();
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case CONTEXT_FOURTEEN:
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
#if !(LOWCOST || defined(IOMTYPE_UIO))    // TODO
        P_GPR.B15 = 1;
#endif
        if (0 == sucSlotNo) {
            for (uiCount = 1; uiCount <= MAXSLOTS; uiCount++) {
                #if defined(IOMTYPE_AOH)
                    ((clsAohSlot *)pDatabase[uiCount])->SetOutDACImg(suiRunCount);
                    AoHardware.DriveOutput(uiCount);
                #else // UIO
                    FPGA.DriveDAC(uiCount, suiRunCount);
                #endif
            }
        }
        else {
            #if defined(IOMTYPE_AOH)      
                ((clsAohSlot *)pDatabase[sucSlotNo])->SetOutDACImg(suiRunCount);
                AoHardware.DriveOutput(sucSlotNo);
            #else
                FPGA.DriveDAC(sucSlotNo, suiRunCount); 
            #endif
        }
        for (uiCount = 0; uiCount < suiDwellTime; uiCount++) IdleWait(1000);
#if !(LOWCOST || defined(IOMTYPE_UIO))    // TODO
        P_GPR.B15 = 0;
        IdleWait(10);
        P_GPR.B15 = 1;
#endif
        for (uiCount = 0; uiCount < suiDwellTime; uiCount++) IdleWait(1000);
        set_imask_exr(ucSaveExr);
        DebugPort.PrintString(" %d",suiRunCount);
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_FIFTEEN:
        if (suiRunCount != suiStopCount) {
            if (0 == sucDirection) {
                if (suiRunCount <= suiStepCount) {
                    suiRunCount = suiStopCount;
                    Context = CONTEXT_TWELVE;
                    s_cInputBuffer[0] = 1;
                }
                else {
                    suiRunCount -= suiStepCount;
                    if (suiRunCount < suiStopCount) {
                        suiRunCount = suiStopCount;
                    }
                }
                Context = CONTEXT_TWELVE;
                s_cInputBuffer[0] = 1;
            }
            else {
                suiRunCount += suiStepCount;
                if (suiRunCount > suiStopCount) {
                    suiRunCount = suiStopCount;
                }
                Context = CONTEXT_TWELVE;
                s_cInputBuffer[0] = 1;
            }
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_SIXTEEN:
        if (TRUE == sbPingPong) {
            suiRunCount = suiStopCount;
            suiStopCount = suiStartCount;
            suiStartCount = suiRunCount;
            sucDirection = (sucDirection) ? 0 : 1;
            Context = CONTEXT_TWELVE;
            s_cInputBuffer[0] = 1;
        }
        RtnSts = DebugPort.PrintString("\n\r\t-------------\n\r");
        break;
    }

    return AdvanceContext(CONTEXT_SIXTEEN,Context,RtnSts);
}
#endif//AOH 
#ifdef IOMTYPE_LLMUX
/*******************************************************************************
*                                  SendFtaMessage                              *
*                                  ==============                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS SendFtaMessage(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context  = CONTEXT_ZERO;
    static UINT8  sucFtaNum = 0;
    static SCIMESSAGE sucCmd;
    static UINT8 sucRetryCount = 10;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tFta Num :");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        sucFtaNum = (UINT8)atoi(s_cInputBuffer);
        if ((sucFtaNum > NO_OF_FTA) || (sucFtaNum < 1)) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = DebugPort.PrintString("\n\r\tTx      :0x");
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        if (6 != strlen(s_cInputBuffer)) {
            DebugPort.PrintString("\n\r\tInput first 3 bytes");
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        sucCmd.LONG = (atoh(s_cInputBuffer) & 0xFFFFFF00) << BYTESIZE; //Make room for CS
        LLMuxHardware.SendRequest(sucFtaNum-1,sucCmd.LONG);
        sucRetryCount = 10;
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_FIVE: 
        {
            UINT32 Response = 0;
            Response = LLMuxHardware.GetResponse(sucFtaNum-1).LONG;
            if(0 == Response) {
                if(sucRetryCount > 0) {
                    --sucRetryCount;
                    return RETURNSTATUS_INPROGRESS;
                }
                else {
                    DebugPort.PrintString("\n\r\tNo response");
                    Context = CONTEXT_ZERO;
                    return RETURNSTATUS_COMPLETE;
                }
            }
            DebugPort.PrintString("\n\r\tRx      :0x%08X",Response);
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
/*******************************************************************************
*                              ChangeFtaScan                                   *
*                              =============                                   *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ChangeFtaScan(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        if (FALSE == g_bStopFtaScan) {
            RtnSts = DebugPort.PrintString(
            "\n\r\tFTA scan is ON");
        }
        else {
            RtnSts = DebugPort.PrintString(
            "\n\r\tFTA scan is OFF");
        }
        break;
    case CONTEXT_ONE:
        if (FALSE == g_bStopFtaScan) {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTOP);
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTSTART);
        }
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_THREE:
        if ('y' == s_cInputBuffer[0]) {
            if (FALSE == g_bStopFtaScan) {
                g_bStopFtaScan = TRUE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STOPPED);
            }
            else {
                g_bStopFtaScan = FALSE;
                RtnSts = DebugPort.PrintString(PRINTSTRING_STARTED);
            }
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_UNCHANGED);
        }
        break;
    }

    return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
#endif//LL
#if (HEK && !defined(IOMTYPE_PI) && !defined(IOMTYPE_UIO)) 
/*******************************************************************************
*                                    ReadFpga                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ReadFpga(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tAddress\tRegister         Value");  
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.PrintString("\n\r\t=======\t========         =====");
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.PrintString("\n\r\t400060 \tFPGA IRQ Status  0x%02x",
                                       (*(volatile UINT8 *)0x400060));
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\n\r\t400070 \tFPGA Version     0x%04x",
                                       (*(volatile UINT16 *)0x400070));
        break;
    case CONTEXT_FOUR:
        RtnSts = RETURNSTATUS_COMPLETE;
#ifdef IOMTYPE_AIH
        RtnSts = DebugPort.PrintString("\n\r\t400080 \tWiggle Pv        0x%02x",
                                       (*(volatile UINT16 *)0x400080));
#endif
#ifdef IOMTYPE_AOH
#if !LOWCOST
        RtnSts = DebugPort.PrintString("\n\r\t400080 \tOutput Control   0x%02x",OCWR.FPGABYTEREG);
#endif
#endif
        break;
    case CONTEXT_FIVE:
        RtnSts = RETURNSTATUS_COMPLETE;
#ifdef IOMTYPE_AOH
        RtnSts = DebugPort.PrintString("\n\r\t400090 \tOutput Mux       0x%02x",OUTSEL);
#endif
        break;
    case CONTEXT_SIX:
        RtnSts = RETURNSTATUS_COMPLETE;
#ifdef IOMTYPE_AIH
        RtnSts = DebugPort.PrintString("\n\r\t4000A0 \tChan Select Mux  0x%02x",INPSEL);
#endif
#ifdef IOMTYPE_AOH
        RtnSts = DebugPort.PrintString("\n\r\t4000A0 \tReadback Mux     0x%02x",INPSEL);
#endif
        break;
    case CONTEXT_SEVEN:
        RtnSts = DebugPort.PrintString("\n\r\t4000B0 \tIntr Global Enbl 0x%02x",DAC_SPI.IGER);
        break;
    case CONTEXT_EIGHT:
        RtnSts = DebugPort.PrintString("\n\r\t4000B1 \tIntr Register    0x%02x",DAC_SPI.IR);
        break;
    case CONTEXT_NINE:
        RtnSts = DebugPort.PrintString("\n\r\t4000B2 \tIntr Enbl        0x%02x",DAC_SPI.IER);
        break;
    case CONTEXT_TEN:
        RtnSts = DebugPort.PrintString("\n\r\t4000B3 \tCtrl Reg Low     0x%02x",DAC_SPI.CRL);
        break;
    case CONTEXT_ELEVEN:
        RtnSts = DebugPort.PrintString("\n\r\t4000B4 \tCtrl Reg High    0x%02x",DAC_SPI.CRH);
        break;
    case CONTEXT_TWELVE:
        RtnSts = DebugPort.PrintString("\n\r\t4000B5 \tStatus Register  0x%02x",DAC_SPI.SR);
        break;
    case CONTEXT_THIRTEEN:
        RtnSts = DebugPort.PrintString("\n\r\t4000B6 \tTX FIFO not read\n\r\t4000B7 \tRX FIFO not read");
        break;
    case CONTEXT_FOURTEEN:
        RtnSts = DebugPort.PrintString("\n\r\t4000B8 \tSlave Select     0x%02x",DAC_SPI.SSR);
        break;
    }

    return AdvanceContext(CONTEXT_FOURTEEN,Context,RtnSts);
}
/*******************************************************************************
*                                  ReadHEKCpld                                 *
*                                  ===========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ReadHEKCpld(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tAddress\tRegister\t\tValue\tUnused");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.PrintString("\n\r\t=======\t========\t\t=====\t======");
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80000\tModule Number\t\t0x%02x\t0x%02x(0x80001)",
                MODNUM,*((UINT8 *)0x80001));
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80002\tSwitch Status\t\t0x%02x\t0x%02x(0x80003)",
                (UINT8)(P_CPLDR02.CPLDRDREG >> BYTESIZE),*((UINT8 *)0x80003));
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80004\tIOL/IOTA Status\t\t0x%02x\t0x%02x(0x80005)",
                (UINT8)(P_CPLDR04.CPLDRDREG >> BYTESIZE),*((UINT8 *)0x80005));
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80006\tMisc Register\t\t0x%02x\t0x%02x(0x80007)",
                (UINT8)(P_CPLDR06.CPLDRDREG >> BYTESIZE),*((UINT8 *)0x80007));
        break;
    case CONTEXT_SIX:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80008\tCPLD Revision\t\t0x%02x%02x",CPLD_REVLETTER,CPLD_REVNUMBER);
        break;
    case CONTEXT_SEVEN:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80010\tHART Mux Address\t0x%04x",HART_MUXADDR);
        break;
    case CONTEXT_EIGHT:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80012\tHART Mux Enable\t\t0x%04x",HART_MUXENBL.ALL_FOUR);
        break;
    case CONTEXT_NINE:
        RtnSts = DebugPort.PrintString(
                "\n\r\t0x80014\tGeneral Purpose\t\t0x%04x\n\r\t\tEEPROM_WP(B10):%d DIP(B9):%d RIP(B8):%d",
                P_GPR,P_GPR.B10,P_GPR.B9,P_GPR.B8);
        break;
    }

    return AdvanceContext(CONTEXT_NINE,Context,RtnSts);
}
/*******************************************************************************
*                                TestPrivatePath                               *
*                                ===============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
*******************************************************************************/
static RETURNSTATUS TestPrivatePath(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 sucIndex = 0;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        g_bTppInProgress = TRUE;
        if (BOX->GetDSA() == 0) {
            // if this module is secondary nothing to do
            // other than setting the test flag. 
            return RETURNSTATUS_COMPLETE;
        }
        sucIndex = 0;
        UART_LITE.ENABLE_INTR = 0; // Disable UART lite interrupt while transmitting
        RtnSts = DebugPort.PrintString("\n\r\tTestString:");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        while (NULL != s_cInputBuffer[sucIndex]) {
            if (0 == UART_LITE.TX_FIFO_FULL) { // if TX_FIFO is not full
                UART_LITE.TXD = s_cInputBuffer[sucIndex++];
            }
            else {
                return RETURNSTATUS_INPROGRESS;
            }
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_THREE:
        if (0 == UART_LITE.TX_FIFO_FULL) {
            UART_LITE.TXD = NULL;
            while (UART_LITE.TX_FIFO_EMPTY == 0);
            sucIndex = 0;
            UART_LITE.ENABLE_INTR = 1;
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    }

    return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
#ifndef IOMTYPE_LLMUX
/*******************************************************************************
*                                HartModemStatus                               *
*                                ===============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
RETURNSTATUS HartModemStatus(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    UINT8 ucModem = 0;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tSts:%d:%d:%d:%d\n\r\tChange(1-4):",
            pHartModem[0]->m_ModemState,pHartModem[1]->m_ModemState,
            pHartModem[2]->m_ModemState,pHartModem[3]->m_ModemState);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ucModem = (UINT8)atoi(s_cInputBuffer);
        if ((ucModem > 0) && (ucModem <= HARTMODEM_COUNT)) {
            ucModem--;
            if (HMODEMSTATE_BAD == pHartModem[ucModem]->m_ModemState) {
                pHartModem[ucModem]->m_ModemState = HMODEMSTATE_IDLE;
            }
            else {
                if (pHartModem[ucModem]->m_ucConnectedChannel > 0) {
                    // If connected to channel, wait for the end of current session.
                    return RETURNSTATUS_INPROGRESS;
                }
                pHartModem[ucModem]->m_ModemState = HMODEMSTATE_BAD;
            }
        }
        RtnSts = DebugPort.PrintString("\n\r\tSts:%d:%d:%d:%d",
            pHartModem[0]->m_ModemState,pHartModem[1]->m_ModemState,
            pHartModem[2]->m_ModemState,pHartModem[3]->m_ModemState);
        break;
    }

    return AdvanceContext(CONTEXT_TWO,Context,RtnSts);   
}
#endif
#endif // HEK
/*******************************************************************************
*                                   KillIom                                    *
*                                   =======                                    *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS KillIom(VOID) {
    UINT8 ucInput = 0;
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tWdt(1)Dgfl(2):");
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ucInput = (UINT8)atoi(s_cInputBuffer);
        if (1 == ucInput) {
            TaskScheduler.EnableWatchdog();
            set_imask_exr(LVLPRI_HIGHEST);
            while (TRUE);
        }
        else if (2 == ucInput) {
            TXREQ_n = IOLDRV_OFF;      // ensure RS-485 transmitter is disabled
            DIAGFAIL_n = 0;
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_TWO,Context,RtnSts);
}
/*******************************************************************************
*                                  MemoryTest                                  *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS MemoryTest(VOID) {
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_XTOCANCEL);
        break;
    case CONTEXT_ONE:
        if ((RETURNSTATUS_COMPLETE == DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE)) &&
            ('x' == s_cInputBuffer[0])) {
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        else {
            RAMContentsDiagRoutine();
            DebugPort.PrintString("\rTestLoc:0x%X",g_ulTestLocation);
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        break;
    }

    return AdvanceContext(CONTEXT_ONE,Context,RtnSts);
}
/*******************************************************************************
*                                 PrintVersion                                 *
*                                 ============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS PrintVersion(VOID) {
    CHAR cRev;
    static CONTEXT Context = CONTEXT_ZERO;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tFW:%d.%03d.%03d",
                 VERSION_NUMBER,REVISION_NUMBER,BUILD_NUMBER);
        break;
    case CONTEXT_ONE:
        cRev = ((clsBoxSlot *)pDatabase[0])->GetHardwareInfo()->HwRevLetter;
        if ((cRev > 0 ) && (cRev < 27)) cRev += ('A' - 1);
        else cRev = ' ';
        RtnSts = DebugPort.PrintString("\n\r\tHW:%c.%02d",cRev,
                 ((clsBoxSlot *)pDatabase[0])->GetHardwareInfo()->HwRevNumber);
        break;
    case CONTEXT_TWO:
        RtnSts = RETURNSTATUS_COMPLETE;
#ifdef IOMTYPE_AIH
        if (BOARDTYPE_PASSONE == ((clsAihBoxSlot *)pDatabase[0])->GetBoardType()) {
            RtnSts = DebugPort.PrintString(" (Pass1)");
        }
        else RtnSts = DebugPort.PrintString(" (Pass2)");
#endif
        break;
    case CONTEXT_THREE:
        cRev = ((clsBoxSlot *)pDatabase[0])->GetHardwareInfo()->Pld1RevLetter;
        if ((cRev > 0 ) && (cRev < 27)) cRev += ('A' - 1);
        else cRev = ' ';
        RtnSts = DebugPort.PrintString("\n\r\tCPLD1:%c.%02d",cRev,
                 ((clsBoxSlot *)pDatabase[0])->GetHardwareInfo()->Pld1RevNumber);
        break;
    case CONTEXT_FOUR:
        cRev = ((clsBoxSlot *)pDatabase[0])->GetHardwareInfo()->Pld2RevLetter;
        if ((cRev > 0 ) && (cRev < 27)) cRev += ('A' - 1);
        else cRev = ' ';
        RtnSts = DebugPort.PrintString("\n\r\tCPLD2/FPGA:%c.%02d",cRev,
                 ((clsBoxSlot *)pDatabase[0])->GetHardwareInfo()->Pld2RevNumber);
        break;
    }

    return AdvanceContext(CONTEXT_FOUR,Context,RtnSts);
}
#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)) && HEK && (!defined(IOMTYPE_PI))
/*******************************************************************************
*                                  ReadEEPROM                                  *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ReadEEPROM(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucColumn;
    static UINT32 ulAddress;
    static UINT16 uiReadCount;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTADDR);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ulAddress = 0;
        ulAddress = atoh(s_cInputBuffer);
        if (ulAddress > EEPROM_ADDR_RANGE_END) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        else {
          RtnSts = DebugPort.PrintString(PRINTSTRING_HOWMANY);
        }
        break;
    case CONTEXT_THREE:
        uiReadCount = 0;
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        uiReadCount = atoi(s_cInputBuffer);
        break;
    case CONTEXT_FOUR:
        if (uiReadCount > 0) {
            RtnSts = DebugPort.PrintString("\n\r 0x%08X\t",ulAddress);
            ucColumn = BYTESIZE;
        }
        else {
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case CONTEXT_FIVE:
        DebugPort.PrintString(" 0x%02x",Eeprom.ReadByte(ulAddress));
        if ((uiReadCount > 0) && (ulAddress < ADDRESS_RANGE_END)) {
            ulAddress += sizeof(UINT8);
        }
        if (uiReadCount > 0) {
            uiReadCount--;
            if (0 == uiReadCount) {
                RtnSts = RETURNSTATUS_COMPLETE;
            }
            else {
                if (ucColumn > 0) {
                    ucColumn--;
                }
                else {
                    Context = CONTEXT_FOUR;
                }
                RtnSts = RETURNSTATUS_INPROGRESS;
            }
        }
        else {
          RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
/*******************************************************************************
*                                  WriteEEPROM                                 *
*                                  ==========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS WriteEEPROM(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT32 ulAddress,ulData;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTADDR);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ulAddress = 0;
        ulAddress = atoh(s_cInputBuffer);
        if (ulAddress > EEPROM_ADDR_RANGE_END) {
            RtnSts = DebugPort.PrintString("\n\r\tInvalid");
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        else {
            RtnSts = DebugPort.PrintString("\n\r\tAddr 0x%08X Data ",ulAddress);
        }
        break;
      case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("0x%02x-New:0x",Eeprom.ReadByte(ulAddress));
        break;
      case CONTEXT_FOUR:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;
      case CONTEXT_FIVE:
        ulData = atoh(s_cInputBuffer);
        RtnSts = DebugPort.PrintString("\n\r");
        break;
      case CONTEXT_SIX:
        Eeprom.EnableWrite();
        Eeprom.WriteByte(ulAddress,(UINT8)ulData);
        Eeprom.CheckWriteInProgress();        
        Eeprom.DisableWrite();
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_SIX, Context, RtnSts);
}
#endif
// PMIO Redesign related debug functions
#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG)
static RETURNSTATUS PrintDPA(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

#if !AIAO
    // Save readback select registers
    UINT8 ucRdBkSel = RDBK_SEL;
    RDBK_SEL = RDBK_MODNUM;
#endif // !AIAO    

    switch (Context) {

    case CONTEXT_ZERO:
#if !AIAO        
        RtnSts = DebugPort.PrintString("\r\nMODNUM: 0x%02x\r\nRDBK  : 0x%02x", MODNUM, (RDBK_SEL & 0x07));
#else
        RtnSts = DebugPort.PrintString("\r\nMODNUM: 0x%02x", MODNUM);
#endif        
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.PrintString("\r\nFILE  : 0x%02x", ((MODNUM & 0x70) >> 4) + 1);
        break;
    case CONTEXT_TWO:      
        RtnSts = DebugPort.PrintString("\r\nPARITY: %s", isOddParity(MODNUM >> 4) ? "OK" : "FAIL");
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\r\nSLOT  : 0x%02x", (MODNUM & 0x0F) + 1);
        break;  
    case CONTEXT_FOUR:        
        RtnSts = DebugPort.PrintString("\r\nDPA   : 0x%02x", BOX->GetDPA());
        break;   
    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString("\r\nDSA   : 0x%02x", BOX->GetDSA());
        break;
    case CONTEXT_SIX:
        RtnSts = DebugPort.PrintString("\r\nBA    : 0x%02x", BOX->GetBA());
        break;
    }    
#if !AIAO            
    RDBK_SEL = ucRdBkSel; // Restore readback select register
#endif

    return AdvanceContext(CONTEXT_SIX, Context, RtnSts);
}
static RETURNSTATUS GetDump(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT16 uiWriteCount = 0;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\r\n");
        break;
    case CONTEXT_ONE:
        if (ucDbgCnt)
        {
            RtnSts = DebugPort.PrintString("%02x ", ucDumpBuff[uiWriteCount]);
        }
        else RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_TWO:
        uiWriteCount++;
        if (uiWriteCount < ucDbgCnt) {
            Context = CONTEXT_ONE;
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else {
            RtnSts = RETURNSTATUS_COMPLETE;
            uiWriteCount = 0;
            ucDbgCnt = 0;
        }
        break;
    }

    return AdvanceContext(CONTEXT_TWO, Context, RtnSts);
}
static RETURNSTATUS PrintSignals(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

#if !AIAO
    // Save readback select registers
    UINT8 ucRdBkSel = RDBK_SEL;
    RDBK_SEL = RDBK_IOTA;
#endif // !AIAO 

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\r\nREDUNT_n(%d): FTA %s", REDUNT_n, (BOX->GetFtaPres()) ? "PRESENT" : "MISSING");
        break;
    case CONTEXT_ONE:       
        RtnSts = DebugPort.PrintString("\r\nBOTTOM(%d)  : IOP%s",  BOTTOM,   (BOX->GetIotaPos()) ? "A"       : "B");
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.PrintString("\r\nPRI/SEC(%d) : %s", Iol.AmPrimary(),(Iol.AmPrimary()) ? "PRIAMRY" : "SECONDARY");
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\r\nFACTORY MODE: %s", (BOX->CheckForFactoryTestMode())  ? "YES"     : "NOT");
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.PrintString("\r\nSWBUREQ_n(%d)", SWBUREQ_n);
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString("\r\nBUPREQ_IN(%d)", BUPREQ_IN);
        break;
    case CONTEXT_SIX:
        RtnSts = DebugPort.PrintString("\r\nMODSTAT1(0x%02x)", BOX->GetModStat1());
        break;
    case CONTEXT_SEVEN:
        RtnSts = DebugPort.PrintString("\r\nMODSTAT2(0x%02x)", BOX->GetModStat2());
        break;
    case CONTEXT_EIGHT:
        RtnSts = DebugPort.PrintString("\r\nMODSTAT3(0x%02x)", BOX->GetModStat3());
        break;
#if defined(IOPTYPE_AO16) || defined(IOPTYPE_HLAI)
    case CONTEXT_NINE:        
        RtnSts = DebugPort.PrintString("\r\nFACTCAL(%d) : FACT CALIB %s", FACTCAL, (FACTCAL == ASSERTED) ? "DISABLED" : "ENABLED");
        break;
    case CONTEXT_TEN:
        RtnSts = DebugPort.PrintString("\r\nCALIBRATE(%d)", CALIBRATE);
        break;
#else
    case CONTEXT_NINE:
        RtnSts = DebugPort.PrintString("\r\nRDBK(0x%02x)", (RDBK_SEL & 0x07));
        break;
#if defined(DIGTYPE_DO16)
    case CONTEXT_TEN:
        RtnSts = DebugPort.PrintString("\r\nSTBYMAN_N(%d)", STDBYMN_PIN);
        break;
#endif
#endif
#if defined(IOPTYPE_AO16)
    case CONTEXT_ELEVEN:
        RtnSts = DebugPort.PrintString("\r\nINHIN_FB_n(%d)", INHIN_FB_n);
        break;
    case CONTEXT_TWELVE:
        RtnSts = DebugPort.PrintString("\r\nINH_SWA(%d)", INH_SWA);
        break;
    case CONTEXT_THIRTEEN:
        RtnSts = DebugPort.PrintString("\r\nINH_SWB(%d)", INH_SWB);
        break;
    case CONTEXT_FOURTEEN:
        RtnSts = DebugPort.PrintString("\r\nDIS_SWA_n(%d)", DIS_SWA_n);
        break;
    case CONTEXT_FIFTEEN:
        RtnSts = DebugPort.PrintString("\r\nDIS_SWB_n(%d)", DIS_SWB_n);
        break;
    case CONTEXT_SIXTEEN:
        RtnSts = DebugPort.PrintString("\r\nFTA STATUS(%d)", FtaStatus());
        break;
    case CONTEXT_SEVENTEEN:
        RtnSts = DebugPort.PrintString("\r\nLSF(%d) LRS(%d) CNT(%d)", BOX->GetLastSfCode(), BOX->GetSfCodeLrs(), BOX->GetucOutputFailCounter());
        break;
#elif defined(IOPTYPE_DO)
    case CONTEXT_ELEVEN:
        RtnSts = DebugPort.PrintString("\r\nINHINX_n(%d)", INHINX_n);
        break;
    case CONTEXT_TWELVE:
        RtnSts = DebugPort.PrintString("\r\nINH_SW1(%d)", INH_SW1);
        break;
    case CONTEXT_THIRTEEN:
        RtnSts = DebugPort.PrintString("\r\nINH_SW2(%d)", INH_SW2);
        break;
    case CONTEXT_FOURTEEN:
        RtnSts = DebugPort.PrintString("\r\nEN_SW(%d)", EN_SW);
        break;
    case CONTEXT_FIFTEEN:
        RtnSts = DebugPort.PrintString("\r\nTST_SW(%d)", TST_SW);
        break;
    case CONTEXT_SIXTEEN:
#if defined(DIGTYPE_DO32)
        RtnSts = DebugPort.PrintString("\r\nINHSW_STATUS(0x%02x)", BOX->InhibitSwitchStatus());
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
        break;
    case CONTEXT_SEVENTEEN:
        RtnSts = DebugPort.PrintString("\r\nFTA STATUS(%d)", FtaStatus());
        break;
#endif
    default:
        RtnSts = RETURNSTATUS_COMPLETE;
        break;    
    }

#if !AIAO            
    RDBK_SEL = ucRdBkSel; // Restore readback select register
#endif

    return AdvanceContext(CONTEXT_SEVENTEEN, Context, RtnSts);
}
static RETURNSTATUS ReadxRAM(VOID) {
    
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucColumn;
    static UINT32 ulAddress;
    static UINT16 uiReadCount;
    UINT8 ucByte;

    switch (Context) 
    {
        case CONTEXT_ZERO:  RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTADDR); 
            break;

        case CONTEXT_ONE:   RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);    
            break;

        case CONTEXT_TWO:   if ((ulAddress = atoh(s_cInputBuffer)) > xRAM_ADDR_END)
                            {
                                DebugPort.PrintString(PRINTSTRING_INVALID);
                                Context = CONTEXT_ZERO;
                                return RETURNSTATUS_COMPLETE;
                            }
                            else RtnSts = DebugPort.PrintString(PRINTSTRING_HOWMANY);                            
            break;

        case CONTEXT_THREE: RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);                            
                            uiReadCount = atoi(s_cInputBuffer);
            break;          

        case CONTEXT_FOUR:  if (uiReadCount > 0)
                            {
                                RtnSts = DebugPort.PrintString("\r\n 0x%08X\t",ulAddress);
                                ucColumn = BYTESIZE;
                            }
                            else RtnSts = RETURNSTATUS_COMPLETE;
            break;

        case CONTEXT_FIVE:  xRamRead(ulAddress, &ucByte, 1);

                            DebugPort.PrintString(" %02x", ucByte);

                            if ((--uiReadCount > 0) && (++ulAddress < xRAM_SIZE)) 
                            {                                 
                                 if (--ucColumn == 0)
                                     Context = CONTEXT_FOUR;

                                 RtnSts = RETURNSTATUS_INPROGRESS;
                            }
                            else RtnSts = RETURNSTATUS_COMPLETE;                            
            break;
    }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
static RETURNSTATUS WritexRAM(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT32 ulAddress;
    static UINT8 ucData;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTADDR);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ulAddress = 0;
        ulAddress = atoh(s_cInputBuffer);
        if (ulAddress > xRAM_ADDR_END) {
            RtnSts = DebugPort.PrintString("\r\n\tInvalid");
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        else {
            RtnSts = DebugPort.PrintString("\r\n\tAddr 0x%08X Data ", ulAddress);
        }
        break;
    case CONTEXT_THREE:
        xRamRead(ulAddress, &ucData, 1);
        RtnSts = DebugPort.PrintString("0x%02x-New:0x", ucData);
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FIVE:
        ucData = atoh(s_cInputBuffer);
        RtnSts = DebugPort.PrintString("\r\n");
        break;
    case CONTEXT_SIX:
        xRamWrite(ulAddress, &ucData, 1);

        if (ulAddress == 0x5000)
        {
            ucDbgPnt = ucData;            
            ucDbgCnt = 0;
        }
        else if (ulAddress == 0x5001)
        {
            uiDbgPnt1 = ucData;
        }
        else if (ulAddress == 0x5002)
        {
            uiDbgPnt2 = ucData;
        }
        
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_SIX, Context, RtnSts);
}
static RETURNSTATUS FillxRAM(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT32 ulAddress;
    static UINT16 uiWriteCount;    
    static UINT8  ucByte[4];
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_PROMPTADDR);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ulAddress = 0;
        ulAddress = atoh(s_cInputBuffer);
        if (ulAddress > xRAM_ADDR_END) {
            RtnSts = DebugPort.PrintString("\r\n\tInvalid");
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_HOWMANY);
        }
        break;
    case CONTEXT_THREE:
        uiWriteCount = 0;
        RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
        uiWriteCount = atoi(s_cInputBuffer);
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.PrintString("\r\n\tFill with:");
        break;
    case CONTEXT_FIVE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_SIX:
        ucByte[0] = atoh(s_cInputBuffer);
        switch (uiWriteCount)
        {        
        case 4:            
            ucByte[3] = ucByte[0] + 3;
            ucByte[2] = ucByte[0] + 2;
        case 2:
            ucByte[1] = ucByte[0] + 1;
            xRamWrite(ulAddress, &ucByte[0], uiWriteCount);
            Context = CONTEXT_EIGHT;
            RtnSts = RETURNSTATUS_COMPLETE;
            break;
        default:
            RtnSts = DebugPort.PrintString("\r\nWait to complete");
            break;
        }                        
        break;
    case CONTEXT_SEVEN:        
        xRamWrite(ulAddress, &ucByte[0], 1);
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_EIGHT:
        if ((uiWriteCount > 0) && (ulAddress < ADDRESS_RANGE_END)) {
            ulAddress += sizeof(UINT8);
        }
        if (uiWriteCount > 0) {
            uiWriteCount--;            
            if (0 == uiWriteCount) {
                RtnSts = RETURNSTATUS_COMPLETE;
            }
            else {         
                Context = CONTEXT_SEVEN;
                RtnSts = RETURNSTATUS_INPROGRESS;
            }
        }
        else {
            RtnSts = RETURNSTATUS_COMPLETE;
        }        
        break;
    }

    return AdvanceContext(CONTEXT_EIGHT, Context, RtnSts);
}
static RETURNSTATUS GetFails(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;   
    static UINT8 ucCount = 0;

    switch (Context) {    
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\r\nBOX SFAIL: ");
        break;
    case CONTEXT_ONE:
        if (ucCount < SFBYTES_SIZE)
        {
            RtnSts = DebugPort.PrintString("%02x ", BOX->GetBoxSfByte(ucCount++));            
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else {            
            ucCount = 0;
            RtnSts = RETURNSTATUS_COMPLETE;
        }        
        break;
    case CONTEXT_TWO:
        RtnSts = DebugPort.PrintString("\r\nSLOT SFAIL: ");
        break;
    case CONTEXT_THREE:
        if (ucCount < MAXSLOTS)
        {
            RtnSts = DebugPort.PrintString("%02x ", SLOT(ucCount++)->GetSlotSfBt());            
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else
        {
            ucCount = 0;
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case CONTEXT_FOUR:
        RtnSts = DebugPort.PrintString("\r\nDBG BUFF: ");
        ucCount = 0;
        break;
    case CONTEXT_FIVE:
        if (ucCount < ucDbgCnt)
        {
            RtnSts = DebugPort.PrintString("%02x-%02x ", ucDumpBuff[ucCount], ucDumpBuff[ucCount+1]);
            ucCount+=2;
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else
        {            
            ucCount = 0;
            RtnSts = DebugPort.PrintString("\r\nDBG CNT: %d", ucDbgCnt);
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    }

    return AdvanceContext(CONTEXT_FIVE, Context, RtnSts);
}
RETURNSTATUS GetPgrp(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucSlotNumber=0;
    static UINT8 *pData=0;
    static UINT8 *ParamPtr=0;
    static UINT8 ucParamSize=0;
    static UINT16  ulChecksum = 0;

#define LastContext CONTEXT_NINE

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;
    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_TWO:
        ucSlotNumber = (UINT8)atoi(s_cInputBuffer);
        if (ucSlotNumber > ((clsBoxSlot *)pDatabase[0])->GetMaxSlots()) {
            RtnSts = DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = LastContext;
        }
        else {
            RtnSts = DebugPort.PrintString(PRINTSTRING_PARAMNUMBER);
        }
        break;
    case CONTEXT_THREE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
        break;
    case CONTEXT_FOUR:
        // RED(C/c) - Redundant params
        if (('R' == s_cInputBuffer[0]) && ('D' == s_cInputBuffer[2])) {
            pData = (UINT8 *)pDatabase[ucSlotNumber]->GetRedParamsPtr();
        }
        // DMP(C/c) - dump parameters
        else if (('D' == s_cInputBuffer[0]) && ('P' == s_cInputBuffer[2])) {
            pData = (UINT8 *)pDatabase[ucSlotNumber]->GetPmioDumpParamPtr();
        }
#if defined(HART_SUPPORT)
        // HRT(C/c) - HART dump parameters
        else if (('H' == s_cInputBuffer[0]) && ('T' == s_cInputBuffer[2])) {
            if (ucSlotNumber > 0) {
                pData = (UINT8 *)pDatabase[ucSlotNumber]->GetPmioHartDumpParamPtr();
            }
            else {
                Context = LastContext;
            }
        }
#endif
        //CPT(C/c) - Checkpoint parameters
        else if (('C' == s_cInputBuffer[0]) && ('T' == s_cInputBuffer[2])) {
            if (ucSlotNumber == 0) {
                pData = (UINT8 *)pDatabase[ucSlotNumber]->GetCheckPointPtr(LATEST_BOXCHKPNT_VERSION);
            }
            else {
                pData = (UINT8 *)pDatabase[ucSlotNumber]->GetCheckPointPtr(LATEST_SLTCHKPNT_VERSION);
            }
        }
        else {
            Context = LastContext;
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_FIVE:
        if (*pData) {
            RtnSts = DebugPort.PrintString("\r\nID: %02x DATA: ", *pData);
            ParamPtr = (UINT8 *)pDatabase[ucSlotNumber]->GetParamPtr(*pData);
            ucParamSize = pDatabase[ucSlotNumber]->GetParamSize(*pData);
        }
        else {
            RtnSts = RETURNSTATUS_COMPLETE;
            Context = LastContext;
        }
        break;
    case CONTEXT_SIX:
        RtnSts = DebugPort.PrintString("%02x ", *ParamPtr);
        break;
    case CONTEXT_SEVEN:
        if ('C' == s_cInputBuffer[3]) {
            // for, PMIO redesign
            // NAN value in series C represented as 0x7FFFFFFF 
            //      where as in pmio represented as 0xFFFFFFFF
            if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)ParamPtr)
#if defined(IOPTYPE_AO16)
                // default value of CHRC_Sn = 0x7FFFFFFF in pmio
                && ((*pData < PARAMID_CHRC_S0) && (*pData > PARAMID_CHRC_S4))
#endif
                )
                    ulChecksum ^= 0xFF;
            else    ulChecksum ^= *ParamPtr;
        }        
        else if ('c' == s_cInputBuffer[3]) {
            ulChecksum += *ParamPtr;
        }
        ParamPtr++;        
        if (--ucParamSize > 0) {
            
            Context = CONTEXT_FIVE;
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_EIGHT:
        if('C' == s_cInputBuffer[3])
            RtnSts = DebugPort.PrintString("CSM^: 0x%08X", (UINT32)ulChecksum);
        else if ('c' == s_cInputBuffer[3])
            RtnSts = DebugPort.PrintString("CSM+: 0x%08X", (UINT32)ulChecksum);
        break;
    case CONTEXT_NINE:
        pData++;
        if (*pData) {
            Context = CONTEXT_FOUR;
        }
        else {
            ulChecksum = 0;
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(LastContext, Context, RtnSts);
}
#if defined(IOPTYPE_HLAI)
static RETURNSTATUS AlarmInfo(VOID)
{
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8  sucSlotNo;

    switch (Context) 
    {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
        break;

    case CONTEXT_ONE:
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
        break;

    case CONTEXT_TWO:
        sucSlotNo = (UINT8)atoi(s_cInputBuffer);
        if (sucSlotNo > MAXSLOTS) {
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ZERO;
            return RETURNSTATUS_COMPLETE;
        }
        RtnSts = DebugPort.PrintString("\n\rALMINFO: %02x",
            ((clsAihSlot *)pDatabase[sucSlotNo])->GetAlmInfo());
        break;

    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString(" ALMSLRS: %02x",
            ((clsAihSlot *)pDatabase[sucSlotNo])->GetAlarmLrs());
        break;     
    }

    return AdvanceContext(CONTEXT_THREE, Context, RtnSts);
}
#endif //#if defined(IOPTYPE_HLAI)
#if defined(IOMTYPE_DO)
static RETURNSTATUS GetDoOutputs(VOID) {
    
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

    // Save readback select registers
    //UINT8 ucSaveExr = get_imask_exr();
    //set_imask_exr(LVLPRI_HIGHEST);     // disable all interrupts
    //UINT8 ucRdBkSel = RDBK_SEL;

    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\n\r\tPORTB\t:0x%02x (Write 0xFFFF6A)", P_PB.PORT.BYTE);
        break;

    case CONTEXT_ONE:
        RtnSts = DebugPort.PrintString("\n\r\tPORTC\t:0x%02x (Write 0xFFFF6B)", P_PC.PORT.BYTE);
        break;

    case CONTEXT_TWO:
        RtnSts = DebugPort.PrintString("\n\r\tPORTD\t:0x%02x (Write 0xFFFF6C)", P_PD.PORT.BYTE);
        break;

    case CONTEXT_THREE:
        RtnSts = DebugPort.PrintString("\n\r\tPORTE\t:0x%02x (Write 0xFFFF6D)", P_PE.PORT.BYTE);
        break;

    case CONTEXT_FOUR:
        RtnSts = DebugPort.PrintString("\r\n\tOPBF2\t:0x%08x", BOX->GetOutputBuffer2());
        break;

    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString("\r\n\tOPBF1\t:0x%08x", BOX->GetOutputBuffer1());
        break;

    default:
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }
    
    //RDBK_SEL = ucRdBkSel; // Restore readback select register
    //set_imask_exr(ucSaveExr);     // disable all interrupts

    return AdvanceContext(CONTEXT_FIVE, Context, RtnSts);
}
/*static RETURNSTATUS GetSwitchStatus(VOID) {

    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucLoopCount=0;
    UINT8 ucByte;

    switch (Context) {

    case CONTEXT_ZERO:
        EN_SW = SW_OFF;
        EN_SW = SW_ON;
        RtnSts = RETURNSTATUS_COMPLETE;
        Context = CONTEXT_FOUR;
        break;

    case CONTEXT_ONE:
        TST_SW = SW_ON;
        INH_SW1 = SW_ON;
        //IdleWait(300);
        RtnSts = RETURNSTATUS_COMPLETE;
        Context = CONTEXT_FOUR;
        break;

    case CONTEXT_TWO:
        INH_SW1 = SW_OFF;
        //IdleWait(150);
        RtnSts = RETURNSTATUS_COMPLETE;
        Context = CONTEXT_FOUR;
        break;

    case CONTEXT_THREE:
        TST_SW = SW_OFF;
        INH_SW2 = SW_ON;
        //IdleWait(300);
        RtnSts = RETURNSTATUS_COMPLETE;
        Context = CONTEXT_FOUR;
        break;

    case CONTEXT_FOUR:
        INH_SW2 = SW_OFF;
        //IdleWait(150);
        RtnSts = RETURNSTATUS_COMPLETE;        
        break;

    case CONTEXT_FIVE:
        RtnSts = DebugPort.PrintString("\n\rEN_SW:%d, TST_SW:%d, INH_SW1:%d, INH_SW2:%d, ", EN_SW, TST_SW, INH_SW1, INH_SW2);
        break;
    
    case CONTEXT_SIX:
        ucByte = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        RDBK_STRB_n = 1;            // Disable CPLD outputs
        RDBK_SEL3 = 1;              // Select CPLD 2
        RDBK_STRB_n = 0;            // Re-enable CPLD outputs
        RDBK_SEL = RDBK_INHSW;
        RtnSts = DebugPort.PrintString(" INHSWV2:%d, INHSWV3:%d, INHSWV1:%d", INHSWV2, INHSWV3, INHSWV1);
        RDBK_STRB_n = 1;            // Disable CPLD outputs
        RDBK_SEL3 = 0;              // Select CPLD 1
        RDBK_STRB_n = 0;            // Re-enable CPLD outputs
        set_imask_exr(ucByte);
        if (ucLoopCount < 5)
        {
            Context = (CONTEXT)ucLoopCount;
            ucLoopCount++;
        }
        else ucLoopCount = 0;
        break;

    default:
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    }

    return AdvanceContext(CONTEXT_SIX, Context, RtnSts);
}*/
#endif
#if defined(IOPTYPE_DI)
static RETURNSTATUS GetDumpDi(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT16 uiWriteCount = 0;
    switch (Context) {
    case CONTEXT_ZERO:
        RtnSts = DebugPort.PrintString("\r\n");
        break;
    case CONTEXT_ONE:
        //if (ucDbgCnt)
        {
            RtnSts = DebugPort.PrintString("%02x ", ucDumpBuff[uiWriteCount]);
        }
        //else RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_TWO:
        uiWriteCount++;
        // 32 channels x no of debug bytes
        if (uiWriteCount < (MAXSLOTS*6)) 
        {            
            Context = (uiWriteCount % 6) ? CONTEXT_ONE : CONTEXT_ZERO;
           
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else {
            RtnSts = DebugPort.PrintString("\r\nDBG CNT: %d", ucDbgCnt);
            RtnSts = RETURNSTATUS_COMPLETE;
            uiWriteCount = 0;
            //ucDbgCnt = 0;
        }
        break;
    }

    return AdvanceContext(CONTEXT_TWO, Context, RtnSts);
}
#endif
#endif //#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG)
//

#if defined(IOMTYPE_PI)
/*******************************************************************************
*                                    ReadFpga                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
 static RETURNSTATUS ReadFpga(VOID){
     RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
     static CONTEXT Context = CONTEXT_ZERO;
     static UINT8 uclCount = 0;
 
     switch (Context) {
     case CONTEXT_ZERO:
         RtnSts = DebugPort.PrintString("\n\r\tAddress\tRegister             Value");  
         break;
     case CONTEXT_ONE:
         RtnSts = DebugPort.PrintString("\n\r\t=======\t================     =====");
         break;
     case CONTEXT_TWO:
         RtnSts = DebugPort.PrintString("\n\r\t400060 \tFPGA IRQ Status      0x%04x",
                                        (*(volatile UINT16 *)0x400060));
         break;
     case CONTEXT_THREE:
         RtnSts = DebugPort.PrintString("\n\r\t400062 \tFPGA IRQ Control     0x%04x",
                                        (*(volatile UINT16 *)0x400062));
         break;
     case CONTEXT_FOUR:
         RtnSts = DebugPort.PrintString("\n\r\t400070 \tBuild & Revision Reg 0x%04x",
                                        (*(volatile UINT16 *)0x400070));
         break;
     case CONTEXT_FIVE:
         RtnSts = DebugPort.PrintString("\n\r\t400072 \tModule Address Reg   0x%04x",
                                        (*(volatile UINT16 *)0x400072));
         break;
     case CONTEXT_SIX:
         RtnSts = DebugPort.PrintString("\n\r\t400074 \tDIP & RIP CR         0x%04x",
                                        (*(volatile UINT16 *)0x400074));
         break;
     case CONTEXT_SEVEN:
         RtnSts = DebugPort.PrintString("\n\r\t400076 \tInhibit SW Control   0x%04x",
                                        (*(volatile UINT16 *)0x400076));
         break;        
     case CONTEXT_EIGHT:
         RtnSts = DebugPort.PrintString("\n\r\t400080 \tInput Thre&Trans CR  0x%04x",
                                        (*(volatile UINT16 *)0x400080));
         break;
     case CONTEXT_NINE:
         RtnSts = DebugPort.PrintString("\n\r\t400082 \tPulse Mode CR        0x%04x",
                                        (*(volatile UINT16 *)0x400082));
         break;
     case CONTEXT_TEN:
         RtnSts = DebugPort.PrintString("\n\r\t400084 \tOutput CR            0x%04x",
                                        (*(volatile UINT16 *)0x400084));
         break;
     case CONTEXT_ELEVEN:
         RtnSts = DebugPort.PrintString("\n\r\t400086 \tCounter clear CR     0x%04x",
                                        (*(volatile UINT16 *)0x400086));
         break;
     case CONTEXT_TWELVE:
         RtnSts = DebugPort.PrintString("\n\r\t400088 \tDiag Counter CR      0x%04x",
                                        (*(volatile UINT16 *)0x400088));
         break;
     case CONTEXT_THIRTEEN:
         RtnSts = DebugPort.PrintString("\n\r\t40008A \tOutput0 Target       0x%08X",
                                        (*(volatile UINT32 *)0x40008A));
         break;
     case CONTEXT_FOURTEEN:    
         RtnSts = DebugPort.PrintString("\n\r\t40008E \tOutput1 Target       0x%08X",
                                        (*(volatile UINT32 *)0x40008E));
         break;
     case CONTEXT_FIFTEEN:
         RtnSts = DebugPort.PrintString("\n\r\t400092 \tPulse Input Status   0x%04x",
                                        (*(volatile UINT16 *)0x400092));
         break;
     case CONTEXT_SIXTEEN:
         RtnSts = DebugPort.PrintString("\n\r\t400094 \tRedundancy Control   0x%04x",
                                        (*(volatile UINT16 *)0x400094));
         break;
     case CONTEXT_SEVENTEEN:
         RtnSts = DebugPort.PrintString("\n\r\t400096 \tIntegrat period CR1  0x%04x",
                                        (*(volatile UINT16 *)0x400096));
         break;
     case CONTEXT_EIGHTEEN:
         RtnSts = DebugPort.PrintString("\n\r\t400098 \tIntegrat period CR2  0x%04x",
                                        (*(volatile UINT16 *)0x400098));
         break;
     case CONTEXT_NINETEEN:
         RtnSts = DebugPort.PrintString("\n\r\t40009A \tPW Rejection  CR     0x%04x",
                                        (*(volatile UINT16 *)0x40009A));
         break;
     case CONTEXT_TWENTY:
         RtnSts = DebugPort.PrintString("\n\r\t40009C \tIP Valid CR          0x%04x",
                                        (*(volatile UINT16 *)0x40009C));
         break;
     case CONTEXT_TWENTYONE:
         RtnSts = DebugPort.PrintString("\n\r\t40009E \tAlarm bits RB        0x%04x",
                                        (*(volatile UINT16 *)0x40009E));
         break;        
     case CONTEXT_TWENTYTWO:
         RtnSts = DebugPort.PrintString("\n\r\t4000A0 \tPow Supply Ctl/Stat  0x%04x",
                                        (*(volatile UINT16 *)0x4000A0));
         break;
     case CONTEXT_TWENTYTHREE:
         RtnSts = DebugPort.PrintString("\n\r\t4000A2 \tDual pulse Integrity 0x%04x",
                                        (*(volatile UINT16 *)0x4000A2));
         break;
     case CONTEXT_TWENTYFOUR:
         RtnSts = DebugPort.PrintString("\n\r\t4000A4 \tScratchpad Reg       0x%04x",
                                        (*(volatile UINT16 *)0x4000A4));
         break;
     case CONTEXT_TWENTYFIVE:
         RtnSts = DebugPort.PrintString("\n\r\t4000A6 \tPulse Capture Status 0x%04x",
                                        (*(volatile UINT16 *)0x4000A6));
         break;
     case CONTEXT_TWENTYSIX:
         RtnSts = DebugPort.PrintString("\n\r\t4000A8 \tPulse Input Test Reg 0x%04x",
                                        (*(volatile UINT16 *)0x4000A8));
         break;         
     case CONTEXT_TWENTYSEVEN:  
         {
           RtnSts = DebugPort.PrintString("\n\r\t%06X \tCounter(%d)           0x%08X (%u)",
                   (0x400100 + (uclCount * 4)),uclCount,(*(volatile UINT32 *)(0x400100 + (uclCount*4))),
                    (*(volatile UINT32 *)(0x400100 + (uclCount*4)))); 
           
           if((RtnSts == RETURNSTATUS_COMPLETE) && (++uclCount == MAXSLOTS)){
               RtnSts = RETURNSTATUS_COMPLETE;
               uclCount = 0;
           }
           else
               RtnSts = RETURNSTATUS_INPROGRESS;
         }
         break;
     case CONTEXT_TWENTYEIGHT:
         {
           RtnSts = DebugPort.PrintString("\n\r\t%06X \tTimer Latch(%d)       0x%08X (%u)",
                    (0x400200 + (uclCount * 4)),uclCount,(*(volatile UINT32 *)(0x400200 + (uclCount*4))),
                    (*(volatile UINT32 *)(0x400200 + (uclCount*4)))); 
           if((RtnSts == RETURNSTATUS_COMPLETE) && (++uclCount == MAXSLOTS)){
               RtnSts = RETURNSTATUS_COMPLETE;
               uclCount = 0;
           }
           else
               RtnSts = RETURNSTATUS_INPROGRESS;
         }
         break;
     case CONTEXT_TWENTYNINE:
         {
           RtnSts = DebugPort.PrintString("\n\r\t%06X \tFRC(%d)               0x%08X (%u)",
                    (0x400400 + (uclCount * 4)),uclCount,(*(volatile UINT32 *)(0x400400 + (uclCount*4))),
                    (*(volatile UINT32 *)(0x400400 + (uclCount*4))));  
           if((RtnSts == RETURNSTATUS_COMPLETE) && (++uclCount == MAXSLOTS)){
               RtnSts = RETURNSTATUS_COMPLETE;
               uclCount = 0;
           }
           else
               RtnSts = RETURNSTATUS_INPROGRESS;
         }
         break;
     case CONTEXT_THIRTY:
         {
           RtnSts = DebugPort.PrintString("\n\r\t%06X \tCounter Update(%d)    0x%08X (%u)",
                   (0x401000 + (uclCount * 4)),uclCount,(*(volatile UINT32 *)(0x401000 + (uclCount*4))),
                    (*(volatile UINT32 *)(0x401000 + (uclCount*4))));  
           if((RtnSts == RETURNSTATUS_COMPLETE) && (++uclCount == MAXSLOTS)){
               RtnSts = RETURNSTATUS_COMPLETE;
               uclCount = 0;
           }
           else
               RtnSts = RETURNSTATUS_INPROGRESS;
         }
         break;
     case CONTEXT_THIRTYONE:
         {
           RtnSts = DebugPort.PrintString("\n\r\t%06X \tGet&Clr Reg(%d)       0x%08X (%u)",
                   (0x402100 + (uclCount * 4)),uclCount,(*(volatile UINT32 *)(0x402100 + (uclCount*4))),
                    (*(volatile UINT32 *)(0x402100 + (uclCount*4))));  
           if((RtnSts == RETURNSTATUS_COMPLETE) && (++uclCount == MAXSLOTS)){
               RtnSts = RETURNSTATUS_COMPLETE;
               uclCount = 0;
           }
           else
               RtnSts = RETURNSTATUS_INPROGRESS;
         }
         break;
     }
 
     return AdvanceContext(CONTEXT_THIRTYONE,Context,RtnSts);
}
/*******************************************************************************
*                                  RedunSwitchTest                             *
*                                  ===============                             *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
 static RETURNSTATUS RedunSwitchTest(VOID) {
     RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
     const UINT8  NO_OF_TESTS = 16;
     const UINT16 DELAY_TIME  = 40; // 40 us delay time
     static CONTEXT Context = CONTEXT_ZERO;
     static BOOL bResult,bIsShortTest;
 
     static UINT8 ReadFloat[NO_OF_TESTS]    = { 0x05,0x01,0x05,0x01,0x05,0x01,0x07,0x00,
                                                0x05,0x01,0x07,0x00,0x05,0x01,0x07,0x00};
     static UINT8 ReadShort[NO_OF_TESTS]    = { 0x05,0x01,0x05,0x01,0x05,0x01,0x07,0x00,
                                                0x05,0x01,0x05,0x01,0x05,0x01,0x07,0x00};
     static UINT8 Results[NO_OF_TESTS]      = { 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
                                                0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
     switch (Context) {
     case CONTEXT_ZERO:
          RtnSts = DebugPort.PrintString("\n\r\tFloat(0),Short(1):");
          break;
     case CONTEXT_ONE:
          RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
          break;
     case CONTEXT_TWO:
          bIsShortTest = (UINT8)atoi(s_cInputBuffer);
          if(bIsShortTest){
             if(INHINX_n){
                RtnSts = DebugPort.PrintString("\n\r\tTest Failed.INHINX_n is High at startup");
                if(RtnSts == RETURNSTATUS_COMPLETE){
                   Context = CONTEXT_ZERO;
                   return RETURNSTATUS_COMPLETE;
                }
             }
          }
          else{ //Float
             if(!INHINX_n){
                RtnSts = DebugPort.PrintString("\n\r\tTest Failed.INHINX_n is Low at startup");
                if(RtnSts == RETURNSTATUS_COMPLETE){
                   Context = CONTEXT_ZERO;
                   return RETURNSTATUS_COMPLETE;
                }
             }
          }
          RtnSts = RETURNSTATUS_COMPLETE;
          break;
     case CONTEXT_THREE:
         {
             UINT8 ucResult = 0;
             bResult = FALSE;
             
             const UINT8 *pcExpResult = bIsShortTest ? ReadShort : ReadFloat;
             for (UINT8 ucIndex = 0; ucIndex < NO_OF_TESTS; ucIndex++) {
                 INHSWCR.LOBYTE = (ucIndex & 0x0F);
                 IdleWait(DELAY_TIME);
                 ucResult = (INHSWCR.HIBYTE & 0x07);
                 Results[ucIndex]= ucResult;  
                 if(Results[ucIndex] != pcExpResult[ucIndex])
                    bResult = TRUE;
                 ucResult = 0;
             }
         }
         RtnSts = RETURNSTATUS_COMPLETE; 
         break;
     case CONTEXT_FOUR:
         if(bResult)
         RtnSts = DebugPort.PrintString("\n\r\tTest Failed......\n");
         else
         RtnSts = DebugPort.PrintString("\n\r\tTest Passed......\n");
         break;
     case CONTEXT_FIVE:
         {
             static UINT8 ucsIndex = 0;
             RtnSts = DebugPort.PrintString("\n\r\tWrote:0x%02x Exptd:0x%02x Read:0x%02x",
                                                ucsIndex, bIsShortTest ? ReadShort[ucsIndex]:ReadFloat[ucsIndex],
                                                Results[ucsIndex]);
             
             // Increment the index only if the PrintString is complete.
             if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == NO_OF_TESTS)) {
                 // All the strings are printed now.
                 RtnSts = RETURNSTATUS_COMPLETE;
                 ucsIndex = 0;
             }
             else {
                 RtnSts = RETURNSTATUS_INPROGRESS;
             }
         }
         break;
     }
 
     return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
/*******************************************************************************
*                                  TestFpgaConnectivity                        *
*                                  =============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS TestFpgaConnectivity(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucResult;
    const  UINT8 NO_OF_TESTS = 8;
    static BOOL  bFailed;
    static UINT8 ExpectedResult[NO_OF_TESTS] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
    static UINT8 ActualResult[NO_OF_TESTS]   = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
    
    switch(Context){
    case CONTEXT_ZERO:
         bFailed = FALSE;
         RtnSts = DebugPort.PrintString("\n\r\tTest VISO_EN->VISO_GOOD Loopback...");
         break;
    case CONTEXT_ONE:
         if(ISOCHNGOOD != 0x00){ 
            Context = CONTEXT_THREE;
            RtnSts = DebugPort.PrintString("Failed\n\r\tExpected Value of VISO_En Reg:0x00 Actual:0x%02x",ISOCHNGOOD);
         }   
         else
            RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_TWO:
         for( UINT8 ucsIndex =0; ucsIndex< NO_OF_TESTS;ucsIndex++){
             ISOCHNENB = ExpectedResult[ucsIndex];
             IdleWait(1);  
             ucResult = ISOCHNGOOD;
             if(ExpectedResult[ucsIndex] != ucResult){
                ActualResult[ucsIndex] = ucResult;
                bFailed = TRUE;
             }
         }
         if(!bFailed){
            Context = CONTEXT_THREE;
            RtnSts = DebugPort.PrintString("Passed");
         }   
         else{
            RtnSts = DebugPort.PrintString("Failed");
         } 
         break;
    case CONTEXT_THREE:
        {
             static UINT8 ucsIndex = 0;
             RtnSts = RETURNSTATUS_COMPLETE;
             if(ActualResult[ucsIndex] != 0x00){
                RtnSts = DebugPort.PrintString("\n\r\tWrote:0x%02x Exptd:0x%02x Read:0x%02x",
                                                (0x01 << ucsIndex), ExpectedResult[ucsIndex],
                                                ActualResult[ucsIndex]);
             }
             
             if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == NO_OF_TESTS)) {
                 // All the strings are printed now.
                 RtnSts = RETURNSTATUS_COMPLETE;
                 ucsIndex = 0;
             }
             else {
                 RtnSts = RETURNSTATUS_INPROGRESS;
             }  
        }  
         break;
    case CONTEXT_FOUR:
         bFailed = FALSE;
         IRQ3_ENABLE = DISABLE;
         for(UINT8 ucsIndex = 0; ucsIndex < NO_OF_TESTS; ucsIndex++)
             ActualResult[ucsIndex] = 0x00;
         RtnSts  = DebugPort.PrintString("\n\r\tTest FPGA IRQs...");
         break;
    case CONTEXT_FIVE:
         ISOCHNENB = 0x00;
         FPGA_CTRLREG_VISO = 0x00;
         IdleWait(1);
         if(FPGA_IRQ == 0){
            Context = CONTEXT_SEVEN;
            bFailed = TRUE;
            RtnSts = DebugPort.PrintString("Failed\n\r\tFPGA_IRQ is LOW at the start of the diagnostic, expected state is HIGH");
         }
         else{
            FPGA_CTRLREG_VISO = 0xFF;
            RtnSts = RETURNSTATUS_COMPLETE;
         }
         break;
    case CONTEXT_SIX:
        {
           static UINT8 ucsIndex = 0;
           ISOCHNENB = ExpectedResult[ucsIndex];
           IdleWait(2);
           if(FPGA_IRQ == 0){
              ISOCHNENB = 0x00;
              IdleWait(2);
              if(FPGA_IRQ == 0){
                 RtnSts = DebugPort.PrintString("Failed\n\r\tFPGA_IRQ is not clear after writing 0x00 to ISO_En(7,0)");
                 if(RtnSts == RETURNSTATUS_COMPLETE){
                    FPGA_CTRLREG_VISO = 0x00;
                    Context = CONTEXT_SEVEN;
                    IRQ3_ENABLE = ENABLE;
                    return RETURNSTATUS_COMPLETE;
                 }
              }
              else 
                 RtnSts = RETURNSTATUS_COMPLETE;
           }
           else{
              RtnSts = DebugPort.PrintString("Failed\n\r\tFPGA_IRQ is not set after setting ISO_En bit:%d",ucsIndex);
              if(RtnSts == RETURNSTATUS_COMPLETE){
                 ISOCHNENB = 0x00;
                 FPGA_CTRLREG_VISO = 0x00;
                 Context = CONTEXT_SEVEN; 
                 IRQ3_ENABLE = ENABLE; 
                 return RETURNSTATUS_COMPLETE;
              }
           }

            if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == NO_OF_TESTS)) {
                FPGA_CTRLREG_VISO = 0x00;
                ISOCHNENB = 0x00;
                RtnSts = RETURNSTATUS_COMPLETE;
                ucsIndex = 0;
            }
            else {
                RtnSts = RETURNSTATUS_INPROGRESS;
            }
        }
         break;
    case CONTEXT_SEVEN:
            IRQ3_ENABLE = ENABLE;
            if(bFailed)
               RtnSts = RETURNSTATUS_COMPLETE;
            else
               RtnSts = DebugPort.PrintString("Passed");
         break;
    case CONTEXT_EIGHT:
         bFailed = FALSE;
         for(UINT8 ucsIndex = 0; ucsIndex < NO_OF_TESTS; ucsIndex++)
             ActualResult[ucsIndex] = 0x00;
         RtnSts = DebugPort.PrintString("\n\r\tTest CVSEL->HI_LO_FB Loopback...");
         break;
    case CONTEXT_NINE:
         if(IPTHRSHSTS != 0x00){ 
            RtnSts = DebugPort.PrintString("Failed \n\r\tExpected Value of status Reg:0x00 Actual:0x%02x",IPTHRSHSTS);
            if(RtnSts == RETURNSTATUS_COMPLETE)
               Context = CONTEXT_ELEVEN;
            else
               RtnSts = RETURNSTATUS_INPROGRESS;
         }   
         else
            RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_TEN:
         for(UINT8 ucsIndex = 0; ucsIndex < NO_OF_TESTS; ucsIndex++){
             VOLT_THRESHOLD = ExpectedResult[ucsIndex];
             IdleWait(1000); // 1 msec delay  
             ucResult = IPTHRSHSTS;
             if(ExpectedResult[ucsIndex] != ucResult){
                ActualResult[ucsIndex] = ucResult;
                bFailed = TRUE;
             }                
         }
         VOLT_THRESHOLD = 0x00;
         if(!bFailed){
            Context = CONTEXT_ELEVEN;
            RtnSts = DebugPort.PrintString("Passed");
         }   
         else
            RtnSts = DebugPort.PrintString("Failed");
         break;
    case CONTEXT_ELEVEN:
        {
             static UINT8 ucsIndex = 0;
             RtnSts = RETURNSTATUS_COMPLETE;
             if(ActualResult[ucsIndex] != 0x00){
                RtnSts = DebugPort.PrintString("\n\r\tWrote:0x%02x Exptd:0x%02x Read:0x%02x",
                                                (0x01 << ucsIndex), ExpectedResult[ucsIndex],ActualResult[ucsIndex]);
             }
             if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == NO_OF_TESTS)) {
                 // All the strings are printed now.
                 RtnSts = RETURNSTATUS_COMPLETE;
                 ucsIndex = 0;
             }
             else {
                 RtnSts = RETURNSTATUS_INPROGRESS;
             }
        }
         break;
    }

    return AdvanceContext(CONTEXT_ELEVEN,Context,RtnSts);
}
/*******************************************************************************
*                                  CounterDiagnostics                          *
*                                  ==============                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS CounterDiagnostics(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT  Context = CONTEXT_ZERO;
    const  UINT8    NO_OF_TESTS = 8;
    static BOOL     bFailed,bTestFailed;
    static UINT32   ulTemp;
    static UINT8    ucTestCount,ucCounterNo,ucSubCmd;
    
    static UINT32   Result[NO_OF_TESTS]    = { 0x00000000,0x00000000,0x00000000,0x00000000,
                                               0x00000000,0x00000000,0x00000000,0x00000000};
    static UINT32   Result1[NO_OF_TESTS]   = { 0x00000000,0x00000000,0x00000000,0x00000000,
                                               0x00000000,0x00000000,0x00000000,0x00000000};
    static UINT32   ExpResult1[NO_OF_TESTS]= { 0x12355679,0x9ABDDEF2,0xFFEFDDCD,0xBBAB1123,
                                               0x33455567,0x778999AB,0xBBCDDDEF,0xFEDDBA99};

    static UINT32   ExpResult2[16]         = { 0x00010001,0x00020002,0x00040004,0x00080008,
                                               0x00100010,0x00200020,0x00400040,0x00800080,
                                               0x01000100,0x02000200,0x04000400,0x08000800,
                                               0x10001000,0x20002000,0x40004000,0x80008000};
    static UINT32   ActResult2[16]         = { 0x00000000,0x00000000,0x00000000,0x00000000,
                                               0x00000000,0x00000000,0x00000000,0x00000000,
                                               0x00000000,0x00000000,0x00000000,0x00000000,
                                               0x00000000,0x00000000,0x00000000,0x00000000};
    static UINT32   LoadValue[16]          = { 0x00000000,0x00010001,0x00030003,0x00070007,
                                               0x000F000F,0x001F001F,0x003F003F,0x007F007F,
                                               0x00FF00FF,0x01FF01FF,0x03FF03FF,0x07FF07FF,
                                               0x0FFF0FFF,0x1FFF1FFF,0x3FFF3FFF,0x7FFF7FFF};
    
    switch(Context){
    case CONTEXT_ZERO:
         ucTestCount = ucCounterNo = ucSubCmd = 0;
         ulTemp = 0;
         for(UINT8 i = 0;i < NO_OF_TESTS;i++){
             Result[i] = 0;
             Result1[i]= 0;
         }
         bFailed = bTestFailed = FALSE;
         RtnSts = DebugPort.PrintString("\n\r\tSelect test RunAll(0),Init&Clr Cntrs(1),Run Cntrs(2),Clr Cntrs(3):");
         break;
    case CONTEXT_ONE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_TWO:
         ucSubCmd = (UINT8)atoi(s_cInputBuffer);
         if(ucSubCmd == 2)
            Context = CONTEXT_EIGHT;
         if(ucSubCmd == 3)
            Context = CONTEXT_THIRTEEN;
         if(ucSubCmd == 0 || ucSubCmd == 1)
            RtnSts = DebugPort.PrintString("\n\r\tTest Clear Counters(CTRL Bits)...");
         else
            RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_THREE:
         DIAGON = 1;
         
         // Loaded Unique pattern to Counter 0-7 Update Registers
         for(UINT8 i =0 ;i < NO_OF_TESTS;i++){
             (*(volatile UINT16 *)(0x401000 +(i*4)))     = ((ExpResult1[i] & 0xFFFF0000) >> 16) - 1;
             (*(volatile UINT16 *)(0x401000 +(i*4) + 2)) = (ExpResult1[i] & 0xFFFF) - 1;
         }
         
         // Set the Loaded value is Valid
         COUNT_UPDATE_FLAGS = 0xFF;
         // Generate the rising edge to increment the counter value
         DIAGWR = 3;
         DIAGWR = 0;
         IdleWait(2);
         // Read Registers Counter 0-7 Values
         for(UINT8 i = 0;i < NO_OF_TESTS; i++){ 
             ulTemp  = (*(volatile UINT32 *)(0x400100 +(i*4)));
             Result[i] = ulTemp;
             if(Result[i] != ExpResult1[i])
                bTestFailed = TRUE;
             ulTemp = 0;
         }
         COUNT_UPDATE_FLAGS = 0x00;

         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_FOUR:
         if(bTestFailed){
            Context = CONTEXT_SIX;
            RtnSts = DebugPort.PrintString("Failed\n\r\tActual Load Value not matches with expected load value");
         }
         else
            RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_FIVE:
         CLEAR_COUNTERS = (0x01 << ucTestCount); // Clear Counter one at a time
         for(UINT8 i = 0;i < NO_OF_TESTS; i++){ 
             ulTemp  = (*(volatile UINT32 *)(0x400100 + (i*4)));
             Result1[i] = ulTemp;
             ulTemp = 0;
         }
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_SIX:
         if(ucTestCount == 0){
            if((Result1[0] !=0x00000000) || (Result1[1]!=0x9ABDDEF2)|| (Result1[2]!=0xFFEFDDCD) || (Result1[3]!=0xBBAB1123)
                 || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                  bFailed = TRUE;
            }
         }
         else if(ucTestCount == 1){
                if((Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0xFFEFDDCD) || (Result1[3]!=0xBBAB1123)
                   || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                   bFailed = TRUE;
                }
         }
         else if(ucTestCount == 2){
                if((Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0xBBAB1123)
                   || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                   bFailed = TRUE;
                }
         }
         else if(ucTestCount == 3){
                if((Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                   || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                   bFailed = TRUE;
                }
         }
         else if(ucTestCount == 4){
                if((Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                   || (Result1[4]!=0x00000000) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                   bFailed = TRUE;
                }
         }
         else if(ucTestCount == 5){
                if((Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                   || (Result1[4]!=0x00000000) || (Result1[5]!=0x00000000) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                   bFailed = TRUE;
                }
         }
         else if(ucTestCount == 6){
                if((Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                   || (Result1[4]!=0x00000000) || (Result1[5]!=0x00000000) || (Result1[6]!=0x00000000) || (Result1[7]!=0xFEDDBA99)){
                   bFailed = TRUE;
                }
         }
         else if(ucTestCount == 7){
                if((Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                   || (Result1[4]!=0x00000000) || (Result1[5]!=0x00000000) || (Result1[6]!=0x00000000) || (Result1[7]!=0x00000000)){
                   bFailed = TRUE;
                }
         } 
         if(bFailed){
            Context = CONTEXT_SIX;
            RtnSts = DebugPort.PrintString("\n\r\tClearing Counter(%d) affecting other counters",ucTestCount);
         }
         else{
            ucTestCount++;
            if(ucTestCount < 8) 
               Context = CONTEXT_FOUR; 
               RtnSts = RETURNSTATUS_COMPLETE;
         }
         break;
    case CONTEXT_SEVEN:
         CLEAR_COUNTERS = 0x00;
         DIAGON = 0;
         if(!(bFailed || bTestFailed)){
             if(ucSubCmd == 1)
                Context = CONTEXT_NINETEEN; // Last one
             else
                Context = CONTEXT_EIGHT;
             RtnSts  = DebugPort.PrintString("Passed");
         }
         else{
            if(bFailed)
               RtnSts = DebugPort.PrintString("\n\r\tCounter     ExpLoadVal   ActLoadVal   Exp(Af Clr)  Act(Af Clr)");
            else
               RtnSts = DebugPort.PrintString("\n\r\tCounter     ExpLoadVal   ActLoadVal");
         }
         break;
    case CONTEXT_EIGHT:
        {
             static UINT8 ucsIndex = 0;
             RtnSts = RETURNSTATUS_COMPLETE;
             if(bFailed){
                RtnSts = DebugPort.PrintString("\n\r\tCounter(%d)  0x%08X   0x%08X   0x00000000   0x%08X",
                                                 ucsIndex,ExpResult1[ucsIndex],Result[ucsIndex],Result1[ucsIndex]);
             }
             else{
                RtnSts = DebugPort.PrintString("\n\r\tCounter(%d)  0x%08X   0x%08X",
                                                 ucsIndex,ExpResult1[ucsIndex],Result[ucsIndex]);
             }
             
             if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == NO_OF_TESTS)) {
                 // All the strings are printed now.
                 ucsIndex = 0;
                 if(ucSubCmd == 1)
                    Context = CONTEXT_NINETEEN; // Last one
                 RtnSts = RETURNSTATUS_COMPLETE;
             }
             else {
                 RtnSts = RETURNSTATUS_INPROGRESS;
             }  
        }
         break;
    case CONTEXT_NINE:
         ucTestCount = 0;ucCounterNo = 0;
         bFailed = FALSE; bTestFailed = FALSE;
         for(UINT8  i = 0;i < NO_OF_TESTS;i++){
             Result[i]  = 0x00000000;
             Result1[i] = 0x00000000;
         }
         DIAGON = 1;
         RtnSts = DebugPort.PrintString("\n\r\tTest Run Counters...");
         break;
    case CONTEXT_TEN:
         // Write to Counter Update registers 0-7
         (*(volatile UINT32 *)(0x401000 + (ucCounterNo*4))) = LoadValue[ucTestCount];
         COUNT_UPDATE_FLAGS = (0x01 << ucCounterNo);
         DIAGWR = 3;
         DIAGWR = 0;
         IdleWait(2);         
         // Read from counters 0-7
         ulTemp = (*(volatile UINT32 *)(0x400100 + (ucCounterNo*4)));
         ActResult2[ucTestCount] = ulTemp;
         if(ActResult2[ucTestCount]!= ExpResult2[ucTestCount])
            bFailed = TRUE;
         COUNT_UPDATE_FLAGS = 0x00;
         if(ucTestCount < 15){
            ucTestCount += 1;
            Context = CONTEXT_NINE;
         }
         else{
            ucCounterNo++;
            ucTestCount = 0;
         }
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_ELEVEN:
         if(bFailed){
            if(bTestFailed)
               RtnSts = DebugPort.PrintString("\n\r\tActual Vals is not equal to Exp Values for Counter %d",(ucCounterNo-1));
            else
               RtnSts = DebugPort.PrintString("Failed\n\r\tActual Vals is not equal to Exp Values for Counter %d",(ucCounterNo-1));
             bTestFailed = TRUE;
         }
         else{
              if(ucCounterNo < 8){
               Context = CONTEXT_NINE;
               for(UINT8 i=0;i< 16;i++)
                   ActResult2[i] = 0;
               RtnSts = RETURNSTATUS_COMPLETE;
              }
            else{
               DIAGON = 0;
               if(ucSubCmd == 2)
                  Context = CONTEXT_NINETEEN; //Last one
               else
                  Context = CONTEXT_THIRTEEN;
               if(!bTestFailed)
                  RtnSts = DebugPort.PrintString("Passed");
               else
                  RtnSts = RETURNSTATUS_COMPLETE;
            }
         }
         break;
    case CONTEXT_TWELVE:
         RtnSts = DebugPort.PrintString("\n\r\tLoadValue    Expected Value  Actual Value");
         break;
    case CONTEXT_THIRTEEN:
        {
             static UINT8 ucsIndex = 0;
             RtnSts = RETURNSTATUS_COMPLETE;
             RtnSts = DebugPort.PrintString("\n\r\t0x%08X   0x%08X      0x%08X",
                                                 LoadValue[ucsIndex],ExpResult2[ucsIndex],ActResult2[ucsIndex]);
             if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == 16)) {
                 // All the strings are printed now.
                 ucsIndex = 0; 
                 if(ucCounterNo == 8){
                    DIAGON = 0;
                    if(ucSubCmd == 2)
                      Context = CONTEXT_NINETEEN; //Last one
                    else
                      Context = CONTEXT_THIRTEEN;
                    RtnSts = RETURNSTATUS_COMPLETE;
                 }
                 else{
                    for(UINT8 i=0;i< 16;i++)
                        ActResult2[i] = 0;
                    bFailed = FALSE;
                    Context = CONTEXT_NINE;
                    RtnSts = RETURNSTATUS_COMPLETE;
                 }
             }
             else {
                 RtnSts = RETURNSTATUS_INPROGRESS;
             }  
        }
         break;
    case CONTEXT_FOURTEEN:
         DIAGON = 0;
         bFailed = FALSE; bTestFailed = FALSE;
         ucTestCount = 0;
         for(UINT8 i=0;i < NO_OF_TESTS;i++){
             Result[i]   = 0x00000000;
             Result1[i]  = 0x00000000;
         }
         RtnSts = DebugPort.PrintString("\n\r\tTest Clear Counters(Get & Clear)...");
         break;
    case CONTEXT_FIFTEEN:
         DIAGON = 1;
         
         // Load unique pattern to Counter 0-7 Update registers
         for(UINT8 i =0 ;i < NO_OF_TESTS;i++){
             (*(volatile UINT16 *)(0x401000 +(i*4)))     = ((ExpResult1[i] & 0xFFFF0000) >> 16);
             (*(volatile UINT16 *)(0x401000 +(i*4) + 2)) = (ExpResult1[i] & 0xFFFF);
         }          

         COUNT_UPDATE_FLAGS = 0xFF;
         IdleWait(2);         
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_SIXTEEN:
         ulTemp = (*(volatile UINT32 *)(0x402100 + (ucTestCount*4)));
         Result[ucTestCount] = ulTemp;

         IdleWait(2);
         UINT32 ulTemp1;
         for(UINT8 i=0;i<NO_OF_TESTS;i++){
             ulTemp1 = (*(volatile UINT32 *)(0x400100 + (i*4)));
             Result1[i] = ulTemp1;
             ulTemp1 = 0;
         }
         ulTemp = 0;
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_SEVENTEEN:
         if(ucTestCount == 0){
            if((Result[ucTestCount] != 0x12355679)||(Result1[0] !=0x00000000) || (Result1[1]!=0x9ABDDEF2)|| (Result1[2]!=0xFFEFDDCD) || (Result1[3]!=0xBBAB1123)
                || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                bFailed = TRUE;
             }
         }
         else if(ucTestCount == 1){
            if((Result[ucTestCount] != 0x9ABDDEF2)||(Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0xFFEFDDCD) || (Result1[3]!=0xBBAB1123)
                || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                bFailed = TRUE;
             }              
         }
         else if(ucTestCount == 2){
            if((Result[ucTestCount] != 0xFFEFDDCD)||(Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0xBBAB1123)
                || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                bFailed = TRUE;
             }              
         }
         else if(ucTestCount == 3){
            if((Result[ucTestCount] != 0xBBAB1123)||(Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                || (Result1[4]!=0x33455567) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                bFailed = TRUE;
             }              
         }
         else if(ucTestCount == 4){
            if((Result[ucTestCount] != 0x33455567)||(Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                || (Result1[4]!=0x00000000) || (Result1[5]!=0x778999AB) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                bFailed = TRUE;
             }              
         }
         else if(ucTestCount == 5){
            if((Result[ucTestCount] != 0x778999AB)||(Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                || (Result1[4]!=0x00000000) || (Result1[5]!=0x00000000) || (Result1[6]!=0xBBCDDDEF) || (Result1[7]!=0xFEDDBA99)){
                bFailed = TRUE;
             }              
         }
         else if(ucTestCount == 6){
            if((Result[ucTestCount] != 0xBBCDDDEF)||(Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                || (Result1[4]!=0x00000000) || (Result1[5]!=0x00000000) || (Result1[6]!=0x00000000) || (Result1[7]!=0xFEDDBA99)){
                bFailed = TRUE;
             }              
         }
         else if(ucTestCount == 7){
            if((Result[ucTestCount] != 0xFEDDBA99)||(Result1[0] !=0x00000000) || (Result1[1]!=0x00000000)|| (Result1[2]!=0x00000000) || (Result1[3]!=0x00000000)
                || (Result1[4]!=0x00000000) || (Result1[5]!=0x00000000) || (Result1[6]!=0x00000000) || (Result1[7]!=0x00000000)){
                bFailed = TRUE;
             }              
         } 
         if(bFailed){
            RtnSts = DebugPort.PrintString("Failed\n\r\tReading Get&Clear Reg:%d Value:0x%08X not equal to \n\r\tLoad value or Clearing other Counter Values",ucTestCount,Result[ucTestCount]);                
         }
         else{
             ucTestCount++;
             if(ucTestCount < 8){
                Context = CONTEXT_FIFTEEN;
                for(UINT8 i=0;i<8;i++)
                   Result1[i]=0;
                RtnSts = RETURNSTATUS_COMPLETE;
             }
             else{
                COUNT_UPDATE_FLAGS = 0x00;
                DIAGON = 0;
                Context = CONTEXT_NINETEEN;
                RtnSts = DebugPort.PrintString("Passed");
             }
         }
         break;
    case CONTEXT_EIGHTEEN:
         RtnSts = DebugPort.PrintString("\n\r\tCounters   Value       Get&Clear Reg");
         break;
    case CONTEXT_NINETEEN:
        {
          static UINT8 ucsIndex = 0;
          RtnSts = RETURNSTATUS_COMPLETE;
          RtnSts = DebugPort.PrintString("\n\r\tCounter %d  0x%08X  0x%08X",ucsIndex,Result1[ucsIndex],Result[ucsIndex]);
          if ((RETURNSTATUS_COMPLETE ==  RtnSts) && (++ucsIndex == 8)) {
              // All the strings are printed now.
                ucsIndex = 0;
                COUNT_UPDATE_FLAGS = 0x00;
                DIAGON = 0;
                RtnSts = RETURNSTATUS_COMPLETE;
          }
          else {
              RtnSts = RETURNSTATUS_INPROGRESS;
          }  
        }
         break;
    }
    return AdvanceContext(CONTEXT_NINETEEN,Context,RtnSts);
}

/*******************************************************************************
*                                  FastCutOffTest                              *
*                                  ==============                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS FastCutOffTest(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucChanNum,ucSubCmd;
    static BOOL bFailed;
    static UINT32 ulTargetVal;

    switch(Context){
    case CONTEXT_ZERO:
         ucChanNum = ucSubCmd = 0;
         bFailed = FALSE;
         ulTargetVal = 0;
         RtnSts = DebugPort.PrintString(PRINTSTRING_SLOTNUMBER);
         break;
    case CONTEXT_ONE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;     
    case CONTEXT_TWO:
         ucChanNum = (UINT8)atoi(s_cInputBuffer);       
         if ((ucChanNum < 6) || (ucChanNum > 7)) {
             DebugPort.PrintString(PRINTSTRING_INVALID);
             Context = CONTEXT_ZERO; 
             return RETURNSTATUS_COMPLETE;
         }
         else {
             RtnSts = DebugPort.PrintString("\n\r\tSelect test RunAll(0),TVCtrl(1),SafeStCtrl(2),DirectSwCtrl(3):");
         }
         break;
    case CONTEXT_THREE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_FOUR:
         ucSubCmd = (UINT8)atoi(s_cInputBuffer);
         if(ucSubCmd == 0 || ucSubCmd == 1)
            RtnSts = DebugPort.PrintString("\n\r\tEnter Target Value:0x");
         else if(ucSubCmd == 2){
            Context = CONTEXT_ELEVEN;
            RtnSts = RETURNSTATUS_COMPLETE;
         }
         else{
            Context = CONTEXT_FOURTEEN;
            RtnSts = RETURNSTATUS_COMPLETE;
         }
         break;
    case CONTEXT_FIVE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_SIX:
         ulTargetVal = (UINT32)atoh(s_cInputBuffer);
         RtnSts = DebugPort.PrintString("\n\r\tTest TargetCtrl...");
         break;
    case CONTEXT_SEVEN:
         DIAGON = 1;
         CLEAR_COUNTERS = 0xC0;
         SAFE_STATE_n   = 1;
         OUT_SEN0  = 1; OUT_SEN1  = 1;
         OUT_CTRL0 = 1; OUT_CTRL1 = 1;
         OUT_SET0  = 0; OUT_SET1  = 0;
                   
         if(ucChanNum == 6){
            IdleWait(2);
            if(COMPARING0!= FALSE){
               if(ucSubCmd == 0)
                  Context = CONTEXT_ELEVEN;
               else
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tCOMP_0 bit Default Value Should be FALSE. Actual COMP_0 is %d \n",COMPARING0);
            }
            else
               RtnSts = RETURNSTATUS_COMPLETE;
         }
         else{
            IdleWait(2);
            if(COMPARING1!= FALSE){
               if(ucSubCmd == 0)
                  Context = CONTEXT_ELEVEN;
               else 
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tCOMP_1 bit Default Value is FALSE. Actual COMP_1 is %d \n",COMPARING1);
            }
            else
              RtnSts = RETURNSTATUS_COMPLETE;
         }
         break;
    case CONTEXT_EIGHT:
         if(ucChanNum == 6){
            OTR0  = ulTargetVal;
            IdleWait(2);
            if(COMPARING0!= TRUE){
               if(ucSubCmd == 0)
                  Context = CONTEXT_ELEVEN;
               else
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tCOMP_0 bit should be TRUE after TV written. Actual COMP_0 is %d \n",COMPARING0);
            }
            else
                  RtnSts = RETURNSTATUS_COMPLETE;
         }
         else{
            OTR1  = ulTargetVal;
            IdleWait(2);
            if(COMPARING1!= TRUE){
               if(ucSubCmd == 0)
                  Context = CONTEXT_ELEVEN;
                else
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tCOMP_1 bit should be TRUE after TV written. Actual COMP_1 is %d \n",COMPARING1);
            }
            else
               RtnSts = RETURNSTATUS_COMPLETE;
         }
         break;
    case CONTEXT_NINE:
         if(ucChanNum == 6){
            // Load Value to one count less than target value.      
            (*(volatile  UINT16 *)0x401018) = ((UINT16)((ulTargetVal & 0xFFFF0000) >> 16)) - 1;
            (*(volatile  UINT16 *)0x40101A) = ((UINT16)(ulTargetVal & 0x0000FFFF)) - 1;
            COUNT_UPDATE_FLAGS = 0x40;
            IdleWait(2);
            if(STATUSOUT0 != FALSE){
               if(ucSubCmd == 0)
                  Context = CONTEXT_ELEVEN;
               else
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tFCO is fired before reaching Target Value");
            }
            else{
               RtnSts = RETURNSTATUS_COMPLETE;
            }
        
         }
         else{
           // Load Value to one count less than target value.            
            (*(volatile  UINT16 *)0x40101C) = ((UINT16)((ulTargetVal & 0xFFFF0000) >> 16)) - 1;
            (*(volatile  UINT16 *)0x40101E) = ((UINT16)(ulTargetVal & 0x0000FFFF)) - 1;
            COUNT_UPDATE_FLAGS = 0x80;
            IdleWait(2);
            if(STATUSOUT1 != FALSE){
               if(ucSubCmd == 0)
                 Context = CONTEXT_ELEVEN;
               else
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tFCO is fired before reaching Target Value");
            }
            else{
               RtnSts = RETURNSTATUS_COMPLETE;
            }
         }
         DIAGWR = 3;  // Generate rising edge to increment counter
         DIAGWR = 0;
         break;
    case CONTEXT_TEN:
         // Wait for COMPARING bit become false. 
         if(ucChanNum == 6){
            if(COMPARING0!= FALSE)
               return RETURNSTATUS_INPROGRESS;
            else{
                if(STATUSOUT0 != TRUE)
                   bFailed = TRUE;
                RtnSts = RETURNSTATUS_COMPLETE;
            }
         }
         else{
            if(COMPARING1!= FALSE)
               return RETURNSTATUS_INPROGRESS;
            else{
                if(STATUSOUT1 != TRUE)
                   bFailed = TRUE;
                RtnSts = RETURNSTATUS_COMPLETE;
            }            
         }
         break;
    case CONTEXT_ELEVEN:
         DIAGON = 0;
         COUNT_UPDATE_FLAGS = 0x00;
         CLEAR_COUNTERS = 0x00;
         OUT_SEN0  = OUT_SEN1  = 0;
         OUT_CTRL0 = OUT_CTRL1 = 0;
         OUT_SET0  = OUT_SET1  = 0;
         if(ucSubCmd != 0)
            Context = CONTEXT_EIGHTEEN;
         if(bFailed)
            RtnSts = DebugPort.PrintString("Failed\n\r\tFCO is not fired after reaching Target Value \n");
         else
            RtnSts = DebugPort.PrintString("Passed");
         break;
    case CONTEXT_TWELVE:
         bFailed = FALSE;
         RtnSts = DebugPort.PrintString("\n\r\tTest SafeStateCtrl...");
         break;
    case CONTEXT_THIRTEEN:
         SAFE_STATE_n = 0;
         if(ucChanNum == 6){
            OUT_SEN0 = 0;
            IdleWait(2);
            if(STATUSOUT0 != 0){
               if(ucSubCmd == 0)
                  Context = CONTEXT_FOURTEEN;
               else
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tExpValue of FCO_0_RDBK:0 ActValue of FCO_0_RDBK:%d \n",STATUSOUT0);
            }
            else
               RtnSts = RETURNSTATUS_COMPLETE;
         }
         else{
            OUT_SEN1 = 0;
            IdleWait(2);
            if(STATUSOUT1 != 0){
               if(ucSubCmd == 0)
                  Context = CONTEXT_FOURTEEN;
               else
                  Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tExpValue of FCO_1_RDBK:0 ActValue of FCO_1_RDBK:%d \n",STATUSOUT1); 
            }
            else
               RtnSts = RETURNSTATUS_COMPLETE;
         }
         break;
    case CONTEXT_FOURTEEN:
         if(ucChanNum == 6){
            OUT_SEN0 = 1;
            IdleWait(2);
            if(STATUSOUT0 != 1){
               RtnSts = DebugPort.PrintString("Failed\n\r\tExpValue of FCO_0_RDBK:1 ActValue of FCO_0_RDBK:%d \n",STATUSOUT0);
            }
            else
               RtnSts = DebugPort.PrintString("Passed");
         }
         else{
            OUT_SEN1 = 1;
            IdleWait(2);
            if(STATUSOUT1 != 1){                  
               RtnSts = DebugPort.PrintString("Failed\n\r\tExpValue of FCO_1_RDBK:1 ActValue of FCO_1_RDBK:%d \n",STATUSOUT1);
            }
            else
               RtnSts = DebugPort.PrintString("Passed");
         }

         if(ucSubCmd == 0)
            Context = CONTEXT_FOURTEEN;
         else
            Context = CONTEXT_EIGHTEEN;
         break;
    case CONTEXT_FIFTEEN:
         OUT_SEN0 = OUT_SEN1 = 0; 
         SAFE_STATE_n = 1;
         RtnSts = DebugPort.PrintString("\n\r\tTest DirectSwCtrl...");
         break;
    case CONTEXT_SIXTEEN:
         SAFE_STATE_n = 1;
         if(ucChanNum == 6){
            OUT_CTRL0 = 1;
            OUT_SET0  = 1;
            IdleWait(2);
            if(STATUSOUT0 != 1){
               Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_0:1 OUT_CTRL_0:1 ExpVal of FCO_0_RDBK:1 ActVal of FCO_0_RDBK:%d",STATUSOUT0);
            }
            else{
               OUT_CTRL0 = 1;
               OUT_SET0  = 0;
               IdleWait(2);
               if(STATUSOUT0 != 0){
                  Context = CONTEXT_EIGHTEEN;
                  RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_0:0 OUT_CTRL_0:1 ExpVal of FCO_0_RDBK:0 ActVal of FCO_0_RDBK:%d",STATUSOUT0);
               }
               else
                  RtnSts = RETURNSTATUS_COMPLETE;
            }
         }
         else{
            OUT_CTRL1 = 1;
            OUT_SET1  = 1;
            IdleWait(2);
            if(STATUSOUT1 != 1){
               Context = CONTEXT_EIGHTEEN;
               RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_1:1 OUT_CTRL_1:1 ExpVal of FCO_1_RDBK:1 ActVal of FCO_1_RDBK:%d",STATUSOUT1);
            }
            else{
               OUT_CTRL1 = 1;
               OUT_SET1  = 0;
               IdleWait(2); 
               if(STATUSOUT1 != 0){
                  Context = CONTEXT_EIGHTEEN;
                  RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_1:0 OUT_CTRL_1:1 ExpVal of FCO_1_RDBK:0 ActVal of FCO_1_RDBK:%d",STATUSOUT1);                     
               }
               else
                  RtnSts = RETURNSTATUS_COMPLETE;
            }
         }
         break;
    case CONTEXT_SEVENTEEN:
         if(ucChanNum == 6){
            OUT_CTRL0 = 0;
            OUT_SET0  = 1;
            IdleWait(2); 
            if(STATUSOUT0 != 0)
               RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_0:1 OUT_CTRL_0:0 ExpVal of FCO_0_RDBK:0 ActVal of FCO_0_RDBK:%d",STATUSOUT0);
            else{
               OUT_CTRL0 = 0;
               OUT_SET0  = 0;
               IdleWait(2);  
               if(STATUSOUT0 != 0)
                  RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_0:0 OUT_CTRL_0:0 ExpVal of FCO_0_RDBK:0 ActVal of FCO_0_RDBK:%d",STATUSOUT0);
               else
                  RtnSts = DebugPort.PrintString("Passed");
            }
         }
         else{
            OUT_CTRL1 = 0;
            OUT_SET1  = 1;
            IdleWait(2);
            if(STATUSOUT1 != 0)
               RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_1:1 OUT_CTRL_1:0 ExpVal of FCO_1_RDBK:0 ActVal of FCO_1_RDBK:%d",STATUSOUT1);
            else{
               OUT_SET1  = 0;
               OUT_CTRL1 = 0;
               IdleWait(2);  
               if(STATUSOUT1 != 0)
                  RtnSts = DebugPort.PrintString("Failed\n\r\tOUT_SET_1:0 OUT_CTRL_1:0 ExpVal of FCO_1_RDBK:0 ActVal of FCO_1_RDBK:%d",STATUSOUT1);                     
               else
                  RtnSts = DebugPort.PrintString("Passed");
            }
         }
         break;
    case CONTEXT_EIGHTEEN:
         OUT_SET0 = OUT_CTRL0 = 0;
         OUT_SET1 =    OUT_CTRL1 = 0;
         SAFE_STATE_n = 0;
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    }
    return AdvanceContext(CONTEXT_EIGHTEEN,Context,RtnSts);
}

/*******************************************************************************
*                                  FrequencyDiagnostics                        *
*                                  ====================                        *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS FrequencyDiagnostics(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucChanNum,ucIntPeriod;
    static FLOAT32 fFreqValue;
    static UINT32 ulMantissa,ulExponent;
    char   ucExponent[7];

    switch(Context){
    case CONTEXT_ZERO:
         ucChanNum  = ucIntPeriod = ulMantissa = ulExponent = 0;
         fFreqValue = 0.0;           
         g_ucSlotInTest = 0;
         g_bFreqValTst  = g_bIPIntProcessed = FALSE;
         for(UINT8 i = 0; i< 7;i++)
             ucExponent[i]= 0;
        
         RtnSts = DebugPort.PrintString("\n\r\tEnter Channel Number(0-7)#:");
         break;
    case CONTEXT_ONE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_TWO:
         ucChanNum = (UINT8)atoi(s_cInputBuffer);
         g_ucSlotInTest = ucChanNum;
         if(ucChanNum > MAXSLOTS){
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ONE;
            return RETURNSTATUS_COMPLETE;
         }
         RtnSts = DebugPort.PrintString("\n\r\tSelect Integration Period \n\r\t25ms(0) 50ms(1) 100ms(2) 200ms(3) 500ms(4) 1s(5) 2s(6):");
         break;
    case CONTEXT_THREE:
         RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
         break;
    case CONTEXT_FOUR:
         ucIntPeriod = (UINT8)atoi(s_cInputBuffer);
         if(ucIntPeriod > (MAXSLOTS-1)){
            DebugPort.PrintString(PRINTSTRING_INVALID);
            Context = CONTEXT_ONE;
            return RETURNSTATUS_COMPLETE;
         }
         FPGA_CTRLREG_IP = 0xFF; // Enable FPGA Interrupts
         // Initialize the Intermediate Counters and FRCs.
         for(UINT8 i=0;i<8;i++){
              INT_COUNTER1[i] = 0;
              INT_COUNTER2[i] = 0;
              INT_FRC1[i]     = 0;
              INT_FRC2[i]     = 0;
         }
         BOX->SetIntPeriod(ucChanNum + 1,(FREQPERIOD)ucIntPeriod);
         g_bFreqValTst = TRUE;         
         RtnSts = RETURNSTATUS_COMPLETE;
         break;
    case CONTEXT_FIVE:
         if(g_bIPIntProcessed){
            // Read Counter Values
            INT_COUNTER1[g_ucSlotInTest] = INT_COUNTER2[g_ucSlotInTest];
            // Read FRC Vaalues
            INT_FRC1[g_ucSlotInTest]     = INT_FRC2[g_ucSlotInTest];
                 
               g_bIPIntProcessed = FALSE;
               RtnSts = RETURNSTATUS_COMPLETE;
         }
         else
           RtnSts = RETURNSTATUS_INPROGRESS;
         break;
    case CONTEXT_SIX:
         if(g_bIPIntProcessed){
              g_bIPIntProcessed = FALSE;
              g_bFreqValTst     = FALSE;
              FPGA_CTRLREG_IP   = 0x00;
              IP_VALID_FLAGS    = 0x00;
              RtnSts = RETURNSTATUS_COMPLETE;
         }
         else
           RtnSts = RETURNSTATUS_INPROGRESS;
         break;
    case CONTEXT_SEVEN:     
         RtnSts = DebugPort.PrintString("\n\r\tCount2 = 0x%08X Count1 = 0x%08X",INT_COUNTER2[g_ucSlotInTest],INT_COUNTER1[g_ucSlotInTest]);
         break;
    case CONTEXT_EIGHT:
         // Re Initialize the FPGA state machine 
         FPGA_RST = 1;
         IdleWait(1);
         FPGA_RST = 0;
         RtnSts = DebugPort.PrintString("\n\r\tFrc2   = 0x%08X Frc1   = 0x%08X",INT_FRC2[g_ucSlotInTest],INT_FRC1[g_ucSlotInTest]);
         break;
    case CONTEXT_NINE:
         // Calculate Actual frequency
         // Freq Value = ((Count2 -Count1) * 10000000)/(Frc2 - Frc1)     
         fFreqValue = (FLOAT32)(INT_COUNTER2[g_ucSlotInTest] - INT_COUNTER1[g_ucSlotInTest]);
         fFreqValue = (fFreqValue * 10000000)/(FLOAT32)(INT_FRC2[g_ucSlotInTest] - INT_FRC1[g_ucSlotInTest]);

         // Calculate mantissa and exponent seperatley and print on hyper terminal.
         ulMantissa = (UINT32)fFreqValue;
         ulExponent = (UINT32)((fFreqValue - floor(fFreqValue)) * 1000000); 
         itoa(ulExponent,ucExponent);
         RtnSts = DebugPort.PrintString("\n\r\tFreq Value = %l.%s",ulMantissa,ucExponent);
    
         break;
    }
    return AdvanceContext(CONTEXT_NINE,Context,RtnSts);
}

#endif
#if defined(IOMTYPE_UIO)
/*******************************************************************************
*                                    ReadFpga                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
 static RETURNSTATUS ReadFpga(VOID){
     RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
     static CONTEXT Context = CONTEXT_ZERO;

     switch(Context){
     case CONTEXT_ZERO:
          RtnSts = DebugPort.PrintString("\n\r\tAddress\tRegister                                 Value");
            break;
     case CONTEXT_ONE:
          RtnSts = DebugPort.PrintString("\n\r\t=======\t================                         =====");
            break;
     case CONTEXT_TWO:
          RtnSts = DebugPort.PrintString("\n\r\t600800 \tFPGA IRQ Status                          0x%04x",
                                        (*(volatile UINT16 *)0x600800));
          break;
     case CONTEXT_THREE:
          RtnSts = DebugPort.PrintString("\n\r\t600802 \tFPGA Bld&Rev REG                         0x%04x",
                                        (*(volatile UINT16 *)0x600802));
            break;
     case CONTEXT_FOUR:
          RtnSts = DebugPort.PrintString("\n\r\t600804 \tHART Control                             0x%04x",
                                        (*(volatile UINT16 *)0x600804));
            break;
     case CONTEXT_FIVE:
          RtnSts = DebugPort.PrintString("\n\r\t600806 \tHART Address Reg P                       0x%04x",
                                        (*(volatile UINT16 *)0x600806));
            break;
     case CONTEXT_SIX:
          RtnSts = DebugPort.PrintString("\n\r\t600808 \tHART Address Reg S                       0x%04x",
                                        (*(volatile UINT16 *)0x600808));
            break;
     case CONTEXT_SEVEN:
          RtnSts = DebugPort.PrintString("\n\r\t60080A \tFlip Flop CR                             0x%04x",
                                        (*(volatile UINT16 *)0x60080A));
            break;
     case CONTEXT_EIGHT:
          RtnSts = DebugPort.PrintString("\n\r\t60080C \tTest Config Toggle                       0x%04x",
                                        (*(volatile UINT16 *)0x60080C));
            break;
     case CONTEXT_NINE:
          RtnSts = DebugPort.PrintString("\n\r\t60080E \tInhibit SW CR                            0x%04x",
                                        (*(volatile UINT16 *)0x60080E));
            break;
     case CONTEXT_TEN:
          RtnSts = DebugPort.PrintString("\n\r\t600200 \tADC ScanReq_fRB_ACurrent_L               0x%04x",
                                        (*(volatile UINT16 *)0x600200));
            break;
     case CONTEXT_ELEVEN:
          RtnSts = DebugPort.PrintString("\n\r\t600202 \tADC ScanReq_fRB_ACurrentP_L              0x%04x",
                                        (*(volatile UINT16 *)0x600202));
            break;
     case CONTEXT_TWELVE:
          RtnSts = DebugPort.PrintString("\n\r\t600204 \tADC ScanReq_RB_ACurrent_L                0x%04x",
                                        (*(volatile UINT16 *)0x600204));
            break;
     case CONTEXT_THIRTEEN:
          RtnSts = DebugPort.PrintString("\n\r\t600206 \tADC ScanReq_RB_DCurrent_L                0x%04x",
                                        (*(volatile UINT16 *)0x600206));
            break;
     case CONTEXT_FOURTEEN:
          RtnSts = DebugPort.PrintString("\n\r\t600208 \tADC ScanReq_RB_DCurrent_Adjust_ComPP_L   0x%04x",
                                        (*(volatile UINT16 *)0x600208));
            break;
     case CONTEXT_FIFTEEN:
          RtnSts = DebugPort.PrintString("\n\r\t60020A \tADC ScanReq_RB_Voltages_L                0x%04x",
                                        (*(volatile UINT16 *)0x60020A));
            break;
     case CONTEXT_SIXTEEN:
          RtnSts = DebugPort.PrintString("\n\r\t600354 \tStatusWord_L                             0x%04x",
                                        (*(volatile UINT16 *)0x600354));
            break;
     case CONTEXT_SEVENTEEN:
          RtnSts = DebugPort.PrintString("\n\r\t600600 \tADC ScanReq_fRB_ACurrent_U               0x%04x",
                                        (*(volatile UINT16 *)0x600600));
            break;
     case CONTEXT_EIGHTEEN:
          RtnSts = DebugPort.PrintString("\n\r\t600602 \tADC ScanReq_fRB_ACurrentP_U              0x%04x",
                                        (*(volatile UINT16 *)0x600602));
            break;
     case CONTEXT_NINETEEN:
          RtnSts = DebugPort.PrintString("\n\r\t600604 \tADC ScanReq_RB_ACurrent_U                0x%04x",
                                        (*(volatile UINT16 *)0x600604));
            break;
     case CONTEXT_TWENTY:
          RtnSts = DebugPort.PrintString("\n\r\t600606 \tADC ScanReq_RB_DCurrent_U                0x%04x",
                                        (*(volatile UINT16 *)0x600606));
            break;
     case CONTEXT_TWENTYONE:
          RtnSts = DebugPort.PrintString("\n\r\t600608 \tADC ScanReq_RB_DCurrent_Adjust_ComPP_U   0x%04x",
                                        (*(volatile UINT16 *)0x600608));
            break;
     case CONTEXT_TWENTYTWO:
          RtnSts = DebugPort.PrintString("\n\r\t60060A \tADC ScanReq_RB_Voltages_U                0x%04x",
                                        (*(volatile UINT16 *)0x60060A));
            break;
     case CONTEXT_TWENTYTHREE:
          RtnSts = DebugPort.PrintString("\n\r\t600754 \tStatusWord_U                             0x%04x",
                                        (*(volatile UINT16 *)0x600754));
            break;
     }
  return AdvanceContext(CONTEXT_TWENTYTHREE,Context,RtnSts);
}
/*******************************************************************************
*                                    ReadCpld                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
 static RETURNSTATUS ReadHEKCpld(VOID){
     RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
     static CONTEXT Context = CONTEXT_ZERO;

     switch(Context){
     case CONTEXT_ZERO:
          RtnSts = DebugPort.PrintString("\n\r\tAddress\tRegister              Value");
            break;
     case CONTEXT_ONE:
          RtnSts = DebugPort.PrintString("\n\r\t=======\t================      =====");
            break;
     case CONTEXT_TWO:
          RtnSts = DebugPort.PrintString("\n\r\t80000  \tModule Number        0x%04x",
                                        (*(volatile UINT16 *)0x80000));
            break;
     case CONTEXT_THREE:
          RtnSts = DebugPort.PrintString("\n\r\t80002  \tSpare1               0x%04x",
                                        (*(volatile UINT16 *)0x80002));
            break;
     case CONTEXT_FOUR:
          RtnSts = DebugPort.PrintString("\n\r\t80004  \tIOL/IOTA Status      0x%04x",
                                        (*(volatile UINT16 *)0x80004));
            break;
     case CONTEXT_FIVE:
          RtnSts = DebugPort.PrintString("\n\r\t80006  \tMiscellaneous Sts    0x%04x",
                                        (*(volatile UINT16 *)0x80006));
            break;
     case CONTEXT_SIX:
          RtnSts = DebugPort.PrintString("\n\r\t80008  \tCPLD Revision        0x%04x",
                                        (*(volatile UINT16 *)0x80008));
            break;
     case CONTEXT_SEVEN:
          RtnSts = DebugPort.PrintString("\n\r\t8000A  \tSpare2               0x%04x",
                                        (*(volatile UINT16 *)0x8000A));
            break;
     case CONTEXT_EIGHT:
          RtnSts = DebugPort.PrintString("\n\r\t8000C  \tSpare3               0x%04x",
                                        (*(volatile UINT16 *)0x8000C));
            break;
     case CONTEXT_NINE:
          RtnSts = DebugPort.PrintString("\n\r\t8000E  \tSpare4               0x%04x",
                                        (*(volatile UINT16 *)0x8000E));
            break;
     case CONTEXT_TEN:
          RtnSts = DebugPort.PrintString("\n\r\t80010  \tScratch Pad          0x%04x",
                                        (*(volatile UINT16 *)0x80010));
            break;
     case CONTEXT_ELEVEN:
          RtnSts = DebugPort.PrintString("\n\r\t80012  \tHART Mux Enable      0x%04x",
                                        (*(volatile UINT16 *)0x80012));
            break;
     case CONTEXT_TWELVE:
          RtnSts = DebugPort.PrintString("\n\r\t80014  \tGeneral Purpose      0x%04x",
                                        (*(volatile UINT16 *)0x80014));
            break;
     case CONTEXT_THIRTEEN:
          RtnSts = DebugPort.PrintString("\n\r\t         DIP(B9):%d RIP(B8):%d",GPREG.B9,GPREG.B8);
            break;
     }
    
  return AdvanceContext(CONTEXT_THIRTEEN,Context,RtnSts);
}
/*******************************************************************************
*                                    RedunSwitchTest                           *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
 static RETURNSTATUS RedunSwitchTest(VOID) {
     RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
     static CONTEXT Context = CONTEXT_ZERO;
     static BOOL bResult;

     switch(Context){
     case CONTEXT_ZERO:
            bResult = FALSE;
            RtnSts  = DebugPort.PrintString("\n\r\tINHOUT    INHIN(Exp)    INHIN(Act)");
            break;
     case CONTEXT_ONE:
            INHSWCR.FPGAWORDREG = 0x0100;
            IdleWait(1000);
            if(!INHIN)
               bResult = TRUE;
            RtnSts = DebugPort.PrintString("\n\r\t   1          1            %d",INHIN);
            break;
     case CONTEXT_TWO:
            INHSWCR.FPGAWORDREG = 0x0000;
            IdleWait(1000);
            if(INHIN)
               bResult = TRUE;
            RtnSts = DebugPort.PrintString("\n\r\t   0          0            %d",INHIN);
            break;
     case CONTEXT_THREE:
            if(bResult)
                RtnSts = DebugPort.PrintString("\n\r\tTest Failed....");
            else
                RtnSts = DebugPort.PrintString("\n\r\tTest Passed....");
            break;
     }

  return AdvanceContext(CONTEXT_THREE,Context,RtnSts);
}
/*******************************************************************************
*                            GetAnalogInputs                                   *
*                            ===============                                   *
* PURPOSE: Scan the ADC raw count for the selected channel by the user and     *
*          display it. User can get single channel data or all 32 channels     *
*          data at a time                                                      *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS GetAnalogInputs(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucCmdChanNum, ucCurChanNum;

    switch(Context) {

        case CONTEXT_ZERO:
            ucCmdChanNum = 0;
            ucCurChanNum = 1;

            // request channel number form the user
            RtnSts = DebugPort.PrintString("\n\r\tChannel Number(0 for all)#:");
            break;

        case CONTEXT_ONE:
            // collect the input from the user
            RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
            break;

        case CONTEXT_TWO:
            ucCmdChanNum = (UINT8)atoi(s_cInputBuffer);

            if(0 == ucCmdChanNum) {
                // drive all DACs to 100% to setup for AI
                for(UINT8 i = 1; i <= MAXSLOTS; i++) {
                        FPGA.DriveDAC(i, 0x0FFF);
                }

                // issue scan requests for all 32 channels
                FPGA.IssueScanRequest(eIoBoard1, eFilteredAnalogCurrent, 0xFFFF);
                FPGA.IssueScanRequest(eIoBoard2, eFilteredAnalogCurrent, 0xFFFF);
            }
            else {
                // drive DAC to 100% to setup for AI
                FPGA.DriveDAC(ucCmdChanNum, 0x0FFF);

                // issue scan requests for this channel
                if(ucCmdChanNum <= 16) {
                    FPGA.IssueScanRequest(eIoBoard1, eFilteredAnalogCurrent, 1 << (ucCmdChanNum-1));
                }
                else {
                    FPGA.IssueScanRequest(eIoBoard2, eFilteredAnalogCurrent, 1 << (ucCmdChanNum-17));
                }
            }
            RtnSts = RETURNSTATUS_COMPLETE;
            break;


        case CONTEXT_THREE:
            // wait for ADC scans to complete
            if(FPGA.IsScanComplete(eIoBoard1) && FPGA.IsScanComplete(eIoBoard2)) {
                RtnSts = RETURNSTATUS_COMPLETE;
            }
            else {
                RtnSts = RETURNSTATUS_INPROGRESS;
            }
            break;

        case CONTEXT_FOUR:
            if(0 == ucCmdChanNum) {
                // need to loop through all 32 channels
                UINT16 uiAdcData = FPGA.Read_fRB_ACurrent(ucCurChanNum);

                if (ucCurChanNum & 0x01) {
                    RtnSts = DebugPort.PrintString("\n\r\tChannel %2d   : 0x%04x", ucCurChanNum, uiAdcData);
                }
                else {
                    RtnSts = DebugPort.PrintString("\t\tChannel %2d    : 0x%04x", ucCurChanNum, uiAdcData);
                }

                // increment current channel number if PrintString completed
                if (RETURNSTATUS_COMPLETE == RtnSts) {
                    ucCurChanNum++;
                    if (ucCurChanNum <= MAXSLOTS) {
                        RtnSts = RETURNSTATUS_INPROGRESS;
                    }
                }
            }
            else {
                UINT16 uiAdcData = FPGA.Read_fRB_ACurrent(ucCmdChanNum);
                RtnSts = DebugPort.PrintString("\t\tChannel %2d   : 0x%04x", ucCmdChanNum, uiAdcData);
            }
            break;
    }

    return AdvanceContext(CONTEXT_FOUR,Context,RtnSts);
}
/*******************************************************************************
*                               SpinAnalogInput                                *
*                               ===============                                *
* PURPOSE: Scan the ADC raw count for the single channel by X number of times  * 
*          selected by user and display Low, High and Average values.          *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/ 
static RETURNSTATUS SpinAnalogInput(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucCmdChanNum;
    static UINT16 uiCmdNumSamples, uiCurSampleCnt, uiHiSample, uiLoSample;
    static FLOAT32 ufAccumalator;

    switch(Context) {

        case CONTEXT_ZERO:
            ucCmdChanNum = 0;
            uiCmdNumSamples = 0;
            uiCurSampleCnt = 0;

            ufAccumalator = 0.0;
            uiLoSample = 0xFFFF;
            uiHiSample = 0;

            // request channel number from the user
            RtnSts = DebugPort.PrintString("\n\r\tEnter the Slot number(1-32)#:");
            break;

        case CONTEXT_ONE:
            // collect user input
            RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);

            // setup for AI
            if (RETURNSTATUS_COMPLETE == RtnSts) {
                ucCmdChanNum = (UINT8)atoi(s_cInputBuffer);
                FPGA.DriveDAC(ucCmdChanNum, 0x0FFF);
            }
            break;

        case CONTEXT_TWO:
            // request number of samples from the user
            RtnSts = DebugPort.PrintString("\n\r\tHow many samples#:");
            break;

        case CONTEXT_THREE:
            // collect user input
            RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);

            if(RtnSts == RETURNSTATUS_COMPLETE) {
                uiCmdNumSamples = (UINT16) atoi(s_cInputBuffer);

                // issue scan requests for this channel
                if(ucCmdChanNum <= 16) {
                    FPGA.IssueScanRequest(eIoBoard1, eFilteredAnalogCurrent, 1 << (ucCmdChanNum-1));
                }
                else {
                    FPGA.IssueScanRequest(eIoBoard2, eFilteredAnalogCurrent, 1 << (ucCmdChanNum-17));
                }
            }
            break;

        case CONTEXT_FOUR:
            // wait for ADC scan to complete
            if(FPGA.IsScanComplete(eIoBoard1) && FPGA.IsScanComplete(eIoBoard2)) {
                // need to loop through all 32 channels
                UINT16 uiAdcData = FPGA.Read_fRB_ACurrent(ucCmdChanNum);
                RtnSts = DebugPort.PrintString("\n\r\t0x%04x", uiAdcData);

                if (RETURNSTATUS_COMPLETE == RtnSts) {
                    // increment sample count
                    uiCurSampleCnt++;

                    // maintain stats
                    ufAccumalator += uiAdcData;
                    if(uiAdcData > uiHiSample) {
                        uiHiSample = uiAdcData;
                    }
                    if(uiAdcData < uiLoSample) {
                        uiLoSample = uiAdcData;
                    }

                    // setup for next sample
                    if (uiCurSampleCnt < uiCmdNumSamples) {
                        // issue scan requests for this channel
                        if(ucCmdChanNum <= 16) {
                            FPGA.IssueScanRequest(eIoBoard1, eFilteredAnalogCurrent, 1 << (ucCmdChanNum-1));
                        }
                        else {
                            FPGA.IssueScanRequest(eIoBoard2, eFilteredAnalogCurrent, 1 << (ucCmdChanNum-17));
                        }
    
                        RtnSts = RETURNSTATUS_INPROGRESS;
                    }
                }
            }
            else {
                RtnSts = RETURNSTATUS_INPROGRESS;
            }
            break;

        case CONTEXT_FIVE:
            {
                // calculate average and print summary
                UINT16 uiAvg = (UINT16)(ufAccumalator / uiCmdNumSamples);
                RtnSts = DebugPort.PrintString("\n\n\r\tLo:0x%04x Hi:0x%04x Avg:0x%04x",uiLoSample, uiHiSample, uiAvg);
            }
            break;
     }

    return AdvanceContext(CONTEXT_FIVE,Context,RtnSts);
}
/*******************************************************************************
*                                 DriveDigitalOutputs                          *
*                                 ===================                          *
* PURPOSE: Drive the DO outputs to ON or OFF state for individual Channel or   *
*          all 32 channels at a time. User is allowed to select the channel    *
*          number (1-32) and output value (ON or OFF) to set.If channel number *
*          is 0 means drive all 32 channels with same output value             *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS DriveDigitalOutputs(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucCmdChanNum;
    static UINT32 ulDoOutputData;

    switch (Context) {

        case CONTEXT_ZERO:
            ucCmdChanNum = 0;
            ulDoOutputData = 0;

            // request channel number from the user
            RtnSts = DebugPort.PrintString("\n\r\tChannel Number(0 for all)#:");
            break;

        case CONTEXT_ONE:
            // collect user input
            RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
            if (RETURNSTATUS_COMPLETE == RtnSts) {
                ucCmdChanNum = (UINT8)atoi(s_cInputBuffer);
            }
            break;

        case CONTEXT_TWO:
            if (0 == ucCmdChanNum) {
                // clear all the AO output DACs
                FPGA.ClearDACs();

                // request the output data from the user
                RtnSts = DebugPort.PrintString("\n\r\tEnter Data(32 bit)#:0x");
            }
            else if (ucCmdChanNum > MAXSLOTS) {
                RtnSts = DebugPort.PrintString(PRINTSTRING_INVALID);
                if (RETURNSTATUS_COMPLETE == RtnSts) {
                    // return user to first step
                    Context = CONTEXT_ZERO;
                    RtnSts = RETURNSTATUS_INPROGRESS;
                }
            }
            else {
                // clear this channel's AO output DAC
                FPGA.DriveDAC(ucCmdChanNum, 0);

                // request the output data from the user
                RtnSts = DebugPort.PrintString("\n\r\tEnter OFF(0) or ON(1)#:");
            }
            break;

        case CONTEXT_THREE:
            // collect user input
            RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
            if (RETURNSTATUS_COMPLETE == RtnSts) {
                ulDoOutputData = (UINT32)atoh(s_cInputBuffer);
            }
            break;

        case CONTEXT_FOUR:
            if (0 == ucCmdChanNum) {
                // set all digital outputs
                FPGA.WriteDigitalOutputAll(0xFFFFFFFF, ulDoOutputData);
            }
            else {
                // set single channel's digital output
                BOOL bSO = (0 == ulDoOutputData) ? FALSE : TRUE;
                FPGA.WriteDigitalOutput(ucCmdChanNum, bSO);
            }
            RtnSts = RETURNSTATUS_COMPLETE;
            break;
    }

    return AdvanceContext(CONTEXT_FOUR, Context, RtnSts);
}
/*******************************************************************************
*                                 DriveDACCount                                *
*                                 ============                                 *
* PURPOSE: Drive the DAC count for the selected channel or to all the 32       *
*          channels provided by user and measure equivalent current flows      *
*          across the screws using current meter                               *
* ARGUMENTS: None.                                                             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS DriveDACCount(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 ucCmdChanNum;
    static UINT16 uiCmdAdcCount;

    switch (Context) {

        case CONTEXT_ZERO:
            ucCmdChanNum = 0;
            uiCmdAdcCount = 0;
            
            // request channel number from the user
            RtnSts = DebugPort.PrintString("\n\r\tChannel Number(0 for all)#:");
            break;

        case CONTEXT_ONE:
            RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
            if (RETURNSTATUS_COMPLETE == RtnSts) {
                ucCmdChanNum = (UINT8)atoi(s_cInputBuffer);
            }
            break;

        case CONTEXT_TWO:
            if (0 == ucCmdChanNum) {
                // clear all the DO outputs
                FPGA.WriteDigitalOutputAll(0xFFFFFFFF, 0);

                // request the output data from the user
                RtnSts = DebugPort.PrintString("\n\r\tEnter the DAC Count#:0x");
            }
            else if (ucCmdChanNum > MAXSLOTS) {
                RtnSts = DebugPort.PrintString(PRINTSTRING_INVALID);
                if (RETURNSTATUS_COMPLETE == RtnSts) {
                    // return user to first step
                    Context = CONTEXT_ZERO;
                    RtnSts = RETURNSTATUS_INPROGRESS;
                }
            }
            else {
                // clear this channel's DO output
                FPGA.WriteDigitalOutput(ucCmdChanNum, FALSE);

                // request the output data from the user
                RtnSts = DebugPort.PrintString("\n\r\tEnter the DAC Count#:0x");
            }
            break;

        case CONTEXT_THREE:
            // collect the user input
            RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
            if (RETURNSTATUS_COMPLETE == RtnSts) {
                uiCmdAdcCount = (UINT16)atoh(s_cInputBuffer);

                // write to AO output DAC(s)
                if (0 == ucCmdChanNum) {
                    for (UINT8 chan = 1; chan <= MAXSLOTS; chan++) {
                        FPGA.DriveDAC(chan, uiCmdAdcCount);
                    }
                }
                else {
                    FPGA.DriveDAC(ucCmdChanNum, uiCmdAdcCount);
                }
            }
            break;
    }
 
    return AdvanceContext(CONTEXT_THREE, Context, RtnSts);
}
/*******************************************************************************
*                                 Calibrate5VRefVoltage                        *
*                                 =====================                        *
* PURPOSE: Calibrate 5V reference source for IO Board 1 and IO Board 2         *
* ARGUMENTS: None.                                                             *
* RETURN: Success or Failure                                                   *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS Calibrate5VRefVoltage(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;
    static UINT8 uiCmdIoBoard;

    switch (Context) {

        case CONTEXT_ZERO:
            uiCmdIoBoard = 0;

            // request IOBOARD from the user
            RtnSts = DebugPort.PrintString("\n\r\tSelect IoBoard0(0) or IoBoard1(1): ");
            break;

        case CONTEXT_ONE:
            // collect user input
            RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
            if (RETURNSTATUS_COMPLETE == RtnSts) {
                uiCmdIoBoard = (UINT8)atoi(s_cInputBuffer);
            }
            break;

        case CONTEXT_TWO:
            // calibrate
            FPGA.CalibrateFiveVoltRef((IOBOARD)uiCmdIoBoard, TRUE);
            RtnSts = RETURNSTATUS_COMPLETE;
            break;
    }

    return AdvanceContext(CONTEXT_TWO, Context, RtnSts);
}
/*******************************************************************************
*                                   InitSPI                                    *
*                                   ========                                   *
* PURPOSE:   Initializes the SPI controller in the FPGA                        *
* ARGUMENTS: None                                                              *
* RETURN:    None                                                              *
* NOTES:     After setting-up the SPI controller to communicate with the       *
*            digital thermometer, the SPI controller configuration is read and *
*            output to the serial debug port                                   *
*******************************************************************************/
static RETURNSTATUS InitSPI(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

    switch (Context) {

        case CONTEXT_ZERO:
            // reset the SPI controller
            FPGA.InitSpi();
            RtnSts = DebugPort.PrintString("\n\r\tSPI Initialized ...");
            break;

        // read the SPI configuration from the FPGA, and output to the debug port
        case CONTEXT_ONE:
            RtnSts = DebugPort.PrintString("\n\r\t4001B0 \tIntr Global Enbl 0x%02x", THERM_SPI.IGER);
            break;

        case CONTEXT_TWO:
            RtnSts = DebugPort.PrintString("\n\r\t4001B1 \tIntr Register    0x%02x", THERM_SPI.IR);
            break;

        case CONTEXT_THREE:
            RtnSts = DebugPort.PrintString("\n\r\t4001B2 \tIntr Enbl        0x%02x", THERM_SPI.IER);
            break;

        case CONTEXT_FOUR:
            RtnSts = DebugPort.PrintString("\n\r\t4001B3 \tCtrl Reg Low     0x%02x", THERM_SPI.CRL);
            break;

        case CONTEXT_FIVE:
            RtnSts = DebugPort.PrintString("\n\r\t4001B4 \tCtrl Reg High    0x%02x", THERM_SPI.CRH);
            break;

        case CONTEXT_SIX:
            RtnSts = DebugPort.PrintString("\n\r\t4001B5 \tStatus Register  0x%02x", THERM_SPI.SR);
            break;

        case CONTEXT_SEVEN:
            RtnSts = DebugPort.PrintString("\n\r\t4001B6 \tTX FIFO not read\n\r\t4001B7 \tRX FIFO not read");
            break;

        case CONTEXT_EIGHT:
            RtnSts = DebugPort.PrintString("\n\r\t4001B8 \tSlave Select     0x%02x", THERM_SPI.SSR);
            break;
    }

    return AdvanceContext(CONTEXT_EIGHT, Context, RtnSts);
}
/*******************************************************************************
*                                  ConfigTherm                                 *
*                                   ========                                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ConfigTherm(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

    switch (Context) {
        case CONTEXT_ZERO:
            // request the configuration byte from the user
            RtnSts = DebugPort.PrintString("\n\r\tConfiguration byte (e.g. 0xE8): 0x");
            break;

        case CONTEXT_ONE:
            // collect the user's input from the debug port
            RtnSts = DebugPort.GetInput(s_cInputBuffer, SMALL_INPUT_BUFFER_SIZE);
            break;

        case CONTEXT_TWO:
            {
                UINT8 writeConfigByte = atoh(s_cInputBuffer);

                // configure the thermometer
                FPGA.ConfigureThermometer(writeConfigByte);

                RtnSts = RETURNSTATUS_COMPLETE;
            }
            break;

        case CONTEXT_THREE:
            RtnSts = DebugPort.PrintString("\n\r\tThermometer configuration complete");
            break;
    }

    return AdvanceContext(CONTEXT_THREE, Context, RtnSts);
}
/*******************************************************************************
*                                   ReadTherm                                  *
*                                   ========                                   *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
static RETURNSTATUS ReadTherm(VOID) {
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;
    static CONTEXT Context = CONTEXT_ZERO;

    static FLOAT32 temperature;
    static UINT8 configByte;

    switch (Context) {

        case CONTEXT_ZERO:
            configByte = 0;
            temperature = FPGA.ReadThermometer(&configByte);
            RtnSts = RETURNSTATUS_COMPLETE;
            break;

        case CONTEXT_ONE:
            RtnSts = DebugPort.PrintString("\n\r\tTemperature: %f   ConfigByte: 0x%02x", temperature, configByte);
            break;
    }

    return AdvanceContext(CONTEXT_ONE, Context, RtnSts);
}
#endif // IOMTYPE_UIO

/*******************************************************************************
*                               DebugCmdHandler                                *
*                               ===============                                *
* PURPOSE:                                                                     *
*    Process the input from debug terminal.                                    *
* ARGUMENTS:                                                                   *
*    a_strDebugCmd - debug command.                                            *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function will be invoked by the debug task.                          *
*******************************************************************************/
RETURNSTATUS DebugCmdHandler(const CHAR *a_strDebugCmd) {
    typedef struct tagDebugCmdTbl {
        const CHAR      *strCmd;
        RETURNSTATUS    (*pHandler)(VOID);
    } DEBUG_CMDTBL;

    DEBUG_CMDTBL DebugCmdTbl[] = {
        "clear",    StartupScreen,
        "ver",      PrintVersion,
        "bkgd",     ChangeBkgd,
        "pget",     ReadDb,
        "pset",     WriteDb,
        "mget",     ReadMemory,
        "mset",     WriteMemory,
        "port",     DisplayPorts,
        "iol",      TestIolink,
        "reboot",   TestReboot,
        "stat",     PrintStat,
        "kill",     KillIom,
        "mtst",     MemoryTest,
#if !(defined(IOMTYPE_DO) || defined(IOMTYPE_DISOE))
        "wdt",      TestWatchdog,
        "swbupreq", BackUpRequest,
        "testdip",  TestDipSignal,
#endif
#if !AIAO
        "rdbk",     ReadBack,
#endif
#if HEK
        "rdfpga",   ReadFpga,
  #if !(defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
        "rdcpld",   ReadHEKCpld,
    #if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
        "eepread",  ReadEEPROM,
        "eepwrite", WriteEEPROM,
    #endif
    #ifndef IOMTYPE_LLMUX
        "hmsts",    HartModemStatus,
    #endif
        "tpp",      TestPrivatePath,  
  #endif
#endif
#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        "diip",     TestDiInputs,
#endif
#ifdef IOMTYPE_DO
        "holdout",  TestHoldOut,
#endif
#ifdef IOMTYPE_AIH
        "getai",    GetAnalogInputs,
        "spinai",   SpinAnalogInput,
#if !LOWCOST
        "syncai",   SyncAnalogInput,
#else
        "adcrw",    AdcRegWrite,
        "adcrr",    AdcRegRead,
#endif
        "spinpv",   SpinPvRaw,
#endif
#ifdef IOMTYPE_AOH
        "drvop",    DriveOp,
        "drvcount", DriveCount,
        "togglesw", ToggleSwitch,
        "refresh",  ChangeRefresh,
        "lpbk",     LoopbackTest,
        "atod",     GetLoopbackDACCount,
        "redswtest",RedunSwitchTest,
#endif
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_UIO))
        "walkdac",  WalkDacTest,
#endif
#ifdef IOMTYPE_LLMUX
        "sendmsg",  SendFtaMessage,
        "ftascan",  ChangeFtaScan,
#endif
#ifdef IOMTYPE_PI
        "redswtest",RedunSwitchTest,
        "testfpgacon", TestFpgaConnectivity,
        "cntdiag",  CounterDiagnostics,
        "testfco",  FastCutOffTest,
        "freqdiag", FrequencyDiagnostics,
#endif
#ifdef IOMTYPE_UIO
        "rdcpld",   ReadHEKCpld,
        "redswtest",RedunSwitchTest,  
        "getai",    GetAnalogInputs,
        "spinai",   SpinAnalogInput,        
        "smod",     ToggleSwitch, 
        "drvdo",    DriveDigitalOutputs,
        "drvao",    DriveDACCount,
        "calib",    Calibrate5VRefVoltage, 
        "initspi",  InitSPI,
        "cfgtherm", ConfigTherm,
        "readtherm",ReadTherm,
#endif
// PMIO Redesign related debug function pointers
#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG)
        "dpa",      PrintDPA,
        "dump",     GetDump,
        "signals",  PrintSignals,        
        "xread",    ReadxRAM,
        "xwrite",   WritexRAM,
        "xfill",    FillxRAM,                        
        "fails",    GetFails,
        "pgrp",     GetPgrp,
#if defined(IOPTYPE_HLAI)
        "alm",      AlarmInfo,
#endif //#if defined(IOPTYPE_HLAI)
#if defined(IOMTYPE_DO)
        "doop",     GetDoOutputs,
       //"switch",   GetSwitchStatus,
#endif //#if defined(IOMTYPE_DO)
#if defined(IOPTYPE_DI)
       "didump",    GetDumpDi,
#endif
#endif //#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG)
        NULL,       NULL
    };


    UINT8 ucCount = 0;
    while (DebugCmdTbl[ucCount].strCmd > NULL) {
        if (strcmp(a_strDebugCmd,DebugCmdTbl[ucCount].strCmd)) {
            if (RETURNSTATUS_INPROGRESS == (*(DebugCmdTbl[ucCount].pHandler))()) {
                return RETURNSTATUS_INPROGRESS;
            }
            break;
        }
        ucCount++;
    }

    if (NULL == DebugCmdTbl[ucCount].strCmd) {
        // if command wask not found in the table, 
        // check for additional commands below.

        if (strcmp(g_cRebootTestString,"reboot")) {
            sTestRebootContext = CONTEXT_ONE;
            if (RETURNSTATUS_INPROGRESS == TestReboot()) {
                return RETURNSTATUS_INPROGRESS;
            }
            // Clear the reboot section string
            strcpy(g_cRebootTestString,"      ");
            sTestRebootContext = CONTEXT_ZERO;
        }
        #if !(defined(IOMTYPE_DO) || defined(IOMTYPE_DISOE))
        else if(strcmp(g_cRebootTestString,"testdip")){
           sTestRebootContext = CONTEXT_THREE;
           if (RETURNSTATUS_INPROGRESS == TestDipSignal()) {
               return RETURNSTATUS_INPROGRESS;
           }
           // Clear the reboot section string
           strcpy(g_cRebootTestString,"      ");
           sTestRebootContext = CONTEXT_ZERO;
        }
        #endif
        #if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)) && AIAO 
        else if (strcmp(a_strDebugCmd,"hlpbk")) {
#if !LOWCOST
            //Setting the flag HartLoopBkTestInProgress ensures that Fault handler
            //is not invoked when Hart Loopback test is in progress
            HartLoopBkTestInProgress = (RETURNSTATUS_INPROGRESS == BOX->HartLoopBackTest());
            if (TRUE == HartLoopBkTestInProgress) {
                return RETURNSTATUS_INPROGRESS;
            }
#else
            while (RETURNSTATUS_COMPLETE != DebugPort.PrintString(
            "\n\r\tNot Applicable for LowCost"));
#endif
        }
        else if (strcmp(a_strDebugCmd, "calib")) {
            #ifdef IOMTYPE_AIH
            ((clsAihBoxSlot *)pDatabase[0])->SetCalibAll(TRUE); 
            #elif defined(IOMTYPE_AOH)
            ((clsAohBoxSlot *)pDatabase[0])->SetCalibAll(TRUE); 
            #endif
            TaskScheduler.RunTask(TASKID_CALIBTASK);
        }
        #endif
        else if (NULLCHAR != *a_strDebugCmd) {
            while (RETURNSTATUS_COMPLETE != DebugPort.PrintString(
            "\n\r\tUnknown command!"));
        }
    }
    
    while (RETURNSTATUS_COMPLETE != DebugPort.PrintString(g_strDebugPrompt));
    return RETURNSTATUS_COMPLETE;
}
/*******************************************************************************
*                                  DebugTask                                   *
*                                  =========                                   *
* PURPOSE:                                                                     *
*    Process the input from debug terminal.                                    *
* ARGUMENTS: None.                                                             *
* RETURN: Task return status to the scheduler.                                 *
*******************************************************************************/
TASKRETURN DebugTask(TASKCONTEXT a_Context) {
    TASKRETURN TaskReturn;
    TaskReturn.ucSuspendTime = 0;
    // Debug task never terminates. After each cycle of execution it suspends.
    TaskReturn.TaskReturnState = TASKRETURNSTATE_SUSPEND;
    switch (a_Context) {
    case TASKCONTEXT_ZERO: // CONTEXT_ZERO executes only during startup.
        TaskReturn.TaskContext = TASKCONTEXT_ZERO;
        
        if (0 == *g_strDebugPrompt) {
            // Initialize prompt if it has not been done yet.
            // A hardfail in startup could have initialized it.
            #ifdef IOMTYPE_AIH
            strcpy(g_strDebugPrompt,"\n\rAIH >");
            #endif
            #ifdef IOMTYPE_AOH
            strcpy(g_strDebugPrompt,"\n\rAOH >");
            #endif
            #if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
            strcpy(g_strDebugPrompt,"\n\rDI  >");
            #endif
            #ifdef IOMTYPE_DO
            strcpy(g_strDebugPrompt,"\n\rDO  >");
            #endif
            #ifdef IOMTYPE_LLMUX
            strcpy(g_strDebugPrompt,"\n\rLMX >");
            #endif
            #ifdef IOMTYPE_PI
            strcpy(g_strDebugPrompt,"\n\rPI  >");
            #endif
            #ifdef IOMTYPE_UIO
            strcpy(g_strDebugPrompt,"\n\rUIO >");
            #endif            
        }
        else {
          /* ***************** It causes Shutdown ****************** */
            // Module was hardfailed but the initialization was
            // allowed to continue for debugging. Disable IOL
            // and switch ON the red light.
            /*
            #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
            if(FALSE == IsFpgaS2) // S3 FPGA
            {              
                P_INTC.IPRK.BIT.LOW  = 0;    // Shutdown IOL.
            }
            else //if(TRUE = IsFpgaS2)
            #endif
            {
                IPRI_IOL  = 0;    // Shutdown IOL.    
            }
            */            
            //IPRI_BLINK = 0;   // Stop LED refreshing.
            //LED_PINS = STATUSLED_RED;  
        }

        if (RETURNSTATUS_INPROGRESS == StartupScreen()) {
            // Suspend the task.
            return TaskReturn;
        }
        while (RETURNSTATUS_INPROGRESS == DebugCmdHandler(""));
        SCIC1_RE = 1;  // Enable SCI1 receiver.  
    case TASKCONTEXT_ONE: // CONTEXT_ONE executes multiple times to
        // receive the user input from debug terminal.
        TaskReturn.TaskContext = TASKCONTEXT_ONE;
        if (RETURNSTATUS_COMPLETE == 
            DebugPort.GetInput(s_cCommandBuffer,LARGE_INPUT_BUFFER_SIZE)) {
            // Input is complete. Process the received command string.
            TaskReturn.TaskContext = TASKCONTEXT_TWO;
        }
        // Suspend the task.
        return TaskReturn;
    case TASKCONTEXT_TWO: // CONTEXT_TWO executes multiple times 
        // until debug command execution is complete.
        TaskReturn.TaskContext = TASKCONTEXT_TWO;
        if (RETURNSTATUS_COMPLETE == DebugCmdHandler(s_cCommandBuffer)) {
            TaskReturn.TaskContext = TASKCONTEXT_ONE;
        }
        // Suspend the task.
        return TaskReturn;
    }
    // The execution should never reach here.
    HardFail(HF_INVPROGRAMEXEC, DEBUG_CPP, __LINE__);
    TaskReturn.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    return TaskReturn;
}

