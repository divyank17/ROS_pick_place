/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : dimain.cpp                                                  *
*    Description : Digital Input module application specific startup code.     *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "dimain.h"
#include "iol.hpp"
/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN DiagnosticTask(TASKCONTEXT);
#ifdef IOMTYPE_DISOE
extern TASKRETURN EventManagerTask(TASKCONTEXT);
#endif
#ifdef DEBUG
    extern TASKRETURN DebugTask(TASKCONTEXT);
#endif
/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
WRITEINPROGRESS  WriteInProgress;
#ifdef DEBUG
    clsDebugPort DebugPort;
#endif

//To Retain the tracelogs at Reset
#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section

clsTaskScheduler TaskScheduler;
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;

// Pointers to database objects
clsIomSlot *pDatabase[MAXSLOTS + 1];

// Database Memory
UINT16 ucIomDbMemory[DIBOXSLOT_SIZE + (MAXSLOTS * DISLOT_SIZE)];

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//NOTE:
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                            WriteDatabaseTask
                                           ,LowPriorityTask
                                           ,EventRecoveryTask
                                           ,DiagnosticTask
#ifdef IOMTYPE_DISOE
                                           ,EventManagerTask
#endif
#ifdef DEBUG
                                           ,DebugTask
#endif
};

 
/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
*    Application specific startup code.                                        *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function is called by the PowerOn reset vector.                      *
*******************************************************************************/
VOID main(VOID) 
{        
    UINT8 ProductCode = *((UINT8*)(MODULEINFO_START_ADDRESS + HW_PROD_CODE_OFFSET));
    RDBK_SEL = RDBK_BANK2; // Select bank for reading DI_IOTA bits
    switch (DI_IOTA) {
#ifdef IOMTYPE_DI
        case DI_IOTA_24V:
        case DI_IOTA_24V_IS:
            if(ProductCode == PRODCODE_DI_24V_LC_S8)
                pDatabase[0] = new clsDiBoxSlot(MODLTYPE_DIL_S8);
            else
                pDatabase[0] = new clsDiBoxSlot(MODLTYPE_DIL);
            TraceLog.AddToTrace(TRACEID_GENERIC,bcDi24VIom,BOX->GetDPA());
            break;
        case DI_IOTA_110V:
            pDatabase[0] = new clsDiBoxSlot(MODLTYPE_DIH);
            TraceLog.AddToTrace(TRACEID_GENERIC,bcDi110VIom,BOX->GetDPA());
            break;
        case DI_IOTA_240V:
            pDatabase[0] = new clsDiBoxSlot(MODLTYPE_DIH);
            TraceLog.AddToTrace(TRACEID_GENERIC,bcDi240VIom,BOX->GetDPA());
            break;
#endif
#ifdef IOMTYPE_DISOE
        case DISOE_IOTA_24V:
        case DISOE_IOTA_24V_IS:
            if((ProductCode != PRODCODE_DISOE_S8) && (ProductCode != PRODCODE_DISOE_LC_S8))
                pDatabase[0] = new clsDiBoxSlot(MODLTYPE_DISOE);
            else
                pDatabase[0] = new clsDiBoxSlot(MODLTYPE_DISOE_S8);
            TraceLog.AddToTrace(TRACEID_GENERIC,bcDisoeIom,BOX->GetDPA());
            break;
#endif
        default:
            HardFail(HF_BADPROGRAMJUMP,DIMAIN_CPP,__LINE__);
    }

    // Create box and slot database objects
    for (UINT8 ucSltNm = 0; ucSltNm < MAXSLOTS; ucSltNm++) {
        pDatabase[ucSltNm + 1] = new(ucSltNm) clsDiSlot(ucSltNm + 1);
#if defined(IOPTYPE_DI)
        // Checkpoint param restoring from xRAM
        pDatabase[ucSltNm + 1]->PmioCheckPointRestore();
#endif
    }
    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();

    // Initialize all periodic tasks
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
                                        DMCPERIOD_LPTASK);
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
                                        DMCPERIOD_DIAGTASK);
#ifdef IOMTYPE_DISOE
    // start the event manager task
    TaskScheduler.RunTask(TASKID_EVMTASK);
#endif
    

#ifdef DEBUG
   // Set the Debug Task to RUN State
    TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif

    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}
/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE:                                                                     *
*    Demo purpose task code.                                                   *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
* Runs Task every 1 seconds,can view LowPriorityTask over Debug terminal       *
* to identify the task                                                         *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}

