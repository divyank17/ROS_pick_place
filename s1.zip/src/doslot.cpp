/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : doslot.cpp                                                  *
*    Description : Class clsDoSlot definition.                                 *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "doslot.hpp"

#if defined(IOMTYPE_UIO)
#include "uioboxslot.hpp"
#else
#include "doboxslot.hpp"
#endif

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
//PARAMETER NUMBER CONTANTS
#if defined(IOMTYPE_UIO)
#define PARAMID_DOTYPE       51
#define PARAMID_OP           54
#define PARAMID_PERIOD       55
#define PARAMID_PNTTYPE      57
#define PARAMID_PTEXECST     58
#define PARAMID_INITREQ      59
#define PARAMID_SLOTSFBT     62
#define PARAMID_SO           63
#define PARAMID_STDBYMAN     64
#define PARAMID_AOSDATA      65
#define PARAMID_SLTCHKPNT    66
#define PARAMID_OPTDIR       67
#define PARAMID_ONPULSE      68
#define PARAMID_OFFPULSE     69
#define PARAMID_PWMINITR     71
#define PARAMID_MODE         72
#define PARAMID_NMODE        73
#define PARAMID_MODEPERM     74
#define PARAMID_MODEATTR     75
#define PARAMID_NMODEATTR    76
#define PARAMID_REDTAG       77
#define PARAMID_OWDENBL      93
#define PARAMID_FAULTOPT     125
#define PARAMID_FAULTVALUE   127
#define PARAMID_FAULTSTATE   128
#define PARAMID_ENBLGANGEDOUTPUTS 129
#define PARAMID_NUMOFCHNLSGANGED  130
#define PARAMID_LOCALMAN     242
#define PARAMID_SLTCHKPNTVER 244

// Slot checkpoint version
#define LATEST_SLTCHKPNT_VERSION LATEST_UIO_DO_SLTCHKPNT_VERSION
#endif

// Mask for checking if OUTPUTFL and OC SF exists.
#if defined (IOMTYPE_UIO)
#define SF_OUTPUT_OC_FL     0x03
#else
#define SF_OUTPUT_OC_FL     0x05
#endif

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
#if defined(IOPTYPE_DO)
const UINT8  clsDoSlot::PmioDumpParamTbl[] = {
    PARAMID_PTEXECST,
    PARAMID_PTEXECSTLRS,
    PARAMID_PNTFORM,
    PARAMID_PNTTYPE,
    PARAMID_DOTYPE,
    PARAMID_PERIOD,
    PARAMID_FL_UNPWRD,
    PARAMID_OPTDIR,
    PARAMID_OP,
    PARAMID_SO,
    PARAMID_ACTV_NRL_SO,
    PARAMID_LATCHED,
#if defined(DIGTYPE_DO32)
    PARAMID_PWM_PLS_TM,
    PARAMID_PRD_TM,
    PARAMID_T_P_STRT,
    PARAMID_STRT_NXT,
    PARAMID_T_P_END,
    PARAMID_OFFPULSE,
    PARAMID_ONPULSE,
#endif
    0 // Terminator
};

const UINT8  clsDoSlot::CheckPointVer1[] = {    
    PARAMID_PNTTYPE,
    PARAMID_DOTYPE,    
    PARAMID_FL_UNPWRD,
    PARAMID_PERIOD,
    PARAMID_OPTDIR,
    PARAMID_PTEXECST,
    0 // Terminator
};
#else
const UINT8  clsDoSlot::CheckPointVer1[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_DOTYPE,
    PARAMID_OPTDIR,
    PARAMID_PERIOD,
    PARAMID_MODEPERM,
    PARAMID_NMODE,
    PARAMID_NMODEATTR,
    PARAMID_MODEATTR,
    PARAMID_MODE,
    PARAMID_FAULTOPT,
    PARAMID_FAULTVALUE,
    PARAMID_REDTAG,
    PARAMID_PTEXECST,
#if defined(IOMTYPE_UIO)
    PARAMID_OWDENBL,
#endif
    0 // Terminator
};
#endif

#if defined(IOMTYPE_UIO)
const UINT8  clsDoSlot::CheckPointVer2[] = {
    PARAMID_SLTCHKPNTVER,
    PARAMID_PNTTYPE,
    PARAMID_DOTYPE,
    PARAMID_OPTDIR,
    PARAMID_PERIOD,
    PARAMID_MODEPERM,
    PARAMID_NMODE,
    PARAMID_NMODEATTR,
    PARAMID_MODEATTR,
    PARAMID_MODE,
    PARAMID_FAULTOPT,
    PARAMID_FAULTVALUE,
    PARAMID_REDTAG,
    PARAMID_PTEXECST,
    PARAMID_OWDENBL,
    PARAMID_ENBLGANGEDOUTPUTS,
    PARAMID_NUMOFCHNLSGANGED,
    0 // Terminator
};
const CHECKPOINT_VER_TABLE clsDoSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
      { CheckPointVer1, 21},
      { CheckPointVer2, 23}  
};
#else
const CHECKPOINT_VER_TABLE clsDoSlot::CheckPointVerTable[LATEST_SLTCHKPNT_VERSION] = {
#if defined(IOPTYPE_DO)
    { CheckPointVer1,  9 }
#else
    { CheckPointVer1, 20 }
#endif
};
#endif

#if defined(IOMTYPE_UIO)
UINT8 clsDoSlot::DoSlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
#else
UINT8 clsDoSlot::SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
#endif

const UINT8 clsDoSlot::RedParams[] = {
    PARAMID_DOTYPE,
    PARAMID_PNTTYPE,
#if !defined(IOPTYPE_DO)
    PARAMID_MODEPERM,
    PARAMID_NMODE,
    PARAMID_NMODEATTR,
    PARAMID_MODEATTR,
    PARAMID_MODE,
    PARAMID_FAULTOPT,
    PARAMID_FAULTVALUE,
    PARAMID_REDTAG,        
    PARAMID_SO,
#else
    PARAMID_PNTFORM,
    PARAMID_FL_UNPWRD,   
    PARAMID_STDBYMAN,
#endif
    PARAMID_OPTDIR,
    PARAMID_LOCALMAN,
    PARAMID_OFFPULSE,
    PARAMID_ONPULSE,
    PARAMID_OP,    
    PARAMID_PERIOD,
#if defined(IOMTYPE_UIO)
    PARAMID_OWDENBL,
#endif
    0 // Terminator
};

const UINT8 clsDoSlot::AosData[] = {
    PARAMID_OP,
    PARAMID_PWMINITR,
    PARAMID_STDBYMAN,
    PARAMID_LOCALMAN,
    0 // Terminator
};

const DO_SLOTPARAMINFO clsDoSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,NoOfParams,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 50    
#if defined(IOPTYPE_DO)
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_INACTIVEORIDLE,PreDOType,PostDOType,GetDOTypePtr,TRUE,     // 51 DoType
    DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, PreFaultOpt, PostFaultOpt, GetFaultOptPtr, TRUE,// 52 FaultOpt (PAR #1-EMPNLXD fix - FaultOpt param is using instead of Fl_UnPwrd param in legacy).
  //DT_ENUM, 1, AT_SBYTE, ALCK_ENGR, CONTROLSTATE_NONE, 0, PostFl_UnPwrd, GetFl_UnPwrdPtr, TRUE,        // 52 Fl_UnPwrd
#else
    DT_ENUM, 1, AT_SBYTE, ALCK_PBD, CONTROLSTATE_INACTIVE, PreDOType, PostDOType, GetDOTypePtr, TRUE,   // 51 DoType
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 52
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 53
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_ACTIVEANDRUN,PreOp,PostOp,GetOpPtr,FALSE,              // 54 Op
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PrePeriod,PostPeriod,GetPeriodPtr,TRUE,           // 55 Period
#if defined(IOPTYPE_DO)
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_NONE, 0, 0, GetPntFormPtr, TRUE,                       // 56 PNTFORM    
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 56
#endif
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PrePntType,PostPntType,GetPntTypePtr,TRUE,            // 57 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PrePtExecSt,PostPtExecSt,GetPtExecStPtr,TRUE,        // 58 PtExecSt
    DT_BOOL,1,AT_BXPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetInitReqPtr,FALSE,                            // 59 InitReq
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 60
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 61
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,                           // 62 SlotSfBt
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreSO,PostSO,GetSOPtr,FALSE,                         // 63 SO
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetStdbyManPtr,FALSE,                            // 64 StdbyMan
    DT_BLIND,7,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetAosDataPtr,FALSE,                             // 65 AosData
#if defined(IOMTYPE_UIO)
    DT_BLIND,23,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,TRUE,              // 66 CheckPoint
#elif defined(IOPTYPE_DO)
    DT_BLIND, 9, AT_PSET, ALCK_VIEW, CONTROLSTATE_NONE, PreCheckPoint, 0, GetCheckPointPtr, TRUE,       // 66 CheckPoint
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVEORIDLE, PreOptDir, 0, GetOptDirPtr, TRUE,      // 67 OptDir
#else
    DT_BLIND,20,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCheckPoint,0,GetCheckPointPtr,TRUE,              // 66 CheckPoint
    DT_ENUM, 1, AT_SBYTE, ALCK_EPB, CONTROLSTATE_INACTIVE, PreOptDir, 0, GetOptDirPtr, TRUE,            // 67 OptDir
#endif    
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreOnPulse,PostOnPulse,GetOnPulsePtr,TRUE,        // 68 OnPulse
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreOffPulse,PostOffPulse,GetOffPulsePtr,TRUE,     // 69 OffPulse
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 70
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPWMInitRPtr,FALSE,                            // 71 PWMInitR
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreMode,PostMode,GetModePtr,TRUE,                    // 72 Mode
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreNMode,0,GetNModePtr,TRUE,                         // 73 NMode
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreModePerm,0,GetModePermPtr,TRUE,                   // 74 ModePerm
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,PreModeAttr,0,GetModeAttrPtr,TRUE,                   // 75 ModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,PreNModeAttr,0,GetNModeAttrPtr,TRUE,                 // 76 NModeAttr
    DT_BOOL,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,PreRedTag,PostRedTag,GetRedTagPtr,TRUE,              // 77 RedTag
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 78
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 79
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 80
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 81
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 82
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 92
#if defined(IOMTYPE_UIO)
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,PostOwd,GetOwdEnablePtr,TRUE,                       // 93 OwdEnable
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 93
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 101
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 102
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 103
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 104
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 114
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 115
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 116
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 124
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreFaultOpt,PostFaultOpt,GetFaultOptPtr,TRUE,         // 125 FaultOpt
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 126
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,PreFaultValue,0,GetFaultValuePtr,TRUE,             // 127 FaultValue
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetFaultStatePtr,FALSE,                          // 128 FaultState
#if defined(IOMTYPE_UIO)
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetEnblGangedOutputsPtr,TRUE,                     // 129  EnblGangedOutputs
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreNumOfChnlsGanged,PostNumOfChnlsGanged,GetNumOfChnlsGangedPtr,TRUE,  // 130  NumOfChnlsGanged
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 130
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 133
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 142
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 181
#if defined(IOMTYPE_UIO)
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHLongTagPtr,FALSE,                          // 182 HLongTag
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetH7Cmd0Ptr,FALSE,                             // 183 H7Cmd0
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvMfgCd7Ptr,FALSE,                         // 184 HDvMfgCd7
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvTypCd7Ptr,FALSE,                         // 185 HDvTypCd7
    DT_UINT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlot0TSPtr,FALSE,                          // 186 HSlot0TS
    DT_BLIND,7,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevCdPtr,FALSE,                              // 187 HDevCd
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 189
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHAlarmEnablePtr,FALSE,                        // 190 HAlarmEnable
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetHEnablePtr,FALSE,                         // 191 HEnable
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetHScanCfgPtr,FALSE,                        // 192 HScanCfg
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynRatePtr,FALSE,                           // 193 HDynRate
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevRatePtr,FALSE,                           // 194 HDevRate
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotDvcPtr,FALSE,                            // 195 HSlotDvc[4]
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHComThrsPtr,FALSE,                          // 196 HComThrs
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHComHysPtr,FALSE,                           // 197 HComHys
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHComStsPtr,FALSE,                             // 198 HComSts
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHNComErrPtr,FALSE,                          // 199 HNComErr
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 203
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHLComFailPtr,FALSE,                           // 204 HLComFail
    DT_BLIND,17,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd0Ptr,FALSE,                             // 205 HCmd0
    DT_BLIND,24,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd12Ptr,FALSE,                            // 206 HCmd12
    DT_BLIND,21,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd13Ptr,FALSE,                            // 207 HCmd13
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd14Ptr,FALSE,                            // 208 HCmd14
    DT_BLIND,18,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd15Ptr,FALSE,                            // 209 HCmd15
    DT_BLIND,3,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd16Ptr,FALSE,                             // 210 HCmd16
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynValPtr,FALSE,                          // 211 HDynVal[4]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynStPtr,FALSE,                              // 212 HDynSt[4]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynCcPtr,FALSE,                              // 213 HDynCc[4]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynEuPtr,FALSE,                              // 214 HDynEu[4]
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotValPtr,FALSE,                         // 215 HSlotVal[8]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotStPtr,FALSE,                             // 216 HSlotSt[8]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotCcPtr,FALSE,                             // 217 HSlotCc[8]
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHSlotEuPtr,FALSE,                             // 218 HSlotEu[8]
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevStPtr,FALSE,                             // 219 HDevSt[4]
    DT_BLIND,25,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd48Ptr,FALSE,                            // 220 HCmd48
    DT_BOOL,1,AT_BITPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmd48Ptr,FALSE,                            // 221 HCmd48BT
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmdFailPtr,FALSE,                            // 222 HCmdFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHCmdRespPtr,FALSE,                           // 223 HCmdResp
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvMfgCdPtr,FALSE,                            // 224 HDvMfgCd
    DT_BLIND,3,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDevIdCdPtr,FALSE,                           // 225 HDevIdCd
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvTypCdPtr,FALSE,                           // 226 HDvTypCd
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDvRevCdPtr,FALSE,                           // 227 HDvRevCd
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDdRevCdPtr,FALSE,                           // 228 HDdRevCd
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 229
    DT_BLIND,50,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHNtfyCfgPtr,FALSE,                          // 230 HNtfyCfg
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 231
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                        // 232 HBrdp
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHDynDvcPtr,FALSE,                             // 233 HDynDvc
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetHartVersionPtr,FALSE,                         // 234 HartVersion
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,PreInitPntType,0,GetPntTypePtr,FALSE,                 // 235 InitPntType
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 235
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 240
#if defined(IOPTYPE_DO)
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetLatchedPtr, FALSE,                     // 241 LATCHED
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 241
#endif
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLocalManPtr,TRUE,                             // 242 LocalMan
#if defined(IOPTYPE_DO)
    DT_BOOL, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetActvNrmlSoPtr, FALSE,                  // 241 ACTV_NRML_SO
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 243
#endif
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,                  // 244 SlotChekpointVerNum
#if defined(IOPTYPE_DO)    
    DT_ENUM, 1, AT_SBYTE, ALCK_SUPR, CONTROLSTATE_NONE, 0, 0, GetPtExecStLrsPtr, FALSE,                 // 245  PTEXECST_LRS
#else
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 245
#endif
    DT_UINT16, 2, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetPRDTimePtr, FALSE,                   // 246 PRDTime
    DT_UINT16, 2, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetPWMPulseTimePtr, FALSE,              // 247 PWMPulseTime
    DT_BLIND, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetStartNextPtr, FALSE,                  // 248 StartNext
#if defined(IOPTYPE_DO)
    DT_BLIND, 3, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetTPStartPtr, FALSE,                    // 249 TPStart
    DT_BLIND, 3, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetTPEndPtr, FALSE,                      // 250 TPEnd
#else
    DT_UINT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetTPStartPtr, FALSE,                   // 249 TPStart
    DT_UINT32, 4, AT_MBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetTPEndPtr, FALSE,                     // 250 TPEnd
#endif
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 251
    DT_NONE, 0, AT_NONE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, 0, FALSE,                                  // 252
    DT_UINT8, 1, AT_SBYTE, ALCK_VIEW, CONTROLSTATE_NONE, 0, 0, GetSlotSfLrsPtr, FALSE,                  // 253 SlotSfLrs
#if defined(IOMTYPE_UIO)
    DT_BLIND,23,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,PreCfgRestore,0,GetCheckPointPtr,TRUE,              // 254 CfgRestore
#else   
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                          // 254
#endif
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE                                           // 255
};
/*******************************************************************************
*                            clsDoSlot::operator new                           *
*                            =======================                           *
* PURPOSE:   This allocates memory for each channel.                           *
* ARGUMENTS: a_ucSltNm - Channel number (0-relative).                          *
* RETURN:    VOID *    - pointer to starting address of allocated memory area. *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDoSlot::operator new(UINT32, UINT8 a_ucSltNm) 
{ 
#if defined(IOMTYPE_UIO)
    return (EXTRAM_SLOT_ADDR(a_ucSltNm + 1));
#else
    return (ucIomDbMemory + DOBOXSLOT_SIZE + (a_ucSltNm * DOSLOT_SIZE));
#endif
}

/*******************************************************************************
*                           clsDoSlot::clsDoSlot                               *
*                           ====================                               *
* PURPOSE: Constructor of clsDoSlot Class. This calls InitDoSlot() which       *
*          initializes clsDoSlot class members.                                *
* ARGUMENTS:                                                                   *
*           a_ucSltNm    -   Channel number                                    *
* RETURN:   NONE                                                               *
* NOTES:    This constructor will internally invokes clsOutSlot class          *
*                   constructor.                                               *
*******************************************************************************/
#ifdef IOMTYPE_UIO
clsDoSlot::clsDoSlot(UINT8 a_ucSltNm) : HartDevDb(a_ucSltNm,&HartCfgDb,&HartCfgDb7),clsOutSlot(PNTTYPE_NOTCONFIGURED,a_ucSltNm) {
#else
clsDoSlot::clsDoSlot(UINT8 a_ucSltNm) : clsOutSlot(PNTTYPE_NOTCONFIGURED,a_ucSltNm) {
#endif
    // Initialize DoSlot class variables.
    InitDoSlot(TRUE, TRUE);
}
/*******************************************************************************
*                            clsDoSlot::GetDataType                            *
*                            ======================                            *
* PURPOSE: This function returns data type of the parameter.                   *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           DataType of the parameter.                                         *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsDoSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}
/*******************************************************************************
*                          clsDoSlot::GetAccessType                            *
*                          =========================                           *
* PURPOSE: This function returns accesstype of the parameter.                  *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           AccessType of the parameter.                                       *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsDoSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}
/*******************************************************************************
*                            clsDoSlot::GetParamSize                           *
*                            =======================                           *
* PURPOSE: This function returns size of the parameter.                        *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           Data size of the parameter.                                        *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsDoSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}
/*******************************************************************************
*                            clsDoSlot::GetParamPtr                            *
*                            ======================                            *
* PURPOSE: This function returns the pointer to the parameter.                 *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           UINT8 *   - pointer to parameter.                                  *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsDoSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}
/*******************************************************************************
*                           clsDoSlot::GetAccessLock                           *
*                           ========================                           *
* PURPOSE: This function returns Access Lock of the parameter.                 *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           Access Lock of the parameter number.                               *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsDoSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}
/*******************************************************************************
*                       clsDoSlot::GetIsDbChecksumed                           *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsDoSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}
/*******************************************************************************
*                         clsDoSlot::VerifyControlState                        *
*                         =============================                        *
* PURPOSE: This function checks the contorl state assigned to the parameter to *
*          actual present control state of the channel and IOM module itself,  *
*          before the actual write to the parameter.                           *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           PASTATUS    - Success (PA_OK) or Warning status code.              *
* NOTES:   This function decides whether the write can be done or not to the   *
*          paramerter under current channel or IOM state.                      *
*******************************************************************************/
PASTATUS clsDoSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        // check whether the channel is INACTIVE.
        if (PTEXECST_INACTIVE != PtExecSt) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        // check whether the channel is INACTIVE and IOM is IDLE.
        if ((PTEXECST_INACTIVE != PtExecSt) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        // check whether the channel is ACTIVE and IOM is in RUN mode.
        if ((PTEXECST_ACTIVE != PtExecSt) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsDoSlot::ExecutePreFunction                        *
*                         =============================                        *
* PURPOSE: This function invokes the pre-function for the given writable       *
*           parameter.                                                         *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           PASTATUS    - Success (PA_OK) or Warning status code.              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                       UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsDoSlot::ExecutePostFunction                       *
*                         ==============================                       *
* PURPOSE: This function invokes the post-function for the given writable      *
*           parameter.                                                         *
* ARGUMENTS:                                                                   *
*           a_ucParamNumber - Parameter code                                   *
* RETURN:                                                                      *
*           PASTATUS    - Success (PA_OK) or Warning status code.              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}
/*******************************************************************************
*                            clsDoSlot::GetInitReqPtr                          *
*                            ========================                          *
* PURPOSE:   This function returns pointer to StsInitCpy, which stores         *
*            InitRequest for all channels.                                     *
* ARGUMENTS:                                                                   *
* RETURN:    VOID *  -  Pointer to StsInitCpy.                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsDoSlot::GetInitReqPtr(VOID) { 
#if defined(IOMTYPE_UIO)
    return &(BOX->PvScanRec.initRequest);
#else
    return BOX->StsInitCpy;
#endif
}
/*******************************************************************************
*                            clsDoSlot::InitDoSlot                             *
*                            =====================                             *
* PURPOSE: InitDoSlot function which initializes clsDoSlot class members.      *
* ARGUMENTS:                                                                   *
*           bFullInit       -   Flag to indicate which type of initialization  *
*           bObjCreate      -   Flag to indicate whether the object is created *
*                               for the first time                             *
* RETURN:    NONE                                                              *
* NOTES:   This function is called when Init Slot request comes.               *
*******************************************************************************/
VOID clsDoSlot::InitDoSlot(BOOL bFullInit, BOOL bObjCreate) {
    if (bFullInit) {
        DOType         =    DOTYPE_STATUS;
        Period         =    10.0;
        OnPulse        =    NaN;
        OffPulse       =    NaN;
        Op             =    0.0;
        SO             =    FALSE;
        PWMInitR       =    TRUE;
        PRDTime        =    1000;
        PWMPulseTime   =    0;
        StdbyMan       =    FALSE;
#if defined(IOMTYPE_UIO)
        OwdEnable      =    FALSE;
        EnblGangedOutputs = FALSE;
        NumOfChnlsGanged  = NUMOFCHNLSGANGED_TWO;
#endif
        BOX->SetInitReq(ChanNum, TRUE);

        // UIO does not need to update hold registers
        // << TODO >> Add functionality back in when UIO supports this << TODO >>
#if !defined(IOMTYPE_UIO)
        BOX->SetFaultOutput(ChanNum,FALSE);
#endif
    }
    if (bObjCreate) {
        StartNext      =    TRUE;
        TPStart        =    0;
        TPEnd          =    0;
    }

#if defined(IOPTYPE_DO)
    ActvNrmlSo = FALSE;
    Latched = TRUE; // if DOType = STATUS, & Onpulse = OffPulse = NAN then TRUE else FALSE        
    PntType = PNTTYPE_DIGITALOUTPUT;
  //Fl_UnPwrd = (FL_UNPWRD)BOX->GetFl_UnPwrd_Bx();
#if defined(DIGTYPE_DO16)
    // added due to PAR# 1-919CFFZ (few channels were holding last value even after deleting channels from monitor)
    // initializing output latch enable flag
    BOX->uiEnableOutputLatch &= ~((UINT16)1 << (ChanNum - 1));
#endif

#endif
}
/*******************************************************************************
*                        clsDoSlot::PreFaultValue                              *
*                        ========================                              *
* PURPOSE: This function check all necessary pre conditions before writing to  *
*           FaultValue. Pointer check, Range check, and access level check     *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the parameter                  *
*           a_Writebuffer   -   pointer to write buffer                        *
* RETURN:                                                                      *
*           PASTATUS    - Success (PA_OK) or Warning status code.              *
* NOTES:   FaultValue can be written only when DoType is PWM and when the      *
*           channel FaultOpt is configured in FAULTOPT_FAULTVLAUE mode         *
*******************************************************************************/
PASTATUS clsDoSlot::PreFaultValue(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    // get the value of FaultValue in local variable
    FLOAT32 ufFaultVal = *(FLOAT32 *)a_Writebuffer;
    
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(FLOAT32 *)a_Writebuffer) == FaultValue))
        return PA_OK;
  
    if ((DOTYPE_PWM != DOType) || (FAULTOPT_FAULTVALUE != FaultOpt)) {
        return DO_PARAMETER_INVALID;
    }
    
    if (isnan(ufFaultVal))
        return DO_ILLEGAL_VALUE;
    
    if ((ufFaultVal > OP_MAXVALUE) || (ufFaultVal < OP_MINVALUE))
        return DO_LIMIT_OR_RANGE_EXCEEDED;

    return PA_OK;
}
/*******************************************************************************
*                           clsDoSlot::PreFaultOpt                             *
*                           ======================                             *
* PURPOSE:  Pre Receiver-Beware function for FaultOpt parameter.               *
*           This method checks for range of the data that can be written to    *
*           FaultOpt parameter.                                                *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
* RETURN:                                                                      *
*           PA_OK           -   If check is successfull                        *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreFaultOpt(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(FAULTOPT *)a_Writebuffer) == FaultOpt))
        return PA_OK;
    
    if (FAULTOPT_FAULTVALUE == (*(FAULTOPT *)a_Writebuffer))
    {
        if (DOTYPE_PWM != DOType)
            return DO_INITIALIZATION_ERROR;
    }
    if (FAULTOPT_POWERED == (*(FAULTOPT *)a_Writebuffer))
    {
        if (DOTYPE_PWM == DOType)
            return DO_INITIALIZATION_ERROR;
        if (DOTYPE_ONPULSE == DOType || DOTYPE_OFFPULSE == DOType)
            return DO_ILLEGAL_VALUE;
    }
    if (((*(FAULTOPT *)a_Writebuffer) < FAULTOPT_HOLD)
        || ((*(FAULTOPT *)a_Writebuffer) > FAULTOPT_FAULTVALUE))
        return DO_ILLEGAL_VALUE;
    return PA_OK;
}
/*******************************************************************************
*                          clsDoSlot::PostFaultOpt                             *
*                          =======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostFaultOpt(UINT8) 
{
    if (FAULTOPT_FAULTVALUE != FaultOpt) {
        FaultValue = 0.0;
    }

#if defined(IOPTYPE_DO)
    // PAR #1-EMPNLXD fix - FaultOpt param is using instead of Fl_UnPwrd param in legacy.
    *(FL_UNPWRD *)BOX->GetFl_UnPwrd_BxPtr() = (FL_UNPWRD)FaultOpt;
#endif

    // UIO does not need to update hold registers
    // << TODO >> Add functionality back in when UIO supports this << TODO >>
#if !defined(IOMTYPE_UIO)
    BOOL bFaultOutput;
    
    switch (FaultOpt) {
    case FAULTOPT_POWERED:
        if (DOTYPE_STATUS == DOType) bFaultOutput = TRUE;
        else bFaultOutput = FALSE;
        break;
    case FAULTOPT_UNPOWERED:
        bFaultOutput = FALSE;
        break;
    case FAULTOPT_HOLD:
        if (DOTYPE_STATUS == DOType) bFaultOutput = SO;
        else bFaultOutput = FALSE;
        break;
    default:
        return;
    }

    // Update fault state value in boxslot database.
    BOX->SetFaultOutput(ChanNum,bFaultOutput);
#endif
}

#if defined(IOPTYPE_DO)
/*******************************************************************************
*                               clsAohSlot::PostFl_UnPwrd                      *
*                               =======================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostFl_UnPwrd(UINT8)
{
    //*(FL_UNPWRD *)BOX->GetFl_UnPwrd_BxPtr() = Fl_UnPwrd;

    // fix for PAR# 1-933RWY8 (DO32 module failure option doesn't function correctly when it was selected as "hold")
    //FaultOpt = (FAULTOPT)Fl_UnPwrd;
    PostFaultOpt(TRUE);
}
#endif
/*******************************************************************************
*                        clsDoSlot::PreMode                                    *
*                        ==================                                    *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreMode(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    BOOL ReqstdNrml = FALSE;
    
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(MODE *)a_Writebuffer) == Mode))
        return PA_OK;

    if ((a_ucAccLvl == ALVL_OPER) && (ModePerm != MODEPERM_PERMIT))
        return DO_CHANGE_NOT_PERMITTED_BY_OPERATOR;
    
    if (REDTAG_ON == RedTag)
        return DO_POINT_IS_RED_TAGGED;

    if ((a_ucAccLvl == ALVL_PROG) && (ModeAttr != MODEATTR_PROGRAM)) {
        //Program changing the value
        return DO_INVALID_MODE_ATTRIBUTE;
    }

    if ((MODE_MANUAL  != (*(MODE *)a_Writebuffer)) &&
        (MODE_CASCADE != (*(MODE *)a_Writebuffer)) &&
        (MODE_NORMAL  != (*(MODE *)a_Writebuffer)))
      return DO_ILLEGAL_VALUE;

    if (((*(MODE *)a_Writebuffer) == MODE_NORMAL) && (NMode == MODE_NONE))
        return DO_NORMAL_MODE_IS_NOT_CONFIGURED;

    if ((*(MODE *)a_Writebuffer) == MODE_NORMAL) {
        ReqstdNrml = TRUE;
        *(MODE *)a_Writebuffer = (MODE)NMode;
    }

    if (ReqstdNrml && (NModeAttr != MODEATTR_NONE))
        ModeAttr = (MODEATTR)NModeAttr;
    else if (a_ucAccLvl & ALCK_ONPROC)
        ModeAttr = MODEATTR_OPERATOR;

    if (PtExecSt == PTEXECST_ACTIVE) {
        if ((*(MODE *)a_Writebuffer) == MODE_CASCADE) {
            DriveToQuiescentState();
        }
    }
    return PA_OK;
}
/*******************************************************************************
*                          clsDoSlot::PostMode                                 *
*                          ========================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostMode(UINT8) {
    if (Mode == MODE_CASCADE) {
        if (BOX->GetOverCurrent(ChanNum)) {
            BOX->SetOverCurrent(ChanNum, FALSE);
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
        }
#if defined(IOMTYPE_UIO)
        ClearOverCurrentSfForAdjChnls();
#endif
    }
    if (Mode == MODE_CASCADE && (DOType == DOTYPE_ONPULSE ||
                                 DOType == DOTYPE_OFFPULSE)) SO = FALSE;
    CmptInitReq();
}
/*******************************************************************************
*                        clsDoSlot::PreModeAttr                                *
*                        ======================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreModeAttr(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {  
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(MODEATTR *)a_Writebuffer) == ModeAttr))
        return PA_OK;

    if (REDTAG_ON == RedTag)
            return DO_POINT_IS_RED_TAGGED;

    if ((a_ucAccLvl == ALVL_OPER) && (ModePerm != MODEPERM_PERMIT))
        return DO_CHANGE_NOT_PERMITTED_BY_OPERATOR;

    if ((*(MODEATTR *)a_Writebuffer) == MODEATTR_NONE)
        return DO_ILLEGAL_VALUE;

    if (((*(MODEATTR *)a_Writebuffer) < MODEATTR_OPERATOR) 
    || ((*(MODEATTR *)a_Writebuffer) > MODEATTR_NORMAL))
    return DO_LIMIT_OR_RANGE_EXCEEDED;

    if ((*(MODEATTR *)a_Writebuffer) == MODEATTR_NORMAL) {
        if (NModeAttr == MODEATTR_NONE)
            return DO_NORMAL_ATTRIBUTE_NOT_CONFIGURED;
        else
            (*(MODEATTR *)a_Writebuffer) = (MODEATTR)NModeAttr;
    }
    else {
    if ((a_ucAccLvl == ALVL_PROG) && (NModeAttr != MODEATTR_NONE))
        NModeAttr = (*(MODEATTR *)a_Writebuffer);
    }
    return PA_OK;
}
/*******************************************************************************
*                        clsDoSlot::PreModePerm                                *
*                        ======================                                *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreModePerm(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(MODEPERM *)a_Writebuffer) == ModePerm))
        return PA_OK;

    if (((*(MODEPERM *)a_Writebuffer) < MODEPERM_NOPERMIT) 
        || ((*(MODEPERM *)a_Writebuffer) > MODEPERM_PERMIT))
        return DO_ILLEGAL_VALUE;
    return PA_OK;
}
/*******************************************************************************
*                          clsDoSlot::PreNMode                                 *
*                          ===================                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreNMode(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(MODE *)a_Writebuffer) == NMode))
        return PA_OK;

    if (((*(MODE *)a_Writebuffer) < MODE_NONE) 
        || ((*(MODE *)a_Writebuffer) > MODE_CASCADE))
        return DO_ILLEGAL_VALUE;

    if (MODE_NONE == (*(MODE *)a_Writebuffer))
        NModeAttr = MODEATTR_NONE;
    return PA_OK;
}
/*******************************************************************************
*                          clsDoSlot::PreNModeAttr                             *
*                          =======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreNModeAttr(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if ((ALVL_IUSER == a_ucAccLvl) && ((*(MODEATTR *)a_Writebuffer) == NModeAttr))
        return PA_OK;

    if (((*(MODEATTR *)a_Writebuffer) < MODEATTR_NONE) 
        || ((*(MODEATTR *)a_Writebuffer) > MODEATTR_NORMAL))
        return DO_ILLEGAL_VALUE;

    if ((*(MODEATTR *)a_Writebuffer) == MODEATTR_NORMAL)
        return DO_ILLEGAL_VALUE;

    if ((NMode == MODE_NONE) && ((*(MODEATTR *)a_Writebuffer) != NModeAttr))
        return DO_NORMAL_MODE_IS_NOT_CONFIGURED;

    return PA_OK;
}
/*******************************************************************************
*                        clsDoSlot::PreRedTag                                  *
*                        ====================                                  *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreRedTag(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if (ALVL_IUSER == a_ucAccLvl)
        return PA_OK;

    if ((*(REDTAG *)a_Writebuffer) == REDTAG_ON) {
        if (a_ucAccLvl & ALCK_ONPROC) {
            if (MODE_MANUAL != Mode)
                return DO_MODE_MUST_BE_MANUAL;
            if (MODEATTR_OPERATOR != ModeAttr)
                return DO_INVALID_MODE_ATTRIBUTE;
        }
        else if ((ALVL_UMCC == a_ucAccLvl) || (ALVL_CC == a_ucAccLvl))
        {
            if (MODE_CASCADE != Mode)
                return DO_INVALID_MODE;
        }
        else 
            return DO_ACCESS_LEVEL_INVALID;
    }
    if (((*(REDTAG *)a_Writebuffer) < REDTAG_OFF) 
        || ((*(REDTAG *)a_Writebuffer) > REDTAG_ON))
        return DO_ILLEGAL_VALUE;
    return PA_OK;
}
/*******************************************************************************
*                          clsDoSlot::PostRedTag                               *
*                          =====================                               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostRedTag(UINT8)
{
    // UIO does not need to update hold registers
    // << TODO >> Add functionality back in when UIO supports this << TODO >>
#if !defined(IOMTYPE_UIO)
    BOOL    bState;
    if (DOType == DOTYPE_STATUS) 
    {
        if (REDTAG_ON == RedTag) 
        {
            // UIO does not need to update hold registers
            // << TODO >> Add functionality back in when UIO supports this << TODO >>

            BOX->SetFaultOutput(ChanNum,SO);
        }
        else 
        {
            switch (FaultOpt) 
            {
                case FAULTOPT_HOLD:
                    bState = SO;
                    break;
                case FAULTOPT_UNPOWERED:
                    bState = FALSE;
                    break;
                case FAULTOPT_POWERED:
                    bState = TRUE;
                    break;
            }
            BOX->SetFaultOutput(ChanNum,bState);
        }
    }
#else
    ;
#endif
}
/*******************************************************************************
*                           clsDoSlot::PreOp                                   *
*                           ================                                   *
* PURPOSE:  Pre Receiver-Beware function for Op parameter.                     *
*           This method checks for range of the data that can be written to    *
*           Op parameter, access level check, module status check and point    *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the Op parameter               *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:    This method clamps the Op data if it is out of boundary            *
*******************************************************************************/
PASTATUS clsDoSlot::PreOp(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PASTATUS ucStatus = PA_OK;
    UINT8 ucRngStatus = WITHIN_RANGE;

    if ((BOX->GetModuleStatus() != MODSTATUS_RUN)
        || (PtExecSt != PTEXECST_ACTIVE))
        return DO_STATE_MUST_BE_RUN;

    if (LocalMan)
        return DO_POINT_IS_LOCAL_MANUAL;

    if (REDTAG_OFF != RedTag)
            return DO_POINT_IS_RED_TAGGED;
    
    if (DOTYPE_PWM != DOType)
        return DO_PARAMETER_INVALID;

    if (isnan(*(FLOAT32 *)a_Writebuffer)) 
        return DO_ILLEGAL_VALUE;

    if (*(FLOAT32 *)a_Writebuffer > OP_MAXVALUE) ucRngStatus = OVER_RANGE;
    else if (*(FLOAT32 *)a_Writebuffer < OP_MINVALUE) ucRngStatus = UNDER_RANGE;

    if (StdbyMan && (!(a_ucAccLvl & ALCK_ONPROC_IUSER)))
        return DO_ACCESS_LEVEL_INVALID;

    // No relay extension board for UIO
#if !defined(IOMTYPE_UIO)
    if (BOX->IsExtBdSFActive()) {
        // if Relay Extension Board Missing
        if(!((Mode == MODE_MANUAL) && (ModeAttr == MODEATTR_OPERATOR))) {
            // if any softfail exists on that channel and in MAN mode and a attribute is operator
            // then allow write to go through.
            return DO_INITIALIZATION_ERROR;
        }
    }
#endif

    // if any softfail exists on that channel and in MAN mode and a attribute is operator
    // then allow write to go through.
    if ((SlotSfBt != 0) && (!((Mode == MODE_MANUAL) && (ModeAttr == MODEATTR_OPERATOR)))) {
        return DO_INITIALIZATION_ERROR;
    }

    switch (Mode) {
    case MODE_MANUAL:
        switch (ModeAttr) {
        case MODEATTR_OPERATOR:
            //if ENGR or SUPERV or OPER (HumanLock)
            if (a_ucAccLvl & ALCK_ONPROC) {
                if(ucRngStatus != WITHIN_RANGE)
                    ucStatus = DO_LIMIT_OR_RANGE_EXCEEDED;
            }
            else if (ALVL_IUSER == a_ucAccLvl)
                    ucStatus = ClampWithWarning(a_Writebuffer, ucRngStatus, DOType);
            else
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        case MODEATTR_PROGRAM:
            if (ALVL_PROG == a_ucAccLvl) {
                ucStatus = ClampWithWarning(a_Writebuffer, ucRngStatus, DOType);
            }
            else 
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        default:
            ucStatus = DO_INVALID_MODE_ATTRIBUTE;
        }
        break;
    case MODE_CASCADE:
        if (FALSE == StdbyMan) {
            if ((ALVL_UMCC != a_ucAccLvl) && (ALVL_CC != a_ucAccLvl))
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            else {
                ucStatus = ClampWithWarning(a_Writebuffer, ucRngStatus, DOType);
            }
        }
        break;
    default:
        ucStatus = DO_INVALID_MODE;
    }
return ucStatus;
}
/*******************************************************************************
*                           clsDoSlot::PostOp                                  *
*                           ==================                                 *
* PURPOSE:  Post Receiver-Beware function for Op parameter.                    *
*           This method calculates Pulse ON Time by calling CalcPwmOnTime      *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the Op parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostOp(UINT8) {
#if defined(IOMTYPE_UIO)
    BOX->SetDoOp(ChanNum, Op);
#endif
    CalcPwmOnTime(Op);
    FaultState = FAULTSTATE_NORMAL;
    // Return the overcurrent softfail if exists
    if (BOX->GetOverCurrent(ChanNum)) {
        BOX->SetOverCurrent(ChanNum, FALSE);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
    }
#if defined(IOMTYPE_UIO)
    ClearOverCurrentSfForAdjChnls();
#endif

#if defined(DIGTYPE_DO16)
    BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
}
/*******************************************************************************
*                           clsDoSlot::PreOnPulse                              *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for OnPulse parameter.                *
*           This method checks for range of the data that can be written to    *
*           OnPulse parameter, module status check and point execution check.  *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the  OnPulse parameter         *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:    Clamps the data if it is outside boundary limit.                   *
*******************************************************************************/
PASTATUS clsDoSlot::PreOnPulse(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PASTATUS ucStatus = PA_OK;
    UINT8 ucRngStatus = WITHIN_RANGE;

    if ((BOX->GetModuleStatus() != MODSTATUS_RUN) 
        || (PtExecSt != PTEXECST_ACTIVE))
        return DO_STATE_MUST_BE_RUN;

    if (LocalMan)
        return DO_POINT_IS_LOCAL_MANUAL;

    if (REDTAG_OFF != RedTag)
            return DO_POINT_IS_RED_TAGGED;

    // added to fix PAR# 1-EWTQH7B (on pulse & off pulse in not working in do16)
    // as per the legacy code, do_type should be status type for on pulse & off pulse
#if defined(IOPTYPE_DO)
//#if defined(DIGTYPE_DO32)
    if (DOTYPE_STATUS != DOType)    
#else
    if (DOTYPE_ONPULSE != DOType)
#endif
        return DO_PARAMETER_INVALID;

    if (isnan(*(FLOAT32 *)a_Writebuffer))
        return DO_ILLEGAL_VALUE;
    
    if (StdbyMan && (!(a_ucAccLvl & ALCK_ONPROC_IUSER)))
        return DO_ACCESS_LEVEL_INVALID;

    if (*(FLOAT32 *)a_Writebuffer > PULSE_MAXVALUE) ucRngStatus = OVER_RANGE;
    else if (*(FLOAT32 *)a_Writebuffer < PULSE_MINVALUE) ucRngStatus = UNDER_RANGE;

#if !defined (IOMTYPE_UIO)
    if (BOX->IsExtBdSFActive() || (SlotSfBt != 0 && SF_OUTPUT_OC_FL != SlotSfBt))
#else
    if (SlotSfBt != 0 && SF_OUTPUT_OC_FL != SlotSfBt)
#endif
    {
        // if Overcurrent exists and only OUTPUTFL SF & Overcurrent exists on that channel 
        // then allow write to go through so that the Overcurrent SF will be returned from 
        // Post function.
        return DO_INITIALIZATION_ERROR;
    }

//  added to fix PAR# 1-EWTQH7B (on pulse & off pulse in not working in do16)
// as per the legacy code, do_type should be status type for on pulse & off pulse
#if !defined(IOPTYPE_DO)
//#if !defined(DIGTYPE_DO32)

    switch (Mode) {
    case MODE_MANUAL:
        switch (ModeAttr) {
        case MODEATTR_PROGRAM:
            ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        case MODEATTR_OPERATOR:
            //if ENGR or SUPERV or OPER (HumanLock)
            if (a_ucAccLvl & ALCK_ONPROC)
                ucStatus = ClampWithWarning(a_Writebuffer, ucRngStatus, DOType);
            else
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        default:
            ucStatus = DO_INVALID_MODE_ATTRIBUTE;
        }
        break;
    case MODE_CASCADE:
        //ALCK_ONPROC_IUSER = ENGR or SUPERV or OPER or IUSER
        if (FALSE == StdbyMan) {
            if ((ALVL_UMCC != a_ucAccLvl) && (ALVL_CC != a_ucAccLvl))
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            else
                ucStatus = ClampWithWarning(a_Writebuffer, ucRngStatus, DOType);
        }
        break;
    default:
        ucStatus = DO_INVALID_MODE;
    }
#endif

return ucStatus;
}
/*******************************************************************************
*                           clsDoSlot::PostOnPulse                             *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for OnPulse parameter.               *
*           Initialize ON Pulse variables and start pulse with ON condition.   *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the  OnPulse parameter         *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostOnPulse(UINT8) {
    FaultState = FAULTSTATE_NORMAL;
    // Return the overcurrent softfail if exists
    if (BOX->GetOverCurrent(ChanNum)) {
        BOX->SetOverCurrent(ChanNum, FALSE);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
    }
#if defined(IOMTYPE_UIO)
    ClearOverCurrentSfForAdjChnls();
#endif

#if defined(IOPTYPE_DO)
    // fix for PAR # 1-DYV60ED (DO32 Pulse period feature not working as expected)
    OffPulse = 0;
#else
    OffPulse = NaN;
#endif
    PulseInProgress = TRUE;
    StartPulse(TRUE, OnPulse);
}
/*******************************************************************************
*                           clsDoSlot::PreOffPulse                             *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for OffPulse parameter.               *
*           This method checks for range of the data that can be written to    *
*           OffPulse parameter, module status check and point execution check. *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the  OffPulse parameter        *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:    Clamps the data if it is outside boundary limit.                   *
*******************************************************************************/
PASTATUS clsDoSlot::PreOffPulse(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PASTATUS ucStatus = PA_OK;
    UINT8 ucRngStatus = WITHIN_RANGE;

    if ((BOX->GetModuleStatus() != MODSTATUS_RUN) 
        || (PtExecSt != PTEXECST_ACTIVE))
        return DO_STATE_MUST_BE_RUN;

    if (LocalMan)
        return DO_POINT_IS_LOCAL_MANUAL;

    if (REDTAG_OFF != RedTag)
            return DO_POINT_IS_RED_TAGGED;

// added to fix PAR# 1-EWTQH7B (on pulse & off pulse in not working in do16)
// as per the legacy code, do_type should be status type for on pulse & off pulse
#if defined(IOPTYPE_DO)
//#if defined(DIGTYPE_DO32)
    if (DOTYPE_STATUS != DOType)
#else
    if (DOTYPE_OFFPULSE != DOType)
#endif
        return DO_PARAMETER_INVALID;

    if (isnan(*(FLOAT32 *)a_Writebuffer))
        return DO_ILLEGAL_VALUE;

    if (StdbyMan && (!(a_ucAccLvl & ALCK_ONPROC_IUSER)))
        return DO_ACCESS_LEVEL_INVALID;

    if (*(FLOAT32 *)a_Writebuffer > PULSE_MAXVALUE) ucRngStatus = OVER_RANGE;
    else if (*(FLOAT32 *)a_Writebuffer < PULSE_MINVALUE) ucRngStatus = UNDER_RANGE;

    if 
    (
#if !defined(IOMTYPE_UIO)
        (BOX->IsExtBdSFActive()) || 
#endif
        (SlotSfBt != 0 && SF_OUTPUT_OC_FL != SlotSfBt)
    ) 
    {
        // if Overcurrent exists and only OUTPUTFL SF & Overcurrent exists on that channel 
        // then allow write to go through so that the Overcurrent SF will be returned from 
        // Post function.
        return DO_INITIALIZATION_ERROR;
    }

// added to fix PAR# 1-EWTQH7B (on pulse & off pulse in not working in do16)
// as per the legacy code, do_type should be status type for on pulse & off pulse
#if !defined(IOPTYPE_DO)
//#if !defined(DIGTYPE_DO32)

    switch (Mode) {
    case MODE_MANUAL:
        switch (ModeAttr) {
        case MODEATTR_PROGRAM:
            ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        case MODEATTR_OPERATOR:
            //if ENGR or SUPERV or OPER (HumanLock)
            if (a_ucAccLvl & ALCK_ONPROC)
                ucStatus = ClampWithWarning(a_Writebuffer, ucRngStatus, DOType);
            else
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        default:
            ucStatus = DO_INVALID_MODE_ATTRIBUTE;
        }
        break;
    case MODE_CASCADE:
        //ALCK_ONPROC_IUSER = ENGR or SUPERV or OPER or IUSER
        if (FALSE == StdbyMan) {
            if ((ALVL_UMCC != a_ucAccLvl) && (ALVL_CC != a_ucAccLvl))
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            else 
                ucStatus = ClampWithWarning(a_Writebuffer, ucRngStatus, DOType);
        }
        break;
    default:
        ucStatus = DO_INVALID_MODE;
    }
#endif

return ucStatus;
}
/*******************************************************************************
*                           clsDoSlot::PostOffPulse                            *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for OffPulse parameter.              *
*           Initialize OFF Pulse variables and start pulse with OFF condition. *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the  OffPulse parameter        *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostOffPulse(UINT8) {
    FaultState = FAULTSTATE_NORMAL;
    // Return the overcurrent softfail if exists
    if (BOX->GetOverCurrent(ChanNum)) {
        BOX->SetOverCurrent(ChanNum, FALSE);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
    }
#if defined(IOMTYPE_UIO)
    ClearOverCurrentSfForAdjChnls();
#endif

#if defined(IOPTYPE_DO)
    // fix for PAR # 1-DYV60ED (DO32 Pulse period feature not working as expected)
    OnPulse = 0;
#else
    OnPulse = NaN;
#endif
    PulseInProgress = TRUE;
    StartPulse(FALSE, OffPulse);
}
/*******************************************************************************
*                           clsDoSlot::PreSO                                   *
*                           ================                                   *
* PURPOSE:  Pre Receiver-Beware function for SO parameter.                     *
*           This method checks for range of the data that can be written to    *
*           SO parameter, module status check, output type check, and access   *
*           level check.                                                       *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the SO parameter               *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreSO(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    PASTATUS ucStatus = PA_OK;

    if ((BOX->GetModuleStatus() != MODSTATUS_RUN)
        || (PtExecSt != PTEXECST_ACTIVE))
        return DO_STATE_MUST_BE_RUN;

    if (LocalMan)
        return DO_POINT_IS_LOCAL_MANUAL;

    if (REDTAG_OFF != RedTag)
            return DO_POINT_IS_RED_TAGGED;

    if (((*(BOOL *)a_Writebuffer) > TRUE) || ((*(BOOL *)a_Writebuffer) < FALSE))
        return DO_ILLEGAL_VALUE;

    if ((DOTYPE_ONPULSE == DOType) || (DOTYPE_OFFPULSE == DOType)) {
        if (MODE_MANUAL == Mode) {
            if (!(a_ucAccLvl & ALCK_ONPROC))
                return DO_ACCESS_LEVEL_INVALID;
        }
        else
            return DO_INVALID_MODE;
    }
    else if (DOTYPE_PWM == DOType)
        return DO_PARAMETER_INVALID;

    // No relay extension board for UIO
#if !defined(IOMTYPE_UIO)
    if (BOX->IsExtBdSFActive()) {
        // if Relay Extension Board Missing
        if (!((Mode == MODE_MANUAL) && (ModeAttr == MODEATTR_OPERATOR))) {
            // if any softfail exists on that channel and in MAN mode and a attribute is operator
            // then allow write to go through.
            return DO_INITIALIZATION_ERROR;
        }
    }
#endif

    // if any softfail exists on that channel and in MAN mode and a attribute is operator
    // then allow write to go through.
    if ((SlotSfBt != 0) && (!((Mode == MODE_MANUAL) && (ModeAttr == MODEATTR_OPERATOR)))) {
        return DO_INITIALIZATION_ERROR;
    }
    switch (Mode) {
    case MODE_MANUAL:
        switch (ModeAttr) {
        case MODEATTR_OPERATOR:
            //if ENGR or SUPERV or OPER (HumanLock)
            if (!(a_ucAccLvl & ALCK_ONPROC))
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        case MODEATTR_PROGRAM:
            if (a_ucAccLvl != ALVL_PROG)
                ucStatus = DO_ACCESS_LEVEL_INVALID;
            break;
        default:
            ucStatus = DO_INVALID_MODE_ATTRIBUTE;
        }
        break;
    case MODE_CASCADE:
        if (FALSE == StdbyMan) {
            if ((ALVL_UMCC != a_ucAccLvl) && (ALVL_CC != a_ucAccLvl))
                ucStatus = DO_ACCESS_LEVEL_INVALID;
        }
        break;
    default:
        ucStatus = DO_INVALID_MODE;
    }
    return ucStatus;
}
/*******************************************************************************
*                           clsDoSlot::PostSO                                  *
*                           ==================                                 *
* PURPOSE:  Post Receiver-Beware function for SO parameter.                    *
*           Drive new SO values and depending on failure option.               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the SO parameter               *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostSO(UINT8) {
    FaultState = FAULTSTATE_NORMAL;
    if (DOTYPE_STATUS ==  DOType) {
        OnPulse = NaN;
        OffPulse = NaN;
    }
    else if (DOTYPE_ONPULSE ==  DOType) {
        OnPulse = 0;
    }
    else if (DOTYPE_OFFPULSE ==  DOType) {
        OffPulse = 0;
    }
    PulseInProgress = FALSE;

    BOX->UpdateOutputBuffer2(ChanNum, SO);

    // UIO does not need to update hold registers
    // << TODO >> Add functionality back in when UIO supports this << TODO >>
#if !defined(IOMTYPE_UIO)
    if ((DOTYPE_STATUS == DOType) && (FAULTOPT_HOLD == FaultOpt)) {
        // Update fault state value in boxslot database and CPLD.
        BOX->SetFaultOutput(ChanNum,SO);
    }
#endif

    // Return the overcurrent softfail
    if (BOX->GetOverCurrent(ChanNum) && TRUE == SO) {
        BOX->SetOverCurrent(ChanNum, FALSE);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
    }
#if defined(IOMTYPE_UIO)
    ClearOverCurrentSfForAdjChnls();
#endif

#if defined(DIGTYPE_DO16)
    BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum-1);
#endif
}
/*******************************************************************************
*                           clsDoSlot::PrePeriod                               *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for Period parameter.                 *
*           This method checks for range of the data that can be written to    *
*           Period parameter. If it is checkpoint write, then check whether    *
*           the new value is same as old value.                                *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the  Period parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:    If write is required, then set TRUE in ScratchPad.                 *
*******************************************************************************/
PASTATUS clsDoSlot::PrePeriod(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if (isnan((*(FLOAT32 *)a_Writebuffer)))
        return DO_ILLEGAL_VALUE;

    if (DOTYPE_PWM != DOType)  {
        if (ALVL_IUSER != a_ucAccLvl)
            return DO_PARAMETER_INVALID;
        else if ((*(FLOAT32 *)a_Writebuffer) != Period)
            return DO_PARAMETER_INVALID;
    }

    if ( ((*(FLOAT32 *)a_Writebuffer) < MIN_PERIOD) ||
         ((*(FLOAT32 *)a_Writebuffer) > MAX_PERIOD) )
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    return PA_OK;
}
/*******************************************************************************
*                           clsDoSlot::PostPeriod                              *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for Period parameter.                *
*           Get the current period and calculate PulseOnTime.                  *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the  Period parameter          *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostPeriod(UINT8) {
    PRDTime = (UINT16)(Period * SCHEDULER_TICKS_IN_SECOND);
    CalcPwmOnTime(Op);
}
/*******************************************************************************
*                           clsDoSlot::PreOptDir                               *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for OptDir parameter.                 *
*           This function checks whether the DoType is PWM or not. If not PWM, *
*           check whether the new write is Check point write and the new data  *
*           matches with the old data.                                         *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the OptDir parameter           *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreOptDir(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    if (DOTYPE_PWM != DOType)  {
        if (ALVL_IUSER != a_ucAccLvl) // check whether it is check point write
            return DO_PARAMETER_INVALID;
        else if (OptDir != *(OPTDIR *)a_Writebuffer)  //if checkpoint write,
            return DO_PARAMETER_INVALID;              // then check with old value
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsDoSlot::PrePntType                              *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for PntType parameter.                *
*           This method checks for range of the data that can be written to    *
*           PntType parameter, access level check, module status check, point  *
*           execution check.                                                   *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PrePntType(UINT8 *a_Writebuffer, UINT8 a_ucAccLvl) {
    this->ScratchPad = *(UINT8 *)a_Writebuffer; // Save for use in post function.
    UINT8 ucModSts = BOX->GetModuleStatus();
    
    if ((ALVL_IUSER == a_ucAccLvl) && (MODSTATUS_IDLE != ucModSts)) {
        return DO_STATE_MUST_BE_IDLE;
    }
    
    if ((MODSTATUS_IDLE != ucModSts) && (PTEXECST_INACTIVE != PtExecSt)) {
        if (PNTTYPE_DIGITALOUTPUT != (PNTTYPE)this->ScratchPad) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
    }

    if (RedTag == REDTAG_ON) {
        return DO_POINT_IS_RED_TAGGED;
    }
    
    if (((PNTTYPE)ScratchPad != PNTTYPE_NOTCONFIGURED)
        && ((PNTTYPE)ScratchPad != PNTTYPE_DIGITALOUTPUT)) {
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;
}

/*******************************************************************************
*                           clsDoSlot::PostPntType                             *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for PntType parameter.               *
*           If point is already configured, initialize the slot fully or if    *
*           point is retained with old value, just initialize new values.      *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PntType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostPntType(UINT8) {
    if ((PNTTYPE)this->ScratchPad == PNTTYPE_NOTCONFIGURED)
    {
#if defined(IOMTYPE_UIO) 
        //if ganging is enabled, initializes h/w interface, 
        //Do channel mask and Disable the DAC for the adjacent channels to default values
        if (EnblGangedOutputs) 
        {
            DeleteAdjacentChannels(ChanNum + 1);
        }
#endif
        InitSlotDatabase(TRUE);
#if defined(IOMTYPE_UIO) 
        UIO_SLOT(ChanNum)->DeleteConfiguredSlot();
#endif
    }
    else
    {
        InitSlotDatabase(FALSE);
    }
}
/*******************************************************************************
*                           clsDoSlot::PrePtExecSt                             *
*                           ======================                             *
* PURPOSE:  Pre Receiver-Beware function for PtExecSt parameter.               *
*           This method checks for range of the data that can be written to    *
*           PtExecSt parameter and access level check.                         *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PtExecSt parameter         *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PrePtExecSt(UINT8 *a_Writebuffer, UINT8) {
    
#if defined(IOPTYPE_DO)
    ScratchPad = PtExecSt; // Save current execution state for post function.
#endif
    
    if ((*(PTEXECST *)a_Writebuffer < PTEXECST_INACTIVE) || 
            (*(PTEXECST *)a_Writebuffer > PTEXECST_ACTIVE))
        return DO_ILLEGAL_VALUE;

    return PA_OK;
}
/*******************************************************************************
*                           clsDoSlot::PostPtExecSt                            *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for PtExecSt parameter.              *
*           Depending on output type, back initializes the slot.               *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PtExecSt parameter         *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostPtExecSt(UINT8) {
    if ((MODSTATUS_RUN == BOX->GetModuleStatus()) && (PTEXECST_ACTIVE == PtExecSt)) {
        BackInit();
#if defined(DIGTYPE_DO16)
        BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
    }
    CmptInitReq();
    // If Channel was set INACTIVE reset the Overcurrent 
    // bit and RTN any alarms related to Overcurrent
    if ((MODSTATUS_IDLE == BOX->GetModuleStatus()) || (PTEXECST_INACTIVE == PtExecSt)) {
        if (BOX->GetOverCurrent(ChanNum)) {
            BOX->SetOverCurrent(ChanNum, FALSE);
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
        }
#if defined(IOMTYPE_UIO)
        ClearOverCurrentSfForAdjChnls();
#endif
#if defined(DIGTYPE_DO16)
        BOX->uiEnableOutputLatch &= ~((UINT16)1 << (ChanNum - 1));
#endif
    }

#if defined(IOPTYPE_DO)
    if ((PTEXECST)ScratchPad != PtExecSt)// point execution state changed
    CreatePtExecStEvt(EVENTTYPE_NORMAL);        
#endif
}

#if defined(IOPTYPE_DO)
/*******************************************************************************
*                          clsDoSlot::CreatePtExecStEvt                       *
*                          =============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS: a_EventType - Normal / Recovery                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::CreatePtExecStEvt(EVENTTYPE a_EventType) {
    EVENTRECORD PtExecStEvent;

    PtExecStEvent.Overflow = FALSE;
    PtExecStEvent.ContactCutout = FALSE;
    PtExecStEvent.Qualifier = a_EventType;
    PtExecStEvent.CurrentState = EVENTSTATE_RETURN;
    PtExecStEvent.EventPacket = EVENTPACKET_SYSTEM;
    PtExecStEvent.SystemEvent.SoftfailStatus = FALSE;
    PtExecStEvent.SystemEvent.ChannelNumber = ChanNum;

    //IF CURRENT PTEXECST = ON
    if (PTEXECST_ACTIVE == PtExecSt)
    {
        PtExecStLrs |= PTEXECST_ON_LRSBIT;

        if (PtExecStLrs & PTEXECST_OFF_LRSBIT)
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_OFF_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_OFF_LRSBIT;
            }
        }
        else
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_ON_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_ON_LRSBIT;
            }
        }
    }
    else //(PTEXECST_INACTIVE == PtExecSt)
    {
        PtExecStLrs |= PTEXECST_OFF_LRSBIT;

        if (PtExecStLrs & PTEXECST_ON_LRSBIT)
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_ON_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_ON_LRSBIT;
            }
        }
        else
        {
            PtExecStEvent.SystemEvent.EventSubType = PTEXECST_OFF_SUBEVT;

            if (BOX->AddPtExecStEvent(&PtExecStEvent) == TRUE)
            {
                PtExecStLrs &= ~PTEXECST_OFF_LRSBIT;
            }
        }
    }
}

#endif
/*******************************************************************************
*                           clsDoSlot::PreDOType                               *
*                           =====================                              *
* PURPOSE:  Pre Receiver-Beware function for DOType parameter.                 *
*           This method checks for range of the data that can be written to    *
*           DOType parameter.                                                  *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the  DOType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:    If write is required, then set TRUE in ScratchPad.                 *
*******************************************************************************/
PASTATUS clsDoSlot::PreDOType(UINT8 *a_Writebuffer, UINT8) {
    if ( ((*(DOTYPE *)a_Writebuffer) < DOTYPE_STATUS) || 
         ((*(DOTYPE *)a_Writebuffer) > DOTYPE_OFFPULSE))
        return DO_ILLEGAL_VALUE;
    else {
        if (*(DOTYPE *)a_Writebuffer != DOType) this->ScratchPad = TRUE;
        else this->ScratchPad = FALSE;

        return PA_OK;
    }
}
/*******************************************************************************
*                           clsDoSlot::PostDOType                              *
*                           ======================                             *
* PURPOSE:  Post Receiver-Beware function for DOType parameter.                *
*           If DOType parameter is changed, then initialize the slot and if it *
*           is PWM, initialze the PWM variables and set PWMInitRequest flag.   *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the  DOType parameter          *
* RETURN:                                                                      *
*           PA_OK           -   On succesfull completion of fuction            *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostDOType(UINT8) {
    // save value of DOType in local variable
    // to restore it after defaulting the slot
    DOTYPE ucNewDOType = DOType;
    
    if (TRUE == this->ScratchPad) {
        InitSlotDatabase(TRUE);
        DOType = ucNewDOType;
        
        if (DOType == DOTYPE_PWM) {
            TPStart     = 0;
            StartNext   = TRUE;
        }
    }
}
/*******************************************************************************
*                           clsDoSlot::CalcPwmOnTime                           *
*                           ========================                           *
* PURPOSE:  Utitlity function which calculates Pulse ON Time.                  *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::CalcPwmOnTime(FLOAT32 Value) {
    if (OPTDIR_REVERSE == OptDir)
        PWMPulseTime = (UINT16)((OP_MAXVALUE - Value) * Period);
    else
        PWMPulseTime = (UINT16)(Value * Period);
}
/*******************************************************************************
*                      clsDoSlot::ClampWithWarning                             *
*                      ===========================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::ClampWithWarning(UINT8 *a_Writebuffer, UINT8 a_ucRngStatus, 
                                     DOTYPE a_DOType) {
    if (OVER_RANGE == a_ucRngStatus) {
        if (DOTYPE_PWM == a_DOType) {
            *(FLOAT32 *)a_Writebuffer  = OP_MAXVALUE;
        }
        else if ((DOTYPE_ONPULSE == a_DOType) || (DOTYPE_OFFPULSE == a_DOType)) {
            *(FLOAT32 *)a_Writebuffer  = PULSE_MAXVALUE;
        }
        return DO_VALUE_CLAMPED_ERROR;
    }
    else if (UNDER_RANGE == a_ucRngStatus) {
        *(FLOAT32 *)a_Writebuffer  = OP_MINVALUE;
        return DO_VALUE_CLAMPED_ERROR; 
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsDoSlot::InitSlotDatabase                          *
*                         ===========================                          *
* PURPOSE:  Utility function which initializes the slot depending on point     *
*           configuration.                                                     *
* ARGUMENTS:                                                                   *
*           bFullInit       -   Full init flag.                                *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::InitSlotDatabase(BOOL bFullInit) {
    BOOL bObjCreate = FALSE;
    PNTTYPE PntType = PNTTYPE_DIGITALOUTPUT;
    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitOutSlot(PntType, bFullInit, bObjCreate);
    InitDoSlot(bFullInit, bObjCreate);
    ComputeCheckSum(); // Recompute SLOT checksum

    if (bFullInit) {
        CmptInitReq();
        BOX->UpdateOutputBuffer2(ChanNum, FALSE);
#if defined(DIGTYPE_DO16)
        // added due to PAR# 1-919CFFZ (few channels were holding last value even after deleting channels from monitor)
        // enabling output latch enable flag
        BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
    }
}
/*******************************************************************************
*                             clsDoSlot::InactivateSlot                        *
*                             =========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::InactivateSlot(VOID) {
    PostPtExecSt(0);
}
/*******************************************************************************
*                           clsDoSlot::BackInit                                *
*                           =====================                              *
* PURPOSE:  Back initializes the slot depending on the output type.            *
*           If output type is STATUS, write the screw value to SO if and only  *
*           if it agrees with the driven value else write the OFF state.       *
*           If PWM type, update OP value according to the outputs present      *
*           state and OPTDIR.                                                  *
*           Actual PWM output should reflect the previous one, till the new OP *
*           write comes).                                                      *
*           If ONPULSE or OFFPULSE type, set the output to its queiscent state *
* ARGUMENTS:                                                                   *
*           NONE.                                                              *
* RETURN:   NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::BackInit(VOID) {
    // Depending on DOType, do the corresponding back init.
    if (DOTYPE_STATUS == DOType) {
        // Back initialize SO from the intersection of the output register and
        // the readback register.
#if defined(IOMTYPE_UIO)
        SO = FPGA.ReadDigitalOutput(ChanNum);
#else
        UINT8 ucBank = (ChanNum - 1) >> 0x03, ucMask = 0x01 << ((ChanNum - 1) & 0x07);

        ((*BOX->OutputPorts[ucBank]) & (GetReadbackRegister(RDBK_BANK2+ucBank)) & ucMask) ? (SO = TRUE): (SO = FALSE);
        BOX->UpdateOutputBuffer2(ChanNum, SO);
#endif
    }
    else if (DOTYPE_PWM ==  DOType) {
        // Initialize the OP value.
        FLOAT32 ufTemp = OP_MINVALUE;

        ufTemp = (FLOAT32)((PWMPulseTime * OP_MAXVALUE)/ PRDTime);

        if (OPTDIR_REVERSE == OptDir)
        {
            Op = 100 - ufTemp;
        }
        else
        {
            Op = ufTemp;
        }
#if defined(IOMTYPE_UIO)
        BOX->SetDoOp(ChanNum, Op);
#endif
    }
    else { //OnPulse or OffPulse
        DriveToQuiescentState();
    }
}
/*******************************************************************************
*                           clsDoSlot::CmptInitReq                             *
*                           ======================                             *
* PURPOSE:  Does Pulse output operation                                        *
* ARGUMENTS:                                                                   *
*           bPulseType    -   type of output to be driven (ON/OFF).            *
*           a_ufPulseTime -   Pulse time in seconds                            *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::CmptInitReq(VOID) {
    UINT8 ucModSts = BOX->GetModuleStatus();
    BOOL bInitReq;
    bInitReq = ((DOTYPE_PWM == DOType)  ||
                (PTEXECST_INACTIVE == PtExecSt) ||
                (MODSTATUS_RUN != ucModSts)     ||
#if defined(IOPTYPE_DO)
                !(BOX->GetFtaPres())            ||
                (SlotSfBt));
#else
                (StdbyMan)                      || 
#if !defined(IOMTYPE_UIO)
                (BOX->IsExtBdSFActive())        || 
#endif
                (MODE_CASCADE != Mode)          || 
                (FAULTSTATE_FAULTED == FaultState));
#endif                
    
#if !defined(IOMTYPE_UIO) //&& !defined(IOPTYPE_DO)
    // fix for PAR # 1-DYV60ES (added for all DO types)
    BOX->SetInitReq(ChanNum, bInitReq);
#endif

    PWMInitR = ((DOTYPE_PWM != DOType)            ||
                (PTEXECST_INACTIVE == PtExecSt) ||
                (MODSTATUS_RUN != ucModSts)     ||
#if defined(IOPTYPE_DO)
                !(BOX->GetFtaPres())            ||
                (SlotSfBt));
#else
                (MODE_CASCADE != Mode)          ||
                (StdbyMan)                      ||
#if !defined(IOMTYPE_UIO)
                (BOX->IsExtBdSFActive())        ||
#endif
                (FAULTSTATE_FAULTED == FaultState));
#endif                
                
   // UIO only has one INITREQUEST field in the scan record.
   // Set INITREQUEST based on the channel type.
#if defined(IOMTYPE_UIO)// || defined(IOPTYPE_DO) // fix for PAR # 1-DYV60ES (removed for DO)
    if (DOType == DOTYPE_PWM)
    {
        BOX->SetInitReq(ChanNum, PWMInitR);
    }
    else
    {
        BOX->SetInitReq(ChanNum, bInitReq);
    }
#endif
}
/*******************************************************************************
*                           clsDoSlot::ProcessDoSlot                           *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::ProcessDoSlot(VOID)
{
#if defined(IOPTYPE_DO) && (0)
    if (FTA_MISSING != BOX->GetFtaPres())
#endif
    {
        // Do Pulse and PWM processing.
        switch (DOType) {
        case DOTYPE_PWM:
#if defined(PMIO_DEBUG) && (0)
            if ((ucDbgPnt == BKPT_DBGPNT) & (ChanNum < 5))
            {                
                ucDumpBuff[ucDbgCnt++] = ChanNum;
                ucDumpBuff[ucDbgCnt++] = StartNext;
                ucDumpBuff[ucDbgCnt++] = (TPStart & 0xFF000000) >> 24;
                ucDumpBuff[ucDbgCnt++] = (TPStart & 0x00FF0000) >> 16;
                ucDumpBuff[ucDbgCnt++] = (TPStart & 0x0000FF00) >> 8;
                ucDumpBuff[ucDbgCnt++] = (TPStart & 0x000000FF);
                ucDumpBuff[ucDbgCnt++] = (TPEnd & 0xFF000000) >> 24;
                ucDumpBuff[ucDbgCnt++] = (TPEnd & 0x00FF0000) >> 16;
                ucDumpBuff[ucDbgCnt++] = (TPEnd & 0x0000FF00) >> 8;
                ucDumpBuff[ucDbgCnt++] = (TPEnd & 0x000000FF);
                ucDumpBuff[ucDbgCnt++] = (PWMPulseTime & 0xFF00) >> 8;
                ucDumpBuff[ucDbgCnt++] = (PWMPulseTime & 0x00FF);
            }
#endif
            //check StartNext to see whether it is Starting or Ending
            if (TRUE == StartNext) { //PWM cycle start
                if (TPStart <= 0) {
                    TPStart += PRDTime;
                    if (PWMPulseTime > 0) { //powerup pwm
                        BOX->UpdateOutputBuffer2(ChanNum, TRUE);
#if defined(DIGTYPE_DO16)
                        BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
                        if (PWMPulseTime <= PRDTime) {
                            TPEnd = PWMPulseTime;
                            StartNext = FALSE;
                        }
                    }//End of PWMPulseTime
                    else { // unpwerup pwm as Op = 0
                        BOX->UpdateOutputBuffer2(ChanNum, FALSE);
#if defined(DIGTYPE_DO16)
                        BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
                        StartNext = FALSE;
                        TPEnd = 0;
                    }
                }//End of TPStart
            }//End of StartNext
            else { // Check for PWM cycle end
                if (TPEnd <= 0) { // PWM cycle end
                    if (PWMPulseTime != PRDTime)
                        BOX->UpdateOutputBuffer2(ChanNum, FALSE);
#if defined(DIGTYPE_DO16)
                    BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
                    StartNext = TRUE;
                }
                else {
                    TPEnd--;
                }
            }// end of Pulse End loop
            // Decrement the TPStart count i.e. period count
            if (TPStart > 0) TPStart--;
            break;
#if defined(IOPTYPE_DO)
            // fix for PAR # 1-DYV60ED (DO32 Pulse period feature not working as expected)
        case DOTYPE_STATUS:
            if (TRUE == PulseInProgress) {
                if (TPEnd <= 0) {

                         if (OnPulse  != 0) BOX->UpdateOutputBuffer2(ChanNum, FALSE); // ON PULSE
                    else if (OffPulse != 0) BOX->UpdateOutputBuffer2(ChanNum, TRUE);  // OFF PULSE

                        // added to fix PAR# 1-EWTQH7B (on pulse & off pulse in not working in do16)
#if defined(DIGTYPE_DO16)
                         BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
                    PulseInProgress = FALSE;
                }
                else {
                    TPEnd--;
                }
            }
            break;
#else
        case DOTYPE_ONPULSE:
            if (TRUE == PulseInProgress) {
                if (TPEnd <= 0) {
                    BOX->UpdateOutputBuffer2(ChanNum, FALSE);
                    PulseInProgress = FALSE;
                }
                else {
                    TPEnd--;
                }
            }
            break;
        case DOTYPE_OFFPULSE:
            if (TRUE == PulseInProgress) {
                if (TPEnd <= 0) {
                    BOX->UpdateOutputBuffer2(ChanNum, TRUE);
                    PulseInProgress = FALSE;
                }
                else {
                    TPEnd--;
                }
            }
            break;
#endif
        default:
            break;
        }
    }

    CmptInitReq();
}
/*******************************************************************************
*                           clsDoSlot::StartPulse                              *
*                           =====================                              *
* PURPOSE:  Does Pulse output operation                                        *
* ARGUMENTS:                                                                   *
*           bPulseType    -   type of output to be driven (ON/OFF).            *
*           a_ufPulseTime -   Pulse time in seconds                            *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::StartPulse(BOOL bPulseType, FLOAT32 a_ufPulseTime) {
    BOOL bPulsedState = bPulseType;
    if (a_ufPulseTime == 0) {
        bPulsedState = ! bPulseType;
        PulseInProgress = FALSE;
    }

    BOX->UpdateOutputBuffer2(ChanNum, bPulsedState);
    TPEnd = ((UINT32)(a_ufPulseTime * 100));

    // added to fix PAR# 1-EWTQH7B (on pulse & off pulse in not working in do16)
#if defined(DIGTYPE_DO16)
    BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
}
/*******************************************************************************
*                      clsDoSlot::SlotFaultHandler                             *
*                      ===========================                             *
* PURPOSE:   This function drives the output to configured FaultOpt values,    *
*            if the COM/CTL TOG fails. If the DOType configured is OffPulse or  * 
*            OnPulse, drive the output to configured FaultOpt                  *
*            If the FaultOpt == HOLD, DO NOTHING.                              *
*            If the point is REDTAGGED, DO NOTHING.                            *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::SlotFaultHandler(TOG_FAILED a_TogFailed) {
    FLOAT32     NewValue;
    BOOL        NewState;

    // If RedTag is ON for this channel do nothing...
    if (REDTAG_ON == RedTag) return;

    // Do not shed the output if only control tog failed
    // and the ouput is in manual-operator control.
    if ((CTLTOG_FAILED == a_TogFailed) && 
        (MODE_MANUAL == Mode) && (MODEATTR_OPERATOR == ModeAttr)) {
        return;
    }

    FaultState = FAULTSTATE_FAULTED; // Mark the slot as faulted.
    CmptInitReq();

    // If FaultOpt is HOLD for this channel do nothing...
    if (FaultOpt == FAULTOPT_HOLD) return;

    switch (DOType) {
        case DOTYPE_ONPULSE:
            if (FaultOpt == FAULTOPT_UNPOWERED) {
                PulseInProgress = FALSE;
                OnPulse = 0;
                BOX->UpdateOutputBuffer2(ChanNum, FALSE);
            }
            break;
        case DOTYPE_OFFPULSE:
            if (FaultOpt == FAULTOPT_UNPOWERED) {
                PulseInProgress = FALSE;
                OffPulse = 0;
                BOX->UpdateOutputBuffer2(ChanNum, FALSE);
            }
            break;
        case DOTYPE_PWM:
            switch (FaultOpt) {
                case FAULTOPT_POWERED:
                    NewValue = (OptDir  == OPTDIR_REVERSE) ? OP_MINVALUE : OP_MAXVALUE;
                    break;
                case FAULTOPT_UNPOWERED:
                    NewValue = (OptDir  == OPTDIR_REVERSE) ? OP_MAXVALUE : OP_MINVALUE;
                    break;
                case FAULTOPT_FAULTVALUE: {
                    NewValue = FaultValue;
                    if (TRUE == BOX->GetOverCurrent(ChanNum)) {
                        BOX->SetOverCurrent(ChanNum, FALSE);
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
                    }
#if defined(IOMTYPE_UIO)
                    ClearOverCurrentSfForAdjChnls();
#endif
                    }
                    break;
            }
            CalcPwmOnTime(NewValue);
            if (BOX->GetModuleStatus() == MODSTATUS_RUN && PtExecSt == PTEXECST_ACTIVE)
            {
                Op = NewValue;
#if defined(IOMTYPE_UIO)
                BOX->SetDoOp(ChanNum, Op);
#endif
            }
            break;
        case DOTYPE_STATUS:
            if (FaultOpt == FAULTOPT_POWERED) {
                NewState = TRUE;
                if (TRUE == BOX->GetOverCurrent(ChanNum)) {
                    BOX->SetOverCurrent(ChanNum, FALSE);
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum);
                }
#if defined(IOMTYPE_UIO)
                ClearOverCurrentSfForAdjChnls();
#endif
            }
            else if (FaultOpt == FAULTOPT_UNPOWERED)
                NewState = FALSE;
            BOX->UpdateOutputBuffer2(ChanNum, NewState);
            if (BOX->GetModuleStatus() == MODSTATUS_RUN && PtExecSt == PTEXECST_ACTIVE)
                SO = NewState;
            break;
    }

// to fix PAR# 1-EMPNLXD (channel OP does not take failure option value when both IOLink is removed) during FaultUnpowered condition
#if defined(DIGTYPE_DO16)
    BOX->uiEnableOutputLatch |= (UINT16)1 << (ChanNum - 1);
#endif
}
/*******************************************************************************
*                      clsDoSlot::DriveToQuiescentState                        *
*                      ================================                        *
* PURPOSE:   If the DOType is OffPulse or OnPulse and if the last values of    *
*            OffPulse and OnPulse are good values, then drive the output to    *
*            Quiescent state. And stop the ongoing pulse train.                *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::DriveToQuiescentState(VOID) {
    if (DOTYPE_OFFPULSE == DOType) {
        // If last value is good value, stop the current pulse and 
        // drive to Quiscent state.
        PulseInProgress = FALSE;
        OffPulse = 0;
        BOX->UpdateOutputBuffer2(ChanNum, TRUE);
    }
    else if (DOTYPE_ONPULSE == DOType) {
        // If last value is good value, stop the current pulse and 
        // drive to Quiscent state.
        PulseInProgress = FALSE;
        OnPulse = 0;
        BOX->UpdateOutputBuffer2(ChanNum, FALSE);
    }
}

VOID clsDoSlot::OverCurrentAction(VOID) {
    FLOAT32 NewValue;
    // Shed the Mode to MANULA and ModeAttr to Operator to avoid further writes coming down.
    // ModeAttr to Operator will avoid further writes coming from SCM.
    Mode = MODE_MANUAL;
    ModeAttr = MODEATTR_OPERATOR;

    if ( (DOTYPE_OFFPULSE == DOType) || (DOTYPE_ONPULSE == DOType)) {
        PulseInProgress = FALSE;
        BOX->UpdateOutputBuffer2(ChanNum, FALSE);
    }
    else if (DOTYPE_STATUS == DOType) {
        SO = FALSE;
        BOX->UpdateOutputBuffer2(ChanNum, FALSE);
    }
    else {
        // We have to Shed the OP to 0% so as to avoid retriggering of PWM.
        BOX->UpdateOutputBuffer2(ChanNum, FALSE);
        NewValue = (OptDir  == OPTDIR_REVERSE) ? OP_MAXVALUE : OP_MINVALUE;
        CalcPwmOnTime(NewValue);
        Op = NewValue;
#if defined(IOMTYPE_UIO)
        BOX->SetDoOp(ChanNum, Op);
#endif
    }
}

/*******************************************************************************
*                          clsDoSlot::IsOutputNotViable                        *
*                          ============================                        *
* PURPOSE:                                                                     *
*   Checks to see if writing a value to the OP/SO parameter will be invalid    *
*   because of an existing soft failure and being in MAN mode with Operator    *
*   attribute.                                                                 *
* ARGUMENTS:                                                                   *
*   ucParamId - Parameter ID of parameter being written                        *
* RETURN:                                                                      *
*   TRUE when writing to OP/SP parameter while in MAN mode with Operator       *
*   attribure; Otherwise, return FALSE.
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
BOOL clsDoSlot::IsOutputNotViable(UINT8 ucParamId) 
{
    // Return TRUE only for OP/SO param write in MAN mode with Operator
    // attribute and if there is any softfail on slot.
    if ((ucParamId != PARAMID_OP) && (ucParamId != PARAMID_SO)) return FALSE;
    if ((SlotSfBt != 0) && (!((Mode == MODE_MANUAL) && (ModeAttr == MODEATTR_OPERATOR)))) return TRUE;
    return FALSE;
}

#if defined(IOMTYPE_UIO)
/*******************************************************************************
*                          clsDoSlot::GetSlotChkPntParamId                     *
*                          ===============================                     *
* PURPOSE:                                                                     *
*   Checks to see if the given parameter code is for the checkpoint /          *
*   configuration restore parameter.                                           *
* ARGUMENTS:                                                                   *
*   a_ucParamNumber - Parameter code to check                                  *
* RETURN:                                                                      *
*   TRUE if the given parameter code is for checkpoint / configuration restore *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsDoSlot::GetSlotChkPntParamId(VOID)
{
    return PARAMID_SLTCHKPNT;
}

/*******************************************************************************
*                          clsDoSlot::GetPtExecStParamId                       *
*                          ==============================                      *
* PURPOSE:                                                                     *
*   Returns the parameter code for the point execution state parameter.        *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   Parameter code for the point execution state parameter                     *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsDoSlot::GetPtExecStParamId(VOID)
{
    return PARAMID_PTEXECST;
}

/*******************************************************************************
*                      clsDoSlot::GetLatestSlotChkPntVersion                   *
*                      ======================================                  *
* PURPOSE:                                                                     *
*   Returns the latest slot checkpoint version number                          *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   Latest slot checkpoint version number                                      *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
UINT8 clsDoSlot::GetLatestSlotChkPntVersion(VOID)
{
    return LATEST_SLTCHKPNT_VERSION;
}

/*******************************************************************************
*                          clsDoSlot::PreInitPntType                           *
*                          =========================                           *
* PURPOSE:                                                                     *
*   This methods checks to see if the InitPntType parameter can be written     *
*   to the slot.                                                               *
* ARGUMENTS:                                                                   *
*   a_WriteBuffer - Pointer to data for the InitPntType parameter              *
*   a_ucAccLvl    - Access level of the InitPntType parameter.                 *
* RETURN:                                                                      *
*   Returns PA_OK if the parameter can be written.                             *
* NOTES:                                                                       *
*   NONE                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreInitPntType(UINT8 *a_Writebuffer, UINT8)
{
    // Value of the parameter being written
    PNTTYPE valueBeingWritten = *(PNTTYPE *)a_Writebuffer;

    // Return Value (assume failure)
    PASTATUS rtnValue = DO_ILLEGAL_VALUE;
    
    // If the value being written is PNTTYPE_DIGITALOUTPUT,
    // allow the store to occur.
    if (valueBeingWritten == PNTTYPE_DIGITALOUTPUT) 
    {
        rtnValue = PA_OK;
    }

    return rtnValue;
}

/*******************************************************************************
*                             clsDoSlot::PostOwd                               *
*                             ==================                               *
* PURPOSE:                                                                     *
*   Sets the DAC to 1 mA if open wire detection was enabled.  If open wire     *
*   detection is disabled, disable the DAC if the channel is not on.           *
* ARGUMENTS:                                                                   *
*   NONE                                                                       *
* RETURN:                                                                      *
*   NONE                                                                       *
* NOTES:                                                                       *
*   See UIO Cookbook, Chapter 33 (04/27/2012) for discussion on DAC management *
*******************************************************************************/
VOID clsDoSlot::PostOwd(UINT8)
{
    if (OwdEnable)
    {
        // Turn on the DAC to support open wire detection
        FPGA.EnableDigitalOutputDac(ChanNum);

        //Turn on the DAC for adjacent channels, if output ganging is enabled.
        if (EnblGangedOutputs)
        {
            for(int nChanCount=1;nChanCount<NumOfChnlsGanged;nChanCount++)
            {
                // Turn on the DAC to support open wire detection
                FPGA.EnableDigitalOutputDac(ChanNum + nChanCount);
            }
        }
        
    }
    else
    {
        // Keep the DAC enabled if the channel is on to support detection
        // of short circuits.  If the channel is not on, disable the DAC. 
        if (!FPGA.ReadDigitalOutput(ChanNum))
        {
            FPGA.DisableDigitalOutputDac(ChanNum);

            //disable the DAC for adjacent channels, if output ganging is enabled
            if (EnblGangedOutputs)   
            {
                for(int nChanCount=1;nChanCount<NumOfChnlsGanged;nChanCount++)
                {
                    FPGA.DisableDigitalOutputDac(ChanNum + nChanCount);
                }
            }
        }
    }
}

/*******************************************************************************
*                          clsDoSlot::PreNumOfChnlsGanged                      *
*                          =============================                       *
* PURPOSE:  Pre Receiver-Beware function for EnblGangedOutputs parameter.      *
*           This method checks for range of the data that can be written to    *
*           NumOfChnlsGanged parameter                                         *
* ARGUMENTS:                                                                   *
*           a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level of the PtExecSt parameter         *
* RETURN:                                                                      *
*           PA_OK           -   If check is succesfull                         *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsDoSlot::PreNumOfChnlsGanged(UINT8 *a_Writebuffer, UINT8)
{
    // Value of the parameter being written
    UINT8 eNewValue = *(NUMOFCHNLSGANGED *)a_Writebuffer;

    if ((eNewValue < NUMOFCHNLSGANGED_TWO) || (eNewValue > NUMOFCHNLSGANGED_FOUR))
    {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    return PA_OK;
}

/*******************************************************************************
*                          clsDoSlot::PostNumOfChnlsGanged                     *
*                          ===============================                     *
* PURPOSE:  Post Receiver-Beware function for NumOfChnlsGanged parameter.      *
*           configures adjacent channels if ganging is enabled and initializes *
*           the adjacent channels to default value if NumOfChnlsGanged value   *
*           is different from previous value                                   *
* ARGUMENTS:                                                                   *
*           a_ucAccLvl      -   Access level of the PtExecSt parameter         *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsDoSlot::PostNumOfChnlsGanged(UINT8)
{
    //Checks for ganging is enabled
    if (EnblGangedOutputs)
    {
        //configures the adjacent channels
        ConfigureAdjacentChannels(ChanNum + 1);
    }
}

/******************************************************************************
*                       clsDoSlot::ConfigureAdjacentChannels                  *
*                          ==================================                 *
* PURPOSE:Configures h/w interface, Do channel mask and Enable/Disable the    *
*         DAC for Adjacent channels                                           *
* ARGUMENTS:                                                                  *
*   a_ucChanStart - adjacent channel number                                   *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
******************************************************************************/
VOID clsDoSlot::ConfigureAdjacentChannels(UINT8 a_ucChanStart)
{
    for(int nChanCount = a_ucChanStart;nChanCount < (ChanNum + NumOfChnlsGanged);nChanCount++)
    {
        // Call HW interface to setup hardware for adjacent channel
        FPGA.ConfigureChannel(nChanCount,PntType);

        //Setup the channel mask
        BOX->SetDOMask(nChanCount);

        if (OwdEnable)
        {
            // Turn on the DAC to support open wire detection
            FPGA.EnableDigitalOutputDac(nChanCount);
        }
        else
        {
            // Keep the DAC enabled if the channel is on to support detection
            // of short circuits.  If the channel is not on, disable the DAC.
            if (!FPGA.ReadDigitalOutput(nChanCount))
            {
                FPGA.DisableDigitalOutputDac(nChanCount);
            }
        }
    }
}

/******************************************************************************
*                       clsDoSlot::DeleteAdjacentChannels                     *
*                       =================================                     *
* PURPOSE:Initializes h/w interface, Do channel mask and Disable the DAC for  *
*         Adjacent channels                                                   *
* ARGUMENTS:                                                                  *
*   a_ucChanStart - adjacent channel number                                   *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
******************************************************************************/
VOID clsDoSlot::DeleteAdjacentChannels(UINT8 a_ucChanStart)
{
    for(int nChanCount = a_ucChanStart;nChanCount < (ChanNum + NumOfChnlsGanged);nChanCount++)
    {
        BOX->UpdateOutputBuffer2(nChanCount, FALSE);

        // Call HW interface to place hardware in safe state for adjacent channel
        FPGA.ConfigureChannel(nChanCount, PNTTYPE_NOTCONFIGURED);

        // disable the FPGA digital output DAC  for adjacent channel
        FPGA.DisableDigitalOutputDac(nChanCount);
        
        // clear the DO mask for adjacent channel
        BOX->ClearDOMask(nChanCount);
    }
}

/******************************************************************************
*                       clsDoSlot::ClearOverCurrentSfForAdjChnls               *
*                       =================================                     *
* PURPOSE:clears the over currnet softfail for do ganging adjacent channels   *
*         if it is already set                                                *
* ARGUMENTS:                                                                  *
*   a_ucChan      - Parent DO channel                                         *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
******************************************************************************/
VOID clsDoSlot::ClearOverCurrentSfForAdjChnls(VOID)
{

    if (EnblGangedOutputs) 
    { 
     for(int nChanCount=1;nChanCount<NumOfChnlsGanged;nChanCount++) 
     { 
         if (BOX->GetOverCurrent(ChanNum+nChanCount))  
         { 
             BOX->SetOverCurrent(ChanNum+nChanCount, FALSE); 
             BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,FALSE,ChanNum+nChanCount); 
         } 
     } 
    } 
}

#endif
