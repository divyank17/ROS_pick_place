/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hart.cpp                                                    *
*    Description : HART global data and functions.                             *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/

#ifdef IOMTYPE_UIO
    #include "uiomain.h"

    // When the compiler first enters hart.cpp UIO_HART_GLOBAL and UIO_HART_SLOTS are not defined.
    // On first pass through hart.cpp define UIO_HART_GLOBAL to process Global Variables and Functions.
    // These are encapsulated by #ifndef UIO_HART_SLOTS and the comments "Start/End Global Variables and Functions".

    // On second pass through hart.cpp change the context by defining UIO_HART_SLOTS, IOMTYPE_AIH, and redefining 
    // SLOT(n) to AIH_SLOT(n). This will process all slot data members and functions conditionally compiled based 
    // on the IOM type. UIO_HART_SLOTS will direct the compiler to skip the Global Functions/Variables and process
    // just the functions encapsulated by #ifndef UIO_HART_GLOBAL and the comments "Start/End Slot Variables and Functions"
    // in the context of the AIH module.

    // On the third and final pass through hart.cpp UIO_HART_SLOTS and IOMTYPE_AIH are defined. Undefine IOMTYPE_AIH,
    // define IOMTYPE_AOH and redefine SLOT(n) to AOH_SLOT(n). This will again skip the Global Functions/Variables and process
    // just the functions encapsulated by #ifndef UIO_HART_GLOBAL and the comments "Start/End Slot Variables and Functions"
    // in the context of the AOH module.

    #ifndef UIO_HART_GLOBAL
        #ifndef UIO_HART_SLOTS
            #define UIO_HART_GLOBAL
        #endif
    #endif
#endif

// UIO will compile this file with IOMTYPE_AIH and IOMTYPE_AOH defined.
// Intentionally preventing aihmain.h and aohmain.h from being included in those contexts.
#ifndef IOMTYPE_UIO
    #ifdef IOMTYPE_AIH
    #include "aihmain.h"
    #endif
    #ifdef IOMTYPE_AOH
    #include "aohmain.h"
    #endif
#endif



#ifndef UIO_HART_SLOTS
// ------------------------------------
// Start Global Variables and functions
// ------------------------------------

/*******************************************************************************
*                               GLOBAL VARIABLES                               *
*******************************************************************************/
// Memory for HART channels receive buffers
UINT8 g_ucHChanRcvBuffer[HART_CHANBUFFER_SIZE * MAXSLOTS];
UINT8 *g_pucHChanRcvBuffer = g_ucHChanRcvBuffer;

// Memory for HART passthrough request buffers
#if defined(IOMTYPE_UIO)
#pragma section EXTERNALRAM_SECTION
UINT8 g_ucHPstReqBuffer[HARTMODEM_COUNT][HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];
#pragma section

// Memory for HART passthrough receive buffers
UINT8 g_ucHPstRcvBuffer[HARTMODEM_COUNT * HART_MAX_BYTECOUNT * HPST_OBJECTCOUNT];
UINT8 *g_pucHPstRcvBuffer = g_ucHPstRcvBuffer;

// Memory for HART passthrough objects
// Each modem has its own set of pass-through objects
UINT16 g_usHPstObjMemory[HARTMODEM_COUNT * CLSHARTPST_SIZE * HPST_OBJECTCOUNT];
clsHartPst *pUioHartPst[HARTMODEM_COUNT][HPST_OBJECTCOUNT];

// Memory for modem object
UINT16 g_usModemObjectMemory[HARTMODEM_COUNT * CLSHARTMODEM_SIZE];
clsHartModem *pHartModem[HARTMODEM_COUNT];

// Memory for queue objects (one per modem)
UINT16 g_usHartQueueObjectMemory[HARTMODEM_COUNT * CLSHARTQUEUE_SIZE];
clsHartQueue *pHartQueue[HARTMODEM_COUNT];

#else
// Memory for HART passthrough request buffers
UINT8 g_ucHPstReqBuffer[HPST_OBJECTCOUNT][HART_MAX_BYTECOUNT];

// Memory for HART passthrough receive buffers
UINT8 g_ucHPstRcvBuffer[HART_MAX_BYTECOUNT * HPST_OBJECTCOUNT];
UINT8 *g_pucHPstRcvBuffer = g_ucHPstRcvBuffer;

// Memory for HART passthrough objects
UINT16 g_usHPstObjMemory[CLSHARTPST_SIZE * HPST_OBJECTCOUNT];
clsHartPst *pHartPst[HPST_OBJECTCOUNT];

// Memory for modem object
UINT16 g_usModemObjectMemory[HARTMODEM_COUNT * CLSHARTMODEM_SIZE];
clsHartModem *pHartModem[HARTMODEM_COUNT];

clsHartQueue HartQueue;
#endif
/*******************************************************************************
*                               isHartCapable                                  *
*                               =============                                  *
* PURPOSE: Determine if the HW is HART capable                                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Called by aihmain and aohmain. Meaningless if it is called by di/do   *
*        If MUXADDR (0x80010) is Read Only, the module is Hartless             *
*******************************************************************************/
BOOL isHartCapable(VOID) {
#if LOWCOST
    return FALSE;   // LOWCOST is not HART
#elif defined(IOMTYPE_UIO)
    // UIO supports HART
    return TRUE;
#else
    if (HART_MUXADDR == 0x0000)   // initial state?
    {
        HART_MUXADDR = 0xA5A5;   // Write some value
        IdleWait(1);
        if (HART_MUXADDR == 0x0000)
        {
            return FALSE;    // all Read Only, this is Hartless
        }
        else  // writable, HART module
        {
            HART_MUXADDR = 0x0000; // restore the data
        }
    }
    // if not 0, it is already used as HART
    return TRUE;
#endif
}

/*******************************************************************************
*                               CheckAndInitHart                               *
*                               ================                               *
* PURPOSE:      Initialize HART registers for HART modules                     *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is HART            *
*******************************************************************************/
VOID CheckAndInitHart(VOID) {
    MODLTYPE ModuleType = BOX->GetModuleType();
    if ((MODLTYPE_AIH == ModuleType) || (MODLTYPE_AOH == ModuleType) || (MODLTYPE_UIO == ModuleType)) {
    
        // Instantiate HART modem objects.
        for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) {
#if defined(IOMTYPE_UIO)
            // Create a queue for the modem
            pHartQueue[ucModem] = new(ucModem) clsHartQueue();
#endif
            pHartModem[ucModem] = new(ucModem) clsHartModem(ucModem);
        }

#if defined(IOMTYPE_UIO)
        // Create and initialize HART passthrough response buffer objects.
        for (int modem = 0; modem < HARTMODEM_COUNT; modem++)
        {
            for (UINT8 ucCount = 0; ucCount < HPST_OBJECTCOUNT; ucCount++) {
                pUioHartPst[modem][ucCount] = new(modem*HPST_OBJECTCOUNT + ucCount) clsHartPst();
                pUioHartPst[modem][ucCount]->m_PstRcvBuffer.Flush();
            }
        }
#endif

        // UIO FW is not responsible for setting up the baud rate
#if !defined(IOMTYPE_UIO)         
        // Configure the common buad rate register for HART baud rate (1200 bps). 
        // Baudrate register value = UART clock frequency / (required baud rate * 16)
        // Baudrate register value = 24000000 / (1200 * 16) = 1250 = 0x04E2
        HART_BAUDRATE_REGISTER.LOBYTE = 0xE2;
        HART_BAUDRATE_REGISTER.HIBYTE = 0x04;
        if ((HART_BAUDRATE_REGISTER.LOBYTE != 0xE2) ||
            (HART_BAUDRATE_REGISTER.HIBYTE != 0x04)) {
            HardFail(HF_INVPROGRAMEXEC,HART_CPP,__LINE__);
        }
#endif
        // Setup TPU2 as HART heartbeat timer interrupt for 
        // HART character time (9.167 msec) interval.
        TPU2_TCR  = 0x21;      // Divide/4 clock, rising edge, clear TCNT on TGRA match.
        TPU2_TMDR = 0xC0;      // TP2 normal operation
        TPU2_TIER = 0x01;      // TGIEA interrupt enabled with TGRA match
        TPU2_TGRA = 55000;     // 9166.66667 * 6 counts/micro second
        IPRG_HART = LVLPRI_HART; // Same level as HART modem interrupts.
        TPU2_CST  = 1;         // Start the HART hearbeat timer
    }
}
/*******************************************************************************
*                               ResetHart                                      *
*                               =========                                      *
* PURPOSE:      Reset Hart UARTS                                               *
* ARGUMENTS:    None                                                           *
* RETURN:       None                                                           *
* NOTES:        Called by aihmain and aohmain if the module is Hartless        *
*******************************************************************************/
VOID ResetHart(VOID) 
{
#if defined(IOMTYPE_UIO)
    // HART modems are reset automatically at power-up.
    ;
#else
    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) // 4 modems
    {   
        HART_UART(ucModem).RESET = 1;
    }
#endif
}

#if defined (IOMTYPE_UIO)
/******************************************************************************
*                               TestHartAddressMux                            *
*                               ==================                            *
* PURPOSE:                                                                    *
*   Write to the H_MA register and readback what was written to verify that   *
*   the HART address multiplexer is working.                                  *
* ARGUMENTS:                                                                  *
*   NONE                                                                      *
* RETURN:                                                                     *
*   NONE                                                                      *
* NOTES:                                                                      *
*   This diagnostic should only be run on the secondary.  The primary         *
*   performs a similar diagnostic when HART communication is initiated for    *
*   a channel.                                                                *
******************************************************************************/
VOID TestHartAddressMux(VOID)
{
    static UINT8 sucHartAddressMuxCurrentSlot = 1;
    
    if (!HartLoopBkTestInProgress)
    {
        // HART modem associated with the channel slot
        UINT8 modem = FPGA.GetChannelModem(sucHartAddressMuxCurrentSlot);
        
        // Set the address
        FPGA.SetHartAddress(sucHartAddressMuxCurrentSlot);
                
        // Read back the address to see if it's valid
        if (!FPGA.IsHartAddressRegisterValid(modem))
        {
            // Read back failed...
            pHartModem[modem]->SetModemBad();
        }
        
        sucHartAddressMuxCurrentSlot++;
        
        if (sucHartAddressMuxCurrentSlot > MAXSLOTS)
        {
            sucHartAddressMuxCurrentSlot = 1;
        }               
    }
}
#endif

/*******************************************************************************
*                                    HartTask                                  *
*                                    ========                                  *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN HartTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_HARTTASK);

    if ((BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA)) {
        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {
#if defined(IOMTYPE_UIO)
            if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT){
               AIH_SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
               AIH_SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
               AIH_SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
            }
            else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT){
               AOH_SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
               AOH_SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
               AOH_SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
            }
#else
            SLOT(ucChan)->GetHartDevDb().m_HDataInit = HDATAINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().m_HEventInit = HEVENTINIT_PENDING;
            SLOT(ucChan)->GetHartDevDb().HComSts = HCOMSTS_NORESPONSE;
#endif
        }
        
#if defined (IOMTYPE_UIO)
        // Test the HART address multiplexer for one channel everytime the
        // HART task runs (250ms) on the secondary.
        TestHartAddressMux();
#endif
    }

    static UINT8 sucHChanToProcess = 1;
    const  UINT8 CHANNELS_PER_CYCLE = 4;

#if defined(IOMTYPE_UIO)
    // Regular HART processing is halted during factory HART testing
    if(FALSE == HartLoopBkTestInProgress)
    {
#endif
        for (UINT8 ucChan = 0; ucChan < CHANNELS_PER_CYCLE; ucChan++) 
        {
#if defined(IOMTYPE_UIO)
           UINT16 ChanToProcessOnBoard1 = sucHChanToProcess;
           UINT16 ChanToProcessOnBoard2 = sucHChanToProcess + SLOTSPERMODEM;
    
           // Process a channel on IoBoard1
           if(BOX->GetInitPntType(ChanToProcessOnBoard1) == PNTTYPE_ANALOGINPUT){
              AIH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ChannelHeartbeat();
              AIH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
           else if(BOX->GetInitPntType(ChanToProcessOnBoard1) == PNTTYPE_ANALOGOUTPUT){
              AOH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ChannelHeartbeat();
              AOH_SLOT(ChanToProcessOnBoard1)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
    
           // Process a channel on IoBoard2
           if(BOX->GetInitPntType(ChanToProcessOnBoard2) == PNTTYPE_ANALOGINPUT){
              AIH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ChannelHeartbeat();
              AIH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
           else if(BOX->GetInitPntType(ChanToProcessOnBoard2) == PNTTYPE_ANALOGOUTPUT){
              AOH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ChannelHeartbeat();
              AOH_SLOT(ChanToProcessOnBoard2)->GetHartDevDb().ProcessHartEvents(FALSE);
           }
    
           sucHChanToProcess++;
    
#else
            SLOT(sucHChanToProcess)->GetHartDevDb().ChannelHeartbeat();
            SLOT(sucHChanToProcess++)->GetHartDevDb().ProcessHartEvents(FALSE);
#endif
        }
    
#if defined(IOMTYPE_UIO)
        // One channel on each board is processed every pass through HartTask().
        // After all the slots per modem are processed:
        //   1) Reset channel to process counter
        //   2) Compute Hart load HCUAVAIL at this time for each modem.
        //   3) For both modems, check if modem is idle, there are no requests from any channels, 
        //      module is primary and HartStack is currently is not processing FDM queue.  If all
        //      cases are true, set up pass through requests.
        if (sucHChanToProcess > SLOTSPERMODEM) {
            sucHChanToProcess = 1;
    
            for (int modem = 0; modem < HARTMODEM_COUNT; modem++) {
                // Update HCuAvail
                FLOAT32 fTotalHartLoad = 100.0;
    
                for (UINT8 ucChan = ((modem*SLOTSPERMODEM)+1); ucChan <= ((modem+1)*SLOTSPERMODEM); ucChan++) {
                    if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT) {
                        fTotalHartLoad -= AIH_SLOT(ucChan)->GetHartDevDb().GetHartLoading();
                    }
                    else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT) {
                        fTotalHartLoad -= AOH_SLOT(ucChan)->GetHartDevDb().GetHartLoading();
                    }
                }
                BOX->SetHCuAvail(fTotalHartLoad, modem);
            
                if ((TRUE == pHartQueue[modem]->IsModemQueueEmpty()) && 
                    (HMODEMSTATE_IDLE == pHartModem[modem]->GetModemState()) && 
                    (FALSE == pHartModem[modem]->IsHartStackProc()) &&
                    (!(BOX->GetDSA() < 1) || (BOX->GetDSA() > MAXDSA))) {
                    // Check for number of PST's available in PST queue
                    // If FDM sessions are present
                    if(BOX->PassthroughInQueue(modem) != FALSE) {
                        // Set up passthrough
                        BOX->SearchForPassthrough(modem);
                    }
                }
            }
        }
#else
        if (sucHChanToProcess > MAXSLOTS) {
            sucHChanToProcess = 1;
            
            // Update HCuAvail
            FLOAT32 fTotalHartLoad = 100.0;
            for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) { 
                fTotalHartLoad -= SLOT(ucChan)->GetHartDevDb().GetHartLoading();
            }
            BOX->SetHCuAvail(fTotalHartLoad);
        }
#endif

#if defined(IOMTYPE_UIO)
    }
    else
    {
       sucHChanToProcess = 1;
    }
#endif

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}
/*******************************************************************************
*                              InitHartConnection                              *
*                              ==================                              *
* PURPOSE:                                                                     *
*    Initiate a HART transaction.                                              *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel object number which requests connection.            *
* RETURN:                                                                      *
*    Boolean. TRUE if request is accepted; FALSE if rejected.                  *
* PROCESS:                                                                     *
*    1. Add a_pClient to the stack queue.                                      *
* NOTES:                                                                       *
*    1. This function is used by channel object to initiate HART transaction.  *
*    2. Modem objects periodically checks the stack queue and uses the client  *
*       reference and callback interface to carry out the HART transaction.    *
*******************************************************************************/
BOOL InitHartConnection(UINT8 a_ucChan) {
#if defined(IOMTYPE_UIO)   
    return pHartQueue[FPGA.GetChannelModem(a_ucChan)]->AddToQueue(a_ucChan);
#else
    return HartQueue.AddToQueue(a_ucChan);
#endif
}
/*******************************************************************************
*                             AbortHartConnection                              *
*                             ===================                              *
* PURPOSE:                                                                     *
*    Abort a previously initiated HART transaction.                            *
* ARGUMENTS:                                                                   *
*    1. a_ucChan - channel number.                                             *
* RETURN:                                                                      *
*    Boolean. TRUE if transaction is aborted; FALSE if any transaction with    *
*    the specified client is not found.                                        *
* PROCESS:                                                                     *
*    1. Check the stack queue for the passed reference and remove from queue   *
*       if it is found.                                                        *
*    2. Otherwise check each modem object for their client references and      *
*       disconnect the modem if a match with the passed reference is found.    *
* NOTES:                                                                       *
*    1. Note that Disconnect method a private method in clsModem and cannot be *
*       called from here. Instead a request is made is to the modem object     *
*       which will be processed subsequently by the modem interrupt routines.  *
*       Disconnect need to be protected as private method to streamline the    *
*       modem state change.                                                    *
*******************************************************************************/
BOOL AbortHartConnection(UINT8 a_ucChan) {

#if defined(IOMTYPE_UIO)  
    // If the request is in the queue, remove it
    if (pHartQueue[FPGA.GetChannelModem(a_ucChan)]->RemoveFromQueue(a_ucChan) == TRUE) 
    {
        return TRUE;
    }
#else
    // If the request is in the queue, remove it
    if (HartQueue.RemoveFromQueue(a_ucChan) == TRUE) {
        return TRUE;
    }
#endif
    
    // If not in the queue, check whether any modem is 
    // processing it. If yes, disconnect and free the modem.
    for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++) {
        if (pHartModem[ucModem]->GetConnectedChannel() == a_ucChan) { 
            pHartModem[ucModem]->RequestDisconnect();
            return TRUE;
        }
    }

    // No match for the passed refence is found. Nothing to abort.
    return FALSE;
}
/*******************************************************************************
*                             ProcessHartInterrupt                             *
*                             ====================                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID ProcessHartInterrupt(VOID) {
    // This static variable ensures equal priority for processing all modems.
    static UINT8 stucModemToProcess = 0;

    while (UINT8 ucIntrFlag = FPGA_ISR.INTFL_HART) { 
        // while any modem interrupt is pending
        UINT8 ucIntrMask = 0x01 << stucModemToProcess;
        
        if (ucIntrFlag & ucIntrMask) {
            switch (HART_UART(stucModemToProcess).HART_INTR_ID) {
            case INTR_ID_RXLINESTATUS:
                // Receiver line status interrupt should not be triggered
                // since the line status interrupt is disabled. HART stack
                // code checks line status register for any errors before 
                // copying each received byte from the UART FIFO. 
                TraceLog.AddToTrace(TRACEID_GENERIC,bcInvHartIntr,1);
                break;
            case INTR_ID_RXDATAAVLBLE: // Receive FIFO full
                pHartModem[stucModemToProcess]->HartModemInterrupt(HINTRTYPE_RCVFIFOFULL);
                break;
            case INTR_ID_CHARTIMEOUT:
                // Reciver FIFO has unread characters, but not full and
                // there are no activity in FIFO for last 4 char time.
                pHartModem[stucModemToProcess]->HartModemInterrupt(HINTRTYPE_RCVFIFOTOUT);
                break;
            case INTR_ID_TXHLDRGEMPTY: // Transmit holding register empty.
                pHartModem[stucModemToProcess]->HartModemInterrupt(HINTRTYPE_XMTFIFOEMPTY);
                break;
            case INTR_ID_MODEMSTATUS: // Modem status interrupt
                if (HART_UART(stucModemToProcess).DELTA_CARRIER_DETECT) { // Carrier detect changed
                    if (HART_UART(stucModemToProcess).CARRIER_DETECT) {
                        // Carrier just appeared at the line.
                        pHartModem[stucModemToProcess]->HartModemInterrupt(HINTRTYPE_CARRIERDETECT);
                    }
                    else { // Carrier just disappeared from the line.
                        pHartModem[stucModemToProcess]->HartModemInterrupt(HINTRTYPE_CARRIERDROP);
                    }
                }
                else {
                    // Execution never reaches here as all other interrupt
                    // sources for modem status interrupt are grounded. 
                    TraceLog.AddToTrace(TRACEID_GENERIC,bcInvHartIntr,2);
                }
                break;
            default:
                break;
            }
        }
    
        // Update modem to be processed next.
        if (HARTMODEM_COUNT == ++stucModemToProcess) {
            stucModemToProcess = 0;
        }
    }
}

// ----------------------------------
// End Global Variables and Functions
// ----------------------------------
#endif // not UIO_HART_SLOTS

#ifndef UIO_HART_GLOBAL
// ----------------------------------
// Start Slot Variables and Functions
// ----------------------------------

/*******************************************************************************
*                         clsAihSlot::GetRcvBufObject                          *
*                         clsAohSlot::GetRcvBufObject                          *
*                         ===========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
clsClientBuffer& clsAihSlot::GetRcvBufObject(VOID) {
#endif
#ifdef IOMTYPE_AOH
clsClientBuffer& clsAohSlot::GetRcvBufObject(VOID) {
#endif
    if (HCHANTYPE_CHANNEL == HartDevDb.m_HChanType) {
        return HartDevDb.m_ChanRcvBuffer; 
    }
    else if (HCHANTYPE_PASSTHROUGH == HartDevDb.m_HChanType) {
#if defined(IOMTYPE_UIO)
        clsHartPst **pHartPst = clsHartPst::PassThroughTable(FPGA.GetChannelModem(ChanNum));
#endif
        return pHartPst[HartDevDb.m_ucPstRemIndex]->m_PstRcvBuffer;
    }
    else {
        HardFail(HF_INVPROGRAMEXEC,HART_CPP,__LINE__);
        // Return value is just to silence compiler.
        return HartDevDb.m_ChanRcvBuffer; 
    }
}
/*******************************************************************************
*                           clsAihSlot::PreCommand                             *
*                           clsAohSlot::PreCommand                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreCommand(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreCommand(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if ((*(COMMAND *)a_WriteBuffer < COMMAND_ACCEPTCFG) ||
        (*(COMMAND *)a_WriteBuffer > COMMAND_RESETHCOMERR)) {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostCommand                            *
*                           clsAohSlot::PostCommand                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostCommand(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostCommand(UINT8) {
#endif
    if (COMMAND_RESETHCOMERR == HartDevDb.Command) {
        HartDevDb.HComSts     = HCOMSTS_GOOD;
        HartDevDb.HLComFail   = HCOMSTS_GOOD;
        HartDevDb.HNComErr    = 0;
        HartDevDb.HCmdFail    = HARTCOMMAND_INVALID;
        HartDevDb.HCmdResp    = 0;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_EXCOMMERR_MASK;
        HartDevDb.HDevSt[1] &= ~HART_DEVST1_CMDFAIL_MASK;
#if defined (IOMTYPE_UIO)

        UINT8 modem = FPGA.GetChannelModem(ChanNum);

        // Only clear the modem status for the modem associated with this channel
        pHartModem[modem]->ClearModemBad();

        // Clear HART Chan Fail for all AI/AO channels associated with this modem
        for (UINT8 ucChan = ((modem*SLOTSPERMODEM)+1); ucChan <= ((modem+1)*SLOTSPERMODEM); ucChan++)
        {
            if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGINPUT)
            {
                AIH_SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
            }
            else if(BOX->GetInitPntType(ucChan) == PNTTYPE_ANALOGOUTPUT)
            {
                AOH_SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
            }
        }
#else
        for (UINT8 ucModem = 0; ucModem < HARTMODEM_COUNT; ucModem++)
        {
            pHartModem[ucModem]->ClearModemBad();
        }

        for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++)
        {
            SLOT(ucChan)->GetHartDevDb().ClearHartChanFail();
        }
#endif
    }
    
    // No need to do anything for accept configuratoin as the controller 
    // is going to write HDVxxCD parameters to the IOM. PostHDevIdCd will 
    // take care resetting any mismatch alarms present.

    HartDevDb.Command = COMMAND_UNDEFINED;
}
/*******************************************************************************
*                           clsAihSlot::PreHEnable                             *
*                           clsAohSlot::PreHEnable                             *
*                           ======================                             *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHEnable(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHEnable(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (*(UINT8 *)a_WriteBuffer > TRUE) {
        return DO_ILLEGAL_VALUE;
    }
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHEnable                            *
*                           clsAohSlot::PostHEnable                            *
*                           =======================                            *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHEnable(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHEnable(UINT8) {
#endif
    if ((PNTTYPE_NOTCONFIGURED != PntType) || BOX->GetHADCEnable(ChanNum)) { // if channel is configured or STAC ops
        if (TRUE == HartCfgDb.HEnable) {
#ifdef IOMTYPE_AIH
            // Sensor type is not loaded for HART enabled channels as it is
            // greyed out on the forms. Default it to 1 to 5V and execute
            // PostSensorTyp for initializing ADRaw and RawSpan correctly.
            SensrTyp = SENSRTYP_1to5_V;
            PostSensrTyp(ALVL_PBD);
            BOX->SetHADCStatus(ChanNum, HART_DATA_PENDING);
#endif
            if (HCHANMODE_INIT == HartDevDb.m_HChanMode) {
#ifdef IOMTYPE_AOH
                if (!isnan(OpFinal) && (OpFinal > OP_LOLIMIT))
#endif
                {
                    // Initialization commands not completed yet
                    HartDevDb.m_HDataInit = HDATAINIT_PENDING;
                    if (HartDevDb.m_ucInitCmdIndex < 1) {
                        // if first C48 is not complete yet
                        HartDevDb.m_HEventInit = HEVENTINIT_PENDING;
                    }
                }
            }

            UINT8 ucDsa = BOX->GetDSA();
            if ((ucDsa > 0) && (ucDsa <= MAXDSA)) {
                // IOM is primary is channel configued with HART enabled.
                // Start HART scanning in this cycle.
                HartDevDb.m_sScanCounter = TICKS_IN_1_SEC;
            }
        }
        else { // Channel configured with HART disabled.
            HartDevDb.InitDevDb(TRUE);
            BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
        }
    }
#ifdef IOMTYPE_AOH
    else // Channel deleted
        BOX->SetHADCStatus(ChanNum, HART_DATA_UNKNOWN);
#endif
}
/*******************************************************************************
*                           clsAihSlot::PreHAlarmEnable                        *
*                           clsAohSlot::PreHAlarmEnable                        *
*                           ===========================                        *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHAlarmEnable(UINT8 *a_WriteBuffer,UINT8 a_ucAccLvl) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHAlarmEnable(UINT8 *a_WriteBuffer,UINT8 a_ucAccLvl) {
#endif
    // Save current configuration
    ScratchPad = HartCfgDb.HAlarmEnable;

    if (ALVL_IUSER == a_ucAccLvl) {
        // If warm restore and checkpoint restore is 
        // going on accept the write value as it is.
        return PA_OK;
    }

    // Update the writebuffer according to write value coming down.
    switch (*a_WriteBuffer) {
    case HALARMENABLE_ALMENBSTATE_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_ALMENBSTATE_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_ALMENBSTATE_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_RSTVAL:
        *a_WriteBuffer = ScratchPad & ~HALARMENABLE_JOURNALONLY_MASK;
        break;
    case HALARMENABLE_JOURNALONLY_SETVAL:
        *a_WriteBuffer = ScratchPad | HALARMENABLE_JOURNALONLY_MASK;
        break;
    default:
        return DO_ILLEGAL_VALUE;
    }

    return PA_OK;
}
/*******************************************************************************
*                          clsAihSlot::PostHAlarmEnable                        *
*                          clsAohSlot::PostHAlarmEnable                        *
*                          ============================                        *
* PURPOSE   : Initialize HART database.                                        *
* ARGUMENTS : Access level                                                     *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHAlarmEnable(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHAlarmEnable(UINT8) {
#endif
    // Check for bits changed in HAlarmEnable
    ScratchPad ^= HartCfgDb.HAlarmEnable;

    if (ScratchPad > 0) { // either or both bits got changed
        if (ScratchPad & HALARMENABLE_ALMENBSTATE_MASK) {
            // ALMENBSTATE bit changed
            if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) {
                // Alarms got enabled - regen current HART event state
                HartDevDb.m_bReReportEvents = TRUE;
            }
        }
        
        if (ScratchPad & HALARMENABLE_JOURNALONLY_MASK) {
            // JOURNALONLY bit changed
            if (0 == (HartCfgDb.HAlarmEnable & HALARMENABLE_JOURNALONLY_MASK)) {
                // Alarms got unsuppressed - if ALENBSTATE is enabled 
                // then regen current HART event state.
                if (HartCfgDb.HAlarmEnable & HALARMENABLE_ALMENBSTATE_MASK) {
                    HartDevDb.m_bReReportEvents = TRUE;
                }
            }
        }

        // Post appropriate alarm option change event.
        // Pass FALSE as argument for normal event reporting.
        HartDevDb.PostHAlmOptChgEvent(FALSE);
    }
}
/*******************************************************************************
*                           clsAihSlot::PreHScanCfg                            *
*                           clsAohSlot::PreHScanCfg                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHScanCfg(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHScanCfg(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (TRUE == HartCfgDb.HEnable) { 
        if ((*a_WriteBuffer > HSCANCFG_UNDEFINED) && 
            (*a_WriteBuffer <= HSCANCFG_STATUSONLY)) {
            return PA_OK;
        }
    }
    else if (HSCANCFG_UNDEFINED == *a_WriteBuffer) {
        return PA_OK;
    }

    return DO_ILLEGAL_VALUE;
}
/*******************************************************************************
*                           clsAihSlot::PostHScanCfg                           *
*                           clsAohSlot::PostHScanCfg                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHScanCfg(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHScanCfg(UINT8) {
#endif
    HartDevDb.BuildScanTable();
}
/*******************************************************************************
*                           clsAihSlot::PreHComThrs                            *
*                           clsAohSlot::PreHComThrs                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHComThrs(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHComThrs(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (0 == *(UINT16 *)a_WriteBuffer) {
        *(UINT16 *)a_WriteBuffer = 1;
        return DO_VALUE_CLAMPED_ERROR;
    }

    return PA_OK;
}
/*******************************************************************************
*                            clsAihSlot::PreHComHys                            *
*                            clsAohSlot::PreHComHys                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHComHys(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHComHys(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (*(UINT16 *)a_WriteBuffer > HartCfgDb.HComThrs) {
        *(UINT16 *)a_WriteBuffer = HartCfgDb.HComThrs;
    }
    
    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PostHDevIdCd                           *
*                           clsAohSlot::PostHDevIdCd                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
VOID clsAihSlot::PostHDevIdCd(UINT8) {
#endif
#ifdef IOMTYPE_AOH
VOID clsAohSlot::PostHDevIdCd(UINT8) {
#endif
    HartDevDb.CheckDevMismatch();
#ifdef IOMTYPE_AIH
    HartDevDb.CheckRangeMismatch();
#endif
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd                            *
*                           clsAohSlot::PreHDvMfgCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvMfgCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvMfgCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvMfgCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvMfgCd7                            *
*                           clsAohSlot::PreHDvMfgCd7                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvMfgCd7(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvMfgCd7(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if ((*(UINT16 *)HartCfgDb7.HDvMfgCd7) != *(UINT16 *)a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd                            *
*                           clsAohSlot::PreHDvTypCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvTypCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvTypCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvTypCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvTypCd7                           *
*                           clsAohSlot::PreHDvTypCd7                           *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvTypCd7(UINT8 *a_WriteBuffer,UINT8){
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvTypCd7(UINT8 *a_WriteBuffer,UINT8){
#endif
    if ((*(UINT16 *)HartCfgDb7.HDvTypCd7) != *(UINT16 *)a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDvRevCd                            *
*                           clsAohSlot::PreHDvRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDvRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDvRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDvRevCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHDdRevCd                            *
*                           clsAohSlot::PreHDdRevCd                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHDdRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
#ifdef IOMTYPE_AOH
PASTATUS clsAohSlot::PreHDdRevCd(UINT8 *a_WriteBuffer,UINT8) {
#endif
    if (HartCfgDb.HDdRevCd != *a_WriteBuffer) {
        // If HART template configuration changes, set the wait counter so that
        // HART event processing for this channel will be suspended for 16 secs
        // for allowing the template to get loaded to SR.
        if (HartCfgDb.HScanCfg != HSCANCFG_UNDEFINED) {
            // HScanCfg check ensures that this is not a first-time load of the
            // channel configuration. First time loads do not need to suspend 
            // and regen the HART alarms and events.
            HartDevDb.m_ucTemplateChangeWaitCount = MAX_TEMPLATECHANGE_WAITCOUNT;
        }
    }

    return PA_OK;
}
/*******************************************************************************
*                           clsAihSlot::PreHEuRngExt                           *
*                           ========================                           *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
#ifdef IOMTYPE_AIH
PASTATUS clsAihSlot::PreHEuRngExt(UINT8 *a_WriteBuffer,UINT8) {
    if (PTEXECST_INACTIVE != PtExecSt) {
        return DO_POINT_MUST_BE_INACTIVE;
    }

    for (UINT8 ucCount = 0; HEuRngExt[ucCount] > 0; ucCount++) {
        DATABYTES RangeData;
        for (UINT8 ucByte = 0; ucByte < sizeof(FLOAT32); ucByte++) {
            RangeData.ucBytes[ucByte] = *a_WriteBuffer++;
        }
        if (isnan(RangeData.f32Val)) return DO_SOURCE_OF_REQUEST_INVALID;
    }

    // If the above cheks passes, default the current value of ranges so that  
    // the individual pre functions will not fail with range cross-over error.
    PvEUHi = NaN;
    PvEULo = NaN;
    PvExEUHi = NaN;
    PvExEULo = NaN;
    
    return PA_OK;
}
#endif
#ifndef IOMTYPE_UIO
#ifdef IOMTYPE_AIH
/*******************************************************************************
*                          clsAihBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAihBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAihBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAihBoxSlot::PostHADCEnable(UINT8) {
    PNTTYPE PointType = SLOT(WriteIndex)->GetPntType();
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    SetAdcCycleCount(WriteIndex,0);
    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        // Save present value of HEnable
        HEnableSaved[WriteIndex - 1] = SLOT(WriteIndex)->GetHEnable();
        // If channel is loaded and HEnable is FALSE set it to TRUE
        if ((PNTTYPE_ANALOGINPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(TRUE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        // If channel is loaded restore old value of HEnable if it was FALSE
        if ((PNTTYPE_ANALOGINPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(FALSE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
    }
}
#endif // ifdef IOMTYPE_AIH
#ifdef IOMTYPE_AOH
/*******************************************************************************
*                          clsAohBoxSlot::PreHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHADCEnable(UINT8 *a_WriteBuffer,UINT8) {
    BOOL bPresentState = HADCEnable[WriteIndex - 1];
    BOOL bNewState =  *(BOOL *)a_WriteBuffer;

    if (PTEXECST_ACTIVE == SLOT(WriteIndex)->GetPtExecSt())
        return DO_CONFIGURATION_MISMATCH_ERROR;
    if (TRUE == SLOT(WriteIndex)->IsRedTagged())
        return DO_POINT_IS_RED_TAGGED;
    if (TRUE == HAutoDet[WriteIndex - 1])
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    if ((TRUE == bNewState) && (FALSE == bPresentState)) Data.ucBytes[1] = ADCEN_OFF_ON;
    else if ((FALSE == bNewState) && (TRUE == bPresentState)) Data.ucBytes[1] = ADCEN_ON_OFF;
    else Data.ucBytes[1] = ADCEN_NOCHANGE;
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHADCEnable                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAohBoxSlot::PostHADCEnable(UINT8) {
    PNTTYPE PointType = SLOT(WriteIndex)->GetPntType();
    FLOAT32 fOp;
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);

    // HADCEnable is coming ON
    if (ADCEN_OFF_ON == Data.ucBytes[1]) {
        // Save present OP value
        Op_Saved[WriteIndex - 1] = GetOp(WriteIndex);
        // If there is not presently enough current
        // Drive output current to the minimum necessary for device discovery
        if (HART_AUTODETECT_OP > SLOT(WriteIndex)->GetOpFinal()) {
            fOp = HART_AUTODETECT_OP;
            if (TRUE == SLOT(WriteIndex)->GetOpChar()) fOp = SLOT(WriteIndex)->ChrcBkwrd(HART_AUTODETECT_OP);
            if (OPTDIR_REVERSE == SLOT(WriteIndex)->GetOptDir()) fOp = ((FLOAT32) 100.0) - fOp;
            SetOp(WriteIndex,fOp);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SetAdcCycleCount(WriteIndex,1);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
        HEnableSaved[WriteIndex - 1] = SLOT(WriteIndex)->GetHEnable();
        // If channel is loaded and HEnable is FALSE set it to TRUE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(TRUE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_PENDING);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
        }
    }
    // HADCEnable is going OFF
    else if (ADCEN_ON_OFF == Data.ucBytes[1]) {
        // If channel is loaded restore old value of HEnable if it was FALSE
        if ((PNTTYPE_ANALOGOUTPUT == PointType) &&
            (FALSE==HEnableSaved[WriteIndex - 1])) {
            SLOT(WriteIndex)->SetHEnable(FALSE);
            SLOT(WriteIndex)->PostHEnable(ALVL_PBD);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
        // If channel current was forced to the min value restore it to old value
        if (HART_AUTODETECT_OP > Op_Saved[WriteIndex - 1]) {
            SetOp(WriteIndex,Op_Saved[WriteIndex - 1]);
            SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
            SLOT(WriteIndex)->GetHartDevDb().InitDevDb(TRUE);
            SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
            SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
        }
    }
}
/*******************************************************************************
*                          clsAohBoxSlot::PreHAutoDet                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAohBoxSlot::PreHAutoDet(UINT8 *a_WriteBuffer,UINT8) {
#if defined(IOPTYPE_AO16)
	if (TRUE == *(BOOL *)a_WriteBuffer) {
		if (BOX->GetFtaPres() == FTA_MISSING) {
			return DO_INITIALIZATION_ERROR;
		}
	}
#else
	if ((TRUE == *(BOOL *)a_WriteBuffer) && 
        (PNTTYPE_NOTCONFIGURED != SLOT(WriteIndex)->GetPntType())) {
        return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    if (TRUE == HADCEnable[WriteIndex - 1]) {
        return DO_PRIOR_FUNCTION_NOT_COMPLETE;
    }
#endif
    return PA_OK;
}
/*******************************************************************************
*                          clsAohBoxSlot::PostHAutoDet                         *
*                          ===========================                         *
* PURPOSE   :                                                                  *
* ARGUMENTS :                                                                  *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsAohBoxSlot::PostHAutoDet(UINT8) {
    /* Removed the check of Primary Module to Fix
       PAR 1-2KSQYU: AO-HART secondary IOM momentarily goes to IDLE 
                     while loading a channel with HAUTODET
    */  
    SLOT(WriteIndex)->GetHartDevDb().InitDevDb(FALSE);
    
    if (TRUE == HAutoDet[WriteIndex - 1]) {
        // Drive output current for auto detection.
        SetOp(WriteIndex,HART_AUTODETECT_OP); // Drive 3.2 mA for auto detection
        SetHADCStatus(WriteIndex,HART_DATA_PENDING);
        SLOT(WriteIndex)->GetHartDevDb().BuildScanTable();
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_1_SEC;
    }
    else {
        SetOp(WriteIndex,OP_LOLIMIT); // Drive 0 mA at output
        // If auto detection is disabled, schedule scan counter for
        // four seconds. This helps in keeping the HART discovery 
        // information, if auto detection was disabled by a channel 
        // load operation and there is enough current for HART. If 
        // there is not enough current, HART database will be fully
        // initialized later.
        SetHADCStatus(WriteIndex,HART_DATA_UNKNOWN);
        SLOT(WriteIndex)->GetHartDevDb().m_sScanCounter = TICKS_IN_4_SEC;
    }
}
#endif // ifdef IOMTYPE_AOH
#endif // end ifndef IOMTYPE_UIO

// --------------------------------
// End Slot Variables and Functions
// --------------------------------
#endif // not UIO_HART_GLOBAL


// Processing definitions for UIO
#ifdef IOMTYPE_UIO
    #ifdef IOMTYPE_AIH
        #undef IOMTYPE_AIH
        #define IOMTYPE_AOH
        #undef SLOT
        #define SLOT(N)  AOH_SLOT(N)
        #include "hart.cpp"
    #endif

    #ifdef UIO_HART_GLOBAL
        #undef UIO_HART_GLOBAL

        #define UIO_HART_SLOTS
        #define IOMTYPE_AIH
        #undef SLOT
        #define SLOT(N)  AIH_SLOT(N)
        #include "hart.cpp"
    #endif
#endif

