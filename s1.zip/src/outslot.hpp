/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : outslot.hpp                                                 *
*    Description : Class clsOutSlot declaration.                               *
*******************************************************************************/
#ifndef __OUTSLOT_HPP__
#define __OUTSLOT_HPP__
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "ioslot.hpp"
#include "scheduler.hpp"
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagOutputDir {
    OPTDIR_DIRECT  = 0,
    OPTDIR_REVERSE = 1
} OPTDIR;

typedef enum tagFaultOption {
    FAULTOPT_HOLD         = 0,
    FAULTOPT_UNPOWERED    = 1,
    FAULTOPT_POWERED      = 2,
    FAULTOPT_FAULTVALUE   = 3
}FAULTOPT;

typedef enum tagFaultState {
    FAULTSTATE_NORMAL   = 0,
    FAULTSTATE_FAULTED  = 1
}FAULTSTATE;

typedef enum tagMode {
    MODE_NONE    = 0,
    MODE_MANUAL  = 1,
    MODE_CASCADE = 2,
#if defined(IOPTYPE_AO16)
    // For redesign PMIO AO16
    MODE_AUTO    = 3,
    MODE_BCAS    = 4,
#endif
    MODE_NORMAL  = 5
}MODE;

typedef enum tagModeAttr {
    MODEATTR_NONE     = 0,
    MODEATTR_OPERATOR = 1,
    MODEATTR_PROGRAM  = 2,
    MODEATTR_NORMAL   = 3
}MODEATTR;

typedef enum tagModePermissive {
#if !defined(IOPTYPE_AO16)
    MODEPERM_NOPERMIT   = 0,
    MODEPERM_PERMIT     = 1
#else
    // for redesign PMIOP AO16
    MODEPERM_NOPERMIT   = 1,
    MODEPERM_PERMIT     = 0
#endif
} MODEPERM;

typedef enum tagRedTag {
    REDTAG_OFF  = 0,
    REDTAG_ON   = 1
} REDTAG;
/*******************************************************************************
*                                  clsOutSlot                                  *
*                                  ==========                                  *
*******************************************************************************/
class clsOutSlot : public clsIoSlot {
protected:
    // !!!*** OUT_SLOT_DUMP_RECORD ***!!!
    // This class is wholly contained within an output slot's redundant synch
    // data area. If any data members are added or deleted from this class,
    // size of the member OutSlotSpare[] need to adujsted so that the dump record
    // size remains the same. Otherwise, this would break the IOM FO upgrade 
    // procedure that OPM depends on. If any new data members are added at the 
    // end class, cls<iomtype>Slot::GetRedSlotSize() must be updated to reference
    // the new end member. This dump record ends in cls<iomtype>Slot.
    FAULTSTATE  FaultState;
    FAULTOPT    FaultOpt;
    FLOAT32     FaultValue;
    MODE        Mode;
    MODEATTR    ModeAttr;
    MODEPERM    ModePerm;
    MODE        NMode;
    MODEATTR    NModeAttr;
    REDTAG      RedTag;
    OPTDIR      OptDir;
    BOOL        LocalMan;
#ifndef DEBUG
    UINT8       OutSlotSpare[4];
#endif

    clsOutSlot(PNTTYPE a_PntType, UINT8 a_ucSltNm) : clsIoSlot(a_PntType,a_ucSltNm) {
        InitOutSlot(a_PntType,TRUE,TRUE);
#ifndef DEBUG
        OutSlotSpare[0] = 0;
        OutSlotSpare[1] = 0;
        OutSlotSpare[2] = 0;
        OutSlotSpare[3] = 0;
#endif
    }

    VOID InitOutSlot(PNTTYPE a_PntType, BOOL bFullInit, BOOL) {
        if (bFullInit) {
            FaultOpt    = FAULTOPT_UNPOWERED;
            FaultState  = FAULTSTATE_NORMAL;
#ifdef IOMTYPE_DO
            FaultValue  = 0.0;
#elif (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
            FaultValue  = -6.9;
#elif defined(IOMTYPE_UIO)
            if (PNTTYPE_DIGITALOUTPUT == a_PntType) {
                FaultValue = 0.0;
            }
            else if (PNTTYPE_ANALOGOUTPUT == a_PntType) {
                FaultValue = -6.9;
            }
#endif 
            Mode = MODE_CASCADE;
#if !defined(IOPTYPE_AO16)
            
            ModeAttr    = MODEATTR_OPERATOR;
#else            
            ModeAttr    = MODEATTR_NONE;
#endif
            ModePerm    = MODEPERM_PERMIT;
            NMode       = MODE_NONE;
            NModeAttr   = MODEATTR_NONE;
            RedTag      = REDTAG_OFF;
            OptDir      = OPTDIR_DIRECT;
            if((a_PntType == PNTTYPE_ANALOGOUTPUT)|| 
                (a_PntType == PNTTYPE_DIGITALOUTPUT)) {
                LocalMan  =   FALSE;
            }
        }
    }

    virtual ~clsOutSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,OUTSLOT_HPP,__LINE__); }
    
    inline VOID *GetLocalManPtr(VOID)       { return &LocalMan; }
    inline VOID *GetOptDirPtr(VOID)         { return &OptDir; }

    inline VOID *GetFaultStatePtr(VOID)     { return &FaultState; }
    inline VOID *GetFaultOptPtr(VOID)       { return &FaultOpt; }
    inline VOID *GetFaultValuePtr(VOID)     { return &FaultValue; }

    inline VOID *GetModePtr(VOID)           { return &Mode; }
    inline VOID *GetModeAttrPtr(VOID)       { return &ModeAttr; }
    inline VOID *GetModePermPtr(VOID)       { return &ModePerm; }
    inline VOID *GetNModePtr(VOID)          { return &NMode; }
    inline VOID *GetNModeAttrPtr(VOID)      { return &NModeAttr; }
    inline VOID *GetRedTagPtr(VOID)         { return &RedTag; }

    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,OUTSLOT_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,OUTSLOT_HPP,__LINE__); } 
    clsOutSlot(const clsOutSlot&); // Safeguard against default copy constructor
    clsOutSlot& operator=(const clsOutSlot&); // and defualt assignement.

    inline PASTATUS PreCheckPoint(UINT8 *, UINT8) {
        if (REDTAG_ON == RedTag) return DO_POINT_IS_RED_TAGGED;
        #ifdef IOMTYPE_UIO
            SlotChkpntVersion = GetLatestSlotChkPntVersion();
        #else
            SlotChkpntVersion = LATEST_SLTCHKPNT_VERSION;
        #endif
        return PA_OK;
    }

public:
    inline FAULTSTATE GetFaultState(VOID)    { return FaultState; }
#if defined(IOMTYPE_UIO)
    virtual void SlotFaultHandler(TOG_FAILED) = 0;
    virtual BOOL IsOutputNotViable(UINT8 ucParamId) = 0;
#endif
    inline VOID ResetFaultState(VOID)        { FaultState = FAULTSTATE_NORMAL; }
    inline VOID SetModeManual(VOID)          { Mode = MODE_MANUAL; }
    inline BOOL IsRedTagged(VOID)            { return (REDTAG_ON == RedTag) ? TRUE : FALSE; }
};
#endif
