/*******************************************************************************
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : svpmain.cpp                                                 *
*    Description : SVP module application specific startup code.               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "svpmain.h"

/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN TCDiagnosticTask(TASKCONTEXT);
#ifdef DEBUG
extern TASKRETURN DebugTask(TASKCONTEXT);
#endif

/*******************************************************************************
*                               EXTERNAL DATA                                  *
*******************************************************************************/
extern volatile BOOL ExitFromCalibTask;

/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
#ifdef DEBUG
clsDebugPort     DebugPort;
#endif

//To Retain the tracelogs at Reset
#pragma section REBOOT_SECTION
clsTraceLog      TraceLog;
#pragma section

#pragma section  INTERNALRAM_SECTION
clsWriteMsgQueue WriteMsgQueue;
clsIol           Iol;
clsShramWriteMsgQueue ShramMsgQueue;
#pragma section 

// Global objects
clsTaskScheduler TaskScheduler;
volatile BOOL ExitFromCalibTask =FALSE;
WRITEINPROGRESS  WriteInProgress;

//Instance for IOLINK and APPLICATION processor SCS Queues
clsIoLinkFifo IolinkScsFifo;
clsIoLinkFifo AppScsFifo;
extern SHRAMDATA ShramData;

//Flag utilized to prevent the stcappprocessing from checking the state 
//of the redundancy switches when switch diagnostcis will be running
BOOL bSwitchDiagRunning = FALSE;

// Pointers to database objects
clsIomSlot       *pDatabase[MAXSLOTS + 1];

// Database Memory
UINT16 ucIomDbMemory[SVPBOXSLOT_SIZE+(AI_MAXSLOTS * AILVDTSLOT_SIZE)+\
                    (AO_MAXSLOTS*AOSERVOSLOT_SIZE)+(DI_MAXSLOTS*DISLOT_SIZE)+
                    (SVPREGCTL_MAXSLOTS*SVPREGCTL_SLOTSIZE)];

/// Address after ucIomDbMemory.Used in testparam support.
UINT16* gIomDbMemoryEndPtr = ((UINT16*)ucIomDbMemory + word_sizeof(ucIomDbMemory));

/*******************************************************************************
*                               CONSTANTS                                      *
*******************************************************************************/
// Initialization of the Task Definition table (in the order of priority)
//If any update in made in the m_TaskDefinitionTable,ensure that the 
//constant TASKCOUNT defined in scheduler.hpp is also modified accordingly
const TASKDEFINITIONTABLE clsTaskScheduler::m_TaskDefinitionTable[] = {
                                            WriteDatabaseTask
                                           ,LowPriorityTask 
                                           ,CalibrationTask 
                                           ,EventRecoveryTask
                                           ,TCDiagnosticTask  
#ifdef DEBUG
                                           ,DebugTask
#endif
};

/*******************************************************************************
*                                     main                                     *
*                                     ====                                     *
* PURPOSE:                                                                     *
*    Application specific startup code.                                        *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*    This function is called by the PowerOn reset vector.                      *
*******************************************************************************/
VOID main(VOID) 
{
    // Link application trace log.
    TraceLog.StoreAppTraceLogPtr(&ShramData.AppTraceLog);

    InitTestParam();
           
    // Create box and slot database objects
    pDatabase[0] = new clsSvpBoxSlot(MODLTYPE_SVP);  // NOTE to be removed

    TraceLog.AddToTrace(TRACEID_GENERIC,bcAiIom,BOX->GetDPA());
  
    // Create object instances for AI LVDI
    for (UINT8  ucSltNm=AI_LVDT_CHANNEL_1_NUMBER;ucSltNm <= AI_LVDT_CHANNEL_2_NUMBER;ucSltNm++)
    {
        pDatabase[ucSltNm] = new(ucSltNm) clsAiLvdtSlot(ucSltNm);
    }

    // Create object instances for AO/SERVO 
    for (UINT8 ucSltNm = AO_SERVO_CHANNEL_1_NUMBER;ucSltNm <= AO_SERVO_CHANNEL_2_NUMBER;ucSltNm++)
    {
        pDatabase[ucSltNm] = new(ucSltNm) clsAoServoSlot(ucSltNm);
    }

    // Create object instnaces for DI channels
    for (UINT8 ucSltNm = DI_CHANNEL_1;ucSltNm <= DI_CHANNEL_2;ucSltNm++)
    {
        pDatabase[ucSltNm] = new(ucSltNm) clsDiSlot(ucSltNm);
    }

    // Create object instnaces for SvpRegctl channels
    for (UINT8 ucSltNm = SVPREGCTL_CHANNEL_1;ucSltNm <= SVPREGCTL_CHANNEL_2;ucSltNm++)
    {
        pDatabase[ucSltNm] = new(ucSltNm) clsSvpRegCtlSlot(ucSltNm);
    }

    TraceLog.AddToTrace(TRACEID_GENERIC,bcIomDbDone);

    // Initialize periodic tasks.
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK,TASKPERIOD_LPTASK,
                                        DMCPERIOD_LPTASK);
    TaskScheduler.InitPeriodicTask(TASKID_DIAGTASK,TASKPERIOD_DIAGTASK,
                                        DMCPERIOD_DIAGTASK);

    // Initialize IOLINK and Application Processor SCS Queues
    IolinkScsFifo.clsIoLinkFifoInit((UINT32)(ShramData.ScsMem),SCS_BUFFER_SIZE);
    AppScsFifo.clsIoLinkFifoInit((UINT32)(ShramData.ScsMemApp),SCS_BUFFER_SIZE);

    //ModStat1.Factory bit is set high if the IOM is configured
    //for factory test mode.
    BOX->SetFactoryTestMode();

#ifdef DEBUG
    // Set the Debug Task to RUN State
    //TaskScheduler.RunTask(TASKID_DEBUGTASK);
#endif

    // Return to AppResetIsr which will transfer execution to TaskScheduler.
}
/*******************************************************************************
*                          LowPriorityTask                                     *
*                          ================                                    *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
* Runs Task every 1 seconds,can view LowPriorityTask over Debug terminal       *
* to identify the task                                                         *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    const UINT8 SWTCH_DIAG_COUNT = 5;
    static UINT8 ucSwDiagCntr= 0;
    static BOOL IsSendNoTogFailCmd=FALSE;

    static TOG_FAILED LastTogFailed = NOTOG_FAILED;
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

    //check if the modules are settled 
    if(((OUTCTL_PARTNER == BOX->GetModStat3State())&&(!Iol.AmPrimary()))||
        ((OUTCTL_MINE == BOX->GetModStat3State())&&(Iol.AmPrimary()))){
        // Check for Communication failure and CEE Failure. If any one of these present, 
        // call FaultHandling function which sheds the output according to Mode and 
        // ModeAttr configuration.
        TOG_FAILED TogFailed = BOX->IsTogFailed();
        // Avoid the Tog Timeout if module is in Factory testmode
        if (BOX->CheckForFactoryTestMode())
            TogFailed = NOTOG_FAILED; //override the Togfailed status with NO TOG FAILED to avoid the mode shed due to TOG timeout

        if (NOTOG_FAILED != TogFailed)
        {   
            IsSendNoTogFailCmd = FALSE;
            if (COMTOG_FAILED == TogFailed)
            {
                if(LastTogFailed != TogFailed)
                {
                    //Handle Communication TOG Failure for SVP Channels
                    IolinkScsFifo.SendSCSCommand(SCS_COMTOG_FAILED);
                }
            }
            
            if (CTLTOG_FAILED == TogFailed)
            {
                if(LastTogFailed!=TogFailed)
                {
                    //Handle Control TOG Failure for SVP Channels
                    IolinkScsFifo.SendSCSCommand(SCS_CTLTOG_FAILED);
                }
            }
            
        }
        else if ((BOX->GetComTog() == TRUE) && (BOX->GetCtlTog() == TRUE)) 
        {
            if(!IsSendNoTogFailCmd)
            {   // send the command only once
                // If both CTL and COMM TOG are present
                if(IolinkScsFifo.SendSCSCommand(SCS_NOTOG_FAILED))
                {
                    IsSendNoTogFailCmd=TRUE;
                }
            }
        }
        LastTogFailed = TogFailed;
        
    }
    
    //Run the switch diagnostics every 500msec
    if(0 == ucSwDiagCntr)
    {
        //Set the Diag run flag so that switch status will not be checked 
        //in stcprocessing routine
        bSwitchDiagRunning = TRUE;

        //Since the hardfail is the outcome of failure of this diagnostics 
        //ignore the return value
        if (!(BOX->CheckForFactoryTestMode())){ //do not execute in Factory Mode
           SwitchDiagnostics();
        }
        ucSwDiagCntr = SWTCH_DIAG_COUNT;
        bSwitchDiagRunning = FALSE;
    }
    else {ucSwDiagCntr--;}

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;

    return TaskReturnValue;
}
/*******************************************************************************
*                                CalibrationTask                               *
*                                ===============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN CalibrationTask(TASKCONTEXT a_TaskContext)
{
    volatile BOOL bCalibrate;
    bCalibrate = CALIBRATE;
   
    //Assert Backup Request while doing Calibration
    BOX->AssertBackup();
 
    if(TRUE == FACTCAL)
    {
        //Send SCS to Application Processor to Set Factory Calibaration Mode
        IolinkScsFifo.SendSCSCommand(SCS_FACTCALIB_SET);
    }
    else
    {
        //Send SCS to Application Processor to Clear Factory Calibaration Mode
        IolinkScsFifo.SendSCSCommand(SCS_FACTCALIB_CLEAR);
    }

    while (1)
    {
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

        TaskScheduler.RefreshTaskDmc(TASKID_DIAGTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        if(bCalibrate != CALIBRATE)
        {
            bCalibrate=CALIBRATE;
            if(bCalibrate==TRUE)
            {
               //Send SCS to Application Processor to enable calibaration
               IolinkScsFifo.SendSCSCommand(SCS_CALIB_ENABLE);
            }
            else
            {
               //Send SCS to Application Processor to disable calibaration
               IolinkScsFifo.SendSCSCommand(SCS_CALIB_DISABLE);
            }
        }

        if(ExitFromCalibTask==TRUE)
        {
            break;
        }
    
    }

    // Terminate the task as this is a periodic task.
    TASKRETURN TaskRetrunValue ;
    TaskRetrunValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskRetrunValue.TaskContext     = a_TaskContext;
    TaskRetrunValue.ucSuspendTime   = 0;
  
    return TaskRetrunValue;  
}
