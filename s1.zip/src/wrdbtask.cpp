/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : wrdbtask.cpp                                                *
*    Description : WriteDatabase task common to all IOMs.                      *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif
#ifdef IOMTYPE_AOH
#include "aohmain.h"
#endif
#if defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE)
#include "dimain.h"
#endif
#ifdef IOMTYPE_DO
#include "domain.h"
#endif
#ifdef IOMTYPE_LLMUX
#include "llmuxmain.h"
#endif
#ifdef IOMTYPE_SVP
#include "svpmain.h"
#endif
#ifdef IOMTYPE_SP
#include "spmain.h"
#endif
#ifdef IOMTYPE_PI
#include "pimain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif

#include "iol.hpp"
extern clsIol Iol;

UINT8 ValidateWrMessage (clsIomSlot *,UINT8 *,UINT8);

#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
    extern UINT8 ucShramWriteMsgNumber; //Shared Ram write message number
    #define LATEST_SLTCHKPNT_VERSION pIomSlot->GetLatestSlotChkpntVersion()
#endif

#ifdef IOMTYPE_UIO
    #define LATEST_SLTCHKPNT_VERSION    (pIomSlot->GetLatestSlotChkPntVersion())
    #define PARAMID_SLTCHKPNT           (pIomSlot->GetSlotChkPntParamId())
#endif
/*******************************************************************************
*                               WriteDatabaseTask                              *
*                               =================                              *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN WriteDatabaseTask(TASKCONTEXT a_TaskContext) {
    const UINT8 WRDBTASK_MAX_EXEC_TIME = 5;
    const UINT8 WRDBTASK_SUSPEND_TIME = 2;
    TASKRETURN TaskReturnValue;
    TaskReturnValue.TaskContext = a_TaskContext;
    UINT32 ulTimeSpent,ulTimeStart = TaskScheduler.Get10msecCounter();

    if (REDSTATE_FROZEN > BOX->GetRedState()) {
        while (WriteMsgQueue.IsRcvBfrEmpty() == FALSE) {
            UINT8 ucMsgStatus = IOL_WM_IN_PROGRESS;
            // Get next message pointer from the write message queue object
            UINT8 *ucpMsg = WriteMsgQueue.GetNextMsgPtr();
            UINT8 ucMsgSize = ucpMsg[IOLMSG_NUMBER];

#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG) && (0)
            if (((ucDbgPnt == WRDB_DBGPNT) && (PARAMID_OP != ucpMsg[IOLREQ_PARAMID])) ||
                 (ucDbgPnt == WRCM_DBGPNT) && (uiDbgPnt1  == ucpMsg[IOLREQ_PARAMID]))
            {
                // to print message that has tobe write into param
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n"));
                for (UINT8 ucIndex = 0; ucIndex < ucMsgSize; ucIndex++)
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("%02x ", ucpMsg[ucIndex]));
            }
#endif
            // Construct pointer to the database object to which write is addressed
            clsIomSlot *pIomSlot = pDatabase[ucpMsg[IOLREQ_SLOTNUM]];
            // Get message number which is saved at the end of the message.
            UINT8 ucMsgNumber = ucpMsg[ucMsgSize];
            
            #if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
                //Same WriteDatabaseTask message number is used while send the write message over shared ram
                //queue to application processor
                ucShramWriteMsgNumber = ucMsgNumber;
            #endif

            switch (ucpMsg[IOLMSG_COMMAND]) {
                case CMD_WRBLOCKABSOLUTE:
                    DATABYTES address;
                    UINT8     *pDest,*pSrc,ucCount;
                    if (ucpMsg[IOLMSG_NUMBER] - IOLWRMSG_OVERHEAD != ucpMsg[IOLREQ_ABSNUM]) {
                        ucMsgStatus = DO_WM_INSUF_DATA;
                        break;
                    }
                    if (BOX->GetModuleStatus() != MODSTATUS_IDLE) {
                        ucMsgStatus = DO_STATE_MUST_BE_IDLE;
                        break;
                    }
                    address.ucBytes[0] = 0;
                    address.ucBytes[1] = ucpMsg[IOLREQ_12DATA];
                    address.ucBytes[2] = ucpMsg[IOLREQ_12DATA+1];
                    address.ucBytes[3] = ucpMsg[IOLREQ_12DATA+2];
                    pDest = (UINT8 *) address.ui32Val;
                    #if HEK
                    #ifndef IOMTYPE_PI
                    if (pDest < (UINT8 *)CPLD_START_ADDRESS ||
                        (pDest > (UINT8 *)CPLD_END_ADDRESS)&& (pDest < (UINT8 *)EXTERNAL_RAM_START_ADDRESS) ||
                        (pDest > (UINT8 *)EXTERNAL_RAM_END_ADDRESS) && (pDest < (UINT8 *)INTERNAL_RAM_START_ADDRESS) ||
                        (pDest >= (UINT8 *)STACK_TOP) && (pDest < (UINT8 *)P1DR) ||
                        (pDest > (UINT8 *)PGDR)) {
                    #else
                    // PIM does not have CPLD and External SRAM, removing these checks.
                    if (pDest < (UINT8 *)FPGA_START_ADDRESS ||
                        (pDest > (UINT8 *)FPGA_END_ADDRESS) && (pDest < (UINT8 *)INTERNAL_RAM_START_ADDRESS) ||
                        (pDest >= (UINT8 *)STACK_TOP) && (pDest < (UINT8 *)P1DR) ||
                        (pDest > (UINT8 *)PGDR)) {
                    #endif
                    #else
                    if (pDest < (UINT8 *)INTERNAL_RAM_START_ADDRESS ||
                        (pDest >= (UINT8 *)STACK_TOP) && (pDest < (UINT8 *)P1DR) ||
                        (pDest > (UINT8 *)PGDR)) {
                    #endif // HEK
                        ucMsgStatus = DO_FUNCTION_NOT_IMPLEMENTED;
                        break;
                    }
                    pSrc = &ucpMsg[IOLREQ_WRDATA];
                    for (ucCount=ucpMsg[IOLREQ_ABSNUM]; ucCount>0; ucCount--)
                        *pDest++ = *pSrc++;
                    ucMsgStatus = PA_OK;
                    break; 
                case CMD_WRNORMAL:
                    if ((ucMsgStatus = ValidateWrMessage (pIomSlot,ucpMsg,0)) == PA_OK) {
                        ucMsgStatus = pIomSlot->WriteParamData(&ucpMsg[IOLREQ_WRDATA],
                                      ucpMsg[IOLREQ_PARAMID],ucpMsg[IOLREQ_ACCLVL]);
                    }
                    break; 
                case CMD_WRINDEXED:
                    if ((ucMsgStatus = ValidateWrMessage (pIomSlot,ucpMsg,1)) == PA_OK) {
                        ucMsgStatus = pIomSlot->WriteParamData(&ucpMsg[IOLREQ_WRDATA+1],
                                      ucpMsg[IOLREQ_PARAMID],ucpMsg[IOLREQ_ACCLVL+1],
                                      ucpMsg[IOLREQ_INDEX]);
                    }
                    break; 
                case CMD_WRINDEXDEFERRED:
                    ucMsgStatus = DO_COMMAND_NOT_SUPPORTED;
                    break; 
                case CMD_FREEZE:
                    if (BOX->GetRedState() == REDSTATE_FREEZE_ACCEPTED) {
                        BOX->SetRedState(REDSTATE_FROZEN);
                        #ifdef IOMTYPE_AIH
                        TraceLog.AddToTrace(TRACEID_GENERIC,bcFrozen,
                            ((BOX->GetRedData() << BYTESIZE) | BOX->GetRedState()));
                        #endif
                    }
                    else BOX->SetRedState(REDSTATE_FREEZE_NOT_ACCEPTED);
                    Iol.ResetDumpIndex();
                    ucMsgStatus = PA_OK;
                    break; 
                default:
                    HardFail(HF_BADPROGRAMJUMP,WRDBTASK_CPP,__LINE__);
                    break; 
            }

#if !defined(IOPTYPE_SCIOM) && defined(PMIO_DEBUG) && (0)
          //if ((ucMsgStatus != PA_OK) && ((ucpMsg[IOLREQ_PARAMID] != PARAMID_OP) || (uiDbgPnt1 != WRSK_DBGPNT)))
            if ((ucMsgStatus != PA_OK) && (uiDbgPnt1 == WRSK_DBGPNT))
            {
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\rSTAT: %02x", ucMsgStatus));
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\rMESG: "));
                for (UINT8 ucIndex = 0; ucIndex < ucMsgSize; ucIndex++)
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("%02x ", ucpMsg[ucIndex]));
            }
#endif
            // Update write message status and remove the processed message.
            WriteMsgQueue.SetMsgStatus(ucMsgNumber,ucMsgStatus);
            WriteMsgQueue.RemoveMessage(ucMsgNumber,ucMsgSize);

            ulTimeSpent = TaskScheduler.Get10msecCounter();
            ulTimeSpent = (ulTimeSpent >= ulTimeStart) ? (ulTimeSpent - ulTimeStart)
                                                       : (MAXUINT32 - ulTimeStart + 1 + ulTimeSpent);
            
            if (ulTimeSpent >= WRDBTASK_MAX_EXEC_TIME) {
                // Suspend if the task has continuously run for max time (co-operative multi tasking)
                TaskReturnValue.ucSuspendTime = WRDBTASK_SUSPEND_TIME;
                TaskReturnValue.TaskReturnState = TASKRETURNSTATE_SUSPEND;
                return TaskReturnValue;
            }
        }
    }

    TaskReturnValue.ucSuspendTime   = 0;
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    return TaskReturnValue;
}

UINT8 ValidateWrMessage (clsIomSlot *pIomSlot,UINT8 *ucpMsg,UINT8 ucOffset)
{
#ifdef IOMTYPE_PI
    if ((PARAMID_TV == ucpMsg[IOLREQ_PARAMID]) && (DT_BLIND == ucpMsg[IOLREQ_DATATYPE])){
        ucpMsg[IOLREQ_PARAMID] = PARAMID_TV64;
        ucpMsg[IOLREQ_DATATYPE] = DT_FLOAT64;
    }
#endif

    UINT8 ucActualDataType = pIomSlot->GetDataType(ucpMsg[IOLREQ_PARAMID]);

    // Validate parameter number.
    if (DT_NONE == ucActualDataType)
    {
        return DO_PARAMETER_INVALID;
    }

    // Validate parameter data type.
    else if (ucActualDataType != ucpMsg[IOLREQ_DATATYPE + ucOffset])
    {
        return DO_DATA_TYPE_ERROR;
    }

    // Validate parameter size. 
    else {
#if defined(IOPTYPE_SCIOM)        
        if (((ucpMsg[IOLREQ_SLOTNUM] == 0) && (ucpMsg[IOLREQ_PARAMID] == PARAMID_BOXCHKPNT) && (ucpMsg[IOLREQ_WRDATA] < LATEST_BOXCHKPNT_VERSION)) ||
            ((ucpMsg[IOLREQ_SLOTNUM] != 0) && (ucpMsg[IOLREQ_PARAMID] == PARAMID_SLTCHKPNT) && (ucpMsg[IOLREQ_WRDATA] < LATEST_SLTCHKPNT_VERSION)))
        {
            // If an older version checkpoint restore comes down, select appropriate checkpoint structure.
            // Note that checkpoint version is available in the first byte of the write buffer.
            if ((ucpMsg[IOLMSG_NUMBER] - IOLWRMSG_OVERHEAD - ucOffset) < pIomSlot->GetCheckPointSize(ucpMsg[IOLREQ_WRDATA]))
            {
                return DO_WM_INSUF_DATA;
            }

        }
        else
        {
            if ((ucpMsg[IOLMSG_NUMBER] - IOLWRMSG_OVERHEAD - ucOffset) < pIomSlot->GetParamSize(ucpMsg[IOLREQ_PARAMID]))
            {
                return DO_WM_INSUF_DATA;
            }
        }
#else
        //due to checkpoint version not existing in PMIO
        if ((ucpMsg[IOLMSG_NUMBER] - IOLWRMSG_OVERHEAD - ucOffset) < pIomSlot->GetParamSize(ucpMsg[IOLREQ_PARAMID]))
        {
            return DO_WM_INSUF_DATA;
        }
#endif
    }

    return PA_OK;
}
