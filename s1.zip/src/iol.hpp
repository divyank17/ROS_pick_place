////////////////////////////////////////////////////////////////////////////////
//                         CSysE, Fort Washington, PA.                        //
//                                                                            //
//                             COPYRIGHT (C) 2004                             //
//                HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                //
//                             ALL RIGHTS RESERVED                            //
//                                                                            //
// This software is a copyrighted work and / or information protected as a    //
// trade secret.  Legal rights of Honeywell Inc. in this software is distinct //
// from ownership of any medium in which the software is embodied. Copyright  //
// or trade secret notices included must be reproduced in any copies that are //
// authorized by Honeywell Inc.                                               //
//                                                                            //
// The information in this software is subject to change without notice and   //
// should not be considered as a commitment by Honeywell Inc.                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//   File Name   : iol.hpp                                                    //
//   Description : IOL Interface class definition file                        //
////////////////////////////////////////////////////////////////////////////////
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif
#ifdef IOMTYPE_AOH
#include "aohmain.h"
#endif
#if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
#include "dimain.h"
#endif
#ifdef IOMTYPE_DO
#include "domain.h"
#endif
#ifdef IOMTYPE_LLMUX
#include "llmuxmain.h"
#endif
#ifdef IOMTYPE_SVP
#include "svpmain.h"
#endif
#ifdef IOMTYPE_SP
#include "spmain.h"
#endif
#ifdef IOMTYPE_PI
#include "pimain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif

#ifndef __IOL_HPP__
#define __IOL_HPP__
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8   MAXDSA = 63;
const UINT8   PHI = 24;                     // System Clock (in MHz)
const UINT16  TMRCLKPER = 16000 / PHI;      // Timer 4 Clock period (in ns)
// for PMIO Redesign IOL Comm related timers constants
#if !defined(IOPTYPE_SCIOM)
const UINT8   NCYCLES_CHARTO = 96;          // TcWait = ~40.00 us
const UINT32  LNKSILNS       = 20000000;    // Link Silence (in ns)
const UINT32  LNKHUNTNS      = 1000000;     // Link hunt time (in ns)
const UINT16  CNTLNKSIL      = 30000;       // 20ms (LNKSILNS/TMRCLKPER)
const UINT16  CNTLNKHUNT     = 1500;        // 1000 us (LNKHUNTUS/TMRCLKPER)
const UINT16  CNTLNKSECTO    = 2*(2 + 40);  // 80ms timeout for the backup module
const UINT16  CNTLNKPRITO    = 2*(2 + 120); // 160ms timeout for the primary module
const UINT16  TPU4CNT_TCWAIT = 52;          // TcWait TPU4_TCNT (34.66 us)
const UINT16  TPU4CNT_TMGAP  = 82;          // Tmgap TPU4_TCNT (54.66 us)
const UINT8   IOL_BAUDRATE   = 1;           // Bit Rate Register Set (N=1 -> 375000bps)
#else // Series C IOL Comm related timers constants
const UINT8   NCYCLES_CHARTO = 48;          // TcWait = ~20.00 us
const UINT32  LNKSILNS = 10000000;          // Link Silence (in ns)
const UINT32  LNKHUNTNS = 500000;           // Link hunt time (in ns)
const UINT16  CNTLNKSIL = 15000;            // 10ms (LNKSILNS/TMRCLKPER)
const UINT16  CNTLNKHUNT = 750;             // 500 us (LNKHUNTUS/TMRCLKPER)
const UINT16  CNTLNKSECTO = 2 + 40;         // 40ms timeout for the backup module
const UINT16  CNTLNKPRITO = 2 + 120;        // 80ms timeout for the primary module
const UINT16  TPU4CNT_TCWAIT = 26;          // TcWait TPU4_TCNT
const UINT16  TPU4CNT_TMGAP = 41;           // Tmgap TPU4_TCNT
const UINT8   IOL_BAUDRATE = 0;             // Bit Rate Register Set (N=0 -> 750000bps) 
#endif
const UINT16  LOOPCNT10USEC = 60;
const UINT16  LOOPCNT20USEC = 120;
const UINT16  LOOPCNT30USEC = 180;
const UINT16  LOOPCNT40USEC = 240;
const UINT16  LOOPCNT100USEC = 600;

// for AO16 Wiggle timings
#if defined(IOPTYPE_AO16) || defined(IOPTYPE_DI) || defined(IOPTYPE_DO)
#define LPCNTUSEC(a) (UINT16)(a*7)
#endif
// for HLAI Wiggle timings
#if defined(IOPTYPE_HLAI) || defined (IOPTYPE_DI) || defined(IOPTYPE_DO)
const UINT32  LOOPCNT83USEC = (LOOPCNT100USEC)+(LOOPCNT10USEC);
//const UINT16  LOOPCNT165USEC = 1320;
//const UINT16  LOOPCNT165USEC = 1320 - (LOOPCNT10USEC);
const UINT16  LOOPCNT165USEC = 1260;
//const UINT16  LOOPCNT210USEC = 1680;
const UINT16  LOOPCNT210USEC = 1680 + (LOOPCNT10USEC);
const UINT32  LOOPCNT252USEC = 2010;
#endif

#if defined(IOMTYPE_SVP) || defined(IOMTYPE_SP)
const UINT16  MAX_DUMP_SIZE = 240;
#endif

//Factory Test Related constants
const UINT8 SECURTYDATA1 = 0x52;
const UINT8 SECURTYDATA2 = 0x57;
const UINT8 SECURTYDATA3 = 0x42;
//Tests
const UINT8 WDT1_TST           = 1;//Tests the Higher limit of the WDT
const UINT8 GHO_TST            = 2;    
const UINT8 JABBER_TST         = 3;
const UINT8 JBR_RES_TST        = 4;
const UINT8 JBR_RES_XMIT_TST   = 5;
const UINT8 RDN_HW_TST         = 6;
const UINT8 UPDT_HWVER_NO      = 7;
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_UIO))
const UINT8 HARTLPBK_TST       = 8;
#endif
#ifdef IOMTYPE_LLMUX
const UINT8 FTA_UART_RTS1      = 5;
const UINT8 FTA_UART_RTS2      = 6;
const UINT8 FTA_UART_RTS3      = 7;
const UINT8 FTA_UART_RTS4      = 8;
const UINT8 FTAUARTLPBK_TST    = 8;
#endif
const UINT8 WDT2_TST           = 9;
const UINT8 UPDT_SERIAL_NO     = 10;
const UINT8 CHNG_SPLSIGNALS    = 11;//To set/reset SWBUREQ_n,EN_SW,TST_SW,INH_SW2,INH_SW1
const UINT8 UPDT_PROD_TYPE     = 13;
const UINT8 UPDT_PROD_CODE     = 14;
#if (defined(IOMTYPE_SVP) || defined(IOMTYPE_SP))
const UINT8 DSC_WDT_TST        = 12;
#endif
const UINT8 TEST_BYTE = 0xAA;

#if defined(IOPTYPE_SCIOM)
//At 750kbps,it takes 1.33usec to xmit a bit. Six TPU5 counts makes one usec.
const UINT8 BITTPU5COUNT = 8;
//This accounts the alert bit and stop bit which follows the MSB of data.
const UINT8 BASETPU5COUNT = 16;
//MAX Jabber Time = 11.55msec,the MIN CHAR TIME = 14.56microsec
//NO_INVALID_CHARS = 11.55msec/14.56us ==> 793 + Safety Factor ==> 900
const UINT16 NO_INVALID_CHARS = 900;
#else // modified for FCT testing (GHO TEST - TEST#4)
//At 375kbps,it would takes 2.66usec to xmit a bit. Six TPU5 counts makes one usec.
const UINT8 BITTPU5COUNT = 16;
//This accounts the alert bit and stop bit which follows the MSB of data.
const UINT8 BASETPU5COUNT = 33;
//MAX Jabber Time = 6msec,the MIN CHAR TIME = 29.26microsec
//NO_INVALID_CHARS = 6msec/29.26us ==> 205 + Safety Factor ==> 400
const UINT16 NO_INVALID_CHARS = 400;
#endif

// The character count of factory command to initiate UPDT_HWREVCODE_NO subcommand
const UINT8 UPDT_HWREVCODE_MSG_CC   = 0x0A;
// The character count of factory command to initiate UPDT_SERIAL_NO subcommand
const UINT8 UPDT_SERIAL_NO_MSG_CC   = 0x0C;
//The character count of the factory command to initiate CHNG_SPLSIGNALS
const UINT8 CHNG_SPLSIGNALS_MSG_CC  = 0x09;
// The character count of the factory command to initiate UPDT_PROD_CODE
const UINT8 UPDT_PROD_CODE_CC       = 0x0A;
// The character count of the factory command to initiate UPDT_PROD_TYPE
const UINT8 UPDT_PROD_TYPE_CC       = 0x0A;
//Factory Command,CHNG_SPLSIGNALS Sub Command related constants
const UINT8 SETMODE_BIT = 0x80;//MSB Bit
const UINT8 DATA_BITS   = 0x7F;//0-6bits
const UINT8 SWBUREQ_SIGNAL = 0;
#if (defined(IOMTYPE_DO) || defined(IOMTYPE_PI))
const UINT8 EN_SW_SIGNAL   = 1;
#endif
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AO) || defined(IOMTYPE_DO)|| defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP) || defined(IOMTYPE_PI))
const UINT8 TST_SW_SIGNAL  = 2;
const UINT8 INH_SW2_SIGNAL = 3;
const UINT8 INH_SW1_SIGNAL = 4;
#endif
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AO)|| defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP))
const UINT8 DIS_SW1_SIGNAL = 5;
const UINT8 DIS_SW2_SIGNAL = 6;
#endif
#if defined(IOMTYPE_UIO)
const UINT8 INHOUT_SIGNAL  = 9;
#endif
#if (defined(IOMTYPE_PI))
const UINT8 FCO_0_SIGNAL   = 10;
const UINT8 FCO_1_SIGNAL   = 11;
#endif
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef enum FLETCHERACTION {
    FTYP_APPEND,
    FTYP_COMPARE
}FLETCHERACTION;

typedef enum tagAddChg {
    ADDCHG_NONE,
    ADDCHG_NEW,
    ADDCHG_DROPPED
} ADDCHG;

class clsIol; // Forward declaration
typedef struct tagCMDINFO {
    UINT8 CountReq;
    UINT8 CountResp;
    PASTATUS (clsIol::* CmdHandler)(VOID);
}CMDINFO;

/*******************************************************************************
*                                     clsIol                                   *
*                                     ======                                   *
*******************************************************************************/
class clsIol {
    static const UINT8   LastCommand;
    static const CMDINFO aCmdInfo[];

    UINT ChecksumHi;
    UINT ChecksumLo;
    UINT8 CountErrorA;
    UINT8 CountErrorB;
    UINT8 ucIolId;
    UINT8 ucIolBA;
    UINT8 ucIolDPA;
    UINT8 ucIolDSA;
    UINT8 ucLastDSA;
    UINT8 ucMsgNumber;
    UINT8 ucIdxDump;
    UINT8 nCharProcd;
    UINT8 *pRcvBuffer;
    UINT8 xmit_buffer[IOL_MAXXMT_MSGSIZE+1];
    UINT8 ucDest;
    UINT8 ucNumber;
    UINT8 ucCommand;
    BOOL  bCommError;
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    UINT8 ucBRDPInfoField[5];   //We need to save these I-Field byte for processing for BRDP.
    // Only 4 bytes are for I-Field. 5th byte is used to save the BRDP MsgNum.
#endif
    BOOL NotMyAddress (UINT8 ucAddress) {
        return ((ucAddress != 0) && (ucAddress != ucIolDPA) && (ucAddress != ucIolDSA));
    }

    VOID Add2Checksum (UINT8 ucByte) {
        ChecksumLo += ucByte;
        if (ChecksumLo > 0xFF) ChecksumLo += 0xFF01;     // if carry, sub 256, add 1 
        ChecksumHi += ChecksumLo;
        if (ChecksumHi > 0xFF) ChecksumHi += 0xFF01;     // if carry, sub 256, add 1
    }

    VOID StartNakResponse(PASTATUS ucNack) {
        xmit_buffer[IOLMSG_DESTINATION] = pRcvBuffer[IOLMSG_SOURCE];
        xmit_buffer[IOLMSG_NUMBER] = aCmdInfo[IOLCMD_NACK].CountResp;
        xmit_buffer[IOLMSG_SOURCE] = pRcvBuffer[IOLMSG_DESTINATION];
        xmit_buffer[IOLMSG_COMMAND] = IOLCMD_NACK | 0x80;
        while (TPU4_TCNT < TPU4CNT_TMGAP); // Wait Tmgap before respondng
        nCharProcd = 0;              // reset transmitted character count 
        TXREQ_n = IOLDRV_ON;                // turn on RS-485 transmitter 
        #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        if(FALSE == IsFpgaS2) // S3 FPGA
        {        
            P_SCI2.TDR = xmit_buffer[nCharProcd];
            P_SCI2.SSR.BIT.MPBT = IOL_ALERT_SET;    // set alert bit in first char 
            P_SCI2.SSR.BIT.TDRE = IOL_TDRE_RESET;   // Clear TDR int flag 
            P_SCI2.SSR.BIT.RDRF = IOL_RDRF_RESET;   // Clear RDR int flag
            nCharProcd += 1;
            set_imask_exr(LVLPRI_IOLN);        // enable xmtr ints to be nested
            P_SCI2.SCR.BYTE = 0xB0;            // enable transmitter interrupts
        }
        else //if(TRUE = IsFpgaS2)
        #endif
        {
            IOL_TDR = xmit_buffer[nCharProcd];
            IOL_ALERT_XMIT = IOL_ALERT_SET;    // set alert bit in first char 
            IOL_TDRE = IOL_TDRE_RESET;         // Clear TDR int flag 
            IOL_RDRF = IOL_RDRF_RESET;         // Clear RDR int flag
            nCharProcd += 1;
            set_imask_exr(LVLPRI_IOLN);        // enable xmtr ints to be nested
            IOL_SCR = 0xB0;                    // enable transmitter interrupts
        }
        xmit_buffer[IOLNAK_PASTAT] = ucNack;
        ComputeFletcher(xmit_buffer, FTYP_APPEND);
    }

    VOID StartResponse(VOID) {
        while (TPU4_TCNT < TPU4CNT_TMGAP); // Wait Tmgap before respondng
        nCharProcd = 0;              // reset transmitted character count 
        TXREQ_n = IOLDRV_ON;                // turn on RS-485 transmitter 
        #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        if(FALSE == IsFpgaS2) // S3 FPGA
        {      
            P_SCI2.TDR = xmit_buffer[nCharProcd];
            P_SCI2.SSR.BIT.MPBT = IOL_ALERT_SET;    // set alert bit in first char 
            P_SCI2.SSR.BIT.TDRE = IOL_TDRE_RESET;   // Clear TDR int flag 
            P_SCI2.SSR.BIT.RDRF = IOL_RDRF_RESET;   // Clear RDR int flag
            nCharProcd += 1;
            set_imask_exr(LVLPRI_IOLN);      // enable xmtr ints to be nested
            P_SCI2.SCR.BYTE = 0xB0;          // enable transmitter interrupts
        }
        else //if(TRUE = IsFpgaS2)
        #endif
        {
            IOL_TDR = xmit_buffer[nCharProcd];
            IOL_ALERT_XMIT = IOL_ALERT_SET;    // set alert bit in first char 
            IOL_TDRE = IOL_TDRE_RESET;                  // Clear TDR int flag 
            IOL_RDRF = IOL_RDRF_RESET;                  // Clear RDR int flag
            nCharProcd += 1;
            set_imask_exr(LVLPRI_IOLN);      // enable xmtr ints to be nested
            IOL_SCR = 0xB0;                  // enable transmitter interrupts
        }
    }

    VOID ResetSilenceTimer(UINT16 uwTimeOut) {
        TPU4_CST = 0;                                  // stop the timer
        TPU4_TCNT = 0;                              // reset the counter
        TPU4_TGRB = uwTimeOut;  // and the link silence compare register
        TPU4_CST = 1;                               // restart the timer
    }

    VOID StartGapTimer(VOID) {
        TPU4_CST = 0;                                  // stop the timer
        TPU4_TCNT = 0;                              // reset the counter
        TPU4_CST = 1;                               // restart the timer
    }

    VOID SetIolDSA(UINT8 ucNewDSA) {
        ucIolDSA = ucNewDSA;
        ucIolBA = 0xFF;
    }

    UINT8 ComputeFletcher(UINT8 *, FLETCHERACTION);
    VOID LossofCommShed(VOID);
    PASTATUS GetPrimaryResponse(UINT8,UINT8,UINT8 *);
    PASTATUS GetPrimaryResponse_S3(UINT8,UINT8,UINT8 *);
    //VOID DoWiggle(VOID);
    VOID TransmitData(UINT8 data);

    PASTATUS Cmd01Handler(VOID);
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    PASTATUS Cmd04Handler(VOID);
    PASTATUS Cmd07Handler(VOID);
#endif
    PASTATUS Cmd08Handler(VOID);
    PASTATUS Cmd0AHandler(VOID);
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    PASTATUS Cmd0BHandler(VOID);
    PASTATUS Cmd0CHandler(VOID);
#endif
    PASTATUS Cmd0FHandler(VOID);
    PASTATUS Cmd10Handler(VOID);
    PASTATUS Cmd16Handler(VOID);
    PASTATUS Cmd17Handler(VOID);
#if defined(IOMTYPE_DISOE) || defined (IOPTYPE_DI)
    PASTATUS Cmd1EHandler(VOID);
#endif
    PASTATUS Cmd1FHandler(VOID);
    PASTATUS Cmd20Handler(VOID);
    PASTATUS Cmd25Handler(VOID);
    PASTATUS Cmd26Handler(VOID);
    PASTATUS Cmd28Handler(VOID);
#if (defined(IOMTYPE_DISOE) || defined(IOMTYPE_UIO))
    PASTATUS Cmd29Handler(VOID);
#endif
    PASTATUS Cmd2AHandler(VOID);
    PASTATUS Cmd2CHandler(VOID);
    PASTATUS Cmd2DHandler(VOID);
#if (defined(IOMTYPE_DISOE) || defined(IOPTYPE_DI))
    PASTATUS Cmd2EHandler(VOID);
#endif
    PASTATUS Cmd2FHandler(VOID);
    PASTATUS Cmd32Handler(VOID);
    PASTATUS Cmd33Handler(VOID);
    PASTATUS Cmd35Handler(VOID);
    PASTATUS Cmd37Handler(VOID);
    PASTATUS DefaultHandler(VOID);
    PASTATUS BroadcastHandler(VOID);
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_UIO))
    BOOL ProcessDefWrCmd(VOID);
#endif
public:
    clsIol(VOID); // constructor
    VOID *operator new (SIZE_T) {return NULL;}
    VOID operator delete(VOID *) {HardFail(HF_INVPROGRAMEXEC,IOL_HPP,__LINE__);}

    // IOLink GHO,Xmit and Receive ISRs
    static VOID ISR_GHO(VOID);
    static VOID ISR_Rcvr_Error(VOID);
    static VOID ISR_Rcvr(VOID);
    static VOID ISR_Xmit(VOID);
    static VOID ISR_XmitEnd(VOID);
    #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
    static VOID ISR_SCI2_Rcvr_Error(VOID);
    static VOID ISR_SCI2_Rcvr(VOID);
    static VOID ISR_SCI2_Xmit(VOID);
    static VOID ISR_SCI2_XmitEnd(VOID);
    #endif
    static VOID ISR_SilenceTimer(VOID);

    VOID Enable(VOID);
    VOID Disable(VOID) {
        // Disable the IOL Interface 
        TXREQ_n = IOLDRV_OFF;             // turn off RS-485 transmitter 
        #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        if(FALSE == IsFpgaS2) // S3 FPGA
        {
            P_SCI2.SCR.BYTE = 0x00;
        }
        else //(TRUE = IsFpgaS2)
        #endif
        {
            IOL_SCR = 0x00;               // Disable everything
        }
        CLRGHL_n = GHO_DISABLED;          // Disable GHO interrupt register
        GHO_IRQ0F = GHO_RESET;            // Reset IRQ0 interrupt flag
    }
    VOID ResetDumpIndex(VOID) {ucIdxDump=0;}
    VOID DropDSA(VOID) {
        ucIolBA = 0xFF;
        ucIolDSA = 0;
        ucLastDSA = 0;
    }
    VOID SetIolBA(UINT8 ucNewBA) {
        ucIolBA = ucNewBA;
        ucIolDSA = (ucIolBA == 0xFF) ? 0 : ucIolBA;
    }
    ADDCHG AddressChange(VOID) {
        ADDCHG RetVal = ADDCHG_DROPPED;
        if (ucIolDSA == ucLastDSA) {
            RetVal = ADDCHG_NONE;
        }
        else if (ucLastDSA == 0) {
            RetVal = ADDCHG_NEW;
        }
        ucLastDSA = ucIolDSA;
        return RetVal;
    }
    BOOL AmPrimary(VOID) {
        BOOL bReturn = TRUE;
        if (ucIolDSA == 0) bReturn = FALSE;
        if (ucIolDSA == ucIolBA) bReturn = FALSE;
        return bReturn;
    }

#ifdef DEBUG
    friend extern RETURNSTATUS WriteDb(VOID);
#endif
};  // clsIol

#endif // IOL_HPP

