/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : diag.cpp                                                    *
*    Description : Implements common diagnostics                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif
#ifdef IOMTYPE_AOH
#include "aohmain.h"
#endif
#if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
#include "dimain.h"
#endif
#ifdef IOMTYPE_DO
#include "domain.h"
#endif
#ifdef IOMTYPE_LLMUX
#include "llmuxmain.h"
#endif
#ifdef IOMTYPE_SVP
#include "svpmain.h"
#endif
#ifdef IOMTYPE_SP
#include "spmain.h"
#endif
#ifdef IOMTYPE_PI
#include "pimain.h"
#endif
#ifdef IOMTYPE_UIO
#include "uiomain.h"
#endif

#include "utils.h"
/*******************************************************************************
*                                EXTERNAL FUNCTIONS                            *
*******************************************************************************/
extern "C" BOOL _TestRAMCell(UINT32);
extern "C" BOOL _TestCPURegisters(VOID);

/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/

#if defined(IOPTYPE_AO16) || defined(IOPTYPE_DO)
// added to resolve, PAR# 1-7LC52TF
#define FTA_RETURN_TIMEOUT 400 //500, 780
#define FTA_OUTCTL_TIMEOUT 200
UINT16 uiFtaReturnTimeout = 0;
#endif
#if !defined(IOPTYPE_SCIOM)
extern clsIol Iol;
#endif

#if defined(PMIO_DEBUG) || defined(PMIO_RLS)
UINT8 ucDumpBuff[DMPBUF_SIZE];
FLOAT32 fDbgFlt;
FLOAT32 fDbgFlt1;
UINT16 ucDbgCnt;
UINT8 ucDbgPnt;
UINT16 uiDbgPnt1;
UINT16 uiDbgPnt2;
UINT8 ucDbgFlag;
//UINT16 uiDbgPnt3;
//UINT16 uiDbgPnt4;
//UINT16 uiDbgPnt5;
//UINT16 uiDbgPnt6;
//UINT16 uiDbgPnt7;
//UINT16 uiDbgPnt8;
#endif

#if (HEK && !defined(IOMTYPE_PI))
UINT32 g_ulTestLocation = EXTERNAL_RAM_START_ADDRESS;
#else
UINT32 g_ulTestLocation = INTERNAL_RAM_START_ADDRESS;
#endif

 // Initialize Diagnostic routines table
const DIAGROUTINE tblDiagRoutines[] =  {
    CPUDiagRoutine,
    RAMContentsDiagRoutine,
#if(defined(IOMTYPE_DO)||defined(IOMTYPE_DI)||defined(IOMTYPE_LLMUX)||defined(IOMTYPE_DISOE))
    FlashContentsDiagRoutine
#else
    FlashContentsDiagRoutine,
#endif
#if(defined(IOMTYPE_AOH))
    EepromCountDiagnostics,
    EepromWrFlagDiagnostics,
    EepromChksmDiagnostics
#elif(defined(IOMTYPE_AIH)) 
    EepromCountDiagnostics,
    EepromWrFlagDiagnostics,
    EepromChksmDiagnostics
#endif
};
//Find the size of diagnostic table 
const UINT8 DIAGROUTINECOUNT = (UINT8)((sizeof(tblDiagRoutines))/sizeof(DIAGROUTINE));

#if (HEK && !defined(IOMTYPE_PI) && !defined(IOMTYPE_UIO))
// Define a function pointer to BOOTCODE memory.  It is used to call FPGA Readback diagnostic
CALLBACKROUTINE *FpgaDiagPtr = (CALLBACKROUTINE *) 0x4E0;
#endif

/*******************************************************************************
*                                  CPUDiagRoutine                              *
*                                  ==============                              *
* PURPOSE:                                                                     * 
*    Test proper operation CPU registers and instructions.                     * 
* ARGUMENTS:                                                                   * 
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire testing is complete. Otherwise INPROGRESS.*
* NOTES:                                                                       *
*    INPROGRESS is returned after completing some tests so that diag task can  *
*    return to the scheduler for scheduling other tasks.                       *
*******************************************************************************/
RETURNSTATUS CPUDiagRoutine(VOID) {
    if (TRUE == _TestCPURegisters()) {
        return RETURNSTATUS_COMPLETE;
    }
    else {
        HardFail(HF_INVPROGRAMEXEC,DIAG_CPP,__LINE__);
    }
    return RETURNSTATUS_INPROGRESS;
}
/*******************************************************************************
*                              RAMContentsDiagRoutine                          *
*                              ======================                          *
* PURPOSE:                                                                     * 
*    Test proper operation RAM read and write operations.                      * 
* ARGUMENTS:                                                                   * 
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire RAM is tested. Otherwise INPROGRESS.      *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS RAMContentsDiagRoutine(VOID) {
#if (HEK && !defined(IOMTYPE_PI))
    if ((g_ulTestLocation <= EXTERNAL_RAM_END_ADDRESS) &&
        (g_ulTestLocation >= EXTERNAL_RAM_START_ADDRESS)) {
        for (UINT8 ucCount = 0; ucCount < RAM_DIAG_CHUNK_SIZE; ucCount++) {
            if (TRUE == _TestRAMCell(g_ulTestLocation)) {
                // Disabling the interrupts for the duration of the test
                // is done inside the _TestRAMCell function.
                g_ulTestLocation += sizeof(UINT32);
                if (g_ulTestLocation > EXTERNAL_RAM_END_ADDRESS) {
                    g_ulTestLocation = INTERNAL_RAM_START_ADDRESS;
                    return RETURNSTATUS_INPROGRESS;
                }
            }
            else {
                HardFail(HF_RAMCONTERROR,DIAG_CPP,__LINE__);
            }
        }


        return RETURNSTATUS_INPROGRESS;
    }
#endif

    for (UINT8 ucCount = 0; ucCount < RAM_DIAG_CHUNK_SIZE; ucCount++) {
        if (TRUE == _TestRAMCell(g_ulTestLocation)) {
            // Disabling the interrupts for the duration of the test
            // is done inside the _TestRAMCell function.
            g_ulTestLocation += sizeof(UINT32);
            if (g_ulTestLocation > INTERNAL_RAM_END_ADDRESS) {
#if (HEK && !defined(IOMTYPE_PI))
                g_ulTestLocation = EXTERNAL_RAM_START_ADDRESS;
#else
                g_ulTestLocation = INTERNAL_RAM_START_ADDRESS;
#endif
                return RETURNSTATUS_COMPLETE;
            }
        }
        else {
            HardFail(HF_RAMCONTERROR,DIAG_CPP,__LINE__);
        }
    }

    return RETURNSTATUS_INPROGRESS;
}
/*******************************************************************************
*                             FlashContentsDiagRoutine                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Check the integrity of flash contents.                                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire FLASH is tested. Otherwise INPROGRESS.    *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS  FlashContentsDiagRoutine(VOID) 
{ 
#ifndef DEBUG
    static  UINT32 *pcCurrentAddress = (UINT32 *)APP_FLASH_START_ADDRESS;
    static  UINT32 suiCrc            = 0;

    for (UINT8 ucCount = 0; ucCount < ROM_DIAG_CHUNK_SIZE; ucCount++) 
    {
        if (!(pcCurrentAddress >= (UINT32 *)APP_HEADER_START_ADDRESS && pcCurrentAddress <= (UINT32 *)APP_HEADER_END_ADDRESS))
            suiCrc = ((suiCrc>>31)|(suiCrc<<1)) ^ (*pcCurrentAddress);
        pcCurrentAddress++;

        if (pcCurrentAddress >= (UINT32 *)APP_FLASH_START_ADDRESS + *((UINT32 *)APP_BYTECNT_ADDRESS)/4) {
            if (*((UINT32 *)APP_CRC_ADDRESS) != suiCrc)
                HardFail(HF_APPCRCFAIL,DIAG_CPP,__LINE__);
            else {
                // Reinitialize the variables for next round of diagnostics.
                pcCurrentAddress = (UINT32 *)APP_FLASH_START_ADDRESS;
                suiCrc           = 0;
                return RETURNSTATUS_COMPLETE;
            }
        }
    }
    return RETURNSTATUS_INPROGRESS;    
#else
    return RETURNSTATUS_COMPLETE;
#endif
}
/*******************************************************************************
*                                AddressDiagRoutine                            *
*                                ==================                            *
* PURPOSE:                                                                     *
*    Test proper operation of address lines.                                   *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire RAM is tested. Otherwise INPROGRESS.      *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS AddressDiagRoutine(VOID) {
    static UINT8 sucTestLocCount = 0,sucChangeLocCount = 1;
    UINT8 ucSaveTestLoc,ucSaveChangeLoc;

    // Test location and change location cannot be the same.
    if (sucTestLocCount == sucChangeLocCount) {
        sucChangeLocCount++;
    }

    if (ADDR_DIAG_COUNT == sucChangeLocCount) {
        sucChangeLocCount = 0;
        sucTestLocCount++;
        if (ADDR_DIAG_COUNT == sucTestLocCount) {
            sucTestLocCount = 0;
            sucChangeLocCount = 1;
            return RETURNSTATUS_COMPLETE;
        }
    }

    // Do the test. Disable all interrupts for the duration of the test.
    UINT8 ucSaveExr = get_imask_exr(); // Save original EXR mask
    set_imask_exr(LVLPRI_HIGHEST); // Disable all interrupts.

    // Save test and change locations.
    ucSaveTestLoc = *ADDR_DIAG_TBL[sucTestLocCount];
    ucSaveChangeLoc = *ADDR_DIAG_TBL[sucChangeLocCount];

    // Modify change location and restore original value
    *ADDR_DIAG_TBL[sucChangeLocCount] = ADDR_DIAG_PATTERN1;
    *ADDR_DIAG_TBL[sucChangeLocCount] = ADDR_DIAG_PATTERN2;
    // Verify that the test location value is not changed.
    if (ucSaveTestLoc != *ADDR_DIAG_TBL[sucTestLocCount]) {
        HardFail(HF_RAMADDRERROR,DIAG_CPP,__LINE__);
    }
    // Restore the original contents at change location.
    *ADDR_DIAG_TBL[sucChangeLocCount] = ucSaveChangeLoc;

    set_imask_exr(ucSaveExr); // Restore the original EXR mask

    sucChangeLocCount++;
    return RETURNSTATUS_INPROGRESS;
}
/*******************************************************************************
*                                  DPADiagRoutine                              *
*                                  ==============                              *
* PURPOSE:                                                                     *
*    Compare DPA value in the database with the address pin settings.          *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  DPADiagRoutine(VOID) {

#if !AIAO
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    RDBK_SEL = RDBK_MODNUM;
#endif // !AIAO
    UINT8 ucModuleId = MODNUM & (MODNUMBITS | IOLIDBIT);

#if !AIAO
    set_imask_exr(ucSaveExr);
#endif // !AIAO

#if !defined(IOPTYPE_SCIOM)
    // for PMIO Redeisgn
    if (!isOddParity(ucModuleId >> 4)) {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_ADDRDIAGFAIL, TRUE, 0);
    }    
    else if (BOX->GetModlNum() != (MODNUM & MODNUMBITS)) {
#else
    if (BOX->GetModuleId() != ucModuleId) {
#endif
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADDRDIAGFAIL,TRUE,0);
    }
    else {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADDRDIAGFAIL,FALSE,0);

    }

    return RETURNSTATUS_COMPLETE;
}
/*******************************************************************************
*                                WiggleDiagRoutine                             *
*                                =================                             *
*  If IOM is in SYNCD state and both wiggle bits in REDDATA are set then post  *
*  REDNDIAG softfail. Otherwise return the REDNDIAG softfail.                  *
*******************************************************************************/
RETURNSTATUS WiggleDiagRoutine(VOID) {
    if (BOX->GetRedState() == REDSTATE_SYNCD) {
        if ((BOX->CheckRedData(REDDATA_WIGGLE)) && 
            (BOX->CheckRedData(REDDATA_WIGLSF))) {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDNDIAG,TRUE,0);
            return RETURNSTATUS_COMPLETE;
        }
    }

    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDNDIAG,FALSE,0);
    return RETURNSTATUS_COMPLETE;                
}
/*******************************************************************************
*                              FtaPowerMonitorRoutine                          *
*                              ======================                          *
* PURPOSE:                                                                     *
*    Monitor P_CPLDR06.B11 to check if the FTA power is good. The bit will be  *
*    0 if FTA power is good, 1 otherwise.                                      *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
#ifdef IOMTYPE_LLMUX
RETURNSTATUS FtaPowerMonitorRoutine(VOID) {
    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_FTAPOWFAIL,FTA_PWR,0);
    return RETURNSTATUS_COMPLETE;
}
#endif

/*******************************************************************************
*                              FtaMissingCheck                                 *
*                              ===============                                 *
* PURPOSE:                                                                     *
*    Checking if FTA present or missing.                                       *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*       For PMIO redesign modules                                              *
*******************************************************************************/
#if !defined(IOPTYPE_SCIOM)
RETURNSTATUS SyncDiagRoutine(VOID)
{
    // Set Sync Lost Sfail if, SEC & Redundant state is sync failed.
    if (!(Iol.AmPrimary()) && (BOX->GetRedState() == REDSTATE_SYNC_FAILED))
         BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_LOSTSYNC,  TRUE, 0);    
    else BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_LOSTSYNC, FALSE, 0);    

    return RETURNSTATUS_COMPLETE;
}
// for pmio redesign modules,
VOID FtaPresenceChecking(VOID) 
{
    BOOL FtaPresence = !REDUNT_n;

    static BOOL FtaCheckRepeat = FALSE;
#if !AIAO
    // Save readback select registers
    UINT8 ucRdBkSel = RDBK_SEL;
    RDBK_SEL = RDBK_IOTA;
    FtaPresence = !REDUNT_n;
#endif // !AIAO
       
    // any change in FTA behaviour (present / missing)
    if ((FtaPresence != BOX->GetFtaPres()) || (FtaCheckRepeat))
    {
        // Updating FTA Presence bit in MODSTAT2
        BOX->SetFtaPres(FtaPresence);

#if !defined(IOPTYPE_AO16)                  
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_FTAMISSG, (FtaPresence==FALSE), 0);
#endif
        // added to update IotaPos bit correctly
        FtaCheckRepeat = (FtaCheckRepeat) ? FALSE : TRUE;

#if !AIAO
        RDBK_SEL = RDBK_IOTA;        
#endif

        BOX->SetIotaPos((BOTTOM==DEASSERTED));
    }
#if defined(IOPTYPE_AO16)
    if (uiFtaReturnTimeout) --uiFtaReturnTimeout;
#endif

#if !AIAO
    // restore back readback select register
    RDBK_SEL = ucRdBkSel;
#endif // !AIAO
}

#if defined(IOPTYPE_AO16) || defined(IOPTYPE_DO)
// added to resolve, PAR# 1-7LC52TF
UINT8 FtaStatus(VOID)
{
    BOOL bFtaMissing = REDUNT_n;

#if !AIAO
    UINT8 ucSaveRdBkSel = RDBK_SEL;
    RDBK_SEL = RDBK_IOTA;
    bFtaMissing = REDUNT_n;
    RDBK_SEL = ucSaveRdBkSel;
#endif

    if (bFtaMissing)
    {
        // if FTA missing sfail not triggered,
        if (!(BOX->GetBoxSfByte(SF_FTAMISSG / BYTESIZE) & (1 << (SF_FTAMISSG % BYTESIZE))))
        {            
            // Updating FTA Presence bit in MODSTAT2
            BOX->SetFtaPres(!bFtaMissing);

            uiFtaReturnTimeout = FTA_RETURN_TIMEOUT;

            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_FTAMISSG, bFtaMissing, 0);            
        }      

        return FTA_MISSING;
    }
    else if (uiFtaReturnTimeout)
    {        
        if (uiFtaReturnTimeout > FTA_OUTCTL_TIMEOUT)
             return FTA_MISSING;
        else return FTA_RETURN_BUT_TOUT;
    }
    else
    {
        if (BOX->GetBoxSfByte(SF_FTAMISSG / BYTESIZE) & (1 << (SF_FTAMISSG % BYTESIZE))) {
            
            // Updating FTA Presence bit in MODSTAT2
            BOX->SetFtaPres(!bFtaMissing);

            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_FTAMISSG, bFtaMissing, 0);
        }
    }

    return FTA_RETURN_AND_TOUT;
}
#endif

#endif

/*******************************************************************************
*                                  DiagnosticTask                              *
*                                  ==============                              *
* PURPOSE:                                                                     *
*    Diag task main function. Calls diag routines in a round robin fashion.    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    TASKRETURN with state = TERMINATE.                                        *
* NOTES:                                                                       *
*    1) Diag task is a periodic task with TASKPERIOD = 250 msec.               *
*    2) In each 250 msec cycle, it is designed to execute a diagnostic chunk,  *
*       that typically takes 100 micro second to complete.                     *
*    3) The complete cycle of the diag task takes many minutes to complete and *
*       depends on the tblDiagRoutines initialized by each module type.        *
*******************************************************************************/
TASKRETURN DiagnosticTask(TASKCONTEXT a_TaskContext) 
{
    static UINT8 sucDiagIndex = 0; // To save index of the current diag routine.
    static UINT8 suc10SecCount = 0;// To throttle WiggleDiag calls once per 10 second
    const  UINT8 DIAG_TENSECOND_COUNT = (MILLISECONDS_IN_SECOND/TASKPERIOD_DIAGTASK)*10;

    TASKRETURN TaskRetrunValue;
    TaskRetrunValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskRetrunValue.TaskContext     = a_TaskContext;
    TaskRetrunValue.ucSuspendTime   = 0;
    TaskScheduler.RefreshTaskDmc(TASKID_DIAGTASK);

#ifdef DEBUG
    // Exit right away if the diag task is commanded to be stopped.
    if (TRUE == g_bStopDiagTask) {
        return TaskRetrunValue; 
    }

    // The following two variables are used only in 
    // debug builds for getting the max chunk exec time.
    static UINT16 sucMaxInterval = 0;
    UINT16 usStartCount = TPU5_TCNT;
#endif

    // Execute DPA at the start of every diag routine.
    DPADiagRoutine();
    
    #if (HEK && !defined(IOMTYPE_PI) && !defined(IOMTYPE_UIO))
        // Execute FPGA Readback diagnostic at the start of every diag routine.  
        // Run FPGA Readback for FPGA Revs. "E" or higher.
        #if (HEK && (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH)))
        if (TRUE == IsFpgaS2) // FPGA read back is only for S2 FPGA
        #endif
        if (BOX->GetPld2RevLetter()>= PD_REV_E)    
            FpgaReadBackDiagRoutine();
    #endif

    // Execute Wiggle diagnostic at every 10 second.
    if (++suc10SecCount >= DIAG_TENSECOND_COUNT) {
        suc10SecCount = 0;
        WiggleDiagRoutine();
    }

#if !defined(IOPTYPE_SCIOM)
    SyncDiagRoutine();
#endif

    // Execute the current diagnostic function.
    RETURNSTATUS ReturnStatus = (tblDiagRoutines[sucDiagIndex])();
#ifdef DEBUG
    // Calculate the chunk exec time and update max chunk exec time if needed.
    UINT16 usStopCount = TPU5_TCNT;
    UINT16 usInterval = (usStopCount > usStartCount) ? (usStopCount - usStartCount)
                      : (TPUCOUNT_MAXVALUE - usStartCount) + usStopCount + 1;
    if (usInterval > sucMaxInterval) sucMaxInterval = usInterval;
#endif

    if (RETURNSTATUS_COMPLETE == ReturnStatus) {
        // Advance to the next diagnostic function 
        // if the current function completes its execution
        sucDiagIndex++;
#ifdef DEBUG
        TraceLog.AddToTrace(TRACEID_DIAGTASK,bcDiagTask,(((UINT32)sucDiagIndex << 24) | sucMaxInterval));
#endif
        if (DIAGROUTINECOUNT == sucDiagIndex) {
            sucDiagIndex = 0; // Reset static counter for next run.
#ifdef DEBUG
            g_usDiagCount++;  // Increment the total bkgd count for debug builds.
#endif
        }
    }

    // Return to the scheduler
    return TaskRetrunValue;
}

#ifdef IOMTYPE_AOH
/*******************************************************************************
*                             SwitchDiagnostics                                *
*                             =================                                *
* PURPOSE:                                                                     *
*    Test all 3 switch control outputs                                         *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
* This routine tests all 3 switch control outputs.                             *
* Since there are propagation delays from the time an output is changed to the *
* time its feedfack signal can be reliably read appropriate delays are         *
* are implemented here with a mechanism for one retry should a miscompare occur*  
* One step of the test sequence is executed per call to the respective diag    * 
* routine. Most steps are comprised of a test to confirm the change made in    *
* the last step and then contingent on its success the next change is made.    *
* The sequence advances to the next step only if the present step succeeds -   *
* otherwise one retry is made before advancing or hardfailing.                 *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  SwitchDiagnostics(VOID) 
{ 
    UINT8 ucSubContext,ucCount;

    // Begin switch diagnostics only if this module does not have control of the
    // field terminations and module roles are not in transition.
#if defined(IOPTYPE_AO16)
    // issue: Wrong FTA is not detecting, if the FTA inserted after the module powered up.
    // root cause: Redstate checking was not allowing to detect the wrong FTA, since the module is not in sync.
    if(OUTCTL_PARTNER == BOX->GetModStat3State()) {
#else
    if((OUTCTL_PARTNER == BOX->GetModStat3State()) && (REDSTATE_SYNCD == BOX->GetRedState())) {
#endif
        // Perform the diagnostic of the Disable Output switches 
        for(ucSubContext = CONTEXT_ZERO; ucSubContext <= CONTEXT_FOUR; ucSubContext++) {
            ucCount = 0;
            while(!AoHardware.DisableSwitchDiagnostics(ucSubContext)) {
                ucCount++;
                if(ucCount>1) {
                    HardFail(HF_OUTPUTCONTROL,DIAG_CPP,__LINE__,
                             ucSubContext,AoHardware.GetSwitchStatus(DIS_SWCH));
                }
                IdleWait(DIS_READ_DELAY_TIME);
            }
            IdleWait(DIS_READ_DELAY_TIME);
        }

        // Perform the diagnostic of the Test switch
        for(ucSubContext = CONTEXT_ZERO; ucSubContext <= CONTEXT_TWO; ucSubContext++) {
            ucCount = 0;
            while(!AoHardware.TestSwitchDiagnostics(ucSubContext)) {
                ucCount++;
                if(ucCount>1) {
                    HardFail(HF_OUTPUTCONTROL,DIAG_CPP,__LINE__,
                             ucSubContext,AoHardware.GetSwitchStatus(TST_SWCH));
                }
                IdleWait(TST_READ_DELAY_TIME);
            }
            IdleWait(TST_READ_DELAY_TIME);
        }

        // Perform the diagnostic of the Inhibit Output switches 
        for(ucSubContext = CONTEXT_ZERO; ucSubContext <= CONTEXT_SIX; ucSubContext++) {
            ucCount = 0;
            while(!AoHardware.InhibitSwitchDiagnostics(ucSubContext)) {
                ucCount++;
                if(ucCount>1) {
                    HardFail(HF_OUTPUTCONTROL,DIAG_CPP,__LINE__,
                             ucSubContext,AoHardware.GetSwitchStatus(INH_SWCH));
                }
                IdleWait(INH_READ_DELAY_TIME);
            }
            IdleWait(INH_READ_DELAY_TIME);
        }
        //check if the ININ_IN line is negated 
        if((INHIN_NEGATED == INHIN_FB_n)&&(BURIN_NEGATED == BUPREQ_IN)){
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,TRUE,0);
        }
        else{
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
        }
    }
    return RETURNSTATUS_COMPLETE;
} // SwitchDiagnostics() end
#endif
#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
/*******************************************************************************
*                            EepromCountDiagnostics                            *
*                            ======================                            *
* PURPOSE:                                                                     *
*    Compare count value and check if it is greater than max 10,000 .          *
*    Issues softfail if it is greater than this value.                         *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  EepromCountDiagnostics(VOID) {
#if defined(IOPTYPE_SCIOM)
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        UINT16 ModuleWriteCount = Eeprom.ReadUint16(EE_MODULEINFO_WRITECOUNT);
        if( ModuleWriteCount >= EEPROM_MAXWRCOUNT ) {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EECNTERR,TRUE,0);
        }
        // Firmware will never return this softfail.
    }
#endif
    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                            EepromWrFlagDiagnostics                           *
*                            =======================                           *
* PURPOSE:                                                                     *
*    Compare Write Flags and Bit 6 and Bit 7 should be complimentory           *
*    Issues softfail if it is bit 6 and Bit 7 are same                         *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  EepromWrFlagDiagnostics(VOID) {
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        UINT16 EepromWriteFlags = Eeprom.ReadUint16(EE_MODULEINFO_WRITE_FLAGS);
        if( MODULINFO_WRITE_COMPLETE != EepromWriteFlags ) {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EEFLAGER,TRUE,0);
        }
        // Firmware will never return this softfail.
    }
    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                            EepromChksmDiagnostics                            *
*                            =======================                           *
* PURPOSE:                                                                     *
*    Calculate and compare the checksum of Calib data                          *
*    Issues softfail om CRC Mismatch                                           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  EepromChksmDiagnostics(VOID) {
    static  UINT16 pcCurrentAddress = EEPROM_ADDR_RANGE_START;
    static  UINT16 suChksum         = 0;
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {
        for (UINT8 ucCount = 0; ucCount < EEPROM_DIAG_CHUNK_SIZE; ucCount++) 
        {
            suChksum ^= (Eeprom.ReadUint16(pcCurrentAddress));
            suChksum >>= 1;  // rotate right once
            pcCurrentAddress+=2;
            if (pcCurrentAddress >= EEPROM_CHKSM_ADDR_END) {
                UINT16 SavedChksum = Eeprom.ReadUint16(EEPROM_CHKSM_ADDR_END);
                if ((SavedChksum != suChksum) ||
                    (0 == suChksum) || (MAXUINT16 == suChksum) ||
                    (0 == SavedChksum) || (MAXUINT16 == SavedChksum)) {
                    // Report the Soffail if checksum does not match
                    // or if saved or calculated checksum is all 0s or all 1s.
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EECKSMER,TRUE,0);
                }
                // Firmware will never return this softfail.

                // Reinitialize the variables for next round of diagnostics.
                pcCurrentAddress = EEPROM_ADDR_RANGE_START;
                suChksum         = 0;
                return RETURNSTATUS_COMPLETE;
            }
        }
        return RETURNSTATUS_INPROGRESS;
    }

    return RETURNSTATUS_COMPLETE;
}

#endif

#if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
/*******************************************************************************
*                            CPLDReadBkRegDiag                                 *
*                            =================                                 *
* PURPOSE:                                                                     *
*    Reads the CPLD Readback Registers associated RDBK_BANK3- BANK             *
*    and compares with the value read at startup.                              *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS CPLDReadBkRegDiag(VOID){
    BOOL bStatus = FALSE;
    // Store the patterns read from the readback registers.3-6.
    UINT8 TestPattern[RDBK_CPLD1-RDBK_BANK2];
    // Test pattern in RDBK_BANK3 to RDBK_BANK6 registers verified.
    TestPattern[RDBK_CPLD1-RDBK_BANK3] = (GetReadbackRegister(RDBK_CPLD1) & 0x80);
    TestPattern[RDBK_CPLD1-RDBK_BANK4] = GetReadbackRegister(RDBK_BANK5);
    TestPattern[RDBK_CPLD1-RDBK_BANK5] = GetReadbackRegister(RDBK_BANK4);
    TestPattern[RDBK_CPLD1-RDBK_CPLD1] = GetReadbackRegister(RDBK_BANK3);
    // Test the patterns for errors
    for(UINT8 i=0; i <= RDBK_BANK3; i++){
        //Test pattern in RDBK_BANK3 to RDBK_BANK6 registers verified.
        bStatus = ((RDBK_TESTPATTERN[i]) != TestPattern[i]);
        if(bStatus) break;//Exit the loop on the first encounter of failure.
    }
    if(bStatus) {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RDBKRGDIAGFL,TRUE,0); 
    }
    else {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_RDBKRGDIAGFL,FALSE,0);
    }
    return RETURNSTATUS_COMPLETE;
}
#endif

#if (HEK && !defined(IOMTYPE_PI) && !defined(IOMTYPE_UIO))
/*******************************************************************************
*                            FpgaReadBackDiagRoutine                           *
*                            =======================                           *
* PURPOSE:                                                                     *
*    Calls back the FPGA Readback BOOT function from Address 0x500             *
*    by using FpgaDiagPtr function pointer                                     *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS FpgaReadBackDiagRoutine( VOID )
{
    INT8 ReadBackStatus = 0;
    static UINT32 ReadBackPassCnt = 0;

    //Call back BOOT FPGA Readback diagnostic from Address 0x500
    ReadBackStatus = (*FpgaDiagPtr)();

    if (-1 == ReadBackStatus) 
    {
        TraceLog.AddToTrace(TRACEID_GENERIC, bcFPGAReadBackDiagFailed, ReadBackPassCnt);
        HardFail(HF_FPGARDBKFAIL, DIAG_CPP, __LINE__, ReadBackPassCnt);
    }
    else if (0 == ReadBackStatus)
    {
        ReadBackPassCnt++;
    }
    else if (1 == ReadBackStatus)
    {
        TraceLog.AddToTrace(TRACEID_GENERIC, bcFPGAReadBackDiagPassed, ReadBackPassCnt);
        return RETURNSTATUS_COMPLETE;
    }
    return RETURNSTATUS_INPROGRESS;
}
#endif








