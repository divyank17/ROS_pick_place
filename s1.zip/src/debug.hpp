/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : debug.hpp                                                   *
*    Description : Debug related declarations and debug port class.            *
*******************************************************************************/
#ifndef __DEBUG_HPP__
#define __DEBUG_HPP__
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
const UINT8 OUTPUT_BUFFER_SIZE = 160;
const UINT8 SMALL_INPUT_BUFFER_SIZE = 9;
const UINT8 LARGE_INPUT_BUFFER_SIZE = 17;
const UINT8 CPUFREE_TESTCOUNT = 10;

const CHAR PRINTSTRING_INVALID[]     = "\n\r\tInvalid";
const CHAR PRINTSTRING_SLOTNUMBER[]  = "\n\r\tSlt#:";
const CHAR PRINTSTRING_PARAMNUMBER[] = "\n\r\tPrm#:";
const CHAR PRINTSTRING_PRINTPARAM[]  = "\n\r\tPrm %d Typ %d Size %d Val %d";
const CHAR PRINTSTRING_PROMPTTYPE[]  = "\n\r\tBYTE(1) WORD(2) DWORD(3) :";
const CHAR PRINTSTRING_PROMPTADDR[]  = "\n\r\tStrtAddr 0x:";
const CHAR PRINTSTRING_HOWMANY[]     = "\n\r\tHow many:";
const CHAR PRINTSTRING_XTOCANCEL[]   = "\n\r\tIn progress... 'x' & ENTER to exit\n\r";
const CHAR PRINTSTRING_PASSED[]      = " passed";
const CHAR PRINTSTRING_FAILED[]      = " failed";
const CHAR PRINTSTRING_PROMPTSTOP[]  = "\n\r\tStop?(y/n)(n):";
const CHAR PRINTSTRING_PROMPTSTART[] = "\n\r\tStart?(y/n)(n):";
const CHAR PRINTSTRING_STOPPED[]     = "\n\r\tStopped";
const CHAR PRINTSTRING_STARTED[]     = "\n\r\tStarted";
const CHAR PRINTSTRING_UNCHANGED[]   = "\n\r\tUnchanged";
const CHAR PRINTSTRING_PROMPTIP[]    = "\n\r\t25ms(0) 50ms(1) 100ms(2) 200ms(3) 500ms(4) 1s(5) 2s(6):";
/*******************************************************************************
*                                  clsDebugPort                                *
*                                  ============                                *
*******************************************************************************/
class clsDebugPort {
    UINT8 ucInputIndex;
    UINT8 ucOutputIndex;
    CHAR  OutputBuffer[OUTPUT_BUFFER_SIZE];
    // Define dummy operator new to avoid creation of default operator new and
    // linking of malloc. Since heap is not supported, linking of malloc will
    // cause a linker error. operator new for this class will never be called.
    VOID *operator new(UINT32) { HardFail(HF_INVPROGRAMEXEC,DEBUG_HPP,__LINE__); return NULL; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,DEBUG_HPP,__LINE__); } 
    clsDebugPort(const clsDebugPort&); // Safeguard against default copy constr
    clsDebugPort& operator=(const clsDebugPort&); // and defualt assignement.

public:
    clsDebugPort(VOID);
    ~clsDebugPort(VOID) { HardFail(HF_INVPROGRAMEXEC,DEBUG_HPP,__LINE__); }

    static VOID SciOneTxiIsr(VOID);
    static VOID SciOneTriIsr(VOID);

    RETURNSTATUS PrintString(const CHAR *,...);
    RETURNSTATUS GetInput(CHAR *,UINT8);

    inline VOID CancelInput(VOID) { ucOutputIndex = 0; }
};
/*******************************************************************************
*                                    GLOBALS                                   *
*******************************************************************************/
extern BOOL   g_bStopDiagTask;
extern UINT16 g_usDiagCount;
extern UINT16 g_usWdtTestTimer[2];
extern BOOL   g_bWdtTestInProgress; // WDT refresh disable - to test WDT
extern UINT8  g_ucCpuFreeTestIndex;
extern UINT32 g_ulCpuFreeTestCounts[CPUFREE_TESTCOUNT];

#if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    extern BOOL g_bStopRefresh; 
    extern UINT16 g_usMaxLpbkCount;
    extern UINT16 g_usMinLpbkCount;
#endif

#if (defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
    extern BOOL g_bStopDiTests;
#endif

#if defined(IOMTYPE_LLMUX)
    extern BOOL   g_bStopFtaScan;
#endif

#endif
