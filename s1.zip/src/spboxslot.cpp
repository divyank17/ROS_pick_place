/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spboxslot.cpp                                               *
*    Description : Class clsSpBoxSlot definition.                              *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "spmain.h"

/*******************************************************************************
*                                 GLOGBAL  DATA                                *
*******************************************************************************/
clsSpAdc SpAdc;
clsTimer TimerObj; //Timer object for statemachine implementation.
MODSTAT1_DSC ModStat1_Dsc;

/*******************************************************************************
*                               EXTERNAL FUNCTIONS                             *
*******************************************************************************/
extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern VOID VerifySwitchState (SWITCH_TYPE,UINT8);

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsIol Iol;

extern SHRAMDATA ShramData;
extern clsIoLinkFifo AppScsFifo;
extern clsIoLinkFifo IolinkScsFifo;

extern UINT16 *uHandeShakeState;
extern BOOL bSwitchDiagRunning;

/*******************************************************************************
*                                 CONTANTS                                     *
*******************************************************************************/
#define CNT_2P5MS_IN_5MS   2

#define SHIFT_7_NIBBLE  28
#define SHIFT_6_NIBBLE  24
#define SHIFT_5_NIBBLE  20
#define SHIFT_4_NIBBLE  16
#define SHIFT_3_NIBBLE  12
#define SHIFT_2_NIBBLE  8
#define SHIFT_1_NIBBLE  4

#define MASK_8_NIBBLE   0xF0000000
#define MASK_7_NIBBLE   0xF000000
#define MASK_6_NIBBLE   0xF00000
#define MASK_5_NIBBLE   0xF0000
#define MASK_4_NIBBLE   0xF000
#define MASK_3_NIBBLE   0xF00
#define MASK_2_NIBBLE   0xF0
#define MASK_1_NIBBLE   0xF

#define RESET_1_NIBBLE  0xFFFFFFF0
#define RESET_2_NIBBLE  0xFFFFFF0F
#define RESET_3_NIBBLE  0xFFFFF0FF
#define RESET_4_NIBBLE  0xFFFF0FFF
#define RESET_5_NIBBLE  0xFFF0FFFF
#define RESET_6_NIBBLE  0xFF0FFFFF
#define RESET_7_NIBBLE  0xF0FFFFFF
#define RESET_8_NIBBLE  0x0FFFFFFF

#define SHIFT_2_BYTES   16
#define SHIFT_1_BYTE    8

#define CKVT1_INDEX     10
#define CKVT2_INDEX     11
#define CKVT3_INDEX     12

const UINT8 SP_AI_IN_CALIB  = 9;

const SOFTFAILTYPE clsBoxSlot::SlotSfMap[BYTESIZE] = {
    SF_DIAGCTFL,
    SF_SP_ROC_FAIL,
    SF_OPENWIRE,
    SF_INPTFAIL,
    SF_OUTPUTFL,
    SF_NO_PULSE_DETECT,
    SF_UNKNOWN
};

const UINT8 clsSpBoxSlot::RedParams[] = {
    kSiomPnDBVALID,
    kSiomPnIOLDevTy,
    kSiomPnModlType,
    kSiomSpPnRevRotChnlA,
    kSiomSpPnRevRotChnlB,
    0 // Terminator
};

const UINT8 clsSpAdc::aInputSelect[] = { 
    0x93,   // REF0
    0x00,   // CHAN01
    0x02,   // CHAN02
    0x00,   // CHAN03
    0x02,   // CHAN04
    0x03,   // CHAN05
    0x00,   // CHAN06
    0x02,   // CHAN07
    0x03,   // CHAN08
    0x03,   // VCAL
    0x01,   // CKVT1
    0x01,   // CKVT2
    0x01,   // CKVT3
};

const UINT8 clsSpAdc::MuxSelEnable[] = { 
    0x00,    // REF0  //Get the info from HW team what should be this value
    0x01,   // CHAN01
    0x01,   // CHAN02
    0x02,   // CHAN03
    0x02,   // CHAN04
    0x02,   // CHAN05
    0x04,   // CHAN06
    0x04,   // CHAN07
    0x04,   // CHAN08
    0x01,   // VCAL
    0x01,   // CKVT1
    0x02,   // CKVT2
    0x04    // CKVT3
};

const BOXPARAMINFO clsSpBoxSlot::tblParamInfo[] = { // Build paraminfo table
    //DataType,Size,AccessType,AccessLock,PrePtr,PostPtr,ParamPtr,IsDbChecksumed,IsRedChecksumed
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 02
    DT_BLIND,3,AT_PSET,ALCK_VIEW,0,0,GetModStatTypePtr,FALSE,                       // 03  ModStatType
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 34
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetSlotSfBitsPtr,FALSE,                      // 35 SlotSfBits
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 36
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetMapSlotInFailPtr,FALSE,                   // 37 MapSlotInFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrAPtr,FALSE,                          // 38 ChnErrA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnErrBPtr,FALSE,                          // 39 ChnErrB
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilAPtr,FALSE,                          // 40 ChnSilA
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetChnSilBPtr,FALSE,                          // 41 ChnSilB
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 42
    DT_BLIND,16,AT_MBYTE,ALCK_VIEW,0,0,GetHwInfoPtr,FALSE,                          // 43 HwInfo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootBuildNoPtr,FALSE,                      // 44 BootBuildNo
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBootSwRevCodePtr,FALSE,                    // 45 BootSwRevCode
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 46
    DT_BLIND,14,AT_PSET,ALCK_VIEW,0,0,GetSup300Ptr,FALSE,                           // 47 Sup300
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppBuildNoPtr,FALSE,                       // 48 AppBuildNo
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 50
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfBitsPtr,FALSE,                       // 51 BoxSfBits
    DT_BLIND,32,AT_MBYTE,ALCK_VIEW,0,0,GetBoxSfLrsPtr,FALSE,                        // 52 BoxSfLrs
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCircListStPtr,FALSE,                       // 53 CircListSt
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommErrPtr,FALSE,                          // 54 CommErr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetCommStatPtr,FALSE,                         // 55 CommStat
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDpaPtr,FALSE,                              // 56 Dpa
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetDsaPtr,FALSE,                              // 57 Dsa
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntAppPtrPtr,FALSE,                      // 58 EvntAppPtr
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,0,0,GetEvntRemPtrPtr,FALSE,                      // 59 EvntRemPtr
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetBaPtr,FALSE,                               // 60 Ba
    DT_BLIND,4,AT_MBYTE,ALCK_IUSER,PreSyncVer,0,GetSyncVerPtr,FALSE,                // 61 SyncVer
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetFailCodePtr,FALSE,                         // 62 FailCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetHwRevCodePtr,FALSE,                        // 63 HwRevCode
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetIolDevTypePtr,FALSE,                       // 64 IolDevType
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastFailPtr,FALSE,                          // 65 LastFail
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMesNoPtr,FALSE,                            // 66 MesNo
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetModStat1Ptr,TRUE,                         // 67 ModStat1
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetModStat2Ptr,FALSE,                         // 68 ModStat2
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetModlTypePtr,FALSE,                          // 69 ModlType
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetNthPtr,FALSE,                              // 70 Nth
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetSuprCtrlPtr,FALSE,                         // 71 SuprCtrl
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetAppSwRevCodePtr,FALSE,                     // 72 SwRevCode
    DT_UINT16,2,AT_MBYTE,ALCK_IUSER,0,0,GetToknStllPtr,FALSE,                       // 73 ToknStll
    DT_BLIND,4,AT_MBYTE,ALCK_VIEW,0,0,GetTstFunctTimePtr,FALSE,                     // 74 TstFunctTime
    DT_BLIND,80,AT_PSET,ALCK_VIEW,0,0,GetSfInfo300Ptr,FALSE,                        // 75 SfInfo300
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetWithBiasPtr,FALSE,                          // 76 WithBias
    DT_BLIND,2,AT_MBYTE,ALCK_IUSER,PreRedData,PostRedData,GetRedDataPtr,FALSE,      // 77 RedData
    DT_BOOL,1,AT_SBYTE,ALCK_IUSER,0,0,GetDbValidPtr,TRUE,                           // 78 DbValid
    DT_BLIND,32,AT_MBYTE,ALCK_IUSER,0,PostSfActionTbl,GetSfActionTblPtr,FALSE,      // 79 SfActionTbl
    DT_BOOL,1,AT_SBYTE,ALCK_EPB,0,0,GetCalibAllPtr,FALSE,                           // 80 CalibAll
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 81
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 82
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 83
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 84
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 85
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 86
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 87
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 88
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 89
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 90
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 91
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 92
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 93
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 94
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 95
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 96
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 97
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 98
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 99
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 100
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 101
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 102
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 103
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 104
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 105
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 106
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 107
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 108
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 109
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 110
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 111
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 112
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 113
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 114
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 115
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,0,0,GetMaxSlotsPtr,FALSE,                         // 116 MaxSlots
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 117
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 118
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 119
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 120
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 121
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 132
    DT_INT32,4,AT_MBYTE,ALCK_IUSER,0,0,GetSpTestParamPtr,FALSE,                     // 133 TESTPARAM[32]
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 134
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 135
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 136
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 141
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 142
    DT_BLIND,6,AT_PSET,ALCK_VIEW,0,0,GetCheckPointPtr,FALSE,                        // 143 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 157
    DT_BLIND,54,AT_MBYTE,ALCK_VIEW,0,0,GetCheckSumPtr,FALSE,                        // 158 CheckSum
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeAvgPtr,FALSE,                     // 159 CPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetCpuFreeMinPtr,FALSE,                     // 160 CPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostStatReset,GetStatResetPtr,FALSE,  // 161 StatReset
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 164
    DT_BLIND,100,AT_MBYTE,ALCK_VIEW,0,0,GetTracelogPtr,FALSE,                       // 165 TraceLog
    DT_BLIND,5,AT_MBYTE,ALCK_VIEW,0,0,GetTraceLogInfoPtr,FALSE,                     // 166 TraceLogInfo
    DT_UINT16,2,AT_MBYTE,ALCK_OPER,0,0,GetTracelevelPtr,FALSE,                      // 167 Tracelevel
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 168 
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 169
    DT_UINT8,1,AT_SBYTE,ALCK_OPER,PreCPLDRegData,PostCPLDRegData,GetCPLDRegDataPtr,FALSE,// 170 CPLDRegData
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 177
    DT_BLIND,77,AT_MBYTE,ALCK_VIEW,0,0,GetSpInputScanRecPtr,FALSE,                  // 178 SpInputScanRec
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetIolProcCpuFreeAvgPtr,FALSE,              // 179 IolProcCPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetIolProcCpuFreeMaxPtr,FALSE,              // 180 IolProcCPUFreeMax
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetIolProcCpuFreeMinPtr,FALSE,              // 181 IolProcCPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,PreStatReset,PostIolProcStatReset,GetIolProcStatResetPtr,FALSE,  // 182 IolProcStatReset
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetAppProcCpuFreeAvgPtr,FALSE,              // 183 AppProcCPUFreeAvg
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetAppProcCpuFreeMaxPtr,FALSE,              // 184 AppProcCPUFreeMax
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetAppProcCpuFreeMinPtr,FALSE,              // 185 AppProcCPUFreeMin
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,0,0,GetAppProcStatResetPtr,FALSE,                  // 186 AppProcStatReset
    DT_BLIND,25,AT_MBYTE,ALCK_VIEW,0,0,GetSpOutPutScanRecPtr,FALSE,                 // 187 SpOutPutScanRec
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,0,0,GetRevRotChnlAPtr,TRUE,                         // 188 RevRotChnlA
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,0,0,GetRevRotChnlBPtr,TRUE,                         // 189 RevRotChnlB
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,PreCalibOpt,PostCalibOpt,GetCalibOptPtr,FALSE,     // 190 CalibOpt
    DT_BOOL,1,AT_SBYTE,ALCK_OPER,0,0,GetResetTripPtr,TRUE,                          // 191 ResetTrip
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,0,0,GetLastTripReasonPtr,FALSE,                    // 192 LastTripReason
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,0,0,GetLastTripTimePtr,FALSE,                   // 193 LastTripTime 
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetRevRotFlPtr,FALSE,                          // 194 RevRotFl
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 240
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetCtlTogPtr,FALSE,                            // 241 CtlTog
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,0,0,GetComTogPtr,FALSE,                            // 242 ComTog
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,0,0,GetBoxChkpntVersionPtr,TRUE,                 // 243 BoxChekpointVerNum
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE,                                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,0,0,0,FALSE                                         // 255
};

/*******************************************************************************
*                          clsSpBoxSlot::clsSpBoxSlot                          *
*                          ==========================                          *
* PURPOSE   : Constructor of clsSpBoxSlot Class. which initializes  class      *
*             members.                                                         *
* ARGUMENTS : a_MdType - Module Type                                           *
* RETURN    : NONE                                                             *
* NOTES:    :                                                                  *
*******************************************************************************/
clsSpBoxSlot::clsSpBoxSlot(MODLTYPE a_MdType) : clsBoxSlot(a_MdType,MAXSLOTS)
{    
    // Initialize data members.
    PpxChannel            = 1;//Start with channel 1.
    CalibOpt              = CALIBOPT_NONE;
    IolProcCpuFreeAvg     = 0.0;
    IolProcCpuFreeMax     = 0.0;
    IolProcCpuFreeMin     = 100.0;
    IolProcStatReset      = OFF;
    AppProcCpuFreeAvg     = 0.0;
    AppProcCpuFreeMax     = 0.0;
    AppProcCpuFreeMin     = 100.0;
    AppProcStatReset      = OFF;
    ResetTrip             = FALSE;
    CalibAll              = FALSE;
    AICalibrationGood     = FALSE;
    AOCalibrationGood     = FALSE;
    OWD_ENB               = 0; // Disable open wire detection circuitry at startup
    pSpShramBoxData       = &ShramData.ShramSlotData.SpShramBoxData;
    PartnerSlotInFail[0]  = 0;
    PartnerSlotInFail[1]  = 0;
    bDisOpInternlUpdte    = FALSE;
    uDeAssertSkipCycles   = 0;
    ucWdtRefreshCounter   = 0;
    uiWdtDiagCounter      = 0;
    WdtDiagState          = WDTDIAG_RESET;
    UINT16 uFPGARev       = FPGA_REV;
    HwInfo.Pld2RevLetter  = ((uFPGARev & 0xFF00) >> 8) & HWINFO_REVLETTER_MASK;
    HwInfo.Pld2RevNumber  = uFPGARev & 0x00FF;
    HwInfo.ProductCode    = PRODCODE_SP;
    HwInfo.ProductType    = PRODTYPE_SP;
    bDisableFO            = FALSE;
    bIsBackUpStatusStable = FALSE;
    ucDscSfChanNum        = DI_CH_START;
    CntBupreq             = BUPREQ_400MS_DELAY;//BUPREQ stability delay to set 400, stability is checked only once the DB gets valid
    ChanProcEvent         = EVENT_NONE;
    uiRefInput            = 0;
    uiCkvtFailCnt         = 0;
    //

    // NOTE- TBD update the Time Values Accordingly
    // Setup TPU0 as SharedRam read
    TPU0_TCR    = 0x23; // Divide/64 clock, rising edge, clear TCNT on TGRA match.
    TPU0_TMDR   = 0xC0; // TPU0 normal mode operation
    TPU0_TIER   = 0x01; // TGIEA interrupt enabled with TGRA match
    TPU0_TGRA   = TPU0_MAXCOUNT; // interrupt every (10/8) = 1.125 msec. 
    IPRI_IOPROC = LVLPRI_IOPROC; // Set PPX interrupt priority level
    //

    // Init Timers for Free Running timer.
    TPU2_CST    = 0;    // make sure the counter is stopped
    TPU2_TCR    = 0x02; // Divide/16 clock, rising edge, 
    TPU2_TMDR   = 0xC0; // TPU2 normal mode operation
    TPU2_CST    = 1;    // Start the Free Running Counter 
    //

    //Initialize InputScan Records
    for(UINT8 ucSlot = 0;ucSlot < AI_MAXSLOTS; ucSlot++ )
    {
        SpInputScanRec.AiPv[ucSlot] = NaN;
        SetPvSts((ucSlot + AI_CH_START),(UINT16)PVVALST_BAD);
    }
    for(UINT8 ucSlot = 0;ucSlot < SP_MAXSLOTS; ucSlot++ )
    {
        SpInputScanRec.SpdPv[ucSlot] = NaN;
        SetSpPvSts((ucSlot + SP_CH_START),(UINT16)PVVALST_BAD);
    }
    SpInputScanRec.VotPv1  = NaN;
    SpInputScanRec.VotPv2  = NaN;
    SpInputScanRec.VotRoc1 = NaN;
    SpInputScanRec.VotRoc2 = NaN;
    SpInputScanRec.VotPvSts  =  (((UINT8)PVVALST_BAD << 4) | PVVALST_BAD);
    SpInputScanRec.VotRocSts =  (((UINT8)PVVALST_BAD << 4) | PVVALST_BAD);
    SpInputScanRec.DiPv.Byte     = (UINT8) 0;
    SpInputScanRec.BadPvFl.Byte  = (UINT8) 0;
    SpInputScanRec.ZeroPvFl.Byte = (UINT8) 0;
    SpInputScanRec.RevRotFlLastTripTimeInfo.Byte = (UINT8) 0;
    //

    //Initialize Output Scan Records
    SpOutPutScanRec.AoOp         = OP_LOLIMIT;
    SpOutPutScanRec.InitReq      = 0;
    for(UINT8 ucSlot = 0;ucSlot < DO_MAXSLOTS; ucSlot++ )
    {
        SpOutPutScanRec.DoOp[ucSlot] = 0;
    }
    SpOutPutScanRec.DoInitReq = 0;
    SpOutPutScanRec.DoSo = 0;
    SpOutPutScanRec.StdbyManLocalMan = 0;
    //

    // AI calibration data default initialization
    CalibData.f5VRefHiLimit = CALIBRATION_5VREF_HILIMIT;
    CalibData.f5VRefLoLimit = CALIBRATION_5VREF_LOLIMIT;
    CalibData.AICalibrationSlope  = CALIBRATION_SLOPE;
    CalibData.AICalibrationOffset = CALIBRATION_OFFSET;
    //

    // These Values Calculated with Factory Calib and Hardcoded here (In PASS 1)
    CalibData.AOFactorySlope         = 0.041511; 
    CalibData.AOFactoryOffset        = -29.47281; 
    //

    //Initialize Redundancy Switches
    SetOutCtl(OUTCTL_PARTNER);
    INH_SWA = 0;
    INH_SWB = 0;
    TST_n = 0;    
    DO_PWR_ENABLE = TRUE;
    DO_OUT_ENABLE = TRUE;
    //

    //Initialize CPLD interrupt settings on IRQ1.
    IPRI_PDVC     = LVLPRI_TICK;   // Set CPLD interrupt priority level
    //

    //Initialize CPLD interrupt settings on IRQ4.
    IPRI_POWERFAIL = LVLPRI_PDVC;
    IRQ4_SENSECTL  = IRQ_SC_RISING;
    IRQ4_STATUS    = DISABLE;         // Clear the IRQ4 status flag
    IRQ4_ENABLE    = ENABLE;          // Enable IRQ4 (CPLD interrupt).
    //

    //Initializing the EEPROM Write Count - Temporary Code
    UINT16 ModuleWriteCount = Eeprom.ReadUint16(0, SP_EE_MODULEINFO_WRITECOUNT);
    if(ModuleWriteCount >= EEPROM_MAXWRCOUNT ) 
    {
        ModuleWriteCount = 1;

        //Enable the writes EEPROM 
        Eeprom.EnableWrite();
        //IdleWait(10000);
        
        Eeprom.WriteByte(0,SP_EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
        //IdleWait(20000);
        
        //Enable the writes EEPROM 
        Eeprom.EnableWrite();
        //IdleWait(10000);

        Eeprom.WriteByte(0,SP_EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
        //IdleWait(20000);
        
        //Disable the write EEPROM 
        Eeprom.DisableWrite();
    }
    //

    //Start the statemachine by starting the timer
    AiChannelsProcStartTime = 0;        
    SetChanProcState ( STATE_IDLE );
    //

#ifdef DEBUG
    m_ulMaxPpxTime  = 0;
    m_ulAvgPpxTime  = 0;
    m_ulMinPpxTime  = MAXUINT32;
#endif
}

/*******************************************************************************
*                          clsSpBoxSlot::GetDataType                           *
*                          =========================                           *
* PURPOSE  : This function returns data type of the parameter.                 *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : DataType of the parameter                                         *
* NOTES    :                                                                   *
*******************************************************************************/
DATATYPE clsSpBoxSlot::GetDataType(UINT8 a_ucParamNumber) 
{
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsSpBoxSlot::GetAccessType                         *
*                          =========================                           *
* PURPOSE  : This function returns accesstype of the parameter.                *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : AccessType of the parameter.                                      *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSTYPE clsSpBoxSlot::GetAccessType(UINT8 a_ucParamNumber) 
{
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                          clsSpBoxSlot::GetParamSize                          *
*                          ==========================                          *
* PURPOSE  : This function returns size of the parameter                       *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Data size of the parameter                                        *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsSpBoxSlot::GetParamSize(UINT8 a_ucParamNumber) 
{
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsSpBoxSlot::GetParamPtr                         *
*                            =========================                         *
* PURPOSE   : This function returns the pointer to the parameter               *
* ARGUMENTS : a_ucParamNumber - Parameter code                                 *
* RETURN    : UINT8 * - pointer to parameter                                   *
* NOTES     :                                                                  *
*******************************************************************************/
UINT8 *clsSpBoxSlot::GetParamPtr(UINT8 a_ucParamNumber) 
{
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                           clsSpBoxSlot::GetAccessLock                        *
*                           ===========================                        *
* PURPOSE  : This function returns Access Lock of the parameter.               *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : Access Lock of the parameter number.                              *
* NOTES    :                                                                   *
*******************************************************************************/
ACCESSLOCK clsSpBoxSlot::GetAccessLock(UINT8 a_ucParamNumber) 
{
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                    clsSpBoxSlot::GetIsDbChecksumed                           *
*                    ===============================                           *
* PURPOSE  : This function returns whether parameter.is checkpointed or not    *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : BOOL - TRUE if parameter is checkpoint paramter, else FALSE       *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) 
{
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsSpBoxSlot::VerifyControlState                     *
*                         ================================                     *
* PURPOSE  : This function checks the contorl state assigned to the parameter  *
*            to actual present control state of the channel and IOM module     *
*            itself,before the actual write to the parameter.                  *
* ARGUMENTS: a_ucParamNumber - Parameter code                                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    : This function decides whether the write can be done or not to the *
*            paramerter under current channel or IOM state.                    *
*******************************************************************************/
PASTATUS clsSpBoxSlot::VerifyControlState(UINT8) 
{
    return PA_OK;
}

/*******************************************************************************
*                         clsSpBoxSlot::ExecutePreFunction                     *
*                         ================================                     *
* PURPOSE  : This function invokes the pre-function for the given writable     *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber  - Parameter Number                               *
*            a_Buffer         - Pointer to the data                            *
*            a_ucAccessLevel  - Access level of the parameter                  *
* RETURN   : PASTATUS    - Success (PA_OK) or Warning status code.             *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsSpBoxSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                         UINT8 *a_Buffer,
                                         UINT8 a_ucAccessLevel) 
{
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) 
    {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsSpBoxSlot::ExecutePostFunction                    *
*                         =================================                    *
* PURPOSE  : This function invokes the post-function for the given writable    *
*            parameter.                                                        *
* ARGUMENTS: a_ucParamNumber - Parameter Number                                *
*            a_ucAccessLevel - Access level of the parameter                   *
* RETURN   : NONE                                                              *                                                                     
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                        UINT8 a_ucAccessLevel) 
{
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) 
    {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
    return;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetModStat1Ptr                         *
*                         ============================                         *
* PURPOSE  : This function returns ModStat1 Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetModStat1Ptr(VOID)
{
    ModStat1.Status  = (UINT8)(pSpShramBoxData->ModStat1 & 0x03);
    ModStat1.Factory = (UINT8)((pSpShramBoxData->ModStat1 & 0x04)>>2); 
    ModStat1.Unused  = (UINT8)((pSpShramBoxData->ModStat1 & 0x78)>>3);
    ModStat1.BuSyncd = (UINT8)((pSpShramBoxData->ModStat1 & 0x80)>>7);

    return &ModStat1;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetModStat2Ptr                         *
*                         ============================                         *
* PURPOSE  : This function returns ModStat2 Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetModStat2Ptr(VOID)
{
    return &ModStat2;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetModStat3Ptr                         *
*                         ============================                         *
* PURPOSE  : This function returns ModStat3 Parameter Vaalue                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8  clsSpBoxSlot::GetModStat3State(VOID)
{
    return ((UINT8)pSpShramBoxData->ModStat3);
}

/*******************************************************************************
*                         clsSpBoxSlot::GetDbValidPtr                          *
*                         ===========================                          *
* PURPOSE  : This function returns DbValid Parameter Pointer                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetDbValidPtr(VOID)
{
    DbValid = (BOOL)pSpShramBoxData->DbValid; 
    
    return &DbValid;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetRevRotChnlAPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns RevRotChnlA Parameter Pointer               *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetRevRotChnlAPtr(VOID)
{
    RevRotChnlA = (REVROTCHNL)pSpShramBoxData->RevRotChnlA;  
    return &RevRotChnlA;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetRevRotChnlBPtr                      *
*                         ===============================                      *
* PURPOSE  : This function returns RevRotChnlB Parameter Pointer               *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetRevRotChnlBPtr(VOID)
{
    RevRotChnlB = (REVROTCHNL)pSpShramBoxData->RevRotChnlB;  
    return &RevRotChnlB;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetRevRotFlPtr                         *
*                         ============================                         *
* PURPOSE  : This function returns RevRotFl Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetRevRotFlPtr(VOID)      
{
    RevRotFl = (BOOL)pSpShramBoxData->RevRotFl;

    return &RevRotFl;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetModuleStatus                        *
*                         ===============================                      *
* PURPOSE  : This function returns ModuleStatus Parameter Value                *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsSpBoxSlot::GetModuleStatus(VOID)
{
    ModStat1.Status  = (UINT8)pSpShramBoxData->ModStat1 & 0x03;
    ModStat1.Factory = (UINT8)((pSpShramBoxData->ModStat1 & 0x04)>>2); 
    ModStat1.Unused  = (UINT8)((pSpShramBoxData->ModStat1 & 0x78)>>3);
    ModStat1.BuSyncd = (UINT8)((pSpShramBoxData->ModStat1 & 0x80)>>7);

    return ModStat1.Status;
}

/*******************************************************************************
*                         clsSpBoxSlot::SetModuleStatus                        *
*                         =============================                        *
* PURPOSE  : This function Sets ModuleStatus Value                             *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetModuleStatus(VOID)
{
    ModStat1.Status  = (UINT8)pSpShramBoxData->ModStat1 & 0x03;
    ModStat1.Factory = (UINT8)((pSpShramBoxData->ModStat1 & 0x04)>>2); 
    ModStat1.Unused  = (UINT8)((pSpShramBoxData->ModStat1 & 0x78)>>3);
    ModStat1.BuSyncd = (UINT8)((pSpShramBoxData->ModStat1 & 0x80)>>7);
}

/*******************************************************************************
*                         clsSpBoxSlot::GetCalibAllPtr                         *
*                         ============================                         *
* PURPOSE  : This function returns CalibAll Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetCalibAllPtr(VOID)
{
    CalibAll = (BOOL)pSpShramBoxData->CalibAll;

    return &CalibAll;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetCalibAllState                       *
*                         ==============================                       *
* PURPOSE  : This function returns CalibAll Parameter Value                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::GetCalibAllState(VOID)
{
    CalibAll = (BOOL)pSpShramBoxData->CalibAll;

    return CalibAll;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetResetTripPtr                        *
*                         =============================                        *
* PURPOSE  : This function returns ResetTrip Parameter Pointer                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetResetTripPtr(VOID)
{ 
    ResetTrip = (BOOL) pSpShramBoxData->ResetTrip;  
    return &ResetTrip;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetCalibOptPtr                         *
*                         ============================                         *
* PURPOSE  : This function returns CalibOpt Parameter Pointer                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : VOID* - Parameter Pointer                                         *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetCalibOptPtr(VOID)
{ 
    return &CalibOpt;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetLastTripReasonPtr                   *
*                         ==================================                   *
* PURPOSE  : This function returns LastTripReason Parameter Value              *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetLastTripReasonPtr(VOID)  
{ 
    LastTripReason   = (LASTTRIPREASON)pSpShramBoxData->LastTripReason;

    return &LastTripReason; 
}

/*******************************************************************************
*                         clsSpBoxSlot::GetLastTripTimePtr                     *
*                         ================================                     *
* PURPOSE  : This function returns LastTripTime Parameter Value                *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetLastTripTimePtr(VOID)  
{ 
    LastTripTime   = (FLOAT32)pSpShramBoxData->LastTripTime;

    return &LastTripTime; 
}

/*******************************************************************************
*                         clsSpBoxSlot::GetAppProcCpuFreeAvgPtr                *
*                         =====================================                *
* PURPOSE  : This function returns AppProcCpuFreeAvg Parameter Value           *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetAppProcCpuFreeAvgPtr(VOID) 
{ 
    AppProcCpuFreeAvg = (FLOAT32)pSpShramBoxData->AppProcCpuFreeAvg;
    
    return &AppProcCpuFreeAvg;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetAppProcCpuFreeMaxPtr                *
*                         =====================================                *
* PURPOSE  : This function returns AppProcCpuFreeMax Parameter Value           *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetAppProcCpuFreeMaxPtr(VOID) 
{ 
    AppProcCpuFreeMax = (FLOAT32)pSpShramBoxData->AppProcCpuFreeMax;

    return &AppProcCpuFreeMax; 
}

/*******************************************************************************
*                         clsSpBoxSlot::GetAppProcCpuFreeMinPtr                *
*                         =====================================                *
* PURPOSE  : This function returns AppProcCpuFreeMin Parameter Value           *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetAppProcCpuFreeMinPtr(VOID) 
{ 
    AppProcCpuFreeMin = (FLOAT32)pSpShramBoxData->AppProcCpuFreeMin;
    
    return &AppProcCpuFreeMin;
}

/*******************************************************************************
*                         clsSpBoxSlot::GetCheckSumPtr                         *
*                         ============================                         *
* PURPOSE  : This function returns CheckSum Parameter Value                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
VOID *clsSpBoxSlot::GetCheckSumPtr(VOID)
{
    return &CheckSum;
}

/*******************************************************************************
*                         clsSpBoxSlot::SetTstTimeFromShram                    *
*                         =================================                    *
* PURPOSE  : This function sets TstTime Parameter Value                        *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Parameter Value                                           *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetTstTimeFromShram(VOID)
{
    INT32 Temp_cnt = (INT32)pSpShramBoxData->TstFunctTime;
    SetTstFunctTime(Temp_cnt);
}

/*******************************************************************************
*                           clsBoxSlot::PostRedData                            *
*                           =======================                            *
* PURPOSE  : Post Receiver-Beware function for RedData parameter               *
* ARGUMENTS: a_ucAccLvl - Access level for check                               *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::PostRedData(UINT8) 
{
    switch (Data.ucBytes[2]) 
    {
        case 0:         // If the new RedData is zero then RedState was changed
            PostRedState();                     // Process it
            break;
        case RDBIT_CLR + REDDATA_BURQST_BITNUM:// If RedData.BuRqst was cleared
            SWBUREQ_n = 1;                      // Deassert Backup Request line
            break;
        case RDBIT_SET + REDDATA_BURQST_BITNUM:    // If RedData.BuRqst was set
            SWBUREQ_n = 0;                        // Assert Backup Request line
            break;
        case RDBIT_CLR + REDDATA_REDCFG_BITNUM:// If RedData.RedCfg was cleared
            SetRedState(REDSTATE_NOT_SYNCD);
            break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x901,Data.ucBytes[2]);
            break;
    }

    //Update the new RedState to Shared Ram
    pSpShramBoxData->RedSyncState = GetRedState();
}

/*******************************************************************************
*                           clsSpBoxSlot::PostIolProcStatReset                 *
*                           ==================================                 *
* PURPOSE  : Post Receiver-Beware function for IolProcStatReset parameter      *
* ARGUMENTS: a_ucAccLvl - Access level for check                               *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::PostIolProcStatReset(UINT8) {

    //Reset the  Statistics calculated for the Module
    //as operator has set the option to reset all stats calculated
    if(IolProcStatReset)
    {       
        //Reset the CpuFreeAvg, CPUFreeMin and CpuFreeMax Parameter
        IolProcCpuFreeAvg = 0.0;  
        IolProcCpuFreeMin = 100.0; //In the beginning the module is approx 100 % free.
        IolProcCpuFreeMax = 0.0;

        //Reset the  ResetStat Flag to start recalculation  
        TaskScheduler.StatReset();

        IolProcStatReset = OFF;//Reset the Value
    } 
}

/*******************************************************************************
*                          clsSpBoxSlot::PreCalibOpt                           *
*                          ===========================                         *
* PURPOSE  : Pre Receiver-Beware function for CalibOpt parameter.              *
*            Validates some pre conditions before the new CalibOpt value can   *
*            be written to database.                                           *
* ARGUMENTS: a_Writebuffer  -   Pointer to the data to be written.             *
*            a_ucAccLvl     -   Access level of the parameter                  *
* RETURN   : PA_OK          -   If check is succesful                          *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS clsSpBoxSlot::PreCalibOpt(UINT8 *a_Writebuffer,UINT8 )
{
    CALIBOPT NewVal = *(CALIBOPT *) a_Writebuffer;   

    // Return config mismatch if Calibration is not enabled.
    if(CalibAll == FALSE)
    {
      return DO_CONFIGURATION_MISMATCH_ERROR;
    }
    
    if((NewVal < CALIBOPT_NONE) || (NewVal > CALIBOPT_SP))
    {
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    }

    //Once calibration option is selected user sould not directly select other option
    //he has to make it as None and should select the other option
    if(CalibOpt != CALIBOPT_NONE)
    {
        return DO_CALIB_IN_PROGRESS;
    }

    return PA_OK;

}

/*******************************************************************************
*                          clsSpBoxSlot::PostCalibOpt                          *
*                          ==========================                          *
* PURPOSE  : Post Receiver-Beware function for CalibOpt parameter              *
* ARGUMENTS: a_ucAccLvl - Access level for check                               *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::PostCalibOpt(UINT8)
{
    TaskScheduler.RunTask(TASKID_CALIBTASK);
}

/*******************************************************************************
*                        clsSpBoxSlot::AppInitialization                       *
*                        ================================                      *
* PURPOSE  : This method loads the calibaration data EEPROM and initailize     *
*            Redudancy Switches                                                *                              
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::AppInitialization(VOID)  
{
    SPLoadCalibrationData();  
    
    TPU0_CST = 1; // Start timer for ppxinterrupthandler

    // Wait until the hardware is settled down;wait time abt 600msec
    for (UINT8 ucCount = 30; ucCount > 0; ucCount--) 
    {
        IdleWait(20000);
    }
    while (!SwitchInit());
} 

/*******************************************************************************
*                         clsSpBoxSlot::SwitchInit                             *
*                         =========================                            *
* PURPOSE  : This method l initailize Redudancy Switches                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : returns TRUE on successfull                                       *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::SwitchInit (VOID) 
{
    //Allow one module to come up earlier than other module
    UINT8 ucDelay = (BOTTOM) ? 20000 : 20;       // compute variable delay (us)

    if (INHIN_NEGATED == INHIN_FB_n)
    {     // partner is not controlling screws
        if (BURIN_ASSERTED == GetPartnersBackupStatus()) {          // partner asserting BUPREQ
            if (INHIN_NEGATED == INHIN_FB_n){// partner still not have screws
                IdleWait(ucDelay);                         // wait for some delay time
                if (INHIN_NEGATED == INHIN_FB_n) { // partnr does not have screws
                    //Shut off the partner outputs from driving the outputs
                    INH_SWA = SW_ON;
                    INH_SWB = SW_ON;
                    IdleWait(ucDelay);   // wait for inhibit switches some delay time
                    if(INHIN_NEGATED == INHIN_FB_n)
                    {
                        SetForPrimary();              // assume role as primary
                        return TRUE;                  // exit finished
                    }
                    else{
                        INH_SWA = SW_OFF;        // relinquish control of screws
                        INH_SWB = SW_OFF;
                        IdleWait(ucDelay);          // wait for some delay time
                        return FALSE;                         // exit unfinished
                    }
                }
                else {                         // partner is controlling screws
                    SetForSecondary(TRUE);      // assume role as backup module
                    return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                               // exit unfinished
            }
        }// partner asserting BUPREQ
        else {
            IdleWait(ucDelay);                      // wait for some delay time
            if (INHIN_NEGATED == INHIN_FB_n) {    // partner does not have screws
                if (BURIN_ASSERTED == GetPartnersBackupStatus()) {  // partner asserting BUPREQ
                    return FALSE;                            // exit unfinished
                }
                else {                       // partner is not asserting BUPREQ
                        SetForPrimary(); 
                        return TRUE;                               // exit finished
                }
            }
            else {                             // partner is controlling screws
                return FALSE;                                // exit unfinished
            }
        }
    }
    else {                                 // partner is controlling the screws
        IdleWait (ucDelay);                         // wait for some delay time
        if (INHIN_NEGATED == INHIN_FB_n) {  // partner does not have screws
            return FALSE;                                    // exit unfinished
        }
        else {                             // partner is controlling the screws
            SetForSecondary(TRUE);              // assume role as backup module
            return TRUE;                                       // exit finished
        }
    }
}

/*******************************************************************************
*                           clsBoxSlot::ManageRedIO                            *
*                           =======================                            *
* PURPOSE  : This function keep track for Redundacny state change and IOL      *
*            address change and takes appropriate action                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::ManageRedIO(VOID) {
    ModStat2.BuReqIn = GetPartnersBackupStatus();

    if(!Iol.AmPrimary() && GetRedState() == REDSTATE_SYNCD) 
    {
        if (ModStat2.BuReqIn && !GetMyBackupStatus()) 
        {
            SetRedState(REDSTATE_FO_COMPLETE);
        }
    }

    switch(Iol.AddressChange()) 
    {
        case ADDCHG_NONE:
            break;
        case ADDCHG_NEW:
            if(Iol.AmPrimary())
            {
                DeAssertBackup();
            }
            SetRedState(REDSTATE_NOT_SYNCD);
            break;
        case ADDCHG_DROPPED:
            if(REDSTATE_IOL_TIMEOUT != GetRedState()) 
            {
                DropSync();
            }
            break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x902,Iol.AddressChange());
            break;
    }
}

/*******************************************************************************
*                     clsSpBoxSlot::CheckFailOverCondition                     *
*                     =====================================                    *
* PURPOSE  : This function change redundancy switches based on the BUPREQ and  *
*            INHIN_FB signals                                                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::CheckFailOverCondition(VOID) {

    BOOL bTstSave = TST_n; // Save state of TST switch

    if (!(BOX->CheckForFactoryTestMode()))
    { 
        TST_n = TSTn_DISABLED;
    }

    if (GetOutCtl() == OUTCTL_PARTNER)             // I do not have ctl of the screws
    {  
        if (BURIN_ASSERTED == BUPREQ_IN)           // my partner has asserted BUPREQ
        {     
            if (INHIN_NEGATED == INHIN_FB_n)       // and partner has given up the screws
            { 
                IdleWait(50);                      //Wait fro 50 us
                if (INHIN_NEGATED == INHIN_FB_n)   // partner still does not have screws
                {
                    if (BUREQ_NEGATED == SWBUREQ_n)// and i have negated BURQ
                    { 
                        SetForPrimary();           // assume role of primary module
                        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x811,0);
                        if (REDSTATE_FO_IN_PROG == GetRedState())
                        {
                            SetRedState(REDSTATE_FO_COMPLETE);
                        }
                    }
                }
            }
        }

        if (Iol.AmPrimary()) {
            if (INHIN_NEGATED == INHIN_FB_n) {    // and it has given up the screws
                IdleWait(50);
                if (INHIN_NEGATED == INHIN_FB_n) {// partner still does not have
                    // If at this point the expected FO sequence did not occur
                    // properly. So save the state of the BUREQ's & REDSTATE
                    // Then take control of the field terminations
                    SetForPrimary();
                    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x812,0);
                    if (REDSTATE_FO_IN_PROG == GetRedState())
                       SetRedState(REDSTATE_FO_COMPLETE);
                }
            }
        }
    }
    else if (!Iol.AmPrimary())                  // I have control of the screws
    {          
        if (BUREQ_ASSERTED == SWBUREQ_n)       // If I am asserting BUPREQ
        {
            if (BURIN_NEGATED == BUPREQ_IN)    // and my partner is not
            {
                SetForSecondary(TRUE);         // assume role of backup module
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x813,0);
            }
        }
    }

    TST_n = bTstSave; // Restore state of TST switch
}

/*******************************************************************************
*                     clsSpBoxSlot::CheckBackUpStatus                          *
*                     ===============================                          *
* PURPOSE  : This functions check the partner is stable for past 400ms         *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::CheckBackUpStatus(VOID)
{
    //BUPREQ stability is checked only once the DB gets valid
    //On the Primary module wait for 400ms for backup request to stabilized on secondary
    //this done to denounce the backup request gitter that happens on the secondary when secondary is
    //powered on. This is done to avoid spurious switchover
    if (BURIN_NEGATED == BUPREQ_IN)// and my partner is not
    {
        if(CntBupreq <= BUPREQ_400MS_DELAY)
        {
            bIsBackUpStatusStable = FALSE;
            CntBupreq++;
        }
    }
    else
    {
        bIsBackUpStatusStable = FALSE;
        CntBupreq = 0;
    }

    //Checks BUPREQ stable for 400ms
    if(CntBupreq >= BUPREQ_400MS_DELAY)
    {
       bIsBackUpStatusStable = TRUE;
    }
}

/*******************************************************************************
*                     clsSpBoxSlot::SetForPrimary                              *
*                     ===========================                              *
* PURPOSE  : This function sets redundancy switches to Primary Role            *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetForPrimary(VOID) 
{
    // set inhibit switches to prevent the other module from driving the outputs
    INH_SWA = SW_ON;
    INH_SWB = SW_ON;

    // set disable switches to allow outputs to be driven
    DIS_SWA_n = SW_ON;
    DIS_SWB_n = SW_ON;

    IdleWait(INH_READ_DELAY_TIME);

    // verify switch states
    VerifySwitchState(DIS_SWCH,DIS_ON_ON);
    VerifySwitchState(INH_SWCH,INH_ON_ON);

    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x809,0);

    SetOutCtl(OUTCTL_MINE);
}

/*******************************************************************************
*                     clsSpBoxSlot::SetForSecondary                            *
*                     =============================                            *
* PURPOSE  : This function sets redundancy switches to Secondary Role          *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetForSecondary(BOOL bDoCheck) 
{
    // set disable switches to allow outputs to be blocked
    DIS_SWA_n = SW_OFF;
    DIS_SWB_n = SW_OFF;

    // set inhibit switches to allow the other module to drive the outputs
    INH_SWA = SW_OFF;
    INH_SWB = SW_OFF;

    if (bDoCheck) 
    { // verify switch states
        IdleWait(INH_READ_DELAY_TIME);
        VerifySwitchState(DIS_SWCH,DIS_OFF_OFF);
        VerifySwitchState(INH_SWCH,INH_OFF_OFF);
    }
 
    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x810,1);

    SetOutCtl(OUTCTL_PARTNER);
}

/*******************************************************************************
*                     clsSpBoxSlot::SetOutCtl                                  *
*                     =======================                                  *
* PURPOSE  : This function set the Module Current  Redundancy Role             *
* ARGUMENTS: uOutCtlState - Module Redundancy Role                             *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetOutCtl(UINT8 uOutCtlState)
{
    pSpShramBoxData->ModStat3 = uOutCtlState;
}

/*******************************************************************************
*                     clsSpBoxSlot::GetOutCtl                                  *
*                     =======================                                  *
* PURPOSE  : This function returns the Module Current Redundancy Role          *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
UINT8 clsSpBoxSlot::GetOutCtl(VOID)
{
    return(pSpShramBoxData->ModStat3);
}

/*******************************************************************************
*                       clsSpBoxSlot::AppColdInit                              *
*                       =========================                              *
* PURPOSE  : Initializes the database of each slots                            *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::AppColdInit(VOID) 
{
    // Send a SCS to Application Processor, to perform AppColdInit operation to initailize the slot database
    IolinkScsFifo.SendSCSCommand(SCS_APP_COLD_INIT);

    //Initialize the Slot database for IOLINK resident slots
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MAX_IOLINK_SLOTS; ucSlotNum++) 
    {
        // Slot checksum is recomputed by InitSlotDatabase.
        SLOT(ucSlotNum)->InitSlotDatabase(TRUE);
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::AppPostSwap                              *
*                       =========================                              *
* PURPOSE  : The function invoked when completion of module swap over          *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::AppPostSwap(VOID) 
{
    //Change the Module switch state to secondary state
    //This change will avoid the switches to be operated twice when the 
    //modules chnages the role.
    SetForSecondary(TRUE);
    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x815,0);
}

/*******************************************************************************
*                       clsSpBoxSlot::AppPostSwap                              *
*                       =========================                              *
* PURPOSE  : The function invoked after the completion of the redundancy dump  *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::AppPostDump(VOID)
{
    //On Secondary send SCS to Application Processor to read the latest configuration
    //from shared ram.
    if(Iol.AmPrimary() == FALSE)
    {
        IolinkScsFifo.SendSCSCommand(SCS_IOL_DUMPCOMPLETE);
    }      

    bDisOpInternlUpdte = TRUE;
}

/*******************************************************************************
*                           clsSpBoxSlot::AppPostSync                          *
*                           ==========================                         *
* PURPOSE  : AppPostSync is called from PostRedState for application specific  *
*            actions after a database dump.                                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/

VOID clsSpBoxSlot::AppPostSync(VOID) {

    if(!Iol.AmPrimary())
    { 
        FLOAT32 fOpval = AO_SLOT(AO_CH_START)->GetOpInternl();
        BOX->SetOp(AO_CH_START,fOpval);
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::GetDumpData                              *
*                       =========================                              *
* PURPOSE  : This method will copy the redundancy dump data to buffer transmit *
*            to the secondary IOM                                              *
* ARGUMENTS: pDump - Dump Pointer                                              *
*            MaxSize - Dump Size                                               *
* RETURN   : PA_OK -   If getdump is succesful                                 *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS  clsSpBoxSlot::GetDumpData(UINT8* pDump, const UINT8 MaxSize)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL && sizeof(strSpBoxSlotDumpData) < MaxSize)
    {
        strSpBoxSlotDumpData *pDumpData = (strSpBoxSlotDumpData*)pDump;

        pDumpData->Version     = PACK2_AS_UI16(SPIOM_SYNC_VER_1,0);
        pDumpData->Tpu5_Pri    = Tpu5_Pri;
        pDumpData->ModStat1    = pSpShramBoxData->ModStat1;
        pDumpData->ModStat2    = pSpShramBoxData->ModStat2;
        pDumpData->RevRotChnlA = pSpShramBoxData->RevRotChnlA;
        pDumpData->RevRotChnlB = pSpShramBoxData->RevRotChnlB;
        pDumpData->MaxSlots    = MaxSlots;
        pDumpData->DbValid     = pSpShramBoxData->DbValid;
        pDumpData->RotationDirData     = pSpShramBoxData->RotationDirData;

        RetVal = PA_OK;
    }

    return RetVal;
}

/*******************************************************************************
*                       clsSpBoxSlot::StoreDumpData                            *
*                       ===========================                            *
* PURPOSE  : This method will copy the redundancy dump data into local dump    *
*            structure in Primary IOM                                          *
* ARGUMENTS: pDump - Dump Pointer                                              *
* RETURN   : PA_OK -   If dump is succesful                                    *
* NOTES    :                                                                   *
*******************************************************************************/
PASTATUS  clsSpBoxSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL)
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SPIOM_SYNC_VER_1)
        {
            strSpBoxSlotDumpData* pDumpData = (strSpBoxSlotDumpData*)(pDump);

            Tpu5_Pri = pDumpData->Tpu5_Pri;            
            pSpShramBoxData->ModStat1 = pDumpData->ModStat1 ;                       
            pSpShramBoxData->RevRotChnlA = pDumpData->RevRotChnlA;
            pSpShramBoxData->RevRotChnlB = pDumpData->RevRotChnlB;
            MaxSlots = pDumpData->MaxSlots;
            pSpShramBoxData->DbValid = pDumpData->DbValid;
            pSpShramBoxData->RotationDirData = pDumpData->RotationDirData;            
        
            RetVal = PA_OK;
        }
    }
    return RetVal;
}

/*******************************************************************************
*                          clsBoxSlot::BoxHouseKeeping                         *
*                          ===========================                         *
* PURPOSE  : This method re-reports any missed events                          *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::BoxHouseKeeping(VOID) {
    // Save current interrupt masks and set current masks
    // so that STC or point processing cannot come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK); 

    UINT8 ucCount,ucIndex = 0,ucCompositeByte = 0,ucMask = SLOTINFAIL_MASKINIT; 
    UINT8 ucByteOffset,ucBitOffset;

    UINT8 ucSfActByteOffset,ucSfActBitOffset=0x01;
    UINT8 SfCount = 0;

    // Update MapSlotInFail parameter
    for (ucCount = 1; ucCount <= MaxSlots; ucCount++) 
    {
        if ((ucByteOffset = SLOT(ucCount)->GetSlotSfBt()) > 0)
        {
            ucCompositeByte |= ucByteOffset;
            MapSlotInFail[ucIndex] |= ucMask;
        }
        else 
        {
            MapSlotInFail[ucIndex] &= ~ucMask;
        }
        ucMask >>= 1;
        if (0 == ucMask) 
        {
            ucMask = SLOTINFAIL_MASKINIT;
            ucIndex++;
        }

        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr); 
        set_imask_exr(LVLPRI_TICK); 
    }

    // Update  SlotSfBits from individual SlotSfBt.
    for (UINT8 ucChan = 1; ucChan <= MaxSlots; ucChan++)
    {
        UINT8 SltSfByte = SLOT(ucChan)->GetSlotSfBt();
        
        //Call AddSoftFailEvent again here to assert/Deassert back-up request
        UINT8 Mask=0x1;
        
        for (ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
        {         
            ucSfActBitOffset=0x01;
    
            UINT8 a_SoftfailType = SlotSfMap[ucCount];
            ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
            ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);
            
            if(SltSfByte & Mask)
            {
                BOOL bIsEntryInActionTbl = SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset;
            
                if(a_SoftfailType == SF_OUTPUTFL)
                {
                    if(bDisableFO)
                    {
                        bIsEntryInActionTbl = FALSE;
                    }
                    else
                    {
                        bIsEntryInActionTbl = TRUE;
                    }
                }

                if(bIsEntryInActionTbl) 
                {
                    SfCount++;
                }
            }
        }
    }

    // Update SlotSfBits from individual SlotSfBt.
    ucMask = 0x01;
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++) 
    {
        if (SF_UNKNOWN != SlotSfMap[ucCount]) 
        {
            ucByteOffset = SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;
            if (ucCompositeByte & ucMask) 
            {
                SlotSfBits[ucByteOffset] |= ucBoxSfMask;
            }
            else 
            {
                SlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
            }
        }
        ucMask <<= 1;

        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr); 
        set_imask_exr(LVLPRI_TICK);
    }

    WriteTestParamUint32(29,SfCount);

    if((0 == SfCount) && (uDeAssertSkipCycles == 0))
    {
        if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) 
        {
            if ((GetCalibAllState() != TRUE) && (!BOX->CheckForFactoryTestMode()))
            {
                DeAssertBackup();
            }
        }
    }
    else
    {
        if(uDeAssertSkipCycles > 0)
        {
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x830,uDeAssertSkipCycles);
            uDeAssertSkipCycles--;
        }
    }

    // Count down SlotSfThrottleCount in all slots.
    for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) 
    {
        SLOT(ucCount)->CountDownSlotSfThrottle();
    }
    
    // Rereport ModStat event if required
    if (ModStat1Lrs > 0) 
    {
        AddModStatEvent(EVENTTYPE_NORMAL);
    }

    // Alow STC to run to avoid STC overruns.
    set_imask_exr(ucSaveExr); 
    set_imask_exr(LVLPRI_TICK); 

    // Periodically recompute database checksums.
    static UINT8 sucSlot = 1;
    pDatabase[sucSlot++]->ComputeCheckSum();
    if (sucSlot > MAX_IOLINK_SLOTS) 
    {
        sucSlot = 1;
    }

    // Restore original interrupt mask and return.
    set_imask_exr(ucSaveExr); 
}

/*******************************************************************************
*                         clsSpBoxSlot::AddSoftfailEvent                       *
*                         =============================                        *
* PURPOSE  : This method reports any events/softfails                          *
* ARGUMENTS: a_EventType    - Event Type                                       *
*            a_SoftfailType - Softfail Type                                    *
*            a_ucSltNm      - Slot Number                                      *
* RETURN   : BOOL - returns TRUE on success                                    *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::AddSoftfailEvent(EVENTTYPE a_EventType,
                                    SOFTFAILTYPE a_SoftfailType,  
                                    BOOL a_bDirection, UINT8 a_ucSltNm)
{
    EVENTRECORD SoftfailEvent;
    // Initialize event record.
    SoftfailEvent.Overflow      = FALSE;
    SoftfailEvent.ContactCutout = FALSE;
    SoftfailEvent.Qualifier     = a_EventType; 
    SoftfailEvent.EventPacket   = EVENTPACKET_SYSTEM;
    SoftfailEvent.SystemEvent.ChannelNumber = a_ucSltNm;
    SoftfailEvent.SystemEvent.EventSubType  = a_SoftfailType;
 
    UINT8 ucSfByte,ucLrsByte,ucByteOffset,ucBitOffset=0x01;
    UINT8 ucSfActByteOffset,ucSfActBitOffset=0x01;

    // Generate ByteOffset and BitOffsets for SfActionTable search
    ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
    ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);
    
    // Set SfByte and LrsByte according to the slot number and softail type.
    if (0 == a_ucSltNm) 
    {
        ucByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
        ucBitOffset <<= (a_SoftfailType % BYTESIZE);
        ucSfByte  = BoxSfBits[ucByteOffset];
        ucLrsByte = BoxSfLrs[ucByteOffset];
    }
    else {
        for (ucByteOffset = 0; ucByteOffset < BYTESIZE; ucByteOffset++) 
        {
            if (SlotSfMap[ucByteOffset] == a_SoftfailType) 
            {
                break;
            }
            ucBitOffset <<= 1;
        }
        if (BYTESIZE == ucByteOffset) 
        {
            return FALSE;
        }
        ucSfByte  = SLOT(a_ucSltNm)->GetSlotSfBt();
        ucLrsByte = SLOT(a_ucSltNm)->GetSlotSfLrs();
    }

    if (TRUE == a_bDirection) 
    {
        SoftfailEvent.CurrentState = EVENTSTATE_ALARM;
        if (EVENTTYPE_NORMAL == a_EventType) 
        {
            BOOL bIsEntryInActionTbl = SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset;
            
            //Initiate a SoftFail Failover if enabled and appropriate
            if (REDSTATE_SYNCD == GetRedState() &&       // if modules syncd
                CheckRedData(REDDATA_SFFOEN) &&          // + SF FO enabled
                bIsEntryInActionTbl)// + FO for this SF
            {
                if (!GetPartnersBackupStatus() && Iol.AmPrimary())
                {
                    if(bIsBackUpStatusStable)
                    {
                        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x888,3);
                        Iol.DropDSA();
                        BOX->SetDSA(0);
                    }
                }
                AssertBackup();
                ResetRedData(REDDATA_SFFOEN);
            }
        }
    }
    else 
    {
        SoftfailEvent.CurrentState = EVENTSTATE_RETURN;
    }

    UINT8 ucSaveExr = get_imask_exr();
    if (EVENTTYPE_NORMAL == a_EventType) 
    {
        // Elevate the priority of executing thread to STC level
        // when SfBits and Sfcounter in database are updated.
        set_imask_exr(LVLPRI_TICK);

        if (a_ucSltNm > 0 && a_ucSltNm <= MAX_IOLINK_SLOTS)
        {
            // if slot softfail, check for throttling
            if (SLOT(a_ucSltNm)->IsSlotSfToBeThrottled(ucBitOffset,a_bDirection) == TRUE) 
            {
                // Softfail to be throttled. Restore original priority and 
                // return wihtout updating SfBits and SfCounter in database.
                set_imask_exr(ucSaveExr);
                return FALSE;
            }
        }
         

        if ((ucSfByte & ucBitOffset) && (FALSE == a_bDirection)) 
        {
            // SfByte bit is set and the softfail is returning
            ucSfByte &= ~ucBitOffset; // reset SfByte bit.
            if (0 == a_ucSltNm) 
            {
                if (BoxSfCounter > 0) 
                {
                    BoxSfCounter--;
                }
            }
            else 
            {
                if (SlotSfCounter > 0) 
                {
                    SlotSfCounter--;
                }
            }
        }
        else if ((!(ucSfByte & ucBitOffset)) && (TRUE == a_bDirection)) 
        {
            // SfByte bit is not set and the softfail is being reported
            ucSfByte |= ucBitOffset; // set SfByte bit.
            if (0 == a_ucSltNm) 
            {
                if (BoxSfCounter < MAXUINT8)
                {
                    BoxSfCounter++;
                }
            }
            else 
            {
                if (SlotSfCounter < MAXUINT8) 
                {
                    SlotSfCounter++;
                }
            }
        }

        // Update SfByte in the box/slot database.
        if (0 == a_ucSltNm) 
        {
            BoxSfBits[ucByteOffset] = ucSfByte;
        }
        else 
        {
               SLOT(a_ucSltNm)->SetSlotSfBt(ucSfByte);
        }

        // Database update complete.
        // Restore original interrupt priority.
        set_imask_exr(ucSaveExr);
    }

    if ((0 == BoxSfCounter) && (0 == SlotSfCounter)) 
    {
        SoftfailEvent.SystemEvent.SoftfailStatus = FALSE;
        pNrmEcl->ResetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = FALSE;
        SetRedData(REDDATA_SFFOEN);
        if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) 
        {
            if ((GetCalibAllState() != TRUE)&&(!BOX->CheckForFactoryTestMode())) 
            {
                DeAssertBackup();
            }
        }
    }
    else 
    {
        SoftfailEvent.SystemEvent.SoftfailStatus = TRUE;
        pNrmEcl->SetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = TRUE;
    }

    WriteTestParamUint32(30,BoxSfCounter);
    WriteTestParamUint32(31,SlotSfCounter);

    if (MODSTATUS_FAIL != GetModuleStatus()) 
    {
        // Add softfail event to the normal event circular list if this is 
        // event recovery OR if SfByte and LrsByte are not matching.
        if ((EVENTTYPE_RECOVERY == a_EventType) ||
            (ucLrsByte ^ ucSfByte) & ucBitOffset) 
        {
            if (EVENTTYPE_RECOVERY == a_EventType) 
            {
                if (pNrmEcl->IsRoomForRegen() == FALSE) 
                {
                    return FALSE;
                }
            }

            if (TRUE == pNrmEcl->AddEvent(&SoftfailEvent)) 
            {
                if (EVENTTYPE_NORMAL == a_EventType) 
                {
                    // Update LRS byte only for normal events. 
                    if (TRUE == a_bDirection) 
                    {
                        ucLrsByte |= ucBitOffset;
                    }
                    else {
                        ucLrsByte &= ~ucBitOffset;
                    }
                }

                // Elevate the priority of executing thread to
                // STC level when LRS byte in database is updated.
                set_imask_exr(LVLPRI_TICK);
                if (0 == a_ucSltNm) 
                {
                    BoxSfLrs[ucByteOffset] = ucLrsByte;
                }
                else 
                {
                    SLOT(a_ucSltNm)->SetSlotSfLrs(ucLrsByte);
                }
                // Database update complete.
                // Restore original interrupt priority.
                set_imask_exr(ucSaveExr);

                return TRUE;
            }
            else
            { // AddEvent failed
                return FALSE;
            }
        }
    }

    // Execution reaches here only if 
    // there is nothing to report.
    return TRUE;
}

/*******************************************************************************
*                           clsSpBoxSlot::ReportDSCSF                          *
*                           ==========================                         *
* PURPOSE  : This reports the missed events/softfail of applicaiton Processor  *
*            resident  channels                                                *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    : This funciton report only one channel at every execution          *
*******************************************************************************/
VOID clsSpBoxSlot::ReportDSCSF()
{
    //Get the Cunnet
    UINT8 SltSfByte = SLOT(ucDscSfChanNum)->GetSlotSfBt();
    
    //Call AddSoftFailEvent for corresponding Slot Number
    UINT8 Mask=0x1;
    for (UINT8 ucCount = 0; ucCount < BYTESIZE; ucCount++,Mask=Mask<<1)
    {
       if(SF_UNKNOWN != SlotSfMap[ucCount])
       {
            BOOL bDirection = (SltSfByte & Mask) >> ucCount;
            SOFTFAILTYPE a_SoftfailType = (SOFTFAILTYPE)SlotSfMap[ucCount];
                      
            // Alow STC to run to avoid STC overruns.
            UINT8 ucSaveExr = get_imask_exr();
            set_imask_exr(LVLPRI_TICK);

            AddSoftfailEvent(EVENTTYPE_NORMAL,a_SoftfailType,bDirection,ucDscSfChanNum);

            set_imask_exr(ucSaveExr); 
       }
    }

    ucDscSfChanNum++;
    if(ucDscSfChanNum > SP_CH_END)
    {
        ucDscSfChanNum = DI_CH_START;
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::PpxInterruptHandler                      *
*                       ==================================                     *
* PURPOSE  : This function is invoked every 5ms, which perform sets operations *
*            like watchdog refresh, checks for redundancy state change,reports *
*            the missed events/softfail, polls Application processor SCS Queue *
*            for any new SCS command                                           *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::PpxInterruptHandler(VOID)  
{

    TPU0_TGFA = 0; // Acknowledge the compare match interrupt

#ifndef _DEBUG
    //Service WatchDog
    RefreshWatchDog();
#endif

    //Check Backup Module backup request status stability
    BOX->CheckBackUpStatus();

    //Call AddSoftFailEvent again here to assert/Deassert back-up request for DSC resident
    //channels
    BOX->ReportDSCSF();

    APPBoardPowerDiagRoutine();
    
    //Check INIT_B from FPGA
    if(0 == FPGA_INIT_n)
    {
        HardFail(HF_FPGARDBKFAIL,SVPBOXSLOT_CPP,__LINE__);
    }

     // Bypass the Redundancy checks while doing calibration.
    if(FALSE==BOX->GetCalibAllState())
    {
        BOX->ManageRedIO(); // Process redundancy inputs and state

        if(BOX->CheckRedData(REDDATA_REDCFG) || (!BOX->GetOutCtl() && Iol.AmPrimary()))
        {
            BOX->CheckFailOverCondition();
        }

        //Ensure redundancy switches on primary and secondary module are intact 
        if (!(BOX->CheckForFactoryTestMode()))//do not execute in Factory Mode
        { 
            if((OUTCTL_MINE == BOX->GetOutCtl())&&(FALSE == bSwitchDiagRunning))
            {
                VerifySwitchState(DIS_SWCH,DIS_ON_ON);
                VerifySwitchState(INH_SWCH,INH_ON_ON);
                VerifySwitchState(TST_SWCH,TST_DISABLED);

                //verify the INHIN_FB_n line 
                if(INHIN_NEGATED != INHIN_FB_n)
                {
                    //Check the Out Control state before rasing softfail
                    if((OUTCTL_MINE == BOX->GetOutCtl())&&(FALSE == bSwitchDiagRunning))
                    {
                        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x824,0);
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,TRUE,0);
                    }
                    else
                    {
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
                    }
                }
                else
                {
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
                }
            }
            else if((OUTCTL_PARTNER == BOX->GetOutCtl())&& 
                   (FALSE == bSwitchDiagRunning)){
                VerifySwitchState(DIS_SWCH,DIS_OFF_OFF);
                VerifySwitchState(INH_SWCH,INH_OFF_OFF);
                VerifySwitchState(TST_SWCH,TST_DISABLED);
            }
        }
    }

    //Checks for any new SCS command from Application processor
    volatile UINT16 ReadVal = AppScsFifo.GetNextEntry();
    while(ReadVal != 0)
    {
        if( ReadVal < 0x8000)
        {
            if(ReadVal<0x4000)
            {// SCS Normal commands
                switch(ReadVal)
                {
                    case SCS_COMMAND_MOD_STATUS:
                    {
                        BOX->SetModuleStatus();
                        BOX->AddModStatEvent(EVENTTYPE_NORMAL);
                    }
                    break;
                    case SCS_SHUTDOWN_IOM:
                        // Update the FailCode and shutdown IOM.
                        FailCode = HF_IOMUSERRESET;
                        ShutdownIom();
                    break;
                    case SCS_CALIB_ENABLE:
                            //check for module calibration CMD.
                            //TaskScheduler.RunTask(TASKID_CALIBTASK);
                            break;
                    case SCS_CALIB_DISABLE:
                        BOX->CalibOpt = CALIBOPT_NONE;
                            break;
                    case SCS_COMMAND_MOD_STATUS_RUN_IDLE:
                        {
                            if (BOX->GetModuleStatus() == MODSTATUS_IDLE) 
                            {
                                for (UINT8 ucSlotNum = 0; ucSlotNum < AI_MAXSLOTS; ucSlotNum++) {
                                    SLOT(AI_CH_START + ucSlotNum)->InactivateSlot();
                                }
                            }

                            for (UINT8 ucSlotNum = 0; ucSlotNum < AO_MAXSLOTS; ucSlotNum++) {
                                SLOT(AO_CH_START + ucSlotNum)->InactivateSlot();
                            }
                        }
                        break;
                    case SCS_COMMAND_MOD_STATUS_IDLE_RUN:
                        {
                            for (UINT8 ucSlotNum = 0; ucSlotNum < AO_MAXSLOTS; ucSlotNum++) {
                                SLOT(AO_CH_START + ucSlotNum)->InactivateSlot();
                            }
                        }
                        break;
                    case SCS_COMMAND_TST_TIME:
                        BOX->SetTstTimeFromShram();
                        break;
                    default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x903,ReadVal);
                        break;
                }
            }
            else
            {
                //Hard Fail Entry
                HFEVENT EvtData;
                EvtData.all = ReadVal;
                PrintStr("\r\nHF");
                PrintVal(EvtData.bit.HfType);
                TraceLog.AddToTrace(TRACEID_GENERIC,bcHardFail1,EvtData.bit.HfType);
                HardFail((HARDFAILTYPE)EvtData.bit.HfType,SVPBOXSLOT_CPP,__LINE__);
             }
        }
        else
        {
            //Soft Fail Entry
            SFEVENT EvtData;
            EvtData.all = ReadVal;

            BOX->AddSoftfailEvent((EVENTTYPE)EvtData.bit.EvtType, (SOFTFAILTYPE)EvtData.bit.SfType,EvtData.bit.SfDir,EvtData.bit.SlotNum);
        }
    
        ReadVal = AppScsFifo.GetNextEntry();
    }
}

/*******************************************************************************
*                         clsSpBoxSlot::AppStcProcessing                       *
*                         ===============================                      *
* PURPOSE  : This function is invokde when IRQ6 interrupt is fired             *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::IRQ6InterruptHandler(VOID)
{
    //IRQ6_STATUS = DISABLE;
    return;
}

/*******************************************************************************
*                         clsSpBoxSlot::AppStcProcessing                       *
*                         ==============================                       *
* PURPOSE  : This functions is invoked every 10ms, which is perform AO Channel *
*            point processing                                                  *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::AppStcProcessing(VOID)
{   
    UINT16 AppBrdStatus=*(UINT8*)0x81030;

    AppBrdStatus &= 0x1;

    if(AppBrdStatus)
    {
        //Shutdown the app board
        (P_CPLDR0C).CPLDRDREG &= 0x8;
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_5V_SUPPLY_FAIL,TRUE,0);
    }
    else
    {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_5V_SUPPLY_FAIL,FALSE,0);
    }
       
    // Perform loopback test if calibration is not in progress.
    if(FALSE==BOX->GetCalibAllState())
    {
        UINT8 LpbkSts;       
        
        //Do the refresh and readback of AO channel
        LpbkSts = AOLPBK_PASSED;

        bDisableFO = FALSE;

        // Refresh the output channel.
        AO_SLOT(AO_CH_START)->DriveOutput(NormalOutput);

        //Do a readback of the channel output only if module roles are stable
        if(((OUTCTL_PARTNER == BOX->GetModStat3State())&&(!Iol.AmPrimary()))||
           ((OUTCTL_MINE == BOX->GetModStat3State())&&(Iol.AmPrimary())))
        {
            //Do a readback of the channel output if the Point Execution state 
            //is active and Module is in Run state 
            if((AO_SLOT(AO_CH_START)->GetPtExecSt() == PTEXECST_ACTIVE)
                && (MODSTATUS_RUN == GetModuleStatus()))
            {  
                if((AO_SLOT(AO_CH_START)->GetOTPT_Unused() == FALSE)//Is channel is use and Op not just written
                    &&(TRUE == AO_SLOT(AO_CH_START)->GetReadBackrequired()))
                {
                    if(0 == AO_SLOT(AO_CH_START)->GetSkipLpBkTst())
                    {
                        //Validate the OP % swing and perform reaback  
                        LpbkSts = AO_SLOT(AO_CH_START)->DoLoopbackTest(Dac4PercentofFullScale);
                        if (AOLPBK_PASSED == LpbkSts)
                        {
                            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,AO_CH_START);
                        }
                        else
                        {
                            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,TRUE,AO_CH_START);
                            bDisableFO = TRUE;
                        }
                    }
                    else
                    {
                        if(AO_SLOT(AO_CH_START)->GetSkipLpBkTst() > 0)
                        {
                            AO_SLOT(AO_CH_START)->DecrSkipLpBkTst();
                        }
                        
                        bDisableFO = TRUE;
                    }
                }
                else
                {
                    //Only if the channel is in use set the readback flag
                    if(AO_SLOT(AO_CH_START)->GetOTPT_Unused() == FALSE)
                    {
                        //Conduct readback test for this channel in next cycle 
                        AO_SLOT(AO_CH_START)->SetReadBackrequired(TRUE);
                        if(0 != AO_SLOT(AO_CH_START)->GetSkipLpBkTst())
                        {
                            AO_SLOT(AO_CH_START)->DecrSkipLpBkTst(); 
                        }
                        
                        bDisableFO = TRUE;
                    }
                }
            }
            else
            {
                if (AOLPBK_PASSED == LpbkSts) 
                {
                    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,FALSE,AO_CH_START);
                }
                else
                {
                    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OUTPUTFL,TRUE,AO_CH_START);
                    bDisableFO = TRUE;
                }
            }
            AO_SLOT(AO_CH_START)->CmptInitReq();
        }
        else
        {
            bDisableFO = TRUE;
        }
       
        if(Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState()))
        {
            //Checks AO Channel is connected to any internal channel
            if(AO_SLOT(AO_CH_START)->IsOpConnected())
            {
                AO_SLOT(AO_CH_START)->StoreInternalOp();
            }
        }

        //Based on the softfail, it update softfail action to enable switchover 
        //for AO Channel softfail
        if ((bDisableFO == FALSE) && (Iol.AmPrimary())&&
            (REDSTATE_SYNCD == GetRedState()))
        {
               EnableOutputFailFO();
        }
    }//Calibartion Not in progress loop


    //Every 10ms, Checksum is read from shared ram for Application processor channels
    //and update to local data.
    CheckSum[0] = pSpShramBoxData->CheckSum[0];
    for(int iSlot=1;iSlot <= MAX_APP_SLOTS;iSlot++)
    {
        CheckSum[iSlot + APP_SLOT_START_INDEX - 1] = pSpShramBoxData->CheckSum[iSlot];
    }

}

/*******************************************************************************
*                       clsSpBoxSlot::ProcessIOChannels                        *
*                       ==================================                     *
* PURPOSE  : This method runs the statemachine required to perform AI point    *
*            processing This method is called from ExecuteTaskScheduler. The   *
*            method checks for any timer expiry and calls the respective event *
*            handler.                                                          *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::ProcessIOChannels(VOID)
{
    while((ChanProcEvent = TimerObj.CheckTimerEvent()) != EVENT_NONE)
    {
        switch(ChanProcEvent)
        {
        case EVENT_CHANPROCCYCLE:
           ChanProcCycle();
           break;
        case EVENT_DIAG_MUX_TOUT:
           DiagMuxTout();
           break;
        case EVENT_DIAGFPGA_RESP_OK:
           DiagFpgaRespOk();
           break;
        case EVENT_CHAN_MUX_TOUT:
           ChanMuxTout();
           break;
        case EVENT_CHANFPGA_RESP_OK:
           ChanFpgaRespOk();
           break;
        default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x904,ChanProcEvent);
           break;
        }
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::SetChanProcState                         *
*                       ==================================                     *
* PURPOSE  : To set channel processing state and start timer for next channel  *
*            if current channel processing state is IDLE (mean processing is   *
*            done)                                                             *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetChanProcState(enmChanProcState NewChanProcState)
{
    ChanProcState = NewChanProcState;
    if(STATE_IDLE == NewChanProcState)
    {
        // Current channel processing is complete, so start timer for next channel
        // processing based on below conditions.
        // 1. If it not 1st AI channel, then start next channel immediatly
        // 2. If all AI channels processed, then start next set after AI_CHAN_PROC_PERIOD
        //      a. If current channels set together took more than AI_CHAN_PROC_PERIOD, then
        //         start next set of channels processing immediatly
        //      b. Else start next channel processing after AI_CHAN_PROC_PERIOD

        if(AI_MAXSLOTS == BOX->PpxChannel)
        {
            // All channels processed, set timer to start next set of channels
            if(0 == AiChannelsProcStartTime)
            {
                // 1st time of module start
                TimerObj.StartTimer(0, EVENT_CHANPROCCYCLE);
            }
            else
            {
                UINT32 ElapsedCount = TimerObj.GetElapsedCount(AiChannelsProcStartTime);
                if( (UINT32)AI_CHAN_PROC_PERIOD < ElapsedCount)
                {
                    // Already late to start processing of next set of channels.
                    // Zero expire time to start next set of channels asap
                    TimerObj.StartTimer(0, EVENT_CHANPROCCYCLE);
                }
                else
                {
                    // We are early, set timer to start next set after remaining time
                    TimerObj.StartTimer(AI_CHAN_PROC_PERIOD - (UINT16)ElapsedCount, EVENT_CHANPROCCYCLE);
                }
            }
        }
        else
        {
            // Current set of AI channels processing is going on, start next one asap (zero expire time)
            TimerObj.StartTimer(0, EVENT_CHANPROCCYCLE);
        }
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::ChanProcCycle                            *
*                       ===========================                            *
* PURPOSE  : ChanProcCycle() is the first step in the statemachine execution   *
*            of AI channel processing.It initiates the first step to check the *
*            reference voltage for the ADC. If everything goes fine, the next  *
*            event generated should be EVENT_DIAG_MUX_TOUT.                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::ChanProcCycle()
{
    //This event is fired only when state is STATE_IDLE
    if(STATE_IDLE == ChanProcState)
    {
        // Setup to do point PPX in the next channel in the next cycle.
        if(AI_MAXSLOTS == BOX->PpxChannel)
        {
            // All channels done, start from 1st channels again
            BOX->PpxChannel = 1;
            // Mark starting time
            AiChannelsProcStartTime = TimerObj.GetFRC();
        }
        else
        {
            BOX->PpxChannel++;
        }

        if((MODSTATUS_RUN == BOX->GetModuleStatus()) ||
           (MODSTATUS_IDLE == BOX->GetModuleStatus()))
        {
            ProcessChannel();
        }
        else
        {
            //Just in case Modstat is neither IDLE or RUN, do nothing.
            SetChanProcState ( STATE_IDLE );
        }
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::ProcessChannel                           *
*                       ============================                           *
* PURPOSE  : ProcessChannel() initiates the first step to check the            *
*            reference voltage for the ADC. If everything goes fine, the next  *
*            event generated should be EVENT_DIAG_MUX_TOUT.                    *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::ProcessChannel()
{
    if (MODSTATUS_RUN == BOX->GetModuleStatus())
    {
        // Check the common mode voltage warning bit.
        if (0 == GetBitValue((*P_AI_CTRL_REG),6))
        {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADRJVAL,TRUE,BOX->PpxChannel);
            SetChanProcState ( STATE_IDLE );
        }
        else
        {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADRJVAL,FALSE,BOX->PpxChannel);
            // Convert and test the check voltage corresponding to this channel.
            // This test ensures that the analog mux is switching correctly.
            BOX->ValidateCheckVoltage(BOX->PpxChannel,0,ChanProcEvent); 
            TimerObj.StartTimer(MUX_SETTLE_DELAY, EVENT_DIAG_MUX_TOUT);
            ChanProcState = STATE_WAITFORDIAGMUX;
        } 
    }
    else if (MODSTATUS_IDLE == BOX->GetModuleStatus())
    {
        //If calibration is not in progress
        if (FALSE == BOX->GetCalibAllState())
        {
            // Convert and test the check voltage corresponding to this channel.
            // This test ensures that the analog mux is switching correctly.
            BOX->ValidateCheckVoltage(BOX->PpxChannel,0,ChanProcEvent); 
            TimerObj.StartTimer(MUX_SETTLE_DELAY, EVENT_DIAG_MUX_TOUT);
            ChanProcState = STATE_WAITFORDIAGMUX;
        }
        else
        {
            SetChanProcState ( STATE_IDLE );
        }
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::DiagMuxTout                              *
*                       =========================                              *
* PURPOSE  : DiagMuxTout() event is generated when the ADC MUX settle time is  *
*            completed. This method starts the next step for getting the       *
*            reference data for the ADC. If everything goes fine, the next     *
*            event generated should be EVENT_DIAGFPGA_RESP_OK.                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSpBoxSlot::DiagMuxTout(VOID)
{
    //Event only valid when state is STATE_WAITFORDIAGMUX
    if(STATE_WAITFORDIAGMUX == ChanProcState)
    {
        BOX->ValidateCheckVoltage(BOX->PpxChannel,0,ChanProcEvent); 
        TimerObj.StartTimer(FPGA_RESP_DELAY, EVENT_DIAGFPGA_RESP_OK);
        ChanProcState = STATE_WAITFOR_DIAGFPGA_RESP;
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::DiagFpgaRespOk                           *
*                       ============================                           *
* PURPOSE  : DiagFpgaRespOk() event is generated when the FPGA ready bit time  *
*            is completed. This method gets the reference data for the ADC and *
*            posts SF if there is a reference error. It then initiates the     *
*            channel data fetch and channel processing for the current ppx     *
*            channel.If everything goes fine, the next event generated should  *
*            be EVENT_CHAN_MUX_TOUT when modstat is RUN.                       *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSpBoxSlot::DiagFpgaRespOk(VOID)
{
    if(STATE_WAITFOR_DIAGFPGA_RESP == ChanProcState)
    {
        if(BOX->ValidateCheckVoltage(BOX->PpxChannel,0,ChanProcEvent) == TRUE)
        {
            if (MODSTATUS_RUN == BOX->GetModuleStatus()) 
            {
                // Call AI Data fetch phase1
                AI_SLOT(BOX->PpxChannel)->AiDataFetch(ChanProcEvent); 
                TimerObj.StartTimer(MUX_SETTLE_DELAY, EVENT_CHAN_MUX_TOUT);
                ChanProcState = STATE_WAITFORCHANMUX;
            }
            else
            {
                if ((FALSE == BOX->GetCalibAllState()) &&
                    (PTEXECST_ACTIVE == AI_SLOT(BOX->PpxChannel)->GetPtExecSt()))
                {
                    AI_SLOT(BOX->PpxChannel)->ProcessSlot(NaN);
                }
                SetChanProcState ( STATE_IDLE );
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,BOX->PpxChannel);
                AI_SLOT(BOX->PpxChannel)->SetAiOpenWireSf(FALSE);
            }
        }
        else
        {
            // Check voltage test failed for this channel. Post softfail.
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
            SetChanProcState ( STATE_IDLE );
        }
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::ChanMuxTout                              *
*                       =========================                              *
* PURPOSE  : ChanMuxTout() event is generated when the ADC MUX settle time is  *
*            completed. This method starts the next step for getting the       * 
*            channel data from the ADC. If everything goes fine, the next      *
*            event generated should be EVENT_CHANFPGA_RESP_OK.                 *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSpBoxSlot::ChanMuxTout(VOID)
{
    if(STATE_WAITFORCHANMUX == ChanProcState)
    {
        AI_SLOT(BOX->PpxChannel)->AiDataFetch(ChanProcEvent); 
        TimerObj.StartTimer(FPGA_RESP_DELAY, EVENT_CHANFPGA_RESP_OK);
        ChanProcState = STATE_WAITFOR_CHANFPGA_RESP;
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::ChanFpgaRespOk                           *
*                       ============================                           *
* PURPOSE  : ChanFpgaRespOk() event is generated when the FPGA ready bit time  *
*            is completed. This method gets the channel data from the ADC. It  *
*            then performs channel processing for the current ppx channel.     *
*            If everything goes fine, the next event generated should be       *
*            EVENT_CHANPROCCYCLE                                               *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSpBoxSlot::ChanFpgaRespOk()
{
    if(STATE_WAITFOR_CHANFPGA_RESP == ChanProcState)
    {
        AI_SLOT(BOX->PpxChannel)->AiDataFetch(ChanProcEvent); 
       //First set current channel to idle as it is done and 
       //start the timer for the next cycle of channel processing.
       SetChanProcState(STATE_IDLE);
    }
}

/*******************************************************************************
*                                   clsSpAdc::GetRawData                       *
*                                   ====================                       *
* PURPOSE  : This funtion returns the ai channel raw data                      *
* ARGUMENTS: a_ucMuxSel - Mux Selected                                         *
*            a_uiWaitTime - Wait time for input to settle                      *
* RETURN   : UINT16 - returns the Raw Data                                     *
* NOTES    :                                                                   *
*******************************************************************************/
UINT16 clsSpAdc::GetRawData(UINT8 a_ucMuxSel,UINT16 a_uiWaitTime)
{
    UINT16 CntlRegVal = (*P_AI_CTRL_REG);

    clsFPGACtrlReg AiCtrlReg((UINT16*)P_AI_CTRL_REG);
    
    UINT16 MuxCtrl = SetMuxCtrl(CntlRegVal,/*0x01*/aInputSelect[a_ucMuxSel]);
    
    AiCtrlReg = MuxCtrl;

    CntlRegVal = (*P_AI_CTRL_REG);
    CntlRegVal = SetMuxEnable(CntlRegVal,MuxSelEnable[a_ucMuxSel]);

    AiCtrlReg = CntlRegVal;

    if (a_uiWaitTime > 0)
    {
        IdleWait(a_uiWaitTime);  // Wait for input to settle
    }
        
    CntlRegVal = (*P_AI_CTRL_REG);

    CntlRegVal = SetAiReqbit(CntlRegVal,TRUE);
    
    AiCtrlReg = CntlRegVal;
  
    UINT16  ulData = 0;
    
    while(1)
    {    
        if(GetBitValue((*P_AI_CTRL_REG),7) == 1)
        {
            ulData = (*P_AI_CHAN_DATA_REG);
            break;
        }

    }
    
    CntlRegVal = (*P_AI_CTRL_REG);
    CntlRegVal = SetAiReqbit(CntlRegVal,FALSE);
    AiCtrlReg = CntlRegVal;

    return ulData;  
}

/*******************************************************************************
*                             clsSpAdc::GetRawDataPhase1                       *
*                             ==========================                       *
* PURPOSE  : Sets the mux selection register and returns. It expects a mux     *
*            selection delay of 200 us before getrawdataphase2 is called       *
* ARGUMENTS: a_ucMuxSel - Mux Selected                                         *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSpAdc::GetRawDataPhase1(UINT8 a_ucMuxSel)
{
    UINT16 CntlRegVal = (*P_AI_CTRL_REG);

    clsFPGACtrlReg AiCntrlReg((volatile UINT16*)P_AI_CTRL_REG);

    UINT16 MuxCtrl = SetMuxCtrl(CntlRegVal,/*0x01*/aInputSelect[a_ucMuxSel]);
    AiCntrlReg = MuxCtrl;

    CntlRegVal = (*P_AI_CTRL_REG);
    CntlRegVal = SetMuxEnable(CntlRegVal,MuxSelEnable[a_ucMuxSel]);

    AiCntrlReg = CntlRegVal;
}

/*************************************************************************************
*                               clsSpAdc::GetRawDataPhase2                           *
*                               ==========================                           *
* PURPOSE  : Sets the request bit for getting ADC data for the AI channel/Diag       *
*            channel                                                                 *
* ARGUMENTS: NONE                                                                    *
* RETURN   : NONE                                                                    *
* NOTES:                                                                             *
**************************************************************************************/
VOID clsSpAdc::GetRawDataPhase2(VOID)
{
    UINT16 CntlRegVal ;
    CntlRegVal = (*P_AI_CTRL_REG);

    CntlRegVal = SetAiReqbit(CntlRegVal,TRUE);
    clsFPGACtrlReg AiCtrlReg((volatile UINT16*)P_AI_CTRL_REG);
    AiCtrlReg = CntlRegVal;
}

/*******************************************************************************
*                         clsSpAdc::GetRawDataPhase3                           *
*                         ==========================                           *
* PURPOSE  : Reads the data from the ADC and returns the raw data              *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT16 - returns raw data                                         *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsSpAdc::GetRawDataPhase3(VOID)
{
    UINT16 CntlRegVal ;
    UINT16 ulData = 0;
    
    if(GetBitValue((*P_AI_CTRL_REG),7) == 1)
    {
        ulData = (*P_AI_CHAN_DATA_REG);
    }
    else
    {
        return 0;
    }
    
    CntlRegVal = (*P_AI_CTRL_REG);
    CntlRegVal = SetAiReqbit(CntlRegVal,FALSE);
    clsFPGACtrlReg AiCtrlReg((volatile UINT16*)P_AI_CTRL_REG);
    AiCtrlReg = CntlRegVal;

    return ulData;  
}

/*******************************************************************************
*                          clsSpAdc::SetMuxEnable                              *
*                          ======================                              *
* PURPOSE  : This method will enable the respective mux                        *
* ARGUMENTS: ui_MuxReg - Mux Register                                          *
*            ui_MuxEn  - value to enable mux                                   *
* RETURN   : UINT16 - returns the AI control register value                    *
* NOTES    :                                                                   *
*******************************************************************************/
UINT16 clsSpAdc::SetMuxEnable(UINT16 ui_MuxReg,UINT8 ui_MuxEn)
{
    volatile AICTRL  temp_Ai_Ctl_Reg;
    temp_Ai_Ctl_Reg.all = ui_MuxReg; // clear the mux enable bits
    temp_Ai_Ctl_Reg.bit.Mux_en = ui_MuxEn;
    return temp_Ai_Ctl_Reg.all;
}

/*******************************************************************************
*                         clsSpAdc::SetMuxCtrl                                 *
*                         ====================                                 *
* PURPOSE  : This method will mux control register                             *
* ARGUMENTS: ui_MuxReg - Mux Register                                          *
*            ui_MuxEn  - value to mux control register                         *
* RETURN   : UINT16 - returns the AI control register value                    *
* NOTES    :                                                                   *
*******************************************************************************/
UINT16 clsSpAdc::SetMuxCtrl(UINT16 ui_MuxReg,UINT8 ui_MuxCtl)
{
    volatile AICTRL  temp_Ai_Ctl_Reg;
    temp_Ai_Ctl_Reg.all = ui_MuxReg; // clear the mux enable bits
    temp_Ai_Ctl_Reg.bit.Mux_ctrl = ui_MuxCtl;
    return (temp_Ai_Ctl_Reg.all);
}

/*******************************************************************************
*                          SetAiReqbit::SetMuxCtrl                             *
*                          =======================                             *
* PURPOSE  : This method will set ai request bit                               *
* ARGUMENTS: ui_MuxReg - Mux Register                                          *
*            AiReqbit  - Ai request bit                                        *
* RETURN   : UINT16 - returns the AI control register value                    *
* NOTES    :                                                                   *
*******************************************************************************/
UINT16 clsSpAdc::SetAiReqbit(UINT16 ui_MuxReg,BOOL AiReqbit)
{
    volatile  AICTRL  temp_Ai_Ctl_Reg;
    temp_Ai_Ctl_Reg.all = ui_MuxReg; // clear the mux enable bits
    temp_Ai_Ctl_Reg.bit.Ai_Req_bit = AiReqbit;
    return (temp_Ai_Ctl_Reg.all);
}

/*******************************************************************************
*                     clsSpBoxSlot::SetFactoryTestMode                         *
*                     =====================================                    *
* PURPOSE  : This function sets the IOM in Factory Mode when the REDUNT_n and  *
*            BOTTOM signals have appropiate states.The signal states chosen    *
*            enusures that the IOMs are not put to Factory Mode inadverently.  *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSpBoxSlot::SetFactoryTestMode(VOID)
{
    //REDUNT_n = 0 and BOTTOM = 1 sets the IOM in Factory Test Mode.
    if(!(REDUNT_n) &&  //Should be Low
        (BOTTOM)       //Should be High
    )
    {
        while(!(*uHandeShakeState == APP_CREATE_DB_DONE))
        {
            IdleWait(1);
        }
        PrintStr("\n\rAPP_CREATE_DB_DONE");

        IolinkScsFifo.SendSCSCommand(SCS_ENTER_FACTTEST_MODE);

        //Wait till App Processor to enter Factory mode and set the 
        // Shared Ram ModeStat data to Factory mode enables.
        while(!BOX->CheckForFactoryTestMode())
        {
           IdleWait(10000);
        }
        PrintStr("\n\rMODULE IN FACTORY MODE");
    }//Set Factory mode bit//IOM is in Factory Test Mode
    else
    {
        // Tell App Proc to not in Factory mode.
        IolinkScsFifo.SendSCSCommand(SCS_NOT_FACTTEST_MODE);
        PrintStr("\n\rMODULE NOT IN FACTORY MODE");
    }
}

/*******************************************************************************
*                     clsSpBoxSlot::SendWdtTstCmdToAppProc                     *
*                     =====================================                    *
* PURPOSE  : This method is to send the SC command to App Processor to start   *
*            the App Processor Watchdog Test                                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSpBoxSlot::SendWdtTstCmdToAppProc(VOID)
{
    // Send SCS command to Appprocessor to start WDT test
    IolinkScsFifo.SendSCSCommand(SCS_START_APP_WDT_TST);
}

/*******************************************************************************
*                     clsSpBoxSlot::CheckForFactoryTestMode                    *
*                     =====================================                    *
* PURPOSE  : This method will return the staus of the Factory bit              *
* ARGUMENTS: NONE                                                              *
* RETURN   : UINT8 - Factory bit                                               *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsSpBoxSlot::CheckForFactoryTestMode(VOID)
{
    ModStat1.Factory = (UINT8)((pSpShramBoxData->ModStat1 & 0x04)>>2); 

    return ModStat1.Factory;
}

/*******************************************************************************
*                          clsSpBoxSlot::FillScanRecord                        *
*                          ============================                        *
* PURPOSE  : This method will fill the Input or Output scan record based on    *
*            parameter number                                                  *
* ARGUMENTS: a_ucParamNumber - Parameter Number                                *
*            a_ReadBuffer    - Scan record buffer pointer                      *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
void clsSpBoxSlot::FillScanRecord(UINT8 a_ucParamNumber, UINT8 *a_ReadBuffer)
{
    switch(a_ucParamNumber)
    {
        case kSiomSpPnInputProcessData: FillInputScanRecord(a_ReadBuffer);
            break;
        case kSiomSpPnOutputProcessData: FillOutputScanRecord(a_ReadBuffer);
            break;
        default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x905,a_ucParamNumber);
            break;
    }
}

/*******************************************************************************
*                          clsSpBoxSlot::FillInputScanRecord                   *
*                          ==================================                  *
* PURPOSE  : This method will fill the Input scan record                       *
* ARGUMENTS: a_ReadBuffer    - Scan record buffer pointer                      *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
void clsSpBoxSlot::FillInputScanRecord(UINT8 *a_ReadBuffer)
{
    SPINPUTSCANREC *pSpInputScanRec = (SPINPUTSCANREC*)(a_ReadBuffer+1);
     
    //AI Channels
    for (UINT8 ucSlot = 0; ucSlot < AI_MAXSLOTS; ucSlot++)
    {
        pSpInputScanRec->AiPv[ucSlot] = SpInputScanRec.AiPv[ucSlot];
    }
    pSpInputScanRec->AiPvSts = SpInputScanRec.AiPvSts;
    
    pSpInputScanRec->SpdPvSts = 0;
    for(UINT8 chnl = 0; chnl < SP_MAXSLOTS; chnl++)
    {
        pSpInputScanRec->SpdPv[chnl] = ShramData.ShramSlotData.SpeedShramSlotData[chnl].Pv;
        
        UINT16 temp_SpPvSts = 0;
        UINT16 PvStsVal = (ShramData.ShramSlotData.SpeedShramSlotData[chnl].PvSts & MASK_1_NIBBLE);
        switch(SP_CH_START+chnl)
        {
            case SP_CH_START:
                temp_SpPvSts = (pSpInputScanRec->SpdPvSts & (UINT16)RESET_1_NIBBLE);
                temp_SpPvSts |= PvStsVal;
                break;
            case (SP_CH_START+1):
                temp_SpPvSts=(pSpInputScanRec->SpdPvSts & (UINT16)RESET_2_NIBBLE);
                temp_SpPvSts |= (PvStsVal << SHIFT_1_NIBBLE); 
                break;
            case (SP_CH_START+2):
                temp_SpPvSts=(pSpInputScanRec->SpdPvSts & (UINT16)RESET_3_NIBBLE);
                temp_SpPvSts |= (PvStsVal << SHIFT_2_NIBBLE);
                break;
            case (SP_CH_END):
                temp_SpPvSts=(pSpInputScanRec->SpdPvSts & (UINT16)RESET_4_NIBBLE);
                temp_SpPvSts |= (PvStsVal << SHIFT_3_NIBBLE); 
                break;
            default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x906,SP_CH_START+chnl);
                break;
        }
        pSpInputScanRec->SpdPvSts = temp_SpPvSts;
        
    }

    pSpInputScanRec->VotPv1    = ShramData.ShramSlotData.VoteShramSlotData.VotPV1;
    pSpInputScanRec->VotPv2    = ShramData.ShramSlotData.VoteShramSlotData.VotPV2;
    pSpInputScanRec->VotRoc1   = ShramData.ShramSlotData.VoteShramSlotData.VotROC1;
    pSpInputScanRec->VotRoc2   = ShramData.ShramSlotData.VoteShramSlotData.VotROC2;
    pSpInputScanRec->VotPvSts  = (ShramData.ShramSlotData.VoteShramSlotData.VotPV1Sts) | (ShramData.ShramSlotData.VoteShramSlotData.VotPV2Sts << 4);
    pSpInputScanRec->VotRocSts = (ShramData.ShramSlotData.VoteShramSlotData.VotROC1Sts) | (ShramData.ShramSlotData.VoteShramSlotData.VotROC2Sts << 4);

    pSpInputScanRec->RevRotFlLastTripTimeInfo.bit.TripInfo1 = (BOOL)ShramData.ShramSlotData.DoShramSlotData[0].TripTimeInfo;
    pSpInputScanRec->RevRotFlLastTripTimeInfo.bit.TripInfo2 = (BOOL)ShramData.ShramSlotData.DoShramSlotData[1].TripTimeInfo;
    pSpInputScanRec->RevRotFlLastTripTimeInfo.bit.TripInfo3 = (BOOL)ShramData.ShramSlotData.DoShramSlotData[2].TripTimeInfo;
    pSpInputScanRec->RevRotFlLastTripTimeInfo.bit.TripInfo4 = (BOOL)ShramData.ShramSlotData.DoShramSlotData[3].TripTimeInfo;
    pSpInputScanRec->RevRotFlLastTripTimeInfo.bit.RevRot = (BOOL)ShramData.ShramSlotData.SpShramBoxData.RevRotFl;

    pSpInputScanRec->ZeroPvFl.bit.ZeroPv1 = (BOOL)ShramData.ShramSlotData.SpeedShramSlotData[0].ZeroSpdFl;
    pSpInputScanRec->ZeroPvFl.bit.ZeroPv2 = (BOOL)ShramData.ShramSlotData.SpeedShramSlotData[1].ZeroSpdFl;
    pSpInputScanRec->ZeroPvFl.bit.ZeroPv3 = (BOOL)ShramData.ShramSlotData.SpeedShramSlotData[2].ZeroSpdFl;
    pSpInputScanRec->ZeroPvFl.bit.ZeroPv4 = (BOOL)ShramData.ShramSlotData.SpeedShramSlotData[3].ZeroSpdFl;

    //DI Channels    
    pSpInputScanRec->DiPv.bit.Di1Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[0].Pv;                           
    pSpInputScanRec->DiPv.bit.Di2Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[1].Pv;                           
    pSpInputScanRec->DiPv.bit.Di3Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[2].Pv;                           
    pSpInputScanRec->DiPv.bit.Di4Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[3].Pv;                           
    pSpInputScanRec->DiPv.bit.Di5Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[4].Pv;                           
    pSpInputScanRec->DiPv.bit.Di6Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[5].Pv;                           
    pSpInputScanRec->DiPv.bit.Di7Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[6].Pv;                           
    pSpInputScanRec->DiPv.bit.Di8Pv  = (BOOL)ShramData.ShramSlotData.DiShramSlotData[7].Pv;                           

    pSpInputScanRec->BadPvFl.bit.Di1PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[0].BadPvFl;
    pSpInputScanRec->BadPvFl.bit.Di2PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[1].BadPvFl;
    pSpInputScanRec->BadPvFl.bit.Di3PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[2].BadPvFl;
    pSpInputScanRec->BadPvFl.bit.Di4PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[3].BadPvFl;
    pSpInputScanRec->BadPvFl.bit.Di5PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[4].BadPvFl;
    pSpInputScanRec->BadPvFl.bit.Di6PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[5].BadPvFl;
    pSpInputScanRec->BadPvFl.bit.Di7PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[6].BadPvFl;
    pSpInputScanRec->BadPvFl.bit.Di8PvFl = (BOOL)ShramData.ShramSlotData.DiShramSlotData[7].BadPvFl;

}

/*******************************************************************************
*                          clsSpBoxSlot::FillOutputScanRecord                  *
*                          ==================================                  *
* PURPOSE  : This method will fill the Output scan record                      *
* ARGUMENTS: a_ReadBuffer    - Scan record buffer pointer                      *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
void clsSpBoxSlot::FillOutputScanRecord(UINT8 *a_ReadBuffer)
{
    SPOUTPUTSCANREC *pSpOutPutScanRec = (SPOUTPUTSCANREC*)(a_ReadBuffer+1);
    
    //Fill AO Channel Data
    pSpOutPutScanRec->AoOp      = SpOutPutScanRec.AoOp;
    pSpOutPutScanRec->InitReq = SpOutPutScanRec.InitReq ;

    //Fill DO Channel Data
    pSpOutPutScanRec->DoSo = 0;
    pSpOutPutScanRec->DoInitReq = 0;
    for(UINT8 chnl = 0; chnl < DO_MAXSLOTS; chnl++)
    {
        UINT8 ucBitIndex  = 0x8 >> (chnl  & 0x03);

        BOOL a_DoInitReq = (BOOL)ShramData.ShramSlotData.DoShramSlotData[chnl].InitReq;
            
        if (TRUE == a_DoInitReq) 
        {
            pSpOutPutScanRec->DoInitReq |= ucBitIndex;
        }
        else 
        {
            pSpOutPutScanRec->DoInitReq &= ~ucBitIndex; 
        }

        BOOL a_bSo = (BOOL)ShramData.ShramSlotData.DoShramSlotData[chnl].SO;
        
        if (TRUE == a_bSo) 
        {
            pSpOutPutScanRec->DoSo |= ucBitIndex;
        }
        else 
        {
            pSpOutPutScanRec->DoSo &= ~ucBitIndex; 
        }

    }
}

/*******************************************************************************
*                          clsSpBoxSlot::GetPv                                 *
*                          ============================                        *
* PURPOSE  : This functions returns the AI PV value of respective channel      *
* ARGUMENTS: a_ucChanNum - Channel Number                                      *
* RETURN   : FLOAT32 - return PV Value                                         *
* NOTES    :                                                                   *
*******************************************************************************/
FLOAT32 clsSpBoxSlot::GetPv(UINT8 a_ucChanNum) 
{
    return SpInputScanRec.AiPv[a_ucChanNum - AI_CH_START];
}

/*******************************************************************************
*                          clsSpBoxSlot::GetAiPvSts                            *
*                          ============================                        *
* PURPOSE  : This functions returns the AI PvSts value of respective channel   *
* ARGUMENTS: a_ucChanNum - Channel Number                                      *
* RETURN   : UINT32 - return PvSts Value                                       *
* NOTES    :                                                                   *
*******************************************************************************/
UINT32 clsSpBoxSlot::GetAiPvSts(UINT8 a_ucChanNum)
{ 
    UINT32  RetVal = PVVALST_BAD;
    if((a_ucChanNum >= AI_CH_START) && (a_ucChanNum <= AI_CH_END))
    {
        switch(a_ucChanNum)
        {
        case 1:
            RetVal = (SpInputScanRec.AiPvSts & MASK_1_NIBBLE);
            break;
        case 2:
            RetVal = ((SpInputScanRec.AiPvSts & MASK_2_NIBBLE) >> SHIFT_1_NIBBLE);
            break;
        case 3:
            RetVal = ((SpInputScanRec.AiPvSts & MASK_3_NIBBLE) >> SHIFT_2_NIBBLE);
            break;
        case 4:
            RetVal = ((SpInputScanRec.AiPvSts & MASK_4_NIBBLE) >> SHIFT_3_NIBBLE);
            break;
        case 5:
            RetVal = ((SpInputScanRec.AiPvSts & MASK_5_NIBBLE) >> SHIFT_4_NIBBLE);
            break;
        case 6:
            RetVal = ((SpInputScanRec.AiPvSts & MASK_6_NIBBLE) >> SHIFT_5_NIBBLE);
            break;
        case 7:
            RetVal = ((SpInputScanRec.AiPvSts & MASK_7_NIBBLE) >> SHIFT_6_NIBBLE);
            break;
        case 8:
            RetVal = ((SpInputScanRec.AiPvSts & MASK_8_NIBBLE) >> SHIFT_7_NIBBLE);
            break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x907,a_ucChanNum);
            break;
        }
        return RetVal;
    }
    return PVVALST_BAD;
}

/*******************************************************************************
*                          clsSpBoxSlot::SetPv                                 *
*                          ===================                                 *
* PURPOSE  : This function sets the AI channel Pv into Input Scan Record       *
*            sturcture for the corresponding channel                           *
* ARGUMENTS: a_ucChanNum - Channel Number                                      *
*            a_fPv - Pv Value                                                  *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetPv(UINT8 a_ucChanNum, FLOAT32 a_fPv) {
    UINT8 uiMask = get_imask_exr();

    set_imask_exr(LVLPRI_HIGHEST);

    SpInputScanRec.AiPv[a_ucChanNum-1] = a_fPv;

    set_imask_exr(uiMask);
}

/*******************************************************************************
*                          clsSpBoxSlot::SetPvSts                              *
*                          ============================                        *
* PURPOSE  : This function sets the AI channel PvSts into Input Scan Record    *
*            sturcture for the corresponding channel                           *
* ARGUMENTS: a_ucChanNum - Channel Number                                      *
*            a_PvSts - Pv Status Value                                         *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetPvSts(UINT8 a_ucChanNum, UINT32 a_PvSts)
{ 
    UINT8 uiMask = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);
    if((a_ucChanNum >= AI_CH_START) && (a_ucChanNum <= AI_CH_END))
    {
        UINT32 temp_AiPvSts=0;
        UINT32 PvStsVal = (a_PvSts & MASK_1_NIBBLE);
        switch(a_ucChanNum)
        {
        case AI_CH_START:
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_1_NIBBLE);
            temp_AiPvSts |= PvStsVal;
            break;
        case (AI_CH_START+1):
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_2_NIBBLE);
            temp_AiPvSts |= (PvStsVal << SHIFT_1_NIBBLE); 
            break;
        case (AI_CH_START+2):
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_3_NIBBLE);
            temp_AiPvSts |= (PvStsVal << SHIFT_2_NIBBLE);
            break;
        case (AI_CH_START+3):
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_4_NIBBLE);
            temp_AiPvSts |= (PvStsVal << SHIFT_3_NIBBLE); 
            break;
        case (AI_CH_START+4):
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_5_NIBBLE);
            temp_AiPvSts |= (PvStsVal << SHIFT_4_NIBBLE);
            break;
        case (AI_CH_START+5):
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_6_NIBBLE);
            temp_AiPvSts |= (PvStsVal << SHIFT_5_NIBBLE); 
            break;
        case (AI_CH_START+6):
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_7_NIBBLE);
            temp_AiPvSts |= (PvStsVal << SHIFT_6_NIBBLE);
            break;
        case (AI_CH_END):
            temp_AiPvSts = (SpInputScanRec.AiPvSts & RESET_8_NIBBLE);
            temp_AiPvSts |= (PvStsVal << SHIFT_7_NIBBLE); 
            break;
        default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x908,a_ucChanNum);
            break;
        }
        SpInputScanRec.AiPvSts = temp_AiPvSts;
    } 
    set_imask_exr(uiMask);
}

/*******************************************************************************
*                          clsSpBoxSlot::SetSpPvSts                            *
*                          ======================                              *
* PURPOSE  : This function sets the Speed channel PvSts into Input Scan Record *
*            sturcture for the corresponding channel                           *
* ARGUMENTS: a_ucChanNum - Channel Number                                      *
*            a_PvSts - Pv Status Value                                         *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetSpPvSts(UINT8 a_ucChanNum, UINT16 a_PvSts)
{ 
    UINT8 uiMask = get_imask_exr();
    set_imask_exr(LVLPRI_HIGHEST);

    UINT16 temp_SpPvSts=0;
    UINT16 PvStsVal = (a_PvSts & MASK_1_NIBBLE);
    switch(a_ucChanNum)
    {
        case SP_CH_START:
            temp_SpPvSts = (SpInputScanRec.SpdPvSts & (UINT16)RESET_1_NIBBLE);
            temp_SpPvSts |= PvStsVal;
            break;
        case (SP_CH_START+1):
            temp_SpPvSts=(SpInputScanRec.SpdPvSts & (UINT16)RESET_2_NIBBLE);
            temp_SpPvSts |= (PvStsVal << SHIFT_1_NIBBLE); 
            break;
        case (SP_CH_START+2):
            temp_SpPvSts=(SpInputScanRec.SpdPvSts & (UINT16)RESET_3_NIBBLE);
            temp_SpPvSts |= (PvStsVal << SHIFT_2_NIBBLE);
            break;
        case (SP_CH_END):
            temp_SpPvSts=(SpInputScanRec.SpdPvSts & (UINT16)RESET_4_NIBBLE);
            temp_SpPvSts |= (PvStsVal << SHIFT_3_NIBBLE); 
            break;
        default:TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x909,a_ucChanNum);
            break;
    }

    SpInputScanRec.SpdPvSts = temp_SpPvSts;

    set_imask_exr(uiMask);
}

/*******************************************************************************
*                          clsSpBoxSlot::SetInitReq                            *
*                          ============================                        *
* PURPOSE  : This function sets the AO channel InitReq into Output Scan Record *
*            sturcture for the corresponding channel                           *
* ARGUMENTS: a_ucChanNum - Channel Number                                      *
*            bInitReq - InitReq Value                                          *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SetInitReq(UINT8 a_ucChanNum, BOOL bInitReq) 
{
    if(a_ucChanNum == AO_CH_START)
    {
        BOOL uiBitIndex = TRUE;
        if (TRUE == bInitReq) 
        {
            SpOutPutScanRec.InitReq |= 0x10;
        }
        else 
        {
            SpOutPutScanRec.InitReq &= (~uiBitIndex << 4); 
        }
    }
}

/*******************************************************************************
*                         clsSpBoxSlot::DoIdleDiagnostics                      *
*                         ================================                     *
* PURPOSE  : This function performs reference voltage check Diagnostic for     *
*            respective channel                                                *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::DoIdleDiagnostics(VOID)
{
    // Test against +/- 4% limits of the reference voltage
    // corresponding to the current PPX channel.
    if (FALSE == ValidateCheckVoltage(PpxChannel,0)) 
    {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);
        return;
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::ValidateCheckVoltage                     *
*                       ===================================                    *
* PURPOSE  : This function performs reference voltage check for respective     *
*            channel                                                           *
* ARGUMENTS: a_ucSlotNum - Slot number                                         *
* RETURN   : BOOL - returns TRUE on success                                    *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::ValidateCheckVoltage(UINT8 a_ucSlotNum,UINT16)
{
    volatile UINT8 uiRefInput = 0;

    if((a_ucSlotNum >= AI_CH_START)&&(a_ucSlotNum <= (AI_CH_START+2)))
    {
        uiRefInput = CKVT1_INDEX;
    }
    else if((a_ucSlotNum >= (AI_CH_START+3))&&(a_ucSlotNum <= (AI_CH_START+5)))
    {
        uiRefInput = CKVT2_INDEX;
    }
    else if((a_ucSlotNum == (AI_CH_START+6))||(a_ucSlotNum == (AI_CH_START+7)))
    {
        uiRefInput = CKVT3_INDEX;
    }
  
    FLOAT32 fRefInput = ((FLOAT32)(SpAdc.GetRawData(uiRefInput))
                         * CalibData.AICalibrationSlope) + CalibData.AICalibrationOffset;   

    if ((fRefInput > SP_REFVOLTAGE_LIMITS[uiRefInput-CKVT1_INDEX].fHiLimit) || 
        (fRefInput < SP_REFVOLTAGE_LIMITS[uiRefInput-CKVT1_INDEX].fLoLimit))
    {       
        return FALSE;
    }
    
    return TRUE;
}

/*******************************************************************************
*                       clsSpBoxSlot::ValidateCheckVoltage                     *
*                       ==================================                     *
* PURPOSE  : Performs diagnostic on the references in 3 steps:                 *
*            Step 1: select the required MUX selection and pass it to          *
*                    getrawdataphase1()                                        *
*            Step 2: getrawdataphase2()                                        *
*            Step 3: Get the ADC count for the reference and return FALSE if   *
*            reference limits are crossed                                      *
* ARGUMENTS: a_ucSlotNum - Slot Number                                         *
*            Event - Takes an additional argument Event to distinguish the     *
*                    steps.                                                    *
* RETURN   : BOOL - returns TRUE on success                                    *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::ValidateCheckVoltage(UINT8 a_ucSlotNum,UINT16,enmChanProcEvent Event)
{
    BOOL RetVal = FALSE;
    FLOAT32 fRefInput;
    switch(Event)
    {
    case EVENT_CHANPROCCYCLE:
        if((a_ucSlotNum >= AI_CH_START)&&(a_ucSlotNum <= (AI_CH_START+2)))
        {
            uiRefInput = CKVT1_INDEX;
        }
        else if((a_ucSlotNum >= (AI_CH_START+3))&&(a_ucSlotNum <= (AI_CH_START+5)))
        {
            uiRefInput = CKVT2_INDEX;
        }
        else if((a_ucSlotNum == (AI_CH_START+6))||(a_ucSlotNum == (AI_CH_START+7)))
        {
            uiRefInput = CKVT3_INDEX;
        }
  
        SpAdc.GetRawDataPhase1(uiRefInput);
        RetVal = TRUE;
        break;

    case EVENT_DIAG_MUX_TOUT:
        SpAdc.GetRawDataPhase2();
        RetVal = TRUE;
        break;

    case EVENT_DIAGFPGA_RESP_OK:
    {
        UINT16 uiRawData = SpAdc.GetRawDataPhase3();

        //perform validate check for CKVT only when Raw Data is >0 
        if(uiRawData > 0)
        {
            fRefInput = ((FLOAT32)(uiRawData) * CalibData.AICalibrationSlope) + CalibData.AICalibrationOffset;

            if ((fRefInput > SP_REFVOLTAGE_LIMITS[uiRefInput-CKVT1_INDEX].fHiLimit) || 
                (fRefInput < SP_REFVOLTAGE_LIMITS[uiRefInput-CKVT1_INDEX].fLoLimit)) 
            {

                // check at index 27 which will have Voltage Ref Input
                WriteTestParamUint32(26,(UINT32)(uiRawData));
                // check at index 28 which will have CKVT channel number
                WriteTestParamUint32(27,(UINT32)uiRefInput);

                RetVal = FALSE;
            }
            else
            {
                RetVal = TRUE;
            }  
        }
        else
        {
            uiCkvtFailCnt++;
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x80A,uiCkvtFailCnt);
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x80B,(UINT32)uiRefInput);        
            // when uiRawData == 0, not performing CKVT votage chack. hence returning true
            RetVal = TRUE;
        }
    }
    break;
    default :TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x910,Event);
        break;
    }
    return RetVal;
}

/*******************************************************************************
*                           clsSpBoxSlot::DoSuccessiveApproximation            *
*                           =======================================            *
* PURPOSE  : Does 10 successive approximation A/D conversions by writing to    *
*            the loopback DAC. Averages the 10 readings together by            *
*            subtracting min and max values and then dividing the sum by 8     *  
*                                                                              *    
* ARGUMENTS: NONE.                                                             *
* RETURN   : FLOAT32 Contains averaged digital value on exit.                  *
* NOTES    : Required set up is to select the multiplexer for desired input    *
*            and wait until the multiplexer and DAC have settled.              * 
*******************************************************************************/
#ifdef DEBUG
FLOAT32 clsSpBoxSlot::DoSuccessiveApproximation(BOOL a_bPrint) {
#else
FLOAT32 clsSpBoxSlot::DoSuccessiveApproximation(BOOL) {
#endif
    const UINT8 ADC_ITERATIONS = 10;
    const UINT8 ADC_FINERESOLUTION_COUNT = 5;

    UINT16 usSelectedbit,usAdcDigVal;
    UINT32 ulSumAdcDigVals = 0;
    UINT16 usMaxCount = 0x0000;
    UINT16 usMinCount = MAXUINT16;
    
    for (UINT8 ucIterations = 0; ucIterations < ADC_ITERATIONS; ucIterations++) 
    {
        usAdcDigVal   = 0;
        usSelectedbit = 0x0800;
        for(UINT8 ucCnt = 0;ucCnt < DAC_RESOLUTION; ucCnt++) {
            usAdcDigVal += usSelectedbit;
            AO_SLOT(AO_CH_START)->DriveDac(usAdcDigVal);
            if(AO_SLOT(AO_CH_START)->ReadComparatorOutput()) { //Is it more?
                usAdcDigVal -= usSelectedbit;//Reduce it
            }
            //divide bit selector by 2
            usSelectedbit >>= 1;
        }
        usAdcDigVal -= 2;
        for(UINT8 ucCnt = 0; ucCnt < ADC_FINERESOLUTION_COUNT; ucCnt++) {
            AO_SLOT(AO_CH_START)->DriveDac(usAdcDigVal);
            if(AO_SLOT(AO_CH_START)->ReadComparatorOutput()) {
                usAdcDigVal-- ;
                break;
            }
            else {
                usAdcDigVal++;
            }
        }
        if(usAdcDigVal > usMaxCount) 
        {
            usMaxCount = usAdcDigVal;
        }
        if(usAdcDigVal < usMinCount) 
        {
            usMinCount = usAdcDigVal;
        }

#ifdef DEBUG
        if (a_bPrint) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(
              "\n\r\t%d\t: 0x%x",(ucIterations + 1),usAdcDigVal));
        }
#endif
        ulSumAdcDigVals += usAdcDigVal;
    }
    ulSumAdcDigVals -= (usMaxCount + usMinCount);
    //TBD : Subtract the HiZero value from the computed DAC count 
    //Average it by samples of 10 and return
#ifdef DEBUG
    g_usMaxLpbkCount = usMaxCount;
    g_usMinLpbkCount = usMinCount;
#endif
    // Maximum and minimum samples are discarded. Return average of 8 values.
    return (ulSumAdcDigVals / (FLOAT32)(ADC_ITERATIONS - 2));
}

/*******************************************************************************
*                              clsSpBoxSlot::CheckRefVoltage                   *
*                              =============================                   *
* PURPOSE  : Checks for the sample voltage to be within valid ranges           *
* ARGUMENTS: DAC count for sample voltage                                      *
* RETURN   : TRUE if successful, FALSE otherwise                               *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::CheckRefVoltage(UINT16 usVoltageLimit) {
    AO_SLOT(AO_CH_START)->DriveDac(usVoltageLimit);
    BOOL bChkRefVoltagests = AO_SLOT(AO_CH_START)->ReadComparatorOutput();
    if( (MIN_ONE_V_OUTPUT_DACCOUNT        == usVoltageLimit) || 
        (MIN_FIVE_V_OUTPUT_DACCOUNT       == usVoltageLimit) ||
        (MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT == usVoltageLimit)) 
    {
        bChkRefVoltagests = !bChkRefVoltagests; // Because the o/p should be low
    }
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,!bChkRefVoltagests,0);
    return bChkRefVoltagests;
}

/*******************************************************************************
*                      clsSpBoxSlot::TestLoopbackCircuit                       *
*                      =================================                       *
* PURPOSE  : This method perform the loopback circuit diagnostic for AO Channel*
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::TestLoopbackCircuit(VOID)
{
    static UINT8 ucHFcount = 0; 
    static UINT8 ucInput = CALCHK_OFFSET; 
    BOOL bMuxAddrFailed = FALSE;
    BOOL bSF_Active = FALSE; 
    BOOL bTestResult = TRUE;
    
    if(((OUTCTL_PARTNER == GetOutCtl())&&(!Iol.AmPrimary()))||
        ((OUTCTL_MINE == GetOutCtl())&&(Iol.AmPrimary())))
    {
        UINT8 ucSaveExr =get_imask_exr();
        set_imask_exr(LVLPRI_TICK);

        // Open the loopback test input.
        bMuxAddrFailed = AO_SLOT(AO_CH_START)->OpenLoopbackMux(ucInput,FALSE);
        
        if (CALCHK_OFFSET == ucInput) 
        {
            //Drive the Dac with the Test Voltage + 2% 
            AO_SLOT(AO_CH_START)->DriveDac(TestCountHi);
            if(AO_SLOT(AO_CH_START)->ReadComparatorOutput()) 
            {
                bTestResult = FALSE;
            }

            if(FALSE == bTestResult) 
            {
                //Drive the Dac with the Test Voltage - 2% 
                AO_SLOT(AO_CH_START)->DriveDac(TestCountLo);
                if(!AO_SLOT(AO_CH_START)->ReadComparatorOutput()) 
                {
                    bTestResult = FALSE;
                }
            }

            if (TRUE == bTestResult) 
            {   // Either +2% or -2% test failed
                if(Iol.AmPrimary()) 
                { // Do HF tests (+/- 4%) only if primary module
                    //Drive the Dac with the Test Voltage + 4%
                    AO_SLOT(AO_CH_START)->DriveDac(TestCountHiHi);
                    if(AO_SLOT(AO_CH_START)->ReadComparatorOutput()) 
                    {
                        bTestResult = FALSE;
                    }

                    if(TRUE == bTestResult) 
                    {
                        ucHFcount++;
                        if(ucHFcount >= 2) 
                        {
                            HardFail(HF_BD_OUTPUT_MUX,AOHBOXSLOT_CPP,__LINE__);
                        }
                    }
                    else 
                    {
                        //Drive the Dac with the Test Voltage - 4% 
                        AO_SLOT(AO_CH_START)->DriveDac(TestCountLoLo);
                        bTestResult = TRUE;
                        if(!AO_SLOT(AO_CH_START)->ReadComparatorOutput()) 
                        {
                            bTestResult = FALSE;
                        }

                        if(TRUE == bTestResult) 
                        {
                            ucHFcount++;
                            if(ucHFcount >= 2) 
                            {
                                HardFail(HF_BD_OUTPUT_MUX,AOHBOXSLOT_CPP,__LINE__);
                            }
                        }
                        else ucHFcount = 0;
                    }
                }
                bSF_Active = TRUE;
            }
            else bSF_Active = FALSE;
        }
        else 
        {   // ucInput == HIZERO1_OFFSET or HIZERO2_OFFSET or HIZERO3_OFFSET
            if(Iol.AmPrimary()) 
            {   // Do HF test only if primary module
                AO_SLOT(AO_CH_START)->DriveDac(HiZeroHiHi);
                if (FALSE == AO_SLOT(AO_CH_START)->ReadComparatorOutput()) 
                {
                    ucHFcount++;
                }
                else
                {
                    ucHFcount = 0;
                }

                if(ucHFcount >= 2) 
                {
                    HardFail(HF_BD_OUTPUT_MUX,AOHBOXSLOT_CPP,__LINE__);
                }
            }
        }
        // Close the test input.
        AO_SLOT(AO_CH_START)->CloseLoopbackMux(ucInput);

        set_imask_exr(ucSaveExr);

        // Change input for the next cycle.
        if(ucInput == CALCHK_OFFSET)
        {
            ucInput = HIZERO1_OFFSET;
        }
        else
        {
            ucInput = CALCHK_OFFSET;
        }
    }
    else 
    {
        ucHFcount = 0; 
        ucInput = CALCHK_OFFSET; 
    }
    
    if (bSF_Active == FALSE && bMuxAddrFailed == FALSE) 
    {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,FALSE,0);
    }
    else 
    {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DIAGCTFL,TRUE,0);
    }
}

/*******************************************************************************
*                         clsSpBoxSlot::PerformModuleCalibration               *
*                         ======================================               *
* PURPOSE  : This function is responsible for performing module calibration    *
* ARGUMENTS: None.                                                             *
* RETURN   : TRUE if successful, FALSE otherwise                               *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::PerformModuleCalibration(VOID)
{
    BOOL CalibStatus = FALSE;
    AssertBackup();

    if( CALIBOPT_AI == BOX->CalibOpt)
    {
        if(PerformSpAiCalibration())
        {
            CalibStatus = SPFlashCalibrationData(CALIBOPT_AI);
        }
    }
    else if( CALIBOPT_AO == BOX->CalibOpt)
    {
        if(AOPerformModuleCalibration())
        {
            CalibStatus = SPFlashCalibrationData(CALIBOPT_AO);
        }
        else
        {
            SetOp(AO_CH_START, OP_LOLIMIT);
        }

    }
    
    if (CalibStatus) 
    {  
        // Calibrtion is successful.
        TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibDone,MODULEINFO_WRITECOUNT);

#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalibration successful"));
#endif
        // Reboot the module so that the new 
        // calibration data gets loaded.

        PrintStr("\n\rCalibration successful"); 

        RebootIom();
    }

    CalibAll = FALSE;
    pSpShramBoxData->CalibAll = CalibAll;
    IolinkScsFifo.SendSCSCommand(SCS_CALIB_DISABLE);
    BOX->CalibOpt = CALIBOPT_NONE;
    return FALSE;
}

/*******************************************************************************
*                         clsSpBoxSlot::PerformSpAiCalibration                 *
*                         ====================================                 *
* PURPOSE  : This function is responsible for performing AI calibration        *
* ARGUMENTS: None.                                                             *
* RETURN   : TRUE if successful, FALSE otherwise                               *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::PerformSpAiCalibration(VOID){

    const UINT8 TOTAL_SAMPLES = 34;

    UINT8  ucCount;
    volatile UINT16 fZeroRefCount,fOneVoltCount,fFiveVoltCount;
    clsOlympicAverage CalInputAverage,ZeroRefAverage;


    if (1 == FACTCAL) 
    {   // If factory calibration is being performed
#ifdef DEBUG
        if (BOARDTYPE_PASSONE == BoardType) 
        {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Pass 1 board"));
        }
        else 
        {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tFactory calibration..Pass 2 board"));
        }
#endif
        // Wait till user press and release CALIBRATE switch on the IOTA.
        while (!CALIBRATE) 
        {   // Process any pending writes while waiting
            TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
            WriteDatabaseTask(TASKCONTEXT_ZERO); 
            // Abort calibration if cancel request was done
            if (FALSE == CalibAll) 
            {
                return FALSE;
            }
        }
        while (CALIBRATE) 
        {   // Process any pending writes while waiting
            TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
            WriteDatabaseTask(TASKCONTEXT_ZERO); 
            // Abort calibration if cancel request was done
            if (FALSE == CalibAll) 
            {
                return FALSE;
            }
        }
        BlinkLed(1);
        // Start with averaging 1V at calib inputs.
        for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) 
        {
            fOneVoltCount = SpAdc.GetRawData(SP_AI_IN_CALIB); 
            CalInputAverage.AddSample(fOneVoltCount);
            // Since we do not have Zero V ref Channel This code is commented every where
            //fZeroRefCount = SpAdc.GetRawData(SP_AI_IN_REF0);
            // once Factory Calibration is done need to remove this
           // ZeroRefAverage.AddSample(fZeroRefCount);  //Note:: Need to discuss with HW team about this step
        }

       // fZeroRefCount = ZeroRefAverage.GetResult(); //Note:: Need to discuss with HW team about this step
       // fOneVoltCount = CalInputAverage.GetResult() - fZeroRefCount; //Note:: Need to discuss with HW team about this step
        fOneVoltCount = CalInputAverage.GetResult();

#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f",
                                          ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(),
                                          fZeroRefCount));
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t1V Hi = %d Lo = %d Avg = %f+%f\n",
                                          CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                          fOneVoltCount,fZeroRefCount));
#endif
       // once Factory Calibration is done need to remove this
        if ((fOneVoltCount < SP_PASS1p5_ONE_VOLT_LOLIMIT) || 
            (fOneVoltCount > SP_PASS1p5_ONE_VOLT_HILIMIT)) 
        {
            // Post bad calibration reference softfail.
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
            CalibAll = FALSE; 
            return FALSE; // Abort calibration.
        }
    } 
    else { // Field calibration. Ensure that factory calibration data is present.
            
        if (AICalibrationGood != TRUE) 
        {
#ifdef DEBUG
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tDo factory calibration first"));
#endif
            CalibAll = FALSE; 
            return FALSE; // Abort calibration.
        }
#ifdef DEBUG
        if (BOARDTYPE_PASSONE == BoardType) 
        {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tField calibration..Pass 1 board"));
        }
        else 
        {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tField calibration..Pass 2 board"));
        }
#endif
    }
   
    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) 
    { // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }
    while (CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }
    BlinkLed(2);

    // Average 5V at calib inputs for both factory and field calibration.
    ZeroRefAverage.Initialize();
    CalInputAverage.Initialize(); 
    for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) 
    {
        fFiveVoltCount = SpAdc.GetRawData(SP_AI_IN_CALIB);
        CalInputAverage.AddSample(fFiveVoltCount);
        // Since we do not have Zero V ref Channel This code and related code is commented every where
        /*fZeroRefCount = SpAdc.GetRawData(SP_AI_IN_REF0);
        ZeroRefAverage.AddSample(fZeroRefCount);*/ //Note:: Need to discuss with HW team about this step
    }
    // once Factory Calibration is done need to remove this
    /*fZeroRefCount = ZeroRefAverage.GetResult();
    fFiveVoltCount = CalInputAverage.GetResult() - fZeroRefCount;*/ //Note:: Need to discuss with HW team about this step
    fFiveVoltCount = CalInputAverage.GetResult();

#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tZero Ref Hi = %d Lo = %d Avg = %f",
                                      ZeroRefAverage.GetHiSample(),ZeroRefAverage.GetLoSample(),
                                      fZeroRefCount));
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\t5V Hi = %d Lo = %d Avg = %f+%f\n",
                                      CalInputAverage.GetHiSample(),CalInputAverage.GetLoSample(),
                                      fFiveVoltCount,fZeroRefCount));
#endif

    // once Factory Calibration is done need to remove this
    if ((fFiveVoltCount < SP_PASS1p5_FIVE_VOLT_LOLIMIT) || 
        (fFiveVoltCount > SP_PASS1p5_FIVE_VOLT_HILIMIT)) 
    {
        // Post bad calibration reference softfail.
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,TRUE,0);
        CalibAll = FALSE; 
        return FALSE; // Abort calibration.
    }

    // Clear bad calibration reference softfail if any.
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_BADCALRF,FALSE,0);

    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }
    while (CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }
    BlinkLed(3);

    if (1 == FACTCAL) 
    { // if factory calibration
        CalibData.AICalibrationSlope = 4.0 / (fFiveVoltCount - fOneVoltCount);
        CalibData.AICalibrationOffset =  1.0 - (CalibData.AICalibrationSlope * fOneVoltCount);
    }
    else 
    { // if field calibration
        CalibData.AICalibrationSlope = (5.0 - CalibData.AICalibrationOffset) / (fFiveVoltCount);
    }

    // Validate reference voltages.
     volatile UINT8 index;
     for ( index = 1; index <= SP_NO_OF_REF_VOLTAGES; index++) 
     {
       volatile FLOAT32 fRefInput = (FLOAT32)SpAdc.GetRawData(SP_AI_IN_CALIB + index);
       // fZeroRefCount = (FLOAT32)SpAdc.GetRawData(SP_AI_IN_REF0); //Note:: Need to discuss with HW team about this step
       // fRefInput -= fZeroRefCount;

       //Note:: We do not have 5V CKVT, should this code be romoved
        if (SP_NO_OF_REF_VOLTAGES == index) 
        {
            // Save 5V reference limits for storing in flash.
            CalibData.f5VRefHiLimit = fRefInput + FIVE_VOLT_TOLERENCE_COUNT;
            CalibData.f5VRefLoLimit = fRefInput - FIVE_VOLT_TOLERENCE_COUNT;
        }
        volatile FLOAT32 RefInput = (fRefInput * CalibData.AICalibrationSlope) + CalibData.AICalibrationOffset;
#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCHKVT%d : %f ZeroCount : %f",
                                          index,(fRefInput * 1000),fZeroRefCount));
#endif
        if ((RefInput > SP_REFVOLTAGE_LIMITS[index - 1].fHiLimit) || 
            (RefInput < SP_REFVOLTAGE_LIMITS[index - 1].fLoLimit)) 
        {
#ifdef DEBUG
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCHKVT test failed"));
#endif
            CalibAll = FALSE;
            return FALSE;
        }
    }

    if (1 == FACTCAL) 
    {   // if factory calibration
        // Find individual channel zero drift offsets.
        for (UINT8 ucSlot = 1; ucSlot <= AI_MAXSLOTS; ucSlot++) 
        {
            ZeroRefAverage.Initialize();
            CalInputAverage.Initialize();
            for (ucCount = 0; ucCount < TOTAL_SAMPLES; ucCount++) 
            {
                FLOAT32 fChanInput = SpAdc.GetRawData(ucSlot);
                CalInputAverage.AddSample(fChanInput);
                
                /*fZeroRefCount = SpAdc.GetRawData(SP_AI_IN_REF0);
                ZeroRefAverage.AddSample(fZeroRefCount);*/
            }
            // fZeroRefCount = ZeroRefAverage.GetResult();
            //CalibData.AIChannelZeroDrift[ucSlot - 1] = CalInputAverage.GetResult() - fZeroRefCount;
            CalibData.AIChannelZeroDrift[ucSlot - 1] = CalInputAverage.GetResult();
#ifdef DEBUG
            if (ucSlot & 0x01) 
            {
                while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r"));
            }
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\tChan%d zero drift %f",ucSlot,
                                                                    CalibData.AIChannelZeroDrift[ucSlot - 1]));
#endif
        }
    }

    return TRUE; 
}

/*******************************************************************************
*                       clsSpBoxSlot::FlashCalibrationData                     *
*                       ===================================                    *
* PURPOSE  : This method will write calibration data into EEPROM               *
* ARGUMENTS: CalibOption - Calibration Option                                  *
* RETURN   : TRUE if successful, FALSE otherwise                               *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::SPFlashCalibrationData(CALIBOPT CalibOption) 
{
    UINT8 *ucBufferPtr;
    UINT8 ucModuleInfoBlockTop[FLASH_PROGRAM_BLOCK_SIZE];
    volatile UINT8 index = 0;
    volatile UINT8 addr = 0;
    // Initialize the buffers.
    for (UINT8 index = 0; index < FLASH_PROGRAM_BLOCK_SIZE; index++) 
    {
        ucModuleInfoBlockTop[index]    = 0xFF;
    }
    // First check if the SPI EEPROM is present on the app board. If the SPI 
    // EEPROM is present then store the data in SPI EEPROM else use FLASH.
    // Read the status register. Bits 2 and 3 are write protect bits and
    // always 0 as we do not protect it. If we see any of these bits ON,then
    // it is safe to assume that SPI device is not present.
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) 
    {
        PrintStr("\n\r EEPROM Detected:"); 

        // Fill the information at the top of the module info block.
        ucBufferPtr = ucModuleInfoBlockTop;
        if(CalibOption == CALIBOPT_AI)
        {
            *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefHiLimit;
            ucBufferPtr += sizeof(FLOAT32);
            *((FLOAT32 *)ucBufferPtr) = CalibData.f5VRefLoLimit;
            ucBufferPtr += sizeof(FLOAT32);
            *((FLOAT32 *)ucBufferPtr) = CalibData.AICalibrationSlope;
            ucBufferPtr += sizeof(FLOAT32);
            *((FLOAT32 *)ucBufferPtr) = CalibData.AICalibrationOffset;
            ucBufferPtr += sizeof(FLOAT32);
                                            
            for ( index = 0; index < (AI_MAXSLOTS); index++) 
            {
                *((FLOAT32 *)ucBufferPtr) = CalibData.AIChannelZeroDrift[index];
                ucBufferPtr += sizeof(FLOAT32);
            }
            addr = 0;
        }
        if(CalibOption == CALIBOPT_AO)
        {
            for (index = 0; index < 4; index++) 
            {
                *((FLOAT32 *)ucBufferPtr) = CalibData.CalibConstants[index];
                ucBufferPtr += sizeof(FLOAT32);
            }
            *((FLOAT32 *)ucBufferPtr) = CalibData.AOFactorySlope;
            ucBufferPtr += sizeof(FLOAT32);
            *((FLOAT32 *)ucBufferPtr) = CalibData.AOFactoryOffset;
            ucBufferPtr += sizeof(FLOAT32);
            *((FLOAT32 *)ucBufferPtr) = TestCount;
            ucBufferPtr += sizeof(FLOAT32);
            addr = 100;
        }

        // calculate Total number fo bytes to be copied to EEPROM
        UINT8 uCalDataBytes = ucBufferPtr - ucModuleInfoBlockTop + addr;
        // Reinit the pointer
        ucBufferPtr = ucModuleInfoBlockTop;
        //Enable the writes EEPROM 
        Eeprom.EnableWrite();
        //Start writing calibration constants to EEPROM.
        for (index = addr ; index < uCalDataBytes; index++) 
        {
            Eeprom.EnableWrite();
            Eeprom.WriteByte(0,index,*ucBufferPtr);
            ucBufferPtr++;
        }
        // Write Calibration complete

        Eeprom.EnableWrite();
        if(CalibOption == CALIBOPT_AI)
        {
            Eeprom.WriteByte(0,AI_CALIBRATION_DONE_ADD,AI_CALIBRATION_DONE);
        }
        else if(CalibOption == CALIBOPT_AO)
        {
            Eeprom.WriteByte(0,AO_CALIBRATION_DONE_ADD,AO_CALIBRATION_DONE);
        }
        Eeprom.EnableWrite();
        Eeprom.WriteByte(0,SP_EE_MODULEINFO_WRITE_FLAGS,0x5A);
        Eeprom.EnableWrite();
        Eeprom.WriteByte(0,SP_EE_MODULEINFO_WRITE_FLAGS+1,0x5A);
        UINT16 ModuleWriteCount;
        ModuleWriteCount = Eeprom.ReadUint16(0, SP_EE_MODULEINFO_WRITECOUNT)+1;
        
        if (0==ModuleWriteCount) 
        {
            ModuleWriteCount = 1;
        }
        
        Eeprom.EnableWrite();
        Eeprom.WriteByte(0,SP_EE_MODULEINFO_WRITECOUNT,(UINT8)ModuleWriteCount);
        Eeprom.EnableWrite();
        Eeprom.WriteByte(0,SP_EE_MODULEINFO_WRITECOUNT+1,(UINT8)(ModuleWriteCount>>8));
        // calculate and write the checksum
        volatile UINT16 Chksum = Eeprom.ComputeEepromChecksum();
        Eeprom.EnableWrite();
        Eeprom.WriteByte(1,EE_CKSUM_ADD,(UINT8)Chksum);
        Eeprom.EnableWrite();
        Eeprom.WriteByte(1,EE_CKSUM_ADD+1,(UINT8)(Chksum>>8));
        //Disable the writes EEPROM 
        Eeprom.DisableWrite();
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x108,(UINT32)Eeprom.ReadByte(0,SP_EE_MODULEINFO_WRITECOUNT)); 
        
        return TRUE;
    }
    
   
    PrintStr("\n\rEEPROM Not Detected, FLASHING FAILED:"); 

    return FALSE;
}

/*******************************************************************************
*                       clsSpBoxSlot::SPLoadCalibrationData                    *
*                       ==================================                     *
* PURPOSE  : This function will read the calibration data from EEPROM and store*
*            into local sturcture                                              *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES    :                                                                   *
*******************************************************************************/
VOID clsSpBoxSlot::SPLoadCalibrationData(VOID) {

    while (RETURNSTATUS_COMPLETE != EepromCountDiagnostics()); 
    #ifndef DEBUG
        PrintStr("\n\rT009");
    #endif

        while (RETURNSTATUS_COMPLETE != EepromWrFlagDiagnostics()); 
    #ifndef DEBUG
        PrintStr("\n\rT010");
    #endif

        while (RETURNSTATUS_COMPLETE != EepromChksmDiagnostics()); 
    #ifndef DEBUG
        PrintStr("\n\rT011");
    #endif

    BOOL ChckSumVal = FALSE;
    // First check if the SPI EEPROM is present on the app board. If the SPI 
    // EEPROM is present then check  if the data is valid. If the data in SPI
    // is not VALID then check if the calibration data is present in FLASH. If
    // yes load the data or declare Invalid calibration data.
    volatile UINT8 FloatSize = sizeof(FLOAT32);
    volatile UINT8 MemLocIndex = 0;
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) 
    {
        PrintStr("\n\rEEPROM Detected after boot"); 
        if (Eeprom.ValidateEepromChecksum()) 
        {
              PrintStr("\n\rChecksum Passed");
              ChckSumVal = TRUE;
        }
        else
        {
            PrintStr("\n\rChecksum failed");
        }

        if(ChckSumVal == TRUE)
        {
            if (AI_CALIBRATION_DONE == Eeprom.ReadByte(0,AI_CALIBRATION_DONE_ADD)) 
            {
                // Check if Calibration data is good
                AICalibrationGood = TRUE;
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,FALSE,0);
                CalibData.f5VRefHiLimit = Eeprom.ReadFloat(0,MemLocIndex);
                MemLocIndex = MemLocIndex + FloatSize;
                CalibData.f5VRefLoLimit = Eeprom.ReadFloat(0,MemLocIndex);
                MemLocIndex = MemLocIndex + FloatSize;
                CalibData.AICalibrationSlope  = Eeprom.ReadFloat(0,MemLocIndex);
                MemLocIndex = MemLocIndex + FloatSize;
                CalibData.AICalibrationOffset = Eeprom.ReadFloat(0,MemLocIndex);
                MemLocIndex = MemLocIndex + FloatSize;
                
                for (UINT8 ucSlotNum = 0; ucSlotNum < AI_MAXSLOTS; ucSlotNum++) 
                {
                    CalibData.AIChannelZeroDrift[ucSlotNum] = 
                        Eeprom.ReadFloat(0,(MemLocIndex +(ucSlotNum*FloatSize)));
                }
            }
            else
            {
                PrintStr("\n\r AI Not Calibrated");
            }
        }
            
        if (ChckSumVal == TRUE)
        {
            if (AO_CALIBRATION_DONE == Eeprom.ReadByte(0,AO_CALIBRATION_DONE_ADD)) 
            {
                AOCalibrationGood = TRUE;
                /// For AO Calibration Data the Starting Address is 100
                MemLocIndex = 100;
                
                for (UINT8 ucCount = 0; ucCount < 4; ucCount++) 
                {
                    CalibData.CalibConstants[ucCount] = Eeprom.ReadFloat(0,MemLocIndex);
                    MemLocIndex = MemLocIndex + FloatSize;
                }
                CalibData.AOFactorySlope = Eeprom.ReadFloat(0,MemLocIndex);
                MemLocIndex = MemLocIndex + FloatSize;
                CalibData.AOFactoryOffset = Eeprom.ReadFloat(0,MemLocIndex);
                MemLocIndex = MemLocIndex + FloatSize;
                TestCount = Eeprom.ReadFloat(0,MemLocIndex);
                PrintStr("ET");
                PrintVal(TestCount);

                FLOAT32 fB1_L = 0.0, fB0_L = 0.0, fB1_O = 0.0, fB0_O = 0.0;
                FLOAT32 fB1LInv = 0.0, fB1Inv = 0.0, fB0_OInv = 0.0, fB0_LInv = 0.0;

                fB1_O = CalibData.CalibConstants[0];
                fB0_O = CalibData.CalibConstants[1];
                //The loopback constants were normalized while saving.
                //De-Normalize them before restoring for use.
                fB1_L = CalibData.CalibConstants[2] * CalibData.AOFactorySlope;
                fB0_L = CalibData.CalibConstants[3]   + CalibData.AOFactoryOffset;
                fB1Inv  = 1 / fB1_O;
                fB1LInv = 1 / fB1_L;
                fB0_OInv = - fB0_O / fB1_O;
                fB0_LInv = - fB0_L / fB1_L;

                AO_SLOT(AO_CH_START)->SetB1O(fB1_O);
                AO_SLOT(AO_CH_START)->SetB0O(fB0_O);
                AO_SLOT(AO_CH_START)->SetB1Inv(fB1Inv);
                AO_SLOT(AO_CH_START)->SetB0Inv(fB0_OInv);
                AO_SLOT(AO_CH_START)->SetB1L(fB1_L);
                AO_SLOT(AO_CH_START)->SetB0L(fB0_L);
                AO_SLOT(AO_CH_START)->SetB1LInv(fB1LInv);
                AO_SLOT(AO_CH_START)->SetB0LInv(fB0_LInv);

                HiZeroHiHi = (-21 - CalibData.AOFactoryOffset) / CalibData.AOFactorySlope;
                
                TestCountHi   =  TestCount * 1.02; // +2%
                TestCountHiHi =  TestCount * 1.04; // +4%
                TestCountLo   =  TestCount * 0.98; // -2%
                TestCountLoLo =  TestCount * 0.96; // -4%

                Dac50Percent  =  50 * fB1LInv + fB0_LInv;
                Dac100Percent = (UINT16)fB1LInv * 100.0 + fB0_LInv;
                Dac4PercentofFullScale =  (UINT16)(Dac100Percent * 4)/100;

                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x106);
                return;
            }
            else
            {
                PrintStr("\n\rAO Not Calibrated");
            }
        }

    }
    else
    {
        PrintStr("\n\rEEPROM Not Detected after boot, Calib data loading failed"); 
    }

    if ((FALSE == AICalibrationGood) || (FALSE == AOCalibrationGood))  // Calibration data is bad or not available.
    {  
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,TRUE,0);

        // Load default constants for diagnostic/debug purposes.
        AO_SLOT(AO_CH_START)->SetB1Inv(DEFAULT_OUTPUT_SLOPE);
        AO_SLOT(AO_CH_START)->SetB0Inv(DEFAULT_OUTPUT_OFFSET);
        AO_SLOT(AO_CH_START)->SetB1LInv(DEFAULT_LOOPBACK_SLOPE);
        AO_SLOT(AO_CH_START)->SetB0LInv(DEFAULT_LOOPBACK_OFFSET);
    }
    else // return ADOUTCAL softfail. 
    {  
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADOUTCAL,FALSE,0);
    }
}

/*******************************************************************************
*                       clsSpBoxSlot::AOPerformModuleCalibration               *
*                       ========================================               *
* PURPOSE  : This function is responsible for AO channel Field & Factory       *
*            calibration                                                       *
* ARGUMENTS: None.                                                             *
* RETURN   : TRUE if successful, FALSE otherwise                               *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
BOOL clsSpBoxSlot::AOPerformModuleCalibration(VOID)
{
    BOOL bResult = FALSE;
    //Drive all channels to DAC 0 state.
    SetOp(AO_CH_START, EXTENDED_OP_LOLIMIT);

    //Verify HIZERO readings 
    AO_SLOT(AO_CH_START)->OpenLoopbackMux(2,TRUE);
    HiZero = (UINT16)DoSuccessiveApproximation(TRUE);
    AO_SLOT(AO_CH_START)->CloseLoopbackMux(2);

    if((HiZero < MINHIZERO_LOOPBACK_DACCOUNT) || 
       (HiZero > MAXHIZERO_LOOPBACK_DACCOUNT)) 
    {
        //Drive all channels to -6.9
        SetOp(AO_CH_START, OP_LOLIMIT);
        CalibAll = FALSE;
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,TRUE,0);
        return FALSE;
    }
    else 
    {
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_VZERO_FL,FALSE,0);
    }
    //Test what Calibration to perform

    if(FACTCAL == 1)
    {
        FieldCalibOn = FALSE;
        bResult = AOPerformFactoryCalibration();
    }
    else
    {
        FieldCalibOn = TRUE;
        bResult =  AOPerformFieldCalibration();
    }

    FieldCalibOn = FALSE;
    return bResult;
}

/*******************************************************************************
*                        clsSpBoxSlot::AOPerformFactoryCalibration             *
*                        =========================================             *
* PURPOSE  : This function is responsible for performing AO Channel factory    *
*            calibration                                                       *
* ARGUMENTS: None.                                                             *
* RETURN   : TRUE if successful, FALSE otherwise                               *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::AOPerformFactoryCalibration(VOID) {
    volatile BOOL    bResult = TRUE;
    // Switch off the status LED 
    LED_PINS = STATUSLED_OFF;

    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) 
    { // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }
    
    while (CALIBRATE) 
    { // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }

    // Select multipliexer input from MUX 1 calibration voltage - SNSCAL
    AO_SLOT(AO_CH_START)->OpenLoopbackMux(0,TRUE);
    //Perform Limit check with the Max/Min value of 1V
    bResult = CheckRefVoltage(MAX_ONE_V_OUTPUT_DACCOUNT) & 
              CheckRefVoltage(MIN_ONE_V_OUTPUT_DACCOUNT);
    if(!bResult) 
    {
        AO_SLOT(AO_CH_START)->CloseLoopbackMux(0);
        return FALSE;
    }

    //Perform A to D Conversion of 1V value present on SNSCAL
    volatile UINT16 us1vDacCount = (UINT16)DoSuccessiveApproximation(TRUE);
    //We are done with the 1V calibration reference, Flash the status LED to 
    //indicate that the tech can now change the reference voltage to 5V.
    BlinkLed(1);
    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }

    while (CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
       WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }

    //Perform Limit check with the Max/Min value of 5V
    bResult = CheckRefVoltage(MAX_FIVE_V_OUTPUT_DACCOUNT) & 
              CheckRefVoltage(MIN_FIVE_V_OUTPUT_DACCOUNT);
    
    if(!bResult) 
    {
        AO_SLOT(AO_CH_START)->CloseLoopbackMux(0);
        return FALSE;
    }
    //Perform A to D Conversion of 5V value present on SNSCAL
    volatile UINT16 us5vDacCount = (UINT16)DoSuccessiveApproximation(TRUE) / GAIN_COMP;
    //Compute the loopback slope and offset with the above readings
    CalibData.AOFactorySlope = (FLOAT32)((100.0 - 0.0)/(us5vDacCount - us1vDacCount));
    //Compute the constant, c = y - mx
    CalibData.AOFactoryOffset = 0.0 - CalibData.AOFactorySlope * us1vDacCount;

    //Blink the LEDs
    BlinkLed(2);
    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }

    while (CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }
    BlinkLed(3);
    AO_SLOT(AO_CH_START)->CloseLoopbackMux(0);

    // SNSV1
    AO_SLOT(AO_CH_START)->OpenLoopbackMux(1,TRUE);
    //Now perform the slot calibration procedure for each slot
    //Drive channels to DAC 0 state.
 
    //calculate the constants. Done in reverse order. 
    AO_SLOT(AO_CH_START)->SetOutDACImg(0);
    AO_SLOT(AO_CH_START)->DriveOutput(CalibrationWithExtendedDelay);
    //Rest of the channels can be charged for 150 us
    AO_SLOT(AO_CH_START)->SetOutDACImg(0);
    AO_SLOT(AO_CH_START)->DriveOutput(CalibrationWithMinimumDelay);
    bResult = AO_SLOT(AO_CH_START)->ComputeCalibrationConstants(CalibData.AOFactorySlope,
                                                           CalibData.AOFactoryOffset);
                              
    //Drive channel to DAC 0 state.
    AO_SLOT(AO_CH_START)->SetOutDACImg(0);
    AO_SLOT(AO_CH_START)->DriveOutput(CalibrationWithMinimumDelay);
    AO_SLOT(AO_CH_START)->CloseLoopbackMux(1);
    //Perform Limit check with the Max/Min value of Test Voltage if everything is Ok

    //For CalChek Channel
    AO_SLOT(AO_CH_START)->OpenLoopbackMux(3,TRUE);  
    TestCount = ((clsSpBoxSlot *)pDatabase[0])->DoSuccessiveApproximation(TRUE);
    
    PrintStr("CT");
    PrintVal(TestCount);

    if (TRUE == bResult) 
    {
      bResult = CheckRefVoltage(MAX_TEST_VOLTAGE_OUTPUT_DACCOUNT) & 
                CheckRefVoltage(MIN_TEST_VOLTAGE_OUTPUT_DACCOUNT);
    }
    AO_SLOT(AO_CH_START)->CloseLoopbackMux(3);
    
    return bResult;
}

/*******************************************************************************
*                        clsSpBoxSlot::AOPerformFieldCalibration               *
*                        =======================================               *
* PURPOSE  : This function is responsible for performing AO Channel Field      *
*            calibration                                                       *
* ARGUMENTS: None.                                                             *
* RETURN   : TRUE if successful, FALSE otherwise                               *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::AOPerformFieldCalibration(VOID) {                                                                      

    //Abort if factory calibration is not yet done
    AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EECKSMER,!AOCalibrationGood,0);
    if(!AOCalibrationGood) 
    {
        return FALSE;
    }

    DisableOutputs();
    BOOL bResult = TRUE;
    //Switch off the status LED
    LED_PINS = STATUSLED_OFF;

    // Wait till user press and release CALIBRATE switch on the IOTA.
    while (!CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }
    while (CALIBRATE) 
    {   // Process any pending writes while waiting
        TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);
        WriteDatabaseTask(TASKCONTEXT_ZERO); 
        // Abort calibration if cancel request was done
        if (FALSE == CalibAll) 
        {
            return FALSE;
        }
    }

    // Select multipliexer input from MUX 1 calibration voltage - SNSCAL
    AO_SLOT(AO_CH_START)->OpenLoopbackMux(0,TRUE);
    //Perform Limit check with the Max/Min value of 5V
    bResult = CheckRefVoltage(MAX_FIVE_V_OUTPUT_DACCOUNT) & 
              CheckRefVoltage(MIN_FIVE_V_OUTPUT_DACCOUNT);
    if(!bResult) 
    {
        AO_SLOT(AO_CH_START)->CloseLoopbackMux(0);
        EnableOutputs();
        return FALSE;
    }
    //Revise B1_L
    UINT16 ui5VCount = DoSuccessiveApproximation(TRUE) / GAIN_COMP;
    volatile FLOAT32 fOldSlope = CalibData.AOFactorySlope;
    CalibData.AOFactorySlope = (100.0 - CalibData.AOFactoryOffset) / ui5VCount;
                             
    //Close SNSCAL1
    AO_SLOT(AO_CH_START)->CloseLoopbackMux(0);
    //Drive all channels to DAC 0 state.
    SetOp(AO_CH_START, EXTENDED_OP_LOLIMIT);
    //Blink the LEDs
    BlinkLed(2);

    AO_SLOT(AO_CH_START)->OpenLoopbackMux(1,TRUE);


    if(FALSE == (bResult = AO_SLOT(AO_CH_START)->ComputeCalibrationConstants(
                                            (AO_SLOT(AO_CH_START)->GetB1L() / 
                                             fOldSlope * CalibData.AOFactorySlope),
                                             AO_SLOT(AO_CH_START)->GetB0L()))) 
    {
        AO_SLOT(AO_CH_START)->CloseLoopbackMux(1);
    }
    
    AO_SLOT(AO_CH_START)->CloseLoopbackMux(1);
    EnableOutputs();
    return bResult;
}

/*******************************************************************************
*                        clsSpBoxSlot::GetInitReq                              *
*                        ========================                              *
* PURPOSE  : This function returns the TRUE if initreq is set                  *
* ARGUMENTS: None.                                                             *
* RETURN   : TRUE if initreq is set, FALSE otherwise                           *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsSpBoxSlot::GetInitReq(UINT8) 
{ 
    if(SpOutPutScanRec.InitReq & 0x10)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/*******************************************************************************
*                            clsTimer::clsTimer                                *
*                            ==================                                *
* PURPOSE  : This rotuine is the constructor for timer class                   *
*            The timer states are initialized and FRC counts set to 0.         *
* ARGUMENTS: NONE                                                              *
* RETURN   : NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
clsTimer::clsTimer()
{
    for (UINT8 i=0; i<MAX_TIMERS; i++)
    {
        TimerArr[i].TimerState = TIMER_FREE;
    }
    LastTpu2Count = 0;
    FRC_Time.frc_count = 0;
}

/*******************************************************************************
*                            clsTimer::StartTimer                              *
*                            ====================                              *
* PURPOSE  : The timer is started and the event to be flagged after expiry of  *
             the timeris stored.                                               *
* ARGUMENTS: Delay - Timer Delay                                               *
*            Event - Timer Event                                               *
* RETURN   : Returns FALSE if no timer is available. Else TRUE                 *
* NOTES    :                                                                   *
*******************************************************************************/
BOOL clsTimer::StartTimer(UINT16 Delay, enmChanProcEvent Event)
{
    strTimer *FreeTimer = NULL;
    BOOL RetVal = FALSE;
    if((FreeTimer = FindFreeTimer()) != NULL)
    {
        FreeTimer->TimerCount = GetFRC();
        FreeTimer->ExpiryCount = FreeTimer->TimerCount + (UINT32) ((FLOAT32)Delay * TPU2_TICKS_IN_MICROSECOND);
        FreeTimer->TimerState = TIMER_RUNNING;
        FreeTimer->PostEvent = Event;
        RetVal = TRUE;
    }
    else
    {
        HardFail(HF_INVPROGRAMEXEC,SPBOXSLOT_HPP,__LINE__);
    }
    return RetVal;
}

/*******************************************************************************
*                            clsTimer::CheckTimerEvent                         *
*                            =========================                         *
* PURPOSE  : Checks and returns any outstanding timer event.                   *
* ARGUMENTS: NONE                                                              *
* RETURN   : Returns EVENT_NONE if no expiry is pending. Else returns the event*
* NOTES    :                                                                   *
*******************************************************************************/
enmChanProcEvent clsTimer::CheckTimerEvent()
{
    UINT32 CurrCount = GetFRC();
    for(UINT8 i = 0; i<MAX_TIMERS; i++)
    {
        if(TimerArr[i].TimerState == TIMER_RUNNING)
        {
            if( (TimerArr[i].ExpiryCount < TimerArr[i].TimerCount) )
            {
                // By the expire time, the FRC wraps around
                if( (CurrCount >= TimerArr[i].ExpiryCount) && (CurrCount < TimerArr[i].TimerCount) )
                {
                    TimerArr[i].TimerState = TIMER_FREE;
                    return TimerArr[i].PostEvent;
                }
            }
            else
            {
                if( (CurrCount >= TimerArr[i].ExpiryCount) || (CurrCount <= TimerArr[i].TimerCount) )
                {
                    TimerArr[i].TimerState = TIMER_FREE;
                    return TimerArr[i].PostEvent;
                }
            }
        }
    }

    return EVENT_NONE;
}

/*******************************************************************************
*                            clsTimer::GetFRC                                  *
*                            ================                                  *
* PURPOSE  : Updates the FRC count and returns it.                             *          
* ARGUMENTS: NONE                                                              *
* RETURN   : Returns the current FRC count.                                    *
* NOTES    :                                                                   *
*******************************************************************************/
UINT32 clsTimer::GetFRC()
{
    FRC_Time.WORD.Tpu2Count = TPU2_TCNT;
    if(FRC_Time.WORD.Tpu2Count < LastTpu2Count)
    {
        FRC_Time.WORD.ClockHighWord++;
    }
    LastTpu2Count = FRC_Time.WORD.Tpu2Count;
    return FRC_Time.frc_count;
}

/*******************************************************************************
*                            clsTimer::GetElapsedCount                         *
*                            =========================                         *
* PURPOSE  : Returns elapsed time from given time                              *
* ARGUMENTS: StartingCount - Timer Starting Count                              *
* RETURN   : Returns the elapsed time in us                                    *
* NOTES    :                                                                   *
*******************************************************************************/
UINT32 clsTimer::GetElapsedCount(UINT32 StartingCount)
{
    UINT32 CurrentCount = GetFRC();
    if(CurrentCount < StartingCount)
    {
        // timer wrapped
        return ( (MAXUINT32 - StartingCount) + CurrentCount);
    }
    else
    {
        return (CurrentCount - StartingCount);
    }
}

/*******************************************************************************
*                            clsTimer::FindFreeTimer                           *
*                            =======================                           *
* PURPOSE  : Finds the free timer from the available timers.                   *
* ARGUMENTS:                                                                   *
* RETURN   : Returns the pointer to a free timer. Else returns NULL.           *
* NOTES    :                                                                   *
*******************************************************************************/
strTimer * clsTimer::FindFreeTimer()
{
    strTimer * RetVal = NULL;
    for(UINT8 i = 0; i<MAX_TIMERS; i++)
    {
        if(TimerArr[i].TimerState == TIMER_FREE)
        {
            RetVal = &TimerArr[i];
            break;
        }
    }
    return RetVal;
}
