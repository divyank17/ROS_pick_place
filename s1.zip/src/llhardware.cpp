/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : llhardware.cpp                                              *
*    Description : LLMUX hardware encapsulation.                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "llmuxmain.h"
/*******************************************************************************
*                                Initialize                                    *
*                                ==========                                    *
* PURPOSE: Initializes the NS-16550 FPGA UARTs and UART Lite                   *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
//TBD: Add more initializations here
VOID clsLLMuxHardware::Initialize(VOID) {
    for (UINT8 ucCount = 0; ucCount < NO_OF_FTA; ucCount++) { 
        FTA_UART(ucCount).RESET               = 1;   //Reset the UART.
        FTA_UART(ucCount).FIFO_ENBL           = 1;   //FIFO operation
        FTA_UART(ucCount).REQUEST_TO_SEND     = 0;   //Disable Tx
        FTA_UART(ucCount).EVEN_PARITY_SELECT  = 1;   //Even parity selected, Parity is 0 for all.
        FTA_UART(ucCount).PARITY_ENBL         = 1;   //1 bit parity
        FTA_UART(ucCount).STOP_BITS_SELECT    = 0;   //1 stop bit
        FTA_UART(ucCount).STICK_PARITY_SELECT = 1;   //Stick parity enabled.
        FTA_UART(ucCount).BITS_PER_CHAR       = FTA_UART_8BITS_PER_CHAR;
        FTA_UART(ucCount).INTR_ENBL_REGISTER  = DISABLE;//Disable all UART interrupts 
        //Select the FIFO control register to enable write access
        FTA_UART(ucCount).DVSR_LATCH_ACCESS   = 1;
        FTA_UART(ucCount).DMA_MODE_SELECT     = 0;   //Mode 0 operation
        FTA_UART(ucCount).RCV_FIFO_TRIG_LEVEL = 1;   //Interrupt after 4 Rx bytes
        FTA_UART(ucCount).RCV_FIFO_CLEAR      = 1;   //Clear Rx fifo
        FTA_UART(ucCount).XMT_FIFO_CLEAR      = 1;   //Clear Tx fifo
        //Deselect the FIFO control register to enable IIR
        FTA_UART(ucCount).DVSR_LATCH_ACCESS   = 0;
        Response[ucCount].LONG = 0;
        CommandHistory[ucCount]= REQ_INVALID;
    }
    // Configure buad rate register for FTA baud rate (9600 bps)
    // Baudrate register value = DUART clock frequency / (required baud rate * 16)
    // Baudrate register value = 24000000 / (9600 * 16) = 156.25 ~ 0x009C
    FTA_BAUDRATE_REGISTER.HIBYTE = 0x00;
    FTA_BAUDRATE_REGISTER.LOBYTE = 0x9C;

    //UART Lite initialization
    UART_LITE.RESET_RX_FIFO = ENABLE; //Clear Rx Fifo
    UART_LITE.RESET_TX_FIFO = ENABLE; //Clear Tx Fifo
    UART_LITE.ENABLE_INTR   = DISABLE;//Disable UART Lite interrupts
    ADC_SPI.IGER            = DISABLE;//Disable SPI interrupts
}
/*******************************************************************************
*                                clsLLMuxHardware                              *
*                                ================                              *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsLLMuxHardware::clsLLMuxHardware() {
    Initialize();
}
/*******************************************************************************
*                                  ComputeChecksum                             *
*                                  ===============                             *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Typical execution time - 1.33 us                                      *
*******************************************************************************/
UINT8 clsLLMuxHardware::ComputeChecksum(UINT32 Message) {
    BOOL bLsb = 0;
    SCIMESSAGE Msg; UINT8 ChSum = 0;
    Msg.LONG = Message & 0xFFFFFF00;//Take first 3 bytes
    for(UINT8 ucIndex = 0; ucIndex < SCIMSGSIZE-1; ucIndex++) {
        bLsb = (ChSum = ChSum ^ Msg.BYTE[ucIndex]) & 0x01;
        ChSum = ((ChSum >> 1) | (bLsb ? 0x80 : 0x00));
    }
    return ChSum;
}
/*******************************************************************************
*                                CreateRequest                                 *
*                                =============                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsLLMuxHardware::CreateAndSendRequest(UINT8 FtaNum,SCI_CMDS Cmd,UINT8 ChanNum) {
    SCIMESSAGE Request; Request.LONG  = 0;
    Request.Const = 1;
    if(REQ_LOADCONFIGDATA == Cmd) {
        UINT8 AbsoluteChanNum = MAXSLOTS_PER_FTA * FtaNum + ChanNum + 1;
        if (SENSRTYP_RTD != SLOT(AbsoluteChanNum)->GetSensrTyp())
            Request.OtdEn = SLOT(AbsoluteChanNum)->GetOwdEnable();
        Request.Data    = (UINT8)SLOT(AbsoluteChanNum)->GetPvChar();
        SLOT(AbsoluteChanNum)->SetInitFlg(TRUE);
    }
    else if(REQ_FREQSEL == Cmd) {
        Request.Data = BOX->GetFreq6050(); 
    }
    Request.FtaId    = BOX->GetFtaUnitId(FtaNum);
    Request.Command  = Cmd;
    Request.ChanNum  = ChanNum;
    CommandHistory[FtaNum] = Cmd;
    RequestTrace[FtaNum] = Request.LONG;
    SendRequest(FtaNum,Request.LONG);
}
/*******************************************************************************
*                                  SendRequest                                 *
*                                  ===========                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: Typical execution time - 5.3 us                                       *
*******************************************************************************/
VOID clsLLMuxHardware::SendRequest(UINT8 FtaNum,UINT32 Message) {
    if (FtaNum < NO_OF_FTA) {
        SCIMESSAGE Msg; Msg.LONG = Message;
        Msg.CheckSum = ComputeChecksum(Message);
        TimeoutFlag[FtaNum] = 1;
        Response[FtaNum].LONG = 0;
        //Select the FIFO control register to enable write access
        FTA_UART(FtaNum).DVSR_LATCH_ACCESS   = 1; 
        //Clear the Tx FIFO before the transmission
        FTA_UART(FtaNum).XMT_FIFO_CLEAR      = 1;   //Clear Tx fifo
        FTA_UART(FtaNum).RCV_FIFO_CLEAR      = 1;     //Clear Fifo
        //Deselect the FIFO control register to enable IIR access
        FTA_UART(FtaNum).DVSR_LATCH_ACCESS   = 0; 
        UINT8 ucSaveExr = get_imask_exr();
        // Disable all interrupts before pushing 4 bytes in the Tx FIFO.
        // This is required because if an IOL interrupt occurs before all
        // 4 bytes forming the request have been added to the FIFO, it may cause
        // a latency that the FTA may interpret as invalid communication and not
        // respond. This may result in NO RESPONSE errors from FTA.
        FTA_UART(FtaNum).REQUEST_TO_SEND = 1;//Enable transmitter.TBD:Disb intrpt?
        set_imask_exr(LVLPRI_HIGHEST);
        for (UINT8 ucCount = 0; ucCount < SCIMSGSIZE; ucCount++)
            FTA_UART(FtaNum).XMTHOLD_REGISTER = Msg.BYTE[ucCount];
        // Restore the old interrupt priority level
        set_imask_exr(ucSaveExr);
        FTA_UART(FtaNum).XMTREGEMPTY_INTR_ENBL = ENABLE; //Enable Tx interrupt
        FTA_UART(FtaNum).RCVLINESTS_INTR_ENBL  = DISABLE;//Disable Rx line status interrupt
        FTA_UART(FtaNum).RCVDATAAVBL_INTR_ENBL = DISABLE;//Disable Rx data available interrupt
    }
}
/*******************************************************************************
*                                CopyRxFromFifo                                *
*                                ==============                                *
* PURPOSE: Copies the response in response buffer of Fta                       *
* ARGUMENTS: Fta Number                                                        *
* RETURN:                                                                      *
* NOTES: Typical execution time - 23us                                         *
*******************************************************************************/
VOID clsLLMuxHardware::CopyRxFromFifo(UINT8 FtaNum) {
    UINT8 RxCount = 0;
    while(FTA_UART(FtaNum).DATA_READY && RxCount < SCIMSGSIZE)
        Response[FtaNum].BYTE[RxCount++] = FTA_UART(FtaNum).RCVBUF_REGISTER;
    TimeoutFlag[FtaNum] = (SCIMSGSIZE != RxCount);
    if(SCIMSGSIZE != RxCount) {
        TraceLog.AddToTrace(TRACEID_GENERIC,bcLLMuxBadRxCount,RxCount);
    }
}
