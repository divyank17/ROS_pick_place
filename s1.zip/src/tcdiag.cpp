/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcdiag.cpp                                                  *
*    Description : Implements common diagnostics                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_SVP
#include "svpmain.h"
#else
#include "spmain.h"
#endif

/*******************************************************************************
*                                EXTERNAL VARIABLES                            *
*******************************************************************************/
extern BOOL FactryModeWDTUTest;
extern clsIoLinkFifo AppScsFifo;

#ifdef H8S
extern BOOL HWRevCodeWriteInProgress;
#endif

//For SVP EEPROM is used only on DSC 
//For SP EEPROM is used only on H8S
#if  (defined(IOMTYPE_SVP) && defined(DSC)) || (defined(IOMTYPE_SP) && defined(H8S))
extern clsEeprom        Eeprom;
#endif

/*******************************************************************************
*                                EXTERNAL FUNCTIONS                            *
*******************************************************************************/
extern "C" BOOL _TestCPURegisters(VOID);

/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/
UINT32 g_ulIntTestLocation  = INTERNAL_RAM_START_ADDRESS;
UINT32 g_ulExtTestLocation  = EXTERNAL_RAM_START_ADDRESS;
BOOL gbWdtIntAsserted = FALSE;

#ifdef DSC
BOOL FactryModeWDTUTest;
#endif

#ifdef IOMTYPE_SP
#ifdef H8S
UINT32 gWdtRefTimerCount = 0;
#endif
#endif

//This variable used created on sharedram, where both H8S and DSC share each other,
//both handshake each other during the startup to make sure booted in specific order
UINT16 *uHandeShakeState = (UINT16*)HAND_SHAKE_ADDRESS;

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
// Initialize Diagnostic routines table
const DIAGROUTINE tblDiagRoutines[] =  {
    CPUDiagRoutine,
    FlashContentsDiagRoutine
};

//Find the size of diagnostic table 
const UINT8 DIAGROUTINECOUNT = (UINT8)((sizeof(tblDiagRoutines))/sizeof(DIAGROUTINE));

/*******************************************************************************
*                                   METHODS                                    *
*******************************************************************************/

/*******************************************************************************
*                                  PrintStr                                    *
*                                  ========                                    *
* PURPOSE   : Print power-on-self-test results to the debug port.              *
* ARGUMENTS : Pointer to the string to be printed.                             *
* RETURN    : None.                                                            *
* NOTES     : This print results are used by factory test engineers.           *
*******************************************************************************/
#ifdef H8S

#ifndef DEBUG

VOID PrintStr(const CHAR *a_cstrPrint) 
{

    SCIC1_TE = ENABLE;  // enable SCI1 transmitter
    SCIC1_TEND = 0;

    while (*a_cstrPrint)
    {
        SCIC1_TDR = *a_cstrPrint++;
        SCIC1_TDRE = 0; //Clear the empty flag. 
        while (!SCIC1_TDRE);//Waiting till TDR is empty
    }
    
    while (!SCIC1_TEND);// wait till last char tx is completed.
    SCIC1_TE = DISABLE;  // disable SCI1 transmitter
} 

VOID scia_xmit(char ch)
{
    SCIC1_TDR = ch;
    SCIC1_TDRE = 0; //Clear the empty flag. 
    while (!SCIC1_TDRE);//Waiting till TDR is empty
    while (!SCIC1_TEND);// wait till last char tx is completed.
}

VOID Convert_Dec_char_send(UINT32 a)
{
    UINT32 b;
    int loop;
    UINT32 array[10];
    UINT32 x;
    loop =0;
    while (a>9)
    {
        b=a/10;
        b=a-(b*10);
        b= 48+b;
        a=a/10;
        array[loop] = b;
        loop++;
    }
    a= 48+a;
    array[loop] = a;
    a=loop;
    
    for(x=0;x<=loop;x++)
    {
        scia_xmit(array[a]);
        a--;
    }
}

VOID Convert_Dec_char_send1(UINT32 a)
{
    UINT32 b;
    volatile int loop;
    UINT32 array[10];
    UINT32 x;
    loop =0;

    for(loop=0;loop<4;loop++)
    {
        b=a/10;
        b=a-(b*10);
        b= 48+b;
        a=a/10;
        array[loop] = b;
    }

    a=loop-1;

    for(x=0;x<loop;x++)
    {
        scia_xmit(array[a]);
        a--;
    }
}
VOID PrintVal(FLOAT32 flNumber)
{
    SCIC1_TE = ENABLE;  // enable SCI1 transmitter

    FLOAT32 flNum=flNumber;
    UINT32 iNum;

    if(flNum<0)
    {
        scia_xmit('-');
        flNum=(-1)*flNum;
    }

    iNum= (UINT32)flNum;
    Convert_Dec_char_send((UINT32)(iNum));
    iNum= (UINT32)((10000*flNum)-iNum*10000);
    scia_xmit('.');
    Convert_Dec_char_send1((UINT32)(iNum));
    scia_xmit(' ');
    scia_xmit('\n');
    scia_xmit(0xD);

    SCIC1_TE = DISABLE;  // disable SCI1 transmitter

}

#endif //#ifndef DEBUG

#endif //#ifdef H8S

/*******************************************************************************
*                                 TestRamCell                                  *
*                                 =============                                *
* PURPOSE:                                                                     *
*    Do RAM contents diagnostic in a 2 byte cell.                              *
* ARGUMENTS:                                                                   *
*    uTestLocation - 2 byte address of the location to be tested.              *
* RETURN:                                                                      *
*    BOOL - true if test is successful, false if failed.                       *
* NOTES:                                                                       *
*******************************************************************************/
BOOL TestRAMCell(UINT32 uTestLocation)
{
#ifdef H8S
    UINT8 ucSaveExr=get_imask_exr();
    set_imask_exr(ucSaveExr);      // allow an IOL request in here if it comes
    set_imask_exr(LVLPRI_HIGHEST); // disable all interrupts
#else
    DisableInterrupts();
#endif

    BOOL IsTestSucceeded  =FALSE;

    volatile UINT16* pTestLocation = (UINT16*)uTestLocation;
    
    //Store the orignial Content of Test Location
    volatile UINT16 ulTestLocCont = *pTestLocation;

    //Test with first pattern
    *pTestLocation = 0x5555;
    if(*pTestLocation != 0x5555)
    {
        #ifdef H8S
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x667,1);
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x668,*pTestLocation);
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x669,uTestLocation);
        #else
        TraceLog.AddToTrace(TRACEID_GENERIC,(APPBreadCrumb)0x667,1);
        TraceLog.AddToTrace(TRACEID_GENERIC,(APPBreadCrumb)0x668,*pTestLocation);
        TraceLog.AddToTrace(TRACEID_GENERIC,(APPBreadCrumb)0x669,uTestLocation);
        #endif
        IsTestSucceeded = FALSE; //Test failed, prepare to return FALSE.
    }
    else // Test Successfull, Test with second pattern
    {
        *pTestLocation = 0xAAAA;
        if(*pTestLocation != 0xAAAA)
        {
            #ifdef H8S
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x667,2);
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x670,*pTestLocation);
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x671,uTestLocation);
            #else
            TraceLog.AddToTrace(TRACEID_GENERIC,(APPBreadCrumb)0x667,2);
            TraceLog.AddToTrace(TRACEID_GENERIC,(APPBreadCrumb)0x670,*pTestLocation);
            TraceLog.AddToTrace(TRACEID_GENERIC,(APPBreadCrumb)0x671,uTestLocation);
            #endif
            IsTestSucceeded = FALSE; //Test failed, prepare to return FALSE.
        }
        else
        {
            IsTestSucceeded = TRUE;
        }
    }

    //Restore the orignial Content of Test Location
    *pTestLocation = ulTestLocCont;

#ifdef H8S
    set_imask_exr(ucSaveExr); // re-enable interrupts
#else
    EnableInterrupts();
#endif

    return IsTestSucceeded;  //Return the Test Status.
}

/*******************************************************************************
*                                  CPUDiagRoutine                              *
*                                  ==============                              *
* PURPOSE:                                                                     * 
*    Test proper operation CPU registers and instructions.                     * 
* ARGUMENTS:                                                                   * 
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire testing is complete. Otherwise Hardfail   *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing some tests so that diag task can  *
*    return to the scheduler for scheduling other tasks.                       *
*******************************************************************************/
RETURNSTATUS CPUDiagRoutine(VOID) {
    if (TRUE == _TestCPURegisters()) {
        return RETURNSTATUS_COMPLETE;
    }
    else {
        HardFail(HF_TCCPUDIAGFAIL,DIAG_CPP,__LINE__);
    }

    return RETURNSTATUS_INPROGRESS;
}
/*******************************************************************************
*                              RAMContentsDiagRoutine                          *
*                              ======================                          *
* PURPOSE:                                                                     * 
*    Test proper operation RAM read and write operations.                      * 
* ARGUMENTS:                                                                   * 
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire RAM is tested. Otherwise INPROGRESS.      *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS RAMContentsDiagRoutine(VOID)
{
    for (UINT8 ucCount = 0; ucCount < RAM_DIAG_CHUNK_SIZE; ucCount++) 
    {
        if (TRUE == TestRAMCell(g_ulIntTestLocation)) 
        {
            // Disabling the interrupts for the duration of the test
            // is done inside the _TestRAMCell function.
            g_ulIntTestLocation += sizeof(UINT16);

#ifdef DSC
            static BOOL bSkipStackArea = FALSE;
            //Ingore the Stack area
            if(g_ulIntTestLocation >= 0x00F200 && bSkipStackArea == FALSE )
            {
                bSkipStackArea = TRUE;
                g_ulIntTestLocation  = 0x00FA00;
            }
#endif
            if (g_ulIntTestLocation > INTERNAL_RAM_END_ADDRESS) 
            {
                g_ulIntTestLocation = INTERNAL_RAM_START_ADDRESS;

                return RETURNSTATUS_COMPLETE;
            }
        }
        else 
        {
            HardFail(HF_RAMCONTERROR,DIAG_CPP,__LINE__);
        }
    }

    return RETURNSTATUS_INPROGRESS;
}

/*******************************************************************************
*                              EXTRAMContentsDiagRoutine                       *
*                              ======================                          *
* PURPOSE:                                                                     * 
*    Test proper operation External RAM read and write operations.             * 
* ARGUMENTS:                                                                   * 
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire RAM is tested. Otherwise INPROGRESS.      *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS EXTRAMContentsDiagRoutine(VOID)
{
    for (UINT8 ucCount = 0; ucCount < RAM_DIAG_CHUNK_SIZE; ucCount++) 
    {
        if (TRUE == TestRAMCell(g_ulExtTestLocation)) 
        {
            // Disabling the interrupts for the duration of the test
            // is done inside the TestRAMCell function.
            g_ulExtTestLocation += sizeof(UINT16);
            if (g_ulExtTestLocation > EXTERNAL_RAM_END_ADDRESS) 
            {
                g_ulExtTestLocation = EXTERNAL_RAM_START_ADDRESS;
                return RETURNSTATUS_COMPLETE;
            }
        }
        else 
        {
            #ifdef H8S
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x666,g_ulExtTestLocation);
            #else
            TraceLog.AddToTrace(TRACEID_GENERIC,(APPBreadCrumb)0x666,g_ulExtTestLocation);
            #endif
            HardFail(HF_TCEXTRAMCONTERROR,DIAG_CPP,__LINE__);
        }
    }

    return RETURNSTATUS_INPROGRESS;
}

/*******************************************************************************
*                             FlashContentsDiagRoutine                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Check the integrity of flash contents.                                    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire FLASH is tested. Otherwise INPROGRESS.    *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS  FlashContentsDiagRoutine(VOID) 
{ 
#ifndef DEBUG
    static  UINT32 *pcCurrentAddress = (UINT32 *)APP_FLASH_START_ADDRESS;
    static  UINT32 suiCrc            = 0;

    for (UINT8 ucCount = 0; ucCount < ROM_DIAG_CHUNK_SIZE; ucCount++) 
    {
        if (!(pcCurrentAddress >= (UINT32 *)APP_HEADER_START_ADDRESS && pcCurrentAddress <= (UINT32 *)APP_HEADER_END_ADDRESS))
        {
            suiCrc = ((suiCrc>>31)|(suiCrc<<1)) ^ (*pcCurrentAddress);
        }
        pcCurrentAddress++;

        if (pcCurrentAddress >= (UINT32 *)APP_FLASH_START_ADDRESS + *((UINT32 *)APP_BYTECNT_ADDRESS)/4) 
        {
            /*if (*((UINT32 *)APP_CRC_ADDRESS) != suiCrc)
                HardFail(HF_APPCRCFAIL,DIAG_CPP,__LINE__);
            else*/ {
                // Reinitialize the variables for next round of diagnostics.
                pcCurrentAddress = (UINT32 *)APP_FLASH_START_ADDRESS;
                suiCrc           = 0;
                return RETURNSTATUS_COMPLETE;
            }
        }
    }
    return RETURNSTATUS_INPROGRESS;    
#else
    return RETURNSTATUS_COMPLETE;
#endif
}
/*******************************************************************************
*                                AddressDiagRoutine                            *
*                                ==================                            *
* PURPOSE:                                                                     *
*    Test proper operation of address lines.                                   *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire RAM is tested. Otherwise Hard Fail .      *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS AddressDiagRoutine(VOID) 
{
    for(UINT8 iAddrLoc = 0;iAddrLoc < ADDR_DIAG_COUNT; iAddrLoc++)
    {
        if(*ADDR_DIAG_TBL[iAddrLoc] != ADDR_DIAG_VAL_TBL[iAddrLoc])
        {
            HardFail(HF_RAMADDRERROR,DIAG_CPP,__LINE__);
        }
    }
 
    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                                DataDiagRoutine                               *
*                                ==================                            *
* PURPOSE:                                                                     *
*    Test proper operation of data lines.                                      *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS_COMPLETE if entire RAM is tested. Otherwise Hard Fail.       *
* NOTES:                                                                       *
*    INPROGRESS is returned after completing test on a chunk so that diag task *
*    can return to the scheduler for scheduling other tasks.                   *
*******************************************************************************/
RETURNSTATUS DataDiagRoutine(VOID)
{
    UINT16 *puDataDiagLoc = (UINT16*)DATA_BUS_DIAG_ADDR;
    
    //Write first pattern to this test location
    *puDataDiagLoc = DATA_DIAG_PATTERN1;

    // Verify that the test location value is not changed.
    if (DATA_DIAG_PATTERN1 != *puDataDiagLoc) 
    {
        HardFail(HF_TCDATABUSERROR,DIAG_CPP,__LINE__);
    }

    UINT16 uMask = 0x0001;
    while(uMask) 
    {
        *puDataDiagLoc = uMask;
        if(uMask == *puDataDiagLoc) 
        {
            uMask <<= 1;
        }
        else
        {
            HardFail(HF_TCDATABUSERROR,DIAG_CPP,__LINE__);
        }
    }

    //Write first pattern to this test location
    *puDataDiagLoc = DATA_DIAG_PATTERN2;

    // Verify that the test location value is not changed.
    if (DATA_DIAG_PATTERN2 != *puDataDiagLoc) 
    {
        HardFail(HF_TCDATABUSERROR,DIAG_CPP,__LINE__);
    }
    
    uMask = 0x1111;
    UINT16 uOneMask  = 0x0001;
    while(uMask) 
    {
        if(*puDataDiagLoc & uOneMask)
        {
            *puDataDiagLoc = *puDataDiagLoc ^ uOneMask;
            uMask          = uMask      ^ uOneMask;
        }

        if(uMask == *puDataDiagLoc) 
        {
            uOneMask <<= 1;
        }
        else
        {
            HardFail(HF_TCDATABUSERROR,DIAG_CPP,__LINE__);
        }
    }

    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                                  TCDiagnosticTask                            *
*                                  ================                            *
* PURPOSE:                                                                     *
*    Diag task main function. Calls diag routines in a round robin fashion.    *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    TASKRETURN with state = TERMINATE.                                        *
* NOTES:                                                                       *
*    1) Diag task is a periodic task with TASKPERIOD = 250 msec.               *
*    2) In each 250 msec cycle, it is designed to execute a diagnostic chunk,  *
*       that typically takes 100 micro second to complete.                     *
*    3) The complete cycle of the diag task takes many minutes to complete and *
*       depends on the tblDiagRoutines initialized by each module type.        *
*******************************************************************************/
TASKRETURN TCDiagnosticTask(TASKCONTEXT a_TaskContext) 
{
    static UINT8 sucDiagIndex = 0; // To save index of the current diag routine.

    TASKRETURN TaskRetrunValue ;
    TaskRetrunValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskRetrunValue.TaskContext     = a_TaskContext;
    TaskRetrunValue.ucSuspendTime   = 0;
#ifdef H8S
    TaskScheduler.RefreshTaskDmc(TASKID_DIAGTASK);

    // Execute DPA at the start of every diag routine.
    DPADiagRoutine();

    // During trace log read app trace log gets locked.
    // Auto unlock app trace log after 30 seconds.
    TraceLog.LockTimeoutProc();

    static UINT8 suc10SecCount = 0;// To throttle WiggleDiag calls once per 10 second
    const  UINT8 DIAG_TENSECOND_COUNT = (MILLISECONDS_IN_SECOND/TASKPERIOD_DIAGTASK)*10;

    // Execute Wiggle diagnostic at every 10 second.
    if (++suc10SecCount >= DIAG_TENSECOND_COUNT) 
    {
       suc10SecCount = 0;
       WiggleDiagRoutine();
    }

    if(BUPREQ_FB == SWBUREQ_n)
    {
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x821,0);
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,TRUE,0);
    }
#endif //#if H8S

    // Based on user request,ProcessTestParams may copy upto 
    // 120 bytes to fpga shared memory.
    // Contention is not expected.
    ProcessTestParams();

    // Execute the current diagnostic function.
    RETURNSTATUS ReturnStatus = (tblDiagRoutines[sucDiagIndex])();

    if (RETURNSTATUS_COMPLETE == ReturnStatus) 
    {
        // Advance to the next diagnostic function 
        // if the current function completes its execution
        sucDiagIndex++;
        if (DIAGROUTINECOUNT == sucDiagIndex) 
        {
            sucDiagIndex = 0; // Reset static counter for next run.
        }
    }

    XReadyDiag();

    return TaskRetrunValue;
}

/*******************************************************************************
*                           RefreshWDT                                         *
*                           ==========                                         *
* PURPOSE:                                                                     *
*    This method refresh watchdog                                              *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*******************************************************************************/
VOID RefreshWDT(VOID)
{
#ifdef H8S
    WDTRFS_n = 0; 
    WDTRFS_n = 1;
#endif

#ifdef DSC
    GpioDataRegs.GPBCLEAR.bit.GPIO54 = 1;
    GpioDataRegs.GPBSET.bit.GPIO54   = 1;
#endif
}

/*******************************************************************************
*                           ClearWDT                                           *
*                           ========                                           *
* PURPOSE:                                                                     *
*    This method clears watchdog                                               *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*******************************************************************************/
VOID ClearWDT(VOID)
{
    // NOTE : WDTODCLR_n refreshes the watchdog automaticall
#ifdef H8S
    WDTODCLR_n = 0; 
    WDTODCLR_n = 1; 
#endif

#ifdef DSC
    GpioDataRegs.GPACLEAR.bit.GPIO30 = 1;
    GpioDataRegs.GPASET.bit.GPIO30 = 1;
#endif
}

/*******************************************************************************
*                                  clsSvpBoxSlot::RefreshWatchDog              *
*                                  ==============================              *
* PURPOSE:                                                                     *
*    Refresh watchdog very 5msec and perform watch diagnostic very 30sec       *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*******************************************************************************/
VOID BOXCLASS::RefreshWatchDog(VOID)
{
    //Check whether it is time to do a WDT diagnostic cycle and Calibration is not in progress, if yes don't do WDT diag
    if((BOX->uiWdtDiagCounter > TC_WDT_DIAGSTART_DIAGCOUNT) &&
        (FALSE == BOX->IsCalibInProgress()) &&
        (!BOX->CheckForFactoryTestMode())) 
    {
        switch (BOX->WdtDiagState) 
        {    
            // State of WDT diagnostic cycle   
            case WDTDIAG_RESET:
            {   
                // Start it by signalling the ISR
                BOX->WdtDiagState = WDTDIAG_RUNNING;
            }
            break;
            case WDTDIAG_RUNNING:   // WDT interrupt has not happened yet
            {
                if (BOX->ucWdtRefreshCounter >= WDT_PREFIRE_TIMEOUT) 
                {
                    BOOL bWdtIntAsserted = (IRQ1_STATUS) ? TRUE : FALSE;
                    
                    bWdtIntAsserted |= gbWdtIntAsserted;

                    #ifdef H8S
                        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x711,gbWdtIntAsserted);
                    #endif
                    if (FALSE == BOX->GetWdtIntProcessed()) 
                    {          
                        #ifdef H8S
                            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x712,BOX->ucWdtRefreshCounter);
                            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x713,BOX->uiWdtDiagCounter);
                        #endif
                        // Stop the watchdog from expiring if IRQ1 has not processed 
                        // the interrupt yet. Note that the FPAG_INFL_WDTO may stay
                        // asserted longer up to 5 msec after the IRQ1 has processed it.
                        BOX->StopImpendingWatchdog();
                        
                        // Mark that scheduler detected FPGA_INTFL_WDTO first and serviced it.
                        // This is required otherwise the Irq1InterruptHandler may hardfail
                        // because the WDTDIAG_STATE is not running.
                        BOX->SetWdtIntProcessed();
                    }

                    // Post the softfail only if the WDT interrupt was not asserted.
                    // Since WDT interrupt is tied to low priority IRQ1, it may not
                    // have got a chance to run due to other higher priority ineterrupts.
                    if (FALSE == bWdtIntAsserted) 
                    {
                        #ifdef H8S
                            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x714,bWdtIntAsserted);
                        #endif
                        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_WDTDIAGFAIL,TRUE,0);
                    }
                    
                    gbWdtIntAsserted = FALSE;
                }
            }
            break;
            default:
            {
                // The state machine is out of whack, so HF
                HardFail(HF_BADPROGRAMJUMP,SCHEDULER_CPP,__LINE__);
            }
            break;
        }

        BOX->ucWdtRefreshCounter += 1;
    }
    else if(!FactryModeWDTUTest)
    {   // It is time to do a WDT refresh for modules
        // Watchdog diagnostics is not
        // scheduled now. Kick the dog, reset the WDT counter,
        // and increment the WDT diag counter.
        RefreshWDT();

#ifdef IOMTYPE_SP
#ifdef H8S
        gWdtRefTimerCount = TPU2_TCNT;
#endif
#endif
        BOX->ucWdtRefreshCounter = 0;

        //If Calibration is inprogress, reset the WDT Diag counter
        if(TRUE == BOX->IsCalibInProgress())
        {
            BOX->uiWdtDiagCounter = 0;
        }
        else
        {
            BOX->uiWdtDiagCounter += 1;
        }

        // Arm IRQ1 processing for watchdog interrupt.
        BOX->ResetWdtIntProcessed();

    }
    else if(FactryModeWDTUTest)
    { 
        BOX->ucWdtRefreshCounter += 1;
    }
}

/*******************************************************************************
*                                      XReadyDiag                              *
*                                ==============================                *
* PURPOSE:                                                                     *
*    XReady diagnostics every 250msec                                          *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
VOID XReadyDiag(VOID)
{
    //Xready and Wait_n diagnostics
    /*UINT16 Value = *((UINT16*)TC_XREADY_TEST_REG);
    if(Value != DIAG_XREADY_VAL)
        TraceLog.AddToTrace(TRACEID_GENERIC,bcXreadyVal,Value);*/
}


/******************************************************************************
*                         clsSvpBoxSlot::IRQ1InterruptHandler                 *
*                         ================================                    *
* PURPOSE: Watch Prefire interrupt handler                                    * 
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/

VOID BOXCLASS::IRQ1InterruptHandler(VOID)  
{    
#ifdef H8S
    IRQ1_STATUS = DISABLE; // Clear the interrupt flag
#else
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP12;
#endif
    // Return if the following factory tests are in progress
#ifdef H8S
    if ((TRUE == FactryModeWDTUTest) || (TRUE == HWRevCodeWriteInProgress))
#endif
#ifdef DSC
    if (TRUE == FactryModeWDTUTest) 
#endif
    {
        BOX->StopImpendingWatchdog();
#ifdef DSC
        FactryModeWDTUTest = FALSE;
#endif
#ifdef H8S
        // Restore original interrupt mask.
        set_imask_exr(LVLPRI_PDVC);
#endif
        return;
    }
#ifdef H8S
    // Restore original interrupt mask.
    set_imask_exr(LVLPRI_IOPROC);
#endif
    gbWdtIntAsserted = TRUE;
    if (FALSE == BOX->bWdtIntProcessed)
    { 
        // if watchdog interrupt is not processed yet.
        BOX->bWdtIntProcessed = TRUE; // Mark watchdog interrupt processed.

        if((BOX->WdtDiagState != WDTDIAG_RUNNING) && (FALSE == BOX->IsCalibInProgress()))
        {
            
            #ifdef IOMTYPE_SP
                #ifdef H8S
                    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x715,gWdtRefTimerCount);
                    TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x724,TPU2_TCNT);
                #endif
            #endif
            #ifdef H8S
                //Unexpected watchdog impending interrupt. Hardfail the module.
                HardFail(HF_WDTTIMEOUT,BOXSLOT_CPP,__LINE__,
                         BOX->WdtDiagState,
                         BOX->ucWdtRefreshCounter);
            #endif
            #ifdef DSC
                //Unexpected watchdog impending interrupt. Hardfail the module.
                HardFail(HF_TCAPPWDTTIMEOUT,BOXSLOT_CPP,__LINE__,
                         BOX->WdtDiagState,
                         BOX->ucWdtRefreshCounter);
            #endif

        }   
        else 
        {   // For IOMs that have a WDT interrupt of 120ms
            // This is a successful watchdog diagnostic test end.
            BOX->StopImpendingWatchdog();
        }
    }
    else
    {
        #ifdef H8S
        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x720,BOX->uiWdtDiagCounter);
        #endif
    }
#ifdef H8S
    // Restore original interrupt mask.
    set_imask_exr(LVLPRI_PDVC);
#endif
}

/*******************************************************************************
*                          BOXCLASS::StopImpendingWatchdog                     *
*                          ===============================                     *
* PURPOSE: This function is called from IRQ1 interrupt refresh watchdog method *
*  to stop watchdog from expiring. In all occassions except factory test mode  *
*  ,watchdog expiry is prevented by asserting WDTODCLR_n line.                 *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None                                                                      *
* NOTES:                                                                       *
******************************************************************************/
VOID BOXCLASS::StopImpendingWatchdog(VOID) 
{
    INT32 WdtTime  = 0;

#ifdef H8S
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);
#endif
    if (!FactryModeWDTUTest)
    {
        // If WDT diagnostics test is being done, 
        // refresh WDT and reset WdtDiag data members.
        // NOTE : WDTODCLR_n refreshes the watchdog automaticall
        ClearWDT();
        uiWdtDiagCounter = 0;
        WdtDiagState = WDTDIAG_RESET;

        // Restart the WdtRefreshCounter to synchronize the refresh window.
        ucWdtRefreshCounter = 0;
    }
    else
    {
        // Make exclusive use of TPU1 for measuring time for the watchdog to expire.
#ifdef DSC
        ClearWDT();
#endif
#ifdef H8S 
        set_imask_exr(LVLPRI_HIGHEST);
#endif
        WdtTime = (INT32)(ucWdtRefreshCounter * WD_REFRESH_PERIOD * MICROSECONDS_IN_MILLISECOND); 
        ucWdtRefreshCounter = 0;
        BOX->SetTstFunctTime(WdtTime);

#ifdef H8S 
        set_imask_exr(ucSaveExr);
#endif
        return; 
    }
#ifdef H8S
    set_imask_exr(ucSaveExr); // re-enable interrupts
#endif

}

/*******************************************************************************
*                               TcIomDiagnostics                               *
*                               ================                               *
* PURPOSE:                                                                     *
*    This method does Address and Data diagnostics                             *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID TcIomDiagnostics()
{
    AddressDiagRoutine();
    DataDiagRoutine();
}

#ifdef H8S
/*******************************************************************************
*                                  DPADiagRoutine                              *
*                                  ==============                              *
* PURPOSE:                                                                     *
*    Compare DPA value in the database with the address pin settings.          *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS - RETURNSTATUS_COMPLETE on success                           *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  DPADiagRoutine(VOID)
{
    UINT8 ucModuleId = MODNUM & (MODNUMBITS | IOLIDBIT);

    if (BOX->GetModuleId() != ucModuleId) {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADDRDIAGFAIL,TRUE,0);
    }
    else {
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_ADDRDIAGFAIL,FALSE,0);
    }    

    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                                  APPIOTADiagRoutine                          *
*                                  ==================                          *
* PURPOSE:                                                                     *
*    Compare APP and IOTA Type value                                           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS - RETURNSTATUS_COMPLETE on success, otherwise HF             *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS APPIOTADiagRoutine(VOID)
{
    UINT8 IotaType     = CPLD_IOTA_TYPE;
    UINT8 AppBoardType = CPLD_APP_TYPE;

    BOOL FlFactMode = (!(REDUNT_n) &&(BOTTOM)); //For Factory Mode:REDUNT_n Should be Low: 
                                                //                 BOTTOM Should be High
               
    if(!FlFactMode && (IotaType != IOTA_TYPE))// if Not in factory mode then only check for IOTA type
    {
        HardFail(HF_TCAPPIOTAERROR,DIAG_CPP,__LINE__);
    }
    else if(AppBoardType != APP_BOARD_TYPE)
    {
        HardFail(HF_TCAPPIOTAERROR,DIAG_CPP,__LINE__);
    }
  
    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                                  APPBoardPowerDiagRoutine                    *
*                                  ========================                    *
* PURPOSE:                                                                     *
*    Compares App board diagnostic                                             *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS - RETURNSTATUS_COMPLETE on success, otherwise HF             *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS APPBoardPowerDiagRoutine(VOID)
{
    static UINT8 uRetryCount = 0;
    volatile APPBRDCTRLREG AppBrdCtrl;

    AppBrdCtrl.all=(*(P_APP_BRD_CTRL_REGS)).all;
    UINT8 uAppBoardPowerStatus = AppBrdCtrl.bit.PWRMON;

    if(uAppBoardPowerStatus == 1)
    {
        uRetryCount = 0;
    }
    else
    {
        uRetryCount++;
    }
           
    if(uRetryCount >= APP_BOARD_POWER_HARD_FAILURE_RETRY)
    {
        HardFail(HF_TCAPPBOARDPOWERR,DIAG_CPP,__LINE__);
    }

    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                                WiggleDiagRoutine                             *
*                                =================                             *
* PURPOSE: If IOM is in SYNCD state and both wiggle bits in REDDATA are set    *
*          then post REDNDIAG softfail. Otherwise return the REDNDIAG softfail *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS - RETURNSTATUS_COMPLETE on success                           *
* NOTES:                                                                       *
*******************************************************************************/
RETURNSTATUS WiggleDiagRoutine(VOID) {
    static UINT8 uRetry = 0;

    if (BOX->GetRedState() == REDSTATE_SYNCD) 
    {
        if ((BOX->CheckRedData(REDDATA_WIGGLE)) && 
            (BOX->CheckRedData(REDDATA_WIGLSF))) 
        {
            if(++uRetry > WIGGLE_TEST_RETRY)
            {
                uRetry = 0;
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDNDIAG,TRUE,0);
            }
            return RETURNSTATUS_COMPLETE;
        }
    }

    uRetry = 0;
    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDNDIAG,FALSE,0);
    
    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                                CPLDVersionDiagRoutine                        *
*                                ======================                        *
* PURPOSE: This method checks the CPLD Version Diagnostic                      *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    RETURNSTATUS - RETURNSTATUS_COMPLETE on success, otherwise HF             *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS CPLDVersionDiagRoutine(VOID) 
{
    if(CPLD_REVNUMBER != CPLD_VERSION)
    {
        HardFail(HF_TCCPLD_VER_FAIL,DIAG_CPP,__LINE__);
    }

    return RETURNSTATUS_COMPLETE;                
}

#ifdef IOMTYPE_SP
/*******************************************************************************
*                            EepromCountDiagnostics                            *
*                            ======================                            *
* PURPOSE:                                                                     *
*    Compare count value and check if it is greater than max 10,000 .          *
*    Issues softfail if it is greater than this value.                         *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  EepromCountDiagnostics(VOID) {
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) 
    {
        UINT16 ModuleWriteCount = Eeprom.ReadUint16(0,SP_EE_MODULEINFO_WRITECOUNT);
        if( ModuleWriteCount >= EEPROM_MAXWRCOUNT ) 
        {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EECNTERR,TRUE,0);
        }
        // Firmware will never return this softfail.
    }
    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                            EepromWrFlagDiagnostics                           *
*                            =======================                           *
* PURPOSE:                                                                     *
*    Compare Write Flags and Bit 6 and Bit 7 should be complimentory           *
*    Issues softfail if it is bit 6 and Bit 7 are same                         *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  EepromWrFlagDiagnostics(VOID) {
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) 
    {
        UINT16 EepromWriteFlags = Eeprom.ReadUint16(0,SP_EE_MODULEINFO_WRITE_FLAGS);
        if( MODULINFO_WRITE_COMPLETE != EepromWriteFlags ) 
        {
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EEFLAGER,TRUE,0);
        }
        // Firmware will never return this softfail.
    }
    return RETURNSTATUS_COMPLETE;
}

/*******************************************************************************
*                            EepromChksmDiagnostics                            *
*                            =======================                           *
* PURPOSE:                                                                     *
*    Calculate and compare the checksum of Calib data                          *
*    Issues softfail om CRC Mismatch                                           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  EepromChksmDiagnostics(VOID) {
    static  UINT16 pcCurrentAddress = EEPROM_ADDR_RANGE_START;
    static  UINT16 suChksum         = 0;
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) 
    {
        for (UINT8 ucCount = 0; ucCount < EEPROM_DIAG_CHUNK_SIZE; ucCount++) 
        {
            suChksum ^= (Eeprom.ReadUint16(0,pcCurrentAddress));
            suChksum >>= 1;  // rotate right once
            pcCurrentAddress+=2;
            if (pcCurrentAddress >= EEPROM_CHKSM_ADDR_END) 
            {
                UINT16 SavedChksum = Eeprom.ReadUint16(1,(UINT8)EEPROM_CHKSM_ADDR_END);
                if ((SavedChksum != suChksum) ||
                    (0 == suChksum) || (MAXUINT16 == suChksum) ||
                    (0 == SavedChksum) || (MAXUINT16 == SavedChksum)) 
                {
                    // Report the Soffail if checksum does not match
                    // or if saved or calculated checksum is all 0s or all 1s.
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_EECKSMER,TRUE,0);
                }
                // Firmware will never return this softfail.

                // Reinitialize the variables for next round of diagnostics.
                pcCurrentAddress = EEPROM_ADDR_RANGE_START;
                suChksum         = 0;
                return RETURNSTATUS_COMPLETE;
            }
        }
        return RETURNSTATUS_INPROGRESS;
    }

    return RETURNSTATUS_COMPLETE;
}
#endif //#if SP

/******************************************************************************
*                         clsSvpBoxSlot::IRQ4InterruptHandler                 *
*                         ================================                    *
* PURPOSE: These voltage levels are monitored at H/W level, any of these      *
*          voltages going below threshold will trigger board reset            * 
* ARGUMENTS:                                                                  * 
*    None.                                                                    *
* RETURN:                                                                     *
*    None.                                                                    *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID BOXCLASS::IRQ4InterruptHandler(VOID)  
{   
    // The state machine is out of whack, so HF
    HardFail(HF_TCKERNALPOWERFAIL,SCHEDULER_CPP,__LINE__);
}

/*******************************************************************************
*                     GetSwitchStatus                                          *
*                     ===============                                          *
* PURPOSE:                                                                     *
*       Reads the FPGA switch register and returns the switch status           *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*          UINT8 value indicates switch status                                 *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 GetSwitchStatus(SWITCH_TYPE eswtype)
{   
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_IOL);
    UINT8 ucTemp = 0x00,ucRetryCntr;
    for (ucRetryCntr=3; ucRetryCntr>0; ucRetryCntr--) {
        switch(eswtype){
        case DIS_SWCH:
            if(DISA_FB_n)
            {
                ucTemp = ucTemp | DIS_SWA_SET;
            }
            if(DISB_FB1_n)
            {
                ucTemp = ucTemp | DIS_SWB1_SET;
            }
            if(DISB_FB2_n)
            {
                ucTemp = ucTemp | DIS_SWB2_SET;
            }
            break;
        case TST_SWCH:
            if(TST_FB)
            {
                ucTemp = ucTemp | TST_SET;
            }
            break;
        case INH_SWCH:
            if(INHST1_FB)
            {
                ucTemp = ucTemp | INH_SWA_SET;
            }
            if(INHST1_FB1)
            {
                ucTemp = ucTemp | INH_SWB1_SET;
            }
            if(INHST1_FB2)
            {
                ucTemp = ucTemp | INH_SWB2_SET;
            }
            break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x913,eswtype);
            break;
        }
    }
    set_imask_exr(ucSaveExr);
    return ucTemp;
}

/*******************************************************************************
*                     GetSwitchStatusPriority                                  *
*                     =======================                                  *
* PURPOSE:                                                                     *
*       Reads the FPGA switch register and returns the switch status           *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*          UINT8 value indicates switch status                                 *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 GetSwitchStatusPriority(SWITCH_TYPE eswtype)
{   
    UINT8 ucTemp = 0x00,ucRetryCntr;
    for (ucRetryCntr=3; ucRetryCntr>0; ucRetryCntr--) {
        switch(eswtype){
        case DIS_SWCH:
            if(DISA_FB_n)
            {
                ucTemp = ucTemp | DIS_SWA_SET;
            }
            if(DISB_FB1_n)
            {
                ucTemp = ucTemp | DIS_SWB1_SET;
            }
            if(DISB_FB2_n)
            {
                ucTemp = ucTemp | DIS_SWB2_SET;
            }
            break;
        case TST_SWCH:
            if(TST_FB)
            {
                ucTemp = ucTemp | TST_SET;
            }
            break;
        case INH_SWCH:
            if(INHST1_FB)
            {
                ucTemp = ucTemp | INH_SWA_SET;
            }
            if(INHST1_FB1)
            {
                ucTemp = ucTemp | INH_SWB1_SET;
            }
            if(INHST1_FB2)
            {
                ucTemp = ucTemp | INH_SWB2_SET;
            }
            break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x914,eswtype);
            break;
        }
    }
    return ucTemp;
}

/*******************************************************************************
*                             TestSwitchDiagnostics                            *
*                             =====================                            *
* PURPOSE:                                                                     *
*    Test Switch Diagnostics                                                   *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    This control output is changed once per diagnostic state and then it is   *
*    checked in the next diagnostic state to confirm the change occurred.      *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL TestSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bTstswDiagSts = TRUE;
    
    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State())
    {
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        bTstswDiagSts = FALSE;
        switch(ucSubContext) 
        {
            case CONTEXT_ZERO:
                TST_n = TSTn_ENABLED;
                bTstswDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(TST_ENABLED == GetSwitchStatusPriority(TST_SWCH)) 
                {
                    bTstswDiagSts = TRUE;
                    TST_n = TSTn_DISABLED;
                }
                break;
            case CONTEXT_TWO:
                if(TST_DISABLED == GetSwitchStatusPriority(TST_SWCH)) 
                {
                    bTstswDiagSts = TRUE;
                }
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x915,ucSubContext);
                break;
        }
        set_imask_exr(ucSaveExr);
    }
    return bTstswDiagSts;
}
/*******************************************************************************
*                             InhibitSwitchDiagnostics                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Inhibit Switch Diagnostics                                                *
* ARGUMENTS:                                                                   *
*    UINT8 ucSubContext                                                        *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    Only one output is changed per diagnostic state and then it is checked in *
*    in the next diagnostic state to confirm the change occurred.              *
*    N.B.: ONLY ONE INH_SW is allowed to be ON during any diagnostic state.    *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL InhibitSwitchDiagnostics(UINT8 ucSubContext) 
{   
    BOOL bInhswDiagSts = TRUE;

    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State())
    {
        UINT8 ucSaveExr =get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
        bInhswDiagSts = FALSE;
        switch(ucSubContext)
        {
            case CONTEXT_ZERO:
                INH_SWB = SW_ON;
                bInhswDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(INH_ON_OFF == GetSwitchStatusPriority(INH_SWCH)) 
                {
                    bInhswDiagSts = TRUE;
                    INH_SWB = SW_OFF;
                }
                break;
            case CONTEXT_TWO:
                if(INH_OFF_OFF == GetSwitchStatusPriority(INH_SWCH)) 
                {
                    bInhswDiagSts = TRUE;
                    TST_n = TSTn_ENABLED;
                }
                break;
            case CONTEXT_THREE:
                if(TST_ENABLED == GetSwitchStatusPriority(TST_SWCH)) 
                {
                    bInhswDiagSts = TRUE;
                    INH_SWA = SW_ON;
                }
                break;
            case CONTEXT_FOUR:
                if(INH_OFF_ON_TST_ON == GetSwitchStatusPriority(INH_SWCH))  
                {
                    bInhswDiagSts = TRUE;
                    INH_SWA = SW_OFF; 
                }
                break;
            case CONTEXT_FIVE:
                if(INH_OFF_OFF_TST_ON == GetSwitchStatusPriority(INH_SWCH)) 
                {
                    bInhswDiagSts = TRUE;
                    TST_n = TSTn_DISABLED; 
                }
                break;
            case CONTEXT_SIX:
                if(TST_DISABLED == GetSwitchStatusPriority(TST_SWCH))
                {
                    bInhswDiagSts = TRUE;
                }
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x916,ucSubContext);
                break;
        }
        set_imask_exr(ucSaveExr);
    }
    return bInhswDiagSts;
}

/*******************************************************************************
*                             DisableSwitchDiagnostics                         *
*                             ========================                         *
* PURPOSE:                                                                     *
*    Disable Switch Diagnostics                                                *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*                                                                              *
* NOTES:                                                                       *
*    Only one output is changed per diagnostic state and then it is checked in *
*    in the next diagnostic state to confirm the change occurred.              *
*    N.B.: ONLY ONE DIS_SW is allowed to be ON during any diagnostic state.    *
*    A TRUE return value indicates to the calling routine that the confirmation*
*    was successful and the state machine can advance to the next diagnostic   *
*    state.                                                                    *
*    A FALSE return value indicates to the calling routine that confirmation   *
*    of the last change failed.                                                *
*                                                                              *
*******************************************************************************/
BOOL DisableSwitchDiagnostics(UINT8 ucSubContext) 
{
    BOOL bDisSwDiagSts = TRUE;

    // If a hard FO to this module has occurred since starting the switch
    // diagnostics manipulation of all SW control outputs must cease. In this
    // case a value of TRUE is returned and the calling routine cycles harmlessly
    // through the rest of the diagnostic sequence without making any further
    // changes.
    if(OUTCTL_PARTNER == BOX->GetModStat3State())
    {
        UINT8 ucSaveExr =get_imask_exr();
        set_imask_exr(LVLPRI_IOL);
        bDisSwDiagSts = FALSE;
        switch(ucSubContext) 
        {
            case CONTEXT_ZERO:
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_OFF;
                bDisSwDiagSts = TRUE;
                break;
            case CONTEXT_ONE:
                if(DIS_ON_OFF == GetSwitchStatusPriority(DIS_SWCH)) 
                {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_OFF;
                }
                break;
            case CONTEXT_TWO:
                if(DIS_OFF_OFF == GetSwitchStatusPriority(DIS_SWCH)) 
                {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_ON;
                }    
                break;
            case CONTEXT_THREE:
                if(DIS_OFF_ON == GetSwitchStatusPriority(DIS_SWCH)) 
                {
                    bDisSwDiagSts = TRUE;
                    DIS_SWA_n = SW_OFF;
                    DIS_SWB_n = SW_OFF;
                }
                break;
            case CONTEXT_FOUR:
                if(DIS_OFF_OFF == GetSwitchStatusPriority(DIS_SWCH)) 
                {
                    bDisSwDiagSts = TRUE;  
                }
                break;
            default:
                TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x917,ucSubContext);
                break;
        }
        set_imask_exr(ucSaveExr);
    }
    return bDisSwDiagSts;
}

/*******************************************************************************
*                             SwitchDiagnostics                                *
*                             =================                                *
* PURPOSE:                                                                     *
*    Test all 3 switch control outputs                                         *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN: RETURNSTATUS - RETURNSTATUS_COMPLETE on success, otherwise HF        *
*                                                                              *
* NOTES:                                                                       *
* This routine tests all 3 switch control outputs.                             *
* Since there are propagation delays from the time an output is changed to the *
* time its feedfack signal can be reliably read appropriate delays are         *
* are implemented here with a mechanism for one retry should a miscompare occur*  
* One step of the test sequence is executed per call to the respective diag    * 
* routine. Most steps are comprised of a test to confirm the change made in    *
* the last step and then contingent on its success the next change is made.    *
* The sequence advances to the next step only if the present step succeeds -   *
* otherwise one retry is made before advancing or hardfailing.                 *
*                                                                              *
*******************************************************************************/
RETURNSTATUS  SwitchDiagnostics(VOID) 
{
    UINT8 ucSubContext,ucCount;
    
    // Begin switch diagnostics only if this module does not have control of the
    // field terminations and module roles are not in transition.
    if((OUTCTL_PARTNER == BOX->GetModStat3State()) && (REDSTATE_SYNCD == BOX->GetRedState()))
    {
        // Perform the diagnostic of the Disable Output switches 
        for(ucSubContext = CONTEXT_ZERO; ucSubContext <= CONTEXT_FOUR; ucSubContext++) 
        {
            ucCount = 0;
            while(!DisableSwitchDiagnostics(ucSubContext)) 
            {
                ucCount++;
                if(ucCount>1) 
                {
                    HardFail(HF_OUTPUTCONTROL,DIAG_CPP,__LINE__,
                             ucSubContext,GetSwitchStatusPriority(DIS_SWCH));
                }
                IdleWait(DIS_READ_DELAY_TIME);
            }
            IdleWait(DIS_READ_DELAY_TIME);
        }

        // Perform the diagnostic of the Test switch
        for(ucSubContext = CONTEXT_ZERO; ucSubContext <= CONTEXT_TWO; ucSubContext++) 
        {
            ucCount = 0;
            while(!TestSwitchDiagnostics(ucSubContext)) 
            {
                ucCount++;
                if(ucCount>1) 
                {
                    HardFail(HF_OUTPUTCONTROL,DIAG_CPP,__LINE__,
                             ucSubContext,GetSwitchStatusPriority(TST_SWCH));
                }
                IdleWait(TST_READ_DELAY_TIME);
            }
            IdleWait(TST_READ_DELAY_TIME);
        }

        // Perform the diagnostic of the Inhibit Output switches 
        for(ucSubContext = CONTEXT_ZERO; ucSubContext <= CONTEXT_SIX; ucSubContext++) {
            ucCount = 0;
            while(!InhibitSwitchDiagnostics(ucSubContext)) {
                ucCount++;
                if(ucCount>1) 
                {
                    HardFail(HF_OUTPUTCONTROL,DIAG_CPP,__LINE__,
                             ucSubContext,GetSwitchStatusPriority(INH_SWCH));
                }
                IdleWait(INH_READ_DELAY_TIME);
            }
            IdleWait(INH_READ_DELAY_TIME);
        }

        static BOOL bRedunFailureFlag = TRUE;
        static UINT8 uRedunFailureRetry = 0;
        //check if the ININ_IN line is negated      
        if((INHIN_NEGATED == INHIN_FB_n)&&(BURIN_NEGATED == BUPREQ_IN))
        {
            //Check the Out Control state before rasing softfail
            if((OUTCTL_PARTNER == BOX->GetModStat3State()) && (REDSTATE_SYNCD == BOX->GetRedState()))
            {
                if(uRedunFailureRetry++ > RED_HW_RETRY)
                {
                    if(bRedunFailureFlag)
                    {
                        bRedunFailureFlag = FALSE;
                        TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x822,0);
                    }
                    uRedunFailureRetry = 0;
                    BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,TRUE,0);
                }
            }
            else
            {
                uRedunFailureRetry = 0;
                bRedunFailureFlag = TRUE;
                BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
            }
        }
        else
        {
            uRedunFailureRetry = 0;
            bRedunFailureFlag = TRUE;
            BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_REDHWFAIL,FALSE,0);
        }
    }
    return RETURNSTATUS_COMPLETE;
} // SwitchDiagnostics() end

/*******************************************************************************
*                           VerifySwitchState                                  *
*                           =================                                  *
* PURPOSE:                                                                     * 
*      Reads the current status of the switches,compares it with whats expected*
*      status,if a mismatch is found the state of the switch is modified with  *
*      expected switch state                                                   *
* ARGUMENTS:                                                                   *
*           NONE                                                               *
* RETURN:                                                                      *
*           NONE                                                               *
* NOTES:                                                                       *
*******************************************************************************/
VOID VerifySwitchState(SWITCH_TYPE eswtype,UINT8 a_ucSwitchState)
{
    static UINT8 uOpHwRetry = 0;

    UINT8 ucCountOuter,ucCountInner,ucFailure=0;
    for (ucCountOuter=3; ucCountOuter>0; ucCountOuter--) 
    {
        switch(eswtype)
        {
        case DIS_SWCH:
            ucFailure = 1;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) 
            {
                if (a_ucSwitchState == GetSwitchStatus(DIS_SWCH)) 
                {
                    uOpHwRetry = 0;
                    return; 
                }
            }
            if (a_ucSwitchState == DIS_ON_ON) 
            {
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_ON;
            }
            else if (a_ucSwitchState == DIS_ON_OFF) 
            {
                DIS_SWA_n = SW_ON;
                DIS_SWB_n = SW_OFF;
            }
            else if (a_ucSwitchState == DIS_OFF_ON) 
            {
                DIS_SWA_n = SW_OFF;
                DIS_SWB_n = SW_ON;
            }
            else if (a_ucSwitchState == DIS_OFF_OFF) 
            {
                DIS_SWA_n = SW_OFF;
                DIS_SWB_n = SW_OFF;
            }
            IdleWait(DIS_READ_DELAY_TIME);
            break;
        case TST_SWCH:
            ucFailure = 2;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) 
            {
                if (a_ucSwitchState == GetSwitchStatus(TST_SWCH)) 
                {
                    uOpHwRetry = 0;
                    return; 
                }
            }
            //Set the switch to desired state
            TST_n = (a_ucSwitchState == TST_DISABLED) ? TSTn_DISABLED : TSTn_ENABLED;
            IdleWait(TST_READ_DELAY_TIME);
            break;
            
        case INH_SWCH:
            ucFailure = 3;
            for (ucCountInner=3; ucCountInner>0; ucCountInner--) 
            {
                if (a_ucSwitchState == GetSwitchStatus(INH_SWCH)) 
                {
                    uOpHwRetry = 0;
                    return; 
                }
            }
            
            if (a_ucSwitchState == INH_ON_ON) 
            {
                INH_SWB = SW_ON;
                INH_SWA = SW_ON;
            }
            else if (a_ucSwitchState == INH_ON_OFF) 
            {
                INH_SWB = SW_ON; 
                INH_SWA = SW_OFF;
            }
            else if (a_ucSwitchState == INH_OFF_ON) 
            {
                INH_SWB = SW_OFF;
                INH_SWA = SW_ON;
            }
            else if (a_ucSwitchState == INH_OFF_OFF) 
            {
                INH_SWA = SW_OFF;
                INH_SWB = SW_OFF;
            }
            IdleWait(INH_READ_DELAY_TIME);
            break;
        default:
            TraceLog.AddToTrace(TRACEID_GENERIC,(IOBreadCrumb)0x918,eswtype);
            break;
        }//switch loop
    }//Outer For loop 
    // If the check and overwrite fails, hard fail the module

    //Let the switch gets settle, try for 3 concecusitive tries then hard fail the module
    if(uOpHwRetry++ >= VERIFY_SWITCH_HARD_FAILURE_RETRY)
    {
        uOpHwRetry = 0;
        HardFail(HF_OUTPUTCONTROL,AOHARDWARE_CPP,__LINE__,ucFailure);
    }
}

/*******************************************************************************
*                               TCStartupDiagnostics                           *
*                               ====================                           *
* PURPOSE: This method perform the startup diagnostics                         * 
* ARGUMENTS: None.                                                             *
* RETURN:    None.                                                             *
* NOTES:                                                                       *
*******************************************************************************/
VOID TCStartupDiagnostics()
{
#ifndef DEBUG
    UINT8 Mask = 0x80;
    
    #if !HEK
    RDBK_SEL         = RDBK_MODNUM;
    #endif // !HEK
    UINT8 ModlId    = MODNUM & MODNUMBITS;
  
    // Printing the module number
    PrintStr("\n\rMODULE NUMBER:");
    while(Mask) {
        if (Mask & ModlId) {
            PrintStr("1");
        }
        else {
            PrintStr("0");
        }
        Mask >>= 1;
    }

    // Printing the DPA
    #if !HEK
    RDBK_SEL = RDBK_IOTA;
    #endif // !HEK
    ModlId = ((BOTTOM) ? 255 : 256) - 2 * ModlId;
    Mask = 0x80;
    PrintStr("\n\rDPA          :");
    while(Mask) {
        if (Mask & ModlId) 
        {
            PrintStr("1");
        }
        else 
        {
            PrintStr("0");
        }
        Mask >>= 1;
    }

    DoPostDiagnostics();
#endif

   
}

/*******************************************************************************
*                               DoPostDiagnostics                              *
*                               =================                              *
* PURPOSE: This method performs the  post diagnostics                          * 
* ARGUMENTS: None.                                                             *
* RETURN:    None.                                                             *
* NOTES:                                                                       *
*******************************************************************************/
VOID DoPostDiagnostics()
{
    while(RETURNSTATUS_COMPLETE != APPIOTADiagRoutine());
#ifndef DEBUG
    PrintStr("\n\rT001");
#endif

    while(RETURNSTATUS_COMPLETE != CPUDiagRoutine());
#ifndef DEBUG
    PrintStr("\n\rT002");
#endif
    
    while (RETURNSTATUS_COMPLETE != RAMContentsDiagRoutine());
#ifndef DEBUG
    PrintStr("\n\rT003");
#endif

    while (RETURNSTATUS_COMPLETE != EXTRAMContentsDiagRoutine());
#ifndef DEBUG
    PrintStr("\n\rT004");
#endif

   while (RETURNSTATUS_COMPLETE != AddressDiagRoutine()); 
#ifndef DEBUG
    PrintStr("\n\rT005");
#endif
    
   while (RETURNSTATUS_COMPLETE != DataDiagRoutine()); 
#ifndef DEBUG
    PrintStr("\n\rT006");
#endif

#ifndef DEBUG
    while (RETURNSTATUS_COMPLETE != FlashContentsDiagRoutine()); 
    PrintStr("\n\rT007");
    
    // Print T999 to mark self test complete
    PrintStr("\n\rT999");
#endif

    *uHandeShakeState = IOLINK_START_UP_DIAG_DONE;
    
    BOOTCTRL1=0;
    BOOTCTRL0=0;
   
    PrintStr("\n\rIOLINK_START_UP_DIAG_DONE");

    while(*uHandeShakeState == IOLINK_START_UP_DIAG_DONE)
    {
       IdleWait(1);
    }
    PrintStr("\n\rAPP_START_UP_DIAG_DONE");
}

#endif //#if H8S

#ifdef DSC

/******************************************************************************
*                            EnableWatchdog                                   *
*                            ==============                                   *
* PURPOSE: This method enables watchdog in the applicaiton processor          * 
* ARGUMENTS: None.                                                            *
* RETURN:    None.                                                            *
* NOTES:                                                                      *
******************************************************************************/
VOID EnableWatchdog(VOID)
{
//Watch Dog is not enabled in debug mode
#ifndef _DEBUG 
    EALLOW; 
        //WDT clear pin setting as output, default set to 1
        GpioCtrlRegs.GPAMUX2.bit.GPIO30 = 0;
        GpioDataRegs.GPADAT.bit.GPIO30  = 1;
        GpioCtrlRegs.GPADIR.bit.GPIO30  = 1;

        //WDT enable pin setting as output, default set to 0
        GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0;
        GpioDataRegs.GPADAT.bit.GPIO27  = 0;
        GpioCtrlRegs.GPADIR.bit.GPIO27  = 1;

        //WDT refresh pin setting as output, default set to 1
        GpioCtrlRegs.GPBMUX2.bit.GPIO54 = 0;
        GpioDataRegs.GPBDAT.bit.GPIO54  = 1;
        GpioCtrlRegs.GPBDIR.bit.GPIO54  = 1;
    EDIS;
#endif
}

/******************************************************************************
*                            FPGAInterruptHandler                             *
*                            ====================                             *
* PURPOSE: Interrupt handler for interrupt from FPGA                          * 
* ARGUMENTS: None.                                                            *
* RETURN:    None.                                                            *
* NOTES:                                                                      *
*                                                                             *
******************************************************************************/
VOID BOXCLASS::FPGAInterruptHandler(VOID)
{
    PieCtrlRegs.PIEACK.all  = PIEACK_GROUP1;
    UINT16* InterruptReg = (UINT16*)0x2008D8;
    HARDFAILTYPE HfCode = HF_UNKNOWN;
    switch(*InterruptReg)
    {
        case 1:
            HfCode = HF_TCPARITYFAIL;
            break;
        case 2:
            HfCode = HF_TCXREADYFAIL;
            break;
        case 4:
            HfCode = HF_TCLVDTADCFAIL;
            break;
        case 8:
            HfCode = HF_TCDACRBFAIL;
            break;
        default:HfCode = HF_UNKNOWN;
            break;
    }
    HardFail(HfCode,DIAG_CPP,__LINE__);
}

/*******************************************************************************
*                                     HardFail                                 *
*                                     ========                                 *
*  HardFail is called when an unrecoverable HW or SW error is detected by the  *
*  firmware. This function responds in three separate ways:                    *
*  1) If this is release build, fail code and trace information is saved and   *
*     DIAGFAIL is asserted, immediately taking down the module.                *
*  2) If this is debug build and the fault is detected during startup (before  *
*     scheduler timer starts), debug prompt is updated to indicate the failure *
*     code and the function returns back to the calling code. This is to allow *
*     modules with HW failures to be started up suceessfully in debug mode so  *
*     that diagnosis of the problem can be performed.                          *
*  3) If this is debug build and the fault is detected after startup, module   *
*     goes to a debug-only mode by stopping all the tasks and interrupts.      *
*******************************************************************************/
VOID HardFail(HARDFAILTYPE a_HfCode,const FILE_NAME a_FlIdx,UINT16 a_LnNo,  
                                                    UINT8 a_Parm1,UINT8 a_Parm2)
{
    HFEVENT HfEventType;
    
    HfEventType.bit.HfCmd = TRUE;
    HfEventType.bit.Reserved = FALSE; // This bit should be FALSE to make sure it is not softfail.
    HfEventType.bit.HfType =  a_HfCode;
    PrintStr("HF::");
    PrintVal(a_HfCode);
    while(!AppScsFifo.SendSCSCommand(HfEventType.all));
    asm("        ESTOP0");
}   

/*******************************************************************************
*                            IdleWait                                          *
*                            ========                                          *
* PURPOSE: Function to wait CPU for requested time              .              *
* ARGUMENTS:  a_uidlewait - Idle Time                                          *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID IdleWait(UINT16 a_uidlewait)
{
    DELAY_US(a_uidlewait);
}

#endif //#if DSC

#if (defined(IOMTYPE_SVP) && defined(DSC))
/*******************************************************************************
*                            clsAiLvdtSlot::DoAiOpenWireDiag                   *
*                            ===============================                   *
* PURPOSE: This method detects the AI channel Openwire diagnostics             *
* ARGUMENTS:fl_RawData - Raw data                                              *
* RETURN:  DIAGSTATUS - DIAG_OK if no openwire condition, DIAG_UNCERN if starts*
*          suspecting openwire problem, DIAG_FAIL on openwire condition        *
* NOTES:                                                                       *
*******************************************************************************/
DIAGSTATUS clsAiLvdtSlot::DoAiOpenWireDiag(FLOAT32 fl_RawData)
#elif (defined(IOMTYPE_SP) && defined(H8S))
DIAGSTATUS clsTcSpAiSlot::DoAiOpenWireDiag(FLOAT32 fl_RawData)
#endif
#if (defined(IOMTYPE_SVP) && defined(DSC)) || (defined(IOMTYPE_SP) && defined(H8S))
{
    DIAGSTATUS eDiagStatus = DIAG_OK;

    //if Open wire Detection is enable then only do the Owd diag
    // PAR#1-EO80LY - Open wire should not detect when PvSource is sub or Man
    if((TRUE==OwdEnable)&&(PTEXECST_ACTIVE == PtExecSt)&&(PVSOURCE_AUTO == PvSource))
    {
       if(fl_RawData <= INPUT_NAN_COUNT)
       {
           if(OpenwireCnt >= OPEN_WIRE_RETRY_CYCLES)
           {
               // log the Open wire soft failure
               BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,TRUE,ChanNum);
               eDiagStatus = DIAG_FAIL;
           }
           else
           {
               eDiagStatus = DIAG_UNCERN;
               OpenwireCnt++;
           }
       }
       else
       {
           BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
           OpenwireCnt = 0;
       }
    }
    else
    {
       //RTN Soft failure
       BOX->AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ChanNum);
       OpenwireCnt = 0;
    }

    return eDiagStatus;
}
#endif

#if  (defined(IOMTYPE_SVP) && defined(DSC)) || (defined(IOMTYPE_SP) && defined(H8S))
/*******************************************************************************
*                                   clsEeprom::ReadStatusRegister              *
*                                   =============================              *
* PURPOSE: This methods read the status register from EEPROM                   *
* ARGUMENTS: NONE                                                              *
* RETURN:   returns the status                                                 *
* NOTES:                                                                       *
*******************************************************************************/
volatile UINT16 ucData = 0xFF;
UINT8 clsEeprom::ReadStatusRegister(VOID)
{
    #ifdef H8S
        UINT8 ucSaveExr;
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
    #endif
    
    clsFPGACtrlReg EepromCtrlReg((UINT16*)&(EEPROM_SPI.CTRL));
 
    EepromCtrlReg = SS_DESELECT;
    
    IdleWait(1);  
    
    EEPROM_SPI.TXD_1 = (UINT16)((RD_STATUS_REG_CMD << 8) | 0); //Instruction for Status Reg read
    EEPROM_SPI.TXD_2 = 0;                          //send additional 8 clocks to get 
                                                 //the data from EEPROM

    EepromCtrlReg = SET_SS_REQ_BIT;
    while ((EEPROM_SPI.CTRL & RD_RDY_BIT) != RD_RDY_BIT);
    
    // Get data from receive FIFO.  
    EepromCtrlReg = SS_DESELECT;
    IdleWait(1); 
    ucData = EEPROM_SPI.RXD;    

    #ifdef H8S
        set_imask_exr(ucSaveExr);
    #endif
    return ((ucData & 0xFF00)>>8);
}

/*******************************************************************************
*                              clsEeprom::ReadByte                             *
*                              ===================                             *
* PURPOSE:  This method will read byte value from eeprom                       *
* ARGUMENTS: uAddressHi - High Address                                         *
*            uAddressLo - Low Address                                          *
* RETURN:   UINT8 - returns byte value                                         *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsEeprom::ReadByte(UINT8 uAddressHi,UINT8 uAddressLo)
{
    UINT16 ucData = 0x55;
    
    #ifdef H8S
        UINT8 ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
    #endif
    
    clsFPGACtrlReg EepromCtrlReg((UINT16*)&EEPROM_SPI.CTRL);
    
    //Reset the receive FIFO;
    EepromCtrlReg = SS_DESELECT;
    IdleWait(1); 
    
    if(uAddressHi)
    {
        uAddressHi = (0x8 | RXD_CMD);
    }  
    else
    {
        uAddressHi = RXD_CMD;
    }   
    
    EEPROM_SPI.TXD_1 = (UINT16) ((uAddressHi<<8) | uAddressLo) ;            //Instruction for read from addr < 255        EEPROM_SPI.TXD = EEPROM_RDHI;            //Instruction for read from addr > 255
    EEPROM_SPI.TXD_2 = (UINT16) 0 ;              //send only last 8 Bits of Address.
                                                 //the data from EEPROM

    EepromCtrlReg = SET_SS_REQ_BIT; // Set Req Bit and Slave select
     
    while ((EEPROM_SPI.CTRL & RD_RDY_BIT) != RD_RDY_BIT);
      
    EepromCtrlReg = SS_DESELECT;
      
    IdleWait(1);
    ucData = EEPROM_SPI.RXD;             // Get data from receive FIFO.
    
    #ifdef H8S    
        set_imask_exr(ucSaveExr);
    #endif
    
    return ((ucData&0xFF00)>>8);
}

/*******************************************************************************
*                              clsEeprom::ReadUint16                           *
*                              =====================                           *
* PURPOSE:  This method will read uint16 value from eeprom                     *
* ARGUMENTS: HiAdd - High Address                                              *
*            LoAdd - Low Address                                               *
* RETURN:   UINT16 - returns uint16 value                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsEeprom::ReadUint16(UINT8 HiAdd, UINT8 LoAdd)
{
    UINT16 Temp;
    Temp = ReadByte(HiAdd,LoAdd+1);
    Temp <<= 8;
    Temp |= ReadByte(HiAdd,LoAdd);
    return Temp;
}

/*******************************************************************************
*                              clsEeprom::ReadUint32                           *
*                              =====================                           *
* PURPOSE:  This method will read uint32 value from eeprom                     *
* ARGUMENTS: HiAdd - High Address                                              *
*            LoAdd - Low Address                                               *
* RETURN:   UINT32 - returns uint32 value                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT32 clsEeprom::ReadUint32(UINT8 HiAdd, UINT8 LoAdd)
{
    DATABYTES DataBytes;
    for (UINT8 ucCount=0;ucCount < sizeof(UINT32); ucCount++)
    {
        DataBytes.ucBytes[ucCount] = ReadByte(HiAdd,LoAdd+ucCount);
    }
    return DataBytes.ui32Val;
}

/*******************************************************************************
*                                   clsEeprom::ReadFloat                       *
*                                   ====================                       *
* PURPOSE:  This method will read float32 value from eeprom                    *
* ARGUMENTS: HiAdd - High Address                                              *
*            LoAdd - Low Address                                               *
* RETURN:   FLOAT32 - returns float32 value                                    *
* NOTES:                                                                       *
*******************************************************************************/
FLOAT32 clsEeprom::ReadFloat(UINT8 HiAdd, UINT8 LoAdd)
{
    DATABYTES DataBytes;
#ifdef H8S
    for (UINT8 ucCount=0;ucCount < sizeof(FLOAT32); ucCount++)
#else
    for (UINT8 ucCount=0;ucCount < 2; ucCount++)
#endif
    {
        volatile UINT16 temp = ucCount*2;
        volatile UINT16 readword;
#ifdef DSC
        readword = ReadUint16(HiAdd,LoAdd+temp);
        DataBytes.ucBytes[ucCount] = readword;
#else
        DataBytes.ucBytes[ucCount]= ReadByte(HiAdd,LoAdd+ucCount);
#endif        
    }
    return DataBytes.f32Val;
}

#ifdef DSC
typedef union tagDataBytes64
{
    INT16   i16Val[4];
    UINT16  ui16Val[4];
    INT64   i64Val;
    UINT64  ui64Val;
    FLOAT64 f64Val;
    UINT16   ucBytes[sizeof(FLOAT64)];
} DATABYTES64;

/*******************************************************************************
*                                  clsEeprom::ReadFloat64                      *
*                                  ======================                      *
* PURPOSE:  This method will read float64 value from eeprom                    *
* ARGUMENTS: HiAdd - High Address                                              *
*            LoAdd - Low Address                                               *
* RETURN:   FLOAT64 - returns float64 value                                    *
* NOTES:                                                                       *
*******************************************************************************/
FLOAT64 clsEeprom::ReadFloat64(UINT8 HiAdd, UINT8 LoAdd)
{
    DATABYTES64 DataBytes64;
#ifdef H8S
    for (UINT8 ucCount=0;ucCount < sizeof(FLOAT64); ucCount++)
#else
    for (UINT8 ucCount=0;ucCount < 4; ucCount++)
#endif
    {
        volatile UINT16 temp = ucCount*2;
        volatile UINT16 readword;
        readword = ReadUint16(HiAdd,LoAdd+temp);
        DataBytes64.ucBytes[ucCount] = readword;
    }
    return DataBytes64.f64Val;
}
#endif //#ifdef DSC

/*******************************************************************************
*                                   clsEeprom::WriteByte                       *
*                                   ====================                       *
* PURPOSE:   This method will write a byte value to EEPROM                     *
* ARGUMENTS: uAddressHi - High Address                                         *
*            uAddressLo - Low Address                                          *
*            ucData - Data which needs to be written                           *
* RETURN:    None                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsEeprom::WriteByte(UINT8 uAddressHi,UINT8 uAddressLo, UINT8 ucData)
{
    #ifdef H8S
        UINT8 ucSaveExr;
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
    #endif
    
    clsFPGACtrlReg EepromCtrlReg((UINT16*)&EEPROM_SPI.CTRL);
    
    EepromCtrlReg = SS_DESELECT;
    IdleWait(1);
    
    if(uAddressHi)
    {
        uAddressHi = (0x8 | TXD_CMD);
    }  
    else
    {
        uAddressHi = TXD_CMD;
    }
    EEPROM_SPI.TXD_1 = (UINT16) ((uAddressHi<<8) | (uAddressLo & 0x00FF)) ;            //Instruction for read from addr < 255        EEPROM_SPI.TXD = EEPROM_RDHI;            //Instruction for read from addr > 255
    EEPROM_SPI.TXD_2 = (UINT16) ((ucData<<8) | 0) ;  //send only last 8 Bits of Address.
    
    EepromCtrlReg = SET_SS_REQ_BIT;  // Set Req Bit and Slave select
   
    while ((EEPROM_SPI.CTRL & RD_RDY_BIT) != RD_RDY_BIT);

    EepromCtrlReg = SS_DESELECT; // Deassert slave select.
    
#ifdef H8S
    set_imask_exr(ucSaveExr);
#endif
    
    //EEPROM Write Byte takes typically 5msec. So wait for 5 msec 
    //then ensure that the write is complete
    IdleWait(EEPROM_WRITE_WAIT);
    
    //If write is still in progress. Wait for additional 5msec. But in 1msec intervals
    UINT16 Count = 0;
    UINT16 WriteComplete = 0;
    do
    {
        WriteComplete = Eeprom.ReadStatusRegister() & SPI_EEPROM_WIP;
        if(WriteComplete == SPI_EEPROM_WIP)
        {
            IdleWait(1000);
            Count++;
        }
        else
        {
            break; //Write complete        
        }
    }
    while(Count < MAX_WRITE_ADDITIONAL_WAIT);
}

/*******************************************************************************
*                                   clsEeprom::EnableWrite                     *
*                                   ======================                     *
* PURPOSE:  This method will enable write to eeprom                            *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsEeprom::EnableWrite(VOID)
{
    #ifdef H8S
        UINT8 ucSaveExr;
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
    #endif
    
    // Disable the Write Protect for EEPROM. 
    //send the Write Enable to SPI EEPROM first
    clsFPGACtrlReg EepromCtrlReg((UINT16*)&EEPROM_SPI.CTRL);

    EepromCtrlReg = SS_DESELECT;
        
    #ifdef DSC
    clsFPGACtrlReg CtrlReg(&WRPROTECT);
    CtrlReg = 0x04;
    #else
    clsFPGACtrlReg CtrlReg(&EEPROM_SPI.WRPROTECT);
    UINT16 EnbleWrite = 0x05;
    CtrlReg = EnbleWrite;
    #endif
    IdleWait(1000);


    RefreshWDT();

    EEPROM_SPI.TXD_1 = (UINT16)((WR_ENABLE_CMD << 8) | 0); //Instruction for write Enable
    EEPROM_SPI.TXD_2 = 0;

    EepromCtrlReg = SET_SS_REQ_BIT;
    while ((EEPROM_SPI.CTRL & RD_RDY_BIT) != RD_RDY_BIT);  // Wait for TXDR to empty.

    EepromCtrlReg = SS_DESELECT;
    IdleWait(1);
    
    #ifdef H8S
        set_imask_exr(ucSaveExr);
    #endif
}

/*******************************************************************************
*                                   clsEeprom::DisableWrite                    *
*                                   =======================                    *
* PURPOSE:  This method will disable the write to eeprom                       *
* ARGUMENTS: NONE                                                              *
* RETURN:    NONE                                                              *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsEeprom::DisableWrite(VOID)
{
    #ifdef H8S
        UINT8 ucSaveExr;
        ucSaveExr = get_imask_exr();
        set_imask_exr(LVLPRI_HIGHEST);
    #endif
    
    clsFPGACtrlReg EepromCtrlReg((UINT16*)&EEPROM_SPI.CTRL);
    
    // Enable the Write Protect for EEPROM
    //send the Write Disable to SPI EEPROM.
    EepromCtrlReg = SS_DESELECT;
    EEPROM_SPI.TXD_1 = (UINT16)((RESET_WR_ENABLE_CMD << 8) | 0);   //Instruction for write disable
    EEPROM_SPI.TXD_2 = 0;

    EepromCtrlReg = SET_SS_REQ_BIT;
    while ((EEPROM_SPI.CTRL & RD_RDY_BIT) != RD_RDY_BIT);  

    EepromCtrlReg = SET_SS_REQ_BIT;
    
    #ifdef H8S
        set_imask_exr(ucSaveExr);
    #endif
}

/*******************************************************************************
*                            clsEeprom::ComputeEepromChecksum                  *
*                            ================================                  *
* PURPOSE: This rotuine does the checksum of the EEPROM contents. The checksum *
*          is made using XOR and rotate right word.                            *
* ARGUMENTS: NONE                                                              *
* RETURN: UINT16 - returns checksum value                                      *
* NOTES:                                                                       *
*******************************************************************************/
UINT16 clsEeprom::ComputeEepromChecksum(VOID)
{
    volatile UINT16 index = 0;
    volatile UINT16 uChksum = 0;
    UINT16 NumBytes = MAX_EEPROM_SIZE-2;  // Number of bytes to checksum
    for (index = 0; index < NumBytes; index++) {
        uChksum ^= (ReadUint16(0,index));
        uChksum >>= 1;  // rotate right once
        index++;    // increment the index so that address and count macthes.
    }
    return(uChksum);
}

/*******************************************************************************
*                            clsEeprom::ValidateEepromChecksum                 *
*                            =================================                 *
* PURPOSE: This rotuine compares checksum of the EEPROM contents.              *
* ARGUMENTS: NONE                                                              *
* RETURN: returns TRUE on success                                               *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsEeprom::ValidateEepromChecksum(VOID)
{
    //Calculate the checksum
    volatile UINT16 uChksum = ComputeEepromChecksum();
    volatile UINT16 eeChksum= Eeprom.ReadUint16(1,EE_CKSUM_ADD);
    if (eeChksum == uChksum)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

#endif //#if  (defined(IOMTYPE_SVP) && defined(DSC)) || (defined(IOMTYPE_SP) && defined(H8S))
