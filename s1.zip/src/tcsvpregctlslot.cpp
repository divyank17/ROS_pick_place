/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcsvpregctlslot.cpp                                         *
*    Description : Class clsSvpRegCtlSlot definition.                         *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "svpmain.h"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern SHRAMDATA ShramData;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsSvpRegCtlSlot::RedParams[] = {
    kSvpRegCtlPnPntType, 
    kSvpRegCtlPnPtExecSt,
    kSvpRegCtlPnMode,
    kSvpRegCtlPnModeAttr,
    kSvpRegCtlPnNormMode,
    kSvpRegCtlPnNormModeAttr,
    kSvpRegCtlPnModePerm,
    kSvpRegCtlPnRedTag,
    kSvpRegCtlPnPrefPv,
    kSvpRegCtlPnPvEUHi,
    kSvpRegCtlPnPvEULo,
    kSvpRegCtlPnPv1Conn,
    kSvpRegCtlPnPv2Conn,
    kSvpRegCtlPnCtlActn,
    kSvpRegCtlPnCtlEqn,
    kSvpRegCtlPnT1,
    kSvpRegCtlPnT1HiLm,
    kSvpRegCtlPnT1LoLm,
    kSvpRegCtlPnT2,
    kSvpRegCtlPnT2HiLm,
    kSvpRegCtlPnT2LoLm,
    kSvpRegCtlPnGainHiLm,
    kSvpRegCtlPnGainLoLm,
    kSvpRegCtlPnK,   
    kSvpRegCtlPnEqnEUnitsOpt, 
    kSvpRegCtlPnOpHiLm,
    kSvpRegCtlPnOpLoLm,
    kSvpRegCtlPnOpExHiLm,
    kSvpRegCtlPnOpExLoLm,
    kSvpRegCtlPnOpMinChg,
    kSvpRegCtlPnSafeOp,
    kSvpRegCtlPnOpTol,
    kSvpRegCtlPnOutInd,
    kSvpRegCtlPnSpTol,
    kSvpRegCtlPnSpHiLm,
    kSvpRegCtlPnSpLoLm,
    kSvpRegCtlPnTmOutMode,
    kSvpRegCtlPnTmOutTime, 
    kSvpRegCtlPnBadCtlOpt,
    kSvpRegCtlPnCvEUHi,
    kSvpRegCtlPnCvEULo,
    kSvpRegCtlPnOpBias_Fix,
    kSvpRegCtlPnOpBias_Rate,
    0 // Terminator
};

const PIDSLOTPARAMINFO clsSvpRegCtlSlot::tblParamInfo[] = { // Build paraminfo table
 //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
//  FILL 0 index to 50th index///////////////////////////////////////////////////////////////////////////////////////////
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPntTypePtr,TRUE,                           // 51 PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPtExecStPtr,TRUE,                         // 52 PtExecSt
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVEORIDLE,0,0,GetPvEUHiPtr,TRUE,              // 53 PvEUHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_INACTIVEORIDLE,0,0,GetPvEULoPtr,TRUE,              // 54 PvEULo
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetModeAttrPtr,TRUE,                         // 55 ModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetModePtr,TRUE,                             // 56 Mode
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetModePermPtr,TRUE,                          // 57 ModePerm
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetNormModeAttrPtr,TRUE,                     // 58 NModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetNormModePtr,TRUE,                         // 59 NMode
    DT_FLOAT32,4,AT_BXREC,ALCK_OPER,CONTROLSTATE_ACTIVEANDRUN,0,0,GetOpPtr,FALSE,                   // 60 Op
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetRedTagPtr,TRUE,                           // 61 RedTag
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 62 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 63
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetInitValPtr,FALSE,                      // 64 InitVal
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetPrefPvSrcPtr,TRUE,                         // 65 PrefPvSrc
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetCtlEqnPtr,TRUE,                            // 66 CtlEqn
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetCtlActnPtr,TRUE,                          // 67 CtlActn
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetT1Ptr,TRUE,                            // 68 T1
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetT1HiLmPtr,TRUE,                        // 69 T1HiLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetT1LoLmPtr,TRUE,                        // 70 T1LoLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetT2Ptr,TRUE,                            // 71 T2
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetT2HiLmPtr,TRUE,                        // 72 T2HiLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetT2LoLmPtr,TRUE,                        // 73 T2LoLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetGainHiLmPtr,TRUE,                      // 74 GainHiLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetGainLoLmPtr,TRUE,                      // 75 GainLoLm
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetGainOptPtr,TRUE,                           // 76 GainOpt
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetKPtr,TRUE,                             // 77 K
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVEORIDLE,0,0,GetEqnEUnitsOptPtr,TRUE,            // 78 EqnEUnitsOpt 
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetSpPtr,FALSE,                           // 79 Sp
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetSpHiLmPtr,TRUE,                        // 80 SpHiLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetSpLoLmPtr,TRUE,                        // 81 SpLoLm
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetTmOutModePtr,TRUE,                        // 82 TmOutMode
    DT_INT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetTmOutTimePtr,TRUE,                       // 83 TmOutTime //Note:: crosscheck for datatype
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetSpTolPtr,TRUE,                         // 84 SpTol
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvTrakOptPtr,FALSE,                       // 85 PvTrakOpt
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvTrakOptAiPtr,FALSE,                     // 86 PvTrakOptAi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOpHiLmPtr,TRUE,                        // 87 OpHiLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOpLoLmPtr,TRUE,                        // 88 OpLoLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOpExHiLmPtr,TRUE,                      // 89 OpExHiLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOpExLoLmPtr,TRUE,                      // 90 OpExLoLm
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOpMinChgLmPtr,TRUE,                    // 91 OpMinChg
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetCvEuHiPtr,TRUE,                        // 92 CvEuHi
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetCvEuLoPtr,TRUE,                        // 93 CvEuLo
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetOpBiasFixPtr,TRUE,                     // 94 OpBiasFix
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetSafeOpPtr,FALSE,                       // 95 SafeOp
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOpTolPtr,TRUE,                         // 96 OpTol
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOutIndPtr,FALSE,                          // 97 OutInd
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetBadCtlOptPtr,TRUE,                        // 98 BadCtlOpt
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv1,FALSE,                             // 99 SVPPIDPV1
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv2,FALSE,                             // 100 SVPPIDPV2
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPv1ConnectionDataPtr,TRUE,                // 101 PV1Connnection
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPv2ConnectionDataPtr,TRUE,                // 102 PV2Connnection
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadCtlFlPtr,FALSE,                        // 103 BadCtlFl
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCvPtr,FALSE,                           // 104 Cv
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetInitManPtr,FALSE,                         // 105 InitMan
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetLastGoodPvPtr,FALSE,                   // 106 LastGoodPv
    DT_FLOAT32,4,AT_MBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetOpBiasPtr,FALSE,                       // 107 OPBias
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpEuPtr,FALSE,                         // 108 OpEu
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpHiFlPtr,FALSE,                          // 109 OpHiFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpLoFlPtr,FALSE,                          // 110 OpLoFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpExHiFlPtr,FALSE,                        // 111 OpExHiFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpExLoFlPtr,FALSE,                        // 112 OpExLoFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSpHiFlPtr,FALSE,                          // 113 SpHiFl
    DT_BLIND,124,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCheckPointPtr,TRUE,                     // 114 CheckPoint
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCtlInitPtr,FALSE,                         // 115 CtlInit
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCtlStatePtr,FALSE,                        // 116 CtlState
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetArwNetPtr,FALSE,                          // 117 ArwNet
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetArwOpPtr,FALSE,                           // 118 ArwOp
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSecInitValPtr,FALSE,                   // 119 Sec InitVal
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSecInitStsPtr,FALSE,                      // 120 Sec InitSts
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSecArwStsPtr,FALSE,                       // 121 Sec ArwSts
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPriInitValPtr,FALSE,                   // 122 Pri InitVal
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPriInitStsPtr,FALSE,                      // 123 Pri InitSts
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPriArwStsPtr,FALSE,                       // 124 Pri ArwSts
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetBadPvFlPtr,FALSE,                         // 125 BadPvFl
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvPtr,FALSE,                           // 126 Pv
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetOpBiasRatePtr,TRUE,                    // 127 BiasRate
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvSts,FALSE,                              // 128 PvSts
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv1Sts,FALSE,                             // 129 Pv1Sts
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPv2Sts,FALSE,                             // 130 Pv2Sts
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetTimeoutFlag,FALSE,                        // 131 TimeoutFlag
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSpLoFlPtr,FALSE,                          // 132 SpLoFl
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetInitReqPtr,FALSE,                         // 133 InitReq
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetPvSelPtr,FALSE,                           // 134 PvSel
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpBiasFloatPtr,FALSE,                  // 135 OpBiasFloat
    DT_INT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetTimeoutCountPtr,FALSE,                   // 136 TimeoutCount
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 137
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 138
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 139
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 140
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 141
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,              // 142 SlotChkpntVersion
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 143
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 144
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 145
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 146
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 147
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 148
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 149
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 150
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 151
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 152
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 153
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 154
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 155
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 156
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 157
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 158
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 159   
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 160 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 161 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 162  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 164 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 165 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 166 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 167 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 168 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 169 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 170 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 171 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 172 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 173 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 174 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 175 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 176 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 178 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 179 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 180 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 181 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 182 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 183 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 184 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 185 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 186 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 187 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 188 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 190 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 191 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 192 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 193 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 194 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 195 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 196 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 197 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 198 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 199 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 200 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 201 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 202 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 208 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 209 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 210 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 211 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 212 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 213 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 214
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 215
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 216
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 217 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 218 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 219
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 220 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 221 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 222 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 223 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 224 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 225 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 226 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 227 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 228 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 229 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 230 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 231 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 232 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 233 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 234 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 235 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 236 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 237 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 238 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 239 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 240 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 241 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 242 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 243 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 244 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 245
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 246
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 247
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 248
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 251 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 252 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 253 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 254 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                                      // 255
};

/*******************************************************************************
*                            clsSvpRegCtlSlot::clsSvpRegCtlSlot              *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsSvpRegCtlSlot::clsSvpRegCtlSlot( UINT8 a_ucSltNm ) : clsIomSlot( a_ucSltNm) 
{
    //Get the slot shared ram pointer into local variable
    UINT8 nSlotNum = a_ucSltNm - SVPREGCTL_CHANNEL_START_INDEX;
    pRegCtlShramSlotData = &ShramData.ShramSlotData.RegCtlShramSlotData[nSlotNum];

    //Initialize the class member variables
    InitPidSlot();
}

/*******************************************************************************
*                           clsSvpRegCtlSlot::operator new                     *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsSvpRegCtlSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return (ucIomDbMemory + SVPBOXSLOT_SIZE + (AI_MAXSLOTS * AILVDTSLOT_SIZE)+ 
           (AO_MAXSLOTS * AOSERVOSLOT_SIZE)+ (DI_MAXSLOTS * DISLOT_SIZE)+ 
           ((a_ucSltNm-SVPREGCTL_CHANNEL_1)* SVPREGCTL_SLOTSIZE));        
}

/*******************************************************************************
*                            clsSvpRegCtlSlot::GetDataType                    *
*                          ==========================                          *
* PURPOSE:    Returns the Data type of a requested parameter                   *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Data type                                                        *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsSvpRegCtlSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsSvpRegCtlSlot::GetAccessType                    *
*                          ==========================                          *
* PURPOSE:    Returns the access type of a requested parameter                 *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Access type                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsSvpRegCtlSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                            clsSvpRegCtlSlot::GetParamSize                   *
*                            ========================                          *
* PURPOSE:    Returns the Size of a requested parameter                        *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Size                                                             *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsSvpRegCtlSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsSvpRegCtlSlot::GetParamPtr                    *
*                            =======================                           *
* PURPOSE:    Returns the Pointer to the GetParamPtr of a requested parameter  *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Pointer to the GetParamPtr function                              *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsSvpRegCtlSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                           clsSvpRegCtlSlot::GetAccessLock                   *
*                           =========================                          *
* PURPOSE:    Returns the access lock of a requested parameter                 *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Access Lock                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsSvpRegCtlSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                       clsSvpRegCtlSlot::GetIsDbChecksumed                   *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsSvpRegCtlSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsSvpRegCtlSlot::VerifyControlState                *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsSvpRegCtlSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    UINT8 PntExecSts   = (PTEXECST)pRegCtlShramSlotData->PtExecSt;
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PntExecSts) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PntExecSts) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PntExecSts) || 
            (MODSTATUS_RUN != ModuleState)) 
        {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsSvpRegCtlSlot::ExecutePreFunction                *
*                         ==============================                       *
* PURPOSE:   Invokes the Prefunction of a request parameter                    *
* ARGUMENTS:                                                                   *
                a_ucParamNumber  - Parameter Number                            *
                a_Buffer         -   Pointer to the data                       *
*               a_ucAccessLevel  -   Access level of the parameter             *
* RETURN:                                                                      *
                PA_OK                                                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsSvpRegCtlSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}
/*******************************************************************************
*                         clsSvpRegCtlSlot::ExecutePostFunction               *
*                         ===============================                      *
* PURPOSE:   Invokes the Postfunction of a request parameter                   *
* ARGUMENTS:                                                                   *
                a_ucParamNumber  - Parameter Number                            *
*               a_ucAccessLevel  -   Access level of the parameter             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpRegCtlSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}

/*******************************************************************************
*                           clsSvpRegCtlSlot::InitSlotDatabase                *
*                           ============================                       *
*  Initialize the entire channel database. Calls the Init function for each    *
*  class in the channel object hierarchy and recompute database checksum.      *
*******************************************************************************/
VOID clsSvpRegCtlSlot::InitSlotDatabase(BOOL ) 
{
    InitPidSlot();
    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                            clsSvpRegCtlSlot::InitServoAoSlot                *
*                          ==========================                          *
* PURPOSE:    Initilizes required AO and Servo Params                          *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsSvpRegCtlSlot::InitPidSlot(VOID){
    
    PntType    = PNTTYPE_NOTCONFIGURED;
    PtExecSt   = PTEXECST_INACTIVE;

    OpData.Cv                = NaN;
    OpData.CvEuHi            = NaN;
    OpData.CvEuLo            = NaN;
    OpData.CvEuSpanBy100     = NaN;
    OpData.Op                = NaN;
    OpData.OpBiasFixed       = NaN;
    OpData.OpBiasFloat       = NaN;
    OpData.OpBiasRate        = NaN;
    OpData.OpBias            = NaN;
    OpData.OpEu              = NaN;
    OpData.NewOp             = NaN;
    OpData.LastOp            = NaN;
    OpData.LastOneshotSeqNum = 0;
    OpData.LastArwSts        = CF::kNormalArw;      
    OpData.ArwOp             = CF::kNormalArw;

    InputData.TimeoutCount            = 0;
    InputData.TimeOutValue            = 0;
    InputData.ArwNet                  = CF::kNormalArw;
    InputData.TimeoutFlag             = FALSE;
    InputData.PrimaryInputHi          = FALSE;
    InputData.PrimaryInputLo          = FALSE;
    InputData.PrimaryIsConnected      = FALSE;
    InputData.PrimaryIsInitializable  = FALSE;
    InputData.PriOpIndex              = 0; 
    InputData.PvSel                   = PVSEL_PV1;

    Mode              =CF::kManCtlMode;
    ModeAttr          =CF::kOper;
    NormMode          =CF::kNormalCtlMode;
    NormModeAttr      =CF::kNone;
    ModePerm          =kNotPerm;
    Redtag            =FALSE;

    PrefPvSrc         =PREFPVSRC_NONE;
    Pv                =NaN;
    BadPvFl           =FALSE;
    PvEUHi            =NaN;
    PvEULo            =NaN;
    Pv1               =NaN;
    Pv2               =NaN;
    Pv1ConnectionData =ZERO;
    Pv2ConnectionData =ZERO;
    LastGoodPv        =NaN;

    CtlActn           =kDirectCtlActn;
    CtlEqn            =kCtlEqnA;
    T1                =NaN;
    T1HiLm            =NaN;
    T1LoLm            =NaN;
    T2                =NaN;
    T2HiLm            =NaN;
    T2LoLm            =NaN;
    GainHiLm          =NaN;
    GainLoLm          =NaN;
    GainOpt           =kLinGain;
    K                 =NaN;   
    EqnEUnitsOpt      =ENGG_UNITS;

    OpHiLm            =NaN;
    OpLoLm            =NaN;
    OpExHiLm          =SVPREGCTL_OPEXHILM;
    OpExLoLm          =SVPREGCTL_OPEXLOLM;
    OpHiFl            =FALSE;
    OpLoFl            =FALSE;
    OpMinChgLm        =ZERO;
    SafeOp            =NaN;
    OpTol             =NaN;
    OutInd            =kDirect;

    PvTrakOpt         =kNoPvTrack;
    PvTrakOptAi       =kNoPvTrack;

    Sp                =0;
    SpTol             =NaN;
    SpHiLm            =NaN;
    SpLoLm            =NaN;
    SpExEuLo          =NaN;
    SpExEuHi          =NaN;
    SpEuHi            =NaN;
    SpEuLo            =NaN;
    SpHiFl            =FALSE;
    SpLoFl            =FALSE;
    InitReq           =FALSE;
    TmOutMode         =CF::kManCtlMode;
    TmOutTime         =0; 

    BadCtlFl          =FALSE;
    BadCtlOpt         =CF::kNoShed;

    InitVal           =NaN;
    InitMan           =FALSE;

    CtlInit           =FALSE;
    CtlState          =kHoldCtlState;

    ArwOp             =CF::kNormalArw;
    ArwNet            =CF::kNormalArw;
    ArwSts            =CF::kNormalArw;

    PvSts             =kBadValSts;
    Pv1Sts            =kBadValSts;
    Pv2Sts            =kBadValSts;

    SecInitVal        =NaN;
    SecStatus         =0;
    SecArwSts         =CF::kNormalArw;

    PriInitVal        =NaN;
    PriStatus         =0;
    PriArwSts         =CF::kNormalArw;
}

/*******************************************************************************
*                    Get Methods for RegCtl Channels Parameters                    *
*******************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////
//Getting the data from shared ram database into local copy and returns the pointers
//////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
//Overrided clsIoSlot Class Varibles GetPtr methods
//////////////////////////////////////////////////////////
VOID *clsSvpRegCtlSlot::GetPntTypePtr(VOID)         
{ 
    PntType = (PNTTYPE)pRegCtlShramSlotData->PntType;
    return &PntType;
}

VOID *clsSvpRegCtlSlot::GetPtExecStPtr(VOID)        
{
    PtExecSt = (PTEXECST)pRegCtlShramSlotData->PtExecSt;

    return &PtExecSt;        
}

///////////////////////////////////////////////////////////
//Member Varibles GetPtr methods
///////////////////////////////////////////////////////////
VOID *clsSvpRegCtlSlot::GetPvEUHiPtr(VOID)     
{
    PvEUHi = (FLOAT32)pRegCtlShramSlotData->PvEUHi;

    return &PvEUHi;
}

VOID *clsSvpRegCtlSlot::GetPvEULoPtr(VOID)     
{
    PvEULo = (FLOAT32)pRegCtlShramSlotData->PvEULo;

    return &PvEULo;
}

VOID *clsSvpRegCtlSlot::GetModeAttrPtr(VOID)   
{
    ModeAttr = (CF::enmModeAttr)pRegCtlShramSlotData->ModeAttr;

    return &ModeAttr;
}

VOID *clsSvpRegCtlSlot::GetModePtr(VOID)       
{
    Mode = (CF::enmCtlMode)pRegCtlShramSlotData->Mode;

    return &Mode;
}

VOID *clsSvpRegCtlSlot::GetNormModeAttrPtr(VOID)
{
    NormModeAttr = (CF::enmModeAttr)pRegCtlShramSlotData->NModeAttr;

    return &NormModeAttr;
}

VOID *clsSvpRegCtlSlot::GetNormModePtr(VOID)   
{
    NormMode = (CF::enmCtlMode)pRegCtlShramSlotData->NMode;

    return &NormMode;
}

VOID *clsSvpRegCtlSlot::GetModePermPtr(VOID)   
{
    ModePerm = (enmPermissive)pRegCtlShramSlotData->ModePerm;

    return &ModePerm;
}

VOID *clsSvpRegCtlSlot::GetRedTagPtr(VOID)     
{
    Redtag = (BOOL)pRegCtlShramSlotData->RedTag;

    return &Redtag;
}

VOID *clsSvpRegCtlSlot::GetPrefPvSrcPtr(VOID)  
{
    PrefPvSrc = (PREFPVSRC)pRegCtlShramSlotData->PrefPvSrc;

    return &PrefPvSrc;
}
   
VOID *clsSvpRegCtlSlot::GetPvPtr(VOID)         
{
    Pv = (FLOAT32)pRegCtlShramSlotData->Pv;

    return &Pv;
}

VOID *clsSvpRegCtlSlot::GetPvSts(VOID)
{
     PvSts = (enmValSts)pRegCtlShramSlotData->PvSts;

     return &PvSts;
}

VOID *clsSvpRegCtlSlot::GetPv1Sts(VOID)
{
     Pv1Sts = (enmValSts)pRegCtlShramSlotData->Pv1Sts;

     return &Pv1Sts;
}

VOID *clsSvpRegCtlSlot::GetPv2Sts(VOID)
{
     Pv2Sts = (enmValSts)pRegCtlShramSlotData->Pv2Sts;

     return &Pv2Sts;
}

VOID *clsSvpRegCtlSlot::GetTimeoutFlag(VOID)
{
     InputData.TimeoutFlag = (BOOL)pRegCtlShramSlotData->TimeoutFlag;

     return &InputData.TimeoutFlag;
}

VOID *clsSvpRegCtlSlot::GetBadPvFlPtr(VOID)    
{
    BadPvFl = (BOOL)pRegCtlShramSlotData->BadPvFl;

    return &BadPvFl;
}

VOID *clsSvpRegCtlSlot::GetPv1(VOID)        
{
    Pv1 = (FLOAT32)pRegCtlShramSlotData->Pv1;

    return &Pv1;
}

VOID *clsSvpRegCtlSlot::GetPv2(VOID)        
{
    Pv2 = (FLOAT32)pRegCtlShramSlotData->Pv2;

    return &Pv2;
}

VOID *clsSvpRegCtlSlot::GetPv1ConnectionDataPtr(VOID)
{
    Pv1ConnectionData = (INT32)pRegCtlShramSlotData->Pv1Connection;

    return &Pv1ConnectionData;
}

VOID *clsSvpRegCtlSlot::GetPv2ConnectionDataPtr(VOID)
{
    Pv2ConnectionData = (INT32)pRegCtlShramSlotData->Pv2Connection;

    return &Pv2ConnectionData;
}

VOID *clsSvpRegCtlSlot::GetLastGoodPvPtr(VOID)
{
    LastGoodPv = (FLOAT32)pRegCtlShramSlotData->LastGoodPv;

    return &LastGoodPv;
}

VOID *clsSvpRegCtlSlot::GetCtlEqnPtr(VOID)     
{
    CtlEqn = (enmCtlEqn)pRegCtlShramSlotData->CtlEqn;

    return &CtlEqn;
}  

VOID *clsSvpRegCtlSlot::GetCtlActnPtr(VOID)    
{
    CtlActn = (enmCtlActn)pRegCtlShramSlotData->CtlActn;

    return &CtlActn;
}  

VOID *clsSvpRegCtlSlot::GetT1Ptr(VOID)         
{
    T1 = (FLOAT32)pRegCtlShramSlotData->T1;

    return &T1;
}  

VOID *clsSvpRegCtlSlot::GetT1LoLmPtr(VOID)     
{
    T1LoLm = (FLOAT32)pRegCtlShramSlotData->T1LoLm;

    return &T1LoLm;
}  

VOID *clsSvpRegCtlSlot::GetT1HiLmPtr(VOID)     
{
    T1HiLm = (FLOAT32)pRegCtlShramSlotData->T1HiLm;

    return &T1HiLm;
}  

VOID *clsSvpRegCtlSlot::GetT2Ptr(VOID)        
{
    T2 = (FLOAT32)pRegCtlShramSlotData->T2;

    return &T2;
}  

VOID *clsSvpRegCtlSlot::GetT2LoLmPtr(VOID)     
{
    T2LoLm = (FLOAT32)pRegCtlShramSlotData->T2LoLm;

    return &T2LoLm;
}  

VOID *clsSvpRegCtlSlot::GetT2HiLmPtr(VOID)     
{
    T2HiLm = (FLOAT32)pRegCtlShramSlotData->T2HiLm;

    return &T2HiLm;
}  

VOID *clsSvpRegCtlSlot::GetGainLoLmPtr(VOID)   
{
    GainLoLm = (FLOAT32)pRegCtlShramSlotData->GainLoLm;

    return &GainLoLm;
}  

VOID *clsSvpRegCtlSlot::GetGainHiLmPtr(VOID)   
{
    GainHiLm = (FLOAT32)pRegCtlShramSlotData->GainHiLm;

    return &GainHiLm;
}  

VOID *clsSvpRegCtlSlot::GetGainOptPtr(VOID)    
{
    GainOpt = (enmGainOpt)pRegCtlShramSlotData->GainOpt;

    return &GainOpt;
}

VOID *clsSvpRegCtlSlot::GetKPtr(VOID)          
{
    K = (FLOAT32)pRegCtlShramSlotData->K;

    return &K;
}  

VOID *clsSvpRegCtlSlot::GetEqnEUnitsOptPtr(VOID)
{
    EqnEUnitsOpt = (EQNEUNITSOPT)pRegCtlShramSlotData->EqnEuUnitsOpt;
    
    return &EqnEUnitsOpt;
}   

VOID *clsSvpRegCtlSlot::GetOpPtr(VOID)         
{
    OpData.Op = (FLOAT32)pRegCtlShramSlotData->Op;

    return &OpData.Op;
}

VOID *clsSvpRegCtlSlot::GetOpEuPtr(VOID)      
{
    OpData.OpEu = (FLOAT32)pRegCtlShramSlotData->OpEu;

    return &OpData.OpEu;
}

VOID *clsSvpRegCtlSlot::GetOpExLoLmPtr(VOID)   
{
    OpExLoLm = (FLOAT32)pRegCtlShramSlotData->OpExLoLm;

    return &OpExLoLm;
}  

VOID *clsSvpRegCtlSlot::GetOpExLoFlPtr(VOID)   
{
    OpData.OpExLoFl = (BOOL)pRegCtlShramSlotData->OpExLoFl;

    return &OpData.OpExLoFl;
}

VOID *clsSvpRegCtlSlot::GetOpExHiLmPtr(VOID)   
{
    OpExHiLm = (FLOAT32)pRegCtlShramSlotData->OpExHiLm;

    return &OpExHiLm;
}  

VOID *clsSvpRegCtlSlot::GetOpExHiFlPtr(VOID)   
{
    OpData.OpExHiFl = (BOOL)pRegCtlShramSlotData->OpExHiFl;

    return &OpData.OpExHiFl;
}

VOID *clsSvpRegCtlSlot::GetOpLoLmPtr(VOID)     
{
    OpLoLm = (FLOAT32)pRegCtlShramSlotData->OpLoLm;

    return &OpLoLm;
}
 
VOID *clsSvpRegCtlSlot::GetOpLoFlPtr(VOID)     
{
    OpLoFl = (BOOL)pRegCtlShramSlotData->OpLoFl;

    return &OpLoFl;
}

VOID *clsSvpRegCtlSlot::GetOpHiFlPtr(VOID)     
{
    OpHiFl = (BOOL)pRegCtlShramSlotData->OpHiFl;

    return &OpHiFl;
}

VOID *clsSvpRegCtlSlot::GetOpHiLmPtr(VOID)     
{
    OpHiLm = (FLOAT32)pRegCtlShramSlotData->OpHiLm;

    return &OpHiLm;
}  

VOID *clsSvpRegCtlSlot::GetOpMinChgLmPtr(VOID)   
{
    OpMinChgLm = (FLOAT32)pRegCtlShramSlotData->OpMinChg;
  
    return &OpMinChgLm;
}  

VOID *clsSvpRegCtlSlot::GetOpTolPtr(VOID)      
{
    OpTol = (FLOAT32)pRegCtlShramSlotData->OpTol;

    return &OpTol;
}  

VOID *clsSvpRegCtlSlot::GetOpBiasPtr(VOID)     
{
    OpData.OpBias = (FLOAT32)pRegCtlShramSlotData->OpBias;

    return &OpData.OpBias;
}

VOID *clsSvpRegCtlSlot::GetOpBiasFixPtr(VOID)  
{
    OpData.OpBiasFixed = (FLOAT32)pRegCtlShramSlotData->OpBiasFixed;

    return &OpData.OpBiasFixed;
}

VOID *clsSvpRegCtlSlot::GetOpBiasRatePtr(VOID)  
{
    OpData.OpBiasRate = (FLOAT32)pRegCtlShramSlotData->OpBiasRate;

    return &OpData.OpBiasRate;
}

VOID *clsSvpRegCtlSlot::GetSafeOpPtr(VOID)     
{
    SafeOp = (FLOAT32)pRegCtlShramSlotData->SafeOp;

    return &SafeOp;
}  

VOID *clsSvpRegCtlSlot::GetOutIndPtr(VOID)     
{
    OutInd = (enmOutInd)pRegCtlShramSlotData->OutInd;

    return &OutInd;
}  

VOID *clsSvpRegCtlSlot::GetPvTrakOptPtr(VOID)  
{
    PvTrakOpt = (enmPvTrackOpt)pRegCtlShramSlotData->PvTrakOpt;

    return &PvTrakOpt;
}  

VOID *clsSvpRegCtlSlot::GetPvTrakOptAiPtr(VOID)
{
    PvTrakOptAi = (enmPvTrackOpt)pRegCtlShramSlotData->PvTrakOptAi;

    return &PvTrakOptAi;
}

VOID *clsSvpRegCtlSlot::GetSpPtr(VOID)         
{
    Sp = (FLOAT32)pRegCtlShramSlotData->Sp;

    return &Sp;
}  

VOID *clsSvpRegCtlSlot::GetSpLoLmPtr(VOID)     
{
    SpLoLm = (FLOAT32)pRegCtlShramSlotData->SpLoLm;
 
    return &SpLoLm;
}  

VOID *clsSvpRegCtlSlot::GetSpLoFlPtr(VOID)     
{
    SpLoFl = (BOOL)pRegCtlShramSlotData->SpLoFl;

    return &SpLoFl;
}

VOID *clsSvpRegCtlSlot::GetSpHiLmPtr(VOID)     
{
    SpHiLm = (FLOAT32)pRegCtlShramSlotData->SpHiLm;

    return &SpHiLm;
}  

VOID *clsSvpRegCtlSlot::GetSpHiFlPtr(VOID)     
{
    SpHiFl = (BOOL)pRegCtlShramSlotData->SpHiFl;

    return &SpHiFl;
}

VOID *clsSvpRegCtlSlot::GetInitReqPtr(VOID)
{
    InitReq= (BOOL)pRegCtlShramSlotData->InitReq;

    return &InitReq;
}

VOID *clsSvpRegCtlSlot::GetPvSelPtr(VOID)
{
    InputData.PvSel= (PVSEL)pRegCtlShramSlotData->PvSel;

    return &InputData.PvSel;
}

VOID *clsSvpRegCtlSlot::GetTimeoutCountPtr(VOID)
{
    InputData.TimeoutCount = (INT32)pRegCtlShramSlotData->TimeoutCount;

    return &InputData.TimeoutCount;
}


VOID *clsSvpRegCtlSlot::GetOpBiasFloatPtr(VOID)
{
    OpData.OpBiasFloat= (FLOAT32)pRegCtlShramSlotData->OpBiasFloat;

    return &OpData.OpBiasFloat;
}

VOID *clsSvpRegCtlSlot::GetSpTolPtr(VOID)      
{
    SpTol = (FLOAT32)pRegCtlShramSlotData->SpTol;

    return &SpTol;
}  

VOID *clsSvpRegCtlSlot::GetTmOutTimePtr(VOID)  
{
    TmOutTime = (UINT32)pRegCtlShramSlotData->TmOutTime;

    return &TmOutTime;
}  

VOID *clsSvpRegCtlSlot::GetTmOutModePtr(VOID)  
{
    TmOutMode = (CF::enmCtlMode)pRegCtlShramSlotData->TmOutMode;

    return &TmOutMode;
}  

VOID *clsSvpRegCtlSlot::GetCvPtr(VOID)         
{
    OpData.Cv = (FLOAT32)pRegCtlShramSlotData->Cv;

    return &OpData.Cv;
}

VOID *clsSvpRegCtlSlot::GetCvEuLoPtr(VOID)    
{
    OpData.CvEuLo = (FLOAT32)pRegCtlShramSlotData->CvEuLo;

    return &OpData.CvEuLo;
}  

VOID *clsSvpRegCtlSlot::GetCvEuHiPtr(VOID)     
{
    OpData.CvEuHi = (FLOAT32)pRegCtlShramSlotData->CvEuHi;

    return &OpData.CvEuHi;
}  

VOID *clsSvpRegCtlSlot::GetBadCtlOptPtr(VOID)  
{
    BadCtlOpt = (CF::enmBadCtlOpt)pRegCtlShramSlotData->BadCtlOpt;

    return &BadCtlOpt;
}

VOID *clsSvpRegCtlSlot::GetBadCtlFlPtr(VOID)   
{
    BadCtlFl = (BOOL)pRegCtlShramSlotData->BadCtlFl;

    return &BadCtlFl;
}
    
VOID *clsSvpRegCtlSlot::GetInitValPtr(VOID)    
{
    InitVal = (FLOAT32)pRegCtlShramSlotData->InitVal;

    return &InitVal;
}

VOID *clsSvpRegCtlSlot::GetInitManPtr(VOID)    
{
    InitMan = (BOOL)pRegCtlShramSlotData->InitMan;

    return &InitMan;
}

VOID *clsSvpRegCtlSlot::GetCtlInitPtr(VOID)    
{
    CtlInit = (BOOL)pRegCtlShramSlotData->CtlInit;

    return &CtlInit;
}

VOID *clsSvpRegCtlSlot::GetCtlStatePtr(VOID)   
{
    CtlState = (enmCtlState)pRegCtlShramSlotData->CtlState;

    return &CtlState;
}

VOID *clsSvpRegCtlSlot::GetArwNetPtr(VOID)     
{
    ArwNet = (CF::enmArw)pRegCtlShramSlotData->ArwNet;

    return &ArwNet;
}

VOID *clsSvpRegCtlSlot::GetArwOpPtr(VOID)      
{
    ArwOp = (CF::enmArw)pRegCtlShramSlotData->ArwOp;

    return &ArwOp;
}

VOID *clsSvpRegCtlSlot::GetArwStsPtr(VOID)     
{
    //ArwSts = (CF::enmArw)pRegCtlShramSlotData->ArwSts;

    return &ArwSts;
}

VOID *clsSvpRegCtlSlot::GetSecInitValPtr(VOID)       
{
    SecInitVal = (FLOAT32)pRegCtlShramSlotData->SecInitVal;

    return &SecInitVal;
}

VOID *clsSvpRegCtlSlot::GetSecInitStsPtr(VOID)      
{
    SecStatus = (BOOL)pRegCtlShramSlotData->SecStatus;

    return &SecStatus;
}

VOID *clsSvpRegCtlSlot::GetSecArwStsPtr(VOID)       
{
    SecArwSts = (CF::enmArw)pRegCtlShramSlotData->SecArwSts;

    return &SecArwSts;
}

VOID *clsSvpRegCtlSlot::GetPriInitValPtr(VOID) 
{
    PriInitVal = (FLOAT32)pRegCtlShramSlotData->PriInitVal;

    return &PriInitVal;
}

VOID *clsSvpRegCtlSlot::GetPriInitStsPtr(VOID) 
{
    PriStatus = (BOOL)pRegCtlShramSlotData->PriStatus;

    return &PriStatus;
}

VOID *clsSvpRegCtlSlot::GetPriArwStsPtr(VOID)  
{
    PriArwSts = (CF::enmArw)pRegCtlShramSlotData->PriArwSts;

    return &PriArwSts;
}


/*******************************************************************************
*                         clsAiLvdtSlot::GetDumpData                           *
*                         ===============================                      *
* PURPOSE:  This method will copy the redundancy dump data to buffer transmit  *
*           to the secondary IOM                                               *
* ARGUMENTS:                                                                   *
                                                                               *
*                                                                              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS  clsSvpRegCtlSlot::GetDumpData(UINT8* const pDump, const UINT8 MaxSize)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL && sizeof(strSvpRegctlSlotDumpData) < MaxSize)
    {
        strSvpRegctlSlotDumpData *pDumpData = (strSvpRegctlSlotDumpData*)pDump;

        pDumpData->Version       = PACK2_AS_UI16(SVPREGCTL_SYNC_VER_1,0);
        pDumpData->PntType       = (PNTTYPE)pRegCtlShramSlotData->PntType;
        pDumpData->PtExecSt      = (PTEXECST)pRegCtlShramSlotData->PtExecSt;
        pDumpData->Mode          = (CF::enmCtlMode)pRegCtlShramSlotData->Mode;
        pDumpData->ModeAttr      = (CF::enmModeAttr)pRegCtlShramSlotData->ModeAttr;
        pDumpData->NormMode      = (CF::enmCtlMode)pRegCtlShramSlotData->NMode;
        pDumpData->NormModeAttr  = (CF::enmModeAttr)pRegCtlShramSlotData->NModeAttr;
        pDumpData->ModePerm      = (enmPermissive)pRegCtlShramSlotData->ModePerm;
        pDumpData->Redtag        = (BOOL)pRegCtlShramSlotData->RedTag;
        pDumpData->PrefPvSrc     = (PREFPVSRC)pRegCtlShramSlotData->PrefPvSrc;
        pDumpData->PvEUHi        = (FLOAT32)pRegCtlShramSlotData->PvEUHi;
        pDumpData->PvEULo        = (FLOAT32)pRegCtlShramSlotData->PvEULo;
        pDumpData->Pv1ConnectionData = (INT32)pRegCtlShramSlotData->Pv1Connection;
        pDumpData->Pv2ConnectionData = (INT32)pRegCtlShramSlotData->Pv2Connection;
        pDumpData->CtlActn       = (enmCtlActn)pRegCtlShramSlotData->CtlActn;
        pDumpData->CtlEqn        = (enmCtlEqn)pRegCtlShramSlotData->CtlEqn;
        pDumpData->T1            = (FLOAT32)pRegCtlShramSlotData->T1;
        pDumpData->T1HiLm        = (FLOAT32)pRegCtlShramSlotData->T1HiLm;
        pDumpData->T1LoLm        = (FLOAT32)pRegCtlShramSlotData->T1LoLm;
        pDumpData->T2            = (FLOAT32)pRegCtlShramSlotData->T2;
        pDumpData->T2HiLm        = (FLOAT32)pRegCtlShramSlotData->T2HiLm;
        pDumpData->T2LoLm        = (FLOAT32)pRegCtlShramSlotData->T2LoLm;
        pDumpData->GainHiLm      = (FLOAT32)pRegCtlShramSlotData->GainHiLm;
        pDumpData->GainLoLm      = (FLOAT32)pRegCtlShramSlotData->GainLoLm;
        pDumpData->K             = (FLOAT32)pRegCtlShramSlotData->K;   
        pDumpData->EqnEUnitsOpt  = (EQNEUNITSOPT)pRegCtlShramSlotData->EqnEuUnitsOpt; 
        pDumpData->OpHiLm        = (FLOAT32)pRegCtlShramSlotData->OpHiLm;
        pDumpData->OpLoLm        = (FLOAT32)pRegCtlShramSlotData->OpLoLm;
        pDumpData->OpExHiLm      = (FLOAT32)pRegCtlShramSlotData->OpExHiLm;
        pDumpData->OpExLoLm      = (FLOAT32)pRegCtlShramSlotData->OpExLoLm;
        pDumpData->OpMinChg      = (FLOAT32)pRegCtlShramSlotData->OpMinChg;
        pDumpData->SafeOp        = (FLOAT32)pRegCtlShramSlotData->SafeOp;
        pDumpData->OpTol         = (FLOAT32)pRegCtlShramSlotData->OpTol;
        pDumpData->OutInd        = (enmOutInd)pRegCtlShramSlotData->OutInd;
        pDumpData->Sp            = (FLOAT32)pRegCtlShramSlotData->Sp;
        pDumpData->SpTol         = (FLOAT32)pRegCtlShramSlotData->SpTol;
        pDumpData->SpHiLm        = (FLOAT32)pRegCtlShramSlotData->SpHiLm;
        pDumpData->SpLoLm        = (FLOAT32)pRegCtlShramSlotData->SpLoLm;
        pDumpData->TmOutMode     = (CF::enmCtlMode)pRegCtlShramSlotData->TmOutMode;
        pDumpData->TmOutTime     = (FLOAT32)pRegCtlShramSlotData->TmOutTime; 
        pDumpData->TimeoutCount   = (INT32)pRegCtlShramSlotData->TimeoutCount; 
        pDumpData->BadCtlOpt     = (CF::enmBadCtlOpt)pRegCtlShramSlotData->BadCtlOpt;
        pDumpData->CvEuHi        = (FLOAT32)pRegCtlShramSlotData->CvEuHi;
        pDumpData->CvEuLo        = (FLOAT32)pRegCtlShramSlotData->CvEuLo;
        pDumpData->OpBiasFixed   = (FLOAT32)pRegCtlShramSlotData->OpBiasFixed;
        pDumpData->OpBiasRate    = (FLOAT32)pRegCtlShramSlotData->OpBiasRate;
        pDumpData->OpBias        = (FLOAT32)pRegCtlShramSlotData->OpBias;
        pDumpData->OpEu          = (FLOAT32)pRegCtlShramSlotData->OpEu;

        pDumpData->Op            = (FLOAT32)pRegCtlShramSlotData->Op;
        RetVal = PA_OK;
    }
    return RetVal;
}

/*******************************************************************************
*                         clsSvpRegCtlSlot::StoreDumpData                      *
*                         ===============================                      *
* PURPOSE:  This method will copy the redundancy dump data into local dump     *
*           structure in Primary IOM                                           *
*                                                                              *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/

PASTATUS  clsSvpRegCtlSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL)
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SVPREGCTL_SYNC_VER_1)
        {
            strSvpRegctlSlotDumpData* pDumpData = (strSvpRegctlSlotDumpData*)(pDump);

            pRegCtlShramSlotData->PntType       = pDumpData->PntType;
            pRegCtlShramSlotData->PtExecSt      = pDumpData->PtExecSt;
            pRegCtlShramSlotData->Mode          = pDumpData->Mode;
            pRegCtlShramSlotData->ModeAttr      = pDumpData->ModeAttr;
            pRegCtlShramSlotData->NMode         = pDumpData->NormMode;
            pRegCtlShramSlotData->NModeAttr     = pDumpData->NormModeAttr;
            pRegCtlShramSlotData->ModePerm      = pDumpData->ModePerm;
            pRegCtlShramSlotData->RedTag        = pDumpData->Redtag;
            pRegCtlShramSlotData->PrefPvSrc     = pDumpData->PrefPvSrc;
            pRegCtlShramSlotData->PvEUHi        = pDumpData->PvEUHi;
            pRegCtlShramSlotData->PvEULo        = pDumpData->PvEULo;
            pRegCtlShramSlotData->Pv1Connection = pDumpData->Pv1ConnectionData;
            pRegCtlShramSlotData->Pv2Connection = pDumpData->Pv2ConnectionData;
            pRegCtlShramSlotData->CtlActn       = pDumpData->CtlActn;
            pRegCtlShramSlotData->CtlEqn        = pDumpData->CtlEqn;
            pRegCtlShramSlotData->T1            = pDumpData->T1;
            pRegCtlShramSlotData->T1HiLm        = pDumpData->T1HiLm;
            pRegCtlShramSlotData->T1LoLm        = pDumpData->T1LoLm;
            pRegCtlShramSlotData->T2            = pDumpData->T2;
            pRegCtlShramSlotData->T2HiLm        = pDumpData->T2HiLm;
            pRegCtlShramSlotData->T2LoLm        = pDumpData->T2LoLm;
            pRegCtlShramSlotData->GainHiLm      = pDumpData->GainHiLm;
            pRegCtlShramSlotData->GainLoLm      = pDumpData->GainLoLm;
            pRegCtlShramSlotData->K             = pDumpData->K;   
            pRegCtlShramSlotData->EqnEuUnitsOpt = pDumpData->EqnEUnitsOpt; 
            pRegCtlShramSlotData->OpHiLm        = pDumpData->OpHiLm;
            pRegCtlShramSlotData->OpLoLm        = pDumpData->OpLoLm;
            pRegCtlShramSlotData->OpExHiLm      = pDumpData->OpExHiLm;
            pRegCtlShramSlotData->OpExLoLm      = pDumpData->OpExLoLm;
            pRegCtlShramSlotData->OpMinChg      = pDumpData->OpMinChg;
            pRegCtlShramSlotData->SafeOp        = pDumpData->SafeOp;
            pRegCtlShramSlotData->OpTol         = pDumpData->OpTol;
            pRegCtlShramSlotData->OutInd        = pDumpData->OutInd;
            pRegCtlShramSlotData->Sp            = pDumpData->Sp;
            pRegCtlShramSlotData->SpTol         = pDumpData->SpTol;
            pRegCtlShramSlotData->SpHiLm        = pDumpData->SpHiLm;
            pRegCtlShramSlotData->SpLoLm        = pDumpData->SpLoLm;
            pRegCtlShramSlotData->TmOutMode     = pDumpData->TmOutMode;
            pRegCtlShramSlotData->TmOutTime     = pDumpData->TmOutTime;
            pRegCtlShramSlotData->TimeoutCount  = pDumpData->TimeoutCount; 
            pRegCtlShramSlotData->BadCtlOpt     = pDumpData->BadCtlOpt;
            pRegCtlShramSlotData->CvEuHi        = pDumpData->CvEuHi;
            pRegCtlShramSlotData->CvEuLo        = pDumpData->CvEuLo;
            pRegCtlShramSlotData->OpBiasFixed   = pDumpData->OpBiasFixed;
            pRegCtlShramSlotData->OpBiasRate    = pDumpData->OpBiasRate;
            pRegCtlShramSlotData->OpBias        = pDumpData->OpBias;
            pRegCtlShramSlotData->OpEu          = pDumpData->OpEu;

            if(CF::kManCtlMode == (CF::enmCtlMode)pDumpData->Mode)
            {
                pRegCtlShramSlotData->Op = pDumpData->Op;
            }       

            RetVal = PA_OK;
        }
    }
    return RetVal;
}
