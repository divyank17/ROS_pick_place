/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : spmain.h                                                    *
*    Description : common defines used by module                               *
*******************************************************************************/
#ifndef __SPMAIN_H__
#define __SPMAIN_H__

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include <machine.h>
#include "datatype.h"
#include "global.h"
#include "utils.h"
#include "tcparamcodes.h"
#include "commonelectronics.h"
#include "tracelog.hpp"
#include "iol.hpp"
#include "hartstack.hpp"
#include "debug.hpp"
#include "scheduler.hpp"
#include "tcdiag.h"
#include "wrmsgque.hpp"
#include "iomslot.hpp"
#include "ioslot.hpp"
#include "inslot.hpp"
#include "outslot.hpp"
#include "spversion.h"
#include "shram.h"
#include "tcspaislot.hpp"
#include "tcdislot.hpp"
#include "tcspaoslot.hpp"
#include "spslot.hpp"
#include "tcdoslot.hpp"
#include "spvotlogic.hpp"
#include "spboxslot.hpp"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern clsEeprom Eeprom;
#endif 
