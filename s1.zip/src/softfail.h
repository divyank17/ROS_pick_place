/*
COPYRIGHT (C) 2015
Honeywell Measurex (Ireland) Limited

ALL RIGHTS RESERVED
This software is a copyrighted work and/or information protected as a trade
secret.  Legal rights of Honeywell Measurex (Ireland) Limited in this software
is distinct from ownership of any medium in which the software is embodied.
Copyright or trade secret notices included must be reproduced in any document.
*/

/**
    @file
    @brief defines the SOFTFAILTYPE enumeration
*/

#if !defined (SOFTFAIL_H)
#define SOFTFAIL_H

/**
    @brief defines the Series-C softfail type codes

    These enumerators must align with the Experion database definitions located in
    /db/src/IOLIM/c-softfailures.arr.xml.
*/
typedef enum tagSoftfailType {
    SF_UNKNOWN              = 0,   ///< UNKNOWN SOFT FAILURE
    SF_STCOVRUN             = 1,   ///< STC OVERRUN
    SF_REQOFLOW             = 2,   ///< TASK REQUEST OVERFLOW
    SF_BADRESUM             = 3,   ///< RESUME OF NON-WAITING TASK
    SF_DIAGTMOT             = 4,   ///< ONE DIAG INITIATION TIMED OUT
    SF_DIAGOFLO             = 5,   ///< ENTIRE DIAG CYCLE OVERFLOW
    SF_FTAMISSG             = 6,   ///< FTA MISSING
    SF_EECKSMER             = 7,   ///< EEPROM CHKSUM ERROR     (WAS NOTCALIB)
    SF_EECNTERR             = 8,   ///< EEPROM COUNTER ERROR
    SF_EEFLAGER             = 9,   ///< EEPROM INCOMPLETION ERROR
    SF_SWTCHERR             = 10,  ///< SWITCHED SIGNAL ERROR
    SF_ADRAMCNT             = 11,  ///< ADP PRIVATE RAM CONTENTS FAILURE
    SF_ADRAMADR             = 12,  ///< ADP PRIVATE RAM ADDRESSING FAILURE
    SF_MBRAMCNT             = 13,  ///< LLAI SHARED RAM CONTENTS FAILURE
    SF_MBRAMADR             = 14,  ///< LLAI SHARED RAM ADDRESSING FAILURE
    SF_MBCHKMER             = 15,  ///< LLAI SHARED RAM CHECKSUM FAILURE
    SF_ADROMERR             = 16,  ///< ADP EPROM CHECKSUM FAILURE
    SF_BADADPER             = 17,  ///< BAD ERROR CODE DETECTED IN ADP
    SF_ADSTRTUP             = 18,  ///< ADP START UP FAILURE
    SF_SCANORUN             = 19,  ///< INPUT MODULE SCAN OVERRUN
    SF_SCANURUN             = 20,  ///< INPUT MODULE SCAN UNDERRUN
    SF_INPTFAIL             = 21,  ///< INPUT POINT FAILURE
    SF_BADSECRG             = 22,  ///< SECONDARY REGULATOR NOT OK
    SF_OUTPUTFL             = 23,  ///< ANY OUTPUT HAS FAILED
    SF_STCKLIM              = 24,  ///< STACK OVERFLOW
    SF_SPARE002             = 25,  ///< SPARE
    SF_DIAGCTFL             = 26,  ///< IOP DIAGNOSTIC CIRCUIT FAILURE
    SF_ADPCOMFL             = 27,  ///< NO COM TO ADP OR OTHER MICRO PROCSR AM
    SF_NOACLINE             = 28,  ///< EXTERNAL AC LINE MISSING
    SF_BADPLUGM             = 29,  ///< BAD PLUG-IN MODULE IN FTA
    SF_VTESTFAIL            = 30,  ///< VTEST REF FAILURE
    SF_FTAMSMCH             = 31,  ///< FTA TYPE MISMATCH WITH POINT CONFIG
    SF_VZERO_FL             = 32,  ///< VZERO REFERENCE FAILURE
    SF_BADRJVAL             = 33,  ///< REFERENCE JUNCTION VALUE BAD
    SF_BADADPJP             = 34,  ///< BAD BRANCH TAKEN IN ADP ROM EXECUTION
    SF_ZEROCNFG             = 35,  ///< BAD CONFIGURATION BYTE PASSED TO ADP
    SF_FTA1FAIL             = 36,  ///< LLMUX FTA1 HAS A FAILURE
    SF_FTA2FAIL             = 37,  ///< LLMUX FTA2 HAS A FAILURE
    SF_CALBABRT             = 38,  ///< CALIBRATION SEQUENCE ABORTED
    SF_BADCALRF             = 39,  ///< CALIBRATION REFERENCE OUTSIDE LIMITS
    SF_EEFAILED             = 40,  ///< EEPROM UPDATE FAILED DUE TO EEPROM BUSY
    SF_VREFFAIL             = 41,  ///< VREF FAILURE
    SF_ADOUTUDF             = 42,  ///< ADC VALUE UNDERFLOW(APPLY TO DATA)
    SF_ADOUTCAL             = 43,  ///< ADC OUT OF CALIBRATION
    SF_BADFLREG             = 44,  ///< AO FAILURE SELECTION REGISTER IS BAD
    SF_BDSNDLTC             = 45,  ///< BAD SECONDARY LATCH
    SF_BDOUTBFR             = 46,  ///< BAD OUTPUT BUFFER
    SF_VCALFAIL             = 47,  ///< VCAL OUT OF RANGE
    SF_F1NOTCAL             = 48,  ///< FTA 1 IS NOT CALIBRATED
    SF_F2NOTCAL             = 49,  ///< FTA 2 IS NOT CALIBRATED
    SF_F1COM_FL             = 50,  ///< FTA 1 COMMUNICATION FAIL
    SF_F2COM_FL             = 51,  ///< FTA 2 COMMUNICATION FAIL
    SF_F1_IDERR             = 52,  ///< FTA 1 IDENT ERROR
    SF_F2_IDERR             = 53,  ///< FTA 2 IDENT ERROR
    SF_F1VREFFL             = 54,  ///< FTA 1 VREF FAIL
    SF_F2VREFFL             = 55,  ///< FTA 2 VREF FAIL
    SF_F1CAL_FL             = 56,  ///< FTA 1 CALIBRATION FAIL
    SF_F2CAL_FL             = 57,  ///< FTA 2 CALIBRATION FAIL
    SF_LOSTSYNC             = 58,  ///< OIP LOST SYNC
    SF_WRITENBL             = 59,  ///< AO/DO WRITE ENABLE PROTECT'N FAILURE
    SF_MLTINPFL             = 60,  ///< MULTIPLE INPUT FAILURE
    SF_REDNDIAG             = 61,  ///< REDUNDANCY DIAG FAILED
    SF_NTUSED62             = 62,  ///< WAS DATBUSFL WHICH IS ALREADY A IOMHF
    SF_WRONG_HW             = 63,  ///< WRONG HW REV FOR IO REDUNDANCY
    SF_HWFIFOFL             = 64,  ///< HARDWARE FIFO FAILURE
    SF_PRVRAMFL             = 65,  ///< PRIVATE RAM FAILURE
    SF_SOECLKFL             = 66,  ///< SOE CLOCK FAILURE
    SF_PVVALDFL             = 67,  ///< PV VALIDATION DIAGNOSTIC FAILURE
    SF_SOECNTFL             = 68,  ///< SOE COUNTER FAILURE
    SF_DTPATHFL             = 69,  ///< DATA PATH FAILURE
    SF_DTPATHTO             = 70,  ///< DATA PATH TIME OUT
    SF_STMACHFL             = 71,  ///< STATE MACHINE FAILURE
    SF_PIFAULTY             = 72,  ///< PI IMAGE IN F-ROM IS FAULTY
    SF_BSORBOTHPS           = 73,  ///< BS OR BOTH PSS IN F-ROM ARE CORRUPTED
    SF_PSCRC                = 74,  ///< EITHER PRI OR SEC PS (NOT BOTH) IS CORRUPTED
    SF_ASPLONLY             = 75,  ///< AS IMAGE IN F-ROM CORRUPTED IN PL ONLY MODE
    SF_STACKHIWATER         = 76,  ///< A TASK'S STACK WENT ABOVE ITS HIGH WATER MARK
    SF_SEG1FAIL             = 77,  ///< FBUS SEG 1 FAILED (DPRAM OR OTHER FAILURE)
    SF_SEG2FAIL             = 78,  ///< FBUS SEG 2 FAILED (DPRAM OR OTHER FAILURE)
    SF_SEG3FAIL             = 79,  ///< FBUS SEG 3 FAILED (DPRAM OR OTHER FAILURE)
    SF_SEG4FAIL             = 80,  ///< FBUS SEG 4 FAILED (DPRAM OR OTHER FAILURE)
    SF_SEGFAIL              = 81,  ///< FBUS SEG IS CONFIGURING OR FAILED
    SF_VFDMACHG             = 82,  ///< FBAP VFD MATCHING PROCESS IN PROGRESS
    SF_VFDMISMA             = 83,  ///< MANAGEMENT OR FBAP VFD MISMATCH DETECTED
    SF_DEVNOTP              = 84,  ///< NO REMOTE DEVICE MATCHING THE CONFIGURATION
    SF_FAILOVER             = 125, ///< CODE 125 IS RESERVED FOR EVENT SUBTYPE FAILOVER
    SF_RUN                  = 126, ///< CODE 126 IS RESERVED FOR EVENT SUBTYPE RUN
    SF_IDLE                 = 127, ///< CODE 127 IS RESERVED FOR EVENT SUBTYPE IDLE
    SF_ERVCSTART            = 128, ///< CODE 128 IS RESERVED FOR EVENT SUBTYPE ERVCSTART
    SF_EVRCEND              = 129, ///< CODE 129 IS RESERVED FOR EVENT SUBTYPE EVRCEND
    SF_RESERVED_130         = 130, ///< CODE 130 RESREVED
    SF_ALARMDISABLE         = 131, ///< CODE 131 RESERVED FOR EVENT SUBTYPE ALARMDISABLE
    SF_INACTIVE             = 132, ///< CODE 132 IS RESERVED FOR EVENT SUBTYPE INACTIVE
    SF_ACTIVE               = 133, ///< CODE 133 IS RESERVED FOR EVENT SUBTYPE ACTIVE
    SF_INOVRCRNT            = 144, ///< Input Channel Over Current Detected
    SF_OSCDIAG_FAIL         = 145, ///< PI COUNTER OSCILLATOR DIAG FAILURE
    SF_FCO_DIAG_FAIL        = 146, ///< Fast CutOff o/p Driver Failure
    SF_PSFAIL               = 147, ///< Power Supply Failure
    SF_TEMPHILM             = 148, ///< High Temperature Exceeded
    SF_TEMPLOLM             = 149, ///< Low Temperature Exceeded
    SF_ADC_REG_WR_FAIL      = 150, ///< ADC Register Write Failure
    SF_ADCINCOMPLETE        = 151, ///< ADC Conversion Incomplete
    SF_ADC_OVERFLOW         = 152, ///< ADC Overflow Failure
    SF_ADC_SUPPLY_FAIL      = 153, ///< ADC Supply Failure
    SF_VDTCOREFALLOUT       = 154, ///< VDT Core fallout
    SF_AINOTCALIB           = 155, ///< SP or SVP AI channels not calibrated
    SF_AONOTCALIB           = 156, ///< SP or SVP AO channels not calibrated
    SF_UNSTABLEINPUT        = 157, ///< Unstable Input
    SF_CHNOTFLDCALIB        = 158, ///< Channel not Field calibrated
    SF_FDBKINPUTFAIL        = 159, ///< Feedback Input Failure
    SF_NO_PULSE_DETECT      = 160, ///< Speed Channel - No Pulse Detected
    SF_HMODEM1              = 161, ///< HART HW ERROR DETECTED FOR DUART CHANNEL 1 OR MODEM 1
    SF_HMODEM2              = 162, ///< HART HW ERROR DETECTED FOR DUART CHANNEL 2 OR MODEM 2
    SF_HMODEM3              = 163, ///< HART HW ERROR DETECTED FOR DUART CHANNEL 3 OR MODEM 3
    SF_HMODEM4              = 164, ///< HART HW ERROR DETECTED FOR DUART CHANNEL 4 OR MODEM 4
    SF_HDIAGTO              = 165, ///< HART PROCESSOR DIAGNOSTIC TASK UNDER-RUN
    SF_HSTACKHI             = 166, ///< HART PROCESSOR PROGRAM STACK ABOVE 90% USAGE LEVEL
    SF_FTA3FAIL             = 167, ///< AIMUX FTA3 HAS A FAILURE
    SF_FTA4FAIL             = 168, ///< AIMUX FTA4 HAS A FAILURE
    SF_F3NOTCAL             = 169, ///< FTA 3 IS NOT CALIBRATED
    SF_F4NOTCAL             = 170, ///< FTA 4 IS NOT CALIBRATED
    SF_F3COM_FL             = 171, ///< FTA 3 COMMUNICATION FAIL
    SF_F4COM_FL             = 172, ///< FTA 4 COMMUNICATION FAIL
    SF_F3_IDERR             = 173, ///< FTA 3 IDENT ERROR
    SF_F4_IDERR             = 174, ///< FTA 4 IDENT ERROR
    SF_F3VREFFL             = 175, ///< FTA 3 VREF FAIL
    SF_F4VREFFL             = 176, ///< FTA 4 VREF FAIL
    SF_F3CAL_FL             = 177, ///< FTA 3 CALIBRATION FAIL
    SF_F4CAL_FL             = 178, ///< FTA 4 CALIBRATION FAIL
    SF_OPENWIRE             = 179, ///< OPEN CONNECTION ( WIRE OR SENSOR ) DETETED
    SF_DOVRCRNT             = 180, ///< DO CHANNEL OVER CURRENT DETECTED
    SF_FTAPOWFAIL           = 181, ///< FTA POWER FAILURE
    SF_ADDRDIAGFAIL         = 182, ///< IOLINK ADDRESS DIAGNOSTIC FAILURE
    SF_RDBKRGDIAGFL         = 183, ///< READBACK REGISTER DIAGNOSTIC FAILURE 
    SF_WDTDIAGFAIL          = 184, ///< WATCH DOG TIMER DIAGNOSTIC FAILURE
    SF_RLYEXTBDMSSNG        = 185, ///< RELAY EXTENSION BOARD MISSING
    SF_REDHWFAIL            = 186, ///< REDUNDANCY HARDWARE FAILURE
    SF_HARTCHANFAIL         = 187, ///< IOM OR IOTA HART CHANNEL FAILURE
    SF_EXCTVOLTFAIL         = 188, ///< LVDT Excitation Voltage out of calibrated Range
    SF_EXCTFREQDRIFT        = 189, ///< LVDT Excitation Frequency Drift Greater than 100Hz
    SF_FDBKAVOLTFAIL        = 190, ///< LVDT Feeback Channel A Voltage out of calibrated Range
    SF_ADC_CHAN_FAIL        = 191, ///< LVDT ADC Channel Selection Failure
    SF_ADC_CRIT_SIG_FAIL    = 192, ///< LVDT Channel Critical Signal Failure
    SF_5V_SUPPLY_FAIL       = 193, ///< 5v Supply to Application board failure
    SF_FDBKBVOLTFAIL        = 194, ///< LVDT Feeback Channel B Voltage out of calibrated Range
    SF_CURRENT_DRV_FAIL     = 195, ///< Servo Channel Current Driver Shutdown
    SF_BOARD_TEMP_FAIL      = 196, ///< Board temperature above 90 deg
    SF_SP_ROC_FAIL          = 197, ///< Speed Channel ROC failure
    SF_ECAP_REF_FAIL        = 198, ///< Speed Channel RCAP Reference Clock Failure
    SF_AI_DIAGCTFL          = 199, ///< AI IOP DIAGNOSTIC CIRCUIT FAILURE
    SF_DI_DIAGCTFL          = 200  ///< DI IOP DIAGNOSTIC CIRCUIT FAILURE
} SOFTFAILTYPE;

#endif // SOFTFAIL_H
