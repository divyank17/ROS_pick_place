/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : diboxslot.hpp                                               *
*    Description : Class clsDiBoxSlot declaration.                             *
*******************************************************************************/

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "boxslot.hpp"
#include "dislot.hpp"
#ifdef IOMTYPE_DISOE
#include "disoeversion.h"
#else
#include "diversion.h"
#endif
#ifndef __DIBOXSLOT_HPP__
#define __DIBOXSLOT_HPP__

/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#define DIBOXSLOT_SIZE ((sizeof(clsDiBoxSlot) + (sizeof(clsDiBoxSlot) % 2)) / 2)
#define PARAMID_PVALL    101
#define PARAMID_BADPVALL 110

#if defined (IOPTYPE_DI)
  const UINT8 MAXEVNTPERCTX    = 12;
  #define PARAMID_ALMALL   111
  #define PARAMID_MOD_STAT1  67
  #define PARAMID_NROFDIS  100
#endif

#define PARAMID_DIMODE   168

#define CNT_ACDROPOUT50HZ 22 // counts in sample periods to declare AC signal OFF
#define CNT_ACDROPOUT60HZ 18
#define CNT_DCDETECT50HZ 6   // counts in sample periods to declare DC signal ON
#define CNT_DCDETECT60HZ 5

// CPLD diagnostic is done at every 500ms. The count is manipulated in 
// AppStcProcessing's ProcessCycle. so 500ms/20ms = 25
const UINT8 CPLD_DIAG_COUNT = 25;
// INputs are arranaged in 4 banks of 8 channels each
const UINT8 NO_OF_BANKS   = 4;
const UINT8 INPUTS_PER_BANK = 8;
const UINT16 TPU0_5MSEC_CNT  = 30000;   // TPU0 5msec count
#ifdef IOMTYPE_DISOE
// disoe declarations.
const UINT16 EVTTIME_200uSEC_FACTOR = 300;  // TPU2 timer runs 300 times faster than 200usec per tick
const UINT16 SOEISROVERRNTIME = 1800;   // No.of TPU2 ticks for 1200usec
const UINT8 STCFOURSECCNT    = 4;
const UINT8 STCTENSECCNT     = 10;
const UINT8 STCTWENTYSECCNT  = 20;
const UINT8 MAXEVNTPERCTX    = 12;
const UINT16 TPU0_1MSEC_CNT  = 6000;
const UINT16 TPU0_990US_CNT  = 5940;
const UINT8 MAX_UNSENT       = 8;       // max unsent Pv chnage packets processed in EVM
const UINT8 HALF_SEC_SUSPEND = 50;      // 500 milliseconds
const UINT8 TWO_SEC_SUSPEND  = 200;     // 2000 milliseconds ( 2sec)
const UINT8 TEN_MS_SUSPEND   = 1;       // 10 msec
const UINT8 MAX_DISCARD      = 16;      // max packets discarded by EVM in one call
const UINT8 SYNC_DIFFERENCE  = 10;
const UINT8 MAX_EVENT_COUNT  = 10;      // maximum no.of packets that can be processed in once STC cycle
// Declarations made for Hardware and TaskFIFO sizes.
const UINT8 TASKFIFO_SIZE     = 64;
const UINT16 PVCLEVTREG_SIZE  = 530;    // PVCL event log for regeneration
const UINT8 TIMESYNCTBLSIZE   = 13;
const UINT8 SOEISRBUFSIZE     = 50;
#endif 
/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
class clsDiBoxSlot; // forward declaration
typedef struct tagBoxParamInfo {
    DATATYPE     DataType;
    UINT8        Size;
    ACCESSTYPE   AccessType;
    ACCESSLOCK   AccessLock;
    PASTATUS (clsDiBoxSlot::* PrePtr)(UINT8 *,UINT8);
    VOID     (clsDiBoxSlot::* PostPtr)(UINT8);
    VOID *   (clsDiBoxSlot::* ParamPtr)(VOID);
    BOOL         IsDbChecksumed;
} BOXPARAMINFO;

typedef enum tagProcessCycle {
    PROCESSCYCLE_INPUT,
    PROCESSCYCLE_DIAG
} PROCESSCYCLE;

//////////////////////////////////////////////////////////////////////////////////////////
//                           DISOE Declarations                                         //
//////////////////////////////////////////////////////////////////////////////////////////
// Declaration of enumerations & structures for various Event Packets.
#ifdef IOMTYPE_DISOE
// Declarations of structure of DebounceAlgorithm and to track the INPUT's sensed.
typedef struct tagStMchInPutBuff { 
    UINT8   unTarget          ;  // configured value of desired debounce time (ticks)
    UINT8   unCount           ;  // active count toward target
    BOOL    bInTransition     ;  // TRUE while active (counting toward target)
    BOOL    bLast             ;  // value of PV last sample
    BOOL    bNew              ;  // value of PV this sample
    BOOL    bOld              ;  // value of PV when last reported to system as an event
    UINT32  EventTime         ;  // Event time stamp taken when Pv change is detected
}STMCHINPTBUFF;
// Declarations for the Hardware FIFO Packet and Task FIFO packet creation.
typedef enum tagTaskFifoPacketType {
    TASKFIFO_STSPKT,  // Taskfifo Status Packet.
    TASKFIFO_RAWPKT,  // Taskfifo Raw Packet.
    TASKFIFO_LSTPKT   // Taskfifo Lost Packet.   
}TASKFIFOPACKETTYPE;
typedef struct tagFRC {
    union {
        UINT32 frc_count;
        struct {
            UINT16 ClockHighWord;
            UINT16 Tpu2Count;
        }WORD;
    };
}FRC;
typedef struct tagTaskFifoRecord {
    UINT8 TaskFifoPacketType   ; // Task FIFO Raw Packet Type. 
    union {// TaskFIFO type 
        struct {
            UINT8   CurrentState        :1  ;  // Includes in First byte Record.
            UINT8   ChanErrorBit        :1  ;
            UINT8   SOEslot             :6  ;  // First byte of event packet
            UINT32  EventTimeStamp          ;  // Second & third byte of event packet
        }stTaskFifoRawPkt;
        struct{
            UINT32 EventTimeStamp           ; // Second & third byte of event packet
        }stTaskFifoEvtLstPkt;
    }; 
}TASKFIFORECORD;
typedef struct tagTimeSyncFifo {
    UINT16  TimeSynchID         ; // syncid .
    UINT32  SynchTimeStamp      ; // sync time.
}TIMESYNCFIFO;
typedef struct tagSoeIsrBuff{
    UINT32  TimeStamp;
    UINT8   ChnPv1_32[4];
}SOEISRBUFF;
#endif
// Decalaration for Evnt option.Default = NONE =(0)
typedef enum tagDiMode{
    DIMODE_NORMAL   = 0,
    DIMODE_SOE      = 1,
    DIMODE_LOWLATNCY= 2
}DIMODE;

#if defined (IOPTYPE_DI)
typedef struct tagFRC {
  union {
      UINT32 frc_count;
      struct {
          UINT16 ClockHighWord;
          UINT16 Tpu2Count;
      }WORD;
  };
}FRC;
#endif


/*******************************************************************************
*                                  clsDiBoxSlot                                *
*                                  ============                                *
*******************************************************************************/
class clsDiBoxSlot : public clsBoxSlot {
private:
    FREQ6050   Freq6050; 
#if defined(IOPTYPE_DI)
    UINT8 NrOfDIs;
#endif 
    BLIND      PvAll[NO_OF_BANKS];
    DIMODE     DiMode;
    // !!!*** BOXSLOT_DUMP_RECORD_END ***!!!
    // This marks the end of the box slot's redundant synch data area
    // No data members that are not to be synch'd can be placed above this point
    // Any new data members to be added to this dump record must be added here
    // at the end. If this is done GetRedBoxSize() must be updated to
    // reference the new end member. This dump record begins in clsBoxSlot.
#ifdef IOMTYPE_UIO
    BOOL       HADCEnable[MAXSLOTS];
    UINT8      HADCStatus[MAXSLOTS];
#endif
    BLIND      BadPvAll[4];

#if defined (IOPTYPE_DI)
    BLIND  AlmAll[NO_OF_BANKS];    
    FRC    FRC_Time;
    UINT16 LastTpu2Count;    
    UINT8  OneSecFlDI[NO_OF_BANKS];
#endif

    UINT16     PvChApp;   // append index pointer
    UINT16     PvChRem;   // remove index pointer
    UINT16     LatchTimeCnt; // Count value corresponding to DiMode 
#ifdef IOMTYPE_DISOE
    UINT16  StMchOvrRuns; // Measure to see if SOE Intr has been missed .
    UINT16  StMchMaxOvrRunTime;
    UINT16  StMchLstOvrRunTime;
    BOOL    ResetOvrRunData;
    // DISOE Point Processing FIFO 's related Declarations .
    STMCHINPTBUFF       StMchInputBuf[MAXSLOTS];
    TASKFIFORECORD      TaskFIFO[TASKFIFO_SIZE];
    FRC    FRC_Time;
    BOOL   bTaskFifoInOverflow;
    UINT8  TaskFifoAppPtr;
    UINT8  TaskFifoRemPtr;
    UINT16 RegLogAppPtr;
    UINT16 RegLogRemPtr;
    BOOL   bEventLost;
    BOOL   bLogEvent;
    BOOL   bInitStMchInputBufFl;
    BOOL   bOneSecFl;
    BOOL   PVCLEvtRegInProgress;
    BOOL   bRegen_Expected;
    BOOL   bLog_Frozen;
    BOOL   bDoForcedInputDiag;
    BOOL   bForcedInputDiagInProg;
    UINT8  ucNoSyncCnt;
    UINT8  ucReceiving_SyncCnt;
    UINT32 SOEHandler_StartTime;
    BOOL   bUnSent_PVCL_Pkts;
    UINT16 UnSentPkt_Ptr;
    UINT16 LastTpu2Count;
    CONTEXT  ucContext;
    RETURNSTATUS ScanChanRtnSts;
    // declaration of time syncID buffer
    TIMESYNCFIFO        TimeSynchtbl[TIMESYNCTBLSIZE];
    TIMESYNCFIFO        RegTimeSynchtbl[TIMESYNCTBLSIZE];
    UINT8  TimeSyncTblAppPtr;
    UINT8  TimeSyncTblRemPtr;
    UINT8  RegTimeSyncTblAppPtr;
#endif
    UINT8      Sequence[MAXSLOTS];
    UINT8      ucDirectionBits[4]; // rising and falling direction for sampling DI HV AC inputs
    INT8       scAccumulator[MAXSLOTS]; // sample counter
    UINT8      nDCdetect[MAXSLOTS]; // DC detection sample counter
    PROCESSCYCLE ProcessCycle;
    BOOL       bDoOpenWireDiag;
    UINT8      m_uiCPLDDiagCounter;
    UINT8      ucSns_Chk_Nrml;
    UINT8      ucSns_Chk_OWD;
    DATABYTES  ForcedInputDiagStatus;

    static const UINT8 PvStAll[]; 
#if defined(IOPTYPE_DI)    
    BLIND     PmBxSfBits[SLOTINFAIL_SIZE];
    static const UINT8 PvStAlm[];
#endif
    static const UINT8 CheckPointVer1[];
#ifdef IOMTYPE_DI
    static const UINT8 CheckPointVer2[];

#if defined(IOPTYPE_DI)
    static const UINT8 PmioDumpParamTbl[];
#endif

#endif
    static const CHECKPOINT_VER_TABLE CheckPointVerTable[];
    static const UINT8 RedParams[]; 
    static const BOXPARAMINFO tblParamInfo[256];

    PASTATUS PreFreq6050(UINT8 *writebuffer, UINT8 AccLvl);
    
    VOID ForcedInputDiag(VOID); // forced input diagnostics to check comparators
    UINT32 OpenWireDiag(VOID); // open wire diagnostics

    inline VOID *GetPvAllPtr(VOID)      { return PvAll; } 
    inline VOID *GetBadPvAllPtr(VOID)   { return BadPvAll; }

#if defined (IOPTYPE_DI)
    inline VOID *GetAlmAllPtr(VOID)   { return AlmAll; }
    inline VOID *GetIopDescPtr(VOID)   { return (VOID*)IopDesc; }
    inline VOID *GetPvStAlmPtr(VOID)    { return (VOID *)PvStAlm; }
#endif

#if defined(IOMTYPE_DISOE) || defined (IOPTYPE_DI)
    inline VOID *GetPvChAppPtr(VOID)    { return GetPVCLAppPtr(); }
    inline VOID *GetPvChRemPtr(VOID)    { return GetPVCLRemPtr(); }
#else
    inline VOID *GetPvChAppPtr(VOID)    { return &PvChApp; }
    inline VOID *GetPvChRemPtr(VOID)    { return &PvChRem; }
#endif
    inline VOID *GetPvStAllPtr(VOID)    { return (VOID *)PvStAll; }

#ifdef IOMTYPE_DISOE
    inline VOID *GetStMchOvrRunsPtr(VOID){return &StMchOvrRuns;}
    inline VOID *GetStMchMaxOvrRunTimePtr(VOID){return &StMchMaxOvrRunTime;}
    inline VOID *GetStMchLstOvrRunTimePtr(VOID){return &StMchLstOvrRunTime;}
    inline VOID *GetResetOvrRunData(VOID){return &ResetOvrRunData;}
    VOID PostResetOvrRunData(UINT8 a_ucAccLvl);
    inline UINT32 GetFrcCount(VOID){
        FRC_Time.WORD.Tpu2Count = TPU2_TCNT;
        if(FRC_Time.WORD.Tpu2Count < LastTpu2Count)
        {
            FRC_Time.WORD.ClockHighWord++;
        }
        LastTpu2Count = FRC_Time.WORD.Tpu2Count;
        return FRC_Time.frc_count;
    }
#endif

#ifdef IOMTYPE_UIO
    PASTATUS PreHADCEnable(UINT8 *,UINT8);
    VOID     PostHADCEnable(UINT8);
    inline VOID *GetHADCEnablePtr(VOID)   { return (VOID *)HADCEnable; }
    inline VOID *GetHADCStatusPtr(VOID)   { return (VOID *)HADCStatus; }
#endif
    PASTATUS PreDiMode(UINT8 *a_Writebuffer , UINT8 a_ucAccLvl);
    VOID PostDiMode(UINT8 a_ucAccLvl);
    PASTATUS PreCheckPoint(UINT8 *,UINT8);

    inline VOID *GetDiModePtr(VOID){return &DiMode;}

    inline VOID *GetFreq6050Ptr(VOID)   { return &Freq6050; }
#if defined(IOPTYPE_DI)
    inline VOID *GetNrOfDIsPtr(VOID)   { return &NrOfDIs; }
#endif
    inline VOID *GetCheckPointPtr(VOID) { return (VOID *)CheckPointVerTable[BoxChkpntVersion-1].CheckPointPtr; }
    inline VOID *GetRedParamsPtr(VOID)  { return (VOID *)RedParams; }

    friend VOID *clsDiSlot::GetPvPtr(VOID);
    friend VOID *clsDiSlot::GetBadPvFlPtr(VOID);

    inline VOID *GetCheckPointPtr(UINT8 a_ucVer) { return (VOID *)CheckPointVerTable[a_ucVer-1].CheckPointPtr; }
    inline UINT8 GetCheckPointSize(UINT8 a_ucVer) { return CheckPointVerTable[a_ucVer-1].CheckPointSize; }
#if !defined(IOPTYPE_DI)
    UINT8    *GetParamPtr(UINT8);
#endif
    PASTATUS ExecutePreFunction(UINT8,UINT8 *,UINT8);
    VOID     ExecutePostFunction(UINT8,UINT8);
    
    clsDiBoxSlot(const clsDiBoxSlot&); // Safeguard against default copy constr.
    clsDiBoxSlot& operator=(const clsDiBoxSlot&); // and default assignment.

public:
    clsDiBoxSlot(MODLTYPE);
    ~clsDiBoxSlot(VOID) { HardFail(HF_INVPROGRAMEXEC,DIBOXSLOT_HPP,__LINE__); }

    VOID *operator new(UINT32) { return ucIomDbMemory; }
    VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC,DIBOXSLOT_HPP,__LINE__); } 

    VOID AppStcProcessing(VOID);
    static VOID DiHvInterruptHandler(VOID);

    DATATYPE   GetDataType(UINT8);
    ACCESSTYPE GetAccessType(UINT8);
    UINT8      GetParamSize(UINT8);
    ACCESSLOCK GetAccessLock(UINT8);
    BOOL       GetIsDbChecksumed(UINT8);
    PASTATUS   VerifyControlState(UINT8);
    VOID       AppColdInit(VOID);
    BOOL       AppFOProcess(VOID);
    VOID       AppPostSwap(VOID);
    VOID       AppPostSync(VOID);
    UINT8 DiHvRawInputs[4];
    static volatile UINT8 *pInputPorts[4];

#ifdef IOMTYPE_DISOE
    // DISOE related Declarations.
    VOID    InitStMchInputBuf(UINT8 unChannel);
    VOID    InitSOEState(UINT8 unChannel, BOOL bStateNow);
    VOID    ProcessTaskfifoPacket();
    UINT16  CalcSyncID(VOID);
    BOOL    PostToPVCL(EVENTPACKET,UINT16 SyncId);
    VOID    ScanChannel(VOID);
    VOID    UpdateTimeSyncId(UINT16);
    VOID    SetStMchInputBufTarget(UINT8 SlotNum,UINT8 Target);
    VOID    Prepare_For_Regen(VOID);
    VOID    CopySyncTbl(VOID);
    UINT8   Restore_Unsent_Pkts(VOID);
    UINT8   Discard_Old_Pkts(UINT8 ucSuspendTime);
    BOOL    PVCLEvtRegen(VOID);

    VOID    ProcessForPvChgEvt(VOID);
    VOID    GetSOESample(VOID);
    inline VOID  SetInitStMchInputBufFl(VOID){bInitStMchInputBufFl = TRUE;}
    inline VOID  SetNoSyncCnt(UINT8 ucValue){ ucNoSyncCnt = ucValue;}
    inline UINT8 GetNoSyncCnt(VOID){ return ucNoSyncCnt;}
    inline BOOL  IsRegen_Expected(VOID){ return bRegen_Expected;}
    inline VOID  SetRegen_Expected(BOOL bValue){ bRegen_Expected = bValue;}
    inline BOOL  IsLogFrozen(VOID){ return bLog_Frozen;}
    inline VOID  SetLog_Frozen(BOOL bValue){ bLog_Frozen = bValue;}
    inline VOID  SetPVCLEvtRegInProgress(BOOL bValue){ PVCLEvtRegInProgress = bValue;}
    inline VOID  SetOneSecFl(VOID){ bOneSecFl=TRUE;}
    inline BOOL  GetForcedInputDiagInProg(VOID){ return bForcedInputDiagInProg;}
#endif
    
    static VOID SOEInterruptHandler(VOID);

    inline DIMODE GetDiMode(VOID){ return DiMode;}
    inline UINT16 GetLatchTimeCnt(VOID){ return LatchTimeCnt;}
    inline UINT32 GetForcedInputDiagStatus(VOID){ return ForcedInputDiagStatus.ui32Val;}

#ifdef IOMTYPE_DISOE
    inline UINT32 GetRedBoxDelta(VOID) {return 0;}
#else

#if defined(IOPTYPE_DI)
    BOOL    PostToPVCL(EVENTPACKET,UINT16 SyncId);
#endif

    inline UINT32 GetRedBoxDelta(VOID) {return 1;}
#endif

#if defined (IOPTYPE_DI)
    inline UINT32 GetRedBoxSize(VOID)    { return PMIO_BOXDUMP_PARAMSIZE; }
    inline UINT8 *GetRedBoxPointer(VOID) { return (UINT8 *)PmioDumpParamTbl; }
#else
    inline UINT32 GetRedBoxSize(VOID) {
        return ((UINT32)((UINT8 *)&DiMode - (UINT8 *)&ModStat1) + sizeof(DiMode));
    }

    inline UINT8 *GetRedBoxPointer(VOID) {
        return (UINT8 *)&ModStat1;
    }
#endif        

    inline ONOFF GetPv(UINT8 a_ucChanNum) 
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        return ((PvAll[ucByteIndex] & ucBitIndex) > 0) ? ON : OFF;
    }
    
    inline VOID SetPv(UINT8 a_ucChanNum,ONOFF a_Pv)
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        if (ON == a_Pv) PvAll[ucByteIndex] |= ucBitIndex;
        else PvAll[ucByteIndex] &= ~ucBitIndex;       
    }

    inline BOOL GetBadPvFl(UINT8 a_ucChanNum) 
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        return ((BadPvAll[ucByteIndex] & ucBitIndex) > 0) ? TRUE : FALSE;
    }
    
    inline VOID SetBadPvFl(UINT8 a_ucChanNum,BOOL a_BadPvFl)
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        if (TRUE == a_BadPvFl) BadPvAll[ucByteIndex] |= ucBitIndex;
        else BadPvAll[ucByteIndex] &= ~ucBitIndex;       
    }

#if defined (IOPTYPE_DI)    
    //inline VOID SetOneSecFlagDI(VOID){ OneSecFlDI = 0xFF;}
    //inline BOOL GetOneSecFlagDI(UINT8 uChanNo){ return ((OneSecFlDI) & (1<<(uChanNo-1)));}
    //inline VOID ResetOneSecFlagDI(UINT8 uChanNo){ ((OneSecFlDI) &= (~(1) << (uChanNo-1)));}

    inline ONOFF GetOneSecFlagDI(UINT8 a_ucChanNum) 
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        return ((OneSecFlDI[ucByteIndex] & ucBitIndex) > 0) ? ON : OFF;
    }
    inline VOID SetOneSecFlagDI(VOID)
    {
        //one second completed for all   
        OneSecFlDI[0] = 0xFF;
        OneSecFlDI[1] = 0xFF;
        OneSecFlDI[2] = 0xFF;
        OneSecFlDI[3] = 0xFF;
    }
    inline VOID ResetOneSecFlagDI(UINT8 a_ucChanNum)
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        OneSecFlDI[ucByteIndex] &= ~ucBitIndex;       
    }


    BOOL    PVCLEvtRegen(VOID);
    inline VOID *GetPmBxSfBitsPtr(VOID)
    { 
        UINT8 ucIndex;

        for (ucIndex = 0; ucIndex < 6; ucIndex++)
            PmBxSfBits[ucIndex] = BoxSfBits[ucIndex];

        for (ucIndex = 6; ucIndex < 12; ucIndex++)
            PmBxSfBits[ucIndex] = SlotSfBits[ucIndex-6];

        for (ucIndex = 12; ucIndex < 16; ucIndex++)
            PmBxSfBits[ucIndex] = MapSlotInFail[ucIndex - 12];

        return PmBxSfBits;
    }

    inline VOID *GetAlMallPtr(VOID)   { return AlmAll; }


    inline BOOL GetAlmFl(UINT8 a_ucChanNum) 
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        return ((AlmAll[ucByteIndex] & ucBitIndex) > 0) ? TRUE : FALSE;
    }
    
    inline VOID SetAlmFl(UINT8 a_ucChanNum,BOOL a_AlmFl)
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        if (TRUE == a_AlmFl) AlmAll[ucByteIndex] |= ucBitIndex;
        else AlmAll[ucByteIndex] &= ~ucBitIndex;       
    }
    
    inline VOID SetAlmAll(UINT8 a_ucChanNum,ONOFF a_Alm)
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        if(ON == a_Alm)//((PvAll[ucByteIndex] & ucBitIndex) > 0)
            AlmAll[ucByteIndex] |= ucBitIndex;
        else
            AlmAll[ucByteIndex] &= ~ucBitIndex;
    }

    inline BOOL GetAlmAll(UINT8 a_ucChanNum) 
    {
        UINT8 ucBitIndex  = 0x80 >> ((a_ucChanNum - 1) & 0x07);
        UINT8 ucByteIndex = ((a_ucChanNum - 1) >> 3) & 0x03;
        return ((AlmAll[ucByteIndex] & ucBitIndex) > 0) ? TRUE : FALSE;
    }

    
    inline UINT32 GetFrcCount(VOID){
      FRC_Time.WORD.Tpu2Count = TPU2_TCNT;
      if(FRC_Time.WORD.Tpu2Count < LastTpu2Count)
      {
          FRC_Time.WORD.ClockHighWord++;
      }
      LastTpu2Count = FRC_Time.WORD.Tpu2Count;
      return FRC_Time.frc_count;
    }
#endif
   
    inline UINT8 GetModlType(VOID) { return ModlType; }
    inline UINT8 GetSnsChkOWD(VOID) { return ucSns_Chk_OWD; }

#ifdef IOMTYPE_UIO
    inline BOOL GetHADCEnable(UINT8 a_ucSlot) { return HADCEnable[a_ucSlot - 1]; }
    inline UINT8 GetHADCStatus(UINT8 a_ucSlot) { return HADCStatus[a_ucSlot - 1]; }
    inline VOID ResetHADCEnable(UINT8 a_ucSlot) { HADCEnable[a_ucSlot - 1] = FALSE; }
    inline VOID SetHADCStatus(UINT8 a_ucSlot, UINT8 a_ucStatus) { HADCStatus[a_ucSlot - 1] = a_ucStatus; }
#endif

#ifdef DEBUG
    UINT16 uiMaxIpTime,uiMaxDiagTime,uiExecTime;
    UINT32 OpenWireDiagStatus;
    VOID   StopOpenWireDiag(VOID) { bDoOpenWireDiag = FALSE; }
#endif

#if defined(IOPTYPE_DI)
    UINT8    *GetParamPtr(UINT8);
    inline VOID *GetPmioDumpParamPtr(VOID)  { return (VOID *)PmioDumpParamTbl; }
    inline UINT8 IsCheckPointParam(UINT8 ucParamId) 
    {
        UINT8 ucArrayIndex = 0;
        UINT8 ucChkPntIndex = 0;

        while (CheckPointVer2[ucArrayIndex])
        {            
            if (CheckPointVer2[ucArrayIndex] == ucParamId)
                return (ucChkPntIndex + 1);
            else
                ucChkPntIndex += GetParamSize(CheckPointVer2[ucArrayIndex]);

            ucArrayIndex++;
        }

        return PA_NULL;
    }
#endif
};

#endif
