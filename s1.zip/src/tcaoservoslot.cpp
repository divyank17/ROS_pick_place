/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2009                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : tcaoservoslot.cpp                                           *
*    Description : Class clsAoServoSlot definition.                            *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "svpmain.h"

/*******************************************************************************
*                                 EXTERNAL DATA                                *
*******************************************************************************/
extern SHRAMDATA ShramData;

/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/
const UINT8 clsAoServoSlot::RedParams[] = {
    kSvpAoPnFaultValue,
    kSvpAoPnFaultOpt,
    kSvpAoPnRedTag,
    kSvpAoPnPntType,
    kSvpAoPnPtExecSt,
    kSvpAoPnOptDir, 
    kSvpAoPnOpIn0, 
    kSvpAoPnOpIn1, 
    kSvpAoPnOpIn2, 
    kSvpAoPnOpIn3, 
    kSvpAoPnOpIn4, 
    kSvpAoPnOpOut0,
    kSvpAoPnOpOut1,
    kSvpAoPnOpOut2,
    kSvpAoPnOpOut3,
    kSvpAoPnOpOut4,
    kSvpAoPnChrc_S0,
    kSvpAoPnChrc_S1,
    kSvpAoPnChrc_S2,
    kSvpAoPnChrc_S3,
    kSvpAoPnChrc_S4,
    kSvpAoPnOpChar,
    kSvpAoPnNMode,
    kSvpAoPnNModeAttr,
    kSvpAoPnModePerm,
    kSvpAoPnModeAttr,
    kSvpAoPnOpConn,
    kSvpAoPnInLckFlOpt1,    
    kSvpAoPnInLckFlOpt2,    
    kSvpAoPnInSelPrcIntLck1,
    kSvpAoPnInSelPrcIntLck2,
    kSvpAoPnPrcSafeOp1,     
    kSvpAoPnPrcSafeOp2,
    kSvpAoPnOpBiasCurrent,
    kSvpAoPnOpAction,   
    kSvpAoPnOpHiCurrent,
    kSvpAoPnOpLoCurrent,
    kSvpAoPnOptType,   
    kSvpAoPnDitherFreq,
    kSvpAoPnDitherAmpl,
    kSvpAoSecDiagCurr,
    kSvpAoSecDiagEnb,
    0 // Terminator
};

const AOSERVOSLOTPARAMINFO clsAoServoSlot::tblParamInfo[] = { // Build paraminfo table
 //DataType,Size,AccessType,AccessLock,ControlState,PrePtr,PostPtr,ParamPtr,IsChecksumed,IsRedChecksumed
//  FILL 0 index to 50th index///////////////////////////////////////////////////////////////////////////////////////////
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 00
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 01
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 02
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 03
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 04
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 05
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 06
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 07
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 08
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 09
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 10
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 11
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 12
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 13
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 14
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 15
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 16
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 17
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 18
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 19
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 20
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 21
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 22
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 23
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 24
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 25
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 26
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 27
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 28
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 29
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 30
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 31
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 32
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 33
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 34
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 35
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 36
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 37
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 38
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 39
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 40
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 41
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 42
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 43
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 44
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 45
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 46
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 47
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 48
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 49
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 50
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetPntTypePtr,TRUE,             // 51  PntType
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetPtExecStPtr,TRUE,           // 52  PtExecSt
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetModeAttrPtr,TRUE,           // 53  ModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_OPER,CONTROLSTATE_NONE,0,0,GetModePtr,TRUE,               // 54  Mode
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetModePermPtr,TRUE,            // 55  ModePerm
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetNModeAttrPtr,TRUE,          // 56  NModeAttr
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetNModePtr,TRUE,              // 57  NMode
    DT_FLOAT32,4,AT_BXREC,ALCK_OPER,CONTROLSTATE_ACTIVEANDRUN,0,0,GetOpPtr,FALSE,     // 58  Op
    DT_BOOL,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetOpCharPtr,TRUE,              // 59  OpChar
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpFinalPtr,FALSE,        // 60  OpFinal
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpIn0Ptr,FALSE,      // 61  OpIn0
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpIn1Ptr,TRUE,       // 62  OpIn1
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpIn2Ptr,TRUE,       // 63  OpIn2
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpIn3Ptr,TRUE,       // 64  OpIn3
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpIn4Ptr,TRUE,       // 65  OpIn4
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpIn5Ptr,FALSE,      // 66  OpIn5
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpOut0Ptr,FALSE,     // 67  OpOut0
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpOut1Ptr,TRUE,      // 68  OpOut1
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpOut2Ptr,TRUE,      // 69  OpOut2
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpOut3Ptr,TRUE,      // 70  OpOut3
    DT_FLOAT32,4,AT_MBYTE,ALCK_SUPR,CONTROLSTATE_INACTIVE,0,0,GetOpOut4Ptr,TRUE,      // 71  OpOut4
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_INACTIVE,0,0,GetOpOut5Ptr,FALSE,     // 72  OpOut5
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_INACTIVE,0,0,GetOptDirPtr,TRUE,          // 73  OptDir
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetRedTagPtr,TRUE,             // 74  RedTag
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfBtPtr,FALSE,         // 75  SlotSfBt
    DT_BOOL,1,AT_BXPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetStdbyManPtr,FALSE,         // 76  StdbyMan
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 77  
    DT_BOOL,1,AT_BXPACK,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetInitReqPtr,FALSE,          // 78  InitReq
    DT_ENUM,1,AT_SBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetFaultOptPtr,TRUE,            // 79  FaultOpt
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetFaultValuePtr,TRUE,       // 80  FaultValue
    DT_ENUM,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetFaultStatePtr,FALSE,        // 81  FaultState
    DT_UINT8,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetSlotSfLrsPtr,FALSE,        // 82  SlotSfLrs
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_LInvPtr,FALSE,        // 83  B0_LInv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_LInvPtr,FALSE,        // 84  B1_LInv
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOpInternalPtr,FALSE,     // 85  OpInternal
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_LPtr,FALSE,           // 86  B0_L
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_LPtr,FALSE,           // 87  B1_L
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_OPtr,FALSE,           // 88  B0_O
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_OPtr,FALSE,           // 89  B1_O 
    DT_UINT16,2,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOutDACImgPtr,FALSE,       // 90  OutDACImg  
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 91   
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S0Ptr,FALSE,        // 92  Chrc_S0 
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S1Ptr,FALSE,        // 93  Chrc_S1 
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S2Ptr,FALSE,        // 94  Chrc_S2  
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S3Ptr,FALSE,        // 95  Chrc_S3 
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetChrc_S4Ptr,FALSE,        // 96  Chrc_S4 
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetOTPT_UnusedPtr,FALSE,       // 97  OTPT_Unused 
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB0_InvPtr,FALSE,         // 98  B0_Inv 
    DT_FLOAT32,4,AT_MBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetB1_InvPtr,FALSE,         // 99  B1_Inv 
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetOptTypePtr,TRUE,             // 100 OptType // Output type (0-20 ma,...etc) 
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetDitherFreqPtr,TRUE,       // 101 DitherFreq // Dither Frequency 
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetDitherAmplPtr,TRUE,      // 102 DitherAmpl // Dither Amplitue 
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetInLckFlOpt1Ptr,TRUE,        // 103 InLckFlOpt1 // Opvalue write control configuration Interloack failure 1 
    DT_ENUM,1,AT_SBYTE,ALCK_SUPR,CONTROLSTATE_NONE,0,0,GetInLckFlOpt2Ptr,TRUE,        // 104 InLckFlOpt2 // Opvalue write control configuration Interloack failure 2 
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetInSelPrcIntLck1Ptr,TRUE,    // 105 InSelPrcIntLck1  // PRCSINTRLOCK1: DI1PVFL, DI2PVFL: selection input for process interlock 
    DT_ENUM,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetInSelPrcIntLck2Ptr,TRUE,    // 106 InSelPrcIntLck2// PRCSINTRLOCK2: DI1PVFL, DI2PVFL: selection input for process interlock 
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetPrcSafeOp1Ptr,TRUE,      // 107 PRCSAFEOP1
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetPrcSafeOp2Ptr,TRUE,      // 108 PRCSAFEOP2
    DT_FLOAT32,4,AT_MBYTE,ALCK_EPB,CONTROLSTATE_NONE,0,0,GetOpBiasCurrentPtr,TRUE,    // 109 OPBIASCURRENT
    DT_INT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetSvpRegCtlOpConnection,TRUE, // 110 OPCONNECTION
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetOpActionPtr,TRUE,            // 111 OPACTION
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetOpHiCurrentPtr,TRUE,      // 112 OPHICURRENT
    DT_FLOAT32,4,AT_MBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetOpLoCurrentPtr,TRUE,      // 113 OPLOCURRENT
    DT_BLIND,92,AT_PSET,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetCheckPointPtr,FALSE,       // 114 CheckPoint
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 115 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 116 
    DT_BOOL,1,AT_SBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetSecDiagEnbPtr,FALSE,        // 117 SecDaigEnable
    DT_FLOAT32,4,AT_MBYTE,ALCK_ENGR,CONTROLSTATE_NONE,0,0,GetSecDiagCurrentPtr,FALSE, // 118  Secondary Diagnostic Current
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntrLck1StsPtr,FALSE,       // 119 Intrlck1Sts
    DT_BOOL,1,AT_SBYTE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,GetIntrLck2StsPtr,FALSE,       // 120 IntrLck2Sts
    DT_ENUM,1,AT_SBYTE,ALCK_PBD,CONTROLSTATE_NONE,0,0,GetDitherWaveformPtr,TRUE,      // 121 DitherWaveform
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 122
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 123
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 124
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 125
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 126
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 127
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 128
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 129
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 130
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 131
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 132
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 133 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 134 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 135 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 136 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 137 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 138 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 139 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 140 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 141 
    DT_UINT8,1,AT_SBYTE,ALCK_IUSER,CONTROLSTATE_NONE,0,0,GetSlotChkpntVersionPtr,TRUE,// 142 SlotChkpntVersion
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 143 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 144 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 145 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 146 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 147 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 148 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 149 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 150 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 151 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 152 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 153 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 154 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 155 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 156 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 157 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 158   
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 159
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 160
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 161
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 162
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 163
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 164
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 165
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 166
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 167
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 168
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 169
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 170
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 171
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 172
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 173
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 174
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 175
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 176
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 177
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 178
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 179
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 180
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 181
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 182
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 183
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 184
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 185
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 186
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 187
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 188
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 189
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 190
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 191
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 192
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 193
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 194
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 195
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 196
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 197
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 198
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 199
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 200
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 201
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 202
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 203
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 204
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 205
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 206
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 207
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 208
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 209
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 210
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 211
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 212
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 213
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 214 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 215 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 216 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 217
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 218
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 219 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 220
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 221
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 222
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 223
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 224
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 225
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 226
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 227
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 228
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 229
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 230
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 231
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 232
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 233
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 234
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 235
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 236
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 237
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 238
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 239
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 240
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 241
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 242
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 243
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 244
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 245 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 246 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 247 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 248 
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 249
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 250
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 251
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 252
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 253
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 254
    DT_NONE,0,AT_NONE,ALCK_VIEW,CONTROLSTATE_NONE,0,0,0,FALSE,                        // 255
};

/*******************************************************************************
*                            clsAoServoSlot::clsAoServoSlot                    *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
clsAoServoSlot::clsAoServoSlot( UINT8 a_ucSltNm ) : clsOutSlot(PNTTYPE_NOTCONFIGURED, a_ucSltNm) 
{
    //Get the slot shared ram pointer into local variable
    UINT8 nSlotNum = a_ucSltNm - AO_SERVO_CHANNEL_START_INDEX;
    pAoShramSlotData = &ShramData.ShramSlotData.AoShramSlotData[nSlotNum];

    //Initialize the class member variables
    InitServoAoSlot();
}

/*******************************************************************************
*                           clsAoServoSlot::operator new                       *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID *clsAoServoSlot::operator new(UINT32, UINT8 a_ucSltNm) { 
    return (ucIomDbMemory + SVPBOXSLOT_SIZE + (AI_MAXSLOTS * AILVDTSLOT_SIZE)+ 
              ((a_ucSltNm-AO_SERVO_CHANNEL_1_NUMBER)* AOSERVOSLOT_SIZE));
}

/*******************************************************************************
*                            clsAoServoSlot::GetDataType                       *
*                          ==========================                          *
* PURPOSE:    Returns the Data type of a requested parameter                   *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Data type                                                        *
* NOTES:                                                                       *
*******************************************************************************/
DATATYPE clsAoServoSlot::GetDataType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].DataType;
}

/*******************************************************************************
*                          clsAoServoSlot::GetAccessType                       *
*                          ==========================                          *
* PURPOSE:    Returns the access type of a requested parameter                 *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Access type                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSTYPE clsAoServoSlot::GetAccessType(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessType;
}

/*******************************************************************************
*                            clsAoServoSlot::GetParamSize                      *
*                            ========================                          *
* PURPOSE:    Returns the Size of a requested parameter                        *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Size                                                             *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 clsAoServoSlot::GetParamSize(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].Size;
}

/*******************************************************************************
*                            clsAoServoSlot::GetParamPtr                       *
*                            =======================                           *
* PURPOSE:    Returns the Pointer to the GetParamPtr of a requested parameter  *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Pointer to the GetParamPtr function                              *
* NOTES:                                                                       *
*******************************************************************************/
UINT8 *clsAoServoSlot::GetParamPtr(UINT8 a_ucParamNumber) {
    return (UINT8 *)(this->*(tblParamInfo[a_ucParamNumber].ParamPtr))();
}

/*******************************************************************************
*                           clsAoServoSlot::GetAccessLock                      *
*                           =========================                          *
* PURPOSE:    Returns the access lock of a requested parameter                 *
* ARGUMENTS:                                                                   *
*             a_ucParamNumber  - Parameter Number                              *
* RETURN:                                                                      *
              Access Lock                                                      *
* NOTES:                                                                       *
*******************************************************************************/
ACCESSLOCK clsAoServoSlot::GetAccessLock(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].AccessLock;
}

/*******************************************************************************
*                       clsAoServoSlot::GetIsDbChecksumed                      *
*                       ============================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsAoServoSlot::GetIsDbChecksumed(UINT8 a_ucParamNumber) {
    return tblParamInfo[a_ucParamNumber].IsDbChecksumed;
}

/*******************************************************************************
*                         clsAoServoSlot::VerifyControlState                   *
*                         ==============================                       *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAoServoSlot::VerifyControlState(UINT8 a_ucParamNumber) {
    UINT8 ModuleState = BOX->GetModuleStatus();
    UINT8 PntExecSts   = (PTEXECST)pAoShramSlotData->PtExecSt;
    switch (tblParamInfo[a_ucParamNumber].ControlState) {
    case CONTROLSTATE_INACTIVE:
        if (PTEXECST_INACTIVE != PntExecSts) {
            return DO_POINT_MUST_BE_INACTIVE;
        }
        break;
    case CONTROLSTATE_INACTIVEORIDLE:
        if ((PTEXECST_INACTIVE != PntExecSts) && 
            (MODSTATUS_IDLE != ModuleState)) {
            return DO_POINT_MUST_BE_INACTIVE_OR_IDLE;
        }
        break;
    case CONTROLSTATE_ACTIVEANDRUN:
        if ((PTEXECST_ACTIVE != PntExecSts) || 
            (MODSTATUS_RUN != ModuleState)) {
            return DO_STATE_MUST_BE_RUN;
        }
        break;
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsAoServoSlot::ExecutePreFunction                   *
*                         ==============================                       *
* PURPOSE:   Invokes the Prefunction of a request parameter                    *
* ARGUMENTS:                                                                   *
                a_ucParamNumber  - Parameter Number                            *
                a_Buffer         -   Pointer to the data                       *
*               a_ucAccessLevel  -   Access level of the parameter             *
* RETURN:                                                                      *
                PA_OK                                                          *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsAoServoSlot::ExecutePreFunction(UINT8 a_ucParamNumber,
                                        UINT8 *a_Buffer,UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PrePtr != 0) {
        return (this->*(tblParamInfo[a_ucParamNumber].PrePtr))
               (a_Buffer,a_ucAccessLevel);
    }
    return PA_OK;
}

/*******************************************************************************
*                         clsAoServoSlot::ExecutePostFunction                  *
*                         ===============================                      *
* PURPOSE:   Invokes the Postfunction of a request parameter                   *
* ARGUMENTS:                                                                   *
                a_ucParamNumber  - Parameter Number                            *
*               a_ucAccessLevel  -   Access level of the parameter             *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAoServoSlot::ExecutePostFunction(UINT8 a_ucParamNumber,
                                         UINT8 a_ucAccessLevel) {
    if (tblParamInfo[a_ucParamNumber].PostPtr != 0) {
        (this->*(tblParamInfo[a_ucParamNumber].PostPtr))(a_ucAccessLevel);
    }
}

/*******************************************************************************
*                           clsAoServoSlot::InitSlotDatabase                   *
*                           ============================                       *
*  Initialize the entire channel database. Calls the Init function for each    *
*  class in the channel object hierarchy and recompute database checksum.      *
*******************************************************************************/
VOID clsAoServoSlot::InitSlotDatabase(BOOL bFullInit) {
    
    BOOL bObjCreate = FALSE; 
    //Initialize base class members
    InitIoSlot(PntType, bFullInit, bObjCreate);
    InitOutSlot(PntType, bFullInit, bObjCreate);
    InitServoAoSlot();
    
    ComputeCheckSum(); // Recompute SLOT checksum
}

/*******************************************************************************
*                            clsAoServoSlot::InitServoAoSlot                   *
*                          ==========================                          *
* PURPOSE:    Initilizes required AO and Servo Params                          *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsAoServoSlot::InitServoAoSlot(VOID)
{
    InitTcAoSlot(FALSE,TRUE);

    OptType        = BP_10_MINUS_10_MA; //Servo
    DitherFreq     = 50; // this is in Hertz  //Servo
    DitherAmpl     = 8; //it is there in ma  //Servo
    IntrLckFlOpt1  = PRC_INT_LCK_FAIL_NONE;
    IntrLckFlOpt2  = PRC_INT_LCK_FAIL_NONE;
    PrcIntLck1     = PRC_LCK_NONE;
    PrcIntLck2     = PRC_LCK_NONE;
    PrcSafeOP      = 0;
    DitherAmpMaxLm = MAX_DITHER_PERCENT;
    DitherAmpMinLm = MIN_DITHER_PERCENT;

    SecDiagEnb     = TRUE;
    SecDiagCurrent = 0.1;

    SvpFaultOpt    = SVPFAULTOPT_USEBIASCURRNT;
    OpBiasCurrent  = 0;
    IntrLck1Sts    = TRUE;
    IntrLck2Sts    = TRUE;
    SvpRegCtlOpConnection = 0;
    OpAction       = OP_INCREMENTAL;
    OpHiCurrent    = NaN;
    OpLoCurrent    = NaN;
    DitherWaveform = DITHER_WAVEFORM_SINE;
}

/*******************************************************************************
*                           clsAoServoSlot::InitTcAoSlot                       *
*                           =======================                            *
* PURPOSE: InitAohSlot function which initializes clsAohSlot class members.    *
* ARGUMENTS:                                                                   *
*            bFullInit   - Flag utilised when slots have to be reinitialised   *
*            bObjCreate  - Flag utilised when slots have to be reinitialised   *
* RETURN:    NONE                                                              *
* NOTES:   This function is called when slot parameters                        *
*          need to be reinitialised                                            *
*******************************************************************************/
VOID clsAoServoSlot::InitTcAoSlot(BOOL bFullInit, BOOL bObjCreate) 
{
    OpChar  =  FALSE;
    OpIn0   =  OP_LOLIMIT;
    OpIn1   =  NaN;
    OpIn2   =  NaN;
    OpIn3   =  NaN;
    OpIn4   =  NaN;
    OpIn5   =  OP_HILIMIT;
    OpOut0  =  OP_LOLIMIT;
    OpOut1  =  NaN;
    OpOut2  =  NaN;
    OpOut3  =  NaN;
    OpOut4  =  NaN;
    OpOut5  =  OP_HILIMIT;    
    OTPT_Unused =  TRUE;

    if (TRUE == bObjCreate) 
    {
        B0_L      =  NaN;
        B1_L      =  NaN;
        B0_O      =  NaN;
        B1_O      =  NaN;

        //In the linear equation 
        // y = mx+c //y = intercept ;m = slope ;c=offset constant 
        //To update these constants at the initialization
        //from the calibration constants 
        B0_Inv    = -B0_O /B1_O; //output offset compensation
        B1_Inv    = 1/B1_O;//slope offset compensation
        B0_LInv   = -B0_L /B1_L; //loopback offset compensation
        B1_LInv   = 1/B1_L; //loopback slope compensation
    
        OutDACImg = 0;
        LoopBackDACImg = 0;

        Chrc_S0   =  NaN;
        Chrc_S1   =  NaN;
        Chrc_S2   =  NaN;
        Chrc_S3   =  NaN;
        Chrc_S4   =  NaN;  
 
        OpFinal   =  OP_LOLIMIT;
        OpInternal =  OP_LOLIMIT;        
    }
    if (TRUE == bFullInit) {
        Op = OP_LOLIMIT;
        InitReq = TRUE;
        StdbyMan = FALSE;
    }
}

/*******************************************************************************
*                    Get Methods for AO Channels Parameters                    *
*******************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////
//Getting the data from shared ram database into local copy and returns the pointers
//////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
//Overrided clsIoSlot Class Varibles GetPtr methods
//////////////////////////////////////////////////////////

VOID *clsAoServoSlot::GetPntTypePtr(VOID)         
{ 
    PntType = (PNTTYPE)pAoShramSlotData->PntType;

    return &PntType;
}

VOID *clsAoServoSlot::GetPtExecStPtr(VOID)        
{
    PtExecSt = (PTEXECST)pAoShramSlotData->PtExecSt;

    return &PtExecSt;        
}

///////////////////////////////////////////////////////////
//Overrided clsOutSlot Class Varibles GetPtr methods
///////////////////////////////////////////////////////////

VOID *clsAoServoSlot::GetModeAttrPtr(VOID)
{
    ModeAttr = (MODEATTR)pAoShramSlotData->ModeAttr;
    
    return &ModeAttr;
} 

VOID *clsAoServoSlot::GetModePtr(VOID)
{
    Mode = (MODE)pAoShramSlotData->Mode;

    return &Mode;
} 

VOID *clsAoServoSlot::GetModePermPtr(VOID)
{
    ModePerm = (MODEPERM)pAoShramSlotData->ModePerm;
    
    return &ModePerm;
} 

VOID *clsAoServoSlot::GetNModeAttrPtr(VOID)
{
    NModeAttr = (MODEATTR)pAoShramSlotData->NModeAttr;
    
    return &NModeAttr;
} 

VOID *clsAoServoSlot::GetNModePtr(VOID)
{
    NMode = (MODE)pAoShramSlotData->NMode;

    return &NMode;
} 

VOID *clsAoServoSlot::GetOptDirPtr(VOID)
{
    OptDir = (OPTDIR)pAoShramSlotData->OptDir;

    return &OptDir;
} 

VOID *clsAoServoSlot::GetRedTagPtr(VOID)
{
    RedTag = (REDTAG)pAoShramSlotData->RedTag;

    return &RedTag;
}

///////////////////////////////////////////////////////////
//Member Varibles GetPtr methods
///////////////////////////////////////////////////////////

VOID *clsAoServoSlot::GetOpPtr(VOID) 
{ 
    Op = (FLOAT32)pAoShramSlotData->Op;

    return &Op;
}

VOID *clsAoServoSlot::GetInitReqPtr(VOID) 
{ 
    InitReq = (BOOL)pAoShramSlotData->InitReq;

    return &InitReq;
}

VOID *clsAoServoSlot::GetOpCharPtr(VOID)
{
    OpChar = (BOOL)pAoShramSlotData->OpChar;

    return &OpChar;
}

VOID *clsAoServoSlot::GetOpFinalPtr(VOID)
{
    OpFinal = (FLOAT32)pAoShramSlotData->OpFinal;

    return &OpFinal;
}

VOID *clsAoServoSlot::GetOpIn0Ptr(VOID)
{
    OpIn0 = (FLOAT32)pAoShramSlotData->OpIn0;

    return &OpIn0;
}

VOID *clsAoServoSlot::GetOpIn1Ptr(VOID)
{
    OpIn1 = (FLOAT32)pAoShramSlotData->OpIn1;

    return &OpIn1;
}

VOID *clsAoServoSlot::GetOpIn2Ptr(VOID)
{
    OpIn2 = (FLOAT32)pAoShramSlotData->OpIn2;

    return &OpIn2;
}

VOID *clsAoServoSlot::GetOpIn3Ptr(VOID)
{
    OpIn3 = (FLOAT32)pAoShramSlotData->OpIn3;
    
    return &OpIn3;
}

VOID *clsAoServoSlot::GetOpIn4Ptr(VOID)
{
    OpIn4 = (FLOAT32)pAoShramSlotData->OpIn4;

    return &OpIn4;
}

VOID *clsAoServoSlot::GetOpIn5Ptr(VOID)
{
    OpIn5 = (FLOAT32)pAoShramSlotData->OpIn5;

    return &OpIn5;
}

VOID *clsAoServoSlot::GetOpOut0Ptr(VOID)
{
    OpOut0 = (FLOAT32)pAoShramSlotData->OpOut0;

    return &OpOut0;
}

VOID *clsAoServoSlot::GetOpOut1Ptr(VOID)
{
    OpOut1 = (FLOAT32)pAoShramSlotData->OpOut1;

    return &OpOut1;
}

VOID *clsAoServoSlot::GetOpOut2Ptr(VOID)
{
    OpOut2 = (FLOAT32)pAoShramSlotData->OpOut2;

    return &OpOut2;
}

VOID *clsAoServoSlot::GetOpOut3Ptr(VOID)
{
    OpOut3 = (FLOAT32)pAoShramSlotData->OpOut3;

    return &OpOut3;
}

VOID *clsAoServoSlot::GetOpOut4Ptr(VOID)
{
    OpOut4 = (FLOAT32)pAoShramSlotData->OpOut4;

    return &OpOut4;
}

VOID *clsAoServoSlot::GetOpOut5Ptr(VOID)
{
    OpOut5 = (FLOAT32)pAoShramSlotData->OpOut5;

    return &OpOut5;
}

VOID *clsAoServoSlot::GetStdbyManPtr(VOID) 
{
    StdbyMan = (BOOL)pAoShramSlotData->StdbyMan;

    return &StdbyMan;
}

VOID *clsAoServoSlot::GetFaultOptPtr(VOID)
{
    SvpFaultOpt = (SVPFAULTOPT)pAoShramSlotData->FaultOpt;

    return &SvpFaultOpt;
}

VOID *clsAoServoSlot::GetFaultValuePtr(VOID)
{
    FaultValue = (FLOAT32)pAoShramSlotData->FaultValue;

    return &FaultValue;
}   

VOID *clsAoServoSlot::GetOptTypePtr(VOID)    
{
    OptType = (AOOPTTYPE)pAoShramSlotData->OptType;

    return &OptType;
}
  
VOID *clsAoServoSlot::GetDitherFreqPtr(VOID)
{
    DitherFreq = (FLOAT32)pAoShramSlotData->DitherFreq;

    return &DitherFreq;
}

VOID *clsAoServoSlot::GetDitherAmplPtr(VOID)
{
    DitherAmpl = (FLOAT32)pAoShramSlotData->DitherAmpl;

    return &DitherAmpl;
}

VOID *clsAoServoSlot::GetInLckFlOpt1Ptr(VOID)
{
    IntrLckFlOpt1 = (PRCINTRLCKFAILOPT)pAoShramSlotData->IntrLckFlOpt1;

    return &IntrLckFlOpt1;
}

VOID *clsAoServoSlot::GetInLckFlOpt2Ptr(VOID)
{
    IntrLckFlOpt2 = (PRCINTRLCKFAILOPT)pAoShramSlotData->IntrLckFlOpt2;

    return &IntrLckFlOpt2;
}

VOID *clsAoServoSlot::GetInSelPrcIntLck1Ptr(VOID)
{
    PrcIntLck1 = (PRCINTRLCK)pAoShramSlotData->PrcIntLck1;

    return &PrcIntLck1;
}

VOID *clsAoServoSlot::GetInSelPrcIntLck2Ptr(VOID)
{
    PrcIntLck2 = (PRCINTRLCK)pAoShramSlotData->PrcIntLck2;

    return &PrcIntLck2;
}  

VOID *clsAoServoSlot::GetPrcSafeOp1Ptr(VOID)
{
    PrcSafeOp1 = (FLOAT32)pAoShramSlotData->PrcSafeOp1;

    return &PrcSafeOp1;
}

VOID *clsAoServoSlot::GetPrcSafeOp2Ptr(VOID)
{
    PrcSafeOp2 = (FLOAT32)pAoShramSlotData->PrcSafeOp2;

    return &PrcSafeOp2;
}


VOID *clsAoServoSlot::GetOpBiasCurrentPtr(VOID)
{
    OpBiasCurrent  = (FLOAT32)pAoShramSlotData->OpBiasCurrent;

    return &OpBiasCurrent;
}

VOID *clsAoServoSlot::GetSvpRegCtlOpConnection(VOID) 
{
    SvpRegCtlOpConnection = (INT32) pAoShramSlotData->SvpRegCtlOpConnection;

    return &SvpRegCtlOpConnection;
}

VOID *clsAoServoSlot::GetOpActionPtr(VOID)
{
   OpAction = (OPACTION) pAoShramSlotData->OpAction;

   return &OpAction;
}

VOID *clsAoServoSlot::GetOpHiCurrentPtr(VOID)
{
    OpHiCurrent = (FLOAT32)pAoShramSlotData->OpHiCurrent;

    return &OpHiCurrent;
}

VOID *clsAoServoSlot::GetOpLoCurrentPtr(VOID)
{
    OpLoCurrent = (FLOAT32)pAoShramSlotData->OpLoCurrent;

    return &OpLoCurrent;
}

VOID *clsAoServoSlot::GetSecDiagEnbPtr(VOID)
{
    SecDiagEnb = (BOOL)pAoShramSlotData->SecDiagEnb;

    return &SecDiagEnb;
}
VOID *clsAoServoSlot::GetB0_LInvPtr(VOID)
{
    B0_LInv = (FLOAT32)pAoShramSlotData->B0_LInv;

    return &B0_LInv;
}

VOID *clsAoServoSlot::GetB1_LInvPtr(VOID)
{
    B1_LInv = (FLOAT32)pAoShramSlotData->B1_LInv;

    return &B1_LInv;
}

VOID *clsAoServoSlot::GetOpInternalPtr(VOID)
{
    OpInternal = (FLOAT32)pAoShramSlotData->OpInternl;

    return &OpInternal;
}

VOID *clsAoServoSlot::GetB0_LPtr(VOID)
{
    B0_L = (FLOAT32)pAoShramSlotData->B0_L;

    return &B0_L;
}

VOID *clsAoServoSlot::GetB1_LPtr(VOID)
{
    B1_L = (FLOAT32)pAoShramSlotData->B1_L;

    return &B1_L;
}

VOID *clsAoServoSlot::GetB0_OPtr(VOID)
{
    B0_O = (FLOAT32)pAoShramSlotData->B0_O;

    return &B0_O;
}

VOID *clsAoServoSlot::GetB1_OPtr(VOID)
{
    B1_O = (FLOAT32)pAoShramSlotData->B1_O;

    return &B1_O;
}

VOID *clsAoServoSlot::GetChrc_S0Ptr(VOID)
{
    Chrc_S0 = (FLOAT32)pAoShramSlotData->Chrc_S0;

    return &Chrc_S0;
}

VOID *clsAoServoSlot::GetChrc_S1Ptr(VOID)
{
    Chrc_S1 = (FLOAT32)pAoShramSlotData->Chrc_S1;

    return &Chrc_S1;
}

VOID *clsAoServoSlot::GetChrc_S2Ptr(VOID)
{
    Chrc_S2 = (FLOAT32)pAoShramSlotData->Chrc_S2;

    return &Chrc_S2;
}

VOID *clsAoServoSlot::GetChrc_S3Ptr(VOID)
{
    Chrc_S3 = (FLOAT32)pAoShramSlotData->Chrc_S3;

    return &Chrc_S3;
}

VOID *clsAoServoSlot::GetChrc_S4Ptr(VOID)
{
    Chrc_S4 = (FLOAT32)pAoShramSlotData->Chrc_S4;

    return &Chrc_S4;
}

VOID *clsAoServoSlot::GetOTPT_UnusedPtr(VOID)
{
    OTPT_Unused = (BOOL)pAoShramSlotData->OTPT_Unused;
    
    return &OTPT_Unused;
}

VOID *clsAoServoSlot::GetB0_InvPtr(VOID)
{
    B0_Inv = (FLOAT32)pAoShramSlotData->B0_Inv;

    return &B0_Inv;
}

VOID *clsAoServoSlot::GetB1_InvPtr(VOID)
{
    B1_Inv = (FLOAT32)pAoShramSlotData->B1_Inv;

    return &B1_Inv;
}

VOID *clsAoServoSlot::GetOutDACImgPtr(VOID)
{
    OutDACImg = (UINT16)pAoShramSlotData->OutDACImg;
    
    return &OutDACImg;
}

VOID *clsAoServoSlot::GetSecDiagCurrentPtr(VOID)
{
    SecDiagCurrent = (FLOAT32)pAoShramSlotData->SecDiagCurrent;
 
    return &SecDiagCurrent;
}

VOID *clsAoServoSlot::GetIntrLck1StsPtr(VOID)
{
    IntrLck1Sts = (BOOL)pAoShramSlotData->IntrLck1Sts;

    return &IntrLck1Sts;
}

VOID *clsAoServoSlot::GetIntrLck2StsPtr(VOID)
{
    IntrLck2Sts = (BOOL)pAoShramSlotData->IntrLck2Sts;

    return &IntrLck2Sts;
}

VOID *clsAoServoSlot::GetDitherWaveformPtr(VOID)    
{
    DitherWaveform = (DITHER_WAVEFORM)pAoShramSlotData->DitherWaveform;

    return &DitherWaveform;
}


/*******************************************************************************
*                         clsAoServoSlot::GetDumpData                          *
*                         ===============================                      *
* PURPOSE:  This method will copy the redundancy dump data to buffer transmit  *
*           to the secondary IOM                                               *
* ARGUMENTS:                                                                   *
                                                                               *
*                                                                              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS  clsAoServoSlot::GetDumpData(UINT8* const pDump, const UINT8 MaxSize)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL && sizeof(strAoServoSlotDumpData) < MaxSize)
    {
        strAoServoSlotDumpData *pDumpData = (strAoServoSlotDumpData*)pDump;
            
        pDumpData->Version      = PACK2_AS_UI16(SVPAO_SYNC_VER_2,0);
        pDumpData->PntType      = (PNTTYPE)pAoShramSlotData->PntType;
        pDumpData->PtExecSt     = (PTEXECST)pAoShramSlotData->PtExecSt;
        pDumpData->FaultState   = (FAULTSTATE)pAoShramSlotData->FaultState;
        pDumpData->FaultOpt     = (SVPFAULTOPT)pAoShramSlotData->FaultOpt;
        pDumpData->FaultValue   = (FLOAT32)pAoShramSlotData->FaultValue;
        pDumpData->Mode         = (MODE)pAoShramSlotData->Mode;
        pDumpData->ModeAttr     = (MODEATTR)pAoShramSlotData->ModeAttr;
        pDumpData->ModePerm     = (MODEPERM)pAoShramSlotData->ModePerm;
        pDumpData->NMode        = (MODE)pAoShramSlotData->NMode;
        pDumpData->NModeAttr    = (MODEATTR)pAoShramSlotData->NModeAttr;
        pDumpData->RedTag       = (REDTAG)pAoShramSlotData->RedTag;
        pDumpData->OptDir       = (OPTDIR)pAoShramSlotData->OptDir;
        pDumpData->OpIn0        = (FLOAT32)pAoShramSlotData->OpIn0;
        pDumpData->OpIn1        = (FLOAT32)pAoShramSlotData->OpIn1;
        pDumpData->OpIn2        = (FLOAT32)pAoShramSlotData->OpIn2;
        pDumpData->OpIn3        = (FLOAT32)pAoShramSlotData->OpIn3;
        pDumpData->OpIn4        = (FLOAT32)pAoShramSlotData->OpIn4;
        pDumpData->OpIn5        = (FLOAT32)pAoShramSlotData->OpIn5;
        pDumpData->OpOut0       = (FLOAT32)pAoShramSlotData->OpOut0;
        pDumpData->OpOut1       = (FLOAT32)pAoShramSlotData->OpOut1;
        pDumpData->OpOut2       = (FLOAT32)pAoShramSlotData->OpOut2;
        pDumpData->OpOut3       = (FLOAT32)pAoShramSlotData->OpOut3;
        pDumpData->OpOut4       = (FLOAT32)pAoShramSlotData->OpOut4;
        pDumpData->OpOut5       = (FLOAT32)pAoShramSlotData->OpOut5;
        pDumpData->PrcSafeOp1   = (FLOAT32)pAoShramSlotData->PrcSafeOp1;
        pDumpData->PrcSafeOp2   = (FLOAT32)pAoShramSlotData->PrcSafeOp2;
        pDumpData->OpBiasCurrent= (FLOAT32)pAoShramSlotData->OpBiasCurrent;
        pDumpData->DitherFreq   = (FLOAT32)pAoShramSlotData->DitherFreq;
        pDumpData->DitherAmpl   = (FLOAT32)pAoShramSlotData->DitherAmpl;
        pDumpData->OpHiCurrent  = (FLOAT32)pAoShramSlotData->OpHiCurrent;
        pDumpData->OpLoCurrent  = (FLOAT32)pAoShramSlotData->OpLoCurrent;
        pDumpData->OpChar       = (BOOL)pAoShramSlotData->OpChar;
        pDumpData->OptType      = (AOOPTTYPE)pAoShramSlotData->OptType;
        pDumpData->OpAction     = (OPACTION)pAoShramSlotData->OpAction;
        pDumpData->IntrLckFlOpt1= (PRCINTRLCKFAILOPT)pAoShramSlotData->IntrLckFlOpt1;
        pDumpData->IntrLckFlOpt2= (PRCINTRLCKFAILOPT)pAoShramSlotData->IntrLckFlOpt2;
        pDumpData->PrcIntLck1   = (PRCINTRLCK)pAoShramSlotData->PrcIntLck1;
        pDumpData->PrcIntLck2   = (PRCINTRLCK)pAoShramSlotData->PrcIntLck2;
        pDumpData->SvpRegCtlOpConnection = (INT32)pAoShramSlotData->SvpRegCtlOpConnection;
        pDumpData->Chrc_S0               = (FLOAT32)pAoShramSlotData->Chrc_S0;
        pDumpData->Chrc_S1               = (FLOAT32)pAoShramSlotData->Chrc_S1;
        pDumpData->Chrc_S2               = (FLOAT32)pAoShramSlotData->Chrc_S2;
        pDumpData->Chrc_S3               = (FLOAT32)pAoShramSlotData->Chrc_S3;
        pDumpData->Chrc_S4               = (FLOAT32)pAoShramSlotData->Chrc_S4;
        pDumpData->OTPT_Unused           = (BOOL)pAoShramSlotData->OTPT_Unused;
        pDumpData->Op                    = (FLOAT32)pAoShramSlotData->Op;        
        pDumpData->SecDiagCurrent = (FLOAT32)pAoShramSlotData->SecDiagCurrent;
        pDumpData->SecDiagEnb = (BOOL)pAoShramSlotData->SecDiagEnb;
        pDumpData->DitherWaveform = (DITHER_WAVEFORM)pAoShramSlotData->DitherWaveform;
        
        RetVal = PA_OK;
    }

    return RetVal;
}

/*******************************************************************************
*                         clsAoServoSlot::StoreDumpData                        *
*                         ===============================                      *
* PURPOSE:  This method will copy the redundancy dump data into local dump     *
*           structure in Primary IOM                                           *
*                                                                              *
* ARGUMENTS:                                                                   *
*                                                                              *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS  clsAoServoSlot::StoreDumpData(UINT8* const pDump)
{
    PASTATUS RetVal = PA_NULL;
    if(pDump != NULL)
    {
        // Find out the dump record version. The first byte of Dump Record Structure always shows current version.
        UINT8 uDumpVer = pDump[0];        

        if(uDumpVer == SVPAO_SYNC_VER_1)
        {
            strAoServoSlotDumpData* pDumpData = (strAoServoSlotDumpData*)(pDump);       

            pAoShramSlotData->PntType      = pDumpData->PntType;
            pAoShramSlotData->PtExecSt     = pDumpData->PtExecSt;
            pAoShramSlotData->FaultState   = pDumpData->FaultState;
            pAoShramSlotData->FaultOpt     = pDumpData->FaultOpt;
            pAoShramSlotData->FaultValue   = pDumpData->FaultValue;
            pAoShramSlotData->Mode         = pDumpData->Mode;
            pAoShramSlotData->ModeAttr     = pDumpData->ModeAttr;
            pAoShramSlotData->ModePerm     = pDumpData->ModePerm;
            pAoShramSlotData->NMode        = pDumpData->NMode;
            pAoShramSlotData->NModeAttr    = pDumpData->NModeAttr;
            pAoShramSlotData->RedTag       = pDumpData->RedTag;
            pAoShramSlotData->OptDir       = pDumpData->OptDir;
            pAoShramSlotData->OpIn0        = pDumpData->OpIn0;
            pAoShramSlotData->OpIn1        = pDumpData->OpIn1;
            pAoShramSlotData->OpIn2        = pDumpData->OpIn2;
            pAoShramSlotData->OpIn3        = pDumpData->OpIn3;
            pAoShramSlotData->OpIn4        = pDumpData->OpIn4;
            pAoShramSlotData->OpIn5        = pDumpData->OpIn5;
            pAoShramSlotData->OpOut0       = pDumpData->OpOut0;
            pAoShramSlotData->OpOut1       = pDumpData->OpOut1;
            pAoShramSlotData->OpOut2       = pDumpData->OpOut2;
            pAoShramSlotData->OpOut3       = pDumpData->OpOut3;
            pAoShramSlotData->OpOut4       = pDumpData->OpOut4;
            pAoShramSlotData->OpOut5       = pDumpData->OpOut5;
            pAoShramSlotData->PrcSafeOp1   = pDumpData->PrcSafeOp1;
            pAoShramSlotData->PrcSafeOp2   = pDumpData->PrcSafeOp2;
            pAoShramSlotData->OpBiasCurrent= pDumpData->OpBiasCurrent;
            pAoShramSlotData->DitherFreq   = pDumpData->DitherFreq;
            pAoShramSlotData->DitherAmpl   = pDumpData->DitherAmpl;
            pAoShramSlotData->OpHiCurrent  = pDumpData->OpHiCurrent;
            pAoShramSlotData->OpLoCurrent  = pDumpData->OpLoCurrent;
            pAoShramSlotData->OpChar       = pDumpData->OpChar;
            pAoShramSlotData->OptType      = pDumpData->OptType;
            pAoShramSlotData->OpAction     = pDumpData->OpAction;
            pAoShramSlotData->IntrLckFlOpt1= pDumpData->IntrLckFlOpt1;
            pAoShramSlotData->IntrLckFlOpt2= pDumpData->IntrLckFlOpt2;
            pAoShramSlotData->PrcIntLck1   = pDumpData->PrcIntLck1;
            pAoShramSlotData->PrcIntLck2   = pDumpData->PrcIntLck2;
            pAoShramSlotData->SvpRegCtlOpConnection = pDumpData->SvpRegCtlOpConnection;
            pAoShramSlotData->Chrc_S0               = pDumpData->Chrc_S0;
            pAoShramSlotData->Chrc_S1               = pDumpData->Chrc_S1;
            pAoShramSlotData->Chrc_S2               = pDumpData->Chrc_S2;
            pAoShramSlotData->Chrc_S3               = pDumpData->Chrc_S3;
            pAoShramSlotData->Chrc_S4               = pDumpData->Chrc_S4;
            pAoShramSlotData->OTPT_Unused           = pDumpData->OTPT_Unused;
            pAoShramSlotData->Op           = pDumpData->Op;            
            pAoShramSlotData->SecDiagCurrent = pDumpData->SecDiagCurrent;
            pAoShramSlotData->SecDiagEnb = pDumpData->SecDiagEnb;
            
            RetVal = PA_OK;
        }
        else if(uDumpVer == SVPAO_SYNC_VER_2)
        {
            strAoServoSlotDumpData* pDumpData = (strAoServoSlotDumpData*)(pDump);

            pAoShramSlotData->PntType      = pDumpData->PntType;
            pAoShramSlotData->PtExecSt     = pDumpData->PtExecSt;
            pAoShramSlotData->FaultState   = pDumpData->FaultState;
            pAoShramSlotData->FaultOpt     = pDumpData->FaultOpt;
            pAoShramSlotData->FaultValue   = pDumpData->FaultValue;
            pAoShramSlotData->Mode         = pDumpData->Mode;
            pAoShramSlotData->ModeAttr     = pDumpData->ModeAttr;
            pAoShramSlotData->ModePerm     = pDumpData->ModePerm;
            pAoShramSlotData->NMode        = pDumpData->NMode;
            pAoShramSlotData->NModeAttr    = pDumpData->NModeAttr;
            pAoShramSlotData->RedTag       = pDumpData->RedTag;
            pAoShramSlotData->OptDir       = pDumpData->OptDir;
            pAoShramSlotData->OpIn0        = pDumpData->OpIn0;
            pAoShramSlotData->OpIn1        = pDumpData->OpIn1;
            pAoShramSlotData->OpIn2        = pDumpData->OpIn2;
            pAoShramSlotData->OpIn3        = pDumpData->OpIn3;
            pAoShramSlotData->OpIn4        = pDumpData->OpIn4;
            pAoShramSlotData->OpIn5        = pDumpData->OpIn5;
            pAoShramSlotData->OpOut0       = pDumpData->OpOut0;
            pAoShramSlotData->OpOut1       = pDumpData->OpOut1;
            pAoShramSlotData->OpOut2       = pDumpData->OpOut2;
            pAoShramSlotData->OpOut3       = pDumpData->OpOut3;
            pAoShramSlotData->OpOut4       = pDumpData->OpOut4;
            pAoShramSlotData->OpOut5       = pDumpData->OpOut5;
            pAoShramSlotData->PrcSafeOp1   = pDumpData->PrcSafeOp1;
            pAoShramSlotData->PrcSafeOp2   = pDumpData->PrcSafeOp2;
            pAoShramSlotData->OpBiasCurrent= pDumpData->OpBiasCurrent;
            pAoShramSlotData->DitherFreq   = pDumpData->DitherFreq;
            pAoShramSlotData->DitherAmpl   = pDumpData->DitherAmpl;
            pAoShramSlotData->OpHiCurrent  = pDumpData->OpHiCurrent;
            pAoShramSlotData->OpLoCurrent  = pDumpData->OpLoCurrent;
            pAoShramSlotData->OpChar       = pDumpData->OpChar;
            pAoShramSlotData->OptType      = pDumpData->OptType;
            pAoShramSlotData->OpAction     = pDumpData->OpAction;
            pAoShramSlotData->IntrLckFlOpt1= pDumpData->IntrLckFlOpt1;
            pAoShramSlotData->IntrLckFlOpt2= pDumpData->IntrLckFlOpt2;
            pAoShramSlotData->PrcIntLck1   = pDumpData->PrcIntLck1;
            pAoShramSlotData->PrcIntLck2   = pDumpData->PrcIntLck2;
            pAoShramSlotData->SvpRegCtlOpConnection = pDumpData->SvpRegCtlOpConnection;
            pAoShramSlotData->Chrc_S0               = pDumpData->Chrc_S0;
            pAoShramSlotData->Chrc_S1               = pDumpData->Chrc_S1;
            pAoShramSlotData->Chrc_S2               = pDumpData->Chrc_S2;
            pAoShramSlotData->Chrc_S3               = pDumpData->Chrc_S3;
            pAoShramSlotData->Chrc_S4               = pDumpData->Chrc_S4;
            pAoShramSlotData->OTPT_Unused           = pDumpData->OTPT_Unused;
            pAoShramSlotData->Op           = pDumpData->Op;            
            pAoShramSlotData->SecDiagCurrent = pDumpData->SecDiagCurrent;
            pAoShramSlotData->SecDiagEnb = pDumpData->SecDiagEnb;
            pAoShramSlotData->DitherWaveform = pDumpData->DitherWaveform;

            RetVal = PA_OK;
        }
    }

    return RetVal;
}

