A4 HART HARDWARE VALIDATION BUILD

HART_HARDWARE_VALIDATION_BUILD=1; CMD0_CONFIRM=2; diagnostic prints enabled

Hardware validation flow:
  AppMain -> BOX/SLOT construction -> CheckAndInitHart -> HartTask registration
  -> scheduler/BOX initialization -> IOL enable -> one channel per HartTask
  -> legacy queue/modem functions -> RT1024 synchronous FPGA/UART transport.

For the hardware build, clean the MCUXpresso project, rebuild and flash it.
After "IOL ENABLED", wait about five seconds and verify this exact banner:
  HART_BUILD A4_LEGACY_STAGED_V2 SPI_RETRY=3 CMD0_CONFIRM=2 SCAN=1-16

No banner means an older binary/project configuration was flashed.
See A4_HART_deep_fix_report.md in the review package for details.
