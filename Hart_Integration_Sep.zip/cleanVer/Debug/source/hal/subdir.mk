################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../source/hal/hal_fpga_spi.c \
../source/hal/hal_gpio.c \
../source/hal/hal_gpt.c \
../source/hal/hal_pit.c \
../source/hal/hal_timer.c \
../source/hal/hal_uart.c 

C_DEPS += \
./source/hal/hal_fpga_spi.d \
./source/hal/hal_gpio.d \
./source/hal/hal_gpt.d \
./source/hal/hal_pit.d \
./source/hal/hal_timer.d \
./source/hal/hal_uart.d 

OBJS += \
./source/hal/hal_fpga_spi.o \
./source/hal/hal_gpio.o \
./source/hal/hal_gpt.o \
./source/hal/hal_pit.o \
./source/hal/hal_timer.o \
./source/hal/hal_uart.o 


# Each subdirectory must supply rules for building sources it contributes
source/hal/%.o: ../source/hal/%.c source/hal/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__NEWLIB__ -DCPU_MIMXRT1024CAG4B -DCPU_MIMXRT1024CAG4B_cm7 -DMCUXPRESSO_SDK -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_ENABLE=1 -DSDK_DEBUGCONSOLE=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DH8S_2319C=0 -DHEK=1 -DIOMTYPE_AIH=1 -DLOWCOST=0 -DMT=AIH -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\board" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\source\hal" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\source" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\drivers" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\utilities\debug_console_lite" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\utilities\str" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\device" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\component\uart" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\component\gpio" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\utilities" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\CMSIS" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\CMSIS\m-profile" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\xip" -I"C:\Users\H606382\OneDrive - Honeywell\Documents\Divyank\PMIO-Migration\D13\cleanVer\device\periph" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-source-2f-hal

clean-source-2f-hal:
	-$(RM) ./source/hal/hal_fpga_spi.d ./source/hal/hal_fpga_spi.o ./source/hal/hal_gpio.d ./source/hal/hal_gpio.o ./source/hal/hal_gpt.d ./source/hal/hal_gpt.o ./source/hal/hal_pit.d ./source/hal/hal_pit.o ./source/hal/hal_timer.d ./source/hal/hal_timer.o ./source/hal/hal_uart.d ./source/hal/hal_uart.o

.PHONY: clean-source-2f-hal

