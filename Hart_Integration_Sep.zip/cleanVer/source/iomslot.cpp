/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : iomslot.cpp                                                 *
*    Description : IOM database interface functions — ReadParamData,           *
*                  WriteParamData, ComputeCheckSum, ComputeRedCheckSum.        *
*                                                                              *
*    Ported from epicio_src/iomslot.cpp (H8S original).                        *
*    Stripped to AIH-only (no SVP/SP/UIO/DISOE conditionals).                  *
*    H8S set_imask_exr/get_imask_exr replaced with HAL calls.                  *
*******************************************************************************/
#include "iomslot.hpp"
#include "boxslot.hpp"
#include "utils.h"

/*******************************************************************************
*                          STATIC DATA                                         *
*******************************************************************************/

#if 1 //defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
extern bool bHartDataDump;
#endif

DATABYTES       clsIomSlot::Data;
UINT8           clsIomSlot::ScratchPad = 0;
UINT8           clsIomSlot::WriteIndex = 0;
UINT8           clsIomSlot::SlotChkpntVersion = 0;
UINT8           clsIomSlot::BoxChkpntVersion = 0;
PASTATUS        clsIomSlot::ucSaveChkpntPaStatus = PA_OK;
WRITEINPROGRESS clsIomSlot::WriteInProgress = { NULL, NULL };

/*******************************************************************************
*                   IsMultiByteScalar (local helper)                           *
*                   =================================                         *
* PURPOSE:                                                                     *
*    AT_MBYTE covers two very different things: true multi-byte numeric        *
*    scalars (UINT16/INT16/UINT32/INT32/FLOAT32) that need byte-order          *
*    conversion between the wire (big-endian, inherited from the H8S)  and     *
*    this ARM Cortex-M7's native little-endian storage, and opaque DT_BLIND    *
*    byte arrays/records (device tags, HART frames, etc.) that must be         *
*    copied byte-for-byte with no reordering.  This distinguishes the two.     *
*******************************************************************************/
static inline BOOL IsMultiByteScalar(DATATYPE a_dt, UINT8 a_ucSize)
{
    if (a_ucSize < 2u || a_ucSize > (UINT8)sizeof(DATABYTES)) {
        return FALSE;
    }
    switch (a_dt) {
        case DT_UINT16:
        case DT_INT16:
        case DT_UINT32:
        case DT_INT32:
        case DT_FLOAT32:
            return TRUE;
        default:
            return FALSE;
    }
}

/*******************************************************************************
*                   clsIomSlot::ReadParamData (basic)                          *
*                   ================================                           *
* PURPOSE:                                                                     *
*    Read parameter data from the database into a_pDest.  Dispatches by        *
*    AccessType: SBYTE, MBYTE, PSET, BXPACK, BXREC.                            *
* ARGUMENTS:                                                                   *
*    a_pDest     : destination buffer for the parameter data.                  *
*    a_ucParamId : parameter index (0–255).                                    *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    WriteInProgress guard prevents torn reads on multi-byte params.           *
*******************************************************************************/
void clsIomSlot::ReadParamData(UINT8 *a_pDest, UINT8 a_ucParamId)
{
    UINT8 *pSource = GetParamPtr(a_ucParamId);
    if (pSource == NULL) {
        return;
    }

    ACCESSTYPE at = GetAccessType(a_ucParamId);

    switch (at) {
        case AT_SBYTE:
            *a_pDest = *pSource;
            break;

        case AT_MBYTE: {
            /* Redirect to write buffer if a write is in progress to this
               exact location — prevents torn reads of multi-byte data */
            UINT8 *pActual = pSource;
            if (WriteInProgress.pDatabase == pSource &&
                WriteInProgress.pWriteBuffer != NULL) {
                pActual = WriteInProgress.pWriteBuffer;
            }
            UINT8 ucSize = GetParamSize(a_ucParamId);
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucSize)) {
                /* Numeric scalar: native byte order -> wire byte order. */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pActual[ucSize - 1u - i];
                }
            } else {
                /* Opaque BLIND byte array/record: copy as-is, then let the
                   derived class swap any embedded scalar fields it knows
                   about (e.g. a FLOAT32 inside a repeating struct array). */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pActual[i];
                }
                TransformBlindRecord(a_ucParamId, a_pDest, ucSize, TRUE);
            }
            break;
        }

        case AT_PSET: {
            /* Parameter-set: pSource is a null-terminated list of
               sub-parameter IDs. Walk the list, copying each sub-param. */
            while (*pSource != 0) {
                UINT8 ucSubParam = *pSource;
                UINT8 *pSubSrc   = GetParamPtr(ucSubParam);
                UINT8  ucSubSz   = GetParamSize(ucSubParam);

                if (pSubSrc != NULL) {
                    /* Check WriteInProgress for multi-byte sub-params */
                    if (ucSubSz > 1 &&
                        WriteInProgress.pDatabase == pSubSrc &&
                        WriteInProgress.pWriteBuffer != NULL) {
                        pSubSrc = WriteInProgress.pWriteBuffer;
                    }
                    if (IsMultiByteScalar(GetDataType(ucSubParam), ucSubSz)) {
                        for (UINT8 j = 0; j < ucSubSz; j++) {
                            a_pDest[j] = pSubSrc[ucSubSz - 1u - j];
                        }
                        a_pDest += ucSubSz;
                    } else {
                        for (UINT8 j = 0; j < ucSubSz; j++) {
                            *a_pDest++ = *pSubSrc++;
                        }
                    }
                }
                pSource++;
            }
            /* For large checkpoint reads, reset STC overrun counter so the
               IOL TX phase doesn't trigger a spurious STC overrun softfail. */
            if (ChanNum != 0 && a_ucParamId == PARAMID_SLTCHKPNT) {
                //TaskScheduler.SetStcOverrunCounter(1);
            }
            break;
        }

        case AT_BXPACK: {
            /* Box-packed bitmap: each channel's data is one bit inside
               a box-level byte array.  Extract the bit for this channel. */
            UINT8 ucBitIndex  = 0x80u >> ((ChanNum - 1) & 0x07);
            UINT8 ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
            *a_pDest = (pSource[ucByteIndex] & ucBitIndex) ? TRUE : FALSE;
            break;
        }

        case AT_BXREC: {
            /* Box blind record: block copy under interrupt protection */
            UINT8 ucSize = GetParamSize(a_ucParamId);
            if (IsMultiByteScalar(GetDataType(a_ucParamId), ucSize)) {
                /* Numeric scalar (e.g. per-channel Pv): native -> wire order. */
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[ucSize - 1u - i];
                }
            } else {
                for (UINT8 i = 0; i < ucSize; i++) {
                    a_pDest[i] = pSource[i];
                }
                TransformBlindRecord(a_ucParamId, a_pDest, ucSize, TRUE);
            }
            break;
        }

        default:
            HardFail(HF_BADPROGRAMJUMP, IOMSLOT_CPP, __LINE__);
            break;
    }
}

/*******************************************************************************
*                          clsIomSlot::ReadParamData                           *
*                          =========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsIomSlot::ReadParamData(UINT8 *a_ReadBuffer,UINT8 a_ucParamNumber,UINT8 a_ucIndex) {
    UINT8 *pSource = GetParamPtr(a_ucParamNumber);
    UINT8 ucSize = GetParamSize(a_ucParamNumber);

    pSource += ucSize * (a_ucIndex - 1);                   // index is one-based
    // Copy parameter data from object memory to read buffer.
    // Check write-in-progress semaphore for non-atomic (multi-byte) data.
    switch (GetAccessType(a_ucParamNumber)) {
    case AT_SBYTE:
        *a_ReadBuffer = *pSource;
        break;
    case AT_MBYTE:
        if (pSource == WriteInProgress.pDatabase) {
            pSource = (UINT8 *)WriteInProgress.pWriteBuffer;
        }
        if (IsMultiByteScalar(GetDataType(a_ucParamNumber), ucSize)) {
            /* made this change because indexed numeric values are stored in
               native little-endian order */
            for (UINT8 i = 0; i < ucSize; i++) {
                a_ReadBuffer[i] = pSource[ucSize - 1u - i];
            }
        } else {
            for (UINT8 i = 0; i < ucSize; i++) {
                a_ReadBuffer[i] = pSource[i];
            }
        }
        break;
    case AT_BITPACK:
        {
            a_ucIndex--; // Convert index to zero-base.
            // Find byte offset. Note that shifting 3
            // bits to right is same as dividing by 8.
            UINT8 ucByteIndex = a_ucIndex >> 3;
            // Make the bit mask. Note that masking out last 3
            // bits is same as taking reminder after dividing by 8.
            UINT8 ucBitMask  = 0x01 << (a_ucIndex & 0x07);
            UINT8 *pSource = GetParamPtr(a_ucParamNumber);
            *a_ReadBuffer = (*(pSource + ucByteIndex) & ucBitMask) ? TRUE : FALSE;
        }
        break;
    default:
        //Invalid program execution
        HardFail(HF_BADPROGRAMJUMP,IOMSLOT_CPP,__LINE__);
        break;
    }
}

/*******************************************************************************
*                          clsIomSlot::WriteParamData                          *
*                          ==========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsIomSlot::WriteParamData(UINT8 *a_pSrc, UINT8 a_ucParamId, UINT8 a_ucAccessLevel, BOOL a_bDoChkSm)
{
	UINT8 *pDestination = GetParamPtr(a_ucParamId);

	if (pDestination == NULL) {
		return DO_PARAMETER_INVALID;
	}

	ACCESSTYPE at = GetAccessType(a_ucParamId);
	UINT8 ucParamSize = GetParamSize(a_ucParamId);

#if 0
	/* ---- Checkpoint version negotiation ---- */
	if (ChanNum == 0 && a_ucParamId == PARAMID_BOXCHKPNT) {
		ucSaveChkpntPaStatus = PA_OK;
		UINT8 ucIncomingVer = *a_pSrc;
		if (ucIncomingVer > BoxChkpntVersion) {
			/* Incoming checkpoint is newer than we support — accept partial */
			pDestination = (UINT8 *)GetCheckPointPtr(BoxChkpntVersion);
			ucParamSize  = GetCheckPointSize(BoxChkpntVersion);
			ucSaveChkpntPaStatus = PA_BAD_PARAMETER_VALUE;
		} else {
			pDestination = (UINT8 *)GetCheckPointPtr(ucIncomingVer);
			ucParamSize  = GetCheckPointSize(ucIncomingVer);
		}
		*a_pSrc = BoxChkpntVersion;  /* Stamp latest version */
	}
	else if (ChanNum != 0 && a_ucParamId == PARAMID_SLTCHKPNT) {
		ucSaveChkpntPaStatus = PA_OK;
		UINT8 ucIncomingVer = *a_pSrc;
		if (ucIncomingVer > SlotChkpntVersion) {
			pDestination = (UINT8 *)GetCheckPointPtr(SlotChkpntVersion);
			ucParamSize  = GetCheckPointSize(SlotChkpntVersion);
			ucSaveChkpntPaStatus = PA_BAD_PARAMETER_VALUE;
		} else {
			pDestination = (UINT8 *)GetCheckPointPtr(ucIncomingVer);
			ucParamSize  = GetCheckPointSize(ucIncomingVer);
		}
		*a_pSrc = SlotChkpntVersion;
	}
#endif
/* ---- Copy incoming data to aligned scratch ---- */
	UINT8 ucCopyLen = ucParamSize;
	if (at != AT_PSET) {
		if (IsMultiByteScalar(GetDataType(a_ucParamId), ucCopyLen)) {
			/* Numeric scalar: wire byte order -> native byte order. */
			for (UINT8 i = 0; i < ucCopyLen; i++) {
				Data.ucBytes[i] = a_pSrc[ucCopyLen - 1u - i];
			}
		} else {
			for (UINT8 i = 0; i < ucCopyLen && i < (UINT8)sizeof(DATABYTES); i++) {
				Data.ucBytes[i] = a_pSrc[i];
			}
		}
	}

	/* ---- Pre-function validation ---- */
	PASTATUS PaStatus = PA_OK;
	if (at != AT_PSET) {
		if (ucCopyLen <= (UINT8)sizeof(DATABYTES)) {
			PaStatus = ExecutePreFunction(a_ucParamId, Data.ucBytes, a_ucAccessLevel);
		} else {
			PaStatus = ExecutePreFunction(a_ucParamId, a_pSrc, a_ucAccessLevel);
		}
		if (PaStatus != PA_OK) {
			return PaStatus;
		}
	}

	/* ---- Interrupt-guarded data copy ---- */
	UINT32 uiSavedMask = hal_interrupt_set_mask(LVLPRI_TICK);

	switch (at) {
	case AT_SBYTE:
		*pDestination = Data.ucBytes[0];
		break;

	case AT_MBYTE: {
		/* Set write-in-progress semaphore */
		WriteInProgress.pDatabase    = pDestination;
		WriteInProgress.pWriteBuffer = &Data.ucBytes[0];

		UINT8 *pCopySrc = (ucCopyLen <= (UINT8)sizeof(DATABYTES)) ? Data.ucBytes : a_pSrc;

		for (UINT8 i = 0; i < ucCopyLen; i++) {

			pDestination[i] = pCopySrc[i];
		}
		break;
	}

#if 0
	case AT_PSET: {
		/* Restore interrupt mask — each recursive sub-param write
             will set its own mask individually. */


		hal_interrupt_set_mask(uiSavedMask);

		UINT8 *pSubList = pDestination; /* null-terminated param ID list */
		UINT8 *pWrPtr   = a_pSrc;

		while (*pSubList != 0) {
			UINT8 ucSubSize = GetParamSize(*pSubList);

			/* Recursive sub-parameter write (no checksum per sub-param) */
			PaStatus = WriteParamData(pWrPtr, *pSubList, ucSubSize, FALSE);
			if (PaStatus > PA_OK) {
				ComputeCheckSum();
				return PaStatus;
			}

			pWrPtr += ucSubSize;
			pSubList++;
		}

		/* Checkpoint status override */
		if ((ChanNum == 0 && a_ucParamId == PARAMID_BOXCHKPNT) ||
				(ChanNum != 0 && a_ucParamId == PARAMID_SLTCHKPNT)) {
			PaStatus = ucSaveChkpntPaStatus;
		}

#if !defined(UNIT_TEST_BUILD) && !defined(QEMU_BUILD)
		if (a_ucParamId == PARAMID_SLTCHKPNT && ChanNum == MAXSLOTS) {
			//TraceLog.AddToTrace(TRACEID_GENERIC, bcDbRestoreDone);
		}
#endif
		/* PSET already restored interrupts above — skip the restore below */
		if (a_bDoChkSm && GetIsDbChecksumed(a_ucParamId)) {
			ComputeCheckSum();
		}
		return (PaStatus == PA_OK) ? PA_OK : PaStatus;
	}

	case AT_BXPACK: {
		/* Box-packed bitmap: set/clear one bit for this channel */
		UINT8 ucBitIndex  = 0x80u >> ((ChanNum - 1) & 0x07);
		UINT8 ucByteIndex = ((ChanNum - 1) >> 3) & 0x03;
		if (Data.ucBytes[0] > 0) {
			pDestination[ucByteIndex] |= ucBitIndex;
		} else {
			pDestination[ucByteIndex] &= ~ucBitIndex;
		}
		break;
	}

	case AT_BXREC: {
		/* Box blind record: copy under highest interrupt guard */
		UINT32 uiHiMask = hal_interrupt_set_mask(LVLPRI_HIGHEST);
		for (UINT8 i = 0; i < ucCopyLen; i++) {
			pDestination[i] = Data.ucBytes[i];
		}
		hal_interrupt_set_mask(uiHiMask);
		break;
	}
#endif
	default:
		hal_interrupt_set_mask(uiSavedMask);
		return DO_DATA_TYPE_ERROR;
	}

	/* ---- Clear semaphore and post-function ---- */
	WriteInProgress.pDatabase    = NULL;
	WriteInProgress.pWriteBuffer = NULL;
	ExecutePostFunction(a_ucParamId, a_ucAccessLevel);

	hal_interrupt_set_mask(uiSavedMask);

	/* ---- Recompute checksum if needed ---- */
	//if (a_bDoChkSm && GetIsDbChecksumed(a_ucParamId)) {
	//  ComputeCheckSum();
	// }

	return PA_OK;
}

/*******************************************************************************
*                          clsIomSlot::WriteParamData                          *
*                          ==========================                          *
* PURPOSE: Process a one-based indexed parameter write                         *
* NOTES:   HART variable selection parameter 195 is written through this path. *
*******************************************************************************/
PASTATUS clsIomSlot::WriteParamData(UINT8 *a_pSrc,
                                    UINT8 a_ucParamId,
                                    UINT8 a_ucAccessLevel,
                                    UINT8 a_ucIndex)
{
	UINT8 *pDestination = GetParamPtr(a_ucParamId);
	if (pDestination == NULL) {
		return DO_PARAMETER_INVALID;
	}

	ACCESSTYPE at = GetAccessType(a_ucParamId);
	if ((at != AT_SBYTE) && (at != AT_MBYTE)) {
		return DO_DATA_TYPE_ERROR;
	}

	ACCESSLOCK accessLock = GetAccessLock(a_ucParamId);
	if (accessLock == ALCK_VIEW) {
		return DO_READ_ONLY_PARAMETER;
	}
	if ((accessLock & a_ucAccessLevel) == 0) {
		return DO_ACCESS_LEVEL_INVALID;
	}

	PASTATUS PaStatus = VerifyControlState(a_ucParamId);
	if (PaStatus != PA_OK) {
		return PaStatus;
	}

	UINT8 ucParamSize = GetParamSize(a_ucParamId);
	UINT8 *pCopySrc = a_pSrc;
	if (ucParamSize <= (UINT8)sizeof(DATABYTES)) {
		if (IsMultiByteScalar(GetDataType(a_ucParamId), ucParamSize)) {
			for (UINT8 i = 0; i < ucParamSize; i++) {
				Data.ucBytes[i] = a_pSrc[ucParamSize - 1u - i];
			}
		}
		else {
			for (UINT8 i = 0; i < ucParamSize; i++) {
				Data.ucBytes[i] = a_pSrc[i];
			}
		}
		pCopySrc = Data.ucBytes;
	}

	WriteIndex = a_ucIndex;
	PaStatus = ExecutePreFunction(a_ucParamId, pCopySrc, a_ucAccessLevel);
	if (PaStatus != PA_OK) {
		return PaStatus;
	}

	UINT32 uiSavedMask = hal_interrupt_set_mask(LVLPRI_TICK);
	pDestination += ucParamSize * (a_ucIndex - 1u);

	if (at == AT_SBYTE) {
		*pDestination = pCopySrc[0];
	}
	else {
		WriteInProgress.pDatabase = pDestination;
		WriteInProgress.pWriteBuffer = pCopySrc;
		for (UINT8 i = 0; i < ucParamSize; i++) {
			pDestination[i] = pCopySrc[i];
		}
	}

	WriteInProgress.pDatabase = NULL;
	WriteInProgress.pWriteBuffer = NULL;
	ExecutePostFunction(a_ucParamId, a_ucAccessLevel);
	hal_interrupt_set_mask(uiSavedMask);

	if (GetIsDbChecksumed(a_ucParamId)) {
		ComputeCheckSum();
	}

	return PA_OK;
}


/*******************************************************************************
*                   clsIomSlot::ComputeCheckSum                                *
*                   ===========================                                *
* PURPOSE:                                                                     *
*    Byte-sum checksum over all parameters in the checkpoint record.           *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None (stores result via SetCheckSum).                                     *
* NOTES:                                                                       *
*    Walks the null-terminated sub-parameter ID list at the checkpoint ptr.    *
*******************************************************************************/
void clsIomSlot::ComputeCheckSum(void)
{
  UINT16 ulChecksum = 0;
  UINT8 *pChkPnt;

  if (ChanNum == 0) {
      pChkPnt = GetParamPtr(PARAMID_BOXCHKPNT);
  } else {
      pChkPnt = GetParamPtr(PARAMID_SLTCHKPNT);
  }

#if defined(IOMTYPE_UIO)
    // If GetParamPtr() returns 0, then PntType is not configured i.e UioSlot.
    // No need to calculate checksum. Set checksum value to Zero.
    if(pChkPnt == (UINT8 *)0)
    {
       ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, ulChecksum);
       return ;
    }

#endif

  /* Iterate the null-terminated sub-parameter ID list */
  while (*pChkPnt != 0) {
      UINT8 ucSubParam = *pChkPnt;
      UINT8 *pParam    = GetParamPtr(ucSubParam);
      UINT8  ucParamSz = GetParamSize(ucSubParam);

      if (pParam != NULL) {
          for (UINT8 j = 0; j < ucParamSz; j++) {
              ulChecksum += pParam[j];
          }
      }

      pChkPnt++;
  }

  ((clsBoxSlot *)pDatabase[0])->SetCheckSum(ChanNum, ulChecksum);
}

/*******************************************************************************
*                          clsIomSlot::ComputeRedCheckSum                      *
*                          ==============================                      *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: SYNC VER                                                              *
*******************************************************************************/
UINT16 clsIomSlot::ComputeRedCheckSum() {
    UINT8   ucSize,*pData,*ParamPtr;
    UINT16  ulChecksum = 0;

    pData = (UINT8 *)GetRedParamsPtr();

#if defined(IOMTYPE_UIO)
    // If GetRedParamsPtr() returns 0, then PntType is not configured i.e UioSlot.
    // No need to calculate Redundant checksum. Return 0
    if(pData == (UINT8 *)0)
       return ulChecksum;
#endif

#if defined(IOPTYPE_SCIOM)

    while (*pData) {

        ParamPtr = (UINT8 *)GetParamPtr(*pData);

        for (ucSize = GetParamSize(*pData); ucSize > 0; ucSize--) {
            ulChecksum += *ParamPtr++;
        }
    }
#else

#if defined(PMIO_DEBUG) && (0)
    if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\n\r\nSLOT-%02x", ChanNum));
#endif

    UINT8 ucParamSize;

    while (*pData) {

#if defined(PMIO_DEBUG) && (0)
        if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nID: %02x DATA: ", *pData));
#endif
        ParamPtr = (UINT8 *)GetParamPtr(*pData);

		ucParamSize = GetParamSize(*pData);

        for (ucSize = ucParamSize; ucSize > 0; ucSize--)
        {
#if defined(PMIO_DEBUG) && (0)
            if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
            {
                if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)ParamPtr)
#if defined(IOPTYPE_AO16)
                      // default value of CHRC_Sn = 0x7FFFFFFF in pmio
                      && ((*pData < PARAMID_CHRC_S0) && (*pData > PARAMID_CHRC_S4))
#endif
                    )
                     while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("FF "));
                else while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("%02x ", *ParamPtr));
            }
#endif
            // for, PMIO redesign
            // NAN value in series C represented as 0x7FFFFFFF
            //      where as in pmio represented as 0xFFFFFFFF
            if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)ParamPtr)
#if defined(IOPTYPE_AO16)
                   // default value of CHRC_Sn = 0x7FFFFFFF in pmio
                   && ((*pData < PARAMID_CHRC_S0) && (*pData > PARAMID_CHRC_S4))
#endif
               )
                 ulChecksum ^= 0xFF;
            else ulChecksum ^= *ParamPtr;

            ParamPtr++;
        }

#if defined(PMIO_DEBUG) && (0)
        if ((ucDbgPnt == RDCM_DBGPNT) && (ChanNum == uiDbgPnt1))
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("CSM: 0x%08X", (UINT32)ulChecksum));
#endif
        pData++;
    }

#endif // defined(IOPTYPE_SCIOM)

    return ulChecksum;
}

/*******************************************************************************
*                          clsIomSlot::PmioDumpParam                           *
*                          ==============================                      *
* PURPOSE:   Redundant data dump routine for PM IOP primary.                   *
* ARGUMENTS: Destination pointer & source pointer.                             *
* RETURN:    NONE                                                              *
* NOTES:     Since the red data & its order is diff in Redesign PM IOPs.       *
*******************************************************************************/
VOID clsIomSlot::PmioDumpParam(UINT8 *pucDest)
{
    UINT8 *pParamId;// = (UINT8 *)GetPmioDumpParamPtr();
    UINT8 ucParamSize;
    UINT8 *pParam;

#if defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16)
    if(true == bHartDataDump) {
        pParamId = (UINT8 *)GetPmioHartDumpParamPtr();
    }
    else
#endif
    {
        pParamId = (UINT8 *)GetPmioDumpParamPtr();
    }

    while(*pParamId)
    {

#if defined(IOPTYPE_DI)
		// added to fix the following issue,
		// when the legacy iop inserted as a partner to the redesign iop (primary), after removing the primary (redesign), the new primary (legacy)
        // is not showing alarm as expected, Because the PVFL param is not retaining properly during data dump, due to its type AT_BXPACK.
        UINT8 u8Temp = 0;
        if(*pParamId == PARAMID_PV_PVFL)
        {
            ReadParamData(&u8Temp, *pParamId);
            pParam = &u8Temp;
        }
        else
#endif
        pParam = (UINT8 *)GetParamPtr(*pParamId);

		ucParamSize = GetParamSize(*pParamId);

#if defined(IOPTYPE_DO) && defined(DIGTYPE_DO32)
        // because, these parameters are having 3 byte size in PMIO DO32,
        if ((*pParamId == PARAMID_T_P_STRT) || (*pParamId == PARAMID_T_P_END)) pParam++;
#endif

        for (UINT8 ucSize = ucParamSize; ucSize > 0; ucSize--)
        {
            // for, PMIO redesign
            // NAN value in series C represented as 0x7FFFFFFF
            //      where as in pmio represented as 0xFFFFFFFF
            if ((ucParamSize == sizeof(FLOAT32)) && isnan(*(FLOAT32*)pParam)
#if defined(IOPTYPE_AO16)
            // default value of CHRC_Sn = 0x7FFFFFFF in pmio
            && ((*pParamId < PARAMID_CHRC_S0) && (*pParamId > PARAMID_CHRC_S4))
#endif
                )
                 *pucDest++ = 0xFF;
            else *pucDest++ = *pParam;

            pParam++;
        }

        pParamId++;
    }
}
