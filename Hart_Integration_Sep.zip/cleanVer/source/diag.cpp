/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2004                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : diag.cpp                                                    *
*    Description : Implements common diagnostics                               *
*******************************************************************************/
/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#ifdef IOMTYPE_AIH
#include "aihmain.h"
#endif

/*******************************************************************************
*                          FtaPresenceChecking                                 *
*                          ===================                                 *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID CheckFtaPresence(VOID)
{
    //static BOOL FtaCheckRepeat = FALSE;

    UINT8 l_u8IotaReg = Fpga.GetIotaRegister();
    
    BOOL FtaPresence = (l_u8IotaReg & FPGA_IOTA_REDUNT_n) ? FALSE : TRUE;

    // any change in FTA behaviour (present / missing)
    //if ((FtaMissing != BOX->GetFtaPres()) || (FtaCheckRepeat))
    {
        // Updating FTA Presence bit in MODSTAT2
        BOX->SetFtaPres(FtaPresence);

#if !defined(IOPTYPE_AO16)
        BOX->AddSoftfailEvent(EVENTTYPE_NORMAL, SF_FTAMISSG, (FtaPresence==FALSE), 0);
#endif
        // added to update IotaPos bit correctly
        //FtaCheckRepeat = (FtaCheckRepeat) ? FALSE : TRUE;

        //BOX->SetIotaPos((BOTTOM==DEASSERTED));
        BOX->SetIotaPos((l_u8IotaReg & FPGA_IOTA_BOTTOM) ? ASSERTED : DEASSERTED);
    }
#if defined(IOPTYPE_AO16)
    if (uiFtaReturnTimeout) --uiFtaReturnTimeout;
#endif

}
