/*
 * Copyright 2016-2026 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file    MIMXRT1024_Project.cpp
 * @brief   Application entry point.
 */
//#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */
#include "hal.h"
#include "aihmain.h"
/* TODO: insert other definitions and declarations here. */

NANINIT  NaNInit;  // For initializing NaN value.

extern VOID AppMain(VOID);


/*
 * @brief   Application entry point.
 */
int main(void) {

    /* Init board hardware. */
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();

    hal_timer_init_dwt();

    /* Initialize default GPIO directions/levels before GPIO adapter IRQ setup. */
    hal_gpio_init();
    hal_fpga_init();
    

    /* Init LPSPI4 as SPI master for ADC communication. Must be done before any
     * Adc.GetRawData() call, otherwise LPSPI4 stays clock-gated/disabled and
     * the TX FIFO never drains, hanging in the polling loops forever. */
    Adc.Init();

    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    /* ~10 second JTAG attach window — remove once board bring-up is stable */
    for (volatile UINT32 ulDelay = 0; ulDelay < 5000000UL; ulDelay++) { NOP; }

#ifdef DBG_PRINT
    PRINTF("\r\nPMIO HLAIH\r\n");
#endif

#if 0 // temp for testing.. HWREV write sequence into EEPROM
    if (EEPROM_PRESENT == (Eeprom.ReadStatusRegister() & EEPROM_STSMASK)) {

        Eeprom.EnableWrite();
        hal_delay_us(10000); // 10 ms delay for EEPROM write enable to take effect

        Eeprom.WriteByte(EE_HARDWARE_REVCODE, 'A');
        Eeprom.CheckWriteInProgress();

        hal_delay_us(10000); // 10 ms delay for EEPROM write to complete

        Eeprom.WriteByte(EE_HARDWARE_REVNUMBER, '0');
        Eeprom.CheckWriteInProgress();

        Eeprom.DisableWrite();
        hal_delay_us(10000); // 10 ms delay for EEPROM write to complete

        PRINTF("EEPROM DUMP 0x0000-0x00FF:\r\n");
        for (UINT16 uiAddress = 0; uiAddress < 256U; uiAddress += 16U) {
            PRINTF("%04X: ", uiAddress);
            for (UINT16 uiOffset = 0; uiOffset < 16U; uiOffset++) {
                PRINTF("%02X ", Eeprom.ReadByte(uiAddress + uiOffset));
            }
            PRINTF("\r\n");
        }

        PRINTF("\r\n%04X: ", 0x1F0);
        for (UINT16 uiOffset = 0x1F0; uiOffset < 0x200; uiOffset++) {
            PRINTF("%02X ", Eeprom.ReadByte(uiOffset));
        }
        PRINTF("\r\n");
    }
#endif

#if 1 /*** FPGA RESET SEQUENCE ***/
    hal_gpio_write(HAL_PIN_FPGA_GRESET, 0);
    //for (volatile UINT32 ulDelay = 0; ulDelay < 0xFFFFFF; ulDelay++) { NOP; }
    hal_delay_us(1000000); // 1 second delay for FPGA reset to complete
    hal_gpio_write(HAL_PIN_FPGA_GRESET, 1);
    //for (volatile UINT32 ulDelay = 0; ulDelay < 0xFFFFFF; ulDelay++) { NOP; }
    hal_delay_us(1000000); // 1 second delay for FPGA reset to complete

    PRINTF("FPGA RESET DONE\r\n");
#endif

    NaNInit.ulDword = SIGNL_NAN; // Initialize NaN value

    AppMain();

    /* Enter an infinite loop, just incrementing a counter. */
    while(1) {
    	;
    }

    return 0 ;
}
