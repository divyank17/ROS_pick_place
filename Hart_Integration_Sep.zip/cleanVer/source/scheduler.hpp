/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : scheduler.hpp                                               *
*    Description : Declarations and constants for scheduler.                   *
*                                                                              *
*    Converted from Renesas H8S/2329 -> NXP LPC1763 -> NXP iMXRT1024.          *
*    H8S TPU5 timer replaced by Cortex-M7 SysTick via HAL.                     *
*    WDT and interrupt masking abstracted through HAL layer.                   *
*******************************************************************************/
#ifndef __SCHEDULER_HPP__
#define __SCHEDULER_HPP__

/******************************************************************************
*                               INCLUDE FILES                                 *
******************************************************************************/
#include "global.h"
#include "commonelectronics.h"

/*******************************************************************************
*                                  CONSTANTS                                   *
*******************************************************************************/
const UINT16 SCHEDULER_PERIOD  = 10; // In units of msec

// Number of scheduler ticks to count 1 second.
const UINT8 SCHEDULER_TICKS_IN_SECOND = MILLISECONDS_IN_SECOND / SCHEDULER_PERIOD;

// Task IDs (in the order of priority)
const UINT8 TASKID_WRDBTASK  = 0x01;
const UINT8 TASKID_LPTASK    = 0x02;
const UINT8 TASKID_CALIBTASK = 0x03;
const UINT8 TASKID_EVRCTASK  = 0x04;
const UINT8 TASKID_HARTTASK  = 0x05;
const UINT8 TASKID_DIAGTASK  = 0x06;
const UINT8 TASKID_DEBUGTASK = 0x07;
const UINT8 TASKCOUNT        = TASKID_DEBUGTASK;
const UINT8 TASKID_INVALID   = 0xFF;

// Task Period for Periodic tasks in units of milliseconds
const UINT16 TASKPERIOD_LPTASK   = 100;
const UINT16 TASKPERIOD_HARTTASK = 250;
const UINT16 TASKPERIOD_DIAGTASK = 250;

// DMC period for all periodic tasks in units of milliseconds
// LPTASK: widened from 3x (300ms) to 10x (1000ms) its period. With the IOL
// address-mismatch cascade fixed (see iol.cpp Rcvr()/NotMyAddress), a
// genuinely saturated multi-drop bus can still legitimately keep the
// higher-priority IOL UART ISR busy enough to starve this housekeeping
// task for a few hundred ms at a time — that's expected scheduling
// behavior under sustained max bus load, not a hang, so the watchdog
// budget needs real headroom instead of hard-failing the module for it.
const UINT16 DMCPERIOD_LPTASK   = TASKPERIOD_LPTASK * 10;
const UINT16 DMCPERIOD_HARTTASK = TASKPERIOD_HARTTASK * 2;
const UINT16 DMCPERIOD_DIAGTASK = TASKPERIOD_DIAGTASK * 2;

// Maximum request count for posting request overflow softfail
const UINT8 MAX_TASKREQ_COUNT = 7;

// Time in seconds for which CPU statistic update is suspended
// after the "Reset Statistics" button is pressed by the user.
const UINT8 STAT_RESET_TIME = 5;

/*******************************************************************************
*                               TYPES & ENUMERATIONS                           *
*******************************************************************************/
typedef enum tagTaskReturnState {
    TASKRETURNSTATE_TERMINATE = 0,
    TASKRETURNSTATE_SUSPEND   = 1
} TASKRETURNSTATE;

typedef enum tagTaskContext {
    TASKCONTEXT_ZERO  = 0,
    TASKCONTEXT_ONE   = 1,
    TASKCONTEXT_TWO   = 2,
    TASKCONTEXT_THREE = 3,
    TASKCONTEXT_FOUR  = 4,
    TASKCONTEXT_FIVE  = 5,
    TASKCONTEXT_SIX   = 6,
    TASKCONTEXT_SEVEN = 7
} TASKCONTEXT;

// Executive error code definitions
typedef enum tagExecErrorCode
{
 EXEC_STC_OVERRUN        = 0x0008, // STC overrun
 EXEC_WDT_NOTREFRESHED   = 0x0004, // Diagnostic not run error
 EXEC_REREQ_OVERRUN      = 0x0002, // ReRequest overrun error
 EXEC_RRNW_OVERRUN       = 0x0001  // Resume request of non-waiting task
}EXECERRORCODE;

typedef enum tagTaskState {
    TASKSTATE_ASLEEP        = 0x00,
    TASKSTATE_RUNNING       = 0x01,
    TASKSTATE_READYTORUN    = 0x02,
    TASKSTATE_WAITING       = 0x04,
    TASKSTATE_READYTORESUME = 0x08
} TASKSTATE;

typedef enum tagWdtDiagState {
    WDTDIAG_RESET   = 0,
    WDTDIAG_RUNNING = 1
} WDTDIAG_STATE;

typedef struct tagTaskReturn
{
    TASKRETURNSTATE  TaskReturnState;
    TASKCONTEXT      TaskContext;
    UINT8            ucReserved;
    UINT8            ucSuspendTime;
    tagTaskReturn() {}
    tagTaskReturn(TASKRETURNSTATE trs,TASKCONTEXT tc,UINT8 st) :
        TaskReturnState(trs),TaskContext(tc),ucSuspendTime(st) {}
} TASKRETURN;

//Task definition table
typedef struct tagTaskDefinitionTable
{
    TASKRETURN (*TaskFunctionPtr)(TASKCONTEXT);
} TASKDEFINITIONTABLE;

//Periodic task table
typedef struct tagPeriodicTable
{
    UINT16 usDownCounter;//timeout period of the periodic task
    UINT16 usPeriod;//time out period for reloading the downcounter
} PERIODICTABLE;

//Task Delay/Suspend Table
typedef struct tagDelaySuspendTable {
    UINT16 usDownCounter;//suspend time of the task
    TASKCONTEXT TaskContext;//task context
} DELAYSUSPENDTABLE;

//Task status table
typedef struct tagTaskStatus {
    TASKSTATE TaskState;//State of the task
    UINT8 ucRequestCounter;//ReRequest counter for the task
}TASKSTATUS;


typedef struct tagDmcTable {
    UINT16  usLifespan;     // DMC lifespan in clock ticks
    UINT16  usCurrentLife;  // Current lifespan in clock ticks
} DMCTABLE;

/******************************************************************************
* ISR declaration — SysTick_Handler replaces the old STC_IRQHandler/TPU5      *
******************************************************************************/
#if !defined(UNIT_TEST_BUILD)
extern "C" void SysTick_Handler(void);
#endif

/*******************************************************************************
*                                 clsTaskScheduler                             *
*                                 ================                             *
*******************************************************************************/
class clsTaskScheduler {

private:

	UINT32 m_ul10msCounter;        // 10 msec clock counter
	UINT32 m_ulLast10msCounter;
	UINT8   m_ucWdtRefreshCounter;
    UINT16  m_uiWdtDiagCounter;
    WDTDIAG_STATE m_WdtDiagState;
    BOOL    m_bWdtEnabled;
    UINT8  m_ucActiveTask;         // Active task number
	UINT16 m_usTaskActivationBits;
	UINT8  m_ucDelayedTaskCount;
	BOOL   m_bOneSecondTimerFlag;
    UINT32  m_ulCpuFreeTimeCounter;
    UINT8   m_ucStatResetCounter;
    UINT8   m_ucStcOverrunCount;
    // Customer (MiRO) Issue(CL Fail) Fix - To count no of write requests tobe processed in the buffer
    UINT16  m_usWriteReqCount;

	// Task tables — RT1024 uses RegisterTask() at runtime instead of
	// the old static m_TaskDefinitionTable[] initialized in aihmain.cpp.
	TASKDEFINITIONTABLE m_TaskDefinitionTable[TASKCOUNT];
	PERIODICTABLE     m_PeriodicTable[TASKCOUNT];
	DELAYSUSPENDTABLE m_DelaySuspendTable[TASKCOUNT];
	TASKSTATUS        m_TaskStatus[TASKCOUNT];
	DMCTABLE          m_DmcTable[TASKCOUNT];

    clsTaskScheduler(const clsTaskScheduler&); // Safeguard against def copy constr.
    clsTaskScheduler& operator=(const clsTaskScheduler&); // and default assignment.

public:

    clsTaskScheduler(VOID);
    ~clsTaskScheduler(VOID);

    // Task registration — replaces the old static m_TaskDefinitionTable
    // that was defined in aihmain.cpp. Now tasks register at runtime.
    VOID RegisterTask(UINT8 a_ucTaskId, TASKRETURN (*a_pfTask)(TASKCONTEXT));

    friend void SysTick_Handler(void);

    VOID STCInterruptHandler(VOID);

    inline UINT32 Get10msecCounter(VOID) { return m_ul10msCounter; }
    /*
    inline VOID SetStcOverrunCounter(UINT8 a_ucCount) { m_ucStcOverrunCount=a_ucCount; }
    inline VOID EnableWatchdog(VOID) {
        if (FALSE == m_bWdtEnabled) {
            WDT_EN_n = 0;
            m_bWdtEnabled = TRUE;
            m_ucWdtRefreshCounter = 0;
            m_uiWdtDiagCounter = 0;
        }
    }
    inline UINT8 GetWdtRefreshCounter(VOID) { return m_ucWdtRefreshCounter; }
    */
    inline VOID StatReset(VOID) { m_ucStatResetCounter = STAT_RESET_TIME; }
    //inline WDTDIAG_STATE GetWdtDiagState(VOID) { return m_WdtDiagState;}


    VOID StartTimer(VOID);
    VOID RunTask(UINT8);
    VOID InitPeriodicTask(UINT8,UINT16,UINT16);

    VOID RefreshTaskDmc(UINT8 a_ucTaskId);
    VOID ExecuteTaskScheduler(VOID); //Main scheduler executive function
    VOID StopImpendingWatchdog(VOID);


#if 0 //#ifdef DEBUG
    UINT16 uiMaxStcLatency;
#endif
};

extern clsTaskScheduler TaskScheduler;

#endif /* __SCHEDULER_HPP__ */
