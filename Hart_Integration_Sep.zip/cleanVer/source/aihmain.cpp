/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : aihmain.cpp                                                 *
*    Description : Analog HART input module application startup code for       *
*                  NXP iMXRT1024.  Creates the box and slot database objects,  *
*                  registers task functions, and initialises periodic tasks.   *
*                                                                              *
*    Converted from Renesas H8S/2329 -> NXP LPC1768 -> NXP iMXRT1024.          *
*    Global objects that were in section-attributed memory on the LPC1768      *
*    are now plain C++ globals (linker handles placement).                     *
*    Static m_TaskDefinitionTable[] replaced by runtime RegisterTask() calls.  *
*******************************************************************************/

/*******************************************************************************
*                                 INCLUDE FILES                                *
*******************************************************************************/
#include "aihmain.h"
#include <new>  /* placement new */
#include "hal_gpt.h"

// temp for testing
extern volatile BOOL bOneSecTick;
extern volatile UINT32 u1_LastExecState;

/*******************************************************************************
*                                    GLOBALS                                   *
*  These are the global object instances declared extern in aihmain.h.         *
*  On the LPC1768 original these had linker section attributes — on RT1024     *
*  the linker script handles all placement automatically.                      *
*******************************************************************************/

/* Static memory pool for IOM database objects — no heap on bare metal.
 * Sized in UINT32 units for alignment.  Matches the original ucIomDbMemory
 * pattern from the H8S/LPC codebase. */
#define AIHBOXSLOT_WORDS  ((sizeof(clsAihBoxSlot) + 3) / 4)
#define AIHSLOT_WORDS     ((sizeof(clsAihSlot) + 3) / 4)
static UINT32 ucIomDbMemory[AIHBOXSLOT_WORDS + (MAXSLOTS * AIHSLOT_WORDS)];

/* Box-level database pointer — set during AppMain() */
//clsBoxSlot *BOX = NULL;

/* pDatabase[] — slot database pointers (box=0, slots=1..MAXSLOTS) */
clsIomSlot *pDatabase[MAXSLOTS + 1] = { NULL };

extern TASKRETURN WriteDatabaseTask(TASKCONTEXT);
extern TASKRETURN EventRecoveryTask(TASKCONTEXT);
extern TASKRETURN HartTask(TASKCONTEXT);
//extern TASKRETURN DiagnosticTask(TASKCONTEXT);
//extern TASKRETURN LowPriorityTask(TASKCONTEXT);

// Task Function declarations
TASKRETURN LowPriorityTask(TASKCONTEXT);
TASKRETURN CalibrationTask(TASKCONTEXT);

/*******************************************************************************
*                                   AppMain                                    *
*                                   =======                                    *
* PURPOSE:                                                                     *
*    Application specific startup code for the AIH module.                     *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    This function is called from main() (epicio_kernel.cpp) after hardware    *
*    initialisation is complete.  It creates the box and slot database          *
*    objects, registers task functions with the scheduler, and initialises     *
*    periodic tasks.  Execution returns to main() which then transfers         *
*    control to TaskScheduler.ExecuteTaskScheduler().                          *
*                                                                              *
*    RT1024 CHANGES:                                                           *
*    - Task functions are registered with RegisterTask() at runtime instead    *
*      of the old static m_TaskDefinitionTable[] initialised in this file.     *
*    - clsAihSlot replaced by clsAixSlot (unified AI analog slot).            *
*    - Section attributes removed — linker handles placement.                  *
*    - isHartCapable() / CheckAndInitHart() / ResetHart() not yet ported —    *
*      module is assumed HART-capable (MODLTYPE_AIH) for now.                 *
*******************************************************************************/
VOID AppMain(VOID)
{
	BOOL bHart = FALSE;

	if (isHartCapable())
	{
		/* ---------------------------------------------------------------
		 * Construct box database object via placement new into the static
		 * memory pool (no heap).  Matches original ucIomDbMemory pattern.
		 * --------------------------------------------------------------- */
		pDatabase[0] = new (ucIomDbMemory) clsAihBoxSlot(MODLTYPE_AIH);
		//BOX = static_cast<clsBoxSlot *>(pDatabase[0]);

		//TraceLog.AddToTrace(TRACEID_GENERIC, bcAihIom, BOX->GetDPA());
		bHart = TRUE;
	}
	else {
		/* ---------------------------------------------------------------
		 * Construct box database object via placement new into the static
		 * memory pool (no heap).  Matches original ucIomDbMemory pattern.
		 * --------------------------------------------------------------- */
		pDatabase[0] = new (ucIomDbMemory) clsAihBoxSlot(MODLTYPE_AI);
		//BOX = static_cast<clsBoxSlot *>(pDatabase[0]);

		//TraceLog.AddToTrace(TRACEID_GENERIC, bcAiIom, BOX->GetDPA());

	}

	/* ---------------------------------------------------------------
	 * Construct per-channel slot database objects (1..MAXSLOTS)
	 * via placement new into successive regions of the memory pool.
	 * --------------------------------------------------------------- */
	for (UINT8 ucSltNm = 0; ucSltNm < MAXSLOTS; ucSltNm++) {

		UINT32 *pSlotMem = ucIomDbMemory + AIHBOXSLOT_WORDS + (ucSltNm * AIHSLOT_WORDS);

		pDatabase[ucSltNm + 1] = new (pSlotMem) clsAihSlot(ucSltNm + 1);
	}
	//TraceLog.AddToTrace(TRACEID_GENERIC, bcIomDbDone);

	BOX->SetFactoryTestMode();

	if (TRUE == bHart) {
		CheckAndInitHart();
	}
	else {
		ResetHart();
	}

#ifdef DBG_PRINT
    // DPA, DSA values can be accessed after db created
	PRINTF("FPGA REVNUM: %2X.%2X\r\n", Fpga.GetRevLetter(), Fpga.GetRevNumber());

    UINT8 dpa = BOX->GetDPA();
    
	UINT8 fileno = ((dpa >> 4) & 0x07) + 1;
    UINT8 slotno = (dpa & 0x0F) + 1;

    PRINTF("FILE NUMBER: %02X\r\n", fileno);
    PRINTF("SLOT NUMBER: %02X\r\n", slotno);

	PRINTF("DPA ADDRESS: %02X\r\n", dpa);
    PRINTF("DSA ADDRESS: %02X\r\n", BOX->GetDSA());
    PRINTF("BKA ADDRESS: %02X\r\n", BOX->GetBA());

	PRINTF("IOTA REGBIT: %02X\r\n", Fpga.GetIotaRegister());
	PRINTF("MISC REGBIT: %02X\r\n", Fpga.GetMiscRegister());

	PRINTF("FACTORY BIT: %02X\r\n", BOX->GetFactoryTestMode());

	PRINTF("HWR  LETTER: %02X\r\n", BOX->GetHwRevLetter());
	PRINTF("HWR  NUMBER: %02X\r\n", BOX->GetHwRevNumber());
#endif

    /* ---------------------------------------------------------------
     * Register task functions with the scheduler.
     * The original used a static const m_TaskDefinitionTable —
     * on RT1024 we use runtime RegisterTask() for flexibility.
     * --------------------------------------------------------------- */
	TaskScheduler.RegisterTask(TASKID_WRDBTASK, WriteDatabaseTask);
	TaskScheduler.RegisterTask(TASKID_LPTASK,   LowPriorityTask);
	TaskScheduler.RegisterTask(TASKID_EVRCTASK, EventRecoveryTask);
	TaskScheduler.RegisterTask(TASKID_CALIBTASK, CalibrationTask);
	if (TRUE == bHart) {
		TaskScheduler.RegisterTask(TASKID_HARTTASK, HartTask);
	}

    /* ---------------------------------------------------------------
     * Initialise periodic tasks with their periods and DMC timeouts.
     * --------------------------------------------------------------- */
    TaskScheduler.InitPeriodicTask(TASKID_LPTASK, TASKPERIOD_LPTASK, DMCPERIOD_LPTASK);
	if (TRUE == bHart) {
		TaskScheduler.InitPeriodicTask(TASKID_HARTTASK, TASKPERIOD_HARTTASK, DMCPERIOD_HARTTASK);
	}

    // Pass execution to TaskScheduler // should be called after launching application in root.cpp
    TaskScheduler.ExecuteTaskScheduler();

    while(1) {

    	;
    }
}

/******************************************************************************
*                          LowPriorityTask                                    *
*                          ================                                   *
* PURPOSE  :                                                                  *
* ARGUMENTS: None.                                                            *
* RETURN   : None.                                                            *
* NOTES    : Runs Task every 1 seconds,can view LowPriorityTask over Debug    *
*            terminal to identify the task                                    *
*******************************************************************************/
TASKRETURN LowPriorityTask(TASKCONTEXT a_TaskContext)
{
    TASKRETURN TaskReturnValue;
    TaskScheduler.RefreshTaskDmc(TASKID_LPTASK);

#if 1 // only for debug
	if (TRUE == bOneSecTick) {

	//UINT8 ucPpxChannel = BOX->GetPpxChannel();
	//UINT8 ucRawChannel = (ucPpxChannel == 1) ? MAXSLOTS : (ucPpxChannel - 1);
	//PRINTF("\r\n[PV-STATE] rawChannel=%u uiRawData=%u uiZeroRef=%u\r\n",
	//       (unsigned)ucRawChannel,
	//       (unsigned)SLOT(ucRawChannel)->GetRawAdcCount());

#if 0    
		/* IOL TX hold diagnostics: snapshots once per second from low-priority context. */
		static UINT32 s_prevStat = 0U;
		static UINT32 s_prevCtrl = 0U;
		static UINT8  s_prevDe = IOLDRV_OFF;
		static UINT8  s_deActiveSec = 0U;
		static UINT8  s_noChangeSec = 0U;
		static UINT8  s_rdrfHighSec = 0U;
		static UINT8  s_summaryDiv = 0U;

		const UINT32 stat = IOLINK_UART_BASEADDR->STAT;
		const UINT32 ctrl = IOLINK_UART_BASEADDR->CTRL;
		const UINT8 de = GetTXREQ_n(); /* Active low: 0 means TX driver enabled. */
		const UINT8 tie = (ctrl & LPUART_CTRL_TIE_MASK) ? 1U : 0U;
		const UINT8 tcie = (ctrl & LPUART_CTRL_TCIE_MASK) ? 1U : 0U;
		const UINT8 rie = (ctrl & LPUART_CTRL_RIE_MASK) ? 1U : 0U;
		const UINT8 te = (ctrl & LPUART_CTRL_TE_MASK) ? 1U : 0U;
		const UINT8 re = (ctrl & LPUART_CTRL_RE_MASK) ? 1U : 0U;
		const UINT8 tdre = (stat & LPUART_STAT_TDRE_MASK) ? 1U : 0U;
		const UINT8 tc = (stat & LPUART_STAT_TC_MASK) ? 1U : 0U;
		const UINT8 rdrf = (stat & LPUART_STAT_RDRF_MASK) ? 1U : 0U;
		const UINT8 orErr = (stat & LPUART_STAT_OR_MASK) ? 1U : 0U;
		const UINT8 feErr = (stat & LPUART_STAT_FE_MASK) ? 1U : 0U;
		const UINT8 nfErr = (stat & LPUART_STAT_NF_MASK) ? 1U : 0U;
		const UINT8 peErr = (stat & LPUART_STAT_PF_MASK) ? 1U : 0U;
		const UINT8 uartIrqEnabled = NVIC_GetEnableIRQ((IRQn_Type)IOLINK_UART_IRQn) ? 1U : 0U;
		const UINT8 uartIrqPending = NVIC_GetPendingIRQ((IRQn_Type)IOLINK_UART_IRQn) ? 1U : 0U;
		const UINT32 rxIsrCnt = g_IolDiag.rxIsrCount;
		const UINT32 txIsrCnt = g_IolDiag.txIsrCount;
		const UINT32 txDoneCnt = g_IolDiag.txDoneIsrCount;
		const UINT32 rxEnCnt = g_IolDiag.rxIrqEnableCount;
		const UINT32 rxDisCnt = g_IolDiag.rxIrqDisableCount;
		const UINT32 txDisCnt = g_IolDiag.txIrqDisableCount;
		const UINT32 tdEnCnt = g_IolDiag.txDoneEnableCount;
		const UINT32 tdDisCnt = g_IolDiag.txDoneDisableCount;
		const UINT32 rspStartCnt = g_IolDiag.startResponseCount;
		const UINT32 rspDropCnt = g_IolDiag.startResponseBusyDropCount;
		const UINT32 errPathCnt = g_IolDiag.errorPathCount;
		const UINT32 noRspCnt = g_IolDiag.noResponseCount;
		const UINT32 rdrfErrCnt = g_IolDiag.rdrfAfterErrorCount;
		const UINT32 lastCmd = g_IolDiag.lastCommandSeen;
		const UINT32 lastRcvrPath = g_IolDiag.lastRcvrExitPath;

		const UINT8 stateChanged = ((stat != s_prevStat) || (ctrl != s_prevCtrl) || (de != s_prevDe)) ? 1U : 0U;

		if (de == IOLDRV_ON) {
			if (s_deActiveSec < 0xFFU) {
				s_deActiveSec++;
			}
			if (!stateChanged) {
				if (s_noChangeSec < 0xFFU) {
					s_noChangeSec++;
				}
			} else {
				s_noChangeSec = 0U;
			}
		} else {
			s_deActiveSec = 0U;
			s_noChangeSec = 0U;
		}

		/* RX-stuck signature:
		 * RDRF remains asserted for seconds but RX IRQ is not being serviced. */
		if (rdrf != 0U) {
			if (s_rdrfHighSec < 0xFFU) {
				s_rdrfHighSec++;
			}
		} else {
			s_rdrfHighSec = 0U;
		}

		if ((s_rdrfHighSec >= 3U) && ((rie == 0U) || (uartIrqPending == 0U))) {
			PRINTF("\r\n[IOLRX-STUCK] rdrfSec=%u RIE=%u IRQen=%u IRQpend=%u TE=%u RE=%u TIE=%u TCIE=%u RXI=%lu TXI=%lu TDI=%lu RXen=%lu RXdis=%lu CMD=%lX PATH=%lu STAT=%08X CTRL=%08X",
					(unsigned)s_rdrfHighSec,
					(unsigned)rie,
					(unsigned)uartIrqEnabled,
					(unsigned)uartIrqPending,
					(unsigned)te,
					(unsigned)re,
					(unsigned)tie,
					(unsigned)tcie,
					(unsigned long)rxIsrCnt,
					(unsigned long)txIsrCnt,
					(unsigned long)txDoneCnt,
					(unsigned long)rxEnCnt,
					(unsigned long)rxDisCnt,
					(unsigned long)lastCmd,
					(unsigned long)lastRcvrPath,
					(unsigned)stat,
					(unsigned)ctrl);
		}

		/* Suspected hold signature:
			* DE remains active for multiple seconds and UART state is not changing. */
		if ((de == IOLDRV_ON) && (s_deActiveSec >= 2U) && (s_noChangeSec >= 2U)) {
			PRINTF("\r\n[IOLTX-HOLD] deSec=%u noChg=%u TIE=%u TCIE=%u RIE=%u TE=%u RE=%u TDRE=%u TC=%u RDRF=%u IRQen=%u IRQpend=%u ERR(o/f/n/p)=%u/%u/%u/%u STAT=%08X CTRL=%08X",
					(unsigned)s_deActiveSec,
					(unsigned)s_noChangeSec,
					(unsigned)tie,
					(unsigned)tcie,
					(unsigned)rie,
					(unsigned)te,
					(unsigned)re,
					(unsigned)tdre,
					(unsigned)tc,
					(unsigned)rdrf,
					(unsigned)uartIrqEnabled,
					(unsigned)uartIrqPending,
					(unsigned)orErr,
					(unsigned)feErr,
					(unsigned)nfErr,
					(unsigned)peErr,
					(unsigned)stat,
					(unsigned)ctrl);

			/* Additional root-cause hint when TX complete is latched but ISR does not run. */
			if ((tc != 0U) && (tcie != 0U) && (uartIrqEnabled != 0U)) {
				PRINTF("\r\n[IOLTX-HOLD] hint: TC=1 and TCIE=1 while DE is still ON. Check TX_DONE ISR delivery/path.");
			}
		}

		/* 10-second heartbeat for trend capture with low print overhead. */
		if (++s_summaryDiv >= 10U) {
			s_summaryDiv = 0U;
			PRINTF("\r\n[IOLTX-SUM] de=%u deSec=%u TIE=%u TCIE=%u RIE=%u TE=%u RE=%u TDRE=%u TC=%u RDRF=%u IRQen=%u IRQpend=%u RXI=%lu TXI=%lu TDI=%lu RXen=%lu RXdis=%lu TXdis=%lu TDen=%lu TDdis=%lu RSP=%lu DROP=%lu ERRS=%lu NORESP=%lu RDRFERR=%lu CMD=%lX PATH=%lu",
					(unsigned)de,
					(unsigned)s_deActiveSec,
					(unsigned)tie,
					(unsigned)tcie,
					(unsigned)rie,
					(unsigned)te,
					(unsigned)re,
					(unsigned)tdre,
					(unsigned)tc,
					(unsigned)rdrf,
					(unsigned)uartIrqEnabled,
					(unsigned)uartIrqPending,
					(unsigned long)rxIsrCnt,
					(unsigned long)txIsrCnt,
					(unsigned long)txDoneCnt,
					(unsigned long)rxEnCnt,
					(unsigned long)rxDisCnt,
					(unsigned long)txDisCnt,
					(unsigned long)tdEnCnt,
					(unsigned long)tdDisCnt,
					(unsigned long)rspStartCnt,
					(unsigned long)rspDropCnt,
					(unsigned long)errPathCnt,
					(unsigned long)noRspCnt,
					(unsigned long)rdrfErrCnt,
					(unsigned long)lastCmd,
					(unsigned long)lastRcvrPath);
		}

		s_prevStat = stat;
		s_prevCtrl = ctrl;
		s_prevDe = de;
#endif
		
    	bOneSecTick = FALSE;
    }
#endif

#if 0 //!LOWCOST
    if(TRUE == HartLoopBkTestInProgress){

        HartLoopBkTestInProgress = (RETURNSTATUS_INPROGRESS == BOX->HartLoopBackTest());
    }
#endif

    // Call BoxHousekeeping which re-reports any missed events
    // and synchronizes box and slot databases.
    BOX->BoxHouseKeeping();

#if 0 //(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
    // Process BRDP Handle and Message Timeout every second.
    if (BOX->BRDPOneSecCounter >= 10) {

        BOX->BRDPOneSecCounter = 0;
        BOX->ProcessBrdpTimeout();
    }
    else {

    	BOX->BRDPOneSecCounter++;
    }
#endif

    // Terminate the task as this is a periodic task.
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;
    return TaskReturnValue;
}

/*******************************************************************************
*                                CalibrationTask                               *
*                                ===============                               *
* PURPOSE:                                                                     *
* ARGUMENTS: None.                                                             *
* RETURN: None.                                                                *
* NOTES:                                                                       *
*******************************************************************************/
TASKRETURN CalibrationTask(TASKCONTEXT a_TaskContext)
{
#if 0 //#ifdef DEBUG
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tStarting calibration...\n\r"));
#else
    PRINTF("\n\r\tStarting calibration...\n\r");
#endif

    //TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibStart,FACTCAL);

//#if 0 // HART
    // Disable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {

        SLOT(ucChan)->GetHartDevDb().InitDevDb(TRUE);
    }

    IdleWait(MICROSECONDS_IN_MILLISECOND);
//    TPU2_CST = 0; // Stop HART modem heartbeat timer.
//#endif

    if (FALSE == BOX->PerformModuleCalibration()) {

        // Calibration was aborted for failed.
        //TraceLog.AddToTrace(TRACEID_GENERIC,bcCalibAbort,MODULEINFO_WRITECOUNT);

#if 0 //#ifdef DEBUG
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n\r\tCalibration aborted"));
#else
        PRINTF("\n\r\tCalibration aborted");
#endif
    }

    // Reneable HART communications
    for (UINT8 ucChan = 1; ucChan <= MAXSLOTS; ucChan++) {

        SLOT(ucChan)->GetHartDevDb().m_sScanCounter = TICKS_IN_16_SEC;
    }

    TASKRETURN      TaskReturnValue;
    TaskReturnValue.TaskReturnState = TASKRETURNSTATE_TERMINATE;
    TaskReturnValue.TaskContext     = a_TaskContext;
    TaskReturnValue.ucSuspendTime   = 0;

    return TaskReturnValue;
}
