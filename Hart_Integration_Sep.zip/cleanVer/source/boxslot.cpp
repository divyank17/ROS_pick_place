/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : boxslot.cpp                                                 *
*    Description : clsBoxSlot implementation for RT1024/QEMU — AIH-only.       *
*                  Full implementation: soft-fail management, status           *
*                  transitions, ECL events, BRDP handle management,           *
*                  parameter read/write, checksum, CPU free tracking.          *
*******************************************************************************/
#include "aihmain.h"

/*******************************************************************************
*                                  GLOBAL DATA                                 *
*******************************************************************************/

#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH))
extern clsHartPst *pHartPst[];
#elif defined(IOMTYPE_UIO)
extern clsHartPst *pUioHartPst[][HPST_OBJECTCOUNT];
#endif

/* pDatabase: slot 0 = BOX, slots 1..MAXSLOTS = channel objects */
extern clsIomSlot *pDatabase[];

BOOL FactryModeWDTUTest;
BOOL FactryModeJabberTest;
#if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH) || defined(IOMTYPE_UIO))
BOOL HartLoopBkTestInProgress;
#endif
#if 0//def DEBUG
extern BOOL g_bTppInProgress;
#endif
BOOL HWRevCodeWriteInProgress;
/*******************************************************************************
*                                  STATIC DATA                                 *
*******************************************************************************/

//#pragma section REBOOT_SECTION
BOOL clsBoxSlot::IomRebooted;
HARDFAILTYPE clsBoxSlot::FailCode;
//Time stamp for traces added to IOM tracelog.
UINT32 clsBoxSlot::TracelogTimeCntr;
INT32 clsBoxSlot::TstFunctTime;
//#pragma section

const UINT8 clsBoxSlot::Bits[] = {0,1,2,4,8,16,32,64,128};

const UINT8 VersionInfo[] = {
    VERSION_NUMBER,
    REVISION_NUMBER,
    BUILD_NUMBER
};

const UINT8 clsBoxSlot::ModStatType[] = {
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT1,
    PARAMID_MODSTAT2,
    0 // Terminator
};
const UINT8 clsBoxSlot::Sup300[] = {
    PARAMID_DSA,
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT2,
    PARAMID_NTH,
    PARAMID_COMMSTAT,
    PARAMID_COMMERR,
    PARAMID_CHNERRA,
    PARAMID_CHNERRB,
    PARAMID_CHNSILA,
    PARAMID_CHNSILB,
    PARAMID_BA,
    PARAMID_REDDATA,
    PARAMID_DBVALID,
    0 // Terminator
};

const UINT8 clsBoxSlot::SfInfo300[] = {

    // added to fix in DO, PAR#1 - 91X5DJ1
    // in DI, observed similar issue in experion setup
    //PARAMID_DO_BOXSFAIL,

    PARAMID_BOXSFBITS,
    PARAMID_SLOTSFBITS,
    PARAMID_MAPSLOTINFAIL,
    0 // Terminator
};

const UINT8 clsBoxSlot::IomDtl[] = {
    PARAMID_MODLTYPE,
    PARAMID_LASTFAIL,
    PARAMID_HWREVCODE,
    PARAMID_SWREVCODE,
    PARAMID_MODSTAT1,
    PARAMID_MODSTAT2,
    PARAMID_BOXSFBITS,
    PARAMID_SLOTSFBITS,
    PARAMID_MAPSLOTINFAIL,
    0 // Terminator
};
const UINT8 clsBoxSlot::IolSup[] = {
    PARAMID_DSA,
    PARAMID_MODLTYPE,
    PARAMID_MODSTAT2,
    PARAMID_NTH,
    PARAMID_COMMSTAT,
    PARAMID_COMMERR,
    PARAMID_CHNERRA,
    PARAMID_CHNERRB,
    PARAMID_CHNSILA,
    PARAMID_CHNSILB,
    0 // Terminator
};

#if 1 //defined(IOPTYPE_HLAI)
UINT8 ucXRamTimeout = 0;
#define XRAM_TIMEOUT 16
#endif

/*******************************************************************************
*                       clsBoxSlot::clsBoxSlot                                 *
*                       ======================                                 *
* PURPOSE:                                                                     *
*    Constructor — initialise module identity, status, softfail bitmaps, ECL,  *
*    BRDP table and LED housekeeping state.                                    *
* ARGUMENTS:                                                                   *
*    a_ModlType : MODLTYPE identifying this module (AIH, AOH, etc.).           *
*    a_MaxSlots : number of channel slots this module supports.                *
* RETURN:                                                                      *
*    None (constructor).                                                       *
* NOTES:                                                                       *
*    RT1024 CHANGES: MODNUM read via hal_fpga_get_modnum() SPI abstraction.    *
*******************************************************************************/
clsBoxSlot::clsBoxSlot(MODLTYPE a_ModlType, UINT8 a_MaxSlots) : clsIomSlot(0) {

    pNrmEcl = new clsEcl(ECLTYPE_NORMAL);
#ifdef IOMTYPE_DISOE
    pPvChngEcl = new clsEcl(ECLTYPE_PVCHANGE);
#endif

    /* Module identity */
    ModlType = a_ModlType;

    HwInfo.VendorID     = HWINFO_VENDOR_ID;
    HwInfo.SerialNumber = DEFAULT_SERIAL_NUMBER;
    HwInfo.HwRevLetter  = Eeprom.ReadByte(EE_HARDWARE_REVCODE) & HWINFO_REVLETTER_MASK;
    HwInfo.HwRevNumber  = Eeprom.ReadByte(EE_HARDWARE_REVNUMBER);

    AppSwRevCode.ucVersion = VersionInfo[0];
    AppSwRevCode.ucRevision = VersionInfo[1];
    BootSwRevCode.ucVersion = 1; //temp for testing
    BootSwRevCode.ucRevision = 0;

    // temp for testing
    AppBuild = 0; // App build number
    BootBuild = 0; // boot build number
    HwInfo.Pld1RevLetter = Fpga.GetRevLetter(); // CPLD_REVLETTER & HWINFO_REVLETTER_MASK;
    HwInfo.Pld1RevNumber = Fpga.GetRevNumber(); // CPLD_REVNUMBER & CPLD_REVNUMBER_MASK;
    HwInfo.Pld2RevLetter = 0;
    HwInfo.Pld2RevNumber = 0;

    /*
     * Read module number from FPGA MODNUM register via SPI (HDD Table 29).
     * MODNUM[7:0] comes from backplane DIP switches into FPGA, exposed at
     * SPI register 0x64. Bits [5:0] = BCD device address, bit 7 = IOL ID.
     */
    UINT8 modnum_raw = Fpga.GetModnumRegister();
    ModlNum = modnum_raw & MODNUMBITS;
    IolId   = modnum_raw & IOLIDBIT;

    /*
     * DPA formation with File & Slot configuration
     * ModlNum Bit 0:3 - Slot number
     * ModlNum Bit 4:6 - File number
     * ModlNUm Bit 7   - Parity bit
     * always odd no of one's should be in the file code (inclusive parity-Bit7)
     */
    if (isOddParity((ModlNum + IolId) >> 4)) {
        Dpa = (0x80 | ModlNum);
    }
    else {
        HardFail(HF_PARITYERROR, BOXSLOT_CPP, __LINE__);
    }

    // added to fix PAR #1-72NBQP7 (HLAI), #1-7KEY6J5 (AO16) - (IOL COMM Errors issues)
    IolId = IOLIDBIT;

    Dsa                 = 0;
    Ba                  = 0xFF;
  //Nth                 = 0;
    IolDevType          = IOLDEVTYPE_SLAVE;
    MaxSlots            = a_MaxSlots;
    ModStat1.BuSyncd    = 0;
    ModStat1.Factory    = 0;
    ModStat1.Status     = MODSTATUS_ALIVE;
    ModStat1Lrs         = 0;
    ModStat2.DbNotDeflt = FALSE;
    ModStat2.BuReqIn    = BUPREQ_IN;
    ModStat2.StndbyMan  = FALSE;
    ModStat2.FtaPres    = TRUE;
    ModStat2.HF         = FALSE;
    ModStat2.SF         = FALSE;
    ModStat2.CommErr    = FALSE;
    ModStat2.IotaPos    = ~BOTTOM;
  //ModStat2.BYTE = 0x45;
    DbValid  = DB_INVALID;
  //ModStat3.BYTE = 0;
    MesNo    = 255;
    CommErr  = PA_OK;
    CommStat.LEA = CommStat.LEB = CommStat.LSA = CommStat.LSB = FALSE;
    CommStat.PRC = RCVSEL_CHANNELA;
    SetRCVSELA_n(RCVSEL_CHANNELA);
    ChnErrA  = 0;
    ChnErrB  = 0;
    ChnSilA  = 0;
    ChnSilB  = 0;

    //Cpu stats Variable
    CpuFreeMin = 100.0f; //In the beginning the module is approx 100 % free.
    CpuFreeAvg = 0.0f;
    StatReset  = OFF;

    // This variable is used when the TPU5 Count is dumped from Primary
    // to get both the modules running as close as possible.
    bStcSyncRestart = FALSE;
    bWdtIntProcessed = FALSE;

    // temp for testing // tobe decided
    LastFail = HF_UNKNOWN;
    FailCode = HF_UNKNOWN;

    for (UINT8 ucCount = 0; ucCount < SFBYTES_SIZE; ucCount++) {
        BoxSfBits[ucCount]   = 0;
        SlotSfBits[ucCount]  = 0;
        BoxSfLrs[ucCount]    = 0;
        SfActionTbl[ucCount] = 0;
        if (ucCount < SLOTINFAIL_SIZE) {
            MapSlotInFail[ucCount] = 0;
        }
    }

    for (UINT8 ucCount = 0; ucCount <= MAXSLOTS; ucCount++) {
        CheckSum[ucCount] = 0;
    }

    BoxSfCounter  = 0;
    SlotSfCounter = 0;

    WithBias = TRUE;
    RedData[0] = REDDATA_SFFOEN | REDDATA_BURQST;
    RedData[1] = 0;
    SyncVer[0] = 0;
    SyncVer[1] = 0;
    SyncVer[2] = 0;
    SyncVer[3] = 0;
    SetBupreqOut(0);

    // modified for FCT testing
    //if (FALSE == IomRebooted){TstFunctTime = 0;}

    FactryModeJabberTest = FALSE;
    FactryModeWDTUTest = FALSE;

    HartLoopBkTestInProgress = FALSE;

    HWRevCodeWriteInProgress = FALSE;

#if 0 //defined(IOPTYPE_HLAI) || defined(IOPTYPE_AO16) // to be decided
    /* Change for redesign HLAI HART IOP FCT:
       As per legacy, HART Loop back status should be init with 0 */
    if(isHartCapable())
        LpBkStat = 0x00;
    else
#endif
    	LpBkStat = LOOPBACK_RUNNING;

    LedBlinkCounter = 0;

    for (UINT8 ucCount = 0; ucCount < BOXSLOT_SPARESIZE; ucCount++) {
        BoxSlotSpare[ucCount] = 0;
    }

    /*
     * configure a timer & start for LED blink ISR
     */
    /* Configure LED blink timer interrupt.
       Period: 500ms (500,000 microseconds) — typical for status LED blinking.
       Callback: BlinkLEDInterruptHandler will be invoked periodically. */
	   // It is handling STCInterruptHandler()
    //hal_timer_configure(HAL_TIMER_LED_BLINK, 500000, (hal_timer_callback_t)BlinkLEDInterruptHandler);
    //hal_timer_start(HAL_TIMER_LED_BLINK);

    // Initialize CPLD interrupt settings on IRQ1. For PI the interrupt will come from FPGA // to be decided
    //IPRI_PDVC     = LVLPRI_PDVC;       // Set CPLD interrupt priority level
    //IRQ1_SENSECTL = IRQ_SC_RISING;     // Trigger IRQ1 on rising edge.

    /*
     * configure a timer & start for Idle wait
     */

}

/*******************************************************************************
*                     clsBoxSlot::BlinkLEDInterruptHandler                     *
*                     ====================================                     *
* PURPOSE:                                                                     *
* ARGUMENTS: NONE                                                              *
* RETURN: NONE                                                                 *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::BlinkLEDInterruptHandler(VOID)  {
    //TPU3_TGFA = 0; // Acknowledge the compare match interrupt
	if (BOX->GetFailCode() >= HF_POWERDOWN) {

		BOX->LED_PINS(WRITE, STATUSLED_RED);
	}
	else if ((BOX->BoxSfCounter > 0) || (BOX->SlotSfCounter > 0) || (BOX->LedBlinkCounter > 0)) {

        if (BOX->LedBlinkCounter > 0) {
            --(BOX->LedBlinkCounter);
        }

        else if (TRUE == BOX->GetCalibAllState()) {
            // If calibration is progress and there is no request to blink the LED by
            // by the calibration function, switch off the LED and return.
        	BOX->LED_PINS(WRITE, STATUSLED_OFF);
            return;
        }

        if (STATUSLED_OFF == BOX->LED_PINS(READ)) {
            (BOX->GetDSA()) ? BOX->LED_PINS(WRITE, STATUSLED_GREEN)
                            : BOX->LED_PINS(WRITE, STATUSLED_AMBER);
        }
        else BOX->LED_PINS(WRITE, STATUSLED_OFF);
    }
    else {
        if (TRUE == BOX->GetCalibAllState()) {
        	BOX->LED_PINS(WRITE, STATUSLED_OFF);
        }
        else {
            (BOX->GetDSA()) ? BOX->LED_PINS(WRITE, STATUSLED_GREEN)
                            : BOX->LED_PINS(WRITE, STATUSLED_AMBER);
        }
    }
}

/*******************************************************************************
*                            clsBoxSlot::PreStatReset                          *
*                            ======================                            *
* PURPOSE: Pre Receiver-Beware function for StatReset parameter                *
*                                                                              *
* ARGUMENTS:a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:  PA_OK           -   If pre check is succesfull                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
PASTATUS clsBoxSlot::PreStatReset(UINT8 *a_Writebuffer,UINT8 ) {
    if((*a_Writebuffer < OFF)||(*a_Writebuffer > ON))
        return DO_LIMIT_OR_RANGE_EXCEEDED;
    return PA_OK;
}


/*******************************************************************************
*                           clsBoxSlot::PostStatReset                          *
*                           ========================                           *
* PURPOSE:   Post Receiver-Beware function for StatReset parameter             *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::PostStatReset(UINT8) {
    //Reset the  Statistics calculated for the Module
    //as operator has set the option to reset all stats calculated
    if(StatReset)
    {
        CpuFreeAvg = 0.0;//Reset the CPUFreeAverage Parameter
        //Reset the CPUFreeMin Parameter
        CpuFreeMin = 100.0;//In the beginning the module is approx 100 % free.
        //Reset the  ResetStat Flag to start recalculation
        TaskScheduler.StatReset();
        StatReset = OFF;
    }
}

/*******************************************************************************
*                           clsBoxSlot::ManageRedIO                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::ManageRedIO(VOID) {

	switch(Iol.AddressChange()) {
	case ADDCHG_NONE:
		break;
	case ADDCHG_NEW:
		if(Iol.AmPrimary()) {
			DeAssertBackup();
		}
		SetRedState(REDSTATE_NOT_SYNCD);
		//TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0x55555555);
		break;
	case ADDCHG_DROPPED:
		if(REDSTATE_IOL_TIMEOUT != GetRedState()){
			DropSync();
			//TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,0xAAAAAAAA);
		}
		break;
	}
}

/*******************************************************************************
*                           clsBoxSlot::DropSync                               *
*                           ====================                               *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::DropSync(VOID) {
    if(REDSTATE_FREEZE_PERMITTED != GetRedState()){
       if(REDSTATE_SYNC_FAILED != GetRedState()) SetRedState(REDSTATE_NOT_SYNCD);
       if(!Iol.AmPrimary()) AssertBackup();
    }
}

/*******************************************************************************
*                            clsBoxSlot::PreRedData                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES: The database image of REDDATA is comprised of two bytes:              *
*        Byte 1 - REDDATA bits that reflect IOM redundancy status              *
*        Byte 2 - REDSTATE, an enum that indicates the IOM redundancy state    *
*        Writes to REDDATA are always to only one of these values at a time    *
*******************************************************************************/
PASTATUS clsBoxSlot::PreRedData(UINT8 *, UINT8) {
    PASTATUS ucStatus = PA_OK;

    if ((Data.ucBytes[0] == 0 && Data.ucBytes[1] == 0) ||
        (Data.ucBytes[0] != 0 && Data.ucBytes[1] != 0)) {
        ucStatus = DO_ILLEGAL_VALUE;
    }
    else {
        if (Data.ucBytes[1] != 0) {                 // Process Write to REDSTATE
            Data.ucBytes[2] = 0;                  // New RedData for PostRedData
            Data.ucBytes[3] = GetRedState();  // Save old value for PostRedState
            ucStatus = PreRedState();                 // Check Write to REDSTATE
        }
        else {                                               // Write to REDDATA
            Data.ucBytes[2] = Data.ucBytes[0]; // Save new value for PostRedData
            switch (Data.ucBytes[0] & REDDATA_BITS) {// Validate and set the bits
                case REDDATA_REDCFG_BITNUM:
                    if ((ModlType == MODLTYPE_LLMUX) || (ModlType == MODLTYPE_LLMUX_S8)){
                        ucStatus = DO_CONFIGURATION_MISMATCH_ERROR;
                        break;
                    }
                case REDDATA_BURQST_BITNUM:
                case REDDATA_SFFOEN_BITNUM:
                case REDDATA_WIGGLE_BITNUM:
                case REDDATA_WIGLSF_BITNUM:
                    UpdateRedData(Data.ucBytes[0]);
                    ucStatus = PA_REDDATA_BYPASS;
                    break;
                default:
                    ucStatus = DO_PARAMETER_INVALID;
                    break;
            }
        }
    }
    return ucStatus;
}

/*******************************************************************************
*                           clsBoxSlot::PostRedData                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::PostRedData(UINT8) {
    switch (Data.ucBytes[2]) {
        case 0:         // If the new RedData is zero then RedState was changed
            PostRedState();                     // Process it
            break;
        case RDBIT_CLR + REDDATA_BURQST_BITNUM: // If RedData.BuRqst was cleared
            //SWBUREQ_n = 1;                      // Deassert Backup Request line
			SetBupreqOut(1);
            break;
        case RDBIT_SET + REDDATA_BURQST_BITNUM: // If RedData.BuRqst was set
            //SWBUREQ_n = 0;                      // Assert Backup Request line
            SetBupreqOut(0);
            break;
        case RDBIT_CLR + REDDATA_REDCFG_BITNUM: // If RedData.RedCfg was cleared
            SetRedState(REDSTATE_NOT_SYNCD);
            break;
    }
}
/*******************************************************************************
*                           clsBoxSlot::PreRedState                            *
*                           =======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsBoxSlot::PreRedState(VOID) {
    if (Data.ucBytes[1] != REDSTATE_SYNCD) {
        if (Data.ucBytes[1] == REDSTATE_FO_IN_PROG) {
            if (CheckRedData(REDDATA_REDCFG)) {
                if (Iol.AmPrimary()) return DO_ILLEGAL_VALUE;
            }
            else return DO_ILLEGAL_VALUE;
        }
        else if (Data.ucBytes[1] == REDSTATE_SWAP_IN_PROG) {
            if (!CheckRedData(REDDATA_REDCFG)) return DO_INVALID_STATE_PA_STATUS;
            else {
                if (Data.ucBytes[3] != REDSTATE_SYNCD) return DO_INVALID_STATE_PA_STATUS;
                else {
                    if (!Iol.AmPrimary()) {
                        // Swap is initiated. mark this to skip diag cycle for new secondary.
                        bStcSyncRestart = TRUE;
                        return PA_REDDATA_BYPASS;
                    }
                }
            }
            // Swap is initiated. mark this to skip diag cycle for new secondary.
            bStcSyncRestart = TRUE;
        }
        else SetRedState(Data.ucBytes[1]);
    }
    else {  // New RedState is SYNCD; check old RedState
        if ((Data.ucBytes[3] != REDSTATE_SYNCD) &&
            (Data.ucBytes[3] != REDSTATE_DUMP_COMPLETE) &&
            (Data.ucBytes[3] != REDSTATE_SWAP_COMPLETE) &&
            (Data.ucBytes[3] != REDSTATE_IOL_TIMEOUT)) return DO_INVALID_STATE_PA_STATUS;
        else SetRedState(Data.ucBytes[1]);
    }
    return PA_REDDATA_BYPASS;
}

/*******************************************************************************
*                           clsBoxSlot::PostRedState                           *
*                           ========================                           *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::PostRedState(VOID) {
    switch (Data.ucBytes[1]) {
        case REDSTATE_SYNCD:                          // If new RedState synched
            if(Data.ucBytes[3] != REDSTATE_SYNCD) {// If old RedState was synched
                if (CheckRedData(REDDATA_SFFOEN))       // If SF Failover Enabled
                    DeAssertBackup();
                ResetRedData(REDDATA_WIGGLE);
                BOX->AppPostSync();
#if 0 // temp for testing
                // initiate to store the dump data into the battery backed SRAM
                BOX->StoreDatabase(0, TRUE);
#endif
                //TraceLog.AddToTrace(TRACEID_GENERIC,bcSynced,
                // ((((UINT32)RedData[0]) << (BYTESIZE+WORDSIZE)) |
                // (((UINT32)RedData[1]) << WORDSIZE) | (Dsa << BYTESIZE) | Ba));
                if(Iol.AmPrimary()) return;      // If module is primary, return
                // Update module status in ECL status byte
                pNrmEcl->SetEclModStat(GetModuleStatus());
                // Generate Module Status state change event
                AddModStatEvent(EVENTTYPE_NORMAL);
            }
            break;
        case REDSTATE_NOT_SYNCD:
        case REDSTATE_SYNC_FAILED:
            if (!Iol.AmPrimary()) { // if module is secondary
                BOX->AppColdInit();
                AssertBackup();
            }
            if (REDSTATE_NOT_SYNCD == Data.ucBytes[1]) {
                ;//TraceLog.AddToTrace(TRACEID_GENERIC,bcNotSynced,*(UINT16 *)RedData<<16 + MesNo);
            }
            else {
                ;//TraceLog.AddToTrace(TRACEID_GENERIC,bcSyncFailed,*(UINT16 *)RedData<<16 + MesNo);
            }
            break;
        case REDSTATE_FO_IN_PROG:
            switch (Data.ucBytes[3]) {         // old RedState
                case REDSTATE_SYNCD:
                case REDSTATE_IOL_TIMEOUT:
                    DeAssertBackup();
                    SetRedState(REDSTATE_FO_COMPLETE);
                    break;
                case REDSTATE_FO_IN_PROG:
                case REDSTATE_FO_COMPLETE:
                    break;
                default:
                    BOX->AppColdInit();
                    SetRedState(REDSTATE_FO_COMPLETE);
                    break;
            }
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcFailOver,256*Data.ucBytes[3]+Data.ucBytes[1]);
            break;
        case REDSTATE_SWAP_IN_PROG:
            if (Iol.AmPrimary()) {

                // added to resolve, PAR# 1-7JRVXP9 (INCOMPATIBLE STATE)
                // ~150msec delay
                for (UINT8 ucLoop = 0; ucLoop < 10; ucLoop++)
                IdleWait(15000);

                SetRedState(REDSTATE_SWAP_COMPLETE);
                UINT8 ucTemp = GetDSA();
                SetBA(ucTemp);
                Iol.SetIolBA(ucTemp);
                BOX->AppPostSwap();
                AssertBackup();
            }
            else {
#if defined(IOPTYPE_AO16) || defined(IOPTYPE_DO) // enabled for DO - to fix PAR # 1-E1F06W3 (PWM is not retaining during PRI-SEC failover)
                // added while point driving through HPMRC, if swap LEG(OK)/RDG(BKP) to LEG(BKP)/RDG(OK)
                // HPMRC mode is changing to MAN instead AUTO, hence point is not driving.
                IdleWait(1000);
#endif
                DeAssertBackup();
                #if defined(IOMTYPE_UIO)
                // It's possible that the module detected the swap in AppStc::CheckFailOverCondition
                // before we had a chance to process it here first.
                // If that's the case, set the redundancy state to failover complete, otherwise
                // we'll be stuck in failover-in-progress.
                if (ModStat3.OutCtl == OUTCTL_MINE)
                {
                    // We already have control of the screws..we're done.
                    SetRedState(REDSTATE_FO_COMPLETE);
                }
                else
                {
                    // We don't have control of the screws...
                    // Failover is in progress.
                    SetRedState(REDSTATE_FO_IN_PROG);
                }
                #elif (defined(IOMTYPE_AOH) || defined(IOMTYPE_DO) || defined(IOMTYPE_SVP) || defined(IOMTYPE_SP) || defined(IOMTYPE_PI))
                SetRedState(REDSTATE_FO_IN_PROG);
#if defined(IOPTYPE_AO16) || defined(IOPTYPE_DO)
                // added while point driving through HPMRC, if swap LEG(OK)/RDG(BKP) to LEG(BKP)/RDG(OK)
                // HPMRC mode is changing to MAN instead AUTO, hence point is not driving.
                SetRedState(REDSTATE_FO_COMPLETE);
#endif
                #else
                SetRedState(REDSTATE_FO_COMPLETE);
                #endif
            }
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcSwap,*(UINT16 *)RedData);
            break;
    }
}
/*******************************************************************************
*                          clsBoxSlot::AddModStatEvent                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddModStatEvent(EVENTTYPE a_EventType) {
    EVENTRECORD ModStatEvent;
    UINT8 CurrentLrsMask, PreviousLrsMask,PreviousModStat;
    EVENTSUBTYPE CurrentSubType, PreviousSubType;

    // Initialize event record.
    ModStatEvent.Overflow      = FALSE;
    ModStatEvent.ContactCutout = FALSE;
    ModStatEvent.Qualifier     = a_EventType;
    ModStatEvent.CurrentState  = EVENTSTATE_RETURN;
    ModStatEvent.EventPacket   = EVENTPACKET_SYSTEM;
    ModStatEvent.SystemEvent.SoftfailStatus = FALSE;
    ModStatEvent.SystemEvent.ChannelNumber  = 0;
    if (ModStat1.Status == MODSTATUS_IDLE) {
        CurrentLrsMask     = MODSTATUS_IDLE_LRSBIT;
        PreviousLrsMask    = MODSTATUS_RUN_LRSBIT;
        CurrentSubType     = EVENTSUBTYPE_IDLE;
        PreviousSubType    = EVENTSUBTYPE_RUN;
        PreviousModStat    = MODSTATUS_RUN;
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        CurrentLrsMask     = MODSTATUS_RUN_LRSBIT;
        PreviousLrsMask    = MODSTATUS_IDLE_LRSBIT;
        CurrentSubType     = EVENTSUBTYPE_RUN;
        PreviousSubType    = EVENTSUBTYPE_IDLE;
        PreviousModStat    = MODSTATUS_IDLE;
    }
    // Set LRS bit only for normal events.
    if (EVENTTYPE_NORMAL == a_EventType) {
        ModStat1Lrs |= CurrentLrsMask;
    }
    // If last module state change is not reported yet, report it.
    if (ModStat1Lrs & PreviousLrsMask) {
        ModStatEvent.SystemEvent.EventSubType = PreviousSubType;
        if (EVENTTYPE_RECOVERY == a_EventType) {
            if (pNrmEcl->IsRoomForRegen() == FALSE) {
                return FALSE;
            }
        }
        else {
            // Set ECL module status only for normal events.
            pNrmEcl->SetEclModStat(PreviousModStat);
        }
        // Do not update LRS for recovery events.
        if (pNrmEcl->AddEvent(&ModStatEvent) == TRUE) {
            if (EVENTTYPE_NORMAL == a_EventType) {
                ModStat1Lrs &= (~PreviousLrsMask);
            }
        }
        else {
            return FALSE;
        }
    }
    // Report current state change to idle.
    ModStatEvent.SystemEvent.EventSubType = CurrentSubType;
    if (EVENTTYPE_RECOVERY == a_EventType) {
        if (pNrmEcl->IsRoomForRegen() == FALSE) {
            return FALSE;
        }
    }
    else {
        // Set ECL module status only for normal events.
        pNrmEcl->SetEclModStat(ModStat1.Status);
    }
    // Do not update lrs for recovery events.
    if (pNrmEcl->AddEvent(&ModStatEvent) == TRUE) {
        if (EVENTTYPE_NORMAL == a_EventType) {
            ModStat1Lrs &= (~CurrentLrsMask);
        }
        return TRUE;
    }
    return FALSE;
}

#if 1 //defined(IOPTYPE_HLAI) || defined(IOPTYPE_DI)
// for redesign PMIO, Alarm Event for HLAI
BOOL clsBoxSlot::AddAiAlarmEvent(ALARMEVENTRECORD *pAlarmEvent)
{
#if 1 //defined(IOPTYPE_HLAI) || defined(IOPTYPE_DI)
    if (NOALARM == pAlarmEvent->AlarmCode)
    {
        pNrmEcl->ResetStatus(ECLSTATUS_NORMAL);
    }
    else
    {
        pNrmEcl->SetStatus(ECLSTATUS_NORMAL);
    }
#endif

    return pNrmEcl->AddAlarmEvent(pAlarmEvent);
}
#endif

BOOL clsBoxSlot::AddPtExecStEvent(EVENTRECORD *pPtExecStEvent)
{
    pNrmEcl->SetStatus(ECLSTATUS_NORMAL);

    return pNrmEcl->AddEvent(pPtExecStEvent);
}

/*******************************************************************************
*                         clsBoxSlot::AddSoftfailEvent                         *
*                         ============================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddSoftfailEvent(EVENTTYPE a_EventType,
                                  SOFTFAILTYPE a_SoftfailType,
                                  BOOL a_bDirection, UINT8 a_ucSltNm) {
    EVENTRECORD SoftfailEvent;
    // Initialize event record.
    SoftfailEvent.Overflow      = FALSE;
    SoftfailEvent.ContactCutout = FALSE;
    SoftfailEvent.Qualifier     = a_EventType;
    SoftfailEvent.EventPacket   = EVENTPACKET_SYSTEM;
    SoftfailEvent.SystemEvent.ChannelNumber = a_ucSltNm;
    SoftfailEvent.SystemEvent.EventSubType  = a_SoftfailType;

    UINT8 ucSfByte,ucLrsByte,ucByteOffset,ucBitOffset=0x01;
    UINT8 ucSfActByteOffset,ucSfActBitOffset=0x01;

#if 1//defined(IOPTYPE_HLAI)
    // for redesign PMIO, there should be timeout between accessing of ADC & xRAM through SPI.
    // in that timeout these softfails are not valid.
    if ((ucXRamTimeout) &&
       ((SF_VREFFAIL == a_SoftfailType) ||
        (SF_ADOUTUDF == a_SoftfailType) ||
        (SF_VZERO_FL == a_SoftfailType) ||
        (SF_ADOUTCAL == a_SoftfailType)))
        return FALSE;
#elif defined(IOPTYPE_AO16)
    // added to fix unwanted softfails with the greater than SFail code 127
    // root cause: Legacy has BoxSfBits[16], where as redesign BoxSfBits[32]
    // modification: so supressed to 128 SFail codes (16 x 8bits)
    if (a_SoftfailType > SF_IDLE) {
        return FALSE;
    }
#endif

    // Generate ByteOffset and BitOffsets for SfActionTable search
    ucSfActByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
    ucSfActBitOffset <<= (a_SoftfailType % BYTESIZE);

    // Set SfByte and LrsByte according to the slot number and softail type.
    if (0 == a_ucSltNm) {
        ucByteOffset = (UINT8) a_SoftfailType / BYTESIZE;
        ucBitOffset <<= (a_SoftfailType % BYTESIZE);
        ucSfByte  = BoxSfBits[ucByteOffset];
        ucLrsByte = BoxSfLrs[ucByteOffset];
    }
    else {
        for (ucByteOffset = 0; ucByteOffset < BYTESIZE; ucByteOffset++) {
            if (SlotSfMap[ucByteOffset] == a_SoftfailType) {
                break;
            }
            ucBitOffset <<= 1;
        }
        if (BYTESIZE == ucByteOffset) {
            return FALSE;
        }
        ucSfByte  = SLOT(a_ucSltNm)->GetSlotSfBt();
        ucLrsByte = SLOT(a_ucSltNm)->GetSlotSfLrs();
    }

    if (TRUE == a_bDirection) {
        SoftfailEvent.CurrentState = EVENTSTATE_ALARM;
        if (EVENTTYPE_NORMAL == a_EventType) {
            //Initiate a SoftFail Failover if enabled and appropriate
            if (REDSTATE_SYNCD == GetRedState() &&       // if modules syncd
                CheckRedData(REDDATA_SFFOEN) &&          // + SF FO enabled
                (SfActionTbl[ucSfActByteOffset] & ucSfActBitOffset))// + FO for this SF
            {
                if ((!GetFtaPres() || !GetPartnersBackupStatus()) && Iol.AmPrimary())
                {
                // added to fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
#if defined(IOPTYPE_AO16)
                    LastSfCode = a_SoftfailType;
#endif
                    Iol.DropDSA();
                    BOX->SetDSA(0);
                }
                AssertBackup();
                ResetRedData(REDDATA_SFFOEN);
            }
        }
    }
    else SoftfailEvent.CurrentState = EVENTSTATE_RETURN;

    UINT8 ucSaveExr = get_imask_exr();
    if (EVENTTYPE_NORMAL == a_EventType) {
        // Elevate the priority of executing thread to STC level
        // when SfBits and Sfcounter in database are updated.
        set_imask_exr(LVLPRI_TICK);

        #ifndef IOMTYPE_SVP
        #ifndef IOMTYPE_SP
            if (a_ucSltNm > 0) { // if slot softfail, check for throttling
                if ((SLOT(a_ucSltNm)->IsSlotSfToBeThrottled(ucBitOffset,a_bDirection) == TRUE) ){
                    // Softfail to be throttled. Restore original priority and
                    // return wihtout updating SfBits and SfCounter in database.
                    set_imask_exr(ucSaveExr);
                    return FALSE;
                }
            }
        #endif
        #endif

        if ((ucSfByte & ucBitOffset) && (FALSE == a_bDirection)) {
            // SfByte bit is set and the softfail is returning
            ucSfByte &= ~ucBitOffset; // reset SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter > 0) BoxSfCounter--;
            }
            else {
                if (SlotSfCounter > 0) SlotSfCounter--;

                // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
#if defined(IOPTYPE_AO16)
                if ((SF_OUTPUTFL == a_SoftfailType) && (ucOutputFailCounter))
                {
                    ucOutputFailCounter--;
                }
#endif
            }
        }
        else if ((!(ucSfByte & ucBitOffset)) && (TRUE == a_bDirection)) {
            // SfByte bit is not set and the softfail is being reported
            ucSfByte |= ucBitOffset; // set SfByte bit.
            if (0 == a_ucSltNm) {
                if (BoxSfCounter < MAXUINT8) BoxSfCounter++;
            }
            else {
                if (SlotSfCounter < MAXUINT8) SlotSfCounter++;

                // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (flooding alarms if SEC in SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion)
#if defined(IOPTYPE_AO16)
                SfCodeLrs = a_SoftfailType;

                if (SF_OUTPUTFL == a_SoftfailType)
                    ucOutputFailCounter++;
#endif
            }
        }

#if defined(PMIO_DEBUG) && (0)
        if (ucDbgPnt == NRML_DBGPNT)
        {
            if (ucDbgCnt < DMPBUF_SIZE - 5)
            {
                ucDumpBuff[ucDbgCnt++] = a_SoftfailType;
                ucDumpBuff[ucDbgCnt++] = ((a_ucSltNm << 4) | a_bDirection);
            }
            else ucDbgCnt = 0;
        }
#endif

        // Update SfByte in the box/slot database.
        if (0 == a_ucSltNm) {
            BoxSfBits[ucByteOffset] = ucSfByte;
        }
        else {
            SLOT(a_ucSltNm)->SetSlotSfBt(ucSfByte);
        }

        // Database update complete.
        // Restore original interrupt priority.
        set_imask_exr(ucSaveExr);
    }

    if ((0 == BoxSfCounter) && (0 == SlotSfCounter)) {
        SoftfailEvent.SystemEvent.SoftfailStatus = FALSE;
        pNrmEcl->ResetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = FALSE;
        SetRedData(REDDATA_SFFOEN);
        if (Iol.AmPrimary() || (REDSTATE_SYNCD == GetRedState())) {
            if (GetCalibAllState() != TRUE) {
                DeAssertBackup();
            }
        }
    }
    else {
        SoftfailEvent.SystemEvent.SoftfailStatus = TRUE;
        pNrmEcl->SetStatus(ECLSTATUS_SOFTFAIL);
        ModStat2.SF = TRUE;
    }

    // Fix for PAR# 1-E2KA8ZT, 1-E2KVSJR & 1-E35JRCL (SEC is going into SFAIL/FO_COMPLETE during OP Fail & FTA Reinsertion on power up)
#if defined(IOPTYPE_AO16)
    if ((!Iol.AmPrimary())
    && (SF_OUTPUTFL == a_SoftfailType)
    && (GetPartnersBackupStatus())
    && (INHIN_NEGATED != INHIN_FB_n))
    {
        LastSfCode = SF_OUTPUTFL;
    }
#endif

    if (MODSTATUS_FAIL != ModStat1.Status) {
        // Add softfail event to the normal event circular list if this is
        // event recovery OR if SfByte and LrsByte are not matching.
        if ((EVENTTYPE_RECOVERY == a_EventType) ||
            (ucLrsByte ^ ucSfByte) & ucBitOffset) {
            if (EVENTTYPE_RECOVERY == a_EventType) {
                if (pNrmEcl->IsRoomForRegen() == FALSE) {
                    return FALSE;
                }
            }

            if (TRUE == pNrmEcl->AddEvent(&SoftfailEvent)) {
                if (EVENTTYPE_NORMAL == a_EventType) {
                    // Update LRS byte only for normal events.
                    if (TRUE == a_bDirection) {
                        ucLrsByte |= ucBitOffset;
                    }
                    else {
                        ucLrsByte &= ~ucBitOffset;
                    }
                }

                // Elevate the priority of executing thread to
                // STC level when LRS byte in database is updated.
                set_imask_exr(LVLPRI_TICK);
                if (0 == a_ucSltNm) {
                    BoxSfLrs[ucByteOffset] = ucLrsByte;
                }
                else {
                    SLOT(a_ucSltNm)->SetSlotSfLrs(ucLrsByte);
                }
                // Database update complete.
                // Restore original interrupt priority.
                set_imask_exr(ucSaveExr);

                return TRUE;
            }
            else { // AddEvent failed
                return FALSE;
            }
        }
    }

    // Execution reaches here only if
    // there is nothing to report.
    return TRUE;
}

/*******************************************************************************
*                           clsBoxSlot::AddBrackEvent                          *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddBracketEvent(EVENTSUBTYPE a_EventSubType) {
    EVENTRECORD EventBracket;
#ifdef IOMTYPE_DISOE
    // The regen in progress flag is set.  If a regen is not expected, the
    // Timesync Table is saved via the Save Timesync Table routine.  Then, if the
    // regen is expected or the log is not frozen, the log is frozen, and the
    // regen expected flag is set false.
    BOOL bRegen_Expected = BOX->IsRegen_Expected();
    if(EVENTSUBTYPE_RECOVERYSTART==a_EventSubType) {
        BOX->SetPVCLEvtRegInProgress(TRUE);
    }
    if(FALSE == bRegen_Expected)
    {
        BOX->CopySyncTbl();
    }
    if( (TRUE==bRegen_Expected) || (FALSE== BOX->IsLogFrozen()) ) {
        BOX->SetLog_Frozen(TRUE);
        BOX->SetRegen_Expected(FALSE);
    }
#endif // disoe
    // Create start backet
    EventBracket.Overflow      = FALSE;
    EventBracket.ContactCutout = FALSE;
    EventBracket.Qualifier     = EVENTTYPE_RECOVERY;
    EventBracket.CurrentState  = EVENTSTATE_RETURN;
    EventBracket.EventPacket   = EVENTPACKET_SYSTEM;
    EventBracket.SystemEvent.SoftfailStatus = FALSE;
    EventBracket.SystemEvent.ChannelNumber  = 0;
    EventBracket.SystemEvent.EventSubType   = a_EventSubType;
    if (pNrmEcl->IsRoomForRegen() == TRUE) {
        return pNrmEcl->AddEvent(&EventBracket);
    }
    return FALSE;
}

#if defined IOMTYPE_DISOE || defined IOPTYPE_DI
/*******************************************************************************
*                           clsBoxSlot::AddPVCLBracketEvent                    *
*                           =========================                          *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::AddPVCLBracketEvent(EVENTSUBTYPE a_EventSubType) {
    EVENTRECORD EventBracket;

    // Create backet event
    EventBracket.Overflow      = FALSE;
    EventBracket.ContactCutout = FALSE;
    EventBracket.Qualifier     = EVENTTYPE_RECOVERY;
    EventBracket.CurrentState  = EVENTSTATE_RETURN;
    EventBracket.EventPacket   = EVENTPACKET_SYSTEM;
    EventBracket.SystemEvent.SoftfailStatus = FALSE;
    EventBracket.SystemEvent.ChannelNumber  = 0;
    EventBracket.SystemEvent.EventSubType   = a_EventSubType;

    if (pPvChngEcl->IsRoomForPVCLRegen() == TRUE)
    {
        return pPvChngEcl->AddPVCLEvent((PVCLEVTRECORD *)&EventBracket);
    }

    return FALSE;
}
#endif
/*******************************************************************************
*                           clsBoxSlot::RegenSoftfails                         *
*                           ==========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
BOOL clsBoxSlot::RegenSoftfails(VOID) {

    static UINT8 ucByteCount = 0,ucBitCount = 0,ucMask = 0x01;

    // Iterate for 32 BoxSfBytes and each SlotSfByte.
    while (ucByteCount <= (SFBYTES_SIZE + MaxSlots)) {

        UINT8 ucSfByte,ucSlotNum;
        if (ucByteCount < SFBYTES_SIZE) { //get box softfail byte

            ucSlotNum = 0;
            ucSfByte = BoxSfBits[ucByteCount];
        }
        else { //get slot soft fail byte

            if (SFBYTES_SIZE == ucByteCount) {

                // Return FALSE so that event recovery task will suspend before
                // recovering slot softfails. Increment ucByteCount before
                // returning so that this function will continue with slot soft
                // fail recovery when scheduler resumes event recovery task.
                ucByteCount++;
                return FALSE;
            }
            ucSlotNum = ucByteCount - SFBYTES_SIZE;
            ucSfByte = SLOT(ucSlotNum)->GetSlotSfBt();
        }

        if (ucSfByte > 0) { // any soft fails exists

            while (ucBitCount < BYTESIZE) {

                if (ucSfByte & ucMask) { // Regenerate softfail event

                    SOFTFAILTYPE SoftfailType;
                    if (ucByteCount < SFBYTES_SIZE) { // box softfail

                        SoftfailType = (SOFTFAILTYPE)
                                       ((ucByteCount * BYTESIZE) + ucBitCount);
                    }
                    else { //slot softfail

                        SoftfailType = (SOFTFAILTYPE)SlotSfMap[ucBitCount];
                    }
                    if (FALSE == AddSoftfailEvent(EVENTTYPE_RECOVERY,SoftfailType, TRUE,ucSlotNum))
                    {
                        // Return FALSE so that task will suspend.
                        return FALSE;
                    }
                }
                ucMask <<= 1;
                ucBitCount++;
            }
        }
        // Reinitialize ucMask and ucBitCount for next regeneration.
        ucMask = 0x01;
        ucBitCount = 0;
        ucByteCount++;
    }
    // Reinitialize ucByteCount for next regeneration.
    ucByteCount = 0;

    return TRUE; // Mark end of the softfail recovery.
}

/*******************************************************************************
*                          clsBoxSlot::BoxHouseKeeping                         *
*                          ===========================                         *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::BoxHouseKeeping(VOID) {

	CheckFtaPresence();

#if 0
    // Save current interrupt masks and set current masks
    // so that STC or point processing cannot come in between.
    UINT8 ucSaveExr = get_imask_exr();
    set_imask_exr(LVLPRI_TICK);

    UINT8 ucCount,ucIndex = 0,ucCompositeByte = 0,ucMask = SLOTINFAIL_MASKINIT;
    UINT8 ucByteOffset,ucBitOffset;

    CheckFtaPresence();

    // Update MapSlotInFail parameter
    for (ucCount = 1; ucCount <= MaxSlots; ucCount++) {

        if ((ucByteOffset = SLOT(ucCount)->GetSlotSfBt()) > 0) {

            ucCompositeByte |= ucByteOffset;
            MapSlotInFail[ucIndex] |= ucMask;
        }
        else {

            MapSlotInFail[ucIndex] &= ~ucMask;
        }
        ucMask >>= 1;
        if (0 == ucMask) {

            ucMask = SLOTINFAIL_MASKINIT;
            ucIndex++;
        }

        // Allow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr);
        set_imask_exr(LVLPRI_TICK);
    }

    // Update SlotSfBits from individual SlotSfBt.
    ucMask = 0x01;
    for (ucCount = 0; ucCount < BYTESIZE; ucCount++) {

        if (SF_UNKNOWN != SlotSfMap[ucCount]) {

            ucByteOffset = SlotSfMap[ucCount] / BYTESIZE;
            ucBitOffset = SlotSfMap[ucCount] % BYTESIZE;
            UINT8 ucBoxSfMask = 0x01 << ucBitOffset;

            if (ucCompositeByte & ucMask) {

                SlotSfBits[ucByteOffset] |= ucBoxSfMask;
            }
            else {

                SlotSfBits[ucByteOffset] &= ~ucBoxSfMask;
            }
        }
        ucMask <<= 1;

        // Alow STC to run to avoid STC overruns.
        set_imask_exr(ucSaveExr);
        set_imask_exr(LVLPRI_TICK);
    }

    // Count down SlotSfThrottleCount in all slots.
    for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {

        SLOT(ucCount)->CountDownSlotSfThrottle();
    }

    // Rereport ModStat event if required
    if (ModStat1Lrs > 0) {

        AddModStatEvent(EVENTTYPE_NORMAL);
    }

    // Alow STC to run to avoid STC overruns.
    set_imask_exr(ucSaveExr);
    set_imask_exr(LVLPRI_TICK);

#if ( defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE) )
    DIMODE DiModeVal = BOX->GetDiMode();
#ifdef IOMTYPE_DISOE
    if((DIMODE_SOE == DiModeVal) || (DIMODE_LOWLATNCY == DiModeVal))
#else
    if(DIMODE_LOWLATNCY == DiModeVal)
#endif
    {
        // If the module is reloaded with the DiMode as SOE/LOWLATNCY, send OWD RTN event
        // as OpenWireDiag routine will not run in these modes to check OWDEnable param and
        // post the SF_OPENWIRE RTN event.
        for(UINT8 ucChanNum=1;ucChanNum<=MAXSLOTS;ucChanNum++)
        {
            if(TRUE == SLOT(ucChanNum)->IsOwdSfSet())
            {
                AddSoftfailEvent(EVENTTYPE_NORMAL,SF_OPENWIRE,FALSE,ucChanNum);
            }
        }
    }
    // Allow STC to run to avoid STC overruns.
    set_imask_exr(ucSaveExr);
    set_imask_exr(LVLPRI_TICK);
    // Post I/P fail soft fail using results saved in ForcedInputDiag.
    UINT32 DiagData,ulMask;
    DiagData = BOX->GetForcedInputDiagStatus();
    for (ucCount = 1,ulMask = 1; ucCount <= MAXSLOTS; ucCount++,ulMask <<= 1)
    {
        if ((ModStat1.Status == MODSTATUS_RUN) &&
            (SLOT(ucCount)->GetPtExecSt() == PTEXECST_ACTIVE) &&
            (DiagData & ulMask))
        {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_INPTFAIL,TRUE,ucCount);
        }
        else
        {
            AddSoftfailEvent(EVENTTYPE_NORMAL,SF_INPTFAIL,FALSE,ucCount);
        }
    }
#endif

#if (defined(IOMTYPE_DO) || defined(IOMTYPE_UIO))
    for (UINT8 ucChanNum = 1; ucChanNum <= MAXSLOTS; ucChanNum++)
    {
        BOOL bDirection = BOX->GetOverCurrent(ucChanNum);
        AddSoftfailEvent(EVENTTYPE_NORMAL,SF_DOVRCRNT,bDirection,ucChanNum);
    }
#endif

    // Periodically recompute database checksums.
    static UINT8 sucSlot = 0;

    // Storing the dump data into the battery backed SRAM slot wise.
    BOX->StoreDatabase(sucSlot, FALSE); // Store database without checksum

    pDatabase[sucSlot++]->ComputeCheckSum();

    if (sucSlot > MAXSLOTS) {
        sucSlot = 0;
    }

    // Restore original interrupt mask and return.
    set_imask_exr(ucSaveExr);
#endif
}

/********************************************************************************************
*                            clsBoxSlot::PreModStat1                                        *
*                            =======================                                        *
* PURPOSE:   Pre Receiver-Beware function for ModStat1 parameter. Checks for module status. *
* ARGUMENTS: a_Writebuffer   -   Pointer to the data to be written.                         *
*            a_ucAccLvl      -   Access level for check                                     *
* RETURN:    PA_OK           -   If pre check is succesfull                                 *
* NOTES:     This method will update ModStat1Trans flag if there is any                     *
*            change in the module status.                                                   *
*********************************************************************************************/
PASTATUS clsBoxSlot::PreModStat1(UINT8 *a_Writebuffer,UINT8) {

    const UINT8 FACTORYMODE_BIT = 0x04; //3rd bit in ModStat1 byte is Factory Mode bit
    UINT8 ucNewMod1State = *(UINT8*)a_Writebuffer;

    if (ucNewMod1State > MODSTATUS_FAIL) {

      return DO_ILLEGAL_VALUE;
    }

    // Return error is module is in the Alive state.
    if (ModStat1.Status == MODSTATUS_ALIVE) {

        return DO_STATE_MUST_BE_IDLE_OR_RUN;
    }

    // Check if calibration is in progress for analog IOMs. 
    // This virtual function returns always FALSE for digtial IOMs.
    if (TRUE == GetCalibAllState()) {

        return DO_CALIB_IN_PROGRESS;
    }

    // Shutdown the IOM if the new value is ALIVE or FAILED.
    if ((MODSTATUS_ALIVE == ucNewMod1State) || (MODSTATUS_FAIL == ucNewMod1State)) {

        if (ModStat1.Status == MODSTATUS_IDLE) {

            //TraceLog.AddToTrace(TRACEID_GENERIC,bcIdleToAlive);

            // Make sure the FaultOpt values are resetted to UNPOWER so that they will
            // Come as UNPOWERED when Module Reboots in ALIVE Mode
            #if (defined(IOMTYPE_DO))
            *(BOX->OutputPorts[0]) = 0;
            *(BOX->OutputPorts[1]) = 0;
            *(BOX->OutputPorts[2]) = 0;
            *(BOX->OutputPorts[3]) = 0;
            HOLDOUT_n = 1;
            HOLDOUT_n = 0;
            #endif

            // Update the FailCode and shutdown IOM.
            FailCode = HF_IOMUSERRESET;
            ShutdownIom();
        }
        else
        {
            return DO_STATE_MUST_BE_IDLE;
        }
    }

    this->ScratchPad = MODSTATUS_NO_TRANS;
    if (ModStat1.Status == MODSTATUS_IDLE) {
        if (ucNewMod1State == MODSTATUS_IDLE) {
            this->ScratchPad  = MODSTATUS_IDLE_IDLE;
        }
        else if (ucNewMod1State == MODSTATUS_RUN) {
            this->ScratchPad  = MODSTATUS_IDLE_RUN;
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcIdleToRun);
        }
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        if (ucNewMod1State == MODSTATUS_IDLE) {
            this->ScratchPad  = MODSTATUS_RUN_IDLE;
            //TraceLog.AddToTrace(TRACEID_GENERIC,bcRunToIdle);
        }
        else if (ucNewMod1State == MODSTATUS_RUN) {
            this->ScratchPad  = MODSTATUS_RUN_RUN;
        }
    }

    //Retain the state of Factory Mode bit when Module state is changed
    if (CheckForFactoryTestMode()) {
        *(UINT8*)a_Writebuffer |= FACTORYMODE_BIT;//Factory Bit
    }

    return PA_OK;
}
/********************************************************************************
*                         clsBoxSlot::PostModStat1                              *
*                         ========================                              *
* PURPOSE:   Post Receiver-Beware function for ModStat1 parameter.  After a     *
*            successfull module status change, this method invokes the Post     *
*            method for Point Execution State parameter (PtExecSt) on each slot.*
*            If there is a module transition from RUN to IDLE or vice versa,    *
*            this generates a module status event.  If the new module state is  *
*            RUN,sets DbValid flag to DB_VALID.                                 *
* ARGUMENTS: a_ucAccLvl      -   Access level for check                         *
* RETURN:    PA_OK           -   If post check is succesfull                    *
* NOTES:     !ToDo! FPGA control on transitions of module status                *
*********************************************************************************/
VOID clsBoxSlot::PostModStat1(UINT8) {
    #if (defined(IOMTYPE_AIH) || defined(IOMTYPE_SVP)||defined(IOMTYPE_SP))
    if (ModStat1.Status == MODSTATUS_IDLE) {
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            SLOT(ucSlotNum)->InactivateSlot();
        }
    }
    #endif

    #if (defined(IOMTYPE_AO) || defined(IOMTYPE_AOH))
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        SLOT(ucSlotNum)->InactivateSlot();
        if(ScratchPad == MODSTATUS_IDLE_RUN) {
            SLOT(ucSlotNum)->ResetLpBkPassCount();
        }
    }
    #endif

    #if (defined(IOMTYPE_DO))
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        SLOT(ucSlotNum)->InactivateSlot();
    }
    #endif

    #if ( defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE) )
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        if (ScratchPad == MODSTATUS_IDLE_RUN) {
            SLOT(ucSlotNum)->UpdateBadPv();
        }
        else if (ScratchPad == MODSTATUS_RUN_IDLE) {
            SLOT(ucSlotNum)->InactivateSlot();
            SLOT(ucSlotNum)->UpdateBadPv();
        }
    }
    #endif

    #if (defined(IOMTYPE_PI))
    if (ModStat1.Status == MODSTATUS_IDLE) {
        // The following line will be uncommented when the FPGA supports it
        //FPGA_RST = FPGA_RESET;
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            SLOT(ucSlotNum)->InactivateSlot();
        }
        BOX->SetForceSafe(FORCEDSAFE_ON);
    }
    else if (ModStat1.Status == MODSTATUS_RUN) {
        BOX->SetForceSafe(FORCEDSAFE_OFF);
        // If going to RUN, clear all AVRAW counters and PL timers
        if (ScratchPad == MODSTATUS_IDLE_RUN) {
            UINT8 ucSaveExr = get_imask_exr();          // save current Int mask
            set_imask_exr(LVLPRI_TICK);         //disable STC and FPGA interrupts
            for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++)
                SLOT(ucSlotNum)->ClrCtrArchive();
            CCCR.FPGAWORDREG = 0xFFFF;
            CCCR.FPGAWORDREG = 0;
            set_imask_exr(ucSaveExr);                   // restore Int mask
        }
    }
    #endif

    #if (defined(IOMTYPE_UIO))
    for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        switch (SLOT(ucSlotNum)->GetPntType()) {
            // output channels: always call InactivateSlot()
            case PNTTYPE_ANALOGOUTPUT:
            case PNTTYPE_DIGITALOUTPUT:
                OUT_SLOT(ucSlotNum)->InactivateSlot();
                break;

            // digital input channels: check ScratchPad for correct behavior
            case PNTTYPE_DIGITALINPUT:
                if (ScratchPad == MODSTATUS_IDLE_RUN) {
                    if((ucSlotNum >= PC_CHANNEL1) && (ucSlotNum <= PC_CHANNEL4))
                    {
                        BOX->StoreAvRaw(ucSlotNum,0);
                        FPGA.ClrCounter(ucSlotNum);
                    }
                    DI_SLOT(ucSlotNum)->UpdateBadPv();
                }
                else if (ScratchPad == MODSTATUS_RUN_IDLE) {
                    DI_SLOT(ucSlotNum)->InactivateSlot();
                    DI_SLOT(ucSlotNum)->UpdateBadPv();
                }
                break;

            // analog input channels: call InactivateSlot() if MODSTATUS_IDLE
            case PNTTYPE_ANALOGINPUT:
                if (ModStat1.Status == MODSTATUS_IDLE) {
                    AIH_SLOT(ucSlotNum)->InactivateSlot();
                }
                break;

            default: // Null PntType
                // do nothing
                break;
        }
    }
    #endif // IOMTYPE_UIO

    if (ModStat1.Status == MODSTATUS_RUN) {
        // Mark the Database to be valid.
        DbValid = DB_VALID; 
    #if(defined(IOMTYPE_DI) || defined(IOMTYPE_DISOE))
        // start the SOE ISR if DiMode is not Normal
        if( DIMODE_NORMAL != BOX->GetDiMode() ) {
            // for the first time after the IOM made RUN, do
            // initialization of SOE State Machine Input buffer.
            #ifdef IOMTYPE_DISOE
            BOX->ScanChannel();
            #endif
            TPU0_CST = 1;       // Start the DISOE timer.
        }
    }

    if (ModStat1.Status == MODSTATUS_IDLE) {
        if(DIMODE_SOE != BOX->GetDiMode()){
            // SOE ISR should run in Idle Mode also as the TPU2 counter
            // wrap is handled in SOE ISR only.
            TPU0_CST = 0;       // Stop the DISOE timer.
        }
    #endif // IOMTYPE_DI || IOMTYPE_DISOE
    }

    if ((ScratchPad == MODSTATUS_IDLE_RUN) || (ScratchPad == MODSTATUS_RUN_IDLE)){
        AddModStatEvent(EVENTTYPE_NORMAL);
        #if (defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH))
        //for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
        //    SLOT(ucSlotNum)->GetHartDevDb().ControlStateChange();
        //}
        #elif defined(IOMTYPE_UIO)
        
        for (UINT8 ucSlotNum = 1; ucSlotNum <= MaxSlots; ucSlotNum++) {
            switch (SLOT(ucSlotNum)->GetPntType()) {
                case PNTTYPE_ANALOGINPUT:
                    AIH_SLOT(ucSlotNum)->GetHartDevDb().ControlStateChange();
                    break;

                case PNTTYPE_ANALOGOUTPUT:
                    AOH_SLOT(ucSlotNum)->GetHartDevDb().ControlStateChange();

                default:
                    // No hart for DI and DO
                    break;
            }
            
        }

        #endif
    }
}

/*******************************************************************************
*                            clsBoxSlot::preSyncVer                            *
*                            ======================                            *
* PURPOSE:                                                                     *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
PASTATUS clsBoxSlot::PreSyncVer(UINT8 *,UINT8) {
    UINT8 ucSlotNum;
#if (defined(IOMTYPE_AOH) || defined(IOMTYPE_SP) || defined(IOMTYPE_UIO))
    BOX->AppSyncver();
#endif
    // If this is initial sync and this is the backup module
    // Calculate the normal checksum for all slots
    if((Data.ucBytes[0] != 0) && (!Iol.AmPrimary())) {
        BOX->ComputeCheckSum();
        for (ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
            SLOT(ucSlotNum)->ComputeCheckSum();
        }
#if defined(PMIO_DEBUG) && (0)
        // indicating as initial sync
        while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\n"));
#endif
    }

    // Put the SYNC VERSION in the first byte of SYNCVER
    Data.ucBytes[0] =
        #if defined(IOMTYPE_AIH)
        AI_SYNC_VERSION;
        #elif defined(IOMTYPE_AOH)
        AO_SYNC_VERSION;
        #elif defined(IOMTYPE_DI)
        DI_SYNC_VERSION;
        #elif defined(IOMTYPE_DISOE)
        DISOE_SYNC_VERSION;
        #elif defined(IOMTYPE_DO)
        DO_SYNC_VERSION;
        #elif defined(IOMTYPE_LLMUX)
        LL_SYNC_VERSION;
        #elif  defined(IOMTYPE_SVP)
        SVP_SYNC_VERSION;
        #elif  defined(IOMTYPE_SP)
        SP_SYNC_VERSION;
        #elif defined(IOMTYPE_PI)
        PI_SYNC_VERSION;
        #elif defined(IOMTYPE_UIO)
        UIO_SYNC_VERSION;
        #endif

    // Put the next message number in the second byte of SYNCVER
    Data.ucBytes[1] = 1 + GetMesNo();

    // Calculate the redundancy checksum for all channels
    // And put it in the last two bytes of SYNVER
    Data.ui16Val[1] = BOX->ComputeRedCheckSum();
    for (ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
        Data.ui16Val[1] += SLOT(ucSlotNum)->ComputeRedCheckSum();
    }

#if defined(PMIO_DEBUG) && (0)
    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString("\r\nSVCSM: 0x%04x", Data.ui16Val[1]));
    if (ucDbgPnt == RDCM_DBGPNT) ucDbgPnt = 0;
#endif

    // SyncVer parameter may not be aligned in even byte boundary.
    // A byte comparison is required. Log the new checksum if it is changed.
    if ((SyncVer[2] != Data.ucBytes[2]) || (SyncVer[3] != Data.ucBytes[3])) {

#if defined(PMIO_DEBUG) && (0)
        if (ucDbgPnt == SVCM_DBGPNT)
        {
            ucDbgPnt = RDCM_DBGPNT;
            // Calculate the redundancy checksum for all channels
            // And put it in the last two bytes of SYNVER
            Data.ui16Val[1] = BOX->ComputeRedCheckSum();

            for (ucSlotNum = 1; ucSlotNum <= MAXSLOTS; ucSlotNum++) {
                Data.ui16Val[1] += SLOT(ucSlotNum)->ComputeRedCheckSum();
            }

            ucDbgPnt = SVCM_DBGPNT;
        }
#endif
        //TraceLog.AddToTrace(TRACEID_GENERIC,bcSyncVer,Data.ui32Val);
    }

    return PA_OK;
}

/*******************************************************************************
*                           clsBoxSlot::HartLoopBackTest                       *
*                           ============================                       *
* PURPOSE: Tests the Hart modems and UARTS of in Analog Module                 *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
#if 0 //(defined(IOMTYPE_AIH) || defined(IOMTYPE_AOH)) && !LOWCOST
RETURNSTATUS clsBoxSlot::HartLoopBackTest(VOID) {
    static BOOL  sbLoopbackSuccess;
    static UINT8 sucXmtModem,sucXmtChan,sucRcvModem,sucRcvCount,sucPreambleCount;
    static CONTEXT Context = CONTEXT_ZERO;

#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
    static char s_cInputBuffer[SMALL_INPUT_BUFFER_SIZE];
    FLOAT32 fOp;
#endif
#endif

    UINT16 usMuxAddr;
    UINT8  ucCount,ucStatus,ucData;
    RETURNSTATUS RtnSts = RETURNSTATUS_INPROGRESS;

    switch (Context) {
    case CONTEXT_ZERO:
        BOX->SetLpBkStat(LOOPBACK_RUNNING);
        sucXmtModem = 0;
        sucXmtChan  = 0;
        sucRcvModem = 0;
        sucRcvCount = 0;

        TPU2_CST = 0; // Stop HART modem heartbeat timer.
        // Abort HART transaction going on if any
        for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {
            AbortHartConnection(ucCount);
        }
        
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.PrintString("\n\rHART Loopback");
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
        break;
   case CONTEXT_ONE:
#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.PrintString("...OP :");
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
#else //IOMTYPE_AIH
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
        break;
    case CONTEXT_TWO:
#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.GetInput(s_cInputBuffer,SMALL_INPUT_BUFFER_SIZE);
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif  
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif
        break;
    case CONTEXT_THREE:
#ifdef IOMTYPE_AOH
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        fOp = atof(s_cInputBuffer);
        if (!isnan(fOp) && (fOp >= OP_LOLIMIT) && (fOp <= OP_HILIMIT)) {
            for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {
                BOX->SetOp(ucCount,fOp);
            }
        }
        else {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(PRINTSTRING_INVALID));
            Context = CONTEXT_TEN; // Abort the test.
            RtnSts = RETURNSTATUS_COMPLETE;
        }
#else // RELEASE BUILD in factory mode drive 50% OP
        for (ucCount = 1; ucCount <= MAXSLOTS; ucCount++) {
            ((clsAohBoxSlot *)pDatabase[0])->SetOp(ucCount,50.0);
        }
#endif
#endif
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_FOUR: // Prepare the hardware for the test.
        HART_MUXENBL.ALL_FOUR = 0; // Disable all four modem/multiplexors.
        for (ucCount = 0; ucCount < HARTMODEM_COUNT; ucCount++) { 
            // Reset modem and UART. This is to avoid the known FPGA problem
            // with break condition that we are working with Xilinx now.
            HART_UART(ucCount).RESET = 1; 
            // Modem control register - Disable RTS.
            HART_UART(ucCount).REQUEST_TO_SEND = 0;
            // Configure UART for 8 bits per character, odd parity and one stop bit.
            HART_UART(ucCount).BITS_PER_CHAR = HART_UART_8BITS_PER_CHAR;
            HART_UART(ucCount).PARITY_ENBL = 1; 
            HART_UART(ucCount).INTR_ENBL_REGISTER = 0;
            HART_UART(ucCount).REQUEST_TO_SEND = 0;
            HART_UART(ucCount).FIFO_ENBL = 1;
            HART_UART(ucCount).XMT_FIFO_CLEAR = 1;
            HART_UART(ucCount).RCV_FIFO_CLEAR = 1;
        }
        // Reprogram baud rate register
        HART_BAUDRATE_REGISTER.LOBYTE = 0xE2;
        HART_BAUDRATE_REGISTER.HIBYTE = 0x04;

#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        RtnSts = DebugPort.PrintString("\n\r  Xmt modem %d chan %d",
                 (sucXmtModem + 1),(sucXmtChan + 1));
#else
        RtnSts = RETURNSTATUS_COMPLETE;
#endif

        break;
    case CONTEXT_FIVE: // Transmit context.
        usMuxAddr = sucXmtChan;
        for (ucCount = 0; ucCount < (HARTMODEM_COUNT - 1); ucCount++) {
            usMuxAddr <<= HARTMODEM_COUNT;
            usMuxAddr |= sucXmtChan;
        }

        HART_MUXADDR = usMuxAddr;
        IdleWait(1); // Wait one mirco second for the MUX address to settle.
        HART_MUXENBL.ALL_FOUR = HART_ENABLE_ALL_MUXES;

        // Wait for 33 character times (link quiet time) before RTS is asserted.
        ucStatus = get_imask_exr();
        set_imask_exr(LVLPRI_IOPROC);
        for (ucCount = 0; ucCount < HART_PRIMARY_QUIET_TIME; ucCount++) {
            IdleWait(HART_BYTE_TIME);
        }
        set_imask_exr(ucStatus);
        
        HART_UART(sucXmtModem).REQUEST_TO_SEND = 1;
        // Transmit using the test modem
        for (ucCount = 0; ucCount < HART_LOOPBACK_SIZE+2; ucCount++) { 
            if (ucCount < 2) { // Transmit two preamble bytes
                HART_UART(sucXmtModem).XMTHOLD_REGISTER = HART_PREAMBLE_BYTE;
            }
            else { // Then transmit the loopback test pattern
                HART_UART(sucXmtModem).XMTHOLD_REGISTER = HART_LOOPBACK_PATTERN[ucCount-2];
            }
        }
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    case CONTEXT_SIX:
        // Wait until all characters are transmitted
        if (HART_UART(sucXmtModem).XMT_COMPLETE == 0) {
            RtnSts = RETURNSTATUS_INPROGRESS;
        }
        else {
            HART_UART(sucXmtModem).REQUEST_TO_SEND = 0;
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
            RtnSts = DebugPort.PrintString("...done");
#else
            RtnSts = RETURNSTATUS_COMPLETE;
#endif
        }
        break;
    case CONTEXT_SEVEN:
        while (sucRcvModem < HARTMODEM_COUNT){
            if (sucRcvModem == sucXmtModem) { // Do not test the transmit modem
                sucRcvModem++;
                if (HARTMODEM_COUNT == sucRcvModem) {
                    sucRcvModem = 0;
                    Context = CONTEXT_NINE; 
                    RtnSts = RETURNSTATUS_COMPLETE;
                    break;
                }
            }
            // Wait until the carrier drops.
            if (HART_UART(sucRcvModem).CARRIER_DETECT != 0) {
                //RtnSts = RETURNSTATUS_INPROGRESS;
                continue;
            }
            else {
                sucRcvCount = 0;
                sucPreambleCount = 0;
                sbLoopbackSuccess = TRUE;
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                RtnSts = DebugPort.PrintString("\n\r\tChecking modem %d Rcvbuffer",(sucRcvModem+1));
#endif
            }
            while(sucRcvCount < HART_LOOPBACK_SIZE){
                if (HART_UART(sucRcvModem).DATA_READY) {
                    ucStatus = HART_UART(sucRcvModem).LINE_STS_REGISTER;
                    ucData = HART_UART(sucRcvModem).RCVBUF_REGISTER;
                    if ((sucRcvCount == 0) && (HART_LOOPBACK_PATTERN[0] != ucData)) {
                        sucPreambleCount++;
                        if (sucPreambleCount <= 2) {
                            // Wait until loopback pattern begins
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" %x",ucData));
#endif
                            //return RETURNSTATUS_INPROGRESS;//changedTD1
                            continue;
                        }
                        else { // Did not find start of the pattern.
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" %x abort",ucData));
#endif
                            sbLoopbackSuccess = FALSE;
                            Context = CONTEXT_NINE;
                            return RETURNSTATUS_INPROGRESS;
                        }
                    }
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
                    while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" %x",ucData));
#endif
                    if ((HART_LOOPBACK_PATTERN[sucRcvCount] != ucData) ||
                        (ucStatus & HART_UART_LINE_STS_ERROR_BITS)) {
                        sbLoopbackSuccess = FALSE;
                        Context = CONTEXT_NINE; 
                        return RETURNSTATUS_INPROGRESS;
                    }
                    sucRcvCount++;
                }//DATA_READY
                else {
                        if (sucRcvCount != HART_LOOPBACK_SIZE) {
                            sbLoopbackSuccess = FALSE;
                            Context = CONTEXT_NINE;
                            return RETURNSTATUS_INPROGRESS;
                        }
                }
             }//Rcvcount while loop
            sucRcvModem++;
        }//RcvModem while loop
        if(HARTMODEM_COUNT == sucRcvModem){
            sucRcvModem = 0;
            Context = CONTEXT_NINE; 
            RtnSts = RETURNSTATUS_COMPLETE;
        }
        break;
    case CONTEXT_NINE:
#if defined(DEBUG) && defined(IOPTYPE_SCIOM)
        if (TRUE == sbLoopbackSuccess) {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" Passed"));
        }
        else 
        {
            while (RETURNSTATUS_INPROGRESS == DebugPort.PrintString(" Failed"));
        }
#endif
        if(FALSE == sbLoopbackSuccess){
            BOX->SetLpBkStatXmtModem(sucXmtModem);
            BOX->SetLpBkStatRcvModem(sucRcvModem);
            BOX->SetLpBkStatChan(sucXmtChan);
            Context = CONTEXT_TEN; // Exit the test
            RtnSts = RETURNSTATUS_COMPLETE;
            break;
        }
//#endif
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
   case CONTEXT_TEN:
        sucXmtChan++;
        if (MAXSLOTS == sucXmtChan) {
            sucXmtChan = 0;
            sucXmtModem++;
            if (HARTMODEM_COUNT == sucXmtModem) {
                RtnSts = RETURNSTATUS_COMPLETE;
                break;
            }   
        }
        Context = CONTEXT_THREE;
        RtnSts = RETURNSTATUS_COMPLETE;
        break;
    default:
        Context = CONTEXT_TEN;
        RtnSts = RETURNSTATUS_COMPLETE;
    }

    if (RtnSts == RETURNSTATUS_COMPLETE) {
        Context = (CONTEXT)((UINT8)Context + 1);
        if (Context > CONTEXT_TEN) {
            //if the test has passed successfully for all channels and modems
            
            if (TRUE == sbLoopbackSuccess){
                BOX->SetLpBkStat(LOOPBACK_SUCCESS);
            }
            HART_MUXENBL.ALL_FOUR = 0; // Disable all four modem/multiplexors.
            
            for (ucCount = 0; ucCount < HARTMODEM_COUNT; ucCount++) { 
                HART_UART(ucCount).INTR_ENBL_REGISTER = 0;
                HART_UART(ucCount).REQUEST_TO_SEND = 0;
                HART_UART(ucCount).XMT_FIFO_CLEAR = 1;
                HART_UART(ucCount).RCV_FIFO_CLEAR = 1;
            }
            HartLoopBkTestInProgress = FALSE;
            Context = CONTEXT_ZERO;
            TPU2_CST = 1; // Restart HART modem heartbeat timer.
            return RETURNSTATUS_COMPLETE;
        }
    }
    return RETURNSTATUS_INPROGRESS;
}
#endif
/*******************************************************************************
*                           clsBoxSlot::FlashHWRevCode()                       *
*                           ============================                       *
* PURPOSE: Writes HWREVCODE and SERIAL_NO into flash in factory mode           *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
#if 1 //ndef DEBUG
BOOL clsBoxSlot::FlashHWRevCode(VOID) {
#if 0 // temp for testing
    UINT8 *ucBufferPtr;
    UINT8 *ModuleInfoTopBufferPtr;
    UINT8 *ModuleInfoBottomBufferPtr;
    volatile UINT8 *ModuleInfoTopFlashPtr  = (UINT8 *)MODULEINFO_START_ADDRESS;//0x00007000
    volatile UINT8 *ModuleInfoBottomFlashPtr = (UINT8 *)(MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1); //0x00007FFF
    UINT8 HwRevCode[sizeof(UINT16)];
    UINT8 SubCommand;
    UINT8 SerialNoPtr[sizeof(UINT32)];
    UINT8 ProductCode[sizeof(UINT16)];
    UINT8 ProductType[sizeof(UINT16)];

    //Get the HWREV CODE from the Rcvr Buffer
    ucBufferPtr = WriteMsgQueue.GetRcvBufPtr();// get ptr to rcv buffer

    SubCommand = ucBufferPtr[IOLREQ_SUBCMD];

    switch (SubCommand){
    case UPDT_HWVER_NO:
        HwRevCode[0] = ucBufferPtr[IOLREQ_HWREVDATA];
        HwRevCode[1] = ucBufferPtr[IOLREQ_HWREVDATA + 1];
        break;
    case UPDT_SERIAL_NO:
        for( UINT8 i= 0 ; i < sizeof(UINT32);i++)
          SerialNoPtr[i] = ucBufferPtr[IOLREQ_SERNO + i];
        break;
    case UPDT_PROD_CODE:
        ProductCode[0] = ucBufferPtr[IOLREQ_PRODCODE];
        ProductCode[1] = ucBufferPtr[IOLREQ_PRODCODE + 1];
        break;
    case UPDT_PROD_TYPE:
        ProductType[0] = ucBufferPtr[IOLREQ_PRODTYPE];
        ProductType[1] = ucBufferPtr[IOLREQ_PRODTYPE + 1]; 
        break;
    default:
        return FALSE;
    }

    //Since the Digital Module do not have memory, the write message queue memory
    //is utilized. Since this module is rebooted after the operation, this approach
    //should not have any adverse effect.
    ucBufferPtr = WriteMsgQueue.GetMsgBufferPtr();// get ptr to Write Messege Queue
    ModuleInfoTopBufferPtr = ucBufferPtr;
    //Top buffer should be at least 10+256+16 bytes. Therefore Bottom buffer starts 
    //after 384bytes (3*128).
    ModuleInfoBottomBufferPtr = ucBufferPtr + (3*FLASH_PROGRAM_BLOCK_SIZE);

    //Copy the data from ModuleInfoTop Block
    ucBufferPtr = ModuleInfoTopBufferPtr;
    for (UINT16 ucCount = 0; ucCount < (3*FLASH_PROGRAM_BLOCK_SIZE); ucCount++){
        *ucBufferPtr = *ModuleInfoTopFlashPtr;
        ucBufferPtr++;
        ModuleInfoTopFlashPtr++;
    }


    //Copy the data from ModuleInfo Bottom Block
    ucBufferPtr = ModuleInfoBottomBufferPtr;
    for (UINT8 ucCount = 0; ucCount < FLASH_PROGRAM_BLOCK_SIZE; ucCount++){
        *ucBufferPtr = *ModuleInfoBottomFlashPtr;
        ucBufferPtr++;
        ModuleInfoBottomFlashPtr++;
    }        

    // Fill the data received in the top of the module info block.
    ucBufferPtr = ModuleInfoTopBufferPtr;
    switch (SubCommand){
    case UPDT_HWVER_NO:
        ucBufferPtr += HWREV_CODE_ADDR_OFFSET;
        *((UINT8*)ucBufferPtr) = HwRevCode[0];
        ucBufferPtr++;
        *((UINT8*)ucBufferPtr) = HwRevCode[1];
        break;
    case UPDT_SERIAL_NO:
        ucBufferPtr += HW_SL_NO_ADDR_OFFSET;
        for( UINT8 i= 0 ; i < sizeof(UINT32);i++){
            *((UINT8 *)ucBufferPtr) = SerialNoPtr[i];
            ucBufferPtr++;
        }
        break;
    case UPDT_PROD_CODE:
        ucBufferPtr += HW_PROD_CODE_OFFSET;
        *((UINT8*)ucBufferPtr) = ProductCode[0];
        ucBufferPtr++;
        *((UINT8*)ucBufferPtr) = ProductCode[1];
        break;
    case UPDT_PROD_TYPE:
        ucBufferPtr += HW_PROD_TYPE_OFFSET;
        *((UINT8*)ucBufferPtr) = ProductType[0];
        ucBufferPtr++;
        *((UINT8*)ucBufferPtr) = ProductType[1];
        break;
    default:
        return FALSE;
    }

    // Fill information at the bottom of module info block.
    ucBufferPtr = ModuleInfoBottomBufferPtr + FLASH_PROGRAM_BLOCK_SIZE - CRC_LOC_OFFSET;
    *((UINT16 *)ucBufferPtr) = 0; // Replace this CRC value later.


    //MODULEINFO_WRITE_FLAGS 
    ucBufferPtr+=sizeof(UINT16);
    *((UINT16 *)ucBufferPtr) = MODULINFO_WRITE_COMPLETE;

    // Program number of times module info section is programmed.
    ucBufferPtr+=sizeof(UINT16);
    *((UINT16 *)ucBufferPtr) =  MODULEINFO_WRITECOUNT + 1;
    if (0 == *((UINT16 *)ucBufferPtr)) {
        *((UINT16 *)ucBufferPtr) = 1;
    }


    if (EraseFlash(MODULE_INFO_FLASH_BLOCK)) {
#if H8S_2319C
        if (ProgramFlash(MODULEINFO_START_ADDRESS,ModuleInfoTopBufferPtr)) {
#else
        if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS,ModuleInfoTopBufferPtr)) {
#endif
#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_SVP)|| defined(IOMTYPE_SP)|| defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
            if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS + FLASH_PROGRAM_BLOCK_SIZE,
                ModuleInfoTopBufferPtr + FLASH_PROGRAM_BLOCK_SIZE)) {
                if (ProgramFlash((UINT8 *)MODULEINFO_START_ADDRESS + 2*FLASH_PROGRAM_BLOCK_SIZE,
                    ModuleInfoTopBufferPtr + 2*FLASH_PROGRAM_BLOCK_SIZE)) {
#endif
#if H8S_2319C
                    if (ProgramFlash((MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1),
                        ModuleInfoBottomBufferPtr)) {
#else
                    if (ProgramFlash((UINT8 *)(MODULEINFO_END_ADDRESS - FLASH_PROGRAM_BLOCK_SIZE + 1),
                        ModuleInfoBottomBufferPtr)) {
#endif
                        return TRUE;
                    }
#if(defined(IOMTYPE_AOH) || defined(IOMTYPE_AIH) || defined(IOMTYPE_SVP)||defined(IOMTYPE_SP)|| defined(IOMTYPE_PI) || defined(IOMTYPE_UIO))
                }
            }
#endif
        }
    }
#endif // temp for testing
    return FALSE;
}
#endif //#ifndef DEBUG

/*******************************************************************************
*                            clsBoxSlot::PreCPLDRegData                        *
*                            ======================                            *
* PURPOSE: Pre Receiver-Beware function for CPLDRegData parameter              *
*                                                                              *
* ARGUMENTS:a_Writebuffer   -   Pointer to the data to be written.             *
*           a_ucAccLvl      -   Access level for check                         *
*                                                                              *
* RETURN:  PA_OK           -   If pre check is succesfull                      *
* NOTES:                                                                       *
*                                                                              *
*******************************************************************************/
PASTATUS clsBoxSlot::PreCPLDRegData(UINT8 *a_Writebuffer,UINT8 ){
	if(*(UINT8 *)a_Writebuffer > RSR_MAX) { //Selected Register is greater than max.RSR ,15
		return DO_LIMIT_OR_RANGE_EXCEEDED;
	}

	return PA_OK;
}

/*******************************************************************************
*                           clsBoxSlot::PostCPLDRegData                        *
*                           ========================                           *
* PURPOSE:   Post Receiver-Beware function for CPLDRegData parameter           *
* ARGUMENTS:                                                                   *
* RETURN:                                                                      *
* NOTES:                                                                       *
*******************************************************************************/
VOID clsBoxSlot::PostCPLDRegData(UINT8) {
#if 0 //!AIAO
   	CPLDRegData = GetReadbackRegister(CPLDRegData);
#endif
#if LOWCOST
   	CPLDRegData = ReadCPLDRegister(CPLDRegData);
#endif
}
/*******************************************************************************
*                                    isOddParity                               *
*                                    ===========                               *
* PURPOSE   : Test for odd no of 1's in a binary number.                       *
* ARGUMENTS : UINT8 - variable to be tested.                                   *
* RETURN    : TRUE if the variable is ODD, else FALSE.                         *
* NOTES     :                                                                  *
*******************************************************************************/
BOOL clsBoxSlot::isOddParity(UINT8 ucBinary)
{
    BOOL bParity = 0;

    while (ucBinary)
    {
        bParity = !bParity;

        ucBinary &= (ucBinary - 1);
    }

    return bParity;
}

/*******************************************************************************
*                              SetFactoryTestMode                              *
*                              ==================                              *
* PURPOSE   : Check factory test hardware and set factory test bit accordingly *
* ARGUMENTS : NONE                                                             *
* RETURN    : NONE                                                             *
* NOTES     :                                                                  *
*******************************************************************************/
VOID clsBoxSlot::SetFactoryTestMode(VOID)
{
	UINT8 iotabits = Fpga.GetIotaRegister();

    ModStat1.Factory = 0;

	// if REDUNT_n=1 (FTA missing), BOTTOM=0 (IOPB) & BUPREQ_IN=0(SWITCHED=0), set IOP in Factory Test Mode.
    if ((TRUE  == (iotabits & FPGA_IOTA_REDUNT_n))      // FTA missing
    &&  (FALSE == (iotabits & FPGA_IOTA_BOTTOM))        // IOP is on bottom (IOPB)
    &&  (FALSE == (iotabits & FPGA_IOTA_BUPREQ_IN))) {  // Backup request is not asserted
        
        ModStat1.Factory = 1;
    }
}

