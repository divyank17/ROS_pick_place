/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hardfail.cpp                                                *
*    Description : HardFail handler for RT1024/QEMU.                           *
*                  On unrecoverable error:                                     *
*                    1. Disables interrupts                                    *
*                    2. Logs crash info to trace memory                        *
*                    3. Copies crash trace block                               *
*                    4. Asserts backup request (redundancy)                    *
*                    5. Halts (or returns in debug/test modes)                 *
********************************************************************************/

#include "datatype.h"
#include "hardfail.h"

#if IOMTYPE_AIH
#include "aihmain.h"
#endif

/* WRDB bad-command context captured right before HardFail in wrdbtask.cpp */
extern volatile UINT8 g_wrdb_bad_cmd;
extern volatile UINT8 g_wrdb_bad_msg_num;
extern volatile UINT8 g_wrdb_bad_msg_sz;
extern volatile UINT8 g_wrdb_bad_slot;
extern volatile UINT8 g_wrdb_bad_param;
extern volatile UINT8 g_wrdb_bad_dtype;
extern volatile UINT8 g_wrdb_bad_acclvl;

/*******************************************************************************
*                              HardFail                                        *
*                              ========                                        *
* PURPOSE:                                                                     *
*    Handle unrecoverable system error.  Disables interrupts, logs crash info  *
*    to trace memory, copies crash block, then halts.                          *
* ARGUMENTS:                                                                   *
*    a_HfCode : hard failure type (HARDFAILTYPE enum).                         *
*    a_FlIdx  : source file index (FILE_NAME enum).                            *
*    a_LnNo   : source line number.                                            *
*    a_Parm1  : diagnostic parameter 1 (default 0).                            *
*    a_Parm2  : diagnostic parameter 2 (default 0).                            *
* RETURN:                                                                      *
*    None — does not return (halts in an infinite loop).                       *
* NOTES:                                                                       *
*    RT1024 CHANGES: Uses HAL for interrupt mask and status LED.               *
*******************************************************************************/
void HardFail(HARDFAILTYPE a_HfCode, FILE_NAME a_FlIdx, UINT16 a_LnNo,
              UINT8 a_Parm1, UINT8 a_Parm2)
{
#if defined(UNIT_TEST_BUILD)
    /* In unit tests: just log and return so tests can verify the call */
    TraceLog.AddToTrace(TRACEID_GENERIC, bcHardFail1,
                        ((UINT32)a_HfCode << 24) |
                        ((UINT32)a_FlIdx  << 16) |
                        (UINT32)a_LnNo);
    TraceLog.AddToTrace(TRACEID_GENERIC, bcHardFail2,
                        ((UINT32)a_Parm1  << 8) |
                        (UINT32)a_Parm2);
    return;

#elif defined(QEMU_BUILD)
    /* In QEMU: log the crash, copy crash block, then halt */
    hal_interrupt_set_mask(LVLPRI_HIGHEST);

    TraceLog.AddToTrace(TRACEID_GENERIC, bcHardFail1,
                        ((UINT32)a_HfCode << 24) |
                        ((UINT32)a_FlIdx  << 16) |
                        (UINT32)a_LnNo);
    TraceLog.AddToTrace(TRACEID_GENERIC, bcHardFail2,
                        ((UINT32)a_Parm1  << 8) |
                        (UINT32)a_Parm2);

    TraceLog.CopyCrashTraceBlock();

    /* Persist crash block + health stats to flash */
#ifdef MAKE_CRASH_BLOCK
    SaveCrashBlock(a_HfCode, (UINT8)a_FlIdx, a_LnNo, a_Parm1, a_Parm2);
#endif

    /* Print crash info to debug UART if available */
    hal_uart_puts(HAL_UART_DEBUG, "\r\n*** HARD FAIL ***\r\n");

    /* Halt — QEMU can be inspected via GDB at this point */
    while (1) {
        NOP;
    }

#else /* RT1024_BUILD */
    /* Mask all maskable interrupts (including SysTick/STC) immediately so the
     * scheduler's DMC countdown and every other ISR stop dead here. Without
     * this, SysTick keeps ticking while we spin below, task DMC counters run
     * out because nothing services them anymore, and a *second* cascading
     * HardFail(HF_DMCTIMEOUT, SCHEDULER_CPP, ...) fires from inside the
     * SysTick ISR — masking the real, original fault. (QEMU_BUILD above
     * already did this; RT1024_BUILD had it commented out.) */
    hal_interrupt_set_mask(LVLPRI_HIGHEST);

    /* Disable IOL transmitter */
    hal_gpio_write(HAL_PIN_IOL_TX_EN, FALSE);

    /* Assert backup request (redundancy failover) */
    hal_gpio_write(HAL_PIN_BUPREQ_OUT, 0);

    BOX->SetFailCode(a_HfCode);

    /* Report the fault unconditionally so it can actually be identified —
     * previously nothing was printed/shown here and the module just hung,
     * making any HardFail() (e.g. HF_IOLJABBERFIRED) indistinguishable from
     * any other silent lockup. */
    PRINTF("\r\n*** HARD FAIL *** code=%d file=%d line=%d p1=%d p2=%d\r\n",
           (int)a_HfCode, (int)a_FlIdx, (int)a_LnNo, (int)a_Parm1, (int)a_Parm2);

    if ((a_HfCode == HF_BADPROGRAMJUMP) && (a_FlIdx == WRDBTASK_CPP)) {
        PRINTF("WRDB ctx cmd=%d msgNum=%d msgSize=%d slot=%d param=%d dtype=%d acclvl=%d\r\n",
               (int)g_wrdb_bad_cmd,
               (int)g_wrdb_bad_msg_num,
               (int)g_wrdb_bad_msg_sz,
               (int)g_wrdb_bad_slot,
               (int)g_wrdb_bad_param,
               (int)g_wrdb_bad_dtype,
               (int)g_wrdb_bad_acclvl);
    }

    /* Solid RED status LED — visible even with no debug terminal attached. */
    // hal_fpga_set_led(FALSE, TRUE); // handling in BlinkLEDInterruptHandler()

    /* Log crash information in trace memory */
    //TraceLog.AddToTrace(TRACEID_GENERIC, bcHardFail1,
    //                    ((UINT32)a_HfCode << 24) |
    //                    ((UINT32)a_FlIdx  << 16) |
    //                    (UINT32)a_LnNo);
    //TraceLog.AddToTrace(TRACEID_GENERIC, bcHardFail2,
    //                    ((UINT32)a_Parm1  << 8) |
    //                    (UINT32)a_Parm2);

    /* Copy last 20 traces to crash block */
    //TraceLog.CopyCrashTraceBlock();

    /* Persist crash block + health stats to external flash */
#ifdef MAKE_CRASH_BLOCK
    SaveCrashBlock(a_HfCode, (UINT8)a_FlIdx, a_LnNo, a_Parm1, a_Parm2);
#endif

#if !defined(CRASH_TO_ALIVE)
    /* Assert DIAGFAIL to take down the module */
    /* On RT1024 this triggers the watchdog, ensuring the module resets */
    //hal_wdt_enable();
#else
    /* CRASH_TO_ALIVE: do NOT assert DIAGFAIL or trip WDT.
     * Module stays in while(1) loop — use GDB breakpoint here for debug.
     * (Crash LED/PRINTF already reported above.) */
#endif

    while (1) {
        NOP;
    }
#endif
}
