/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : fpga.hpp                                                    *
*    Description : RT1024 / QEMU hardware abstraction.                         *
*                  Replaces the H8S register definitions with HAL calls.       *
*                  This file is included by legacy code that expects it.       *
*******************************************************************************/

#ifndef __FPGA_HPP__
#define __FPGA_HPP__

#include "datatype.h"
/*******************************************************************************
*                                    clsFpga                                   *
*                                    =======                                   *
*******************************************************************************/
class ClsFpga {    

public:
    ClsFpga(VOID) {
        ;
    }
    ~ClsFpga(VOID);

    //VOID *operator new (SIZE_T)  { return NULL; }
    //VOID operator delete(VOID *) { HardFail(HF_INVPROGRAMEXEC, FPGA_HPP, __LINE__); }

    UINT8 GetIotaRegister(VOID);
    UINT8 GetMiscRegister(VOID);
    UINT8 GetModnumRegister(VOID);
    UINT8 GetRevLetter(VOID);
    UINT8 GetRevNumber(VOID);

};  // ClsFpga

extern ClsFpga Fpga;

#endif /* __FPGA_HPP__ */
