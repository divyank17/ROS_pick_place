/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : datatype.h                                                  *
*    Description : Datatypes declations.                                       *
*******************************************************************************/
#ifndef __DATATYPE_H__
#define __DATATYPE_H__

/* Ensure bool is available in C mode */
#ifndef __cplusplus
#include <stdbool.h>
#endif

/*******************************************************************************
*                             TYPES AND ENUMERATIONS                           *
*******************************************************************************/
typedef void            VOID;
typedef bool            BOOL;
typedef char            CHAR;
typedef signed char     INT8;
typedef unsigned char   UINT8;
typedef unsigned char   BLIND;
typedef int             INT;
typedef unsigned int    UINT;
typedef short           INT16;
typedef unsigned short  UINT16;
typedef long            INT32;
typedef unsigned long   UINT32;
typedef float           FLOAT32;
typedef double          FLOAT64;

#ifndef _APP_SIZE_T
#define _APP_SIZE_T
typedef unsigned long   SIZE_T;
#endif

typedef struct tagUInt64 {
    UINT32 ulDwordHi;
    UINT32 ulDwordLo;
} UINT64;

typedef union tagNaN {
    UINT32  ulDword;
    FLOAT32 fVal;
} NANINIT;

typedef union tagDNaN {
    UINT64  uqWord;
    FLOAT64 dVal;
} DNANINIT;

typedef union tagDataBytes {
    INT16   i16Val[2];
    UINT16  ui16Val[2];
    INT32   i32Val;
    UINT32  ui32Val;
    FLOAT32 f32Val;
    UINT8   ucBytes[sizeof(FLOAT32)];
} DATABYTES;
/*******************************************************************************
*                                   CONSTANTS                                  *
*******************************************************************************/
#ifndef NULL
#ifdef __cplusplus
#define NULL 0
#else
#define NULL ((void *)0)
#endif
#endif

#define NULLCHAR  '\0'
#define ENABLE    1
#define DISABLE   0

#define MAXUINT8  0xFF
#define MAXUINT16 0xFFFF
#define MAXUINT32 0xFFFFFFFF

/* In C, const has external linkage — use static to avoid multiple defs */
#ifdef __cplusplus
#define DT_CONST const
#else
#define DT_CONST static const
#endif

DT_CONST UINT8 LONIBBLE = 0x0F;
DT_CONST UINT8 HINIBBLE = 0xF0;
DT_CONST UINT8 BYTESIZE = 8;
DT_CONST UINT8 WORDSIZE = 16;

#ifdef __cplusplus
const BOOL FALSE = false;
const BOOL TRUE = true;
const BOOL TRUE_n = false;
const BOOL FALSE_n = true;
const BOOL ASSERTED = true;
const BOOL DEASSERTED = false;
const BOOL ASSERTED_n = false;
const BOOL DEASSERTED_n = true;
#else
/* In C, const variables can't be used as initializers, so use macros */
#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif
#define TRUE_n      0
#define FALSE_n     1
#define ASSERTED    1
#define DEASSERTED  0
#define ASSERTED_n  0
#define DEASSERTED_n 1
#endif

DT_CONST UINT32 SIGNL_NAN        = 0x7FFFFFFF;
DT_CONST UINT32 TESTNAN_EXPONENT = 0x7F800000;
DT_CONST UINT32 TESTNAN_MANTISSA = 0x007FFFFF;
DT_CONST UINT32 SIGNL_DNAN_HI    = 0x7FFFFFFF;
DT_CONST UINT32 SIGNL_DNAN_LO    = 0xFFFFFFFF;
DT_CONST UINT32 TESTDNAN_EXPONENT_HI = 0x7FF00000;
DT_CONST UINT32 TESTDNAN_EXPONENT_LO = 0x00000000;
DT_CONST UINT32 TESTDNAN_MANTISSA_HI = 0x000FFFFF;
DT_CONST UINT32 TESTDNAN_MANTISSA_LO = 0xFFFFFFFF;

extern NANINIT NaNInit;
#define NaN NaNInit.fVal
#if defined(IOMTYPE_PI)
extern DNANINIT DNaNInit;
#define DNaN DNaNInit.dVal
#endif

/*******************************************************************************
*                     PLACEMENT NEW (freestanding C++)                          *
*  Use the toolchain declaration from <new> to avoid duplicate definitions.    *
*******************************************************************************/
#ifdef __cplusplus
#include <new>
#endif

#endif
