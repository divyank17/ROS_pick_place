/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_timer.h                                                 *
*    Description : Timer abstraction interface.                                *
*                  Abstracts the system tick (STC) timer and application       *
*                  timers that were previously TPU channels on the H8S.        *
*                                                                              *
*    H8S:    TPU5 (10ms STC), TPU0 (PPX 3.125ms), TPU2 (HART heartbeat),     *
*            TPU3 (LED blink), TPU4 (IOL silence timer)                        *
*    LPC17xx: RIT (STC), TIM0/1/2 (app timers)                                *
*    RT1024:  SysTick (STC), PIT/GPT (app timers)                             *
*    QEMU:    SysTick (via CMSDK)                                             *
*******************************************************************************/
#ifndef HAL_TIMER_H
#define HAL_TIMER_H

#include "hal_platform.h"
#include "datatype.h"

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
*                          STC (System Tick Counter)                            *
*  10ms scheduler tick — replaces H8S TPU5 / LPC17xx RIT                       *
*******************************************************************************/

/**
 * @brief Initialize and start the STC (10ms scheduler tick timer).
 * 
 * Platform mapping:
 *   RT1024:  SysTick_Config(SystemCoreClock / 100)
 *   QEMU:    SysTick via CMSDK (25 MHz / 100 = 250000 ticks)
 *   UnitTest: Software counter (no hardware timer)
 */
void hal_stc_init(void);

/**
 * @brief Check if STC timer is running.
 */
BOOL hal_stc_is_running(void);

/**
 * @brief Get current STC count value.
 *        On SysTick this reads the CURRENT register (counts DOWN from reload).
 */
UINT32 hal_stc_get_count(void);

/**
 * @brief Get STC reload value (period in ticks).
 */
UINT32 hal_stc_get_reload(void);

/*******************************************************************************
*                        APPLICATION TIMERS                                    *
*  Replaces H8S TPU0 (PPX), TPU2 (HART heartbeat), TPU3 (LED), TPU4 (IOL)   *
*******************************************************************************/

typedef enum {
    HAL_TIMER_PPX       = 0,  /**< PPX interrupt (ADC scan, 3.125ms for AIH)  */
    HAL_TIMER_HART_HB   = 1,  /**< HART modem heartbeat timer                 */
    HAL_TIMER_LED_BLINK = 2,  /**< Status LED blink timer                     */
    HAL_TIMER_IOL_SIL   = 3,  /**< IOLink silence timer                       */
    HAL_TIMER_COUNT     = 4
} HAL_TIMER_ID;

typedef void (*hal_timer_callback_t)(void);

/**
 * @brief Configure an application timer with a periodic interrupt.
 * @param timer_id   Which timer to configure
 * @param period_us  Period in microseconds
 * @param callback   ISR callback function
 */
void hal_timer_configure(HAL_TIMER_ID timer_id, UINT32 period_us, 
                         hal_timer_callback_t callback);

/**
 * @brief Start an application timer.
 */
void hal_timer_start(HAL_TIMER_ID timer_id);

/**
 * @brief Stop an application timer.
 */
void hal_timer_stop(HAL_TIMER_ID timer_id);

/**
 * @brief Read the current counter value of an application timer.
 * @param timer_id  Which timer to read
 * @return Current count in microseconds (free-running since last start/reset)
 */
UINT32 hal_timer_get_count(HAL_TIMER_ID timer_id);

/*******************************************************************************
*                        BUSY-WAIT COUNTER                                     *
*  Used by WDT factory test to measure expiry time.                            *
*  Replaces LPC17xx StartCounter/IsCounterArrived.                            *
*******************************************************************************/

/**
 * @brief Start a one-shot busy-wait counter with the given resolution (us).
 */
void hal_timer_start_counter(UINT16 resolution_us);

/**
 * @brief Check if the busy-wait counter has expired.
 */
BOOL hal_timer_counter_arrived(void);

/**
 * @brief Set the interrupt mask level.
 * @param level  H8S-convention level (0-7), OR a raw BASEPRI value (>7)
 *               returned from a previous call (for save/restore).
 *               0 = all enabled, 7 = block everything.
 * @return Previous raw BASEPRI value (pass back to restore).
 */
UINT32 hal_interrupt_set_mask(UINT32 level);

/**
 * @brief Get current raw BASEPRI value.
 */
UINT32 hal_interrupt_get_mask(void);

/**
 * @brief Disable all maskable interrupts.
 */
void hal_interrupt_disable_all(void);

/**
 * @brief Enable all maskable interrupts (restore to level 0).
 */
void hal_interrupt_enable_all(void);

/*******************************************************************************
*                          DELAY UTILITIES                                     *
*******************************************************************************/

/**
 * @brief Busy-wait delay in microseconds.
 * @param us  Number of microseconds to wait
 */
void hal_delay_us(UINT32 us);

/**
 * @brief Enable and initialize the Cortex-M7 DWT cycle counter.
 */
void hal_timer_init_dwt(void);

/**
 * @brief Busy-wait delay in milliseconds (calls hal_delay_us internally).
 */
static inline void hal_delay_ms(UINT32 ms)
{
    hal_delay_us(ms * 1000u);
}

#ifdef __cplusplus
}
#endif

#endif /* HAL_TIMER_H */
