/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_gpt.h                                                   *
*    Description : GPT abstraction interface.                                  *
*                                                                              *
*    Pin definitions will be provided later when RT1024 pin mapping is known.  *
*    For now, this defines the abstract interface and the logical signal names *
*    used by the application code.                                             *
*******************************************************************************/

#ifndef HAL_HAL_GPT_H_
#define HAL_HAL_GPT_H_

#include "hal_platform.h"
#include "datatype.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * GPT (General Purpose Timer) abstraction for RT1024.
 * The GPT peripheral is used for application timers that were previously
 */
typedef enum {
    HAL_GPT_IOL_SIL   = 0,  /**< IOLink silence timer                       */
    HAL_GPT_COUNT     = 1
} HAL_GPT_ID;

typedef void (*hal_gpt_callback_t)(void);

typedef struct
{
    UINT32 initCount;
    UINT32 startCount;
    UINT32 stopCount;
    UINT32 irqEntryCount;
    UINT32 irqOc1Count;
    UINT32 irqSpuriousCount;
    UINT32 cbCount;
    UINT32 lastFlags;
    UINT32 lastCnt;
    UINT32 lastCmp;
    UINT32 lastPeriodTicks;
} hal_gpt_dbg_t;

extern volatile hal_gpt_dbg_t g_hal_gpt_dbg;

/**
 * @brief Configure an application timer with a periodic interrupt.
 * @param timer_id   Which timer to configure
 * @param period_us  Period in microseconds
 * @param callback   ISR callback function
 */
void hal_gpt_configure(HAL_GPT_ID timer_id, UINT32 period_us, hal_gpt_callback_t callback);

/**
 * @brief Start an application timer.
 */
void hal_gpt_start(HAL_GPT_ID timer_id);

/**
 * @brief Stop an application timer.
 */
void hal_gpt_stop(HAL_GPT_ID timer_id);

VOID hal_gpt_rearm_us(HAL_GPT_ID gpt_id, UINT32 period_us);

/**
 * @brief Read current GPT counter value for the selected logical GPT timer.
 * @param gpt_id  Which GPT timer to read
 * @return Current count in microseconds (0 on invalid ID)
 */
UINT32 hal_gpt_get_count(HAL_GPT_ID gpt_id);

#ifdef __cplusplus
}
#endif

#endif /* HAL_HAL_GPT_H_ */
