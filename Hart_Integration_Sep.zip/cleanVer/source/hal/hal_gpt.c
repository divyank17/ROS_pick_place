/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_gpt.c                                                   *
*    Description : GPT abstraction implementation for iMXRT1024.               *
*                                                                              *
*    Pin assignments are derived from epicio_aih.mex (MCUXpresso Config).      *
*    This file is compiled ONLY for RT1024_BUILD.                              *
*******************************************************************************/
#include "hal_gpt.h"
#if defined(RT1024_BUILD)

#include "fsl_clock.h"
#include "fsl_gpt.h"

#define IOL_SIL_GPT                 GPT1
#define IOL_SIL_GPT_IRQn            GPT1_IRQn
#define IOL_SIL_GPT_IRQ_ENABLE      kGPT_OutputCompare1InterruptEnable
#define IOL_SIL_GPT_FLAG            kGPT_OutputCompare1Flag
#define IOL_SIL_GPT_CHANNEL         kGPT_OutputCompare_Channel1

/* Re-arm guard to avoid programming compare too close/in the past */
#ifndef HAL_GPT_MIN_REARM_GUARD_TICKS
#define HAL_GPT_MIN_REARM_GUARD_TICKS 8u
#endif

/* Silence timer callback and period for interrupt-based use */
static hal_gpt_callback_t s_gptCallbacks[HAL_GPT_COUNT];
static UINT32             s_gptPeriodUs[HAL_GPT_COUNT];
static BOOL               s_gptRunning[HAL_GPT_COUNT];

static BOOL   s_gptInitDone = FALSE;
static UINT32 s_gptClkHz = 0u;
static UINT32 s_gptNextCompare = 0u;

volatile hal_gpt_dbg_t g_hal_gpt_dbg = {0};


/** Capture a snapshot of the GPT live registers for debugging purposes */
volatile UINT32 g_gpt_live_cnt = 0u;
volatile UINT32 g_gpt_live_ocr1 = 0u;
volatile UINT32 g_gpt_live_sr = 0u;
volatile UINT32 g_gpt_live_ir = 0u;
volatile UINT32 g_gpt_live_cr = 0u;
volatile UINT32 g_hal_gpt_rearmCount = 0u;
volatile UINT32 g_hal_gpt_lastRearmCnt = 0u;
volatile UINT32 g_hal_gpt_lastRearmOcr = 0u;

void hal_gpt_debug_snapshot(void)
{
    g_gpt_live_cnt  = GPT_GetCurrentTimerCount(IOL_SIL_GPT);
    g_gpt_live_ocr1 = IOL_SIL_GPT->OCR[0];
    g_gpt_live_sr   = IOL_SIL_GPT->SR;
    g_gpt_live_ir   = IOL_SIL_GPT->IR;
    g_gpt_live_cr   = IOL_SIL_GPT->CR;
}

/*******************************************************************************
*                       hal_timer_init_gpt                                     *
*                       ==================                                     *
* PURPOSE:                                                                     *
*    Initialize GPT1 peripheral                                                *
* ARGUMENTS:                                                                   *
*    None.                                                                     *
* RETURN:                                                                      *
*    None.                                                                     *
* NOTES:                                                                       *
*    None.                                                                     *
*******************************************************************************/
static void hal_gpt_init(void)
{
    if (s_gptInitDone) {
        return;
    }

    g_hal_gpt_dbg.initCount++;

    gpt_config_t cfg;
    GPT_GetDefaultConfig(&cfg);
    cfg.enableRunInStop = false;
    cfg.enableRunInWait = true;
    cfg.enableRunInDoze = false;
    cfg.enableFreeRun = true;

    CLOCK_EnableClock(kCLOCK_Gpt1);
    GPT_Init(IOL_SIL_GPT, &cfg);

    GPT_SetClockSource(IOL_SIL_GPT, kGPT_ClockSource_Periph);
    GPT_SetClockDivider(IOL_SIL_GPT, 1u);

    /* For kGPT_ClockSource_Periph, use IPG clock */
    s_gptClkHz = CLOCK_GetFreq(kCLOCK_IpgClk);
    if (s_gptClkHz == 0u) {
        s_gptClkHz = CLOCK_GetFreq(kCLOCK_PerClk);
    }
    if (s_gptClkHz == 0u) {
        s_gptClkHz = SystemCoreClock;
    }

    GPT_DisableInterrupts(IOL_SIL_GPT, IOL_SIL_GPT_IRQ_ENABLE);
    GPT_ClearStatusFlags(IOL_SIL_GPT, IOL_SIL_GPT_FLAG);
    NVIC_ClearPendingIRQ(IOL_SIL_GPT_IRQn);
    NVIC_SetPriority(IOL_SIL_GPT_IRQn, HAL_IRQ_PRIO_GHO);

    s_gptInitDone = TRUE;
}

static UINT32 hal_gpt_us_to_ticks(UINT32 us, UINT32 clk_hz)
{
    uint64_t t = ((uint64_t)clk_hz * (uint64_t)us + 999999ull) / 1000000ull;
    if (t == 0ull) t = 1ull;
    if (t > 0xFFFFFFFFull) t = 0xFFFFFFFFull;
    return (UINT32)t;
}

void hal_gpt_configure(HAL_GPT_ID gpt_id, UINT32 period_us, hal_gpt_callback_t callback)
{
    if ((gpt_id >= HAL_GPT_COUNT) || (callback == NULL)) {
        return;
    }

    if (period_us == 0u) {
        period_us = 1u;
    }

    hal_gpt_init();

    s_gptCallbacks[gpt_id] = callback;
    s_gptRunning[gpt_id] = FALSE;

    if (gpt_id == HAL_GPT_IOL_SIL) {
        UINT32 per_ticks = hal_gpt_us_to_ticks(period_us, s_gptClkHz);
        s_gptPeriodUs[gpt_id] = per_ticks;

        s_gptNextCompare = GPT_GetCurrentTimerCount(IOL_SIL_GPT) + per_ticks;

        GPT_SetOutputCompareValue(IOL_SIL_GPT, IOL_SIL_GPT_CHANNEL, s_gptNextCompare);

        s_gptRunning[gpt_id] = TRUE;
        GPT_EnableInterrupts(IOL_SIL_GPT, IOL_SIL_GPT_IRQ_ENABLE);
        NVIC_ClearPendingIRQ(IOL_SIL_GPT_IRQn);
        NVIC_EnableIRQ(IOL_SIL_GPT_IRQn);
        GPT_StartTimer(IOL_SIL_GPT);
        return;
    }
}

void hal_gpt_start(HAL_GPT_ID gpt_id)
{
    if (gpt_id >= HAL_GPT_COUNT) {
        return;
    }

    if (gpt_id == HAL_GPT_IOL_SIL) {
        hal_gpt_init();
        g_hal_gpt_dbg.startCount++;

        if (s_gptPeriodUs[gpt_id] == 0u) {
            s_gptPeriodUs[gpt_id] = 1u;
        }
        g_hal_gpt_dbg.lastPeriodTicks = s_gptPeriodUs[gpt_id];

        GPT_StopTimer(IOL_SIL_GPT);
        GPT_ClearStatusFlags(IOL_SIL_GPT, IOL_SIL_GPT_FLAG);

        s_gptNextCompare = GPT_GetCurrentTimerCount(IOL_SIL_GPT) + s_gptPeriodUs[gpt_id];
        g_hal_gpt_dbg.lastCnt = GPT_GetCurrentTimerCount(IOL_SIL_GPT);
        g_hal_gpt_dbg.lastCmp = s_gptNextCompare;

        GPT_SetOutputCompareValue(IOL_SIL_GPT, IOL_SIL_GPT_CHANNEL, s_gptNextCompare);

        s_gptRunning[gpt_id] = TRUE;
        GPT_EnableInterrupts(IOL_SIL_GPT, IOL_SIL_GPT_IRQ_ENABLE);
        NVIC_ClearPendingIRQ(IOL_SIL_GPT_IRQn);
        NVIC_EnableIRQ(IOL_SIL_GPT_IRQn);
        GPT_StartTimer(IOL_SIL_GPT);
        return;
    }

}

void hal_gpt_stop(HAL_GPT_ID gpt_id)
{
    if (gpt_id >= HAL_GPT_COUNT) {
        return;
    }

    if (gpt_id == HAL_GPT_IOL_SIL) {
        g_hal_gpt_dbg.stopCount++;
        s_gptRunning[gpt_id] = FALSE;

        GPT_DisableInterrupts(IOL_SIL_GPT, IOL_SIL_GPT_IRQ_ENABLE);
        GPT_StopTimer(IOL_SIL_GPT);
        GPT_ClearStatusFlags(IOL_SIL_GPT, IOL_SIL_GPT_FLAG);
        NVIC_ClearPendingIRQ(IOL_SIL_GPT_IRQn);
        return;
    }

}

UINT32 hal_gpt_get_count(HAL_GPT_ID gpt_id)
{
    if (gpt_id >= HAL_GPT_COUNT) {
        return 0u;
    }

    if (gpt_id == HAL_GPT_IOL_SIL) {
        hal_gpt_init();

        const UINT32 ticks = GPT_GetCurrentTimerCount(IOL_SIL_GPT);
        if (s_gptClkHz == 0u) {
            return 0u;
        }

        uint64_t us = ((uint64_t)ticks * 1000000ull) / (uint64_t)s_gptClkHz;
        if (us > 0xFFFFFFFFull) {
            us = 0xFFFFFFFFull;
        }
        return (UINT32)us;
    }

    return 0u;
}

VOID hal_gpt_rearm_us(HAL_GPT_ID gpt_id, UINT32 period_us)
{
    if (gpt_id >= HAL_GPT_COUNT) {
        return;
    }

    if (period_us == 0u) {
        period_us = 1u;
    }

    hal_gpt_init();

    if (gpt_id == HAL_GPT_IOL_SIL) {
        uint64_t ticks = ((uint64_t)s_gptClkHz * (uint64_t)period_us + 999999ull) / 1000000ull;
        UINT32 per = (ticks == 0ull) ? 1u : (UINT32)((ticks > 0xFFFFFFFFull) ? 0xFFFFFFFFu : ticks);

        if (per < HAL_GPT_MIN_REARM_GUARD_TICKS) {
            per = HAL_GPT_MIN_REARM_GUARD_TICKS;
        }

        s_gptPeriodUs[gpt_id] = per;

        UINT32 now = GPT_GetCurrentTimerCount(IOL_SIL_GPT);
        s_gptNextCompare = now + per;

        GPT_SetOutputCompareValue(IOL_SIL_GPT, IOL_SIL_GPT_CHANNEL, s_gptNextCompare);

        g_hal_gpt_rearmCount++;
        g_hal_gpt_lastRearmCnt = now;
        g_hal_gpt_lastRearmOcr = s_gptNextCompare;

        GPT_ClearStatusFlags(IOL_SIL_GPT, IOL_SIL_GPT_FLAG);
        GPT_EnableInterrupts(IOL_SIL_GPT, IOL_SIL_GPT_IRQ_ENABLE);
        NVIC_EnableIRQ(IOL_SIL_GPT_IRQn);
        GPT_StartTimer(IOL_SIL_GPT);

        s_gptRunning[gpt_id] = TRUE;
    }
}

static void hal_gpt_irq_dispatch(HAL_GPT_ID id)
{
    if ((id < HAL_GPT_COUNT) && s_gptRunning[id] && (s_gptCallbacks[id] != NULL)) {
        s_gptCallbacks[id]();
    }
}

void GPT1_DriverIRQHandler(void)
{
    /* Count IRQ entry here (works even if GPT1_IRQHandler wrapper is bypassed) */
    g_hal_gpt_dbg.irqEntryCount++;

    uint32_t flags = GPT_GetStatusFlags(IOL_SIL_GPT, IOL_SIL_GPT_FLAG);
    g_hal_gpt_dbg.lastFlags = flags;

    if ((flags & (uint32_t)IOL_SIL_GPT_FLAG) != 0u) {
        g_hal_gpt_dbg.irqOc1Count++;
        GPT_ClearStatusFlags(IOL_SIL_GPT, IOL_SIL_GPT_FLAG);

        if (s_gptRunning[HAL_GPT_IOL_SIL]) {
            UINT32 now = GPT_GetCurrentTimerCount(IOL_SIL_GPT);
            UINT32 per = s_gptPeriodUs[HAL_GPT_IOL_SIL];
            if (per < HAL_GPT_MIN_REARM_GUARD_TICKS) {
                per = HAL_GPT_MIN_REARM_GUARD_TICKS;   /* avoid missing next compare */
            }
            s_gptNextCompare = now + per;
            g_hal_gpt_dbg.lastCnt = now;
            g_hal_gpt_dbg.lastCmp = s_gptNextCompare;
            g_hal_gpt_dbg.lastPeriodTicks = per;

            GPT_SetOutputCompareValue(IOL_SIL_GPT, IOL_SIL_GPT_CHANNEL, s_gptNextCompare);

            if (s_gptCallbacks[HAL_GPT_IOL_SIL] != NULL) {
                hal_gpt_irq_dispatch(HAL_GPT_IOL_SIL);
                g_hal_gpt_dbg.cbCount++;
            }
        }
    } else {
        g_hal_gpt_dbg.irqSpuriousCount++;
    }

    __DSB();
}

void GPT1_IRQHandler(void)
{
    GPT1_DriverIRQHandler();
}

#endif /* RT1024_BUILD */
