/*******************************************************************************
*                         CSysE, Fort Washington, PA.                          *
*                                                                              *
*                              COPYRIGHT (C) 2026                              *
*                 HONEYWELL INDUSTRIAL AUTOMATION AND CONTROLS                 *
*                              ALL RIGHTS RESERVED                             *
*                                                                              *
*   This software is a copyrighted work and / or information protected as a    *
*   trade secret.  Legal rights of Honeywell Inc. in this software is distinct *
*   from ownership of any medium in which the software is embodied. Copyright  *
*   or trade secret notices included must be reproduced in any copies that are *
*   authorized by Honeywell Inc.                                               *
*                                                                              *
*   The information in this software is subject to change without notice and   *
*   should not be considered as a commitment by Honeywell Inc.                 *
*                                                                              *
* ============================================================================ *
*    File Name   : hal_platform.h                                              *
*    Description : Platform detection and build configuration.                 *
*                  Defines exactly ONE of:                                      *
*                    RT1024_BUILD  - iMXRT1024 MCUXpresso target               *
*                    QEMU_BUILD    - MPS2-AN500 QEMU emulation target          *
*                    UNIT_TEST_BUILD - Host PC GoogleTest target                *
*******************************************************************************/
#ifndef HAL_PLATFORM_H
#define HAL_PLATFORM_H

/*******************************************************************************
*  Platform detection — only one should be active at build time.               *
*  The build system (CMake, Makefile, MCUXpresso) defines one of these.        *
*******************************************************************************/
#if defined(UNIT_TEST_BUILD)
    /* Tier 1: GoogleTest on host PC — no hardware at all */
#elif defined(QEMU_BUILD)
    /* Tier 2: MPS2-AN500 QEMU emulation — Cortex-M7, CMSDK peripherals */
#elif defined(RT1024_BUILD) || defined(CPU_MIMXRT1024DAG5A) || defined(CPU_MIMXRT1024DAG5B)
    /* Tier 3: Real hardware — NXP iMXRT1024 */
    #ifndef RT1024_BUILD
    #define RT1024_BUILD 1
    #endif
    /* Enable real SPI drivers for FPGA, ADC, EEPROM */
    #ifndef HAL_FPGA_SPI_ENABLED
    #define HAL_FPGA_SPI_ENABLED 1
    #endif
#else
    /* Default to RT1024 if building from MCUXpresso which defines the CPU */
    #define RT1024_BUILD 1
    #define HAL_FPGA_SPI_ENABLED 1
#endif

/* Module type — AIH only for this repository (no conditional compilation) */
#define IOMTYPE_AIH 1

/* High-End Kernel — AIH uses CPLD, FPGA, external SRAM */
#define HEK 1

/* Not low-cost (AIH with HART is full-featured) */
#define LOWCOST 0

#define NOP  __asm volatile("nop")

/**********************************************************************************
*  UART ASSIGNMENT — Prototype Board Configuration                                *
*                                                                                 *
*  Define AIH_PROTO_V1 to select the CURRENT prototype board wiring:             *
*    AIH_PROTO_V1 defined  (Proto1):  IOLink = LPUART1, DebugPort = LPUART2      *
*    HLAI_PROTO_V1 undefined (Proto1b): IOLink = LPUART2, DebugPort = LPUART1     *
*                            (Proto1b matches RT1024 serial downloader on LPUART1)*
*                                                                                 *
*  The Proto1b board revision will NOT define AIH_PROTO_V1.                      *
*  Set this via build system: -DAIH_PROTO_V1=1                                   *
***********************************************************************************/
#if !defined(AIH_PROTO_V1)
    /* Default: uncomment below for current prototype, or pass -DAIH_PROTO_V1=1 */
    #define AIH_PROTO_V1 0 // PROTO 2

#endif

/*******************************************************************************
*                        INTERRUPT PRIORITY CONTROL                            *
*  Replaces H8S set_imask_exr() / LPC17xx __set_BASEPRI()                    *
*                                                                              *
*  H8S convention: 0=lowest (all enabled) .. 7=highest (all blocked).         *
*  ARM convention: 0=highest priority .. 15=lowest.  BASEPRI masks >=value.   *
*                                                                              *
*  The mapping inverts the numbering so that higher H8S levels block more     *
*  interrupts, matching the original firmware behavior:                        *
*    LVLPRI_LOWEST(0)  -> BASEPRI=0    : nothing blocked                      *
*    LVLPRI_TASK(1)    -> BASEPRI=0xC0 : blocks ARM prio >= 12               *
*    LVLPRI_GHO(4)     -> BASEPRI=0x80 : blocks ARM prio >= 8                *
*    LVLPRI_TICK(5)    -> BASEPRI=0x60 : blocks ARM prio >= 6                *
*    LVLPRI_HIGHEST(7) -> BASEPRI=0x10 : blocks ARM prio >= 1 (everything)   *
*                                                                              *
*  Only LVLPRI_HIGHEST can block the IOL UART (ARM prio 2).                   *
*******************************************************************************/

/* ARM NVIC priority assignments for RT1024 (0=highest, 15=lowest).
 * Chosen so that BASEPRI thresholds above produce correct blocking sets. */
#define HAL_IRQ_PRIO_IOL_UART    1   	/* IOL UART — only blocked by HIGHEST    */
#define HAL_IRQ_PRIO_HART        2   	/* GPT2 HART event; no SPI work in ISR   */
#define HAL_IRQ_PRIO_SYSTICK     3   	/* SysTick  — blocked by TICK & HIGHEST  */
#define HAL_IRQ_PRIO_GHO         1   	/* GHO GPIO — blocked by GHO, TICK, HIGH */
#define HAL_IRQ_PRIO_DBG_UART    6  	/* Debug    — blocked by TASK and above  */

#endif /* HAL_PLATFORM_H */
